#coding=utf-8
import xlwt

# 使用说明:
# 安装环境: pip3 install xlwt
# 运行: python3 log_analyse.py
# 打开: data.xls

#TODO: 在此添加其他的默模块
name_filters  = ["CD", "CDPH", "MOS", "RD", "IOT", "ET", "SP", "CFG", "TS", "SWD", "CMD", "IO", "AP", "GA", "CFG", "ZJ", "APP", "OTA", "P2P", "CH", "AI", "PTZ", "AC", "RF", "BC"]
level_filters = ["INFO", "WARN", "ERR"]

#设置表格样式
def set_stlye(name,height,colour_index,bold=False,_alignment=False):
    #初始化样式
    style = xlwt.XFStyle()
    #创建字体
    font = xlwt.Font()
    font.bold = bold
    font.colour_index = 0 # black
    font.height = height
    font.name =name
    style.font = font

    if _alignment:
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER    #水平居中
        alignment.vert = xlwt.Alignment.VERT_CENTER    #垂直居中
        style.alignment = alignment

    return style

def set_stlye_from_level(name,height,level,bold=False,_alignment=False):
    #初始化样式
    style = xlwt.XFStyle()
    #创建字体
    font = xlwt.Font()
    font.bold = bold

    if level == "INFO":
        font.colour_index = 17 #green
    elif level == "WARN":
        font.colour_index = 51 #yellow
    elif level == "ERR":
        font.colour_index = 10 #red

    font.height = height
    font.name =name
    style.font = font

    if _alignment:
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER    #水平居中
        alignment.vert = xlwt.Alignment.VERT_CENTER    #垂直居中
        style.alignment = alignment

    return style

#写入数据
def write_excel(data, allcount):
    count  = 0
    offset = 1
    column0 = []
    for k,v in allcount.items():
        if v != 0:
            column0.append(k)
    
    f = xlwt.Workbook()
    
    #创建sheet1
    sheet1 = f.add_sheet(u'sheet1',cell_overwrite_ok=True)
    row0 = ['Module','Level','Text']

    #设置第一行标题的宽度
    sheet1.col(0).width = 256 * 20
    sheet1.col(1).width = 256 * 20
    sheet1.col(2).width = 256 * 20

    for i in range(0,len(row0)):
        sheet1.write(0,i,row0[i],set_stlye("Time New Roman",220,0,True,True))
        i,j = 1,0
    for module in column0:
        count = allcount[module]
        sheet1.write_merge(offset,offset + count - 1,0,0,module,set_stlye('Arial',220,0,True,True))
        offset += count

    offset = 0
    for module in column0:
        i = 0
        for level_fil in level_filters:
            if len(data["%s"%(module)+" %s"%(level_fil)]) != 0:
                for d in data["%s"%(module)+" %s"%(level_fil)]:
                    sheet1.write(i+offset+1,1,"%s"%(module)+" %s"%(level_fil),set_stlye_from_level('Arial',220,level_fil,False,True))
                    sheet1.write(i+offset+1,2,d,set_stlye_from_level('Arial',220,level_fil,False,False))
                    i += 1
        offset += allcount[module]
    f.save('data.xls')

def deviceSdkLogHandle():

    data     = {}
    count    = {}
    allcount = {}

    for name_fil in name_filters:
        allcount[name_fil] = 0
        for level_fil in level_filters:
            count["%s"%(name_fil)+" %s"%(level_fil)] = 0
            data["%s"%(name_fil)+" %s"%(level_fil)] = []

    try:
        for index in range(0, 2):
            f0 = open("TestPath/system/config/log/hm_run_%d.log"%(index),encoding='utf-8')
            while True:
                line = f0.readline()
                if line:
                    for name_fil in name_filters:
                        for level_fil in level_filters:
                            if (name_fil in line) and (level_fil in line):
                                allcount[name_fil] = allcount[name_fil] + 1
                                count["%s"%(name_fil)+" %s"%(level_fil)] = count["%s"%(name_fil)+" %s"%(level_fil)] + 1
                                data["%s"%(name_fil)+" %s"%(level_fil)].append(line)
                else:
                    break
            f0.close()
    except:
        print("发现异常字节，已跳过...")
    write_excel(data, allcount)

if __name__ == "__main__":
    deviceSdkLogHandle()