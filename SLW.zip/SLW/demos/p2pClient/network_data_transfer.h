#ifndef NETWORK_DATA_TRANSFER_H
#define NETWORK_DATA_TRANSFER_H
#include <errno.h>
#include <error.h>

class NetworkDataTransfer
{
public:
    NetworkDataTransfer();
    static NetworkDataTransfer& instance()
    {
        static NetworkDataTransfer instance_;
        return instance_;
    }

    static int  send_data( int sockfd,  char *buf,int len);
    static int  recieve_data( int sockfd, char* buf,int len);
    static int  send_data_nowait(int sockfd, char *buf, int len);
    static int  recieve_data_nowait(int sockfd, char *buf, int len);
};

#endif // NETWORK_DATA_TRANSFER_H
