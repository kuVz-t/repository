#include "network_data_transfer.h"
#include <sys/select.h>
#include <sys/types.h>
#include <sys/socket.h>
/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

//DWORD TimeOut = 2000; //设置发送超时6秒
//		if(setsockopt(sockfd1, SOL_SOCKET,SO_SNDTIMEO, (char *)&TimeOut, sizeof(TimeOut)) == SOCKET_ERROR)
//		{
//			goto ERROR_CLOSE;
//		}
//		TimeOut = 2000;//设置接收超时6秒
//		if(setsockopt(sockfd1,SOL_SOCKET,SO_RCVTIMEO,(char *)&TimeOut,sizeof(TimeOut))==SOCKET_ERROR)
//		{
//			goto ERROR_CLOSE;
//		}
int  NetworkDataTransfer::send_data( int sockfd, char *buf,int len)
{
    int rnflag=0;
    fd_set sendfds;
    struct timeval timeout;
    timeout.tv_sec=2;
    timeout.tv_usec=0;
    FD_ZERO(&sendfds);
    FD_SET(sockfd,&sendfds);


    int iRet = select(sockfd+1, NULL, &sendfds, NULL, &timeout);

    if(iRet > 0)
    {
//        rnflag=send(sockfd,(char *)buf,len,0);
        int nwritten;

        nwritten = 0;
        while ( nwritten < len )
        {
            int r;

            r = send( sockfd, (char*) buf + nwritten, len - nwritten, 0 );
            if ( r < 0 && ( errno == EINTR || errno == EAGAIN ) )
            {
                continue;
            }
            if ( r < 0 )
                return r;
            if ( r == 0 )
                break;
            nwritten += r;
        }

        return nwritten;
    }
    return rnflag;
}

int  NetworkDataTransfer::send_data_nowait( int sockfd, char *buf,int len)
{
    int rnflag=0;
    fd_set sendfds;
    struct timeval timeout;
    timeout.tv_sec=2;
    timeout.tv_usec=0;
    FD_ZERO(&sendfds);
    FD_SET(sockfd,&sendfds);


    int iRet = select(sockfd+1, NULL, &sendfds, NULL, &timeout);

    if(iRet > 0)
    {
        rnflag=send(sockfd,(char *)buf,len,0);
    }
    return rnflag;
}

//  ================================================================================//
//  recive data
//  ================================================================================//
int NetworkDataTransfer::recieve_data( int sockfd,char* buf,int len)
{
    int rnflag=0;
     fd_set readfds;
    struct timeval timeout;
    timeout.tv_sec=2;
    timeout.tv_usec=0;
    FD_ZERO(&readfds);
    FD_SET(sockfd,&readfds);

    int iRet = select(sockfd+1, &readfds, NULL, NULL, &timeout);
    if(iRet > 0)
    {
        //printf("recive data furnciton file describtion!\n");
        #if 0
        rnflag=recvfrom(sockfd,(char *)buf,len,0,NULL,NULL);
        #elif 1
//        rnflag= recv(sockfd, buf, len, 0);
        int nread;

        nread = 0;
        while ( nread < len )
        {
            int r;

            r = recv( sockfd, (char*) buf + nread, len - nread , 0 );
            printf("fun:%s %d, recvsize:%d\n", __FUNCTION__, __LINE__, r);
            if ( r < 0 && ( errno == EINTR || errno == EAGAIN ) )
            {
                continue;
            }
            if ( r < 0 )
                return r;
            if ( r == 0 )
                break;
            nread += r;
        }

        return nread;
        #else
        rnflag=recvfrom(sockfd,(char *)buf,len,0,&recvAdd,&addLen);
        #endif
    }

    return rnflag;
}

//  ================================================================================//
//  recive data
//  ================================================================================//
int NetworkDataTransfer::recieve_data_nowait( int sockfd,char* buf,int len)
{
    int rnflag=0;
//    int recvAdd;
//    int addLen=sizeof(sockaddr);
//    char textBuff[64]={0,};

    fd_set readfds;
    struct timeval timeout;
    timeout.tv_sec=2;
    timeout.tv_usec=0;
    FD_ZERO(&readfds);
    FD_SET(sockfd,&readfds);

    int iRet = select(sockfd+1, &readfds, NULL, NULL, &timeout);
    if(iRet > 0)
    {
        //printf("recive data furnciton file describtion!\n");
        #if 1
        rnflag=recvfrom(sockfd,(char *)buf,len,0,NULL,NULL);
        #elif 1
//        rnflag= recv(sockfd, buf, len, 0);
        int nread;

        nread = 0;
        while ( nread < len )
        {
            int r;

            r = recv( sockfd, (char*) buf + nread, len - nread , 0 );
            if ( r < 0 && ( errno == EINTR || errno == EAGAIN ) )
            {
                continue;
            }
            if ( r < 0 )
                return r;
            if ( r == 0 )
                break;
            nread += r;
        }

        return nread;
        #else
        rnflag=recvfrom(sockfd,(char *)buf,len,0,&recvAdd,&addLen);
        #endif
    }

    return rnflag;
}

NetworkDataTransfer::NetworkDataTransfer()
{

}
