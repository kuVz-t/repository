#ifndef SIGNALSERVERCOM_H
#define SIGNALSERVERCOM_H
#include "g_defines.h"

class SignalServerCom
{
public:
    SignalServerCom();
    void InitServerInfo(char *ipaddr, int port);
    void SetDeviceToken(char *token);
    bool ConnectServer();


    int httpdWrite(int fd, const void *buf, size_t nbytes);
    void SendLoginReq(char *userToken);
    void SendGetUserListReq(char *userToken);

    char *GetRandNumber();
    int ReciveData(char *buffer, int len);
    int SendMessage(int sockfd, char *buffer_send, size_t len);
    int SendMediaMessage(int sockfd, char *buffer_send, size_t len, int type, int method);
    void SendDeviceSdpReq(char *userToken, char *toUserToken, char *mySdpInfo);

    int GetSokcet()
    {
        return m_socket_signal;
    }

    int ParseJasonInfo(char *buffer, int length, char* sdpInfo, char* pFrom, char*pTo);
private:
    char         m_signalIp[64];
    unsigned int m_signalPort;
    int          m_socket_signal;
    int          m_randNumber;
    char         m_deviceToken[64];
    int          m_debug;
};

#endif // SIGNALSERVERCOM_H
