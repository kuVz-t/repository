#ifndef G_DEFINES_H
#define G_DEFINES_H
#include  <stdio.h>
#include  <unistd.h>
#include  <error.h>
#include  <sys/types.h>
#include  <sys/stat.h>
#include  <fcntl.h>
#include  <errno.h>
#include  "string.h"
#include  "stdlib.h"

#pragma pack (4)
typedef struct TcpHeader
{
    char m_flag[2]; //#$
    char m_type;
    char m_method;
    short m_datalen;
    char  m_encrypt;
    char  m_reserver;
}structTcpHeader;

typedef enum ICE_TRANS_STATUS
{
    ICE_TRANS_STATUS_INIT = 0,//
    ICE_TRANS_STATUS_LINKING =1,//offer
    ICE_TRANS_STATUS_SDPREQ = 2,
    ICE_TRANS_STATUS_SDPRESP =3,
    ICE_TRANS_STATUS_START =4,
    ICE_TRANS_STATUS_COMPLITE=5,
    ICE_TRANS_STATUS_BECONNECT=6,//answer

}ENUM_ICE_TRANS_STATUS;

#pragma pack ()

#endif // G_DEFINES_H

