/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: user
 *
 * Created on June 5, 2017, 9:08 AM
 */ 
#include <iostream>
#include <unistd.h> 
#include "IceTransport.h"
#include "pj/log.h" 
#include "SignalServerCom.h"
#include "network_data_transfer.h"
#include <poll.h>  

using namespace std;
char  serverIp[32] = {"106.55.39.76"};
short serverPort  = 8090;
char  deviceToken[32] = {"15361790660"};

#define SDP_BUFFER_LEN 4000
#define MAX_RECIVE_SIZE 4096
#define WAIT_MILLI_SEC (100 * 1000)
static void log_writer(int level, const char *buffer, int len)
{
    if (access("/tmp/debug_log", F_OK) == 0)
    printf("log-len:%d :%s \n", len, buffer);
}

int processKey(IceTransport* trans1, IceTransport* trans2);
int waitState(IceTransport* trans1, IceTransport* trans2, pj_ice_strans_state state);

static void icedemoPrintMenu(void)
{
    puts("");
    puts("+----------------------------------------------------------------------+");
    puts("|                    M E N U                                           |");
    puts("+---+------------------------------------------------------------------+");
    puts("| c | checklist        getClient the instance                          |");
    puts("| l | connect          l:xxxxxx ,xxx is userId                         |");
    puts("| i | init o|a         Initialize ICE session as offerer or answerer   |");
    puts("| e | stop             End/stop ICE session                            |");
    puts("| s | show             Display local ICE info                          |");
    puts("| r | remote           Input remote ICE info                           |");
    puts("| b | start            Begin ICE negotiation                           |");
    puts("| x | send <compid> .. Send data to remote                             |");
    puts("+---+------------------------------------------------------------------+");
    puts("| h |  help            * Help! *                                       |");
    puts("| q |  quit            Quit                                            |");
    puts("+----------------------------------------------------------------------+");
}

ENUM_ICE_TRANS_STATUS ice_status = ICE_TRANS_STATUS_INIT;
int main(int argc, char** argv)
{
    char sdp1[SDP_BUFFER_LEN] = {0};
    char sdp2[SDP_BUFFER_LEN] = {0};
    char buffer[MAX_RECIVE_SIZE] = {0};
    unsigned int role = 'a';
    int enable = 0;
    //char *person = nullptr;

    if (argc < 2)
    {
        printf("userage %s answer|offer [myuserId] [noturn /1/0] ", argv[0]);
        return 0;
    }

    for (int a=0; a<argc; a++)
    {
        printf("argc:%d argv:%s\n",a, argv[a]);
    }

    if (strstr(argv[1], "offer") != NULL)
    {
        role = 'o';
        strcpy(deviceToken, "13711234291");
    }

    if (argc >= 3)
    {
        strcpy(deviceToken, argv[2]);
    }

    if (argc >= 4)
    {
        enable = atoi(argv[3]);        
    }

    pj_log_set_log_func(&log_writer);
    IceTransport* transport1 = new IceTransport();
    SignalServerCom  ServerInstance;
    ServerInstance.InitServerInfo(serverIp, serverPort);
    if (ServerInstance.ConnectServer())
    {
          ServerInstance.SendLoginReq(deviceToken);
          int ret = ServerInstance.ReciveData(buffer, sizeof(buffer));
          printf("recive len:%d data:\n", ret);
          ServerInstance.SendGetUserListReq(deviceToken);
          memset(buffer, 0, sizeof(buffer));
          ret = ServerInstance.ReciveData(buffer, sizeof(buffer));
          printf("getlist recive len:%d  \n", ret);
    }

    transport1->setOptions(enable);
    transport1->setRole(role);
    transport1->setName("transport1");
    transport1->init();
    transport1->start();
    transport1->getLocalSDP(sdp1, SDP_BUFFER_LEN);
    printf("sdp1: %s\n", sdp1);
    printf("transfer 2 start!!>>>> my deviceToken:%s\n", deviceToken);

//    ServerInstance.SendDeviceSdpReq(deviceToken, "QH-20151105CXGZ", sdp1);
//    int ret = ServerInstance.ReciveData(buffer, sizeof(buffer));
//    printf("recive len:%d data:\n", ret);

    int sockfd = ServerInstance.GetSokcet();
    struct pollfd connect_in[2] = { {sockfd, POLLIN, 0 }, {STDIN_FILENO, POLLIN, 0}};//| POLLOUT

    ice_status = ICE_TRANS_STATUS_INIT;
    while(1)
    {
        int result = poll( connect_in, 2, 100 );

        if ( result < 0 )
        {
            perror( "Error in audio listening" );
        }
        else if (result == 0)
        {

        }
        else if (result  > 0)
        {
            for (int i=0; i<2; i++)
            {
                if ( ( connect_in[i].revents & POLLIN ) != 0 )
                {
                    if (connect_in[i].fd == STDIN_FILENO)
                    {
                        char str[32] = {0};
                        fgets(str, sizeof(str), stdin);
                        printf("input string: %s\n", str);
                        if ( strstr(str, "help") != NULL)
                        {
                            icedemoPrintMenu();
                        }
                        else
                        {
                            int value = str[0];
                            switch (value)
                            {
                            case 'c':
                                ServerInstance.SendGetUserListReq(deviceToken);
                                break;

                            case 'l':
                            {
                                char *p=(char*)strchr(str, ':');
                                char *q=(char*)strchr(str, '\n');
                                *q='\0';
                                if (p != NULL)
                                {
                                    p++;
                                    ServerInstance.SendDeviceSdpReq(deviceToken, p, sdp1);
                                    ice_status = ICE_TRANS_STATUS_LINKING;
                                }
                            }
                                break;

                            case 's':
                                transport1->showIceInfo();
                                break;


                            case 'w':
                            {
                                char *p=(char*)strchr(str, ':');
                                char *q=(char*)strchr(str, '\n');
                                *q='\0';
                                if (p != NULL)
                                {
                                    p++;
                                    transport1->sendData(1, p);
                                }
                            }
                                break;

                            default:
                                icedemoPrintMenu();
                                break;
                            }

                        }
                    }
                    else if (connect_in[i].fd == sockfd)
                    {
                       int ret = ServerInstance.ReciveData(buffer, sizeof(buffer));
                       printf("%s recive len:%d  \n", __FUNCTION__, ret);

                       char strFrom[64]={0};
                       char strTo[64]={0};
                       int  bRet = ServerInstance.ParseJasonInfo(buffer+sizeof(structTcpHeader),
                                                                 ret-sizeof(structTcpHeader),
                                                                 (char*)sdp2, strFrom, strTo) ; 
                       //recive sdp info
                       if (bRet == 1)
                       {
                            transport1->setRemoteSDP(sdp2);
                            if (ice_status == ICE_TRANS_STATUS_LINKING)//peer to connect
                            {
                                printf("start negotiation >>>>>>>>>>>>>>>>>>>>\n");
                                transport1->startNegotiation();
                                ice_status = ICE_TRANS_STATUS_START;
                            }
                            else if (ice_status == ICE_TRANS_STATUS_INIT)//peer to connect
                            {
                                printf("recive connect device from:%s >>>>>>>>>>>>>>>>>>>>\n", strFrom);
                                ice_status = ICE_TRANS_STATUS_BECONNECT;
                                ServerInstance.SendDeviceSdpReq(deviceToken, strFrom, sdp1);
                            }
                       }
                       else if (bRet == 2)
                       {
                           if (ice_status == ICE_TRANS_STATUS_LINKING || ice_status == ICE_TRANS_STATUS_BECONNECT)//peer to connect
                           {
                               printf("start negotiation >>>>>>>>>>>>>>>>>>>>\n");
                               transport1->startNegotiation();
                               ice_status = ICE_TRANS_STATUS_START;
                           }
                       }
                    }
                }
            }
        }
    }

#if 0
    IceTransport* transport2 = new IceTransport();
    transport2->setOptions();
    transport2->setRole('o');
    transport2->setName("transport2");
    transport2->init();
    printf("transfer 2 init!!###################");
    transport2->start();
     getchar();
     transport1->setRemoteSDP(sdp2);
     transport1->startNegotiation();

    sleep(5);
    waitState(transport1, transport2, PJ_ICE_STRANS_STATE_READY);

    transport1->getLocalSDP(sdp1, SDP_BUFFER_LEN);
    transport2->getLocalSDP(sdp2, SDP_BUFFER_LEN);
    printf("sdp1: %s\n", sdp1);
    printf("sdp2: %s\n", sdp2);
    getchar();

    transport2->setRemoteSDP(sdp1);
    transport2->startNegotiation();

    waitState(transport1, transport2, PJ_ICE_STRANS_STATE_RUNNING);

    processKey(transport1, transport2);
#endif
    transport1->stop();
    transport1->deinit();
    delete transport1;
    transport1 = NULL;

    return 0;
}

int processKey(IceTransport* trans1, IceTransport* trans2) {
    bool run = 1;

    while (run) {
        char str[8];

        fgets(str, sizeof(str), stdin);
        switch (str[0]) {
            case '1':
            {
                trans1->sendData(1, "data from t1 c1");
                break;
            }
            case '2':
            {
                trans1->sendData(2, "data from t1 c2");
                break;
            }
            case '3':
            {
                trans2->sendData(1, "data from t2 c1");
                break;
            }
            case '4':
            {
                trans2->sendData(2, "data from t2 c2");
                break;
            }
            case 's':
            {
                trans1->showIceInfo();
                break;
            }
            case 'd':
            {
                trans2->showIceInfo();
                break;
            }
            case 'q':
            {
                run = 0;
                break;
            }

        }
    }
}

int waitState(IceTransport* trans1, IceTransport* trans2, pj_ice_strans_state state)
{
    while (1) {
        usleep(WAIT_MILLI_SEC);
        if ((pj_ice_strans_get_state(trans1->icest) == state)
                &&(pj_ice_strans_get_state(trans2->icest) == state)
                ) {
            break;
        }
    }
    
    return 0;
}
