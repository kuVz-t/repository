#include "SignalServerCom.h"
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include "cJSON.h"
#include "network_data_transfer.h"
#include <arpa/inet.h>

#define MAXLINE 4096

void wrapTcpHeader(structTcpHeader &header, int type, int method, int lenght)
{
    header.m_flag[0]='#';
    header.m_flag[1]='$';
    header.m_type = type;
    header.m_method = method;
    header.m_datalen = htons(lenght);
    header.m_encrypt = 0;
}

SignalServerCom::SignalServerCom()
{
    m_randNumber = 10000;
    m_debug = 0;
}

void SignalServerCom::InitServerInfo(char *ipaddr, int port)
{
    strcpy(m_signalIp, (const char*)ipaddr);
    m_signalPort = port;
}

void SignalServerCom::SetDeviceToken(char *token)
{
    strcpy(m_deviceToken, (const char*)token);
}

bool SignalServerCom::ConnectServer()
{
    int    &sockfd = m_socket_signal;
    char   sendline[4096];
    struct sockaddr_in  servaddr;

    if( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("create socket error: %s(errno: %d)\n", strerror(errno),errno);
        return false;
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(m_signalPort);
    if( inet_pton(AF_INET, m_signalIp, &servaddr.sin_addr) <= 0)
    {
        printf("inet_pton error for %s\n", m_signalIp);
        return false;
    }

    if( connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0)
    {
        printf("connect error: %s(errno: %d)\n",strerror(errno),errno);
        return false;
    }
    printf("send msg to server:%d \n", sockfd);
//    if( send(sockfd, sendline, strlen(sendline), 0) < 0)
//    {
//        printf("send msg error: %s(errno: %d)\n", strerror(errno), errno);
//    }
//    close(sockfd);
    return true;
}

int SignalServerCom::httpdWrite ( int fd, const void* buf, size_t nbytes )
{
    int nwritten;

    nwritten = 0;
    while ( nwritten < nbytes )
    {
        int r;

        r = write( fd, (char*) buf + nwritten, nbytes - nwritten );
        if ( r < 0 && ( errno == EINTR || errno == EAGAIN ) )
        {
            continue;
        }
        if ( r < 0 )
            return r;
        if ( r == 0 )
            break;
        nwritten += r;
    }

    return nwritten;
}

int SignalServerCom::SendMessage(int sockfd, char *buffer_send, size_t len)
{
    structTcpHeader header;
    memset(&header, 0, sizeof(header));
//用户终端与平台交互类（类型字:62）
    wrapTcpHeader(header, 0x62, 0x13, len);
    int ret = send(sockfd, (const char*)&header, sizeof(header), 0);
    char *p = (char*)&header;
    for (int i=0; i<sizeof(header); i++)
    {
        printf("%d ", p[i]);
    }
    int ret2 = httpdWrite(sockfd, buffer_send, len);

    return (ret+ret2);
}

int SignalServerCom::SendMediaMessage(int sockfd, char *buffer_send, size_t len, int type, int method)
{
    structTcpHeader header;
    memset(&header, 0, sizeof(header));
    wrapTcpHeader(header, type, method, len);
    int ret = send(sockfd, (const char*)&header, sizeof(header), 0);
    char *p = (char*)&header;
    for (int i=0; i<sizeof(header); i++)
    {
        printf("%d ", p[i]);
    }
    int ret2 = httpdWrite(sockfd, buffer_send, len);

    return (ret+ret2);
}


void SignalServerCom::SendLoginReq(char *userToken)
{
//    {
//        "METHOD":"6213",
//        "SEQID":"10001",
//        "BODY":{
//           "UserToken":"APP在能力平台注册获得的TOKEN"
//        }
//    }
    cJSON *root = NULL;
    char *buffer_send = NULL;
    root = cJSON_CreateObject();//创建一个cJSON结构体指针并分配空间，然后赋值给root
    cJSON_AddStringToObject(root, "METHOD", "6213");
    cJSON_AddStringToObject(root, "SEQID", GetRandNumber());
    cJSON * pSubJson = NULL;
    pSubJson = cJSON_CreateObject();
    if(NULL == pSubJson)
    {
        cJSON_Delete(root);
        return  ;
    }
    cJSON_AddStringToObject(pSubJson, "UserToken", (const char*)userToken);
    cJSON_AddItemToObject(root, "BODY", pSubJson);

    buffer_send = cJSON_Print(root);//将cJSON结构体转换为字符串(带格式)增加一些换行和空格
    if (m_debug)
    printf("%s\n", buffer_send);

    int ret = SendMessage(m_socket_signal, buffer_send, strlen(buffer_send));

    printf("send size:%d\n", ret);
    free(buffer_send);//释放malloc分配的空间
    buffer_send = NULL;

    cJSON_Delete(root );//释放cJSON结构体指针
    root = NULL;

}

char *SignalServerCom::GetRandNumber()
{
    static char buffer[10] = {0};
    sprintf(buffer, "%d", m_randNumber);
    m_randNumber++;
    if (m_randNumber >= 99999)
    {
        m_randNumber = 10000;
    }
    return buffer;
}

void SignalServerCom::SendDeviceSdpReq(char *userToken, char *toUserToken, char *mySdpInfo)
{
//    "METHOD":"6410",
//     "SEQID":"10001",
//     "FROM":{
//        "UserId":"用户标识"
//     },
//     "TO":{
//        "DID":"设备唯一ID"
//     },
//     "BODY":{
//        "SDPType":"sdp类型",
//        "SDP":"SDP内容"
//     }

    cJSON *root, *pFromJson,*pToJson,*pBodyJson;
    char *buffer_send = NULL;
    root = cJSON_CreateObject();//创建一个cJSON结构体指针并分配空间，然后赋值给root
    cJSON_AddStringToObject(root, "METHOD", "6410");
    cJSON_AddStringToObject(root, "SEQID", GetRandNumber());

    //form info
    pFromJson = cJSON_CreateObject();
    if(NULL == pFromJson)
    {
        cJSON_Delete(root);
        return  ;
    }
    cJSON_AddStringToObject(pFromJson, "UserId", (const char*)userToken);
    cJSON_AddItemToObject(root, "FROM", pFromJson);

    //to user info
    pToJson = cJSON_CreateObject();
    if(NULL == pToJson)
    {
        cJSON_Delete(root);
        return  ;
    }
    cJSON_AddStringToObject(pToJson, "UserId", (const char*)toUserToken);
    cJSON_AddItemToObject(root, "TO", pToJson);

    //sdp body info
    pBodyJson = cJSON_CreateObject();
    if(NULL == pBodyJson)
    {
        cJSON_Delete(root);
        return  ;
    }
    cJSON_AddStringToObject(pBodyJson, "SDPType", "iceAddr");
    cJSON_AddStringToObject(pBodyJson, "SDP", (const char*)mySdpInfo);
    cJSON_AddItemToObject(root, "BODY", pBodyJson);


    buffer_send = cJSON_Print(root);//将cJSON结构体转换为字符串(带格式)增加一些换行和空格
    if (m_debug)
    printf("%s\n", buffer_send);

    SendMediaMessage(m_socket_signal, buffer_send, strlen(buffer_send), 0x64, 0x10);

    free(buffer_send);//释放malloc分配的空间
    buffer_send = NULL;

    cJSON_Delete(root );//释放cJSON结构体指针
    root = NULL;

}


void SignalServerCom::SendGetUserListReq(char *userToken)
{
//    {
//        "METHOD":"6090",
//        "SEQID":"10001",
//        "BODY":{
//           "UserToken":"APP在能力平台注册获得的TOKEN"
//        }
//    }

    cJSON *root = NULL;
    char *buffer_send = NULL;
    root = cJSON_CreateObject();//创建一个cJSON结构体指针并分配空间，然后赋值给root
    cJSON_AddStringToObject(root, "METHOD", "6090");
    cJSON_AddStringToObject(root, "SEQID", GetRandNumber());
    cJSON * pSubJson = NULL;
    pSubJson = cJSON_CreateObject();
    if(NULL == pSubJson)
    {
        cJSON_Delete(root);
        return  ;
    }
    cJSON_AddStringToObject(pSubJson, "UserToken", (const char*)userToken);
    cJSON_AddItemToObject(root, "BODY", pSubJson);

    buffer_send = cJSON_Print(root);//将cJSON结构体转换为字符串(带格式)增加一些换行和空格
    if (m_debug)
    printf("%s\n", buffer_send);

    SendMediaMessage(m_socket_signal, buffer_send, strlen(buffer_send), 0x60, 0x90);

    free(buffer_send);//释放malloc分配的空间
    buffer_send = NULL;

    cJSON_Delete(root );//释放cJSON结构体指针
    root = NULL;

}

int SignalServerCom::ParseJasonInfo(char *buffer, int length, char *sdpInfo, char* pFrom, char*pTo)
{
    int bRet = 0;
    cJSON* root=cJSON_Parse(buffer); //获取整个大的句柄
    if (root == NULL)
    {
        printf("jason is null!!\n");
        return bRet;
    }
    cJSON *arrayItem = cJSON_GetObjectItem(root,"METHOD"); //获取这个对象成员
    printf("method:%s\n",  (arrayItem->valuestring));
    if ( strstr(arrayItem->valuestring, "6410")!= NULL)
    {
        cJSON *from = cJSON_GetObjectItem(root, "FROM");
        if (from)
        {
            char *sdpFrom=cJSON_GetObjectItem(from, "UserId")->valuestring;
            memcpy(pFrom, sdpFrom, strlen(sdpFrom));
        }
        cJSON *to = cJSON_GetObjectItem(root, "TO");
        if (from)
        {
            char *sdpFrom=cJSON_GetObjectItem(to, "UserId")->valuestring;
            memcpy(pTo, sdpFrom, strlen(sdpFrom));
        }

        cJSON *result = cJSON_GetObjectItem(root, "BODY");
        if (result)
        {
            //从result节点获取各个元素的值
            //char sdpInfo[1024]= {0};
            char sdpType[32]= {0};
            char *sdpT=cJSON_GetObjectItem(result, "SDPType")->valuestring;
            char *sdpS = cJSON_GetObjectItem(result, "SDP")->valuestring;
            memcpy(sdpInfo, sdpS, strlen(sdpS));
            memcpy(sdpType, sdpT, strlen(sdpT));
            //strcpy(sdpType, cJSON_GetObjectItem(result, "SDPType")->valuestring);
            printf("sdpType:%s sdkInfo:%s, \n", sdpType, sdpInfo);//,type:%s sdp:%s cJSON_GetObjectItem(result, "SDP")->valuestring, cJSON_GetObjectItem(result, "SDPType")->valuestring);
            bRet = 1;
        }
    }
    else if ( strstr(arrayItem->valuestring, "6411")!= NULL)
    {
        bRet = 2;
    }
    else if (strstr(arrayItem->valuestring, "6091")!= NULL)
    {//"BODY":[{"ID":"13711234291","Type":"U","Host":"113.111.9.170:48674","Status":"1"}]
        cJSON *ip_arry = cJSON_GetObjectItem(root, "BODY");  //clientlist 是使用 cjson对象
        if( NULL != ip_arry )
        {
            cJSON *client_list  = ip_arry->child;
            while( client_list != NULL )
            {
                char * id   = cJSON_GetObjectItem( client_list , "ID")->valuestring ;
                char * type = cJSON_GetObjectItem( client_list , "Type")->valuestring ;
                char * host = cJSON_GetObjectItem( client_list , "Host")->valuestring ;
                char * status = cJSON_GetObjectItem( client_list , "Status")->valuestring ;
                printf("id: %s  type: %s, host:%s status:%s \n", id, type, host, status);
                client_list = client_list->next ;
            }
        }
    }
    cJSON_Delete(root);
    return bRet;
}


int SignalServerCom::ReciveData(char *buffer, int len)
{
    memset(buffer, 0, len);
    int ret = NetworkDataTransfer::recieve_data_nowait(m_socket_signal, buffer, len);

    if (m_debug)
    {
        printf("fun:%s %d, recvsize:%d\n", __FUNCTION__, __LINE__, ret);
        char *p = (char*)buffer;
        for (int i=0; i<sizeof(structTcpHeader); i++)
        {
            printf("%d ", p[i]);
        }
        printf("body:%s\n", p+(sizeof(buffer)));
    }
    return ret;
}


