#include "stdio.h"
#include "stdio.h"
#include "pjlib.h"
#include "P2pManageMent.h"
#include <iostream>
#include <unistd.h>
#include "IceTransport.h"
#include <poll.h>
#include "mos.h"
#include <map>
#include "zj_interface.h"
#include "adpt_json_adapt.h"
#include "p2p_connect.h"
#include "msgct_type.h"
#include "ice_p2pqueue.h"

//#include "zj_system.h"
//#include "adpt_json_adapt.h"
//#include "adpt_crypto_adapt.h"
#include <iostream>
#include <string>

#define DEVICE_SYSTEM_PATH              "/mnt/config/system"
#define DEVICE_CONFIG_PATH              "/mnt/config/config"
using namespace std;

int main(int argc, char **argv)
{
    int a = 10;
    a++;
    unsigned char aucInBuf[256] = {0};
    unsigned int uiTime = 41268785;//Mos_GetTickCount();
    unsigned char aucDevCTEI[32] = {"18000454321231"};
    unsigned char aucDevVerSion[32] = {"V5.2.5-00-190910"};
    unsigned char aucDevUID[32] = {"3YSA024392VFHXW"};
    unsigned char aucDevKey[32] = {"YtGPpvscnP"};
    unsigned char pucOutBuff[128] = {0};

    ZJ_Init(DEVICE_SYSTEM_PATH, DEVICE_CONFIG_PATH);
    snprintf(aucInBuf, 256,"CTEI=%s&DID=%s&TimeStamp=%u&Version=%s",
       aucDevCTEI,aucDevUID,uiTime,aucDevVerSion);

    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,128, aucDevKey);
    MOS_PRINTF(", 1111aucDevkey:%s aucInBuf:%s\n", aucDevKey, aucInBuf);
    MOS_PRINTF("my Signature:%s\n", pucOutBuff);
    printf("a=%d\n", a);
    return 0;
}
