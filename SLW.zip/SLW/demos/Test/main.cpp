#include "stdio.h"
#include "string.h"
int test()
{
    char a[5];
    char *ptr;
    int b = 0;
    printf("hello world1\r\n");
    printf("hello world2\r\n");
    printf("hello world3\r\n");
    printf("hello world4\r\n");
    // b = 1 / 0;
    for (int i = 0; i < 1000; i++)
    {
        memcpy(ptr, "123", strlen("123"));
        a[i] = 1;
        printf("%d\r\n", a[i]);

    }
    printf("hello world5\r\n");
    return 0;
}

int main(int argc, char *argv[]){
    test();
    return 0;
}