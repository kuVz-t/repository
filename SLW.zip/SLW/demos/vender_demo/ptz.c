#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#include "zj_type.h"
#include "zj_log.h"
#include "zj_camera.h"
#include "zj_channel.h"

#include "type.h"
#include "devlog.h"
#include "ptz.h"

#define PTZ_STEP_LEN  6

typedef struct stru_ptz_info
{
    int iX;
    int iY;
    int iMaxX;
    int iMaxY;
    int iFreeFlag;
    int iCruiseRun;
    int iSmartCruiseRun;
    int iMoveRun;
    int iPresetPointNum;
    pthread_t hPthread;
    pthread_t hMovePthread;
    EN_ZJ_CAMERA_PTZ_CONTROL enPTZControl;
    ST_ZJ_CAMERA_CRUISE_PRESET *pstPresets;
}ST_PTZ_INF;

ST_PTZ_INF g_stPtzInf = {0};

void* camera_ptz_moveloop(void *argc)
{
    __INFO_PRINTF("device ptz move loop run\n");
    while(g_stPtzInf.iMoveRun)
    {
        __INFO_PRINTF("device ptz position:\n");
        switch (g_stPtzInf.enPTZControl)
        {
        case EN_ZJ_CAMERA_PTZ_CONTROL_UP:
            __INFO_PRINTF("          direction: %s", "up");
            g_stPtzInf.iY += PTZ_STEP_LEN;
        break;
        case EN_ZJ_CAMERA_PTZ_CONTROL_DOWN:
            __INFO_PRINTF("          direction: %s", "down");
            g_stPtzInf.iY -= PTZ_STEP_LEN;
        break;
        case EN_ZJ_CAMERA_PTZ_CONTROL_LEFT:
            __INFO_PRINTF("          direction: %s", "left");
             g_stPtzInf.iX += PTZ_STEP_LEN;
        break;
        case EN_ZJ_CAMERA_PTZ_CONTROL_RIGHT:
            __INFO_PRINTF("          direction: %s", "reght");
             g_stPtzInf.iX -= PTZ_STEP_LEN;
        break;
        default:
            return NULL;
        }
        __INFO_PRINTF("                  X: %d\n", g_stPtzInf.iX);
        __INFO_PRINTF("                  Y: %d\n", g_stPtzInf.iY);
        __INFO_PRINTF("              MAX X: %d\n", g_stPtzInf.iMaxX);
        __INFO_PRINTF("              MAX Y: %d\n", g_stPtzInf.iMaxY);
        sleep(1);
    }
    __INFO_PRINTF("device ptz move loop exit\n");
    return NULL;
}


/**
 * 摄像头PTZ回调接口，告诉设备进行PTZ操作;PTZ操作方法；速度，1~7；1最低；7最快；PTZStep：移动步长，一个步长为1度。360表示一直移动到头一圈
 */
int camera_ptz_move_cb(EN_ZJ_CAMERA_PTZ_CONTROL enPTZControl, int iSpeed, int iPTZStep)
{
    if(g_stPtzInf.iMoveRun)
    {
        return 0;
    }
    __INFO_PRINTF("enPTZControl:[%d]\n", enPTZControl);
    __INFO_PRINTF("iSpeed:[%d]\n", iSpeed);
    __INFO_PRINTF("iPTZStep:[%d]\n", iPTZStep);
//    g_stPtzInf.enPTZControl = enPTZControl;
//    g_stPtzInf.iMoveRun = 1;
//    pthread_create(&g_stPtzInf.hMovePthread, NULL, camera_ptz_moveloop, NULL);
    return 0;
}


/**
 * 摄像头当前位置获取，获取X,Y点值；
 */
int camera_ptz_getpoint_cb(int* piX, int* piY)
{
    __INFO_PRINTF("device ptz get point, current posiston: X [%d] Y [%d]\n", g_stPtzInf.iX, g_stPtzInf.iY);
    *piX = g_stPtzInf.iX;
    *piY = g_stPtzInf.iY;
    return 0;
}


/**
 * 摄像机移动到预置点位置
 */
int camera_ptz_gotopoint_cb(int iX, int iY)
{
    __INFO_PRINTF("device ptz goto point x [%d] y [%d] ...\n", iX, iY);
    if(iX > g_stPtzInf.iMaxX || iX < 0 || iY > g_stPtzInf.iMaxY || iY < 0)
    {
        __ERROR_PRINTF("device ptz goto point failed\n");
        return -1;
    }
    g_stPtzInf.iX = iX;
    g_stPtzInf.iY = iY;
     __INFO_PRINTF("device ptz goto point x [%d] y [%d] ok\n", iX, iY);
    return 0;
}


/**
 * 摄像机自动检测，当预置点位置因人为转动电机导致错乱时，需要重新设置，设置前需要先自检获得初始位置；
 */
int camera_ptz_autocheck_cb()
{
    __INFO_PRINTF("device ptz auto check\n");
    /**
     * PTZ归零校验
    */
    g_stPtzInf.iX  = 0;
    g_stPtzInf.iY = 0;

    /**
     * PTZ转动到预设的中间位置
    */
    g_stPtzInf.iX = g_stPtzInf.iMaxX / 2;
    g_stPtzInf.iY = g_stPtzInf.iMaxY / 2;
    return 0;
}
void* camera_ptz_cruise_loop(void *argc)
{
    int i = 0;
    int j = 0;
    int iWait;
    pthread_detach(pthread_self());
    __INFO_PRINTF("device ptz auto cruise run ok\n");
    while (g_stPtzInf.iCruiseRun == 1)
    {
        for(i=0;i<g_stPtzInf.iPresetPointNum; i++)
        {
            if(g_stPtzInf.iFreeFlag)
            {
                goto GExit;
            }
            __INFO_PRINTF("device ptz Move to cruise point[%d]:\n", g_stPtzInf.iPresetPointNum);
            __INFO_PRINTF("                         index:[%d]\n", g_stPtzInf.pstPresets[i].Idx);
            __INFO_PRINTF("                             X:[%d]\n", g_stPtzInf.pstPresets[i].iX);
            __INFO_PRINTF("                             Y:[%d]\n", g_stPtzInf.pstPresets[i].iY);
            __INFO_PRINTF("                         speed:[%d]\n", g_stPtzInf.pstPresets[i].iSpeed);
            __INFO_PRINTF("                    dwell time:[%d]\n", g_stPtzInf.pstPresets[i].iDwellTime);
            iWait = g_stPtzInf.pstPresets[i].iDwellTime*10;
            for(j=0; j< iWait; j++)
            {
                if(g_stPtzInf.iCruiseRun == 0)
                {
                    goto GExit;
                }
                usleep(100*1000);
            }  
        }
    }
GExit:
    g_stPtzInf.iCruiseRun = 2;
    __INFO_PRINTF("device ptz auto curise loop exit\n");
    return NULL;
}

/**
 * 摄像机巡航开始回调接口，告诉设备按定义的预置点巡航 位置巡航；
 * 当执行巡航过程中，平台下发PTZ指令，则停止本次巡航，待下一次巡航开始执行。（全景巡航和位置巡航都要求）
 */
int camera_ptz_cruisestart_cb(int iPresetPointNum, ST_ZJ_CAMERA_CRUISE_PRESET* pstPresets)
{
    __INFO_PRINTF("device ptz cruise start, preset point num [%d]...\n", iPresetPointNum);
    if(g_stPtzInf.iCruiseRun == 1)  
    {
        return 0;
    }
    int i = 0;
    /**
     * 缓存预置巡航点，在停止巡航时释放
    */
    g_stPtzInf.pstPresets = (ST_ZJ_CAMERA_CRUISE_PRESET*)malloc(sizeof(ST_ZJ_CAMERA_CRUISE_PRESET)*iPresetPointNum);
    memset(g_stPtzInf.pstPresets, 0, sizeof(ST_ZJ_CAMERA_CRUISE_PRESET)*iPresetPointNum);
    g_stPtzInf.iPresetPointNum = iPresetPointNum;
    g_stPtzInf.iFreeFlag = 0;
    g_stPtzInf.iCruiseRun = 1;
    for(i=0; i<iPresetPointNum; i++)
    {
        g_stPtzInf.pstPresets[i] = pstPresets[i];
    }
    pthread_create(&g_stPtzInf.hPthread, NULL, camera_ptz_cruise_loop, NULL);
    return 0;
}

// 摄像机停止执行位置巡航
int camera_ptz_cruise_stop_cb()
{
    __INFO_PRINTF("device ptz cruise stop \n");

    if(g_stPtzInf.iCruiseRun == 1)
    {
        g_stPtzInf.iCruiseRun  = 0;
        int iWaitTime = 100;
        while(iWaitTime > 0 && g_stPtzInf.iCruiseRun != 2)
        {
            usleep(100*1000);
        }
        g_stPtzInf.iCruiseRun  = 0;
        free(g_stPtzInf.pstPresets);
        g_stPtzInf.iFreeFlag = 1;
        g_stPtzInf.iPresetPointNum = 0;
        g_stPtzInf.pstPresets = NULL;
    }

    return 0;
}

//摄像机停止PTZ移动
int camera_ptz_stop_cb()
{
    __INFO_PRINTF("device ptz ... \n");

    if(g_stPtzInf.iMoveRun == 1)
    {
        g_stPtzInf.iMoveRun = 0;
    }
    __INFO_PRINTF("device ptz stop ok\n");
    return 0;
}

// 摄像机开始执行全景巡航
// 选择全景巡航后，根据所设定的巡航时段自动从左到右、从右到左进行巡航。每一个指令旋转60度，指令执行后将停留iDwellTime(s)
// 全景巡航时，如果不满足60度，可转到底部停止，并不用上报底部提示。
// 当执行巡航过程中，平台下发PTZ指令，则停止本次巡航，待下一次巡航开始执行。（全景巡航和位置巡航都要求）
int camera_ptz_smartcruise_start_cb(int iPointCnt, int iDwellTime)
{
    __INFO_PRINTF("device ptz start smartcruise ok iPointCnt:%d iDwellTime:%d \n", iPointCnt, iDwellTime);

    g_stPtzInf.iSmartCruiseRun = 1;

    return 0;
}

// 摄像机停止执行全景巡航
int camera_ptz_smartcruise_stop_cb()
{
    __INFO_PRINTF("device ptz start smartcruise stop \n");

    g_stPtzInf.iSmartCruiseRun = 0;

    return 0;
}

#if 0
//摄像机PTZ
//"enPTZControl":"0.停止；1.Up；2.Down；3.Left；4.Right；5.变倍；6.变焦"
//"iSpeed":"转速 1-7", //1最低；7最快
//"iPTZStep":"步长 1-360"
//"iZoomType":"变倍方式"   //1.画面缩小（OUT），2.画面放大（IN）
//"iFocusType":"变焦方式" //1.拉进焦距（NEAR），2.拉远焦距（FAR）
int camera_ptz_ex_cb(EN_ZJ_CAMERA_PTZ_CONTROL enPTZControl, int iSpeed, int iPTZStep,int iZoomType,int iFocusType)
{
    __INFO_PRINTF("device ptz ex:\n");
    __INFO_PRINTF("enPTZControl:[%d]\n", enPTZControl);
    __INFO_PRINTF("iSpeed:[%d]\n", iSpeed);
    __INFO_PRINTF("iPTZStep:[%d]\n", iPTZStep);
    __INFO_PRINTF("iZoomType:[%d]\n", iZoomType);
    __INFO_PRINTF("iFocusType:[%d]\n", iFocusType);
    return 0;
}
#endif

int ptz_init()
{
    /**
     * 设置PTZ能力 0.不支持；0x01: 支持P；0x02: 支持T；0x04: 支持Z；按位与
     */
    int iPTZAbility = EN_ZJ_CAMERA_PTZ_ABILITY_P|EN_ZJ_CAMERA_PTZ_ABILITY_T|EN_ZJ_CAMERA_PTZ_ABILITY_Z;
    ZJ_SetPTZAbility(iPTZAbility);
    /**
     * 设置PTZ云台速度设置标志 0.不支持； 1.支持；
     */
    ZJ_SetPTZSpeedAbility(1);
    /**
     * 预置点设置能力支持 0.不支持； 1.支持；
     */
    ZJ_SetPresetPointAbility(1);
    /**
     * 设置外挂云台PTZ能力 0.不支持； 1.支持；
     */
    ZJ_SetAttachPTZAbility(0);

    /**
     * 设置智能巡航能力能力 0x01:支持自定义巡航 0x02:支持全景巡航
     */
    ZJ_SetCuriseAbility(EN_ZJ_CAMERA_CURISE_ABILITY_CUSTOM | EN_ZJ_CAMERA_CURISE_ABILITY_PANORAMIC);
    /**
     * 摄像机ptz智能巡航回调接口,通过该接口通知上层开始智能全景巡航
     */
    ZJ_SetCameraSmartPtzCB(camera_ptz_smartcruise_start_cb, camera_ptz_smartcruise_stop_cb, camera_ptz_cruise_stop_cb);
    /**
     * 设置摄像头PTZ回调接口，通过该回调接口通知上层完成对应PTZ操作
     */
    ZJ_SetCameraPTZCB(camera_ptz_move_cb,
                      camera_ptz_getpoint_cb,
                      camera_ptz_gotopoint_cb, 
                      camera_ptz_autocheck_cb,
                      camera_ptz_cruisestart_cb,
                      camera_ptz_stop_cb);
#if 0
    /**
     * 设置PTZ变倍标志 0.不支持； 1.支持；
     */
    ZJ_SetZoomAbility(1);
    /**
     * 设置PTZ变焦标志 0.不支持； 1.支持；
     */
    ZJ_SetFocusAbility(1);
    /**
     * 设置摄像头PTZEx接口，通过回调接口通知上层完成PTZ和变倍变焦操作
     */
    ZJ_SetCameraPTZCBEx(camera_ptz_ex_cb);
#endif

    /**
     * 模拟PTZ初始化， x最大2048 y最1024
    */
    g_stPtzInf.iMaxX = 2048;
    g_stPtzInf.iMaxY = 1024;
    g_stPtzInf.iX =  g_stPtzInf.iMaxX / 2;
    g_stPtzInf.iY =  g_stPtzInf.iMaxY / 2;
    g_stPtzInf.iCruiseRun = 0;
    g_stPtzInf.iFreeFlag = 0;
    g_stPtzInf.iPresetPointNum = 0;
    g_stPtzInf.pstPresets = NULL;
    return 0;
}

int ptz_start()
{
    __INFO_PRINTF("device ptz start\n");
    return 0;
}
