#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "zj_type.h"
#include "zj_log.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "zj_ga1400.h"

#include "type.h"
#include "devlog.h"
#include "ga_1400.h"

#include "type.h"
#include "devlog.h"
#include "input_car_number.h"
#include "input_face.h"
#include "public.h"

static ST_GA1400_INFO g_stGa1400Info = {0};

static int video_set_ga1400info_cb(unsigned char *pucGa1400ID, unsigned char *pucDomain)
{
    __INFO_PRINTF("pucGa1400ID:%s  pucDomain:%s \n", pucGa1400ID, pucDomain);

    //TODO: 配置GAT1400参数
    strncpy((char *)g_stGa1400Info.aucDomain, (char *)pucDomain, sizeof(g_stGa1400Info.aucDomain));
    strncpy((char *)g_stGa1400Info.aucGa1400ID, (char *)pucGa1400ID, sizeof(g_stGa1400Info.aucGa1400ID));
    return 0;
}

static int video_set_ga1400status_cb(unsigned int uiGa1400Status)
{
    __INFO_PRINTF("uiGa1400Status:%u \n", uiGa1400Status);

    //TODO: 配置GAT1400在线状态
    g_stGa1400Info.uiGa1400Status = uiGa1400Status;
    return 0;
}

// demoGA1400初始化
int ga1400_init(void)
{
    /**
     * 设置GAT1400回调接口
     */
    ZJ_SetGat1400Ability(1);
    ZJ_SetGa1400CB(NULL, video_set_ga1400info_cb, video_set_ga1400status_cb);

    return 0;
}

// 上传车牌抓拍图片到1400平台
int ga1400_upload_car_snap()
{
    ST_ZJ_AIPIC_NODE       stAiPicHead      = {0};
    ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo = {0};
    int iPlateColor = 9; // 1：黑  2:白  5:蓝  6：黄  9：绿  99:其他

    // 外部图片资源信息
    struct stat buf;
    unsigned int  uiPicSize        = 0;
    unsigned char *pucPicData      = NULL;
    unsigned char *pucPicDataBg    = NULL;
    unsigned char aucFileName[256] = {0};

    unsigned char ucCarNum[16]       = "鄂AY60Z2";
    unsigned char aucPicExpandDes[1024]   = {0};
    unsigned char aucBgPicExpandDes[1024] = {0};
    unsigned char aucEventExpandDes[1024] = {0};

    // 车牌1图片
    // /opt/21cn/testfile/pic/car_number1.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, CAR_NUMBER1_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize  = buf.st_size;
    pucPicData = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicData)
    {
        __INFO_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("uiPicSize:%u\r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicData, aucFileName))
    {
        free(pucPicData);
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    strncpy((char *)stAiPicHead.aucCarNum, (char *)ucCarNum, sizeof(stAiPicHead.aucCarNum));
    stAiPicHead.pucPicBuf       = pucPicData;        //车牌抠图数据
    stAiPicHead.uiPicLen        = uiPicSize;      //车牌抠图大小
    stAiPicHead.dWidth          = 320;
    stAiPicHead.dHeight         = 160;
    stAiPicHead.uiLeftTopX      = 100;
    stAiPicHead.uiLeftTopY      = 200;
    stAiPicHead.uiRightBtmX     = stAiPicHead.uiLeftTopX + stAiPicHead.dWidth;
    stAiPicHead.uiRightBtmY     = stAiPicHead.uiLeftTopY + stAiPicHead.dHeight;
    sprintf((char *)aucPicExpandDes, "{\"Title\": \"AAAAAAAA\"}");
    strncpy((char *)stAiPicHead.aucPicExpandDes, (char *)aucPicExpandDes, sizeof(stAiPicHead.aucPicExpandDes));
    stAiPicHead.pstNextNode     = NULL;

    // 车牌1背景图片
    // /opt/21cn/testfile/pic/car_number1_bg.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, CAR_NUMBER1_BG_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        free(pucPicData);
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize    = buf.st_size;
    pucPicDataBg = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicDataBg)
    {
        free(pucPicData);
        __INFO_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("Bg uiPicSize:%u\r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicDataBg, aucFileName))
    {
        free(pucPicData);
        free(pucPicDataBg);
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    stAiPicEventInfo.pucBgJpgBuff = pucPicDataBg; //车牌背景图数据
    stAiPicEventInfo.uiBgJpgLen   = uiPicSize;    //车牌背景图大小
    stAiPicEventInfo.dBgWidth     = 1920;
    stAiPicEventInfo.dBgHeight    = 1080;
    stAiPicEventInfo.lluTimeStamp = time(NULL);
    sprintf((char *)aucBgPicExpandDes, "{\"Title\": \"AAAAAAAA_BG\"}");
    strncpy((char *)stAiPicEventInfo.aucBgPicExpandDes, (char *)aucBgPicExpandDes, sizeof(stAiPicEventInfo.aucBgPicExpandDes));
    sprintf((char *)aucEventExpandDes, "{\"PlateColor\": \"%d\"}", iPlateColor);
    strncpy((char *)stAiPicEventInfo.aucEventExpandDes, (char *)aucEventExpandDes, sizeof(stAiPicEventInfo.aucEventExpandDes));
    stAiPicEventInfo.pstAiPicHead = &stAiPicHead;
    
    ZJ_SetAiPicEventEx2(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_CARNUM_DISCERN, &stAiPicEventInfo);

    // SDK会回调释放图片资源
    // free(pucPicData);
    // free(pucPicDataBg);

    sleep(1);

    ST_ZJ_AIPIC_NODE       stAiPicHead1      = {0};
    ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo1 = {0};
    int iPlateColor1 = 6; // 1：黑  2:白  5:蓝  6：黄  9：绿  99:其他

    // 外部图片资源信息
    unsigned char *pucPicData1      = NULL;
    unsigned char *pucPicDataBg1    = NULL;

    unsigned char ucCarNum1[16]            = "粤BC21CN";
    unsigned char aucPicExpandDes1[1024]   = {0};
    unsigned char aucBgPicExpandDes1[1024] = {0};
    unsigned char aucEventExpandDes1[1024] = {0};

    // 车牌2图片
    // /opt/21cn/testfile/pic/car_number2.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, CAR_NUMBER2_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize   = buf.st_size;
    pucPicData1 = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicData1)
    {
        __INFO_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("uiPicSize:%u\r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicData1, aucFileName))
    {
        free(pucPicData1);
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    strncpy((char *)stAiPicHead1.aucCarNum, (char *)ucCarNum1, sizeof(stAiPicHead1.aucCarNum));
    stAiPicHead1.pucPicBuf       = pucPicData1;        //车牌抠图数据
    stAiPicHead1.uiPicLen        = uiPicSize;      //车牌抠图大小
    stAiPicHead1.dWidth          = 320;
    stAiPicHead1.dHeight         = 160;
    stAiPicHead1.uiLeftTopX      = 100;
    stAiPicHead1.uiLeftTopY      = 200;
    stAiPicHead1.uiRightBtmX     = stAiPicHead1.uiLeftTopX + stAiPicHead1.dWidth;
    stAiPicHead1.uiRightBtmY     = stAiPicHead1.uiLeftTopY + stAiPicHead1.dHeight;
    sprintf((char *)aucPicExpandDes1, "{\"Title\": \"BBBBBBB\"}");
    strncpy((char *)stAiPicHead1.aucPicExpandDes, (char *)aucPicExpandDes1, sizeof(stAiPicHead1.aucPicExpandDes));
    stAiPicHead1.pstNextNode     = NULL;

    // 车牌2背景图片
    // /opt/21cn/testfile/pic/car_number2_bg.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, CAR_NUMBER2_BG_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        free(pucPicData1);
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize     = buf.st_size;
    pucPicDataBg1 = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicDataBg1)
    {
        free(pucPicData1);
        __INFO_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("Bg uiPicSize:%u\r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicDataBg1, aucFileName))
    {
        free(pucPicData1);
        free(pucPicDataBg1);
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    stAiPicEventInfo1.pucBgJpgBuff = pucPicDataBg1;    //车牌背景图数据
    stAiPicEventInfo1.uiBgJpgLen   = uiPicSize;  //车牌背景图大小
    stAiPicEventInfo1.dBgWidth     = 1920;
    stAiPicEventInfo1.dBgHeight    = 1080;
    stAiPicEventInfo1.lluTimeStamp = time(NULL);
    sprintf((char *)aucBgPicExpandDes1, "{\"Title\": \"BBBBBBB_BG\"}");
    strncpy((char *)stAiPicEventInfo1.aucBgPicExpandDes, (char *)aucBgPicExpandDes1, sizeof(stAiPicEventInfo1.aucBgPicExpandDes));
    sprintf((char *)aucEventExpandDes1, "{\"PlateColor\": \"%d\"}", iPlateColor1);
    strncpy((char *)stAiPicEventInfo1.aucEventExpandDes, (char *)aucEventExpandDes1, sizeof(stAiPicEventInfo1.aucEventExpandDes));
    stAiPicEventInfo1.pstAiPicHead = &stAiPicHead1;
    
    ZJ_SetAiPicEventEx2(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_CARNUM_DISCERN, &stAiPicEventInfo1);

    // SDK会回调释放图片资源
    // free(pucPicData1);
    // free(pucPicDataBg1);

    return 0; 
}

// 上传人脸抓拍图片到1400平台
int ga1400_upload_face_snap(EN_FACE_TYPE faceType)
{
    ST_ZJ_AIPIC_NODE       stAiPicHead      = {0};
    ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo = {0};
    int iGenderCode    = 1;  // 0：未知的性别  1: 男性  2: 女性 9：未说明的性别
    int iAgeUpLimit    = 22;
    int iAgeLowerLimit = 18;

    // 外部图片资源信息
    struct stat buf;
    unsigned int  uiPicSize        = 0;
    unsigned char *pucPicData      = NULL;
    unsigned char *pucPicDataBg    = NULL;
    unsigned char aucFileName[256] = {0};

    unsigned char aucPicExpandDes[1024]   = {0};
    unsigned char aucBgPicExpandDes[1024] = {0};
    unsigned char aucEventExpandDes[1024] = {0};
    
    // 人脸图片
    // /opt/21cn/testfile/pic/face.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, FACE_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize  = buf.st_size;
    pucPicData = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicData)
    {
        __ERROR_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("uiPicSize:%u\r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicData, aucFileName))
    {
        free(pucPicData);
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    stAiPicHead.pucPicBuf       = pucPicData;        //人脸抠图数据
    stAiPicHead.uiPicLen        = uiPicSize;      //人脸抠图大小
    stAiPicHead.dWidth          = 320;
    stAiPicHead.dHeight         = 160;
    stAiPicHead.uiLeftTopX      = 100;
    stAiPicHead.uiLeftTopY      = 200;
    stAiPicHead.uiRightBtmX     = stAiPicHead.uiLeftTopX + stAiPicHead.dWidth;
    stAiPicHead.uiRightBtmY     = stAiPicHead.uiLeftTopY + stAiPicHead.dHeight;
    sprintf((char *)aucPicExpandDes, "{\"Title\": \"AAAAAAAA\"}");
    strncpy((char *)stAiPicHead.aucPicExpandDes, (char *)aucPicExpandDes, sizeof(stAiPicHead.aucPicExpandDes));
    stAiPicHead.pstNextNode     = NULL;

    // 人脸背景图片
    // /opt/21cn/testfile/pic/face_bg.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, FACE_BG_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        free(pucPicData);
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize    = buf.st_size;
    pucPicDataBg = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicDataBg)
    {
        free(pucPicData);
        __ERROR_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("Bg uiPicSize:%u\r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicDataBg, aucFileName))
    {
        free(pucPicData);
        free(pucPicDataBg);
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    stAiPicEventInfo.pucBgJpgBuff = pucPicDataBg;    //人脸背景图数据
    stAiPicEventInfo.uiBgJpgLen   = uiPicSize;       //人脸背景图大小
    stAiPicEventInfo.dBgWidth     = 1920;
    stAiPicEventInfo.dBgHeight    = 1080;
    stAiPicEventInfo.lluTimeStamp = time(NULL);
    sprintf((char *)aucBgPicExpandDes, "{\"Title\": \"AAAAAAAA_BG\"}");
    strncpy((char *)stAiPicEventInfo.aucBgPicExpandDes, (char *)aucBgPicExpandDes, sizeof(stAiPicEventInfo.aucBgPicExpandDes));
    sprintf((char *)aucEventExpandDes, "{\"GenderCode\": \"%d\",\"AgeUpLimit\": \"%d\",\"AgeLowerLimit\": \"%d\"}", 
                                    iGenderCode, iAgeUpLimit, iAgeLowerLimit);
    strncpy((char *)stAiPicEventInfo.aucEventExpandDes, (char *)aucEventExpandDes, sizeof(stAiPicEventInfo.aucEventExpandDes));
    stAiPicEventInfo.pstAiPicHead = &stAiPicHead;

    if (EN_OLD_FACE_TYPE == faceType)
    {
        ZJ_SetAiPicEventEx2(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_FACE, &stAiPicEventInfo);
    }
    else
    {
        ZJ_SetAiPicEventEx2(EN_ZJ_AIIOT_TYPE_FACE_CAPTURE, 0, 0, &stAiPicEventInfo);
    }

    // SDK会回调释放图片资源
    // free(pucPicData);
    // free(pucPicDataBg);

    return 0;
}