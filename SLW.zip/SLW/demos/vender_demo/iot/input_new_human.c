#include "zj_type.h"
#include "zj_cameraiot.h"
#include "zj_camera.h"
#include "public.h"
#include "output_buzzer.h"

static ST_IOT_EVENT_NEWAI g_stNewHumanAlarm = {0};

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_humanalarmnew_setporp(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_HUMANALARMNEW 中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {
     *      "Sensitive":"灵敏度0-100（string）",
     *      "Status":"功能开关（string）",
     *      "Trace":"是否追踪（string）",
     *      "Interval":"事件检测间隔（string）",
     *      "Capture":"抓拍开关（string）",
     *      "Vedio":"视频开关（string）"
     * }
     */

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);

    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;
    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    // 实现相关属性解析
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if(cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_stNewHumanAlarm.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] NewHumanAlarm aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                              Status: [%d]\n", g_stNewHumanAlarm.stEvent.iStatus);      
    }
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }

    return 0;
}

// 新人形事件上报
int iot_new_human_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};

    if (1 == g_stNewHumanAlarm.stEvent.iStatus)
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, 0, 0, &stAIAlarmUploadInf);
        }
    }
    else
    {
         __INFO_PRINTF("[iot %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_HUMANALARMNEW);
    }        

    return ret;
}

// 老人吃药相关IOT注册
int iot_new_human_register(void)
{
    unsigned char aucBuff[256] = {0};

    // 老人吃药功能demo参考
    SetAlarmSoundExecuteTimeAbility(1);

    // 设置报警声音多时间段执行能力  老人吃药需要支持该能力值
    ZJ_SetCameraAlarmSoundExecuteTimeAbility(1);

    // 新人形侦测能力值
    ZJ_SetDevAiCommonAbility("NewHumanAlarmAbility", 1);
    /**
     * 应用于设备老人吃药智能提醒
     * 新人形注册示例，注意：检测到检测到人形时上报 
    */
    // 新人形侦测报警属性
    char *pchumanalarmnewProp = "{\"Sensitive\":\"50\",\"Status\":\"0\",\"Interval\":\"0\",\"Trace\":\"0\",\"Capture\":\"0\",\"Video\":\"0\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        NULL, 
                        aiiot_humanalarmnew_setporp, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot humanalarmnew register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pchumanalarmnewProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_HumanNew = {0};
        stIoTPolicyInfo_HumanNew.uiInIoTType    = EN_ZJ_AIIOT_TYPE_HUMANALARMNEW;
        stIoTPolicyInfo_HumanNew.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_HumanNew.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_HumanNew.uiOpenFlag     = 1;
        stIoTPolicyInfo_HumanNew.uiSpanFlag     = 0;
        stIoTPolicyInfo_HumanNew.uiStartTime    = 0;
        stIoTPolicyInfo_HumanNew.uiEndTime      = 86400;
        stIoTPolicyInfo_HumanNew.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_HumanNew.aucPolicyName), IOT_POLICYNAME_NEWHUMANALARM, sizeof(stIoTPolicyInfo_HumanNew.aucPolicyName));
        // 添加新人形侦测报警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_HumanNew);
        // 添加响应IoT需要根据产品需求添加，联系产品经理确认
        // 新人形侦测报警IoT添加响应IoT-扬声器  PS: 老人吃药功能默认语音播报规则为每个时间段只播报一次，即："RemindRule":"1"
        snprintf((char*)aucBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"1\",\"ExecuteTime\":[]}", EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuff);
        // 新人形侦测报警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        snprintf((char*)aucBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucBuff);
    }

    return 0;
}