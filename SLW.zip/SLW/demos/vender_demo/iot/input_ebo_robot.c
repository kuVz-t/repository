#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "public.h"

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_EboRobot_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_EBO_ROBOT中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {"Shake":{"Sensitive":"20","Status":"1","Interval":"30"},"LowPower":{"Sensitive":"20","Status":"1","Interval":"30"},"Recharge":{"Sensitive":"20","Status":\"1","Interval":"30"}};
     *
     * {
     *   "Sensitive":"灵敏度0-100（string）",
     *   "Status":"功能开关（string）",
     *   "Interval":"事件检测间隔（string）"
     * }
     * 
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

// ebo机器人告警消息上报
int iot_ebo_robot_event(unsigned int uiEvent)
{
    int ret = 0;

    // ebo机器人告警上报示例
    switch (uiEvent)
    {
        case EN_ZJ_EBO_ROBOT_EVENT_SHAKE:
            // 连续摇晃
            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, 0, EN_ZJ_EBO_ROBOT_EVENT_SHAKE);
            break;
        case EN_ZJ_EBO_ROBOT_EVENT_LOW_POWER:
            // 低电量
            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, 0, EN_ZJ_EBO_ROBOT_EVENT_LOW_POWER);
            break;
        case EN_ZJ_EBO_ROBOT_EVENT_RECHARGE_FAILED:
            // 回充失败
            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, 0, EN_ZJ_EBO_ROBOT_EVENT_RECHARGE_FAILED);
            break;
        default:
            ret = -1;
            break;
    }

    return ret;
}

// ebo机器人IOT注册
int iot_ebo_robot_register(void)
{
    // 添加ebo机器人报警IOT示例
   
    char *pcEboRobotProp =  "{\"Shake\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Interval\":\"30\"},"
                          "\"LowPower\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Interval\":\"30\"},"
                          "\"Recharge\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Interval\":\"30\"}}";
    // 添加ebo机器人告警IOT
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        NULL, 
                        aiiot_EboRobot_setprop, //一期暂时未用到，可配置为NULL
                        NULL) == 0)
    {
        // 设置ebo机器人默认属性
        __INFO_PRINTF("device iot ebo register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_EBO_ROBOT, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcEboRobotProp);
        
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_eboRobot = {0};
        stIoTPolicyInfo_eboRobot.uiInIoTType           = EN_ZJ_AIIOT_TYPE_EBO_ROBOT;
        stIoTPolicyInfo_eboRobot.lluInIoTId            = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_eboRobot.uiOpenFlag            = 1;
        stIoTPolicyInfo_eboRobot.uiSpanFlag            = 0;
        stIoTPolicyInfo_eboRobot.uiStartTime           = 0;
        stIoTPolicyInfo_eboRobot.uiEndTime             = 86400;
        stIoTPolicyInfo_eboRobot.uiWeekFlag            = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_eboRobot.aucPolicyName), IOT_POLICYNAME_EBO_ROBOT, sizeof(stIoTPolicyInfo_eboRobot.aucPolicyName));

        // 添加连续摇晃事件默认联动策略
        stIoTPolicyInfo_eboRobot.uiInIoTEventId = EN_ZJ_EBO_ROBOT_EVENT_SHAKE;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_eboRobot);
        // 删除连续摇晃事件联动策略-云存
        ZJ_DelAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_EBO_ROBOT,  EN_ZJ_DEFAULT_IOTID, EN_ZJ_EBO_ROBOT_EVENT_SHAKE, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, EN_ZJ_DEFAULT_IOTID);

        // 添加低电量事件默认联动策略
        stIoTPolicyInfo_eboRobot.uiInIoTEventId = EN_ZJ_EBO_ROBOT_EVENT_LOW_POWER;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_eboRobot);
        // 删除低电量事件联动策略-云存
        ZJ_DelAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_EBO_ROBOT,  EN_ZJ_DEFAULT_IOTID, EN_ZJ_EBO_ROBOT_EVENT_LOW_POWER, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, EN_ZJ_DEFAULT_IOTID);

        // 添加回充失败事件默认联动策略类型
        stIoTPolicyInfo_eboRobot.uiInIoTEventId = EN_ZJ_EBO_ROBOT_EVENT_RECHARGE_FAILED;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_eboRobot);
        // 删除回充失败事件联动策略-云存
        ZJ_DelAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_EBO_ROBOT,  EN_ZJ_DEFAULT_IOTID, EN_ZJ_EBO_ROBOT_EVENT_RECHARGE_FAILED, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, EN_ZJ_DEFAULT_IOTID);
    }

    return 0;
}