#include "zj_type.h"
#include "zj_log.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"

#include "public.h"
#include "input_motion.h"
#include "input_car_number.h"

#include "type.h"
#include "devlog.h"
#include "zip.h"
#include "ga_1400.h"
#include "stdio.h"
// 车牌抓拍ZIP
static ST_ZJ_AI_ZIP_EVENT_SIGNAL g_stAiCarZipEventInfo = {0};

static ST_MOTION_MNG *g_pstMotionMng = NULL;

int car_snap_upload_zip()
{
    // Ai事件信号输入(压缩方式)
    __INFO_PRINTF("ZJ_SetAiPicEventEx start \r\n");

    struct stat buf;
    int iRetZip                    =  0;
    zipFile zf                     = NULL;
    zip_fileinfo zi                = {0};

    // 外部图片资源信息
    unsigned int  uiPicSize        = 0;
    unsigned char *pucPicDataZip   = NULL;
    unsigned char *pucPicDataBgZip = NULL;
    unsigned char aucFileName[256] = {0};

    // 压缩包信息
    unsigned char aucFileZipName[256] = {0};
    char acBgFileNameZip[16]          = "000.jpg";
    char acCarFileNameZip0[16]        = "000_0.jpg";

    ST_MOS_SYS_TIME stSysTime;
    get_mos_time(&stSysTime);
    //Mos_GetSysTime(&stSysTime);
    ST_DEV_INFO *pstDevInfo = get_dev_info();

    snprintf(aucFileZipName, sizeof(aucFileZipName), "%s/%s_%04hu%02hu%02hu_%02hu%02hu%02hu.zip", DEVICE_AIPIC_PATH, \
    pstDevInfo->acDevUID, stSysTime.usYear, stSysTime.usMonth, stSysTime.usDay, stSysTime.usHour, stSysTime.usMinute, stSysTime.usSecond);

    __INFO_PRINTF("aucFileZipName:%s\r\n", aucFileZipName);

    // 创建打开zip文件
    zf = zipOpen64(aucFileZipName, 0);
    if (zf == NULL)
    {
        __ERROR_PRINTF("error opening %s \r\n", aucFileZipName);
    }
    else
    {
        __INFO_PRINTF("creating ZIP File %s \r\n", aucFileZipName);
    }

    // 背景图片
    // /opt/21cn/testfile/pic/car_number1_bg.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, CAR_NUMBER1_BG_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize = buf.st_size;
    pucPicDataBgZip = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicDataBgZip)
    {
        __ERROR_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("Bg uiPicSize:%d \r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicDataBgZip, aucFileName))
    {
        free(pucPicDataBgZip);
        __ERROR_PRINTF("get_file_data: %s failed\n", aucFileName);
        return -1;
    }

    __INFO_PRINTF("Bg  acBgFileNameZip:%s \r\n", acBgFileNameZip);

    // 将被压缩的文件名ucAIBgPicName添加进zip文件
    iRetZip = zipOpenNewFileInZip3_64(zf, acBgFileNameZip, &zi, NULL, 0, NULL, 0, NULL, Z_DEFLATED,
                                    9, 0, -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY, NULL, 0, 0);
    if (iRetZip != ZIP_OK)
    {
        __ERROR_PRINTF("error BG zipOpenNewFileInZip3_64 %s \r\n", acBgFileNameZip);
    }
    else
    {
        // 将被压缩的文件数据写进zip文件
        iRetZip = zipWriteInFileInZip (zf, pucPicDataBgZip, uiPicSize);
        if (iRetZip < 0)
        {
            __ERROR_PRINTF("error BG zipWriteInFileInZip %s \r\n", acBgFileNameZip);
        }
        else
        {
            // 每个被压缩文件写完后都要条用该接口关闭文件
            iRetZip = zipCloseFileInZip(zf);
            if (iRetZip != ZIP_OK)
            {
                __ERROR_PRINTF("error BG zipCloseFileInZip %s \r\n", acBgFileNameZip);
            }
        }
    }

    // 车牌图片
    // /opt/21cn/testfile/pic/car_number1.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, CAR_NUMBER1_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        free(pucPicDataBgZip);
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize = buf.st_size;
    pucPicDataZip = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicDataZip)
    {
        free(pucPicDataBgZip);
        __ERROR_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("Bg uiPicSize:%d \r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicDataZip, aucFileName))
    {
        free(pucPicDataZip);
        free(pucPicDataBgZip);
        __ERROR_PRINTF("get_file_data: %s failed\n", aucFileName);
        return -1;
    }

    __INFO_PRINTF("Car  acCarFileNameZip0:%s \r\n", acCarFileNameZip0);

    // 将被压缩的文件名ucAIBgPicName添加进zip文件
    iRetZip = zipOpenNewFileInZip3_64(zf, acCarFileNameZip0, &zi, NULL, 0, NULL, 0, NULL, Z_DEFLATED,
                                    9, 0, -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY, NULL, 0, 0);
    if (iRetZip != ZIP_OK)
    {
        __ERROR_PRINTF("error Car zipOpenNewFileInZip3_64 %s \r\n", acCarFileNameZip0);
    }
    else
    {
        // 将被压缩的文件数据写进zip文件
        iRetZip = zipWriteInFileInZip (zf, pucPicDataZip, uiPicSize);
        if (iRetZip < 0)
        {
            __ERROR_PRINTF("error Car zipWriteInFileInZip %s \r\n", acCarFileNameZip0);
        }
        else
        {
            // 每个被压缩文件写完后都要条用该接口关闭文件
            iRetZip = zipCloseFileInZip(zf);
            if (iRetZip != ZIP_OK)
            {
                __ERROR_PRINTF("error Car zipCloseFileInZip %s \r\n", acCarFileNameZip0);
            }
        }
    }

    if (zf)
    {
        // 关闭zip文件
        iRetZip = zipClose(zf, NULL);
        if (iRetZip != ZIP_OK)
        {
            __ERROR_PRINTF("error zipClose %s \r\n", aucFileZipName);
        }
        zf = NULL;
    }

    strcpy((char *)g_stAiCarZipEventInfo.aucFilePath, (char *)aucFileZipName);

    __INFO_PRINTF("aucFileZipName:%s \r\n", g_stAiCarZipEventInfo.aucFilePath);

    ST_ZJ_ZIP_AIBGFILE_NODE stZipAiBgFileNode = {0};
    strcpy((char *)stZipAiBgFileNode.aucBgFileName, acBgFileNameZip);
    stZipAiBgFileNode.lluTimeStamp = getCurrentDayMsec();

    ST_ZJ_ZIP_AIFACEFILE_INFO stZipAiCarFileInf1 = {0};
    strcpy((char *)stZipAiCarFileInf1.aucFaceFileName, acCarFileNameZip0);

    stZipAiBgFileNode.pstZipFaceFileHead = &stZipAiCarFileInf1;

    g_stAiCarZipEventInfo.pstZipBgFileHead  = &stZipAiBgFileNode;

    ZJ_SetAiPicEventEx(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_CARNUM_DISCERN, &g_stAiCarZipEventInfo);
    __INFO_PRINTF("ZJ_SetAiPicEventEx end   \r\n");

    free(pucPicDataZip);
    free(pucPicDataBgZip);

    return 0;
}

int iot_car_snap_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime = 0;

    g_pstMotionMng = aiiot_get_motion_mng();

    if (1 == g_pstMotionMng->stCarNum.iStatus)
    {
        gettimeofday(&cur_tv, 0);

        if ((cur_tv.tv_sec - lastTime) >= g_pstMotionMng->stCarNum.iInterval)
        {
            lastTime = cur_tv.tv_sec;

            /*车牌抓拍上传示例*/
            /*1400方式上传*/
            ret = ga1400_upload_car_snap();

            // 压缩方式上传业务平台
            ret = car_snap_upload_zip();
        }
    }
    else
    {
        // __INFO_PRINTF("[iot %d, event %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_MOTION_EVENT_CARNUM_DISCERN);
    }

    return ret;
}
