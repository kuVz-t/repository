#include "zj_type.h"
#include "zj_cameraiot.h"
#include "zj_camera.h"
#include "public.h"

/**
 * 摄像头自定义铃声文件删除回调接口
 */
int aiiot_buzzer_delsoundfile(unsigned char *pucSoundName)
{
    printf("aiiot_buzzer_delsoundfile %s\r\n",pucSoundName);
    return 0;
}

/**
 * 门铃&摄像头自定义铃声文件回调接口
 *  *门铃设备内置固定声音文件
 *  *摄像头设备需厂商管理自定义声音文件列表
 *  *对于门铃设备,是内置门铃音频文件列表
 *  *对于非门铃设备,是自定义下载音频文件和预设内置告警声列表
 */
int aiiot_buzzer_getsoundfiles( unsigned int *piTotalSize, unsigned int *piFreeSize, ST_ZJ_SOUNDFILE_INFO **pstHeadNode, EN_ZJ_RING_TYPE enSoundType)
{
    int i = 0;
    ST_ZJ_SOUNDFILE_INFO *pstPreNode = NULL;
    ST_ZJ_SOUNDFILE_INFO *pstTmpNode = NULL;
    #ifdef APP_DOORBELL
    ST_ZJ_SOUNDFILE_INFO soundfiles[] = {{"quickreply_wait",0,0x01,"稍等稍等,马上来", 0x01},
                                         {"quickreply_wait2",0,0x01,"这就给您开门,请稍等", 0x01},
                                         {"quickreply_refuse",0,0x01,"主人不在家,请给我留言", 0x01},
                                         {"quickreply_express",0,0x01,"您好,快递请放在门口,谢谢", 0x01},
                                         {"ringtone_dingdong",0,0x02,"叮声", 0x01},
                                         {"ringtone_dingling",0,0x02,"叮铃", 0x01},
                                         {"ringtone_kong",0,0x02,"空竹声", 0x01},
                                         {"ringtone_welcome",0,0x02,"欢迎光临", 0x01},
                                         {"warning_normal",0,0x04,"普通告警音", 0x01}};
    #else // 预置的声音文件由厂商自己生成
    ST_ZJ_SOUNDFILE_INFO soundfiles[] = {{"presetsound_medicine", 0, 0x01, "请准时吃药",      0x02},
                                         {"presetsound_clockin",  0, 0x01, "上下班请打卡",    0x02},
                                         {"presetsound_welcome",  0, 0x01, "欢迎光临",        0x02},
                                         {"presetsound_caution",  0, 0x01, "请注意安全",      0x02},
                                         {"presetsound_closedoor",0, 0x01, "请随手关门",      0x02},
                                         {"presetsound_steps",    0, 0x01, "请小心台阶",      0x02},
                                         {"presetsound_area",     0, 0x01, "你已进入监控区域", 0x02}};
    #endif

    *piFreeSize  =  512*1024*1024;
    *piTotalSize = 1024*1024*1024;

    // 注意：pstHeadNode参数, 有声音文件时, 需要每个节点malloc, 拼接成链表 该malloc在SDK内部释放
    for (i=0; i<7; i++) // 循环次数根据soundfiles数组的大小定
    {
        if (pstTmpNode == NULL)
        {
            pstTmpNode = malloc(sizeof(ST_ZJ_SOUNDFILE_INFO));
            *pstHeadNode = pstTmpNode;
        }
        else
        {
            pstTmpNode = malloc(sizeof(ST_ZJ_SOUNDFILE_INFO));
        }
        
        strcpy((char*)(pstTmpNode->aucFileName), (char*)(soundfiles[i].aucFileName));
        strcpy((char*)(pstTmpNode->aucFileContent), (char*)(soundfiles[i].aucFileContent));
        pstTmpNode->uiFileSize      = 2*1024;
        pstTmpNode->uiFileFormat    = soundfiles[i].uiFileFormat;
        pstTmpNode->uiFileCategory  = soundfiles[i].uiFileCategory;
        pstTmpNode->pstNextNode     = 0;
        if (pstPreNode)
        {
            pstPreNode->pstNextNode = pstTmpNode;
        }
        pstPreNode = pstTmpNode;
    }

    return 0;
}

/**
 * 摄像头文件下载通知回调接口
 *  uiFileType : EN_ZJ_FILE_FORMAT  自定义声音文件
 *  uiFileSize : 文件大小,字节
 *  pucFileName: 文件名
 *  return     : 0-ok   1-fail
 */
int aiiot_filedown_notice(unsigned int uiFileType,unsigned int uiFileSize,unsigned char *pucFileName)
{
    printf("%s type=%d size=%d name=%s\r\n",__FUNCTION__,uiFileType,uiFileSize,pucFileName);
    return 0;
}

/**
 * 摄像头文件下载传输回调接口
 *  pucPackage : 数据
 *  uiPacklen  : 数据长度
 *  uiEndFlag  : 结束标志   0-正在下载    1-下载结束
 *  return     : 0-ok   1-fail
 */
int aiiot_filedown_trans(unsigned char *pucPackage,unsigned int uiPacklen,unsigned int uiEndFlag)
{
    printf("%s plen=%d endflag=%d\r\n",__FUNCTION__,uiPacklen,uiEndFlag);
    return 0;
}

/**
 * 摄像头文件下载停止回调接口 - 下载错误，通知删除文件
 *  return     : 0-ok
 */
int aiiot_filedown_stop()
{
    printf("%s\r\n",__FUNCTION__);
    return 0;
}

// 智能播报
int iot_intelligent_broadcast_register(void)
{
    /**
     * 设置摄像头自定义声音文件(智能播报)能力与相关回调
    */ 
    ZJ_SetCustomizeAlarmSoundAbility(1);
    ZJ_SetCamAlarmSoundFileCB(aiiot_buzzer_delsoundfile, aiiot_buzzer_getsoundfiles);
    ZJ_SetDownLoadFileCBFuncs(aiiot_filedown_notice, aiiot_filedown_trans, aiiot_filedown_stop);

    return 0;
}