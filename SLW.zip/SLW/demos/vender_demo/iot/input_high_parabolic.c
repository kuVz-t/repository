#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "public.h"
#include "type.h"

typedef struct stru_aiiot_event_HighParabolic
{
    ST_IOT_EVENT   stEvent;
    int            iRegionNum;
    unsigned char  ucRegions;
    int            iWaterMarkNum;
    unsigned char  ucWaterMarks;
}ST_IOT_EVENT_HIGHPARABOLIC;

static ST_IOT_EVENT_HIGHPARABOLIC g_stHighParabolic = {0};

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
static int aiiot_HighParabolic_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
static int aiiot_HighParabolic_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_HighParabolic_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);
    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;

    if ((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }

    cProp = cJSON_Parse((char*)pstProp);
    if (cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }

    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if (cStatus != NULL)
    {
        if (GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_stHighParabolic.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] HighParabolic aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                                      Status: [%d]\n", g_stHighParabolic.stEvent.iStatus);        
    }

    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }
       
    return 0;
}

// 高空抛物事件上报
int iot_high_parabolic_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};

    if (1 == g_stHighParabolic.stEvent.iStatus)
    {
        // PS流封装
        // iot_videoUpload(DEVICE_VIDEO_FILE_PATH_FILE, DEVICE_VIDEO_FILE_PATH_CFG, DEVICE_AUDIO_FILE_PATH);

        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, 0, 0, &stAIAlarmUploadInf);
        }
    }
    else
    {
         __INFO_PRINTF("[iot %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC);
    }        

    return ret;
}

// 高空抛物IOT注册
int iot_high_parabolic_register(void)
{
    unsigned char aucLampBuff[256]    = {0};

    #if 0
    char *pcHighParabolicProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Interval\":\"30\",\"Capture\":\"0\",\"Video\":\"0\"}";
    #else
    char *pcHighParabolicProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Interval\":\"30\",\"Capture\":\"0\",\"Video\":\"0\",\"RegionNum\":\"100034\",\"Regions\":[{\"RegionId\":\"1\",\"RegionPoints\":[{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"}]}],\"WaterMarkNum\":\"267543\",\"WaterMarks\":[{\"WaterMarkId\":\"1\",\"FontSize\":\"8\",\"FontContent\":\"10Floor\",\"WaterMarkPoints\":[{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"}]}]}";
    #endif

    // AI高空抛物识别能力 0.不支持；1.支持
    ZJ_SetDevAiHighParabolicAbility(1);

    // 添加高空抛物检测告警IoT设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_HighParabolic_start,
                        aiiot_HighParabolic_stop, 
                        NULL, 
                        NULL, 
                        aiiot_HighParabolic_setprop, 
                        NULL) == 0)
    {
        // 设置高空抛物检测默认属性
        __INFO_PRINTF("device iot HighParabolic register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcHighParabolicProp);
    
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_HighParabolic = {0};
        stIoTPolicyInfo_HighParabolic.uiInIoTType     = EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC;
        stIoTPolicyInfo_HighParabolic.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_HighParabolic.uiInIoTEventId  = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_HighParabolic.uiOpenFlag      = 1;
        stIoTPolicyInfo_HighParabolic.uiSpanFlag      = 0;
        stIoTPolicyInfo_HighParabolic.uiStartTime     = 0;
        stIoTPolicyInfo_HighParabolic.uiEndTime       = 86400;
        stIoTPolicyInfo_HighParabolic.uiWeekFlag      = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_HighParabolic.aucPolicyName), IOT_POLICYNAME_HIGHPARABOLIC, sizeof(stIoTPolicyInfo_HighParabolic.aucPolicyName));
        // 添加高空抛物检测告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_HighParabolic);
        // 添加响应IoT需要根据产品需求添加，联系产品经理确认
        // 高空抛物检测告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        #if 0
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\"}");
        #else
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        #endif
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
        // 删除IOT类型的属性字段
        // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC,EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, "Interval", NULL);
    }

    return 0;
}