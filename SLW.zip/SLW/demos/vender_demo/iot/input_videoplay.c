#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "public.h"
#include "input_videoplay.h"

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */        
static int aiiot_videoplay_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_VIDEOPLAY中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {""Status":"1"};
     *
     * {
     *   "Status":"功能开关（string）",
     * }
     * 
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

// 双向视频通话消息上报
int iot_videoplay_event(unsigned int uiEvent)
{
    int ret = 0;

    // 双向视频通话上报示例
    switch (uiEvent)
    {
        case EN_ZJ_VIDEOPLAY_EVENT_CALL:
            // 呼叫消息
            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_VIDEOPLAY, 0, EN_ZJ_VIDEOPLAY_EVENT_CALL);
            break;
        case EN_ZJ_VIDEOPLAY_EVENT_HANGUP:
            // 挂断消息
            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_VIDEOPLAY, 0, EN_ZJ_VIDEOPLAY_EVENT_HANGUP);
            break;
        default:
            ret = -1;
            break;
    }

    return ret;
}

// 双向视频通话IOT注册
int iot_videoplay_register(void)
{
    /**
     * 双向视频通话注册示例,注意：双向视频通话前需要
    */
    char *pcvideoplayProp = "{\"Status\":\"1\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_VIDEOPLAY, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        NULL, 
                        aiiot_videoplay_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot videoplay register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_VIDEOPLAY, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_VIDEOPLAY, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcvideoplayProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_VideoPlay = {0};
        stIoTPolicyInfo_VideoPlay.uiInIoTType    = EN_ZJ_AIIOT_TYPE_VIDEOPLAY;
        stIoTPolicyInfo_VideoPlay.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_VideoPlay.uiInIoTEventId = EN_ZJ_VIDEOPLAY_EVENT_CALL;
        stIoTPolicyInfo_VideoPlay.uiOpenFlag     = 1;
        stIoTPolicyInfo_VideoPlay.uiSpanFlag     = 0;
        stIoTPolicyInfo_VideoPlay.uiStartTime    = 0;
        stIoTPolicyInfo_VideoPlay.uiEndTime      = 86400;
        stIoTPolicyInfo_VideoPlay.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_VideoPlay.aucPolicyName), IOT_POLICYNAME_VIDEOPLAY, sizeof(stIoTPolicyInfo_VideoPlay.aucPolicyName));
        // 添加双向视频通话IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_VideoPlay);

        stIoTPolicyInfo_VideoPlay.uiInIoTEventId = EN_ZJ_VIDEOPLAY_EVENT_HANGUP;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_VideoPlay);
    }

    return 0;
}