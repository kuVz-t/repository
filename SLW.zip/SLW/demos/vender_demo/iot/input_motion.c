
#include "zj_type.h"
#include "zj_cameraiot.h"
//#include "zj_ga1400.h"
#include "public.h"
#include "input_motion.h"
#include "input_fence.h"
#include "input_car_number.h"
#include "input_face.h"

static ST_MOTION_MNG g_StMotionMng = {0};

ST_MOTION_MNG *aiiot_get_motion_mng()
{
    return &g_StMotionMng;
}

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
static int aiiot_motion_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
static int aiiot_motion_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}


/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_motion_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_MOTION中
     * 注意：运动侦测iot包含，移动侦测、人形侦测、人脸识别三种事件类型，每一种事件类型都可以配置
     * 格式如下以移动侦测为例：
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     *          {"Motion":{"Interval":"30","Sensitive":"25","Status":"0","Trace":"0"}}
     * Interval     时间间隔
     * Sensitive    灵敏度 低25 中50 高75
     * Status       开启状态
     * Trace        是否开启自动追踪
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]\n", uiAIIoTType, uiAIIoTID);
    int iInterval   = 0;
    int iSensitive  = 0;
    int iStatus     = 0;
    int iTrace      = 0;
    int iDiscernFlag    = 0;
    int iFenceStayTime  = 0;
    int iFenceVideoFlag = 0;
    int iFenceCaptureFlag = 0;
    cJSON *cProp    = NULL;
    cJSON *cMotion  = NULL;
    cJSON *cHuman   = NULL;
    cJSON *cFence   = NULL;
    cJSON *cFace    = NULL;
    cJSON *cCarNum  = NULL;

    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    cMotion = cJSON_GetObjectItem(cProp, "Motion");
    if(cMotion != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cMotion,"Interval"), &iInterval)==0)
        {
            g_StMotionMng.stMotion.iInterval = iInterval;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cMotion,"Sensitive"), &iSensitive) == 0)
        {
            g_StMotionMng.stMotion.iSensitive = iSensitive;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cMotion,"Status"), &iStatus)==0)
        {
            g_StMotionMng.stMotion.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cMotion,"Trace"), &iTrace) == 0)
        {
            g_StMotionMng.stMotion.iTrace = iTrace;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] Motion aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                                Interval: [%d]\n", g_StMotionMng.stMotion.iInterval);
        __INFO_PRINTF("                                               Sensitive: [%d]\n", g_StMotionMng.stMotion.iSensitive);
        __INFO_PRINTF("                                                  Status: [%d]\n", g_StMotionMng.stMotion.iStatus);
        __INFO_PRINTF("                                                   Trace: [%d]\n", g_StMotionMng.stMotion.iTrace);
    }

    cHuman = cJSON_GetObjectItem(cProp, "Human");
    if(cHuman != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cHuman,"Interval"), &iInterval)==0)
        {
            g_StMotionMng.stHuman.iInterval = iInterval;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cHuman,"Sensitive"), &iSensitive) == 0)
        {
            g_StMotionMng.stHuman.iSensitive = iSensitive;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cHuman,"Status"), &iStatus)==0)
        {
            g_StMotionMng.stHuman.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cHuman,"Trace"), &iTrace) == 0)
        {
            g_StMotionMng.stHuman.iTrace = iTrace;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] Human aiiot id [%llu]:\n",  uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                               Interval: [%d]\n",  g_StMotionMng.stHuman.iInterval);
        __INFO_PRINTF("                                              Sensitive: [%d]\n",  g_StMotionMng.stHuman.iSensitive);
        __INFO_PRINTF("                                                 Status: [%d]\n",  g_StMotionMng.stHuman.iStatus);
        __INFO_PRINTF("                                                  Trace: [%d]\n",  g_StMotionMng.stHuman.iTrace);
    }

    cFence = cJSON_GetObjectItem(cProp, "Fence");
    if (cFence != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cFence,"Status"), &iStatus)==0)
        {
            g_StMotionMng.stFence.stEvent.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFence,"StayTime"), &iFenceStayTime)==0)
        {
            g_StMotionMng.stFence.iStayTime = iFenceStayTime;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFence,"Capture"), &iFenceCaptureFlag)==0)
        {
            g_StMotionMng.stFence.iCapture = iFenceCaptureFlag;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFence,"Video"), &iFenceVideoFlag)==0)
        {
            g_StMotionMng.stFence.iVideo = iFenceVideoFlag;
        }       
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] Fence aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                                Status: [%d]\n", g_StMotionMng.stFence.stEvent.iStatus);
        __INFO_PRINTF("                                              StayTime: [%d]\n", g_StMotionMng.stFence.iStayTime);
        __INFO_PRINTF("                                               Capture: [%d]\n", g_StMotionMng.stFence.iCapture);
        __INFO_PRINTF("                                                 Video: [%d]\n", g_StMotionMng.stFence.iVideo);                         
    }
    else
    {
        __INFO_PRINTF("cFence == NULL\n");
    }

    cFace = cJSON_GetObjectItem(cProp, "Face");
    if (cFace != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cFace,"Status"), &iStatus)==0)
        {
            // 人脸抓拍开关
            g_StMotionMng.stFace.stEvent.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFace,"DiscernFlag"), &iDiscernFlag)==0)
        {
            // 人脸布控开关
            g_StMotionMng.stFace.iDiscernFlag = iDiscernFlag;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFace,"Trace"), &iTrace) == 0)
        {
            // 如果是云台机，开启人脸追踪
            g_StMotionMng.stFace.stEvent.iTrace = iTrace;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFace,"Interval"), &iInterval)==0)
        {
            g_StMotionMng.stFace.stEvent.iInterval = iInterval;
        }
    }
    
    cCarNum = cJSON_GetObjectItem(cProp, "CarNum");
    if (cCarNum != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cCarNum,"Status"), &iStatus)==0)
        {
            // 开启车牌抓拍
            g_StMotionMng.stCarNum.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cCarNum,"Trace"), &iTrace) == 0)
        {
            // 如果是云台机，开启车牌追踪
            g_StMotionMng.stCarNum.iTrace = iTrace;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cCarNum,"Interval"), &iInterval)==0)
        {
            g_StMotionMng.stCarNum.iInterval = iInterval;
        }
    }
    
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("prop: %s\n", pstProp);
    
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }

    return 0;
}

// 移动侦测报警事件推送,注：SDK内部会做抓图、报警视频录制等相关业务操作
static int iot_motion_motion_event(void)
{
    struct timeval cur_tv;
    static long lastTime = 0;

    if (1 == g_StMotionMng.stMotion.iStatus)
    {
        gettimeofday(&cur_tv, 0);

        if ((cur_tv.tv_sec - lastTime) >= g_StMotionMng.stMotion.iInterval)
        {
            lastTime = cur_tv.tv_sec;

            __INFO_PRINTF("device iot push event, iot [%d] iot id [%d] iot type [%d]\n", EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_MOTION);

            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_MOTION);
        }
        else
        {
            __INFO_PRINTF("input iInterval < %d\n", g_StMotionMng.stMotion.iInterval);
        }
    }
    else
    {
        __INFO_PRINTF("[iot %d, event %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_MOTION_EVENT_MOTION);
    }

    return 0;
}

// 人形侦测报警事件推送,注：SDK内部会做抓图、报警视频录制等相关业务操作
static int iot_motion_human_event(void)
{
    struct timeval cur_tv;
    static long lastTime = 0;

    if (1 == g_StMotionMng.stHuman.iStatus)
    {
        gettimeofday(&cur_tv, 0);

        if ((cur_tv.tv_sec - lastTime) >= g_StMotionMng.stHuman.iInterval)
        {
            lastTime = cur_tv.tv_sec;

            __INFO_PRINTF("device iot push event, iot [%d] iot id [%d] iot type [%d]\n", EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_HUMAN);

            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_HUMAN);
        }
        else
        {
            __INFO_PRINTF("input iInterval < %d\n", g_StMotionMng.stHuman.iInterval);
        }
    }
    else
    {
        __INFO_PRINTF("[iot %d, event %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_MOTION_EVENT_HUMAN);
    }

    return 0;
}

// 移动侦测事件上报
int iot_motion_event(unsigned int uiEvent)
{
    int ret = -1;

    switch (uiEvent)
    {
        case EN_ZJ_MOTION_EVENT_FENCE_HUMAN_STAY:
            // 电子围栏/进出滞留
            ret = iot_fence_event();
            break;
        case EN_ZJ_MOTION_EVENT_MOTION:
            // 移动侦测
            ret = iot_motion_motion_event();
            break;
        case EN_ZJ_MOTION_EVENT_HUMAN:
            // 人形侦测
            ret = iot_motion_human_event();
            break;
        case EN_ZJ_MOTION_EVENT_FACE:
        case EN_ZJ_MOTION_EVENT_CARNUM_DISCERN:
            // 车牌和人脸在iot_loop()定时上报
            ret = 0;
            break;
        default:
            ret = -1;
            break;
    }

    return ret;
}

// 移动侦测IOT注册
int iot_motion_register(void)
{
#ifndef APP_DOORBELL //门铃只有移动侦测和人形侦测
    char *pcMotionProp = "{\"Motion\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Trace\":\"0\",\"Interval\":\"30\"},"
                          "\"Human\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Trace\":\"0\",\"Interval\":\"30\"},"
                          "\"Face\":{\"Sensitive\":\"20\",\"Status\":\"0\",\"DiscernFlag\":\"0\",\"Trace\":\"0\",\"Interval\":\"0\"},"
                          "\"Fence\":{\"EventType\":\"1\",\"OnlyFlag\":\"0\",\"Status\":\"0\",\"Direction\":\"1\",\"StayTime\":\"0\","
                                     "\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"Capture\":\"0\",\"Video\":\"0\",\"ExpandEventAbility\":\"3\","
                                     "\"Regions\":{"
                                        "\"RegionNum\":\"0\","
                                        "\"Regions\":[{\"RegionId\":\"0\",\"RegionPoints\":[{\"x\":\"0.000\",\"y\":\"0.000\"},{\"x\":\"0.000\",\"y\":\"0.000\"},{\"x\":\"0.000\",\"y\":\"0.000\"},{\"x\":\"0.000\",\"y\":\"0.000\"}]}]}},"
                          "\"CarNum\":{\"Sensitive\":\"20\",\"Status\":\"0\",\"Trace\":\"0\",\"Interval\":\"0\"},"
                          "\"Car\":{\"Sensitive\":\"20\",\"Status\":\"0\",\"Trace\":\"0\",\"Interval\":\"0\"}}";
#else
    char *pcMotionProp =  "{\"Motion\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Trace\":\"0\",\"Interval\":\"30\"},"
                          "\"Human\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Trace\":\"0\",\"Interval\":\"30\"}}";
#endif

    /**
     * 运动侦测IOT注册示例
     * 运动侦测包含三种事件类型
     * EN_ZJ_MOTION_EVENT_MOTION       移动侦测事件类型
     * EN_ZJ_MOTION_EVENT_HUMAN        人形侦测事件类型
     * EN_ZJ_MOTION_EVENT_FACE         人脸侦测事件类型
     * 
     * 注意: MOTION IOT不需要设置策略，SDK内部已添加相关策略
     */
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_MOTION, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_motion_start,
                        aiiot_motion_stop, 
                        NULL, 
                        NULL, 
                        aiiot_motion_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot motion register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcMotionProp);
        // unsigned char aucLampBuff1[256]    = {0};
        // snprintf((char*)aucLampBuff1,256,"{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\",\"AddOutputProp\":\"0\"}");
        // ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_HUMAN,EN_ZJ_AIIOT_TYPE_INNER_LAMP,EN_ZJ_DEFAULT_IOTID, aucLampBuff1);
        // ZJ_DelAlarmPolicyOutputProp(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_HUMAN,
        //                         EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID,
        //                         (unsigned char*)"AddOutputProp");
    }

    // 删除IOT类型的属性字段
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "Motion");
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "Human");
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "Face");
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "CarNum");
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "Car");

    return 0;
}
