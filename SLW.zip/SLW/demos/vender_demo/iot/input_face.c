#include "zj_type.h"
#include "zj_log.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"

#include "public.h"
#include "input_motion.h"
#include "input_face.h"

#include "type.h"
#include "devlog.h"
#include "zip.h"
#include "ga_1400.h"

#define FACE_BLACKLIST_LABELID  "AICAM_LABELID"
#define FACE_WHITELIST_LABELID  "FACE_WHITELIST_LABELID"

static ST_MOTION_MNG *g_pstMotionMng = NULL;

// 人脸布控
static ST_ZJ_AIPIC_EVENT_INFO    g_stAiPicEventInfo = {0};
// 人脸抓拍ZIP
static ST_ZJ_AI_ZIP_EVENT_SIGNAL g_stAiZipEventInfo = {0};

// 人脸布控ID
static unsigned char g_aucBlackDispositionID[64] = {0};
static unsigned char g_aucWhiteDispositionID[64] = {0};

// 人脸识别上传图片, 注意设备每次上电都要平台先下发人脸库, 然后再上传，否则aucDispositionID不符合要求平台不识别
int face_Discern_upload_pic(EN_FACE_TYPE faceType, EN_FACE_MODE faceMode)
{
    struct stat buf;
    unsigned int uiPicSize         = 0;
    unsigned char *pucPicDataBg    = NULL;
    unsigned char *pucPicData      = NULL;
    unsigned char aucFileName[256] = {0};
    char aucDispositionID[64]      = {0};
    ST_ZJ_AIPIC_NODE stAiPicHead   = {0};

    // 根据布控模式选择对应的图片ID
    if (EN_FACE_BLACK_MODE == faceMode)
    {
         strncpy((char *)aucDispositionID, (char *)g_aucBlackDispositionID, sizeof(aucDispositionID));
    }
    else
    {
         strncpy((char *)aucDispositionID, (char *)g_aucWhiteDispositionID, sizeof(aucDispositionID));
    }

    // 未下发布控图片返回失败
    if (strlen((char *)aucDispositionID) < 1)
    {
        __ERROR_PRINTF("Face not distributed!\n");
        return -1;
    }

    // 背景图片
    // /opt/21cn/testfile/pic/face_bg.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, FACE_BG_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize    = buf.st_size;
    pucPicDataBg = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicDataBg)
    {
        __ERROR_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("Bg uiPicSize:%u\r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicDataBg, aucFileName))
    {
        free(pucPicDataBg);
        __INFO_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    g_stAiPicEventInfo.pucBgJpgBuff = pucPicDataBg;
    g_stAiPicEventInfo.uiBgJpgLen   = uiPicSize;
    g_stAiPicEventInfo.lluTimeStamp = getCurrentDayMsec();//Mos_Time();
    g_stAiPicEventInfo.dBgWidth     = 1920;
    g_stAiPicEventInfo.dBgHeight    = 1080;

    // 人脸图片
    // /opt/21cn/testfile/pic/face.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, FACE_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        free(pucPicDataBg);
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize  = buf.st_size;
    pucPicData = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicData)
    {
        free(pucPicDataBg);
        __ERROR_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("uiPicSize:%d \r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicData, aucFileName))
    {
        free(pucPicData);
        free(pucPicDataBg);
        __ERROR_PRINTF("get_file_data: %s failed\n", aucFileName);
        return -1;
    }

    stAiPicHead.pucPicBuf    = pucPicData;
    stAiPicHead.uiPicLen     = uiPicSize;
    stAiPicHead.uiSimilarity = 98;
    stAiPicHead.pstNextNode  = NULL;
    strcpy((char *)stAiPicHead.aucLabelID, aucDispositionID);

    g_stAiPicEventInfo.pstAiPicHead = &stAiPicHead;

    // 人脸布控事件上报
    __INFO_PRINTF("ZJ_SetAiPicEvent start \r\n");
    if (EN_OLD_FACE_TYPE == faceType)
    {
        ZJ_SetAiPicEvent(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_FACE, &g_stAiPicEventInfo);
    }
    else
    {
        ZJ_SetAiPicEvent(EN_ZJ_AIIOT_TYPE_FACE_DISCERN, 0, 0, &g_stAiPicEventInfo);
    }
    __INFO_PRINTF("ZJ_SetAiPicEvent end   \r\n");
    
    // SDK会回调释放图片资源
    // free(pucPicData);
    // free(pucPicDataBg);

    return 0;
}

// 人脸抓拍上传(ZIP方式)
int face_snap_upload_zip(EN_FACE_TYPE faceType)
{
    // Ai事件信号输入(压缩方式)
    __INFO_PRINTF("ZJ_SetAiPicEventEx start \r\n");

    struct stat buf; 
    int iRetZip                    =  0;
    zipFile zf                     = NULL;
    zip_fileinfo zi                = {0};

    // 外部图片资源信息
    unsigned int  uiPicSize        = 0;
    unsigned char *pucPicDataZip   = NULL;
    unsigned char *pucPicDataBgZip = NULL;
    unsigned char aucFileName[256] = {0};

    // 压缩包信息
    unsigned char aucFileZipName[256]     = {0};
    unsigned char aucBgFileNameZip[16]    = "000.jpg";
    unsigned char aucFaceFileNameZip0[16] = "000_0.jpg";

    ST_MOS_SYS_TIME stSysTime;
    get_mos_time(&stSysTime);
    ST_DEV_INFO *pstDevInfo = get_dev_info();

    snprintf(aucFileZipName, sizeof(aucFileZipName), "%s/%s_%04hu%02hu%02hu_%02hu%02hu%02hu.zip", DEVICE_PIC_PATH, pstDevInfo->acDevUID, \
    stSysTime.usYear, stSysTime.usMonth, stSysTime.usDay, stSysTime.usHour, stSysTime.usMinute, stSysTime.usSecond);

    __INFO_PRINTF("aucFileZipName:%s\r\n", aucFileZipName);

    // 创建打开zip文件
    zf = zipOpen64(aucFileZipName, 0);
    if (zf == NULL)
    {
        __ERROR_PRINTF("error opening %s \r\n", aucFileZipName);
    }
    else
    {
        __INFO_PRINTF("creating ZIP File %s \r\n", aucFileZipName);
    }

    // BG PIC TO ZIP
    // /opt/21cn/testfile/pic/face_bg.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, FACE_BG_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize = buf.st_size;
    pucPicDataBgZip = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicDataBgZip)
    {
        __ERROR_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("Bg uiPicSize:%d \r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicDataBgZip, aucFileName))
    {
        free(pucPicDataBgZip);
        __ERROR_PRINTF("get_file_data: %s failed\n", aucFileName);
        return -1;
    }

    __INFO_PRINTF("Bg  aucBgFileNameZip:%s \r\n", aucBgFileNameZip);

    // 将被压缩的文件名ucAIBgPicName添加进zip文件
    iRetZip = zipOpenNewFileInZip3_64(zf, (char *)aucBgFileNameZip, &zi, NULL, 0, NULL, 0, NULL, Z_DEFLATED,
                                    9, 0, -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY, NULL, 0, 0);
    if (iRetZip != ZIP_OK)
    {
        __ERROR_PRINTF("error BG zipOpenNewFileInZip3_64 %s \r\n", aucBgFileNameZip);
    }
    else
    {
        // 将被压缩的文件数据写进zip文件
        iRetZip = zipWriteInFileInZip (zf, pucPicDataBgZip, uiPicSize);
        if (iRetZip < 0)
        {
            __ERROR_PRINTF("error BG zipWriteInFileInZip %s \r\n", aucBgFileNameZip);
        }
        else
        {
            // 每个被压缩文件写完后都要条用该接口关闭文件
            iRetZip = zipCloseFileInZip(zf);
            if (iRetZip != ZIP_OK)
            {
                __ERROR_PRINTF("error BG zipCloseFileInZip %s \r\n", aucBgFileNameZip);
            }
        }
    }

    // FACE1 PIC TO ZIP
    // /opt/21cn/testfile/pic/face.jpg
    sprintf((char *)aucFileName, "%s/%s", DEVICE_PIC_PATH, FACE_FILE_NAME);

    if (stat((char *)aucFileName, &buf) < 0)
    {
        free(pucPicDataBgZip);
        __ERROR_PRINTF("stat: %s failed\n", aucFileName);
        return -1;
    }

    uiPicSize = buf.st_size;
    pucPicDataZip = (unsigned char *)malloc(uiPicSize);
    if (NULL == pucPicDataZip)
    {
        free(pucPicDataBgZip);
        __ERROR_PRINTF("malloc failed\n");
        return -1;       
    }

    __INFO_PRINTF("Bg uiPicSize:%d \r\n", uiPicSize);

    // 获取图片数据
    if (0 != get_file_data((char *)pucPicDataZip, aucFileName))
    {
        free(pucPicDataZip);
        free(pucPicDataBgZip);
        __ERROR_PRINTF("get_file_data: %s failed\n", aucFileName);
        return -1;
    }

    __INFO_PRINTF("Face  aucFaceFileNameZip0:%s \r\n", aucFaceFileNameZip0);

    // 将被压缩的文件名ucAIBgPicName添加进zip文件
    iRetZip = zipOpenNewFileInZip3_64(zf, (char *)aucFaceFileNameZip0, &zi, NULL, 0, NULL, 0, NULL, Z_DEFLATED,
                                    9, 0, -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY, NULL, 0, 0);
    if (iRetZip != ZIP_OK)
    {
        __ERROR_PRINTF("error Face zipOpenNewFileInZip3_64 %s \r\n", aucFaceFileNameZip0);
    }
    else
    {
        // 将被压缩的文件数据写进zip文件
        iRetZip = zipWriteInFileInZip (zf, pucPicDataZip, uiPicSize);
        if (iRetZip < 0)
        {
            __ERROR_PRINTF("error Face zipWriteInFileInZip %s \r\n", aucFaceFileNameZip0);
        }
        else
        {
            // 每个被压缩文件写完后都要条用该接口关闭文件
            iRetZip = zipCloseFileInZip(zf);
            if (iRetZip != ZIP_OK)
            {
                __ERROR_PRINTF("error Face zipCloseFileInZip %s \r\n", aucFaceFileNameZip0);
            }
        }
    }

    if (zf)
    {
        // 关闭zip文件
        iRetZip = zipClose(zf, NULL);
        if (iRetZip != ZIP_OK)
        {
            __ERROR_PRINTF("error zipClose %s \r\n", aucFileZipName);
        }
        zf = NULL;
    }

    strcpy((char *)g_stAiZipEventInfo.aucFilePath, (char *)aucFileZipName);

    __INFO_PRINTF("aucFileZipName:%s \r\n", g_stAiZipEventInfo.aucFilePath);

    ST_ZJ_ZIP_AIBGFILE_NODE stZipAiBgFileNode = {0};
    strcpy((char *)stZipAiBgFileNode.aucBgFileName, (char *)aucBgFileNameZip);
    stZipAiBgFileNode.lluTimeStamp = getCurrentDayMsec();//Mos_Time();

    ST_ZJ_ZIP_AIFACEFILE_INFO stZipAiFaceFileInf1 = {0};
    strcpy((char *)stZipAiFaceFileInf1.aucFaceFileName, (char *)aucFaceFileNameZip0);

    stZipAiBgFileNode.pstZipFaceFileHead = &stZipAiFaceFileInf1;

    g_stAiZipEventInfo.pstZipBgFileHead  = &stZipAiBgFileNode;

    if (EN_OLD_FACE_TYPE == faceType)
    {
        ZJ_SetAiPicEventEx(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_FACE, &g_stAiZipEventInfo);
    }
    else
    {
        ZJ_SetAiPicEventEx(EN_ZJ_AIIOT_TYPE_FACE_CAPTURE, 0, 0, &g_stAiZipEventInfo);
    }
    __INFO_PRINTF("ZJ_SetAiPicEventEx end   \r\n");

    free(pucPicDataZip);
    free(pucPicDataBgZip);

    return 0;
}

int iot_face_snap_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime = 0;

    gettimeofday(&cur_tv, 0);

    g_pstMotionMng = aiiot_get_motion_mng();

    if ((cur_tv.tv_sec - lastTime) >= g_pstMotionMng->stFace.stEvent.iInterval)
    {
        lastTime = cur_tv.tv_sec;

        // __INFO_PRINTF("iStatus = %d, iDiscernFlag = %d, iInterval = %d\n", g_pstMotionMng->stFace.stEvent.iStatus, \
        //                                                                    g_pstMotionMng->stFace.iDiscernFlag, \
        //                                                                    g_pstMotionMng->stFace.stEvent.iInterval);

        if (1 == g_pstMotionMng->stFace.iDiscernFlag)
        {
            // 人脸布控示例
            ret = face_Discern_upload_pic(EN_OLD_FACE_TYPE, EN_FACE_BLACK_MODE);
        }        
        else if (1 == g_pstMotionMng->stFace.stEvent.iStatus)
        {
            /* 人脸上传参考示例 */
            /* 1400方式上传 */
            ret = ga1400_upload_face_snap(EN_OLD_FACE_TYPE);

            // 人脸抓拍上传(ZIP方式)
            ret = face_snap_upload_zip(EN_OLD_FACE_TYPE);
        }
    }
    else
    {
        // __INFO_PRINTF("input iInterval < %d\n", g_pstMotionMng->stFace.stEvent.iInterval);
    }

    return ret;
}

// 创建识别底库集,一个pucLabelID可对应多张picid; iLableType 1人脸 2牌照; uiWBList 1.黑名单 2.白名单
int ai_CreateLabelCb(unsigned char *pucLabelID, int iLableType, unsigned int uiWBList)
{
    __INFO_PRINTF("ai_CreateLabelCb pucLabelID:%s iLableType:%d uiWBList:%u\n", pucLabelID, iLableType, uiWBList);

    return 0;
}

// 提取布控图片特征值
int ai_AddSingleAiPicCb(unsigned char *pucLabelID, unsigned char *pucPicID, unsigned char *pucAIPicFile)
{
    __INFO_PRINTF("ai_AddSingleAiPicCb pucLabelID:%s pucPicID:%s pucAIPicFile:%s TODO \n", pucLabelID, pucPicID, pucAIPicFile);

    if (0 == strcmp(pucLabelID, FACE_BLACKLIST_LABELID))
    {
        // 黑名单图片
        strncpy((char *)g_aucBlackDispositionID, (char *)pucPicID, sizeof(g_aucBlackDispositionID));
    }
    else
    {
        //  白名单图片
        strncpy((char *)g_aucWhiteDispositionID, (char *)pucPicID, sizeof(g_aucWhiteDispositionID));
    }
    
    // TODO 提取布控图片特征值
    return 0;
}

// 删除布控图片的特征值
int ai_DelSingleAiPicCb(unsigned char *pucLabelID, unsigned char *pucPicID)
{
    __INFO_PRINTF("ai_DelSingleAiPicCb pucLabelID:%s pucPicID:%s TODO \n", pucLabelID, pucPicID);

    // TODO 删除布控图片的特征值
    return 0;
}

// 释放上报人脸图和背景图的缓存
int ai_FreeAiPicCacheCb(unsigned char *pucPicID, unsigned char *pucFaceData, unsigned char *pucBgData)
{
    __INFO_PRINTF("ai_FreeAiPicCacheCb pucPicID:%s pucFaceData:%p pucBgData:%p TODO \n", pucPicID, pucFaceData, pucBgData);

    if (pucBgData)
    {
        free(pucBgData);
    }

    if (pucFaceData)
    {
        free(pucFaceData);
    }
    
    return 0;  
}

int face_init()
{
    // AI旧人脸布控能力（对接新人脸时该接口不能调用）0.不支持；1.支持 
    ZJ_SetDevAiFaceAbility(1);

    // AI 设备支持的最大布控底图数目
    ZJ_SetAiMaxPicNum(100);

    // AI 设备当前布控地图数目
    ZJ_SetAiCurPicNum(10);

    // 设置布控人脸图片缓存路径
    ZJ_SetFaceFileCachePath((unsigned char *)DEVICE_AIPIC_PATH);

    // Ai事件注册回调设置
    ZJ_SetAiPicCB(ai_CreateLabelCb, NULL, ai_AddSingleAiPicCb, ai_DelSingleAiPicCb, NULL);

    // 注册回调：释放上报人脸图和背景图的缓存
    ZJ_SetFreeAiPicCacheCB(ai_FreeAiPicCacheCb);

    return 0;
}
