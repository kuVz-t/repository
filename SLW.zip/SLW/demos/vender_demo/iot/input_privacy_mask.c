#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "public.h"

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
static int aiiot_PrivacyMask_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
static int aiiot_PrivacyMask_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_PrivacyMask_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_PRIVACYMASK中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {"Status":"0","MaskMode":"0","Regions":[{"RegionId":"1","RegionPoints":[{"x":"0.000","y":"0.000"},{"x":"0.000","y":"0.000"}]}],"ExecuteTime":[{"StartTime":"0","EndTime":"86400","SpanFlag":"0"}]}
     *
     * {
     *   "Status":"功能开关（string）",
     *   "MaskMode":"遮罩模式（string）,0-区域内遮罩,1-区域外遮罩",
     *   "Regions":[]见SDK对接文档6.2.25章节"
     *   "ExecuteTime":[]见SDK对接文档6.2.25章节"
     * }
     * 
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

// 隐私遮罩IOT注册
int iot_privacy_mask_register(void)
{
    // 添加隐私遮罩能力值 0:不支持; 1:支持,只支持单个矩形区域; 2:支持,支持单个多边形区域; 3:支持,支持多个矩形区域; 4:支持,支持多个多边形区域
    ZJ_SetDevAiCommonAbility("PrivacyMaskAbility", 1);

    // 添加隐私遮罩告警IoT设备
    char *pcPrivacyMaskDefaultProp = "{\"Status\":\"0\",\"MaskMode\":\"0\","
                                     "\"Regions\":[{\"RegionId\":\"0\",\"RegionPoints\":[{\"x\":\"0.000\",\"y\":\"0.000\"},{\"x\":\"0.000\",\"y\":\"0.000\"}]}],"
                                     "\"ExecuteTime\":[{\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\"}]}";

    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_PRIVACYMASK, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_PrivacyMask_start,
                        aiiot_PrivacyMask_stop, 
                        NULL, 
                        NULL, 
                        aiiot_PrivacyMask_setprop, 
                        NULL) == 0)
    {
        // 设置隐私遮罩默认属性
        __INFO_PRINTF("device iot PrivacyMask register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_PRIVACYMASK, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_PRIVACYMASK, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcPrivacyMaskDefaultProp);
    
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_PrivacyMask = {0};
        stIoTPolicyInfo_PrivacyMask.uiInIoTType     = EN_ZJ_AIIOT_TYPE_PRIVACYMASK;
        stIoTPolicyInfo_PrivacyMask.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_PrivacyMask.uiInIoTEventId  = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_PrivacyMask.uiOpenFlag      = 1;
        stIoTPolicyInfo_PrivacyMask.uiSpanFlag      = 0;
        stIoTPolicyInfo_PrivacyMask.uiStartTime     = 0;
        stIoTPolicyInfo_PrivacyMask.uiEndTime       = 86400;
        stIoTPolicyInfo_PrivacyMask.uiWeekFlag      = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_PrivacyMask.aucPolicyName), IOT_POLICYNAME_PRIVACYMASK, sizeof(stIoTPolicyInfo_PrivacyMask.aucPolicyName));
        // 添加隐私遮罩告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_PrivacyMask);
    }

    return 0;
}