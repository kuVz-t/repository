
#include "zj_type.h"
#include "zj_cameraiot.h"
#include "zj_camera.h"
#include "public.h"

typedef struct stru_executeTime_inf
{
    unsigned int uiUseFlag;
    unsigned int uiIoTType;
    int iSpanFlag;
    int iRemindStatus;
    unsigned int uiStartTime;
    unsigned int uiEndTime;
    struct stru_executeTime_inf *pstNextNode;
}ST_EXECUTETIME_INF;

static int g_iAlarmSoundExecuteTimeAbility = 0;

static int g_iExecuteTimeArraySize  = 0;
static ST_EXECUTETIME_INF *g_pstExecuteTimeInfHead = NULL;

void SetAlarmSoundExecuteTimeAbility(int ability)
{
    g_iAlarmSoundExecuteTimeAbility = ability;
}

/**
 * 向AIiOT 设备输出信号回调接口,通过该接口,将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 * 对于扬声器(1009)的注意事项：
    1、先判断CtrlType字段做开启或关闭播放
    2、再进行时间判断
        a、常规功能,不支持扬声器多时间段播报能力AlarmSoundExecuteTimeAbility  仅处理外部StartTime、EndTime,不需处理ExecuteTime字段
            1) 判断当前时间是否在StartTime、EndTime的范围,若StartTime和EndTime字段缺失则认为生效
        b、支持扬声器多时间段播报能力AlarmSoundExecuteTimeAbility后(对接支持老人吃药提醒功能)
            1) 扬声器(1009)output的ExecuteTime字段为空或者数组个数为0时,仅处理外部StartTime、EndTime,不需处理ExecuteTime字段,
                            判断当前时间是否在StartTime、EndTime的范围,若StartTime和EndTime字段缺失则认为生效
            2) 扬声器(1009)output的ExecuteTime数组个数非0时,不需处理外部StartTime、EndTime,需要处理ExecuteTime字段以及其包含的字段
                            目前业务需求最大支持10个时间段,StartTime和EndTime每天生效
            3) 多时间段个数变更,即对时间段修改,重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
            4) 多时间段个数未变更,若某时间段被修改,重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
            5) RemindRule字段缺失时,默认每次播报
    3、再判断SoundType字段(2-自定义告警声 或者 预设内置告警声,4-默认告警声)
        1) 如果SoundType为2时,再根据SoundName播放自定义(下载)告警声音 或者 播放预置(非下载)告警声音,此时AlarmType字段允许缺失；
        2) 如果SoundType为4时,再根据AlarmType播放某类型的默认告警声音；
    4、最后根据LoopCnt字段做次数播放
 */
static int aiiot_buzzer_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue, ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来,需要对接厂商解析并设置
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue == NULL ? (unsigned char*)"nil":pSignalValue);
    __INFO_PRINTF("AlarmSoundExecuteTimeAbility: %d \n", g_iAlarmSoundExecuteTimeAbility);

    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",    pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n",  pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",    pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",    pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",   pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",    pstTriggerInf->pstHandler);
    }

    int i                     = 0;
    int iInTimeFlag           = 0;
    int iIsChangeExecuteTime  = 0;
    int iSpanFlag             = 0;
    unsigned int uiStartTime  = 0;
    unsigned int uiEndTime    = 0;
    unsigned int uiSecInDay   = 0;
    int iExecuteTimeArraySize = 0;
    int iCtrlType   = 0;
    int iSoundType  = 0;
    int iAlarmType  = 0;
    int iLoopCnt    = 0;
    int iRemindRule = 0;
    time_t tCurTime = 0;
    struct tm stTmCurTime = {0};
    unsigned char aucDay[16] = {0};
    static unsigned char aucLastDay[16] = {0};
    unsigned char *pucSoundName = NULL;
    unsigned char aucSoundName[64] = {0};
    ST_EXECUTETIME_INF *pstExecuteTimeInfPre  = NULL;
    ST_EXECUTETIME_INF *pstExecuteTimeInfTmp  = NULL;

    cJSON *cOutputJson = NULL;
    cJSON *cSpanFlag   = NULL;
    cJSON *cStartTime  = NULL;
    cJSON *cEndTime    = NULL;
    cJSON *cExecuteTimeItem  = NULL;
    cJSON *cExecuteTimeArray = NULL;
    cJSON *cCtrlType   = NULL;
    cJSON *cSoundType  = NULL;
    cJSON *cAlarmType  = NULL;
    cJSON *cSoundName  = NULL;
    cJSON *cLoopCnt    = NULL;
    cJSON *cRemindRule = NULL;

    if ((pSignalValue == NULL) || (strlen((char*)pSignalValue) <= 0))
    {
        __ERROR_PRINTF("device aiiot buzzer output failed\n");
        return -1;
    }

    cOutputJson = cJSON_Parse((char*)pSignalValue);
    if (cOutputJson == NULL)
    {
        __ERROR_PRINTF("device aiiot buzzer output failed, json prase err\n");
        return -1;
    }

    // 1、先判断CtrlType字段做开启或关闭播放
    // 获取控制开关字段
    cCtrlType = cJSON_GetObjectItem(cOutputJson, "CtrlType");
    if (cCtrlType)
    {
        // 获取控制开关字段值
        GetIntegerValue(cCtrlType, &iCtrlType);
    }

    //播放开关关闭,退出播放
    if (iCtrlType == 0)
    {
        __INFO_PRINTF("iCtrlType: %d \n", iCtrlType);
        // 释放JSON
        if (cOutputJson != NULL)
        {
            cJSON_Delete(cOutputJson);
            cOutputJson = NULL;
        }
        return 0;
    }

    // 2、再进行时间判断
    // a、常规功能,不支持扬声器多时间段播报能力 AlarmSoundExecuteTimeAbility 仅处理外部StartTime、EndTime,不需处理ExecuteTime字段.
    if (g_iAlarmSoundExecuteTimeAbility == 0)
    {
		// 1) 判断当前时间是否在外部StartTime、EndTime的范围,若StartTime和EndTime字段缺失则认为生效.
        // 获取外部StartTime、EndTime值
        cStartTime = cJSON_GetObjectItem(cOutputJson, "StartTime");
        if (cStartTime)
        {
            if (GetIntegerValue(cStartTime, (int *)&uiStartTime) == 0)
            {
                cEndTime = cJSON_GetObjectItem(cOutputJson, "EndTime");
                if (cEndTime)
                {
                    if (GetIntegerValue(cEndTime, (int *)&uiEndTime) == 0)
                    {
                        // 获取当天的秒数
                        tCurTime = time(NULL);
                        localtime_r(&tCurTime, &stTmCurTime);
                        uiSecInDay = (stTmCurTime.tm_hour * 3600) + (stTmCurTime.tm_min * 60) + (stTmCurTime.tm_sec);

                        // 当前时间在播放时间段内
                        if ((uiSecInDay >= uiStartTime) && (uiSecInDay <= uiEndTime))
                        {
                            iInTimeFlag = 1;
                        }
                    }
                }
                else
                {
                    // 若StartTime和EndTime字段缺失则认为生效
                    // output里外部StartTime和EndTime字段缺失时, 默认处于时间内播放语音
                    iInTimeFlag = 1;
                }
            }
        }
        else
        {
            // 若StartTime和EndTime字段缺失则认为生效
            // output里外部StartTime和EndTime字段缺失时, 默认处于时间内播放语音
            iInTimeFlag = 1;
        }
    }
    // b、支持扬声器多时间段播报能力AlarmSoundExecuteTimeAbility后(对接支持老人吃药提醒功能)
    else if (g_iAlarmSoundExecuteTimeAbility == 1)
    {
        // 获取拓展多时间段字段
        cExecuteTimeArray = cJSON_GetObjectItem(cOutputJson, "ExecuteTime");
        if (cExecuteTimeArray)
        {
            // 获取拓展多时间段字段数组个数
            iExecuteTimeArraySize = cJSON_GetArraySize(cExecuteTimeArray);
        }

        // 1) 扬声器(1009)output的ExecuteTime字段为空或者数组个数为0时,仅处理外部StartTime、EndTime,不需处理ExecuteTime字段.
        //    判断当前时间是否在外部StartTime、EndTime的范围,若StartTime和EndTime字段缺失则认为生效.
        if (iExecuteTimeArraySize == 0)
        {
            // 获取外部StartTime、EndTime值
            cStartTime = cJSON_GetObjectItem(cOutputJson, "StartTime");
            if (cStartTime)
            {
                if (GetIntegerValue(cStartTime, (int *)&uiStartTime) == 0)
                {
                    cEndTime = cJSON_GetObjectItem(cOutputJson, "EndTime");
                    if (cEndTime)
                    {
                        if (GetIntegerValue(cEndTime, (int *)&uiEndTime) == 0)
                        {
                            // 获取当天的秒数
                            tCurTime = time(NULL);
                            localtime_r(&tCurTime, &stTmCurTime);
                            uiSecInDay = (stTmCurTime.tm_hour * 3600) + (stTmCurTime.tm_min * 60) + (stTmCurTime.tm_sec);

                            // 当前时间在播放时间段内
                            if ((uiSecInDay >= uiStartTime) && (uiSecInDay <= uiEndTime))
                            {
                                iInTimeFlag = 1;
                            }
                        }
                    }
                    else
                    {
                        // 若StartTime和EndTime字段缺失则认为生效
                        // output里外部StartTime和EndTime字段缺失时, 默认处于时间内播放语音
                        iInTimeFlag = 1;     
                    }
                }
            }
            else
            {
                // 若StartTime和EndTime字段缺失则认为生效
                // output里外部StartTime和EndTime字段缺失时, 默认处于时间内播放语音
                iInTimeFlag = 1;
            }
        }
        // 2) 扬声器(1009)output的ExecuteTime数组个数非0时,不需处理外部StartTime、EndTime,需要处理ExecuteTime字段以及其包含的字段.
        // 目前业务需求最大支持10个时间段.StartTime和EndTime每天生效.
        else if (iExecuteTimeArraySize > 0)
        {
            // 3) 多时间段个数变更,即对时间段修改,重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
            if (g_iExecuteTimeArraySize != iExecuteTimeArraySize)
            {
                iIsChangeExecuteTime = 1;
            }
            // 4) 多时间段个数未变更,若某时间段被修改,重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
            else
            {
                // 遍历时间段的个节点数据有无被修改
                pstExecuteTimeInfTmp = g_pstExecuteTimeInfHead;
                for (i = 0; i < iExecuteTimeArraySize; i++)
                {
                    cExecuteTimeItem = cJSON_GetArrayItem(cExecuteTimeArray,i);

                    // 获取ExecuteTime内部StartTime值
                    cStartTime = cJSON_GetObjectItem(cExecuteTimeItem, "StartTime");
                    if (cStartTime)
                    {
                        GetIntegerValue(cStartTime, (int *)&uiStartTime);
                    }
                    // 获取ExecuteTime内部EndTime值
                    cEndTime = cJSON_GetObjectItem(cExecuteTimeItem, "EndTime");
                    if (cEndTime)
                    {
                        GetIntegerValue(cEndTime, (int *)&uiEndTime);
                    }
                    // 获取ExecuteTime内部SpanFlag值
                    cSpanFlag = cJSON_GetObjectItem(cExecuteTimeItem, "SpanFlag");
                    if (cSpanFlag)
                    {
                        GetIntegerValue(cSpanFlag, &iSpanFlag);
                    }

                    if (pstExecuteTimeInfTmp)
                    {
                        // 该时间段节点未被修改
                        if ((pstExecuteTimeInfTmp->iSpanFlag   == iSpanFlag)   &&
                            (pstExecuteTimeInfTmp->uiStartTime == uiStartTime) &&
                            (pstExecuteTimeInfTmp->uiEndTime   == uiEndTime))
                        {
                            // 继续遍历下一个节点
                            pstExecuteTimeInfTmp = pstExecuteTimeInfTmp->pstNextNode;
                            continue;
                        }
                        // 该时间段节点被修改
                        else
                        {
                            iIsChangeExecuteTime = 1;
                            break;
                        }
                    }
                    // 出现NULL节点即被修改时间段
                    else
                    {
                        iIsChangeExecuteTime = 1;
                        break;
                    }
                }
            }

            // 检测到跨天，重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
            ST_MOS_SYS_TIME stSysTime = {0};
            get_mos_time(&stSysTime);
            snprintf(aucDay, "%04hu-%02hu-%02hu", stSysTime.usYear, stSysTime.usMonth, stSysTime.usDay);
            if (strlen(aucLastDay) == 0)
            {
                strncpy(aucLastDay, aucDay, sizeof(aucLastDay));
            }
            else
            {
                if (strncmp(aucDay, aucLastDay, sizeof(aucDay)) != 0)
                {
                    iIsChangeExecuteTime = 1;
                    strncpy(aucLastDay, aucDay, sizeof(aucLastDay));
                }
            }

            // 若时间段被修改 重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报.
            if (iIsChangeExecuteTime == 1)
            {
                for (i = 0; i < iExecuteTimeArraySize; i++)
                {
                    cExecuteTimeItem = cJSON_GetArrayItem(cExecuteTimeArray,i);

                    // 获取ExecuteTime内部StartTime值
                    cStartTime = cJSON_GetObjectItem(cExecuteTimeItem, "StartTime");
                    if (cStartTime)
                    {
                        GetIntegerValue(cStartTime,(int *) &uiStartTime);
                    }
                    // 获取ExecuteTime内部EndTime值
                    cEndTime = cJSON_GetObjectItem(cExecuteTimeItem, "EndTime");
                    if (cEndTime)
                    {
                        GetIntegerValue(cEndTime, (int *)&uiEndTime);
                    }

                    // 获取ExecuteTime内部SpanFlag值
                    cSpanFlag = cJSON_GetObjectItem(cExecuteTimeItem, "SpanFlag");
                    if (cSpanFlag)
                    {
                        GetIntegerValue(cSpanFlag, &iSpanFlag);
                    }

                    if (pstExecuteTimeInfTmp == NULL)
                    {
                        pstExecuteTimeInfTmp    = malloc(sizeof(ST_EXECUTETIME_INF));
                        g_pstExecuteTimeInfHead = pstExecuteTimeInfTmp;
                    }
                    else
                    {
                        pstExecuteTimeInfTmp = malloc(sizeof(ST_EXECUTETIME_INF));
                    }

                    pstExecuteTimeInfTmp->uiIoTType     = uiAIIoTType;
                    pstExecuteTimeInfTmp->iSpanFlag     = iSpanFlag;
                    pstExecuteTimeInfTmp->uiStartTime   = uiStartTime;
                    pstExecuteTimeInfTmp->uiEndTime     = uiEndTime;
                    pstExecuteTimeInfTmp->iRemindStatus = 0;    //播放标志位清0 语音播报状态为未播报.
                    if (pstExecuteTimeInfPre)
                    {
                        pstExecuteTimeInfPre->pstNextNode = pstExecuteTimeInfTmp;
                    }
                    pstExecuteTimeInfPre = pstExecuteTimeInfTmp;
                }
            }

            // 获取当天的秒数
            tCurTime = time(NULL);
            localtime_r(&tCurTime, &stTmCurTime);
            uiSecInDay = (stTmCurTime.tm_hour * 3600) + (stTmCurTime.tm_min * 60) + (stTmCurTime.tm_sec);

            pstExecuteTimeInfTmp = g_pstExecuteTimeInfHead;
            while (pstExecuteTimeInfTmp)
            {
                // 在布控时间段内触发告警
                if (((iSpanFlag == 0) && ((uiSecInDay >= pstExecuteTimeInfTmp->uiStartTime) && (uiSecInDay <= pstExecuteTimeInfTmp->uiEndTime))) || 
                    ((iSpanFlag == 1) && ((uiSecInDay >= pstExecuteTimeInfTmp->uiStartTime) || (uiSecInDay <= pstExecuteTimeInfTmp->uiEndTime))) )
                {
                    // 获取播报提醒规则字段
                    cRemindRule = cJSON_GetObjectItem(cExecuteTimeItem, "RemindRule");
                    if (cRemindRule)
                    {
                        // 获取播报提醒规则字段值
                        GetIntegerValue(cRemindRule, &iRemindRule);
                        // 每次都播报
                        if (iRemindRule == 0)
                        {
                            iInTimeFlag = 1;
                            break;
                        }
                        // 每个时间段只播报一次
                        else if (iRemindRule == 1)
                        {
                            // 未播报
                            if (pstExecuteTimeInfTmp->iRemindStatus == 0)
                            {
                                iInTimeFlag = 1;
                                pstExecuteTimeInfTmp->iRemindStatus = 1;
                                break;
                            }
                            // 已播报
                            else
                            {
                                iInTimeFlag = 0;
                            }
                        }
                    }
                    // 5) RemindRule字段缺失时,默认每次播报.
                    else
                    {
                        iInTimeFlag = 1;
                        break;
                    }
                }
                else
                {
                    pstExecuteTimeInfTmp = pstExecuteTimeInfTmp->pstNextNode;
                }
            }
        }
    }

    // 在时间段内
    if (iInTimeFlag == 1)
    {
        // 3、再判断SoundType字段(2-自定义告警声 或者 预设内置告警声,4-默认告警声)
        // 获取播放声音类型字段
        cSoundType = cJSON_GetObjectItem(cOutputJson, "SoundType");
        if (cSoundType)
        {
            // 获取播放声音类型字段值
            if (GetIntegerValue(cSoundType, &iSoundType) == 0)
            {
                // 下载的自定义报警声音文件(可删) 和 预置的报警声音文件(不可删)
                // 1)如果SoundType为2时,再根据SoundName播放自定义(下载)告警声音 或者 播放预置(非下载)告警声音
                if (iSoundType == EN_ZJ_RING_DOORBELL)
                {
                    // 获取报警声音文件名字段
                    cSoundName = cJSON_GetObjectItem(cOutputJson, "SoundName");
                    if (cSoundName)
                    {
                        // 获取报警声音文件名字段值
                        GetStringValue(cSoundName, &pucSoundName);
                        if (pucSoundName)
                        {
                            strncpy((char *)aucSoundName, (char *)pucSoundName, sizeof(aucSoundName));

                            // 获取文件播放几次字段
                            cLoopCnt = cJSON_GetObjectItem(cOutputJson, "LoopCnt");
                            if (cLoopCnt)
                            {
                                // 获取文件播放几次字段值
                                if (GetIntegerValue(cLoopCnt, &iLoopCnt) == 0)
                                {
                                    // TODO
                                    // 如果SoundType为2时,再根据SoundName播放自定义(下载)告警声音 或者 播放预置(非下载)告警声音,最后根据LoopCnt字段做次数播放
                                }
                            }
                        }
                    }
                }
                // 设备默认警戒音
                // 2)如果SoundType为4时,再根据AlarmType播放某类型的默认告警声音
                else if (iSoundType == EN_ZJ_RING_ALARM)
                {
                    // 获取触发扬声器的报警类型字段
                    cAlarmType = cJSON_GetObjectItem(cOutputJson, "AlarmType");
                    if (cAlarmType)
                    {
                        // 获取触发扬声器的报警类型字段值
                        if (GetIntegerValue(cAlarmType, &iAlarmType) == 0)
                        {
                            // 获取文件播放几次字段
                            cLoopCnt = cJSON_GetObjectItem(cOutputJson, "LoopCnt");
                            if (cLoopCnt)
                            {
                                // 获取文件播放几次字段值
                                if (GetIntegerValue(cLoopCnt, &iLoopCnt) == 0)
                                {
                                    // TODO
                                    // 如果SoundType为4时,再根据AlarmType播放某类型的默认告警声音,最后根据LoopCnt字段做次数播放
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 释放JSON
    if (cOutputJson != NULL)
    {
        cJSON_Delete(cOutputJson);
        cOutputJson = NULL;
    }
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_buzzer_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_BUZZER中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     *          {"Volume":100}
     * Volume       门铃铃声音量
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]\n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Prop Value: %s \n", pstProp == NULL ? (unsigned char*)"null":pstProp);

    return 0;
}

// 扬声器IOT注册
int iot_buzzer_register(void)
{
    /**
     * 扬声器注册示例，注意：注册扬声器前需要
    */

    char *pcBuzzerProp = "{\"Volume\":\"100\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_BUZZER, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        aiiot_buzzer_output, 
                        aiiot_buzzer_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot buzzer register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcBuzzerProp);// 设置扬声器音量默认值
    }

    return 0;
}