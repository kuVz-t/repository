#include "zj_type.h"
#include "input_motion.h"
#include "public.h"

// 电子围栏/进出滞留的事件上传
int iot_fence_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};
    ST_MOTION_MNG *pstMotionMng = aiiot_get_motion_mng();

    if ((1 == pstMotionMng->stFence.stEvent.iStatus) && (pstMotionMng->stFence.iStayTime > 0))
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_MOTION, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_STAY, &stAIAlarmUploadInf);
        }
    }
    else
    {
         __INFO_PRINTF("[iot %d, eventid %d] iStatus or iStayTime is 0!\n", EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_STAY);
    }        

    return ret;
}