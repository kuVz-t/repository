#include "zj_type.h"
#include "zj_cameraiot.h"
#include "zj_camera.h"
#include "zj_system.h"
#include "zj_power.h"
#include "public.h"
#include "intelligent_broadcast.h"

static ST_IOT_EVENT g_stForceMove = {0};
static ST_IOT_EVENT g_stStayAlarm = {0};

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
static int aiiot_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%d] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_FORCEREMOVE)
    {
        g_stForceMove.iStatus = 1;
    }
    else if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_STAY)
    {
        g_stStayAlarm.iStatus = 1;
    }
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
static int aiiot_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%d] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_FORCEREMOVE)
    {
        g_stForceMove.iStatus = 0;
    }
    else if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_STAY)
    {
        g_stStayAlarm.iStatus = 0;
    }
    return 0;
}

// 门铃：有人按门铃事件推送
int iot_doorbell_event(void)
{
    ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_INNER_DOORBELL, 0, 0);

    return 0;
}

// 门铃：强拆报警事件推送
int iot_force_remove_event(void)
{
    int ret = -1;

    if (1 == g_stForceMove.iStatus)
    {
        ret = ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_FORCEREMOVE, 0, 0);
    }
    else
    {
         __INFO_PRINTF("[iot %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_FORCEREMOVE);
    }        

    return ret;
}

// 门铃：有人逗留报警事件推送
int iot_stay_event(void)
{
    int ret = -1;

    if (1 == g_stStayAlarm.iStatus)
    {
        ret = ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_STAY, 0, 0);
    }
    else
    {
         __INFO_PRINTF("[iot %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_STAY);
    }        

    return ret;
}

// 门铃IOT注册
int iot_doorbell_register(void)
{
    /**
     * 设置设备类型为门铃
    */
    ZJ_SetDevType(EN_ZJ_DEV_TYPE_DOORBELL_SINGLE);
    /**
     * 设置低功耗能力 - 可远程唤醒
    */
    ZJ_SetAwakeAbility(EN_ZJ_AWAKE_ABILITY_REMOTEAWAKE);
    /**
     * 设置摄像头自定义声音文件回调
    */    
    ZJ_SetCamAlarmSoundFileCB(NULL, aiiot_buzzer_getsoundfiles);
    /**
     * 内置门铃注册示例，注意：注册门铃前需要
    */
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_INNER_DOORBELL, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        NULL, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot doorbell register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_INNER_DOORBELL, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIotDefaultPolicy(EN_ZJ_AIIOT_TYPE_INNER_DOORBELL, 1, 0, 0, 1, 0, 
                            1, 1, 1, 0, 6, 0, EN_ZJ_RING_DOORBELL, (unsigned char *)"ringtone_dingdong");//设置默认门铃策略：关联扬声器IOT，设置默认铃声
    }

    /**
     * 设备强拆报警注册示例，注意：设备强拆报警前需要
    */
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_FORCEREMOVE, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot forceremove register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_FORCEREMOVE, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIotDefaultPolicy(EN_ZJ_AIIOT_TYPE_FORCEREMOVE, 0, 0, 0, 0, 0, 
                    1, 1, 1, 0, 6, 0, 0, (unsigned char *)"");//设置默认强拆策略
    }
    /**
     * 设备逗留报警注册示例，注意：设备逗留报警前需要
    */
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_STAY, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot stay register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_STAY, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIotDefaultPolicy(EN_ZJ_AIIOT_TYPE_STAY, 0, 0, 0, 0, 0, 
                    1, 1, 1, 0, 6, 30, 0, (unsigned char *)"");//设置默认逗留策略-30s
    }

    return 0;
}