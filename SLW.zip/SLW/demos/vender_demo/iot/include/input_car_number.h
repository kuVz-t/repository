#ifndef __INPUT_CAR_NUMBER_H__
#define __INPUT_CAR_NUMBER_H__

#define CAR_NUMBER1_FILE_NAME     "car_number1.jpg"
#define CAR_NUMBER1_BG_FILE_NAME  "car_number1_bg.jpg"

#define CAR_NUMBER2_FILE_NAME     "car_number2.jpg"
#define CAR_NUMBER2_BG_FILE_NAME  "car_number2_bg.jpg"

int iot_car_snap_event(void);

// 车牌抓拍上传(ZIP方式)
int car_snap_upload_zip();
#endif