#ifndef __OUTPUT_BUZZER_H__
#define __OUTPUT_BUZZER_H__

int iot_buzzer_register(void);
void SetAlarmSoundExecuteTimeAbility(int ability);

#endif