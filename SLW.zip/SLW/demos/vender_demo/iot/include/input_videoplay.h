#ifndef __INPUT_VIDEOPLAY_H__
#define __INPUT_VIDEOPLAY_H__

int iot_videoplay_register(void);
int iot_videoplay_event(unsigned int uiEvent);

#endif