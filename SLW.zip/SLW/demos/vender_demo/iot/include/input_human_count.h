#ifndef __INPUT_HUMAN_COUNT_H__
#define __INPUT_HUMAN_COUNT_H__

int iot_human_count_register(void);

#endif