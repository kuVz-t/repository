#ifndef __INPUT_NEW_HUMAN_H__
#define __INPUT_NEW_HUMAN_H__

int iot_new_human_register(void);
int iot_new_human_event(void);

#endif