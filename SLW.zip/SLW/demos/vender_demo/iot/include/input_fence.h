#ifndef __INPUT_FENCE_H__
#define __INPUT_FENCE_H__

int iot_fence_event(void);

#endif