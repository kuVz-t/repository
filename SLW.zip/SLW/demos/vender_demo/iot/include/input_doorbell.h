#ifndef __INPUT_DOOR_BELL_H__
#define __INPUT_DOOR_BELL_H__

int iot_doorbell_register(void);
int iot_doorbell_event(void);
int iot_force_remove_event(void);
int iot_stay_event(void);

#endif