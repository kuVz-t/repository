#ifndef __INPUT_FACE_H__
#define __INPUT_FACE_H__

#define FACE_FILE_NAME     "face.jpg"
#define FACE_BG_FILE_NAME  "face_bg.jpg"

typedef enum en_face_type
{
    EN_OLD_FACE_TYPE,  // 旧人脸
    EN_NEW_FACE_TYPE,  // 新人脸
}EN_FACE_TYPE;

typedef enum en_face_mode
{
    EN_FACE_BLACK_MODE,  // 黑名单布控
    EN_FACE_WHITE_MODE,  // 白名单布控
}EN_FACE_MODE;

// 人脸布控初始化
int face_init();

int iot_face_snap_event(void);

// 人脸识别上传图片
int face_Discern_upload_pic(EN_FACE_TYPE faceType, EN_FACE_MODE faceMode);
// 人脸抓拍上传(ZIP方式)
int face_snap_upload_zip(EN_FACE_TYPE faceType);
#endif