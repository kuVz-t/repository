#ifndef __INPUT_HIGH_PARABOLIC_H__
#define __INPUT_HIGH_PARABOLIC_H__

int iot_high_parabolic_register(void);
int iot_high_parabolic_event(void);

#endif