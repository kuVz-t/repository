#ifndef __INPUT_FALL_DOWN_H__
#define __INPUT_FALL_DOWN_H__

int iot_fall_down_register(void);

#endif