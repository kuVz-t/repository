#ifndef __IOT_H__
#define __IOT_H__
#ifdef __cplusplus
extern "C" {
#endif
typedef struct stru_iot_msg
{
    unsigned int uiIoTType;
    unsigned int uiEvent;
}ST_IOT_MSG;

int iot_init();
int iot_start();
int iot_event_input(unsigned int uiIoTType, unsigned int uiEvent);
#ifdef __cplusplus
}
#endif
#endif
