#ifndef __INPUT_BATTERY_BIKE_H__
#define __INPUT_BATTERY_BIKE_H__

int iot_battery_bike_register(void);
int iot_battery_bike_event(void);

#endif