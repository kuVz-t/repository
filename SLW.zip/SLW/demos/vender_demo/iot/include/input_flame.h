#ifndef __INPUT_FLAME_H__
#define __INPUT_FLAME_H__

int iot_flame_register(void);
int iot_flame_event(void);

#endif