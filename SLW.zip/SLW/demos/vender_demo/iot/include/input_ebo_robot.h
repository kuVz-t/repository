#ifndef __INPUT_EBO_ROBOT_H__
#define __INPUT_EBO_ROBOT_H__

int iot_ebo_robot_register(void);
int iot_ebo_robot_event(unsigned int uiEvent);

#endif