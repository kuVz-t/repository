#ifndef __INPUT_MOTION_H__
#define __INPUT_MOTION_H__

#include "public.h"

typedef struct stru_aiiot_event_face
{
    ST_IOT_EVENT   stEvent;
    int            iDiscernFlag;
}ST_IOT_EVENT_FACE;

typedef struct stru_aiiot_event_Fence
{
    ST_IOT_EVENT   stEvent;
    int            iStayTime;
    int            iCapture;
    int            iVideo;
}ST_IOT_EVENT_FENCE;

typedef struct stru_aiiot_mng
{
    ST_IOT_EVENT       stMotion;
    ST_IOT_EVENT       stHuman;
    ST_IOT_EVENT       stCarNum;
    ST_IOT_EVENT_FACE  stFace;
    ST_IOT_EVENT_FENCE stFence;

}ST_MOTION_MNG;

ST_MOTION_MNG *aiiot_get_motion_mng();

int iot_motion_register(void);
int iot_motion_event(unsigned int uiEvent);
#endif
