#ifndef __INPUT_PRIVACY_MASK_H__
#define __INPUT_PRIVACY_MASK_H__

int iot_privacy_mask_register(void);

#endif