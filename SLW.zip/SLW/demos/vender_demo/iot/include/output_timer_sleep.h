#ifndef __OUTPUT_TIMER_SLEEP_H__
#define __OUTPUT_TIMER_SLEEP_H__

int iot_timer_sleep_register(void);

#endif