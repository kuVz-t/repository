#ifndef __PUBLIC_H__
#define __PUBLIC_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h> 

#include "cJSON.h"
#include "devlog.h"
#include "zj_type.h"

typedef struct stru_aiiot_event
{
    int iInterval;
    int iSensitive;
    int iStatus;
    int iTrace;
}ST_IOT_EVENT;

typedef struct stru_aiiot_event_newai
{
    ST_IOT_EVENT stEvent;
    int          iCapture;
    int          iVideo;
}ST_IOT_EVENT_NEWAI;

typedef struct _HTA_RECT_P_
{
    unsigned int    x;         // 坐标x
    unsigned int    y;         // 坐标y
    unsigned int    w;         // 宽
    unsigned int    h;         // 高
}HTA_RECT_P;

typedef struct _HTA_TARGET_
{
    unsigned int     ID;          // ID，同一个目标抛物值相同
    unsigned char    type;        // 目标类型
    unsigned char    alarm_flg;   // 目标的警报级别
    unsigned char    reserved[6]; // 保留字段
    HTA_RECT_P       rect;        // 目标区域 
}HTA_TARGET;
typedef struct stru_MOS_SYS_TIME
{
    unsigned short usYear;
    unsigned short usMonth;
    unsigned short usDay;
    unsigned short usWeekDay;
    unsigned short usHour;
    unsigned short usMinute;
    unsigned short usSecond;
    unsigned short usIsdst;
}ST_MOS_SYS_TIME;

int getFileExitst(const char *fileName);
int readFileTemplate(const char *file_name , char  *buffer, int size);
unsigned int getCurrentDayMsec();
int GetIntegerValue(cJSON *hObject, int *piOut);
int GetStringValue(cJSON *hObject, unsigned char **ppaucOut);

int get_file_data(char *pdata, unsigned char *fileName);

int aiiot_free_before_startup_cache(EN_ZJ_FREE_BEFORE_STARTUP_CACHE_TYPE iFreeStartUpCacheType);
int aiiot_free_upload_aialarm_pv_cache(unsigned char *ucPicPath, unsigned char *ucVideoPath);

int get_alarm_upload_info(unsigned int uiIoTType, ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf);
int get_mos_time(ST_MOS_SYS_TIME *mos_time);
#endif
