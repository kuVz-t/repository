#ifndef __INPUT_HELMET_H__
#define __INPUT_HELMET_H__

int iot_helmet_register(void);
int iot_helmet_event(void);

#endif