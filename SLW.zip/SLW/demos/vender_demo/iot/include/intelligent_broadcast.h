#ifndef __INTELLIGENT_BROADCAST_H__
#define __INTELLIGENT_BROADCAST_H__

int iot_intelligent_broadcast_register(void);
int aiiot_buzzer_getsoundfiles( unsigned int *piTotalSize, unsigned int *piFreeSize, ST_ZJ_SOUNDFILE_INFO **pstHeadNode, EN_ZJ_RING_TYPE enSoundType);

#endif