#ifndef __INPUT_NEW_FACE_H__
#define __INPUT_NEW_FACE_H__

int iot_new_face_register(void);
int iot_new_face_event(void);
#endif