#ifndef __CRY_H__
#define __CRY_H__

int iot_cry_register(void);
int iot_cry_event(void);
#endif