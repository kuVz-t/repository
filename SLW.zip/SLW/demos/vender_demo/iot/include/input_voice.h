#ifndef __INPUT_VOICE_H__
#define __INPUT_VOICE_H__

int iot_voice_register(void);

#endif