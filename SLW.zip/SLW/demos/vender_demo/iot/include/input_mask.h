#ifndef __INPUT_MASK_H__
#define __INPUT_MASK_H__

int iot_mask_register(void);
int iot_mask_event(void);

#endif