#ifndef __OUTPUT_LAMP_H__
#define __OUTPUT_LAMP_H__

int iot_lamp_register(void);

#endif