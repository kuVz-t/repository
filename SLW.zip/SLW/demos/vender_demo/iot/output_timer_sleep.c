#include "zj_type.h"
#include "zj_cameraiot.h"
#include "zj_camera.h"
#include "public.h"
#include "system.h"

/**
 * 向AIiOT 设备输出信号回调接口，通过该接口，将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 */
static int aiiot_camera_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来,需要对接厂商解析并设置
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue ==NULL ? (unsigned char*)"null":pSignalValue);


    if((pSignalValue == NULL)|| (strlen((char*)pSignalValue) <= 0))
    {
        __ERROR_PRINTF("device aiiot camera output failed\n");
        return -1;
    }

    int iDeviceIAwakeFlag = 0;
    cJSON *cSignalValue = NULL;
    cSignalValue = cJSON_Parse((char*)pSignalValue);
    if(cSignalValue == NULL)
    {
        __ERROR_PRINTF("device aiiot camera output failed, json prase err\n");
        return -1;
    }

    // 设备开关状态,0.关闭； 1.打开
    if(GetIntegerValue(cJSON_GetObjectItem(cSignalValue,"CtrlType"), &iDeviceIAwakeFlag)==0)
    {
        // 厂家添加打印就好，休眠SDK内部已处理控制
        if (iDeviceIAwakeFlag == 0)
        {
            __INFO_PRINTF(" Device Go To Sleep: \n");
        }
        else if (iDeviceIAwakeFlag == 1)
        {
            __INFO_PRINTF(" Device Go To Awake: \n");
        }
    }

    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",   pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n", pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",   pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",   pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",  pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",   pstTriggerInf->pstHandler);
    }

    return 0;
}

// 定时休眠相关IOT注册
int iot_timer_sleep_register(void)
{
    // 定时休眠能力值
    ZJ_SetTimingAwakeAbility(1);
    /**
     * 应用于设备定时休眠
     * 摄像机注册示例，注意：注册摄像机前需要 
    */
    // 设备开关状态，0.关闭； 1.打开
    // char *pcCameraProp = "{\"CtrlType\":\"0\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_CAMERA, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        aiiot_camera_output, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot camera register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_CAMERA, EN_ZJ_DEFAULT_IOTID);
        // ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_CAMERA, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcCameraProp);
    }

    return 0;
}