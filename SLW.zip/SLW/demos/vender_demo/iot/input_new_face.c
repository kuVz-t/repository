#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "public.h"
#include "input_face.h"
#include "ga_1400.h"

typedef struct stru_aiiot_event_faceDiscern
{
    ST_IOT_EVENT stEvent;
    int          iModel;
}ST_IOT_EVENT_FACEDISCERN;

static ST_IOT_EVENT               g_stNewFaceCapture = {0};
static ST_IOT_EVENT_FACEDISCERN   g_stNewFaceDiscern = {0};

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_faceCapture_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
int aiiot_faceCapture_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 *
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_faceCapture_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_FACE_CAPTURE
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {"Sensitive":"20","Status":"0","Trace":"0","Interval":"0"}
     * Sensitive    灵敏度 低25 中50 高75
     * Status       开启状态
     * Trace        是否开启自动追踪
     * Interval     时间间隔
     */

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    int iInterval   = 0;
    int iSensitive  = 0;
    int iStatus     = 0;
    int iTrace      = 0;
    cJSON *cProp    = NULL;

    if ((NULL == pstProp) || (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }

    cProp = cJSON_Parse((char*)pstProp);
    if (cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Sensitive"), &iSensitive) == 0)
    {
        g_stNewFaceCapture.iSensitive = iSensitive;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Status"), &iStatus) == 0)
    {
        // 抓拍开关 0:关闭 1:开启
        g_stNewFaceCapture.iStatus = iStatus;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Trace"), &iTrace) == 0)
    {
        // 如果是云台机，开启人脸追踪
        g_stNewFaceCapture.iTrace = iTrace;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Interval"), &iInterval) == 0)
    {
        g_stNewFaceCapture.iInterval = iInterval;
    }

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] face capture aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("                                                         Sensitive: [%d]\n", g_stNewFaceCapture.iSensitive);
    __INFO_PRINTF("                                                            Status: [%d]\n", g_stNewFaceCapture.iStatus);
    __INFO_PRINTF("                                                             Trace: [%d]\n", g_stNewFaceCapture.iTrace);
    __INFO_PRINTF("                                                          Interval: [%d]\n", g_stNewFaceCapture.iInterval);

    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }

    return 0;
}

/**********************新人脸识别(布控)告警相关注册函数*******************************/
/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_faceDiscern_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
int aiiot_faceDiscern_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 *
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_faceDiscern_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_FACE_DISCERN
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {"Sensitive":"20","Status":"0","Model":"0","Trace":"0","Interval":"30"}
     * Sensitive    灵敏度 低25 中50 高75
     * Status       开启状态
     * Model        识别(布控)模式 0:黑名单 1:白名单 2:黑白名单
     * Trace        是否开启自动追踪
     * Interval     时间间隔
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    int iInterval   = 0;
    int iSensitive  = 0;
    int iStatus     = 0;
    int iModel      = 0;
    int iTrace      = 0;
    cJSON *cProp    = NULL;

    if ((NULL == pstProp) || (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }

    cProp = cJSON_Parse((char*)pstProp);
    if (cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Sensitive"), &iSensitive) == 0)
    {
        g_stNewFaceDiscern.stEvent.iSensitive = iSensitive;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Status"), &iStatus) == 0)
    {
        // 识别开关 0:关闭 1:开启
        g_stNewFaceDiscern.stEvent.iStatus = iStatus;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Model"), &iModel) == 0)
    {
        // 识别(布控)模式 0:黑名单 1:白名单 2:黑白名单
        g_stNewFaceDiscern.iModel = iModel;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Trace"), &iTrace) == 0)
    {
        // 如果是云台机，开启人脸追踪
        g_stNewFaceDiscern.stEvent.iTrace = iTrace;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Interval"), &iInterval) == 0)
    {
        g_stNewFaceDiscern.stEvent.iInterval = iInterval;
    }

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] face discern aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("                                                         Sensitive: [%d]\n", g_stNewFaceDiscern.stEvent.iSensitive);
    __INFO_PRINTF("                                                            Status: [%d]\n", g_stNewFaceDiscern.stEvent.iStatus);
    __INFO_PRINTF("                                                             Model: [%d]\n", g_stNewFaceDiscern.iModel);
    __INFO_PRINTF("                                                             Trace: [%d]\n", g_stNewFaceDiscern.stEvent.iTrace);
    __INFO_PRINTF("                                                          Interval: [%d]\n", g_stNewFaceDiscern.stEvent.iInterval);

    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }

    return 0;
}

// 新人脸抓拍IOT注册
static int iot_face_capture_register(void)
{
    /**
     * 新人脸抓拍注册示例
     * 注意:1. 默认属性Status和IOT 1000默认属性Face字段有冲突，请删除IOT 1000默认属性Face字段
     *      2. 当对接旧人脸时，该IOT不能注册
    */

    // 设置人脸抓拍能力值 0.不支持；1.支持
    ZJ_SetDevAiCommonAbility("NewFaceCaptureAbility", 1);

    char *pcFaceCaptureProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Trace\":\"0\",\"Interval\":\"30\"}";

    // 添加人脸抓拍告警IoT设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_FACE_CAPTURE,
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_faceCapture_start,
                        aiiot_faceCapture_stop,
                        NULL,
                        NULL,
                        aiiot_faceCapture_setprop,
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot face capture register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_FACE_CAPTURE, EN_ZJ_DEFAULT_IOTID);

        // 设置人脸抓拍默认属性
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_FACE_CAPTURE, EN_ZJ_DEFAULT_IOTID, (unsigned char *)pcFaceCaptureProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_FaceCapture = {0};
        stIoTPolicyInfo_FaceCapture.uiInIoTType    = EN_ZJ_AIIOT_TYPE_FACE_CAPTURE;
        stIoTPolicyInfo_FaceCapture.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_FaceCapture.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_FaceCapture.uiOpenFlag     = 1;
        stIoTPolicyInfo_FaceCapture.uiSpanFlag     = 0;
        stIoTPolicyInfo_FaceCapture.uiStartTime    = 0;
        stIoTPolicyInfo_FaceCapture.uiEndTime      = 86400;
        stIoTPolicyInfo_FaceCapture.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char *)(stIoTPolicyInfo_FaceCapture.aucPolicyName), IOT_POLICYNAME_FACECAPTURE, sizeof(stIoTPolicyInfo_FaceCapture.aucPolicyName));

        // 添加人脸抓拍告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_FaceCapture);
    }

    return 0;
}

// 新人脸识别(布控)IOT注册
static int iot_face_discern_register(void)
{
    /**
     * 新人脸识别(布控)注册示例
     * 注意:1. 默认属性Status和IOT 1000默认属性Face字段有冲突，请删除IOT 1000默认属性Face字段
     *      2. 当对接旧人脸时，该IOT不能注册
    */

    // 设置人脸识别能力值 0.不支持；1.只支持黑名单；2.只支持白名单；3.支持黑/白名单(不支持同时打开)；4.支持黑/白名单(支持同时打开)
    ZJ_SetDevAiCommonAbility("NewFaceDiscernAbility", 3);

    char *pcFaceDiscernProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Model\":\"0\",\"Trace\":\"0\",\"Interval\":\"30\"}";

    // 添加人脸识别告警IoT设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_FACE_DISCERN,
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_faceDiscern_start,
                        aiiot_faceDiscern_stop,
                        NULL,
                        NULL,
                        aiiot_faceDiscern_setprop,
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot face discern register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_FACE_DISCERN, EN_ZJ_DEFAULT_IOTID);

        // 设置人脸识别默认属性
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_FACE_DISCERN, EN_ZJ_DEFAULT_IOTID, (unsigned char *)pcFaceDiscernProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_FaceDiscern = {0};
        stIoTPolicyInfo_FaceDiscern.uiInIoTType    = EN_ZJ_AIIOT_TYPE_FACE_DISCERN;
        stIoTPolicyInfo_FaceDiscern.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_FaceDiscern.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_FaceDiscern.uiOpenFlag     = 1;
        stIoTPolicyInfo_FaceDiscern.uiSpanFlag     = 0;
        stIoTPolicyInfo_FaceDiscern.uiStartTime    = 0;
        stIoTPolicyInfo_FaceDiscern.uiEndTime      = 86400;
        stIoTPolicyInfo_FaceDiscern.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char *)(stIoTPolicyInfo_FaceDiscern.aucPolicyName), IOT_POLICYNAME_FACEDISCERN, sizeof(stIoTPolicyInfo_FaceDiscern.aucPolicyName));

        // 添加人脸识别告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_FaceDiscern);
    }

    return 0;
}

// 人脸识别(布控)事件上报
int iot_face_discern_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime  = 0;
    EN_FACE_MODE faceMode = EN_FACE_BLACK_MODE;

    if (1 == g_stNewFaceDiscern.stEvent.iStatus)
    {
        gettimeofday(&cur_tv, 0);

        if ((cur_tv.tv_sec - lastTime) >= g_stNewFaceDiscern.stEvent.iInterval)
        {
            lastTime = cur_tv.tv_sec;

            if (EN_FACE_BLACK_MODE == g_stNewFaceDiscern.iModel)
            {
                faceMode = EN_FACE_BLACK_MODE;
            }
            else
            {
                faceMode = EN_FACE_WHITE_MODE;
            }

            // 人脸布控示例
            ret = face_Discern_upload_pic(EN_NEW_FACE_TYPE, faceMode);
        }
        else
        {
            // __INFO_PRINTF("input iInterval < %d\n", g_stNewFaceDiscern.stEvent.iInterval);
        }
    }

    return ret;
}

// 人脸抓拍事件上报
int iot_face_capture_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime = 0;

    if (1 == g_stNewFaceCapture.iStatus)
    {
        gettimeofday(&cur_tv, 0);

        if ((cur_tv.tv_sec - lastTime) >= g_stNewFaceCapture.iInterval)
        {
            lastTime = cur_tv.tv_sec;
            
            /* 1400方式上传 */
            ret = ga1400_upload_face_snap(EN_NEW_FACE_TYPE);

            // 人脸抓拍上传(ZIP方式)
            ret |= face_snap_upload_zip(EN_NEW_FACE_TYPE);
        }
        else
        {
            // __INFO_PRINTF("input iInterval < %d\n", g_stNewFaceCapture.iInterval);
        }
    }

    return ret;
}

// 新人脸事件上报
int iot_new_face_event(void)
{
    int ret = -1;

    ret = iot_face_capture_event();

    ret |= iot_face_discern_event();

    return ret;
}

// 新人脸IOT注册
int iot_new_face_register(void)
{
    iot_face_capture_register();

    iot_face_discern_register();

    return 0;
}