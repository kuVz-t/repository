#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>

#include "iot.h"
#include "devlog.h"

#define FIFOMODE (0777)
#define FIFO_IOT_SERVER "/tmp/iot_fifo_server"
#define FIFO_IOT_CLIENT "/tmp/iot_fifo_client"

typedef struct stru_fifo_mng
{
    int iRun;
    pthread_t hThread;
}ST_FIFO_MNG;

static ST_FIFO_MNG g_StFifoMng = {0};

// 接收IOT事件
int fifo_recive_event(void)
{
    int len             = 0;
    int ret             = 0;
    int fd_server       = 0;
    int fd_client       = 0;
    ST_IOT_MSG stIotMsg = {0};

    if ((mkfifo(FIFO_IOT_SERVER, FIFOMODE) < 0) && (errno != EEXIST))
    {
        __INFO_PRINTF("mkfifo %s failed!\n", FIFO_IOT_SERVER);
        return -1;
    }

    if ((mkfifo(FIFO_IOT_CLIENT, FIFOMODE) < 0) && (errno != EEXIST))
    {
        __INFO_PRINTF("mkfifo %s failed!\n", FIFO_IOT_CLIENT);
        unlink(FIFO_IOT_SERVER);
        return -1;
    }

    if ((fd_server = open(FIFO_IOT_SERVER, O_RDWR)) < 0) 
    {
        __INFO_PRINTF("open %s failed!\n", FIFO_IOT_SERVER);
        unlink(FIFO_IOT_SERVER); 
        unlink(FIFO_IOT_CLIENT);
        return -1;
    } 

    if ((fd_client = open(FIFO_IOT_CLIENT, O_RDWR)) < 0)
    {
        __INFO_PRINTF("open %s failed!\n", FIFO_IOT_CLIENT);
        unlink(FIFO_IOT_SERVER); 
        unlink(FIFO_IOT_CLIENT);
        close(fd_server); 
        return -1;
    }

 
    while (g_StFifoMng.iRun)
    {
        len = read(fd_server, &stIotMsg, sizeof(ST_IOT_MSG)); 
        if (len > 0)
        {
            ret = iot_event_input(stIotMsg.uiIoTType, stIotMsg.uiEvent);

            len = write(fd_client, &ret, sizeof(ret));
            if (len < 0)
            {
                __INFO_PRINTF("write failed!\n");
            }
        } 

        usleep(10000);
    } 
   
    unlink(FIFO_IOT_SERVER); 
    unlink(FIFO_IOT_CLIENT);

    close(fd_server); 
    close(fd_client);

    return 0;
}

void* fifo_proc(void* argc)
{
    fifo_recive_event();

    return NULL;
}

// 启动fifo接收IOT事件输入
int fifo_start(void)
{
    g_StFifoMng.iRun = 1;

    if (pthread_create(&g_StFifoMng.hThread, NULL, fifo_proc, NULL) != 0)
    {
        __ERROR_PRINTF("create fifo_proc failed\n");
        return -1;
    }
    else
    {
        __INFO_PRINTF("create fifo_proc ok\n");
    }

    return 0;
}
