#include "public.h"
#include "type.h"

#define PIC_MASK_NAME     "mask.jpg"

#include "time.h"
unsigned int getCurrentDayMsec()
{
    struct timeval unix_time = {0,0};
    gettimeofday(&unix_time, NULL);
    struct tm *date = localtime(&unix_time.tv_sec);
    unsigned int ms = (date->tm_hour * 3600 + date->tm_min * 60 + date->tm_sec) * 1000;
    ms += (unix_time.tv_usec / 1000);
    return ms;
}


int getFileExitst(const char *fileName)
{
   return (access(fileName, F_OK) == 0)?0:-1;
}

int readFileTemplate(const char *file_name , char  *buffer, int size)
{
    int ret = 0;
    int fd = open(file_name, O_RDONLY,
                  S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);

    if(fd > 0)
    {
        ret = read(fd, buffer, size);
        close(fd);
    }
    return ret;
}


int GetIntegerValue(cJSON *hObject, int *piOut)
{
    if (hObject == NULL)
    {
        *piOut = 0;
        return -1;
    }
    if (piOut == NULL)
    {
        return -1;
    }
    if (cJSON_Number == hObject->type)
    {
        *piOut = hObject->valueint;
    }
    else if ((cJSON_String == hObject->type) && (hObject->valuestring))
    {
        *piOut = atoi(hObject->valuestring);
        return 0;
    }
    else
    {
        *piOut = 0;
        return -1;
    }
    return 0;
}

int GetStringValue(cJSON *hObject, unsigned char **ppaucOut)
{
    cJSON *pNode = hObject;

    if (ppaucOut)
    {
        *ppaucOut = (unsigned char*)"";
    }
    else
    {
        return -1;
    }

    if ((!hObject) || (cJSON_String != pNode->type))
    {
        return -1;
    }

    *ppaucOut = (unsigned char *)pNode->valuestring;

    return 0;
}

// 释放启动前可能存在的缓存
int aiiot_free_before_startup_cache(EN_ZJ_FREE_BEFORE_STARTUP_CACHE_TYPE iFreeStartUpCacheType)
{
    // TODO 释放启动前可能存在的缓存

    return 0;
}

// 释放上报IOT AI图片和视频的缓存
int aiiot_free_upload_aialarm_pv_cache(unsigned char *ucPicPath, unsigned char *ucVideoPath)
{
    // TODO
    // 文件路径判断, 并删除相关文件和释放相关内存
    char cmd[512] = {0};

    if (ucPicPath && strlen((char *)ucPicPath))
    {
        sprintf(cmd, "rm %s", ucPicPath);
        system(cmd);
        __INFO_PRINTF("free PicPath[%s]\n", ucPicPath);
    }

    if (ucVideoPath && strlen((char *)ucVideoPath))
    {
        sprintf(cmd, "rm %s", ucVideoPath);
        system(cmd);
        __INFO_PRINTF("free VideoPath[%s]\n", ucVideoPath);
    }

    return 0;
}

// 获取文件数据
int get_file_data(char *pdata, unsigned char *fileName)
{
    FILE *pfile = NULL;
    struct stat buf;

    pfile = fopen((char *)fileName, "r+");
    if (NULL == pfile)
    {
        __ERROR_PRINTF("fopen: %s failed", fileName);
        return -1;
    }

    if (stat((char *)fileName, &buf) < 0)
    {
        fclose(pfile);
        __ERROR_PRINTF("stat: %s failed", fileName);
        return -1;
    }

    if (fread(pdata, 1, buf.st_size, pfile) != buf.st_size)
    {
        fclose(pfile);
        __ERROR_PRINTF("fread: %s failed", fileName);
        return -1;    
    }

    fclose(pfile);

    return 0;
}

// 获取报警图片的路径
static int get_alarm_pic(unsigned int uiIotType, char *picFile)
{
    if (NULL == picFile)
    {
        return -1;
    }

    switch (uiIotType)
    {
        case EN_ZJ_AIIOT_TYPE_MASK:
            sprintf(picFile, "%s/%s", DEVICE_PIC_PATH, PIC_MASK_NAME);
            break;
        default:
            strcpy(picFile, DEVICE_SNAP_FILE_JPG1);
            break;
    }

    return 0;
}

// 模拟AI告警事件上传图片信息
int get_alarm_upload_info(unsigned int uiIoTType, ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf)
{
    char cmd[256]      = {0};
    char *pstr         = NULL;  
    char acDevPath[64] = {0};
    char acDevFile[64] = {0};
  
    if (NULL == pstAIAlarmUploadInf)
    {
         __ERROR_PRINTF("param is null!");
        return -1;
    }

    memset(pstAIAlarmUploadInf, 0, sizeof(ST_ZJ_AI_AlARM_UPLOAD_INF));

    get_alarm_pic(uiIoTType, acDevFile);

    // 判断源图片是否存在
    if (0 != access(acDevFile, F_OK))
    {
        __ERROR_PRINTF("file does not exist! %s\n", acDevFile);
        return -1;
    }

    // 解析图片储存的路径
    pstr = strrchr(acDevFile, '/');
    memcpy(acDevPath, acDevFile, pstr - acDevFile);

    pstAIAlarmUploadInf->lluTimeStamp = time(0);

    // 生成新的模拟图片
    // memcpy(pstAIAlarmUploadInf->ucPicPath, "/opt/21cn/testfile/pic/longmao.jpg", 35);
    // memcpy(pstAIAlarmUploadInf->ucVideoPath, "/opt/21cn/testfile/video/test.ps", 34);
    sprintf((char *)pstAIAlarmUploadInf->ucPicPath,"%s/iot_%u_%llu.jpg", acDevPath, uiIoTType, pstAIAlarmUploadInf->lluTimeStamp);
    sprintf(cmd, "cp %s %s", acDevFile, pstAIAlarmUploadInf->ucPicPath);
    system(cmd);

    __INFO_PRINTF("create new jpg[%s]\n", pstAIAlarmUploadInf->ucPicPath);

    return 0;
}

int iot_videoUpload(char *videoPath,char *videoCfgPath, char *audioFilePath)
{
    FILE *faudio  = NULL;
    FILE *hVideo  = NULL;
    FILE *hVideoCfg  = NULL;
    char pVideobuf[100000] = {0}; 
    char *pVideobufCfg = NULL;
    hVideo  = fopen(videoPath,"rb"); 
    if(NULL==hVideo)
    {
        __ERROR_PRINTF("device video fopen video path failed!\n");
        return -1;
    }
    hVideoCfg  = fopen(videoCfgPath,"rb"); 
    if(NULL==hVideoCfg)
    {
        __ERROR_PRINTF("device video fopen video cfg path failed!\n");
        return -1;
    }

    const int audioSize = 320;
    char *pbufAudio = (char *)malloc(audioSize);
    faudio  = fopen(audioFilePath,"rb"); 
    if(NULL==faudio)
    {
        __ERROR_PRINTF("device audio open file failed!\n");
        return -1;
    }
    pbufAudio = (char *)malloc(audioSize);
    if(NULL==pbufAudio)
    {
        __ERROR_PRINTF("device audio malloc failed!\n");
        return -1;
    }
    
    pVideobufCfg = (char *)malloc(40 + 2);
    if(NULL==pVideobufCfg)
    {
        __ERROR_PRINTF("device video buf cfg malloc failed!\n");
        return -1;
    }
    int muxerId = PsMuxer_CreateHandle((unsigned char*)"/opt/21cn/testfile/video/test.ps", EN_PS_CONTENT_TYPE_HIGHPARABOLIC);
    unsigned long long int ulltimestamp;
    while(fread(pVideobufCfg, 1, 39, hVideoCfg)!= 0 && fread(pbufAudio, 1, audioSize, faudio)!= 0)
    {
        int length = 0;
        int utimestamp = 0;
        
        int frametype = 0;
        unsigned char  bIsIFrame = 0;

        sscanf(pVideobufCfg, "LEN:%05dFRAMETYPE:%02dTIMESTAMP:%8d", &length,&frametype, &utimestamp);

        if(0x0e == frametype)
            bIsIFrame = 1;
        else
            bIsIFrame = 0;
        if(0 == fread(pVideobuf, 1, length, hVideo))
        {
            free(pVideobufCfg);
            fclose(hVideo);
            fclose(hVideoCfg);
            pVideobufCfg = NULL;
            return -1;
        }
        ulltimestamp = getCurrentDayMsec();//util_GetTickCount();
        HTA_TARGET st_hta[1] = {0};
        st_hta[0].ID = 123;
        st_hta[0].type = EN_PS_CONTENT_TYPE_HIGHPARABOLIC;
        st_hta[0].alarm_flg = 2;
        // memcpy(st_hta[0].reserved, 0, 6);
        st_hta[0].rect.x = 1;
        st_hta[0].rect.y = 2;
        st_hta[0].rect.w = 3;
        st_hta[0].rect.h = 4;

        // 写一帧PS Appand方式写入
        PsMuxer_WriteVideo(muxerId, pVideobuf, length, ulltimestamp, bIsIFrame, (unsigned char *)((void*)st_hta));
        PsMuxer_WriteAudio(muxerId, pbufAudio, audioSize, (unsigned int)ulltimestamp);

        usleep(40*1000);
        memset(pVideobuf, 0, 100000);
        memset(pVideobufCfg, 0, 40 + 2);
    }

    free(pVideobufCfg);
    fclose(hVideo);
    fclose(hVideoCfg);
    fclose(faudio);
    free(pbufAudio);
    pVideobufCfg = NULL;
    PsMuxer_DestoryHandle(muxerId);
    return 0;
}

int get_mos_time(ST_MOS_SYS_TIME *mos_time)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    int64_t seconds = tv.tv_sec;
    struct tm tm_time;
    //gmtime_r(&seconds, &tm_time);

    localtime_r(&seconds, &tm_time);
    mos_time->usDay = tm_time.tm_mday;
    mos_time->usYear = tm_time.tm_year;
    mos_time->usMonth = tm_time.tm_mon;
    mos_time->usWeekDay = tm_time.tm_wday;
    mos_time->usHour = tm_time.tm_hour;
    mos_time->usMinute = tm_time.tm_min;
    mos_time->usSecond = tm_time.tm_sec;
    mos_time->usIsdst = tm_time.tm_isdst;

    return 0;
}


