#include "zj_type.h"
#include "zj_cameraiot.h"
#include "public.h"

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
static int aiiot_fall_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
static int aiiot_fall_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_fall_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_FALL中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     *          {"Sensitive":50, "Interval":30}
     * Interval     时间间隔
     * Sensitive    灵敏度 0-100
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

// 跌倒IOT注册
int iot_fall_down_register(void)
{
    // 跌倒检测
    char *pcFallProp = "{\"Sensitive\":\"50\",\"Interval\":\"0\"}";
    if (ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_FALLDOWN, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_fall_start,
                        aiiot_fall_stop, 
                        NULL, 
                        NULL, 
                        aiiot_fall_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot Fall register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_FALLDOWN, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_FALLDOWN, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcFallProp);
    }

    return 0;
}