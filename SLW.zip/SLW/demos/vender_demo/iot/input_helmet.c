#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "public.h"

static ST_IOT_EVENT_NEWAI g_stHelmetDetect = {0};

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
static int aiiot_Helmet_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
static int aiiot_Helmet_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_Helmet_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);

    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;
    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    // 实现相关属性解析
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if(cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_stHelmetDetect.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] FlameDetect aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                              Status: [%d]\n", g_stHelmetDetect.stEvent.iStatus);      
    }
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }
    return 0;
}

// 头盔检测事件上报
int iot_helmet_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};

    if (1 == g_stHelmetDetect.stEvent.iStatus)
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_HELMET, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_HELMET, 0, 0, &stAIAlarmUploadInf);
        }
    }
    else
    {
         __INFO_PRINTF("[iot %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_HELMET);
    }        

    return ret;
}

//头盔检测IOT注册
int iot_helmet_register(void)
{
    unsigned char aucLampBuff[256]    = {0};
    unsigned char aucBuzzerBuff[256]  = {0};

    ZJ_SetDevAiCommonAbility("HelmetAlarmAbility", 1);
    // 添加头盔检测告警IoT设备
    char *pcHelmetDefaultProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Interval\":\"30\",\"Capture\":\"0\",\"Regions\":[{\"RegionId\":\"1\",\"RegionPoints\":[{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"}]}]}";
    /*支持追踪*/
    // char *pcHelmetDefaultProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Trace\":\"0\",\"Interval\":\"30\",\"Capture\":\"0\"}"; // 支持追踪设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_HELMET, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_Helmet_start,
                        aiiot_Helmet_stop, 
                        NULL, 
                        NULL, 
                        aiiot_Helmet_setprop, 
                        NULL) == 0)
    {
        // 设置头盔检测默认属性
        __INFO_PRINTF("device iot Helmet register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcHelmetDefaultProp);
    
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_Helmet = {0};
        stIoTPolicyInfo_Helmet.uiInIoTType     = EN_ZJ_AIIOT_TYPE_HELMET;
        stIoTPolicyInfo_Helmet.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_Helmet.uiInIoTEventId  = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_Helmet.uiOpenFlag      = 1;
        stIoTPolicyInfo_Helmet.uiSpanFlag      = 0;
        stIoTPolicyInfo_Helmet.uiStartTime     = 0;
        stIoTPolicyInfo_Helmet.uiEndTime       = 86400;
        stIoTPolicyInfo_Helmet.uiWeekFlag      = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_Helmet.aucPolicyName), IOT_POLICYNAME_HELMET, sizeof(stIoTPolicyInfo_Helmet.aucPolicyName));
        // 添加头盔检测告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_Helmet);
        // 添加响应IoT需要根据产品需求添加,联系产品经理确认
        // 头盔检测告警IoT添加响应IoT-扬声器
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"0\",\"ExecuteTime\":[]}", EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 头盔检测告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }

    return 0;
}