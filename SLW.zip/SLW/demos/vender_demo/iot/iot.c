#include "zj_type.h"
#include "zj_cameraiot.h"
#include "public.h"
#include "recv_event.h"
#include "input_face.h"
#include "input_motion.h"
#include "input_car_number.h"
#include "input_mask.h"
#include "input_flame.h"
#include "input_battery_bike.h"
#include "input_high_parabolic.h"
#include "input_voice.h"
#include "input_fall_down.h"
#include "input_human_count.h"
#include "output_lamp.h"
#include "output_buzzer.h"
#include "output_timer_sleep.h"
#include "input_cry.h"
#include "input_new_human.h"
#include "input_doorbell.h"
#include "intelligent_broadcast.h"
#include "input_ebo_robot.h"
#include "input_helmet.h"
#include "input_privacy_mask.h"
#include "input_videoplay.h"

#define USE_NEW_FACE 0

// 定时事件上报处理线程
static void *iot_loop()
{
    while(1)
    {
        #if USE_NEW_FACE
        // 新人脸抓拍/布控
        iot_new_face_event();
        #else
        // 旧人脸抓拍/布控
        iot_face_snap_event();
        #endif

        // 车牌抓拍
        iot_car_snap_event();

        usleep(1000 * 1000);
    }

    return NULL;
}

/**
 * 常用IOT类型注册参考：
 * EN_ZJ_AIIOT_TYPE_MOTION 需要注册：aiiot_start、aiiot_stop、aiiot_setprop
 * EN_ZJ_AIIOT_TYPE_DNSET 需要注册：aiiot_start、aiiot_stop、aiiot_output
 * EN_ZJ_AIIOT_TYPE_INNER_LAMP 需要注册：aiiot_start、aiiot_stop、aiiot_output
 * 
 * EN_ZJ_AIIOT_TYPE_BUZZER 需要注册：aiiot_start、aiiot_stop、aiiot_setprop、aiiot_output
 * 备注：
 *     1. 只用告警类型的iot才会使用到prop，其他iot控制使用output控制
 *     2. prop 和 output json内容参考 "zj_cameraiot.h"
 *     3. 除了Motion和Human的Interval默认值不为0;其他告警的默认Interval都为0
*/
int iot_init()
{
    // 人脸布控初始化
    face_init();

#if USE_NEW_FACE
    // 新人脸
    iot_new_face_register();
#endif

    // 移动侦测
    iot_motion_register();

    // 口罩识别
    iot_mask_register();

    // 烟火检测
    iot_flame_register();

    // 电瓶车识别
    iot_battery_bike_register();

    // 高空抛物
    iot_high_parabolic_register();

    // 声音检测和异响告警
    iot_voice_register();

    // 跌倒检测
    iot_fall_down_register();

    // 客流预警
    iot_human_count_register();

    // 哭声检测
    iot_cry_register();

    // 定时休眠
    iot_timer_sleep_register();

    // 新人形, 用于老人吃药
    iot_new_human_register();

    // 头盔检测
    iot_helmet_register();

    // 隐私遮罩IOT注册
    iot_privacy_mask_register();

    // ebo机器人
    iot_ebo_robot_register();

    // 设置摄像头自定义声音文件(智能播报)能力与相关回调
    iot_intelligent_broadcast_register();

    // 设置 释放上报IOT AI告警事件的视频图片的缓存 的回调接口
    ZJ_SetFreeUploadAIAlarmPVCacheCB(aiiot_free_upload_aialarm_pv_cache);

    // 释放启动前可能存在的缓存(ZJ_IotAIEventPVInPut或ZJ_SetAiPicEventEx 产生的缓存)
    ZJ_SetFreeBeforeStartUpCacheCB(aiiot_free_before_startup_cache);

    //门铃
    // iot_doorbell_register();

    // 红外灯 内置白光灯 内置状态灯
    iot_lamp_register();

    // 扬声器
    iot_buzzer_register();

    // 双向视频通话
    iot_videoplay_register();

    return 0;
}

int iot_start()
{
    pthread_t tidp;

    // 启动fifo接收外部IOT事件输入
    fifo_start();

    // 启动定时上报处理线程
    if (pthread_create(&tidp, NULL, iot_loop, NULL) != 0)
    {
        __ERROR_PRINTF("device iot create iot_loop failed\n");
    }

    return 0;
}

int iot_event_input(unsigned int uiIoTType, unsigned int uiEvent)
{
    int ret = 0;

    __INFO_PRINTF("input uiIoTType = %d, uiEvent = %d\n", uiIoTType, uiEvent);

    switch (uiIoTType)
    {
        case EN_ZJ_AIIOT_TYPE_MOTION: 
            // 移动侦测
            ret = iot_motion_event(uiEvent);
            break;
        case EN_ZJ_AIIOT_TYPE_BATTERYBIKE:
            // 电瓶车识别
            ret = iot_battery_bike_event();
            break;
        case EN_ZJ_AIIOT_TYPE_CRYALARM:
            // 哭声检测
            ret = iot_cry_event();
            break;
        case EN_ZJ_AIIOT_TYPE_FLAMEDETECT:
            // 烟雾检测
            ret = iot_flame_event();
            break;
        case EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC:
            // 高空抛物
            ret = iot_high_parabolic_event();
            break;
        case EN_ZJ_AIIOT_TYPE_MASK:
            // 口罩识别
            ret = iot_mask_event();
            break;
        case EN_ZJ_AIIOT_TYPE_HUMANALARMNEW:
            // 新人形(老人吃药)
            ret = iot_new_human_event();
            break;
        case EN_ZJ_AIIOT_TYPE_STAY:
            // 有人逗留
            ret = iot_stay_event();
            break;
        case EN_ZJ_AIIOT_TYPE_HELMET:
            ret = iot_helmet_event();
            break;
        case EN_ZJ_AIIOT_TYPE_EBO_ROBOT:
            // ebo机器人
            ret = iot_ebo_robot_event(uiEvent);
            break;
        case EN_ZJ_AIIOT_TYPE_FORCEREMOVE:
            // 强拆
            ret = iot_force_remove_event();
            break;
        case EN_ZJ_AIIOT_TYPE_INNER_DOORBELL:
            // 有人按铃
            ret = iot_doorbell_event();
            break;
        case EN_ZJ_AIIOT_TYPE_VIDEOPLAY:
            // 双向视频通话上报
            ret = iot_videoplay_event(uiEvent);
            break;
        default:
            ret = -1;
            break;
    }

    return ret;
}