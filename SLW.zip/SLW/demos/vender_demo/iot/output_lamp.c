#include "zj_type.h"
#include "zj_cameraiot.h"
#include "zj_camera.h"
#include "public.h"

/**********************红外灯相关注册函数*******************************/
/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_dnset_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}


/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
int aiiot_dnset_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 查询AIiOT 设备当前事件或信号量回调接口， 通过该接口返回设备当前的信号量和事件, 
 * 返回输入信号类型和对应的信号Json字串返回下来
 * {"DNFlag":"1"} // 1 白天 2 晚上
 */
int aiiot_dnset_input(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char *aucSignalValue)
{
    /**
     * 查询AIiOT 设备当前事件或信号量
     */
    __INFO_PRINTF("device aiiot input, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    // strcpy(aucSignalValue, "{\"DNFlag\":\"1\"}");
    strcpy((char *)aucSignalValue, "{\"DNFlag\":\"2\"}");
    return 0;
}

/**
 * 向AIiOT 设备输出信号回调接口，通过该接口，将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 */
int aiiot_dnset_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来，需要对接厂商解析并设置
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue ==NULL ? (unsigned char*)"nil":pSignalValue);
    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",    pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n",  pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",    pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",    pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",   pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",    pstTriggerInf->pstHandler);
    }

    return 0;
}

/**********************内置白光灯相关注册函数*******************************/
/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_inner_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}


/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
int aiiot_inner_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}


/**
 * 向AIiOT 设备输出信号回调接口，通过该接口，将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 */
int aiiot_inner_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来，需要对接厂商解析并设置
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue ==NULL ? (unsigned char*)"nil":pSignalValue);

    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",    pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n",  pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",    pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",    pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",   pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",    pstTriggerInf->pstHandler);
    }

    return 0;
}

/**********************内置状态指示灯相关注册函数*******************************/

/**
 * 向AIiOT 设备输出信号回调接口，通过该接口，将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 */
int aiiot_inner_statelamp_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue, ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来，需要对接厂商解析并设置
     * 内置指示灯Signal Value: {"CtrlType":"1","Flicker":""} ，CtrlType=1：开，CtrlType=0：关
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue ==NULL ? (unsigned char*)"nil":pSignalValue);

    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",   pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n", pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",   pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",   pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",  pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",   pstTriggerInf->pstHandler);
    }

    return 0;
}

int iot_IR_lamp_register(void)
{
    /**
     * 红外灯注册示例
     */

    // 红外灯能力集配置:取值 0或1
    ZJ_SetIRLedAbility(1);
    
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_DNSET, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_dnset_start,
                        aiiot_dnset_stop, 
                        aiiot_dnset_input, 
                        aiiot_dnset_output, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot ndnset register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_DNSET, EN_ZJ_DEFAULT_IOTID);
    }

    return 0;
}

int iot_inner_white_lamp_register(void)
{
    /**
     * 白光灯注册示例，注意：注册白光灯前需要
    */
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_INNER_LAMP, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_inner_start,
                        aiiot_inner_stop, 
                        NULL, 
                        aiiot_inner_output, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot inner lamp register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID);
    }

    return 0;
}

int iot_inner_state_lamp_register(void)
{
    /**
     * 内置状态指示灯注册示例，注意：注册内置状态指示灯前需要
    */
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_INNER_STATELAMP, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        aiiot_inner_statelamp_output, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot inner statelamp register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_INNER_STATELAMP, EN_ZJ_DEFAULT_IOTID);
    }

    return 0;
}

// 灯相关IOT注册
int iot_lamp_register(void)
{
    // 红外灯
    iot_IR_lamp_register();

    // 内置白光灯
    iot_inner_white_lamp_register();

    // 内置状态灯
    iot_inner_state_lamp_register();

    return 0;
}