#include "zj_type.h"
#include "zj_cameraiot.h"
#include "public.h"

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_humancount_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
int aiiot_humancount_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_humancount_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_HUMANCOUNT中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     *          {"Interval":30,"Count":30}
     * Interval     时间间隔
     * Count        检测周期内的检测数量
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

// 客流IOT注册
int iot_human_count_register(void)
{
    // 客流预警
    char *pcHumanCountProp = "{\"Interval\":\"0\", \"Count\":\"100\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_HUMANCOUNT, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_humancount_start,
                        aiiot_humancount_stop, 
                        NULL, 
                        NULL, 
                        aiiot_humancount_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot Human Count register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_HUMANCOUNT, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_HUMANCOUNT, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcHumanCountProp);
    }

    return 0;
}