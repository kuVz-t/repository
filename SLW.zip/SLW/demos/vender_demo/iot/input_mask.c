#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "public.h"

static ST_IOT_EVENT_NEWAI g_stMask = {0};

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
static int aiiot_Mask_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
static int aiiot_Mask_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
static int aiiot_Mask_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);

    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;

    if ((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }

    cProp = cJSON_Parse((char*)pstProp);
    if (cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }

    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if (cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_stMask.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] Mask aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                              Status: [%d]\n", g_stMask.stEvent.iStatus);        
    }

    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    } 
    
    return 0;
}

// 口罩识别事件上报
int iot_mask_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};

    if (1 == g_stMask.stEvent.iStatus)
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_MASK, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_MASK, 0, 0, &stAIAlarmUploadInf);

            // 若支持AI告警视频上传
            // sleep(10);
            // __INFO_PRINTF("device iot MASK event start Set VIDEOOOOOOOOO \r\n");
            // ZJ_SetUploadAIAlarmPVFileFinish(pstAIAlarmUploadInf->ucVideoPath, 1);
        }
    }
    else
    {
         __INFO_PRINTF("[iot %d] iStatus is 0!\n", EN_ZJ_AIIOT_TYPE_MASK);
    }        

    return ret;
}

// 口罩IOT注册
int iot_mask_register(void)
{
    unsigned char aucLampBuff[256]    = {0};
    unsigned char aucBuzzerBuff[256]  = {0};

    char *pcMaskProp = "{\"Sensitive\":\"50\",\"Status\":\"0\",\"Interval\":\"0\",\"Trace\":\"0\",\"Capture\":\"0\",\"Video\":\"0\"}";
  
    // AI口罩识别能力    0.不支持；1.支持
    ZJ_SetDevAiMaskDiscernAbility(1);
  
    // 添加口罩识别告警IoT设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_MASK, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_Mask_start,
                        aiiot_Mask_stop, 
                        NULL, 
                        NULL, 
                        aiiot_Mask_setprop, 
                        NULL) == 0)
    {
        // 设置口罩识别默认属性
        __INFO_PRINTF("device iot Mask register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcMaskProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_Mask = {0};
        stIoTPolicyInfo_Mask.uiInIoTType    = EN_ZJ_AIIOT_TYPE_MASK;
        stIoTPolicyInfo_Mask.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_Mask.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_Mask.uiOpenFlag     = 1;
        stIoTPolicyInfo_Mask.uiSpanFlag     = 0;
        stIoTPolicyInfo_Mask.uiStartTime    = 0;
        stIoTPolicyInfo_Mask.uiEndTime      = 86400;
        stIoTPolicyInfo_Mask.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_Mask.aucPolicyName), IOT_POLICYNAME_MASK, sizeof(stIoTPolicyInfo_Mask.aucPolicyName));
        // 添加口罩识别告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_Mask);
        // 添加响应IoT需要根据产品需求添加，联系产品经理确认
        // 口罩识别告警IoT添加响应IoT-扬声器
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"0\",\"ExecuteTime\":[]}", EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 口罩识别告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0, 过滤白光灯联动
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }
    // TEST
    // 口罩识别告警IoT删除属性字段  StartTime
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, (unsigned char*)"StartTime", NULL);
    // 删除 口罩识别告警IoT 联动 响应的IOT白光灯 的 动作属性(字段) EndTime
    // ZJ_DelAlarmPolicyOutputProp(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID,
    //                             EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID,
    //                             (unsigned char*)"EndTime");
    // 口罩识别告警IoT删除响应IoT-白光灯
    // ZJ_DelAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID);
    // 口罩识别告警IoT添加响应IoT-白光灯
    // ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    // 删除口罩识别告警IoT的联动策略类型
    // ZJ_DelIoTDefaultPolicy(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID);

    return 0;
}
