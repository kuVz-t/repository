#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "zj_type.h"
#include "zj_power.h"
#include "zj_system.h"
#include "zj_camera.h"
#include "zj_network.h"
#include "zj_log.h"
#include "zj_time.h"

#include "type.h"
#include "devlog.h"

#include "system.h"

/**
 *设备状态回调接口； 告诉设备当前状态；
 */ 
int system_device_status_cb(EN_ZJ_SERVER_STATUS enDeviceStatus, int iErrCode)
{
    __INFO_PRINTF("device system set device status [%d] ErrCode [%d] \n", enDeviceStatus, iErrCode);
    if(iErrCode < 0)
    {
        __ERROR_PRINTF("device system get status failed , err code [%d]\n", iErrCode);
        return 0;
    }
    switch(enDeviceStatus)
    {
        case EN_ZJ_SERVER_STATUS_INIT:
            __INFO_PRINTF("device system zj server status init ok");
            break;
        case EN_ZJ_SERVER_STATUS_GETADDR:
            __INFO_PRINTF("device system zj server status get addr ok");
            break;
        case EN_ZJ_SERVER_STATUS_CONNECT:
            __INFO_PRINTF("device system zj server status connect ok");
            break;
        case EN_ZJ_SERVER_STATUS_REGIST:
            __INFO_PRINTF("device system zj server status regist ok");
            break;
        case EN_ZJ_SERVER_STATUS_WAITBIND:
            __INFO_PRINTF("device system zj server status waitbind");
            break;
        case EN_ZJ_SERVER_STATUS_PROCESS:
            __INFO_PRINTF("device system zj server status online ok");
            break;
        default:
            __INFO_PRINTF("device system zj server status unknown");
            break;
    }
    return 0;
}

/**
 * 重启摄像机回调接口； 
 * 参数: iRebootType 0-正常重启 1-静默重启  默认0 参考:EN_ZJ_REBOOT_TYPE
 *  * 注意：
 *  重启需要停掉录像，ZJ_SetStoragePath(NULL);设置为NULL时可以停止TF卡录像。
 */ 
int system_reboot_cb(int iRebootType)
{
    ZJ_SetStoragePath(NULL);

    __INFO_PRINTF("device system reboot\n");
    if (iRebootType == EN_ZJ_REBOOT_NORMAL)
    {
        __INFO_PRINTF("Normal Reboot");
        // 正常重启需播放重启提示音
    }
    else if (iRebootType == EN_ZJ_REBOOT_SILENCE)
    {
        __INFO_PRINTF("Silence Reboot");
        // 静默重启不需要播放重启提示音
    }
    else
    {
        __INFO_PRINTF("Err Reboot Type");
    }
    /**
     *该接口不会真正重启，以下操作是在重启后设置为TF卡真实路径
    */
    ZJ_SetStoragePath(DEVICE_TFCARD_PATH);
    return 0;
}

/**
 * 设备恢复出厂设置回调接口，告诉设备需要将参数配置恢复出厂配置状态
 *  * 注意：
 *  重置需要停掉录像，ZJ_SetStoragePath(NULL);设置为NULL时可以停止TF卡录像。
 *  删除ZJ_Init设置的DEVICE_SYSTEM_PATH与DEVICE_CONFIG_PATH路径下的所有文件
 */ 
int system_reset_cb()
{
     ZJ_SetStoragePath(NULL);
    __INFO_PRINTF("device system reset\n");
    remove(DEVICE_SYSTEM_PATH);
    remove(DEVICE_CONFIG_PATH);
    /**
     *
    */
    return 0;  
}

// 设备进入休眠回调接口， 设备在该接口,收到等待秒数后，进入休眠状态，-1.为不可以进入休眠； 0.立刻进入休眠； > 0为等待对应的秒数后进入休眠；
int system_start_sleep_cb(int iWaitSecond)
{
    __INFO_PRINTF("device system start_sleep iWaitSecond %d \n", iWaitSecond);
    /**
     *
    */
    return 0;  

}

int system_record_status_cb(int iStatus)
{
    __INFO_PRINTF("device system record_status iStatus %d \n", iStatus);
    /**
     *
    */
    return 0;  

}

int system_dismantable_alarm_switch_cb(unsigned int uiOpenFlag)
{
    __INFO_PRINTF("device system dismantable_alarm_switch uiOpenFlag %d \n", uiOpenFlag);
    /**
     *
    */
    return 0;  
}

int system_stay_alarm_switch_cb(unsigned int uiOpenFlag)
{
    __INFO_PRINTF("device system stay_alarm_switch uiOpenFlag %d \n", uiOpenFlag);
    /**
     *
    */
    return 0;  
}

int system_camera_switch_cb(int iState)
{
    __INFO_PRINTF("device system camera_switch iState %d \n", iState);
    /**
     *
    */
    return 0;    
}

// ZJ_PFUN_DEVICE_SETWIFI pfuncSetWifi, ZJ_PFUN_DEVICE_GETWIFI pfuncGetWifi,ZJ_PFUN_DEVICE_GETNETINFO pfunGetCurNetInfo
int system_set_wifi_cb(EN_ZJ_NETWORK_TYPE enWifiType, char* pcSSID, char* pcPwd, int iEncrytType)
{
    __INFO_PRINTF("device system set_wifi enWifiType  %d \n", enWifiType);
    __INFO_PRINTF("device system set_wifi iEncrytType %d \n", iEncrytType);
    __INFO_PRINTF("device system set_wifi pcSSID %s      \n", pcSSID);
    __INFO_PRINTF("device system set_wifi pcPwd  %s      \n", pcPwd);
    /**
     *
    */
    return 0; 

}

int system_get_wifi_list_cb(ST_ZJ_WIFI_INFO stWifiInfo[16], unsigned int *puiWifiCount)
{
    __INFO_PRINTF("device system get_wifi \n");
    /**
     *
    */
    return 0; 
}

int system_get_cur_wifi_info_cb(ST_ZJ_NETWORK_INFO* pstNetInfo)
{
    strcpy((char *)pstNetInfo->aucGateway, "192.168.1.1");
    strcpy((char *)pstNetInfo->aucIPAddr, "192.168.1.123");
    strcpy((char *)pstNetInfo->aucIPv6Addr, "2408:874c:1ff:32:28::2");
    strcpy((char *)pstNetInfo->aucMacAddr, "12:34:56:78:90:33");
    strcpy((char *)pstNetInfo->aucNetmask, "255.255.255.0");
    strcpy((char *)pstNetInfo->aucWIFISSID, "wifiName");
    strcpy((char *)pstNetInfo->aucUpMacAddr, "12:34:56:78:90:33");

    pstNetInfo->iNetType     = 1;
    pstNetInfo->iSignalType  = 1;
    pstNetInfo->iSigStrength = 500;
    __INFO_PRINTF("device system get_wifi_info \n");
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->aucGateway: %s \n", pstNetInfo->aucGateway);
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->aucIPAddr: %s \n", pstNetInfo->aucIPAddr);
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->aucIPv6Addr: %s \n", pstNetInfo->aucIPv6Addr);
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->aucMacAddr: %s \n", pstNetInfo->aucMacAddr);
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->aucNetmask: %s \n", pstNetInfo->aucNetmask);
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->aucWIFISSID: %s \n", pstNetInfo->aucWIFISSID);
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->iNetType: %d \n", pstNetInfo->iNetType);
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->iSignalType: %d \n", pstNetInfo->iSignalType);
    __INFO_PRINTF("device system get_wifi_info pstNetInfo->iSigStrength: %d \n", pstNetInfo->iSigStrength);
    /**
     *
    */
    return 0; 
}

// 无感配网结果返回,1-成功,-1-失败
int system_set_AutoConnResult_cb(int iResult)
{
	__INFO_PRINTF("AutoConn iResult %d      \n",iResult);	
    return 0; 
}


static int g_iYear = 0;
static int g_iMon  = 0;
static int g_iMday = 0;
static int g_iHour = 0;
static int g_iMin  = 0;
static int g_iSec  = 0;
static int g_iZone = 480;
 /**
* 自动同步默认开启，值为1
*/
static int g_iSyncFlag = 1;

/**
 * 设置时间时区回调接口， 告诉设备按参数设置时间时区；
 * 注意：
 * 设置时间前，需要停掉录像，ZJ_SetStoragePath(NULL);设置为NULL时可以停止TF卡录像
 * 设置完时间，再设置成TF卡实际路径，开启TF卡录制
*/
int system_settimezone_cb(int iSyncFlag, int iZone, char *pcDateTime, char *pucDst)
{
    __INFO_PRINTF("device system module, set time zone, sync flag [%d] zone [%d] date time [%s] Dst [%s]", iSyncFlag, iZone, pcDateTime, pucDst);
    g_iSyncFlag = iSyncFlag;
    ZJ_SetStoragePath(NULL);
    if(iSyncFlag == 1)
    {
        /**
         * 时区值是以秒为单位传递下来的，注意：存在半时区的设置
        */
        __INFO_PRINTF("device system set zone [%d]\n", iZone);
        g_iZone = iZone/60;
        ZJ_SetStoragePath(DEVICE_TFCARD_PATH);
        return 0;
    }

    if(pcDateTime != NULL && strlen(pcDateTime)>0)
    {
        sscanf(pcDateTime, "%04d-%02d-%02d %02d:%02d:%02d", &g_iYear, &g_iMon, &g_iMday,&g_iHour, &g_iMin, &g_iSec);
        __INFO_PRINTF("device system set time:\n");
        __INFO_PRINTF("                  year:%04d\n", g_iYear);
        __INFO_PRINTF("                   mon:%02d\n", g_iMon);
        __INFO_PRINTF("                   day:%02d\n", g_iMday);
        __INFO_PRINTF("                  hour:%02d\n", g_iHour);
        __INFO_PRINTF("                   min:%02d\n", g_iMin);
        __INFO_PRINTF("                   sec:%02d\n", g_iSec);
    }
    ZJ_SetStoragePath(DEVICE_TFCARD_PATH);
    return 0;
}

/**
 * 时间时区信息获取回调接口
*/
int system_gettimezone_cb(int *piZone, unsigned char *pucTime, int *piSyncFlag)
{
    char acStrTime[30] = "";
    /**
     * 需要组成固定字符串传递给SDK，YYYY-MM-DD hh:mm:ss
    */
    snprintf(acStrTime, sizeof(acStrTime), "%04d-%02d-%02d %02d:%02d:%02d", g_iYear, g_iMon, g_iMday, g_iHour, g_iMin, g_iSec);
    strcpy((char *)pucTime, acStrTime);
    /**
     * 时区以秒为单位传递给SDK
    */
    *piZone = g_iZone * 60;
    /**
     * 自动同步默认开启，值为1
    */
    *piSyncFlag = g_iSyncFlag;
    __INFO_PRINTF("get device time and zone ok, zone [%d] time [%s] sync flag[%d] \n", *piZone, pucTime, *piSyncFlag);
    return 0;
}

/**
 * 时间时区信息获取回调接口
*/
int system_getDefaulttimezone_cb(int iSetZoneFlag, int piZone, long long iGMTSecond)
{
    if (iSetZoneFlag)
    {
        g_iZone = piZone;
    }
    /**
     * 自动同步默认开启，值为1
    */
    __INFO_PRINTF("set default time and zone ok, zone [%d] time [%lld] zone flag[%d] \n", piZone, iGMTSecond, iSetZoneFlag);
    return 0;
}

/**
 *  SD卡格式化回调接口,通过该接口通知设备格式化
 */
int system_formatsdcard_cb()
{ 
    /**
     * 模拟测试
    */
    char acCmdBuf[1024] = "";
    int iRet = 0;
    snprintf(acCmdBuf, 1024, "rm %s/* -r", DEVICE_TFCARD_PATH);
    iRet = system(acCmdBuf);
    __INFO_PRINTF("device system format sd card, result [%d]\n", iRet);
    return 0;
}


/**
 * 获取SD卡容量和状态回调接口，通过该接口获取SD卡容量信息 单位 M 和 sdcard状态 EN_ZJ_SDCARD_STATUS
 */
int system_getsdcardsize_cb(unsigned int  *piTotalSize, unsigned int *piFreeSize)
{
    int istatus = EN_ZJ_SDCARD_NORMAL;
    if(piTotalSize == NULL || piFreeSize == NULL)
    {
        istatus = EN_ZJ_SDCARD_USELESS;
        __ERROR_PRINTF("device system  get sd card size failed, parameter error");
        return istatus;
    }
    FILE* fd = NULL;
    long long int llFreeSize = 0;
    char acCmdBuf[1024] = "";
    char acTmpBuf[1024] = "";
    snprintf(acCmdBuf, 1024, "du -sc %s | awk 'NR==1'|awk '{print $1}'", DEVICE_TFCARD_PATH);
    fd = popen(acCmdBuf, "r");
    if(fd == NULL)
    {
        istatus = EN_ZJ_SDCARD_USELESS;
        __ERROR_PRINTF("device system get sd card size failed\n");
        return istatus;
    }
    if(fgets(acTmpBuf, sizeof(acTmpBuf-1), fd)<=0)
    {
        istatus = EN_ZJ_SDCARD_USELESS;
        __ERROR_PRINTF("device system get sd card size failed\n");
        pclose(fd);
        return istatus;
    }

    // Todo 获取SDCard状态
    // SDcard 正常       istatus = EN_ZJ_SDCARD_NORMAL;
    // SDcard 不可用     istatus = EN_ZJ_SDCARD_USELESS;
    // SDcard 没插卡     istatus = EN_ZJ_SDCARD_NOCARD;
    // SDcard 格式化中   istatus = EN_ZJ_SDCARD_FORMATING;

    llFreeSize   = atol(acTmpBuf) / 1024;//换算成M
    *piTotalSize = 100*1024;//100M
    llFreeSize   = (long long int)(*piTotalSize)-llFreeSize;
    llFreeSize   = llFreeSize <= 0? *piTotalSize:llFreeSize;
    *piFreeSize  = llFreeSize;
    pclose(fd);
    __INFO_PRINTF("device system  get sd card size, total size [%d] free size [%d]\n", *piTotalSize, *piFreeSize);
    return istatus;
}


/**
 *SD卡自检测回调接口,通过该接口让SD卡进行检测修复
 */
int system_checksdcard_cb(int *piErrCode)
{
    // ZJ_SetStoragePath(NULL);
    /**
     * 相关自检操作需要对接厂商自行实现
    */
    // ZJ_SetStoragePath(DEVICE_TFCARD_PATH);
    __INFO_PRINTF("device system check sd card \n");
    return 0;
}

/**
 *  把日志打包成ZIP，再通过ZJ_SetCollectLogFilesStatus接口通知SDK
 */
int system_prepare_local_log_cb(unsigned char *pucPeerId,unsigned int iSessionId,unsigned char *pcDesInfo)
{
    //TODO: 把日志打包成ZIP

    //通知SDK,上传日志
    ZJ_SetCollectLogFilesStatus((unsigned char *)"",0,0,(unsigned char *)"",(unsigned char *)"xxx/xxx.zip");

    return 0;
}

int system_getcpuramusage_cb(unsigned int* piCpuUsage, unsigned int* piRamUsage)
{
	*piCpuUsage = 20;
	*piRamUsage = 60;
    return 0;
}

int system_getpinginfo_cb(unsigned char *pucIp, unsigned int uiPingNum, unsigned int *puiDelayMin, unsigned int *puiDelayMax, unsigned int *puiDelayAvg, unsigned int *puiMissRate)
{
    return 0;
}

int system_superCodes_cb(unsigned int uiOpenFlag)
{
    __INFO_PRINTF("uiOpenFlag = %d\n", uiOpenFlag);

    return 0;
}

int system_setUtc_cb(long long illSecond)
{
    __INFO_PRINTF("UTC illSecond = %lld\n", illSecond);

    return 0;
}

int system_ipv6switch_cb(unsigned int uiIPv6Switch)
{
    __INFO_PRINTF("uiIPv6Switch:%u \n", uiIPv6Switch);

    //TODO: 配置IPv6开关
    return 0;
}

int system_init()
{
    /**
     * 设备状态回调函数设置， 从初始化启动&设备配网&设备添加绑定，一般为需要上层做相关提示的产品设置该回调函数
     */ 
    ZJ_Set_SystemStatusCB(system_device_status_cb);
    /**
     * 设备重启回调函数设置，设备上层在该函数中安全关闭设备各执行程序，然后将设备重新启动
     */ 
    ZJ_SetDeviceRebootCbFunc(system_reboot_cb);

    ZJ_SetRestoreFactorySettingCB(system_reset_cb);

    ZJ_SetStartSleepCb(system_start_sleep_cb);

    ZJ_SetRecordStatusCB(system_record_status_cb);

    ZJ_SetDismantableAlarmSwitchCB(system_dismantable_alarm_switch_cb);
    
    ZJ_SetStayAlarmSwitchCB(system_stay_alarm_switch_cb);

    ZJ_SetCameraSwitchCB(system_camera_switch_cb);

    ZJ_SetWifiCB(system_set_wifi_cb, system_get_wifi_list_cb, system_get_cur_wifi_info_cb);
	
	ZJ_SetAutoConnSSIDInfoCBFunc(system_set_wifi_cb);
	ZJ_SetAutoConnResultCBFunc(system_set_AutoConnResult_cb);

    /**
     * 设置系统时间获取与设置回调函数
     */
    ZJ_SetZoneAndTimeCB(system_settimezone_cb, system_gettimezone_cb);
#if 1
    ZJ_SetDefaultZoneAndTimeCB(system_getDefaulttimezone_cb);
#endif
    /**
     *设置SD卡支持能力   0.不支持； 1.支持；
     */
    ZJ_SetSDCardAbility(1);
    /**
     * 设置SD卡操作回调接口；
     */
    ZJ_SetSDCardCB(system_formatsdcard_cb, 
                    system_getsdcardsize_cb, 
                    system_checksdcard_cb);
    /**
     * 设置tf卡路径，TF卡插拔时都需要设置对应的状态
    */
    ZJ_SetStoragePath(DEVICE_TFCARD_PATH);

    /**
     * 设置本地LOG回调接口
    */ 
    ZJ_SetDevCollectLogFilesFunc(system_prepare_local_log_cb);
	
    /**
     * 设置cpu占用率、内存使用率获取回调接口
    */ 
    ZJ_SetCpuRamUsageCB(system_getcpuramusage_cb);

    /**
     * 设置UTC回调接口
    */ 
    ZJ_SetUtcTimeCB(system_setUtc_cb);

    /**
     *设置物理遮蔽支持能力
    */
    //ZJ_SetCameraPhysicalMaskAbility(1);

    /**
     *设置音柱支持能力
    */
    //ZJ_SetExternalSpeakerAbility(1);

    /**
     *设置音柱连接状态和音柱信息
    */
    //ZJ_SetExternalSpeakerStatus(0, NULL);

	/**
    *设置超级编码支持能力   0.不支持； 1.支持；
    */
    //ZJ_SetCameraSuperCodesAbility(1);

    /**
    * 设置超级编码开关回调接口
    */ 
    //ZJ_SetSuperCodesOpenFlagCB(system_superCodes_cb);

    /**
    * 设置IPv6能力与开关回调接口
    */ 
    //
    ZJ_SetIPv6Ability(1);
    ZJ_SetIPv6SwitchCB(system_ipv6switch_cb);

    return 0;
}

int system_start()
{
    __INFO_PRINTF("device system start\n");
    return 0;
}
