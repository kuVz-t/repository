#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "zj_channel.h"
#include "zj_log.h"
#include "zj_network.h"
#include "zj_ota.h"
#include "zj_power.h"
#include "zj_system.h"
#include "zj_err.h"

#include "devlog.h"
#include "type.h"
#include "video.h"
#include "audio.h"
#include "iot.h"
#include "system.h"
#include "ptz.h"
#include "ota.h"
#include "input_face.h"
#include "ga_1400.h"
#include "public.h"
//#include "sys/time.h"
#include "cJSON.h"

static int g_Exit = 0;

ZJ_HANDLE g_hPlayHandle;

static ST_DEV_INFO g_stDevInfo = {0};

static void signal_Termination(int sign)
{
    switch (sign)
    {
    case SIGINT/* constant-expression */:
        g_Exit = 1;
        ZJ_LOG_INF("device stop run,catch signnal %u ",sign);
        break;
    
    default:
        ZJ_LOG_INF("catch signnal %u ",sign);
        break;
    }
}

int make_path()
{
    char acCmd[1280] = {0};
    int ret = 0;
    if(access(DEVICE_SYSTEM_PATH, F_OK) != 0)
    {
        memset(acCmd, 0, sizeof(acCmd));
        sprintf(acCmd, "mkdir -p %s", DEVICE_SYSTEM_PATH);
        ret = system(acCmd);
    }
    if(access(DEVICE_CONFIG_PATH, F_OK) != 0)
    {
        memset(acCmd, 0, sizeof(acCmd));
        sprintf(acCmd, "mkdir -p %s", DEVICE_CONFIG_PATH);
        ret = system(acCmd);
    }
    if(access(DEVICE_AUDIO_PATH, F_OK) != 0)
    {
        memset(acCmd, 0, sizeof(acCmd));
        sprintf(acCmd, "mkdir -p %s", DEVICE_AUDIO_PATH);
        ret = system(acCmd);
    }
    if(access(DEVICE_TFCARD_PATH, F_OK) != 0)
    {
        memset(acCmd, 0, sizeof(acCmd));
        sprintf(acCmd, "mkdir -p %s", DEVICE_TFCARD_PATH);
        ret = system(acCmd);
    }
    __INFO_PRINTF("%d\n", ret);
    return 0;
}

ST_DEV_INFO *get_dev_info(void)
{
    return &g_stDevInfo;
}

int set_dev_info(ST_DEV_INFO *pstDevInfo)
{
    if (NULL == pstDevInfo)
    {
        return -1;
    }

    memcpy(&g_stDevInfo, pstDevInfo, sizeof(ST_DEV_INFO));

    // 设置固件版本号
    ZJ_SetAppVersion(pstDevInfo->acDevVerSion);

    // CTEI UID DeviceModel设置
    ZJ_SetCTEIID((unsigned char *)pstDevInfo->acDevCTEI);      	
    ZJ_SetDeviceModel((unsigned char *)pstDevInfo->acDevModel);
    ZJ_SetDeviceUID((unsigned char *)pstDevInfo->acDevUID, (unsigned char *)pstDevInfo->acDevkey);

    return 0;
}


int main(int argc, char *argv[])
{
    ST_DEV_INFO stDevInfo = {0};

    signal(SIGPIPE, SIG_IGN);
    signal(SIGINT, signal_Termination);
    make_path();

    //设置设备运行工作环境，1、生产环境，0、测试环境, zj_init前调用
    ZJ_SetSdkRunMode(1);
    /**
    初始化SDK，并配置SDK配置文件存储路径, 
    注意： SDK配置初始化包括音视频等、回调函数注册、
           设备能力集配置、IOT设备添加等均需要在SDK Init后
           SDK Start之前完成。
    ZJ_Init路径配置说明：
    DEVICE_SYSTEM_PATH为核心配置路径，不可以删除
    DEVICE_CONFIG_PATH为常规配置文件路径，恢复出厂设置时需要删除该路径下所有文件
    */
    ZJ_Init(DEVICE_SYSTEM_PATH, DEVICE_CONFIG_PATH);

    /**
     * 开启SDK打印， 1打开 0 关闭
     */
    ZJ_SetDebugMode(1);

    /**
     * 设置log打印等级
     */
    ZJ_SetDebugLevel(EN_ZJ_LOG_LVL_ALL);
    // 设置设备信息
    // 设置设备信息
    if ( getFileExitst("/mnt/config/kj_device_info.json") == 0)
    {
        char buffer1[512] = {0};
        readFileTemplate("/mnt/config/kj_device_info.json", buffer1, sizeof(buffer1));
        printf("buffer1:-------------------------------------------\n");
        {
            cJSON *cProp = cJSON_Parse((char*)buffer1);
            if(cProp == NULL)
            {
                __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
                return -1;
            }
            cJSON* cDevInfoUid = cJSON_GetObjectItem(cProp, "UID");
            cJSON* cDevInfoPwd = cJSON_GetObjectItem(cProp, "PASSWD");
            cJSON* cObj1 =cJSON_GetObjectItem(cProp, "CTEI");
            cJSON* cObj2 =cJSON_GetObjectItem(cProp, "MODEL");
            cJSON* cObj3 =cJSON_GetObjectItem(cProp, "VERSION");

            printf("uid:%s %s %s %s %s\n", (unsigned char *)(cDevInfoUid->valuestring),(unsigned char *)(cDevInfoPwd->valuestring), (unsigned char*)(cObj1->valuestring),(unsigned char*)(cObj2->valuestring), (unsigned char*)(cObj3->valuestring));
            ZJ_SetDeviceUID((unsigned char *)(cDevInfoUid->valuestring),(unsigned char *)(cDevInfoPwd->valuestring));
            ZJ_SetCTEIID((unsigned char*)(cObj1->valuestring));
            ZJ_SetDeviceModel((unsigned char*)(cObj2->valuestring));
            ZJ_SetAppVersion((unsigned char*)(cObj3->valuestring));
            ZJ_SetSN((unsigned char*)(cObj1->valuestring));
            if (cProp != NULL)
            {
                cJSON_Delete(cProp);
                cProp = NULL;
            }
        }
    }
    else
    {
        sprintf(stDevInfo.acDevVerSion, "V10.0.0-00-220701");     // 固件版本号
        sprintf(stDevInfo.acDevModel,   "C3050-10-LI-PV(2.8mm)"); // 设备型号
        sprintf(stDevInfo.acDevSN,      "12345678");              // 设备SN码
        sprintf(stDevInfo.acDevCTEI,    "181000800000043");       // 设备CTEI
        sprintf(stDevInfo.acDevUID,     "3HWCP361750007K");       // 设备UID
        sprintf(stDevInfo.acDevkey,     "WZa762EV5F");            // 设备密码
    }

    set_dev_info(&stDevInfo);

    /**
     * 网络发生变化时需要设置一下网络状态，相同的网络类型网络发生变化也需要设置
     */
    ZJ_SetNetWorkType(EN_ZJ_NETWORK_TYPE_WIRED);

    /*-----------------------*/
    /**
     * 初始化并启动测试用例
     */

#if 1
    video_init();
    audio_init();
    ptz_init();
    ga1400_init();
    iot_init();
    system_init();
    ota_init();

    video_start();
    audio_start();
    iot_start();
    system_start();
    ptz_start();
    ota_start();
#endif
    /*-----------------------*/

    /**
     * 启动SDK
     */
    ZJ_Start();
    printf("-------ZJ_Start END-------------\r\n");
#if AI_DEBUG
    ai_test();
#endif
    while(!g_Exit)
    {
        usleep(1*1000*1000);
    }
     /*停止SDK运行*/
    ZJ_Stop();
     /*释放占用资源*/
    ZJ_Destroy();
    return 0;
}
