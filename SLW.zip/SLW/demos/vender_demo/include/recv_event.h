#ifndef __RECV_EVENT_H__
#define __RECV_EVENT_H__
#ifdef __cplusplus
extern "C" {
#endif
int fifo_start(void);
#ifdef __cplusplus
}
#endif
#endif
