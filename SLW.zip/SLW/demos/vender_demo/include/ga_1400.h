#ifndef __GA_1400_H__
#define __GA_1400_H__

#include "input_face.h"

#ifdef __cplusplus
extern "C" {
#endif
typedef struct stru_ga1400_info
{
    unsigned int  uiGa1400Status;   // 1400注册登录状态
    unsigned char aucDomain[64];    // Ga1400域名
    unsigned char aucGa1400ID[32];  // Ga1400ID
}ST_GA1400_INFO;

// demoGA1400初始化
int ga1400_init(void);

// 上传车牌抓拍图片到1400平台
int ga1400_upload_car_snap();
// 上传人脸抓拍图片到1400平台
int ga1400_upload_face_snap(EN_FACE_TYPE faceType);


#ifdef __cplusplus
}
#endif

#endif
