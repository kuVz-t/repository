#ifndef __AUDIO_H__
#define __AUDIO_H__
#ifdef __cplusplus
extern "C" {
#endif
/*
    初始化
*/
int audio_init();

/*
    启动
*/
int audio_start();
#ifdef __cplusplus
}
#endif
#endif
