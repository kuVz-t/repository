#ifndef __PTZ_H__
#define __PTZ_H__
#ifdef __cplusplus
extern "C" {
#endif
int ptz_init();
int ptz_start();
#ifdef __cplusplus
}
#endif
#endif
