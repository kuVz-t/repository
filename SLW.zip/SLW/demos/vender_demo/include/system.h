#ifndef __SYSTEM_H__
#define __SYSTEM_H__
#ifdef __cplusplus
extern "C" {
#endif
int system_init();
int system_start();
#ifdef __cplusplus
}
#endif
#endif
