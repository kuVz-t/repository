#ifndef __TYPE_H__
#define __TYPE_H__
#ifdef __cplusplus
extern "C" {
#endif
#ifdef BUILD_ON_ARM
    /*SDK相关配置文件存储路径, TestPath为测试路径使用时，请根据需求修改为实际路径*/
    #define DEVICE_SYSTEM_PATH              "/mnt/sdcard/TestPath/system"
    #define DEVICE_CONFIG_PATH              "/mnt/sdcard/TestPath/system/config"
    #define DEVICE_AUDIO_PATH               "/mnt/sdcard/TestPath/system/audio"
    #define DEVICE_TFCARD_PATH              "/mnt/sdcard/TestPath/sd"
    #define DEVICE_AIPIC_PATH               "/mnt/sdcard/TestPath/aipic"

    //video relation
    #define DEVICE_VIDEO_FILE_PATH_CFG      "/mnt/sdcard/testfile/video/DemovideoDesc.txt"
    #define DEVICE_VIDEO_FILE_PATH_FILE     "/mnt/sdcard/testfile/video/Demovideo.H264"

    #define DEVICE_VIDEO_FILE_PATH_CFG_265      "/mnt/sdcard/testfile/video/DemovideoDesc_h265.txt"
    #define DEVICE_VIDEO_FILE_PATH_FILE_265     "/mnt/sdcard/testfile/video/Demovideo.h265"
    //audio relation
    #define DEVICE_AUDIO_FILE_PATH          "/mnt/sdcard/testfile/video/1.wav"
    //pic relation
    #define DEVICE_SNAP_FILE_JPG1           "/mnt/sdcard/testfile/pic/longmao.jpg"
    #define DEVICE_SNAP_FILE_JPG2           "/mnt/sdcard/testfile/pic/timg.jpg"
    #define DEVICE_PIC_PATH                 "/mnt/sdcard/testfile/pic"
#else
    /*SDK相关配置文件存储路径, TestPath为测试路径使用时，请根据需求修改为实际路径*/
    #define DEVICE_SYSTEM_PATH              "./TestPath/system"
    #define DEVICE_CONFIG_PATH              "./TestPath/system/config"
    #define DEVICE_AUDIO_PATH               "./TestPath/system/audio"
    #define DEVICE_TFCARD_PATH              "./TestPath/sd"
    #define DEVICE_AIPIC_PATH               "./TestPath/system/aipic"

    /*以下是音视频测试文件路径，仅测试时使用*/
    //video relation
    #define DEVICE_VIDEO_FILE_PATH_CFG      "/opt/21cn/testfile/video/DemovideoDesc.txt"
    #define DEVICE_VIDEO_FILE_PATH_FILE     "/opt/21cn/testfile/video/Demovideo.H264"
    
    #define DEVICE_VIDEO_FILE_PATH_CFG_265      "/opt/21cn/testfile/video/DemovideoDesc_h265.txt"
    #define DEVICE_VIDEO_FILE_PATH_FILE_265     "/opt/21cn/testfile/video/Demovideo.h265"
    //audio relation
    #define DEVICE_AUDIO_FILE_PATH          "/opt/21cn/testfile/video/1.wav"
    //pic relation
    #define DEVICE_SNAP_FILE_JPG1           "/opt/21cn/testfile/pic/longmao.jpg"
    #define DEVICE_SNAP_FILE_JPG2           "/opt/21cn/testfile/pic/timg.jpg"
    #define DEVICE_PIC_PATH                 "/opt/21cn/testfile/pic"
#endif

// #define APP_DOORBELL     //门铃专项功能开关

typedef struct stru_DEV_INFO
{
    char acDevVerSion[64];   // 固件版本号
    char acDevModel[64];     // 设备型号
    char acDevSN[64];        // 厂商的序列号
    char acDevCTEI[24];      // CTEI
    char acDevUID[64];       // 设备uid
    char acDevkey[64];       // 设备KEY

}ST_DEV_INFO;

ST_DEV_INFO *get_dev_info(void);
#ifdef __cplusplus
}
#endif
#endif
