#ifndef __OTA_H__
#define __OTA_H__
#ifdef __cplusplus
extern "C" {
#endif
int ota_init();
int ota_start();
#ifdef __cplusplus
}
#endif
#endif
