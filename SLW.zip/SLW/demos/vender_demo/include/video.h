#ifndef __VIDEO_H__
#define __VIDEO_H__
//#ifdef __cplusplus
//extern "C" {
//#endif
/*
    初始化
*/
int video_init(void);

/*
    启动
*/
int video_start(void);
//#ifdef __cplusplus
//}
//#endif
#endif
