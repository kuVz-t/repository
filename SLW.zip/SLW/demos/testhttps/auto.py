#coding=utf-8
import json
import sys, getopt

# 创建json函数
def create_pack_json_function(argv):
    # opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])

    test = "{\"METHOD\":\"3220\",\"SEQID\":\"10001\",\"BODY\":{\"DID\":\"设备ID\",\"BindCode\":\"用户绑定码\",\"Mac\":\"设备MAC地址\",\"CTEI\":\"CTEI码\",\"FirmwareVersion\":\"固件版本号\",\"TimeStamp\":\"Unix时间戳（毫秒）\",\"DevType\":\"设备型号\",\"Signature\":\"签名\"}}"

    fun_name = "yj_device_bind"

    method = "DEVICE_BIND"

    print("char *" + fun_name + "()")
    print("{")
    print("    char *json_string;")
    print("    cJSON *root, *body;\n")
    print("    // 获取硬件和软件信息")
    print("    yj_storage_get(&device_info, &software_info);")
    print("    // seqid自增")
    print("    SEQID_INC(seqid);\n")
    print("    // 转换格式")
    print("    strcpy(method_string, yj_hex_to_ascii(" + method + "));")
    print("    sprintf(seqid_string, \"%d\", seqid);\n")
    print("    root = cJSON_CreateObject();")
    print("    body = cJSON_CreateObject();\n")

    # 将 JSON 对象转换为 Python 字典
    params_json = json.loads(test)

    # 仅仅获取BODY
    body = params_json['BODY']

    items = body.items()
    for key, value in items:
        if str(key) == "CTEI" or str(key) == "DID":
            print("    JSON_SET_KEY_VALUE_STRING(body, \"" + str(key) + "\", device_info->" + str(key) + ");")
        else:
            print("    JSON_SET_KEY_VALUE_STRING(body, \"" + str(key) + "\", software_info->" + str(key) + ");")

    print("    JSON_SET_KEY_VALUE_STRING(root, \"METHOD\", method_string);")
    print("    JSON_SET_KEY_VALUE_STRING(root, \"SEQID\", seqid_string);")
    print("    JSON_SET_KEY_VALUE_OBJECT(root, \"BODY\", body);\n")
    print("    cJSON_free(root);")
    print("    return json_string;")
    print("}")

def create_unpack_json_function(argv):
    # opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])

    test = "{\"METHOD\":\"3219\",\"SEQID\":\"10001\",\"CODE\":\"0\"}"

    fun_name = "yj_unpack_change_key_info"
    try:
        # 将 JSON 对象转换为 Python 字典
        params_json = json.loads(test)

        body = params_json['BODY']
        items = body.items()

        print("YJ_RET " + fun_name + "(cJSON *body)")
        print("{")
        print("    if (body == NULL)")
        print("    {")
        print("        YJ_ERROR_PRINT();")
        print("        return YJ_FAIL;")
        print("    }\n")
        print("    // 获取storage句柄")
        print("    yj_storage_get(&device_info, &software_info);\n")
        print("    /* 存入本地config.json中 */")

        for key, value in items:
            if str(key) == "CTEI" or str(key) == "DID":
                print("    strcpy(device_info->" + str(key) + ",   JSON_GET_VALUE_FROM_KEY(body, \"" + str(key) + "\"));")
            else:
                print("    strcpy(software_info->" + str(key) + ",   JSON_GET_VALUE_FROM_KEY(body, \"" + str(key) + "\"));")

        print("    yj_storage_set();\n")
        print("    return YJ_OK;")
        print("}")

    except KeyError as identifier:
        pass


def add_new_json_string(key, init_value, buf_size, note):
    try:
        f = open('./yj_storage.c', 'r')
        for num, line in enumerate(f.readlines()):
            if line.find('AUTO:在上面添加新字段(读)') > 0:
                file_write("./yj_storage.c", num, "    strcpy((&software_info)->" + key + ", JSON_GET_VALUE_FROM_KEY(si, \"" + key + "\"));")
                print("./yj_storage.c")
                print("+++++++++    strcpy((&software_info)->" + key + ", JSON_GET_VALUE_FROM_KEY(si, \"" + key + "\"));")
            if line.find('AUTO:在上面添加新字段(写)') > 0:
                file_write("./yj_storage.c", num + 1, "    JSON_SET_KEY_VALUE_STRING(si, \"" + key + "\", (&software_info)->" + key + ");")
                print("./yj_storage.c")
                print("+++++++++    JSON_SET_KEY_VALUE_STRING(si, \"" + key + "\", (&software_info)->" + key + ");")
    finally:
        if f:
            f.close()
    try:
        f = open('./yj_config.h', 'r')
        for num, line in enumerate(f.readlines()):
            if line.find('AUTO:在上面添加新字段') > 0:
                file_write("./yj_config.h", num, "    char " + key + "[" + str(buf_size) + "];" + "  /* " + note + " */")
                print("./yj_config.h")
                print("+++++++++    char " + key + "[" + str(buf_size) + "];" + "  /* " + note + " */")
    finally:
        if f:
            f.close()
    try:
        f = open('./config.json', 'r')
        length = len(f.readlines()) - 2
        file_add_string("./config.json", length - 1, ",")
        file_write("./config.json", length, "        \"" + key + "\": " + "\"" + init_value + "\"")
        print("./config.json")
        print("+++++++++    \"" + key + "\": " + "\"" + init_value + "\"")
    finally:
        if f:
            f.close()

def file_add_string(file_name, line_num, text):
    lines=[]

    f=open(file_name,'r')  #your path!
    for line in f:
        lines.append(line)
    f.close()

    temp = lines[line_num].replace("\n", "")

    lines[line_num] = temp + text + "\n"

    s=''.join(lines)

    f=open(file_name,'w+') #重新写入文件
    f.write(s)
    f.close()

    del lines[:]           #清空列表

def file_write(file_name, line_num, text):
    lines=[]

    f=open(file_name,'r')  #your path!
    for line in f:
        lines.append(line)
    f.close()

    lines.insert(line_num, text + "\n")
    s=''.join(lines)

    f=open(file_name,'w+') #重新写入文件
    f.write(s)
    f.close()

    del lines[:]           #清空列表

if __name__ == "__main__":
    # create_pack_json_function(sys.argv[1:])
    # create_unpack_json_function(sys.argv[1:])
    # add_new_json_string("BindCode", "0", 12, "绑定码")
