#include "yj_storage.h"

static YJ_DEVICE_INFO device_info;
static YJ_SOFTWARE_INFO software_info;

YJ_RET yj_storage_init()
{
    char temp[128] = {'\0'};
    char text[1024] = {'\0'};
    cJSON *root, *di, *si;
    FILE *fd;

    // 打开文件
    fd = fopen("config.json", "r");

    if (!fd)
    {
        printf("open file fail!\r\n");
        return YJ_FAIL;
    }

    // 轮询每一行
    while(!feof(fd))
    {
        // 读取文件内容
        fgets(temp, 128, fd);
        strcat(text, temp);
    }// while(!feof(fp))

    // 解析JSON
    cJSON_Minify(text);
    root = cJSON_Parse(text);
    di = cJSON_GetObjectItem(root, "device_info");
    si = cJSON_GetObjectItem(root, "software_info");

    // 读出的参数赋值给结构体
    strcpy((&device_info)->CTEI, JSON_GET_VALUE_FROM_KEY(di, "CTEI"));
    strcpy((&device_info)->DID,  JSON_GET_VALUE_FROM_KEY(di, "DID"));
    strcpy((&software_info)->Version,  JSON_GET_VALUE_FROM_KEY(si, "Version"));
    strcpy((&software_info)->SignKey, JSON_GET_VALUE_FROM_KEY(si, "SignKey"));
    strcpy((&software_info)->EncKey,  JSON_GET_VALUE_FROM_KEY(si, "EncKey"));
    strcpy((&software_info)->EncLoad, JSON_GET_VALUE_FROM_KEY(si, "EncLoad"));
    strcpy((&software_info)->EncType, JSON_GET_VALUE_FROM_KEY(si, "EncType"));
    strcpy((&software_info)->NatIP,   JSON_GET_VALUE_FROM_KEY(si, "NatIP"));
    strcpy((&software_info)->NatPort, JSON_GET_VALUE_FROM_KEY(si, "NatPort"));
    strcpy((&software_info)->DevToken, JSON_GET_VALUE_FROM_KEY(si, "DevToken"));
    strcpy((&software_info)->InitFlag, JSON_GET_VALUE_FROM_KEY(si, "InitFlag"));
    strcpy((&software_info)->TimeOut, JSON_GET_VALUE_FROM_KEY(si, "TimeOut"));
    strcpy((&software_info)->BindCode, JSON_GET_VALUE_FROM_KEY(si, "BindCode"));
    strcpy((&software_info)->Mac, JSON_GET_VALUE_FROM_KEY(si, "Mac"));
    strcpy((&software_info)->FirmwareVersion, JSON_GET_VALUE_FROM_KEY(si, "FirmwareVersion"));
    strcpy((&software_info)->DevType, JSON_GET_VALUE_FROM_KEY(si, "DevType"));
    // AUTO:在上面添加新字段(读)

    // 释放资源
    fclose(fd);
    cJSON_free(root);

    return YJ_OK;
}

YJ_RET yj_storage_set()
{
    char *json_string;
    cJSON *root, *di, *si;
    FILE *fd;

    // 打开文件
    fd = fopen("config.json", "w");

    if (!fd)
    {
        printf("open file fail!\r\n");
        return YJ_FAIL;
    }

    // 创建json object
    root = cJSON_CreateObject();
    di = cJSON_CreateObject();
    si = cJSON_CreateObject();

    // 将参数填入JSON
    JSON_SET_KEY_VALUE_STRING(di, "CTEI", (&device_info)->CTEI);
    JSON_SET_KEY_VALUE_STRING(di, "DID", (&device_info)->DID);
    JSON_SET_KEY_VALUE_STRING(si, "Version", (&software_info)->Version);
    JSON_SET_KEY_VALUE_STRING(si, "SignKey", (&software_info)->SignKey);
    JSON_SET_KEY_VALUE_STRING(si, "EncKey", (&software_info)->EncKey);
    JSON_SET_KEY_VALUE_STRING(si, "EncLoad", (&software_info)->EncLoad);
    JSON_SET_KEY_VALUE_STRING(si, "EncType", (&software_info)->EncType);
    JSON_SET_KEY_VALUE_STRING(si, "NatIP", (&software_info)->NatIP);
    JSON_SET_KEY_VALUE_STRING(si, "NatPort", (&software_info)->NatPort);
    JSON_SET_KEY_VALUE_STRING(si, "DevToken", (&software_info)->DevToken);
    JSON_SET_KEY_VALUE_STRING(si, "InitFlag", (&software_info)->InitFlag);
    JSON_SET_KEY_VALUE_STRING(si, "TimeOut", (&software_info)->TimeOut);
    JSON_SET_KEY_VALUE_STRING(si, "BindCode", (&software_info)->BindCode);
    JSON_SET_KEY_VALUE_STRING(si, "Mac", (&software_info)->Mac);
    JSON_SET_KEY_VALUE_STRING(si, "FirmwareVersion", (&software_info)->FirmwareVersion);
    JSON_SET_KEY_VALUE_STRING(si, "DevType", (&software_info)->DevType);
    // AUTO:在上面添加新字段(写)

    JSON_SET_KEY_VALUE_OBJECT(root, "device_info", di);
    JSON_SET_KEY_VALUE_OBJECT(root, "software_info", si);

    // 格式化为文本
    json_string = cJSON_Print(root);

    // 写入文件
    fputs(json_string, fd);

    // 释放资源
    fclose(fd);
    cJSON_free(root);
    free(json_string);

    return YJ_OK;
}

YJ_RET yj_storage_get(YJ_DEVICE_INFO **device_info_output, YJ_SOFTWARE_INFO **software_info_output)
{
    if (device_info_output == NULL || software_info_output == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    /* 返回指针 */
    *device_info_output = &device_info;
    *software_info_output = &software_info;

    return YJ_OK;
}
