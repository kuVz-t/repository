#include "yj_util.h"

void yj_hex_buf_to_ascii(unsigned char *pHex, unsigned char *pAscii, int nLen)
{
    if (pHex == NULL || pAscii == NULL || nLen < 0)
    {
        YJ_ERROR_PRINT();
        return NULL;
    }

    unsigned char Nibble[2];
    unsigned int i,j;

    for (i = 0; i < nLen; i++){
        Nibble[0] = (pHex[i] & 0xF0) >> 4;
        Nibble[1] = pHex[i] & 0x0F;
        for (j = 0; j < 2; j++){
            if (Nibble[j] < 10){            
                Nibble[j] += 0x30;
            }
            else{
                if (Nibble[j] < 16)
                    Nibble[j] = Nibble[j] - 10 + 'A';
            }
            *pAscii++ = Nibble[j];
        } // for (j = 0; j < 2; j++)
    } // for (i = 0; i < nLen; i++)

    *pAscii = '\0';
}

unsigned char *yj_hex_to_ascii(unsigned short hex)
{
    if (hex < 0)
    {
        YJ_ERROR_PRINT();
        return NULL;
    }

    static unsigned char pAscii[5];
    unsigned char Nibble[4];
    unsigned int i,j;

    Nibble[0] = (hex & 0xF000) >> 12;
    Nibble[1] = (hex & 0x0F00) >> 8;
    Nibble[2] = (hex & 0x00F0) >> 4;
    Nibble[3] = (hex & 0x000F);

    for (j = 0; j < 4; j++){
        if (Nibble[j] < 10){
            Nibble[j] += 0x30;
        }
        else{
            if (Nibble[j] < 16)
                Nibble[j] = Nibble[j] - 10 + 'A';
        }
        pAscii[j] = Nibble[j];
    } // for (j = 0; j < 2; j++)

    pAscii[4] = '\0';

    return pAscii;
}

unsigned short yj_ascii_to_hex(unsigned char *text)
{
    if (text == NULL)
    {
        YJ_ERROR_PRINT();
        return NULL;
    }

    unsigned short hex = 0x0000;
    for(int i = 0; i < 4; i++)
    {
        unsigned char temp = text[i];
        if( '0' <= temp && temp <= '9'){
            hex |= (temp - '0') << ((3 - i) * 4);
        }
        else if( 'a' <= temp && temp <= 'z'){
            hex |= (temp - 'a' + 0x0A) << ((3 - i) * 4);
        }
        else if( 'A' <= temp && temp <= 'Z'){
            hex |= (temp - 'A' + 0x0A) << ((3 - i) * 4);
        }
    }// for(int i = 0; i < 4; i++)

    return hex;
}

long yj_sntp_get_timestamp()
{
    int fd, len, retry = 0;
    char ip[16];
    time_t timestamp = 0;

    socklen_t sev_len;
    struct sockaddr_in sev_addr;
    struct hostent *hostent;
    struct in_addr **addr_list;

    // 通过域名获取IP地址
    hostent = gethostbyname("ntp2.aliyun.com");
    addr_list = (struct in_addr **) hostent->h_addr_list;
    strcpy(ip ,inet_ntoa(*addr_list[0]));

    if(hostent == NULL)
    {
        printf("create socket fail!\n");
        return YJ_FAIL;
    }

    // 创建SOCKET，UDP类型
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(fd < 0)
    {
        printf("create socket fail!\n");
        return YJ_FAIL;
    }
 
    // 配置IP、端口
    memset(&sev_addr, 0, sizeof(sev_addr));
    sev_addr.sin_family = AF_INET;
    sev_addr.sin_addr.s_addr = inet_addr(ip);
    sev_addr.sin_port = htons(123);

    while(1)
    {
        // 准备协议
        char msg[48]={'\0'};
        unsigned char buf[48]={0};
        msg[0] = 3 | (4<<3);
        sev_len = sizeof(sev_addr);

        // 发送命令到SNTP服务器
        sendto(fd, msg, 48, 0, (struct sockaddr*)&sev_addr, sev_len);

        // 接受时间
        len = recvfrom(fd, buf, 48, 0, (struct sockaddr*)&sev_addr, &sev_len);

		if(len == 48)
		{
			for(int i = 40; i <= 43; i++)
			{
				unsigned char c = (unsigned char)buf[i];
				timestamp = (timestamp<<8) | c;
			}
 
            // 减去1970.1.1 0:0:0
			timestamp -= 2209075200;

            // 北京时间
			timestamp += 24 * 60 * 60;

            break;
		}

        // 超过3次
        if(++retry == 3){
            return YJ_FAIL;
        }
    }// while(1)

    close(fd);

    return timestamp % 10000 * 1000;
}
