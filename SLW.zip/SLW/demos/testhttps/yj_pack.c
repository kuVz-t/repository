#include "yj_config.h"
#include "yj_util.h"
#include "yj_aes.h"

#include "cJSON.h"

static YJ_DEVICE_INFO *device_info = NULL;
static YJ_SOFTWARE_INFO *software_info = NULL;
static cJSON *root = NULL, *body = NULL;
static int seqid = 100000;
static unsigned char method_string[6] = {0};
static unsigned char seqid_string[6]  = {0};

YJ_RET yj_pack_encrypt(unsigned char *plaintext, unsigned char *ciphertext, unsigned short *ciphertextlen)
{
    if (plaintext == NULL || ciphertext == NULL || ciphertextlen == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    static unsigned char key[17] = {0}; // A 128 bit key
    static unsigned char iv[17] = {0};  // A 128 bit IV
    int ciphertext_len = 0;

    // 获取硬件和软件信息
    yj_storage_get(&device_info, &software_info);

    strcpy(key, software_info->EncKey);
    strcpy(iv, software_info->EncLoad);

    /* Encrypt the plaintext */
    ciphertext_len = yj_aes_encrypt(plaintext, strlen(plaintext), key, iv, ciphertext);

    /* Do something useful with the ciphertext here */
    printf("Ciphertext is:\n");
    BUF_PRINTF_EX("Ciphertext", ciphertext, ciphertext_len);

    *ciphertextlen = ciphertext_len;

    return YJ_OK;
}

YJ_RET yj_pack_protocol(unsigned short Method, unsigned char *Text, unsigned short TextLen, unsigned char *output_buf, unsigned short *output_len)
{
    if (Method <= 0 || output_buf == NULL || output_len == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    U16_TO_U8S(MAGIC_HEAD, &output_buf[0]);
    U16_TO_U8S(Method, &output_buf[2]);
    U16_TO_U8S(TextLen, &output_buf[4]);

    /* 心跳包无内容，无加密 */
    if (Method != KJ_HEARTBEAT)
    {
        output_buf[6] = software_info->EncType;
        output_buf[7] = 0x00;
    }
    else
    {
        output_buf[6] = 0x00;
        output_buf[7] = 0x00;
        memcpy(&output_buf[8], Text, TextLen);
    }

    *output_len = PACKET_LEN + TextLen;

    return YJ_OK;
}

char *yj_pack_device_register()
{
    long timestamp;
    unsigned char sign[65], message[256], timestamp_string[8];
    char *json_string;

    // 获取硬件和软件信息
    yj_storage_get(&device_info, &software_info);

    // 获取timestamp
    timestamp = yj_sntp_get_timestamp();

    // seqid自增
    SEQID_INC(seqid);

    // 转换格式
    strcpy(method_string, yj_hex_to_ascii(KJ_DEVICE_REGISTER));
    sprintf(seqid_string, "%d", seqid);
    sprintf(timestamp_string, "%ld", timestamp);
    sprintf(message,
            "CTEI=%s&DID=%s&TimeStamp=%s&Version=%s",
            device_info->CTEI,
            device_info->DID,
            timestamp_string,
            software_info->Version
    );

    // 签名
    yj_sign(message, strlen(message), software_info->SignKey, strlen(software_info->SignKey), sign);

    // 创建json object
    root = cJSON_CreateObject();
    body = cJSON_CreateObject();

    // 封装成JSON格式
    JSON_SET_KEY_VALUE_STRING(body, "CTEI", device_info->CTEI);
    JSON_SET_KEY_VALUE_STRING(body, "DID", device_info->DID);
    JSON_SET_KEY_VALUE_STRING(body, "TimeStamp", timestamp_string);
    JSON_SET_KEY_VALUE_STRING(body, "Version", software_info->Version);
    JSON_SET_KEY_VALUE_STRING(body, "Signature", sign);
    JSON_SET_KEY_VALUE_STRING(root, "METHOD", method_string);
    JSON_SET_KEY_VALUE_STRING(root, "SEQID", seqid_string);
    JSON_SET_KEY_VALUE_OBJECT(root, "BODY", body);

    // 格式化json为string
    json_string = cJSON_Print(root);

    //释放json
    if (root != NULL)
    {
        cJSON_free(root);
        root == NULL;
    }
    
    //记得free(json_string);
    return json_string;
}

char *yj_pack_signaling_login()
{
    char *json_string;
    cJSON *root, *body;

    // 获取硬件和软件信息
    yj_storage_get(&device_info, &software_info);
    // seqid自增
    SEQID_INC(seqid);

    // 转换格式
    strcpy(method_string, yj_hex_to_ascii(KJ_SIGNALING_LOGIN));
    sprintf(seqid_string, "%d", seqid);

    root = cJSON_CreateObject();
    body = cJSON_CreateObject();

    JSON_SET_KEY_VALUE_STRING(body, "CTEI", device_info->CTEI);
    JSON_SET_KEY_VALUE_STRING(body, "DID", device_info->DID);
    JSON_SET_KEY_VALUE_STRING(body, "DevToken", software_info->DevToken);
    JSON_SET_KEY_VALUE_STRING(body, "Version", software_info->Version);
    JSON_SET_KEY_VALUE_STRING(body, "InitFlag", software_info->InitFlag);
    JSON_SET_KEY_VALUE_STRING(root, "METHOD", method_string);
    JSON_SET_KEY_VALUE_STRING(root, "SEQID", seqid_string);
    JSON_SET_KEY_VALUE_OBJECT(root, "BODY", body);

    json_string = cJSON_Print(root);

    cJSON_free(root);
    return json_string;
}

char *yj_pack_get_nat_info()
{
    yj_pack_device_register();
}

char *yj_pack_change_key_info()
{
    char *json_string;
    cJSON *root, *body;

    // 获取硬件和软件信息
    yj_storage_get(&device_info, &software_info);
    // seqid自增
    SEQID_INC(seqid);

    // 转换格式
    strcpy(method_string, yj_hex_to_ascii(KJ_CHANGE_KEY_INFO));
    sprintf(seqid_string, "%d", seqid);

    root = cJSON_CreateObject();
    body = cJSON_CreateObject();

    JSON_SET_KEY_VALUE_STRING(body, "EncType", software_info->EncType);
    JSON_SET_KEY_VALUE_STRING(body, "EncKey", software_info->EncKey);
    JSON_SET_KEY_VALUE_STRING(body, "EncLoad", software_info->EncLoad);
    JSON_SET_KEY_VALUE_STRING(root, "METHOD", method_string);
    JSON_SET_KEY_VALUE_STRING(root, "SEQID", seqid_string);
    JSON_SET_KEY_VALUE_OBJECT(root, "BODY", body);

    cJSON_free(root);
    return json_string;
}

char *yj_pack_device_bind()
{
    long timestamp;
    unsigned char sign[65], message[256], timestamp_string[8];
    char *json_string;
    cJSON *root, *body;

    // 获取硬件和软件信息
    yj_storage_get(&device_info, &software_info);

    // seqid自增
    SEQID_INC(seqid);

    // 获取timestamp
    timestamp = yj_sntp_get_timestamp();

    // 转换格式
    strcpy(method_string, yj_hex_to_ascii(KJ_DEVICE_REGISTER));
    sprintf(seqid_string, "%d", seqid);
    sprintf(timestamp_string, "%ld", timestamp);
    sprintf(message,
            "CTEI=%s&DID=%s&TimeStamp=%s&Version=%s",
            device_info->CTEI,
            device_info->DID,
            timestamp_string,
            software_info->Version
    );

    // 签名
    yj_sign(message, strlen(message), software_info->SignKey, strlen(software_info->SignKey), sign);

    root = cJSON_CreateObject();
    body = cJSON_CreateObject();

    JSON_SET_KEY_VALUE_STRING(body, "DID", device_info->DID);
    JSON_SET_KEY_VALUE_STRING(body, "BindCode", software_info->BindCode);
    JSON_SET_KEY_VALUE_STRING(body, "Mac", software_info->Mac);
    JSON_SET_KEY_VALUE_STRING(body, "CTEI", device_info->CTEI);
    JSON_SET_KEY_VALUE_STRING(body, "FirmwareVersion", software_info->FirmwareVersion);
    JSON_SET_KEY_VALUE_STRING(body, "TimeStamp", timestamp_string);
    JSON_SET_KEY_VALUE_STRING(body, "DevType", software_info->DevType);
    JSON_SET_KEY_VALUE_STRING(body, "Signature", sign);
    JSON_SET_KEY_VALUE_STRING(root, "METHOD", method_string);
    JSON_SET_KEY_VALUE_STRING(root, "SEQID", seqid_string);
    JSON_SET_KEY_VALUE_OBJECT(root, "BODY", body);

    cJSON_free(root);
    return json_string;
}
