#include "yj_config.h"
#include "yj_util.h"
#include "yj_aes.h"
#include "cJSON.h"

static YJ_DEVICE_INFO *device_info = NULL;
static YJ_SOFTWARE_INFO *software_info = NULL;
static cJSON *root = NULL;
static cJSON *body = NULL;

YJ_RET yj_unpack_decrypt(unsigned char *ciphertext, unsigned short ciphertext_len, unsigned char *decryptedtext)
{
    if (ciphertext == NULL || ciphertext_len <= 0 || decryptedtext == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    static unsigned char key[17] = {0}; // A 128 bit key
    static unsigned char iv[17] = {0};  // A 128 bit IV
    int decryptedtext_len = 0;

    // 获取硬件和软件信息
    yj_storage_get(&device_info, &software_info);

    strcpy(key, software_info->EncKey);
    strcpy(iv, software_info->EncLoad);

    /* Decrypt the ciphertext */
    decryptedtext_len = yj_aes_decrypt(ciphertext, ciphertext_len, key, iv, decryptedtext);

    if(decryptedtext_len < 0)
    {
        /* Verify error */
        printf("Decrypted text failed to verify\n");
    }
    else
    {
        /* Add a NULL terminator. We are expecting printable text */
        decryptedtext[decryptedtext_len] = '\0';

        /* Show the decrypted text */
        printf("Decrypted text is:\n");
        printf("%s\n", decryptedtext);
    }

    return YJ_OK;
}

char *yj_unpack_protocol(unsigned char *Text, unsigned short *Method)
{
    if (Text == NULL || Method == NULL)
    {
        YJ_ERROR_PRINT();
        return NULL;
    }

    unsigned short DataLen     = 0;
    unsigned char  EncryptMode = 0;
    unsigned char  Reserve     = 0;
    unsigned char *Data        = NULL;
    unsigned char  decryptedtext[PAKCET_MAX_SIZE] = {0};
    char *json_string = NULL;

    // 得到方法字
    U8S_TO_U16(Text + 2, *Method);

    // 得到数据长度
    U8S_TO_U16(Text + 4, DataLen);

    // 得到加密标记位
    U8S_TO_U8(Text + 6, EncryptMode);

    /* 得到数据 */
    Data = (unsigned char *)malloc((size_t)DataLen);
    memcpy(Data, Text + 8, (size_t)DataLen);

    /* 根据相应加密等级解密 */
    if (EncryptMode == HIGH_ENCRYPT)
    {
        // 解密
        yj_unpack_decrypt(Data, DataLen, decryptedtext);

        // 解析JSON
        root = cJSON_Parse(decryptedtext);
        body = cJSON_GetObjectItem(root, "BODY");

        // 转换格式为字符串
        json_string = cJSON_Print(root);

        return json_string;
    }
}

YJ_RET yj_unpack_device_register(cJSON *body)
{
    if (body == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    // 获取storage句柄
    yj_storage_get(&device_info, &software_info);

    /* 存入本地config.json中 */
    strcpy(software_info->DevToken, JSON_GET_VALUE_FROM_KEY(body, "DevToken"));
    strcpy(software_info->EncKey,   JSON_GET_VALUE_FROM_KEY(body, "EncKey"));
    strcpy(software_info->EncLoad,  JSON_GET_VALUE_FROM_KEY(body, "EncLoad"));
    strcpy(software_info->EncType,  JSON_GET_VALUE_FROM_KEY(body, "EncType"));
    strcpy(software_info->NatIP,    JSON_GET_VALUE_FROM_KEY(body, "NatIP"));
    strcpy(software_info->NatPort,  JSON_GET_VALUE_FROM_KEY(body, "NatPort"));
    yj_storage_set();

    return YJ_OK;
}

YJ_RET yj_unpack_signaling_login(cJSON *body)
{
    if (body == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    // 获取storage句柄
    yj_storage_get(&device_info, &software_info);

    /* 存入本地config.json中 */
    strcpy(software_info->EncType,   JSON_GET_VALUE_FROM_KEY(body, "EncType"));
    strcpy(software_info->EncKey,    JSON_GET_VALUE_FROM_KEY(body, "EncKey"));
    strcpy(software_info->EncLoad,   JSON_GET_VALUE_FROM_KEY(body, "EncLoad"));
    strcpy(software_info->TimeOut,   JSON_GET_VALUE_FROM_KEY(body, "TimeOut"));
    yj_storage_set();

    return YJ_OK;
}

YJ_RET yj_unpack_get_nat_info(cJSON *body)
{
    if (body == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    return yj_unpack_device_register(body);
}

