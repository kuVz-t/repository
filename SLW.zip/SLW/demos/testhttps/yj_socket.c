#include "yj_socket.h"

#define SA struct sockaddr

#define BUF_MAX_SIZE 2048
char buf[BUF_MAX_SIZE] = {0}; 

YJ_SOCKET *yj_socket_open(char *HostOrIp, int Port, int type)
{
    if (HostOrIp == NULL || Port < 0 || (type != YJ_TCP && type != YJ_UDP))
    {
        YJ_ERROR_PRINT();
        return NULL;
    }

    int  sockfd = 0;
    int  connfd = 0;
    char buffer[BUF_MAX_SIZE]   = {0};
    struct sockaddr_in servaddr = {0};
    YJ_SOCKET *Socket  = NULL;
    in_addr_t Addr = 0;

    // 如果为域名, 则获取IP
    if ((Addr = inet_addr(HostOrIp)) < 0){
       Addr = inet_addr(HostOrIp);
    }

    Socket = (YJ_SOCKET *)malloc(sizeof(YJ_SOCKET));
    if (type == YJ_TCP){
        /* 创建socket */
        if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) { 
            perror("socket creation failed"); 
            exit(EXIT_FAILURE); 
        } 

        /* 配置服务器参数 */
        memset(&servaddr, 0, sizeof(servaddr)); 
        servaddr.sin_family = AF_INET; 
        servaddr.sin_addr.s_addr = Addr;
        servaddr.sin_port = htons(Port); 

        /* 连接上服务器 */
        if (connect(sockfd, (SA*)&servaddr, sizeof(servaddr)) != 0) { 
            printf("connection with the server failed...\n"); 
            exit(0); 
        } 

        /* 给Socket结构体赋值 */
        Socket->fd       = sockfd;
        Socket->type     = YJ_TCP;
        Socket->servaddr = (struct sockaddr_in *)malloc(sizeof(servaddr));
        memcpy(Socket->servaddr, &servaddr, sizeof(servaddr));
    
        /* 延时一秒 */
        usleep(1000000);

        //记得释放servaddr和Socket
        return Socket;
    }
    else if (type == YJ_UDP){

        /* 创建socket */
        if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) { 
            perror("socket creation failed"); 
            exit(EXIT_FAILURE); 
        } 

        /* 配置服务器参数 */
        memset(&servaddr, 0, sizeof(servaddr)); 
        servaddr.sin_family = AF_INET; 
        servaddr.sin_addr.s_addr = Addr; 
        servaddr.sin_port = htons(Port); 

        /* 给Socket结构体赋值 */
        Socket->fd       = sockfd;
        Socket->type     = YJ_UDP;
        Socket->servaddr = (struct sockaddr_in *)malloc(sizeof(servaddr));
        memcpy(Socket->servaddr, &servaddr, sizeof(servaddr));

        //记得释放servaddr和Socket
        return Socket;
    }

    printf("Create socket fail!\r\n");
    return YJ_FAIL; 
}

YJ_RET yj_socket_close(YJ_SOCKET *Socket)
{
    if (Socket == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    // 关闭SOCKET
    close(Socket->fd); 

    return YJ_OK;
}

YJ_RET yj_socket_send(YJ_SOCKET *Socket, char *Buf, int BufLen)
{
    if (Socket == NULL || Buf == NULL || BufLen < 0)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }
    
    int len = 0;

    /* 写 */
    if(Socket->type == YJ_TCP) {
        len = write(Socket->fd, Buf, BufLen);
    }
    else if(Socket->type == YJ_UDP){
        sendto(Socket->fd, (const char *)Buf, BufLen, 
            MSG_CONFIRM, (const struct sockaddr *) Socket->servaddr,  
                sizeof(*(Socket->servaddr))); 
    }

    return YJ_OK;
}

YJ_RET yj_socket_recv(YJ_SOCKET *Socket, char *Buf, int *BufLen)
{
    if (Socket == NULL || Buf == NULL || BufLen < 0)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }
    
    int len = 0;
    int sev_len = 0;

    /* 读 */
    if(Socket->type == YJ_TCP) {
        len = read(Socket->fd, Buf, BUF_MAX_SIZE); 
        Buf[len] = '\0';
    }
    else if(Socket->type == YJ_UDP){
        len = recvfrom(Socket->fd, (char *)Buf, BUF_MAX_SIZE,  
                    MSG_WAITALL, (struct sockaddr *) Socket->servaddr, 
                    &sev_len); 
        Buf[len] = '\0'; 
    }

    *BufLen = len;

    return YJ_OK;
}
