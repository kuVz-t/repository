#include "yj_https.h"

YJ_RET yj_https_get(char *host)
{
    if (host == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    BIO *sbio, *out;
    int ret, len;
    char connbuf[128];
    char hostbuf[128];
    char tmpbuf[1024];
    SSL_CTX *ctx;
    SSL *ssl;

    sprintf(connbuf, "%s:https", host);
    sprintf(hostbuf, "Host:%s\n\n", host);

    /* XXX Seed the PRNG if needed. */
    ctx = SSL_CTX_new(TLS_client_method());

    if ((ret = SSL_CTX_use_certificate_file(ctx, "ca.cer", SSL_FILETYPE_PEM)) != 1)
    {
        printf("SSL_CTX_use_certificate_file failed!\n");
        return -1;
    }

    /* XXX Set verify paths and mode here. */
    sbio = BIO_new_ssl_connect(ctx);
    BIO_get_ssl(sbio, &ssl);
    if (ssl == NULL)
    {
        fprintf(stderr, "Can't locate SSL pointer\n");
        ERR_print_errors_fp(stderr);
        return YJ_FAIL;
    }

    /* Don't want any retries */
    SSL_set_mode(ssl, SSL_MODE_AUTO_RETRY);

    /* XXX We might want to do other things with ssl here */

    /* An empty host part means the loopback address */
    BIO_set_conn_hostname(sbio, connbuf);

    out = BIO_new_fp(stdout, BIO_NOCLOSE);
    if (BIO_do_connect(sbio) <= 0)
    {
        fprintf(stderr, "Error connecting to server\n");
        ERR_print_errors_fp(stderr);
        return YJ_FAIL;
    }
    if (BIO_do_handshake(sbio) <= 0)
    {
        fprintf(stderr, "Error establishing SSL connection\n");
        ERR_print_errors_fp(stderr);
        return YJ_FAIL;
    }

    /* XXX Could examine ssl here to get connection info */
    BIO_puts(sbio, "GET / HTTP/1.1\r\n");
    BIO_puts(sbio, hostbuf);

    for (;;)
    {
        len = BIO_read(sbio, tmpbuf, 1024);
        if (len <= 0) break;
        tmpbuf[1023] = '\0';
        printf("rsp: %s\r\n", tmpbuf); 
        break;
    }
    BIO_free_all(sbio);
    BIO_free(out);
    return YJ_OK;
}

YJ_RET yj_https_post(char *host, char *page, char *text)
{
    if (host == NULL || page == NULL || text == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    BIO *sbio, *out;
    int ret, len;
    char reqbuf[128];
    char connbuf[128];
    char hostbuf[128];
    char contentBuf[512];
    char contentLenBuf[128];
    char tmpbuf[1024];
    SSL_CTX *ctx;
    SSL *ssl;

    sprintf(connbuf, "%s:https", host);
    sprintf(reqbuf, "POST %s HTTP/1.1\r\n", page);
    sprintf(hostbuf, "Host:%s\r\n", host);
    sprintf(contentLenBuf, "Content-Length:%d\n\n", strlen(text));
    sprintf(contentBuf, "%s\n\n", text);

    printf("req:\r\n%s", contentBuf);

    /* XXX Seed the PRNG if needed. */
    ctx = SSL_CTX_new(TLS_client_method());

    if ((ret = SSL_CTX_use_certificate_file(ctx, "ca.cer", SSL_FILETYPE_PEM)) != 1)
    {
        printf("SSL_CTX_use_certificate_file failed!\n");
        return -1;
    }

    /* XXX Set verify paths and mode here. */
    sbio = BIO_new_ssl_connect(ctx);
    BIO_get_ssl(sbio, &ssl);
    if (ssl == NULL)
    {
        fprintf(stderr, "Can't locate SSL pointer\n");
        ERR_print_errors_fp(stderr);
        return YJ_FAIL;
    }

    /* Don't want any retries */
    SSL_set_mode(ssl, SSL_MODE_AUTO_RETRY);

    /* XXX We might want to do other things with ssl here */

    /* An empty host part means the loopback address */
    BIO_set_conn_hostname(sbio, connbuf);

    out = BIO_new_fp(stdout, BIO_NOCLOSE);
    if (BIO_do_connect(sbio) <= 0)
    {
        fprintf(stderr, "Error connecting to server\n");
        ERR_print_errors_fp(stderr);
        return YJ_FAIL;
    }
    if (BIO_do_handshake(sbio) <= 0)
    {
        fprintf(stderr, "Error establishing SSL connection\n");
        ERR_print_errors_fp(stderr);
        return YJ_FAIL;
    }

    /* XXX Could examine ssl here to get connection info */
    BIO_puts(sbio, reqbuf);
    BIO_puts(sbio, hostbuf);
    BIO_puts(sbio, "Content-Type: application/json\r\n");
    BIO_puts(sbio, contentLenBuf);
    BIO_puts(sbio, contentBuf);

    for (;;)
    {
        len = BIO_read(sbio, tmpbuf, 1024);
        if (len <= 0) break;
        tmpbuf[len] = '\0';
        char *json_string = strstr(tmpbuf, "{");
        yj_protocol_unpack(json_string);
        break;
    }
    
    BIO_free_all(sbio);
    BIO_free(out);
    return YJ_OK;
}
