/************************************************************ 
 Copyright (C), 1988-1999, Huawei Tech. Co., Ltd. 
 FileName: test.cpp 
 Author: Version : Date: 
 Description: // 模块描述
 
 Version: // 版本信息
 Function List: // 主要函数及其功能
 1. ------- 
 History: // 历史修改记录
 <author> <time> <version > <desc> 
 David 96/10/12 1.0 build this moudle 
***********************************************************/
#ifndef _YJ_CONFIG_H
#define _YJ_CONFIG_H

#include <stdio.h>
#include <netdb.h>
#include <time.h>
#include <unistd.h> 
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAGIC_HEAD        0x2324     /* 包头部 #$ */

#define PACKET_LEN        8          /* 包头长度 */

#define PAKCET_MAX_SIZE   256        /* 定义包的最大值 */

typedef enum {
    YJ_FAIL = -1, /* 失败 */
    YJ_OK   = 0   /* 成功 */
    // TODO：在此添加其他错误码
} YJ_RET;

typedef enum {
    /* 设备 ----> 平台 */
    KJ_DEVICE_REGISTER      = 0x3242, /* 设备能力平台注册请求（走能力平台，HTTPS） */
    KJ_DEVICE_REGISTER_ACK  = 0x3243, /* 设备能力平台注册请求回复（走能力平台，HTTPS） */

    KJ_SIGNALING_LOGIN      = 0x3244, /* 设备到信令服务登陆（TCP） */
    KJ_SIGNALING_LOGIN_ACK  = 0x3245, /* 设备到信令服务登陆回复（TCP） */

    KJ_GET_NAT_INFO         = 0x3246, /* 获取设备信令服务器地址（走能力平台，HTTPS） */
    KJ_GET_NAT_INFO_ACK     = 0x3247, /* 获取设备信令服务器地址回复（走能力平台，HTTPS） */

    DEVICE_BIND          = 0x3220, /* 设备绑定用户绑定码（走能力平台，HTTPS） */
    DEVICE_BIND_ACK      = 0x3221, /* 设备绑定用户绑定码回复（走能力平台，HTTPS） */

    KJ_HEARTBEAT            = 0xFF00, /* 链路检测(非低功耗类设备) （TCP） */

    // TODO:低功耗产品（门铃）命令字
    // HEARTBEAT_LE         = 0x321A,
    // KJ_HEARTBEAT            = 0x00FF,

    /* 平台 ----> 设备 */
    KJ_CHANGE_KEY_INFO      = 0x3218, /* 密钥变更通知（TCP） */
    KJ_CHANGE_KEY_INFO_ACK  = 0x3219, /* 密钥变更通知回复（TCP） */

    // TODO:低功耗产品（门铃）命令字
    // WAKE_UP            = 0xFF00, /* 休眠设备唤醒通知（TCP） */

    /* APP ----> 设备 */
    // TODO:局域网通讯因安全考虑暂时关闭
    // REQUEST_PAIR         = 0x3222, /* 局域网直连模式下WIFI配置和添加设备 （TCP） */
    // REQUEST_PAIR_ACK     = 0x3221, /* 局域网直连模式下WIFI配置和添加设备回复 （TCP） */
} YJ_METHOD;

typedef enum {
    NONE_ENCRYPT = 0x00, /* 无加密 */
    LOW_ENCRYPT  = 0x30, /* 简单加密 */
    HIGH_ENCRYPT = 0x31  /* AES加密 */
} YJ_ENCRYPT;

// typedef union {
//     unsigned char magic_head[2];   /* 包头部 */
//     unsigned char method_word[2];  /* 方法字 */
//     unsigned char data_len[1];     /* 数据长度 */
//     unsigned char encrypt_mode[1]; /* 加密模式 */
//     unsigned char reserve[1];      /* 保留 */
//     unsigned char *data;           /* 数据 */
// }YJ_PACKET_PROTOCOL;

// typedef struct {
//     char *METHOD;   /* [必须]请求的类型，类型字十六进制2位+方法字十六进制2位；*/
//     int  SEQID;     /* [必须]请求序列号，设备侧由100001~199999循环使用；App侧由200001~299999循环使用；能力平台侧由300001~399999循环使用；*/
//     char *BODY;     /* [非必须]请求的信令消息体(JSON结构) */
//     char *FROM;     /* [非必须]请求来源实体的唯一标识 */
//     char *TO;       /* [非必须]请求目的实体的标识 */
//     int  CODE;      /* 错误码，[必须]如果是响应消息，[非必须]非响应消息 */
// }YJ_JSON_PROTOCOL;

typedef struct {
    char CTEI[20];  /* 由中国电信统一分配，用来区分产品品牌与型号，为设备全网唯一码*/
    char DID[16];   /* Device ID，即设备在能力平台deviceSN */
} YJ_DEVICE_INFO;

typedef struct {
    char Version[20];  /* 软件版本号 */
    char DevToken[33];/* 设备token */
    char R1[3];  /* 保留 */
    char SignKey[12]; /* 签名key */
    char EncKey[17];  /* 加密key */
    char R2[3];  /* 保留 */
    char EncLoad[17]; /* 加密key */
    char EncType[3];  /* 加密类型 */
    char NatIP[17];   /* 信令服务器IP地址 */
    char R3[3];  /* 加密类型 */
    char NatPort[6];  /* 信令服务器端口 */
    char InitFlag[2];  /* 初始请求标志位 0：第一次 1：复位 */
    char TimeOut[6];  /* 心跳包间隔时间 */
    char R4[2];  /* 加密类型 */
    char BindCode[12];  /* 绑定码 */
    char Mac[16];  /* MAC地址 */
    char FirmwareVersion[20];  /* 固件版本 */
    char DevType[20];  /* 设备类型 */
    // AUTO:在上面添加新字段
} YJ_SOFTWARE_INFO;

#endif
