/************************************************************ 
 Copyright (C), 1988-1999, Huawei Tech. Co., Ltd. 
 FileName: test.cpp 
 Author: Version : Date: 
 Description: // 模块描述
 
 Version: // 版本信息
 Function List: // 主要函数及其功能
 1. ------- 
 History: // 历史修改记录
 <author> <time> <version > <desc> 
 David 96/10/12 1.0 build this moudle 
***********************************************************/
#ifndef _YJ_UTIL_H
#define _YJ_UTIL_H

#include "yj_config.h"
#include "cJSON.h"

/* 打印BUF */
#define BUF_PRINTF(name, buf, len) \
        printf("------------------%s[%d]------------------\r\n", (name), (len)); \
        int i = 0; \
        for(i = 0; i < (len); i++){ \
            printf("%02x", (buf)[i]); \
        } \
        printf("\r\n---------------------------------------\r\n");

/* 打印内存格式的BUF */
#define BUF_PRINTF_EX(name, buf, len) \
        printf("------------------%s[%d]------------------\r\n", (name), (len)); \
        for(int i=0;i<len;i++) {\
            printf("%02x",(unsigned char)(buf)[i]); \
        }\
        printf("---------------------------------------\r\n");

/* 参数检查 */
#define YJ_ERROR_PRINT() printf("[%s:%d] <%s> input parameters invaild!\r\n", __FILE__, __LINE__, __FUNCTION__);

/* JSON便捷操作 */
#define JSON_GET_VALUE_FROM_KEY(object, key) \
                (cJSON_GetObjectItem((object), (key))->valuestring)
#define JSON_SET_KEY_VALUE_STRING(object, key, value) \
                (cJSON_AddItemToObject((object), (key), cJSON_CreateString((value))))
#define JSON_SET_KEY_VALUE_OBJECT(object, key, value) \
                (cJSON_AddItemToObject((object), (key), (value)))

/* SEQID自增 */
#define SEQID_INC(value) value++;value%=200000;

/* u16转u8 buf */
#define U16_TO_U8S(u16, u8_buf) \
        *(u8_buf) = (unsigned char)(((u16) & 0xff00) >> 8); \
        *(u8_buf + 1) = (unsigned char)(((u16) & 0x00ff));

/* u32转u8 buf */
#define U32_TO_U8S(u32, u8_buf) \
        *(u8_buf) = (unsigned char)(((u32) & 0xff000000) >> 24); \
        *(u8_buf + 1) = (unsigned char)(((u32) & 0x00ff0000) >> 16); \
        *(u8_buf + 2) = (unsigned char)(((u32) & 0x0000ff00) >> 8); \
        *(u8_buf + 3) = (unsigned char)(((u32) & 0x000000ff));

/* u8 buf转u8 */
#define U8S_TO_U8(u8_buf, u8) \
        (u8) |= (unsigned char)(*(u8_buf));

/* u8 buf转u16 */
#define U8S_TO_U16(u8_buf, u16) \
        (u16) |= (unsigned short)(*(u8_buf) << 8); \
        (u16) |= (unsigned short)(*(u8_buf + 1));

/* u8 buf转u32 */
#define U8S_TO_U32(u8_buf, u32) \
        (u32) |= (unsigned int)(*(u8_buf) << 24); \
        (u32) |= (unsigned int)(*(u8_buf + 1) << 16); \
        (u32) |= (unsigned int)(*(u8_buf + 2) << 8); \
        (u32) |= (unsigned int)(*(u8_buf + 3));

/************************************************* 
 Function: // 函数名称
 Description: // 函数功能、性能等的描述
 Calls: // 被本函数调用的函数清单
 Called By: // 调用本函数的函数清单
 Table Accessed: // 被访问的表（此项仅对于牵扯到数据库操作的程序）
 Table Updated: // 被修改的表（此项仅对于牵扯到数据库操作的程序）
 Input: // 输入参数说明，包括每个参数的作
 // 用、取值说明及参数间关系。
 Output: // 对输出参数的说明。
 Return: // 函数返回值的说明
 Others: // 其它说明
*************************************************/ 
unsigned char * yj_hex_to_ascii(unsigned short Hex);

/************************************************* 
 Function: // 函数名称
 Description: // 函数功能、性能等的描述
 Calls: // 被本函数调用的函数清单
 Called By: // 调用本函数的函数清单
 Table Accessed: // 被访问的表（此项仅对于牵扯到数据库操作的程序）
 Table Updated: // 被修改的表（此项仅对于牵扯到数据库操作的程序）
 Input: // 输入参数说明，包括每个参数的作
 // 用、取值说明及参数间关系。
 Output: // 对输出参数的说明。
 Return: // 函数返回值的说明
 Others: // 其它说明
*************************************************/ 
unsigned short yj_ascii_to_hex(unsigned char *text);

/************************************************* 
 Function: // 函数名称
 Description: // 函数功能、性能等的描述
 Calls: // 被本函数调用的函数清单
 Called By: // 调用本函数的函数清单
 Table Accessed: // 被访问的表（此项仅对于牵扯到数据库操作的程序）
 Table Updated: // 被修改的表（此项仅对于牵扯到数据库操作的程序）
 Input: // 输入参数说明，包括每个参数的作
 // 用、取值说明及参数间关系。
 Output: // 对输出参数的说明。
 Return: // 函数返回值的说明
 Others: // 其它说明
*************************************************/ 
void yj_hex_buf_to_ascii(unsigned char *pHex, unsigned char *pAscii, int nLen);

/************************************************* 
 Function: // 函数名称
 Description: // 函数功能、性能等的描述
 Calls: // 被本函数调用的函数清单
 Called By: // 调用本函数的函数清单
 Table Accessed: // 被访问的表（此项仅对于牵扯到数据库操作的程序）
 Table Updated: // 被修改的表（此项仅对于牵扯到数据库操作的程序）
 Input: // 输入参数说明，包括每个参数的作
 // 用、取值说明及参数间关系。
 Output: // 对输出参数的说明。
 Return: // 函数返回值的说明
 Others: // 其它说明
*************************************************/ 
long yj_sntp_get_timestamp();
#endif
