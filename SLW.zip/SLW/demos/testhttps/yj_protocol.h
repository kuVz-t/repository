/************************************************************ 
 Copyright (C), 1988-1999, Huawei Tech. Co., Ltd. 
 FileName: test.cpp 
 Author: Version : Date: 
 Description: // 模块描述
 
 Version: // 版本信息
 Function List: // 主要函数及其功能
 1. ------- 
 History: // 历史修改记录
 <author> <time> <version > <desc> 
 David 96/10/12 1.0 build this moudle 
***********************************************************/
#ifndef _YJ_PROTOCOL_H
#define _YJ_PROTOCOL_H

#include "yj_config.h"
#include "yj_storage.h"
#include "yj_util.h"
#include "yj_hmac_sha.h"
#include "yj_socket.h"

#include "cJSON.h"

/************************************************* 
 Function: // 函数名称
 Description: // 函数功能、性能等的描述
 Calls: // 被本函数调用的函数清单
 Called By: // 调用本函数的函数清单
 Table Accessed: // 被访问的表（此项仅对于牵扯到数据库操作的程序）
 Table Updated: // 被修改的表（此项仅对于牵扯到数据库操作的程序）
 Input: // 输入参数说明，包括每个参数的作
 // 用、取值说明及参数间关系。
 Output: // 对输出参数的说明。
 Return: // 函数返回值的说明
 Others: // 其它说明
*************************************************/ 
YJ_RET yj_protocol_pack(unsigned short method);

/************************************************* 
 Function: // 函数名称
 Description: // 函数功能、性能等的描述
 Calls: // 被本函数调用的函数清单
 Called By: // 调用本函数的函数清单
 Table Accessed: // 被访问的表（此项仅对于牵扯到数据库操作的程序）
 Table Updated: // 被修改的表（此项仅对于牵扯到数据库操作的程序）
 Input: // 输入参数说明，包括每个参数的作
 // 用、取值说明及参数间关系。
 Output: // 对输出参数的说明。
 Return: // 函数返回值的说明
 Others: // 其它说明
*************************************************/ 
YJ_RET yj_protocol_unpack(char *Text);
#endif
