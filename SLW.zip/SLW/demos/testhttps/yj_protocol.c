#include "yj_protocol.h"

static unsigned short packet_len    = 0;
static unsigned short ciphertextlen = 0;
static unsigned char  packet_buf[PAKCET_MAX_SIZE + PACKET_LEN] = {0};
static unsigned char  ciphertext[PAKCET_MAX_SIZE]              = {0};
static char *json_string = NULL;

extern YJ_RET yj_pack_protocol(unsigned short Method, unsigned char *Text, unsigned short TextLen, unsigned char *output_buf, unsigned short *output_len);
extern YJ_RET yj_pack_encrypt(unsigned char *plaintext, unsigned char *ciphertext, unsigned short *ciphertextlen);
extern char  *yj_pack_device_register();
extern char  *yj_pack_signaling_login();
extern char  *yj_pack_get_nat_info();

extern char  *yj_unpack_protocol(unsigned char *Text, unsigned short *Method);
extern YJ_RET yj_unpack_decrypt(unsigned char *ciphertext, unsigned short ciphertext_len, unsigned char *decryptedtext);
extern YJ_RET yj_unpack_device_register(cJSON *Body);
extern YJ_RET yj_unpack_signaling_login(cJSON *Body);
extern YJ_RET yj_unpack_get_nat_info(cJSON *Body);

YJ_RET yj_protocol_pack(unsigned short Method)
{
    if (Method <= 0)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    /* 根据Method区分出不同命令字 */
    switch(Method)
    {
        /* 设备能力平台注册请求（走能力平台，HTTPS）*/
        case KJ_DEVICE_REGISTER:
        {
            json_string = yj_pack_device_register();

            yj_https_post("beta.ehome.21cn.com", "/esigtran/DeviceRegister", json_string);
        }
        break;

        /* 设备到信令服务登陆（TCP） */
        case KJ_SIGNALING_LOGIN:
        {
            json_string = yj_pack_signaling_login();

            printf("json_string: %s\r\n", json_string);

            yj_pack_encrypt(json_string, ciphertext, &ciphertextlen);

            yj_pack_protocol(Method, ciphertext, ciphertextlen, packet_buf, &packet_len);

            BUF_PRINTF("packet_head", packet_buf, packet_len);

            /* 测试 */
            {
                char buf[512] = {0};
                int buf_len = 0;
                
                YJ_DEVICE_INFO   *device_info   = NULL;
                YJ_SOFTWARE_INFO *software_info = NULL;

                yj_storage_get(&device_info, &software_info);

                YJ_SOCKET * Socket = yj_socket_open(software_info->NatIP, atoi(software_info->NatPort), YJ_TCP);

                yj_socket_send(Socket, packet_buf, packet_len);

                yj_socket_recv(Socket, buf, &buf_len);

                BUF_PRINTF_EX("rsp", buf, buf_len);

                yj_socket_close(Socket);

                free(Socket->servaddr);
                free(Socket);
            }
        }
        break;

        /* 获取设备信令服务器地址（走能力平台，HTTPS）与 设备能力平台注册请求 一样*/
        case KJ_GET_NAT_INFO:
        {
            json_string = yj_pack_get_nat_info();

            yj_https_post("beta.ehome.21cn.com", "/esigtran/DeviceRegister", json_string);
        }

        /* 设备绑定用户绑定码（走能力平台，HTTPS） */
        case DEVICE_BIND:
        {
            json_string = yj_pack_device_bind();

            yj_https_post("beta.ehome.21cn.com", "/esigtran/DeviceBind", json_string);
        }

        /* 链路检测(非低功耗类设备) （TCP） */
        case KJ_HEARTBEAT:
        {
            yj_pack_protocol(Method, NULL, 0, packet_buf, &packet_len);
            /* 测试 */
            {
                char buf[512] = {0};
                int buf_len = 0;
                
                YJ_DEVICE_INFO   *device_info   = NULL;
                YJ_SOFTWARE_INFO *software_info = NULL;

                yj_storage_get(&device_info, &software_info);

                YJ_SOCKET * Socket = yj_socket_open(software_info->NatIP, atoi(software_info->NatPort), YJ_TCP);

                yj_socket_send(Socket, packet_buf, packet_len);

                yj_socket_recv(Socket, buf, &buf_len);

                BUF_PRINTF_EX("rsp", buf, buf_len);

                yj_socket_close(Socket);

                free(Socket->servaddr);
                free(Socket);
            }
        }

        //TODO: 在这添加其他方法字
        default:
        break;
    }

    if (json_string != NULL)
    {
        free(json_string);
        json_string = NULL;
    }
    return YJ_OK;
}

YJ_RET yj_protocol_unpack(char *Text)
{
    if (Text == NULL)
    {
        YJ_ERROR_PRINT();
        return YJ_FAIL;
    }

    unsigned short MagicHead = 0;
    unsigned short Method    = 0;

    cJSON *Root = NULL;
    cJSON *Body = NULL;

    // 获取包头部
    U8S_TO_U16(Text, MagicHead);

    /* 区分该包为json格式还是16进制包格式 */
    if (MagicHead != MAGIC_HEAD)
    {
        // 解析JSON
        Root = cJSON_Parse(Text);
        Body = cJSON_GetObjectItem(Root, "BODY");

        // 转换格式为字符串
        json_string = cJSON_Print(Root);
        printf("rsp:\r\n%s\r\n", json_string);

        // 得到方法字
        Method = yj_ascii_to_hex(JSON_GET_VALUE_FROM_KEY(Root, "METHOD"));
    }
    else
    {
        // 解包，解析JSON
        json_string = yj_unpack_protocol(Text, &Method);
    }

    // 根据Method区分出不同命令字
    switch (Method)
    {
        case KJ_DEVICE_REGISTER_ACK:
        {
            yj_unpack_device_register(Body);
        }
        break;

        case KJ_SIGNALING_LOGIN:
        {
            yj_unpack_signaling_login(Body);
        }
        break;

        case KJ_GET_NAT_INFO:
        {
            yj_unpack_get_nat_info(Body);
        }

        case DEVICE_BIND:
        {
            
        }

        case KJ_HEARTBEAT:
        {
            
        }
    }

    if (json_string != NULL)
    {
        free(json_string);
        json_string = NULL;
    }
    
    if (Root != NULL)
    {
        cJSON_free(Root);
        Root = NULL;
    }
}
