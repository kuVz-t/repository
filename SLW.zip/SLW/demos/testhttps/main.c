#include "yj_hmac_sha.h"
#include "yj_https.h"
#include "yj_protocol.h"
#include "yj_util.h"
#include "yj_storage.h"
#include "yj_aes.h"
#include "yj_socket.h"

extern YJ_RET yj_pack_encrypt(unsigned char *plaintext, unsigned char *ciphertext, unsigned short *ciphertextlen);
extern YJ_RET yj_pack_decrypt(unsigned char *ciphertext, unsigned short ciphertext_len, unsigned char *decryptedtext);

int main( int argc, char *argv[] )
{
    if (argc < 2)
    {
        printf("./main [test_module]\r\n");
        printf("test_module: tcp_client | udp_client | hmac_sign | sntp | file_test | aes_128_cbc | api \r\n");
        return 0;
    }

    if (!strcmp("tcp_client", argv[1]))
    {
        YJ_DEVICE_INFO   *device_info   = NULL;
        YJ_SOFTWARE_INFO *software_info = NULL;
        YJ_SOCKET *Socket = NULL;
        char *example  = "test hello world";
        char buf[1024] = {0};
        int  buf_len   = 0;

        yj_storage_init();
        yj_storage_get(&device_info, &software_info);

        printf("连接服务器....\r\n");
        Socket = yj_socket_open("192.168.10.113", 8889, YJ_TCP);

        printf("发送....\r\n");
        yj_socket_send(Socket, example, strlen(example));

        printf("接受....\r\n");
        while(1)
        {
            yj_socket_recv(Socket, buf, &buf_len);
            printf("%s\r\n", buf);

            usleep(500000);
        }

        yj_socket_close(Socket);

        free(Socket->servaddr);
        free(Socket);
    }
    else if (!strcmp("udp_client", argv[1]))
    {
        YJ_DEVICE_INFO   *device_info   = NULL;
        YJ_SOFTWARE_INFO *software_info = NULL;
        YJ_SOCKET *Socket = NULL;
        char *example  = "test hello world";
        char buf[1024] = {0};
        int  buf_len   = 0;

        yj_storage_init();
        yj_storage_get(&device_info, &software_info);

        printf("连接服务器....\r\n");
        Socket = yj_socket_open("127.0.0.1", 8080, YJ_UDP);

        printf("发送....\r\n");
        yj_socket_send(Socket, example, strlen(example));

        // yj_socket_recv(Socket, buf, &buf_len);
        // usleep(500000);

        yj_socket_close(Socket);

        free(Socket->servaddr);
        free(Socket);
    }
    else if (!strcmp("hmac_sign", argv[1]))
    {
        const char *key = "w2GBr6zmVl";
        char message[256];
        unsigned char output[64 + 1];

        sprintf( message,
                "%s",
                "CTEI=MBafUQ54&DID=3ELLK243335TKKJ&TimeStamp=4265854&Version=V1.0.01-00-200916"
                );

        yj_sign(message, strlen(message), key, strlen(key), output);

        printf("sign: %s\r\n", output);
    }
    else if (!strcmp("sntp", argv[1]))
    {
        printf("time: %ld\r\n", yj_sntp_get_timestamp());
    }
    else if (!strcmp("file_test", argv[1]))
    {
        YJ_DEVICE_INFO *device_info;
        YJ_SOFTWARE_INFO *software_info;

        yj_storage_init();

        yj_storage_get(&device_info, &software_info);

        printf("%s\r\n", device_info->CTEI);
        printf("%s\r\n", device_info->DID);
        printf("%s\r\n", software_info->Version);
        printf("%s\r\n", software_info->SignKey);
        printf("%s\r\n", software_info->EncKey);
        printf("%s\r\n", software_info->EncLoad);
        printf("%s\r\n", software_info->EncType);
        printf("%s\r\n", software_info->NatIP);
        printf("%s\r\n", software_info->NatPort);

        yj_storage_set();
    }
    else if (!strcmp("aes_128_cbc", argv[1]))
    {
        unsigned char ciphertext[128] = {0};
        unsigned char decryptedtext[128] = {0};
        unsigned short ciphertextlen = 0;

        yj_storage_init();
        yj_aes_init();

        yj_pack_encrypt("test", ciphertext, &ciphertextlen);
        yj_unpack_decrypt(ciphertext, ciphertextlen, decryptedtext);
    }
    else if (!strcmp("api", argv[1]))
    {
        if (argc < 3)
        {
            printf("./main api [function_name]\r\n");
            printf("function_name: device_register | signaling_login | change_key_info | heartbeat\r\n");
            return 0;
        }

        // 设备注册 与 获取设备信令服务器地址 相同
        if (!strcmp("device_register", argv[2]))
        {
            yj_storage_init();

            yj_protocol_pack(KJ_DEVICE_REGISTER);
        }

        // 连接信令服务器
        else if (!strcmp("signaling_login", argv[2]))
        {
            yj_storage_init();

            yj_aes_init();

            yj_protocol_pack(KJ_SIGNALING_LOGIN);
        }

        // 连接密钥更改通知
        else if (!strcmp("change_key_info", argv[2]))
        {
            yj_storage_init();

            yj_aes_init();

            yj_protocol_pack(KJ_CHANGE_KEY_INFO);
        }

        // 心跳包
        else if (!strcmp("heartbeat", argv[2]))
        {
            yj_storage_init();

            yj_aes_init();

            yj_protocol_pack(KJ_HEARTBEAT);
        }
        else
        {
            printf("./main api [function_name]\r\n");
            printf("function_name: device_register | signaling_login | change_key_info | heartbeat\r\n");
            return 0;
        }
    }
    else
    {
        printf("./main [test_module]\r\n");
        printf("test_module: tcp_client | udp_client | hmac_sign | sntp | file_test | aes_128_cbc | api \r\n");
    }

    return 0;
}
