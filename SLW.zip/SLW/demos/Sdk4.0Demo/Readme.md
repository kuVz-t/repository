统一SDK4.0Demo使用说明

一、统一SDK4.0Demo目录结构

├─ CMakeLists.txt                       //
├─ Makefile                             // 测试Makefile，与.prarm结合使用
├─ Readme.md                            // 
├─ include                              // SDK头文件
│    ├─ cJSON.h
│    ├─ zj_camera.h
│    ├─ zj_cameraiot.h
│    ├─ zj_channel.h
│    ├─ zj_err.h
│    ├─ zj_log.h
│    ├─ zj_network.h
│    ├─ zj_ota.h
│    ├─ zj_power.h
│    ├─ zj_system.h
│    ├─ zj_thirdmedia.h
│    ├─ zj_type.h
│    └─ zj_ga1400.h
├─ lib                                  // SDK库文件
│    ├─ dymic                           // SDK动态库
│    │    └─ x86
│    ├─ static                          // SDK静态库
│    │    └─ x86
│    └─ thirdparty                      // 第三方加密库
│           └─ lib_ssl
├─ param_compile                        // prarm目录
│    ├─ compile_mips.prarm
│    └─ compile_x86.prarm
├─ TestPath                             // 设备存储路径
│    ├─ sd                              // 模拟SD卡
│    ├─ system                          // 配置存储路径
├─ source                               // 资源文件，用于模拟IPC设备获取的音视频和图片资源等
│    ├─ pic                             // 模拟抓拍图片
│    │    ├─ longmao.jpg
│    │    └─ timg.jpg
│    └─ video                           // 模拟音视频流
│           ├─ 1.wav
│           ├─ Demovideo.H264
│           ├─ Demovideo.h265
│           ├─ DemovideoDesc.txt
│           └─ DemovideoDesc_h265.txt
└─ src                                  // 模拟IPC对接功能文件
       ├─ ai.c
       ├─ audio.c
       ├─ include
       │    ├─ ai.h
       │    ├─ audio.h
       │    ├─ iot.h
       │    ├─ log.h
       │    ├─ ota.h
       │    ├─ ptz.h
       │    ├─ system.h
       │    ├─ type.h
       │    └─ video.h
       ├─ iot.c
       ├─ iot_event.c
       ├─ main.c
       ├─ ota.c
       ├─ ptz.c
       ├─ system.c
       └─ video.c
       

二、demo编译运行

- 修改param_compile文件夹中的文件，设置库路径和依赖的库名

- 执行make后，会在当前目录下生成可执行文件

三、模块介绍

- audio.c

        1、本文件为模拟IPC音频流推送、IPC语音对讲、云广播、音量调节等。
        2、音频流推送主要接口为ZJ_Audio_WriteFrame（详情参见文档5.2.4.9），其中对音频格式的要求参加文档3.4章，时间戳要求参见3.6章。其他初始化接口使用参考audio_init函数使用。
        3、语音对讲主要接口为ZJ_SetMediaToPlayCB（详情参见文档5.2.4.2.1），语音对讲流程参见文档4.6.7章。实现参见audio_VoiceToPlay_cb回调。
        4、云广播与语音对讲走同样接口，只需要使能云广播能力即可
        5、音量调节主要接口ZJ_SetAudioVolumnCB（详情参见文档5.2.4.6）。

- video.c

        1、本文件为模拟IPC视频流推送、IPC抓图、画面翻转、水印等。详细接口说明查看文档5.2.3章。
        2、视频流推送主要接口为ZJ_Video_WriteFrame（详情参见文档5.2.3.22），视频参数标准参见文档3.3章，时间戳要求参见3.6章。其他初始化接口使用参考video_init函数使用。
        3、抓图功能需要提前使用ZJ_Video_SetGetJpegCB注册回调，由SDK触发回调，其中图片数据需使用静态内存空间。详见video.c中device_VideoSnap_cb实现。
        4、画面翻转需要使用ZJ_SetImageInversionCB注册回调，由SDK触发回调，设备进行相应翻转操作。
        5、水印功能涉及三个回调，时间水印和自定义水印开关通过ZJ_SetShowTimeOSDCB（函数定义参见5.2.3.12）注册回调，当SDK回调1，则需要显示相应水印。另外，自定义水印内容通过ZJ_SetOSDSettingCB（参数定义参见5.2.3.11）注册的回调下发。

- ota.c

        1、本文件负责设备的OTA升级，OTA升级包可在门户网站上部署。
        2、OTA功能需要使用ZJ_SetOtaCBFuncs和ZJ_StartUpdate两个接口。ZJ_SetOtaCBFuncs接口需要注册三个回调（功能参数详见5.6.2），升级流程详见文档4.6.9章

- ptz.c

        1、本文件负责设备的云台功能，不支持云台的设备可使用ZJ_SetPTZAbility设置能力值为0。不需要再设置其他接口。
        2、云台所有回调使用ZJ_SetCameraPTZCB注册（参数详见文档5.3.6）。
        3、云台移动逻辑是：SDK回调（ZJ_PFUN_CAMERA_ONPTZ）360的步长，设备保持一直转动，直到SDK回调（camera_ptz_stop_cb）时停止。设备也要支持根据步长转动（暂不使用）。当云台转到不能转，需要使用ZJ_SendPTZtoEndFlag接口通知SDK。
        4、获取云台预置位坐标、转动到预置位、云台自检、智能巡航功能参考ptz.c实现和文档5.3.8章。

- system.c

        1、本文件负责设备的系统设置的回调注册，包括重启、恢复出厂、配网等功能。详见system.c实现。

- iot.c

        1、本文件负责设备IOT模块功能。SDK把部分IPC能力（移动侦测、人形侦测、白光灯、扬声器、红外、客流统计、区域入侵、电瓶车识别、口罩识别、高空抛物识别等）抽象成一个IOT设备，便于IPC能力之间的联动。一个IOT设备有启动、停止、属性输入、控制等，详细接口说明参见文档5.8章。
        2、只用告警类型的iot才会使用到prop，其他iot控制使用output控制。
        3、prop 和 output json内容参考 "zj_cameraiot.h"，部分iot控制开关通过属性输入回调json串进行控制。
        4、除了Motion和Human的Interval默认值不为0;其他告警的默认Interval都为0
        5、iot功能策略参见文档9.2章。
        6、iot的注册流程可参见iot.c中iot_init函数。
        7、iot事件触发可参见iot_event.c中iot_loop函数。
        8、iot ai需要设置联动策略，使用ZJ_AddAlarmPolicyOutput接口，参见iot.c使用。

- iot_event.c
        1、本文件负责iot事件触发上报。

- ai.c

        1、本文件负责设备的ai功能对接，包括人脸布控、人脸抓拍、车牌抓拍、1400等，不支持ai的设备设置相关能力值为0即可。另外，本文件实现的ai功能需要与IOT ai区分，两者上报的接口不一致，详见文档4.6.8章。上报流程参考iot.c中iot_loop函数实现，接口说明参见5.8.5章。
        2、ai功能相关接口参见文档5.8.5章。人脸抓拍图规范参见3.20章。
        3、设备支持人脸抓拍或车牌抓拍等功能，需要使用ZJ_SetGat1400Ability使能1400。1400对接指引参见文档9.4章。

- main.c

        1、应用程序初始化和启动，注意要参照demo初始化顺序，同时参照文档第3章总体接入要求。


四、对接建议

**统一SDK4.0功能对接需参考SDK4.0Demo和对接文档。有歧义或表述不清可在钉钉群上提出，如遇崩溃问题，参考咨询问题模板向研发提出。感谢！**