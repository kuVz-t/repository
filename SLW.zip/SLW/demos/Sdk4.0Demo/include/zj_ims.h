#ifndef _ZJ_IMS_H_
#define _ZJ_IMS_H_

#ifdef __cplusplus
extern "C" {
#endif

//recv err notice
typedef int (*ZJ_PFUN_IMS_RECV_ERRNTC)(EN_ZJ_IMSERR_TYPE enErrType);

int ZJ_SetIMSAbility(int iIMSAbility);

int ZJ_SetRecvImsErrCB(ZJ_PFUN_IMS_RECV_ERRNTC pfun_RecvErrNtc);

#ifdef __cplusplus
}
#endif

#endif