
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include "zj_type.h"
#include "zj_log.h"
#include "zj_camera.h"  
#include "zj_cameraiot.h"
#include "zj_network.h"
#include "log.h"
#include "type.h"
#include "string.h"
#include "audio.h"
#include "system.h"

struct ST_VIDEOPLAY
{
    int  iRun; //0:任务已结束, 1:任务执行中，2:控制任务结束
    char pcPeerID[128];
};

typedef enum enum_ZJ_VIDEO_STREAM_TYPE{
    EN_VIDEO_MAIN,
    EN_VIDEO_SUB
}EN_DEVICE_STREAM_TYPE;

static struct ST_VIDEOPLAY st_hHander = {0};
static char *PcSnapPic = NULL;
static unsigned int picSel = 0;
static int g_iVideoMainEncode = 0;
static int g_iVideoSecEncode = 0;
char pTmpmMalloc[256*1024] = {0};


unsigned long long int util_GetTickCount()
{
    struct timespec stTime;

    clock_gettime(CLOCK_MONOTONIC, &stTime);

    return (stTime.tv_sec * 1000 + stTime.tv_nsec/1000000);
}

/**
*抓图接口回调参考
*注意：SDK也不做内存释放操作，需要固件层自己管理申请到的内存，可参考如下方式
*/
int device_VideoSnap_cb(EN_ZJ_PICTURE_TYPE enPicType, unsigned char **ppucJpegBuf)
{
    FILE *hJpg  = NULL;
    char *pFilepath = DEVICE_SNAP_FILE_JPG1;
    unsigned int uiFilesize = 0;
    __INFO_PRINTF("device video get jpg ...\n");
    if(0 == (picSel++%2))
        pFilepath = DEVICE_SNAP_FILE_JPG1;
    else
        pFilepath = DEVICE_SNAP_FILE_JPG2;

    hJpg  = fopen(pFilepath,"rb"); 
    if(NULL==hJpg)
    {
        __ERROR_PRINTF("device fopen jpg file failed!\n");
        return -1;
    }   
    fseek(hJpg,0, SEEK_END);
    uiFilesize = ftell(hJpg);//读取图片的大小长度
    fseek(hJpg, 0, SEEK_SET);
    __INFO_PRINTF("device get jpg file size:%d\n",uiFilesize);
    if(0 == uiFilesize)
        return -1;
//    pTmpmMalloc = (char *)realloc(PcSnapPic, uiFilesize);
//    if(pTmpmMalloc == NULL)
//    {
//        __ERROR_PRINTF("device video snap realloc buff failed\n");
//        return -1;
//    }
    memset(pTmpmMalloc, 0, sizeof(pTmpmMalloc));
    PcSnapPic = pTmpmMalloc;
    if(0 == fread(PcSnapPic, 1, uiFilesize, hJpg))
    {
        fclose(hJpg);
        __ERROR_PRINTF("device video snap fread failed\n");
        return -1;
    }
    fclose(hJpg);
    *ppucJpegBuf = (unsigned char *)PcSnapPic;
    __INFO_PRINTF("device video get jpg ok\n");
    return uiFilesize;//需要返回图片大小
}


typedef struct videoTimeInfo
{
    unsigned int count_times;
    unsigned int last_timestamps;
    unsigned int diff_timestamps;
}videoTimeInfo;

videoTimeInfo readInfo = {0, 0, 0};
/**
*写视频帧参考
*/
int video_exeUpload(char *videoPath,char *videoCfgPath, int isMain)
{
    int is_first = 0;
    FILE *hVideo  = NULL;
    FILE *hVideoCfg  = NULL;
    char pVideobuf[100000] = {0}; 
    char *pVideobufCfg = NULL;
    hVideo  = fopen(videoPath,"rb"); 
    if(NULL==hVideo)
    {
        __ERROR_PRINTF("device video fopen video path failed!\n");
        return -1;
    }
    hVideoCfg  = fopen(videoCfgPath,"rb"); 
    if(NULL==hVideoCfg)
    {
        __ERROR_PRINTF("device video fopen video cfg path failed!\n");
        return -1;
    }
    int add = isMain>0 ? 1: 0;
    pVideobufCfg = (char *)malloc(40 + 2);
    if(NULL==pVideobufCfg)
    {
        __ERROR_PRINTF("device video buf cfg malloc failed!\n");
        return -1;
    }
    unsigned int uLastTimeStamp = 0;
    while(fread(pVideobufCfg, 1, 39 + add, hVideoCfg)!= 0)
    {
        int length = 0;
        int utimestamp = 0;
        unsigned long long int ulltimestamp = 0;
        int frametype = 0;
        unsigned char  bIsIFrame = 0;
        if (isMain)
        {
            sscanf(pVideobufCfg, "LEN:%05dFRAMETYPE:%02dTIMESTAMP:%9d", &length,&frametype, &utimestamp);
        }
        else 
        {
            sscanf(pVideobufCfg, "LEN:%05dFRAMETYPE:%02dTIMESTAMP:%8d", &length,&frametype, &utimestamp);
        }
        if(0x0e == frametype)
            bIsIFrame = EN_ZJ_VIDEO_FRAME_TYPE_I;
        else
            bIsIFrame = EN_ZJ_VIDEO_FRAME_TYPE_P;
        if(0 == fread(pVideobuf, 1, length, hVideo))
        {
            __TRACE_PRINTF("device video fread failed! %d\n", isMain);
            free(pVideobufCfg);
            fclose(hVideo);
            fclose(hVideoCfg);
            pVideobufCfg = NULL;
            return -1;
        }
        /**
         * 以上部分为测试用例代码,调用参考
         */
        if(g_iVideoMainEncode)
        {
            ulltimestamp = getCurrentDayMsec();//util_GetTickCount();
            //ulltimestamp += (readInfo.diff_timestamps*readInfo.count_times);
            /**
             * 注意： 时间戳单位毫秒
            */
            ZJ_Video_WriteFrame(isMain>=1?EN_VIDEO_MAIN:EN_VIDEO_SUB, (unsigned char *)pVideobuf, length, (unsigned int)ulltimestamp, bIsIFrame);
            if (is_first)
            {
                uLastTimeStamp = (unsigned int)ulltimestamp;
                is_first = 0;
            }
            //printf("stream:%d len:%d time:%u\n",1-isMain, length, ulltimestamp);
            readInfo.last_timestamps = ulltimestamp - uLastTimeStamp;
        }
        /**
         * 以下部分为测试用例代码
         */
        usleep(66*1000);
        memset(pVideobuf, 0, 100000);
        memset(pVideobufCfg, 0, 40 + 2);

    }
    readInfo.diff_timestamps = readInfo.last_timestamps;
    readInfo.count_times++;
    free(pVideobufCfg);
    fclose(hVideo);
    fclose(hVideoCfg);
    pVideobufCfg = NULL;
    return 0;
}
#include "stdlib.h"
/**
*视频写流模拟线程
*/
static void *video_loop(void *arg)
{
    int isMain = 1;
    int iDeviceIAwakeFlag = 0;
    if (arg != NULL)
    {
         isMain= atoi(arg);
    }
    __INFO_PRINTF("device video loop thread start ok,##### isMain:%d\n", isMain);
    while(1)
    {
        if (isMain <= 0)
        {
            if(0 != video_exeUpload(DEVICE_VIDEO_FILE_PATH_FILE, DEVICE_VIDEO_FILE_PATH_CFG, 0))
            {
                __ERROR_PRINTF("device video upload failed \n");
            }
        }
        else
        {
            if(0 != video_exeUpload(DEVICE_VIDEO_FILE_PATH_FILE_265, DEVICE_VIDEO_FILE_PATH_CFG_265, 1))
            {
                __ERROR_PRINTF("device video upload failed \n");
            }
        }

        usleep(40000);
    }
    __INFO_PRINTF("device video loop thread start exit\n");
    return 0;
}


/**
*设置画面翻转回调接口， 告诉设备画面进行翻转，取值参考：EN_ZJ_ROTATE_TYPE
*/
int video_ImageInversion_cb(int iState)
{
    __INFO_PRINTF("device video recv image inversion ..., stat [%d] \n", iState);
    switch(iState)
    {
        case EN_ZJ_ROTATE_TYPE_VERTICAL_UP:  //旋转180°
            __INFO_PRINTF("device video image rotate 180\n");
            break;
        case EN_ZJ_ROTATE_TYPE_VERTICAL_DOWN:  //反向旋转180°
            __INFO_PRINTF("device video image reverse rotate 180\n");
            break;
        case EN_ZJ_ROTATE_TYPE_MIRROR_ENABLE:  //镜像翻转
            __INFO_PRINTF("device video image mirror flip\n");
            break;
        case EN_ZJ_ROTATE_TYPE_MIRROR_DISABLE:  //取消镜像翻转
            __INFO_PRINTF("device video image cancel mirror flip\n");
            break;
        default:
            __INFO_PRINTF("device video recv image inversion failed, stat [%d] \n", iState);
            return -1;
    }
    __INFO_PRINTF("device video recv image inversion ok, stat [%d] \n", iState);
    return 0;
}

int video_wdr_cb(unsigned int uiOpenFlag)
{
    __INFO_PRINTF("device video recv wdr ..., stat [%d] \n", uiOpenFlag);

    return 0;
}

/* 设置OSD信息 */
int video_osdinfo_cb(int iPosition, char* pcOSDName)
{
    // OSD自定义(文本)水印位置      参考: EN_ZJ_OSD_POSITION_TYPE 0.默认；1.左上；2.左下；3.右上；4.右下
    __INFO_PRINTF("device video recv set OSD Info ..., iPosition [%d] \n", iPosition);
    // OSD自定义(文本)水印内容      格式:UTF-8，最大支持512字节
    __INFO_PRINTF("device video recv set OSD Info ..., pcOSDName [%s] \n", pcOSDName);
    return 0;
}

int video_osdTimedisplay_cb(int iOpenFlag)
{
    // OSD默认(时间)水印显示开关    0.不显示 1.显示
    __INFO_PRINTF("device video recv set OSD Time Display [%d] \n", iOpenFlag);
    return 0;
}

int video_osdCustomdisplay_cb(int iOpenFlag)
{
    // OSD自定义(文本)水印显示开关  0.不显示 1.显示
    __INFO_PRINTF("device video recv set OSD Custom Display [%d] \n", iOpenFlag);
    return 0;
}

int video_osdCustomMode_cb(int iMode)
{
    // OSD自定义(文本)水印模式  0.默认，只能显示一个位置水印；1.支持同时显示四个位置水印
    __INFO_PRINTF("device video recv set OSD Custom Mode [%d] \n", iMode);
    return 0;
}

int video_osdcommoninfo_cb(int iOSDCommonPosition, int iOSDCommonFormat)
{
    // OSD默认(时间)水印位置    参考: EN_ZJ_OSD_POSITION_TYPE 0.默认；1.左上；2.左下；3.右上；4.右下
    __INFO_PRINTF("device video recv set OSD Commom Info ..., iOSDCommonPosition [%d] \n", iOSDCommonPosition);
    // OSD默认(时间)水印格式    参考: EN_ZJ_OSD_TIMEFORMAT_TYPE
    __INFO_PRINTF("device video recv set OSD Commom Info ..., iOSDCommonFormat   [%d] \n", iOSDCommonFormat);
    return 0;
}

/**
*流媒体需要一个I帧回调接口，告知设备当前流需要一个关键帧； EN_ZJ_KEYFRAME_QUALITY
*/
int video_NeedIframe_cb(int iStreamID,unsigned int uiKeyQuality)
{
    __INFO_PRINTF("device video need i frame ...\n");
    switch (uiKeyQuality)
    {
        case EN_ZJ_KEYFRAME_QUALITY_NORMAL://标准质量
            __INFO_PRINTF("device video stream id [%d] need i frame quality is normal\n", iStreamID);
            break;
        case EN_ZJ_KEYFRAME_QUALITY_LOW:// 低质量
            __INFO_PRINTF("device video stream id [%d] need i frame quality is low\n", iStreamID);
            break;
        default:
            __INFO_PRINTF("device video need i frame failed\n");
            return -1;
    }
     __INFO_PRINTF("device video need i frame ok\n");
    return 0;
}

/**
*视频编码开关回调， 该路视频开始编码/结束编码 0. 结束； 1.开始
*如有两路码流，需要根据不同的stream id进行切换。
*/
int video_EncodeSwitch_cb(int iStreamID, int iState)
{
    switch (iStreamID)
    {
    case 0: //超清
        if(iState)
        {
            g_iVideoMainEncode = 1;//示例：控制视频流是否写入SDK中
            __INFO_PRINTF("device video stream id [%d] start encode\n", iStreamID);
        }
        else
        {
            g_iVideoMainEncode = 0;//示例：控制视频流是否写入SDK中
            __INFO_PRINTF("device video stream id [%d] stop encode\n", iStreamID);
        }
        break;
    case 1://高清
          if(iState)
        {
            g_iVideoSecEncode = 1;//示例：控制视频流是否写入SDK中
            __INFO_PRINTF("device video stream id [%d] start encode\n", iStreamID);
        }
        else
        {
            g_iVideoSecEncode = 0;//示例：控制视频流是否写入SDK中
            __INFO_PRINTF("device video stream id [%d] stop encode\n", iStreamID);
        }
        break;
    break;
    default:
        break;
    }
    return 0;
}

/**
*流媒体码流需要调节回调接口，告诉设备当前流媒体要调节； 
*iAdjust: -10~10; 当为负数时为降低，负的越多降码率越大；
*当为正数时提升，正的越大升码率越大；
*/
int video_Adjust_cb(int iStreamID, int iAdjust)
{
    __INFO_PRINTF("device video set adjust stream id [%d] adjust [%d]\n", iStreamID, iAdjust);
    return 0;
}

/**
*这是设置视频采集参数的回调函数
*/
int video_SetParm_cb(int iStreamID,ST_ZJ_VIDEO_PARAM *pstVideoParm)
{
    pstVideoParm->uiWidth  = 1920;
    pstVideoParm->uiHeight = 1080;
    __INFO_PRINTF("device video set parm stream id [%d]: \n", iStreamID);
    __INFO_PRINTF("     resolution: [%u]\n", pstVideoParm->uiResolution);
    __INFO_PRINTF("          width: [%u]\n", pstVideoParm->uiWidth);
    __INFO_PRINTF("         height: [%u]\n", pstVideoParm->uiHeight);
    __INFO_PRINTF("     encodeType: [%u]\n", pstVideoParm->uiEncodeType);
    __INFO_PRINTF(" smart enc flag: [%u]\n", pstVideoParm->uiSmartEncFlag);
    __INFO_PRINTF("        quality: [%u]\n", pstVideoParm->uiQuality);
    __INFO_PRINTF("        bitrate: [%u]\n", pstVideoParm->uiBitrate);
    __INFO_PRINTF("      framerate: [%u]\n", pstVideoParm->uiFramerate);
    __INFO_PRINTF(" frame interval: [%u]\n", pstVideoParm->uiFrameInterval);
    __INFO_PRINTF("      rate type: [%u]\n", pstVideoParm->uiRateType);

    /**
     * 示例仅供参考
    */
    //重置编码参数，一般是改变了采集分辨率和编码方法
    ZJ_Video_ResetParam(iStreamID, pstVideoParm);
    /***********/
    return 0;
}

/**
 * 双向视频通话测试参考用例
*/
static void* device_VideoStreamToPlayLoop(void *argv)
{
    pthread_detach(pthread_self());
    int iDataLen;
    int is_keyframe;
    unsigned char *ucVideoData;
    unsigned int uiTimestamp;

    while(st_hHander.iRun == 1)
    {
        /*
            获取对端双向视频通话数据
        */
        ZJ_GetVideoData(&ucVideoData, &iDataLen, &is_keyframe, &uiTimestamp);
        if(iDataLen > 0)
        {
            __INFO_PRINTF("device video recv stream data, size [%d] is_keyframe[%u] uiTimestamp[%u]\n", iDataLen, is_keyframe, uiTimestamp);
            /*
            设备语音可在此处进行播放
            */
        }
        else
        {
            //printf("%s %d readSize:%d\n", __FUNCTION__, __LINE__, iDataLen);
            usleep(10*1000);
        }
        //
    }
    st_hHander.iRun = 0;
    printf("exit audio thread %s %d s\n", __FUNCTION__, __LINE__);
    return NULL;
}

/**
* 摄像头有逆向视频流传入回调接口，告诉设备有逆向视频流传入；iStatus(1. Start; 0. Stop)
*/
int video_StreamToPlay_cb(const char* pcPeerID, int iStatus)
{
    if(iStatus)
    {
        pthread_t hPthread;
        ST_ZJ_VIDEO_PARAM stVideoParam = {0};
        st_hHander.iRun = 1;
        if (pcPeerID != NULL)
        {
            memcpy(st_hHander.pcPeerID,pcPeerID,sizeof(st_hHander.pcPeerID));
        }
        __INFO_PRINTF("device video start stream to play\n");
        /*
            获取双向视频的视频显示参数
        */
        ZJ_GetVideoaram(&stVideoParam);
        __INFO_PRINTF("device video encode param:\n");
        __INFO_PRINTF("             uiEncodeType: %u\n", stVideoParam.uiEncodeType);
        __INFO_PRINTF("             uiResolution: %u\n", stVideoParam.uiResolution);
        __INFO_PRINTF("             uiWidth:      %u\n", stVideoParam.uiWidth);
        __INFO_PRINTF("             uiHeight:     %u\n", stVideoParam.uiHeight);

        //创建双向视频获取视频流线程
        pthread_create( &hPthread, NULL, device_VideoStreamToPlayLoop, NULL);
    }
    else
    {
    	st_hHander.iRun = 2;//设置为2，等待线程退出(注意:需要确保线程退出后再return)
		int i = 200;
		while(i>0)
		{
			if(st_hHander.iRun == 0)
			{
				break;
			}
			i--;

			usleep(10);
		}

        st_hHander.iRun = 0;
        memset(st_hHander.pcPeerID,0,sizeof(st_hHander.pcPeerID));

        __INFO_PRINTF("device video end stream to play\n");
    }
    return 0;
}

int video_init(void)
{
    __INFO_PRINTF("device video init \n");
    ST_ZJ_VIDEO_PARAM stMainVideo;
    memset(&stMainVideo, 0, sizeof(stMainVideo));
    ST_ZJ_VIDEO_PARAM stSubVideo;
    memset(&stSubVideo, 0, sizeof(stSubVideo));

 
    /*主码流，设置分辨率能力集；支持多种按位与 EN_ZJ_CARERA_RESOLUTION_ABILITY 必须设置*/
    ZJ_SetResolutionAbility(EN_VIDEO_MAIN, EN_ZJ_CARERA_RESOLUTION_ABILITY_360P|EN_ZJ_CARERA_RESOLUTION_ABILITY_1080P \
    |EN_ZJ_CARERA_RESOLUTION_ABILITY_720P|EN_ZJ_CAMERA_RESOLUTION_ABILITY_600W);

    /*主码流，设置编码能力；支持多种按位与 见：EN_ZJ_VIDEOENC_TYPE 必须设置*/
    ZJ_SetVideoEncodeAbility(EN_VIDEO_MAIN, EN_ZJ_VIDEOENC_TYPE_H264|EN_ZJ_VIDEOENC_TYPE_H265);
    
    /*stream 数量必须设置，例如：为1仅有1路码流为主码流了，为2是为主次码流*/
    ZJ_SetStreamCount(2);

    stMainVideo.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_128K; 
    stMainVideo.uiEncodeType = EN_ZJ_VIDEOENC_TYPE_H265;
    stMainVideo.uiQuality = EN_ZJ_KEYFRAME_QUALITY_NORMAL;
    stMainVideo.uiResolution = EN_ZJ_CARERA_RESOLUTION_ABILITY_1080P;
    stMainVideo.uiSmartEncFlag = 1;
    stMainVideo.uiRateType = 0;
    stMainVideo.uiFrameInterval = 5;
    stMainVideo.uiFramerate = 15;
    stMainVideo.uiHeight =1080 ;
    stMainVideo.uiWidth = 1920;
    ZJ_SetVideoEncParam(EN_VIDEO_MAIN,  &stMainVideo);/*主码流配置*/


    stSubVideo.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_128K;
    stSubVideo.uiEncodeType = EN_ZJ_VIDEOENC_TYPE_H264;
    stSubVideo.uiQuality = EN_ZJ_KEYFRAME_QUALITY_NORMAL;
    stSubVideo.uiResolution = EN_ZJ_CARERA_RESOLUTION_ABILITY_360P;
    stSubVideo.uiSmartEncFlag = 1;
    stSubVideo.uiRateType = 0;
    stSubVideo.uiFrameInterval = 5;
    stSubVideo.uiFramerate = 25;
    stSubVideo.uiHeight = 480;
    stSubVideo.uiWidth = 640;
    ZJ_SetVideoEncParam(EN_VIDEO_SUB,  &stSubVideo);/*次码流配置*/

    /*画面翻转回调接口注册，告诉设备画面进行翻转*/	 
    ZJ_SetImageInversionCB(video_ImageInversion_cb);

    /* WDR */
    ZJ_SetCamWdrOpenFlagCB(video_wdr_cb);

    /*设置OSD能力值*/
    ZJ_SetOSDSetAbility(1);
    /*设置OSD自定义(文本)水印信息*/
    ZJ_SetOSDSettingCB(video_osdinfo_cb);
    /*设置OSD自定义(文本)/默认(时间)显示状态*/
    ZJ_SetShowTimeOSDCB(video_osdTimedisplay_cb, video_osdCustomdisplay_cb);

    /*设置OSD拓展能力值-支持同时四角显示水印*/
    ZJ_SetCustomOSDExpandAbility(1);
    /*设置OSD自定义(文本)展示模式回调函数 0-只显示一个位置水印，1-同时四角水印显示*/
    ZJ_SetCustomOSDModeCB(video_osdCustomMode_cb);

    /*OSD默认(时间)水印设置能力 0.不支持，1.支持（支持0-10十一种水印格式）,预留2、3支持更多时间水印格式*/
    ZJ_SetOSDCommonSetAbility(1);
    /*设置OSD默认(时间)水印信息*/
    ZJ_SetOSDCommonSettingCB(video_osdcommoninfo_cb);

    /*强制I帧回调接口*/	 
    ZJ_SetVideoNeedIFrameCB(video_NeedIframe_cb);

    /*视频编码开关回调接口注册 通过该接口控制视频是否编码*/
    ZJ_SetVideoEncSwitchCB(video_EncodeSwitch_cb);

    /*获取抓图图片*/
    ZJ_Video_SetGetJpegCB(device_VideoSnap_cb);

    //设置视频编码参数
    ZJ_SetVideoEncParamCB(video_SetParm_cb);

    /*双向视频接收回调接口*/  
    ZJ_SetVideoToPlayCB(video_StreamToPlay_cb);

    // 设置多目摄像头
    ZJ_SetCameraMultiFocalLenthAbility(0);

    // 设置最大通道数，默认为1
    ZJ_SetMaxChnNum(1);

    /*设置具备屏幕能力 0.不支持；1.支持*/
    ZJ_SetWithScreenAbility(0);

    /*设置双向视频通话能力 0.不支持；1.支持*/
    ZJ_SetVideoPlayAbility(0);

    /*设置呼出物理按键能力 0.不支持；1.支持*/
    ZJ_SetCallButtonAbility(0);

    /*设置挂断物理按键能力 0.不支持；1.支持*/
    ZJ_SetHangUpButtonAbility(0);

    /*双向视频通话对端出流支持能力信息集合*/
    ST_ZJ_VIDEOPLAY_SUPPORT_INFO pstVideoPlaySupportAbility = {0};
    pstVideoPlaySupportAbility.uiResolutionAbility = EN_ZJ_CARERA_RESOLUTION_ABILITY_1080P|EN_ZJ_CARERA_RESOLUTION_ABILITY_360P; 
    pstVideoPlaySupportAbility.uiVideoEncAbility   = EN_ZJ_VIDEOENC_TYPE_H264|EN_ZJ_VIDEOENC_TYPE_H265;
    pstVideoPlaySupportAbility.uiMaxBitRate        = EN_ZJ_CAMERA_BITRATE_TYPE_1024K;
    ZJ_SetVideoPlaySupportAbility(&pstVideoPlaySupportAbility);

    /*设置带屏设备屏幕硬件属性*/
    ST_ZJ_SCREEN_HARDWARE_INFO pstScreenHardwareInfo = {0};
    pstScreenHardwareInfo.dScreenSize        = 15.60; 
    pstScreenHardwareInfo.uiResolution       = EN_ZJ_CARERA_RESOLUTION_ABILITY_1080P;
    pstScreenHardwareInfo.uiWidth            = 1920;
    pstScreenHardwareInfo.uiHeight           = 1080; 
    pstScreenHardwareInfo.uiDpi              = 100;
    pstScreenHardwareInfo.uiSupportTouchFlag = 0;
    ZJ_SetScreenHardwareInfo(&pstScreenHardwareInfo);

    /*设置双向视频通话对端出流信息*/ 
    ST_ZJ_VIDEO_PARAM pstVideoPlayInfo  = {0};
    pstVideoPlayInfo.uiResolution       = EN_ZJ_CARERA_RESOLUTION_ABILITY_360P;
    pstVideoPlayInfo.uiWidth            = 640; 
    pstVideoPlayInfo.uiHeight           = 360 ;
    pstVideoPlayInfo.uiEncodeType       = EN_ZJ_VIDEOENC_TYPE_H264;
    pstVideoPlayInfo.uiBitrate          = EN_ZJ_CAMERA_BITRATE_TYPE_384K; 
    pstVideoPlayInfo.uiFramerate        = 15;
    pstVideoPlayInfo.uiFrameInterval    = 30;
    pstVideoPlayInfo.uiQuality          = EN_ZJ_KEYFRAME_QUALITY_NORMAL;
    pstVideoPlayInfo.uiRateType         = 0;
    pstVideoPlayInfo.uiSmartEncFlag     = 0;
    ZJ_SetVideoPlayInfo(&pstVideoPlayInfo);

    __INFO_PRINTF("device video init ok###\n");
    return 0;
}

int video_start(void)
{
    pthread_t tidp;
    __INFO_PRINTF("device video start\n");
    if(-1 == pthread_create(&tidp, NULL, video_loop, "0"))
    {
        __ERROR_PRINTF("device create video thread failed\n");
        return -1;
    }
    if(-1 == pthread_create(&tidp, NULL, video_loop, "1"))
    {
        __ERROR_PRINTF("device create video thread failed\n");
        return -1;
    }
    return 0;
} 


