
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include "zj_type.h"
#include "zj_log.h"
#include "zj_camera.h"  
#include "zj_cameraiot.h"

#include "type.h"
#include "log.h"
#include "audio.h"
#include "video.h"
#include "system.h"

struct ST_VOICEPLAY
{
    int  iRun;
    const char *pcPeerID;
    ZJ_HANDLE hPlayHandle;
};
struct ST_VOICEPLAY st_hHander = {0};
static int g_iAudioEncode = 0;
/**
* 音频数据采集SDK输入示例
*/
typedef struct AudioTimeInfo
{
    unsigned int count_times;
    unsigned int last_timestamps;
    unsigned int diff_timestamps;
}AudioTimeInfo;

extern unsigned long long int util_GetTickCount();
AudioTimeInfo readaInfo = {0, 0, 0};
static int audio_exeUpload(char *audioFilePath){
    FILE *faudio  = NULL;
    char *pbufAudio = NULL;
    int is_first = 0;
    // unsigned int uiAudioStamp = 0;
    int audioSize = 320;
    faudio  = fopen(audioFilePath,"rb"); 
    if(NULL==faudio)
    {
        __ERROR_PRINTF("device audio open file failed!\n");
        return -1;
    }
    pbufAudio = (char *)malloc(audioSize);
    if(NULL==pbufAudio)
    {
        __ERROR_PRINTF("device audio malloc failed!\n");
        return -1;
    }

    unsigned int uLastTimeStamp = 0;
    while( fread(pbufAudio, 1, audioSize, faudio)!= 0 )
    {
        unsigned int ulltimestamp = 0;
        //uiAudioStamp++;
        //ulltimestamp = uiAudioStamp*25+61317904;

        ulltimestamp = getCurrentDayMsec();//util_GetTickCount();
        /*音频采集输入 buf大小为audioSize*/
        if(g_iAudioEncode)
        {
            //ulltimestamp += (readaInfo.diff_timestamps*readaInfo.count_times);
            ZJ_Audio_WriteFrame((unsigned char *)pbufAudio, audioSize, (unsigned int)ulltimestamp);

            if (is_first)
            {
                uLastTimeStamp = (unsigned int)ulltimestamp;
                is_first = 0;
            }
            readaInfo.last_timestamps = ulltimestamp - uLastTimeStamp;
        }
        memset(pbufAudio, 0, audioSize);
        usleep(40*1000);
    }
    readaInfo.diff_timestamps = readaInfo.last_timestamps;
    readaInfo.count_times++;
    fclose(faudio);
    free(pbufAudio);
    pbufAudio = NULL;
    return 0;
}

/**
* 音频数据采集SDK输入示例线程
*/
static void *audio_loop()
{
    int iDeviceIAwakeFlag = 0;
    ZJ_LOG_INF("device audio start audio loop");
    while(1)
    {
        if(0 != audio_exeUpload(DEVICE_AUDIO_FILE_PATH))
        {
            ZJ_LOG_INF("device audio upload failed\n");
        }

        usleep(40000);
    }
    return 0;
}

/**
*这是设置音频采集参数的回调函数
*/
int audio_SetParm_cb(ST_ZJ_AUDIO_PARAM *pstAudioParm)
{
    __INFO_PRINTF("     uiChannel:      [%u]\n", pstAudioParm->uiChannel);
    __INFO_PRINTF("     uiDepth:        [%u]\n", pstAudioParm->uiDepth);
    __INFO_PRINTF("     uiEncodeType:   [%u]\n", pstAudioParm->uiEncodeType);
    __INFO_PRINTF("     uiSampleRate:   [%u]\n", pstAudioParm->uiSampleRate);

    /**
     * 示例仅供参考
    */
    //重置音频编码参数
    ZJ_Audio_ResetParam(pstAudioParm);
    /***********/
    return 0;
}

/**
* 音频编码开关回调， 音频开始编码/关闭编码 0. 结束； 1.开始
*/
int audio_EncodeSwitch(int iState)
{
    if(iState)
    {
        g_iAudioEncode = 1;
        __INFO_PRINTF("device audio start encode\n");
    }
    else
    {
        g_iAudioEncode = 0;
        __INFO_PRINTF("device audio stop encode\n");
    }
    return 0;
}


/**
 * 语音对讲测试参考用例
*/
static void* device_VoiceToPlayLoop(void *argv)
{
    pthread_detach(pthread_self());
    int iDataLen;
    unsigned char *ucAudioData;
    unsigned int uiTimestamp;

    while(st_hHander.iRun)
    {
        /*
            获取APP端语音对讲数据
        */
        ZJ_GtMediaAudioData(st_hHander.hPlayHandle, &ucAudioData, &iDataLen, &uiTimestamp);
        if(iDataLen > 0)
        {
            __INFO_PRINTF("device audio recv voice data, size [%d] uiTimestamp[%u]\n", iDataLen, uiTimestamp);
            /*
            设备语音可在此处进行播放
            */
        }
        else
        {
            //printf("%s %d readSize:%d\n", __FUNCTION__, __LINE__, iDataLen);
            usleep(10*1000);
        }
        //
    }
    printf("exit audio thread %s %d s\n", __FUNCTION__, __LINE__);
    return NULL;
}


/**
* 摄像头有逆向流传入回调接口，告诉设备有逆向媒体流传入； 1. Start; 0. Stop; iStreamType:EN_ZJ_STREAMER_TYPE
*/
int audio_VoiceToPlay_cb(const char* pcPeerID, ZJ_HANDLE hPlayHandle, int iStreamType, int iStatus)
{
    if(iStatus)
    {
        pthread_t hPthread;
        ST_ZJ_AUDIO_PARAM stAudioParam = {0};
        st_hHander.pcPeerID = pcPeerID;
        st_hHander.hPlayHandle  =  hPlayHandle;
        st_hHander.iRun = 1;
        __INFO_PRINTF("device audio start voice to play , iStreamType [%d]\n", iStreamType);
        /*
            获取语音对讲的音频参数
        */
        ZJ_GetMediaAudioParam(st_hHander.hPlayHandle , &stAudioParam);
        __INFO_PRINTF("device audio encode param:\n");
        __INFO_PRINTF("             uiEncodeType: %u\n", stAudioParam.uiEncodeType);
        __INFO_PRINTF("             uiSampleRate: %u\n", stAudioParam.uiSampleRate);
        __INFO_PRINTF("                uiChannel: %u\n", stAudioParam.uiChannel);
        __INFO_PRINTF("                  uiDepth: %u\n", stAudioParam.uiDepth);

        //创建语音对讲线程
        pthread_create( &hPthread, NULL, device_VoiceToPlayLoop, NULL);
    }
    else
    {
        st_hHander.pcPeerID = NULL;
        st_hHander.hPlayHandle  =  NULL;
        st_hHander.iRun = 0;
         __INFO_PRINTF("device video start voice to play , iStreamType [%d]\n", iStreamType);
    }
    return 0;
}


/**
* 音频音量调节回调接口，告诉设备要将音量大小; 0~100。 0为静音；100为最大声音
*/
int audio_VolumAdjust_cb(int iMicId, int iVolumn)
{
    __INFO_PRINTF("device audio set iMicId [%d] volum adjust [%d]\n", iMicId, iVolumn);
    /*配置成功后，设置设置当前音量大小 */
    ZJ_SetAudioVolumn(iVolumn); 
    return 0;
}


int audio_init()
{
    __INFO_PRINTF("device audio init\n");
    ST_ZJ_AUDIO_PARAM   stAudioParam;
    stAudioParam.uiEncodeType = EN_ZJ_AUDIOENC_TYPE_G711A;
    stAudioParam.uiSampleRate = 8000;
    stAudioParam.uiChannel = 1;
    stAudioParam.uiDepth = 16;
    /*设置编码参数*/
    ZJ_SetAudioEncParm(&stAudioParam);

    /*设置咪头打开标志*/   
    if(ZJ_GetCameraMicOpenFlag() == 0)
    {
        ZJ_SetCamerMicOpenFlag(1);
    }
    
     /*设置音频文件存储路径*/    
    ZJ_SetDevSoudFilePath(DEVICE_AUDIO_PATH);

    //设置音频编码参数
    ZJ_SetAudioEncParamCB(audio_SetParm_cb); // typedef int (*ZJ_PFUN_SET_AUDIO_PARM)(ST_ZJ_AUDIO_PARAM *pstAudioParm);

    /*设置音频编码开关*/    
    ZJ_SetAudioEncSwitchCB(audio_EncodeSwitch);

     /*语音对讲接收回调接口*/  
    ZJ_SetMediaToPlayCB(audio_VoiceToPlay_cb);

    //设置音频采集/播放音量调节接口 通过该接口调节音量
    ZJ_SetAudioVolumnCB(audio_VolumAdjust_cb);

    //支持云广播功能
    ZJ_SetCloudBroadcastAbility(0);    
    
    return 0;
}

int audio_start()
{
    pthread_t tidp;
    ZJ_LOG_INF("device audio start \n");
    if(-1 == pthread_create(&tidp, NULL, audio_loop, NULL))
    {
        ZJ_LOG_INF("device audio create pthread failed\n");
        return -1;
    }
    return 0;
}


