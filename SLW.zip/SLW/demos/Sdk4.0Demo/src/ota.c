#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "zj_type.h"
#include "zj_log.h"
#include "zj_ota.h"

#include "type.h"
#include "log.h"
#include "ota.h"

/**
 * 设备版本状态回调接口，告诉设备当前版本升级状态
 */ 
int ota_newversion_notice_cb(unsigned char *pucNewVersion,unsigned int uiFileSize)
{
    if(pucNewVersion == NULL || uiFileSize<=0)
    {
        __ERROR_PRINTF("device ota recv new version failed, version[%p] size [%u]\n", pucNewVersion, uiFileSize);
        return -1;
    }
    __INFO_PRINTF("device ota recv new version notice ... , version [%s] size [%u]",  pucNewVersion, uiFileSize);
    
    /**
     * 升级时，释放相关资源。SDK不可以释放否则无法正常升级
     */

    /**
     * 设备已经准备完毕，开始进行升级
    */
    ZJ_StartUpdate();
    __INFO_PRINTF("device ota recv new version notice ok start upgrade, start update version [%s] size [%u]", pucNewVersion, uiFileSize);
    return 0;
}

/**
 * 设备版本状态回调接口，告诉设备当前版本升级状态
 */ 
int ota_newversion_datadown_cb(unsigned char *pucPackage,unsigned int uiPacklen,unsigned int uiEndFlag)
{
    static int iDownloadFlag = 0;
    static int iPackCount = 0;
    static int iPackSize = 0;
    if(iDownloadFlag == 0)
    {
        iDownloadFlag = 1;
        __INFO_PRINTF("device ota start download update pack ...");
    }
    //__INFO_PRINTF("device ota download firmware pack ..., pack len [%d] end flag [%d]", uiPacklen, uiEndFlag);
    iPackCount += 1;
    iPackSize += (int)uiPacklen;
   
    /**
     * 将收到的升级包分片依次缓存下来
    */

    if(uiEndFlag == 1)
    {
        __INFO_PRINTF("device ota download update pack write complete, pack count [%d] pack len[%d]",iPackCount, iPackSize);
        /**
         * 升级包下载完成，升级进度为70%，需要上报为70；
        */
        ZJ_SetBurnningProgress(70);
    }
    return 0;
}

/**
 * 停止下载文件并释放升级包占用的空间
 */ 
int ota_stopupgrade_cb()
{
    /**
     * 停止升级，删除升级包缓存内存，重启设备
    */
    __INFO_PRINTF("device ota stop upgrade \n");
    return 0;
}

/**
 * 1 校验成功，通知固件覆盖镜像、 0 校验不成功，释放占用空间并重启
 */ 
int ota_coverimage_notice_cb(unsigned int uiCoverFlag)
{   
    int i = 70;
    if(uiCoverFlag)
    {
        /**
         * 开始固件覆盖，固件覆盖进度需要上报，从70-100进行上报
        */
       while(i<100)
       {
           i += 5;
           /**
            * 升级进度上报100后，升级成功，部分设备升级完成会直接重启，可以重启后直接上报进度100完成升级
            * 若是升级失败 ZJ_SetBurnningProgress(0);
           */
           ZJ_SetBurnningProgress(i);
           sleep(1);
       }
    }
    return 0;
}


int ota_init()
{ 
    __INFO_PRINTF("device ota init \n");
    /*设置设备升级状态回调函数注册，通过回调返回升级状态；设备上层收到后，启用升级程序下载升级固件*/
    ZJ_SetOtaCBFuncs(ota_newversion_notice_cb, 
                     ota_newversion_datadown_cb, 
                     ota_stopupgrade_cb,
                     ota_coverimage_notice_cb);

     return 0;
}

int ota_start()
{

    return 0;
}