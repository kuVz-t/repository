#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "zj_channel.h"
#include "zj_log.h"
#include "zj_network.h"
#include "zj_ota.h"
#include "zj_power.h"
#include "zj_system.h"
#include "zj_err.h"

#include "log.h"
#include "type.h"
#include "video.h"
#include "audio.h"
#include "iot.h"
#include "system.h"
#include "ptz.h"
#include "ota.h"
#include "ai.h"

static int g_Exit = 0;

ZJ_HANDLE g_hPlayHandle;

static void signal_Termination(int sign)
{
    switch (sign)
    {
    case SIGINT/* constant-expression */:
        g_Exit = 1;
        ZJ_LOG_INF("device stop run,catch signnal %u ",sign);
        break;
    
    default:
        ZJ_LOG_INF("catch signnal %u ",sign);
        break;
    }
}

int make_path()
{
    char acCmd[1280] = {0};
    int ret = 0;
    if(access(DEVICE_SYSTEM_PATH, F_OK) != 0)
    {
        memset(acCmd, 0, sizeof(acCmd));
        sprintf(acCmd, "mkdir -p %s", DEVICE_SYSTEM_PATH);
        ret = system(acCmd);
    }
    if(access(DEVICE_CONFIG_PATH, F_OK) != 0)
    {
        memset(acCmd, 0, sizeof(acCmd));
        sprintf(acCmd, "mkdir -p %s", DEVICE_CONFIG_PATH);
        ret = system(acCmd);
    }
    if(access(DEVICE_AUDIO_PATH, F_OK) != 0)
    {
        memset(acCmd, 0, sizeof(acCmd));
        sprintf(acCmd, "mkdir -p %s", DEVICE_AUDIO_PATH);
        ret = system(acCmd);
    }
    if(access(DEVICE_TFCARD_PATH, F_OK) != 0)
    {
        memset(acCmd, 0, sizeof(acCmd));
        sprintf(acCmd, "mkdir -p %s", DEVICE_TFCARD_PATH);
        ret = system(acCmd);
    }
    __INFO_PRINTF("%d\n", ret);
    return 0;
}

#include "time.h"
unsigned int getCurrentDayMsec()
{
    struct timeval unix_time = {0,0};
    gettimeofday(&unix_time, NULL);
    struct tm *date = localtime(&unix_time.tv_sec);
    unsigned int ms = (date->tm_hour * 3600 + date->tm_min * 60 + date->tm_sec) * 1000;
    ms += (unix_time.tv_usec / 1000);
    return ms;
}

int main(int argc, char *argv[]){
    signal(SIGPIPE, SIG_IGN);
    signal(SIGINT, signal_Termination);
    make_path();
    //设置设备运行工作环境，1、生产环境，0、测试环境, zj_init前调用
    ZJ_SetSdkRunMode(0);
    /**
    初始化SDK，并配置SDK配置文件存储路径, 
    注意： SDK配置初始化包括音视频等、回调函数注册、
           设备能力集配置、IOT设备添加等均需要在SDK Init后
           SDK Start之前完成。
    ZJ_Init路径配置说明：
    DEVICE_SYSTEM_PATH为核心配置路径，不可以删除
    DEVICE_CONFIG_PATH为常规配置文件路径，恢复出厂设置时需要删除该路径下所有文件
    */
    ZJ_Init(DEVICE_SYSTEM_PATH, DEVICE_CONFIG_PATH);

    /**
     * 开启SDK打印， 1打开 0 关闭
     */
    ZJ_SetDebugMode(1);

    /**
     * 设置log打印等级
     */
    ZJ_SetDebugLevel(EN_ZJ_LOG_LVL_ALL);

    /**
     * 设置固件版本号
     */
    ZJ_SetAppVersion("xxxxxxxxxxxx"); 

    /**
     * CTEI UID DeviceModel设置
     */
    ZJ_SetCTEIID((unsigned char *)"xxxxxxxxxxxx");
    ZJ_SetDeviceModel((unsigned char *)"xxxxxxxxxxxx");
	ZJ_SetSN((unsigned char *)"xxxxxxxxxxxx");             /*没有SN码可以使用设备uid代替*/
    ZJ_SetDeviceUID((unsigned char *)"3xxxxxxxxxxxxxx",(unsigned char *)"xxxxxxxxxx");
     // ZJ_SetDeviceUID((unsigned char *)"3xxxxxxxxxxxxxx",(unsigned char *)"xxxxxxxxxx");

    /**
     * 网络发生变化时需要设置一下网络状态，相同的网络类型网络发生变化也需要设置，包括无网络状态
     */
    ZJ_SetNetWorkType(EN_ZJ_NETWORK_TYPE_WIRED);

    /**
     * 普通IPC设备都是不支持唤醒；
     * 低功耗设备设置，设置休眠能力，如设置为非EN_ZJ_AWAKE_ABILITY_NOTSUPPORT，sdk会回调休眠唤醒间隔函数给厂商
     */
    ZJ_SetAwakeAbility(EN_ZJ_AWAKE_ABILITY_NOTSUPPORT);
    
    /*-----------------------*/
    /**
     * 初始化并启动测试用例
     */

#if 1
    video_init();
    audio_init();
    ptz_init();
    ai_init();
    iot_init();
    system_init();
    ota_init();
    
    video_start();
    audio_start();
    iot_start();
    system_start();
    ptz_start();
    ota_start();
    ai_start();
#endif
    /*-----------------------*/

    /**
     * 启动SDK
     */
    ZJ_Start();
    printf("-------ZJ_Start END-------------\r\n");

    while(!g_Exit)
    {
        usleep(1*1000*1000);
    }
     /*停止SDK运行*/
    ZJ_Stop();
     /*释放占用资源*/
    ZJ_Destroy();
    return 0;
}
