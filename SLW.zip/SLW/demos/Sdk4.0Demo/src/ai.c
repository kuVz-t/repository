#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "zj_type.h"
#include "zj_log.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "watchdog_api.h"
#include "kj_timer.h"
#include "zj_aicamera.h"

#include "type.h"
#include "log.h"
#include "ai.h"


// 创建识别底库集,一个pucLabelID可对应多张picid ,iLableType 1 人脸  2 牌照, uiWBList 1黑名单 2白名单
int ai_CreateLabelCb(unsigned char *pucLabelID,int iLableType, unsigned int uiWBList)
{
    __INFO_PRINTF("ai_CreateLabelCb pucLabelID:%s iLableType:%d uiWBList:%u\n", pucLabelID, iLableType, uiWBList);
    
    return 0;
}

// 提取布控图片特征值
int ai_AddSingleAiPicCb(unsigned char *pucLabelID, unsigned char *pucPicID, unsigned char *pucAIPicFile)
{
    __INFO_PRINTF("ai_AddSingleAiPicCb pucLabelID:%s pucPicID:%s pucAIPicFile:%s TODO \n", pucLabelID, pucPicID, pucAIPicFile);
    
    // TODO 提取布控图片特征值
    return 0;
}

// 删除布控图片的特征值
int ai_DelSingleAiPicCb(unsigned char *pucLabelID,unsigned char *pucPicID)
{
    __INFO_PRINTF("ai_DelSingleAiPicCb pucLabelID:%s pucPicID:%s TODO \n", pucLabelID, pucPicID);
    
    // TODO 删除布控图片的特征值
    return 0;
}

// 释放上报人脸图和背景图的缓存
int ai_FreeAiPicCacheCb(unsigned char *pucPicID, unsigned char *pucFaceData, unsigned char *pucBgData)
{
    __INFO_PRINTF("ai_FreeAiPicCacheCb pucPicID:%s pucFaceData:%s pucBgData:%s TODO \n", pucPicID, pucFaceData, pucBgData);
    
    return 0;  
}

/**
 *  设置GAT1400
 */
int video_set_ga1400switch_cb(unsigned int uiGa1400Switch)
{
    __INFO_PRINTF("uiGa1400Switch:%u \n", uiGa1400Switch);

    //TODO: 配置GAT1400开关
    return 0;
}

int video_set_ga1400info_cb(unsigned char *pucGa1400ID, unsigned char *pucDomain)
{
    __INFO_PRINTF("pucGa1400ID:%s  pucDomain:%s \n", pucGa1400ID, pucDomain);

    //TODO: 配置GAT1400参数
    return 0;
}

int video_set_ga1400status_cb(unsigned int uiGa1400Status)
{
    __INFO_PRINTF("uiGa1400Status:%u \n", uiGa1400Status);

    //TODO: 配置GAT1400在线状态
    return 0;
}

/**
*AI布控图片比对消息上报线程
*/
static void *ai_loop(void *arg)
{
    int iAiComparison = 1; //AI比对能力
    __INFO_PRINTF("ai loop thread start ok,##### \n");

    while(1)
    {
        /*上传操作在iot.c iot_loop函数中实现*/
        if (iAiComparison == 1) // 布控和识别只支持一种 带AI比对能力的推荐布控
        {
        }
        else
        {
        }

        usleep(40000);
    }

    __INFO_PRINTF("ai loop thread start exit\n");
    return 0;
}

int ai_init()
{
    // AI旧人脸布控能力（对接新人脸时该接口不能调用）0.不支持；1.支持 
    ZJ_SetDevAiFaceAbility(1);

    // AI 设备支持的最大布控底图数目（为黑/白名单相加）
    ZJ_SetAiMaxPicNum(100);

    // AI 设备当前布控地图数目（为黑/白名单相加）
    ZJ_SetAiCurPicNum(10);

    // 客流统计能力
    ZJ_SetHumCountAbility(1);

    // 云化摄像头能力   0.不支持；1.支持
    ZJ_SetCloudCameraAbility(1);

    // 设置布控人脸图片缓存路径
    ZJ_SetFaceFileCachePath((unsigned char *)DEVICE_AIPIC_PATH);

    // AI口罩识别能力    0.不支持；1.支持
    ZJ_SetDevAiMaskDiscernAbility(1);
    // AI电瓶车识别能力   0.不支持；1.支持
    ZJ_SetDevAiBatteryBikeAbility(1);
    // AI高空抛物识别能力 0.不支持；1.支持
    ZJ_SetDevAiHighParabolicAbility(1);
    // AI烟火识别能力 0.不支持；1.支持
    ZJ_SetDevAiFlameAlarmAbility(1);

    // Ai事件注册回调设置
    ZJ_SetAiPicCB(ai_CreateLabelCb, NULL, ai_AddSingleAiPicCb, ai_DelSingleAiPicCb, NULL);
    // 注册回调：释放上报人脸图和背景图的缓存
    ZJ_SetFreeAiPicCacheCB(ai_FreeAiPicCacheCb);

    /**
     * 设置GAT1400回调接口
     */
    ZJ_SetGat1400Ability(1);
    ZJ_SetGa1400CB(video_set_ga1400switch_cb, video_set_ga1400info_cb, video_set_ga1400status_cb);

    return 0;
}
static void *monitor_task_loop(void *arg)
{
    ZJ_HANDLE    test;
    kj_timer_t    tConfigFeedDogTimeOut;
    test = ZJ_AppThreadMonitorRegist("monitor", FEED_DOG_SUPER_MAX_TIMESEC);
    kj_timer_init(&tConfigFeedDogTimeOut);
    getDiffTimems(&tConfigFeedDogTimeOut,  1, 1, 60*10);

    while (1)
    {
        // 软看门狗检测喂狗  喂狗不能太频繁  建议1~3秒一次
        if (getDiffTimems(&tConfigFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) > FEED_DOG_TIMEOUT_SEC)
        {
            ZJ_AppThreadMonitorFeedDog(test);
            getDiffTimems(&tConfigFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
            __INFO_PRINTF("ZJ_Swd_AppThreadFeedDog \n");
        }
    }
    ZJ_AppThreadMonitorUnRegist(test);
    __INFO_PRINTF("monitor task out \n");
}
int ai_start()
{
    __INFO_PRINTF("device ai start\n");
    pthread_t tidp;
    if(pthread_create(&tidp, NULL,ai_loop, NULL)!=0)
    {
        __ERROR_PRINTF("ai create loop failed\n");
    }
    else
    {
        __INFO_PRINTF("ai create loop ok\n");
    }
    if(-1 == pthread_create(&tidp, NULL, monitor_task_loop, NULL))
    {
        __ERROR_PRINTF("device create monitor task thread failed\n");
        return -1;
    }
    else
    {
        __INFO_PRINTF("monitor task create loop ok\n");
    }
    return 0;
}
