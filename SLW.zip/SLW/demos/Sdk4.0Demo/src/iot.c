#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "zj_log.h"
#include "zj_type.h"
#include "zj_ga1400.h"

#include "cJSON.h"

#include "type.h"
#include "log.h"
#include "iot.h"
#include "system.h"

#define ONEKEYALARM_MODULE (unsigned char*)"OneKeyAlarm"

static ST_IOT_MNG g_StIotMng = {0};

static int g_iAlarmSoundExecuteTimeAbility = 0;
static int g_iExecuteTimeArraySize  = 0;
static ST_EXECUTETIME_INF *g_pstExecuteTimeInfHead = NULL;

ST_IOT_MNG *iot_get_mng()
{
    return &g_StIotMng;
}

int GetIntegerValue(cJSON *hObject, int *piOut)
{
    if (hObject == NULL)
    {
        *piOut = 0;
        return -1;
    }
    if (piOut == NULL)
    {
        return -1;
    }
    if (cJSON_Number == hObject->type)
    {
        *piOut = hObject->valueint;
    }
    else if ((cJSON_String == hObject->type) && (hObject->valuestring))
    {
        *piOut = atoi(hObject->valuestring);
        return 0;
    }
    else
    {
        *piOut = 0;
        return -1;
    }
    return 0;
}

int GetStringValue(cJSON *hObject, unsigned char **ppaucOut)
{
    cJSON *pNode = hObject;

    if (ppaucOut)
    {
        *ppaucOut = (unsigned char*)"";
    }
    else
    {
        return -1;
    }

    if ((!hObject) || (cJSON_String != pNode->type))
    {
        return -1;
    }

    *ppaucOut = (unsigned char *)pNode->valuestring;
    return 0;
}
/**********************新人脸抓拍告警相关注册函数*******************************/
/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_faceCapture_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
int aiiot_faceCapture_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**********************新人脸识别(布控)告警相关注册函数*******************************/
/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_faceDiscern_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
int aiiot_faceDiscern_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * AIiOT 设备开始工作回调接口, 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
 
    return 0;
}

/**
 * AIiOT 设备停止工作回调接口, 通过该接口通知设备停止信号采集；
 */
int aiiot_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);

    return 0;
}

/**
 * 向人脸抓拍IoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 *
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_faceCapture_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_FACE_CAPTURE
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {"Sensitive":"20","Status":"0","Trace":"0","Interval":"0"}
     * Sensitive    灵敏度 低25 中50 高75
     * Status       开启状态
     * Trace        是否开启自动追踪
     * Interval     时间间隔
     */

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    int iInterval   = 0;
    int iSensitive  = 0;
    int iStatus     = 0;
    int iTrace      = 0;
    cJSON *cProp    = NULL;

    if ((NULL == pstProp) || (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }

    cProp = cJSON_Parse((char*)pstProp);
    if (cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Sensitive"), &iSensitive) == 0)
    {
        g_StIotMng.stNewFaceCapture.iSensitive = iSensitive;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Status"), &iStatus) == 0)
    {
        // 抓拍开关 0:关闭 1:开启
        g_StIotMng.stNewFaceCapture.iStatus = iStatus;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Trace"), &iTrace) == 0)
    {
        // 如果是云台机，开启人脸追踪
        g_StIotMng.stNewFaceCapture.iTrace = iTrace;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Interval"), &iInterval) == 0)
    {
        g_StIotMng.stNewFaceCapture.iInterval = iInterval;
    }

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] face capture aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("                                                         Sensitive: [%d]\n", g_StIotMng.stNewFaceCapture.iSensitive);
    __INFO_PRINTF("                                                            Status: [%d]\n", g_StIotMng.stNewFaceCapture.iStatus);
    __INFO_PRINTF("                                                             Trace: [%d]\n", g_StIotMng.stNewFaceCapture.iTrace);
    __INFO_PRINTF("                                                          Interval: [%d]\n", g_StIotMng.stNewFaceCapture.iInterval);

    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }

    return 0;
}

/**
 * 向人脸识别(布控)IoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 *
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_faceDiscern_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_FACE_DISCERN
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {"Sensitive":"20","Status":"0","Model":"0","Trace":"0","Interval":"30"}
     * Sensitive    灵敏度 低25 中50 高75
     * Status       开启状态
     * Model        识别(布控)模式 0:黑名单 1:白名单 2:黑白名单
     * Trace        是否开启自动追踪
     * Interval     时间间隔
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    int iInterval   = 0;
    int iSensitive  = 0;
    int iStatus     = 0;
    int iModel      = 0;
    int iTrace      = 0;
    cJSON *cProp    = NULL;

    if ((NULL == pstProp) || (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }

    cProp = cJSON_Parse((char*)pstProp);
    if (cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Sensitive"), &iSensitive) == 0)
    {
        g_StIotMng.stNewFaceDiscern.stEvent.iSensitive = iSensitive;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Status"), &iStatus) == 0)
    {
        // 识别开关 0:关闭 1:开启
        g_StIotMng.stNewFaceDiscern.stEvent.iStatus = iStatus;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Model"), &iModel) == 0)
    {
        // 识别(布控)模式 0:黑名单 1:白名单 2:黑白名单
        g_StIotMng.stNewFaceDiscern.iModel = iModel;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Trace"), &iTrace) == 0)
    {
        // 如果是云台机，开启人脸追踪
        g_StIotMng.stNewFaceDiscern.stEvent.iTrace = iTrace;
    }

    if (GetIntegerValue(cJSON_GetObjectItem(cProp, "Interval"), &iInterval) == 0)
    {
        g_StIotMng.stNewFaceDiscern.stEvent.iInterval = iInterval;
    }

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] face discern aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("                                                         Sensitive: [%d]\n", g_StIotMng.stNewFaceDiscern.stEvent.iSensitive);
    __INFO_PRINTF("                                                            Status: [%d]\n", g_StIotMng.stNewFaceDiscern.stEvent.iStatus);
    __INFO_PRINTF("                                                             Model: [%d]\n", g_StIotMng.stNewFaceDiscern.iModel);
    __INFO_PRINTF("                                                             Trace: [%d]\n", g_StIotMng.stNewFaceDiscern.stEvent.iTrace);
    __INFO_PRINTF("                                                          Interval: [%d]\n", g_StIotMng.stNewFaceDiscern.stEvent.iInterval);

    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }

    return 0;
}

/**
 * 向ebo机器人IoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_EboRobot_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_EBO_ROBOT中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {"Shake":{"Sensitive":"20","Status":"1","Interval":"30"},"LowPower":{"Sensitive":"20","Status":"1","Interval":"30"},"Recharge":{"Sensitive":"20","Status":\"1","Interval":"30"}};
     *
     * {
     *   "Sensitive":"灵敏度0-100（string）",
     *   "Status":"功能开关（string）",
     *   "Interval":"事件检测间隔（string）"
     * }
     * 
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

/**
 * 向口罩识别IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_Mask_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);

    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;
    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if(cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_StIotMng.stMask.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] Mask aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                              Status: [%d]\n", g_StIotMng.stMask.stEvent.iStatus);        
    }
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }     
    return 0;
}

/**
 * 向烟火识别IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_FlameDetect_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);

    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;
    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    // 实现相关属性解析
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if(cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_StIotMng.stFlameDetect.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] FlameDetect aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                              Status: [%d]\n", g_StIotMng.stFlameDetect.stEvent.iStatus);      
    }
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }     
    return 0;
}

/**
 * 向电瓶车侦测IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_BatteryBike_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);
    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;
    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if(cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_StIotMng.stBatteryBike.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] BatteryBike aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                                      Status: [%d]\n", g_StIotMng.stBatteryBike.stEvent.iStatus);        
    }
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }     
    return 0;
}

/**
 * 向隐私遮罩IoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_PrivacyMask_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_PRIVACYMASK中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {"Status":"0","MaskMode":"0","Regions":[{"RegionId":"1","RegionPoints":[{"x":"0.000","y":"0.000"},{"x":"0.000","y":"0.000"}]}],"ExecuteTime":[{"StartTime":"0","EndTime":"86400","SpanFlag":"0"}]}
     *
     * {
     *   "Status":"功能开关（string）",
     *   "MaskMode":"遮罩模式（string）,0-区域内遮罩,1-区域外遮罩",
     *   "Regions":[]见SDK对接文档6.2.25章节"
     *   "ExecuteTime":[]见SDK对接文档6.2.25章节"
     * }
     * 
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

/**
 * 向高空抛物侦测IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_HighParabolic_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);
    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;
    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if(cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_StIotMng.stHighParabolic.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] HighParabolic aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                                      Status: [%d]\n", g_StIotMng.stHighParabolic.stEvent.iStatus);        
    }
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }         
    return 0;
}

/**
 * 向车辆行为分析IoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_car_analyse_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_CAR_ANALYSE
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

/**
 * 向移动侦测IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_motion_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_MOTION中
     * 注意：运动侦测iot包含,移动侦测、人形侦测、人脸识别三种事件类型,每一种事件类型都可以配置
     * 格式如下以移动侦测为例：
     * json格式(需要对接厂商自己解析,取出对应的值并设置)：
     *          {"Motion":{"Interval":"30","Sensitive":"25","Status":"0","Trace":"0"}}
     * Interval     时间间隔
     * Sensitive    灵敏度 低25 中50 高75
     * Status       开启状态
     * Trace        是否开启自动追踪
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]\n", uiAIIoTType, uiAIIoTID);
    int iInterval   = 0;
    int iSensitive  = 0;
    int iStatus     = 0;
    int iTrace      = 0;
    int iDiscernFlag    = 0;
    int iFenceStayTime  = 0;
    int iFenceVideoFlag = 0;
    int iFenceCaptureFlag = 0;
    cJSON *cProp    = NULL;
    cJSON *cMotion  = NULL;
    cJSON *cHuman   = NULL;
    cJSON *cFence   = NULL;
    cJSON *cFace    = NULL;
    cJSON *cCarNum  = NULL;

    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    cMotion = cJSON_GetObjectItem(cProp, "Motion");
    if(cMotion != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cMotion,"Interval"), &iInterval)==0)
        {
            g_StIotMng.stMotion.iInterval = iInterval;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cMotion,"Sensitive"), &iSensitive) == 0)
        {
            g_StIotMng.stMotion.iSensitive = iSensitive;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cMotion,"Status"), &iStatus)==0)
        {
            g_StIotMng.stMotion.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cMotion,"Trace"), &iTrace) == 0)
        {
            g_StIotMng.stMotion.iTrace = iTrace;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] Motion aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                                Interval: [%d]\n", g_StIotMng.stMotion.iInterval);
        __INFO_PRINTF("                                               Sensitive: [%d]\n", g_StIotMng.stMotion.iSensitive);
        __INFO_PRINTF("                                                  Status: [%d]\n", g_StIotMng.stMotion.iStatus);
        __INFO_PRINTF("                                                   Trace: [%d]\n", g_StIotMng.stMotion.iTrace);
    }

    cHuman = cJSON_GetObjectItem(cProp, "Human");
    if(cHuman != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cHuman,"Interval"), &iInterval)==0)
        {
            g_StIotMng.stHuman.iInterval = iInterval;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cHuman,"Sensitive"), &iSensitive) == 0)
        {
            g_StIotMng.stHuman.iSensitive = iSensitive;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cHuman,"Status"), &iStatus)==0)
        {
            g_StIotMng.stHuman.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cHuman,"Trace"), &iTrace) == 0)
        {
            g_StIotMng.stHuman.iTrace = iTrace;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] Human aiiot id [%llu]:\n",  uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                               Interval: [%d]\n",  g_StIotMng.stHuman.iInterval);
        __INFO_PRINTF("                                              Sensitive: [%d]\n",  g_StIotMng.stHuman.iSensitive);
        __INFO_PRINTF("                                                 Status: [%d]\n",  g_StIotMng.stHuman.iStatus);
        __INFO_PRINTF("                                                  Trace: [%d]\n",  g_StIotMng.stHuman.iTrace);
    }

    cFence = cJSON_GetObjectItem(cProp, "Fence");
    if (cFence != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cFence,"Status"), &iStatus)==0)
        {
            g_StIotMng.stFence.stEvent.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFence,"StayTime"), &iFenceStayTime)==0)
        {
            g_StIotMng.stFence.iStayTime = iFenceStayTime;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFence,"Capture"), &iFenceCaptureFlag)==0)
        {
            g_StIotMng.stFence.iCapture = iFenceCaptureFlag;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFence,"Video"), &iFenceVideoFlag)==0)
        {
            g_StIotMng.stFence.iVideo = iFenceVideoFlag;
        }       
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] Fence aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                                Status: [%d]\n", g_StIotMng.stFence.stEvent.iStatus);
        __INFO_PRINTF("                                              StayTime: [%d]\n", g_StIotMng.stFence.iStayTime);
        __INFO_PRINTF("                                               Capture: [%d]\n", g_StIotMng.stFence.iCapture);
        __INFO_PRINTF("                                                 Video: [%d]\n", g_StIotMng.stFence.iVideo);                         
    }
    else
    {
        __INFO_PRINTF("cFence == NULL\n");
    }

    #if !USE_NEW_FACE
    // 旧人脸
    cFace = cJSON_GetObjectItem(cProp, "Face");
    if (cFace != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cFace,"Status"), &iStatus)==0)
        {
            // 人脸抓拍开关
            g_StIotMng.stFace.stEvent.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFace,"DiscernFlag"), &iDiscernFlag)==0)
        {
            // 人脸布控开关
            g_StIotMng.stFace.iDiscernFlag = iDiscernFlag;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFace,"Trace"), &iTrace) == 0)
        {
            // 如果是云台机,开启人脸追踪
            g_StIotMng.stFace.stEvent.iTrace = iTrace;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cFace,"Interval"), &iInterval)==0)
        {
            g_StIotMng.stFace.stEvent.iInterval = iInterval;
        }
    }
    #endif
    
    cCarNum = cJSON_GetObjectItem(cProp, "CarNum");
    if (cCarNum != NULL)
    {
        if(GetIntegerValue(cJSON_GetObjectItem(cCarNum,"Status"), &iStatus)==0)
        {
            // 开启车牌抓拍
            g_StIotMng.stCarNum.iStatus = iStatus;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cCarNum,"Trace"), &iTrace) == 0)
        {
            // 如果是云台机,开启车牌追踪
            g_StIotMng.stCarNum.iTrace = iTrace;
        }
        if(GetIntegerValue(cJSON_GetObjectItem(cCarNum,"Interval"), &iInterval)==0)
        {
            g_StIotMng.stCarNum.iInterval = iInterval;
        }
    }
    
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("prop: %s\n", pstProp);
    
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }

    return 0;
}

/**
 * 向声音检测和异响告警IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_voice_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT中
     * json格式(需要对接厂商自己解析,取出对应的值并设置)：
     *          {"Sensitive":50,"Trace":0,"Interval":30}
     * Interval     时间间隔
     * Sensitive    灵敏度 0-100
     * Trace        是否开启自动追踪
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);

    return 0;
}

/**
 * 向哭声侦测IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_cry_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_CRY中
     * json格式(需要对接厂商自己解析,取出对应的值并设置)：
     *          {"Sensitive":50,"Trace":0,"Interval":30}
     * Interval     时间间隔
     * Sensitive    灵敏度 0-100
     * Trace        是否开启自动追踪
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%d] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);

    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;
    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    // 实现相关属性解析
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if(cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_StIotMng.stFlameDetect.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%d] FlameDetect aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                              Status: [%d]\n", g_StIotMng.stFlameDetect.stEvent.iStatus);      
    }
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }     
    return 0;
}

/**
 * 向头盔侦测IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_Helmet_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * {
     *   "Sensitive":"灵敏度0-100（string）",
     *   "Status":"功能开关（string）",
     *   "Trace":"是否追踪（string）",     //不支持云台，不需要此字段
     *   "Interval":"事件检测间隔（string）",
     *   "Capture":"抓拍开关（string）"
     * }
    */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);
    return 0;
}

/**********************一键告警相关注册函数*******************************/
/*
一键告警推流线程
*/
static void* onekeyalarm_loop(void* argc)
{
    int iFirstFlag          = 1;
    time_t tFeedDogTime     = 0;
    time_t tFeedDogTimeBak  = 0;
    int iFeedDogTimeSub     = 30;
    int iTimeOutSecs        = 30;
    int iFeedIntervalSec    = 10;
    unsigned int uiWatchId  = 0;
    unsigned char aucStrStatusLog[128] = {0};
    unsigned int iExOneKeyAlarmStatusCount = 0;

    // 一键告警推流线程注册SDK看门狗
    uiWatchId = ZJ_ThirdModuleRegistSwd(ONEKEYALARM_MODULE, iTimeOutSecs, iFeedIntervalSec);

    __INFO_PRINTF("device onekeyalarm test loop start\n");

    while (g_StIotMng.stOneKeyAlarm.iRunFlag)
    {
        tFeedDogTime = time(0);
        iFeedDogTimeSub = abs(tFeedDogTime - tFeedDogTimeBak);
        if (iFeedDogTimeSub > iFeedIntervalSec)
        {
            // 国标模块线程向SDK喂狗
            ZJ_ThirdModuleFeedDog(uiWatchId);
            tFeedDogTimeBak = tFeedDogTime;
        }

        if (iFirstFlag == 1)
        {
            // 设备启动，设备自行检测外接一键告警器的初始的插入状态并通知SDK
            ZJ_SetCommonExDevInsertStatus("ExOneKeyAlarmStatus", 0); // 0只是demo模拟值，具体状态根据实际情况填写
            iFirstFlag = 0;
        }
        else
        {
            // 设备自行检测外接一键告警器的插入状态，变更则通知SDK
            ++iExOneKeyAlarmStatusCount;            // 此为模拟触发按键告警逻辑，需自行实现识别按键告警
            if (iExOneKeyAlarmStatusCount == 50)
            {
                ZJ_SetCommonExDevInsertStatus("ExOneKeyAlarmStatus", 1); // 1只是demo模拟值，具体状态根据实际情况填写
            }
        }

        // 判断一键推流功能开关
        if (g_StIotMng.stOneKeyAlarm.iStatus == 1)
        {
            // TODO 实现一键推流功能
            // 1. 判断推流地址有效期 g_StIotMng.stOneKeyAlarm.aucPushStreamAddrValidDate
            // 2. 选择推流协议 g_StIotMng.stOneKeyAlarm.iPushStreamProtocol
            // 3. 连接推流地址 g_StIotMng.stOneKeyAlarm.aucPushStreamAddr
            // 4. 推流时长 g_StIotMng.stOneKeyAlarm.iPushStreamDuration

            // 一键告警功能注意事项：
            // 1) 设备启动，设备自行检测外接一键告警器的初始的插入状态并通知SDK
            // 2) 设备自行检测外接一键告警器的插入状态，变更则通知SDK
            // 3) 按一次触发一键告警，再按一次是停止当前告警声音播报
            // 4) 对于设备推流，在推流过程中再次触发一键告警事件，当前推流时长清0，按重新PushStreamDuration推流时长计算
            // 5) 一键告警推图功能默认关闭， 即："Capture":"0"
            // 6) 一键告警白光灯联动默认闪烁,即: "Flicker":"1"          
        }
        sleep(1);
    }

    // 国标模块线程注销SDK看门狗
    ZJ_ThirdModuleUnRegistSwd(uiWatchId);
    __INFO_PRINTF("device onekeyalarm test loop exit\n");
    return NULL;
}

/**
 * AIiOT 设备开始工作回调接口， 通过该接口启动AIIOT设备信号采集；
 */
int aiiot_onekeyalarm_start(unsigned int uiAIIoTType, unsigned long long uiAIIoTID)
{
    /**
     * 启动IOT
     */
    g_StIotMng.stOneKeyAlarm.iRunFlag = 1;

    if(pthread_create(&g_StIotMng.stOneKeyAlarm.hThread, NULL, onekeyalarm_loop, NULL)!=0)
    {
        __ERROR_PRINTF("device create onekeyalarm loop failed\n");
    }
    else
    {
        __INFO_PRINTF("device create onekeyalarm loop ok\n");
    }
    __INFO_PRINTF("device aiiot start, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    return 0;
}

 /**
 * AIiOT 设备停止工作回调接口， 通过该接口通知设备停止信号采集；
 */
int aiiot_onekeyalarm_stop(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
     /**
     * 停止IOT
     */
    g_StIotMng.stOneKeyAlarm.iRunFlag = 0;
    __INFO_PRINTF("device aiiot stop, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, lluAIIoTID);
    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口，通过该接口，将新的属性值设置给AIIoT设备，让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_onekeyalarm_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * 在 EN_ZJ_AIIOT_TYPE_ONEKETALARM 中
     * json格式（需要对接厂商自己解析，取出对应的值并设置）：
     * {
            "Status":"功能开关(string)",       // 0:关 1:开 默认:0关闭
            "Interval":"事件检测间隔(string)", // 单位:秒(s) 默认:1s
            "Capture":"抓拍开关（string）",    // 0.关闭；1.打开
            "Vedio":"视频开关（string）",      // 0.关闭；1.打开
            "PushStreamProtocol":"推流使用协议(string)", // 1:RTMP协议推流
            "PushStreamAddr":"推流目标地址(string)",     // 最大长度128字节
            "PushStreamDuration":"推流时长(string),      // 单位:分钟，默认10分钟，上限24小时
            "PushStreamAddrValidDate":"推流地址有效期(string), // 格式：YYYY-MM-DD-HH-MM-SS
        }
        PushStreamAddr推流地址示例：
            rtmp://120.71.43.45:1935/live/报警号码?auth=XXXXXXXXXX
            rtmp://120.71.43.45:1935/live/17726739125?auth=XXXXXXXXXX
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);

    int iStatus      = 0;
    int iInterval    = 0;
    int iCapture     = 0;
    int iVedio       = 0;
    int iPushStreamProtocol = 0;
    int iPushStreamDuration = 0;
    unsigned char aucPushStreamAddr[128] = {0};
    unsigned char aucPushStreamAddrValidDate[64] = {0};
    cJSON *cProp     = NULL;
    cJSON *cStatus   = NULL;
    cJSON *cInterval = NULL;
    cJSON *cCapture  = NULL;
    cJSON *cVedio    = NULL;
    cJSON *cPushStreamAddr     = NULL;
    cJSON *cPushStreamProtocol = NULL;
    cJSON *cPushStreamDuration = NULL;
    cJSON *cPushStreamAddrValidDate = NULL;

    if ((pstProp == NULL) || (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if (cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }

    // 实现相关属性解析
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if (cStatus != NULL)
    {
        if (GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_StIotMng.stOneKeyAlarm.iStatus = iStatus;
        }     
    }

    cInterval = cJSON_GetObjectItem(cProp, "Interval");
    if (cInterval != NULL)
    {
        if (GetIntegerValue(cInterval, &iInterval)==0)
        {
            g_StIotMng.stOneKeyAlarm.iInterval = iInterval;
        }     
    }

    cCapture = cJSON_GetObjectItem(cProp, "Capture");
    if (cCapture != NULL)
    {
        if (GetIntegerValue(cCapture, &iCapture)==0)
        {
            g_StIotMng.stOneKeyAlarm.iCapture = iCapture;
        }     
    }

    cVedio = cJSON_GetObjectItem(cProp, "Vedio");
    if (cVedio != NULL)
    {
        if (GetIntegerValue(cVedio, &iVedio)==0)
        {
            g_StIotMng.stOneKeyAlarm.iVedio = iVedio;
        }     
    }

    cPushStreamProtocol = cJSON_GetObjectItem(cProp, "PushStreamProtocol");
    if (cPushStreamProtocol != NULL)
    {
        if (GetIntegerValue(cPushStreamProtocol, &iPushStreamProtocol)==0)
        {
            g_StIotMng.stOneKeyAlarm.iPushStreamProtocol = iPushStreamProtocol;
        }     
    }

    cPushStreamDuration = cJSON_GetObjectItem(cProp, "PushStreamDuration");
    if (cPushStreamDuration != NULL)
    {
        if (GetIntegerValue(cPushStreamDuration, &iPushStreamDuration)==0)
        {
            g_StIotMng.stOneKeyAlarm.iPushStreamDuration = iPushStreamDuration;
        }     
    }
    
    cPushStreamAddr = cJSON_GetObjectItem(cProp, "PushStreamAddr");
    if (cPushStreamAddr != NULL)
    {
        if (GetStringValue(cPushStreamAddr, &aucPushStreamAddr)==0)
        {
            strncpy(g_StIotMng.stOneKeyAlarm.aucPushStreamAddr, aucPushStreamAddr, sizeof(g_StIotMng.stOneKeyAlarm.iPushStreamDuration));
        }     
    }

    cPushStreamAddrValidDate = cJSON_GetObjectItem(cProp, "PushStreamAddrValidDate");
    if (cPushStreamAddrValidDate != NULL)
    {
        if (GetStringValue(cPushStreamAddrValidDate, &aucPushStreamAddrValidDate)==0)
        {
            strncpy(g_StIotMng.stOneKeyAlarm.aucPushStreamAddrValidDate, aucPushStreamAddrValidDate, sizeof(g_StIotMng.stOneKeyAlarm.aucPushStreamAddrValidDate));
        }     
    }

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] OneKeyAlarm aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("                                              Status: [%d]\n", g_StIotMng.stOneKeyAlarm.iStatus); 
    __INFO_PRINTF("                                            Interval: [%d]\n", g_StIotMng.stOneKeyAlarm.iInterval); 
    __INFO_PRINTF("                                            Interval: [%d]\n", g_StIotMng.stOneKeyAlarm.iCapture); 
    __INFO_PRINTF("                                               Vedio: [%d]\n", g_StIotMng.stOneKeyAlarm.iVedio); 
    __INFO_PRINTF("                                  PushStreamProtocol: [%d]\n", g_StIotMng.stOneKeyAlarm.iPushStreamProtocol); 
    __INFO_PRINTF("                                  PushStreamDuration: [%d]\n", g_StIotMng.stOneKeyAlarm.iPushStreamDuration); 
    __INFO_PRINTF("                                      PushStreamAddr: [%s]\n", g_StIotMng.stOneKeyAlarm.aucPushStreamAddr); 
    __INFO_PRINTF("                             PushStreamAddrValidDate: [%s]\n", g_StIotMng.stOneKeyAlarm.aucPushStreamAddrValidDate); 

    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }     
    return 0;
}

/**********************红外灯相关注册函数*******************************/
/**
 * 查询AIiOT 设备当前事件或信号量回调接口, 通过该接口返回设备当前的信号量和事件, 
 * 返回输入信号类型和对应的信号Json字串返回下来
 * {"DNFlag":"1"} // 1 白天 2 晚上
 */
int aiiot_dnset_input(unsigned int uiAIIoTType, unsigned long long uiAIIoTID,unsigned char *aucSignalValue)
{
    /**
     * 查询AIiOT 设备当前事件或信号量
     */
    __INFO_PRINTF("device aiiot input, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    // strcpy(aucSignalValue, "{\"DNFlag\":\"1\"}");
    strcpy(aucSignalValue, "{\"DNFlag\":\"2\"}");
    return 0;
}

/**
 * 向AIiOT 设备输出信号回调接口,通过该接口,将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 */
int aiiot_dnset_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来,需要对接厂商解析并设置
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue ==NULL ? (unsigned char*)"nil":pSignalValue);
    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",    pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n",  pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",    pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",    pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",   pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",    pstTriggerInf->pstHandler);
    }

    return 0;
}


/**********************白光灯相关注册函数*******************************/
/**
 * 向AIiOT 设备输出信号回调接口,通过该接口,将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 */
int aiiot_inner_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来,需要对接厂商解析并设置
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue ==NULL ? (unsigned char*)"nil":pSignalValue);

    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",    pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n",  pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",    pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",    pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",   pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",    pstTriggerInf->pstHandler);
    }

    return 0;
}

/**********************内置状态指示灯相关注册函数*******************************/
/**
 * 向AIiOT 设备输出信号回调接口,通过该接口,将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 */
int aiiot_inner_statelamp_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue, ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来,需要对接厂商解析并设置
     * 内置指示灯Signal Value: {"CtrlType":"1","Flicker":""} ,CtrlType=1：开,CtrlType=0：关
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue ==NULL ? (unsigned char*)"nil":pSignalValue);

    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",   pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n", pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",   pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",   pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",  pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",   pstTriggerInf->pstHandler);
    }

    return 0;
}

/**
 * 向扬声器Iot设备输出信号回调接口,通过该接口,将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 * 对于扬声器(1009)的注意事项：
		1、先判断CtrlType字段做开启或关闭播放
		2、再进行时间判断
			a、常规功能,不支持扬声器多时间段播报能力AlarmSoundExecuteTimeAbility  仅处理外部StartTime、EndTime,不需处理ExecuteTime字段
                1) 判断当前时间是否在StartTime、EndTime的范围,若StartTime和EndTime字段缺失则认为生效
			b、支持扬声器多时间段播报能力AlarmSoundExecuteTimeAbility后(对接支持老人吃药提醒功能)
                1) 扬声器(1009)output的ExecuteTime字段为空或者数组个数为0时,仅处理外部StartTime、EndTime,不需处理ExecuteTime字段,
                                判断当前时间是否在StartTime、EndTime的范围,若StartTime和EndTime字段缺失则认为生效
				2) 扬声器(1009)output的ExecuteTime数组个数非0时,不需处理外部StartTime、EndTime,需要处理ExecuteTime字段以及其包含的字段
                                目前业务需求最大支持10个时间段,StartTime和EndTime每天生效
                3) 多时间段个数变更,即对时间段修改,重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
                4) 多时间段个数未变更,若某时间段被修改,重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
                5) RemindRule字段缺失时,默认每次播报
        3、再判断SoundType字段(2-自定义告警声 或者 预设内置告警声,4-默认告警声)
            1) 如果SoundType为2时,再根据SoundName播放自定义(下载)告警声音 或者 播放预置(非下载)告警声音,此时AlarmType字段允许缺失；
            2) 如果SoundType为4时,再根据AlarmType播放某类型的默认告警声音；
        4、最后根据LoopCnt字段做次数播放
 */
int aiiot_buzzer_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue, ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来,需要对接厂商解析并设置
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue == NULL ? (unsigned char*)"nil":pSignalValue);

    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",    pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n",  pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",    pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",    pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",   pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",    pstTriggerInf->pstHandler);
    }

    int i = 0;
    int iInTimeFlag = 0;
    int iIsChangeExecuteTime  = 0;
    int iSpanFlag   = 0;
    unsigned int uiStartTime  = 0;
    unsigned int uiEndTime    = 0;
    unsigned int uiSecInDay   = 0;
    int iExecuteTimeArraySize = 0;
    int iCtrlType   = 0;
    int iSoundType  = 0;
    int iAlarmType  = 0;
    int iLoopCnt    = 0;
    int iRemindRule = 0;
    time_t tCurTime = 0;
    struct tm stTmCurTime = {0};
    unsigned char aucDay[16] = {0};
    static unsigned char aucLastDay[16] = {0};
    unsigned char *pucSoundName = NULL;
    unsigned char aucSoundName[64] = {0};
    ST_EXECUTETIME_INF *pstExecuteTimeInfPre  = NULL;
    ST_EXECUTETIME_INF *pstExecuteTimeInfTmp  = NULL;

    cJSON *cOutputJson = NULL;
    cJSON *cSpanFlag   = NULL;
    cJSON *cStartTime  = NULL;
    cJSON *cEndTime    = NULL;
    cJSON *cExecuteTimeItem  = NULL;
    cJSON *cExecuteTimeArray = NULL;
    cJSON *cCtrlType   = NULL;
    cJSON *cSoundType  = NULL;
    cJSON *cAlarmType  = NULL;
    cJSON *cSoundName  = NULL;
    cJSON *cLoopCnt    = NULL;
    cJSON *cRemindRule = NULL;

    if ((pSignalValue == NULL) || (strlen((char*)pSignalValue) <= 0))
    {
        __ERROR_PRINTF("device aiiot buzzer output failed\n");
        return -1;
    }

    cOutputJson = cJSON_Parse((char*)pSignalValue);
    if (cOutputJson == NULL)
    {
        __ERROR_PRINTF("device aiiot buzzer output failed, json prase err\n");
        return -1;
    }

    // 1、先判断CtrlType字段做开启或关闭播放
    // 获取控制开关字段
    cCtrlType = cJSON_GetObjectItem(cOutputJson, "CtrlType");
    if (cCtrlType)
    {
        // 获取控制开关字段值
        GetIntegerValue(cCtrlType, iCtrlType);
    }

    //播放开关关闭,退出播放
    if (iCtrlType == 0)
    {
        __INFO_PRINTF("iCtrlType: %d \n", iCtrlType);
        // 释放JSON
        if (cOutputJson != NULL)
        {
            cJSON_Delete(cOutputJson);
            cOutputJson = NULL;
        }
        return 0;
    }

    // 2、再进行时间判断
    // a、常规功能,不支持扬声器多时间段播报能力 AlarmSoundExecuteTimeAbility 仅处理外部StartTime、EndTime,不需处理ExecuteTime字段.
    if (g_iAlarmSoundExecuteTimeAbility == 0)
    {
		// 1) 判断当前时间是否在外部StartTime、EndTime的范围,若StartTime和EndTime字段缺失则认为生效.
        // 获取外部StartTime、EndTime值
        cStartTime = cJSON_GetObjectItem(cOutputJson, "StartTime");
        if (cStartTime)
        {
            if (GetIntegerValue(cStartTime, uiStartTime) == 0)
            {
                cEndTime = cJSON_GetObjectItem(cOutputJson, "EndTime");
                if (cEndTime)
                {
                    if (GetIntegerValue(cEndTime, uiEndTime) == 0)
                    {
                        // 获取当天的秒数
                        tCurTime = time(NULL);
                        localtime_r(&tCurTime, &stTmCurTime);
                        uiSecInDay = (stTmCurTime.tm_hour * 3600) + (stTmCurTime.tm_min * 60) + (stTmCurTime.tm_sec);

                        // 当前时间在播放时间段内
                        if ((uiSecInDay >= uiStartTime) && (uiSecInDay <= uiEndTime))
                        {
                            iInTimeFlag = 1;
                        }
                    }
                }
                else
                {
                    // 若StartTime和EndTime字段缺失则认为生效
                    // output里外部StartTime和EndTime字段缺失时, 默认处于时间内播放语音
                    iInTimeFlag = 1;
                }
            }
        }
        else
        {
            // 若StartTime和EndTime字段缺失则认为生效
            // output里外部StartTime和EndTime字段缺失时, 默认处于时间内播放语音
            iInTimeFlag = 1;
        }
    }
    // b、支持扬声器多时间段播报能力AlarmSoundExecuteTimeAbility后(对接支持老人吃药提醒功能)
    else if (g_iAlarmSoundExecuteTimeAbility == 1)
    {
        // 获取拓展多时间段字段
        cExecuteTimeArray = cJSON_GetObjectItem(cOutputJson, "ExecuteTime");
        if (cExecuteTimeArray)
        {
            // 获取拓展多时间段字段数组个数
            iExecuteTimeArraySize = cJSON_GetArraySize(cExecuteTimeArray);
        }

        // 1) 扬声器(1009)output的ExecuteTime字段为空或者数组个数为0时,仅处理外部StartTime、EndTime,不需处理ExecuteTime字段.
        //    判断当前时间是否在外部StartTime、EndTime的范围,若StartTime和EndTime字段缺失则认为生效.
        if (iExecuteTimeArraySize == 0)
        {
            // 获取外部StartTime、EndTime值
            cStartTime = cJSON_GetObjectItem(cOutputJson, "StartTime");
            if (cStartTime)
            {
                if (GetIntegerValue(cStartTime, uiStartTime) == 0)
                {
                    cEndTime = cJSON_GetObjectItem(cOutputJson, "EndTime");
                    if (cEndTime)
                    {
                        if (GetIntegerValue(cEndTime, uiEndTime) == 0)
                        {
                            // 获取当天的秒数
                            tCurTime = time(NULL);
                            localtime_r(&tCurTime, &stTmCurTime);
                            uiSecInDay = (stTmCurTime.tm_hour * 3600) + (stTmCurTime.tm_min * 60) + (stTmCurTime.tm_sec);

                            // 当前时间在播放时间段内
                            if ((uiSecInDay >= uiStartTime) && (uiSecInDay <= uiEndTime))
                            {
                                iInTimeFlag = 1;
                            }
                        }
                    }
                    else
                    {
                        // 若StartTime和EndTime字段缺失则认为生效
                        // output里外部StartTime和EndTime字段缺失时, 默认处于时间内播放语音
                        iInTimeFlag = 1;     
                    }
                }
            }
            else
            {
                // 若StartTime和EndTime字段缺失则认为生效
                // output里外部StartTime和EndTime字段缺失时, 默认处于时间内播放语音
                iInTimeFlag = 1;
            }
        }
        // 2) 扬声器(1009)output的ExecuteTime数组个数非0时,不需处理外部StartTime、EndTime,需要处理ExecuteTime字段以及其包含的字段.
        // 目前业务需求最大支持10个时间段.StartTime和EndTime每天生效.
        else if (iExecuteTimeArraySize > 0)
        {
            // 3) 多时间段个数变更,即对时间段修改,重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
            if (g_iExecuteTimeArraySize != iExecuteTimeArraySize)
            {
                iIsChangeExecuteTime = 1;
            }
            // 4) 多时间段个数未变更,若某时间段被修改,重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
            else
            {
                // 遍历时间段的个节点数据有无被修改
                pstExecuteTimeInfTmp = g_pstExecuteTimeInfHead;
                for (i = 0; i < iExecuteTimeArraySize; i++)
                {
                    cExecuteTimeItem = cJSON_GetArrayItem(cExecuteTimeArray,i);

                    // 获取ExecuteTime内部StartTime值
                    cStartTime = cJSON_GetObjectItem(cExecuteTimeItem, "StartTime");
                    if (cStartTime)
                    {
                        GetIntegerValue(cStartTime, uiStartTime);
                    }
                    // 获取ExecuteTime内部EndTime值
                    cEndTime = cJSON_GetObjectItem(cExecuteTimeItem, "EndTime");
                    if (cEndTime)
                    {
                        GetIntegerValue(cEndTime, uiEndTime);
                    }
                    // 获取ExecuteTime内部SpanFlag值
                    cSpanFlag = cJSON_GetObjectItem(cExecuteTimeItem, "SpanFlag");
                    if (cSpanFlag)
                    {
                        GetIntegerValue(cSpanFlag, iSpanFlag);
                    }

                    if (pstExecuteTimeInfTmp)
                    {
                        // 该时间段节点未被修改
                        if ((pstExecuteTimeInfTmp->iSpanFlag   == iSpanFlag)   &&
                            (pstExecuteTimeInfTmp->uiStartTime == uiStartTime) &&
                            (pstExecuteTimeInfTmp->uiEndTime   == uiEndTime))
                        {
                            // 继续遍历下一个节点
                            pstExecuteTimeInfTmp = pstExecuteTimeInfTmp->pstNextNode;
                            continue;
                        }
                        // 该时间段节点被修改
                        else
                        {
                            iIsChangeExecuteTime = 1;
                            break;
                        }
                    }
                    // 出现NULL节点即被修改时间段
                    else
                    {
                        iIsChangeExecuteTime = 1;
                        break;
                    }
                }
            }

            // 检测到跨天，重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报
            struct timeval tv;
            gettimeofday(&tv, NULL);
            int64_t seconds = tv.tv_sec;
            struct tm tm_time;
            localtime_r(&seconds, &tm_time);
            snprintf(aucDay, "%04hu-%02hu-%02hu", tm_time.tm_year, tm_time.tm_mon, tm_time.tm_mday);
            if (strlen(aucLastDay) == 0)
            {
                strncpy(aucLastDay, aucDay, sizeof(aucLastDay));
            }
            else
            {
                if (strncmp(aucDay, aucLastDay, sizeof(aucDay)) != 0)
                {
                    iIsChangeExecuteTime = 1;
                    strncpy(aucLastDay, aucDay, sizeof(aucLastDay));
                }
            }

            // 若时间段被修改 重新赋值各时间段的值,所有时间段更新时间段内触发语音播报状态为未播报.
            if (iIsChangeExecuteTime == 1)
            {
                for (i = 0; i < iExecuteTimeArraySize; i++)
                {
                    cExecuteTimeItem = cJSON_GetArrayItem(cExecuteTimeArray,i);

                    // 获取ExecuteTime内部StartTime值
                    cStartTime = cJSON_GetObjectItem(cExecuteTimeItem, "StartTime");
                    if (cStartTime)
                    {
                        GetIntegerValue(cStartTime, uiStartTime);
                    }
                    // 获取ExecuteTime内部EndTime值
                    cEndTime = cJSON_GetObjectItem(cExecuteTimeItem, "EndTime");
                    if (cEndTime)
                    {
                        GetIntegerValue(cEndTime, uiEndTime);
                    }

                    // 获取ExecuteTime内部SpanFlag值
                    cSpanFlag = cJSON_GetObjectItem(cExecuteTimeItem, "SpanFlag");
                    if (cSpanFlag)
                    {
                        GetIntegerValue(cSpanFlag, iSpanFlag);
                    }

                    if (pstExecuteTimeInfTmp == NULL)
                    {
                        pstExecuteTimeInfTmp    = malloc(sizeof(ST_EXECUTETIME_INF));
                        g_pstExecuteTimeInfHead = pstExecuteTimeInfTmp;
                    }
                    else
                    {
                        pstExecuteTimeInfTmp = malloc(sizeof(ST_EXECUTETIME_INF));
                    }

                    pstExecuteTimeInfTmp->uiIoTType     = uiAIIoTType;
                    pstExecuteTimeInfTmp->iSpanFlag     = iSpanFlag;
                    pstExecuteTimeInfTmp->uiStartTime   = uiStartTime;
                    pstExecuteTimeInfTmp->uiEndTime     = uiEndTime;
                    pstExecuteTimeInfTmp->iRemindStatus = 0;    //播放标志位清0 语音播报状态为未播报.
                    if (pstExecuteTimeInfPre)
                    {
                        pstExecuteTimeInfPre->pstNextNode = pstExecuteTimeInfTmp;
                    }
                    pstExecuteTimeInfPre = pstExecuteTimeInfTmp;
                }
            }

            // 获取当天的秒数
            tCurTime = time(NULL);
            localtime_r(&tCurTime, &stTmCurTime);
            uiSecInDay = (stTmCurTime.tm_hour * 3600) + (stTmCurTime.tm_min * 60) + (stTmCurTime.tm_sec);

            pstExecuteTimeInfTmp = g_pstExecuteTimeInfHead;
            while (pstExecuteTimeInfTmp)
            {
                // 在布控时间段内触发告警
                if (((iSpanFlag == 0) && ((uiSecInDay >= pstExecuteTimeInfTmp->uiStartTime) && (uiSecInDay <= pstExecuteTimeInfTmp->uiEndTime))) || 
                    ((iSpanFlag == 1) && ((uiSecInDay >= pstExecuteTimeInfTmp->uiStartTime) || (uiSecInDay <= pstExecuteTimeInfTmp->uiEndTime))) )
                {
                    // 获取播报提醒规则字段
                    cRemindRule = cJSON_GetObjectItem(cExecuteTimeItem, "RemindRule");
                    if (cRemindRule)
                    {
                        // 获取播报提醒规则字段值
                        GetIntegerValue(cRemindRule, iRemindRule);
                        // 每次都播报
                        if (iRemindRule == 0)
                        {
                            iInTimeFlag = 1;
                            break;
                        }
                        // 每个时间段只播报一次
                        else if (iRemindRule == 1)
                        {
                            // 未播报
                            if (pstExecuteTimeInfTmp->iRemindStatus == 0)
                            {
                                iInTimeFlag = 1;
                                pstExecuteTimeInfTmp->iRemindStatus = 1;
                                break;
                            }
                            // 已播报
                            else
                            {
                                iInTimeFlag = 0;
                            }
                        }
                    }
                    // 5) RemindRule字段缺失时,默认每次播报.
                    else
                    {
                        iInTimeFlag = 1;
                        break;
                    }
                }
                else
                {
                    pstExecuteTimeInfTmp = pstExecuteTimeInfTmp->pstNextNode;
                }
            }
        }
    }

    // 在时间段内
    if (iInTimeFlag == 1)
    {
        // 3、再判断SoundType字段(2-自定义告警声 或者 预设内置告警声,4-默认告警声)
        // 获取播放声音类型字段
        cSoundType = cJSON_GetObjectItem(cOutputJson, "SoundType");
        if (cSoundType)
        {
            // 获取播放声音类型字段值
            if (GetIntegerValue(cSoundType, iSoundType) == 0)
            {
                // 下载的自定义报警声音文件(可删) 和 预置的报警声音文件(不可删)
                // 1)如果SoundType为2时,再根据SoundName播放自定义(下载)告警声音 或者 播放预置(非下载)告警声音
                if (iSoundType == EN_ZJ_RING_DOORBELL)
                {
                    // 获取报警声音文件名字段
                    cSoundName = cJSON_GetObjectItem(cOutputJson, "SoundName");
                    if (cSoundName)
                    {
                        // 获取报警声音文件名字段值
                        GetStringValue(cSoundName, &pucSoundName);
                        if (pucSoundName)
                        {
                            strncpy(aucSoundName, pucSoundName, sizeof(aucSoundName));

                            // 获取文件播放几次字段
                            cLoopCnt = cJSON_GetObjectItem(cOutputJson, "LoopCnt");
                            if (cLoopCnt)
                            {
                                // 获取文件播放几次字段值
                                if (GetIntegerValue(cLoopCnt, iLoopCnt) == 0)
                                {
                                    // TODO
                                    // 如果SoundType为2时,再根据SoundName播放自定义(下载)告警声音 或者 播放预置(非下载)告警声音,最后根据LoopCnt字段做次数播放
                                }
                            }
                        }
                    }
                }
                // 设备默认警戒音
                // 2)如果SoundType为4时,再根据AlarmType播放某类型的默认告警声音
                else if (iSoundType == EN_ZJ_RING_ALARM)
                {
                    // 获取触发扬声器的报警类型字段
                    cAlarmType = cJSON_GetObjectItem(cOutputJson, "AlarmType");
                    if (cAlarmType)
                    {
                        // 获取触发扬声器的报警类型字段值
                        if (GetIntegerValue(cAlarmType, iAlarmType) == 0)
                        {
                            // 获取文件播放几次字段
                            cLoopCnt = cJSON_GetObjectItem(cOutputJson, "LoopCnt");
                            if (cLoopCnt)
                            {
                                // 获取文件播放几次字段值
                                if (GetIntegerValue(cLoopCnt, iLoopCnt) == 0)
                                {
                                    // TODO
                                    // 如果SoundType为4时,再根据AlarmType播放某类型的默认告警声音,最后根据LoopCnt字段做次数播放
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 释放JSON
    if (cOutputJson != NULL)
    {
        cJSON_Delete(cOutputJson);
        cOutputJson = NULL;
    }
    return 0;
}

/**
 * 向扬声器IoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_buzzer_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_BUZZER中
     * json格式(需要对接厂商自己解析,取出对应的值并设置)：
     *          {"Volume":100}
     * Volume       门铃铃声音量
     */
    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu]\n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Prop Value: %s \n", pstProp == NULL ? (unsigned char*)"null":pstProp);

    return 0;
}

/**
 * 向AIiOT 设备输出信号回调接口,通过该接口,将输出信号类型和对应的JSON描述字符串输出到AIiOT设备；
 */
int aiiot_camera_output(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    /**
     * 控制信息一般json格式通过pSignalValue传递下来,需要对接厂商解析并设置
     */
    __INFO_PRINTF("device aiiot output, aiiot type [%u] aiiot id [%llu] \n", uiAIIoTType, uiAIIoTID);
    __INFO_PRINTF("Signal Value: %s \n", pSignalValue ==NULL ? (unsigned char*)"null":pSignalValue);


    if((pSignalValue == NULL)|| (strlen((char*)pSignalValue) <= 0))
    {
        __ERROR_PRINTF("device aiiot camera output failed\n");
        return -1;
    }

    int iDeviceIAwakeFlag = 0;
    cJSON *cSignalValue = NULL;
    cSignalValue = cJSON_Parse((char*)pSignalValue);
    if(cSignalValue == NULL)
    {
        __ERROR_PRINTF("device aiiot camera output failed, json prase err\n");
        return -1;
    }

    // 设备开关状态,0.关闭； 1.打开
    if(GetIntegerValue(cJSON_GetObjectItem(cSignalValue,"CtrlType"), &iDeviceIAwakeFlag)==0)
    {
        // 厂家添加打印就好，休眠SDK内部已处理控制
        if (iDeviceIAwakeFlag == 0)
        {
            __INFO_PRINTF(" Device Go To Sleep: \n");
        }
        else if (iDeviceIAwakeFlag == 1)
        {
            __INFO_PRINTF(" Device Go To Awake: \n");
        }
    }

    if (NULL != pstTriggerInf)
    {
        __INFO_PRINTF(" trigger info: \n");
        __INFO_PRINTF("    uiIotType: %u\n",   pstTriggerInf->uiIotType);
        __INFO_PRINTF("     lluIotId: %llu\n", pstTriggerInf->lluIotId);
        __INFO_PRINTF("    uiEventId: %u\n",   pstTriggerInf->uiEventId);
        __INFO_PRINTF("   uiDuration: %u\n",   pstTriggerInf->uiDuration);
        __INFO_PRINTF("  tCreateTime: %lu\n",  pstTriggerInf->tCreateTime);
        __INFO_PRINTF("   pstHandler: %p\n",   pstTriggerInf->pstHandler);
    }

    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_humanalarmnew_setporp(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * EN_ZJ_AIIOT_TYPE_HUMANALARMNEW 中
     * json格式(需要对接厂商自己解析,取出对应的值并设置)：
     * {
     *      "Sensitive":"灵敏度0-100(string)",
     *      "Status":"功能开关(string)",
     *      "Trace":"是否追踪(string)",
     *      "Interval":"事件检测间隔(string)",
     *      "Capture":"抓拍开关(string)",
     *      "Vedio":"视频开关(string)"
     * }
     */

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);

    int iStatus     = 0;
    cJSON *cProp    = NULL;
    cJSON *cStatus  = NULL;
    if((pstProp == NULL)|| (strlen((char*)pstProp) <= 0))
    {
        __ERROR_PRINTF("device aiiot set prop failed\n");
        return -1;
    }
    cProp = cJSON_Parse((char*)pstProp);
    if(cProp == NULL)
    {
        __ERROR_PRINTF("device aiiot set prop failed, json prase err\n");
        return -1;
    }
    // 实现相关属性解析
    cStatus = cJSON_GetObjectItem(cProp, "Status");
    if(cStatus != NULL)
    {
        if(GetIntegerValue(cStatus, &iStatus)==0)
        {
            g_StIotMng.stNewHumanAlarm.stEvent.iStatus = iStatus;
        }
        __INFO_PRINTF("device aiiot set prop, aiiot type [%u] NewHumanAlarm aiiot id [%llu]:\n", uiAIIoTType, uiAIIoTID);
        __INFO_PRINTF("                                              Status: [%d]\n", g_StIotMng.stNewHumanAlarm.stEvent.iStatus);      
    }
    if (cProp != NULL)
    {
        cJSON_Delete(cProp);
        cProp = NULL;
    }

    return 0;
}

/**
 * 向AIIoT设备设置属性回调接口,通过该接口,将新的属性值设置给AIIoT设备,让设备以设置的属性值进行工作；属性以一个JSON字符串传递；
 * 
 * 注意：json解析使用的是cJson仅供参考
 */
int aiiot_videoplay_setprop(unsigned int uiAIIoTType, unsigned long long uiAIIoTID, unsigned char* pstProp)
{
    /**
     * json格式(需要对接厂商自己解析,取出对应的值并设置)：
     * {
     *      "Status":"功能开关(string)",
     * }
     */

    __INFO_PRINTF("device aiiot set prop, aiiot type [%u] aiiot id [%llu] prop:%s \n", uiAIIoTType, uiAIIoTID, pstProp);
    return 0;
}

/**
 * 摄像头自定义铃声文件删除回调接口
 */
int aiiot_buzzer_delsoundfile(unsigned char *pucSoundName)
{
    printf("aiiot_buzzer_delsoundfile %s\r\n",pucSoundName);
    return 0;
}
/**
 * 门铃&摄像头自定义铃声文件回调接口
 *  *门铃设备内置固定声音文件
 *  *摄像头设备需厂商管理自定义声音文件列表
 *  *对于门铃设备,是内置门铃音频文件列表
 *  *对于非门铃设备,是自定义下载音频文件和预设内置告警声列表
 */
int aiiot_buzzer_getsoundfiles( unsigned int *piTotalSize, unsigned int *piFreeSize, ST_ZJ_SOUNDFILE_INFO **pstHeadNode, EN_ZJ_RING_TYPE enSoundType)
{
    int i = 0;
    ST_ZJ_SOUNDFILE_INFO *pstPreNode = NULL;
    ST_ZJ_SOUNDFILE_INFO *pstTmpNode = NULL;
    #ifdef APP_DOORBELL
    ST_ZJ_SOUNDFILE_INFO soundfiles[] = {{"quickreply_wait",0,0x01,"稍等稍等,马上来", 0x01},
                                         {"quickreply_wait2",0,0x01,"这就给您开门,请稍等", 0x01},
                                         {"quickreply_refuse",0,0x01,"主人不在家,请给我留言", 0x01},
                                         {"quickreply_express",0,0x01,"您好,快递请放在门口,谢谢", 0x01},
                                         {"ringtone_dingdong",0,0x02,"叮声", 0x01},
                                         {"ringtone_dingling",0,0x02,"叮铃", 0x01},
                                         {"ringtone_kong",0,0x02,"空竹声", 0x01},
                                         {"ringtone_welcome",0,0x02,"欢迎光临", 0x01},
                                         {"warning_normal",0,0x04,"普通告警音", 0x01}};
    #else // 预置的声音文件由厂商自己生成
    ST_ZJ_SOUNDFILE_INFO soundfiles[] = {{"presetsound_medicine", 0, 0x01, "请准时吃药",      0x02},
                                         {"presetsound_clockin",  0, 0x01, "上下班请打卡",    0x02},
                                         {"presetsound_welcome",  0, 0x01, "欢迎光临",        0x02},
                                         {"presetsound_caution",  0, 0x01, "请注意安全",      0x02},
                                         {"presetsound_closedoor",0, 0x01, "请随手关门",      0x02},
                                         {"presetsound_steps",    0, 0x01, "请小心台阶",      0x02},
                                         {"presetsound_area",     0, 0x01, "你已进入监控区域", 0x02}};
    #endif

    *piFreeSize  =  512*1024*1024;
    *piTotalSize = 1024*1024*1024;

    // 注意：pstHeadNode参数, 有声音文件时, 需要每个节点malloc, 拼接成链表 该malloc在SDK内部释放
    for (i=0; i<7; i++) // 循环次数根据soundfiles数组的大小定
    {
        if (pstTmpNode == NULL)
        {
            pstTmpNode = malloc(sizeof(ST_ZJ_SOUNDFILE_INFO));
            *pstHeadNode = pstTmpNode;
        }
        else
        {
            pstTmpNode = malloc(sizeof(ST_ZJ_SOUNDFILE_INFO));
        }
        
        strcpy((char*)(pstTmpNode->aucFileName), (char*)(soundfiles[i].aucFileName));
        strcpy((char*)(pstTmpNode->aucFileContent), (char*)(soundfiles[i].aucFileContent));
        pstTmpNode->uiFileSize      = 2*1024;
        pstTmpNode->uiFileFormat    = soundfiles[i].uiFileFormat;
        pstTmpNode->uiFileCategory  = soundfiles[i].uiFileCategory;
        pstTmpNode->pstNextNode     = 0;
        if (pstPreNode)
        {
            pstPreNode->pstNextNode = pstTmpNode;
        }
        pstPreNode = pstTmpNode;
    }

    return 0;
}

/**
 * 摄像头文件下载通知回调接口
 *  uiFileType : EN_ZJ_FILE_FORMAT  自定义声音文件
 *  uiFileSize : 文件大小,字节
 *  pucFileName: 文件名
 *  return     : 0-ok   1-fail
 */
int aiiot_filedown_notice(unsigned int uiFileType,unsigned int uiFileSize,unsigned char *pucFileName)
{
    printf("%s type=%d size=%d name=%s\r\n",__FUNCTION__,uiFileType,uiFileSize,pucFileName);
    return 0;
}

/**
 * 摄像头文件下载传输回调接口
 *  pucPackage : 数据
 *  uiPacklen  : 数据长度
 *  uiEndFlag  : 结束标志   0-正在下载    1-下载结束
 *  return     : 0-ok   1-fail
 */
int aiiot_filedown_trans(unsigned char *pucPackage,unsigned int uiPacklen,unsigned int uiEndFlag)
{
    printf("%s plen=%d endflag=%d\r\n",__FUNCTION__,uiPacklen,uiEndFlag);
    return 0;
}

/**
 * 摄像头文件下载停止回调接口 - 下载错误,通知删除文件
 *  return     : 0-ok
 */
int aiiot_filedown_stop()
{
    printf("%s\r\n",__FUNCTION__);
    return 0;
}

// 释放上报IOT AI图片和视频的缓存
int aiiot_free_upload_aialarm_pv_cache(unsigned char *ucPicPath, unsigned char *ucVideoPath)
{
    // TODO
    // 文件路径判断, 并删除相关文件和释放相关内存
    char cmd[512] = {0};
    if (ucPicPath && strlen(ucPicPath))
    {
        sprintf(cmd, "rm %s", ucPicPath);
        system(cmd);
        __INFO_PRINTF("free PicPath[%s]\n", ucPicPath);
    }
    if (ucVideoPath && strlen(ucVideoPath))
    {
        sprintf(cmd, "rm %s", ucVideoPath);
        system(cmd);
        __INFO_PRINTF("free VideoPath[%s]\n", ucVideoPath);
    }
    return 0;
}

// 释放启动前可能存在的缓存
int aiiot_free_before_startup_cache(EN_ZJ_FREE_BEFORE_STARTUP_CACHE_TYPE iFreeStartUpCacheType)
{
    // TODO 释放启动前可能存在的缓存

    return 0;
}

// 人流量统计开关, 统计间隔回调函数
// uiOpenFlag: 人流量统计开关
// uiInterval: 时间单位：分钟（默认1分钟）
int ai_SetHumanCountParamCb(unsigned int uiOpenFlag,unsigned int uiInterval)
{
    __INFO_PRINTF("ai_SetHumanCountParamCb uiOpenFlag:%d uiInterval:%d  TODO \n", uiOpenFlag, uiInterval);

    // TODO 设置人流统计参数
    return 0;
}

// 人流量统计坐标设置回调函数
int ai_SetHumanCountRegionsCb(unsigned char *pucRegions)
{
    __INFO_PRINTF("ai_SetHumanCountRegionsCb pucRegions: %s TODO \n", pucRegions);
    
    // TODO 设置人流统计坐标
    return 0;
}

/**
 * 常用IOT类型注册参考：
 * EN_ZJ_AIIOT_TYPE_MOTION 需要注册：aiiot_start、aiiot_stop、aiiot_setprop
 * EN_ZJ_AIIOT_TYPE_DNSET 需要注册：aiiot_start、aiiot_stop、aiiot_output
 * EN_ZJ_AIIOT_TYPE_INNER_LAMP 需要注册：aiiot_start、aiiot_stop、aiiot_output
 * 
 * EN_ZJ_AIIOT_TYPE_BUZZER 需要注册：aiiot_start、aiiot_stop、aiiot_setprop、aiiot_output
 * 备注：
 *     1. 只用告警类型的iot才会使用到prop,其他iot控制使用output控制
 *     2. prop 和 output json内容参考 "zj_cameraiot.h"
 *     3. 除了Motion和Human的Interval默认值不为0;其他告警的默认Interval都为0
*/

int iot_init()
{
    // 客流统计回调设置 用于重启后回调客流统计区域等信息
    ZJ_SetHumanCountFuncsCB(ai_SetHumanCountParamCb, ai_SetHumanCountRegionsCb);
    
    memset(&g_StIotMng, 0, sizeof(g_StIotMng));

#if USE_NEW_FACE
    /**
     * 新人脸抓拍注册示例
     * 注意:1. 默认属性Status和IOT 1000默认属性Face字段有冲突，请删除IOT 1000默认属性Face字段
     *      2. 当对接旧人脸时，该IOT不能注册
    */

    // 设置人脸抓拍能力值 0.不支持；1.支持
    ZJ_SetDevAiCommonAbility("NewFaceCaptureAbility", 1);

    char *pcFaceCaptureProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Trace\":\"0\",\"Interval\":\"30\"}";

    // 添加人脸抓拍告警IoT设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_FACE_CAPTURE,
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop,
                        NULL,
                        NULL,
                        aiiot_faceCapture_setprop,
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot face capture register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_FACE_CAPTURE, EN_ZJ_DEFAULT_IOTID);

        // 设置人脸抓拍默认属性
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_FACE_CAPTURE, EN_ZJ_DEFAULT_IOTID, (unsigned char *)pcFaceCaptureProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_FaceCapture = {0};
        stIoTPolicyInfo_FaceCapture.uiInIoTType    = EN_ZJ_AIIOT_TYPE_FACE_CAPTURE;
        stIoTPolicyInfo_FaceCapture.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_FaceCapture.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_FaceCapture.uiOpenFlag     = 1;
        stIoTPolicyInfo_FaceCapture.uiSpanFlag     = 0;
        stIoTPolicyInfo_FaceCapture.uiStartTime    = 0;
        stIoTPolicyInfo_FaceCapture.uiEndTime      = 86400;
        stIoTPolicyInfo_FaceCapture.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char *)(stIoTPolicyInfo_FaceCapture.aucPolicyName), IOT_POLICYNAME_FACECAPTURE, sizeof(stIoTPolicyInfo_FaceCapture.aucPolicyName));

        // 添加人脸抓拍告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_FaceCapture);
    }

    /**
     * 新人脸识别(布控)注册示例
     * 注意:1. 默认属性Status和IOT 1000默认属性Face字段有冲突，请删除IOT 1000默认属性Face字段
     *      2. 当对接旧人脸时，该IOT不能注册
    */

    // 设置人脸识别能力值 0.不支持；1.只支持黑名单；2.只支持白名单；3.支持黑/白名单(不支持同时打开)；4.支持黑/白名单(支持同时打开)
    ZJ_SetDevAiCommonAbility("NewFaceDiscernAbility", 3);

    char *pcFaceDiscernProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Model\":\"0\",\"Trace\":\"0\",\"Interval\":\"30\"}";

    // 添加人脸识别告警IoT设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_FACE_DISCERN,
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop,
                        NULL,
                        NULL,
                        aiiot_faceDiscern_setprop,
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot face discern register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_FACE_DISCERN, EN_ZJ_DEFAULT_IOTID);

        // 设置人脸识别默认属性
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_FACE_DISCERN, EN_ZJ_DEFAULT_IOTID, (unsigned char *)pcFaceDiscernProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_FaceDiscern = {0};
        stIoTPolicyInfo_FaceDiscern.uiInIoTType    = EN_ZJ_AIIOT_TYPE_FACE_DISCERN;
        stIoTPolicyInfo_FaceDiscern.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_FaceDiscern.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_FaceDiscern.uiOpenFlag     = 1;
        stIoTPolicyInfo_FaceDiscern.uiSpanFlag     = 0;
        stIoTPolicyInfo_FaceDiscern.uiStartTime    = 0;
        stIoTPolicyInfo_FaceDiscern.uiEndTime      = 86400;
        stIoTPolicyInfo_FaceDiscern.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char *)(stIoTPolicyInfo_FaceDiscern.aucPolicyName), IOT_POLICYNAME_FACEDISCERN, sizeof(stIoTPolicyInfo_FaceDiscern.aucPolicyName));

        // 添加人脸识别告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_FaceDiscern);
    }
#endif

    char *pcMotionProp = "{\"Motion\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Trace\":\"0\",\"Interval\":\"30\"},"
                          "\"Human\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Trace\":\"0\",\"Interval\":\"30\"},"
                          #if !USE_NEW_FACE
                          "\"Face\":{\"Sensitive\":\"20\",\"Status\":\"0\",\"DiscernFlag\":\"0\",\"Trace\":\"0\",\"Interval\":\"0\"},"
                          #endif
                          "\"Fence\":{\"EventType\":\"1\",\"OnlyFlag\":\"0\",\"Status\":\"0\",\"Direction\":\"1\",\"StayTime\":\"0\","
                                     "\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"Capture\":\"0\",\"Video\":\"0\",\"ExpandEventAbility\":\"3\","
                                     "\"Regions\":{"
                                        "\"RegionNum\":\"0\","
                                        "\"Regions\":[{\"RegionId\":\"0\",\"RegionPoints\":[{\"x\":\"0.000\",\"y\":\"0.000\"},{\"x\":\"0.000\",\"y\":\"0.000\"},{\"x\":\"0.000\",\"y\":\"0.000\"},{\"x\":\"0.000\",\"y\":\"0.000\"}]}]}},"
                          "\"CarNum\":{\"Sensitive\":\"20\",\"Status\":\"0\",\"Trace\":\"0\",\"Interval\":\"0\"},"
                          "\"Car\":{\"Sensitive\":\"20\",\"Status\":\"0\",\"Trace\":\"0\",\"Interval\":\"0\"}}";

    /**
     * 运动侦测IOT注册示例
     * 运动侦测包含三种事件类型
     * EN_ZJ_MOTION_EVENT_MOTION       移动侦测事件类型
     * EN_ZJ_MOTION_EVENT_HUMAN        人形侦测事件类型
     * EN_ZJ_MOTION_EVENT_FACE         人脸侦测事件类型
     * 
     * 注意: 1. MOTION IOT不需要设置策略，SDK内部已添加相关策略
     *       2. 当对接新人脸时，需要删除Face字段
     */
#if 1
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_MOTION, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_motion_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot motion register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcMotionProp);
        // unsigned char aucLampBuff1[256]    = {0};
        // snprintf((char*)aucLampBuff1,256,"{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\",\"AddOutputProp\":\"0\"}");
        // ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_HUMAN,EN_ZJ_AIIOT_TYPE_INNER_LAMP,EN_ZJ_DEFAULT_IOTID, aucLampBuff1);
        // ZJ_DelAlarmPolicyOutputProp(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_HUMAN,
        //                         EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID,
        //                         (unsigned char*)"AddOutputProp");
    }

    // 删除IOT类型的属性字段
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "Motion");
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "Human");
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "Face");
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "CarNum");
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID, 0, "Interval", "Car");
#endif

    unsigned char aucLampBuff[256]    = {0};
    unsigned char aucBuzzerBuff[256]  = {0};
 
    char *pcMaskProp = "{\"Sensitive\":\"50\",\"Status\":\"0\",\"Interval\":\"0\",\"Trace\":\"0\",\"Capture\":\"0\",\"Video\":\"0\"}";
    // 添加口罩识别告警IoT设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_MASK, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_Mask_setprop, 
                        NULL) == 0)
    {
        // 设置口罩识别默认属性
        __INFO_PRINTF("device iot Mask register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcMaskProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_Mask = {0};
        stIoTPolicyInfo_Mask.uiInIoTType    = EN_ZJ_AIIOT_TYPE_MASK;
        stIoTPolicyInfo_Mask.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_Mask.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_Mask.uiOpenFlag     = 1;
        stIoTPolicyInfo_Mask.uiSpanFlag     = 0;
        stIoTPolicyInfo_Mask.uiStartTime    = 0;
        stIoTPolicyInfo_Mask.uiEndTime      = 86400;
        stIoTPolicyInfo_Mask.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_Mask.aucPolicyName), IOT_POLICYNAME_MASK, sizeof(stIoTPolicyInfo_Mask.aucPolicyName));
        // 添加口罩识别告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_Mask);
        // 添加响应IoT需要根据产品需求添加,联系产品经理确认
        // 口罩识别告警IoT添加响应IoT-扬声器
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"0\",\"ExecuteTime\":[]}", EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 口罩识别告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0, 过滤白光灯联动
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }
    // TEST
    // 口罩识别告警IoT删除属性字段  StartTime
    // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, (unsigned char*)"StartTime", NULL);
    // 删除 口罩识别告警IoT 联动 响应的IOT白光灯 的 动作属性(字段) EndTime
    // ZJ_DelAlarmPolicyOutputProp(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID,
    //                             EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID,
    //                             (unsigned char*)"EndTime");
    // 口罩识别告警IoT删除响应IoT-白光灯
    // ZJ_DelAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID);
    // 口罩识别告警IoT添加响应IoT-白光灯
    // ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    // 删除口罩识别告警IoT的联动策略类型
    // ZJ_DelIoTDefaultPolicy(EN_ZJ_AIIOT_TYPE_MASK, EN_ZJ_DEFAULT_IOTID);

    char *pcFlamDetectProp = "{\"Sensitive\":\"50\",\"Status\":\"0\",\"Interval\":\"30\",\"Trace\":\"0\",\"Capture\":\"0\",\"Video\":\"0\"}";
    // 添加烟火检测告警IoT设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_FLAMEDETECT, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_FlameDetect_setprop, 
                        NULL) == 0)
    {
        // 设置烟火检测默认属性
        __INFO_PRINTF("device iot FlameDetect register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_FLAMEDETECT, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_FLAMEDETECT, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcFlamDetectProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_FlameDetect = {0};
        stIoTPolicyInfo_FlameDetect.uiInIoTType    = EN_ZJ_AIIOT_TYPE_FLAMEDETECT;
        stIoTPolicyInfo_FlameDetect.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_FlameDetect.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_FlameDetect.uiOpenFlag     = 1;
        stIoTPolicyInfo_FlameDetect.uiSpanFlag     = 0;
        stIoTPolicyInfo_FlameDetect.uiStartTime    = 0;
        stIoTPolicyInfo_FlameDetect.uiEndTime      = 86400;
        stIoTPolicyInfo_FlameDetect.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_FlameDetect.aucPolicyName), IOT_POLICYNAME_FLAMEDETECT, sizeof(stIoTPolicyInfo_FlameDetect.aucPolicyName));
        // 添加烟火检测告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_FlameDetect);
        // 添加响应IoT需要根据产品需求添加,联系产品经理确认
        // 烟火检测告警IoT添加响应IoT-扬声器
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"0\",\"ExecuteTime\":[]}", EN_ZJ_AIIOT_TYPE_FLAMEDETECT, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_FLAMEDETECT, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 烟火检测告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_FLAMEDETECT, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }

    // 添加电瓶车检测告警IoT设备
    char *pcBatteryBikeProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Interval\":\"1\",\"Capture\":\"0\",\"Video\":\"0\",\"RegionNum\":\"1\",\"Regions\":[{\"RegionId\":\"1\",\"RegionPoints\":[{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"}]}]}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_BATTERYBIKE, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_BatteryBike_setprop, 
                        NULL) == 0)
    {
        // 设置电瓶车检测默认属性
        __INFO_PRINTF("device iot BatteryBike register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_BATTERYBIKE, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_BATTERYBIKE, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcBatteryBikeProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_BatteryBike = {0};
        stIoTPolicyInfo_BatteryBike.uiInIoTType     = EN_ZJ_AIIOT_TYPE_BATTERYBIKE;
        stIoTPolicyInfo_BatteryBike.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_BatteryBike.uiInIoTEventId  = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_BatteryBike.uiOpenFlag      = 1;
        stIoTPolicyInfo_BatteryBike.uiSpanFlag      = 0;
        stIoTPolicyInfo_BatteryBike.uiStartTime     = 0;
        stIoTPolicyInfo_BatteryBike.uiEndTime       = 86400;
        stIoTPolicyInfo_BatteryBike.uiWeekFlag      = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_BatteryBike.aucPolicyName), IOT_POLICYNAME_BATTERYBIKE, sizeof(stIoTPolicyInfo_BatteryBike.aucPolicyName));
        // 添加电瓶车检测告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_BatteryBike);
        // 添加响应IoT需要根据产品需求添加,联系产品经理确认
        // 电瓶车检测告警IoT添加响应IoT-扬声器
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"0\",\"ExecuteTime\":[]}", EN_ZJ_AIIOT_TYPE_BATTERYBIKE, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_BATTERYBIKE, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 电瓶车检测告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_BATTERYBIKE, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }

    // 添加高空抛物检测告警IoT设备
    #if 0
    char *pcHighParabolicProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Interval\":\"30\",\"Capture\":\"0\",\"Video\":\"0\"}";
    #else
    char *pcHighParabolicProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Interval\":\"30\",\"Capture\":\"0\",\"Video\":\"0\",\"RegionNum\":\"100034\",\"Regions\":[{\"RegionId\":\"1\",\"RegionPoints\":[{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"}]}],\"WaterMarkNum\":\"267543\",\"WaterMarks\":[{\"WaterMarkId\":\"1\",\"FontSize\":\"8\",\"FontContent\":\"10Floor\",\"WaterMarkPoints\":[{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"}]}]}";
    #endif
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_HighParabolic_setprop, 
                        NULL) == 0)
    {
        // 设置高空抛物检测默认属性
        __INFO_PRINTF("device iot HighParabolic register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcHighParabolicProp);
    
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_HighParabolic = {0};
        stIoTPolicyInfo_HighParabolic.uiInIoTType     = EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC;
        stIoTPolicyInfo_HighParabolic.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_HighParabolic.uiInIoTEventId  = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_HighParabolic.uiOpenFlag      = 1;
        stIoTPolicyInfo_HighParabolic.uiSpanFlag      = 0;
        stIoTPolicyInfo_HighParabolic.uiStartTime     = 0;
        stIoTPolicyInfo_HighParabolic.uiEndTime       = 86400;
        stIoTPolicyInfo_HighParabolic.uiWeekFlag      = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_HighParabolic.aucPolicyName), IOT_POLICYNAME_HIGHPARABOLIC, sizeof(stIoTPolicyInfo_HighParabolic.aucPolicyName));
        // 添加高空抛物检测告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_HighParabolic);
        // 添加响应IoT需要根据产品需求添加,联系产品经理确认
        // 高空抛物检测告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        #if 0
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\"}");
        #else
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        #endif
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
        // 删除IOT类型的属性字段
        // ZJ_DelIoTProp(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC,EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, "Interval", NULL);
    }

    ZJ_SetDevAiCommonAbility("HelmetAlarmAbility", 1);
    // 添加头盔检测告警IoT设备
    char *pcHelmetDefaultProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Interval\":\"30\",\"Capture\":\"0\",\"Regions\":[{\"RegionId\":\"1\",\"RegionPoints\":[{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"},{\"x\":\"0.100\",\"y\":\"0.001\"}]}]}";
    /*支持追踪*/
    // char *pcHelmetDefaultProp = "{\"Sensitive\":\"20\",\"Status\":\"0\",\"Trace\":\"0\",\"Interval\":\"30\",\"Capture\":\"0\"}"; // 支持追踪设备
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_HELMET, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_Helmet_setprop, 
                        NULL) == 0)
    {
        // 设置头盔检测默认属性
        __INFO_PRINTF("device iot Helmet register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcHelmetDefaultProp);
    
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_Helmet = {0};
        stIoTPolicyInfo_Helmet.uiInIoTType     = EN_ZJ_AIIOT_TYPE_HELMET;
        stIoTPolicyInfo_Helmet.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_Helmet.uiInIoTEventId  = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_Helmet.uiOpenFlag      = 1;
        stIoTPolicyInfo_Helmet.uiSpanFlag      = 0;
        stIoTPolicyInfo_Helmet.uiStartTime     = 0;
        stIoTPolicyInfo_Helmet.uiEndTime       = 86400;
        stIoTPolicyInfo_Helmet.uiWeekFlag      = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_Helmet.aucPolicyName), IOT_POLICYNAME_HELMET, sizeof(stIoTPolicyInfo_Helmet.aucPolicyName));
        // 添加头盔检测告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_Helmet);
        // 添加响应IoT需要根据产品需求添加,联系产品经理确认
        // 头盔检测告警IoT添加响应IoT-扬声器
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"0\",\"ExecuteTime\":[]}", EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 头盔检测告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HELMET, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }

    // 添加隐私遮罩能力值 0:不支持; 1:支持,只支持单个矩形区域; 2:支持,支持单个多边形区域; 3:支持,支持多个矩形区域; 4:支持,支持多个多边形区域
    ZJ_SetDevAiCommonAbility("PrivacyMaskAbility", 1);

    // 添加隐私遮罩告警IoT设备
    char *pcPrivacyMaskDefaultProp = "{\"Status\":\"0\",\"MaskMode\":\"0\","
                                     "\"Regions\":[{\"RegionId\":\"0\",\"RegionPoints\":[{\"x\":\"0.000\",\"y\":\"0.000\"},{\"x\":\"0.000\",\"y\":\"0.000\"}]}],"
                                     "\"ExecuteTime\":[{\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\"}]}";

    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_PRIVACYMASK, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_PrivacyMask_setprop, 
                        NULL) == 0)
    {
        // 设置隐私遮罩默认属性
        __INFO_PRINTF("device iot PrivacyMask register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_PRIVACYMASK, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_PRIVACYMASK, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcPrivacyMaskDefaultProp);
    
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_PrivacyMask = {0};
        stIoTPolicyInfo_PrivacyMask.uiInIoTType     = EN_ZJ_AIIOT_TYPE_PRIVACYMASK;
        stIoTPolicyInfo_PrivacyMask.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_PrivacyMask.uiInIoTEventId  = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_PrivacyMask.uiOpenFlag      = 1;
        stIoTPolicyInfo_PrivacyMask.uiSpanFlag      = 0;
        stIoTPolicyInfo_PrivacyMask.uiStartTime     = 0;
        stIoTPolicyInfo_PrivacyMask.uiEndTime       = 86400;
        stIoTPolicyInfo_PrivacyMask.uiWeekFlag      = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_PrivacyMask.aucPolicyName), IOT_POLICYNAME_PRIVACYMASK, sizeof(stIoTPolicyInfo_PrivacyMask.aucPolicyName));
        // 添加隐私遮罩告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_PrivacyMask);
    }
	
 #if USE_EBO_ROBOOT   
    /**
     * 添加ebo机器人报警IOT示例
    */
      char *pcEboRobotProp =  "{\"Shake\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Interval\":\"30\"},"
                          "\"LowPower\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Interval\":\"30\"},"
                          "\"Recharge\":{\"Sensitive\":\"20\",\"Status\":\"1\",\"Interval\":\"30\"}}";
    // 添加ebo机器人告警IOT
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        NULL, 
                        aiiot_EboRobot_setprop, //一期暂时未用到，可配置为NULL
                        NULL) == 0)
    {
        // 设置ebo机器人默认属性
        __INFO_PRINTF("device iot ebo register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_EBO_ROBOT, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcEboRobotProp);
        
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_eboRobot = {0};
        stIoTPolicyInfo_eboRobot.uiInIoTType           = EN_ZJ_AIIOT_TYPE_EBO_ROBOT;
        stIoTPolicyInfo_eboRobot.lluInIoTId            = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_eboRobot.uiOpenFlag            = 1;
        stIoTPolicyInfo_eboRobot.uiSpanFlag            = 0;
        stIoTPolicyInfo_eboRobot.uiStartTime           = 0;
        stIoTPolicyInfo_eboRobot.uiEndTime             = 86400;
        stIoTPolicyInfo_eboRobot.uiWeekFlag            = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_eboRobot.aucPolicyName), IOT_POLICYNAME_EBO_ROBOT, sizeof(stIoTPolicyInfo_eboRobot.aucPolicyName));

        // 添加连续摇晃事件默认联动策略
        stIoTPolicyInfo_eboRobot.uiInIoTEventId = EN_ZJ_EBO_ROBOT_EVENT_SHAKE;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_eboRobot);
        // 删除连续摇晃事件联动策略-云存
        ZJ_DelAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_EBO_ROBOT,  EN_ZJ_DEFAULT_IOTID, EN_ZJ_EBO_ROBOT_EVENT_SHAKE, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, EN_ZJ_DEFAULT_IOTID);

        // 添加低电量事件默认联动策略
        stIoTPolicyInfo_eboRobot.uiInIoTEventId = EN_ZJ_EBO_ROBOT_EVENT_LOW_POWER;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_eboRobot);
        // 删除低电量事件联动策略-云存
        ZJ_DelAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_EBO_ROBOT,  EN_ZJ_DEFAULT_IOTID, EN_ZJ_EBO_ROBOT_EVENT_LOW_POWER, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, EN_ZJ_DEFAULT_IOTID);

        // 添加回充失败事件默认联动策略类型
        stIoTPolicyInfo_eboRobot.uiInIoTEventId = EN_ZJ_EBO_ROBOT_EVENT_RECHARGE_FAILED;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_eboRobot);
        // 删除回充失败事件联动策略-云存
        ZJ_DelAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_EBO_ROBOT,  EN_ZJ_DEFAULT_IOTID, EN_ZJ_EBO_ROBOT_EVENT_RECHARGE_FAILED, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, EN_ZJ_DEFAULT_IOTID);
    }
 #endif
 
    ZJ_SetDevAiCommonAbility("CarAnalyseAbility", 1);
    // 添加车辆分析告警IoT设备
    char *pcCarAnalyseDefaultProp = "{\"Sensitive\":\"80\",\"Status\":\"0\",\"Interval\":\"1\",\"Capture\":\"0\",\"StayTime\":\"600\",\"StayIntervalTime\":\"60\",\"StayIntervalAlarmFreq\":\"1\",\"CarNumSwitch\":\"0\",\"Regions\":[],\"ExecuteTime\":[]}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_CAR_ANALYSE, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_car_analyse_setprop, 
                        NULL) == 0)
    {
        // 设置车辆分析检测默认属性
        __INFO_PRINTF("device iot Car Analyse register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_CAR_ANALYSE, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_CAR_ANALYSE, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcCarAnalyseDefaultProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_CarAnalyse = {0};
        stIoTPolicyInfo_CarAnalyse.uiInIoTType     = EN_ZJ_AIIOT_TYPE_CAR_ANALYSE;
        stIoTPolicyInfo_CarAnalyse.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_CarAnalyse.uiInIoTEventId  = EN_ZJ_CAR_ANALYSE_EVENT_STAY;
        stIoTPolicyInfo_CarAnalyse.uiOpenFlag      = 1;
        stIoTPolicyInfo_CarAnalyse.uiSpanFlag      = 0;
        stIoTPolicyInfo_CarAnalyse.uiStartTime     = 0;
        stIoTPolicyInfo_CarAnalyse.uiEndTime       = 86400;
        stIoTPolicyInfo_CarAnalyse.uiWeekFlag      = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_CarAnalyse.aucPolicyName), IOT_POLICYNAME_CAR_ANALYSE, sizeof(stIoTPolicyInfo_CarAnalyse.aucPolicyName));
        // 添加车辆分析检测告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_CarAnalyse);
        // 添加响应IoT需要根据产品需求添加,联系产品经理确认
        // 车辆分析检测告警IoT添加响应IoT-扬声器
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\"}", EN_ZJ_AIIOT_TYPE_CAR_ANALYSE, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_CAR_ANALYSE, EN_ZJ_DEFAULT_IOTID, EN_ZJ_CAR_ANALYSE_EVENT_STAY, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 车辆分析检测告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_CAR_ANALYSE, EN_ZJ_DEFAULT_IOTID, EN_ZJ_CAR_ANALYSE_EVENT_STAY, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
        
        // 添加车辆分析-车辆离开联动策略
        stIoTPolicyInfo_CarAnalyse.uiInIoTEventId = EN_ZJ_CAR_ANALYSE_EVENT_LEAVE;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_CarAnalyse);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_CAR_ANALYSE, EN_ZJ_DEFAULT_IOTID, EN_ZJ_CAR_ANALYSE_EVENT_LEAVE, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_CAR_ANALYSE, EN_ZJ_DEFAULT_IOTID, EN_ZJ_CAR_ANALYSE_EVENT_LEAVE, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }

    // 声音检测 和 异响告警
    char *pcVoiceProp = "{\"Sensitive\":\"50\",\"Trace\":\"0\",\"Interval\":\"0\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_voice_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot Voice register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcVoiceProp);
    }

    // 哭声检测报警
    ZJ_SetDevAiCommonAbility("CryAlarmAbility", 1);

    /***如果设备支持云台追踪，属性中要增加Trace字段****/
    char *pcCryProp = "{\"Sensitive\":\"80\",\"Status\":\"0\",\"Interval\":\"30\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_CRYALARM, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        NULL, 
                        aiiot_cry_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot Cry register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_CRYALARM, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_CRYALARM, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcCryProp);
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_Cry = {0};
        stIoTPolicyInfo_Cry.uiInIoTType    = EN_ZJ_AIIOT_TYPE_CRYALARM;
        stIoTPolicyInfo_Cry.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_Cry.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_Cry.uiOpenFlag     = 1;
        stIoTPolicyInfo_Cry.uiSpanFlag     = 0;
        stIoTPolicyInfo_Cry.uiStartTime    = 0;
        stIoTPolicyInfo_Cry.uiEndTime      = 86400;
        stIoTPolicyInfo_Cry.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_Cry.aucPolicyName), IOT_POLICYNAME_CRY, sizeof(stIoTPolicyInfo_Cry.aucPolicyName));
        // 添加哭声识别告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_Cry);
    }
#if 0
    /*  一键告警
        一键告警功能注意事项：
        1) 设备启动，设备自行检测外接一键告警器的初始的插入状态并通知SDK
        2) 设备自行检测外接一键告警器的插入状态，变更则通知SDK
        3) 按一次触发一键告警，再按一次是停止当前告警声音播报
        4) 对于设备推流，在推流过程中再次触发一键告警事件，当前推流时长清0，按重新PushStreamDuration推流时长计算
        5) 一键告警推图功能默认关闭， 即："Capture":"0"
        6) 一键告警白光灯联动默认闪烁,即: "Flicker":"1"  
    */
    ZJ_SetDevAiCommonAbility("OneKeyAlarmAbility", 1);

    char *pcOneKeyAlarmProp = "{\"Status\":\"0\",\"Interval\":\"1\",\"Capture\":\"0\",\"Vedio\":\"0\",\"PushStreamProtocol\":\"0\",\"PushStreamAddr\":\"\",\"PushStreamDuration\":\"10\",\"PushStreamAddrValidDate\":\"\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_ONEKEYALARM, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_onekeyalarm_start,
                        aiiot_onekeyalarm_stop, 
                        NULL, 
                        NULL, 
                        aiiot_onekeyalarm_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot OneKeyAlarm register ok, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_ONEKEYALARM, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_ONEKEYALARM, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcOneKeyAlarmProp);
        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_OneKeyAlarm = {0};
        stIoTPolicyInfo_OneKeyAlarm.uiInIoTType    = EN_ZJ_AIIOT_TYPE_ONEKEYALARM;
        stIoTPolicyInfo_OneKeyAlarm.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_OneKeyAlarm.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_OneKeyAlarm.uiOpenFlag     = 1;
        stIoTPolicyInfo_OneKeyAlarm.uiSpanFlag     = 0;
        stIoTPolicyInfo_OneKeyAlarm.uiStartTime    = 0;
        stIoTPolicyInfo_OneKeyAlarm.uiEndTime      = 86400;
        stIoTPolicyInfo_OneKeyAlarm.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_OneKeyAlarm.aucPolicyName), IOT_POLICYNAME_ONEKEYALARM, sizeof(stIoTPolicyInfo_OneKeyAlarm.aucPolicyName));
        // 添加一键告警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_OneKeyAlarm);
        // 添加响应IoT需要根据产品需求添加，联系产品经理确认
        // 一键告警IoT添加响应IoT-扬声器
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"1\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\"}", EN_ZJ_AIIOT_TYPE_ONEKEYALARM, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_ONEKEYALARM, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 一键告警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0, 过滤白光灯联动
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"1\"}"); // 一键告警白光灯联动默认闪烁,即: "Flicker":"1"
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_ONEKEYALARM, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }
#endif
     /**
     * 红外灯注册示例
     */
    int iIRLedAbility = 1;
    int iCurWorkMode = EN_ZJ_IRMODE_AUTO;
    // 红外灯能力集配置:取值 0或1
    ZJ_SetIRLedAbility(iIRLedAbility);
    
    // 已遗弃
    // ZJ_SetCamerCurIRWorkMode(iCurWorkMode);

    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_DNSET, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        aiiot_dnset_input, 
                        aiiot_dnset_output, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot ndnset register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_DNSET, EN_ZJ_DEFAULT_IOTID);
    }

    /**
     * 白光灯注册示例,注意：注册白光灯前需要
    */
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_INNER_LAMP, 
                        EN_ZJ_DEFAULT_IOTID,
                        aiiot_start,
                        aiiot_stop, 
                        NULL, 
                        aiiot_inner_output, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot inner lamp register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID);
    }

    /**
     * 内置状态指示灯注册示例,注意：注册内置状态指示灯前需要
    */
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_INNER_STATELAMP, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        aiiot_inner_statelamp_output, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot inner statelamp register, Type [%d] ID [%llu]\n", EN_ZJ_AIIOT_TYPE_INNER_STATELAMP, EN_ZJ_DEFAULT_IOTID);
    }

    /**
     * 扬声器注册示例,注意：注册扬声器前需要
    */
    char *pcBuzzerProp = "{\"Volume\":\"100\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_BUZZER, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        aiiot_buzzer_output, 
                        aiiot_buzzer_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot buzzer register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcBuzzerProp);// 设置扬声器音量默认值
    }

    // 定时休眠能力值
    ZJ_SetTimingAwakeAbility(1);
    /**
     * 应用于设备定时休眠
     * 摄像机注册示例,注意：注册摄像机前需要 
    */
    // 设备开关状态,0.关闭； 1.打开
    // char *pcCameraProp = "{\"CtrlType\":\"0\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_CAMERA, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        aiiot_camera_output, 
                        NULL, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot camera register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_CAMERA, EN_ZJ_DEFAULT_IOTID);
        // ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_CAMERA, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcCameraProp);
    }

    // 老人吃药功能demo参考
    // 设置报警声音多时间段执行能力  老人吃药需要支持该能力值
    g_iAlarmSoundExecuteTimeAbility = 1;
    ZJ_SetCameraAlarmSoundExecuteTimeAbility(g_iAlarmSoundExecuteTimeAbility);

    // 新人形侦测能力值
    ZJ_SetDevAiCommonAbility("NewHumanAlarmAbility", 1);
    /**
     * 应用于设备老人吃药智能提醒
     * 新人形注册示例,注意：检测到检测到人形时上报 
    */
    // 新人形侦测报警属性
    char *pchumanalarmnewProp = "{\"Sensitive\":\"50\",\"Status\":\"0\",\"Interval\":\"0\",\"Trace\":\"0\",\"Capture\":\"0\",\"Video\":\"0\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        NULL, 
                        aiiot_humanalarmnew_setporp, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot humanalarmnew register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pchumanalarmnewProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_HumanNew = {0};
        stIoTPolicyInfo_HumanNew.uiInIoTType    = EN_ZJ_AIIOT_TYPE_HUMANALARMNEW;
        stIoTPolicyInfo_HumanNew.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_HumanNew.uiInIoTEventId = EN_ZJ_DEFAULT_IOT_EVENTID;
        stIoTPolicyInfo_HumanNew.uiOpenFlag     = 1;
        stIoTPolicyInfo_HumanNew.uiSpanFlag     = 0;
        stIoTPolicyInfo_HumanNew.uiStartTime    = 0;
        stIoTPolicyInfo_HumanNew.uiEndTime      = 86400;
        stIoTPolicyInfo_HumanNew.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_HumanNew.aucPolicyName), IOT_POLICYNAME_NEWHUMANALARM, sizeof(stIoTPolicyInfo_HumanNew.aucPolicyName));
        // 添加新人形侦测报警IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_HumanNew);
        // 添加响应IoT需要根据产品需求添加,联系产品经理确认
        // 新人形侦测报警IoT添加响应IoT-扬声器  PS: 老人吃药功能默认语音播报规则为每个时间段只播报一次,即："RemindRule":"1"
        snprintf((char*)aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"1\",\"ExecuteTime\":[]}", EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_RING_ALARM);
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_BUZZER, EN_ZJ_DEFAULT_IOTID, aucBuzzerBuff);
        // 新人形侦测报警IoT添加响应IoT-白光灯 V4.4.2后默认CtrlType为0
        snprintf((char*)aucLampBuff, 256, "{\"CtrlType\":\"0\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
        ZJ_AddAlarmPolicyOutput(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, EN_ZJ_DEFAULT_IOTID, EN_ZJ_DEFAULT_IOT_EVENTID, EN_ZJ_AIIOT_TYPE_INNER_LAMP, EN_ZJ_DEFAULT_IOTID, aucLampBuff);
    }

    /**
     * 双向视频通话注册示例,注意：双向视频通话前需要
    */
    char *pcvideoplayProp = "{\"Status\":\"1\",\"Interval\":\"5\"}";
    if(ZJ_AddIoTDevice(EN_ZJ_AIIOT_TYPE_VIDEOPLAY, 
                        EN_ZJ_DEFAULT_IOTID,
                        NULL,
                        NULL, 
                        NULL, 
                        NULL, 
                        aiiot_videoplay_setprop, 
                        NULL) == 0)
    {
        __INFO_PRINTF("device iot videoplay register, Type [%d] ID [%d]\n", EN_ZJ_AIIOT_TYPE_VIDEOPLAY, EN_ZJ_DEFAULT_IOTID);
        ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_VIDEOPLAY, EN_ZJ_DEFAULT_IOTID, (unsigned char*)pcvideoplayProp);

        ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo_VideoPlay = {0};
        stIoTPolicyInfo_VideoPlay.uiInIoTType    = EN_ZJ_AIIOT_TYPE_VIDEOPLAY;
        stIoTPolicyInfo_VideoPlay.lluInIoTId     = EN_ZJ_DEFAULT_IOTID;
        stIoTPolicyInfo_VideoPlay.uiInIoTEventId = EN_ZJ_VIDEOPLAY_EVENT_CALL;
        stIoTPolicyInfo_VideoPlay.uiOpenFlag     = 1;
        stIoTPolicyInfo_VideoPlay.uiSpanFlag     = 0;
        stIoTPolicyInfo_VideoPlay.uiStartTime    = 0;
        stIoTPolicyInfo_VideoPlay.uiEndTime      = 86400;
        stIoTPolicyInfo_VideoPlay.uiWeekFlag     = 0X7F;  // 或者填 127
        strncpy((char*)(stIoTPolicyInfo_VideoPlay.aucPolicyName), IOT_POLICYNAME_VIDEOPLAY, sizeof(stIoTPolicyInfo_VideoPlay.aucPolicyName));
        // 添加双向视频通话IoT的联动策略类型
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_VideoPlay);

        stIoTPolicyInfo_VideoPlay.uiInIoTEventId = EN_ZJ_VIDEOPLAY_EVENT_HANGUP;
        ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo_VideoPlay);
    }

    /**
     * 设置摄像头自定义声音文件(智能播报)能力与相关回调
    */ 
    ZJ_SetCustomizeAlarmSoundAbility(1);
    ZJ_SetCamAlarmSoundFileCB(aiiot_buzzer_delsoundfile, aiiot_buzzer_getsoundfiles);
    ZJ_SetDownLoadFileCBFuncs(aiiot_filedown_notice, aiiot_filedown_trans, aiiot_filedown_stop);

    /* 设置 释放上报IOT AI告警事件的视频图片的缓存 的回调接口 */
    ZJ_SetFreeUploadAIAlarmPVCacheCB(aiiot_free_upload_aialarm_pv_cache);

    /* 释放启动前可能存在的缓存 */
    ZJ_SetFreeBeforeStartUpCacheCB(aiiot_free_before_startup_cache);

    return 0;
}

int iot_start()
{
    g_StIotMng.iRun = 1;
    if(pthread_create(&g_StIotMng.hThread, NULL,iot_loop, NULL)!=0)
    {
        __ERROR_PRINTF("device iot create loop failed\n");
    }
    else
    {
        __INFO_PRINTF("device iot create loop ok\n");
    }
    return 0;
}
