#ifndef __TYPE_H__
#define __TYPE_H__


/*SDK相关配置文件存储路径, TestPath为测试路径使用时，请根据需求修改为实际路径*/
#define DEVICE_SYSTEM_PATH                  "./TestPath/system"
#define DEVICE_CONFIG_PATH                  "./TestPath/system/config"
#define DEVICE_AUDIO_PATH                   "./TestPath/system/audio"
#define DEVICE_TFCARD_PATH                  "./TestPath/sd"
#define DEVICE_AIPIC_PATH                   "./TestPath/system/aipic"

/*以下是音视频测试文件路径，仅测试时使用*/
//video relation
#define DEVICE_VIDEO_FILE_PATH_CFG          "./source/video/DemovideoDesc.txt" 
#define DEVICE_VIDEO_FILE_PATH_FILE         "./source/video/Demovideo.H264" 
#define DEVICE_VIDEO_FILE_PATH_CFG_265      "./source/video/DemovideoDesc_h265.txt"
#define DEVICE_VIDEO_FILE_PATH_FILE_265     "./source/video/Demovideo.h265"
//audio relation
#define DEVICE_AUDIO_FILE_PATH              "./source/video/1.wav" 
//pic relation
#define DEVICE_SNAP_FILE_JPG1               "./source/pic/longmao.jpg" 
#define DEVICE_SNAP_FILE_JPG2               "./source/pic/timg.jpg" 

// #define APP_DOORBELL     //门铃专项功能开关

#endif