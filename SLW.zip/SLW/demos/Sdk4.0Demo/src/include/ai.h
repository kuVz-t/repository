#ifndef __AI_H__
#define __AI_H__

#define AI_DEBUG 0

int ai_init();
int ai_start();

#endif