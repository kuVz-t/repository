#ifndef __AUDIO_H__
#define __AUDIO_H__
/*
    初始化
*/
int audio_init();
unsigned int getCurrentDayMsec();
/*
    启动
*/
int audio_start();
#endif
