#ifndef __VIDEO_H__
#define __VIDEO_H__

/*
    初始化
*/
int video_init(void);

/*
    启动
*/
int video_start(void);

#endif