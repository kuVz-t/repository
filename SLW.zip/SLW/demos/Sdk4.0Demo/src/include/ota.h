#ifndef __OTA_H__
#define __OTA_H__

int ota_init();
int ota_start();

#endif