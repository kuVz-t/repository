#ifndef __SYSTEM_H__
#define __SYSTEM_H__

int system_init();
int system_start();
#endif
