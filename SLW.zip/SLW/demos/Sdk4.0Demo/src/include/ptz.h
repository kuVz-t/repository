#ifndef __PTZ_H__
#define __PTZ_H__

int ptz_init();
int ptz_start();

#endif