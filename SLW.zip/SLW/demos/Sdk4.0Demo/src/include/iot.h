#ifndef __IOT_H__
#define __IOT_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <sys/un.h>

#define SERVER_NAME "@SDK40"

#define USE_EBO_ROBOOT 0   // ebo机器人
#define USE_NEW_FACE   0   // 使用新人脸抓拍和新人脸布控
typedef struct stru_IOT_EVENT_type
{
    int iot_type;
    int event_type;
}iot_event_type;

typedef struct _HTA_RECT_P_
{
  unsigned int    x;         // 坐标x
  unsigned int    y;         // 坐标y
  unsigned int    w;         // 宽
  unsigned int    h;         // 高
}HTA_RECT_P;
typedef struct _HTA_TARGET_
{
  unsigned int     ID;          // ID，同一个目标抛物值相同
  unsigned char    type;        //目标类型
  unsigned char    alarm_flg;    //目标的警报级别
  unsigned char    reserved[6];  // 保留字段
  HTA_RECT_P       rect;        // 目标区域 
}HTA_TARGET;

typedef struct stru_executeTime_inf
{
    unsigned int uiUseFlag;
    unsigned int uiIoTType;
    int iSpanFlag;
    int iRemindStatus;
    unsigned int uiStartTime;
    unsigned int uiEndTime;
    struct stru_executeTime_inf *pstNextNode;
}ST_EXECUTETIME_INF;

typedef struct stru_aiiot_event
{
    int iInterval;
    int iSensitive;
    int iStatus;
    int iTrace;
}ST_IOT_EVENT;

typedef struct stru_aiiot_event_faceDiscern
{
    ST_IOT_EVENT stEvent;
    int          iModel;
}ST_IOT_EVENT_FACEDISCERN;


typedef struct stru_aiiot_event_newai
{
    ST_IOT_EVENT stEvent;
    int          iCapture;
    int          iVideo;
}ST_IOT_EVENT_NEWAI;

typedef struct stru_aiiot_event_batterybike
{
    ST_IOT_EVENT   stEvent;
    int            iRegionNum;
    unsigned char  ucRegions;
}ST_IOT_EVENT_BATTERYBIKE;

typedef struct stru_aiiot_event_face
{
    ST_IOT_EVENT   stEvent;
    int            iDiscernFlag;
}ST_IOT_EVENT_FACE;

typedef struct stru_aiiot_event_HighParabolic
{
    ST_IOT_EVENT   stEvent;
    int            iRegionNum;
    unsigned char  ucRegions;
    int            iWaterMarkNum;
    unsigned char  ucWaterMarks;
}ST_IOT_EVENT_HIGHPARABOLIC;

typedef struct stru_aiiot_event_Fence
{
    ST_IOT_EVENT   stEvent;
    int            iStayTime;
    int            iCapture;
    int            iVideo;
}ST_IOT_EVENT_FENCE;

typedef struct stru_aiiot_event_onekeyalarm
{
    int iRunFlag;                                   // 运行标志
    pthread_t hThread;                              // 推流线程
    int iStatus;                                    // 功能开关 0:关 1:开 默认:0关闭
    int iInterval;                                  // 事件检测间隔 单位:秒(s) 默认:1s
    int iCapture;                                   // 抓拍开关 0.关闭；1.打开
    int iVedio;                                     // 视频开关 0.关闭；1.打开    
    int iPushStreamProtocol;                        // 推流使用协议 1:RTMP协议推流
    unsigned char aucPushStreamAddr[128];           // 推流目标地址
    int iPushStreamDuration;                        // 推流时长，单位:分钟，默认10分钟，上限24小时
    unsigned char aucPushStreamAddrValidDate[64];   // 推流地址有效期，格式：YYYY-MM-DD-HH-MM-SS",
}ST_IOT_EVENT_ONEKEYALARM;

typedef struct stru_aiiot_mng
{
    ST_IOT_EVENT               stMotion;
    ST_IOT_EVENT               stHuman;
    ST_IOT_EVENT               stForceMove;
    ST_IOT_EVENT               stStayAlarm;
    ST_IOT_EVENT               stCarNum;
    ST_IOT_EVENT_FACE          stFace; //旧人脸
    ST_IOT_EVENT               stNewFaceCapture;
    ST_IOT_EVENT_FACEDISCERN   stNewFaceDiscern;
    ST_IOT_EVENT_NEWAI         stMask;
    ST_IOT_EVENT_NEWAI         stFlameDetect;
    ST_IOT_EVENT_NEWAI         stNewHumanAlarm;
    ST_IOT_EVENT_BATTERYBIKE   stBatteryBike;
    ST_IOT_EVENT_HIGHPARABOLIC stHighParabolic;
    ST_IOT_EVENT_FENCE         stFence;
    ST_IOT_EVENT_ONEKEYALARM   stOneKeyAlarm;
    int iRun;
    pthread_t hThread;
}ST_IOT_MNG;


int iot_init();
int iot_start();

void* iot_loop(void* argc);
ST_IOT_MNG *iot_get_mng();

#endif