#include "zj_type.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "zj_log.h"
#include "zj_type.h"
#include "zj_ga1400.h"

#include "cJSON.h"

#include "type.h"
#include "log.h"
#include "iot.h"
#include "system.h"

static int iot_videoUpload(char *videoPath,char *videoCfgPath, char *audioFilePath)
{
    FILE *faudio  = NULL;
    FILE *hVideo  = NULL;
    FILE *hVideoCfg  = NULL;
    char pVideobuf[100000] = {0}; 
    char *pVideobufCfg = NULL;
    hVideo  = fopen(videoPath,"rb"); 
    if(NULL==hVideo)
    {
        __ERROR_PRINTF("device video fopen video path failed!\n");
        return -1;
    }
    hVideoCfg  = fopen(videoCfgPath,"rb"); 
    if(NULL==hVideoCfg)
    {
        __ERROR_PRINTF("device video fopen video cfg path failed!\n");
        return -1;
    }

    const int audioSize = 320;
    char *pbufAudio = (char *)malloc(audioSize);
    faudio  = fopen(audioFilePath,"rb"); 
    if(NULL==faudio)
    {
        __ERROR_PRINTF("device audio open file failed!\n");
        return -1;
    }
    pbufAudio = (char *)malloc(audioSize);
    if(NULL==pbufAudio)
    {
        __ERROR_PRINTF("device audio malloc failed!\n");
        return -1;
    }
    
    pVideobufCfg = (char *)malloc(40 + 2);
    if(NULL==pVideobufCfg)
    {
        __ERROR_PRINTF("device video buf cfg malloc failed!\n");
        return -1;
    }
    int muxerId = PsMuxer_CreateHandle((unsigned char*)"/opt/21cn/testfile/video/test.ps", EN_PS_CONTENT_TYPE_HIGHPARABOLIC);
    unsigned long long int ulltimestamp;
    while(fread(pVideobufCfg, 1, 39, hVideoCfg)!= 0 && fread(pbufAudio, 1, audioSize, faudio)!= 0)
    {
        int length = 0;
        int utimestamp = 0;
        
        int frametype = 0;
        unsigned char  bIsIFrame = 0;

        sscanf(pVideobufCfg, "LEN:%05dFRAMETYPE:%02dTIMESTAMP:%8d", &length,&frametype, &utimestamp);

        if(0x0e == frametype)
            bIsIFrame = 1;
        else
            bIsIFrame = 0;
        if(0 == fread(pVideobuf, 1, length, hVideo))
        {
            free(pVideobufCfg);
            fclose(hVideo);
            fclose(hVideoCfg);
            pVideobufCfg = NULL;
            return -1;
        }
        ulltimestamp = getCurrentDayMsec();//util_GetTickCount();
        HTA_TARGET st_hta[1] = {0};
        st_hta[0].ID = 123;
        st_hta[0].type = EN_PS_CONTENT_TYPE_HIGHPARABOLIC;
        st_hta[0].alarm_flg = 2;
        // memcpy(st_hta[0].reserved, 0, 6);
        st_hta[0].rect.x = 1;
        st_hta[0].rect.y = 2;
        st_hta[0].rect.w = 3;
        st_hta[0].rect.h = 4;

        // 写一帧PS Appand方式写入
        PsMuxer_WriteVideo(muxerId, pVideobuf, length, ulltimestamp, bIsIFrame, (unsigned char *)((void*)st_hta));
        PsMuxer_WriteAudio(muxerId,(unsigned char *)pbufAudio,audioSize,(unsigned int)ulltimestamp);

        usleep(40*1000);
        memset(pVideobuf, 0, 100000);
        memset(pVideobufCfg, 0, 40 + 2);
    }

    free(pVideobufCfg);
    fclose(hVideo);
    fclose(hVideoCfg);
    fclose(faudio);
    free(pbufAudio);
    pVideobufCfg = NULL;
    PsMuxer_DestoryHandle(muxerId);
    return 0;
}

// 获取AI告警事件上传图片信息
static int get_alarm_upload_info(unsigned int uiIoTType, ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf)
{
    char cmd[256]      = {0};
    char *pstr         = NULL;  

    if (NULL == pstAIAlarmUploadInf)
    {
         __ERROR_PRINTF("param is null!");
        return -1;
    }

    memset(pstAIAlarmUploadInf, 0, sizeof(ST_ZJ_AI_AlARM_UPLOAD_INF));

    pstAIAlarmUploadInf->lluTimeStamp = time(0);

    sprintf((char *)pstAIAlarmUploadInf->ucPicPath, "iot_%u_%llu.jpg", uiIoTType, pstAIAlarmUploadInf->lluTimeStamp);
    sprintf(cmd, "cp %s %s", DEVICE_SNAP_FILE_JPG1, pstAIAlarmUploadInf->ucPicPath);
    system(cmd);

    __INFO_PRINTF("create new jpg[%s]\n", pstAIAlarmUploadInf->ucPicPath);

    return 0;
}

// 高空抛物事件上报
int iot_high_parabolic_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    if (1 == pstIotMng->stHighParabolic.stEvent.iStatus)
    {
        // PS流封装
        iot_videoUpload(DEVICE_VIDEO_FILE_PATH_FILE, DEVICE_VIDEO_FILE_PATH_CFG, DEVICE_AUDIO_FILE_PATH);

        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC, 0, 0, &stAIAlarmUploadInf);
        }
    }

    return 0;
}

// 电瓶车识别事件上报
int iot_battery_bike_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    if (1 == pstIotMng->stBatteryBike.stEvent.iStatus)
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_BATTERYBIKE, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_BATTERYBIKE, 0, 0, &stAIAlarmUploadInf);
        }
    }

    return 0;
}

// 电子围栏逗留人形侦测报警事件上报
int iot_human_stay_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    if ((1 == pstIotMng->stFence.stEvent.iStatus) && (pstIotMng->stFence.iStayTime > 0))
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_MOTION, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_STAY, &stAIAlarmUploadInf);
        }
    }

    return 0;
}

// 口罩识别事件上报
int iot_mask_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    if (1 == pstIotMng->stMask.stEvent.iStatus)
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_MASK, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_MASK, 0, 0, &stAIAlarmUploadInf);
        }

        // 若支持AI告警视频上传
        // sleep(10);
        // __INFO_PRINTF("device iot MASK event start Set VIDEOOOOOOOOO \r\n");
        // ZJ_SetUploadAIAlarmPVFileFinish(pstAIAlarmUploadInf->ucVideoPath, 1);
    }

    return 0;
}

// 烟火检测事件上报
int iot_flame_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    if (1 == pstIotMng->stFlameDetect.stEvent.iStatus)
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_FLAMEDETECT, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_FLAMEDETECT, 0, 0, &stAIAlarmUploadInf);
        }
    }

    return 0;
}

// 新人形侦测报警事件上报
int iot_new_human_event(void)
{
    int ret = -1;
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf = {0};
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    if (1 == pstIotMng->stNewHumanAlarm.stEvent.iStatus)
    {
        ret = get_alarm_upload_info(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, &stAIAlarmUploadInf);
        if(0 == ret)
        {
            ZJ_IotAIEventPVInPut(EN_ZJ_AIIOT_TYPE_HUMANALARMNEW, 0, 0, &stAIAlarmUploadInf);
        }
    }

    return 0;
}

// 移动侦测报警事件推送, 注：SDK内部会做抓图、报警视频录制等相关业务操作
int iot_motion_detect_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime  = 0;
    ST_IOT_MNG *pstIotMng = iot_get_mng();
    
    if (1 == pstIotMng->stMotion.iStatus)
    {
        gettimeofday(&cur_tv, 0);

        if ((cur_tv.tv_sec - lastTime) >= pstIotMng->stMotion.iInterval)
        {
            lastTime = cur_tv.tv_sec;

            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_MOTION);
        }
    }

    return 0;
}

// 人形侦测侦测报警事件推送,注：SDK内部会做抓图、报警视频录制等相关业务操作
int iot_human_detect_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime  = 0;
    ST_IOT_MNG *pstIotMng = iot_get_mng();
    
    if (1 == pstIotMng->stHuman.iStatus)
    {
        gettimeofday(&cur_tv, 0);

        if ((cur_tv.tv_sec - lastTime) >= pstIotMng->stHuman.iInterval)
        {
            lastTime = cur_tv.tv_sec;

            ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_HUMAN);
        }
    }

    return 0;
}

// 人脸抓拍报警事件上报
int iot_face_capture_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime  = 0;
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    #if USE_NEW_FACE
    if (pstIotMng->stNewFaceCapture.iStatus)
    #else
    if ((1 == pstIotMng->stFace.stEvent.iStatus) && (0 == pstIotMng->stFace.iDiscernFlag)) // 旧人脸抓拍
    #endif    
    {
        gettimeofday(&cur_tv, 0);

        #if USE_NEW_FACE
        if ((cur_tv.tv_sec - lastTime) >= pstIotMng->stNewFaceCapture.iInterval)
        #else
        if ((cur_tv.tv_sec - lastTime) >= pstIotMng->stFace.stEvent.iInterval) // 旧人脸抓拍
        #endif
        {
            lastTime = cur_tv.tv_sec;

            /*人脸上传参考示例*/
            #if 1 /*1400方式上传*/
            ST_ZJ_AIPIC_NODE       stAiPicHead      = {0};
            ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo = {0};
            int iGenderCode    = 1;  // 0：未知的性别  1: 男性  2: 女性 9：未说明的性别
            int iAgeUpLimit    = 22;
            int iAgeLowerLimit = 18;

            unsigned char aucPicData[16]     = "PicData";
            unsigned char aucPicDataBg[64]   = "PicDataBg";
            unsigned int  uiTargetSize       = sizeof(aucPicData);
            unsigned int  uiTargetSizeBg     = sizeof(aucPicDataBg);
            unsigned char aucPicExpandDes[1024]   = {0};
            unsigned char aucBgPicExpandDes[1024] = {0};
            unsigned char aucEventExpandDes[1024] = {0};
            
            stAiPicHead.pucPicBuf       = aucPicData;        //人脸抠图数据
            stAiPicHead.uiPicLen        = uiTargetSize;      //人脸抠图大小
            stAiPicHead.dWidth          = 320;
            stAiPicHead.dHeight         = 160;
            stAiPicHead.uiLeftTopX      = 100;
            stAiPicHead.uiLeftTopY      = 200;
            stAiPicHead.uiRightBtmX     = stAiPicHead.uiLeftTopX + stAiPicHead.dWidth;
            stAiPicHead.uiRightBtmY     = stAiPicHead.uiLeftTopY + stAiPicHead.dHeight;
            sprintf(aucPicExpandDes, "{\"Title\": \"AAAAAAAA\"}");
            strncpy(stAiPicHead.aucPicExpandDes, aucPicExpandDes, sizeof(stAiPicHead.aucPicExpandDes));
            stAiPicHead.pstNextNode     = NULL;

            stAiPicEventInfo.pucBgJpgBuff = aucPicDataBg;    //人脸背景图数据
            stAiPicEventInfo.uiBgJpgLen   = uiTargetSizeBg;  //人脸背景图大小
            stAiPicEventInfo.dBgWidth     = 1920;
            stAiPicEventInfo.dBgHeight    = 1080;
            stAiPicEventInfo.lluTimeStamp = time(NULL);
            sprintf(aucBgPicExpandDes, "{\"Title\": \"AAAAAAAA_BG\"}");
            strncpy(stAiPicEventInfo.aucBgPicExpandDes, aucBgPicExpandDes, sizeof(stAiPicEventInfo.aucBgPicExpandDes));
            sprintf(aucEventExpandDes, "{\"GenderCode\": \"%d\",\"AgeUpLimit\": \"%d\",\"AgeLowerLimit\": \"%d\"}", 
                                            iGenderCode, iAgeUpLimit, iAgeLowerLimit);
            strncpy(stAiPicEventInfo.aucEventExpandDes, aucEventExpandDes, sizeof(stAiPicEventInfo.aucEventExpandDes));
            stAiPicEventInfo.pstAiPicHead = &stAiPicHead;

            #if USE_NEW_FACE
            ZJ_SetAiPicEventEx2(EN_ZJ_AIIOT_TYPE_FACE_CAPTURE, 0, 0, &stAiPicEventInfo);
            #else
            ZJ_SetAiPicEventEx2(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_FACE, &stAiPicEventInfo);
            #endif
            #elif 0 /*压缩方式上传业务平台*/
            static ST_ZJ_AI_ZIP_EVENT_SIGNAL stAiZipEventInfo = {0};
            ST_ZJ_ZIP_AIBGFILE_NODE stZipAiBgFileNode = {0};
            strcpy(stAiZipEventInfo.aucFilePath, "aucFileZipPath");
            strcpy(stZipAiBgFileNode.aucBgFileName, "aucBgFileName.Zip");        // 人脸背景图
            stZipAiBgFileNode.lluTimeStamp = 1650521256840;

            ST_ZJ_ZIP_AIFACEFILE_INFO stZipAiFaceFileInf1 = {0};                 // 人脸抠图1
            strcpy(stZipAiFaceFileInf1.aucFaceFileName, "aucFaceFileName0.Zip");

            ST_ZJ_ZIP_AIFACEFILE_INFO stZipAiFaceFileInf2 = {0};                 // 人脸抠图2
            strcpy(stZipAiFaceFileInf2.aucFaceFileName, "aucFaceFileName1.Zip");
            stZipAiFaceFileInf1.pstNextNode = &stZipAiFaceFileInf2;

            stZipAiBgFileNode.pstZipFaceFileHead = &stZipAiFaceFileInf1;
            stAiZipEventInfo.pstZipBgFileHead  = &stZipAiBgFileNode;

            #if USE_NEW_FACE
            ZJ_SetAiPicEventEx(EN_ZJ_AIIOT_TYPE_FACE_CAPTURE, 0, 0, &stAiZipEventInfo);
            #else
            ZJ_SetAiPicEventEx(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_FACE, &stAiZipEventInfo);
            #endif
            #endif
        }
    }

    return 0;
}

// 人脸识别(布控)报警事件上报
int iot_face_discern_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime  = 0;
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    #if USE_NEW_FACE
    if (pstIotMng->stNewFaceDiscern.stEvent.iStatus)
    #else
    if (1 == pstIotMng->stFace.iDiscernFlag) // 旧人脸布控
    #endif    
    {
        gettimeofday(&cur_tv, 0);

        #if USE_NEW_FACE
        if ((cur_tv.tv_sec - lastTime) >= pstIotMng->stNewFaceDiscern.stEvent.iInterval)
        #else
        if ((cur_tv.tv_sec - lastTime) >= pstIotMng->stFace.stEvent.iInterval) // 旧人脸布控
        #endif
        {
            lastTime = cur_tv.tv_sec;

            /*人脸布控示例*/
            ST_ZJ_AIPIC_NODE       stAiPicHead      = {0};
            ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo = {0};

            struct timeval tv_time;
            gettimeofday(&tv_time, NULL);
            stAiPicEventInfo.lluTimeStamp = tv_time.tv_sec;

            stAiPicEventInfo.pucBgJpgBuff = NULL;             // 背景图片数据
            stAiPicEventInfo.uiBgJpgLen   = 0;                // 背景图片长度
            stAiPicEventInfo.dBgWidth     = 1920;
            stAiPicEventInfo.dBgHeight    = 1080;

            strcpy(stAiPicHead.aucLabelID, "PRO958993bd242441beab77635ee3d9db72");
            stAiPicHead.pucPicBuf       = NULL;               // 抠图数据
            stAiPicHead.uiPicLen        = 0;                  // 抠图长度
            stAiPicHead.uiSimilarity    = 98;                 // 相似度
            // stAiPicHead.pstNextNode     = &stAiPicNode1;   // 没有其他抠图,可不填

            stAiPicEventInfo.pstAiPicHead = &stAiPicHead;

            #if USE_NEW_FACE
            stAiPicEventInfo.uiWBList = 2; // 白名单

            // Ai事件信号输入 (布控)
            ZJ_SetAiPicEvent(EN_ZJ_AIIOT_TYPE_FACE_DISCERN, 0, 0, &stAiPicEventInfo);
            #else 
            stAiPicEventInfo.uiWBList = 1; // 黑名单

            // Ai事件信号输入 (布控)
            ZJ_SetAiPicEvent(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_FACE, &stAiPicEventInfo);
            #endif           
        }
    }

    return 0;
}

// 车牌抓拍报警事件上报
int iot_car_number_event(void)
{
    int ret = -1;
    struct timeval cur_tv;
    static long lastTime  = 0;
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    if (1 == pstIotMng->stCarNum.iStatus) 
    {
        gettimeofday(&cur_tv, 0);

        if ((cur_tv.tv_sec - lastTime) >= pstIotMng->stCarNum.iInterval)
        {
            lastTime = cur_tv.tv_sec;

            /*车牌抓拍上传示例*/
            #if 1  /*1400方式上传*/
            ST_ZJ_AIPIC_NODE       stAiPicHead      = {0};
            ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo = {0};
            int iPlateColor = 9; // 1：黑  2:白  5:蓝  6：黄  9：绿  99:其他

            unsigned char aucPicData[16]     = "PicData";
            unsigned char aucPicDataBg[64]   = "PicDataBg";
            unsigned int  uiTargetSize       = sizeof(aucPicData);
            unsigned int  uiTargetSizeBg     = sizeof(aucPicDataBg);
            unsigned char ucCarNum[16]       = "粤AA21CN";
            unsigned char aucPicExpandDes[1024]   = {0};
            unsigned char aucBgPicExpandDes[1024] = {0};
            unsigned char aucEventExpandDes[1024] = {0};
            strncpy(stAiPicHead.aucCarNum, ucCarNum, sizeof(stAiPicHead.aucCarNum));
            stAiPicHead.pucPicBuf       = aucPicData;        //车牌抠图数据
            stAiPicHead.uiPicLen        = uiTargetSize;      //车牌抠图大小
            stAiPicHead.dWidth          = 320;
            stAiPicHead.dHeight         = 160;
            stAiPicHead.uiLeftTopX      = 100;
            stAiPicHead.uiLeftTopY      = 200;
            stAiPicHead.uiRightBtmX     = stAiPicHead.uiLeftTopX + stAiPicHead.dWidth;
            stAiPicHead.uiRightBtmY     = stAiPicHead.uiLeftTopY + stAiPicHead.dHeight;
            sprintf(aucPicExpandDes, "{\"Title\": \"AAAAAAAA\"}");
            strncpy(stAiPicHead.aucPicExpandDes, aucPicExpandDes, sizeof(stAiPicHead.aucPicExpandDes));
            stAiPicHead.pstNextNode     = NULL;

            stAiPicEventInfo.pucBgJpgBuff = aucPicDataBg;    //车牌背景图数据
            stAiPicEventInfo.uiBgJpgLen   = uiTargetSizeBg;  //车牌背景图大小
            stAiPicEventInfo.dBgWidth     = 1920;
            stAiPicEventInfo.dBgHeight    = 1080;
            stAiPicEventInfo.lluTimeStamp = time(NULL);
            sprintf(aucBgPicExpandDes, "{\"Title\": \"AAAAAAAA_BG\"}");
            strncpy(stAiPicEventInfo.aucBgPicExpandDes, aucBgPicExpandDes, sizeof(stAiPicEventInfo.aucBgPicExpandDes));
            sprintf(aucEventExpandDes, "{\"PlateColor\": \"%d\"}", iPlateColor);
            strncpy(stAiPicEventInfo.aucEventExpandDes, aucEventExpandDes, sizeof(stAiPicEventInfo.aucEventExpandDes));
            stAiPicEventInfo.pstAiPicHead = &stAiPicHead;
            
            ZJ_SetAiPicEventEx2(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_CARNUM_DISCERN, &stAiPicEventInfo);

            sleep(1);

            ST_ZJ_AIPIC_NODE       stAiPicHead1      = {0};
            ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo1 = {0};
            int iPlateColor1 = 6; // 1：黑  2:白  5:蓝  6：黄  9：绿  99:其他

            unsigned char aucPicData1[16]     = "PicData1";
            unsigned char aucPicDataBg1[64]   = "PicDataBg1";
            unsigned int  uiTargetSize1       = sizeof(aucPicData1);
            unsigned int  uiTargetSizeBg1     = sizeof(aucPicDataBg1);
            unsigned char ucCarNum1[16]       = "粤AC21CN";
            unsigned char aucPicExpandDes1[1024]   = {0};
            unsigned char aucBgPicExpandDes1[1024] = {0};
            unsigned char aucEventExpandDes1[1024] = {0};
            strncpy(stAiPicHead1.aucCarNum, ucCarNum1, sizeof(stAiPicHead1.aucCarNum));
            stAiPicHead1.pucPicBuf       = aucPicData1;        //车牌抠图数据
            stAiPicHead1.uiPicLen        = uiTargetSize1;      //车牌抠图大小
            stAiPicHead1.dWidth          = 320;
            stAiPicHead1.dHeight         = 160;
            stAiPicHead1.uiLeftTopX      = 100;
            stAiPicHead1.uiLeftTopY      = 200;
            stAiPicHead1.uiRightBtmX     = stAiPicHead1.uiLeftTopX + stAiPicHead1.dWidth;
            stAiPicHead1.uiRightBtmY     = stAiPicHead1.uiLeftTopY + stAiPicHead1.dHeight;
            sprintf(aucPicExpandDes1, "{\"Title\": \"BBBBBBB\"}");
            strncpy(stAiPicHead1.aucPicExpandDes, aucPicExpandDes1, sizeof(stAiPicHead1.aucPicExpandDes));
            stAiPicHead1.pstNextNode     = NULL;

            stAiPicEventInfo1.pucBgJpgBuff = aucPicDataBg1;    //车牌背景图数据
            stAiPicEventInfo1.uiBgJpgLen   = uiTargetSizeBg1;  //车牌背景图大小
            stAiPicEventInfo1.dBgWidth     = 1920;
            stAiPicEventInfo1.dBgHeight    = 1080;
            stAiPicEventInfo1.lluTimeStamp = time(NULL);
            sprintf(aucBgPicExpandDes1, "{\"Title\": \"BBBBBBB_BG\"}");
            strncpy(stAiPicEventInfo1.aucBgPicExpandDes, aucBgPicExpandDes1, sizeof(stAiPicEventInfo1.aucBgPicExpandDes));
            sprintf(aucEventExpandDes1, "{\"PlateColor\": \"%d\"}", iPlateColor1);
            strncpy(stAiPicEventInfo1.aucEventExpandDes, aucEventExpandDes1, sizeof(stAiPicEventInfo1.aucEventExpandDes));
            stAiPicEventInfo1.pstAiPicHead = &stAiPicHead1;
            
            ZJ_SetAiPicEventEx2(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, EN_ZJ_MOTION_EVENT_CARNUM_DISCERN, &stAiPicEventInfo1);

            #elif 0 /*压缩方式上传业务平台*/
            ST_ZJ_AI_ZIP_EVENT_SIGNAL stAiZipEventInfo = {0};
            ST_ZJ_ZIP_AIBGFILE_NODE stZipAiBgFileNode  = {0};
            strcpy(stAiZipEventInfo.aucFilePath, "aucFileZipPath");
            strcpy(stZipAiBgFileNode.aucBgFileName, "aucBgFileName.Zip");        // 车牌背景图
            stZipAiBgFileNode.lluTimeStamp = 1650521256840;

            ST_ZJ_ZIP_AIFACEFILE_INFO stZipAiFaceFileInf1 = {0};                 // 车牌抠图1
            strcpy(stZipAiFaceFileInf1.aucFaceFileName, "aucFaceFileName0.Zip");

            ST_ZJ_ZIP_AIFACEFILE_INFO stZipAiFaceFileInf2 = {0};                 // 车牌抠图2
            strcpy(stZipAiFaceFileInf2.aucFaceFileName, "aucFaceFileName1.Zip");
            stZipAiFaceFileInf1.pstNextNode = &stZipAiFaceFileInf2;

            stZipAiBgFileNode.pstZipFaceFileHead = &stZipAiFaceFileInf1;
            stAiZipEventInfo.pstZipBgFileHead  = &stZipAiBgFileNode;

            ZJ_SetAiPicEventEx(EN_ZJ_AIIOT_TYPE_MOTION, 0, EN_ZJ_MOTION_EVENT_CARNUM_DISCERN, &stAiZipEventInfo);
            #endif
           
        }
    }

    return 0;
}

// ebo机器人消息上报
int iot_ebo_roboot_event(void)
{
    // ebo机器人告警上报示例
    ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, 0, EN_ZJ_EBO_ROBOT_EVENT_SHAKE);           // 连续摇晃
    ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, 0, EN_ZJ_EBO_ROBOT_EVENT_LOW_POWER);       // 低电量
    ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_EBO_ROBOT, 0, EN_ZJ_EBO_ROBOT_EVENT_RECHARGE_FAILED); // 回充失败
    return 0;
}

// 双向视频通话消息上报
int iot_videoplay_event(void)
{
    // 双向视频通话告警上报示例
    ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_VIDEOPLAY, 0, EN_ZJ_VIDEOPLAY_EVENT_CALL);         // 呼出
    ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_VIDEOPLAY, 0, EN_ZJ_VIDEOPLAY_EVENT_HANGUP);       // 关断

    return 0;
}

/**
 * 事件推送示例
*/
void* iot_loop(void* argc)
{
    ST_IOT_MNG *pstIotMng = iot_get_mng();

    __INFO_PRINTF("device iot event test loop start\n");

    while(pstIotMng->iRun)
    {
        /**
         * 示例推送报警事件,
         * 注意：报警事件推送需要注意推送间隔,SDK内部会做过滤,为避免资源浪费,对接厂商也需要控制一下事件推送间隔
        */
       
        // 高空抛物事件上报
        iot_high_parabolic_event();

        // 电瓶车识别事件上报
        iot_battery_bike_event();  

        // 电子围栏逗留人形侦测报警事件上报
        iot_human_stay_event();

        // 口罩识别事件上报
        iot_mask_event();

        // 烟火检测事件上报
        iot_flame_event();

        // 新人形侦测报警事件上报
        iot_new_human_event();

        // 移动侦测报警事件上报
        iot_motion_detect_event();

        // 人形侦测侦测报警事件上报
        iot_human_detect_event();   

        // 人脸抓拍报警事件上报
        iot_face_capture_event();

        // 人脸识别(布控)报警事件上报
        iot_face_discern_event();

        // 车牌抓拍报警事件上报
        iot_car_number_event();

        // ebo机器人消息上报
        iot_ebo_roboot_event();

        // 双向视频通话消息上报
        iot_videoplay_event();
        sleep(1);
    }

    __INFO_PRINTF("device iot event test loop exit\n");
    return NULL;
}