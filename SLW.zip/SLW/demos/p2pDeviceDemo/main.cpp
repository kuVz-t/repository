/*
 * @Author: hejh
 * @Date: 2020-10-26 19:31:26
 * @LastEditTime: 2020-10-27 02:54:32
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /yjDeviceSdk/demos/p2pDeviceDemo/main.cpp
 */
#include "stdio.h"   
#include "pjlib.h"
#include "P2pManageMent.h"
#include <iostream>
#include <unistd.h>
#include "IceTransport.h"
#include "pj/log.h"
#include "SignalServerCom.h"
#include <poll.h>
#include "mos.h"
#include <map>
#include "zj_interface.h"
#include "adpt_json_adapt.h"
#include "p2p_connect.h"
#include "msgmng_type.h"
#include "ice_p2pqueue.h"

using namespace std;
char  serverIp[32] = {"106.55.39.76"};
short serverPort  = 8090;
char  deviceToken[32] = {"15361790660"};

#define SDP_BUFFER_LEN 4000
#define MAX_RECIVE_SIZE 4096
#define WAIT_MILLI_SEC (100 * 1000)
static void log_writer(int level, const char *buffer, int len)
{
    if (access("/tmp/debug_log", F_OK) == 0)
    printf("log-len:%d :%s \n", len, buffer);
}
extern "C"
{
extern _INT MsgMng_RecvSetClientSdpMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
}

static void icedemoPrintMenu(void)
{
    puts("");
    puts("+----------------------------------------------------------------------+");
    puts("|                    M E N U                                           |");
    puts("+---+------------------------------------------------------------------+");
    puts("| c | checklist        getClient the instance                          |");
    puts("| l | connect          l:xxxxxx ,xxx is userId                         |");
    puts("| i | init o|a         Initialize ICE session as offerer or answerer   |");
    puts("| e | stop             End/stop ICE session                            |");
    puts("| s | show             Display local ICE info                          |");
    puts("| r | remote           Input remote ICE info                           |");
    puts("| b | start            Begin ICE negotiation                           |");
    puts("| x | send <compid> .. Send data to remote                             |");
    puts("+---+------------------------------------------------------------------+");
    puts("| h |  help            * Help! *                                       |");
    puts("| q |  quit            Quit                                            |");
    puts("+----------------------------------------------------------------------+");
}

ENUM_ICE_TRANS_STATUS ice_status = ICE_TRANS_STATUS_INIT;
std::map<string, int>   client_status;
std::map<string, int>   client_seq;
int main(int argc, char** argv)
{
    char sdp1[SDP_BUFFER_LEN] = {0};
    char sdp2[SDP_BUFFER_LEN] = {0};
    char buffer[MAX_RECIVE_SIZE] = {0};
    client_status.clear();
    client_seq.clear();
    unsigned int role = 'a';
    int enable = 0;
    //char *person = nullptr;

    if (argc < 2)
    {
        printf("userage %s answer|offer [myuserId] [noturn /1/0] ", argv[0]);
        return 0;
    }

    for (int a=0; a<argc; a++)
    {
        printf("argc:%d argv:%s\n",a, argv[a]);
    }

    if (strstr(argv[1], "offer") != NULL)
    {
        role = 'o';
        MOS_STRCPY(deviceToken, "13711234291");
    }

    if (argc >= 3)
    {
        MOS_STRCPY(deviceToken, argv[2]);
    }

    if (argc >= 4)
    {
        enable = atoi(argv[3]);
    }

    //pj_log_set_log_func(&log_writer);
    ZJ_Init("./build/testDemo", "build/testDemo");
    P2pManageMent &p2pMngCtrl = P2pManageMent::instance();
    p2pMngCtrl.InitP2p((_UC*)deviceToken);
    p2pMngCtrl.StartP2p();
    Ice_Queue_Init();


    SignalServerCom  ServerInstance;
    ServerInstance.InitServerInfo(serverIp, serverPort);
    if (ServerInstance.ConnectServer())
    {
          ServerInstance.SendLoginReq(deviceToken);
          int ret = ServerInstance.ReciveData(buffer, sizeof(buffer));
          printf("recive len:%d data:\n", ret);
          ServerInstance.SendGetUserListReq(deviceToken);
          memset(buffer, 0, sizeof(buffer));
          ret = ServerInstance.ReciveData(buffer, sizeof(buffer));
          printf("getlist recive len:%d  \n", ret);
    }

    int sockfd = ServerInstance.GetSokcet();
    struct pollfd connect_in[2] = { {sockfd, POLLIN, 0 }, {STDIN_FILENO, POLLIN, 0}};

    ice_status = ICE_TRANS_STATUS_INIT;
    while(1)
    {
        int result = poll( connect_in, 2, 100 );

        if ( result < 0 )
        {
            perror( "Error in audio listening" );
        }
        else if (result == 0)
        {
            ST_FROM_TO_MSG stFromTo;
            ST_CMTASK_GETSDPINFO SdpInfo;
            if (Ice_P2p_Queue_pro(&stFromTo, &SdpInfo) == MOS_TRUE)
            {
                ServerInstance.SendDeviceSdpReq(stFromTo.aucDID, stFromTo.aucUserToken, SdpInfo.aucSdpInfo);
            }
        }
        else if (result  > 0)
        {
            for (int i=0; i<2; i++)
            {
                if ( ( connect_in[i].revents & POLLIN ) != 0 )
                {
                    if (connect_in[i].fd == STDIN_FILENO)
                    {
                        char str[32] = {0};
                        fgets(str, sizeof(str), stdin);
                        printf("input string: %s\n", str);
                        if ( strstr(str, "help") != NULL)
                        {
                            icedemoPrintMenu();
                        }
                        else
                        {
                            int value = str[0];
                            switch (value)
                            {
                            case 'c':
                                ServerInstance.SendGetUserListReq(deviceToken);
                                break;

                            case 'l':
                            {
                                char *p=(char*)strchr(str, ':');
                                char *q=(char*)strchr(str, '\n');
                                *q='\0';
                                if (p != NULL)
                                {
                                    p++;
                                    ServerInstance.SendDeviceSdpReq(deviceToken, p, sdp1);
                                    ice_status = ICE_TRANS_STATUS_LINKING;
                                }
                            }
                                break;

                            case 's':
                                //transport1->showIceInfo();
                                break;

                            case 'w':
                            {
                                char *p=(char*)strchr(str, ':');
                                char *q=(char*)strchr(str, '\n');
                                *q='\0';
                                if (p != NULL)
                                {
                                    p++;
                                    //transport1->sendData(1, p);
                                }
                            }
                                break;

                            default:
                                icedemoPrintMenu();
                                break;
                            }

                        }
                    }
                    else if (connect_in[i].fd == sockfd)
                    {
                       int ret = ServerInstance.ReciveData(buffer, sizeof(buffer));
                       printf("%s recive len:%d  \n", __FUNCTION__, ret);

                       char strFrom[64]={0};
                       char strTo[64]={0};
                       int  seqNumber = 0;
                       int  bRet = ServerInstance.ParseJasonInfo(buffer+sizeof(structTcpHeader),
                                                                 ret-sizeof(structTcpHeader),
                                                                 (char*)sdp2, strFrom, strTo, &seqNumber);
                       //recive sdp info
                       if (bRet == 1)
                       {
                           std::string name = strFrom;
                           client_seq[name] = seqNumber;
                           client_status[name] = ICE_TRANS_STATUS_INIT;
                           int &ice_status  = client_status[name];
                           printf("recive:%s\n", buffer+sizeof(structTcpHeader));
                           void* root=Adpt_Json_Parse(buffer+sizeof(structTcpHeader)); //获取整个大的句柄
                           //MsgCt_RecvGetDeviceSdpMsg("CN21_SEVER_ID",  (_UI)seqNumber, root);
                            //transport1->setRemoteSDP(sdp2);
                            if (ice_status == ICE_TRANS_STATUS_LINKING)//peer to connect
                            {
                                printf("start 111negotiation >>>>>>>>>>>>>>>>>>>>\n");
                                //transport1->startNegotiation();
                                ice_status = ICE_TRANS_STATUS_START;
                            }
                            else if (ice_status == ICE_TRANS_STATUS_INIT)//peer to connect
                            {
                                printf("recive connect device from:%s >>>>>>>>>>>>>>>>>>>>\n", strFrom);
                                MsgMng_RecvSetClientSdpMsg(MSGMNG_CMD_SERVER_ID, (_UI)seqNumber, root);
                                //char *sdp = p2pMngCtrl.onNewConnectTion(strFrom, sdp2);
                                ice_status = ICE_TRANS_STATUS_BECONNECT;
                                //ServerInstance.SendDeviceSdpReq(deviceToken, strFrom, sdp);
                            }
                       }
                       else if (bRet == 2)
                       {
                           std::string name;
                           std::map<string, int>::iterator iter;

                           for(iter = client_seq.begin(); iter != client_seq.end(); iter++)

                           {
                               if(iter->second == seqNumber)
                               {
                                    name = iter->first;
                                    printf("found client name:%s\n", name.c_str());
                                    break;
                               }

                           }
                           int &ice_status  = client_status[name];
                           if (ice_status == ICE_TRANS_STATUS_LINKING || ice_status == ICE_TRANS_STATUS_BECONNECT)//peer to connect
                           {
                               printf("start negotiation >>>>>>>>>>>>>>>>>clientname:%s>>>\n", name.c_str());
                               //transport1->startNegotiation();
                               //p2pMngCtrl.onStartNego(name.c_str());
                               ice_status = ICE_TRANS_STATUS_START;
                           }
                       }
                    }
                }
            }
        }
    }


    return 0;
}

