iot_tool使用说明

一、介绍
    该工具用于模拟IOT事件输入，触发deviceDemo的IOT事件上报。运行一次触发一次IOT上报。

二、编译
    编译生成的可执行文件在CN21DeviceSdk/build/common_arch/bin/iotEventDemo

三、运行
    1）先确保已经运行deviceDemo，否则运行iotEventDemo会失败
    2）iotEventDemo运行示例：
         ************************参数输入示例**********************

           	可执行程序             iot类型     iot事件ID              
            ./iotEventDemo           1000            0                   

         ************************************************************

四、特殊说明：
    1）人脸布控上报：设备每次上电启动需要在平台下发人脸底库才会上报。
    2）人脸布控上报，人脸/车牌1400上报和人脸/车牌zip上报开关打开之后SDK按上报间隔持续上报，无需iotEventDemo触发上报。