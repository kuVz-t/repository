
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define FIFO_IOT_SERVER "/tmp/iot_fifo_server"
#define FIFO_IOT_CLIENT "/tmp/iot_fifo_client"

typedef struct stru_iot_msg
{
    unsigned int uiIoTType;
    unsigned int uiEvent;
}ST_IOT_MSG;

#define SEND_FAIL (-2) 

static void fifo_close(int fd_server, int fd_client)
{
    if (fd_server > 0)
    {
        close(fd_server);
    }

    if (fd_client > 0)
    {
        close(fd_client);
    }
}

static int iot_event_write(ST_IOT_MSG *pstIotMsg)
{
    int fd_server = 0;
    int fd_client = 0;
    int result    = 0;

    if ((fd_server = open(FIFO_IOT_SERVER, O_RDWR, 0)) < 0)
    {
        perror("open");
        return SEND_FAIL;
    }

    if ((fd_client = open(FIFO_IOT_CLIENT, O_RDWR, 0)) < 0)
    {
        perror("open");
        fifo_close(fd_server, fd_client);
        return SEND_FAIL;
    }

    if (write(fd_server, pstIotMsg, sizeof(ST_IOT_MSG)) < 0)
    {
        perror("write");
        fifo_close(fd_server, fd_client);
        return SEND_FAIL;
    }

    if (read(fd_client, &result, sizeof(int)) < 0)
    {
        perror("read");
        fifo_close(fd_server, fd_client);
        return SEND_FAIL;
    }

    fifo_close(fd_server, fd_client);

    return result;
}

void usage_printf(void)
{
    printf("\n************************参数输入示例************************\n\n");
    printf("           可执行程序         iot类型    iot事件ID              \n");
    printf("example: ./iotEventDemo         1000        0                   \n");
    printf("\n************************************************************\n\n");
}

int main(int argc, char *argv[])
{
    int ret = -1;
    ST_IOT_MSG stIotMsg = {0};

    if (3 != argc)
    {
        usage_printf();
        return -1;
    }

    if (strspn(argv[1], "0123456789") != strlen(argv[1]))
    {
        printf("IOT类型不符合要求!\n");
        return -1;
    }

    if (strspn(argv[2], "0123456789") != strlen(argv[2]))
    {
        printf("事件ID不符合要求!\n");
        return -1;
    }

    stIotMsg.uiIoTType = atoi(argv[1]);
    stIotMsg.uiEvent   = atoi(argv[2]);

    printf("发送IOT事件[类型:%d][事件ID:%d]\n", stIotMsg.uiIoTType, stIotMsg.uiEvent);

    ret = iot_event_write(&stIotMsg);
    switch (ret)
    {
        case 0:
            printf("发送成功!\n");
            break;
        case SEND_FAIL:
            printf("发送失败!\n");
            break;
        default:
            printf("对方执行事件失败!\n");
            break;
    }

    return 0;
}