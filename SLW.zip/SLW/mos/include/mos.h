#ifndef _MOS_H_
#define _MOS_H_

#include "mos_adapter_os/mos_os.h"
#include "mos_protect.h"
#include "mos_form_map.h"
#include "mos_define.h"
#include "mos_err.h"
#include "mos_check.h"
#include "mos_mem.h"
#include "mos_char.h"
#include "mos_string.h"
#include "mos_print.h"

#include "mos_list.h"
#include "mos_msgqueue.h"
#include "mos_file.h"
#include "mos_mutex.h"
#include "mos_time.h"
#include "mos_thread.h"
#include "mos_socket.h"
#include "mos_sockbuf.h"
#include "mos_log.h"
#include "mos_md5.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef enum enum_MOS_DEVICE_ABILITY
{
   EN_MOS_DEVICE_ABILITY_RICH = 0,
   EN_MOS_DEVICE_ABILITY_MID  = 1,
   EN_MOS_DEVICE_ABILITY_POOR = 2
}EN_MOS_DEVICE_ABILITY;


_MOS_API _INT Mos_SysInit(_UC *pucWorkPath);

_MOS_API _VOID Mos_SysDestroy();

_MOS_API _VOID  Mos_SysSetDMode(_BOOL bDebugMode);

_MOS_API _VOID  Mos_SysSetDLevel(_UI uiDebugLevel);

_MOS_API _BOOL  Mos_SysGetDMode();

_MOS_API _UC  *Mos_GetWorkPath();

_MOS_API _UC  *Mos_GetCachePath();

_MOS_API _UI  Mos_GetSessionId();
    
_MOS_API _VOID  Mos_SysSetDeviceAbility(EN_MOS_DEVICE_ABILITY enDevice);

_MOS_API EN_MOS_DEVICE_ABILITY  Mos_SysGetDeviceAbility();

#ifdef __cplusplus
}
#endif

#endif
