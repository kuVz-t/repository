#ifndef _CIOS_THREAD_H_
#define _CIOS_THREAD_H_

#ifdef __cplusplus
extern "C" {
#endif

_INT Mios_ThreadCreate(_UC *pucName, _INT iPriority, _UI uiStackSize, 
					   PFN_THREADPROC pfunProc, _VPTR pParam, _HOSTHREAD *phOutOSThread);
_INT Mios_ThreadDelete(_HOSTHREAD hOSThread, _BOOL bForce);
_INT Mios_Sleep(_UI uiMilliSecond);
_UI  Mios_ThreadGetCurId();

#ifdef __cplusplus
}
#endif

#endif