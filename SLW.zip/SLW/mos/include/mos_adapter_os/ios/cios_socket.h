#ifndef  _CIOS_SOCKET_H_
#define  _CIOS_SOCKET_H_


#ifdef __cplusplus
extern "C" {
#endif

#define MOS_ISSOCKRETINVALID(_ret)    ((int)(_ret) == (int)(MOS_SOCKET_INVALID))
#define MOS_ISSOCKINVALID(_sock)    ((int)(_sock) == (int)(MOS_SOCKET_INVALID))

_INT    Mios_InetInit();
_VOID   Mios_InetDestroy();

_INT    Mios_InetAddr(_UC *pucAddrStr, _UI *puiDstAddr);

_UI     Mios_InetNtohl(_UI uiVal);
_UI     Mios_InetHtonl(_UI uiVal);
_US     Mios_InetNtohs(_US usVal);
_US     Mios_InetHtons(_US usVal);

_INT    Mios_InetFDCreate(MOS_FD_SET *pFds);
_INT    Mios_InetFDDelete(MOS_FD_SET fds);
_INT    Mios_InetFDCpy(MOS_FD_SET dstFds, MOS_FD_SET srcFds);
_INT    Mios_InetFDZero(MOS_FD_SET fds);
_INT    Mios_InetFDSet(_INT iFd, MOS_FD_SET fds);
_BOOL   Mios_InetFDIsSet(_INT iFd, MOS_FD_SET fds);
_INT    Mios_InetFDClr(_INT iFd, MOS_FD_SET fds);

_INT    Mios_InetGetAddrInfo(_UC *pucHostName,_US usPort,_INT iProtoType,_BOOL bPassive, ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mios_InetGetHostByName(_UC *pucName, ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mios_InetGetDnsIps(ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mios_InetGetLocalIps(ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mios_InetGetLocalIpsNew(ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mios_InetGetLocalMac(_UC *pucMacStr);
_INT    Mios_InetGetRemoteMac(_UC *pucSrcAddr, _UC *pucDstAddr, _OUT _UC *pucDstMac);

_SOCKET Mios_SocketOpen(_INT iNetType, _INT iProtoType, _BOOL bBlock, _BOOL bReuseAddr);
_INT    Mios_SocketClose(_SOCKET sock);
_INT    Mios_SocketShutDown(_SOCKET sock, _INT iHowTo);
_INT    Mios_SocketSelect(_INT imaxFd, MOS_FD_SET readFds, MOS_FD_SET writeFds, MOS_FD_SET exceptFds, _INT iMillSecWait);
_INT    Mios_SocketBind(_SOCKET sock, ST_MOS_INET_IP *pstLocalIp);
_INT    Mios_SocketListen(_SOCKET sock);
_SOCKET Mios_SocketAccept(_SOCKET sock, ST_MOS_INET_IP *pstRmtAddr, _BOOL bBlock);
_INT    Mios_SocketConnect(_SOCKET sock, ST_MOS_INET_IP *pstRmtAddr,_BOOL *bConnect);
_INT    Mios_SocketSendTo(_SOCKET sock, ST_MOS_INET_IP *pstRmtAddr, _VPTR pBuf, _INT uiLen, _BOOL *pbOutWait);
_INT    Mios_SocketRecvFrom(_SOCKET sock, ST_MOS_INET_IP *pstIORmtAddr, _VPTR pOutBuf, _INT iLen,_BOOL *pbOutClosed);
_INT    Mios_SocketSend(_SOCKET sock, _VPTR pBuf, _INT iLen, _BOOL *pbOutWait);
_INT    Mios_SocketRecv(_SOCKET sock, _VPTR pOutBuf, _INT iLen, _BOOL *pbOutClosed);
_INT    Mios_SocketRead(_SOCKET sock, _VPTR pBuf, _INT iLen);
_INT    Mios_SocketWrite(_SOCKET sock, _VPTR pOutBuf, _INT iLen, _BOOL *pbOutClosed);
_INT    Mios_SocketGetLocalIp(_SOCKET sock, ST_MOS_INET_IP *pstOutLclIp);
_INT    Mios_SocketGetRemoteIp(_SOCKET sock, ST_MOS_INET_IP *pstOutRmtIp);


_INT    Mios_SocketSetOptBlk(_SOCKET sock, _BOOL bBlock);
_INT    Mios_SocketSetOptTtl(_SOCKET sock, _UI uiTtlVal);
_INT    Mios_SocketSetOptReuseAddr(_SOCKET sock, _BOOL bReuseAddr);
_INT    Mios_SocketSetOptNodelay(_SOCKET sock, _BOOL bOn);
_INT    Mios_SocketSetRecvBuf(_SOCKET sock, _INT iBufSize);
_INT    Mios_SocketSetSendBuf(_SOCKET sock, _INT iBufSize);
_INT    Mios_SocketSetSendTimeOut(_SOCKET sock, _INT iTimeOutSec);
_INT    Mios_SocketSetRecvTimeOut(_SOCKET sock, _INT iTimeOutSec);
_INT    Mios_SocketSetOptCork(_SOCKET sock, _BOOL bOnCork);
_INT    Mios_SocketGetLastErr();

#ifdef __cplusplus
}
#endif

#endif