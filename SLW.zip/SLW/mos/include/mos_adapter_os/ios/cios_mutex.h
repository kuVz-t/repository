#ifndef _CIOS_MUTEX_H_
#define _CIOS_MUTEX_H_

#ifdef __cplusplus
extern "C" {
#endif

_INT       Mios_MutexCreate(_HMUTEX *phOutMutex);
_VOID      Mios_MutexDelete(_HMUTEX *phMutex);
_INT       Mios_MutexLock(_HMUTEX *phMutex);
_INT       Mios_MutexUnLock(_HMUTEX *phMutex);

_INT       Mios_SemCreate(_HSEM *phOutSem);
_VOID      Mios_SemDelete(_HSEM *phSem);
_INT       Mios_SemWait(_HSEM *phSem);
_INT       Mios_SemPost(_HSEM *phSem);


_INT   Mios_EventCreate(_HEVENT *phOutEvent);
_VOID  Mios_EventDelete(_HEVENT *phEvent);
_INT   Mios_EventWait(_HEVENT *phEvent);
_INT   Mios_EventTimedWait(_HEVENT *phEvent,_UI uiWaitMs);
_INT   Mios_EventSet(_HEVENT *phEvent);
_INT   Mios_EventPulse(_HEVENT *phEvent);
_INT   Mios_EventReSet(_HEVENT *phEvent);

#ifdef __cplusplus
}
#endif

#endif