#ifndef _CIOS_TIME_H_
#define _CIOS_TIME_H_

#ifdef __cplusplus
extern "C" {
#endif

_CTIME_T Mios_Time(_CTIME_T *ptTime);

_TM   * Mios_LocalTime(_CTIME_T *ptTime,_TM *ptTm);

_UI     Mios_GetTickCount();
_ULLID     Mios_GetLLTickCount();

_CTIME_T  Mios_SysTimetoTime(ST_MOS_SYS_TIME *pstTime);

#ifdef __cplusplus
}
#endif

#endif