#ifndef _CIOS_FILE_H_
#define _CIOS_FILE_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct stru_CIOS_DIR
{
	DIR             *pstDir;
	struct dirent   *pstEntry;
	_UC              aucName[MOS_DIR_NAME_LEN];
}ST_CIOS_DIR;

_HFILE Mios_FileOpen(_UC *pucFileName, _UI uiFlag);

_INT Mios_FileClose(_HFILE hFile);

_INT Mios_FileRmv(_UC *pucFileName);

_INT Mios_FileRename(_UC *pucOldFileName, _UC *pucNewFileName);

_BOOL Mios_FileEof(_HFILE hFile);

_INT Mios_FileWrite(_HFILE hFile, _UC *pucBuf, _INT iLen);

_INT Mios_FileRead(_HFILE hFile, _UC *pucBuf, _INT iLen);

_INT Mios_FileFlush(_HFILE hFile);

_INT Mios_FileSeek(_HFILE hFile, _US usFlag, _INT iOffSet);

_INT Mios_FileSize(_HFILE hFile);

_INT Mios_FileTell(_HFILE hFile);

_INT Mios_FileStat(_UC *pucFileName, ST_MOS_FILE_INF *pstInf);

_HDIR Mios_DirOpen(_UC *pucDirName);

_INT Mios_DirClose(_HDIR hDir);

_INT Mios_DirRead(_HDIR hDir, _UC *pucEntryName, _INT iMaxLen, ST_MOS_FILE_INF *pstInf);

_INT Mios_DirMake(_UC *pucDirName, _UI uiFlag);

_INT Mios_DirRmv(_UC *pucDirName);

_INT Mios_GetDiskSize(_UC *pucDisk, _XXLSIZE *xxlFreeSpace, _XXLSIZE *xxlTotalSpace);

_INT Mios_FileTrunCate(_UC *pucFileName,_INT iFileLen);

#ifdef __cplusplus
}
#endif

#endif
