#ifndef _CAND_FILE_H_
#define _CAND_FILE_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct stru_CAND_DIR
{
	DIR             *pstDir;
	struct dirent   *pstEntry;
	_UC              aucName[MOS_DIR_NAME_LEN];
}ST_CAND_DIR;

_HFILE Mandro_FileOpen(_UC *pucFileName, _UI uiFlag);

_INT  Mandro_FileClose(_HFILE hFile);

_INT  Mandro_FileRmv(_UC *pucFileName);

_INT  Mandro_FileRename(_UC *pucOldFileName, _UC *pucNewFileName);

_BOOL Mandro_FileEof(_HFILE hFile);

_INT  Mandro_FileWrite(_HFILE hFile, _UC *pucBuf, _INT iLen);

_INT  Mandro_FileRead(_HFILE hFile, _UC *pucBuf, _INT iLen);

_INT  Mandro_FileFlush(_HFILE hFile);

_INT  Mandro_FileSeek(_HFILE hFile, _US usFlag, _INT iOffSet);

_INT  Mandro_FileSize(_HFILE hFile);

_INT  Mandro_FileTell(_HFILE hFile);

_INT  Mandro_FileStat(_UC *pucFileName, ST_MOS_FILE_INF *pstInf);

_HDIR  Mandro_DirOpen(_UC *pucDirName);

_INT  Mandro_DirClose(_HDIR hDir);

_INT  Mandro_DirRead(_HDIR hDir, _UC *pucEntryName, _INT iMaxLen, ST_MOS_FILE_INF *pstInf);

_INT  Mandro_DirMake(_UC *pucDirName, _UI uiFlag);

_INT  Mandro_DirRmv(_UC *pucDirName);

_INT  Mandro_GetDiskSize(_UC *pucDisk, _XXLSIZE *xxlFreeSpace, _XXLSIZE *xxlTotalSpace);

_INT Mandro_FileTrunCate(_UC *pucFileName,_INT iFileLen);

#ifdef __cplusplus
}
#endif

#endif
