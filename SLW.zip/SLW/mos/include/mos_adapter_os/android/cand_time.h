#ifndef _CAND_TIME_H_
#define _CAND_TIME_H_

#ifdef __cplusplus
extern "C" {
#endif

_CTIME_T Mandro_Time(_CTIME_T *ptTime);

_TM   * Mandro_LocalTime(_CTIME_T *ptTime,_TM *ptTm);

_UI     Mandro_GetTickCount();
_ULLID     Mandro_GetLLTickCount();

_CTIME_T  Mandro_SysTimetoTime(ST_MOS_SYS_TIME *pstTime);

#ifdef __cplusplus
}
#endif

#endif