#ifndef _CAND_MUTEX_H_
#define _CAND_MUTEX_H_

#ifdef __cplusplus
extern "C" {
#endif

_INT   Mandro_MutexCreate(_HMUTEX *phOutMutex);
_VOID  Mandro_MutexDelete(_HMUTEX *phMutex);
_INT   Mandro_MutexLock(_HMUTEX *phMutex);
_INT   Mandro_MutexUnLock(_HMUTEX *phMutex);

_INT   Mandro_SemCreate(_HSEM *phOutSem);
_VOID  Mandro_SemDelete(_HSEM *phSem);
_INT   Mandro_SemWait(_HSEM *phSem);
_INT   Mandro_SemPost(_HSEM *phSem);

_INT   Mandro_EventCreate(_HEVENT *phOutEvent);
_VOID  Mandro_EventDelete(_HEVENT *phEvent);
_INT   Mandro_EventWait(_HEVENT *phEvent);
_INT   Mandro_EventTimedWait(_HEVENT *phEvent,_UI uiWaitMs);
_INT   Mandro_EventSet(_HEVENT *phEvent);
_INT   Mandro_EventPulse(_HEVENT *phEvent);
_INT   Mandro_EventReSet(_HEVENT *phEvent);

#ifdef __cplusplus
}
#endif

#endif