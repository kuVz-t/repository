#ifndef _CAND_THREAD_H_
#define _CAND_THREAD_H_

#ifdef __cplusplus
extern "C" {
#endif

_INT Mandro_ThreadCreate(_UC *pucName, _INT iPriority, _UI uiStackSize, 
		PFN_THREADPROC pfunProc, _VPTR pParam, _HOSTHREAD *phOutOSThread);
_INT Mandro_ThreadDelete(_HOSTHREAD hOSThread, _BOOL bForce);
_INT Mandro_Sleep(_UI uiMilliSecond);
_UI  Mandro_ThreadGetCurId();

#ifdef __cplusplus
}
#endif

#endif