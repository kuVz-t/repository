#ifndef  _CAND_SOCKET_H_
#define  _CAND_SOCKET_H_


#ifdef __cplusplus
extern "C" {
#endif

#define MOS_ISSOCKRETINVALID(_ret)    ((int)(_ret) == (int)(-1))
#define MOS_ISSOCKINVALID(_sock)    ((int)(_sock) == (int)(-1))

_INT    Mandro_InetInit();
_VOID   Mandro_InetDestroy();
_INT    Mandro_InetAddr(_UC *pucAddrStr, _UI *puiDstAddr);

_UI     Mandro_InetNtohl(_UI uiVal);
_UI     Mandro_InetHtonl(_UI uiVal);
_US     Mandro_InetNtohs(_US usVal);
_US     Mandro_InetHtons(_US usVal);

_INT    Mandro_InetFDCreate(MOS_FD_SET *pFds);
_INT    Mandro_InetFDDelete(MOS_FD_SET fds);
_INT    Mandro_InetFDCpy(MOS_FD_SET dstFds, MOS_FD_SET srcFds);
_INT    Mandro_InetFDZero(MOS_FD_SET fds);
_INT    Mandro_InetFDSet(_INT iFd, MOS_FD_SET fds);
_BOOL   Mandro_InetFDIsSet(_INT iFd, MOS_FD_SET fds);
_INT    Mandro_InetFDClr(_INT iFd, MOS_FD_SET fds);

_INT    Mandro_InetGetAddrInfo(_UC *pucHostName,_US usPort,_INT iProtoType,_BOOL bPassive, ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mandro_InetGetHostByName(_UC *pucName, ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mandro_InetGetDnsIps(ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mandro_InetGetLocalIps(ST_MOS_INET_IPARRAY *pstIpArrayInfo);
_INT    Mandro_InetGetLocalMac(_UC *pucMacStr);
_INT    Mandro_InetGetRemoteMac(_UC *pucSrcAddr, _UC *pucDstAddr, _OUT _UC *pucDstMac);

_SOCKET Mandro_SocketOpen(_INT iNetType, _INT iProtoType, _BOOL bBlock, _BOOL bReuseAddr);
_INT    Mandro_SocketClose(_SOCKET sock);
_INT    Mandro_SocketShutDown(_SOCKET sock, _INT iHowTo);
_INT    Mandro_SocketSelect(_INT imaxFd, MOS_FD_SET readFds, MOS_FD_SET writeFds, MOS_FD_SET exceptFds, _INT iMillSecWait);
_INT    Mandro_SocketBind(_SOCKET sock, ST_MOS_INET_IP *pstLocalIp);
_INT    Mandro_SocketListen(_SOCKET sock);
_SOCKET Mandro_SocketAccept(_SOCKET sock, ST_MOS_INET_IP *pstRmtAddr, _BOOL bBlock);
_INT    Mandro_SocketConnect(_SOCKET sock, ST_MOS_INET_IP *pstRmtAddr,_BOOL *bConnect);

_INT    Mandro_SocketSendTo(_SOCKET sock, ST_MOS_INET_IP *pstRmtAddr, _VPTR pBuf, _INT iLen,_BOOL *pbOutWait);
_INT    Mandro_SocketRecvFrom(_SOCKET sock, ST_MOS_INET_IP *pstIORmtAddr, _VPTR pOutBuf, _INT iLen,_BOOL *pbOutClosed);

_INT    Mandro_SocketSend(_SOCKET sock, _VPTR pBuf, _INT iLen,_BOOL *pbOutWait);
_INT    Mandro_SocketRecv(_SOCKET sock, _VPTR pOutBuf, _INT iLen, _BOOL *pbOutClosed);

_INT    Mandro_SocketRead(_SOCKET sock, _VPTR pBuf, _UI uiLen);
_INT    Mandro_SocketWrite(_SOCKET sock, _VPTR pOutBuf, _UI uiLen, _BOOL *pbOutClosed);
_INT    Mandro_SocketGetLocalIp(_SOCKET sock, ST_MOS_INET_IP *pstOutLclIp);
_INT    Mandro_SocketGetRemoteIp(_SOCKET sock, ST_MOS_INET_IP *pstOutRmtIp);


_INT    Mandro_SocketSetOptBlk(_SOCKET sock, _BOOL bBlock);
_INT    Mandro_SocketSetOptTtl(_SOCKET sock, _UI uiTtlVal);
_INT    Mandro_SocketSetOptReuseAddr(_SOCKET sock, _BOOL bReuseAddr);
_INT    Mandro_SocketSetOptNodelay(_SOCKET sock, _BOOL bOn);
_INT    Mandro_SocketSetOptCork(_SOCKET sock, _BOOL bOnCork);
_INT    Mandro_SocketSetRecvBuf(_SOCKET sock, _INT iBufSize);
_INT    Mandro_SocketSetSendBuf(_SOCKET sock, _INT iBufSize);
_INT    Mandro_SocketSetSendTimeOut(_SOCKET sock, _INT iTimeOutSec);
_INT    Mandro_SocketSetRecvTimeOut(_SOCKET sock, _INT iTimeOutSec);
_INT    Mandro_SocketGetLastErr();

#ifdef __cplusplus
}
#endif

#endif