#ifndef _CAND_OS_H_
#define _CAND_OS_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <pthread.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <semaphore.h>
#include <errno.h>
#include <dirent.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/vfs.h>
#include <ifaddrs.h>
#include <netinet/if_ether.h>


#ifdef __cplusplus
extern "C" {
#endif

#define _MOS_FILE     __FILE__
#define _MOS_FUNC     __func__
#define _MOS_LINE     __LINE__

#ifdef  _MOS_EXPORT
#define _MOS_API       __declspec(dllexport)
#define _MOS_EX_DATA       __declspec(dllimport)
#elif   defined(_MOS_IMPORT)
#define _MOS_API       __declspec(dllimport)
#define _MOS_EX_DATA       __declspec(dllimport)
#else
#define _MOS_API
#define _MOS_EX_DATA
#endif

typedef unsigned char      _UC;
typedef unsigned short     _US;
typedef unsigned int       _UI;
typedef int                _INT;
typedef unsigned long long _LLID;
typedef unsigned long long _XXLSIZE;
typedef void               _VOID;
typedef void              *_VPTR;
typedef int                _SOCKET;
typedef double             _DOUBLE;

typedef pthread_mutex_t    _HMUTEX;
typedef sem_t              _HSEM;
typedef pthread_t          _HOSTHREAD;
typedef time_t             _CTIME_T;
typedef struct tm          _TM;

typedef _VOID              *_HANDLE;
typedef _VOID              *_HTHREAD;
typedef _HANDLE            _HFILE;
typedef _HANDLE            _HDIR;

typedef struct struct_HEVENT
{
    pthread_cond_t  stCond;
    _HMUTEX         hmutex;
}_HEVENT;

#define  MOS_SOCKET_INVALID ((_SOCKET)-1)

typedef  va_list            _ICH_VA_LIST;
#define  _ICH_VA_START(_ap, _format)  va_start(_ap, _format)
#define  _ICH_VA_END(_ap)             va_end(_ap)
#define  _ICH_VA_ARG(_ap, _type)      va_arg(_ap, _type)


#ifdef __cplusplus
}
#endif

#endif
