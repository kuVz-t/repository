from threading import Thread,Lock 
import requests
import binascii
import signal
import random
import time

upload_url = 'http://media-hunanchenzhou-yijia13.hn3oss.xstore.ctyun.cn/HFAMILY07/000B/S_242a1dee8d70474a9eabf6fedf6695cf.ps?Signature=xW3WrBm0/6p9lC8PKahYylrG/GM%3D\u0026AWSAccessKeyId=NG3J04E4IHB1F554FZJW\u0026Expires=1636098046\u0026append\u0026position='
host = 'media-hunanchenzhou-yijia13.hn3oss.xstore.ctyun.cn'
date = 'Fri, 05 Nov 2021 07:40:46 GMT'

video_path = '/home/james/work/CN21DeviceSdk/demos/Sdk4.0Demo/source/video/Demovideo.H264'
delay_ms   = 66

total_time = 400
slice_time = 3
slice_bytes = 196608
position = '0'

run_flag = True
buffer = b''

# anaylse
request_total_time = 0
request_count = 0
timeout_count = 0

def my_handler(signum, frame):
    global run_flag
    run_flag = False
    print('\r\nreceive stop signal, now exit...')

def capture_video_loop(mutex):
    global run_flag
    global buffer
    f = open(video_path, 'rb')
    while run_flag:
        data = f.read(10000)
        if len(data) == 0:
            print("reopen file")
            f.close()
            f = open(video_path, 'rb')
            continue
        else:
            mutex.acquire()
            buffer = buffer + data
            mutex.release()
        time.sleep(0.001 * delay_ms)

def upload_video_loop(mutex):
    global run_flag
    global buffer
    while run_flag:
        mutex.acquire()
        if len(buffer) > slice_bytes:
            data = buffer[0:slice_bytes]
            upload_video(data)
            # delete sent data
            buffer = buffer[slice_bytes:]
        else:
            print("len(buffer)", len(buffer))
        mutex.release()
        time.sleep(0.001 * delay_ms)
    pass

def upload_video(data):
    global upload_url, host, date, position, timeout_count, request_total_time, request_count
    
    # data = generate_random_str(slice_bytes)
    url = upload_url + position
    payload=data
    headers = {
        'Host': host,
        'Content-Type': 'application/octet-stream',
        'Date': date,
        'Content-Length': str(len(data))
    }
    print(url)
    print(headers)
    # print(payload)
    try:
        response = requests.request("PUT", url, headers=headers, data=payload, timeout=5)
        position = response.headers['x-rgw-next-append-position']
        print('rsp: {}, cost {}s'.format(response.headers, response.elapsed.total_seconds()))
        request_count = request_count + 1
        request_total_time = request_total_time + response.elapsed.total_seconds()
        if response.elapsed.total_seconds() > 3:
            timeout_count = timeout_count + 1
    except:
        return 
if __name__ == "__main__":
    signal.signal(signal.SIGINT, my_handler)
    signal.signal(signal.SIGHUP, my_handler)
    signal.signal(signal.SIGTERM, my_handler)

    print("open file {}".format(video_path))

    mutex = Lock()

    capture_video_thread = Thread(target=capture_video_loop, args=(mutex,))
    upload_video_thread = Thread(target=upload_video_loop, args=(mutex,))

    capture_video_thread.start()
    upload_video_thread.start()

    while run_flag:
        time.sleep(1)
    print("3s timeout {}, average {}s , count {}".format(timeout_count, request_total_time/request_count, request_count))

    capture_video_thread.join()
    upload_video_thread.join()

