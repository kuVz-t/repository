#!/bin/sh
rm build/x86/* -rf
rm build/arm/* -rf
rm build/mips/* -rf
rm build/arm_gnueabihf/* -rf
rm build/* -rf
