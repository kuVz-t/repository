#ifndef _RECORD_MP4_PRV_H_
#define _RECORD_MP4_PRV_H_

#include <stdio.h>

#define                           MAXCACHESIZE                   512000
#define                           MEFC_GETHEVTYPE(nalubyte)      ((nalubyte & 0X7E) >> 1)

#define MAXFRAME       40000
#define MAX_VIDEOFRAME 16000    // FIXME:15000
#define MAX_AUDIOFRAME 40000
#define MAX_VIDEOPAGESIZE 1200

//#define WRITE_CACHE_MP4
#pragma pack(push)
#pragma pack(1)

#ifdef __cplusplus
extern "C" {
#endif

typedef struct stru_HEVC_Decodercfg_recordparty
{
    _UC  configurationVersion;
    _UC  general_profile_space;
    _UC  general_tier_flag;
    _UC  general_profile_idc;
    _UI general_profile_compatibility_flags;
    _LLID general_constraint_indicator_flags;
    _UC  general_level_idc;
    _UC  parallelismType;
    _US  min_spatial_segmentation_idc;
    _UC  chromaFormat;
    _UC  bitDepthLumaMinus8;
    _UC  bitDepthChromaMinus8;
    _US  avgFrameRate;
    _UC  constantFrameRate;
    _UC  numTemporalLayers;
    _UC  temporalIdNested;
    _UC  lengthSizeMinusOne;
    _UC  numOfArrays;
    _UC  reserved[3];
}ST_HEVC_DECODERCFG_RECORDPARTY;


struct STTSBOX{
    unsigned int size;
    char name[4];
    int version;//char version[4];
    unsigned int num;
    unsigned int data[MAXFRAME][2];
};
struct STSSBOX{
    unsigned int size;
    char name[4];
    int version;//char version[4];
    unsigned int num;
    unsigned int data[MAXFRAME];
};
struct STSCBOX{
    unsigned int size;
    char name[4];
    int version;//char version[4];
    unsigned int num;
    unsigned int data[MAXFRAME/5][3];
};
struct STSZBOX{
    unsigned int size;
    char name[4];
    int version;//char version[4];
    int version1;//char version[4];
    unsigned int num;
    unsigned int data[MAXFRAME];
};
struct STCOBOX{
    unsigned int size;
    char name[4];
    int version;//char version[4];
    unsigned int num;
    unsigned int data[MAXFRAME];
};
typedef struct{
    _UI     uiUserId;
    _HFILE  hFileHandle;
    _HFILE  hSubFileHandle;

    _UC     ucIsUsing;
    _UC     ucIsSetAudioType;
    _UC     ucHevcFlag;      // 0 H264 1 H265
    _UC     aucR;
    _UI     uiErrCode;
    _UC     aucAacFrame[1024];
    _UI     uiAacPacketLen;

    _US     usWidth;
    _US     usHeight;

    _UI    uiSpsLen;
    _UI    uiPpsLen;
    _UI    uiVpsLen; 
    _UC    aucSpsPps[1024];

    _US     usChannelCount;
    _US     usSampleSize;
    _UI     uiAudioType;
    _UI     uiSampleRate;
    _UI     uiProfile;

    _UI     uiSamplePerFrame;

    _UI     uiTps;
    _UI     uiDuration;

    _UI     uiVideoDuration;
    _UI     uiAudioDuration;
    _UI     uiAPreTimeStamp;

#ifdef WRITE_CACHE_MP4
    _UC     uaCachebuf[MAXCACHESIZE];
    _UI    uiCacheSize;
#endif


    _UC    aucFileName[256];
    _UC    aucSubName[256];
    _UI    uiOffset;
    _UI    uiMaxAudioSize;

    _UI    uiVideoCnt;
    _UI    uiAudioCnt;

    _UI    uiVideoFps;
    _CTIME_T uiStartTime;
    _CTIME_T uiEndTime;
    _UI    uiPrevTimeStamp;
    _UI    uiTimestampBase;
    _UI    uiEndTimeStamp;
    ST_ZJ_VIDEO_CIRCLE stCircle;


    struct STTSBOX stts_v; // 每一帧的持续时间
    struct STSSBOX stss_v; // 记录关键帧
    struct STSCBOX stsc_v; // 记录chuck 
    struct STSZBOX stsz_v; // 记录帧的大小 
    struct STCOBOX stco_v; // 记录文件中偏移
    struct STTSBOX stts_a;

    struct STSCBOX stsc_a;
    struct STSZBOX stsz_a;
    struct STCOBOX stco_a;


    ST_HEVC_DECODERCFG_RECORDPARTY stHecvRecordParty;
}ST_RDSTG_MP4MUXER;

typedef struct 
{
    _UI uiUserId;
    _HFILE hFileHandle;
    _UC ucIsUsing;
    _UC ucCycleFlag;
    _UC ucRes1[2];
    _UC aucFileName[256];

    ST_ZJ_VIDEO_CIRCLE stCircle;

    _UI stsc_v[1];
    _UI stts_v[MAX_VIDEOFRAME];     // 记录当前帧相对于文件第一帧的偏移时间差
    _UI stsz_v[MAX_VIDEOFRAME];
    _UI stco_v[MAX_VIDEOFRAME];     // 记录当前帧相对于文件头的偏移字节数
    _UI stss_v[MAX_VIDEOFRAME/10];  // 记录当前IRD帧处于录像文件的第几帧 即视频帧总数

    _UI stsc_a[1];
    _UI stts_a[MAX_AUDIOFRAME];
    _UI stsz_a[MAX_AUDIOFRAME];
    _UI stco_a[MAX_AUDIOFRAME];

    _UI uiVideoType;
    _UC aucSpsPps[1024];
    _UI uiSpsLen;
    _UI uiPpsLen;
    _UI uiVpsLen;
    _UI uiVideoWidth;
    _UI uiVideoHeight;

    _UI uiAudioType;
    _UI uiProfile;
    _UI uiSampleRate;
    _UI uiChannel;

    _UI uiVideoNum;
    _UI uiAudioNum;
    _UI uiVideoCnt;
    _UI uiAudioCnt;
    _UI uiVideoThunkNum;
    _UI uiAudioThunkNum;
    _UI uiVideoThunkCnt;
    _UI uiAudioThunkCnt;
    _UI uiVideoTps;
    _UI uiAudioTps;
    _UI uiIdrNum;           // 当前录像文件的IDR帧总数
    _UI uiSampleInThunk;
    _UI uiMaxFrameSize;
    _UI uiFrameLen;
    _UI uiFramePos;
    _UC ucFrameType;
    _UC ucRes2[3];
    _UI uiNaluLen;
    _UI uiNaluPos;
    _UI uiNaluNum;
}ST_RDSTG_MP4DEMUXER;

#ifdef __cplusplus
}
#endif

#pragma pack(pop)

#endif

