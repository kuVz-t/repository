#ifndef _RECORD_MP4_H_
#define _RECORD_MP4_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "media_video.h"
typedef MOS_MASK_HANDLE_TYPE(_HMP4MUXER)   _HMP4MUXER; 
typedef MOS_MASK_HANDLE_TYPE(_HMP4DEMUXER) _HMP4DEMUXER;
#define  RDSTG_MP4LOG                          "RD"

_INT RdStg_AacGetSampleByIndex(_US usSample);

_INT RdStg_AacGetIndexBySample(_INT isample);

/*************************************************************************************************
  写接口
*************************************************************************************************/
/*MP4 的写接口*/
_INT RdStg_Mp4Muxer_Init();

_INT RdStg_Mp4Muxer_Destory();

_HMP4MUXER RdStg_Mp4Muxer_OpenFile(_UC *pucFilename,_UI uiVideoType, _UI usWidth, _UI usHeight);

_INT RdStg_Mp4Muxer_SetAudioType(_HMP4MUXER hHandle,ST_ZJ_AUDIO_PARAM *pstAudioDes);//设置音频的类型 EN_MEDT_AUDIO_TYPE

_INT RdStg_Mp4Muxer_SetCircleInf(_HMP4MUXER hHandle,ST_ZJ_VIDEO_CIRCLE *pstCircle);

_VOID RdStg_Mp4Muxer_SetReSample(_UI uiFlag);

_INT RdStg_Mp4Muxer_VideoWrite(_HMP4MUXER hHandle, _UC *pucData,_UI uiLen, _UI uiTimeStamp);

_INT RdStg_Mp4Muxer_NaluWrite(_HMP4MUXER hHandle,_UI uiNaluNum, _UC **puiNalu,_UI *puiNaluLen,_UI uiTimeStamp);//按nal的方式写数据

_INT RdStg_Mp4Muxer_AudioWrite(_HMP4MUXER hHandle, _UC* pucData, _UI uiLen, _UI uiTimeStamp);//写音频

_INT RdStg_Mp4Muxer_VFNWrite(_HMP4MUXER hHandle, _HVIDEOREAD hVideo, ST_FRAME_NODE *pstFrameHead,_UI uiListCnt,_UI uiTimeStamp);//按framenode的方式写视频数据

_INT RdStg_Mp4Muxer_AFNWrite(_HMP4MUXER hHandle,ST_FRAME_NODE *pstFrameHead,_UI uiListCnt, _UI uiTimeStamp);//按framenode的方式写音频数据

_INT RdStg_Mp4Muxer_CloseFile(_HMP4MUXER hHandle, _UI uiFps);//关闭文件 uifps为非0值，则文件的帧率为设置的，为0则按照真是的情况

_UI  RdStg_Mp4Muxer_GetErrtype(_HMP4MUXER hHandle);

_UI  RdStg_Mp4Muxer_GetWriteOffSet(_HMP4MUXER hHandle);

_UI  RdStg_Mp4Muxer_GetLastTimeStamp(_HMP4MUXER hHandle);

_UI  RdStg_Mp4Muxer_GetWriterByName(_UC *pucFileName, _UI *puiFileSize);

_HMP4MUXER RdStg_Mp4Muxer_GetWritingWriter(_UC* pucFileName);

_HMP4MUXER RdStg_Mp4Repair_OpenFile(_UC *pucFileName);

_INT RdStg_Mp4Muxer_ReadCnf(_HMP4MUXER hHandle,_UI *puiFrameRate);

_INT RdStg_Mp4Muxer_ReadInfo(_HMP4MUXER hHandle,_UI *puiDuration);

_INT RdStg_Mp4Muxer_WriteSubCnf(_HMP4MUXER hHandle);
/*************************************************************************************************
读接口
*************************************************************************************************/
_INT RdStg_Mp4DeMuxer_Init();

_INT RdStg_Mp4DeMuxer_Destory();

_INT RdStg_Mp4DeMuxer_GetTotalTime(_UC *pucFileName, _UI *puiTimeTotalMs);//获取mp4文件的时长

_INT RdStg_Mp4DeMuxer_CheckFileEnd(_HMP4DEMUXER hHandle);

_HMP4DEMUXER RdStg_Mp4DeMuxer_OpenFile(_UC *pucFileName);//打开文件

_INT RdStg_Mp4DeMuxer_CloseFile(_HMP4DEMUXER hHandle);//关闭文件

_INT RdStg_Mp4DeMuxer_SetCycleRead(_HMP4DEMUXER hHandle, _UC ucFlag);

_INT RdStg_Mp4DeMuxer_GetAudioDes(_HMP4DEMUXER hHandle,_INT *puiAudioType, _UI *puiSampleRate, _UI *puiChannel);//获取音频描述

_INT RdStg_Mp4DeMuxer_GetVideoDes(_HMP4DEMUXER hHandle, _INT *puiVideoType, _UI* puiVideoWidth, _UI *puiVideoHeight);//获取视频描述

_INT RdStg_Mp4DeMuxer_GetCircleInf(_HMP4DEMUXER hHandle,ST_ZJ_VIDEO_CIRCLE *pstCircle);
//读取一帧数据
//pucStreambuf 数据缓冲区 
//*puiLength 数据长度,是一个int数组，表示每个nal的长度,当只有一个nal的话（音频）可以是一个int（取地址），一般为32项
//puiDataOffset缓冲区 中数据 的实际偏移量

_INT RdStg_Mp4DeMuxer_ReadBuf(_HMP4DEMUXER hHandle, _UC *pucBuf, _UI *puiBufLen, _UC *pucAVFlag, _UI *puiTimeStamp, _UC *pucFramePos, _UI *puiFrameLen);

_INT RdStg_Mp4DeMuxer_ReadFrame(_HMP4DEMUXER hHandle, _UC *pucStreambuf,_UI *puiNalNum, _UI *puiLength, _UC *pucAVType, _UI *puiTimeStamp,_UI *puiDataOffset, _UC *pucFrametype);//

_INT RdStg_Mp4DeMuxer_SeekFile(_HMP4DEMUXER hHandle, _UI uiSeekTime, _UI *uiSeekTimeStamp);

#ifdef __cplusplus
}
#endif

#endif


