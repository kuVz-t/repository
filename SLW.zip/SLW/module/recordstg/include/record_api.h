#ifndef _RECORD_API_H
#define _RECORD_API_H

#ifdef __cplusplus
extern "C" {
#endif
#include "config_type.h"
#include "config_camera.h"
typedef  MOS_MASK_HANDLE_TYPE(_RDFILEFD)           _RDFILEFD;

typedef struct st_RDSTG_DATE
{
    _UC ucCheck;        // $
    _UC ucBInUse;       // 是否使用 
    _UC ucRsv[2];       // 保留
    _UC aucDate[12];    // 20201207
}ST_RDSTG_DATE;            // date.txt存储结构体

typedef struct st_RDSTG_DATENODE
{
    ST_RDSTG_DATE stDate;          // date.txt存储结构体
    ST_MOS_LIST_NODE stNode;
}ST_RDSTG_DATENODE;    // date.txt存储结构体节点

typedef struct st_RDSTG_FILEDES
{
    _UC ucCheck;            // $
    _UC ucBInUse;           // 是否被使用
    _UC ucBCover;           // 是否覆盖录像
    _UC ucRsv;              // 保留
    _UI uiFileSeq;          // 文件句柄
    _UI uiStartTimeStamp;   // 录像开始时间 视频时间戳
    _UI uiEndTimeStamp;     // 录像结束时间 视频时间戳
    _CTIME_T cStartTime;    // 录像开始时间 系统时间戳
    _CTIME_T cStopTime;     // 录像结束时间 系统时间戳
#ifdef USER_RD_EXTERN_FILEDES
    _UI uiStreamId;         // 录像的码流     
    _UI uiAudioEncType;     // 录像音频编码类型
    _UI uiVideoEncType;     // 录像视频编码类型
    _UI uiVideoWidth;       // 录像视频分辨率宽
    _UI uiVideoHeight;      // 录像视频分辨率高
    _UI uiVideoFrameRate;   // 录像视频帧率
#endif
}ST_RDSTG_FILEDES;          // filedes.txt存储结构体

typedef struct st_RDSTG_FILEDESNODE
{
    ST_RDSTG_FILEDES stFileDes;    // filedes.txt存储结构体
    ST_MOS_LIST_NODE stNode;
}ST_RDSTG_FILEDESNODE; // filedes.txt存储结构体节点

typedef _INT (*PFUN_RDSTG_DATELIST)(_VPTR pUsrPoint, ST_MOS_LIST *pstDateList);
typedef _INT (*PFUN_RDSTG_FILELIST)(_VPTR pUsrPoint, ST_MOS_LIST *pstFileList);

_INT RdStg_SetCurRecordVideoParam(_INT iCamid, _INT iStreamid);
ST_CFG_VIDEODES *RdStg_GetCurRecordVideoParam();
_INT RdStg_SetCurRecordAudioParam();
ST_ZJ_AUDIO_PARAM *RdStg_GetCurRecordAudioParam();
 
_INT RdStg_Init(_INT iStreamId, _INT iMaxCameraNum);

_INT RdStg_Destory();

_INT RdStg_ResetStreamId(_INT iCamId, _INT iStreamId);

_INT RdStg_CreateEvent(_INT iCamId, _INT iDuration, _CTIME_T cNowTime);

_INT RdStg_StartCustom(_UC *pucPeerSID, _INT iCamId);

_INT RdStg_StopCustom(_UC *pucPeerSID, _INT iCamId);

_INT RdStg_SetAllDayRecordFlag(_INT iCamId, _UC AllDayFlag);

// 摄像机关闭标志
_INT RdStg_SetCamOpenFlag(_INT iCamId,_INT iOpenFlag);


_RDFILEFD RdStg_SeekOnOneFile(_RDFILEFD *pstRdStg_fileFD, _UC *pucPlayTime, _INT *piAdjustTime);
_RDFILEFD RdStg_OpenFile(_INT iCamId, _UC *pucPlayTime, _INT *piAdjustTime);
_INT RdStg_CloseFile(_RDFILEFD *hHandle);
/**************************************/
_INT RdStg_RepairFile(_UC *pucFileName,_UI *puiDuration);
/**************************************/
_INT RdStg_ReadData(_RDFILEFD hHandle, _UC *pucBuf, _UI *puiBufLen, _UC *pucAVFlag, _UI *puiTimeStamp, _UC *pucFramePos,_UI *puiFrameLen);///
_INT RdStg_SeekByTimeStr(_RDFILEFD hHandle,_UC *pucSeekTime);
_INT RdStg_SeekByTimeStamp(_RDFILEFD hHandle,_UI uiTimeStamp);
_INT RdStg_ReadFileDes(_RDFILEFD hHandle,ST_CFG_VIDEODES *pstVideoDes, ST_ZJ_AUDIO_PARAM *pstAudioParm);

_INT RdStg_QueryDate(_VPTR pUsrPoint, _INT iCamId, PFUN_RDSTG_DATELIST pfuncOnDateList);
_INT RdStg_QueryList(_VPTR pUsrPoint, _INT iCamId, _UC *pucDay, PFUN_RDSTG_FILELIST pfuncOnFileList);
_INT RdStg_Delete(_VPTR pUsrPoint, _INT iCamId, _UI uiStartTime, _UI uiEndTime);

_INT RdStg_AddCompatibleDate(_UC *pucDate,_INT iCamId);
_INT RdStg_AddCompatibleFile(_UC *pucDate,_INT iCamId,_UC *pucFilePath,_UI uiStartUnixTime,_UI uiEndUnixTime,_UI uiStartTime,_UI uiEndTime);

ST_MOS_LIST *RdStg_GetDateList(_INT iCamId);
ST_MOS_LIST *RdStg_GetFileDesList(_INT iCamId,_UC *pucDay);

//%04hu-%02hu-%02hu %02hu:%02hu:%02hu
ST_MOS_LIST *RdStg_GetFileListByPage(_INT iCamId,_UC *pucStartTime,_UI uiPageSize);

ST_RDSTG_FILEDES *RdStg_GetFileDesFromHandle(_RDFILEFD hHandle);
_INT RdStg_GetFileDes(_INT iCamId,_UC *pucDay,_CTIME_T cTime, ST_RDSTG_FILEDES *pstFileDes);

_INT RdStg_GetRecordFileList(_UC *pucPlaybackFileStartTime);
_INT RdStg_PlayBackFunc(_UC *pucPlaybackFileStartTime);

_RDFILEFD *RdStg_OpenPlayBackFile(_UC *pucPlaybackFileStartTime, _INT *piAdjustTime, _UC ucPlayMode);
_INT RdStg_ClosePlayBackFile(_RDFILEFD *hHandle);
_INT RdStg_ReadPlayBackFile(_RDFILEFD *pstRdStg_fileFD, _UC *pucBuf, _UI *puiBufLen, _UC *pucAVFlag, _UI *puiTimeStamp, _UC *pucFramePos, _UI *puiFrameLen);
#ifdef __cplusplus
}
#endif

#endif
