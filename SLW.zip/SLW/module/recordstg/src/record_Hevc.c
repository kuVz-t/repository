#include "mos.h"
#include "zj_type.h"
#include "record_mp4_prv.h"
#include "record_Hevc.h"


#define HEVC_MAX_SUB_LAYERS 7
#define HEVC_MAX_VPS_COUNT 16
#define HEVC_MAX_SPS_COUNT 32
#define HEVC_MAX_PPS_COUNT 256
#define HEVC_MAX_SHORT_TERM_RPS_COUNT 64
#define HEVC_MAX_CU_SIZE 128

#define HEVC_MAX_REFS 16
#define HEVC_MAX_DPB_SIZE 16 // A.4.1

#define HEVC_MAX_LOG2_CTB_SIZE 6

#pragma pack(1)


typedef struct
{
    const _UC *data;
    _UI idx;
    _UI len;
    _UI bits;
    _UC byte;
    _UI zeros;
} GetBitContext;


typedef struct 
{
    _UC  profile_space;
    _UC  tier_flag;
    _UC  profile_idc;
    _UI  profile_compatibility_flags;
    _LLID constraint_indicator_flags;
    _UC  level_idc;
} HVCCProfileTierLevel;

#pragma pack()


static int _FHHEVC_GetBitInit(GetBitContext* gbc, const _UC *data, int len)
{
    if (!gbc)
        return 0;

    memset(gbc, 0, sizeof(GetBitContext));
    gbc->data = data;
    gbc->len = len;

    return 1;
}

_UC _FHHEVC_GetByte(GetBitContext* gbc)
{
    _UC b;
    if (!gbc)
        return 0;
    
	if (gbc->idx >= gbc->len )
		return 0;
	b = gbc->data[gbc->idx++];
	if ( b == 0)
	{
		gbc->zeros++;
		if ( (gbc->idx < gbc->len) && (gbc->zeros == 2) && (gbc->data[gbc->idx] == 0x03))
		{
			gbc->idx++;
			gbc->zeros=0;
		}
	} 
	else 
	{
		gbc->zeros = 0;
	}
	return b;
};

_UI _FHHEVC_GetBit(GetBitContext* gbc) 
{
    if (!gbc)
        return 0;

	if (gbc->bits == 0) 
	{
		gbc->byte = _FHHEVC_GetByte(gbc);
		gbc->bits = 8;
	}
	gbc->bits--;
	return (gbc->byte >> gbc->bits) & 0x1;
};

_UI _FHHEVC_GetBits(GetBitContext* gbc, int bits) 
{
	_UI ret;
	_UI u = 0;
	while (bits > 0)
	{
		u <<= 1;
		ret = _FHHEVC_GetBit(gbc);
		u |= ret;
		bits--;
	}
	return u;
};

_UI _FHHEVC_GetUE(GetBitContext* gbc) 
{
    int zeros = 0;
    if (!gbc)
        return 0;
	while (gbc->idx < gbc->len && _FHHEVC_GetBit(gbc) == 0 ) zeros++;
	return _FHHEVC_GetBits(gbc, zeros) + ((1 << zeros) - 1);
};
		
_INT _FHHEVC_GetSE(GetBitContext* gbc)
{
	_UI UE = _FHHEVC_GetUE(gbc);
	_UI positive = UE & 1;
	_INT SE = (UE + 1) >> 1;
	if (!positive)
	{
		SE = -SE;
	}
	return SE;
};



static void _FHHEVC_SkipScalingListData(GetBitContext* gbc)
{
    int i, j, k, num_coeffs;

    for (i = 0; i < 4; i++)
        for (j = 0; j < (i == 3 ? 2 : 6); j++)
            if (!_FHHEVC_GetBits(gbc, 1))         // scaling_list_pred_mode_flag[i][j]
                _FHHEVC_GetUE(gbc); // scaling_list_pred_matrix_id_delta[i][j]
            else {
                num_coeffs = MOS_MIN_NUM(64, 1 << (4 + (i << 1)));

                if (i > 1)
                    _FHHEVC_GetUE(gbc); // scaling_list_dc_coef_minus8[i-2][j]

                for (k = 0; k < num_coeffs; k++)
                    _FHHEVC_GetUE(gbc); // scaling_list_delta_coef
            }
}

static void _FHHEVC_SkipTimingInfo(GetBitContext *gbc)
{
    _FHHEVC_GetBits(gbc, 16);
    _FHHEVC_GetBits(gbc, 16); // num_units_in_tick
    _FHHEVC_GetBits(gbc, 16);
    _FHHEVC_GetBits(gbc, 16); // time_scale

    if (_FHHEVC_GetBits(gbc, 1))          // poc_proportional_to_timing_flag
        _FHHEVC_GetUE(gbc); // num_ticks_poc_diff_one_minus1
}


static int _FHHEVC_ParseRPS(GetBitContext *gbc, unsigned int rps_idx,
                     unsigned int num_rps,
                     unsigned int num_delta_pocs[HEVC_MAX_SHORT_TERM_RPS_COUNT])
{
    unsigned int i;

    if (rps_idx && _FHHEVC_GetBits(gbc, 1)) { // inter_ref_pic_set_prediction_flag
        /* this should only happen for slice headers, and this isn't one */
        if (rps_idx >= num_rps)
            return 0;

        _FHHEVC_GetBits(gbc, 1); // delta_rps_sign
        _FHHEVC_GetUE(gbc); // abs_delta_rps_minus1

        num_delta_pocs[rps_idx] = 0;

        /*
         * From libavcodec/hevc_ps.c:
         *
         * if (is_slice_header) {
         *    //foo
         * } else
         *     rps_ridx = &sps->st_rps[rps - sps->st_rps - 1];
         *
         * where:
         * rps:             &sps->st_rps[rps_idx]
         * sps->st_rps:     &sps->st_rps[0]
         * is_slice_header: rps_idx == num_rps
         *
         * thus:
         * if (num_rps != rps_idx)
         *     rps_ridx = &sps->st_rps[rps_idx - 1];
         *
         * NumDeltaPocs[RefRpsIdx]: num_delta_pocs[rps_idx - 1]
         */
        for (i = 0; i <= num_delta_pocs[rps_idx - 1]; i++) {
            _UC use_delta_flag = 0;
            _UC used_by_curr_pic_flag = (_UC)_FHHEVC_GetBits(gbc, 1);
            if (!used_by_curr_pic_flag)
                use_delta_flag = (_UC)_FHHEVC_GetBits(gbc, 1);

            if (used_by_curr_pic_flag || use_delta_flag)
                num_delta_pocs[rps_idx]++;
        }
    } else {
        unsigned int num_negative_pics = _FHHEVC_GetUE(gbc);
        unsigned int num_positive_pics = _FHHEVC_GetUE(gbc);

        //if ((num_positive_pics + (FHU64)num_negative_pics) * 2 > get_bits_left(gbc))
        //    return 0;

        num_delta_pocs[rps_idx] = num_negative_pics + num_positive_pics;

        for (i = 0; i < num_negative_pics; i++) {
            _FHHEVC_GetUE(gbc); // delta_poc_s0_minus1[rps_idx]
            _FHHEVC_GetBits(gbc, 1); // used_by_curr_pic_s0_flag[rps_idx]
        }

        for (i = 0; i < num_positive_pics; i++) {
            _FHHEVC_GetUE(gbc); // delta_poc_s1_minus1[rps_idx]
            _FHHEVC_GetBits(gbc, 1); // used_by_curr_pic_s1_flag[rps_idx]
        }
    }

    return 0;
}

static void _FHHEVC_SkipSubLayerHrdParamters(GetBitContext *gbc,
                                          unsigned int cpb_cnt_minus1,
                                          _UC sub_pic_hrd_params_present_flag)
{
    unsigned int i;

    for (i = 0; i <= cpb_cnt_minus1; i++) {
        _FHHEVC_GetUE(gbc); // bit_rate_value_minus1
        _FHHEVC_GetUE(gbc); // cpb_size_value_minus1

        if (sub_pic_hrd_params_present_flag) {
            _FHHEVC_GetUE(gbc); // cpb_size_du_value_minus1
            _FHHEVC_GetUE(gbc); // bit_rate_du_value_minus1
        }

        _FHHEVC_GetBits(gbc, 1); // cbr_flag
    }
}


static int _FHHEVC_SkipHrdParamters(GetBitContext *gbc, _UC cprms_present_flag,
                                unsigned int max_sub_layers_minus1)
{
    unsigned int i;
    _UC sub_pic_hrd_params_present_flag = 0;
    _UC nal_hrd_parameters_present_flag = 0;
    _UC vcl_hrd_parameters_present_flag = 0;

    if (cprms_present_flag) {
        nal_hrd_parameters_present_flag = (_UC)_FHHEVC_GetBits(gbc, 1);
        vcl_hrd_parameters_present_flag = (_UC)_FHHEVC_GetBits(gbc, 1);

        if (nal_hrd_parameters_present_flag ||
            vcl_hrd_parameters_present_flag) {
            sub_pic_hrd_params_present_flag = (_UC)_FHHEVC_GetBits(gbc, 1);

            if (sub_pic_hrd_params_present_flag)
                /*
                 * tick_divisor_minus2                          u(8)
                 * du_cpb_removal_delay_increment_length_minus1 u(5)
                 * sub_pic_cpb_params_in_pic_timing_sei_flag    u(1)
                 * dpb_output_delay_du_length_minus1            u(5)
                 */
                _FHHEVC_GetBits(gbc, 19);

            /*
             * bit_rate_scale u(4)
             * cpb_size_scale u(4)
             */
            _FHHEVC_GetBits(gbc, 8);

            if (sub_pic_hrd_params_present_flag)
                _FHHEVC_GetBits(gbc, 4); // cpb_size_du_scale

            /*
             * initial_cpb_removal_delay_length_minus1 u(5)
             * au_cpb_removal_delay_length_minus1      u(5)
             * dpb_output_delay_length_minus1          u(5)
             */
            _FHHEVC_GetBits(gbc, 15);
        }
    }

    for (i = 0; i <= max_sub_layers_minus1; i++) {
        unsigned int cpb_cnt_minus1            = 0;
        _UC low_delay_hrd_flag             = 0;
        _UC fixed_pic_rate_within_cvs_flag = 0;
        _UC fixed_pic_rate_general_flag    = (_UC)_FHHEVC_GetBits(gbc, 1);

        if (!fixed_pic_rate_general_flag)
            fixed_pic_rate_within_cvs_flag = (_UC)_FHHEVC_GetBits(gbc, 1);

        if (fixed_pic_rate_within_cvs_flag)
            _FHHEVC_GetUE(gbc); // elemental_duration_in_tc_minus1
        else
            low_delay_hrd_flag = (_UC)_FHHEVC_GetBits(gbc, 1);

        if (!low_delay_hrd_flag) {
            cpb_cnt_minus1 = _FHHEVC_GetUE(gbc);
            if (cpb_cnt_minus1 > 31)
                return 0;
        }

        if (nal_hrd_parameters_present_flag)
            _FHHEVC_SkipSubLayerHrdParamters(gbc, cpb_cnt_minus1,
                                          sub_pic_hrd_params_present_flag);

        if (vcl_hrd_parameters_present_flag)
            _FHHEVC_SkipSubLayerHrdParamters(gbc, cpb_cnt_minus1,
                                          sub_pic_hrd_params_present_flag);
    }

    return 0;
}


static void _FHHEVC_ParseVUI(GetBitContext *gbc,
                           ST_HEVC_DECODERCFG_RECORDPARTY *hvcc,
                           unsigned int max_sub_layers_minus1)
{
    unsigned int min_spatial_segmentation_idc;

    if (_FHHEVC_GetBits(gbc, 1))              // aspect_ratio_info_present_flag
        if (_FHHEVC_GetBits(gbc, 8) == 255) // aspect_ratio_idc
        {
            _FHHEVC_GetBits(gbc, 16);
            _FHHEVC_GetBits(gbc, 16); // sar_width u(16), sar_height u(16)
        }

    if (_FHHEVC_GetBits(gbc, 1))  // overscan_info_present_flag
        _FHHEVC_GetBits(gbc, 1); // overscan_appropriate_flag

    if (_FHHEVC_GetBits(gbc, 1)) {  // video_signal_type_present_flag
        _FHHEVC_GetBits(gbc, 4); // video_format u(3), video_full_range_flag u(1)

        if (_FHHEVC_GetBits(gbc, 1)) // colour_description_present_flag
            /*
             * colour_primaries         u(8)
             * transfer_characteristics u(8)
             * matrix_coeffs            u(8)
             */
            _FHHEVC_GetBits(gbc, 24);
    }

    if (_FHHEVC_GetBits(gbc,1)) {        // chroma_loc_info_present_flag
        _FHHEVC_GetUE(gbc); // chroma_sample_loc_type_top_field
        _FHHEVC_GetUE(gbc); // chroma_sample_loc_type_bottom_field
    }

    /*
     * neutral_chroma_indication_flag u(1)
     * field_seq_flag                 u(1)
     * frame_field_info_present_flag  u(1)
     */
    _FHHEVC_GetBits(gbc, 3);

    if (_FHHEVC_GetBits(gbc,1)) {        // default_display_window_flag
        _FHHEVC_GetUE(gbc); // def_disp_win_left_offset
        _FHHEVC_GetUE(gbc); // def_disp_win_right_offset
        _FHHEVC_GetUE(gbc); // def_disp_win_top_offset
        _FHHEVC_GetUE(gbc); // def_disp_win_bottom_offset
    }

    if (_FHHEVC_GetBits(gbc,1)) { // vui_timing_info_present_flag
        _FHHEVC_SkipTimingInfo(gbc);

        if (_FHHEVC_GetBits(gbc,1)) // vui_hrd_parameters_present_flag
            _FHHEVC_SkipHrdParamters(gbc, 1, max_sub_layers_minus1);
    }

    if (_FHHEVC_GetBits(gbc,1)) { // bitstream_restriction_flag
        /*
         * tiles_fixed_structure_flag              u(1)
         * motion_vectors_over_pic_boundaries_flag u(1)
         * restricted_ref_pic_lists_flag           u(1)
         */
        _FHHEVC_GetBits(gbc, 3);

        min_spatial_segmentation_idc = _FHHEVC_GetUE(gbc);

        /*
         * unsigned int(12) min_spatial_segmentation_idc;
         *
         * The min_spatial_segmentation_idc indication must indicate a level of
         * spatial segmentation equal to or less than the lowest level of
         * spatial segmentation indicated in all the parameter sets.
         */
        hvcc->min_spatial_segmentation_idc = MOS_MIN_NUM(hvcc->min_spatial_segmentation_idc,
                                                   min_spatial_segmentation_idc);

        _FHHEVC_GetUE(gbc); // max_bytes_per_pic_denom
        _FHHEVC_GetUE(gbc); // max_bits_per_min_cu_denom
        _FHHEVC_GetUE(gbc); // log2_max_mv_length_horizontal
        _FHHEVC_GetUE(gbc); // log2_max_mv_length_vertical
    }
}


static void _FHHEVC_UpdatePTL(ST_HEVC_DECODERCFG_RECORDPARTY *hvcc,
                            HVCCProfileTierLevel *ptl)
{

    hvcc->general_profile_space = ptl->profile_space;
    if (hvcc->general_tier_flag < ptl->tier_flag)
        hvcc->general_level_idc = ptl->level_idc;
    else
        hvcc->general_level_idc = MOS_MAX_NUM(hvcc->general_level_idc, ptl->level_idc);

    hvcc->general_tier_flag = MOS_MAX_NUM(hvcc->general_tier_flag, ptl->tier_flag);
    hvcc->general_profile_idc = MOS_MAX_NUM(hvcc->general_profile_idc, ptl->profile_idc);
    hvcc->general_profile_compatibility_flags &= ptl->profile_compatibility_flags;
    hvcc->general_constraint_indicator_flags &= ptl->constraint_indicator_flags;
}

static void _FHHEVC_ParsePTL(GetBitContext *gbc, ST_HEVC_DECODERCFG_RECORDPARTY *hvcc, unsigned int max_sub_layers_minus1)
{
    unsigned int i;
    HVCCProfileTierLevel general_ptl;
    _UC sub_layer_profile_present_flag[HEVC_MAX_SUB_LAYERS];
    _UC sub_layer_level_present_flag[HEVC_MAX_SUB_LAYERS];

    general_ptl.profile_space               = (_UC)_FHHEVC_GetBits(gbc, 2);
    general_ptl.tier_flag                   = (_UC)_FHHEVC_GetBits(gbc, 1);
    general_ptl.profile_idc                 = (_UC)_FHHEVC_GetBits(gbc, 5);
    general_ptl.profile_compatibility_flags = (_UC)_FHHEVC_GetBits(gbc, 32);
    general_ptl.constraint_indicator_flags  = _FHHEVC_GetBits(gbc, 48);
    general_ptl.level_idc                   = (_UC)_FHHEVC_GetBits(gbc, 8);

    _FHHEVC_UpdatePTL(hvcc, &general_ptl);

    for (i = 0; i < max_sub_layers_minus1; i++) {
        sub_layer_profile_present_flag[i] = (_UC)_FHHEVC_GetBits(gbc, 1);
        sub_layer_level_present_flag[i]   = (_UC)_FHHEVC_GetBits(gbc, 1);
    }

    if (max_sub_layers_minus1 > 0)
        for (i = max_sub_layers_minus1; i < 8; i++)
            _FHHEVC_GetBits(gbc, 2); // reserved_zero_2bits[i]

    for (i = 0; i < max_sub_layers_minus1; i++) {
        if (sub_layer_profile_present_flag[i]) {
            _FHHEVC_GetBits(gbc, 2);
            _FHHEVC_GetBits(gbc, 1);
            _FHHEVC_GetBits(gbc, 5);
            _FHHEVC_GetBits(gbc, 32);
            _FHHEVC_GetBits(gbc, 1);
            _FHHEVC_GetBits(gbc, 1);
            _FHHEVC_GetBits(gbc, 1);
            _FHHEVC_GetBits(gbc, 1);
            _FHHEVC_GetBits(gbc, 44);
        }

        if (sub_layer_level_present_flag[i])
            _FHHEVC_GetBits(gbc, 8);
    }

}

static int _FHHEVC_ParseVPS(GetBitContext *gbc,
                          ST_HEVC_DECODERCFG_RECORDPARTY *hvcc)
{
    unsigned int vps_max_sub_layers_minus1;

    _FHHEVC_GetBits(gbc, 12);

    vps_max_sub_layers_minus1 = _FHHEVC_GetBits(gbc, 3);


    hvcc->numTemporalLayers = MOS_MAX_NUM(hvcc->numTemporalLayers,
                                    vps_max_sub_layers_minus1 + 1);
    _FHHEVC_GetBits(gbc, 17);

    _FHHEVC_ParsePTL(gbc, hvcc, vps_max_sub_layers_minus1);
    
    return 1;
}



static int _FHHEVC_ParseSPS(GetBitContext *gbc,
                          ST_HEVC_DECODERCFG_RECORDPARTY *hvcc)
{
    unsigned int i, sps_max_sub_layers_minus1, log2_max_pic_order_cnt_lsb_minus4;
    unsigned int num_short_term_ref_pic_sets, num_delta_pocs[HEVC_MAX_SHORT_TERM_RPS_COUNT];

    _FHHEVC_GetBits(gbc, 4);// sps_video_parameter_set_id

    sps_max_sub_layers_minus1 = _FHHEVC_GetBits(gbc, 3);
    hvcc->numTemporalLayers = MOS_MAX_NUM(hvcc->numTemporalLayers,
                                    sps_max_sub_layers_minus1 + 1);

    hvcc->temporalIdNested = (_UC)_FHHEVC_GetBits(gbc, 1);

    _FHHEVC_ParsePTL(gbc, hvcc, sps_max_sub_layers_minus1);

    _FHHEVC_GetUE(gbc); // sps_seq_parameter_set_id

    hvcc->chromaFormat = (_UC)_FHHEVC_GetUE(gbc);

    if (hvcc->chromaFormat == 3)
        _FHHEVC_GetBits(gbc, 1); // separate_colour_plane_flag

    _FHHEVC_GetUE(gbc); // pic_width_in_luma_samples
    _FHHEVC_GetUE(gbc); // pic_height_in_luma_samples
    if (_FHHEVC_GetBits(gbc, 1)) {        // conformance_window_flag
        _FHHEVC_GetUE(gbc); // conf_win_left_offset
        _FHHEVC_GetUE(gbc); // conf_win_right_offset
        _FHHEVC_GetUE(gbc); // conf_win_top_offset
        _FHHEVC_GetUE(gbc); // conf_win_bottom_offset
    }

    hvcc->bitDepthLumaMinus8          = (_UC)_FHHEVC_GetUE(gbc);
    hvcc->bitDepthChromaMinus8        = (_UC)_FHHEVC_GetUE(gbc);
    log2_max_pic_order_cnt_lsb_minus4 = _FHHEVC_GetUE(gbc);

    /* sps_sub_layer_ordering_info_present_flag */
    i = _FHHEVC_GetBits(gbc, 1) ? 0 : sps_max_sub_layers_minus1;
    for (; i <= sps_max_sub_layers_minus1; i++)
    {
        _FHHEVC_GetUE(gbc); // max_dec_pic_buffering_minus1
        _FHHEVC_GetUE(gbc); // max_num_reorder_pics
        _FHHEVC_GetUE(gbc); // max_latency_increase_plus1
    }

    _FHHEVC_GetUE(gbc); // log2_min_luma_coding_block_size_minus3
    _FHHEVC_GetUE(gbc); // log2_diff_max_min_luma_coding_block_size
    _FHHEVC_GetUE(gbc); // log2_min_transform_block_size_minus2
    _FHHEVC_GetUE(gbc); // log2_diff_max_min_transform_block_size
    _FHHEVC_GetUE(gbc); // max_transform_hierarchy_depth_inter
    _FHHEVC_GetUE(gbc); // max_transform_hierarchy_depth_intra

    if (_FHHEVC_GetBits(gbc, 1) && // scaling_list_enabled_flag
        _FHHEVC_GetBits(gbc, 1))   // sps_scaling_list_data_present_flag
        _FHHEVC_SkipScalingListData(gbc);

    _FHHEVC_GetBits(gbc, 1); // amp_enabled_flag
    _FHHEVC_GetBits(gbc, 1); // sample_adaptive_offset_enabled_flag

    if (_FHHEVC_GetBits(gbc, 1)) {           // pcm_enabled_flag
        _FHHEVC_GetBits(gbc, 4); // pcm_sample_bit_depth_luma_minus1
        _FHHEVC_GetBits(gbc, 4); // pcm_sample_bit_depth_chroma_minus1
        _FHHEVC_GetUE(gbc);    // log2_min_pcm_luma_coding_block_size_minus3
        _FHHEVC_GetUE(gbc);    // log2_diff_max_min_pcm_luma_coding_block_size
        _FHHEVC_GetBits(gbc, 1);    // pcm_loop_filter_disabled_flag
    }

    num_short_term_ref_pic_sets = _FHHEVC_GetUE(gbc);
    if (num_short_term_ref_pic_sets > HEVC_MAX_SHORT_TERM_RPS_COUNT)
        return 0;

    for (i = 0; i < num_short_term_ref_pic_sets; i++) {
        int ret = _FHHEVC_ParseRPS(gbc, i, num_short_term_ref_pic_sets, num_delta_pocs);
        if (ret < 0)
            return ret;
    }

    if (_FHHEVC_GetBits(gbc, 1)) {                               // long_term_ref_pics_present_flag
        unsigned num_long_term_ref_pics_sps = _FHHEVC_GetUE(gbc);
        if (num_long_term_ref_pics_sps > 31U)
            return 0;
        for (i = 0; i < num_long_term_ref_pics_sps; i++) { // num_long_term_ref_pics_sps
            int len = MOS_MIN_NUM(log2_max_pic_order_cnt_lsb_minus4 + 4, 16);
            _FHHEVC_GetBits(gbc, len); // lt_ref_pic_poc_lsb_sps[i]
            _FHHEVC_GetBits(gbc, 1);      // used_by_curr_pic_lt_sps_flag[i]
        }
    }

    _FHHEVC_GetBits(gbc, 1); // sps_temporal_mvp_enabled_flag
    _FHHEVC_GetBits(gbc, 1); // strong_intra_smoothing_enabled_flag

    if (_FHHEVC_GetBits(gbc, 1)) // vui_parameters_present_flag
        _FHHEVC_ParseVUI(gbc, hvcc, sps_max_sub_layers_minus1);

    /* nothing useful for hvcC past this point */
    return 1;
}

static int _FHHEVC_ParsePPS(GetBitContext *gbc,
                          ST_HEVC_DECODERCFG_RECORDPARTY *hvcc)
{
    _UC tiles_enabled_flag, entropy_coding_sync_enabled_flag;

    _FHHEVC_GetUE(gbc); // pps_pic_parameter_set_id
    _FHHEVC_GetUE(gbc); // pps_seq_parameter_set_id

    /*
     * dependent_slice_segments_enabled_flag u(1)
     * output_flag_present_flag              u(1)
     * num_extra_slice_header_bits           u(3)
     * sign_data_hiding_enabled_flag         u(1)
     * cabac_init_present_flag               u(1)
     */
    _FHHEVC_GetBits(gbc, 7);

    _FHHEVC_GetUE(gbc); // num_ref_idx_l0_default_active_minus1
    _FHHEVC_GetUE(gbc); // num_ref_idx_l1_default_active_minus1
    _FHHEVC_GetSE(gbc); // init_qp_minus26

    /*
     * constrained_intra_pred_flag u(1)
     * transform_skip_enabled_flag u(1)
     */
    _FHHEVC_GetBits(gbc, 2);

    if (_FHHEVC_GetBits(gbc, 1))          // cu_qp_delta_enabled_flag
        _FHHEVC_GetUE(gbc); // diff_cu_qp_delta_depth

    _FHHEVC_GetSE(gbc); // pps_cb_qp_offset
    _FHHEVC_GetSE(gbc); // pps_cr_qp_offset

    /*
     * pps_slice_chroma_qp_offsets_present_flag u(1)
     * weighted_pred_flag               u(1)
     * weighted_bipred_flag             u(1)
     * transquant_bypass_enabled_flag   u(1)
     */
    _FHHEVC_GetBits(gbc, 4);

    tiles_enabled_flag               = (_UC)_FHHEVC_GetBits(gbc, 1);
    entropy_coding_sync_enabled_flag = (_UC)_FHHEVC_GetBits(gbc, 1);

    if (entropy_coding_sync_enabled_flag && tiles_enabled_flag)
        hvcc->parallelismType = 0; // mixed-type parallel decoding
    else if (entropy_coding_sync_enabled_flag)
        hvcc->parallelismType = 3; // wavefront-based parallel decoding
    else if (tiles_enabled_flag)
        hvcc->parallelismType = 2; // tile-based parallel decoding
    else
        hvcc->parallelismType = 1; // slice-based parallel decoding

    /* nothing useful for hvcC past this point */
    return 1;
}



_UI FHHEVC_FrameParse(const _UC *nalu, _UI naluSize, HEVCNALUnitType naluType, ST_HEVC_DECODERCFG_RECORDPARTY *hevc)
{
    GetBitContext gbc;
    _FHHEVC_GetBitInit(&gbc, nalu, naluSize);
	switch (naluType)
    {
        case HEVC_NAL_VPS:
            _FHHEVC_ParseVPS(&gbc, hevc);
            break;
        case HEVC_NAL_SPS:
            _FHHEVC_ParseSPS(&gbc, hevc);
            break;
        case HEVC_NAL_PPS:
            _FHHEVC_ParsePPS(&gbc, hevc);
        default:
            break;
	}

    hevc->configurationVersion = 1;
    if (hevc->min_spatial_segmentation_idc > MAX_SPATIAL_SEGMENTATION)
        hevc->min_spatial_segmentation_idc = 0;
    if (!hevc->min_spatial_segmentation_idc)
        hevc->parallelismType = 0;

    hevc->avgFrameRate      = 0;
    hevc->constantFrameRate = 0;

    hevc->numOfArrays++;
    
    return 1;
}

