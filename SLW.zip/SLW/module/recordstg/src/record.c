﻿#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "record_api.h"
#include "IoManage_api.h"
#include "media_cache_api.h"
#include "config_api.h"
#include "record_mp4.h"
#include "record_prv.h"
#include "kjiot_device_api.h"
#include "adpt_json_adapt.h"
#include "record_mp4_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

//#define PLAYBACK_DEBUG 1

static ST_RDSTG_MSG_NODE *g_pstMsgHead      = MOS_NULL;
static ST_RECORD_MNG      g_stRecordMng     = {0};

static ST_CFG_VIDEODES   *g_pstRdVideoParam = MOS_NULL;
static ST_ZJ_AUDIO_PARAM *g_pstRdAudioParam = MOS_NULL;
/********************************************************************
********************************************************************/
ST_RECORD_MNG *RdStg_GetMng()
{
    return &g_stRecordMng;
}

_INT RdStg_SetCurRecordVideoParam(_INT iCamid, _INT iStreamid)
{
    // 获取视频参数
    g_pstRdVideoParam = Config_GetVideoDes(iCamid, iStreamid);
    return MOS_OK;
}

ST_CFG_VIDEODES *RdStg_GetCurRecordVideoParam()
{
    return g_pstRdVideoParam;
}

_INT RdStg_SetCurRecordAudioParam()
{
    // 获取音频参数
    g_pstRdAudioParam = Config_GetCamAudioParm(0);
    return MOS_OK;
}

ST_ZJ_AUDIO_PARAM *RdStg_GetCurRecordAudioParam()
{
    return g_pstRdAudioParam;
}


// 录像的IOT output接口
_INT RdStg_ProcEventOutput(_UI uiAIIoTType, _LLID lluAIIoTID, _UC* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    MOS_PARAM_NULL_RETERR(pstTriggerInf);
    MOS_PARAM_NULL_RETERR(pSignalValue);

    _INT iContrlType   = 0;
    _INT iDuration     = 0; 
    _UC* pucPropStr    = MOS_NULL;
    _HANDLE hPropObj   = MOS_NULL;
    _UI  uiIotDuration = 0;
    ST_CFG_INIOT_NODE *pstInIotNode = Config_FindInnerIotDevice(uiAIIoTType,lluAIIoTID);
    
    // MOS_LOG_INF(RDSTG_LOGSTR,"IOT Alarm Is Coming, Go to Record Now  pSignalValue:%s !!!", pSignalValue);

    // 转义成json数据
    JSON_HANDLE hRoot = Adpt_Json_Parse((_UC*)pSignalValue);
    if(hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"json parse err");
        return MOS_ERR;
    }
    if(pstInIotNode == MOS_NULL || pstInIotNode->uiOpenFlag == 0)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"KjIot %u %llu can't find device node",uiAIIoTType,lluAIIoTID);
        Adpt_Json_Delete(hRoot);
        return MOS_ERR;
    }
    // json数据解析
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),&iContrlType);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Duration"),&iDuration);

    // 获取Record的KjIot属性
    pucPropStr = Config_GetInIotProp(EN_ZJ_AIIOT_TYPE_RECORD,lluAIIoTID);
    // 转义成json数据
    hPropObj = Adpt_Json_Parse(pucPropStr);
    // MOS_LOG_INF(RDSTG_LOGSTR,"uiAIIoTType :%d  hPropObj:%s !!!", uiAIIoTType, pucPropStr);
    // json数据解析
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPropObj,(_UC*)"Duration"),&uiIotDuration);

    if(iContrlType == 1)
    {
        if(iDuration == 0)
        {
            iDuration = uiIotDuration;
        }
#if SDK_AWAKE_SLEEP_ENABLE
        if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //低功耗设备
        {
            // 门铃设备或低功耗设备使用统一自定义录像时长
            iDuration = uiIotDuration;
        }
#endif
        // 报警触发录像
        RdStg_CreateEvent(0,iDuration,pstTriggerInf->tCreateTime);
    }

    Adpt_Json_Delete(hRoot);
    Adpt_Json_Delete(hPropObj);
    return MOS_OK;
}

// 查询或修改文件
_INT RdStg_FindAndRepairFile(_UC *pucDate)
{
    MOS_PARAM_NULL_RETERR(pucDate);

    _INT iRet = 0;
    _INT iRetLen = 0;
    _INT iSize = 0;
    _INT iSeq = 0;
    _UI uiRepairDuration = 0;
    _UC aucFileName[256];
    _UC aucSubName[256];
    _UC aucVersion[24];
    _HFILE hFile = MOS_NULL;
    ST_RDSTG_FILEDES stTmpDes;

    if(MOS_STRLEN(pucDate) == 0)
    {
        return MOS_OK;
    }

    MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%s",Config_GetCoreMng()->aucCachePath,0,pucDate,RDSTG_FILEDESCFG_NAME);
    MOS_LOG_INF(RDSTG_LOGSTR,"Record File aucFileName %s", aucFileName);

    hFile = Mos_FileOpen(aucFileName, MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL){
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return MOS_ERR;
    }
    Mos_FileRead(hFile, aucVersion, 16);
    if(MOS_STRNCMP(aucVersion, RDSTG_FILEDESCFG_VERSION,MOS_STRLEN(RDSTG_FILEDESCFG_VERSION)) != 0){
        Mos_FileClose(hFile);
        return MOS_ERR;
    }
    iSize = sizeof(ST_RDSTG_FILEDES);
    do{
        iRetLen = Mos_FileRead(hFile,(_UC *)&stTmpDes,iSize);
        if(iRetLen == iSize && stTmpDes.ucBInUse == 1 && stTmpDes.ucCheck == '$' && (stTmpDes.cStopTime == 0 || stTmpDes.uiEndTimeStamp == 0)) // PC uiEndTimeStamp = 0
        {
            iSeq = stTmpDes.uiFileSeq;
            MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%d.mp4",Config_GetCoreMng()->aucCachePath,0,pucDate,iSeq);
            MOS_PRINTF("stTmpDes.cStopTime: %u  stTmpDes.uiEndTimeStamp: %u \r\n", stTmpDes.cStopTime, stTmpDes.uiEndTimeStamp);
            MOS_LOG_INF(RDSTG_LOGSTR,"RM Record File aucFileName %s", aucFileName);
            Mos_FileRmv(aucFileName);
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,-iSize);
            stTmpDes.ucBInUse = 0;
            Mos_FileWrite(hFile,(_UC *)&stTmpDes,iSize);
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,0);
        }
    }while(Mos_FileEof(hFile) == MOS_FALSE);


    /*MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%d.mp4",Config_GetCoreMng()->aucCachePath,0,pucDate,iSeq);
    MOS_VSNPRINTF(aucSubName,256,"%s/%d/%s/%d.inf",Config_GetCoreMng()->aucCachePath,0,pucDate,iSeq);
    if(Mos_FileIsExist(aucSubName))
    {
        iRet = RdStg_RepairFile(aucFileName,&uiRepairDuration);
    }
    else
    {
        iRet = MOS_ERR;
    }

    if(uiRepairDuration != 0 && iRet != MOS_ERR)
    {
        Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,-iSize);
        stTmpDes.uiEndTimeStamp = stTmpDes.uiStartTimeStamp + uiRepairDuration;
        stTmpDes.cStopTime = stTmpDes.cStartTime + uiRepairDuration / 1000;
        Mos_FileWrite(hFile,(_UC *)&stTmpDes,iSize);
    }
    else
    {
        Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,-iSize);
        stTmpDes.ucBInUse = 0;
        Mos_FileWrite(hFile,(_UC *)&stTmpDes,iSize);
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        Mos_FileRmv(aucSubName);
        MOS_LOG_ERR(RDSTG_LOGSTR,"repair file fail, file name : %s",aucFileName);
        return iRet;
    }*/
    
    Mos_FileClose(hFile);
    return MOS_OK;
}

// 查找映射文件
static _INT RdStg_FindMappingFile(_UC *pucMapDes,_UC *pucMapFile,_UI uiFileSeq)
{
    MOS_PARAM_NULL_RETERR(pucMapDes);
    MOS_PARAM_NULL_RETERR(pucMapFile);

    _INT iRet = 0;
    _INT iSize = sizeof(ST_RDSTG_MAP_INF);
    _HFILE hFile = MOS_NULL;
    ST_RDSTG_MAP_INF stMapInf;
    
    hFile = Mos_FileOpen(pucMapDes,MOS_FILE_O_BIN | MOS_FILE_O_RDWR);
    if(hFile == MOS_NULL)
    {
        return MOS_ERR;
    }
    do
    {
        iRet = Mos_FileRead(hFile,(_UC*)&stMapInf,iSize);
        if(iRet != iSize)
        {
            break;
        }
        if(stMapInf.uiDataSeq == uiFileSeq)
        {
            MOS_STRNCPY(pucMapFile,stMapInf.aucFileMap,256);
            Mos_FileClose(hFile);
            return MOS_OK;
        }
    }while(Mos_FileEof(hFile) == MOS_FALSE);

    Mos_FileClose(hFile);
    return MOS_ERR;
}

// 录像模块初始化
_INT RdStg_Init(_INT iStreamId, _INT iMaxCameraNum)
{
    if(RdStg_GetMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(RDSTG_LOGSTR,"Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stRecordMng, 0, sizeof(g_stRecordMng));
    RdStg_Mp4Muxer_Init();
    RdStg_Mp4DeMuxer_Init();
    
    RdStg_GetMng()->uiCurrentSeq      = 0;
    RdStg_GetMng()->ucDefaultStreamID = iStreamId;
    RdStg_GetMng()->uiMaxCamCnt       = iMaxCameraNum;
    Mos_MutexCreate(&RdStg_GetMng()->hMutex);
    // 设置录像的KjIot output接口
    KjIoT_AddDevContrlFun(EN_ZJ_AIIOT_TYPE_RECORD,RdStg_ProcEventOutput,MOS_NULL,MOS_NULL,MOS_NULL);
    // 向local IO注册
    IoMng_Register((_UC*)"record", RdStg_IoProcess,  RdStg_IoStop, RdStg_IoReStart,RdStg_IoAutoDelete);
    RdStg_GetMng()->ucInitFlag        = 1;
    MOS_LOG_INF(RDSTG_LOGSTR,"record task init");
    return MOS_OK;
}

// 销毁录像模块
_INT RdStg_Destory()
{
    if(RdStg_GetMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(RDSTG_LOGSTR,"Already Destroy");
        return MOS_OK;
    }
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RDSTG_NODE *pstRdNode = MOS_NULL;
    ST_RDSTG_READER_NODE *pstReadNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&RdStg_GetMng()->stReadList, pstReadNode, stIterator)
    {
        MOS_LIST_RMVNODE(&RdStg_GetMng()->stReadList, pstReadNode);
        MOS_FREE(pstReadNode);
    }
    FOR_EACHDATA_INLIST(&RdStg_GetMng()->stRdList, pstRdNode, stIterator)
    {
        if(pstRdNode->hAudio)
        {
            #if 0
            Media_AudioDestroyReadHandle(pstRdNode->hAudio);
            #else
            Media_AudioSetFrameUsed2(pstRdNode->hAudio);
            Media_AudioDestroyReadHandle2(pstRdNode->hAudio);
            #endif
            pstRdNode->hAudio = MOS_NULL;
        }
        if(pstRdNode->hVideo)
        {
            #if 0
            Media_VideoDestroyReadHandle(pstRdNode->hVideo);
            #else
            Media_VideoSetFrameUsed2(pstRdNode->hVideo);
            Media_VideoDestroyReadHandle2(pstRdNode->hVideo);
            #endif
            pstRdNode->hVideo = MOS_NULL;
        }
        MOS_LIST_RMVALL(&pstRdNode->stCustomList, MOS_TRUE);
        MOS_LIST_RMVNODE(&RdStg_GetMng()->stRdList, pstRdNode);
        MOS_FREE(pstRdNode);
    }
    RdStg_Mp4Muxer_Destory();
    RdStg_Mp4DeMuxer_Destory();
    Mos_MutexDelete(&RdStg_GetMng()->hMutex);
    RdStg_GetMng()->ucInitFlag = 0;
    MOS_LOG_INF(RDSTG_LOGSTR,"record task destory");
    return MOS_OK;
}

// 通过 CamId 查找录像节点
ST_RDSTG_NODE *RdStg_FindNodeByCamId(_INT iCamId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RDSTG_NODE *pstRdNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&RdStg_GetMng()->stRdList, pstRdNode, stIterator)
    {
        if(iCamId == pstRdNode->iCamId)
        {
            return pstRdNode;
        }
    }
    return MOS_NULL;
}

// 查找或者创建录像节点
ST_RDSTG_NODE *RdStg_FindAndCreateNode(_INT iCamId)
{
    ST_RDSTG_NODE *pstRdNode = RdStg_FindNodeByCamId(iCamId);
    if(MOS_NULL != pstRdNode)
    {
        return pstRdNode;
    }
    pstRdNode = (ST_RDSTG_NODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_NODE));
    pstRdNode->ucCamOpenFlag = Config_GetCamaraMng()->uiCamOpenFlag;
    pstRdNode->iCamId        = iCamId;
    pstRdNode->iStreamId = RdStg_GetMng()->ucDefaultStreamID;
    Mos_MutexLock(&RdStg_GetMng()->hMutex);
    MOS_LIST_ADDTAIL(&RdStg_GetMng()->stRdList, pstRdNode);
    Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
    MOS_LOG_INF(RDSTG_LOGSTR,"cam %d create node",iCamId);
    return pstRdNode;
}

// 查找录像定制节点
ST_RDSTG_CUSTOM_NODE *RdStg_FindCustomNode(ST_RDSTG_NODE *pstRdNode, _UC *pucPeerSID)
{
    MOS_PARAM_NULL_RETNULL(pstRdNode);
    MOS_PARAM_NULL_RETNULL(pucPeerSID);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_RDSTG_CUSTOM_NODE *pstCustomNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstRdNode->stCustomList, pstCustomNode, stIterator)
    {
       if(pstCustomNode->ucIsUsing && MOS_STRCMP(pucPeerSID,pstCustomNode->aucPeerSID) == 0)
        {
            return pstCustomNode;
        }
    }
    return NULL;
}

// 查找或者创建录像定制节点
ST_RDSTG_CUSTOM_NODE *RdStg_FindAndCreatCustomNode(ST_RDSTG_NODE *pstRdNode, _UC *pucPeerSID,_UI *puiCreatFlag)
{
    MOS_PARAM_NULL_RETNULL(pstRdNode);
    MOS_PARAM_NULL_RETNULL(pucPeerSID);
    MOS_PARAM_NULL_RETNULL(puiCreatFlag);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_RDSTG_CUSTOM_NODE *pstCustomNode    = MOS_NULL;
    ST_RDSTG_CUSTOM_NODE *pstCustomTmpNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstRdNode->stCustomList, pstCustomNode, stIterator)
    {
        if(pstCustomNode->ucIsUsing && MOS_STRCMP(pucPeerSID,pstCustomNode->aucPeerSID) == 0)
        {
            return pstCustomNode;
        }
        else if(pstCustomNode->ucIsUsing == 0)
        {
            pstCustomTmpNode = pstCustomNode;
        }
    }
    if(pstCustomTmpNode == MOS_NULL)
    {
        pstCustomTmpNode = (ST_RDSTG_CUSTOM_NODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_CUSTOM_NODE));
        MOS_LIST_ADDTAIL(&pstRdNode->stCustomList, pstCustomTmpNode);
    }
    if(puiCreatFlag)
    {
        *puiCreatFlag = 1;
    }
    MOS_STRNCPY(pstCustomTmpNode->aucPeerSID, pucPeerSID, sizeof(pstCustomTmpNode->aucPeerSID));
    pstCustomTmpNode->ucIsUsing = 1;
    return pstCustomTmpNode;
}

// 重置 iCamId  iStreamId通道
_INT RdStg_ResetStreamId(_INT iCamId, _INT iStreamId)
{
    ST_RDSTG_NODE *pstNode = RdStg_FindAndCreateNode(iCamId);
    if(NULL == pstNode){
        MOS_LOG_ERR(RDSTG_LOGSTR,"cam %d malloc fail",iCamId);
        return MOS_ERR_NOMEM;
    }
    if((_UI)iStreamId >= Config_GetCamaraMng()->uiStreamCnt)
    {
        iStreamId = Config_GetCamaraMng()->uiStreamCnt - 1;
    }
    if((iStreamId != pstNode->iStreamId) && (pstNode->hVideo))
    {
        pstNode->ucStreamFlag = 1;
    }
    pstNode->iStreamId = iStreamId;
    MOS_LOG_INF(RDSTG_LOGSTR,"cam %d reset stream id %d, max:%d",iCamId,iStreamId, Config_GetCamaraMng()->uiStreamCnt);
    return MOS_OK;
}

// 报警触发录像
_INT RdStg_CreateEvent(_INT iCamId, _INT iDuration, _CTIME_T cNowTime)
{
    _CTIME_T cToTime;
    // 查询录像节点 iCamId
    ST_RDSTG_NODE *pstNode = RdStg_FindAndCreateNode(iCamId);
    if(NULL == pstNode){
        MOS_LOG_ERR(RDSTG_LOGSTR,"cam %d malloc fail",iCamId);
        return MOS_ERR_NOMEM;
    }
    
    // 当录像节点没有处于运行状态和没有启动全天候录像时
    if(pstNode->ucStatus != EN_RDSTG_STATUS_RUN && pstNode->ucAllDayRecordFlag == 0)
    {
        // 修改报警录像的时间点
        pstNode->cEventTime = cNowTime;
    }
    // 报警录像结束时间
    cToTime = cNowTime + iDuration;

    if(pstNode->cRecordToTime < cToTime)
    {
        pstNode->cRecordToTime = cToTime;
    }

    pstNode->ucWakeUp = 1;
    // MOS_LOG_INF(RDSTG_LOGSTR,"cam %d creat event duration %d",iCamId,iDuration);
    return MOS_OK;
}

// 启动录像定制
_INT RdStg_StartCustom(_UC *pucPeerSID, _INT iCamId)
{
    MOS_PARAM_NULL_RETERR(pucPeerSID);

    _UI uiCreatFlag = 0;
    ST_RDSTG_CUSTOM_NODE *pstCustom = MOS_NULL;
    ST_RDSTG_NODE *pstNode = RdStg_FindAndCreateNode(iCamId);
    if(NULL == pstNode){
        MOS_LOG_ERR(RDSTG_LOGSTR,"cam %d malloc fail",iCamId);
        return MOS_ERR_NOMEM;
    }
    Mos_MutexLock(&RdStg_GetMng()->hMutex);
    pstCustom = RdStg_FindAndCreatCustomNode(pstNode,pucPeerSID,&uiCreatFlag);
    if(uiCreatFlag == 1)
    {
        pstNode->uiCustomNodeNum++;
    }
    Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
    pstNode->ucWakeUp = 1;
    MOS_LOG_INF(RDSTG_LOGSTR,"cam %d peerid %s,start custom record node num %u",iCamId,pucPeerSID,pstNode->uiCustomNodeNum);
    return MOS_OK;
}

// 停止录像定制
_INT RdStg_StopCustom(_UC *pucPeerSID, _INT iCamId)
{
    MOS_PARAM_NULL_RETERR(pucPeerSID);

    ST_RDSTG_CUSTOM_NODE *pstCustom = MOS_NULL;
    ST_RDSTG_NODE *pstNode = RdStg_FindNodeByCamId(iCamId);
    if(NULL == pstNode){
        MOS_LOG_ERR(RDSTG_LOGSTR,"cam %d not start custom record", iCamId);
        return MOS_ERR_PARAM;
    }
    pstNode->cEventTime = 0;
    Mos_MutexLock(&RdStg_GetMng()->hMutex);
    pstCustom = RdStg_FindCustomNode(pstNode, pucPeerSID);
    if(NULL != pstCustom){ 
        pstNode->uiCustomNodeNum--;
        pstCustom->ucIsUsing = 0;
    }
    Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
    MOS_LOG_WARN(RDSTG_LOGSTR,"cam %d peerid %s,stop custom record nodeNum %d",iCamId, pucPeerSID,pstNode->uiCustomNodeNum);
    return MOS_OK;
}

// 设置全天录像标志
_INT RdStg_SetAllDayRecordFlag(_INT iCamId, _UC ucAllDayFlag)
{
    ST_RDSTG_NODE *pstNode = RdStg_FindAndCreateNode(iCamId);
    pstNode->ucAllDayRecordFlag = ucAllDayFlag;
    pstNode->ucWakeUp = 1;
    MOS_LOG_INF(RDSTG_LOGSTR,"cam %d set all day record flag %u",iCamId,ucAllDayFlag);
    return MOS_OK;
}

// 设置打开摄像头的标志
_INT RdStg_SetCamOpenFlag(_INT iCamId,_INT iOpenFlag)
{
    ST_RDSTG_NODE *pstNode = RdStg_FindAndCreateNode(iCamId);
    pstNode->ucCamOpenFlag = iOpenFlag;
    MOS_LOG_INF(RDSTG_LOGSTR,"cam %d set openFlag %u",iCamId,iOpenFlag);
    return MOS_OK;
}

//  更新filedes.txt文件
_INT RdStg_UpdateFileDes(_INT iCamId,_UC *paucDate,ST_RDSTG_FILEDES *pstFileDes)
{
    MOS_PARAM_NULL_RETERR(paucDate);
    MOS_PARAM_NULL_RETERR(pstFileDes);

    _UC aucBuff[32]; 
    _UC aucFileName[256];
    _HFILE hFile = MOS_NULL;
    ST_RDSTG_FILEDES stFileDes;
    _INT iOffSet = sizeof(ST_RDSTG_FILEDES);
    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0)
    {
        return MOS_ERR;
    }
    MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,iCamId,paucDate,RDSTG_FILEDESCFG_NAME);
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_RDWR | MOS_FILE_O_BIN);
    if(hFile == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"cam %d open file %s errno %d",iCamId,aucFileName,errno);
        return MOS_ERR;
    } 
    if(16 != Mos_FileRead(hFile,aucBuff, 16)){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        return MOS_ERR;
    }
    if(MOS_STRNCMP(aucBuff, RDSTG_FILEDESCFG_VERSION,MOS_STRLEN(RDSTG_FILEDESCFG_VERSION)) != 0)
    {
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        return MOS_ERR;
    }
    if(Mos_FileSize(hFile) < iOffSet + MOS_STRLEN(RDSTG_FILEDESCFG_VERSION))
    {
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        return MOS_ERR;
    }
    iOffSet = -iOffSet;
    Mos_FileSeek(hFile, MOS_FILE_SEEK_END, iOffSet);
    Mos_FileRead(hFile,(_UC*)&stFileDes, sizeof(ST_RDSTG_FILEDES));
    if(pstFileDes->uiFileSeq != stFileDes.uiFileSeq)
    {
        Mos_FileClose(hFile);
        MOS_LOG_ERR(RDSTG_LOGSTR,"update filedes err file id %u update id %u",stFileDes.uiFileSeq ,pstFileDes->uiFileSeq);
        return MOS_ERR;
    }
    Mos_FileSeek(hFile, MOS_FILE_SEEK_END, iOffSet);
    Mos_FileWrite(hFile,(_UC*)pstFileDes, sizeof(ST_RDSTG_FILEDES));
    Mos_FileClose(hFile);
    return MOS_OK;
}

// 强制的话，只要报错了，说明正在写的的，以及已经写入的数据都不可靠。
// 录像节点停止
static _INT RdStg_NodeStop(ST_RDSTG_NODE *pstNode, _UC ucIsForce)
{
    MOS_PARAM_NULL_RETERR(pstNode);

    _INT iRet                         = 0;
    pstNode->cEventTime               = 0;
    pstNode->stFileDes.ucBCover       = 0;
    pstNode->stFileDes.cStopTime      = Mos_Time();
    pstNode->stFileDes.uiEndTimeStamp = Mos_Time();
    // pstNode->stFileDes.uiEndTimeStamp = pstNode->uiVTimeStamp;

    if(pstNode->hAudio)
    {
        // 关闭音频取流句柄
        #if 0
        Media_AudioDestroyReadHandle(pstNode->hAudio);
        #else
        Media_AudioSetFrameUsed2(pstNode->hAudio);
        Media_AudioDestroyReadHandle2(pstNode->hAudio);
        #endif
        pstNode->hAudio = MOS_NULL;
    }
    if(pstNode->hVideo)
    {
        // 关闭视频取流句柄
        #if 0
        Media_VideoDestroyReadHandle(pstNode->hVideo);
        #else
        Media_VideoSetFrameUsed2(pstNode->hVideo);
        Media_VideoDestroyReadHandle2(pstNode->hVideo);
        #endif
        pstNode->hVideo = MOS_NULL;
    }
 
    if(pstNode->hMp4File)
    {
        // 关闭录像文件
        iRet = RdStg_Mp4Muxer_CloseFile(pstNode->hMp4File, 0);
        pstNode->hMp4File = MOS_NULL;
        MOS_LOG_INF(RDSTG_LOGSTR,"camid %d file close iRet %d",pstNode->iCamId,iRet);
    }

#ifdef USER_RD_EXTERN_FILEDES
    // 获取音视频参数
    g_pstRdAudioParam = RdStg_GetCurRecordAudioParam();
    g_pstRdVideoParam = RdStg_GetCurRecordVideoParam();
    pstNode->stFileDes.uiStreamId       = pstNode->iStreamId;
    pstNode->stFileDes.uiAudioEncType   = g_pstRdAudioParam->uiEncodeType;
    pstNode->stFileDes.uiVideoEncType   = g_pstRdVideoParam->stVideoPara.uiEncodeType;
    pstNode->stFileDes.uiVideoWidth     = g_pstRdVideoParam->stVideoPara.uiWidth;
    pstNode->stFileDes.uiVideoHeight    = g_pstRdVideoParam->stVideoPara.uiHeight;
    pstNode->stFileDes.uiVideoFrameRate = g_pstRdVideoParam->stVideoPara.uiFramerate;
#endif
    
    // 修复关闭录像失败处理，避免卡回看列表出现异常录像节点
    // 更新filedes.txt文件
    if (iRet < 0)
    {
        // 关闭录象失败，删除录像文件，删除已记录的录像节点
        _UC aucFileName[256] = {0};
        MOS_VSNPRINTF(aucFileName, sizeof(aucFileName),"%s/%d/%s/%d.mp4", Config_GetCoreMng()->aucCachePath, 0, pstNode->aucDay, pstNode->stFileDes.uiFileSeq);
        // MOS_PRINTF("stTmpDes.cStopTime: %u  stTmpDes.uiEndTimeStamp: %u \r\n", stTmpDes.cStopTime, stTmpDes.uiEndTimeStamp);
        MOS_LOG_INF(RDSTG_LOGSTR, "RM Record File aucFileName %s", aucFileName);
        Mos_FileRmv(aucFileName);
        pstNode->stFileDes.ucBInUse = 0;
        iRet = RdStg_UpdateFileDes(pstNode->iCamId, pstNode->aucDay, &pstNode->stFileDes);
    }
    else
    {
        // 关闭录像成功，更新录像节点信息
        iRet = RdStg_UpdateFileDes(pstNode->iCamId, pstNode->aucDay, &pstNode->stFileDes);
    }
    MOS_LOG_INF(RDSTG_LOGSTR, "camid %d channel update fileDes Close %u.mp4 file , iRet: %d", pstNode->iCamId, pstNode->stFileDes.uiFileSeq, iRet);

    return MOS_OK;
}

// 检查文件Des filedes.txt
_VOID RdStg_CheckFileDes(ST_RDSTG_NODE *pstNode,_UC *paucDate)
{
    MOS_PARAM_NULL_NORET(pstNode);
    MOS_PARAM_NULL_NORET(paucDate);

    _HFILE hFile;
    _UI uiDuration = 0,uiEndTimeStamp= 0,iOffSet = 0;
    _INT iRetLen = 0;
    _UC aucBuff[24];
    _UC aucFileName[256];
    ST_RDSTG_FILEDES stFileDes;

    pstNode->uiDataSeq = 0;

    MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,pstNode->iCamId,paucDate,RDSTG_FILEDESCFG_NAME);
    // 打开 filedes.txt
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return;
    }

    // 读取 filedes.txt 头16
    Mos_FileRead(hFile,aucBuff, 16);

    // 判断 RDSTG_FILEDESCFG_VERSION = "0001000100010001"
    if(MOS_STRNCMP(aucBuff, RDSTG_FILEDESCFG_VERSION,MOS_STRLEN(RDSTG_FILEDESCFG_VERSION)) != 0)
    {
        // RDSTG_FILEDESCFG_VERSION不对，删除文件 filedes.txt
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        return;
    }

    // 循环读取 filedes.txt 大小 sizeof(stFileDes) 知道文件结束
    do
    {
        // 读取 filedes.txt
        iRetLen = Mos_FileRead(hFile,(_UC*)&stFileDes,sizeof(stFileDes));

        // 判断标志符 '$'
        if(iRetLen == sizeof(stFileDes) && stFileDes.ucCheck == '$' )
        {
            // 已添加的 ST_RDSTG_FILEDES 覆盖更新
            pstNode->uiDataSeq = stFileDes.uiFileSeq;
            if(stFileDes.cStopTime == 0 && stFileDes.ucBInUse)
            {
                stFileDes.cStopTime = stFileDes.cStartTime + uiDuration/1000;
                stFileDes.uiEndTimeStamp = uiEndTimeStamp;
                iOffSet = Mos_FileTell(hFile);
                if(Mos_FileSeek(hFile, MOS_FILE_SEEK_CUR,-iRetLen) == MOS_OK)
                {
                    Mos_FileWrite(hFile,(_UC*)&stFileDes,iRetLen);
                }
                else
                {
                    MOS_LOG_ERR(RDSTG_LOGSTR,"Mos_FileSeek errno = %u",errno);
                }
                Mos_FileSeek(hFile,MOS_FILE_SEEK_BEGIN,iOffSet);
                break;
            }
        }
        // 未添加 ST_RDSTG_FILEDES 后面追加
        else if(iRetLen > 0 && iRetLen < sizeof(stFileDes))
        {
            stFileDes.ucCheck   = '$';
            stFileDes.ucBInUse  = 0;
            stFileDes.uiFileSeq++;

            iOffSet = Mos_FileTell(hFile) - iRetLen;
            if(Mos_FileSeek(hFile, MOS_FILE_SEEK_CUR,-iRetLen) == MOS_OK)
            {
                Mos_FileWrite(hFile,(_UC*)&stFileDes,sizeof(stFileDes));
            }
            Mos_FileSeek(hFile,MOS_FILE_SEEK_BEGIN,iOffSet + sizeof(stFileDes));
            pstNode->uiDataSeq++;
            MOS_LOG_INF(RDSTG_LOGSTR,"filedes repare ok");
            break;
        }
    }while(Mos_FileEof(hFile) == MOS_FALSE);    // 文件是否结束

    Mos_FileClose(hFile);
    return ;
}

// 添加录像时间 对文件date.txt最后追加写 同时检查更新filedes.txt
_INT RdStg_AddDate(ST_RDSTG_NODE *pstNode, ST_RDSTG_DATE *pstDateInf)
{
    MOS_PARAM_NULL_RETERR(pstNode);
    MOS_PARAM_NULL_RETERR(pstDateInf);

    _UC aucFileName[256];
    _UC aucDirName[256];
    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0)
    {
        return MOS_ERR;
    }
    MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s",RdStg_GetMng()->aucCachePath,pstNode->iCamId,RDSTG_DATECFG_NAME);
    // MOS_LOG_INF(RDSTG_LOGSTR,"aucFileName: %s", aucFileName);

    // 判断date.txt文件是否存在
    if(Mos_FileIsExist(aucFileName) == MOS_FALSE)
    {
        // MOS_LOG_INF(RDSTG_LOGSTR,"GO TO write 0001000100010001 to date.txt");
        // 对文件date.txt最后追加写 0001000100010001 文件的起始头
        Mos_FileWriteAppend(aucFileName,(_UC*)RDSTG_DATECFG_VERSION, MOS_STRLEN(RDSTG_DATECFG_VERSION));
    }

    MOS_VSNPRINTF(aucDirName,255,"%s/%d/%s",RdStg_GetMng()->aucCachePath,pstNode->iCamId,pstDateInf->aucDate);
    MOS_LOG_INF(RDSTG_LOGSTR,"aucDirName: %s", aucDirName); 

    // 创建日期文件
    Mos_DirMake(aucDirName, MOS_DIR_MAKE_FLAG);
    // 检查更新filedes.txt文件
    RdStg_CheckFileDes(pstNode,pstDateInf->aucDate);

    pstDateInf->ucBInUse = 1;
    pstDateInf->ucCheck  = '$';
    // MOS_LOG_INF(RDSTG_LOGSTR,"GO TO write ST_RDSTG_DATE to date.txt Mos_FileWriteAppend"); 
    // 对文件date.txt最后追加写 ST_RDSTG_DATE 结构体 $2020-12-07
    Mos_FileWriteAppend(aucFileName,(_UC*)pstDateInf, sizeof(ST_RDSTG_DATE));
    return MOS_OK;
}

// 检查录像时间
_VOID RdStg_CheckDate(ST_RDSTG_NODE *pstNode)
{
    MOS_PARAM_NULL_NORET(pstNode);

    _UI i = pstNode->iCamId;
    _HDIR hDir;
    _UC aucDirName[256];
    _UC aucEntryName[256];
    ST_MOS_FILE_INF stInf;
    ST_MOS_LIST stList;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RDSTG_DATENODE *pstDateNodeNew = MOS_NULL;
    ST_RDSTG_DATENODE *pstDateNodeTmp = MOS_NULL;

    MOS_VSNPRINTF(aucDirName, 256, "%s/%d",RdStg_GetMng()->aucCachePath,i);
    // MOS_LOG_INF(RDSTG_LOGSTR,"aucDirName:%s ", aucDirName);

    // 打开录像文件夹
    hDir = Mos_DirOpen(aucDirName);
    if(hDir == MOS_NULL)
    {
        MOS_LOG_INF(RDSTG_LOGSTR,"DirOpen %s Failed ,Go to Make", aucDirName);
        Mos_DirMake(aucDirName,MOS_DIR_MAKE_FLAG);
        return;
    }
    MOS_MEMSET(&stList, 0, sizeof(stList));

    // 遍历获取录像文件夹里的文件名，和文件信息 aucEntryName stInf
    while(Mos_DirRead(hDir,aucEntryName,256, &stInf) != MOS_ERR)
    {
        // MOS_LOG_INF(RDSTG_LOGSTR,"Record Dir aucEntryName:%s stInf.ucType:%d", aucEntryName, stInf.ucType);

        // 录像文件夹(名字为具体的日期 如: 2020-12-03)
        if(stInf.ucType == EN_CFILE_DIR)
        {
            pstDateNodeNew = (ST_RDSTG_DATENODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_DATENODE));
            if(pstDateNodeNew == MOS_NULL)
            {
                break;
            }
            // 初始化录像日期的节点
            MOS_STRCPY(pstDateNodeNew->stDate.aucDate,aucEntryName);    // 2020-12-03
            pstDateNodeNew->stDate.ucBInUse = 1;
            pstDateNodeNew->stDate.ucCheck  = '$';  // 日期分隔符

            // 遍历录像日期的链表
            FOR_EACHDATA_INLIST(&stList, pstDateNodeTmp, stIterator)
            {
                // 将日期大到小排列
                if(MOS_STRCMP(pstDateNodeTmp->stDate.aucDate,aucEntryName) > 0)
                {
                    // MOS_LOG_INF(RDSTG_LOGSTR,"Go To MOS_LIST_INSERTPRE");
                    MOS_LIST_INSERTPRE(&stList, pstDateNodeTmp, pstDateNodeNew);
                    break;
                }
            }

            // 若录像日期链表为空，则添加录像日期节点到链表中
            if(pstDateNodeTmp == MOS_NULL)
            {
                // MOS_LOG_INF(RDSTG_LOGSTR,"Go To MOS_LIST_ADDTAIL");
                MOS_LIST_ADDTAIL(&stList, pstDateNodeNew);
            }

            MOS_LOG_INF(RDSTG_LOGSTR,"MOS_LIST_GETCOUNT(&stList) %d ", MOS_LIST_GETCOUNT(&stList));
        }
    }

    // 删除 date.txt 配置文件
    MOS_VSNPRINTF(aucEntryName, 256, "%s/%d/%s",RdStg_GetMng()->aucCachePath,i,RDSTG_DATECFG_NAME);
    // MOS_LOG_INF(RDSTG_LOGSTR,"RM aucEntryName:%s ", aucEntryName);
    Mos_FileRmv(aucEntryName);

    // 遍历录像日期的链表 更新date.txt 配置文件
    FOR_EACHDATA_INLIST(&stList, pstDateNodeTmp, stIterator)
    {
        if(MOS_LIST_GETCOUNT(&stList) == 1)
        {
            // 查询或修改文件
            // MOS_LOG_INF(RDSTG_LOGSTR,"Go To RdStg_FindAndRepairFile %s", pstDateNodeTmp->stDate.aucDate);
            RdStg_FindAndRepairFile(pstDateNodeTmp->stDate.aucDate);
        }

        // 增加录像日期
        // MOS_LOG_INF(RDSTG_LOGSTR,"Go To RdStg_AddDate");
        RdStg_AddDate(pstNode,&pstDateNodeTmp->stDate);
        MOS_LIST_RMVNODE(&stList, pstDateNodeTmp);
        MOS_FREE(pstDateNodeTmp);
    }
    Mos_DirClose(hDir);
    return;
}

// 录像节点初始化 更新date.txt 配置文件
_INT RdStg_NodeInit(ST_RDSTG_NODE *pstNode)
{
    MOS_PARAM_NULL_RETERR(pstNode);

    // 检查录像时间
    RdStg_CheckDate(pstNode);

    // 重置 iCamId  iStreamId通道
    RdStg_ResetStreamId(pstNode->iCamId,Config_GetInIotMng()->stRecordInf.uiStreamerId);

    pstNode->ucStatus = EN_RDSTG_STATUS_IDEL;
    return MOS_OK;
}

// 获取录像文件名
_UI RdStg_GetFileName(ST_RDSTG_NODE *pstNode,_UC *pauDate,_UC aucFileName[256])
{
    MOS_PARAM_NULL_RETERR(pstNode);
    MOS_PARAM_NULL_RETERR(pauDate);

    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0)
    {
        return 0;
    }
    MOS_VSNPRINTF(aucFileName,256, "%s/%u/%s/%u.mp4",RdStg_GetMng()->aucCachePath,pstNode->iCamId,pauDate,++pstNode->uiDataSeq);
    // 记录当前录像文件句柄 即 *.MP4
    RdStg_GetMng()->uiCurrentSeq = pstNode->uiDataSeq;
    return pstNode->uiDataSeq;
}

// 录像节点启动
_INT RdStg_NodeStart(ST_RDSTG_NODE *pstNode, _CTIME_T cNowCTime)
{
    MOS_PARAM_NULL_RETERR(pstNode);

    _INT iRet1      = 0;
    _INT iRet2      = 0;
    _UI  uiFlag     = 0;
    _UI  uiReadType = EN_READ_NEWKEY;
    _UC  aucDay[16] = {0};
    _UC  aucFileName[256]     = {0};
    ST_MOS_SYS_TIME stSysTime = {0};
    ST_CFG_VIDEODES   *pstVideoDes  = MOS_NULL;
    ST_ZJ_AUDIO_PARAM *pstAudioParm = MOS_NULL;
    ST_RDSTG_DATE stRecordDate = {0};

    if (5 == pstNode->uiMp4WriteTimes && cNowCTime < pstNode->cNextTryTime)
    {
        return MOS_ERR;
    }
    else if (5 == pstNode->uiMp4WriteTimes && cNowCTime >= pstNode->cNextTryTime)
    {
        pstNode->uiMp4WriteTimes = 0;
    }

    // 初始换当前录像节点的变量
    pstNode->uiATimeStamp  = 0;
    pstNode->uiVTimeStamp  = 0;
    pstNode->uiWritVCnt    = 0;
    pstNode->uiWritACnt    = 0;
    pstNode->pstAFrameNode = MOS_NULL;
    pstNode->pstVFrameNode = MOS_NULL;
    pstNode->ucFirstRead   = 1; // 获取第一个I帧

    MOS_LOG_INF(RDSTG_LOGSTR,">>>>>>>>>>>>>pstNode->iStreamId:%d", pstNode->iStreamId);
    if (MOS_NULL == pstNode->hAudio)
    {
        // 创建音频读句柄
        #if 0
        pstNode->hAudio = Media_AudioCreatReadHandle(0,uiReadType);
        #else
        MOS_PRINTF("%s %d creat audio hander!!\n", __FUNCTION__, __LINE__);
        pstNode->hAudio = Media_AudioCreatReadHandle2(0, uiReadType, __FUNCTION__);
        #endif
    }
    if (MOS_NULL == pstNode->hVideo)
    {
        // 创建视频读句柄
        #if 0
        pstNode->hVideo = Media_VideoCreatReadHandle(pstNode->iCamId, pstNode->iStreamId,uiReadType, EN_ZJ_KEYFRAME_QUALITY_NORMAL);
        #else
        pstNode->hVideo = Media_VideoCreatReadHandle2(pstNode->iCamId, pstNode->iStreamId, uiReadType, EN_ZJ_KEYFRAME_QUALITY_NORMAL, __FUNCTION__);
        #endif
    }

    // 获取系统时间
    Mos_GetSysTime(&stSysTime);

    MOS_VSNPRINTF(aucDay,16,"%04u-%02u-%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    // MOS_LOG_INF(RDSTG_LOGSTR,"aucDay %s ", aucDay);

    if (MOS_STRCMP(aucDay,pstNode->aucDay) != 0)
    {
        uiFlag = 1;
    }

    MOS_VSNPRINTF(pstNode->aucDay,16, "%04u-%02u-%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    MOS_LOG_INF(RDSTG_LOGSTR,"pstNode->aucDay %s ", pstNode->aucDay);
    MOS_MEMSET(&pstNode->stFileDes, 0, sizeof(pstNode->stFileDes));

    MOS_VSNPRINTF(aucFileName,255,"%s/%d",RdStg_GetMng()->aucCachePath,pstNode->iCamId);
    // MOS_LOG_INF(RDSTG_LOGSTR,"aucDirName %s ", aucFileName);
    // 创建文件夹 */sd/0/
    Mos_DirMake(aucFileName, MOS_DIR_MAKE_FLAG);

    MOS_VSNPRINTF(aucFileName,256, "%s/%u/%s",RdStg_GetMng()->aucCachePath,pstNode->iCamId,pstNode->aucDay);
    MOS_LOG_INF(RDSTG_LOGSTR,"aucFileName %s ", aucFileName);

    // 判断是否存在日期文件夹
    if (Mos_DirIsExist(aucFileName) == MOS_FALSE)
    {
        MOS_STRCPY(stRecordDate.aucDate,pstNode->aucDay);
        // 更新date.txt文件
        RdStg_AddDate(pstNode,&stRecordDate);
    }
    else if (uiFlag == 1)
    {
        // 检查filedes.txt文件
        RdStg_CheckFileDes(pstNode, pstNode->aucDay);
    }

    // 获取当前录像的文件名 *.MP4 aucFileName
    pstNode->stFileDes.uiFileSeq = RdStg_GetFileName(pstNode,pstNode->aucDay,aucFileName);
    // 获取视频参数
    pstVideoDes  = Config_GetVideoDes(pstNode->iCamId,pstNode->iStreamId);
    // 获取音频参数
    pstAudioParm = Config_GetCamAudioParm(0);

    if (pstNode->hMp4File == MOS_NULL)
    {
        // 记录当前录像的MP4文件的信息 返回userid
        pstNode->hMp4File = RdStg_Mp4Muxer_OpenFile(aucFileName,pstVideoDes->stVideoPara.uiEncodeType,pstVideoDes->stVideoPara.uiWidth,pstVideoDes->stVideoPara.uiHeight);
        if(pstNode->hMp4File == MOS_NULL)
        {
            pstNode->uiMp4WriteTimes++;
            if (pstNode->uiMp4WriteTimes == 5)
            {
                pstNode->cNextTryTime = Mos_Time() + RDSTG_DELAY_RETRY_TIME;
                RdStg_GetMng()->ucCbTfCardErrFlag = 1;
            }
            return MOS_ERR;
        }
    }

    if (pstVideoDes || pstAudioParm)
    {
        // 根据userid 记录MP4录像文件的音视频信息
        iRet1 = RdStg_Mp4Muxer_SetAudioType(pstNode->hMp4File,pstAudioParm);
        iRet2 = RdStg_Mp4Muxer_SetCircleInf(pstNode->hMp4File,&pstVideoDes->stCircle);
        if (MOS_ERR == iRet1 || MOS_OK != iRet2)
        {
            pstNode->uiMp4WriteTimes++;
            if(pstNode->uiMp4WriteTimes == 5)
            {
                pstNode->cNextTryTime = Mos_Time() + RDSTG_DELAY_RETRY_TIME;
                RdStg_GetMng()->ucCbTfCardErrFlag = 1;
            }
            return MOS_ERR;
        }
    }

    // 更新当前录像节点的工作状态
    pstNode->ucStatus = EN_RDSTG_STATUS_RUN;

    // 向厂商更新录像状态 厂商设置回调ZJ_SetRecordStatusCB 
    if(ZJ_GetFuncTable()->pfunRecordStatus)
    {
        ZJ_GetFuncTable()->pfunRecordStatus(1);
    }

    // 向InIot更新录像IOT的工作状态
    Config_SetInIotWorkStatus(EN_ZJ_AIIOT_TYPE_RECORD,pstNode->iCamId,1);

    MOS_LOG_INF(RDSTG_LOGSTR,"cam %u record task start ok",pstNode->iCamId);
    return MOS_OK;
}

// 添加录像文件Des
_INT RdStg_AddFileDes(_INT iCamId,_UC *paucDate,ST_RDSTG_FILEDES *pstFileDes)
{
    MOS_PARAM_NULL_RETERR(paucDate);
    MOS_PARAM_NULL_RETERR(pstFileDes);
    _UC aucFileName[256] = {0};

    MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,iCamId,paucDate,RDSTG_FILEDESCFG_NAME);
    MOS_LOG_INF(RDSTG_LOGSTR,"aucFileName:%s", aucFileName);

    // 判断filedes.txt是否存在
    if(Mos_FileIsExist(aucFileName) == MOS_FALSE){
        Mos_FileSave(aucFileName, RDSTG_FILEDESCFG_VERSION, MOS_STRLEN(RDSTG_FILEDESCFG_VERSION));
    }

    // 初始化 ST_RDSTG_FILEDES 结构体
    pstFileDes->ucBCover = 0;
    pstFileDes->ucCheck  = '$';
    pstFileDes->ucBInUse = 1;

    // 文件尾部添加结构体数据
    if(Mos_FileWriteAppend(aucFileName,(_UC*)pstFileDes, sizeof(ST_RDSTG_FILEDES)) == MOS_FALSE){
        MOS_LOG_ERR(RDSTG_LOGSTR,"write file %s fail errno = %u",aucFileName,errno);
        return MOS_ERR;
    }
    return MOS_OK;
}

// 读取ringbuf缓冲区的媒体流数据 一个一个NALU的取
static _INT RdStg_ReadChannelData(ST_RDSTG_NODE *pstNode,_CTIME_T cNowTime)
{
    MOS_PARAM_NULL_RETERR(pstNode);

    _INT iANodeCnt    = 0;
    _LLID  llTimePts  = 0;
    ST_CFG_VIDEODES   *pstRdVideoParam = MOS_NULL;
    ST_ZJ_AUDIO_PARAM *pstRdAudioParam = MOS_NULL;

    //  获取视频的句柄不为空
    if(pstNode->hVideo && pstNode->pstVFrameNode == MOS_NULL)
    {
        // 获取视频数据
        #if 0
        Media_VideoGetFrame(pstNode->hVideo,&pstNode->pstVFrameNode,&pstNode->uiVTimeStamp);
        #else
        Media_VideoGetFrame2(pstNode->hVideo,&pstNode->pstVFrameNode,&pstNode->uiVTimeStamp,&llTimePts);
        #endif
    }
    //  获取音频的句柄不为空
    if(pstNode->hAudio && pstNode->pstAFrameNode == MOS_NULL)
    {
        // 获取音频数据
        #if 0
        iANodeCnt = Media_AudioGetFrame(pstNode->hAudio,&pstNode->pstAFrameNode,&pstNode->uiATimeStamp);
        #else
        iANodeCnt = Media_AudioGetFrame2(pstNode->hAudio,&pstNode->pstAFrameNode,&pstNode->uiATimeStamp);
        #endif
    }

    // 获取音视频失败
    if((pstNode->pstVFrameNode == MOS_NULL && pstNode->pstAFrameNode == MOS_NULL)
        || (pstNode->ucFirstRead && pstNode->pstVFrameNode == MOS_NULL))
    {
        //MOS_LOG_ERR(RDSTG_LOGSTR,"(pstNode->pstVFrameNode == MOS_NULL && pstNode->pstAFrameNode == MOS_NULL)|| (pstNode->ucFirstRead && pstNode->pstVFrameNode == MOS_NULL)");
        return MOS_ERR_TRYAGAIN;
    }

    // 是否该录像节点第一次读取媒体流数据
    if(pstNode->ucFirstRead)
    {
        // pstNode->cEventTime RdStg_CreateEvent赋值 默认为0 触发了报警才会走
        if(pstNode->cEventTime != 0 && cNowTime - pstNode->cEventTime > 0)
        {
            _INT iTime = (_INT)(cNowTime - pstNode->cEventTime);
            pstNode->cRecordToTime += iTime;
            pstNode->cEventTime = 0;
            MOS_LOG_WARN(RDSTG_LOGSTR,"waiting for the first frame is too long %d",iTime);
        }

        //FIXME: add by hejh 2020-12-29
        while (pstNode->pstVFrameNode == MOS_NULL || MD_GETFRAMETYPE(pstNode->pstVFrameNode->ucFramPos) != EN_FRAMETYPE_I)
        {
            Media_VideoSetFrameUsed2(pstNode->hVideo);
            pstNode->pstVFrameNode = MOS_NULL;
            _INT Ret = Media_VideoGetFrame2(pstNode->hVideo,&pstNode->pstVFrameNode,&pstNode->uiVTimeStamp,&llTimePts);
            //if (Ret >0)
            //    MOS_PRINTF("to find I frame>>pstNode->pstVFrameNode:%d pos:%02x, pstNode->uiVTimeStamp:%u\n", pstNode->pstVFrameNode->uiNaluLen, pstNode->pstVFrameNode->ucFramPos, pstNode->uiVTimeStamp);
        }
        MOS_PRINTF("find>>>pstNode->pstVFrameNode:%d pos:%02x, pstNode->uiVTimeStamp:%u\n", pstNode->pstVFrameNode->uiNaluLen, pstNode->pstVFrameNode->ucFramPos, pstNode->uiVTimeStamp);


//        if (pstNode->pstVFrameNode != MOS_NULL)
//        {
//            ST_FRAME_NODE *pstFrameNode = pstNode->pstVFrameNode;
//            int naul_count = 0;
//            while(pstFrameNode != MOS_NULL)
//            {
//                // 获取当前视频流链表的节点数 即NALU数 一般情况下为1
//                MOS_PRINTF(" count:%d naultype:%02x, len:%d, %02x\n", naul_count, pstFrameNode->ucFramPos,
//                           pstFrameNode->uiNaluLen, pstFrameNode->ptDatabuff[4]);
//                pstFrameNode = pstFrameNode->ptnest;
//            }
//        }
        // 音视频时间戳差异时长太大，重新获取音频流
        while(((pstNode->uiATimeStamp < pstNode->uiVTimeStamp )&& (pstNode->uiVTimeStamp > pstNode->uiATimeStamp + 40))  ||
            ((pstNode->uiATimeStamp > pstNode->uiVTimeStamp )&& ((pstNode->uiATimeStamp - pstNode->uiVTimeStamp) >  0XFFFFF)) )
        {
            // 设置取出的音频流已被使用
            #if 0
            Media_AudioSetFrameUsed(pstNode->hAudio);
            #else
            Media_AudioSetFrameUsed2(pstNode->hAudio);
            #endif
            pstNode->pstAFrameNode = MOS_NULL;
            pstNode->uiATimeStamp  = 0;
            // 获取音频数据
            #if 0
            iANodeCnt = Media_AudioGetFrame(pstNode->hAudio,&pstNode->pstAFrameNode,&pstNode->uiATimeStamp);
            #else
            iANodeCnt = Media_AudioGetFrame2(pstNode->hAudio,&pstNode->pstAFrameNode,&pstNode->uiATimeStamp);
            #endif
            if(iANodeCnt <= 0)
                break;
        }
        pstNode->stFileDes.cStartTime       = cNowTime;                    // 记录当前的系统时间戳
        pstNode->stFileDes.uiStartTimeStamp = pstNode->uiVTimeStamp;       // 记录当前的视频时间戳
        MOS_PRINTF("%s %d pstNode->uiVTimeStamp:%u\n", __FUNCTION__, __LINE__, pstNode->uiVTimeStamp);

#ifdef USER_RD_EXTERN_FILEDES
        // 获取视频参数
        pstRdVideoParam = Config_GetVideoDes(pstNode->iCamId, pstNode->iStreamId);
        // 获取音频参数
        pstRdAudioParam = Config_GetCamAudioParm(0);
        pstNode->stFileDes.uiStreamId       = pstNode->iStreamId;
        pstNode->stFileDes.uiAudioEncType   = pstRdAudioParam->uiEncodeType;
        pstNode->stFileDes.uiVideoEncType   = pstRdVideoParam->stVideoPara.uiEncodeType;
        pstNode->stFileDes.uiVideoWidth     = pstRdVideoParam->stVideoPara.uiWidth;
        pstNode->stFileDes.uiVideoHeight    = pstRdVideoParam->stVideoPara.uiHeight;
        pstNode->stFileDes.uiVideoFrameRate = pstRdVideoParam->stVideoPara.uiFramerate;
#endif
        // 追加更新filedes.txt 文件
        RdStg_AddFileDes(pstNode->iCamId,pstNode->aucDay,&pstNode->stFileDes);

        pstNode->ucFirstRead = 0;
        MOS_LOG_INF(RDSTG_LOGSTR,"camid %d find first frame videostamp %u audiostamp %u ",
            pstNode->iCamId,pstNode->uiVTimeStamp,pstNode->uiATimeStamp);
    }
    return MOS_OK;
}

// 处理通道 Slice  检查录像时长是否超出或者录像已跨天 并新建录像文件 --> 功能相当于RdStg_NodeStart
static _VOID RdStg_ProcChannelSlice(ST_RDSTG_NODE *pstNode,_CTIME_T cNowTime)
{
    MOS_PARAM_NULL_NORET(pstNode);

    _UC aucDay[16]                  = {0};
    _UI uiDayChgFlag                =  0;
    _UC aucFileName[256]            = {0};
    _UC aucLogBuf[128]              = {0};
    ST_RDSTG_DATE stRecordData      = {0};
    ST_MOS_SYS_TIME stTmTime        = {0};
    ST_CFG_VIDEODES   *pstVideoDes  = MOS_NULL;
    ST_ZJ_AUDIO_PARAM *pstAudioParm = MOS_NULL;
    _UC *pucStartTime               = MOS_NULL;
    _UC *pucEndTime                 = MOS_NULL;

    ST_RDSTG_FILEDES *pstFileDes  = &pstNode->stFileDes;
    if(Mos_TimetoSysTime(&cNowTime, &stTmTime) == MOS_ERR)
    {
        return ;
    }
    MOS_VSNPRINTF(aucDay,16, "%04u-%02u-%02u",stTmTime.usYear,stTmTime.usMonth,stTmTime.usDay);

    // 录像日期没对上 修改时间或者录像时间跨天
    if(MOS_STRCMP(aucDay, pstNode->aucDay) != 0)
    {
        uiDayChgFlag = 1;
    }

    // 录像时长超过最大时长 10min 或者 录像日期改变
    //MOS_PRINTF("nowtime:%u, startTime:%u, diff:%u\n ", cNowTime,  pstFileDes->cStartTime, (cNowTime - pstFileDes->cStartTime));
    if(MOS_ABS_NUM(cNowTime - pstFileDes->cStartTime) >= RDSTG_FILE_MAX_TIME || uiDayChgFlag == 1)
    {
        MOS_LOG_INF(RDSTG_LOGSTR,"Record Time(%d) is Over than RDSTG_FILE_MAX_TIME(%d) Or Date had changed DayChgFlag(%d)",
                                cNowTime - pstFileDes->cStartTime, RDSTG_FILE_MAX_TIME, uiDayChgFlag);

        // 记录当前录像结束时间 FIXME
        pstFileDes->cStopTime         = cNowTime;
        pstFileDes->uiEndTimeStamp    = cNowTime;
        // pstFileDes->uiEndTimeStamp = RdStg_Mp4Muxer_GetLastTimeStamp(pstNode->hMp4File);

        MOS_LOG_INF(RDSTG_LOGSTR,"StreamId:%d AEncodeType:%d VEncodeType:%d Width:%d Height:%d Framerate:%d", 
                                pstNode->iStreamId, g_pstRdAudioParam->uiEncodeType, g_pstRdVideoParam->stVideoPara.uiEncodeType,
                                g_pstRdVideoParam->stVideoPara.uiWidth, g_pstRdVideoParam->stVideoPara.uiHeight, g_pstRdVideoParam->stVideoPara.uiFramerate);

#ifdef USER_RD_EXTERN_FILEDES
        pstFileDes->uiStreamId       = pstNode->iStreamId;
        pstFileDes->uiAudioEncType   = g_pstRdAudioParam->uiEncodeType;
        pstFileDes->uiVideoEncType   = g_pstRdVideoParam->stVideoPara.uiEncodeType;
        pstFileDes->uiVideoWidth     = g_pstRdVideoParam->stVideoPara.uiWidth;
        pstFileDes->uiVideoHeight    = g_pstRdVideoParam->stVideoPara.uiHeight;
        pstFileDes->uiVideoFrameRate = g_pstRdVideoParam->stVideoPara.uiFramerate;
#endif

        // 更新filedes.txt文件
        RdStg_UpdateFileDes(pstNode->iCamId,pstNode->aucDay,pstFileDes);

        // 关闭录像文件 pstMp4muxer->uiVideoFps
        RdStg_Mp4Muxer_CloseFile(pstNode->hMp4File, 0);//g_pstRdVideoParam->stVideoPara.uiFramerate);

        MOS_LOG_INF(RDSTG_LOGSTR,"Record %d.MP4 END", pstFileDes->uiFileSeq);

        pucStartTime = Mos_PrintTime(pstFileDes->cStartTime);
        pucEndTime   = Mos_PrintTime(pstFileDes->cStopTime);
        MOS_MEMSET(aucLogBuf, 0, sizeof(aucLogBuf));
        MOS_SPRINTF(aucLogBuf, "Successfully save a mp4 file, start time: %s, end time: %s", pucStartTime, pucEndTime);
        CloudStg_UploadLogEx2(RDSTG_LOGSTR_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_RDSTG_RT_SAVE_MP4, aucLogBuf,MOS_NULL, 1);
        MOS_FREE(pucStartTime);
        MOS_FREE(pucEndTime);

        if(pstNode->uiWritACnt == 0)
        {
            // 关闭取音频流的句柄
            #if 0
            Media_AudioDestroyReadHandle(pstNode->hAudio);
            #else
            Media_AudioSetFrameUsed2(pstNode->hAudio);
            Media_AudioDestroyReadHandle2(pstNode->hAudio);
            #endif
            // 新建音频取流的句柄
            #if 0
            pstNode->hAudio = Media_AudioCreatReadHandle(0,EN_READ_COMMON);
            #else
            MOS_PRINTF("%s %d creat audio hander!!\n", __FUNCTION__, __LINE__);
            pstNode->hAudio = Media_AudioCreatReadHandle2(0, EN_READ_COMMON, __FUNCTION__);
            #endif
        }

        // 录像跨天
        if(uiDayChgFlag == 1){
            // 更新date.txt文件
            MOS_MEMSET(&stRecordData, 0, sizeof(stRecordData));
            MOS_STRCPY(stRecordData.aucDate, aucDay);
            RdStg_AddDate(pstNode,&stRecordData);
            MOS_LOG_INF(RDSTG_LOGSTR,"date switch to %s",aucDay);
        }

        MOS_STRCPY(pstNode->aucDay, aucDay);
        MOS_MEMSET(pstFileDes, 0, sizeof(pstNode->stFileDes));
        // 获取新录像得到文件名 *.MP4
        pstFileDes->uiFileSeq = RdStg_GetFileName(pstNode,pstNode->aucDay,aucFileName);
        // 获取视频参数
        pstVideoDes  = Config_GetVideoDes(pstNode->iCamId,pstNode->iStreamId);
        // 获取音频参数
        pstAudioParm = Config_GetCamAudioParm(0);
        // 记录当前录像的MP4文件的信息 返回userid
        pstNode->hMp4File = RdStg_Mp4Muxer_OpenFile(aucFileName,pstVideoDes->stVideoPara.uiEncodeType,pstVideoDes->stVideoPara.uiWidth,pstVideoDes->stVideoPara.uiHeight);
        if(pstNode->hMp4File == MOS_NULL)
        {
            return ;
        }

        if(pstVideoDes || pstAudioParm)
        {
            // 根据userid 记录MP4录像文件的音视频信息
            RdStg_Mp4Muxer_SetAudioType(pstNode->hMp4File,pstAudioParm);
            RdStg_Mp4Muxer_SetCircleInf(pstNode->hMp4File,&pstVideoDes->stCircle);
        }

        // 添加ST_RDSTG_FILEDES 到 filedes.txt文件
        pstFileDes->cStartTime              = cNowTime;
        pstFileDes->uiStartTimeStamp        = pstNode->uiVTimeStamp;
#ifdef USER_RD_EXTERN_FILEDES
        pstNode->stFileDes.uiStreamId       = pstNode->iStreamId;
        pstNode->stFileDes.uiAudioEncType   = pstAudioParm->uiEncodeType;
        pstNode->stFileDes.uiVideoEncType   = pstVideoDes->stVideoPara.uiEncodeType;
        pstNode->stFileDes.uiVideoWidth     = pstVideoDes->stVideoPara.uiWidth;
        pstNode->stFileDes.uiVideoHeight    = pstVideoDes->stVideoPara.uiHeight;
        pstNode->stFileDes.uiVideoFrameRate = pstVideoDes->stVideoPara.uiFramerate;
#endif
        RdStg_AddFileDes(pstNode->iCamId,pstNode->aucDay,pstFileDes);

        // 将当前录像文件的错误次数清零
        pstNode->uiMp4WriteTimes = 0;

        MOS_LOG_INF(RDSTG_LOGSTR,"Record %d.MP4 START", pstFileDes->uiFileSeq);
    }
    return ;
}

//  将ringbuf取出来的媒体流数据写到MP4文件 一个NALU的写
static _INT RdStg_WriteChannelData(ST_RDSTG_NODE *pstNode)
{
    MOS_PARAM_NULL_RETERR(pstNode);

    _INT iWriteLen = 0;
    _INT iRetLen = 0;
    _UI uiNalNum = 0;
    _UI uiListCnt = 0;

    // 写视频数据
    if(pstNode->pstVFrameNode != MOS_NULL)
    {
        ST_FRAME_NODE *pstFrameNode = pstNode->pstVFrameNode;

        while(pstFrameNode != MOS_NULL)
        {
            // 获取当前视频流链表的节点数 即NALU数 一般情况下为1
            uiListCnt++;
            pstFrameNode = pstFrameNode->ptnest;
        }

        // 将视频数据写到MP4文件
        iRetLen = RdStg_Mp4Muxer_VFNWrite(pstNode->hMp4File,pstNode->hVideo,pstNode->pstVFrameNode,uiListCnt,pstNode->uiVTimeStamp);
        if(iRetLen <= 0)
        {
            // 写视频数据失败
            pstNode->uiMp4WriteTimes++;
            MOS_LOG_INF(RDSTG_LOGSTR,"VIDEO pstNode->uiMp4WriteTimes:%d, uiListCnt:%d", pstNode->uiMp4WriteTimes, uiListCnt);
            if(pstNode->uiMp4WriteTimes == 5)
            {
                pstNode->cNextTryTime = Mos_Time() + RDSTG_DELAY_RETRY_TIME;
            }
            return MOS_ERR;
        } 
        else // 写视频数据成功
        {
            // 设置当前的视频数据已消费
            #if 0
            Media_VideoSetFrameUsed(pstNode->hVideo);
            #else
            if (pstNode->pstVFrameNode != MOS_NULL)
                Media_VideoSetFrameUsed2(pstNode->hVideo);
            #endif
            pstNode->uiWritVCnt++;
            pstNode->pstVFrameNode = MOS_NULL;
        }
        iWriteLen += iRetLen;
        uiListCnt = 0;
    }

    // 写音频数据
    if(pstNode->pstAFrameNode != MOS_NULL)
    {
        ST_FRAME_NODE *pstFrameNode = pstNode->pstAFrameNode;
        while(pstFrameNode != MOS_NULL)
        {
            // 获取当前音频流链表的节点数 即帧数
            uiListCnt++;
            pstFrameNode = pstFrameNode->ptnest;
        }

        // 将音频数据写到MP4文件
        iRetLen = RdStg_Mp4Muxer_AFNWrite(pstNode->hMp4File,pstNode->pstAFrameNode,uiListCnt,pstNode->uiATimeStamp);
        if(iRetLen <= 0)
        {
            // 写音频数据失败
            pstNode->uiMp4WriteTimes++;
            MOS_LOG_INF(RDSTG_LOGSTR,"AUDIO pstNode->uiMp4WriteTimes:%d", pstNode->uiMp4WriteTimes);
            if(pstNode->uiMp4WriteTimes == 5)
            {
                pstNode->cNextTryTime=Mos_Time()+RDSTG_DELAY_RETRY_TIME;
            }
            return MOS_ERR;
        } 
        else // 写音频数据成功
        {
            // 设置当前的音频数据已消费
            #if 0
            Media_AudioSetFrameUsed(pstNode->hAudio);
            #else
            Media_AudioSetFrameUsed2(pstNode->hAudio);
            #endif
            pstNode->uiWritACnt++;
            pstNode->pstAFrameNode = MOS_NULL;
        }
        iWriteLen += iRetLen;
    }
    return iWriteLen;
}

// 录像节点进行中(录像操作)
_INT RdStg_NodeRuning(ST_RDSTG_NODE *pstNode, _CTIME_T cNowTime)
{
    MOS_PARAM_NULL_RETERR(pstNode);

    _INT iRetLen   = 0;
    _INT iWriteLen = 0;
    ST_CFG_VIDEODES   *pstVideoDes  = MOS_NULL;
    ST_ZJ_AUDIO_PARAM *pstAudioParm = MOS_NULL;

    RdStg_SetCurRecordAudioParam();
    RdStg_SetCurRecordVideoParam(pstNode->iCamId,pstNode->iStreamId);

    while(RdStg_GetMng()->ucInitFlag)
    {
        if((0 == pstNode->uiMp4WriteTimes) && pstNode->ucStreamFlag)
        {
            pstNode->ucStatus = EN_RDSTG_STATUS_STOP;
            pstNode->ucStreamFlag = 0;
            MOS_LOG_INF(RDSTG_LOGSTR,"record turn to stop ");
            break;
        }

        // 获取ringbuf缓冲区的媒体流数据
        if(RdStg_ReadChannelData(pstNode,cNowTime) != MOS_OK)
        {
            // MOS_LOG_ERR(RDSTG_LOGSTR,"Read RingBuf Failed ");
            break;
        }

        // 获取音视频参数
        pstAudioParm = Config_GetCamAudioParm(0);
        pstVideoDes  = Config_GetVideoDes(pstNode->iCamId,pstNode->iStreamId);

        // I帧 或者 切换分辨率 才做的判断
        if( (0 == pstNode->uiTryTimes) && (pstNode->pstVFrameNode != MOS_NULL)      &&
            ((MD_GETFRAMETYPE(pstNode->pstVFrameNode->ucFramPos) == EN_FRAMETYPE_I) ||
              (g_pstRdAudioParam->uiEncodeType              != pstAudioParm->uiEncodeType)             ||
              (g_pstRdVideoParam->stVideoPara.uiEncodeType  != pstVideoDes->stVideoPara.uiEncodeType)  ||
              (g_pstRdVideoParam->stVideoPara.uiWidth       != pstVideoDes->stVideoPara.uiWidth)       ||
              (g_pstRdVideoParam->stVideoPara.uiHeight      != pstVideoDes->stVideoPara.uiHeight)      ||
              (g_pstRdVideoParam->stVideoPara.uiFramerate   != pstVideoDes->stVideoPara.uiFramerate)   ||
              pstNode->pstVFrameNode->ucVideoResolutionChangeFlag ) )
        {
            // 检查录像时长是否超出或者录像已跨天 并新建录像文件 --> 功能相当于RdStg_NodeStart
            RdStg_ProcChannelSlice(pstNode,cNowTime);
            pstNode->uiWritVCnt = 0;
            pstNode->uiWritACnt = 0;
        }

        if (pstNode->pstVFrameNode && (pstNode->pstVFrameNode->ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_RES || pstNode->pstVFrameNode->ucVideoResolutionChangeFlag == 2))
        {        
            MOS_PRINTF("record turn to stop for change encodeparam\n");
            /*RdStg_ProcChannelSlice(pstNode,cNowTime);
            pstNode->uiWritVCnt = 0;
            pstNode->uiWritACnt = 0;*/
            RdStg_GetMng()->ucCbTfCardErrFlag = 1;
            // 停止当前录像
            pstNode->ucStatus = EN_RDSTG_STATUS_STOP;
            break;
        }

        // 将ringbuf取出来的媒体流数据写到MP4文件 一个NULA的写
        iRetLen = RdStg_WriteChannelData(pstNode);
        if(iRetLen > 0)
        {
            // 写流成功
            iWriteLen += iRetLen;

            RdStg_SetCurRecordAudioParam();
            RdStg_SetCurRecordVideoParam(pstNode->iCamId, pstNode->iStreamId);
            #if 0   // FIXME
            // 记录当前录像结束时间
            pstNode->stFileDes.cStopTime      = cNowTime;
            pstNode->stFileDes.uiEndTimeStamp = RdStg_Mp4Muxer_GetLastTimeStamp(pstNode->hMp4File);
            #endif
            // 更新filedes.txt文件
            // RdStg_UpdateFileDes(pstNode->iCamId,pstNode->aucDay,&pstNode->stFileDes);
        }
        else if(iRetLen < 0)
        {
            // 写流失败
            if(5 == pstNode->uiMp4WriteTimes)
            {
                RdStg_GetMng()->ucCbTfCardErrFlag = 1;
                // 停止当前录像
                pstNode->ucStatus = EN_RDSTG_STATUS_STOP;
            }
            break;
        }
    }

    return iWriteLen;
}

// 删除录像Day
_INT RdStg_DeleteDay(_INT iCamId, _UC *pucDay)
{
    MOS_PARAM_NULL_RETERR(pucDay);

    _INT iSise = 0;
    _UC aucFileName[256];
    _UC aucVersion[24];
    _HFILE hFile = MOS_NULL;
    ST_RDSTG_DATE  stDate;

    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0)
    {
        return 0;
    }
    MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s",RdStg_GetMng()->aucCachePath,iCamId,RDSTG_DATECFG_NAME);
    hFile = Mos_FileOpen(aucFileName, MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return MOS_OK;
    }
    Mos_FileRead(hFile, aucVersion, 16);
    if(MOS_STRNCMP(aucVersion, RDSTG_DATECFG_VERSION,16) != 0)
    {
        Mos_FileClose(hFile);
        return MOS_OK;
    }
    iSise = sizeof(stDate);
    do
    {
        Mos_FileRead(hFile,(_UC*)&stDate, iSise);
        if(stDate.ucCheck == '$' && MOS_STRCMP(stDate.aucDate,pucDay) == 0 && stDate.ucBInUse == 1)
        {
            MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s",RdStg_GetMng()->aucCachePath,iCamId,stDate.aucDate);
            MOS_LOG_INF(RDSTG_LOGSTR,"Rd rmv Dir %s  ",aucFileName);
            Mos_DirRecurRmv(aucFileName);
            stDate.ucBInUse = 0;
            iSise = -iSise;
            Mos_FileSeek( hFile,MOS_FILE_SEEK_CUR, iSise);
            Mos_FileWrite(hFile, (_UC*)&stDate, sizeof(stDate));
            break;  
        }
    }while(Mos_FileEof(hFile) == MOS_FALSE);

    Mos_FileClose(hFile);

    return MOS_OK;
}

// 删除录像文件
_UI RdStg_DeleteFile(_INT iCamId,_UC *pucDay,_UI uiDeletSize)
{
    MOS_PARAM_NULL_RETERR(pucDay);

    _INT iLen                   =  0;
    _INT iOffSet                =  0;
    _UI  uiHaveDelSize          =  0;
    _UC  aucBuff[24]            = {0};
    _UC  aucMapDes[256]         = {0};
    _UC  aucFileName[256]       = {0};
    ST_RDSTG_FILEDES   stFileDes   = {0};
    ST_MOS_FILE_INF stFileInf   = {0};
    ST_MOS_SYS_TIME stSysTime   = {0};
    _HFILE hFile                = MOS_NULL;

    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0){
        return 0;
    }

    MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath, iCamId,pucDay,RDSTG_FILEDESCFG_NAME);
    MOS_VSNPRINTF(aucMapDes, 256, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath, iCamId,pucDay,RDSTG_MAPPING_NAME);
    // 打开 filedes.txt
    hFile = Mos_FileOpen(aucFileName, MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL){
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s",RdStg_GetMng()->aucCachePath,iCamId,pucDay);
        Mos_DirRecurRmv(aucFileName);
        RdStg_DeleteDay(iCamId,pucDay);
        return 0;
    }
    Mos_FileRead(hFile, aucBuff, 16);
    if(MOS_STRNCMP(aucBuff, RDSTG_FILEDESCFG_VERSION,16) != 0){
        Mos_FileClose(hFile);
        MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s",RdStg_GetMng()->aucCachePath,iCamId,pucDay);
        Mos_DirRecurRmv(aucFileName);
        RdStg_DeleteDay(iCamId,pucDay);
        MOS_LOG_ERR(RDSTG_LOGSTR,"file %s version err so remove",aucFileName);
        return 0;
    }
    iLen = sizeof(stFileDes);
    do{
        if(Mos_FileRead(hFile,(_UC*) &stFileDes,iLen) < iLen){
            break;
        }
        if(stFileDes.ucRsv == 1){
            RdStg_FindMappingFile(aucMapDes,aucFileName,stFileDes.uiFileSeq);
        }else{
            MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s/%d.mp4",RdStg_GetMng()->aucCachePath,iCamId,pucDay,stFileDes.uiFileSeq);
        }
        if(RdStg_Mp4Muxer_GetWriterByName(aucFileName,MOS_NULL) != 0){
            break;
        }
        MOS_MEMSET(&stFileInf,0,sizeof(stFileInf));
        if(Mos_FileStat(aucFileName,&stFileInf) == MOS_OK){
            uiHaveDelSize += stFileInf.uiSize;
            MOS_LOG_INF(RDSTG_LOGSTR,"rmv file %s  uiHaveDelSize:%u uiDeletSize:%u",aucFileName, uiHaveDelSize, uiDeletSize);
            Mos_FileRmv(aucFileName);
        }
        if(stFileDes.ucBInUse != 0){
            iOffSet = Mos_FileTell(hFile);
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR, -iLen);
            stFileDes.ucBInUse = 0;
            Mos_FileWrite(hFile,(_UC*) &stFileDes, iLen);
            Mos_FileSeek(hFile,MOS_FILE_SEEK_BEGIN, iOffSet);
        }

    }while(Mos_FileEof(hFile) == MOS_FALSE && uiHaveDelSize < uiDeletSize);

    Mos_FileClose(hFile);

    if(uiHaveDelSize < uiDeletSize){
        Mos_GetSysTime(&stSysTime);
        MOS_VSNPRINTF(aucBuff,24, "%04u-%02u-%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
        if(MOS_STRCMP(pucDay,aucBuff ) != 0){
            RdStg_DeleteDay(iCamId,pucDay);
        }
    }
    return uiHaveDelSize;
}

// ST_MEDIA_DATENODE 获取数据流的节点
ST_MOS_LIST *RdStg_GetDateList(_INT iCamId)
{
    _HFILE hFile = MOS_NULL;
    _INT iRetLen = 0;
    _UC aucFileName[256];
    _UC aucVersion[24];
    ST_MOS_LIST *pstList = MOS_NULL;
    ST_RDSTG_DATE  stDate;
    ST_RDSTG_DATENODE *pstDateNode = MOS_NULL;

    MOS_LOG_INF(RDSTG_LOGSTR,"cam %d get date list",iCamId);
    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0){
        return MOS_NULL;
    }
    MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s",RdStg_GetMng()->aucCachePath, iCamId, RDSTG_DATECFG_NAME);
    hFile = Mos_FileOpen(aucFileName, MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL){
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return MOS_NULL;
    }
    Mos_FileRead(hFile, aucVersion, 16);
    if(MOS_STRNCMP(aucVersion, RDSTG_DATECFG_VERSION,MOS_STRLEN(RDSTG_DATECFG_VERSION)) != 0){
        Mos_FileClose(hFile);
        return MOS_NULL;
    }
    do{
        iRetLen = Mos_FileRead(hFile,(_UC*)&stDate, sizeof(stDate));
        if(iRetLen == sizeof(stDate) && stDate.ucBInUse == 1 && stDate.ucCheck == '$'){
            if(pstList == MOS_NULL){
                pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
                if(pstList == MOS_NULL){
                    break;
                }
            }
            pstDateNode = (ST_RDSTG_DATENODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_DATENODE));
            if(pstDateNode != MOS_NULL){  
                MOS_MEMCPY(&pstDateNode->stDate,&stDate, sizeof(stDate));
                MOS_LIST_ADDTAIL(pstList, pstDateNode);
            }
        }
    }while(Mos_FileEof(hFile) == MOS_FALSE);
    Mos_FileClose(hFile);
    return pstList;
}

// 释放数据流节点
_VOID RdStg_FreeList(ST_MOS_LIST *pstDataList)
{
    MOS_PARAM_NULL_NORET(pstDataList);

    MOS_LIST_RMVALL(pstDataList, MOS_TRUE);
    MOS_FREE(pstDataList);
    return ;
}

// 自动删除文件 向localIO注册的AutoDelete
_INT RdStg_IoAutoDelete()
{
    _INT iDelFileSize = 0;

    if (Config_GetInIotMng()->stRecordInf.uiloopFlag == 1) // 循环录像
    {
        _UI i;
        ST_RDSTG_DATENODE *pstDateNode = MOS_NULL;

        for(i = 0 ; i < RdStg_GetMng()->uiMaxCamCnt; i++ )
        {
            ST_MOS_LIST *pstList =  RdStg_GetDateList(i);
            if(pstList == MOS_NULL)
            {
                continue;
            }

            pstDateNode = (ST_RDSTG_DATENODE *)MOS_LIST_GETHEAD(pstList);
            if(pstDateNode)
            {
                iDelFileSize += RdStg_DeleteFile(i,pstDateNode->stDate.aucDate, 40*1024*1024);
            }

            RdStg_FreeList(pstList);
        }

        MOS_LOG_INF(RDSTG_LOGSTR,"Rd LoopRecord auto delete OK");
    }
    else    // 非循环录像
    {
        MOS_LOG_INF(RDSTG_LOGSTR,"Rd No LoopRecord not to delete");
    }

    return iDelFileSize;
}

// 录像节点停止
_INT RdStg_NodeStoping(ST_RDSTG_NODE *pstNode)
{
    MOS_PARAM_NULL_RETERR(pstNode);

    // 录像节点停止
    RdStg_NodeStop(pstNode, 1);

    // 更新当前录像节点的工作状态
    pstNode->ucStatus = EN_RDSTG_STATUS_IDEL; 

    // 向厂商更新录像状态 厂商设置回调ZJ_SetRecordStatusCB 
    if(ZJ_GetFuncTable()->pfunRecordStatus)
        ZJ_GetFuncTable()->pfunRecordStatus(0);

    // 向InIot更新录像IOT的工作状态    
    Config_SetInIotWorkStatus(EN_ZJ_AIIOT_TYPE_RECORD,pstNode->iCamId,0);
    return MOS_OK;
}

// 处理录像逻辑 向localIO注册的Process
_INT RdStg_IoProcess()
{
    _INT iErrCode  = 0;
    _INT iWriteLen = 0;
    _CTIME_T cNowCTime;
    ST_RDSTG_NODE *pstNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;

#if DEBUG
    static _INT count = 0;
#endif
    if(RdStg_GetMng()->ucStopAllFlag)
    {
        return MOS_OK;
    }

    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0)
    {
        return MOS_ERR;
    }

    cNowCTime = Mos_Time(); 
    // 遍历录像链表
    FOR_EACHDATA_INLIST(&RdStg_GetMng()->stRdList,pstNode,stIterator)
    {
        if(EN_RDSTG_STATUS_INIT == pstNode->ucStatus)
        {
            // 录像节点初始化 更新date.txt 配置文件
            MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_NodeInit iCamId:%d ", pstNode->iCamId);
            RdStg_NodeInit(pstNode);
            MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_NodeInit END ");
        }
        else if(EN_RDSTG_STATUS_IDEL == pstNode->ucStatus && pstNode->ucCamOpenFlag == 1)
        {
            // MOS_PRINTF(" ucAllDayRecordFlag:%d cNowCTime:%u cRecordToTime:%u \r\n", pstNode->ucAllDayRecordFlag, pstNode->cRecordToTime);
            if(cNowCTime <= pstNode->cRecordToTime || pstNode->uiCustomNodeNum || pstNode->ucAllDayRecordFlag == 1)
            {
                // 初始化节点 filedes.txt 配置文件
                // MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_NodeStart iCamId:%d cNowCTime:%u pstNode->cRecordToTime:%u", pstNode->iCamId, cNowCTime, pstNode->cRecordToTime);
                RdStg_NodeStart(pstNode, cNowCTime);
                // MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_NodeStart END ");
            }
        }
        else if(EN_RDSTG_STATUS_RUN == pstNode->ucStatus)
        {
            if((cNowCTime < pstNode->cRecordToTime || pstNode->uiCustomNodeNum || pstNode->ucAllDayRecordFlag)
                && pstNode->ucCamOpenFlag == 1)
            {
#if !defined PLAYBACK_DEBUG
                // 节点运行 *.mp4录像文件录制
                iWriteLen += RdStg_NodeRuning(pstNode, cNowCTime);
#endif

#if DEBUG
                count++;
                printf("count: %d\r\n", count);
                if (count > 10000)
                {
                    pstNode->ucStatus = EN_RDSTG_STATUS_STOP;
                    MOS_LOG_INF(RDSTG_LOGSTR,"record turn to stop for no task");
                    continue;
                }
#endif
            }
            else
            {
                pstNode->ucStatus = EN_RDSTG_STATUS_STOP;
                MOS_LOG_INF(RDSTG_LOGSTR,"record turn to stop for no task");
                continue;
            }
        }
        else if(EN_RDSTG_STATUS_STOP == pstNode->ucStatus)
        {
            // 节点暂停
            
            MOS_LOG_INF(RDSTG_LOGSTR,"EN_RDSTG_STATUS_STOP");
            RdStg_NodeStoping(pstNode);
        }
    }
    
    // SD卡有错误
    if(RdStg_GetMng()->ucCbTfCardErrFlag == 1)
    {
        // 检测SD卡
        if(ZJ_GetFuncTable()->pfunCheckSDCard)
        {
            // ZJ_GetFuncTable()->pfunCheckSDCard(&iErrCode);
        }
        RdStg_GetMng()->ucCbTfCardErrFlag = 0;
    }
    return iWriteLen;
}

#ifdef PLAYBACK_DEBUG
_INT RdStg_GetRecordFileList(_UC *pucPlaybackFileStartTime);
// 卡录像回放线程
_INT RdStg_PlayBackProc(_VPTR pParam)
{
    sleep(10);
    _UC ucPlaybackFileStartTime[32] = {0};
    RdStg_GetRecordFileList(ucPlaybackFileStartTime);
    MOS_LOG_INF(RDSTG_LOGSTR,"file name ucPlaybackFileStartTime %s \r\n", ucPlaybackFileStartTime);

    _INT iAdjustTime = 0;
    _RDFILEFD *pstRdStg_fileFD;
    ST_RDSTG_READER_NODE *pstReader = MOS_NULL; 

    // 打开录像文件
    pstRdStg_fileFD = RdStg_OpenFile(0, ucPlaybackFileStartTime, &iAdjustTime);
    if (pstRdStg_fileFD == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"pstRdStg_fileFD == MOS_NULL");
    }
    else
    {
       pstReader  =  (ST_RDSTG_READER_NODE *)pstRdStg_fileFD; 
       MOS_LOG_INF(RDSTG_LOGSTR,"pstRdStg_fileFD RdStg_OpenFile END");
    }

    // 读取录像数据流
     _UC  ucBuf[1400] = {0};
    _UI  uiBufLen = 0;
    _UC  ucAVFlag = 0;
    _UI  uiTimeStamp = 0;
    _UC  ucFramePos  = 0;
    _UI  uiFrameLen  = 0;
    int  ret = 0;

    // 打开存储读取出来的录像文件内容的文件
    // pstMefcMp4DeMuxer->hFileHandle = Mos_FileOpen(pucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    FILE *mp4_fd = fopen("./playback.h264", "wb");
    // FILE *mp4_fd = fopen("/mnt/sdcard/playback.h264", "wb");
    if (MOS_NULL == mp4_fd)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"MOS_NULL == mp4_fd");
    }

    while(RdStg_GetMng()->ucInitFlag)
    {
        ret = RdStg_ReadData(pstRdStg_fileFD, ucBuf, &uiBufLen, &ucAVFlag, &uiTimeStamp, &ucFramePos , &uiFrameLen);
        if (ret < 0)
        {
            MOS_LOG_ERR(RDSTG_LOGSTR,"RdStg_ReadData failed");
            if (ret == MOS_ERR_FILEEND)
            {
                MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_ReadData MOS_ERR_FILEEND");
                break;
            }
        }
        else
        {
            MOS_LOG_INF(RDSTG_LOGSTR,"uiBufLen:    %d", uiBufLen);
            MOS_LOG_INF(RDSTG_LOGSTR,"ucAVFlag:    %d", ucAVFlag);
            MOS_LOG_INF(RDSTG_LOGSTR,"uiTimeStamp: %d", uiTimeStamp);
            MOS_LOG_INF(RDSTG_LOGSTR,"ucFramePos:  %d", ucFramePos);
            MOS_LOG_INF(RDSTG_LOGSTR,"uiFrameLen:  %d", uiFrameLen);
            if (ucBuf != MOS_NULL)
            {
                MOS_BUFPRINTF("MP4 ucBuf", (_UC *)ucBuf, 20);
            }
            else
            {
                MOS_LOG_ERR(RDSTG_LOGSTR,"pucBuf == MOS_NULL");
            }

            ret = fwrite(ucBuf, uiBufLen, 1, mp4_fd);
            if (ret < 0)
            {
                MOS_LOG_ERR(RDSTG_LOGSTR,"fwrite error");
            }
        }

        Mos_Sleep(50);
    }
    fclose(mp4_fd);
    return MOS_OK;
}
#endif

// 录像停止 向localIO注册的stop
_INT RdStg_IoStop()
{
    ST_RDSTG_NODE *pstNode;
    ST_MOS_LIST_ITERATOR stIterator;
    //遍历录像链表
    FOR_EACHDATA_INLIST(&RdStg_GetMng()->stRdList,pstNode,stIterator)
    {
        // 停止录像节点
        RdStg_NodeStop(pstNode, 1);
        pstNode->ucStatus = EN_RDSTG_STATUS_INIT;
    }
    RdStg_GetMng()->ucStopAllFlag  = 1;

#ifdef PLAYBACK_DEBUG
    Mos_ThreadDelete(RdStg_GetMng()->hPlayBackThread);
#endif

    MOS_LOG_INF(RDSTG_LOGSTR,"Record io stop ok");
    return MOS_OK;
}

// 录像模块开始 向localIO注册的start
_INT RdStg_IoReStart(_UC *pucLocalPath)
{
    MOS_PARAM_NULL_RETERR(pucLocalPath);

    // 初始化缓存路径
    MOS_MEMCPY(RdStg_GetMng()->aucCachePath, pucLocalPath, MOS_STRLEN(pucLocalPath) + 1);
    MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_GetMng()->aucCachePath: %s ", RdStg_GetMng()->aucCachePath);

#ifdef PLAYBACK_DEBUG
    _INT iRet;
    iRet = Mos_ThreadCreate((_UC *)"RdStg_PlayBackMgr", EN_THREAD_PRIORITY_NORMAL, MOS_THREAD_STACK_NORMAL_SIZE,
        RdStg_PlayBackProc, MOS_NULL, MOS_NULL, &RdStg_GetMng()->hPlayBackThread);
#endif
    RdStg_GetMng()->ucStopAllFlag = 0;
    return MOS_OK;
}

_INT RdStg_QueryDate(_VPTR pUsrPoint, _INT iCamId, PFUN_RDSTG_DATELIST pfuncOnDateList)
{
    ST_RDSTG_QUERY_DATE_NODE *pstQryDate;
    ST_RDSTG_MSG_NODE *pstMsgNode = (ST_RDSTG_MSG_NODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_MSG_NODE));

    if(NULL == pstMsgNode){
        return MOS_ERR_NOMEM;
    }
    pstQryDate = (ST_RDSTG_QUERY_DATE_NODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_QUERY_DATE_NODE));
    if(NULL == pstQryDate){
        MOS_FREE(pstMsgNode);
        return MOS_ERR_NOMEM;
    }
    pstMsgNode->pMsgStruct = pstQryDate;
    pstMsgNode->uiMsgType = RDSTG_MSG_TYPE_QUERY_DATE;
    pstQryDate->iCamId = iCamId;
    pstQryDate->pfuncOnDateList = pfuncOnDateList;
    pstQryDate->pUsrPoint = pUsrPoint;
    Mos_MutexLock(&RdStg_GetMng()->hMutex);
    pstMsgNode->pstNext = g_pstMsgHead;
    g_pstMsgHead = pstMsgNode;
    Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
    return MOS_OK;
}

_INT RdStg_QueryList(_VPTR pUsrPoint, _INT iCamId, _UC *pucDay, PFUN_RDSTG_FILELIST pfuncOnFileList)
{
    ST_RDSTG_QUERY_FILE_NODE *pstQryFile;
    ST_RDSTG_MSG_NODE *pstMsgNode = (ST_RDSTG_MSG_NODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_MSG_NODE));

    if(NULL == pstMsgNode){
        return MOS_ERR_NOMEM;
    }
    pstQryFile = (ST_RDSTG_QUERY_FILE_NODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_QUERY_FILE_NODE));
    if(NULL == pstQryFile){
        return MOS_ERR_NOMEM;
    }
    pstMsgNode->pMsgStruct = pstQryFile;
    pstMsgNode->uiMsgType = RDSTG_MSG_TYPE_QUERY_FILE;
    pstQryFile->iCamId = iCamId;
    pstQryFile->pfuncOnFileList = pfuncOnFileList;
    pstQryFile->pUsrPoint = pUsrPoint;
    MOS_MEMCPY(pstQryFile->aucDay, pucDay, MOS_STRLEN(pucDay) + 1);
    Mos_MutexLock(&RdStg_GetMng()->hMutex);
    pstMsgNode->pstNext = g_pstMsgHead;
    g_pstMsgHead = pstMsgNode;
    Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
    return MOS_OK;
}

_INT RdStg_ProcessQueryDate(ST_RDSTG_QUERY_DATE_NODE *pstQryDate)
{
    MOS_PARAM_NULL_RETERR(pstQryDate);

    ST_MOS_LIST *pstDateList = RdStg_GetDateList(pstQryDate->iCamId);
    if(pstQryDate->pfuncOnDateList){
        pstQryDate->pfuncOnDateList(pstQryDate->pUsrPoint, pstDateList);
    }
    if(pstDateList){
        RdStg_FreeList(pstDateList);
    }
    return MOS_OK;
}

ST_MOS_LIST *RdStg_GetFileDesList(_INT iCamId,_UC *pucDay)
{
    MOS_PARAM_NULL_RETNULL(pucDay);

    _HFILE hFile = MOS_NULL ;
    _INT iRetLen = 0;
    _UC aucFileName[256];
    _UC aucVersion[24];
    ST_RDSTG_FILEDES stFileDes;
    ST_MOS_LIST *pstList = MOS_NULL;
    ST_RDSTG_FILEDESNODE *pstFileDesNode = MOS_NULL;

    MOS_LOG_INF(RDSTG_LOGSTR,"cam %d get filedes list",iCamId);
    MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,iCamId,pucDay,RDSTG_FILEDESCFG_NAME);

    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return MOS_NULL;
    }
    MOS_MEMSET(aucVersion, 0, 24);
    Mos_FileRead(hFile,aucVersion,16);
    if(MOS_STRNCMP(aucVersion, RDSTG_FILEDESCFG_VERSION,MOS_STRLEN(RDSTG_FILEDESCFG_VERSION)) != 0)
    {
        Mos_FileClose(hFile);
        return MOS_NULL;
    }
    do
    {
        iRetLen = Mos_FileRead(hFile,(_UC*)&stFileDes,sizeof(stFileDes));
        if(iRetLen == sizeof(stFileDes) && stFileDes.ucCheck == '$' && stFileDes.ucBInUse)
        {
            if(pstList == MOS_NULL)
            {
                pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
                if(pstList == MOS_NULL)
                {
                    break;
                }
            }
            pstFileDesNode = (ST_RDSTG_FILEDESNODE*)MOS_MALLOC(sizeof(ST_RDSTG_FILEDESNODE));
            if(pstFileDesNode)
            {
                MOS_MEMCPY(&pstFileDesNode->stFileDes, &stFileDes, sizeof(stFileDes));
                MOS_LIST_ADDTAIL(pstList, pstFileDesNode);
            }
        }
    }while(Mos_FileEof(hFile) ==MOS_FALSE);

    Mos_FileClose(hFile);
    return pstList;
}

// 通过page查询卡录像文件列表 通过信令调用 (卡录像查询入口)
ST_MOS_LIST *RdStg_GetFileListByPage(_INT iCamId,_UC *pucStartTime,_UI uiPageSize)
{
    MOS_PARAM_NULL_RETNULL(pucStartTime);

    _HFILE hFile = MOS_NULL ;
    _INT iRetLen = 0;
    _UC aucFileName[256];
    _UC aucVersion[24];
    _UC aucDay[16];
    _CTIME_T cStartTime;
    ST_MOS_SYS_TIME stSysTime;
    ST_RDSTG_FILEDES stFileDes;
    ST_MOS_LIST *pstList = MOS_NULL;
    ST_RDSTG_FILEDESNODE *pstFileDesNode = MOS_NULL;
    
    MOS_MEMSET(aucDay,0,16);
    MOS_MEMCPY(aucDay, pucStartTime,10);
    MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,iCamId,aucDay,RDSTG_FILEDESCFG_NAME);
    MOS_LOG_INF(RDSTG_LOGSTR,"cam %d get file list by page %u from %s aucFileName %s",iCamId,uiPageSize,pucStartTime,aucFileName);

    // 打开filedes.txt文件
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return MOS_NULL;
    }
    MOS_MEMSET(aucVersion, 0, 24);
    // 读取filedes.txt文件 RDSTG_FILEDESCFG_VERSION 对比版本号
    Mos_FileRead(hFile,aucVersion,16);
    if(MOS_STRNCMP(aucVersion, RDSTG_FILEDESCFG_VERSION,MOS_STRLEN(RDSTG_FILEDESCFG_VERSION)) != 0)
    {
        Mos_FileClose(hFile);
        return MOS_NULL;
    }
    
    Mos_GetSysTime(&stSysTime);
    MOS_SSCANF(pucStartTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        &stSysTime.usYear,&stSysTime.usMonth,&stSysTime.usDay,&stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
    cStartTime = Mos_SysTimetoTime(&stSysTime);
    do
    {
        // 读取filedes.txt文件 filedes结构体 ST_RDSTG_FILEDES
        iRetLen = Mos_FileRead(hFile,(_UC*)&stFileDes,sizeof(stFileDes));
        if( iRetLen == sizeof(stFileDes) && stFileDes.ucCheck == '$' && stFileDes.ucBInUse &&
            stFileDes.cStartTime >= cStartTime)
        {
            if(pstList == MOS_NULL)
            {
                pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
                if(pstList == MOS_NULL)
                {
                    break;
                }
            }
            pstFileDesNode = (ST_RDSTG_FILEDESNODE*)MOS_MALLOC(sizeof(ST_RDSTG_FILEDESNODE));
            if(pstFileDesNode)
            {
                MOS_MEMCPY(&pstFileDesNode->stFileDes, &stFileDes, sizeof(stFileDes));
                if(pstFileDesNode->stFileDes.cStopTime == 0)
                {
                    // 当前录制中的录像文件
                    if (pstFileDesNode->stFileDes.uiFileSeq == RdStg_GetMng()->uiCurrentSeq)
                    {
                        // 记录当前的设备时间
                        pstFileDesNode->stFileDes.cStopTime = Mos_Time();
                    }
                    // 之前插拔sdcard或其他原因损坏的录像文件
                    else
                    {
                        // 获取录像列表不上报损坏的录像文件的节点信息
                        MOS_LOG_ERR(RDSTG_LOGSTR, "GetFileList cStopTime Err, %u.mp4", pstFileDesNode->stFileDes.uiFileSeq);
                        continue;
                    }
                }
                MOS_LIST_ADDTAIL(pstList, pstFileDesNode);
            }
            if(MOS_LIST_GETCOUNT(pstList) >= uiPageSize) // 一页最大数 信令传下来
            {
                break;
            }
        }
        else if (iRetLen < 0)
        {
            MOS_LOG_ERR(RDSTG_LOGSTR,"GetFileList fail fread errno = %u");
        }
    }while(Mos_FileEof(hFile) ==MOS_FALSE);

    Mos_FileClose(hFile);
    return pstList;
}

// 通过Handle获取文件Des
ST_RDSTG_FILEDES *RdStg_GetFileDesFromHandle(_RDFILEFD hHandle)
{
    ST_RDSTG_READER_NODE *pstReader = (ST_RDSTG_READER_NODE *)hHandle;
    MOS_LOG_INF(RDSTG_LOGSTR,"Get file descripions %p play record", pstReader);
    if((NULL == pstReader) || (0 == pstReader->ucIsUsing)){
        return MOS_NULL;
    }
    
    return &pstReader->stFileDes;
}

_INT RdStg_ProcessQueryFile(ST_RDSTG_QUERY_FILE_NODE *pstQryFile)
{
    MOS_PARAM_NULL_RETERR(pstQryFile);

    ST_MOS_LIST *pstFileList = RdStg_GetFileDesList(pstQryFile->iCamId, pstQryFile->aucDay);
    if(pstQryFile->pfuncOnFileList){
        pstQryFile->pfuncOnFileList(pstQryFile->pUsrPoint, pstFileList);
    }
    if(pstFileList){
        RdStg_FreeList(pstFileList);
    }
    return MOS_OK;
}

_VOID RdStg_ProcessQuery()
{
    ST_RDSTG_MSG_NODE *pstMsgNode;
    while(g_pstMsgHead){
        Mos_MutexLock(&RdStg_GetMng()->hMutex);
        pstMsgNode = g_pstMsgHead;
        g_pstMsgHead = g_pstMsgHead->pstNext;
        Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
        if(RDSTG_MSG_TYPE_QUERY_DATE == pstMsgNode->uiMsgType){
            RdStg_ProcessQueryDate((ST_RDSTG_QUERY_DATE_NODE *)pstMsgNode->pMsgStruct);
            MOS_FREE(pstMsgNode->pMsgStruct);
            MOS_FREE(pstMsgNode);
        }else if(RDSTG_MSG_TYPE_QUERY_FILE == pstMsgNode->uiMsgType){
            RdStg_ProcessQueryFile((ST_RDSTG_QUERY_FILE_NODE *)pstMsgNode->pMsgStruct);
            MOS_FREE(pstMsgNode->pMsgStruct);
            MOS_FREE(pstMsgNode);
        }
    }
}

_INT RdStg_Delete(_VPTR pUsrPoint, _INT iCamId, _UI uiStartTime, _UI uiEndTime)
{
    return MOS_OK;
}

// 获取回放节点信息
ST_RDSTG_READER_NODE *RdStg_GetReader()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RDSTG_READER_NODE *pstReadNode = MOS_NULL;
    Mos_MutexLock(&RdStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&RdStg_GetMng()->stReadList, pstReadNode, stIterator)
    {
        if(0 == pstReadNode->ucIsUsing)
        {
            break;
        }
    }
    if(MOS_NULL == pstReadNode)
    {
        pstReadNode = (ST_RDSTG_READER_NODE*)MOS_MALLOCCLR(sizeof(ST_RDSTG_READER_NODE));
        MOS_LIST_ADDTAIL(&RdStg_GetMng()->stReadList, pstReadNode);
    }
    MOS_MEMSET(&pstReadNode->stThirdRead,0,sizeof(ST_RDSTG_THIRDREAD));
    pstReadNode->ucIsUsing = 1;
    Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
    return pstReadNode;
}

// 获取文件des
_INT RdStg_GetFileDes(_INT iCamId,_UC *pucDay,_CTIME_T cTime, ST_RDSTG_FILEDES *pstFileDes)
{
    MOS_PARAM_NULL_RETERR(pucDay);
    MOS_PARAM_NULL_RETERR(pstFileDes);

    _HFILE hFile = MOS_NULL ;
    _INT iRetLen = 0;
    _INT iRet    = MOS_ERR;
    _UC aucFileName[256];
    _UC aucVersion[24];
    ST_RDSTG_FILEDES stFileDes;

    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0){
        return iRet;
    }

    MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,iCamId,pucDay,RDSTG_FILEDESCFG_NAME);
    
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL){
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return iRet;
    }

    Mos_FileRead(hFile,aucVersion,16);
    if(MOS_STRNCMP(aucVersion, RDSTG_FILEDESCFG_VERSION,MOS_STRLEN(RDSTG_FILEDESCFG_VERSION)) == 0){  
        do{
            iRetLen = Mos_FileRead(hFile,(_UC*)&stFileDes,sizeof(stFileDes));
            if(iRetLen == sizeof(stFileDes) && stFileDes.ucCheck == '$' && stFileDes.ucBInUse &&
                cTime >= stFileDes.cStartTime && (cTime < stFileDes.cStopTime || stFileDes.cStopTime == 0))
             {
                MOS_MEMCPY(pstFileDes,&stFileDes,sizeof(stFileDes));
                iRet = MOS_OK;
                #if 0
                MOS_LOG_INF(RDSTG_LOGSTR,"cTime:                          %u ", cTime);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->ucRsv:              %d ", pstFileDes->ucRsv);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->ucCheck:            %d ", pstFileDes->ucCheck);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->ucBInUse:           %d ", pstFileDes->ucBInUse);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->ucBCover:           %d ", pstFileDes->ucBCover);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->uiFileSeq:          %u ", pstFileDes->uiFileSeq);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->cStartTime:         %u ", pstFileDes->cStartTime);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->cStopTime:          %u ", pstFileDes->cStopTime);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->uiStartTimeStamp:   %u ", pstFileDes->uiStartTimeStamp);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->uiEndTimeStamp:     %u ", pstFileDes->uiEndTimeStamp);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->uiAudioEncType:     %u  ", pstFileDes->uiAudioEncType );
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->uiVideoEncType:     %u  ", pstFileDes->uiVideoEncType);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->uiVideoWidth:       %u  ", pstFileDes->uiVideoWidth);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->uiVideoHeight:      %u  ", pstFileDes->uiVideoHeight);
                MOS_LOG_INF(RDSTG_LOGSTR,"pstFileDes->uiVideoFrameRate:   %u  ", pstFileDes->uiVideoFrameRate);
                #endif
                break;
            }

        }while(Mos_FileEof(hFile) ==MOS_FALSE);
    }
    Mos_FileClose(hFile);
    return iRet;
}
// seek录像文件
_RDFILEFD RdStg_SeekOnOneFile(_RDFILEFD *pstRdStg_fileFD, _UC *pucPlayTime, _INT *piAdjustTime)
{
    MOS_PARAM_NULL_RETNULL(pucPlayTime);
    MOS_PARAM_NULL_RETNULL(piAdjustTime);

    ST_RDSTG_READER_NODE *pstReader = (ST_RDSTG_READER_NODE *)pstRdStg_fileFD;
    _INT iRet = 0;
    _UI  uiSubTime = 0;
    _CTIME_T cTime = 0;
    _UI uiSeekTimeStamp = 0;
    ST_MOS_SYS_TIME stSysTime = {0};
    // 获取回放节点信息
    Mos_GetSysTime(&stSysTime);

    iRet = MOS_SSCANF(pucPlayTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        &stSysTime.usYear,&stSysTime.usMonth,&stSysTime.usDay,
        &stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);

    if(iRet != 6)
    {
        return MOS_NULL;
    }

    cTime = Mos_SysTimetoTime(&stSysTime);
    // 播放时间戳和录像文件开始时间的差值
    uiSubTime = (_UI)(cTime - pstReader->stFileDes.cStartTime);
    if(uiSubTime >= RDSTG_FILE_MAX_TIME)
    {
        uiSubTime = 0;
    }

    uiSubTime = uiSubTime*1000;
    if(pstReader->stFileDes.ucRsv == 1 && ZJ_GetFuncTable()->pfunSeekTime)
    {
        // 第三方录像文件 (厂商自己录像文件)
        ZJ_GetFuncTable()->pfunSeekTime(pstReader->hMp4File,uiSubTime, &uiSeekTimeStamp);
    }
    else
    {
        // 查找回放的录像的时间戳对应的视频IDR帧和音频帧
        RdStg_Mp4DeMuxer_SeekFile(pstReader->hMp4File,uiSubTime, &uiSeekTimeStamp);
    }

    if(piAdjustTime)
    {
        // 相对于点播时间戳的调整时间戳差值
        // 运用场景: 拖动：拖动回放的时间点未必是IDR帧，则就要做时间偏移调整回放时间点
        *piAdjustTime = (_INT)(uiSeekTimeStamp - uiSubTime);
    }

    MOS_LOG_INF(RDSTG_LOGSTR,"creat record handle %p play time %s  timestatmp %u seekstamp %u "
        "filedes: time %u - %u,stamp %u-%u,ajust time %d",
        pstReader,pucPlayTime,uiSubTime,uiSeekTimeStamp,
        pstReader->stFileDes.cStartTime,pstReader->stFileDes.cStopTime,
        pstReader->stFileDes.uiStartTimeStamp,pstReader->stFileDes.uiEndTimeStamp,*piAdjustTime);

    return (_RDFILEFD)pstReader;
}

// 打开录像文件
_RDFILEFD RdStg_OpenFile(_INT iCamId, _UC *pucPlayTime, _INT *piAdjustTime)
{
    MOS_PARAM_NULL_RETNULL(pucPlayTime);
    MOS_PARAM_NULL_RETNULL(piAdjustTime);

    _INT iRet = 0;
    _UI  uiSubTime = 0;
    _UC aucFileName[256];
    _CTIME_T cTime = 0;
    _UI uiSeekTimeStamp = 0;
    ST_MOS_SYS_TIME stSysTime = {0};
    ST_RDSTG_READER_NODE *pstReader = MOS_NULL;
    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0)
    {
        return MOS_NULL;
    }

    // 获取回放节点信息
    pstReader = RdStg_GetReader();
    if(MOS_NULL == pstReader)
    {
        return MOS_NULL;
    }
    Mos_GetSysTime(&stSysTime); 

    iRet = MOS_SSCANF(pucPlayTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        &stSysTime.usYear,&stSysTime.usMonth,&stSysTime.usDay,
        &stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);

    if(iRet != 6)
    {
        pstReader->ucIsUsing = 0;
        return MOS_NULL;
    }

    MOS_VSNPRINTF(pstReader->aucDay,16, "%04u-%02u-%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay); 
    // MOS_LOG_INF(RDSTG_LOGSTR,"pstReader->aucDay %s ",pstReader->aucDay);

    cTime = Mos_SysTimetoTime(&stSysTime);
    // MOS_LOG_INF(RDSTG_LOGSTR,"cTime %u ", cTime);

    if(RdStg_GetFileDes(iCamId,pstReader->aucDay,cTime,&pstReader->stFileDes) == MOS_ERR)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"can't find file by play time %s ",pucPlayTime);
        pstReader->ucIsUsing = 0;
        return MOS_NULL; 
    }

    if(pstReader->stFileDes.ucRsv == 1)
    {
        _UC aucMapDes[256];
        MOS_VSNPRINTF(aucMapDes, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath, iCamId,pstReader->aucDay,RDSTG_MAPPING_NAME);

        RdStg_FindMappingFile(aucMapDes,aucFileName,pstReader->stFileDes.uiFileSeq);

        if(ZJ_GetFuncTable()->pfunOpenFile){
            // 第三方录像(厂商自行录像)
            // 打开录像文件
            pstReader->hMp4File = ZJ_GetFuncTable()->pfunOpenFile(aucFileName,&pstReader->stThirdRead.uiMaxFrameLen);
            pstReader->stThirdRead.pucThirdBuff = (_UC *)MOS_MALLOCCLR(pstReader->stThirdRead.uiMaxFrameLen);
        }
    }
    else
    {
        MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%d.mp4",RdStg_GetMng()->aucCachePath,iCamId,pstReader->aucDay,pstReader->stFileDes.uiFileSeq);
        // 打开录像文件 并获取回放的录像文件的配置信息
        pstReader->hMp4File = RdStg_Mp4DeMuxer_OpenFile(aucFileName);
    }
    MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_OpenFile open record file:%s", aucFileName);
    if(MOS_NULL == pstReader->hMp4File){
        pstReader->ucIsUsing = 0;
        return MOS_NULL; 
    }
    
    // 播放时间戳和录像文件开始时间的差值
    uiSubTime = (_UI)(cTime - pstReader->stFileDes.cStartTime);
    if(uiSubTime >= RDSTG_FILE_MAX_TIME)
    {
        uiSubTime = 0;
    }

    uiSubTime = uiSubTime*1000;
    if(pstReader->stFileDes.ucRsv == 1 && ZJ_GetFuncTable()->pfunSeekTime)
    {
        // 第三方录像文件 (厂商自己录像文件)
        ZJ_GetFuncTable()->pfunSeekTime(pstReader->hMp4File,uiSubTime, &uiSeekTimeStamp);
    }
    else
    {
        // 查找回放的录像的时间戳对应的视频IDR帧和音频帧
        RdStg_Mp4DeMuxer_SeekFile(pstReader->hMp4File,uiSubTime, &uiSeekTimeStamp);
    }
    pstReader->iCamId  = iCamId;

    if(piAdjustTime)
    {
        // 相对于点播时间戳的调整时间戳差值
        // 运用场景: 拖动：拖动回放的时间点未必是IDR帧，则就要做时间偏移调整回放时间点
        *piAdjustTime = (_INT)(uiSeekTimeStamp - uiSubTime);
    }
    
    MOS_LOG_INF(RDSTG_LOGSTR,"creat record handle %p play time %s  timestatmp %u seekstamp %u "
        "filedes: time %u - %u,stamp %u-%u,ajust time %d",
        pstReader,pucPlayTime,uiSubTime,uiSeekTimeStamp,
        pstReader->stFileDes.cStartTime,pstReader->stFileDes.cStopTime,
        pstReader->stFileDes.uiStartTimeStamp,pstReader->stFileDes.uiEndTimeStamp,*piAdjustTime);
    
    return (_RDFILEFD)pstReader;
}

// 关闭录像文件
_INT RdStg_CloseFile(_RDFILEFD *hHandle)
{
    ST_RDSTG_READER_NODE *pstReader = (ST_RDSTG_READER_NODE *)hHandle;
    MOS_LOG_INF(RDSTG_LOGSTR,"close handle %p play record",pstReader);
    if((NULL == pstReader) || (0 == pstReader->ucIsUsing)){
        return MOS_ERR_PARAM;
    }
    MOS_FREE(pstReader->stThirdRead.pucThirdBuff);
    if(pstReader->hMp4File){
        // 关闭录像文件 
        // 第三方录像(厂商自行录像)
        if(pstReader->stFileDes.ucRsv == 1 && ZJ_GetFuncTable()->pfunCloseFile){
            ZJ_GetFuncTable()->pfunCloseFile(pstReader->hMp4File);
        }else{
            // 关闭录像文件
            RdStg_Mp4DeMuxer_CloseFile(pstReader->hMp4File);
        }
    }
    pstReader->ucIsUsing = 0;
    return MOS_OK;
}

// 获取下一个录像文件的Des
_INT RdStg_GetNextFileDes(_INT iCamId,_UC *pucDay,_UI uiFileSeq,ST_RDSTG_FILEDES *pstFileDes)
{
    MOS_PARAM_NULL_RETERR(pucDay);
    MOS_PARAM_NULL_RETERR(pstFileDes);

    _HFILE hFile = MOS_NULL ;
    _INT iRetLen = 0;
    _INT iRet    = MOS_ERR;
    _UC aucFileName[256];
    _UC aucVersion[24];
    ST_RDSTG_FILEDES stFileDes;

    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0){
        return MOS_ERR;
    }

    MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,iCamId,pucDay,RDSTG_FILEDESCFG_NAME);
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if(hFile == MOS_NULL) {
        MOS_LOG_ERR(RDSTG_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return iRet;
    }
    Mos_FileRead(hFile,aucVersion,16);
    if(MOS_STRNCMP(aucVersion, RDSTG_FILEDESCFG_VERSION,16) == 0){  
        do{
            iRetLen = Mos_FileRead(hFile,(_UC*)&stFileDes,sizeof(stFileDes));
            if(iRetLen == sizeof(stFileDes) && stFileDes.ucCheck == '$' && stFileDes.ucBInUse &&
                stFileDes.uiFileSeq > uiFileSeq){
                MOS_MEMCPY(pstFileDes,&stFileDes,sizeof(stFileDes));
                iRet = MOS_OK;
                break;
            }
        }while(Mos_FileEof(hFile) ==MOS_FALSE);
    }
    Mos_FileClose(hFile);
    return iRet;
}

// 读取第三方MP4的数据
_INT RdStg_ReadThirdMp4Buf(_RDFILEFD hHandle, _UC *pucBuf, _UI *puiBufLen, _UC *pucAVFlag, _UI *puiTimeStamp, _UC *pucFramePos, _UI *puiFrameLen)
{
    MOS_PARAM_NULL_RETERR(pucBuf);

    _INT iRet = 0;
    _INT isIFrame = 0;
    ST_RDSTG_READER_NODE *pstReader = (ST_RDSTG_READER_NODE *)hHandle;

    if(ZJ_GetFuncTable()->pfunReadFrame == MOS_NULL)
    {
         return MOS_ERR;
    }
    
    if( pstReader->stThirdRead.uiResFrameLen == 0)
    {
        iRet = ZJ_GetFuncTable()->pfunReadFrame(pstReader->hMp4File,pstReader->stThirdRead.pucThirdBuff,&pstReader->stThirdRead.uiCurrentFrameLen,
                                    &pstReader->stThirdRead.pucAVFlag,&pstReader->stThirdRead.uiIFrameFlag,&pstReader->stThirdRead.uiTimeStamp);
        if(iRet <= 0)
        {
            return MOS_ERR_FILEEND;
        }
        *puiFrameLen  = pstReader->stThirdRead.uiResFrameLen = pstReader->stThirdRead.uiCurrentFrameLen;
        *pucAVFlag    = pstReader->stThirdRead.pucAVFlag;
        *puiTimeStamp = pstReader->stFileDes.uiStartTimeStamp + pstReader->stThirdRead.uiTimeStamp;
        if(pstReader->stThirdRead.uiResFrameLen <= MAX_VIDEOPAGESIZE)
        {
            *puiBufLen = pstReader->stThirdRead.uiResFrameLen;
            MOS_MEMCPY(pucBuf,pstReader->stThirdRead.pucThirdBuff,pstReader->stThirdRead.uiResFrameLen);
            if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_VIDEO && pstReader->stThirdRead.uiIFrameFlag == 1){
                *pucFramePos |= 0x1F;
            }else if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_VIDEO && pstReader->stThirdRead.uiIFrameFlag == 0){
                *pucFramePos |= 0x0F;
            }else if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_AUDIO){
                *pucFramePos |= 0x0C;
            }
            pstReader->stThirdRead.uiResFrameLen = 0;
            pstReader->stThirdRead.uiCurrentFrameLen = 0;
        }
        else
        {

            MOS_MEMCPY(pucBuf,pstReader->stThirdRead.pucThirdBuff, MAX_VIDEOPAGESIZE);
            *puiBufLen = MAX_VIDEOPAGESIZE;
            pstReader->stThirdRead.uiFramePos    += MAX_VIDEOPAGESIZE;
            pstReader->stThirdRead.uiResFrameLen -= MAX_VIDEOPAGESIZE;
            if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_VIDEO && pstReader->stThirdRead.uiIFrameFlag == 1){
                *pucFramePos |= 0x1A;
            }else if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_VIDEO && pstReader->stThirdRead.uiIFrameFlag == 0){
                *pucFramePos |= 0x0A;
            }else if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_AUDIO){
                *pucFramePos |= 0x08;
            }	

        }
        return MOS_OK;
    }
    else if(pstReader->stThirdRead.uiResFrameLen >= MAX_VIDEOPAGESIZE)
    {
        MOS_MEMCPY(pucBuf,pstReader->stThirdRead.pucThirdBuff + pstReader->stThirdRead.uiFramePos,MAX_VIDEOPAGESIZE);
        *puiBufLen = MAX_VIDEOPAGESIZE;
        pstReader->stThirdRead.uiFramePos += MAX_VIDEOPAGESIZE;
        pstReader->stThirdRead.uiResFrameLen -= MAX_VIDEOPAGESIZE;
        if(pstReader->stThirdRead.pucAVFlag== EN_ZJ_MEDIA_VIDEO && pstReader->stThirdRead.uiIFrameFlag == 1){
            *pucFramePos |= 0x10;		
        }else if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_VIDEO && pstReader->stThirdRead.uiIFrameFlag == 0){
            *pucFramePos |= 0x00;
        }else if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_AUDIO){
            *pucFramePos |= 0x00;
        }
    }
    else
    {
        MOS_MEMCPY(pucBuf,pstReader->stThirdRead.pucThirdBuff + pstReader->stThirdRead.uiFramePos,pstReader->stThirdRead.uiResFrameLen);
        *puiBufLen = pstReader->stThirdRead.uiResFrameLen;
        pstReader->stThirdRead.uiFramePos = 0;
        pstReader->stThirdRead.uiResFrameLen = 0;
        if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_VIDEO && pstReader->stThirdRead.uiIFrameFlag == 1){
            *pucFramePos |= 0x15;
        }else if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_VIDEO && pstReader->stThirdRead.uiIFrameFlag == 0){
            *pucFramePos |= 0x05;
        }else if(pstReader->stThirdRead.pucAVFlag == EN_ZJ_MEDIA_AUDIO){
            *pucFramePos |= 0x04;
        }
    }
    *puiFrameLen  = pstReader->stThirdRead.uiCurrentFrameLen;
    *pucAVFlag    = pstReader->stThirdRead.pucAVFlag;
    *puiTimeStamp = pstReader->stFileDes.uiStartTimeStamp + pstReader->stThirdRead.uiTimeStamp;
    return MOS_OK;
}

// 读取录像数据流
_INT RdStg_ReadData(_RDFILEFD hHandle, _UC *pucBuf, _UI *puiBufLen, _UC *pucAVFlag, _UI *puiTimeStamp, _UC *pucFramePos, _UI *puiFrameLen)
{
    MOS_PARAM_NULL_RETERR(pucBuf);

    _INT iRet,iFileEnd = 0;
    _UI uiNaluNum = 0;
    ST_RDSTG_FILEDES  stNextFileDes;
    ST_RDSTG_READER_NODE *pstReader = (ST_RDSTG_READER_NODE *)hHandle;
    if((NULL == pstReader) || (0 == pstReader->ucIsUsing))
    {
        return MOS_ERR_PARAM;
    }
    MOS_PARAM_NULL_RETERR(puiBufLen);
    MOS_PARAM_NULL_RETERR(pucAVFlag);
    MOS_PARAM_NULL_RETERR(puiTimeStamp);
    MOS_PARAM_NULL_RETERR(pucFramePos);
    MOS_PARAM_NULL_RETERR(puiFrameLen);
    
    *puiBufLen    = 0;
    *pucAVFlag    = 0;
    *puiTimeStamp = 0;
    *pucFramePos  = 0;
    *puiFrameLen  = 0;

    if(pstReader->stFileDes.ucRsv == 1)
    {
        // 第三方录像(厂商自行录像)
        // 读取MP4文件数据
        iRet = RdStg_ReadThirdMp4Buf(hHandle, pucBuf, puiBufLen, pucAVFlag, puiTimeStamp, pucFramePos, puiFrameLen);
    }
    else
    {
        // 读取MP4文件数据
        iRet = RdStg_Mp4DeMuxer_ReadBuf(pstReader->hMp4File, pucBuf, puiBufLen, pucAVFlag, puiTimeStamp, pucFramePos, puiFrameLen);
        *puiTimeStamp += pstReader->stFileDes.uiStartTimeStamp;
        if(MOS_ERR == iRet)
        {
            // 关闭录像文件
            RdStg_Mp4DeMuxer_CloseFile(pstReader->hMp4File);
            pstReader->hMp4File = NULL;

            return MOS_ERR_FILEEND;
        }
    }

    if(MOS_ERR_FILEEND != iRet)
    {
        return iRet;
    }

    // MOS_ERR_FILEEND
    if (pstReader->ucPlayMode == 0)
    {
        // 关闭录像文件
        RdStg_Mp4DeMuxer_CloseFile(pstReader->hMp4File);
        pstReader->hMp4File = NULL;
        MOS_LOG_INF(RDSTG_LOGSTR,"pstReader->ucPlayMode == 0 single file play mode");
        return MOS_ERR_FILEFINISH;
    }

    MOS_LOG_INF(RDSTG_LOGSTR,"Go To PlayBack Next File");

    if(RdStg_GetNextFileDes(pstReader->iCamId,pstReader->aucDay,pstReader->stFileDes.uiFileSeq,&stNextFileDes) == MOS_ERR)
    {
        MOS_LOG_INF(RDSTG_LOGSTR,"get next file des err , so file end ");
        return MOS_ERR_FILEEND;
    }

    if(stNextFileDes.uiStartTimeStamp < pstReader->stFileDes.uiEndTimeStamp + 4000)
    {
        _UC aucFileName[256] = {0};
        MOS_FREE(pstReader->stThirdRead.pucThirdBuff);
        if(stNextFileDes.ucRsv == 1)
        {
            _UC aucMapDes[256] = {0};
            if(ZJ_GetFuncTable()->pfunCloseFile)
            {
                ZJ_GetFuncTable()->pfunCloseFile(pstReader->hMp4File);
            }
            MOS_VSNPRINTF(aucMapDes, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath, pstReader->iCamId,pstReader->aucDay,RDSTG_MAPPING_NAME);
            RdStg_FindMappingFile(aucMapDes,aucFileName,stNextFileDes.uiFileSeq);
            if(ZJ_GetFuncTable()->pfunOpenFile)
            {
                pstReader->hMp4File = ZJ_GetFuncTable()->pfunOpenFile(aucFileName,&pstReader->stThirdRead.uiMaxFrameLen);
                pstReader->stThirdRead.pucThirdBuff = (_UC *)MOS_MALLOCCLR(pstReader->stThirdRead.uiMaxFrameLen);
            }
        }
        else
        {
            // 关闭录像文件
            RdStg_Mp4DeMuxer_CloseFile(pstReader->hMp4File);
            MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%d.mp4",RdStg_GetMng()->aucCachePath,pstReader->iCamId,pstReader->aucDay,stNextFileDes.uiFileSeq);
            // 打开录像文件 并获取回放的录像文件的配置信息
            pstReader->hMp4File = RdStg_Mp4DeMuxer_OpenFile(aucFileName);
        }

        if(MOS_NULL == pstReader->hMp4File)
        {
            pstReader->ucIsUsing = 0;
            return MOS_ERR; 
        }

        MOS_MEMCPY(&pstReader->stFileDes,&stNextFileDes,sizeof(stNextFileDes));
        MOS_LOG_INF(RDSTG_LOGSTR,"switch next slice");
        return MOS_ERR_FILESWITCH;
    }
    else
    {
        MOS_LOG_INF(RDSTG_LOGSTR,"get next file des sub time too big  so file end  ");
        return MOS_ERR_FILEEND;
    }
}

// 通过录像时间戳的字符串查询录像
_INT RdStg_SeekByTimeStr(_RDFILEFD hHandle,_UC *pucSeekTime)
{
    _INT iRet;
    _UC aucFileName[256];
    _UI uiTimeStamp,uiSeekTimeStamp;
    ST_MOS_SYS_TIME stSysTime;
    _CTIME_T cTime;
    ST_RDSTG_FILEDES  stNewFileDes;
    ST_RDSTG_READER_NODE *pstReader = (ST_RDSTG_READER_NODE *)hHandle;

    if((NULL == pstReader) || (0 == pstReader->ucIsUsing)){
        return MOS_ERR_PARAM;
    }
    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0){
        return MOS_ERR;
    }
    Mos_GetSysTime(&stSysTime); 
    iRet = MOS_SSCANF(pucSeekTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        &stSysTime.usYear,&stSysTime.usMonth,&stSysTime.usDay,
        &stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
    if(iRet != 6){
        return MOS_ERR;
    }
    cTime = Mos_SysTimetoTime(&stSysTime);
    if(RdStg_GetFileDes(pstReader->iCamId,pstReader->aucDay,cTime,&stNewFileDes) == MOS_ERR){
        return MOS_ERR; 
    }
    if(stNewFileDes.uiFileSeq == pstReader->stFileDes.uiFileSeq){
        uiTimeStamp = (_UI)(cTime - pstReader->stFileDes.cStartTime)*1000 + pstReader->stFileDes.uiStartTimeStamp;
        if(stNewFileDes.ucRsv == 1 && ZJ_GetFuncTable()->pfunSeekTime)
        {
            ZJ_GetFuncTable()->pfunSeekTime(pstReader->hMp4File,uiTimeStamp, &uiSeekTimeStamp);
        }else{
            // 查找回放的录像的时间戳对应的视频IDR帧和音频帧
            RdStg_Mp4DeMuxer_SeekFile(pstReader->hMp4File,uiTimeStamp, &uiSeekTimeStamp);
        }
    }
    else{
        MOS_FREE(pstReader->stThirdRead.pucThirdBuff);
        if(pstReader->stFileDes.ucRsv == 1 && ZJ_GetFuncTable()->pfunCloseFile){
            ZJ_GetFuncTable()->pfunCloseFile(pstReader->hMp4File);
        }else{
            // 关闭录像文件
            RdStg_Mp4DeMuxer_CloseFile(pstReader->hMp4File);
        }
        if(stNewFileDes.ucRsv == 1){
            _UC aucMapDes[256];
            MOS_VSNPRINTF(aucMapDes, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath, pstReader->iCamId,pstReader->aucDay,RDSTG_MAPPING_NAME);
            RdStg_FindMappingFile(aucMapDes,aucFileName,stNewFileDes.uiFileSeq);
            if(ZJ_GetFuncTable()->pfunOpenFile){
                pstReader->hMp4File = ZJ_GetFuncTable()->pfunOpenFile(aucFileName,&pstReader->stThirdRead.uiMaxFrameLen);
                pstReader->stThirdRead.pucThirdBuff = (_UC *)MOS_MALLOCCLR(pstReader->stThirdRead.uiMaxFrameLen);
            }
            MOS_MEMCPY(&pstReader->stFileDes,&stNewFileDes,sizeof(stNewFileDes));
            uiTimeStamp = (_UI)(cTime - pstReader->stFileDes.cStartTime)*1000 + pstReader->stFileDes.uiStartTimeStamp;
            if(ZJ_GetFuncTable()->pfunSeekTime){
                ZJ_GetFuncTable()->pfunSeekTime(pstReader->hMp4File, uiTimeStamp, &uiSeekTimeStamp);
            }
        }else{
            MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%d.mp4",RdStg_GetMng()->aucCachePath,pstReader->iCamId,pstReader->aucDay,stNewFileDes.uiFileSeq);
            // 打开录像文件 并获取回放的录像文件的配置信息
            pstReader->hMp4File = RdStg_Mp4DeMuxer_OpenFile(aucFileName);
            MOS_MEMCPY(&pstReader->stFileDes,&stNewFileDes,sizeof(stNewFileDes));
            uiTimeStamp = (_UI)(cTime - pstReader->stFileDes.cStartTime)*1000 + pstReader->stFileDes.uiStartTimeStamp;
            // 查找回放的录像的时间戳对应的视频IDR帧和音频帧
            RdStg_Mp4DeMuxer_SeekFile(pstReader->hMp4File, uiTimeStamp, &uiSeekTimeStamp);
        }
    }
    return MOS_OK;
}

// 通过时间戳查询录像
_INT RdStg_SeekByTimeStamp(_RDFILEFD hHandle,_UI uiTimeStamp)
{
    _HMP4DEMUXER hMp4File;
    _UC aucFileName[256];
    _UI uiSeekTimeStamp;
    ST_RDSTG_FILEDES stFileDes = {0};
    ST_RDSTG_READER_NODE *pstReader = (ST_RDSTG_READER_NODE *)hHandle;
    if((NULL == pstReader) || (0 == pstReader->ucIsUsing)){
        return MOS_ERR_PARAM;
    }
    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath) == 0){
        return MOS_ERR;
    }
    if(uiTimeStamp >= pstReader->stFileDes.uiStartTimeStamp){
        if(pstReader->stFileDes.ucRsv == 1 && ZJ_GetFuncTable()->pfunSeekTime){
            ZJ_GetFuncTable()->pfunSeekTime(pstReader->hMp4File, uiTimeStamp,&uiSeekTimeStamp);
        }else{
            // 查找回放的录像的时间戳对应的视频IDR帧和音频帧
            RdStg_Mp4DeMuxer_SeekFile(pstReader->hMp4File, uiTimeStamp,&uiSeekTimeStamp);
        }
        return MOS_OK;
    }

    if(uiTimeStamp < pstReader->stFileDes.uiStartTimeStamp){
        if(RdStg_GetFileDes(pstReader->iCamId,pstReader->aucDay,
            (_CTIME_T)( pstReader->stFileDes.cStartTime - pstReader->stFileDes.cStopTime), &stFileDes) == MOS_ERR){
            return MOS_ERR; 
        }
    }
    else{
        if(RdStg_GetNextFileDes(pstReader->iCamId,pstReader->aucDay,pstReader->stFileDes.uiFileSeq,&stFileDes) == MOS_ERR){
            return MOS_ERR; 
        }
    }
    MOS_FREE(pstReader->stThirdRead.pucThirdBuff);
    if(stFileDes.ucRsv == 1){
        _UC aucMapDes[256];
        MOS_VSNPRINTF(aucMapDes, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath, pstReader->iCamId,pstReader->aucDay,RDSTG_MAPPING_NAME);
        RdStg_FindMappingFile(aucMapDes,aucFileName,stFileDes.uiFileSeq);
        if(ZJ_GetFuncTable()->pfunOpenFile){
            hMp4File = ZJ_GetFuncTable()->pfunOpenFile(aucFileName,&pstReader->stThirdRead.uiMaxFrameLen);
        }
        if(hMp4File){
            if(ZJ_GetFuncTable()->pfunCloseFile){
                ZJ_GetFuncTable()->pfunCloseFile(pstReader->hMp4File);
            }
            pstReader->hMp4File = hMp4File;
            pstReader->stThirdRead.pucThirdBuff = (_UC *)MOS_MALLOCCLR(pstReader->stThirdRead.uiMaxFrameLen);
            MOS_MEMCPY(&pstReader->stFileDes, &stFileDes, sizeof(stFileDes));
            if(ZJ_GetFuncTable()->pfunSeekTime){
                ZJ_GetFuncTable()->pfunSeekTime(pstReader->hMp4File,uiTimeStamp,&uiSeekTimeStamp);
            }
        }
    }else{
        MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s/%d.mp4",RdStg_GetMng()->aucCachePath,pstReader->iCamId,pstReader->aucDay,stFileDes.uiFileSeq);
        // 打开录像文件 并获取回放的录像文件的配置信息
        hMp4File = RdStg_Mp4DeMuxer_OpenFile(aucFileName);
        if(hMp4File){
            // 关闭录像文件
            RdStg_Mp4DeMuxer_CloseFile(pstReader->hMp4File);
            pstReader->hMp4File = hMp4File;
            MOS_MEMCPY(&pstReader->stFileDes, &stFileDes, sizeof(stFileDes));
            // 查找回放的录像的时间戳对应的视频IDR帧和音频帧
            RdStg_Mp4DeMuxer_SeekFile(pstReader->hMp4File,uiTimeStamp,&uiSeekTimeStamp);
        }
    }
    return MOS_OK;
}

// 读取录像文件Des
_INT RdStg_ReadFileDes(_RDFILEFD hHandle,ST_CFG_VIDEODES *pstVideoDes, ST_ZJ_AUDIO_PARAM *pstAudioParm)
{
    MOS_PARAM_NULL_RETERR(pstVideoDes);
    MOS_PARAM_NULL_RETERR(pstAudioParm);

    _INT iRet = 0;
    ST_RDSTG_READER_NODE *pstReader = (ST_RDSTG_READER_NODE *)hHandle;
    
    if((NULL == pstReader) || (0 == pstReader->ucIsUsing)){
        return MOS_ERR_PARAM;
    }
    if(pstReader->stFileDes.ucRsv == 1 && ZJ_GetFuncTable()->pfunGetFileDes)
    {
        ZJ_GetFuncTable()->pfunGetFileDes(pstReader->hMp4File,&pstVideoDes->stVideoPara,&pstVideoDes->stCircle,pstAudioParm);
    }
    else
    {
        RdStg_Mp4DeMuxer_GetAudioDes(pstReader->hMp4File,&pstAudioParm->uiEncodeType,&pstAudioParm->uiSampleRate,&pstAudioParm->uiChannel);
        pstAudioParm->uiDepth = 16;
        iRet = RdStg_Mp4DeMuxer_GetCircleInf(pstReader->hMp4File,&pstVideoDes->stCircle);
        if(iRet != MOS_OK)
        {
            return iRet;
        }
        iRet = RdStg_Mp4DeMuxer_GetVideoDes(pstReader->hMp4File,&pstVideoDes->stVideoPara.uiEncodeType,&pstVideoDes->stVideoPara.uiWidth,
            &pstVideoDes->stVideoPara.uiHeight);
    }
    return iRet;
}

_INT RdStg_RepairFile(_UC *pucFileName,_UI *puiDuration)
{
    MOS_PARAM_NULL_RETERR(pucFileName);
    MOS_PARAM_NULL_RETERR(puiDuration);

    _INT iRet = 0;
    _UI uiFrameRate = 0;
    _HMP4MUXER hMp4File = MOS_NULL;
    hMp4File = RdStg_Mp4Repair_OpenFile(pucFileName);
    if(hMp4File == MOS_NULL){
        MOS_LOG_ERR(RDSTG_LOGSTR,"cant open file name %s",pucFileName);
        return MOS_ERR;
    }
    iRet = RdStg_Mp4Muxer_ReadCnf(hMp4File,&uiFrameRate);
    if(iRet != MOS_OK)
    {
        RdStg_Mp4Muxer_CloseFile(hMp4File,0);
        MOS_LOG_ERR(RDSTG_LOGSTR,"read config to fix err");
        return iRet;
    }
    iRet = RdStg_Mp4Muxer_ReadInfo(hMp4File,puiDuration);
    if(iRet == MOS_ERR){
        MOS_LOG_ERR(RDSTG_LOGSTR,"read media info to fix err");
        RdStg_Mp4Muxer_CloseFile(hMp4File,0);
        return iRet;
    }
    if(uiFrameRate > 60)
        RdStg_Mp4Muxer_CloseFile(hMp4File,15);
    else
        RdStg_Mp4Muxer_CloseFile(hMp4File,uiFrameRate);
    MOS_LOG_INF(RDSTG_LOGSTR,"iRet = %d",iRet);
    return iRet;
}

_INT RdStg_AddCompatibleDate(_UC *pucDate,_INT iCamId)
{
    MOS_PARAM_NULL_RETERR(pucDate);

    _HFILE hFile;
    _INT iRet  = 0;
    _INT iSize = sizeof(ST_RDSTG_DATE);
    _UC aucVersion[20]={0};
    _UC aucFileName[256];
    ST_RDSTG_DATE stDateInf;

    if(MOS_STRLEN(RdStg_GetMng()->aucCachePath)==0)
    {
        return MOS_OK;
    }

    MOS_VSNPRINTF(aucFileName,256,"%s/%d",RdStg_GetMng()->aucCachePath,iCamId);
    if(Mos_DirIsExist(RdStg_GetMng()->aucCachePath) == MOS_FALSE){
        Mos_DirMake(aucFileName,MOS_DIR_MAKE_FLAG);
    }

    MOS_VSNPRINTF(aucFileName,256,"%s/%s",aucFileName,RDSTG_DATECFG_NAME);

    if(Mos_FileIsExist(aucFileName)==MOS_FALSE)
    {
        Mos_FileWriteAppend(aucFileName,(_UC*)RDSTG_DATECFG_VERSION,MOS_STRLEN(RDSTG_DATECFG_VERSION));
    }

    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);

    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(RDSTG_DATECFG_VERSION));

    if(MOS_STRCMP(aucVersion,RDSTG_DATECFG_VERSION)){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(RDSTG_LOGSTR,"Record date file version error");
        return MOS_ERR;
    }
    while(Mos_FileEof(hFile) == MOS_FALSE)
    {
        iRet=Mos_FileRead(hFile,(_UC*)&stDateInf,iSize);
        if(iRet > 0 && iRet < iSize)
        {
            stDateInf.ucBInUse = 0;
            stDateInf.ucCheck = '$';
            Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iRet);
            Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
            break;
        }
    }
    stDateInf.ucCheck = '$';
    stDateInf.ucBInUse = 1;
    stDateInf.ucRsv[1] = 1;

    MOS_VSNPRINTF(aucFileName,256,"%s/%d/%s",RdStg_GetMng()->aucCachePath,iCamId,pucDate);
    if(Mos_DirIsExist(aucFileName) == MOS_FALSE){
        Mos_DirMake(aucFileName,MOS_DIR_MAKE_FLAG);
    }
    if(MOS_STRCMP(pucDate,stDateInf.aucDate) == 0)
    {
        Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iSize);
        Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
    }
    else
    {
        MOS_STRNCPY(stDateInf.aucDate,pucDate,sizeof(stDateInf.aucDate));
        Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
    }
    RdStg_GetMng()->uiCurrentSeq = 0;
    Mos_FileClose(hFile);
    return MOS_OK;
}

_INT RdStg_AddCompatibleFile(_UC *pucDate,_INT iCamId,_UC *pucFilePath,_UI uiStartUnixTime,_UI uiEndUnixTime,_UI uiStartTime,_UI uiEndTime)
{
    MOS_PARAM_NULL_RETERR(pucDate);
    MOS_PARAM_NULL_RETERR(pucFilePath);

    _UC aucFileName[256];
    ST_RDSTG_FILEDES stFileDes;
    ST_RDSTG_MAP_INF stMapDes;
    _INT iSize = sizeof(ST_RDSTG_FILEDES);

    Mos_MutexLock(&RdStg_GetMng()->hMutex);
    MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,iCamId,pucDate,RDSTG_FILEDESCFG_NAME);

    if(Mos_FileIsExist(aucFileName) == MOS_FALSE){
        Mos_FileSave(aucFileName, RDSTG_FILEDESCFG_VERSION, MOS_STRLEN(RDSTG_FILEDESCFG_VERSION));
    }
    if(RdStg_GetMng()->uiCurrentSeq == 0)
    {
        _HFILE hFile = MOS_NULL;
        hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN | MOS_FILE_O_RDONLY);
        if(hFile == MOS_NULL)
        {
            Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
            return MOS_ERR;
        }
        Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iSize);
        Mos_FileRead(hFile,(_UC*)&stFileDes,iSize);
        if(stFileDes.ucCheck == '$')
            RdStg_GetMng()->uiCurrentSeq = stFileDes.uiFileSeq;
        Mos_FileClose(hFile);
    }
#ifdef USER_RD_EXTERN_FILEDES
	stFileDes.uiStreamId          = 0;
    stFileDes.uiAudioEncType      = 2;
    stFileDes.uiVideoEncType      = 2;
    stFileDes.uiVideoWidth        = 1920;
    stFileDes.uiVideoHeight       = 1080;
    stFileDes.uiVideoFrameRate    = 15;
#endif

    stFileDes.cStartTime          = uiStartUnixTime;
    stFileDes.cStopTime           = uiEndUnixTime;
    stFileDes.uiStartTimeStamp    = uiStartTime;
    stFileDes.uiEndTimeStamp      = uiEndTime;
    stFileDes.ucRsv               = 1;
    stFileDes.ucBCover            = 0;
    stFileDes.ucCheck             = '$';
    stFileDes.ucBInUse            = 1;
    stFileDes.uiFileSeq           = ++RdStg_GetMng()->uiCurrentSeq;
    Mos_MutexUnLock(&RdStg_GetMng()->hMutex);
    if(Mos_FileWriteAppend(aucFileName,(_UC*)&stFileDes, iSize) == MOS_FALSE){
        MOS_LOG_ERR(RDSTG_LOGSTR,"write file %s fail errno = %u",aucFileName,errno);
        return MOS_ERR;
    }

    iSize = sizeof(ST_RDSTG_MAP_INF);
    MOS_VSNPRINTF(aucFileName, 255, "%s/%d/%s/%s",RdStg_GetMng()->aucCachePath,iCamId,pucDate,RDSTG_MAPPING_NAME);
    stMapDes.uiDataSeq = stFileDes.uiFileSeq;
    MOS_STRNCPY(stMapDes.aucFileMap,pucFilePath,sizeof(stMapDes.aucFileMap));
    if(Mos_FileWriteAppend(aucFileName,(_UC*)&stMapDes, iSize) == MOS_FALSE){
        MOS_LOG_ERR(RDSTG_LOGSTR,"write file map seq %u path %s fail errno = %u",stMapDes.uiDataSeq,stMapDes.aucFileMap,errno);
        return MOS_ERR;
    }
    return MOS_OK;
}

_INT RdStg_GetRecordFileList(_UC *pucPlaybackFileStartTime)
{
    int count           = 0;
    _UI uiDuration      = 0;
    _UC aucBuff[32]     = {0};
    _UC ucPlayTime[32]  = {0};
    _UC ucFileListStartTime[32]  = {0};
    ST_MOS_SYS_TIME stSysTime ;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST *pstAxisList = MOS_NULL;
    ST_RDSTG_FILEDESNODE *pstFileDesNode = MOS_NULL;

    #if 1
    Mos_GetSysTime(&stSysTime); 
    MOS_VSNPRINTF(ucFileListStartTime, 32, "%04u-%02u-%02u 00:00:00",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay); 
    #else
    MOS_VSNPRINTF(ucFileListStartTime, 32, "%04u-%02u-%02u 00:00:00",2021,02,01); 
    #endif
    MOS_LOG_INF(RDSTG_LOGSTR,"ucFileListStartTime %s ", ucFileListStartTime);

    // 通过page查询卡录像文件列表 通过信令调用 (卡录像查询入口)
    pstAxisList = RdStg_GetFileListByPage(0 ,ucFileListStartTime ,10);

    int RecordFileNum = MOS_LIST_GETCOUNT(pstAxisList);
    MOS_LOG_INF(RDSTG_LOGSTR,"------- RecordFileNum: %d -------------", RecordFileNum);

    FOR_EACHDATA_INLIST(pstAxisList, pstFileDesNode, stIterator)
    {
        // Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"FileID",Adpt_Json_CreateStrWithNum(pstFileDesNode->stFileDes.uiFileSeq));
        MOS_LOG_INF(RDSTG_LOGSTR,"------- FileID[%d]: %d -------------", count, pstFileDesNode->stFileDes.uiFileSeq);

        Mos_TimetoSysTime(&pstFileDesNode->stFileDes.cStartTime,&stSysTime); 
        MOS_SPRINTF(aucBuff, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
            stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
        // Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"SrcTime",Adpt_Json_CreateString(aucBuff));
        MOS_LOG_INF(RDSTG_LOGSTR,"------- SrcTime[%d]: %s -------------", count, aucBuff);

        if(pstFileDesNode->stFileDes.cStopTime > pstFileDesNode->stFileDes.cStartTime)
        {
            uiDuration = (_UI)(pstFileDesNode->stFileDes.cStopTime- pstFileDesNode->stFileDes.cStartTime);
            if(uiDuration == 0)
            {
                uiDuration = 1;
            }
            // Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDuration));
            MOS_LOG_INF(RDSTG_LOGSTR,"------- uiDuration[%d]: %d -------------", count, uiDuration);
        }
        else
        {
            uiDuration = (pstFileDesNode->stFileDes.uiEndTimeStamp - pstFileDesNode->stFileDes.uiStartTimeStamp)/1000;
            if(uiDuration == 0)
            {
                uiDuration = 1;
            }
            // Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDuration));
            MOS_LOG_INF(RDSTG_LOGSTR,"------- SrcTime[%d]: %d -------------", count, uiDuration);
        }
        MOS_LIST_RMVNODE(pstAxisList, pstFileDesNode);
        MOS_FREE(pstFileDesNode);
        if (count == 0)
        {
            strcpy(ucPlayTime, aucBuff);
            strcpy(pucPlaybackFileStartTime, aucBuff);
        }
        count++;
    }
    return 0;
}

_RDFILEFD *RdStg_OpenPlayBackFile(_UC *pucPlaybackFileStartTime, _INT *piAdjustTime, _UC ucPlayMode)
{
    MOS_PARAM_NULL_RETERR(piAdjustTime);
    MOS_PARAM_NULL_RETERR(pucPlaybackFileStartTime);


    _RDFILEFD *pstRdStg_fileFD = MOS_NULL;
    ST_RDSTG_READER_NODE *pstReader = MOS_NULL; 
    MOS_LOG_INF(RDSTG_LOGSTR,"file name ucPlayTime %s", pucPlaybackFileStartTime);
    
    // 打开录像文件
    pstRdStg_fileFD = RdStg_OpenFile(0, pucPlaybackFileStartTime, piAdjustTime);
    if (pstRdStg_fileFD == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"pstRdStg_fileFD == MOS_NULL");
        return MOS_NULL;
    }
    else
    {
       pstReader  =  (ST_RDSTG_READER_NODE *)pstRdStg_fileFD; 
       pstReader->ucPlayMode = ucPlayMode;
       MOS_LOG_INF(RDSTG_LOGSTR,"pstRdStg_fileFD RdStg_OpenFile END");
    }

    return pstRdStg_fileFD;
}

_INT RdStg_ClosePlayBackFile(_RDFILEFD *hHandle)
{
    MOS_PARAM_NULL_RETERR(hHandle);

    _INT ret = 0;

    ret = RdStg_CloseFile(hHandle);
    if (ret != MOS_OK)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"RdStg_CloseFile PlayBack File Failed !!!");
        return MOS_ERR;
    }

    MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_CloseFile PlayBack File Successful !!!");
    return MOS_OK;
}

// 读取录像数据流
_INT RdStg_ReadPlayBackFile(_RDFILEFD *pstRdStg_fileFD, _UC *pucBuf, _UI *puiBufLen, _UC *pucAVFlag, _UI *puiTimeStamp,
                            _UC *pucFramePos, _UI *puiFrameLen)
{
    MOS_PARAM_NULL_RETERR(pucBuf);
    if (pstRdStg_fileFD == MOS_NULL)
    {
        return MOS_ERR;
    }

    _INT  ret = 0;
    *puiBufLen = 0;
    ret = RdStg_ReadData(pstRdStg_fileFD, pucBuf, puiBufLen, pucAVFlag, puiTimeStamp, pucFramePos , puiFrameLen);
    if (ret < 0)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"RdStg_ReadData failed");
        if (ret == MOS_ERR_FILEFINISH)
        {
            *puiBufLen = 0;
            return MOS_ERR_FILEFINISH;
        }
        else if (ret == MOS_ERR_FILEEND)
        {
            MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_ReadData MOS_ERR_FILEEND");
            return MOS_ERR;
        }
        return MOS_ERR;
    }
    else
    {
        if (Mos_FileIsExist("/tmp/debug_playback") == MOS_TRUE)
        MOS_PRINTF("puiBufLen:%d AVFLAG:%d timestamp:%u pos:%2x len:%u \r\n",
                   *puiBufLen, *pucAVFlag, *puiTimeStamp , *pucFramePos , *puiFrameLen);
        if (pucBuf != MOS_NULL)
        {
//            if (*puiBufLen < 20)
//            {
//                MOS_BUFPRINTF("MP4 pucBuf", (_UC *)pucBuf, *puiBufLen);
//            }
//            else
//            {
//                MOS_BUFPRINTF("MP4 pucBuf", (_UC *)pucBuf, 20);
//            }
        }
        else
        {
 //           MOS_LOG_ERR(RDSTG_LOGSTR,"pucBuf == MOS_NULL");
            return MOS_ERR;
        }
    }
    return MOS_OK;
}

_INT RdStg_PlayBackFunc(_UC *pucPlaybackFileStartTime)
{
    _INT iAdjustTime = 0;
    _RDFILEFD *pstRdStg_fileFD;
    ST_RDSTG_READER_NODE *pstReader = MOS_NULL; 
    MOS_LOG_INF(RDSTG_LOGSTR,"file name ucPlayTime %s", pucPlaybackFileStartTime);
    
    // 打开录像文件
    pstRdStg_fileFD = RdStg_OpenFile(0, pucPlaybackFileStartTime, &iAdjustTime);
    if (pstRdStg_fileFD == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"pstRdStg_fileFD == MOS_NULL");
    }
    else
    {
       pstReader  =  (ST_RDSTG_READER_NODE *)pstRdStg_fileFD; 
       MOS_LOG_INF(RDSTG_LOGSTR,"pstRdStg_fileFD RdStg_OpenFile END");
    }

    // 读取录像数据流
     _UC ucBuf[1400]    = {0};
    _UI  uiBufLen       = 0;
    _UC  ucAVFlag       = 0;
    _UI  uiTimeStamp    = 0;
    _UC  ucFramePos     = 0;
    _UI  uiFrameLen     = 0;
    _INT ret            = 0;

    #if 0
    // 打开存储读取出来的录像文件内容的文件
    // pstMefcMp4DeMuxer->hFileHandle = Mos_FileOpen(pucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    FILE *mp4_fd = fopen("./playback.h264", "wb");
    // FILE *mp4_fd = fopen("/mnt/sdcard/playback.h264", "wb");
    if (MOS_NULL == mp4_fd)
    {
        MOS_LOG_ERR(RDSTG_LOGSTR,"MOS_NULL == mp4_fd");
    }
    #endif

    while(RdStg_GetMng()->ucInitFlag)
    {
        ret = RdStg_ReadData(pstRdStg_fileFD, ucBuf, &uiBufLen, &ucAVFlag, &uiTimeStamp, &ucFramePos , &uiFrameLen);
        if (ret < 0)
        {
            MOS_LOG_ERR(RDSTG_LOGSTR,"RdStg_ReadData failed");
            if (ret == MOS_ERR_FILEEND)
            {
                MOS_LOG_INF(RDSTG_LOGSTR,"RdStg_ReadData MOS_ERR_FILEEND");
                break;
            }
        }
        else
        {
            MOS_LOG_INF(RDSTG_LOGSTR,"uiBufLen:    %d", uiBufLen);
            MOS_LOG_INF(RDSTG_LOGSTR,"ucAVFlag:    %d", ucAVFlag);
            MOS_LOG_INF(RDSTG_LOGSTR,"uiTimeStamp: %d", uiTimeStamp);
            MOS_LOG_INF(RDSTG_LOGSTR,"ucFramePos:  %d", ucFramePos);
            MOS_LOG_INF(RDSTG_LOGSTR,"uiFrameLen:  %d", uiFrameLen);
            if (ucBuf != MOS_NULL)
            {
                MOS_BUFPRINTF("MP4 ucBuf", (_UC *)ucBuf, 20);
            }
            else
            {
                MOS_LOG_ERR(RDSTG_LOGSTR,"pucBuf == MOS_NULL");
            }
            #if 0
            ret = fwrite(ucBuf, uiBufLen, 1, mp4_fd);
            if (ret < 0)
            {
                MOS_LOG_ERR(RDSTG_LOGSTR,"fwrite error");
            }
            #endif
        }

        Mos_Sleep(50);
    }
    #if 0
    fclose(mp4_fd);
    #endif
    return 0;
} 
