#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_type.h"
#include "media_cache_type.h"
#include "record_mp4.h"
#include "record_mp4_prv.h"
#include "adpt_parsesps.h"
#include "record_Hevc.h"
#include "mos_log.h"
#define MP4MUXER_NODE_NUM  16
#define MEFC_MP4MUXER_LOG_ID "RD"

typedef struct
{
    _UC ucInitFlag;
    _UC ucReSampleFlag;
    _UC ucRsv[2];
    _UC aucMatrix[36];
    _HMUTEX hMutex;
    ST_RDSTG_MP4MUXER *apMp4Muxer[MP4MUXER_NODE_NUM];
}ST_RDSTG_MP4MUXER_MNG;

static ST_RDSTG_MP4MUXER_MNG g_stMdmuxerMng;

static ST_RDSTG_MP4MUXER_MNG *RdStg_GetMp4MuxerMng()
{
    return &g_stMdmuxerMng;
}

// MP4编码初始化
_INT RdStg_Mp4Muxer_Init()
{
    if(RdStg_GetMp4MuxerMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(MEFC_MP4MUXER_LOG_ID, "have init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stMdmuxerMng, 0, sizeof(ST_RDSTG_MP4MUXER_MNG));
    if(Mos_MutexCreate(&RdStg_GetMp4MuxerMng()->hMutex) != MOS_OK)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID, "create lock");
        return MOS_ERR;
    }
    RdStg_GetMp4MuxerMng()->aucMatrix[1]  = 1;
    RdStg_GetMp4MuxerMng()->aucMatrix[17] = 1;
    RdStg_GetMp4MuxerMng()->aucMatrix[32] = 0x40;
    RdStg_GetMp4MuxerMng()->ucInitFlag = 1;
    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID, "mp4 muxer init ok");
    return MOS_OK;
}

// MP4编码去初始化
_INT RdStg_Mp4Muxer_Destory()
{
    _UI i = 0;
    if(RdStg_GetMp4MuxerMng()->ucInitFlag == 0){
        MOS_LOG_WARN(MEFC_MP4MUXER_LOG_ID, "not init");
        return MOS_OK;
    }
    Mos_MutexLock(&RdStg_GetMp4MuxerMng()->hMutex);
    for(i= 0; i < MP4MUXER_NODE_NUM; i++){
        if(RdStg_GetMp4MuxerMng()->apMp4Muxer[i] != MOS_NULL)
            MOS_FREE(RdStg_GetMp4MuxerMng()->apMp4Muxer[i]);
    }
    Mos_MutexUnLock(&RdStg_GetMp4MuxerMng()->hMutex);
    Mos_MutexDelete(&RdStg_GetMp4MuxerMng()->hMutex);
    RdStg_GetMp4MuxerMng()->ucInitFlag = 0;
    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID, "mp4 muxer destory ok");
    return MOS_OK;
}

// 将数据写入录像文件MP4
static _INT RdStg_Mp4Muxer_FwriteCache(ST_RDSTG_MP4MUXER* pstMp4Muxer,_VOID *pBuf, _UI uiSize)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(pBuf);

    _INT iRetlen  = 0;
    if(pstMp4Muxer->hFileHandle == MOS_NULL)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID, "task[%p] hFileHandle is null",pstMp4Muxer);
        return MOS_ERR;
    }
    pstMp4Muxer->uiErrCode = 0;
    iRetlen = Mos_FileWrite(pstMp4Muxer->hFileHandle, pBuf,uiSize);
    if( iRetlen > 0)
    {
        return MOS_OK;
    }
    pstMp4Muxer->uiErrCode = errno;
    MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] hFileHandle[%p] write data error %d", 
                                     pstMp4Muxer, pstMp4Muxer->hFileHandle,pstMp4Muxer->uiErrCode);
    Mos_FileClose(pstMp4Muxer->hFileHandle);
    pstMp4Muxer->hFileHandle = NULL;
    return MOS_ERR;
}

// 初始化MP4编码信息结构体
static _VOID  RdStg_Mp4Muxer_InitMp4Muxer(ST_RDSTG_MP4MUXER* pstMp4Muxer)
{
    MOS_PARAM_NULL_NORET(pstMp4Muxer);

    MOS_MEMSET(pstMp4Muxer,0,sizeof(ST_RDSTG_MP4MUXER));
    MOS_MEMCPY(pstMp4Muxer->stts_v.name, "stts",4);
    MOS_MEMCPY(pstMp4Muxer->stss_v.name, "stss",4);
    MOS_MEMCPY(pstMp4Muxer->stsc_v.name, "stsc",4);
    MOS_MEMCPY(pstMp4Muxer->stsz_v.name, "stsz",4);
    MOS_MEMCPY(pstMp4Muxer->stco_v.name, "stco",4);

    MOS_MEMCPY(pstMp4Muxer->stts_a.name, "stts",4);
    MOS_MEMCPY(pstMp4Muxer->stsc_a.name, "stsc",4);
    MOS_MEMCPY(pstMp4Muxer->stsz_a.name, "stsz",4);
    MOS_MEMCPY(pstMp4Muxer->stco_a.name, "stco",4);
    pstMp4Muxer->uiOffset          = 0x20;
    pstMp4Muxer->uiTps             = 600;
    pstMp4Muxer->usSampleSize      = 16;
    pstMp4Muxer->uiVideoFps        = 15;
    pstMp4Muxer->uiPrevTimeStamp   = 0;
}

// 写MP4录像文件的头
static _INT RdStg_Mp4Muxer_WriteMp4Ftyp(ST_RDSTG_MP4MUXER* pstMp4Muxer)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);

    // ftyp BOX
    char bufftyp[24] = {0x00, 0x00, 0x00, 0x18, 0x66, 0x74, 0x79, 0x70,
                        0x69, 0x73, 0x6f, 0x6d, 0x00, 0x00, 0x00, 0x01,
                        0x69, 0x73, 0x6f, 0x6d, 0x61, 0x76, 0x63, 0x31};
    // mdat BOX
    char bufmdat[8] = {0x00, 0x00, 0x00, 0x00, 0x6d, 0x64, 0x61, 0x74};

    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,bufftyp, 24) != MOS_OK){
        return -5;
    }

    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,bufmdat, 8) != MOS_OK){
        return -5;
    }
    return 32;
}

// 申请MP4配置节点
static ST_RDSTG_MP4MUXER* RdStg_Mp4Muxer_AllocNode()
{
    _UI i = 0;
	ST_RDSTG_MP4MUXER *pstMp4Muxer = MOS_NULL;
    Mos_MutexLock(&RdStg_GetMp4MuxerMng()->hMutex);

     for(i = 0; i < MP4MUXER_NODE_NUM; i++)
     {
        if(RdStg_GetMp4MuxerMng()->apMp4Muxer[i] == MOS_NULL)
        {
            RdStg_GetMp4MuxerMng()->apMp4Muxer[i] = (ST_RDSTG_MP4MUXER*)MOS_MALLOC(sizeof(ST_RDSTG_MP4MUXER));
            pstMp4Muxer = RdStg_GetMp4MuxerMng()->apMp4Muxer[i];
            break;
        }
        else if(RdStg_GetMp4MuxerMng()->apMp4Muxer[i]->ucIsUsing == 0)
        {
            pstMp4Muxer = RdStg_GetMp4MuxerMng()->apMp4Muxer[i] ;
            break;
        }
    }
    if(pstMp4Muxer)
    {
        // 初始化MP4编码信息结构体
        RdStg_Mp4Muxer_InitMp4Muxer(pstMp4Muxer);
        pstMp4Muxer->uiUserId  = i + MP4MUXER_NODE_NUM;
        pstMp4Muxer->ucIsUsing = 1;
    }
    Mos_MutexUnLock(&RdStg_GetMp4MuxerMng()->hMutex);
    return pstMp4Muxer;
}

// H265解码配置初始化
static void RdStg_hvcc_init(ST_HEVC_DECODERCFG_RECORDPARTY *psthvcc)
{
    MOS_PARAM_NULL_NORET(psthvcc);

    MOS_MEMSET(psthvcc, 0, sizeof(ST_HEVC_DECODERCFG_RECORDPARTY));
    psthvcc->configurationVersion = 1;
    psthvcc->lengthSizeMinusOne   = 3; // 4 bytes
    psthvcc->general_profile_compatibility_flags = 0xffffffff;
    psthvcc->general_constraint_indicator_flags  = 0xffffffffffff;
    psthvcc->min_spatial_segmentation_idc = MAX_SPATIAL_SEGMENTATION + 1;
    return;
}

// 记录当前录像的MP4文件的信息 返回userid
_HMP4MUXER RdStg_Mp4Muxer_OpenFile(_UC *pucFilename,_UI uiVideoType, _UI usWidth, _UI usHeight)
{
    MOS_PARAM_NULL_RETNULL(pucFilename);

    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"pucFilename %s  uiVideoType:%d usWidth:%d usHeight:%d", pucFilename, uiVideoType, usWidth, usHeight);

    // 申请MP4配置节点
    ST_RDSTG_MP4MUXER*pstMp4Muxer = RdStg_Mp4Muxer_AllocNode();
    if(pstMp4Muxer == MOS_NULL)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"mp4 muxer have full");
        return MOS_NULL;
    }

    if(EN_ZJ_VIDEOENC_TYPE_H265 == uiVideoType)
    {
        pstMp4Muxer->ucHevcFlag  = 1;
    }
    else{
        pstMp4Muxer->ucHevcFlag  = 0;
    }

    // H265解码配置初始化
    RdStg_hvcc_init(&pstMp4Muxer->stHecvRecordParty);
    pstMp4Muxer->uiAudioType = EN_ZJ_AUDIOENC_TYPE_AAC;
    MOS_STRNCPY(pstMp4Muxer->aucFileName,pucFilename,sizeof(pstMp4Muxer->aucFileName));
    pstMp4Muxer->usWidth  = usWidth;
    pstMp4Muxer->usHeight = usHeight;

    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"tast[%p] taskid[%u] filename[%s] HevcFlag %u", 
        pstMp4Muxer, pstMp4Muxer->uiUserId, pucFilename,pstMp4Muxer->ucHevcFlag);
    return (_HMP4MUXER)(pstMp4Muxer->uiUserId);
}

// 修改已打开的文件
_HMP4MUXER RdStg_Mp4Repair_OpenFile(_UC *pucFileName)
{
    MOS_PARAM_NULL_RETNULL(pucFileName);

    _UC aucSubName[256];
    ST_RDSTG_MP4MUXER *pstMp4Muxer      = RdStg_Mp4Muxer_AllocNode();
    ST_CFG_VIDEODES *pstVideoDes     = Config_GetVideoDes(0,0);
    ST_ZJ_AUDIO_PARAM *pstAudioParam = Config_GetCamAudioParm(0);

    if(pstMp4Muxer == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_MP4LOG,"mp4 muxer have full");
        return MOS_NULL;
    }

    // H265解码配置初始化
    RdStg_hvcc_init(&pstMp4Muxer->stHecvRecordParty);
    MOS_SSCANF(pucFileName,"%[^.]",aucSubName);
    MOS_VSNPRINTF(aucSubName,256,"%s.inf",aucSubName);
    
    //原有的句柄要先关闭
    if(pstMp4Muxer->hFileHandle != MOS_NULL)
    {
        MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"hFileHandle is not NULL ,now close it");
        Mos_FileClose(pstMp4Muxer->hFileHandle);
        pstMp4Muxer->hFileHandle = MOS_NULL;
    }
    if(pstMp4Muxer->hSubFileHandle != MOS_NULL)
    {
        MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"hSubFileHandle is not NULL ,now close it");
        Mos_FileClose(pstMp4Muxer->hSubFileHandle);
        pstMp4Muxer->hSubFileHandle = MOS_NULL;
    }
    pstMp4Muxer->hFileHandle = Mos_FileOpen(pucFileName,MOS_FILE_O_BIN | MOS_FILE_O_RDWR);
    pstMp4Muxer->hSubFileHandle = Mos_FileOpen(aucSubName,MOS_FILE_O_BIN | MOS_FILE_O_RDONLY);
    MOS_STRNCPY(pstMp4Muxer->aucSubName,aucSubName,sizeof(pstMp4Muxer->aucSubName));
    MOS_STRNCPY(pstMp4Muxer->aucFileName,pucFileName,sizeof(pstMp4Muxer->aucFileName));

    return (_HMP4MUXER)(pstMp4Muxer->uiUserId);
}

// 根据UserID获取录像文件信息
ST_RDSTG_MP4MUXER* RdStg_Mp4Muxer_GetMp4MuxerById(_UI uiUserId)
{
    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_GetMp4MuxerMng()->apMp4Muxer[uiUserId % MP4MUXER_NODE_NUM];
    if((pstMp4Muxer == MOS_NULL) || (pstMp4Muxer->ucIsUsing == 0) || (pstMp4Muxer->uiUserId != uiUserId))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"tast[%p] taskid[%u] not found",pstMp4Muxer, uiUserId);
        return MOS_NULL;
    }
    return pstMp4Muxer;
}

// 设置ReSample Flag
_VOID RdStg_Mp4Muxer_SetReSample(_UI uiFlag)
{
    RdStg_GetMp4MuxerMng()->ucReSampleFlag = uiFlag;
    return;
}

// 记录MP4录像文件的音频信息
_INT RdStg_Mp4Muxer_SetAudioType(_HMP4MUXER hHandle,ST_ZJ_AUDIO_PARAM *pstAudioDes)
{
    MOS_PARAM_NULL_RETERR(pstAudioDes);

    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL)
    {
        return -1;
    }
    if(pstMp4Muxer->ucIsSetAudioType == 1)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"tast[%p] audiotype[%d] have set",pstMp4Muxer, pstAudioDes->uiEncodeType);
        return 0;
    }

    pstMp4Muxer->uiAudioType    = pstAudioDes->uiEncodeType;
    pstMp4Muxer->usSampleSize   = pstAudioDes->uiDepth;
    pstMp4Muxer->uiSampleRate   = pstAudioDes->uiSampleRate;
    pstMp4Muxer->usChannelCount = pstAudioDes->uiChannel;
    if(pstAudioDes->uiEncodeType == EN_ZJ_AUDIOENC_TYPE_G711A || pstAudioDes->uiEncodeType <= EN_ZJ_AUDIOENC_TYPE_G711U)
    {
        pstMp4Muxer->usSampleSize   = 16;
        pstMp4Muxer->uiSampleRate   = 8000;
        pstMp4Muxer->usChannelCount = 1;
    }
    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"tast[%p] audiotype[%d] set ok",pstMp4Muxer, pstAudioDes->uiEncodeType);
    pstMp4Muxer->ucIsSetAudioType   = 1;
    return 1;
}

// 记录MP4录像文件的视频信息
_INT RdStg_Mp4Muxer_SetCircleInf(_HMP4MUXER hHandle,ST_ZJ_VIDEO_CIRCLE *pstCircle)
{
    MOS_PARAM_NULL_RETERR(pstCircle);

    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL)
    {
        return MOS_ERR;
    }
    MOS_MEMCPY(&pstMp4Muxer->stCircle, pstCircle, sizeof(ST_ZJ_VIDEO_CIRCLE));
    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"tast[%p] ST_ZJ_VIDEO_CIRCLE set ok",pstMp4Muxer);
    
    return MOS_OK;
}

// 记录MP4的 Stts_v(每一帧的持续时间) 结构体信息 
static _VOID RdStg_Mp4Muxer_WriteVideoStts(ST_RDSTG_MP4MUXER* pstMp4Muxer, _UI uiTimeStamp)
{ 
    MOS_PARAM_NULL_NORET(pstMp4Muxer);

    _UI time_now = 0;
    _INT time_temp = 0;
    pstMp4Muxer->uiEndTimeStamp = uiTimeStamp;
    if(pstMp4Muxer->uiVideoCnt < 2)
    {
        if(pstMp4Muxer->uiVideoCnt == 0)
        {
            pstMp4Muxer->uiVideoDuration = 0;
            pstMp4Muxer->uiTimestampBase = uiTimeStamp;
            pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0] = 0;
            pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][1] = 0;
        }
        else
        {
            pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0] = 1;
            pstMp4Muxer->uiPrevTimeStamp = (uiTimeStamp - pstMp4Muxer->uiTimestampBase)*pstMp4Muxer->uiTps / 1000;
            
            if(pstMp4Muxer->uiPrevTimeStamp < 3600*pstMp4Muxer->uiTps)
            {
                pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][1] = pstMp4Muxer->uiPrevTimeStamp;
            }
            else
            {
                pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][1] = pstMp4Muxer->uiTps * 40 / 1000;
            }
        }
    }
    else
    {
        time_temp = uiTimeStamp - pstMp4Muxer->uiTimestampBase;
        
        time_now = time_temp/1000 * pstMp4Muxer->uiTps + time_temp%1000 * pstMp4Muxer->uiTps / 1000;
        time_temp = time_now - pstMp4Muxer->uiPrevTimeStamp;
        if((time_temp > SAFE_INT(pstMp4Muxer->uiTps * 3600)) || (time_temp < 0))
        {
            time_temp = pstMp4Muxer->uiTps * 40 / 1000;
        }
        
        if(time_temp == pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][1])
        {
            pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0]++;
        }
        else
        {
            pstMp4Muxer->stts_v.num++;
            pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0] = 1;
            pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][1] = time_temp;
        }
        pstMp4Muxer->uiPrevTimeStamp = time_now;
    }
    pstMp4Muxer->uiVideoDuration += pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][1];
}


_INT RdStg_Mp4Muxer_ReadCnf(_HMP4MUXER hHandle,_UI *puiFrameRate)
{
    MOS_PARAM_NULL_RETERR(puiFrameRate);

    _UI uiVideoEnc = 0;
    ST_RDSTG_MP4MUXER* pstMp4muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    
    if(pstMp4muxer->hSubFileHandle == MOS_NULL)
    {
        return MOS_ERR;
    }
    if((Mos_FileSize(pstMp4muxer->hSubFileHandle)) < 24)
    {
        return MOS_ERR;
    }
    Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->usHeight),2);
    Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->usWidth),2);
    Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&uiVideoEnc,4);
    Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->uiVideoFps),4);
    Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->uiAudioType),4);
    Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->usChannelCount),2);
    Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->usSampleSize),2);
    Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->uiSampleRate),4);
    pstMp4muxer->usHeight = Mos_InetNtohs(pstMp4muxer->usHeight);
    pstMp4muxer->usWidth = Mos_InetNtohs(pstMp4muxer->usWidth);
    uiVideoEnc = Mos_InetNtohl(uiVideoEnc);

    if(uiVideoEnc == EN_ZJ_VIDEOENC_TYPE_H265)
    {
        pstMp4muxer->ucHevcFlag = 1;
    }
    else
    {
        pstMp4muxer->ucHevcFlag = 0;
    }

    pstMp4muxer->uiVideoFps = Mos_InetNtohl(pstMp4muxer->uiVideoFps);
    *puiFrameRate = pstMp4muxer->uiVideoFps;
    pstMp4muxer->uiAudioType = Mos_InetNtohl(pstMp4muxer->uiAudioType);
    pstMp4muxer->usChannelCount = Mos_InetNtohs(pstMp4muxer->usChannelCount);
    pstMp4muxer->usSampleSize = Mos_InetNtohs(pstMp4muxer->usSampleSize);
    pstMp4muxer->uiSampleRate = Mos_InetNtohl(pstMp4muxer->uiSampleRate);

    do{
        Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->stco_a.data[pstMp4muxer->stco_a.num++]),4);
        Mos_FileRead(pstMp4muxer->hSubFileHandle,(_UC*)&(pstMp4muxer->stsz_a.data[pstMp4muxer->stsz_a.num++]),4);
    }while(Mos_FileEof(pstMp4muxer->hSubFileHandle) == MOS_FALSE);

    pstMp4muxer->uiOffset = 32;

    return MOS_OK;
}

// 修改MP4文件的Mdat的box 24个字节后 大小：8字节
static _INT RdStg_Mp4Muxer_RepairMdat(ST_RDSTG_MP4MUXER* pstMp4muxer,_UI *puiMdatLen,_UI uiOffSet,_UI *puiDuration)
{
    MOS_PARAM_NULL_RETERR(pstMp4muxer);
    MOS_PARAM_NULL_RETERR(puiMdatLen);

    Mos_FileSeek(pstMp4muxer->hFileHandle,MOS_FILE_SEEK_BEGIN,24);
    *puiMdatLen = Mos_InetHtonl(uiOffSet - 24);
    Mos_FileWrite(pstMp4muxer->hFileHandle,(_UC*)puiMdatLen,4);
    Mos_FileSeek(pstMp4muxer->hFileHandle,MOS_FILE_SEEK_BEGIN,uiOffSet);
    pstMp4muxer->uiOffset = uiOffSet;
    if(puiDuration != MOS_NULL)
    {
        *puiDuration = pstMp4muxer->uiEndTimeStamp;
    }
    return MOS_OK;
}

_INT RdStg_Mp4Muxer_ReadInfo(_HMP4MUXER hHandle, _UI *puiDuration)
{
    _INT iReadSize = 0;
    _UI uiOffSet = 0,uiLastVideoOffSet = 0;
    _UI uiEndOffSet = 0;
    _UI uiNaluLen = 0,uiFrameTmpLen = 0;
    _UI uiMdatLen = 0;
    _UI uiVideoTimeStamp = 0,uiAudioTimeStamp = 0;
    _UC ucAvFlag = 0;
    _UC aucBuf[256];
    _UC aucWritePos[8];
    _UC ucFrameType = 0,ucLastFrameType = 0;
    ST_RDSTG_MP4MUXER* pstMp4muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    uiEndOffSet = Mos_FileSize(pstMp4muxer->hFileHandle);
    MOS_MEMSET(aucWritePos,0,8);
    MOS_MEMSET(aucBuf,0,256);

    if(pstMp4muxer == MOS_NULL )
    {
        return -1;
    }
    pstMp4muxer->uiVideoCnt = 0;
    pstMp4muxer->uiAudioCnt = 0;
    Mos_FileSeek(pstMp4muxer->hFileHandle,MOS_FILE_SEEK_BEGIN,pstMp4muxer->uiOffset);
    uiOffSet = Mos_FileTell(pstMp4muxer->hFileHandle);

    while(pstMp4muxer->uiAudioCnt < MAXFRAME - 1 && pstMp4muxer->uiVideoCnt < MAXFRAME - 1)
    {
        iReadSize = Mos_FileRead(pstMp4muxer->hFileHandle,aucWritePos, 8);
        if(uiOffSet == Mos_InetNtohl(pstMp4muxer->stco_a.data[pstMp4muxer->uiAudioCnt]))//判断当前是否音频帧
        {
            ucAvFlag = 0;
            uiNaluLen = Mos_InetNtohl(pstMp4muxer->stsz_a.data[pstMp4muxer->uiAudioCnt]);
        }
        else
        {
            ucAvFlag = 1;
            MOS_MEMCPY(&uiNaluLen, aucWritePos, 4);
            uiNaluLen = Mos_InetNtohl(uiNaluLen);
        }
        if(iReadSize != 8 || (aucWritePos[4] == 'm' && aucWritePos[5] == 'o' && aucWritePos[6] == 'o' && aucWritePos[7] == 'v') || uiOffSet + uiNaluLen >= uiEndOffSet)
        {
            if(aucWritePos[4] == 'm' && aucWritePos[5] == 'o' && aucWritePos[6] == 'o' && aucWritePos[7] == 'v')
            {
                MOS_LOG_INF(RDSTG_MP4LOG,"dont need repair,filename: %s",pstMp4muxer->aucFileName);
                return MOS_OK;
            }
            RdStg_Mp4Muxer_RepairMdat(pstMp4muxer,&uiMdatLen,uiOffSet,puiDuration);
            return MOS_ERR_FILEEND;
        }

        if(ucAvFlag == 0)//判断音视频帧
        {
            Mos_FileSeek(pstMp4muxer->hFileHandle,MOS_FILE_SEEK_CUR,-8);
            Mos_FileSeek(pstMp4muxer->hFileHandle,MOS_FILE_SEEK_CUR,uiNaluLen);
            if(ucLastFrameType >= 1)//如果之前为视频帧
            {
                pstMp4muxer->stco_v.data[pstMp4muxer->stco_v.num++] = Mos_InetHtonl(uiLastVideoOffSet);//记录上帧位置、帧长度及时间戳
                pstMp4muxer->stsz_v.data[pstMp4muxer->stsz_v.num++] = Mos_InetHtonl(uiFrameTmpLen);
                if(pstMp4muxer->uiVideoCnt == 0)
                {
                    uiVideoTimeStamp = 0;
                }
                else
                {
                    uiVideoTimeStamp += 1000 / pstMp4muxer->uiVideoFps;
                }

                if(ucLastFrameType >= 5)
                {
                    pstMp4muxer->stss_v.data[pstMp4muxer->stss_v.num++] = Mos_InetHtonl(pstMp4muxer->uiVideoCnt);
                }
                RdStg_Mp4Muxer_WriteVideoStts(pstMp4muxer,uiVideoTimeStamp);

                pstMp4muxer->uiVideoCnt++;
                uiFrameTmpLen = 0;
                uiNaluLen = 0;
            }
            if(pstMp4muxer->uiAudioCnt >= 2)
            {
                uiAudioTimeStamp += (pstMp4muxer->uiAudioCnt % 2 == 0) ? 40 : 0;
            }
            if(pstMp4muxer->uiAudioCnt == 0)
            {
                pstMp4muxer->stts_a.data[pstMp4muxer->stts_a.num][0] = 1;
                pstMp4muxer->stts_a.data[pstMp4muxer->stts_a.num][1] = pstMp4muxer->uiPrevTimeStamp*1000/pstMp4muxer->uiTps;
                pstMp4muxer->uiAudioDuration = pstMp4muxer->uiPrevTimeStamp*1000/pstMp4muxer->uiTps*8;
            }
            else
            {
                if(pstMp4muxer->stts_a.num == MAXFRAME || pstMp4muxer->stts_a.data[pstMp4muxer->stts_a.num][1] == (uiAudioTimeStamp - pstMp4muxer->uiAPreTimeStamp)*pstMp4muxer->uiSampleRate/1000)
                {
                    pstMp4muxer->stts_a.data[pstMp4muxer->stts_a.num][0]++;
                }
                else
                {
                    pstMp4muxer->stts_a.num++;
                    pstMp4muxer->stts_a.data[pstMp4muxer->stts_a.num][0] = 1;
                    pstMp4muxer->stts_a.data[pstMp4muxer->stts_a.num][1] = (uiAudioTimeStamp - pstMp4muxer->uiAPreTimeStamp) *pstMp4muxer->uiSampleRate/1000;
                }
                pstMp4muxer->uiAudioDuration += (uiAudioTimeStamp - pstMp4muxer->uiAPreTimeStamp) *pstMp4muxer->uiSampleRate/1000;
            }

            pstMp4muxer->uiAPreTimeStamp = uiAudioTimeStamp;
            pstMp4muxer->uiAudioCnt++;
            uiOffSet = Mos_FileTell(pstMp4muxer->hFileHandle);//记录当前音频帧读完位置
            ucLastFrameType = 0;//记录本帧为音频
            continue;
        }
        else
        {
            if(pstMp4muxer->ucHevcFlag == 0){
                ucFrameType = aucWritePos[4] & 0x1f;
            }
            else
            {
                ucFrameType = MEFC_GETHEVTYPE(aucWritePos[4]);
            }

            Mos_FileSeek(pstMp4muxer->hFileHandle,MOS_FILE_SEEK_CUR,-4);

            if(ucFrameType == 7 || ucFrameType == 8 || ucFrameType >= 32)
            {
                if(uiNaluLen <= 256)
                {
                    iReadSize = Mos_FileRead(pstMp4muxer->hFileHandle,aucBuf,uiNaluLen);
                    if(iReadSize != uiNaluLen)
                    {
                        RdStg_Mp4Muxer_RepairMdat(pstMp4muxer,&uiMdatLen,uiOffSet,puiDuration);
                        return MOS_ERR_FILEEND;
                    }
                }
                else
                {
                    RdStg_Mp4Muxer_RepairMdat(pstMp4muxer,&uiMdatLen,uiOffSet,puiDuration);
                    return MOS_ERR_FILEEND;
                }

                switch(ucFrameType)
                {
                    case 7:
                    case 33:
                        {
                            pstMp4muxer->uiSpsLen = uiNaluLen;
                            MOS_MEMCPY(pstMp4muxer->aucSpsPps + pstMp4muxer->uiVpsLen, aucBuf, pstMp4muxer->uiSpsLen);
                            break;
                        }
                    case 8:
                    case 32:
                        {
                            pstMp4muxer->uiPpsLen = uiNaluLen;
                            MOS_MEMCPY(pstMp4muxer->aucSpsPps + pstMp4muxer->uiVpsLen + pstMp4muxer->uiSpsLen, aucBuf, pstMp4muxer->uiPpsLen);
                            break;
                        }
                    case 34:
                        {
                            pstMp4muxer->uiVpsLen = uiNaluLen;
                            MOS_MEMCPY(pstMp4muxer->aucSpsPps, aucBuf, pstMp4muxer->uiVpsLen);
                            break;
                        }
                    default:
                        break;
                }
            }
            else
            {
                Mos_FileSeek(pstMp4muxer->hFileHandle,MOS_FILE_SEEK_CUR,uiNaluLen);
            }

            uiNaluLen += 4;
            if((ucLastFrameType != 0 && ucFrameType == 1) || ucLastFrameType == 1 || (ucLastFrameType == 5 && ucFrameType > 5) 
                || ((ucLastFrameType == 19 || ucLastFrameType == 20) && ucFrameType > 20))//如果视频帧前后帧类型不一致
            {
                pstMp4muxer->stco_v.data[pstMp4muxer->stco_v.num++] = Mos_InetHtonl(uiLastVideoOffSet);//记录上帧位置、帧长度及时间戳
                pstMp4muxer->stsz_v.data[pstMp4muxer->stsz_v.num++] = Mos_InetHtonl(uiFrameTmpLen);
                if(pstMp4muxer->uiVideoCnt == 0)
                {
                    uiVideoTimeStamp = 0;
                }
                else
                {
                    uiVideoTimeStamp += 1000 / pstMp4muxer->uiVideoFps;
                }

                if(ucLastFrameType >= 5)
                {
                    pstMp4muxer->stss_v.data[pstMp4muxer->stss_v.num++] = Mos_InetHtonl(pstMp4muxer->uiVideoCnt);
                }
                RdStg_Mp4Muxer_WriteVideoStts(pstMp4muxer,uiVideoTimeStamp);

                uiLastVideoOffSet = uiOffSet;//记录此帧起始位置
                pstMp4muxer->uiVideoCnt++;
                uiFrameTmpLen = 0;
                uiNaluLen = 0;
            }
            if(ucLastFrameType == 0)
            {
                uiLastVideoOffSet = uiOffSet;//记录此帧起始位置
            }

            ucLastFrameType = ucFrameType;
            uiFrameTmpLen += uiNaluLen;
            uiOffSet = Mos_FileTell(pstMp4muxer->hFileHandle);//上一视频帧若处于未完状态，则记录当前位置
            continue;
        }
    }
    RdStg_Mp4Muxer_RepairMdat(pstMp4muxer,&uiMdatLen,uiOffSet,puiDuration);

    return MOS_ERR_FILEEND;
}

_INT RdStg_Mp4Muxer_WriteSubCnf(_HMP4MUXER hHandle)
{

    return MOS_OK;
}

_INT RdStg_Mp4Muxer_VideoWriteSimple(_HMP4MUXER hHandle, _UC *pucData,_UI uiLen, _UI uiTimeStamp)
{
    MOS_PARAM_NULL_RETERR(pucData);

    _UI  uiWriteTotal = 0;
    _UI  uiSpsLenth = 0;
    _UI i, uiPpsLen   = 0;
    _INT iRet;
    _UI  uiWriteLen = 0;
    _UC* ptWrirePos = MOS_NULL;
    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL)
    {
        return -1;
    }
    if(pstMp4Muxer->uiVideoCnt >= (MAXFRAME - 1))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many video frame",pstMp4Muxer);
        return -2;
    }
    
    if(pstMp4Muxer->uiVideoCnt == 0)
    {
        //原有的句柄要先关闭
        if(pstMp4Muxer->hFileHandle != MOS_NULL)
        {
            MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"hFileHandle is not NULL ,now close it");
            Mos_FileClose(pstMp4Muxer->hFileHandle);
            pstMp4Muxer->hFileHandle = MOS_NULL;
        }
        pstMp4Muxer->hFileHandle = Mos_FileOpen(pstMp4Muxer->aucFileName,MOS_FILE_O_RDWR|MOS_FILE_O_CREAT|MOS_FILE_O_BIN);
        if(pstMp4Muxer->hFileHandle == MOS_NULL)
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] open mp4 filename[%s] error %d",pstMp4Muxer, pstMp4Muxer->aucFileName,errno);
            return -4;
        }

        MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"task[%p] open file hFileHandle[%p]",pstMp4Muxer, pstMp4Muxer->hFileHandle);
        iRet = RdStg_Mp4Muxer_WriteMp4Ftyp(pstMp4Muxer);
        if(iRet < 0)
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p]  write ftyp error", pstMp4Muxer);
            return -5;
        }
        uiWriteTotal += iRet;
    }
    RdStg_Mp4Muxer_WriteVideoStts(pstMp4Muxer,uiTimeStamp);
    pstMp4Muxer->uiVideoCnt++;    
    if((pucData[4]&0x1f) != 1)
    {
        _UI uiSpsStart = 0, uiSpsEnd = 0, uiPpsStart = 0, uiPpsEnd = 0, uiEndPos = 0, uiNalFlag = 0;
        for(i = 0; (i < 200) && (i < uiLen); i++)
        {
            if((pucData[i] == 0) && (pucData[i + 1] == 0) && (pucData[i + 2] == 0) && (pucData[i + 3] == 1))
            {
                if((pucData[i + 4]&0x1f) == 7)
                {
                    uiSpsStart = i + 4;
                    uiNalFlag = 7;
                }
                else if((pucData[i + 4]&0x1f) == 8)
                {
                    uiPpsStart = i + 4;
                    if(uiNalFlag == 7)
                        uiSpsEnd = i;
                    uiNalFlag = 8;
                }
                else if((pucData[i + 4]&0x1f) == 5)
                {
                    if(uiNalFlag == 8)
                        uiPpsEnd = i;
                    uiEndPos = i;
                    break;
                }
                else
                {
                    if(uiNalFlag == 7)
                        uiSpsEnd = i;
                    if(uiNalFlag == 8)
                        uiPpsEnd = i;
                    uiNalFlag = 0;
                    uiEndPos = i;
                }
            }
        }
        ptWrirePos = pucData + uiEndPos + 4;
        uiWriteLen = (uiLen - (uiEndPos + 4));
        uiSpsLenth = uiSpsEnd - uiSpsStart;
        uiPpsLen = uiPpsEnd - uiPpsStart;
        if(uiSpsLenth > 0 && uiPpsLen > 0)
        {
            if(pstMp4Muxer->uiSpsLen == 0)
            {
                pstMp4Muxer->uiSpsLen = uiSpsLenth;
                pstMp4Muxer->uiPpsLen = uiPpsLen;
                MOS_MEMCPY(pstMp4Muxer->aucSpsPps, pucData + uiSpsStart, pstMp4Muxer->uiSpsLen);
                MOS_MEMCPY(pstMp4Muxer->aucSpsPps + pstMp4Muxer->uiSpsLen, pucData + uiPpsStart, pstMp4Muxer->uiPpsLen);
            }

            uiSpsLenth = Mos_InetHtonl(uiSpsLenth);
            uiPpsLen = Mos_InetHtonl(uiPpsLen);
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,&uiSpsLenth, 4) != MOS_OK)
            {
                return -5;
            }
            uiWriteTotal += 4;
            uiSpsLenth = uiSpsEnd - uiSpsStart;
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pucData + uiSpsStart, uiSpsLenth) != MOS_OK)
            {
                return -5;
            }
            uiWriteTotal += uiSpsLenth;
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,&uiPpsLen, 4) != MOS_OK)
            {
                return -5;
            }
            uiWriteTotal += 4;
            uiPpsLen = uiPpsEnd - uiPpsStart;
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pucData + uiPpsStart, uiPpsLen) != MOS_OK)
            {
                return -5;
            }
            uiWriteTotal += uiPpsLen;
            pstMp4Muxer->stss_v.data[pstMp4Muxer->stss_v.num++] = Mos_InetHtonl(pstMp4Muxer->uiVideoCnt);
            uiSpsLenth += 4;
            uiPpsLen += 4;
        }
    }
    else
    {
        ptWrirePos = pucData + 4;
        uiWriteLen = uiLen - 4;
    }

    pstMp4Muxer->stco_v.data[pstMp4Muxer->stco_v.num++] = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset += uiWriteLen + 4 + uiSpsLenth + uiPpsLen;
    pstMp4Muxer->stsz_v.data[pstMp4Muxer->stsz_v.num++] = Mos_InetHtonl(uiWriteLen + 4 + uiSpsLenth + uiPpsLen);
    uiWriteLen = Mos_InetHtonl(uiWriteLen);
    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,&uiWriteLen, 4) != MOS_OK)
    {
        return -5;
    }
    uiWriteTotal += 4;
    uiWriteLen = Mos_InetHtonl(uiWriteLen);
    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,ptWrirePos, uiWriteLen) != MOS_OK)
    {
        return -5;
    }
    uiWriteTotal += uiWriteLen;
    if(pstMp4Muxer->uiStartTime == 0)
    {
        pstMp4Muxer->uiStartTime = Mos_Time();
    }
    pstMp4Muxer->uiEndTime = Mos_Time();
    return uiWriteTotal;
}

_INT RdStg_Mp4Muxer_NaluWrite(_HMP4MUXER hHandle,_UI uiNaluNum, _UC **puiNalu,_UI *puiNaluLen,_UI uiTimeStamp)
{
    _UI uiWriteLen   = 0;
    _UI uiWriteTotal = 0;
    _UI i, uiTotalLen = 0;
    _INT iRet;
    _UC ucIsIFrame = 0;
    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL)
    {
        return -1;
    }
    if(pstMp4Muxer->uiVideoCnt >= (MAXFRAME - 1))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many video frame %u ",pstMp4Muxer, pstMp4Muxer->uiVideoCnt);
        return -2;
    }

    if((puiNalu == MOS_NULL) || (uiNaluNum == 0))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have no nalu ",pstMp4Muxer);
        return -3;
    }
    
    if(pstMp4Muxer->uiVideoCnt == 0)
    {
        _UC *ptSps = MOS_NULL, *ptPps = MOS_NULL,*ptVps = MOS_NULL;
        _UI uiSpsLen = 0,uiPpsLen = 0,uiVpsLen = 0;
        _UI uiWidth,uiHeight,uiFp;
        for(i = 0; i < uiNaluNum; i++)
        {
            if((puiNalu[i] == NULL) || (puiNaluLen[i] < 4))
            {
                MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have empty nal", pstMp4Muxer);
                return -3;
            }
            if((puiNalu[i][1] == 0) && (puiNalu[i][2] == 1))
            {
                if(((puiNalu[i][3] & 0x1f) == 8 && pstMp4Muxer->ucHevcFlag == 0)
                    ||( MEFC_GETHEVTYPE(puiNalu[i][3]) == 34 && pstMp4Muxer->ucHevcFlag == 1))
                {
                    ptPps = puiNalu[i] + 3;
                    uiPpsLen = puiNaluLen[i] - 3;

                    FHHEVC_FrameParse(ptPps,uiPpsLen,MEFC_GETHEVTYPE(puiNalu[i][3]),&pstMp4Muxer->stHecvRecordParty);
                }
                else if( ((puiNalu[i][3] & 0x1f) == 7 && pstMp4Muxer->ucHevcFlag == 0) || 
                    (MEFC_GETHEVTYPE(puiNalu[i][3]) == 33 && pstMp4Muxer->ucHevcFlag == 1))
                {
                    ptSps = puiNalu[i] + 3;
                    uiSpsLen = puiNaluLen[i] - 3;
                    FHHEVC_FrameParse(ptSps,uiSpsLen,MEFC_GETHEVTYPE(puiNalu[i][3]),&pstMp4Muxer->stHecvRecordParty);
                }
                else if(((puiNalu[i][3] & 0x1f) == 5 && pstMp4Muxer->ucHevcFlag == 0)
                    || ((MEFC_GETHEVTYPE(puiNalu[i][3]) == 19 || MEFC_GETHEVTYPE(puiNalu[i][3])== 20) && pstMp4Muxer->ucHevcFlag == 1))
                {
                    break;
                }
                else if(pstMp4Muxer->ucHevcFlag == 1 && MEFC_GETHEVTYPE(puiNalu[i][3]) == 32)
                {
                    ptVps = puiNalu[i] + 3;
                    uiVpsLen =  puiNaluLen[i] - 3;
                    FHHEVC_FrameParse(ptVps,uiVpsLen,MEFC_GETHEVTYPE(puiNalu[i][3]),&pstMp4Muxer->stHecvRecordParty);
                }
            }
            
            if((puiNalu[i][2] == 0) && (puiNalu[i][3] == 1))
            {
                if(((puiNalu[i][4] & 0x1f) == 7 && pstMp4Muxer->ucHevcFlag == 0)
                    ||(MEFC_GETHEVTYPE(puiNalu[i][4]) == 33 && pstMp4Muxer->ucHevcFlag == 1))
                {
                    ptSps = puiNalu[i] + 4;
                    uiSpsLen = puiNaluLen[i] - 4;
                    FHHEVC_FrameParse(ptSps,uiSpsLen,MEFC_GETHEVTYPE(puiNalu[i][4]),&pstMp4Muxer->stHecvRecordParty);
                }
                else if(((puiNalu[i][4] & 0x1f) == 8 && pstMp4Muxer->ucHevcFlag == 0) || 
                    (MEFC_GETHEVTYPE(puiNalu[i][4]) == 34 && pstMp4Muxer->ucHevcFlag == 1)) 
                {
                    ptPps = puiNalu[i] + 4;
                    uiPpsLen = puiNaluLen[i] - 4;
                    FHHEVC_FrameParse(ptPps,uiPpsLen,MEFC_GETHEVTYPE(puiNalu[i][4]),&pstMp4Muxer->stHecvRecordParty);
                }
                else if(((puiNalu[i][4] & 0x1f) == 5 && pstMp4Muxer->ucHevcFlag == 0)
                        || ((MEFC_GETHEVTYPE(puiNalu[i][4]) == 19 || MEFC_GETHEVTYPE(puiNalu[i][4]) == 20)&& pstMp4Muxer->ucHevcFlag == 1))
                {
                    break;
                }
                else if(pstMp4Muxer->ucHevcFlag == 1 && MEFC_GETHEVTYPE(puiNalu[i][4]) == 32)
                {
                    ptVps = puiNalu[i] + 3;
                    uiVpsLen =  puiNaluLen[i] - 3;
                    FHHEVC_FrameParse(ptVps,uiVpsLen,MEFC_GETHEVTYPE(puiNalu[i][4]),&pstMp4Muxer->stHecvRecordParty);
                }
            }

        }
        if(i >= uiNaluNum)
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] the first frame is not a iframe",pstMp4Muxer);
            return 0;
        }
        if(uiVpsLen > 0)
        {
            pstMp4Muxer->uiVpsLen = uiVpsLen;
            MOS_MEMCPY(pstMp4Muxer->aucSpsPps, ptVps, uiVpsLen);
        }
        if(uiSpsLen > 0)
        {
            pstMp4Muxer->uiSpsLen = uiSpsLen;
            MOS_MEMCPY(pstMp4Muxer->aucSpsPps + pstMp4Muxer->uiVpsLen, ptSps, pstMp4Muxer->uiSpsLen);
            h264_decode_sps(ptSps,pstMp4Muxer->uiSpsLen,&uiWidth,&uiHeight,&uiFp);
            if(uiWidth != 0 && uiHeight != 0)
            {
                pstMp4Muxer->usWidth = (_US)uiWidth;
                pstMp4Muxer->usHeight = (_US)uiHeight;
            }
        }
        if(uiPpsLen > 0)
        {
            pstMp4Muxer->uiPpsLen = uiPpsLen;
            MOS_MEMCPY(pstMp4Muxer->aucSpsPps + pstMp4Muxer->uiVpsLen + pstMp4Muxer->uiSpsLen, ptPps, pstMp4Muxer->uiPpsLen);
        }

        //原有的句柄要先关闭
        if(pstMp4Muxer->hFileHandle != MOS_NULL)
        {
            MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"hFileHandle is not NULL ,now close it");
            Mos_FileClose(pstMp4Muxer->hFileHandle);
            pstMp4Muxer->hFileHandle = MOS_NULL;
        }
        pstMp4Muxer->hFileHandle = Mos_FileOpen(pstMp4Muxer->aucFileName,MOS_FILE_O_RDWR|MOS_FILE_O_CREAT|MOS_FILE_O_BIN);
        if(pstMp4Muxer->hFileHandle == MOS_NULL)
        {
            pstMp4Muxer->uiErrCode = errno;
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] %s open fail,errno[%d]",pstMp4Muxer, pstMp4Muxer->aucFileName, errno);
            return -4;
        }
        MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"task[%p] open file hFileHandle[%p]",pstMp4Muxer, pstMp4Muxer->hFileHandle);
        iRet = RdStg_Mp4Muxer_WriteMp4Ftyp(pstMp4Muxer);
        if(iRet < 0)
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] write ftyp error",pstMp4Muxer);
            return -5;
        }
        uiWriteTotal += iRet;
    }
    RdStg_Mp4Muxer_WriteVideoStts(pstMp4Muxer,uiTimeStamp);
    pstMp4Muxer->uiVideoCnt++;
    for(i = 0; i < uiNaluNum; i++)
    {
        if((puiNalu[i] == NULL) || (puiNaluLen[i] < 4))
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have empty nal",pstMp4Muxer);
            return -3;
        }
        if((puiNalu[i][1] == 0) && (puiNalu[i][2] == 1))
        {
            if(((puiNalu[i][3] & 0x1f) == 5 && pstMp4Muxer->ucHevcFlag == 0) 
                || ((MEFC_GETHEVTYPE(puiNalu[i][3]) == 19 || MEFC_GETHEVTYPE(puiNalu[i][3]) == 20) && pstMp4Muxer->ucHevcFlag == 1))
                ucIsIFrame = 1;
            uiWriteLen = Mos_InetHtonl(puiNaluLen[i] - 3);
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,&uiWriteLen, 4) != MOS_OK)
            {
                return -5;
            }
            uiWriteTotal += 4;
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,puiNalu[i] + 3, puiNaluLen[i] - 3) != MOS_OK)
            {
                return -5;
            }
            uiWriteTotal += puiNaluLen[i] - 3;
            uiTotalLen += puiNaluLen[i] + 1;
            continue;
        }
        else if((puiNalu[i][2] == 0) && (puiNalu[i][3] == 1))
        {
            if(((puiNalu[i][4] & 0x1f) == 5 && pstMp4Muxer->ucHevcFlag == 0) || 
                ((MEFC_GETHEVTYPE(puiNalu[i][4]) == 19 || MEFC_GETHEVTYPE(puiNalu[i][4]) == 20) && pstMp4Muxer->ucHevcFlag == 1))
                ucIsIFrame = 1;
            uiWriteLen = Mos_InetHtonl(puiNaluLen[i] - 4);
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,&uiWriteLen, 4) != MOS_OK)
            {
                return -5;
            }
            uiWriteTotal += 4;
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,puiNalu[i] + 4, puiNaluLen[i] - 4) != MOS_OK)
            {
                    return -5;
            }
            uiWriteTotal += puiNaluLen[i] - 4;
            uiTotalLen += puiNaluLen[i];
        }
    }
    if(ucIsIFrame)
    {
        pstMp4Muxer->stss_v.data[pstMp4Muxer->stss_v.num++] = Mos_InetHtonl(pstMp4Muxer->uiVideoCnt);
    }
    pstMp4Muxer->stco_v.data[pstMp4Muxer->stco_v.num++]     = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset += uiTotalLen;
    pstMp4Muxer->stsz_v.data[pstMp4Muxer->stsz_v.num++]     = Mos_InetHtonl(uiTotalLen);
    if(uiTimeStamp == 0)
    {
        if(pstMp4Muxer->uiStartTime== 0)
        {
            pstMp4Muxer->uiStartTime = Mos_Time();
        }
        pstMp4Muxer->uiEndTime= Mos_Time();
    }
    return uiWriteTotal;
}

_INT RdStg_Mp4Muxer_VideoWrite(_HMP4MUXER hHandle, _UC *pucData,_UI uiLen, _UI uiTimeStamp)
{
    _UC *pucEndData;
    _UI uiNalNum = 0;
    _UC *apucNalu[32];
    _UI auiNaluLe[32];
    if((pucData == MOS_NULL) || (uiLen <= 4))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID, "frame err pucData[%p] uiLen[%u]",pucData, uiLen);
        return -1;
    }
    pucEndData = pucData + uiLen - 4;
    pucData += 2;
    while(pucData < pucEndData)
    {
        if(*pucData > 1)
        {
            pucData += 3;
            continue;
        }
        if(*pucData == 0)
        {
            pucData++;
            continue;
        }
        if((pucData[-1] != 0) || (pucData[-2] != 0))
        {
            pucData += 3;
            continue;
        }
        
        apucNalu[uiNalNum] = pucData - 2;
        if(uiNalNum > 0)
        {
            _UC *pNalEnd = apucNalu[uiNalNum];
            while(pNalEnd > apucNalu[uiNalNum - 1] && (*pNalEnd == 0))
            {
                pNalEnd--;
            }
            auiNaluLe[uiNalNum - 1] = pNalEnd - apucNalu[uiNalNum - 1] + 1;
        }
        uiNalNum++;
        if(uiNalNum >= 32)
        {
            break;
        }
        pucData += 5;
    }
    if(uiNalNum < 1)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID, "frame err uiNalNum[%u]",uiNalNum);
        return -100;
    }
    auiNaluLe[uiNalNum - 1] = pucEndData - apucNalu[uiNalNum - 1] + 4;
    return RdStg_Mp4Muxer_NaluWrite(hHandle, uiNalNum, apucNalu, auiNaluLe, uiTimeStamp);
}

// 找到第一个65IDR，则开始写MP4头
_INT RdStg_Mp4Muxer_VFNWriteHead(ST_RDSTG_MP4MUXER* pstMp4Muxer, _HVIDEOREAD hVideo, ST_FRAME_NODE *pstFrameNode, _UI uiListCnt)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(pstFrameNode);

    _UI i;
    _INT iRet;
    _UC *pucSps = MOS_NULL, *pucPps = MOS_NULL,*ptVps = MOS_NULL;
    _UI uiSpsLen = 0,uiPpsLen = 0,uiVpsLen = 0;

    // MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"................RdStg_Mp4Muxer_VFNWriteHead.....start");

    for(i = 0; i < uiListCnt; i++)
    {
        // 跳过 不符合的视频数据
        if((pstFrameNode->ptDatabuff[3] != 1))//((pstFrameNode->ucFramPos & 0x02) == 0) || 
        {
            pstFrameNode = pstFrameNode->ptnest;
            // MOS_BUFPRINTF("MP4 head error", pstFrameNode->ptDatabuff, 7);
            // 设置该视频数据已被消费
            //Media_VideoSetFrameUsed(hVideo);
            continue;
        }

        // MOS_BUFPRINTF("MP4 head", pstFrameNode->ptDatabuff, 7);
        // 67: 264 SPS  42:265 SPS
        if(((pstFrameNode->ptDatabuff[4] & 0x1f) == 7 && pstMp4Muxer->ucHevcFlag == 0) || 
            (MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]) == 33 && pstMp4Muxer->ucHevcFlag == 1))
        {
            MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"Find SPS Frame i:%d !!!! uiListCnt:%d", i, uiListCnt);
            pucSps   = pstFrameNode->ptDatabuff + 4;
            uiSpsLen = pstFrameNode->usDatalen  - 4; 
            // 解释SPS视频数据到 pstMp4Muxer->stHecvRecordParty
            if (pstMp4Muxer->ucHevcFlag == 1)
            {
                // RV1109芯片数据流不兼容需要编译脚本加 -DMP4_NOPARSE_SPS=1
                #ifndef  MP4_NOPARSE_SPS
                FHHEVC_FrameParse(pucSps,uiSpsLen,MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]),&pstMp4Muxer->stHecvRecordParty);
                #endif
            }
            else
            {
                FHHEVC_FrameParse(pucSps,uiSpsLen,MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]),&pstMp4Muxer->stHecvRecordParty);
            }

        }
        // 68: 264 PPS  44:265 PPS
        else if(((pstFrameNode->ptDatabuff[4] & 0x1f) == 8 && pstMp4Muxer->ucHevcFlag == 0) || 
           ( MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]) == 34 && pstMp4Muxer->ucHevcFlag == 1) )
        {
            MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"Find PPS Frame i:%d !!!! uiListCnt:%d", i, uiListCnt);
            pucPps   = pstFrameNode->ptDatabuff + 4;
            uiPpsLen = pstFrameNode->usDatalen  - 4;
            // 解释PPS视频数据到 pstMp4Muxer->stHecvRecordParty
            FHHEVC_FrameParse(pucPps,uiPpsLen,MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]),&pstMp4Muxer->stHecvRecordParty);
        }
        // 65 264 IDR  26 265 IDR
        else if(((pstFrameNode->ptDatabuff[4] & 0x1f) == 5 && pstMp4Muxer->ucHevcFlag == 0) || 
            ((MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]) == 19 || MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4])== 20) && pstMp4Muxer->ucHevcFlag == 1))
        {
            // 找到录像文件的第一个IDR帧
            MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"Find Record File First IDR Frame !!!! uiListCnt:%d ISH265:%d ", uiListCnt, pstMp4Muxer->ucHevcFlag);
            break;
        }
        // 40 265 VPS
        else if(pstMp4Muxer->ucHevcFlag == 1 && MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]) == 32)
        {
            MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"Find VPS Frame i:%d !!!! uiListCnt:%d", i, uiListCnt);
            // H265 VPS数据
            ptVps    = pstFrameNode->ptDatabuff + 4;
            uiVpsLen = pstFrameNode->usDatalen  - 4;
            // 解释VPS视频数据到 pstMp4Muxer->stHecvRecordParty
            FHHEVC_FrameParse(ptVps,uiVpsLen,MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]),&pstMp4Muxer->stHecvRecordParty);
        }

        pstFrameNode = pstFrameNode->ptnest;
        // 非IDR帧都将视频流数据设置为已消费 目的为了找到IDR帧
        //Media_VideoSetFrameUsed(hVideo);
    }

    if(i >= uiListCnt)
    {
        MOS_LOG_ERRFILTER(MEFC_MP4MUXER_LOG_ID,"task[%p] the first frame is not a iframe i:%d >= uiListCnt:%d",pstMp4Muxer,i,uiListCnt);
        return 0;
    }

    if(uiVpsLen > 0)
    {
        pstMp4Muxer->uiVpsLen = uiVpsLen;
        MOS_MEMCPY(pstMp4Muxer->aucSpsPps, ptVps, uiVpsLen);
    }

    if(uiSpsLen > 0)
    {
        pstMp4Muxer->uiSpsLen = uiSpsLen;
        MOS_MEMCPY(pstMp4Muxer->aucSpsPps + uiVpsLen, pucSps ,uiSpsLen);
    }
    if(uiPpsLen > 0)
    {
        pstMp4Muxer->uiPpsLen = uiPpsLen;
        MOS_MEMCPY(pstMp4Muxer->aucSpsPps + uiVpsLen + uiSpsLen, pucPps,uiPpsLen);
    }

    // 创建录像文件 *.mp4   原有的句柄要先关闭
    if(pstMp4Muxer->hFileHandle != MOS_NULL)
    {
        MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"hFileHandle is not NULL ,now close it");
        Mos_FileClose(pstMp4Muxer->hFileHandle);
        pstMp4Muxer->hFileHandle = MOS_NULL;
    }
    pstMp4Muxer->hFileHandle = Mos_FileOpen(pstMp4Muxer->aucFileName,MOS_FILE_O_RDWR|MOS_FILE_O_CREAT|MOS_FILE_O_BIN);
    if(pstMp4Muxer->hFileHandle == MOS_NULL)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] %s open fail,errno[%d]",pstMp4Muxer, pstMp4Muxer->aucFileName, errno);
        return -4;
    }

    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"task[%p] open file hFileHandle[%p]",pstMp4Muxer, pstMp4Muxer->hFileHandle);

    // 写MP4录像文件的头
    iRet = RdStg_Mp4Muxer_WriteMp4Ftyp(pstMp4Muxer);
    if(iRet < 0)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] write ftyp error",pstMp4Muxer);
        return -5;
    }

    // MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"................RdStg_Mp4Muxer_VFNWriteHead.....over");
    return iRet;
}

// 写MP4视频数据
_INT RdStg_Mp4Muxer_VFNWriteData(ST_RDSTG_MP4MUXER* pstMp4Muxer,ST_FRAME_NODE *pstFrameNode,_UI uiListCnt, _UC *pucIsIFrame)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(pstFrameNode);

    _UI i,j;
    _INT iWriteLen = 0;
    _UI uiNalLen = 0;
    ST_FRAME_NODE *pstTempNode;
    for(i = 0; i < uiListCnt; i++)
    {
        if(pstFrameNode == MOS_NULL)
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] frame node is null",pstMp4Muxer);
            break;
        }

        if((pstFrameNode->usDatalen <= 0) )//|| (pstFrameNode->usDatalen > 65535))  // FIXME: 原2048
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] frame node len [%d] error", pstMp4Muxer, pstFrameNode->usDatalen);
            return -1;
        }
        
        // 65(IDR) 或 61(P)的开头
        if((pstFrameNode->ucFramPos&0x02) > 0)
        {
            if(pstMp4Muxer->ucHevcFlag == 0 && (pstFrameNode->ptDatabuff[4]&0x1f) == 5)
            {
                // 264
                //MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"------- Record Write H264 I Frame !!! ------------");
                *pucIsIFrame = 1;
            }
            else if(pstMp4Muxer->ucHevcFlag && (MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]) == 19 || MEFC_GETHEVTYPE(pstFrameNode->ptDatabuff[4]) == 20))
            {
                // 265?
                //MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"------- Record Write H265 I Frame !!! ------------");
                *pucIsIFrame = 1;
            }   
            
            if((pstFrameNode->usDatalen < 4) || (pstFrameNode->ptDatabuff[3] != 1)){
                MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] node error start Datalen[%d]",pstMp4Muxer, pstFrameNode->usDatalen);
                return -1;
            }

            uiNalLen = pstFrameNode->usDatalen;
            pstTempNode = pstFrameNode->ptnest;
            
            for(j = i + 1; j < uiListCnt; j++)
            {
                if(pstTempNode == MOS_NULL)
                {
                    MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] temp node is null",pstMp4Muxer);
                    break;
                }
                if(pstTempNode->ucFramPos&0x02)
                {
                    break;
                }
                uiNalLen += pstTempNode->usDatalen;
                pstTempNode = pstTempNode->ptnest;
            }
            uiNalLen = Mos_InetHtonl(uiNalLen - 4);

            // 写入文件（I、P帧）
            // 先向文件写入该NULA的长度
            // MOS_BUFPRINTF("uiNalLen", &uiNalLen, 4);
            // MOS_BUFPRINTF("RdStg_Mp4Muxer_VFNWriteData", pstFrameNode->ptDatabuff+4, 7);
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,&uiNalLen, 4) != MOS_OK)
            {
                return -5;
            }
            // 先向文件写入该NULA的视频数据
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pstFrameNode->ptDatabuff + 4, pstFrameNode->usDatalen - 4) != MOS_OK)
            {
                return -5;
            }
        }
        else
        {
            // 向文件写入该NULA的视频数据
            if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pstFrameNode->ptDatabuff, pstFrameNode->usDatalen) != MOS_OK)
            {
                return -5;
            }
        }
        iWriteLen += pstFrameNode->usDatalen;
        pstFrameNode = pstFrameNode->ptnest;
    }
    return iWriteLen;
}

// 将视频数据写到MP4文件
_INT RdStg_Mp4Muxer_VFNWrite(_HMP4MUXER hHandle, _HVIDEOREAD hVideo, ST_FRAME_NODE *pstFrameHead,_UI uiListCnt,_UI uiTimeStamp)
{
    _INT iRet        = 0;
    _UI uiTotalLen   = 0;
    _UC ucIsIFrame   = 0;
    _INT iWriteTotal = 0;

    // 根据UserID获取录像文件信息
    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"pstMp4Muxer == MOS_NUL");
        return -1;
    }
    if(pstMp4Muxer->uiVideoCnt >= (MAXFRAME - 1))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many video frame %u ",pstMp4Muxer, pstMp4Muxer->uiVideoCnt);
        return -2;
    }
    if((pstFrameHead == MOS_NULL) || (uiListCnt == 0))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have no data",pstMp4Muxer);
        return 0;
    }

   // 还没写第一帧数据
    if(pstMp4Muxer->uiVideoCnt == 0){

        // 找到第一个IDR，则开始写MP4头
        iRet = RdStg_Mp4Muxer_VFNWriteHead(pstMp4Muxer, hVideo, pstFrameHead, uiListCnt);
        if(iRet <= 0)
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"Mp4Muxer Write Head failed iRet:%d", iRet);
            return iRet;
        }
        MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"task[%p] open file %s ok",pstMp4Muxer, pstMp4Muxer->aucFileName);
        iWriteTotal += iRet;
    }

    // 记录MP4的 Stts_v(每一帧的持续时间) 结构体信息 
    RdStg_Mp4Muxer_WriteVideoStts(pstMp4Muxer,uiTimeStamp);

    // 写视频数据到MP4文件
    iRet =  RdStg_Mp4Muxer_VFNWriteData(pstMp4Muxer,pstFrameHead,uiListCnt,&ucIsIFrame);
    if(iRet < 0)
    {
        if (ucIsIFrame == 1)
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"Mp4Muxer Write Data failed iRet:%d", iRet);
        }
        return iRet;
    }

    uiTotalLen  += iRet;
    iWriteTotal += iRet;
    if(ucIsIFrame)
    {
        // pstMp4Muxer->stss_v.num 记录录像文件的I帧个数
        pstMp4Muxer->stss_v.data[pstMp4Muxer->stss_v.num++] = Mos_InetHtonl(pstMp4Muxer->uiVideoCnt);
    }
    pstMp4Muxer->stco_v.data[pstMp4Muxer->stco_v.num++] = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset += uiTotalLen;
    pstMp4Muxer->stsz_v.data[pstMp4Muxer->stsz_v.num++] = Mos_InetHtonl(uiTotalLen);
    pstMp4Muxer->uiVideoCnt++;

    // 20帧保存一次文件
    if(pstMp4Muxer->uiVideoCnt%20 == 0)
    {
        Mos_FileFlush(pstMp4Muxer->hFileHandle);
    }
    if(uiTimeStamp == 0){
        if(pstMp4Muxer->uiStartTime== 0){
            pstMp4Muxer->uiStartTime = Mos_Time();
        }
        pstMp4Muxer->uiEndTime= Mos_Time();
    }
    return iWriteTotal;
}

// 将AAC音频数据写到MP4录像文件
_INT RdStg_Mp4Muxer_AacFNWrite(ST_RDSTG_MP4MUXER* pstMp4Muxer, ST_FRAME_NODE *pstFrameNode,_UI uiListCnt, _UI uiTimeStamp)
{
    _UI i; 
    _INT iWriteLen = 0;
    if((uiListCnt <= 0) || (pstFrameNode == MOS_NULL) || (pstFrameNode->usDatalen < 7))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] error in frame ",pstMp4Muxer);
        return -1;
    }
    if(pstMp4Muxer->uiAudioCnt >= (MAXFRAME - 1))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many audio frame",pstMp4Muxer);
        return -2;
    }
    if((pstFrameNode->ptDatabuff[0] != 0xff) || (pstFrameNode->ptDatabuff[1] < 0xf0))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] the audio is not aac",pstMp4Muxer);
        return -3;
    }
    if(pstMp4Muxer->uiSampleRate == 0)
    {
        pstMp4Muxer->uiProfile      = pstFrameNode->ptDatabuff[2] / 64;
        pstMp4Muxer->usChannelCount = pstFrameNode->ptDatabuff[3] / 64 + (pstFrameNode->ptDatabuff[3] % 2) * 4;
        pstMp4Muxer->usSampleSize   = 16;
        pstMp4Muxer->uiSampleRate   = RdStg_AacGetSampleByIndex((short)((pstFrameNode->ptDatabuff[2] & 0x3c) / 4));
    }

    if(pstMp4Muxer->uiAudioCnt == 0)
    {
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = 1024;
        pstMp4Muxer->uiAudioDuration = 1024;
    }
    else
    {
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0]++;
        pstMp4Muxer->uiAudioDuration += 1024;
    }

    // 将AAC音频数据写到MP4录像文件
    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pstFrameNode->ptDatabuff + 7, pstFrameNode->usDatalen - 7) != MOS_OK)
    {
        return -5;
    }
    iWriteLen += pstFrameNode->usDatalen - 7;
    pstFrameNode = pstFrameNode->ptnest;
    for(i = 1; i < uiListCnt; i++)
    {
        if((pstFrameNode == MOS_NULL) || (pstFrameNode->usDatalen <= 0))
        {
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] error in frame ",pstMp4Muxer);
            return -1;
        }
        // 将AAC音频数据写到MP4录像文件
        if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pstFrameNode->ptDatabuff, pstFrameNode->usDatalen) != MOS_OK)
        {
            return -5;
        }
        iWriteLen += pstFrameNode->usDatalen;
        pstFrameNode = pstFrameNode->ptnest;
    }

    pstMp4Muxer->stco_a.data[pstMp4Muxer->stco_a.num++] = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset+= iWriteLen;
    pstMp4Muxer->stsz_a.data[pstMp4Muxer->stsz_a.num++] = Mos_InetHtonl(iWriteLen);
    pstMp4Muxer->uiAudioCnt++;
    return iWriteLen;
}

_INT RdStg_Mp4Muxer_AacWrite(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC* pucData, _UI uiLen, _UI uiTimeStamp)
{
    _INT iWriteLen  = uiLen - 7;
    _UI uiWriteTotal = 0;
    _UC *pucWritePos  = pucData + 7;
    if(iWriteLen <= 0){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] uiWriteLen [%d] ",pstMp4Muxer, iWriteLen);
        return -1;
    }
    if((pucData[0] != 0xff) || (pucData[1] < 0xf0)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] the audio is not aac",pstMp4Muxer);
        return -3;
    }
    if(pstMp4Muxer->uiAudioCnt >= (MAXFRAME - 1)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many audio frame",pstMp4Muxer);
        return -2;
    }
    if(pstMp4Muxer->uiSampleRate == 0){
        pstMp4Muxer->uiProfile      = pucData[2] / 64;
        pstMp4Muxer->usChannelCount = pucData[3] / 64 + (pucData[3] % 2) * 4;
        pstMp4Muxer->usSampleSize   = 16;
        pstMp4Muxer->uiSampleRate   = RdStg_AacGetSampleByIndex((short)((pucData[2] & 0x3c) / 4));
    }
    
    if(pstMp4Muxer->uiAudioCnt == 0){
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = pstMp4Muxer->uiPrevTimeStamp*1000/pstMp4Muxer->uiTps;
        pstMp4Muxer->uiAudioDuration = pstMp4Muxer->uiPrevTimeStamp*1000/pstMp4Muxer->uiTps*8;
    }else{
        if(pstMp4Muxer->stts_a.num == MAXFRAME || pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] == (uiTimeStamp - pstMp4Muxer->uiAPreTimeStamp)*pstMp4Muxer->uiSampleRate/1000)
        {
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0]++;
        }
        else
        {
            pstMp4Muxer->stts_a.num++;
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = (uiTimeStamp - pstMp4Muxer->uiAPreTimeStamp) *pstMp4Muxer->uiSampleRate/1000;
        }
        pstMp4Muxer->uiAudioDuration += (uiTimeStamp - pstMp4Muxer->uiAPreTimeStamp) *pstMp4Muxer->uiSampleRate/1000;
    }
    pstMp4Muxer->uiAPreTimeStamp = uiTimeStamp;
    pstMp4Muxer->uiAudioCnt++;
    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pucWritePos, iWriteLen) != MOS_OK){
        return -5;
    }
    uiWriteTotal += iWriteLen;
    pstMp4Muxer->stco_a.data[pstMp4Muxer->stco_a.num++] = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset+= iWriteLen;
    pstMp4Muxer->stsz_a.data[pstMp4Muxer->stsz_a.num++] = Mos_InetHtonl(iWriteLen);
    return uiWriteTotal;
}

_UI g_auiMp3SampleRateTable[3][3] = {{11025, 12000, 8000}, {22050, 24000, 16000}, {44100, 48000, 32000}};
_UI g_auiMp3SamplePerFrameTable[3][3] = {{576, 1152, 384},{576, 1152, 384},{1152, 1152, 384}};
_INT RdStg_Mp4Muxer_mp3Parse(ST_RDSTG_MP4MUXER* pstMp4Muxer, _UC *pucMp3Frame)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(pucMp3Frame);

    _UI uiVersion, uiLayer, uiSamplingFrequency, uiChannelMode;
    uiVersion = (pucMp3Frame[1] & 0x18) >> 3;
    uiLayer = (pucMp3Frame[1] & 0x6) >> 1;
    uiSamplingFrequency = (pucMp3Frame[2] & 0xc) >> 2;
    uiChannelMode = (pucMp3Frame[3] & 0xc0) >> 6;
    if ((3 == uiSamplingFrequency) || (1 == uiVersion) || (0 == uiLayer)) {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID, "mp3 sampling_frequency[%d], version[%d] layer[%d]?\n", uiSamplingFrequency, uiVersion, uiLayer);
        return -1;
    }
    uiLayer--;
    if (uiVersion > 1) {
        uiVersion--;
    }
    pstMp4Muxer->uiSampleRate = g_auiMp3SampleRateTable[uiVersion][uiSamplingFrequency];
    if (3 == uiChannelMode) {
        pstMp4Muxer->usChannelCount = 1;
    }
    else {
        pstMp4Muxer->usChannelCount = 2;
    }
    pstMp4Muxer->uiSamplePerFrame = g_auiMp3SamplePerFrameTable[uiVersion][uiLayer];
    return 0;
}

// 将MP3音频数据写到MP4录像文件
_INT RdStg_Mp4Muxer_mp3FNWrite(ST_RDSTG_MP4MUXER* pstMp4Muxer, ST_FRAME_NODE *pstFrameNode,_UI uiListCnt, _UI uiTimeStamp)
{
    _UI i; 
    _INT iWriteLen = 0;
    if((uiListCnt <= 0) || (pstFrameNode == MOS_NULL) || (pstFrameNode->usDatalen < 5)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] error in frame ",pstMp4Muxer);
        return -1;
    }
    if(pstMp4Muxer->uiAudioCnt >= (MAXFRAME - 1)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many audio frame",pstMp4Muxer);
        return -2;
    }
    if((pstFrameNode->ptDatabuff[0] != 0xff) || (pstFrameNode->ptDatabuff[1] < 0xe0)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] the audio is not mp3",pstMp4Muxer);
        return -3;
    }
    if(pstMp4Muxer->uiSampleRate == 0){
        if(RdStg_Mp4Muxer_mp3Parse(pstMp4Muxer, pstFrameNode->ptDatabuff) < 0){
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] the audio is not mp3",pstMp4Muxer);
            return -4;
        }
    }

    if(pstMp4Muxer->uiAudioCnt == 0){
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = pstMp4Muxer->uiSamplePerFrame;
        pstMp4Muxer->uiAudioDuration = pstMp4Muxer->uiSamplePerFrame;
    }else{
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0]++;
        pstMp4Muxer->uiAudioDuration += pstMp4Muxer->uiSamplePerFrame;
    }
    pstMp4Muxer->uiAudioCnt++;
    // 将MP3音频数据写到MP4录像文件
    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pstFrameNode->ptDatabuff, pstFrameNode->usDatalen) != MOS_OK){
        return -5;
    }
    iWriteLen += pstFrameNode->usDatalen;
    pstFrameNode = pstFrameNode->ptnest;
    for(i = 1; i < uiListCnt; i++){
        if((pstFrameNode == MOS_NULL) || (pstFrameNode->usDatalen <= 0)){
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] error in frame ",pstMp4Muxer);
            return -1;
        }
        // 将MP3音频数据写到MP4录像文件
        if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pstFrameNode->ptDatabuff, pstFrameNode->usDatalen) != MOS_OK){
            return -5;
        }
        iWriteLen += pstFrameNode->usDatalen;
        pstFrameNode = pstFrameNode->ptnest;
    }

    pstMp4Muxer->stco_a.data[pstMp4Muxer->stco_a.num++] = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset+= iWriteLen;
    pstMp4Muxer->stsz_a.data[pstMp4Muxer->stsz_a.num++] = Mos_InetHtonl(iWriteLen);
    return iWriteLen;
}

_INT RdStg_Mp4Muxer_mp3Write(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC* pucData, _UI uiLen, _UI uiTimeStamp)
{
    _INT iWriteLen  = uiLen;
    _UI uiWriteTotal = 0;
    _UC *pucWritePos  = pucData;
    if(iWriteLen <= 4){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] uiWriteLen [%d] ",pstMp4Muxer, iWriteLen);
        return -1;
    }
    if((pucData[0] != 0xff) || (pucData[1] < 0xe0)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] the audio is not aac",pstMp4Muxer);
        return -3;
    }
    if(pstMp4Muxer->uiAudioCnt >= (MAXFRAME - 1)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many audio frame",pstMp4Muxer);
        return -2;
    }
    if(pstMp4Muxer->uiSampleRate == 0){
        if(RdStg_Mp4Muxer_mp3Parse(pstMp4Muxer, pucData) < 0){
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] the audio is not mp3",pstMp4Muxer);
            return -4;
        }
    }

    if(pstMp4Muxer->uiAudioCnt == 0){
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = pstMp4Muxer->uiSamplePerFrame;
        pstMp4Muxer->uiAudioDuration = pstMp4Muxer->uiSamplePerFrame;
    }else{
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0]++;
        pstMp4Muxer->uiAudioDuration += pstMp4Muxer->uiSamplePerFrame;
    }

    pstMp4Muxer->uiAudioCnt++;
    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pucWritePos, iWriteLen) != MOS_OK){
        return -5;
    }
    uiWriteTotal += iWriteLen;
    pstMp4Muxer->stco_a.data[pstMp4Muxer->stco_a.num++] = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset+= iWriteLen;
    pstMp4Muxer->stsz_a.data[pstMp4Muxer->stsz_a.num++] = Mos_InetHtonl(iWriteLen);
    return uiWriteTotal;
}

// 将G711A/G711U音频数据写到MP4录像文件
_INT RdStg_Mp4Muxer_G711FNWrite(ST_RDSTG_MP4MUXER* pstMp4Muxer, ST_FRAME_NODE *pstFrameNode,_UI uiListCnt, _UI uiTimeStamp)
{
    _UI i;
    _INT iWriteLen = 0;
    if(pstMp4Muxer->uiAudioCnt >= (MAXFRAME - 1)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many audio frame g711",pstMp4Muxer);
        return -2;
    }
    for(i = 0; i < uiListCnt; i++){
        if((pstFrameNode == MOS_NULL) || (pstFrameNode->usDatalen <= 0)){
            MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] error in frame ",pstMp4Muxer);
            return -1;
        }
        // 将G711A/G711U音频数据写到MP4录像文件
        if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pstFrameNode->ptDatabuff, pstFrameNode->usDatalen) != MOS_OK){
            return -5;
        }
        iWriteLen += pstFrameNode->usDatalen;
        pstFrameNode = pstFrameNode->ptnest;
    }
    if(pstMp4Muxer->uiSampleRate == 0){
        pstMp4Muxer->uiProfile = 3;
        if(pstMp4Muxer->uiAudioType == 1)
            pstMp4Muxer->usChannelCount = 5;
        else{
            pstMp4Muxer->usChannelCount = 6;
        }
        pstMp4Muxer->usSampleSize = 16;
        pstMp4Muxer->uiSampleRate = 8000;
    }
    if(pstMp4Muxer->uiAudioCnt == 0){
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = pstMp4Muxer->uiPrevTimeStamp*1000/pstMp4Muxer->uiTps;
        pstMp4Muxer->uiAudioDuration = pstMp4Muxer->uiPrevTimeStamp*1000/pstMp4Muxer->uiTps*8;
    }else{
        if(pstMp4Muxer->stts_a.num == MAXFRAME || pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] == (uiTimeStamp - pstMp4Muxer->uiAPreTimeStamp)*pstMp4Muxer->uiSampleRate/1000)
        {
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0]++;
        }
        else
        {
            pstMp4Muxer->stts_a.num++;
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = (uiTimeStamp - pstMp4Muxer->uiAPreTimeStamp) *pstMp4Muxer->uiSampleRate/1000;
        }
        pstMp4Muxer->uiAudioDuration += (uiTimeStamp - pstMp4Muxer->uiAPreTimeStamp) *pstMp4Muxer->uiSampleRate/1000;
    }
    pstMp4Muxer->uiAPreTimeStamp = uiTimeStamp;

    pstMp4Muxer->uiAudioCnt++;

    pstMp4Muxer->stco_a.data[pstMp4Muxer->stco_a.num++] = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset += iWriteLen;
    pstMp4Muxer->stsz_a.data[pstMp4Muxer->stsz_a.num++] = Mos_InetHtonl(iWriteLen);
    return iWriteLen;
}

_INT RdStg_Mp4Muxer_G711Write(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC* ptdata, _UI uilen, _UI uiTimeStamp)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptdata);

    _UI uiWriteTotal = 0;
    if(uilen <= 0){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] audio data len error",pstMp4Muxer);
        return -2;
    }
    if(pstMp4Muxer->uiAudioCnt >= (MAXFRAME - 1)){
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] have too many audio frame g711",pstMp4Muxer);
        return -2;
    }
    if(pstMp4Muxer->uiSampleRate == 0){
        pstMp4Muxer->uiProfile = 3;
        if(pstMp4Muxer->uiAudioType == 1)
            pstMp4Muxer->usChannelCount = 5;
        else{
            pstMp4Muxer->usChannelCount = 6;
        }
        pstMp4Muxer->usSampleSize = 16;
        pstMp4Muxer->uiSampleRate = 8000;
    }
    if(pstMp4Muxer->uiAudioCnt == 0){
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
        pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = uilen;
        pstMp4Muxer->uiAudioDuration = uilen;
    }else{
        if(uilen == pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1]){
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0]++;
        }else{
            pstMp4Muxer->stts_a.num++;
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][0] = 1;
            pstMp4Muxer->stts_a.data[pstMp4Muxer->stts_a.num][1] = uilen;
        }
        pstMp4Muxer->uiAudioDuration += uilen;
    }
    pstMp4Muxer->uiAudioCnt++;

    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,ptdata,uilen) != MOS_OK){
        return -5;
    }
    uiWriteTotal += uilen;

    pstMp4Muxer->stco_a.data[pstMp4Muxer->stco_a.num++] = Mos_InetHtonl(pstMp4Muxer->uiOffset);
    pstMp4Muxer->uiOffset += uilen;
    pstMp4Muxer->stsz_a.data[pstMp4Muxer->stsz_a.num++] = Mos_InetHtonl(uilen);
    return uiWriteTotal;
}

_INT RdStg_Mp4Muxer_AudioWrite(_HMP4MUXER hHandle, _UC* pucData, _UI uiLen, _UI uiTimeStamp)
{
    MOS_PARAM_NULL_RETERR(pucData);

    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL){
        return -1;
    }
    if(pstMp4Muxer->uiVideoCnt == 0){
        MOS_LOG_WARN(MEFC_MP4MUXER_LOG_ID,"task[%p] please to get a i frame",pstMp4Muxer);
        return 0;
    }
    if(pstMp4Muxer->uiAudioType == EN_ZJ_AUDIOENC_TYPE_AAC){
        return RdStg_Mp4Muxer_AacWrite(pstMp4Muxer,pucData, uiLen,uiTimeStamp);
    }else if(pstMp4Muxer->uiAudioType == EN_ZJ_AUDIOENC_TYPE_MP3){
        return RdStg_Mp4Muxer_mp3Write(pstMp4Muxer,pucData, uiLen,uiTimeStamp);
    }else{
        return RdStg_Mp4Muxer_G711Write(pstMp4Muxer,pucData, uiLen,uiTimeStamp);
    }
    return 0;
}

// 将音频数据写到MP4文件
_INT RdStg_Mp4Muxer_AFNWrite(_HMP4MUXER hHandle,ST_FRAME_NODE *pstFrameHead,_UI uiListCnt, _UI uiTimeStamp)
{
    MOS_PARAM_NULL_RETERR(pstFrameHead);

    // 根据UserID获取录像文件信息
    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"pstMp4Muxer == MOS_NUL");
        return -1;
    }
    if(pstMp4Muxer->uiVideoCnt == 0){
        MOS_LOG_WARN(MEFC_MP4MUXER_LOG_ID,"task[%p] please to get a i frame",pstMp4Muxer);
        return 0;
    }
    if(pstMp4Muxer->uiAudioType == EN_ZJ_AUDIOENC_TYPE_AAC)
    {
        // 将AAC音频数据写到MP4录像文件
        return RdStg_Mp4Muxer_AacFNWrite(pstMp4Muxer,pstFrameHead,uiListCnt,uiTimeStamp);
    }
    else if(pstMp4Muxer->uiAudioType == EN_ZJ_AUDIOENC_TYPE_MP3)
    {
        // 将MP3音频数据写到MP4录像文件
        return RdStg_Mp4Muxer_mp3FNWrite(pstMp4Muxer,pstFrameHead,uiListCnt,uiTimeStamp);
    }
    else
    {
        // 将G711A/G711U音频数据写到MP4录像文件
        return RdStg_Mp4Muxer_G711FNWrite(pstMp4Muxer,pstFrameHead,uiListCnt,uiTimeStamp);
    }
    return 0;
}

static _INT RdStg_Mp4Muxer_SetMvhd(ST_RDSTG_MP4MUXER* pstMp4Muxer, _UC *ptBoxBuff)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI uiLongType;
    _US ushortType;
    _UI uiBoxLenth = 8;
    
    MOS_MEMSET(ptBoxBuff + uiBoxLenth, 0, 4);
    uiBoxLenth += 4;
    
    uiLongType = 0x87654321;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;
    
    uiLongType = 0x87654321;
    /*modifi time */
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;

    uiLongType = Mos_InetHtonl(pstMp4Muxer->uiTps);
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;

    uiLongType = Mos_InetHtonl(pstMp4Muxer->uiDuration);
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;

    uiLongType = Mos_InetHtonl(0x10000);
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;
    ushortType = Mos_InetHtons(0x100);
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
    uiBoxLenth += 2;
    MOS_MEMSET(ptBoxBuff + uiBoxLenth, 0, 10);
    uiBoxLenth += 10;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, RdStg_GetMp4MuxerMng()->aucMatrix, 36);
    uiBoxLenth += 36;
    MOS_MEMSET(ptBoxBuff + uiBoxLenth, 0, 24);
    uiBoxLenth += 24;
    uiLongType = 0;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;
    uiLongType = Mos_InetHtonl(uiBoxLenth);
    MOS_MEMCPY(ptBoxBuff, &uiLongType, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "mvhd", 4);
    return uiBoxLenth;
}

static _INT RdStg_Mp4Muxer_SetTkhd(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)//0 video 1 audio
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI uiLongType;
    _US ushortType;
    _UI uiBoxLenth = 8;
    uiLongType = 0x03000000;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;
    
    uiLongType = 0x87654321;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;
    
    uiLongType = 0x87654321;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;
    
    if(iFlag == 0){
        uiLongType = 0x01000000;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    }else if(iFlag == 1){
        uiLongType = 0x02000000;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    }
    uiBoxLenth += 4;
    
    uiLongType = 0;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    uiBoxLenth += 4;
    
    if(iFlag == 0){
        uiLongType = Mos_InetHtonl(pstMp4Muxer->uiVideoDuration);
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    }else if(iFlag == 1){
        uiLongType = Mos_InetHtonl(pstMp4Muxer->uiVideoDuration);
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &uiLongType, 4);
    }
    uiBoxLenth += 4;
    MOS_MEMSET(ptBoxBuff + uiBoxLenth, 0, 8);//not use
    uiBoxLenth += 8;
    ushortType = 0;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
    uiBoxLenth += 2;
    ushortType = 0;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
    uiBoxLenth += 2;
    if(iFlag == 0){
        ushortType = 0;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
    }else if(iFlag == 1){
        ushortType = 1;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
    }
    uiBoxLenth += 2;
    ushortType = 0;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
    uiBoxLenth += 2;
    MOS_MEMCPY(ptBoxBuff + uiBoxLenth, RdStg_GetMp4MuxerMng()->aucMatrix, 36);
    uiBoxLenth += 36;
    if(iFlag == 0){
        ushortType = Mos_InetHtons(pstMp4Muxer->usWidth);
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
        uiBoxLenth += 2;
        ushortType = 0;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
        uiBoxLenth += 2;
        ushortType = Mos_InetHtons(pstMp4Muxer->usHeight);
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
        uiBoxLenth += 2;
        ushortType = 0;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
        uiBoxLenth += 2;
    }else if(iFlag == 1){
        ushortType = 0;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
        uiBoxLenth += 2;
        ushortType = 0;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
        uiBoxLenth += 2;
        ushortType = 0;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
        uiBoxLenth += 2;
        ushortType = 0;
        MOS_MEMCPY(ptBoxBuff + uiBoxLenth, &ushortType, 2);
        uiBoxLenth += 2;
    }
    uiLongType = Mos_InetHtonl(uiBoxLenth);
    MOS_MEMCPY(ptBoxBuff, &uiLongType, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "tkhd", 4);
    return uiBoxLenth;
}

static _INT RdStg_Mp4Muxer_SetMdhd(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _US shorttype;
    _UI box_length = 8;
    MOS_MEMSET(ptBoxBuff + box_length, 0, 4);//version,flag fix
    box_length += 4;
    longtype = 0x87654321;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    longtype = 0x87654321;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    if(iFlag == 0){
        longtype = Mos_InetHtonl(pstMp4Muxer->uiTps);
        MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    }else if(iFlag == 1){
        longtype = Mos_InetHtonl(pstMp4Muxer->uiSampleRate);
        MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    }
    box_length += 4;
    if(iFlag == 0){
        longtype = Mos_InetHtonl(pstMp4Muxer->uiVideoDuration);
        MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    }else if(iFlag == 1){
        longtype = Mos_InetHtonl(pstMp4Muxer->uiAudioDuration);
        MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    }
    box_length += 4;
    shorttype = 0xc455;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    shorttype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "mdhd", 4);
    return box_length;
}

static _INT RdStg_Mp4Muxer_SetHdlr(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI  box_length = 8;
    _UC ucBuff[256] = {0};
    MOS_MEMSET(ptBoxBuff + box_length, 0, 4);//version,flag fix
    box_length += 4;
    MOS_MEMSET(ptBoxBuff + box_length, 0, 4);//
    box_length += 4;
    if(iFlag == 0){
        MOS_MEMCPY(ptBoxBuff + box_length, "vide", 4);
    }else if(iFlag == 1){
        MOS_MEMCPY(ptBoxBuff + box_length, "soun", 4);
    }
    box_length += 4;
    MOS_MEMSET(ptBoxBuff + box_length, 0, 12);//
    box_length += 12;

    MOS_VSNPRINTF(ucBuff, 255, "radius=%u;ccx1=%u;ccy1=%u;ccx2=%u;ccy2=%u;angle=%u",pstMp4Muxer->stCircle.uiRadius,
                                pstMp4Muxer->stCircle.uiCc1x,pstMp4Muxer->stCircle.uiCc1Y,
                                pstMp4Muxer->stCircle.uiCc2x,pstMp4Muxer->stCircle.uiCc2Y,
                                pstMp4Muxer->stCircle.doubleAngle);
    
    MOS_MEMCPY(ptBoxBuff + box_length, ucBuff, MOS_STRLEN(ucBuff)+1);
    
    box_length += MOS_STRLEN(ucBuff)+1;
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "hdlr", 4);
    return box_length;
}

static _INT RdStg_Mp4Muxer_SetVmhd(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI box_length = 8;
    longtype = 0x1000000;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    MOS_MEMSET(ptBoxBuff + box_length, 0, 8);//
    box_length += 8;
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "vmhd", 4);
    return box_length;
}

static _INT RdStg_Mp4Muxer_SetSmhd(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI box_length = 8;
    MOS_MEMSET(ptBoxBuff + box_length, 0, 8);//
    box_length += 8;
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "smhd", 4);
    return box_length;
}
/******************
ADTS ff f1 50 80 adts_fixed_header();28bit

 fff1
syncword 12bit fff
id       1bit  0     ;0 for MPEG-4, 1 for MPEG-2
layer    2bit  00
protection_absent 1bit 1
508
profile 2bit 01
samplingFrequencyIndex  4bit 0100 44100
private_bit 1bie 0
channel_configuration 3bit 010 2channel
original 1bit 0
home 1bit 0

1210    :14496-3 1.6
        :1210(hex)=
        :0001 0010 0001 0000(bit)
        :0001 0                     :audioObjectType 2 GASpecificConfig
        :      010 0                :samplingFrequencyIndex
        :           001 0           :channelConfiguration 2  
        :                00         :cpConfig
        :                  0        :directMapping
*******************/

static _INT RdStg_Mp4Muxer_SetEsds(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _US shorttype;
    _UI box_length = 8;
    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    ptBoxBuff[box_length++] = 0x03;//tag
    ptBoxBuff[box_length++] = 0x19;//length
    shorttype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    ptBoxBuff[box_length++] = 0;//steamDependenceFlag 1,URL_Flag 1,OCRstreamFlag 1,streamPriority 5
    ptBoxBuff[box_length++] = 0x04;//tag
    ptBoxBuff[box_length++] = 0x11;//length
    ptBoxBuff[box_length++] = 0x40;//audio type mpeg4 audio
    ptBoxBuff[box_length++] = 0x15;//streamType  5 Audio Stream; upStream 1 0;reserved 1 1
    pstMp4Muxer->uiMaxAudioSize = Mos_InetHtonl(pstMp4Muxer->uiMaxAudioSize);
    MOS_MEMCPY(ptBoxBuff + box_length, ((unsigned char*)(&pstMp4Muxer->uiMaxAudioSize)) + 1, 3);//bufferSizeDB
    box_length += 3;
    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    ptBoxBuff[box_length++] = 0x05;//tag
    ptBoxBuff[box_length++] = 0x02;//length
    shorttype = Mos_InetHtons((pstMp4Muxer->uiProfile + 1) * 2048 + RdStg_AacGetIndexBySample(pstMp4Muxer->uiSampleRate) * 128 + pstMp4Muxer->usChannelCount* 8);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    ptBoxBuff[box_length++] = 0x06;//tag
    ptBoxBuff[box_length++] = 0x01;//length
    ptBoxBuff[box_length++] = 0x02;//predefined 0x02 Reserved for use in MP4 files
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "esds", 4);
    return box_length;
}

static _INT  RdStg_Mp4Muxer_SetMp4a(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _US shorttype;
    _UI box_length = 8;

    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;

    longtype = 0x1000000;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    MOS_MEMSET(ptBoxBuff + box_length, 0, 8);
    box_length += 8;

    shorttype = Mos_InetHtons(pstMp4Muxer->usChannelCount);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;

    shorttype = Mos_InetHtons(16);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;

    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;

    shorttype = Mos_InetHtons((unsigned short)pstMp4Muxer->uiSampleRate);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    
    shorttype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    if(EN_ZJ_AUDIOENC_TYPE_AAC == pstMp4Muxer->uiAudioType){
        box_length += RdStg_Mp4Muxer_SetEsds(pstMp4Muxer, ptBoxBuff + box_length);
    }
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    if(EN_ZJ_AUDIOENC_TYPE_AAC == pstMp4Muxer->uiAudioType){
        MOS_MEMCPY(ptBoxBuff + 4, "mp4a", 4);
    }else if(EN_ZJ_AUDIOENC_TYPE_G711A == pstMp4Muxer->uiAudioType){
        MOS_MEMCPY(ptBoxBuff + 4, "alaw", 4);
    }
    else if(EN_ZJ_AUDIOENC_TYPE_G711U == pstMp4Muxer->uiAudioType){
        MOS_MEMCPY(ptBoxBuff + 4, "ulaw", 4);
    }
    else if(EN_ZJ_AUDIOENC_TYPE_PCM16 == pstMp4Muxer->uiAudioType){
        MOS_MEMCPY(ptBoxBuff + 4, "sowt", 4);
    }    
    else if(EN_ZJ_AUDIOENC_TYPE_MP3 == pstMp4Muxer->uiAudioType){
        MOS_MEMCPY(ptBoxBuff + 4, ".mp3", 4);
    }
    return box_length;
}

/**********************************
00 00 00 23 （avcC Size）
61 76 63 43 （avcC box name）
01 (version)
64 (AVCProfileIndication)
00 (profile_compatibility)
29 (AVCLevelIndication)
ff  (NALU 长度)
e1 (SPS个数，低五位有效)
00 0c (SPS长度)
67 64    00 29 ac 76    80 78 02 27    e5 40  (SPS内容)
01 (PPS个数)
00 04 (PPS长度)
68 ee 38  b0  (PPS内容)
**********************************************/

static _INT RdStg_Mp4Muxer_SetAvcC(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _US shorttype;
    _UI box_length = 8;
    ptBoxBuff[box_length++] = 1;//
    MOS_MEMCPY(ptBoxBuff + box_length, pstMp4Muxer->aucSpsPps + 1,3);
    box_length += 3;
    ptBoxBuff[box_length++] = 0xff;
    ptBoxBuff[box_length++] = 0xe1;

    shorttype = Mos_InetHtons(pstMp4Muxer->uiSpsLen);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    MOS_MEMCPY(ptBoxBuff + box_length, pstMp4Muxer->aucSpsPps, pstMp4Muxer->uiSpsLen);//sps
    box_length += pstMp4Muxer->uiSpsLen;
    ptBoxBuff[box_length++] = 1;

    shorttype = Mos_InetHtons(pstMp4Muxer->uiPpsLen);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    MOS_MEMCPY(ptBoxBuff + box_length, pstMp4Muxer->aucSpsPps + pstMp4Muxer->uiSpsLen, pstMp4Muxer->uiPpsLen);//pps
    box_length += pstMp4Muxer->uiPpsLen;

    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "avcC", 4);
    return box_length;
}
/*
    MP4_BASE_BOX{
     
        U32 size;
        U32 type;
    }
    U8 reserved[6];
    U16 data_reference_index;
    
    U16 pre_defined;
    U16 reserved;
    U32 pre_defined[3];
    U16 width;
    U16 height;
    U32 horiz_res;
    U32 vert_res;
    U32 reserved;
    U16 frames_count;
    AVCDecoderConfigurationRecord{
        U8 compressr_name[32];
        U16 bit_depth;
        U16 pre_defined;
    }
*/

static _INT  RdStg_Mp4Muxer_SetAvc1(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _US shorttype;
    _UI box_length = 8;

    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    longtype = 0x1000000;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    MOS_MEMSET(ptBoxBuff + box_length, 0, 16);
    box_length += 16;
    shorttype = Mos_InetHtons(pstMp4Muxer->usWidth);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    shorttype = Mos_InetHtons(pstMp4Muxer->usHeight);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    longtype = 0x4800;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    longtype = 0x4800;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    shorttype = 0x0100;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    MOS_MEMSET(ptBoxBuff + box_length, 0, 32);//compressorname
    box_length += 32;
    shorttype = 0x1800;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    shorttype = 0xffff;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    box_length += RdStg_Mp4Muxer_SetAvcC(pstMp4Muxer, ptBoxBuff + box_length);
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "avc1", 4);
    return box_length;
}
// H265

static _INT RdStg_Mp4Muxer_SetHvcC(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _US shorttype;
    _UI box_length = 8;


    ptBoxBuff[box_length] = pstMp4Muxer->stHecvRecordParty.configurationVersion;
    box_length += 1;

    ptBoxBuff[box_length] = ( pstMp4Muxer->stHecvRecordParty.general_profile_space << 6 |
                              pstMp4Muxer->stHecvRecordParty.general_tier_flag     << 5 |
                              pstMp4Muxer->stHecvRecordParty.general_profile_idc ); 
    box_length += 1;


    longtype = MOS_INET_HTONL(pstMp4Muxer->stHecvRecordParty.general_profile_compatibility_flags);
    MOS_MEMCPY(ptBoxBuff + box_length , &longtype, 4);
    box_length += 4;

    longtype = MOS_INET_HTONL(pstMp4Muxer->stHecvRecordParty.general_constraint_indicator_flags >> 16);
    MOS_MEMCPY(ptBoxBuff + box_length , &longtype, 4);
    box_length += 4;
    
    shorttype = MOS_INET_HTONS(pstMp4Muxer->stHecvRecordParty.general_constraint_indicator_flags);
    MOS_MEMCPY(ptBoxBuff + box_length , &shorttype, 2);
    box_length += 2;
    
    ptBoxBuff[box_length] = pstMp4Muxer->stHecvRecordParty.general_level_idc;
    box_length += 1;

    shorttype = MOS_INET_HTONS(pstMp4Muxer->stHecvRecordParty.min_spatial_segmentation_idc |0xf000 );
    MOS_MEMCPY(ptBoxBuff + box_length , &shorttype, 2);
    box_length += 2;

    ptBoxBuff[box_length] = (pstMp4Muxer->stHecvRecordParty.parallelismType | 0xfc);
    box_length++;

    ptBoxBuff[box_length] = (pstMp4Muxer->stHecvRecordParty.chromaFormat | 0xfc);
    box_length++;

    ptBoxBuff[box_length] = (pstMp4Muxer->stHecvRecordParty.bitDepthLumaMinus8 | 0xf8);
    box_length++;

    ptBoxBuff[box_length] = (pstMp4Muxer->stHecvRecordParty.bitDepthChromaMinus8 | 0xf8);
    box_length++;

    shorttype = MOS_INET_HTONS(pstMp4Muxer->stHecvRecordParty.avgFrameRate);
    MOS_MEMCPY(ptBoxBuff + box_length , &shorttype, 2);
    box_length += 2;

    ptBoxBuff[box_length] = ( pstMp4Muxer->stHecvRecordParty.constantFrameRate << 6 |
                            pstMp4Muxer->stHecvRecordParty.numTemporalLayers << 5 |
                            pstMp4Muxer->stHecvRecordParty.temporalIdNested  << 2 |
                            pstMp4Muxer->stHecvRecordParty.lengthSizeMinusOne);
    box_length++;
// 30
    ptBoxBuff[box_length] =  pstMp4Muxer->stHecvRecordParty.numOfArrays;
    box_length++;

    ptBoxBuff[box_length] =  0x20; // nalu type vps 
    box_length++;

    ptBoxBuff[box_length] =  0x00;
    box_length++;

    ptBoxBuff[box_length] =  0x01;
    box_length++;

    shorttype = pstMp4Muxer->uiVpsLen;
    shorttype = MOS_INET_HTONS(shorttype);
    MOS_MEMCPY(ptBoxBuff + box_length , &shorttype, 2);
    box_length += 2;

    MOS_MEMCPY(ptBoxBuff + box_length , pstMp4Muxer->aucSpsPps, pstMp4Muxer->uiVpsLen);
    box_length +=  pstMp4Muxer->uiVpsLen;


    ptBoxBuff[box_length] =  0x21; // nalu type sps 
    box_length++;

    ptBoxBuff[box_length] =  0x00;
    box_length++;

    ptBoxBuff[box_length] =  0x01;
    box_length++;

    shorttype = pstMp4Muxer->uiSpsLen;
    shorttype = MOS_INET_HTONS(shorttype);
    MOS_MEMCPY(ptBoxBuff + box_length , &shorttype, 2);
    box_length += 2;
    
    MOS_MEMCPY(ptBoxBuff + box_length , pstMp4Muxer->aucSpsPps + pstMp4Muxer->uiVpsLen ,  pstMp4Muxer->uiSpsLen);
    box_length += pstMp4Muxer->uiSpsLen;


    ptBoxBuff[box_length] =  0x22; // nalu type pps 
    box_length++;

    ptBoxBuff[box_length] =  0x00;
    box_length++;

    ptBoxBuff[box_length] =  0x01;
    box_length++;

    shorttype = pstMp4Muxer->uiPpsLen;
    shorttype = MOS_INET_HTONS(shorttype);
    MOS_MEMCPY(ptBoxBuff + box_length , &shorttype, 2);
    box_length += 2;
    
    MOS_MEMCPY(ptBoxBuff + box_length , pstMp4Muxer->aucSpsPps + pstMp4Muxer->uiVpsLen + pstMp4Muxer->uiSpsLen,  pstMp4Muxer->uiPpsLen);
    box_length += pstMp4Muxer->uiPpsLen;

    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "hvcC", 4);
    return box_length;
}

static _INT  RdStg_Mp4Muxer_SetHev1(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

     _UI longtype;
    _US shorttype;
    _UI box_length = 8;

    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    
    longtype = 0x1000000;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    
    MOS_MEMSET(ptBoxBuff + box_length, 0, 16);
    box_length += 16;
    
    shorttype = Mos_InetHtons(pstMp4Muxer->usWidth);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    
    shorttype = Mos_InetHtons(pstMp4Muxer->usHeight);
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    
    longtype = MOS_INET_HTONL(0x00480000);
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    
    longtype = MOS_INET_HTONL(0x00480000);
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    
    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    
    shorttype = 0x0100;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    
    MOS_MEMSET(ptBoxBuff + box_length, 0, 32);//compressorname
    box_length += 32;
    
    shorttype = 0x1800;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    
    shorttype = 0xffff;
    MOS_MEMCPY(ptBoxBuff + box_length, &shorttype, 2);
    box_length += 2;
    
    box_length += RdStg_Mp4Muxer_SetHvcC(pstMp4Muxer, ptBoxBuff + box_length);
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "hev1", 4);
    return box_length;
}

static _INT  RdStg_Mp4Muxer_Setstsd(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI box_length = 8;
    longtype = 0;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    longtype = 0x1000000;
    MOS_MEMCPY(ptBoxBuff + box_length, &longtype, 4);
    box_length += 4;
    if(iFlag == 0)
    {
        if(pstMp4Muxer->ucHevcFlag == 0)
        {
            box_length += RdStg_Mp4Muxer_SetAvc1(pstMp4Muxer, ptBoxBuff + box_length);
        }
        else
        {
           box_length +=  RdStg_Mp4Muxer_SetHev1(pstMp4Muxer, ptBoxBuff + box_length);
        }
    }
    else if(iFlag == 1)
    {
        box_length += RdStg_Mp4Muxer_SetMp4a(pstMp4Muxer, ptBoxBuff + box_length);
    }
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "stsd", 4);
    return box_length;
}

static _INT  RdStg_Mp4Muxer_Setstts(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI box_length = 0;
    if(iFlag == 0){
        box_length = 16 + pstMp4Muxer->stts_v.num * 8;
        pstMp4Muxer->stts_v.size = Mos_InetHtonl(box_length);
        pstMp4Muxer->stts_v.num = Mos_InetHtonl(pstMp4Muxer->stts_v.num);
        MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stts_v), box_length);
    }else if(iFlag == 1){
        box_length = 16 + pstMp4Muxer->stts_a.num * 8;
        pstMp4Muxer->stts_a.size = Mos_InetHtonl(box_length);
        pstMp4Muxer->stts_a.num = Mos_InetHtonl(pstMp4Muxer->stts_a.num);
        MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stts_a), box_length);
    }
    return box_length;
}

static _INT RdStg_Mp4Muxer_Setstss(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI box_length = 0;
    box_length = 16 + pstMp4Muxer->stss_v.num * 4;
    pstMp4Muxer->stss_v.size = Mos_InetHtonl(box_length);
    pstMp4Muxer->stss_v.num = Mos_InetHtonl(pstMp4Muxer->stss_v.num);
    MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stss_v), box_length);
    return box_length;
}

static _INT RdStg_Mp4Muxer_Setstsc(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI box_length = 0;
    if(iFlag == 0){
        box_length = 16 + pstMp4Muxer->stsc_v.num * 12;
        pstMp4Muxer->stsc_v.size = Mos_InetHtonl(box_length);
        pstMp4Muxer->stsc_v.num = Mos_InetHtonl(pstMp4Muxer->stsc_v.num);
        MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stsc_v), box_length);
    }else if(iFlag == 1){
        box_length = 16 + pstMp4Muxer->stsc_a.num * 12;
        pstMp4Muxer->stsc_a.size = Mos_InetHtonl(box_length);
        pstMp4Muxer->stsc_a.num = Mos_InetHtonl(pstMp4Muxer->stsc_a.num);
        MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stsc_a), box_length);
    }
    return box_length;
}

static _INT RdStg_Mp4Muxer_SetStsz(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI box_length = 0;
    if (iFlag == 0)
    {
        box_length = 20 + pstMp4Muxer->stsz_v.num * 4;
        pstMp4Muxer->stsz_v.size = Mos_InetHtonl(box_length);
        pstMp4Muxer->stsz_v.num = Mos_InetHtonl(pstMp4Muxer->stsz_v.num);
        MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stsz_v), box_length);
    }
    else if (iFlag == 1)
    {
        box_length = 20 + pstMp4Muxer->stsz_a.num * 4;
        pstMp4Muxer->stsz_a.size = Mos_InetHtonl(box_length);
        pstMp4Muxer->stsz_a.num = Mos_InetHtonl(pstMp4Muxer->stsz_a.num);
        MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stsz_a), box_length);
    }
    return box_length;
}

static _INT RdStg_Mp4Muxer_SetStco(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI box_length = 0;
    if(iFlag == 0){
        box_length = 16 + pstMp4Muxer->stco_v.num * 4;
        pstMp4Muxer->stco_v.size = Mos_InetHtonl(box_length);
        pstMp4Muxer->stco_v.num = Mos_InetHtonl(pstMp4Muxer->stco_v.num);
        MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stco_v), box_length);
    }else if(iFlag == 1){
        box_length = 16 + pstMp4Muxer->stco_a.num * 4;
        pstMp4Muxer->stco_a.size = Mos_InetHtonl(box_length);
        pstMp4Muxer->stco_a.num = Mos_InetHtonl(pstMp4Muxer->stco_a.num);
        MOS_MEMCPY(ptBoxBuff, &(pstMp4Muxer->stco_a), box_length);
    }
    return box_length;
}

static _INT RdStg_Mp4Muxer_SetStbl(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI box_length = 8;
    box_length += RdStg_Mp4Muxer_Setstsd(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_Mp4Muxer_Setstts(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    if(iFlag == 0)
        box_length += RdStg_Mp4Muxer_Setstss(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_Mp4Muxer_Setstsc(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_Mp4Muxer_SetStsz(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_Mp4Muxer_SetStco(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "stbl", 4);
    return box_length;
}

static _INT RdStg_Mp4Muxer_SetDinf(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

     _UI longtype;
     _UI box_length = 8;
     _UC ttt[28] = {0x00, 0x00, 0x00, 0x1c, 0x64, 0x72, 0x65, 0x66,
                    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
                    0x00, 0x00, 0x00, 0x0c, 0x75, 0x72, 0x6c, 0x20,
                    0x00, 0x00, 0x00, 0x01};
     MOS_MEMCPY(ptBoxBuff + box_length, ttt, 28);
     box_length += 28;
     longtype = Mos_InetHtonl(box_length);
     MOS_MEMCPY(ptBoxBuff, &longtype, 4);
     MOS_MEMCPY(ptBoxBuff + 4, "dinf", 4);
     return box_length;
}

static _INT RdStg_Mp4Muxer_SetMinf(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI box_length = 8;
    if(iFlag == 0)
        box_length += RdStg_Mp4Muxer_SetVmhd(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    else if(iFlag == 1)
        box_length += RdStg_Mp4Muxer_SetSmhd(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_Mp4Muxer_SetDinf(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_Mp4Muxer_SetStbl(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    
//  *(unsigned long *)box_buf = htonl(box_length);
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "minf", 4);
    return box_length;
}

static _INT RdStg_SetMdia(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI box_length = 8;
    box_length += RdStg_Mp4Muxer_SetMdhd(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_Mp4Muxer_SetHdlr(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_Mp4Muxer_SetMinf(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "mdia", 4);
    return box_length;
}

static _INT RdStg_Mp4Muxer_SetTrak(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff, _INT iFlag)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI box_length = 8;
    box_length += RdStg_Mp4Muxer_SetTkhd(pstMp4Muxer, ptBoxBuff + box_length, iFlag);
    box_length += RdStg_SetMdia(pstMp4Muxer, ptBoxBuff + box_length, iFlag);

    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "trak", 4);
    return box_length;
}

// 写MP4文件的各个BOX
static _INT RdStg_SetMoov(ST_RDSTG_MP4MUXER* pstMp4Muxer,_UC *ptBoxBuff)
{
    MOS_PARAM_NULL_RETERR(pstMp4Muxer);
    MOS_PARAM_NULL_RETERR(ptBoxBuff);

    _UI longtype;
    _UI box_length = 8;
    box_length += RdStg_Mp4Muxer_SetMvhd(pstMp4Muxer, ptBoxBuff + box_length); 
    if(pstMp4Muxer->uiVideoCnt > 0)
        box_length += RdStg_Mp4Muxer_SetTrak(pstMp4Muxer, ptBoxBuff + box_length, 0);

    if(pstMp4Muxer->uiAudioCnt > 0)
        box_length += RdStg_Mp4Muxer_SetTrak(pstMp4Muxer, ptBoxBuff + box_length, 1);
    
    longtype = Mos_InetHtonl(box_length);
    MOS_MEMCPY(ptBoxBuff, &longtype, 4);
    MOS_MEMCPY(ptBoxBuff + 4, "moov", 4);
    return box_length;
}

// 关闭录像文件
_INT RdStg_Mp4Muxer_CloseFile(_HMP4MUXER hHandle, _UI uiFps)
{
    _UI  i              = 0;
    _INT j              = 0;
    _UI uiWriteLen      = 0;
    _UI uiBoxLength     = 0;
    //_UI uiTimeTotal   = 0;
    _UI uiWriteTotal    = 0;
    _UC *pucMoov = MOS_NULL;

    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL)
    {
        return -1;
    }

    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"task[%p] stopin",pstMp4Muxer);
    if((pstMp4Muxer->uiVideoCnt <= 0) || (pstMp4Muxer->hFileHandle == MOS_NULL))
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] write error %d %x",pstMp4Muxer, pstMp4Muxer->uiVideoCnt, pstMp4Muxer->hFileHandle);
        if(pstMp4Muxer->hFileHandle)
        {
            Mos_FileClose(pstMp4Muxer->hFileHandle);
            pstMp4Muxer->hFileHandle= NULL;
        }
        pstMp4Muxer->ucIsUsing = 0;
        return -1;
    }

    if(uiFps > 0 || pstMp4Muxer->uiPrevTimeStamp == 0)
    {
        if(uiFps > 0)
        {
            pstMp4Muxer->uiVideoFps = uiFps;
        }
        else
        {
            if(pstMp4Muxer->uiEndTime == pstMp4Muxer->uiStartTime)
            {
                pstMp4Muxer->uiVideoFps = 15;
            }
            else
            {
                pstMp4Muxer->uiVideoFps = pstMp4Muxer->uiVideoCnt/(_UI)(pstMp4Muxer->uiEndTime - pstMp4Muxer->uiStartTime);
                if(pstMp4Muxer->uiVideoFps <= 0)
                {
                    MOS_LOG_WARN(MEFC_MP4MUXER_LOG_ID,"task[%p] the frame rate is too small %u",pstMp4Muxer ,pstMp4Muxer->uiVideoFps);
                    pstMp4Muxer->uiVideoFps = 1;
                }
            }
        }

        pstMp4Muxer->uiVideoDuration = 0;
        pstMp4Muxer->stts_v.num      = 0;
        j = pstMp4Muxer->uiTps - pstMp4Muxer->uiTps/pstMp4Muxer->uiVideoFps * pstMp4Muxer->uiVideoFps;    
        if(j)
        {
            for(i = pstMp4Muxer->uiVideoFps; i < pstMp4Muxer->uiVideoCnt; i += pstMp4Muxer->uiVideoFps)
            {
                pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0]    = Mos_InetHtonl(j);
                pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num++][1]  = Mos_InetHtonl(pstMp4Muxer->uiTps/pstMp4Muxer->uiVideoFps + 1);
                pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0]    = Mos_InetHtonl(pstMp4Muxer->uiVideoFps - j);
                pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num++][1]  = Mos_InetHtonl(pstMp4Muxer->uiTps/pstMp4Muxer->uiVideoFps);
                pstMp4Muxer->uiVideoDuration += pstMp4Muxer->uiTps;
            }
            if(pstMp4Muxer->uiVideoCnt%pstMp4Muxer->uiVideoFps)
            {
                pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0]    = Mos_InetHtonl(pstMp4Muxer->uiVideoCnt%pstMp4Muxer->uiVideoFps);
                pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num++][1]  = Mos_InetHtonl(pstMp4Muxer->uiTps/pstMp4Muxer->uiVideoFps + 1);
                pstMp4Muxer->uiVideoDuration += (pstMp4Muxer->uiVideoCnt%pstMp4Muxer->uiVideoFps) * (pstMp4Muxer->uiTps/pstMp4Muxer->uiVideoFps + 1);
            }
            
        }
        else
        {
            pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0]    = Mos_InetHtonl(pstMp4Muxer->uiVideoCnt);
            pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num++][1]  = Mos_InetHtonl(pstMp4Muxer->uiTps/pstMp4Muxer->uiVideoFps);
            pstMp4Muxer->uiVideoDuration = pstMp4Muxer->uiVideoCnt  * (pstMp4Muxer->uiTps/pstMp4Muxer->uiVideoFps);
        }
    }
    else
    {
        pstMp4Muxer->stts_v.data[pstMp4Muxer->stts_v.num][0]++;
        pstMp4Muxer->stts_v.num++;
        // pstMp4Muxer->uiVideoDuration = pstMp4Muxer->uiPrevTimeStamp + pstMp4Muxer->stts_v.data[0][1];
        for(i = 0; i < pstMp4Muxer->stts_v.num;i++)
        {
            pstMp4Muxer->stts_v.data[i][0] = Mos_InetHtonl(pstMp4Muxer->stts_v.data[i][0]);
            pstMp4Muxer->stts_v.data[i][1] = Mos_InetHtonl(pstMp4Muxer->stts_v.data[i][1]);  
        }  
    }

    pstMp4Muxer->stsc_v.data[pstMp4Muxer->stsc_v.num][0]    = 0x1000000;
    pstMp4Muxer->stsc_v.data[pstMp4Muxer->stsc_v.num][1]    = 0x1000000;
    pstMp4Muxer->stsc_v.data[pstMp4Muxer->stsc_v.num++][2]  = 0x1000000;

    pstMp4Muxer->stts_a.num++;
    for(i = 0; i < pstMp4Muxer->stts_a.num;i++)
    {
        pstMp4Muxer->stts_a.data[i][0] = Mos_InetHtonl(pstMp4Muxer->stts_a.data[i][0]);
        pstMp4Muxer->stts_a.data[i][1] = Mos_InetHtonl(pstMp4Muxer->stts_a.data[i][1]);
    }

    pstMp4Muxer->stsc_a.data[pstMp4Muxer->stsc_a.num][0]    = 0x1000000;
    pstMp4Muxer->stsc_a.data[pstMp4Muxer->stsc_a.num][1]    = 0x1000000;
    pstMp4Muxer->stsc_a.data[pstMp4Muxer->stsc_a.num++][2]  = 0x1000000;
    pucMoov = (unsigned char *)MOS_MALLOC(10000+(pstMp4Muxer->uiVideoCnt+ pstMp4Muxer->uiAudioCnt)*16);
    if(pucMoov == MOS_NULL)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] malloc moov error",pstMp4Muxer);
        Mos_FileClose(pstMp4Muxer->hFileHandle);
        pstMp4Muxer->hFileHandle = NULL;
        pstMp4Muxer->ucIsUsing = 0;
        return -6;
    }

    pstMp4Muxer->uiDuration = pstMp4Muxer->uiVideoDuration;
    // 写MP4文件的各个BOX
    uiBoxLength = RdStg_SetMoov(pstMp4Muxer, pucMoov);
    
    if(RdStg_Mp4Muxer_FwriteCache(pstMp4Muxer,pucMoov, uiBoxLength) != MOS_OK)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] fwrite error",pstMp4Muxer);
        Mos_FileClose(pstMp4Muxer->hFileHandle);
        pstMp4Muxer->hFileHandle = NULL;
        pstMp4Muxer->ucIsUsing= 0;
        MOS_FREE(pucMoov);
        return -5;
    }

    MOS_FREE(pucMoov);
    uiWriteTotal += uiBoxLength;
    if(Mos_FileSeek(pstMp4Muxer->hFileHandle, MOS_FILE_SEEK_BEGIN, 0x18) != MOS_OK)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] fseek error",pstMp4Muxer);
        Mos_FileClose(pstMp4Muxer->hFileHandle);
        pstMp4Muxer->hFileHandle = NULL;
        pstMp4Muxer->ucIsUsing   = 0;
        return -5;
    }

    pstMp4Muxer->uiOffset = Mos_InetHtonl(pstMp4Muxer->uiOffset - 0x18);
    uiWriteLen = 4;
    pstMp4Muxer->uiErrCode = 0;
    if(Mos_FileWrite( pstMp4Muxer->hFileHandle,(_UC *)&(pstMp4Muxer->uiOffset),uiWriteLen) != uiWriteLen)
    {
        MOS_LOG_ERR(MEFC_MP4MUXER_LOG_ID,"task[%p] write error iWriteLen[%d]",uiWriteLen);
        Mos_FileClose(pstMp4Muxer->hFileHandle);
        pstMp4Muxer->hFileHandle = NULL;
        pstMp4Muxer->ucIsUsing   = 0;
        pstMp4Muxer->uiErrCode   = errno;
        return -5;
    }

    Mos_FileClose(pstMp4Muxer->hFileHandle);
    pstMp4Muxer->hFileHandle = MOS_NULL;
    pstMp4Muxer->ucIsUsing = 0;
    MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"task[%p] stop",pstMp4Muxer);
    return uiWriteTotal;
}

_UI RdStg_Mp4Muxer_GetErrtype(_HMP4MUXER hHandle)
{
    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(pstMp4Muxer == MOS_NULL)
    {
        return 0XFFFFFFFF;
    }
    return pstMp4Muxer->uiErrCode;
}

_UI RdStg_Mp4Muxer_GetWriteOffSet(_HMP4MUXER hHandle)
{
    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(NULL == pstMp4Muxer){
        return 0;
    }
    return pstMp4Muxer->uiOffset;
}

_UI RdStg_Mp4Muxer_GetLastTimeStamp(_HMP4MUXER hHandle)
{
    ST_RDSTG_MP4MUXER* pstMp4Muxer = RdStg_Mp4Muxer_GetMp4MuxerById((_UI)hHandle);
    if(NULL == pstMp4Muxer){
        return 0;
    }
    return pstMp4Muxer->uiEndTimeStamp;
}

_UI RdStg_Mp4Muxer_GetWriterByName(_UC *pucFileName, _UI *puiFileSize)
{
    MOS_PARAM_NULL_RETERR(pucFileName);

    _INT i;
    for(i = 0; i <  MP4MUXER_NODE_NUM; i++){
        if(NULL == RdStg_GetMp4MuxerMng()->apMp4Muxer[i]){
            return 0;
        }

        if(0 == RdStg_GetMp4MuxerMng()->apMp4Muxer[i]->ucIsUsing){
            continue;
        }
        if(MOS_STRCMP(pucFileName, RdStg_GetMp4MuxerMng()->apMp4Muxer[i]->aucFileName) == 0){
            if(puiFileSize){
                *puiFileSize = RdStg_GetMp4MuxerMng()->apMp4Muxer[i]->uiOffset;
            }
            MOS_LOG_INF(MEFC_MP4MUXER_LOG_ID,"file %s uid %u in recording ",pucFileName,RdStg_GetMp4MuxerMng()->apMp4Muxer[i]->uiUserId);
            return RdStg_GetMp4MuxerMng()->apMp4Muxer[i]->uiUserId;
        }
    }
    return 0;
}

// 判断是否回放正在录像的文件
_HMP4MUXER RdStg_Mp4Muxer_GetWritingWriter(_UC* pucFileName)
{
    MOS_PARAM_NULL_RETNULL(pucFileName);

    _INT i = 0;
    ST_RDSTG_MP4MUXER *pstMp4Muxer = MOS_NULL;
    for(i = 0; i <  MP4MUXER_NODE_NUM; i++)
    {
        pstMp4Muxer = RdStg_GetMp4MuxerMng()->apMp4Muxer[i];
        
        if((NULL != pstMp4Muxer) && pstMp4Muxer->ucIsUsing == 1 && pucFileName != MOS_NULL && pstMp4Muxer->aucFileName != MOS_NULL)
        {
            if(MOS_STRCMP(pstMp4Muxer->aucFileName,pucFileName) == 0)
            {
                return (_HMP4MUXER)pstMp4Muxer;
            }
        }
    }
    return MOS_NULL;
}
