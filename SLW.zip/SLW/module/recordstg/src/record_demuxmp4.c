#include "mos.h"
#include "zj_interface.h"
#include "config_type.h"
#include "media_cache_type.h"
#include "media_cache_api.h"
#include "record_mp4.h"
#include "record_mp4_prv.h"
#include "record_api.h"
#include "record_prv.h"

#define MAX_MP4_NODE_NUM       32

typedef struct
{
    _UC ucInitFlag;
    _UC ucRsv[3];
    _UC aucNaluId[4];
    _HMUTEX hMutex;
    ST_RDSTG_MP4DEMUXER *apstDeMuxer[MAX_MP4_NODE_NUM];
}ST_MP4_DEMUXTER_MNG;

static ST_MP4_DEMUXTER_MNG  g_stMediaMp4Mng = {0};

static ST_MP4_DEMUXTER_MNG * RdStg_GetDeMp4MuxterMng()
{
    return &g_stMediaMp4Mng;
}

// MP4解码初始化
_INT RdStg_Mp4DeMuxer_Init()
{
    if(RdStg_GetDeMp4MuxterMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(RDSTG_MP4LOG, "have init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stMediaMp4Mng, 0, sizeof(ST_MP4_DEMUXTER_MNG));
    if(Mos_MutexCreate(&RdStg_GetDeMp4MuxterMng()->hMutex) != MOS_OK){
        MOS_LOG_ERR(RDSTG_MP4LOG, "create lock fail");
        return MOS_ERR;
    }
    RdStg_GetDeMp4MuxterMng()->aucNaluId[3] = 1;
    RdStg_GetDeMp4MuxterMng()->ucInitFlag = 1;
    MOS_LOG_INF(RDSTG_MP4LOG, "mp4 demuxer init ok");
    return MOS_OK;
}

// MP4解码去初始化
_INT RdStg_Mp4DeMuxer_Destory()
{
    _UI i = 0;
    if(RdStg_GetDeMp4MuxterMng()->ucInitFlag == 0){
        MOS_LOG_WARN(RDSTG_MP4LOG, "not init");
        return MOS_OK;
    }
    Mos_MutexLock(&RdStg_GetDeMp4MuxterMng()->hMutex);
    for(i= 0; i < MAX_MP4_NODE_NUM; i++)
    {
        if(RdStg_GetDeMp4MuxterMng()->apstDeMuxer[i] != MOS_NULL)
        {
            MOS_FREE(RdStg_GetDeMp4MuxterMng()->apstDeMuxer[i]);
        }
    }
    Mos_MutexUnLock(&RdStg_GetDeMp4MuxterMng()->hMutex);
    Mos_MutexDelete(&RdStg_GetDeMp4MuxterMng()->hMutex);
    RdStg_GetDeMp4MuxterMng()->ucInitFlag = 0;
    MOS_LOG_INF(RDSTG_MP4LOG, "mp4 demuxer destory ok");
    return MOS_OK;
}

/*读录像文件数据 */
static _INT RdStg_Mp4DeMuxer_Read(_HFILE ptMp4Handle,_UC *ptReadBuff,_UI uiLenth)
{
    _INT iRetLen = -1;
    MOS_PARAM_NULL_RETERR(ptMp4Handle);
    MOS_PARAM_NULL_RETERR(ptReadBuff);

    iRetLen = Mos_FileRead(ptMp4Handle,ptReadBuff,uiLenth);
    return iRetLen;
}

static _VOID RdStg_Mp4DeMuxer_GetAacInf(_US usConfigInfo,_UI *puiAudioType, _UI *puiChannel, _UI *puiSampleRate, _UI *puiProfile)
{
    _US usTemp;
    if(usConfigInfo == 0)
    {
        *puiAudioType = 0;
        MOS_LOG_ERR(RDSTG_MP4LOG,"configinfo err");
        return;
    }
    usTemp = usConfigInfo >> 11;
    *puiProfile = usTemp - 1; 

    usTemp =  usConfigInfo << 5;
    usTemp = usTemp   >>12;
    *puiSampleRate = RdStg_AacGetSampleByIndex(usTemp);

    usTemp = usConfigInfo << 9;
    *puiChannel = usTemp >> 12;
    if(*puiChannel > 4)
    {
        *puiAudioType = *puiChannel % 4 + EN_ZJ_AUDIOENC_TYPE_G711A;
        *puiChannel = *puiChannel / 4;
    }
    else
    {
        *puiAudioType = EN_ZJ_AUDIOENC_TYPE_AAC;
    }
}

static _INT RdStg_Mp4DeMuxer_GetAudioTag(ST_RDSTG_MP4DEMUXER* pstMp4Demuxer)
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,16);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(pstMp4Demuxer->uiChannel), 2);
    pstMp4Demuxer->uiChannel = Mos_InetNtohs(pstMp4Demuxer->uiChannel);

    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,6);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(pstMp4Demuxer->uiAudioTps), 2);
    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,2);
    pstMp4Demuxer->uiAudioTps = Mos_InetNtohs(pstMp4Demuxer->uiAudioTps);
    pstMp4Demuxer->uiSampleRate = pstMp4Demuxer->uiAudioTps;
    return 0;
}

static _INT RdStg_Mp4DeMuxer_GetMp4a(ST_RDSTG_MP4DEMUXER* pstMp4Demuxer)
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _US usConfigInfo;
    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,24);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(pstMp4Demuxer->uiAudioTps), 2);
    
    pstMp4Demuxer->uiAudioTps = Mos_InetNtohs(pstMp4Demuxer->uiAudioTps);

    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,36);
    
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(usConfigInfo),2);
    usConfigInfo = Mos_InetNtohs(usConfigInfo);

    RdStg_Mp4DeMuxer_GetAacInf(usConfigInfo, &(pstMp4Demuxer->uiAudioType), &(pstMp4Demuxer->uiChannel), &(pstMp4Demuxer->uiSampleRate), &(pstMp4Demuxer->uiProfile));

    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 3);
    return 0;

}

static _INT RdStg_Mp4DeMuxer_GetAvc1(ST_RDSTG_MP4DEMUXER* pstMp4Demuxer)
{
    _US usSpsLen = 0, pps_len = 0;
    _US video_w = 0, video_h = 0;
    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 24);
    
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(video_w),2);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(video_h),2);
    
    pstMp4Demuxer->uiVideoWidth  = Mos_InetNtohs(video_w);
    pstMp4Demuxer->uiVideoHeight = Mos_InetNtohs(video_h);

    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 64);
    
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(usSpsLen), 2);
    
    usSpsLen = Mos_InetNtohs(usSpsLen);
    
    MOS_MEMCPY(pstMp4Demuxer->aucSpsPps, RdStg_GetDeMp4MuxterMng()->aucNaluId, 4);
    
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,pstMp4Demuxer->aucSpsPps + 4, usSpsLen);
    
    pstMp4Demuxer->uiSpsLen = usSpsLen + 4;

    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 1);
    
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(pps_len), 2);
    
    pps_len = Mos_InetNtohs(pps_len);
    MOS_MEMCPY(pstMp4Demuxer->aucSpsPps + pstMp4Demuxer->uiSpsLen, RdStg_GetDeMp4MuxterMng()->aucNaluId, 4);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle, pstMp4Demuxer->aucSpsPps + pstMp4Demuxer->uiSpsLen + 4, pps_len);
    pstMp4Demuxer->uiPpsLen = pps_len + 4;
    return 0;
}

static _INT RdStg_Mp4DeMuxer_GetHev1(ST_RDSTG_MP4DEMUXER* pstMp4Demuxer)
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _US usSpsLen = 0, pps_len = 0,usVpsLen = 0;
    _US video_w = 0, video_h = 0;
    _UC aucBuff[32];
    _UC ucArryCnt = 0;
    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 24);
    
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(video_w),2);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(video_h),2);
    
    pstMp4Demuxer->uiVideoWidth  = Mos_InetNtohs(video_w);
    pstMp4Demuxer->uiVideoHeight = Mos_InetNtohs(video_h);

    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 80);
    
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)aucBuff, 4);
    ucArryCnt = aucBuff[0];
    if(aucBuff[1] == 0x20)
    {
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&usVpsLen, 2);
        usVpsLen = MOS_INET_NTOHS(usVpsLen);
        pstMp4Demuxer->uiVpsLen = usVpsLen + 4;
        MOS_MEMCPY(pstMp4Demuxer->aucSpsPps, RdStg_GetDeMp4MuxterMng()->aucNaluId, 4);
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)pstMp4Demuxer->aucSpsPps+4, usVpsLen);
    }
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)aucBuff, 3);
    if(aucBuff[0] == 0x21)
    {
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&usSpsLen, 2);
        usSpsLen = MOS_INET_NTOHS(usSpsLen);
        pstMp4Demuxer->uiSpsLen = usSpsLen + 4;
        MOS_MEMCPY(pstMp4Demuxer->aucSpsPps + pstMp4Demuxer->uiVpsLen, RdStg_GetDeMp4MuxterMng()->aucNaluId, 4);
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)pstMp4Demuxer->aucSpsPps + pstMp4Demuxer->uiVpsLen +4, usSpsLen);
    }

    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)aucBuff, 3);
    if(aucBuff[0] == 0x22)
    {
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&pps_len, 2);
        pps_len = MOS_INET_NTOHS(pps_len);
        MOS_MEMCPY(pstMp4Demuxer->aucSpsPps + pstMp4Demuxer->uiVpsLen + pstMp4Demuxer->uiSpsLen, RdStg_GetDeMp4MuxterMng()->aucNaluId, 4);
        pstMp4Demuxer->uiPpsLen = pps_len + 4;
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)pstMp4Demuxer->aucSpsPps + pstMp4Demuxer->uiVpsLen + pstMp4Demuxer->uiSpsLen + 4, pps_len);
    }
    return 0;
}

static _INT  RdStg_Mp4DeMuxer_GetStsd(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer, _UI iFlag)//0 video,1 audio
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _UI uiBoxSize = 0;
    _UC box_name[4];

    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 8);

    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&uiBoxSize,4);
    
    uiBoxSize = Mos_InetNtohl(uiBoxSize) - 8;
    
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,box_name,4);

    if(MOS_STRNCMP(box_name, "mp4a", 4) == 0){
        RdStg_Mp4DeMuxer_GetMp4a(pstMp4Demuxer);
    }else if(MOS_STRNCMP(box_name, "avc1", 4) == 0){
        RdStg_Mp4DeMuxer_GetAvc1(pstMp4Demuxer);
        pstMp4Demuxer->uiVideoType = EN_ZJ_VIDEOENC_TYPE_H264;
    }
    else if(MOS_STRNCMP(box_name, "hev1", 4) == 0)
    {
        RdStg_Mp4DeMuxer_GetHev1(pstMp4Demuxer);
        pstMp4Demuxer->uiVideoType = EN_ZJ_VIDEOENC_TYPE_H265;
    }
    else if(MOS_STRNCMP(box_name, "ulaw", 4) == 0){
        RdStg_Mp4DeMuxer_GetAudioTag(pstMp4Demuxer);
        pstMp4Demuxer->uiAudioType = EN_ZJ_AUDIOENC_TYPE_G711U;
    }else if(MOS_STRNCMP(box_name, "alaw", 4) == 0){
        RdStg_Mp4DeMuxer_GetAudioTag(pstMp4Demuxer);
        pstMp4Demuxer->uiAudioType = EN_ZJ_AUDIOENC_TYPE_G711A;
    }else if(MOS_STRNCMP(box_name, "sowt", 4) == 0){
        RdStg_Mp4DeMuxer_GetAudioTag(pstMp4Demuxer);
        pstMp4Demuxer->uiAudioType = EN_ZJ_AUDIOENC_TYPE_PCM16;
    }else if(MOS_STRNCMP(box_name, ".mp3", 4) == 0){
        RdStg_Mp4DeMuxer_GetAudioTag(pstMp4Demuxer);
        pstMp4Demuxer->uiAudioType = EN_ZJ_AUDIOENC_TYPE_MP3;
    }else{
        return -1;
    }
    return 0;
}

static _INT RdStg_Mp4DeMuxer_GetStts(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer, _UI iFlag)//0 video,1 audio
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _UI i, j, uiNum = 0, uiSampleNum = 0, sample_duration = 0, uiFrameCnt = 0;
    _UI *ptStts;
    if(iFlag == 0)
        ptStts = pstMp4Demuxer->stts_v;
    else if(iFlag == 1)
        ptStts = pstMp4Demuxer->stts_a;
    else
        return -1;
    
    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 4);
    
    RdStg_Mp4DeMuxer_Read( pstMp4Demuxer->hFileHandle,(_UC *)&uiNum, 4);
    
    uiNum = Mos_InetNtohl(uiNum);

    for(i = 0; i < uiNum; i++)
    {
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&uiSampleNum, 4);
        uiSampleNum = Mos_InetNtohl(uiSampleNum);
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&sample_duration,4);
        sample_duration = Mos_InetNtohl(sample_duration);
        for(j = 0; j < uiSampleNum; j++)
        {
            ptStts[uiFrameCnt++] = sample_duration;
        }
    }
    if(iFlag == 0)
        pstMp4Demuxer->uiVideoNum= uiFrameCnt;
    else if(iFlag == 1)
        pstMp4Demuxer->uiAudioNum= uiFrameCnt;
    return 0;
}

static _INT RdStg_Mp4DeMuxer_GetStsc(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer, _UI iFlag)//0 video,1 audio
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _UI i,uiNum = 0, uiThunkIndex = 0, uiSampleNum = 0, uiThunkCnt = 0;
    _UI *ptStsc;
    if(iFlag == 0)
        ptStsc = pstMp4Demuxer->stsc_v;
    else if(iFlag == 1)
        ptStsc = pstMp4Demuxer->stsc_a;
    else
        return -1;
    
    Mos_FileSeek(pstMp4Demuxer->hFileHandle, MOS_FILE_SEEK_CUR,4);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&uiNum, 4);
    uiNum = Mos_InetNtohl(uiNum);
    
    for(i = 0; i < uiNum; i++){
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&uiThunkIndex, 4);
        uiThunkIndex = Mos_InetNtohl(uiThunkIndex);
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&uiSampleNum, 4);
        uiSampleNum = Mos_InetNtohl(uiSampleNum);
        Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 4);
        for(;uiThunkCnt < uiThunkIndex - 1; uiThunkCnt++){
                ptStsc[uiThunkCnt] = ptStsc[uiThunkCnt - 1];
        }
        ptStsc[uiThunkIndex - 1] = uiSampleNum;
        uiThunkCnt++;
    }
    for(;uiThunkCnt < 1; uiThunkCnt++){
        ptStsc[uiThunkCnt] = ptStsc[uiThunkCnt - 1];
    }
    return 0;
}

static _INT RdStg_Mp4DeMuxer_GetStsz(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer, _UI iFlag) //0 video,1 audio
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _UI i            = 0;
    _UI uiNum        = 0;
    _UI uiSampleSize = 0;
    _UI *ptstsz      = MOS_NULL;

    if (iFlag == 0)
    {
        ptstsz = pstMp4Demuxer->stsz_v;
    }
    else if (iFlag == 1)
    {
        ptstsz = pstMp4Demuxer->stsz_a;
    }
    else
    {
        return -1;
    }

    Mos_FileSeek(pstMp4Demuxer->hFileHandle, MOS_FILE_SEEK_CUR,8);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&uiNum, 4);

    uiNum = Mos_InetNtohl(uiNum);
    for(i = 0; i < uiNum; i++)
    {
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle, (_UC *)&uiSampleSize, 4);
        ptstsz[i] = Mos_InetNtohl(uiSampleSize);
        if(ptstsz[i] > pstMp4Demuxer->uiMaxFrameSize)
        {
            pstMp4Demuxer->uiMaxFrameSize = ptstsz[i];
        }
    }

    if (iFlag == 0)
    {
        pstMp4Demuxer->uiVideoNum= uiNum;
    }
    else if (iFlag == 1)
    {
        pstMp4Demuxer->uiAudioNum= uiNum;
    }

    return 0;
}

static _INT RdStg_Mp4DeMuxer_GetStco(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer, _UI iFlag)//0 video,1 audio
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _UI i, uiNum = 0, uiThunkAddr = 0;
    _UI *stco;
    if(iFlag == 0)
        stco = pstMp4Demuxer->stco_v;
    else if(iFlag == 1)
        stco = pstMp4Demuxer->stco_a;
    else
        return -1;
    
    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR, 4);

    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&uiNum,4);
    uiNum = Mos_InetNtohl(uiNum);
    if (uiNum > MAX_VIDEOFRAME)
    {
        uiNum = MAX_VIDEOFRAME;
    }

    for(i = 0; i < uiNum; i++)
    {
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&uiThunkAddr,4);
        stco[i] = Mos_InetNtohl(uiThunkAddr);
    }

    if(iFlag == 0)
        pstMp4Demuxer->uiVideoThunkNum = uiNum;
    else if(iFlag == 1)
        pstMp4Demuxer->uiAudioThunkNum = uiNum;
    return 0;
}

static _INT  RdStg_Mp4DeMuxer_GetStss(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer)
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _UI i = 0;
    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,4);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(pstMp4Demuxer->uiIdrNum), 4);
    pstMp4Demuxer->uiIdrNum = Mos_InetNtohl(pstMp4Demuxer->uiIdrNum);
    RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(pstMp4Demuxer->stss_v[0]), 4 * pstMp4Demuxer->uiIdrNum);
    for( i = 0; i < pstMp4Demuxer->uiIdrNum; i++)
    {
        pstMp4Demuxer->stss_v[i] = Mos_InetNtohl(pstMp4Demuxer->stss_v[i]);
    }
    return 0;

}

static _VOID RdStg_Mp4DeMuxer_Gethdrf(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer,_UC *ptBuff)
{
    MOS_PARAM_NULL_NORET(pstMp4Demuxer);

    _UC * ptTmp = MOS_NULL;
    if(ptBuff == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_MP4LOG,"circle ptBuff is Null");
    }
    ptTmp = MOS_STRSTR(ptBuff, "radius=");
    if(ptTmp )
    {
        ptTmp += MOS_STRLEN("radius=");
        pstMp4Demuxer->stCircle.uiRadius = MOS_ATOI(ptTmp);
    }
    ptTmp = MOS_STRSTR(ptBuff, "ccx1=");
    if(ptTmp)
    {
        ptTmp += MOS_STRLEN("ccx1=");
        pstMp4Demuxer->stCircle.uiCc1x= MOS_ATOI(ptTmp);
    }
    ptTmp = MOS_STRSTR(ptBuff, "ccy1=");
    if(ptTmp)
    {
        ptTmp += MOS_STRLEN("ccy1=");
        pstMp4Demuxer->stCircle.uiCc1Y = MOS_ATOI(ptTmp);
    }

    ptTmp = MOS_STRSTR(ptBuff, "ccx2=");
    if(ptTmp)
    {
        ptTmp += MOS_STRLEN("ccx2=");
        pstMp4Demuxer->stCircle.uiCc2x = MOS_ATOI(ptTmp);
    }

    ptTmp = MOS_STRSTR(ptBuff, "ccy2=");
    if(ptTmp)
    {
        ptTmp += MOS_STRLEN("ccy2=");
        pstMp4Demuxer->stCircle.uiCc2Y = MOS_ATOI(ptTmp);
    }
    ptTmp = MOS_STRSTR(ptBuff, "angle=");
    if(ptTmp)
    {
        ptTmp += MOS_STRLEN("angle=");
        pstMp4Demuxer->stCircle.doubleAngle = atof(ptTmp);
    }
    return;
}

// 读取MP4文件的各个BOX
static _INT RdStg_Mp4DeMuxer_ReadHead(ST_RDSTG_MP4DEMUXER* pstMp4Demuxer)
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);

    _UI uiBoxSize = 0;
    _UC box_name[8];
    _UI is_audio_trak = 0;
    _UI uiVideoTps = 0;
    _UI iRet = -1;
    
    MOS_MEMSET(box_name, 0, sizeof(box_name));

    while(RdStg_GetMng()->ucInitFlag)
    {
        iRet = RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle, (_UC *)&uiBoxSize, 4);
        if(iRet != 4 )
        {
            break;
        }
        uiBoxSize = Mos_InetNtohl(uiBoxSize);
        if(uiBoxSize < 8)
            break;
        uiBoxSize -= 8;
            
        if(Mos_FileEof(pstMp4Demuxer->hFileHandle))
        {
            break;
        }
        iRet = RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,box_name, 4);
        if(iRet < 4)
            break;

        // MOS_BUFPRINTF("box_name", (_UC *)box_name, 4);
        // MOS_LOG_INF(RDSTG_MP4LOG,"-------------box_name %s--------uiBoxSize %d--------", box_name, uiBoxSize);

        if(MOS_STRNCMP(box_name, "moov", 4) == 0)
        {
            continue;
        }
        else if(MOS_STRNCMP(box_name, "trak", 4) == 0){
            continue;
        }else if(MOS_STRNCMP(box_name, "mdia", 4) == 0){
            continue;   
        }else if(MOS_STRNCMP(box_name, "mdhd", 4) == 0){
            Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,12);
            RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC *)&(uiVideoTps),4);
            uiVideoTps = Mos_InetNtohl(uiVideoTps);
            Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,8);
        }else if(MOS_STRNCMP(box_name, "hdlr", 4) == 0){
            _UC tag[512] = {0};
            Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,24);
            RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,(_UC*)tag,uiBoxSize - 24);
            RdStg_Mp4DeMuxer_Gethdrf(pstMp4Demuxer,tag);
        }else if(MOS_STRNCMP(box_name, "smhd", 4) == 0){
            is_audio_trak = 1;
            Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,uiBoxSize);
        }else if(MOS_STRNCMP(box_name, "vmhd", 4) == 0){
            is_audio_trak = 0;
            pstMp4Demuxer->uiVideoTps = uiVideoTps;
            Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,uiBoxSize);
        }else if(MOS_STRNCMP(box_name, "minf", 4) == 0){
            continue;   
        }else if(MOS_STRNCMP(box_name, "stbl", 4) == 0){
            continue;   
        }else if(MOS_STRNCMP(box_name, "stsd", 4) == 0){
            RdStg_Mp4DeMuxer_GetStsd(pstMp4Demuxer, is_audio_trak);
        }else if(MOS_STRNCMP(box_name, "stts", 4) == 0){
            RdStg_Mp4DeMuxer_GetStts(pstMp4Demuxer, is_audio_trak);
        }else if(MOS_STRNCMP(box_name, "stss", 4) == 0){
            RdStg_Mp4DeMuxer_GetStss(pstMp4Demuxer);
        }else if(MOS_STRNCMP(box_name, "stsc", 4) == 0){
            RdStg_Mp4DeMuxer_GetStsc(pstMp4Demuxer, is_audio_trak);
        }else if(MOS_STRNCMP(box_name, "stsz", 4) == 0){
            RdStg_Mp4DeMuxer_GetStsz(pstMp4Demuxer, is_audio_trak);
        }else if(MOS_STRNCMP(box_name, "stco", 4) == 0){
            RdStg_Mp4DeMuxer_GetStco(pstMp4Demuxer, is_audio_trak);
        }else
        {
            if(uiBoxSize > 0)
            {
                Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,uiBoxSize);
            }
            else
            {
                 MOS_LOG_WARN(RDSTG_MP4LOG,"mp4 file error, may not a mp4 or file is destory");
            }
        }   
    }
    return pstMp4Demuxer->uiMaxFrameSize;
}

static _INT RdStg_Mp4DeMuxer_ReadWritingHead(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer, ST_RDSTG_MP4MUXER *pstMp4muxer)
{
    MOS_PARAM_NULL_RETERR(pstMp4Demuxer);
    MOS_PARAM_NULL_RETERR(pstMp4muxer);

    if(&pstMp4muxer->stCircle){
        pstMp4Demuxer->stCircle = pstMp4muxer->stCircle;
    }

    if(pstMp4muxer->uiAudioType){
        pstMp4Demuxer->uiAudioType = pstMp4muxer->uiAudioType;
    }

    if(pstMp4muxer->uiSampleRate){
        pstMp4Demuxer->uiSampleRate = pstMp4muxer->uiSampleRate;
    }

    if(pstMp4muxer->uiProfile){
        pstMp4Demuxer->uiProfile = pstMp4muxer->uiProfile;
    }

    if(pstMp4muxer->usChannelCount){
        pstMp4Demuxer->uiChannel = pstMp4muxer->usChannelCount;
    }

    if(pstMp4muxer->usHeight){
        pstMp4Demuxer->uiVideoHeight = pstMp4muxer->usHeight;
    }

    if(pstMp4muxer->usWidth){
        pstMp4Demuxer->uiVideoWidth  = pstMp4muxer->usWidth;
    }

    if(pstMp4muxer->ucHevcFlag == 1){
        pstMp4Demuxer->uiVideoType = EN_ZJ_VIDEOENC_TYPE_H265;
    }else{
        pstMp4Demuxer->uiVideoType = EN_ZJ_VIDEOENC_TYPE_H264;
    }
    return MOS_OK;
}

static _VOID  RdStg_Mp4DeMuxer_SetDemux(ST_RDSTG_MP4DEMUXER* pstMp4Demuxer)
{
    MOS_PARAM_NULL_NORET(pstMp4Demuxer);

    _UI i       = 0;
    _UI j       = 0;
    _UI add     = 0;
    _UI uiCnt   = 0;
    _UI uiTmp   = 0;

    for(i = 0; i < pstMp4Demuxer->uiVideoNum; i++)
    {
        // 记录当前帧相对于文件第一帧的偏移时间差
        uiTmp = pstMp4Demuxer->stts_v[i];
        pstMp4Demuxer->stts_v[i] = add / pstMp4Demuxer->uiVideoTps* 1000 + (add%pstMp4Demuxer->uiVideoTps) * 1000 / pstMp4Demuxer->uiVideoTps;
        add += uiTmp;
    }

    add = 0;
    for(i = 0; i < pstMp4Demuxer->uiAudioNum; i++)
    {
        // 记录当前帧相对于文件第一帧的偏移时间差
        uiTmp = pstMp4Demuxer->stts_a[i];
        pstMp4Demuxer->stts_a[i] = add / pstMp4Demuxer->uiAudioTps* 1000 + (add%pstMp4Demuxer->uiAudioTps) * 1000 / pstMp4Demuxer->uiAudioTps;
        add += uiTmp;
    }

    uiCnt = 0;
    for(i = 0; i < pstMp4Demuxer->uiAudioThunkNum; i++)
    {
        add = 0;
        for(j = 0; j < pstMp4Demuxer->stsc_a[0]; j++)
        {
            // 记录当前帧相对于文件头的偏移字节数
            pstMp4Demuxer->stco_a[uiCnt] = pstMp4Demuxer->stco_a[i] + add;
            add += pstMp4Demuxer->stsz_a[uiCnt];
            uiCnt++;
            if (uiCnt == 40000)
            {
                break;
            }
        }
    }

    if(pstMp4Demuxer->uiVideoNum== 0)
    {
        pstMp4Demuxer->stts_v[0] = 1000000000;
        pstMp4Demuxer->stco_v[0] = 1000000000;
    }
    if(pstMp4Demuxer->uiAudioNum== 0)
    {
        pstMp4Demuxer->stts_a[0] = 1000000000;
        pstMp4Demuxer->stco_a[0] = 1000000000;
    }

    if(pstMp4Demuxer->stco_a[0] > pstMp4Demuxer->stco_v[0])
    {
        Mos_FileSeek(pstMp4Demuxer->hFileHandle, MOS_FILE_SEEK_BEGIN, pstMp4Demuxer->stco_v[0]);   
    }
    else
    {
        Mos_FileSeek(pstMp4Demuxer->hFileHandle, MOS_FILE_SEEK_BEGIN, pstMp4Demuxer->stco_a[0]);
    }

}

static _VOID RdStg_Mp4DeMuxer_SetWritingDemux(ST_RDSTG_MP4DEMUXER *pstMp4Demuxer, ST_RDSTG_MP4MUXER *pstMp4muxer)
{
    MOS_PARAM_NULL_NORET(pstMp4Demuxer);
    MOS_PARAM_NULL_NORET(pstMp4muxer);

    _UI i = 0, j = 0, k = 0, uiCnt = 0;
    _UI add = 0;
    _UI uiAudioDuration = 0,uiVideoDuration = 0;
    pstMp4Demuxer->uiVideoNum = pstMp4muxer->uiVideoCnt;
    pstMp4Demuxer->uiAudioNum = pstMp4muxer->uiAudioCnt;
    pstMp4Demuxer->uiIdrNum   = pstMp4muxer->stss_v.num;

    for(i = 0; i < pstMp4Demuxer->uiVideoNum; i++)
    {
        if(i != 0)
        {
            _INT time_dur = 0;
            if(j == pstMp4muxer->stts_v.data[k][0])
            {
                j = 0;
                k++;
            }
            time_dur = pstMp4muxer->stts_v.data[k][1] / pstMp4muxer->uiTps * 1000 + pstMp4muxer->stts_v.data[k][1] % pstMp4muxer->uiTps * 1000 / pstMp4muxer->uiTps;
            uiVideoDuration += time_dur;
            j++;
        }
        if(i <= pstMp4muxer->stss_v.num){
            pstMp4Demuxer->stss_v[i] = Mos_InetNtohl(pstMp4muxer->stss_v.data[i]);
        }
        pstMp4Demuxer->stts_v[i] = uiVideoDuration;
        pstMp4Demuxer->stsz_v[i] = Mos_InetNtohl(pstMp4muxer->stsz_v.data[i]);
        pstMp4Demuxer->stco_v[i] = Mos_InetNtohl(pstMp4muxer->stco_v.data[i]);
    }

    j = 0;
    k = 0;
    for(i = 0; i < pstMp4Demuxer->uiAudioNum; i++)
    {
        if(i != 0)
        {
            _INT time_dur = 0;
            if(j == pstMp4muxer->stts_a.data[k][0])
            {
                j = 0;
                k++;
            }
            time_dur = pstMp4muxer->stts_a.data[k][1] / pstMp4muxer->uiSampleRate * 1000 + pstMp4muxer->stts_a.data[k][1] % pstMp4muxer->uiSampleRate * 1000 / pstMp4muxer->uiSampleRate;
            uiAudioDuration += time_dur;
            j++;
        }
        pstMp4Demuxer->stts_a[i] = uiAudioDuration;
        pstMp4Demuxer->stsz_a[i] = Mos_InetNtohl(pstMp4muxer->stsz_a.data[i]);
        pstMp4Demuxer->stco_a[i] = Mos_InetNtohl(pstMp4muxer->stco_a.data[i]);
    }
    if(pstMp4Demuxer->uiVideoNum== 0){
        pstMp4Demuxer->stts_v[0] = 1000000000;
        pstMp4Demuxer->stco_v[0] = 1000000000;
    }
    if(pstMp4Demuxer->uiAudioNum== 0){
        pstMp4Demuxer->stts_a[0] = 1000000000;
        pstMp4Demuxer->stco_a[0] = 1000000000;
    }
    MOS_MEMCPY(pstMp4Demuxer->aucSpsPps,pstMp4muxer->aucSpsPps,1024);
    if(pstMp4Demuxer->stco_a[0] > pstMp4Demuxer->stco_v[0])
        Mos_FileSeek(pstMp4Demuxer->hFileHandle,  MOS_FILE_SEEK_BEGIN,pstMp4Demuxer->stco_v[0]);
    else
        Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_BEGIN, pstMp4Demuxer->stco_a[0]);

    return;
}

// set userID
static _VOID Mefc_Mp4DeMuxer_OpenSetMp4DeMuxer(ST_RDSTG_MP4DEMUXER *pstMefcMp4DeMuxer)
{
    MOS_PARAM_NULL_NORET(pstMefcMp4DeMuxer);

    _UI uiUserId = pstMefcMp4DeMuxer->uiUserId;
    MOS_MEMSET(pstMefcMp4DeMuxer, 0, sizeof(ST_RDSTG_MP4DEMUXER));
    pstMefcMp4DeMuxer->uiUserId = uiUserId;
}

// 打开录像文件 并获取回放的录像文件的配置信息
_HMP4DEMUXER RdStg_Mp4DeMuxer_OpenFile(_UC *pucFileName)
{
    _UI i;
    ST_RDSTG_MP4MUXER   *pstMefcMp4Muxer   = MOS_NULL;
    ST_RDSTG_MP4DEMUXER *pstMefcMp4DeMuxer = MOS_NULL;
    if(pucFileName == MOS_NULL){
        MOS_LOG_ERR(RDSTG_MP4LOG,"in pucFileName");
        return MOS_NULL;
    }
    Mos_MutexLock(&RdStg_GetDeMp4MuxterMng()->hMutex);
    for(i = 0; i < MAX_MP4_NODE_NUM; i++)
    {
        if(RdStg_GetDeMp4MuxterMng()->apstDeMuxer[i] == NULL)
        {
            RdStg_GetDeMp4MuxterMng()->apstDeMuxer[i] = (ST_RDSTG_MP4DEMUXER *)MOS_MALLOCCLR(sizeof(ST_RDSTG_MP4DEMUXER));
            pstMefcMp4DeMuxer = RdStg_GetDeMp4MuxterMng()->apstDeMuxer[i];
            if(pstMefcMp4DeMuxer == MOS_NULL){
                MOS_LOG_ERR(RDSTG_MP4LOG,"malloc fail");
                Mos_MutexUnLock(&RdStg_GetDeMp4MuxterMng()->hMutex);
                return MOS_NULL;
            }
            MOS_MEMSET(pstMefcMp4DeMuxer,0,sizeof(ST_RDSTG_MP4DEMUXER));
            pstMefcMp4DeMuxer->uiUserId = i;
            break;
        }
        else if(RdStg_GetDeMp4MuxterMng()->apstDeMuxer[i]->ucIsUsing == 0)
        {
            pstMefcMp4DeMuxer = RdStg_GetDeMp4MuxterMng()->apstDeMuxer[i];
            break;
        }
    }
    if(pstMefcMp4DeMuxer == MOS_NULL)
    {
        Mos_MutexUnLock(&RdStg_GetDeMp4MuxterMng()->hMutex);
        MOS_LOG_ERR(RDSTG_MP4LOG,"too many road");
        return MOS_NULL;
    }

    // set userID
    Mefc_Mp4DeMuxer_OpenSetMp4DeMuxer(pstMefcMp4DeMuxer);
    pstMefcMp4DeMuxer->uiUserId += MAX_MP4_NODE_NUM;
    pstMefcMp4DeMuxer->ucIsUsing = 1; 
    Mos_MutexUnLock(&RdStg_GetDeMp4MuxterMng()->hMutex);

    // 打开录像文件
    pstMefcMp4DeMuxer->hFileHandle = Mos_FileOpen(pucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if(pstMefcMp4DeMuxer->hFileHandle == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_MP4LOG,"open %s err",pucFileName);
        pstMefcMp4DeMuxer->ucIsUsing = 0;
        return MOS_NULL;
    }

    MOS_LOG_INF(RDSTG_MP4LOG,"open %s successful", pucFileName);
    MOS_STRNCPY(pstMefcMp4DeMuxer->aucFileName,pucFileName,sizeof(pstMefcMp4DeMuxer->aucFileName));
    // 判断是否回放正在录像的文件
    pstMefcMp4Muxer = (ST_RDSTG_MP4MUXER *)RdStg_Mp4Muxer_GetWritingWriter(pucFileName);
    if(pstMefcMp4Muxer != MOS_NULL)
    {
        // 回放正在录像的文件
        RdStg_Mp4DeMuxer_ReadWritingHead(pstMefcMp4DeMuxer,pstMefcMp4Muxer);
        RdStg_Mp4DeMuxer_SetWritingDemux(pstMefcMp4DeMuxer,pstMefcMp4Muxer);
        MOS_LOG_INF(RDSTG_MP4LOG,"Mp4 file is writing ,name: %s",pucFileName);
    }
    else
    {
        // 回放已录像的文件
        // 读取MP4各个BOX
        RdStg_Mp4DeMuxer_ReadHead(pstMefcMp4DeMuxer);
        RdStg_Mp4DeMuxer_SetDemux(pstMefcMp4DeMuxer);
        MOS_LOG_INF(RDSTG_MP4LOG,"Mp4 file was wrote ,name: %s",pucFileName);
    }

    MOS_LOG_INF(RDSTG_MP4LOG,"task[%p] taskid[%u] pucFileName[%s] create",pstMefcMp4DeMuxer,pstMefcMp4DeMuxer->uiUserId, pucFileName);
    return (_HMP4DEMUXER)(pstMefcMp4DeMuxer->uiUserId);
}

// 获取当前读取的录像文件的解码结构体
ST_RDSTG_MP4DEMUXER* RdStg_Mp4DeMuxer_GetNodeId(_UI uiUserId)
{
    ST_RDSTG_MP4DEMUXER* pstMp4DeMuxer = RdStg_GetDeMp4MuxterMng()->apstDeMuxer[uiUserId % MAX_MP4_NODE_NUM];
    if(pstMp4DeMuxer == MOS_NULL || (pstMp4DeMuxer->ucIsUsing == 0) || (pstMp4DeMuxer->uiUserId != uiUserId))
    {
        MOS_LOG_ERR(RDSTG_MP4LOG,"task[pstMp4DeMuxer] taskid[%u] not found",uiUserId);
        return MOS_NULL;
    }
    return pstMp4DeMuxer;
}

_INT RdStg_Mp4DeMuxer_CheckFileEnd(_HMP4DEMUXER hHandle)
{
    ST_RDSTG_MP4MUXER *pstMefcMp4Muxer = MOS_NULL;
    // 获取当前读取的录像文件的解码结构体
    ST_RDSTG_MP4DEMUXER *pstMefcMp4DeMuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);

    pstMefcMp4Muxer = (ST_RDSTG_MP4MUXER *)RdStg_Mp4Muxer_GetWritingWriter(pstMefcMp4DeMuxer->aucFileName);
    if(pstMefcMp4Muxer == MOS_NULL)
    {
        // 打开录像文件 并获取回放的录像文件的配置信息
        _HMP4DEMUXER hTmpDemuxer = RdStg_Mp4DeMuxer_OpenFile(pstMefcMp4DeMuxer->aucFileName);
        // 获取当前读取的录像文件的解码结构体
        ST_RDSTG_MP4DEMUXER *pstTmpMp4DeMuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hTmpDemuxer);
        // 关闭录像文件
        RdStg_Mp4DeMuxer_CloseFile(hTmpDemuxer);
        if(pstTmpMp4DeMuxer->uiIdrNum > pstMefcMp4DeMuxer->uiIdrNum)
        {
            pstTmpMp4DeMuxer->uiVideoCnt = pstMefcMp4DeMuxer->uiVideoCnt;
            pstTmpMp4DeMuxer->uiAudioCnt = pstMefcMp4DeMuxer->uiAudioCnt;
            MOS_MEMCPY(pstMefcMp4DeMuxer,pstTmpMp4DeMuxer,sizeof(ST_RDSTG_MP4DEMUXER));
            return 0;
        }
        else
        {
            return 1;
        }
    }
    else
    {
        RdStg_Mp4DeMuxer_SetWritingDemux(pstMefcMp4DeMuxer,pstMefcMp4Muxer);
    }
    return 0;
}

// 关闭录像文件
_INT RdStg_Mp4DeMuxer_CloseFile(_HMP4DEMUXER hHandle)
{
    // 获取当前读取的录像文件的解码结构体
    ST_RDSTG_MP4DEMUXER* pstMp4Demuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);
    if(pstMp4Demuxer == MOS_NULL){
        MOS_LOG_ERR(RDSTG_MP4LOG,"mp4 demuxer close err");
        return -1;
    }
    if(pstMp4Demuxer->hFileHandle ){
        // 关闭录像文件
        Mos_FileClose(pstMp4Demuxer->hFileHandle);
        MOS_LOG_INF(RDSTG_MP4LOG,"mp4 demuxer close ok,filename %s",pstMp4Demuxer->aucFileName);
    }
    pstMp4Demuxer->hFileHandle = MOS_NULL;
    pstMp4Demuxer->ucIsUsing = 0;
    return 1;
}

_INT RdStg_Mp4DeMuxer_SetCycleRead(_HMP4DEMUXER hHandle, _UC ucFlag)
{
    // 获取当前读取的录像文件的解码结构体
    ST_RDSTG_MP4DEMUXER* pstMp4Demuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);
    if(pstMp4Demuxer == MOS_NULL){
        return -1;
    }
    pstMp4Demuxer->ucCycleFlag = ucFlag;
    return 1;
}

// 读取MP4文件数据
_INT RdStg_Mp4DeMuxer_ReadBuf(_HMP4DEMUXER hHandle, _UC *pucNaluBuf, _UI *puiLength, 
                             _UC *pucAVType, _UI *puiTimeStamp, _UC *pucFramePos, _UI *puiFrameLen)
{
    _UI i = 0;
    _UI uiReadLen = 0;
    _UI iextern = 0;
    _UC *ptWritePos = MOS_NULL;
    _UI auiNaluLen[32] = {0};
    // 获取当前读取的录像文件的解码结构体
    // MOS_PRINTF("hHandle:%d \r\n", (_UI)hHandle);
    ST_RDSTG_MP4DEMUXER* pstMp4Demuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);
    if(pstMp4Demuxer == MOS_NULL)
    {
        MOS_PRINTF("RdStg_Mp4DeMuxer_ReadBuf pstMp4Demuxer == MOS_NULL\r\n");
        return -1;
    }
    MOS_PARAM_NULL_RETERR(pucNaluBuf);
    MOS_PARAM_NULL_RETERR(puiLength);
    MOS_PARAM_NULL_RETERR(puiTimeStamp);
    MOS_PARAM_NULL_RETERR(pucFramePos);

    if(pstMp4Demuxer->uiVideoCnt == 100000000)
    {
        pstMp4Demuxer->uiVideoCnt = 0;
    }

    // 当前播放的帧大于总帧数 返回错错误
    if((pstMp4Demuxer->uiVideoCnt >= pstMp4Demuxer->uiVideoNum) && (pstMp4Demuxer->uiAudioCnt >= pstMp4Demuxer->uiAudioNum))
    {
        MOS_PRINTF("RdStg_Mp4DeMuxer_ReadBuf MOS_ERR_FILEEND uiVideoCnt(%d) >= uiVideoNum(%d) && uiAudioCnt(%d) >= uiAudioNum(%d) \r\n", 
                    pstMp4Demuxer->uiVideoCnt, pstMp4Demuxer->uiVideoNum, pstMp4Demuxer->uiAudioCnt, pstMp4Demuxer->uiAudioNum);
        return MOS_ERR_FILEEND;
    }
    // 视频帧的偏移字节 比 音频帧的偏移字节 小
    else if(pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt] > pstMp4Demuxer->stco_a[pstMp4Demuxer->uiAudioCnt])
    {
        // 音频帧
        *pucAVType = 2;
    }
    // 视频帧的偏移字节 比 音频帧的偏移字节 大
    else if(pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt] < pstMp4Demuxer->stco_a[pstMp4Demuxer->uiAudioCnt])
    {
        // 视频帧
        *pucAVType = 1;
    }
    // 当前视频帧大于音频总帧数
    else if(pstMp4Demuxer->uiVideoCnt >= pstMp4Demuxer->uiVideoNum)
    {
        // 音频帧
        *pucAVType = 2;
    }
    else 
    {
        // 视频帧
        *pucAVType = 1;
    }

    // 音频帧
    if(*pucAVType == 2)
    {
        if(pstMp4Demuxer->uiAudioType != EN_ZJ_AUDIOENC_TYPE_AAC)
        {
            ptWritePos = pucNaluBuf;
        }
        else
        {
            ptWritePos = pucNaluBuf + 7;
        }

        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle, ptWritePos, pstMp4Demuxer->stsz_a[pstMp4Demuxer->uiAudioCnt]);
        *pucFramePos |= MD_FRAME_HEAD;
        *pucFramePos |= MD_FRAME_TAIL;
        *puiLength = pstMp4Demuxer->stsz_a[pstMp4Demuxer->uiAudioCnt];
        *puiFrameLen = pstMp4Demuxer->stsz_a[pstMp4Demuxer->uiAudioCnt];
        *puiTimeStamp = pstMp4Demuxer->stts_a[pstMp4Demuxer->uiAudioCnt];
        pstMp4Demuxer->uiAudioCnt++;
        if(pstMp4Demuxer->uiAudioType == EN_ZJ_AUDIOENC_TYPE_AAC)
        {
            *puiLength    += 7;
            *puiFrameLen  += 7;
            ptWritePos    -= 7;
            ptWritePos[0] = 0xff;
            ptWritePos[1] = 0xf1;
            ptWritePos[2] = pstMp4Demuxer->uiProfile * 64 + RdStg_AacGetIndexBySample(pstMp4Demuxer->uiSampleRate) * 4 + pstMp4Demuxer->uiChannel / 4;
            ptWritePos[3] = (pstMp4Demuxer->uiChannel % 4) * 64 + (_UC)(*puiLength / 2048);
            ptWritePos[4] = (_UC)(*puiLength / 8);
            ptWritePos[5] = (_UC)((*puiLength % 8192) * 32);
            ptWritePos[6] = 0xfc;
        }
        *pucFramePos |= MD_NAUL_HEAD;
        *pucFramePos |= MD_NALU_TAIL;

        *pucFramePos |= 0x10;
    }
    else  // 视频帧
    {
        _UI length, total = 0, is_i_frame = 0;
        ptWritePos = pucNaluBuf;

        // 返回帧时间戳
        *puiTimeStamp = pstMp4Demuxer->stts_v[pstMp4Demuxer->uiVideoCnt];//获取帧时间

        if(pstMp4Demuxer->uiFrameLen == 0)//某帧第一次读取
        {
            *pucFramePos |= MD_FRAME_HEAD;
            pstMp4Demuxer->uiFrameLen = pstMp4Demuxer->stsz_v[pstMp4Demuxer->uiVideoCnt];
            pstMp4Demuxer->uiFramePos = 0;
            pstMp4Demuxer->uiNaluLen  = 0;
            pstMp4Demuxer->uiNaluPos  = 0;
            pstMp4Demuxer->ucFrameType = 0;
        }

        // 返回帧的长度
        *puiFrameLen = pstMp4Demuxer->uiFrameLen;
        
        if(pstMp4Demuxer->uiNaluLen == 0)//如果是第一个nalu包
        {
            *pucFramePos |= MD_NAUL_HEAD;
            // 获取nalu的数据长度
            RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,ptWritePos, 5);
            Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_CUR,-5);
            MOS_MEMCPY(&length, ptWritePos, 4);
            length = Mos_InetNtohl(length) + 4;
            pstMp4Demuxer->uiNaluLen = length;
            pstMp4Demuxer->uiNaluPos = 0;

            // 264
            if(pstMp4Demuxer->uiVideoType == EN_ZJ_VIDEOENC_TYPE_H264)
            {
                if((ptWritePos[4] & 0x1f) == 5 || (ptWritePos[4] & 0x1f) == 7 || (ptWritePos[4] & 0x1f) == 8)
                {
                    // 264 i帧
                    is_i_frame = 1;
                }
            }
            // 265
            else if(pstMp4Demuxer->uiVideoType == EN_ZJ_VIDEOENC_TYPE_H265)
            {
                if( MEFC_GETHEVTYPE(ptWritePos[4]) == 32 || MEFC_GETHEVTYPE(ptWritePos[4]) == 33 ||
                    MEFC_GETHEVTYPE(ptWritePos[4]) == 34 || MEFC_GETHEVTYPE(ptWritePos[4]) == 19 || 
                    MEFC_GETHEVTYPE(ptWritePos[4]) == 20)
                {
                    // 265 i帧
                    is_i_frame = 1;
                }
            }
            pstMp4Demuxer->ucFrameType = is_i_frame;
        }

        if(pstMp4Demuxer->ucFrameType == EN_FRAMETYPE_I)
        {
            // 当前nalu在帧内的位置
            *pucFramePos |= 0x10;
        }

        // 数据长度
        uiReadLen = pstMp4Demuxer->uiNaluLen - pstMp4Demuxer->uiNaluPos;
        if(uiReadLen >= MAX_VIDEOPAGESIZE)
        {
            uiReadLen = MAX_VIDEOPAGESIZE;
        }

        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,ptWritePos, uiReadLen);

        if(pstMp4Demuxer->uiNaluPos == 0)
        {
            MOS_MEMCPY(ptWritePos, RdStg_GetDeMp4MuxterMng()->aucNaluId, 4);
        }

        pstMp4Demuxer->uiNaluPos += uiReadLen;
        pstMp4Demuxer->uiFramePos += uiReadLen;
        // 返回nalu数据长度
        *puiLength = uiReadLen;

        if(pstMp4Demuxer->uiNaluPos == pstMp4Demuxer->uiNaluLen)
        {
            *pucFramePos |= MD_NALU_TAIL;
            pstMp4Demuxer->uiNaluLen = 0;
        }

        if(pstMp4Demuxer->uiFrameLen > pstMp4Demuxer->stsz_v[pstMp4Demuxer->uiVideoCnt]){
            *pucFramePos |= MD_FRAME_TAIL;
            pstMp4Demuxer->uiVideoCnt++;
            MOS_LOG_ERR(RDSTG_MP4LOG, "read frame err");
            return -1;
        }

        if(pstMp4Demuxer->uiFrameLen == pstMp4Demuxer->uiFramePos)
        {
            *pucFramePos |= MD_FRAME_TAIL;
            pstMp4Demuxer->uiFrameLen = 0;
            pstMp4Demuxer->uiVideoCnt++;
        }
    }
    if(*puiFrameLen == 0)
    {
        MOS_PRINTF("RdStg_Mp4DeMuxer_ReadBuf MOS_ERR_FILEEND puiFrameLen == 0 \r\n");
        return MOS_ERR_FILEEND;
    }
    return 0;
}

_INT RdStg_Mp4DeMuxer_ReadFrame(_HMP4DEMUXER hHandle, _UC *pucStreambuf,_UI *puiNalNum, 
                             _UI *puiLength, _UC *pucAVType,  _UI *puiTimeStamp,_UI *puiDataOffset, _UC *pucFrametype)
{
    _UI i = 0;
    _UI iextern = 0;
    _UC *ptWritePos = MOS_NULL;
    _UI auiNaluLen[32] = {0};
    // 获取当前读取的录像文件的解码结构体
    ST_RDSTG_MP4DEMUXER* pstMp4Demuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);
    if(pstMp4Demuxer == MOS_NULL){
        return -1;
    }

    MOS_PARAM_NULL_RETERR(pucStreambuf);
    MOS_PARAM_NULL_RETERR(puiLength);
    MOS_PARAM_NULL_RETERR(puiTimeStamp);
    MOS_PARAM_NULL_RETERR(puiDataOffset);
    MOS_PARAM_NULL_RETERR(pucFrametype);

    *pucFrametype = 0;
    *puiNalNum    = 0;
    ptWritePos = pucStreambuf + 1024;
    if(pstMp4Demuxer->uiVideoCnt == 100000000)
    {
        pstMp4Demuxer->uiVideoCnt = 0;  
    }

    if((pstMp4Demuxer->uiVideoCnt >= pstMp4Demuxer->uiVideoNum) && (pstMp4Demuxer->uiAudioCnt >= pstMp4Demuxer->uiAudioNum)){
        if(pstMp4Demuxer->ucCycleFlag == 1){
            pstMp4Demuxer->uiVideoCnt = 0;
            pstMp4Demuxer->uiAudioCnt = 0;
            Mos_FileSeek(pstMp4Demuxer->hFileHandle, MOS_FILE_SEEK_BEGIN, pstMp4Demuxer->stco_v[0]);
            return  RdStg_Mp4DeMuxer_ReadFrame( hHandle, pucStreambuf,puiNalNum, puiLength, pucAVType, puiTimeStamp,puiDataOffset, pucFrametype);
        }
        return 0;
    }
    else if(pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt] > pstMp4Demuxer->stco_a[pstMp4Demuxer->uiAudioCnt])
    {
        *pucAVType = 2;
    }
    else if(pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt] < pstMp4Demuxer->stco_a[pstMp4Demuxer->uiAudioCnt])
    {
        *pucAVType = 1;
    }
    else if(pstMp4Demuxer->uiVideoCnt >= pstMp4Demuxer->uiVideoNum)
    {
        *pucAVType = 2;
    }
    else 
    {
        *pucAVType = 1;
    }
    if(*pucAVType == 2){
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle, ptWritePos, pstMp4Demuxer->stsz_a[pstMp4Demuxer->uiAudioCnt]);
        puiLength[0] = pstMp4Demuxer->stsz_a[pstMp4Demuxer->uiAudioCnt];
        *puiTimeStamp = pstMp4Demuxer->stts_a[pstMp4Demuxer->uiAudioCnt];
        *puiDataOffset = 1024;
        *puiNalNum = 1;
        pstMp4Demuxer->uiAudioCnt++;
        if(pstMp4Demuxer->uiAudioType == EN_ZJ_AUDIOENC_TYPE_AAC){
            puiLength[0]   += 7;
            *puiDataOffset -= 7;
            ptWritePos     -= 7;

            ptWritePos[0] = 0xff;
            ptWritePos[1] = 0xf1;
            ptWritePos[2] = pstMp4Demuxer->uiProfile * 64 + RdStg_AacGetIndexBySample(pstMp4Demuxer->uiSampleRate) * 4 + pstMp4Demuxer->uiChannel / 4;
            ptWritePos[3] = (pstMp4Demuxer->uiChannel % 4) * 64 + (_UC)(puiLength[0] / 2048);
            ptWritePos[4] = (_UC)(puiLength[0] / 8);
            ptWritePos[5] = (_UC)((puiLength[0] % 8192) * 32);
            ptWritePos[6] = 0xfc;
        }
    }else{
        _UI length, total = 0, is_i_frame = 0, is_have_sps = 0;
        RdStg_Mp4DeMuxer_Read(pstMp4Demuxer->hFileHandle,ptWritePos, pstMp4Demuxer->stsz_v[pstMp4Demuxer->uiVideoCnt]);
        while(RdStg_GetMng()->ucInitFlag){
            MOS_MEMCPY(&length, ptWritePos + total, 4);
            length = Mos_InetNtohl(length);
            MOS_MEMCPY(ptWritePos + total, RdStg_GetDeMp4MuxterMng()->aucNaluId, 4);
            if((ptWritePos[total + 4] & 0x1f) == 5){
                is_i_frame = 1;
                *pucFrametype = 1;
            }else if((ptWritePos[total + 4] & 0x1f) == 7){
                is_have_sps = 1;
            }
            total += (length + 4);
            auiNaluLen[i] = length + 4;;
            i++;
            (*puiNalNum)++;
            if(total >= pstMp4Demuxer->stsz_v[pstMp4Demuxer->uiVideoCnt])
                break;
        }
        if(total > pstMp4Demuxer->stsz_v[pstMp4Demuxer->uiVideoCnt]){
            pstMp4Demuxer->uiVideoCnt++;
            return -2;
        }
        *puiTimeStamp = pstMp4Demuxer->stts_v[pstMp4Demuxer->uiVideoCnt];
        *puiDataOffset = 1024;
        if((is_i_frame == 1) && (is_have_sps == 0))
        {
            if( pstMp4Demuxer->uiVpsLen > 0)
            {
                *puiNalNum += 3;
                iextern = 3;
                puiLength[0] = pstMp4Demuxer->uiVpsLen;
                puiLength[1] = pstMp4Demuxer->uiSpsLen;
                puiLength[2] = pstMp4Demuxer->uiPpsLen;
            }
            else
            {
                *puiNalNum += 2;
                iextern = 2;
                puiLength[0] = pstMp4Demuxer->uiSpsLen;
                puiLength[1] = pstMp4Demuxer->uiPpsLen;
            }
            MOS_MEMCPY(ptWritePos - pstMp4Demuxer->uiSpsLen- pstMp4Demuxer->uiPpsLen - pstMp4Demuxer->uiVpsLen, pstMp4Demuxer->aucSpsPps, pstMp4Demuxer->uiSpsLen + pstMp4Demuxer->uiPpsLen);
            *puiDataOffset = 1024 - pstMp4Demuxer->uiSpsLen- pstMp4Demuxer->uiPpsLen - pstMp4Demuxer->uiVpsLen;
        }
        pstMp4Demuxer->uiVideoCnt++;
        for(i = 0; i< *puiNalNum - iextern ; i++){
            puiLength[iextern + i] = auiNaluLen[i];
        }
    }
    return 1;
}

_INT  RdStg_AacGetSampleByIndex(_US usSample)
{
    switch(usSample)
    {
    case 0 :
        return 96000;
    case 1 :
        return 88200;
    case 2 :
        return 64000;
    case 3  :
        return 48000;
    case 4  :
        return 44100;
    case 5 :
        return 32000;
    case 6 :
        return 24000;
    case 7 :
        return 22050;
    case 8 :
        return 16000;
    case 9 :
        return 12000;
    case 10 :
        return 11025;
    case 11 :
        return 8000;
    case 12 :
        return 7350;
    default:
        return -1;  
    }
}

_INT RdStg_AacGetIndexBySample(_INT isample)
{
    switch(isample)
    {
        case 96000 :
            return 0;
        case 88200 :
            return 1;
        case 64000 :
            return 2;
        case 48000  :
            return 3;
        case 44100  :
            return 4;
        case 32000 :
            return 5;
        case 24000 :
            return 6;
        case 22050 :
            return 7;
        case 16000 :
            return 8;
        case 12000 :
            return 9;
        case 11025 :
            return 10;
        case 8000 :
            return 11;
        case 7350 :
            return 12;
        default:
            return -1;  
    }
}


_INT RdStg_Mp4DeMuxer_GetAudioDes(_HMP4DEMUXER hHandle,_INT *puiAudioType, _UI *puiSampleRate, _UI *puiChannel)
{
    // 获取当前读取的录像文件的解码结构体
    ST_RDSTG_MP4DEMUXER* pstMp4Demuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);
    if(pstMp4Demuxer == MOS_NULL){
        return -1;
    }
    if(pstMp4Demuxer->uiAudioType == 0){
        MOS_LOG_ERR(RDSTG_MP4LOG,"task[%p] have no audio", pstMp4Demuxer);
        return 0;
    }
    if(puiAudioType)
        *puiAudioType = pstMp4Demuxer->uiAudioType;
    if(puiSampleRate)
        *puiSampleRate = pstMp4Demuxer->uiSampleRate;
    if(puiChannel)
        *puiChannel = pstMp4Demuxer->uiChannel;

    return 1;
}

_INT RdStg_Mp4DeMuxer_GetVideoDes(_HMP4DEMUXER hHandle, _INT *puiVideoType, _UI* puiVideoWidth, _UI *puiVideoHeight)
{
    // 获取当前读取的录像文件的解码结构体
    ST_RDSTG_MP4DEMUXER* pstMp4Demuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);
    if(pstMp4Demuxer == MOS_NULL){
        return -1;
    }
    if(puiVideoType)
    {
        *puiVideoType = pstMp4Demuxer->uiVideoType;
    }
    if(puiVideoWidth)
        *puiVideoWidth = pstMp4Demuxer->uiVideoWidth;
    if(puiVideoHeight)
        *puiVideoHeight = pstMp4Demuxer->uiVideoHeight;
    return 1;
}

_INT RdStg_Mp4DeMuxer_GetCircleInf(_HMP4DEMUXER hHandle,ST_ZJ_VIDEO_CIRCLE *pstCircle)
{
    // 获取当前读取的录像文件的解码结构体
    ST_RDSTG_MP4DEMUXER* pstMp4Demuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);
    if(pstMp4Demuxer == MOS_NULL){
        return MOS_ERR;
    }
    if(pstCircle)
        MOS_MEMCPY(pstCircle,&pstMp4Demuxer->stCircle, sizeof(ST_ZJ_VIDEO_CIRCLE));
    return MOS_OK;
}

// 查找回放的录像的时间戳对应的视频IDR帧和音频帧 播放时间轴的重定位 uiTimeStamp文件偏移量 
_INT RdStg_Mp4DeMuxer_SeekFile(_HMP4DEMUXER hHandle, _UI uiTimeStamp, _UI *uiSeekTimeStamp)
{
    MOS_PARAM_NULL_RETERR(uiSeekTimeStamp);
    _UI i = 0, j = 0;

    // 获取当前读取的录像文件的解码结构体
    ST_RDSTG_MP4DEMUXER* pstMp4Demuxer = RdStg_Mp4DeMuxer_GetNodeId((_UI)hHandle);
    if(pstMp4Demuxer == MOS_NULL)
    {
        MOS_LOG_ERR(RDSTG_MP4LOG,"pstMp4Demuxer == MOS_NULL");
        return -1;
    }

    if (pstMp4Demuxer->uiIdrNum == 0)
    {
        MOS_LOG_ERR(RDSTG_MP4LOG,"pstMp4Demuxer->uiIdrNum == 0");
        return -1; 
    }

    MOS_PRINTF("Seek uiTimeStamp:%lu \r\n", uiTimeStamp);
    MOS_PRINTF("pstMp4Demuxer->uiIdrNum:%d \r\n", pstMp4Demuxer->uiIdrNum);
    // 遍历当前读取的录像文件的IDR帧
    for(i = 0; i < pstMp4Demuxer->uiIdrNum; i++)
    {
        // 获取当前IDR帧位于视频帧的第几帧
        // pstMp4Demuxer->stss_v[i] = Mos_InetNtohl(pstMp4Demuxer->stss_v[i]);

        // 获取当前IDR帧相对文件第一帧的偏移时间戳 并于播放的偏移时间戳比较
        // 寻找播放时间戳后的IDR帧
        if(pstMp4Demuxer->stts_v[pstMp4Demuxer->stss_v[i]] >= uiTimeStamp)
        {
            // 非录像文件第一帧IDR帧
            if(i != 0)
            {
                // 获取当前IDR帧相对文件第一帧的偏移时间戳
                *uiSeekTimeStamp = pstMp4Demuxer->stts_v[pstMp4Demuxer->stss_v[i - 1]];

                // 获取回放IDR帧位于视频帧的第几帧
                pstMp4Demuxer->uiVideoCnt = pstMp4Demuxer->stss_v[i - 1];
                MOS_PRINTF("PlayBack IDR Frame Num:%d \r\n", i);
                // 遍历当前读取的录像文件的音频帧
                for(j = 0; j < pstMp4Demuxer->uiAudioNum; j++)
                {
                    // 比较音视频相对于文件头的偏移字节数
                    // 获取播放的视频帧后的音频帧的        
                    if( pstMp4Demuxer->stco_a[j] >= pstMp4Demuxer->stco_v[pstMp4Demuxer->stss_v[i - 1]])
                    {
                        break;
                    }
                }
            }
            else    // 录像文件的第一帧IDR帧
            {
                // 获取当前IDR帧相对文件第一帧的偏移时间戳
                *uiSeekTimeStamp = pstMp4Demuxer->stts_v[pstMp4Demuxer->stss_v[i]];

                // 获取回放IDR帧位于视频帧的第几帧
                pstMp4Demuxer->uiVideoCnt = pstMp4Demuxer->stss_v[i];
                
                // 遍历当前读取的录像文件的音频帧
                for(j = 0; j < pstMp4Demuxer->uiAudioNum; j++)
                {
                    // 比较音视频相对于文件头的偏移字节数
                    // 获取播放的视频帧后的音频帧的 
                    if( pstMp4Demuxer->stco_a[j] >= pstMp4Demuxer->stco_v[pstMp4Demuxer->stss_v[i]])
                    {
                        break;
                    }
                }
            }

            // 记录播放的音频帧处于录像文件音频帧的第几帧
            pstMp4Demuxer->uiAudioCnt = j;

            // 文件偏移  pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt] 字节数
            Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_BEGIN, pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt]);

            if (i == 0)
            {
                MOS_LOG_INF(RDSTG_MP4LOG,"seek time %u to %u,position %u",uiTimeStamp,pstMp4Demuxer->stts_v[pstMp4Demuxer->stss_v[i]],pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt]);
            }
            else
            {
                MOS_LOG_INF(RDSTG_MP4LOG,"seek time %u to %u,position %u",uiTimeStamp,pstMp4Demuxer->stts_v[pstMp4Demuxer->stss_v[i - 1]],pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt]);    
            }
            
            return 1;
        }
    }

    // 若未找到相应的IDR帧, 则回放由当前回放文件的最后一个IDR帧开始回放

    // 获取当前IDR帧相对文件第一帧的偏移时间戳
    *uiSeekTimeStamp = pstMp4Demuxer->stts_v[pstMp4Demuxer->stss_v[i - 1]];
    // 获取回放IDR帧位于视频帧的第几帧
    pstMp4Demuxer->uiVideoCnt = pstMp4Demuxer->stss_v[i - 1];
    // 遍历当前读取的录像文件的音频帧
    for(j = 0; j < pstMp4Demuxer->uiAudioNum; j++)
    {
        // 比较音视频相对于文件头的偏移字节数
        // 获取播放的视频帧后的音频帧的
        if( pstMp4Demuxer->stco_a[j] >=pstMp4Demuxer->stco_v[pstMp4Demuxer->stss_v[i - 1]])
        {
            break;
        }
    }
 
    // 记录播放的音频帧处于录像文件音频帧的第几帧
    pstMp4Demuxer->uiAudioCnt = j;

    // 文件偏移  pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt] 字节数
    Mos_FileSeek(pstMp4Demuxer->hFileHandle,MOS_FILE_SEEK_BEGIN, pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt]);
    
    MOS_LOG_INF(RDSTG_MP4LOG,"seek time %u to %u,position %u",uiTimeStamp,pstMp4Demuxer->stts_v[pstMp4Demuxer->stss_v[i - 1]],pstMp4Demuxer->stco_v[pstMp4Demuxer->uiVideoCnt]);
    return 0;
}

_INT RdStg_Mp4DeMuxer_GetTotalTime(_UC *pucFileName, _UI *puiTimeTotalMs)
{
    _INT iRet;
    _UI uiBoxSize;
    _UC uaBoxName[4];
    _HFILE ptfileHandle = MOS_NULL;

    MOS_PARAM_NULL_RETERR(pucFileName);
    MOS_PARAM_NULL_RETERR(puiTimeTotalMs);

    ptfileHandle = Mos_FileOpen(pucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if(ptfileHandle == MOS_NULL){
        MOS_LOG_ERR(RDSTG_MP4LOG,"open %s file err ",pucFileName);
        return -1;
    }
    if(ptfileHandle == MOS_NULL){
        MOS_LOG_ERR(RDSTG_MP4LOG,"open file error get_mp4_describle");
        return -1;
    }
    *puiTimeTotalMs = 0;
    while(RdStg_GetMng()->ucInitFlag){
        iRet = RdStg_Mp4DeMuxer_Read(ptfileHandle,(_UC *)&uiBoxSize, 4);
        if(iRet < 4)
            break;
        uiBoxSize = Mos_InetNtohl(uiBoxSize);
        if(uiBoxSize < 8){
            MOS_LOG_ERR(RDSTG_MP4LOG,"the file have error box");
            break;
        }
        uiBoxSize -= 8;
        if(Mos_FileEof(ptfileHandle) !=  MOS_FALSE)
        {
            break;
        }
        iRet = RdStg_Mp4DeMuxer_Read(ptfileHandle,uaBoxName, 4);
        if(iRet < 4)
            break;
        if(MOS_STRNCMP(uaBoxName, "moov", 4) == 0){
            continue;
        }else if(MOS_STRNCMP(uaBoxName, "trak", 4) == 0){
            continue;
        }else if(MOS_STRNCMP(uaBoxName, "mdia", 4) == 0){
            continue;   
        }else if(MOS_STRNCMP(uaBoxName, "mvhd", 4) == 0)
        {
            _UI uiTps = 1, uiTotalTime = 0;
            Mos_FileSeek(ptfileHandle, MOS_FILE_SEEK_CUR,12);
            RdStg_Mp4DeMuxer_Read(ptfileHandle,(_UC *)&uiTps, 4);
            
            RdStg_Mp4DeMuxer_Read(ptfileHandle,(_UC *)&uiTotalTime, 4);
            uiTps = Mos_InetNtohl(uiTps);
            uiTotalTime = Mos_InetNtohl(uiTotalTime);
            *puiTimeTotalMs = uiTotalTime / uiTps * 1000;
            break;
        }else if(MOS_STRNCMP(uaBoxName, "minf", 4) == 0){
            continue;   
        }else if(MOS_STRNCMP(uaBoxName, "stbl", 4) == 0){
            continue;   
        }else{
            if(uiBoxSize > 0){
                Mos_FileSeek(ptfileHandle,MOS_FILE_SEEK_CUR,uiBoxSize);         
            }else{
                MOS_LOG_ERR(RDSTG_MP4LOG,"mp4 file error, may not a mp4 or file is destory");
            }   }
        }   
    Mos_FileClose(ptfileHandle);
    if(*puiTimeTotalMs == 0){
        return -3;
    }
    return 0;
}

