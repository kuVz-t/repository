#ifndef _RECORD_PRV_H
#define _RECORD_PRV_H

#ifdef __cplusplus
extern "C" {
#endif

#define RDSTG_LOGSTR                           (_UC*)"RD"
#define RDSTG_DATECFG_NAME                     (_UC*)"date.txt"
#define RDSTG_FILEDESCFG_NAME                  (_UC*)"filedes.txt"
#define RDSTG_MAPPING_NAME                     (_UC*)"mapdes.txt"
#define RDSTG_DATECFG_VERSION                  (_UC*)"0001000100010001"
#define RDSTG_FILEDESCFG_VERSION               (_UC*)"0001000100010001"
#define RDSTG_DISK_RSV_SIZE                     600
#define RDSTG_FILE_MAX_TIME                     600
#define RDSTG_DELAY_RETRY_TIME					 30			//节点重试等待时间

#define RDSTG_MSG_TYPE_QUERY_DATE 1
#define RDSTG_MSG_TYPE_QUERY_FILE 2




typedef struct st_RDSTG_QUERY_DATE_NODE
{
    _INT iCamId;
    _VPTR pUsrPoint;
    PFUN_RDSTG_DATELIST pfuncOnDateList;
}ST_RDSTG_QUERY_DATE_NODE;
typedef struct st_RDSTG_QUERY_FILE_NODE
{
    _INT iCamId;
    _UC aucDay[12];
    _VPTR pUsrPoint;
    PFUN_RDSTG_FILELIST pfuncOnFileList;
}ST_RDSTG_QUERY_FILE_NODE;
typedef struct st_RDSTG_MSG_NODE
{
    _UI uiMsgType;      // 消息队列类型
    _VPTR pMsgStruct;   // 消息队列结构体
    struct st_RDSTG_MSG_NODE *pstNext;
}ST_RDSTG_MSG_NODE;    // 录像的消息队列
typedef struct st_RDSTG_MAP_INF
{
    _UI uiDataSeq;
    _UC aucFileMap[256];
}ST_RDSTG_MAP_INF;

typedef enum enum_rd_status
{
    EN_RDSTG_STATUS_INIT = 0,  // 初始化
    EN_RDSTG_STATUS_IDEL = 1,  // 处理
    EN_RDSTG_STATUS_RUN  = 2,  // 运行
    EN_RDSTG_STATUS_STOP = 3   // 停止
}EN_RDSTG_STATUS;      // 录像节点状态值

typedef struct st_RDSTG_CUSTOM_NODE
{
    _UC ucIsUsing;
    _UC aucPeerSID[32];
    ST_MOS_LIST_NODE stNode;
}ST_RDSTG_CUSTOM_NODE;

typedef struct st_RDSTG_NODE
{
    _UC ucStatus;                   // 录像节点的状态
    _UC ucStreamFlag;               // 录像取流标志
    _UC ucAllDayRecordFlag;         // 录像全天候录像标志
    _UC ucNeedIDR;                  // 录像节点是否需要强制I帧
    
    _UC ucFirstRead;                // 是否为该录像节点的第一次读取媒体数据流
    _UC ucWakeUp;                   // 该录像节点是否在工作
    _UC ucCamOpenFlag;              // 摄像机是否打开
    _UC aucDay[16];                 // 该录像所处于的日期
    _UI uiTryTimes;                 // 尝试次数
    _INT iCamId;                    // 摄像机ID
    _INT iStreamId;                 // 流通道ID
    _UI uiMp4WriteTimes;            // 重写MP4数据流次数
    _UI uiCustomNodeNum;            // 定制录像个数
    _UI uiDataSeq;                  // 当天的第几个录像 1.MP4
    _CTIME_T cRecordToTime;         // 该录像节点的结束时间
    _CTIME_T cEventTime;            // 告警事件触发时间
    _HVIDEOREAD hVideo;             // 视频参数结构体
    _HAUDIOREAD hAudio;             // 音频参数结构体
    _CTIME_T cNextTryTime;          // 下次重写数据流时间
    ST_FRAME_NODE *pstVFrameNode;   // 视频数据链表
    ST_FRAME_NODE *pstAFrameNode;   // 音频数据链表
    _UI uiATimeStamp;               // 音频时间戳
    _UI uiVTimeStamp;               // 视频时间戳
    _UI uiWritACnt;                 // 该录像需要写的音频数
    _UI uiWritVCnt;                 // 该录像需要写的视频数
    _HMP4MUXER hMp4File;            // 录像文件的文件句柄
    ST_RDSTG_FILEDES stFileDes;        // filedes.txt存储结构体
    ST_MOS_LIST stCustomList;       // ST_RDSTG_CUSTOM_NODE
    ST_MOS_LIST_NODE stNode;        // 
}ST_RDSTG_NODE;        // 录像节点结构体

typedef struct st_RDSTG_THIRDREAD
{
    _UI uiMaxFrameLen;      //最大帧长度
    _UI uiResFrameLen;      //当前读取的帧剩余需要分包的长度
    _UI uiFramePos;         //帧的偏移位置
    _UI uiIFrameFlag;       //I帧标记
    _UI uiTimeStamp;        //时间戳
    _UC *pucThirdBuff;      //当前读取的帧BUFF
    _UC pucAVFlag;          //帧类型refer to EN_ZJ_STREAMER_TYPE
    _UI uiCurrentFrameLen;  //当前读取的帧长度
    _UC pucRes[3];          //保留
}ST_RDSTG_THIRDREAD;

typedef struct st_RDSTG_READER_NODE
{
    _UC ucIsUsing;                  // 使用标志
    _UC ucPlayMode;                 //0-signel file,1-continous
    _INT iCamId;                    // 摄像机ID
    _UC aucDay[12];                 // 该录像所处于的日期
    _HMP4DEMUXER hMp4File;          // 录像文件的文件句柄
    ST_RDSTG_FILEDES stFileDes;        // filedes.txt存储结构体
    ST_RDSTG_THIRDREAD stThirdRead;    // 第三方录像头
    ST_MOS_LIST_NODE stNode;
}ST_RDSTG_READER_NODE;     // 录像头结构体


typedef struct stru_record_mng
{
    _UC ucInitFlag;                         // 录像模块初始化标志
    _UC ucDefaultStreamID;                  // 录像模块默认的取流通道ID
    _UC ucStopAllFlag;                      // 录像模块启动停止标志
    _UC ucReadCnt;                          // 保留,暂时未使用

    _HTHREAD hPlayBackThread;               // 卡录像回放线程

    _UC ucCbTfCardErrFlag;                  // SDCard错误标志
    _UI uiCurrentSeq;                       // 录像个数
    _UI uiMaxCamCnt;                        // 支持最大摄像机个数 目前支持1
    _UC aucCachePath[CFG_STRING_MAXLEN];    // sdcard录像存储路径

    _HMUTEX hMutex;                         // 录像模块的互斥锁
    ST_MOS_LIST stRdList;                   // 录制句柄
    ST_MOS_LIST stReadList;                 // ST_RDSTG_READER_NODE
}ST_RECORD_MNG; // 录像模块的管理结构体

ST_RECORD_MNG *RdStg_GetMng();

_INT RdStg_IoProcess();
_INT RdStg_IoStop();
_INT RdStg_IoReStart(_UC *pucLocalPath);
_INT RdStg_IoAutoDelete();

_VOID RdStg_ProcessQuery();

#ifdef __cplusplus
}
#endif

#endif
