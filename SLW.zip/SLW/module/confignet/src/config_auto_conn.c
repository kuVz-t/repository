#include "config_auto_conn.h"
#include "http_api.h"
#include "kj_timer.h"
#include "msgmng_api.h"
#include "zj_interface.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "config_api.h"
#include "qualityprobe_api.h"

#include <fcntl.h>
#include <sys/ioctl.h>

#define SOCKET_RECV_MAX_BUFLEN  4096

static _SOCKET g_iSocketFd = 0;
static _UC g_aucHardVer[] = "V2.800.10YA000.0.R-00-210118";
static _UC g_aucMAC[] = "FC6BF0DD7259";
static _INT g_iNormalWifiStatus = 0;

static ST_AUTO_CONN_MNG g_stAutoConnMng = {0};
_INT AutoConn_ServerTask_Loop(_VPTR pstArg);

static _INT AutoConn_SocketSend(_INT iSocketFd, _VPTR pBuf, _INT iLen, _INT iProtoType);
static _INT AutoConn_SocketRecv(_INT iSocketFd, _VPTR pBuf, _INT iLen, _INT iProtoType);
static _INT AutoConn_Keyngreq(_INT iSocketFd, _INT *piSequence);
static _INT AutoConn_Sendkey(_INT iSocketFd, _INT *piSequence, _UC *pucPubKey, _UC *pucPValueAes, _UC *pucGValueAes, _UC *pucDHKey);
static _INT AutoConn_Keepalive(_INT iSocketFd, _INT *piSequence, _UC *pucSharekey);
static _INT AutoConn_DevReg(_INT iSocketFd, _INT *piSequence, _UC *pucSharekey);
static _INT AutoConn_GetSSID(_INT iSocketFd, _UC *pucSharekey,_UC *pucGetSSID,_UC *pucGetKey,_UC *pucGetAuth,_UC *pucDeData);
static _INT AutoConn_SendUdppack(_INT iSocketFd, _INT *piSequence);
static _INT AutoConn_RecvData(_INT iSocketFd, _UC *pucSharekey, _UC *pucRecvBuf);
static _INT AutoConn_CheckHead(_UC *pBuf);
static _INT AutoConn_MakeHead(_UC *pBuf, _INT iDataLen);

static _INT AutoConn_MacRemoveColon(_UC *pucInMac,_UC *pucOutMac)
{
    _INT i = 0, j = 0;
    while (i < MOS_STRLEN(pucInMac))
    {
        
        if (pucInMac[i] != ':')
        {
            pucOutMac[j] = pucInMac[i++];
            if (pucOutMac[j] - '0' >= 49 && pucOutMac[j]- '0' <= 74)
            {
                pucOutMac[j] = pucOutMac[j] - 'a' + 'A';
                j++;
            }
            else if((pucOutMac[j]- '0' >= 17 && pucOutMac[j]- '0' <= 42 ) || (pucOutMac[j]- '0' >= 0 && pucOutMac[j]- '0' <= 9))
            {
                j++;
                continue;
            }
            else
            {
                return MOS_NULL;
            }
        }
        else
        {
            i++;
        }
    }
    return MOS_OK;
}

_INT AutoConn_SetNormalWifi_Status()
{
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SetNormalWifi_Status !!!!!!!!!!!!!!!!");
    g_iNormalWifiStatus = 1;
    return MOS_OK;
}

ST_AUTO_CONN_MNG *AutoConn_GetTaskMng()
{
    return &g_stAutoConnMng;
}

_INT AutoConn_Task_Init()
{
    if (AutoConn_GetTaskMng ()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(AUTO_CONN_LOGSTR, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stAutoConnMng, 0, sizeof(g_stAutoConnMng));
    // AutoConn_GetTaskMng ()->hMsgQueque = Mos_MsgQueueCreate(MOS_FALSE,10);
    AutoConn_GetTaskMng ()->ucInitFlag = 1;

    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AUTO CONN INIT OK !!!!!!!!!!!!!!!!");
    return MOS_OK;
}

_INT AutoConn_Task_Start()
{
    ST_MOS_INET_IP stLocalIp = {0};
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;

    if (AutoConn_GetTaskMng ()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }

    if (AutoConn_GetTaskMng ()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(AUTO_CONN_LOGSTR, "Already Init");
        return MOS_OK;
    }

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    AutoConn_GetTaskMng ()->ucRunFlag  = 1;
    if (Mos_ThreadCreate((_UC*)"AutoConn_task",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        AutoConn_ServerTask_Loop,MOS_NULL,MOS_NULL,&AutoConn_GetTaskMng ()->hThread) == MOS_ERR)
    {
        AutoConn_GetTaskMng ()->ucRunFlag = 0;
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "Auto Conn Start Failed !!!!!!!!!!!!!!!!");
        return MOS_ERR;
    }

    return MOS_OK;
}

_INT AutoConn_ServerTask_Loop(_VPTR pstArg)
{
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_ServerTask_Loop Start \n");

    _INT iRet        = 0;
    _INT iRetryCount = 0;
    _INT iSequence   = 0;
    _INT iTimeOutSec = 15;
    _INT iGetSSidFlag   = 0;
    _BOOL bConnect   = MOS_TRUE;

    _UC aucDHGValue[128] = {0};
    _UC aucDHPValue[128] = {0};
    _UC aucPubKey[128]   = {0};

    _UC aucDHkey[128]   = {0};
    _UC aucSharekey[17] = {0};

    _UC aucGetSSID[64]  = {0};
    _UC aucGetKey[64]   = {0};
    _UC aucGetAuth[64]  = {0};
    _UC aucGateway[64]  = {0};

    fd_set readfds;
    struct timeval wait_time = {1, 0};

    g_iNormalWifiStatus = 0;
    struct in_addr addr;

    // 获取网关地址
    ST_ZJ_NETWORK_INFO stNetWorkInf = {0};
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetWorkInf);
        if (iRet == MOS_ERR)
        {
             MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pfunGetCurNetInfo err");
             MOS_MEMCPY(aucGateway, "192.168.1.1", sizeof(aucGateway));  
        }
        else
        {
            MOS_MEMCPY(aucGateway, stNetWorkInf.aucGateway, sizeof(aucGateway));
        }
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pfunGetCurNetInfo is NULL!");
        MOS_MEMCPY(aucGateway, "192.168.1.1", sizeof(aucGateway));
    }

    MOS_LOG_INF(AUTO_CONN_LOGSTR, "Gateway = %s", aucGateway);

    //DH生成公钥、P、G值
    _HCRYPTOCTX hDHCtx = Adpt_DHCreateCrypto();
    if (hDHCtx == MOS_NULL)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "Adpt_DHCreateCrypto Failed\n");
        //通知设备端无感配网结果
        if (ZJ_GetFuncTable()->pFunAutoConnResult)
        {
            ZJ_GetFuncTable()->pFunAutoConnResult(MOS_ERR);
        }
        AutoConn_GetTaskMng ()->ucRunFlag = 0;
        // Mos_ThreadDelete(AutoConn_GetTaskMng ()->hThread); /*Mos_ThreadFree(AutoConn_GetTaskMng ()->hThread)*/
        return MOS_ERR;
    }

    Adpt_DHGetSelfValue(hDHCtx, aucDHGValue, aucDHPValue, aucPubKey);
    // MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucDHGValue = %s  aucDHPValue = %s  aucPubKey = %s \n",aucDHGValue,aucDHPValue,aucPubKey);

    while(AutoConn_GetTaskMng ()->ucRunFlag)
    {
        //生成TCP套接字
        g_iSocketFd = Mos_SocketOpen(EN_CINET_TYPE_IPV4, EN_CINET_PRTL_TCP, MOS_TRUE, MOS_TRUE);
        if (g_iSocketFd == MOS_SOCKET_INVALID)
        {
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_Sleep(1000);
                continue;
            }
            MOS_LOG_ERR(AUTO_CONN_LOGSTR, "Create iTcpSocket error \n");
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            iRet = MOS_ERR;
            break;
        }

        //进行TCP连接
        inet_aton(aucGateway, &addr);
        ST_MOS_INET_IP tTcpServerAddr = {0};

        tTcpServerAddr.usType = EN_CINET_TYPE_IPV4;
        tTcpServerAddr.usPort = 32769;
        tTcpServerAddr.u.uiIp = addr.s_addr;
        iRet = Mos_SocketConnect(g_iSocketFd, &tTcpServerAddr, &bConnect);
        if (iRet != MOS_OK)
        {
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_SocketClose(g_iSocketFd);
                g_iSocketFd = 0;
                Mos_Sleep(1000);
                continue;
            }
            MOS_LOG_ERR(AUTO_CONN_LOGSTR, "tcp Socket_Connect is failed \n");
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            iRet = MOS_ERR;
            break;    
        }
        else
        {    
            MOS_LOG_INF(AUTO_CONN_LOGSTR, "tcp Socket_Connect is successful \n");
        }

        Mos_SocketSetRecvTimeOut(g_iSocketFd, iTimeOutSec);
        Mos_SocketSetSendTimeOut(g_iSocketFd, iTimeOutSec);

        //协商密钥生成方式
        iRet = AutoConn_Keyngreq(g_iSocketFd,&iSequence);
        if (iRet < MOS_OK)
        {
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_SocketClose(g_iSocketFd);
                g_iSocketFd = 0;
                Mos_Sleep(1000);
                continue;
            }
            iRet = MOS_ERR;
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            break;    
        }

        //数据交互获取公钥
        iRet = AutoConn_Sendkey(g_iSocketFd,&iSequence,aucPubKey,aucDHPValue,aucDHGValue,aucDHkey);
        if (iRet < MOS_OK)
        {
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_SocketClose(g_iSocketFd);
                g_iSocketFd = 0;
                Mos_Sleep(1000);
                continue;
            }
            iRet = MOS_ERR;
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            break;    
        }

        //进行运算生成共享密钥，用于数据的加解密
        if (Adpt_DHGenerateSharekey(hDHCtx, aucDHkey, aucSharekey) != 0)
        {
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_SocketClose(g_iSocketFd);
                g_iSocketFd = 0;
                Mos_Sleep(1000);
                continue;
            }              
            MOS_LOG_INF(AUTO_CONN_LOGSTR,"Adpt_DHGenerateSharekey Failed!\n");
            iRet = MOS_ERR;
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            break;    
        }
        MOS_LOG_INF(AUTO_CONN_LOGSTR,"Adpt_DHGenerateSharekey successfully!\n");   

        //进行设备注册
        iRet = AutoConn_DevReg(g_iSocketFd,&iSequence,aucSharekey);
        if (iRet < MOS_OK)
        {
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_SocketClose(g_iSocketFd);
                g_iSocketFd = 0;
                Mos_Sleep(1000);
                continue;
            }
            iRet = MOS_ERR;
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            break;    
        }

        AutoConn_Keepalive(g_iSocketFd, &iSequence, aucSharekey);

        _INT i = 0;
        while (i < 30)
        {
            i++;
            wait_time.tv_sec  = 1;
            wait_time.tv_usec = 0;
            FD_ZERO(&readfds);
            FD_SET(g_iSocketFd, &readfds);
            switch (select(g_iSocketFd+1, &readfds, MOS_NULL, MOS_NULL, &wait_time))
            {
                case -1:
                    MOS_PRINTF(":::%s:::%d::::\n",__func__,__LINE__);
                case 0:        
                    MOS_PRINTF(":::%s:::%d::::\n",__func__,__LINE__);
                default:
                {
                    if (FD_ISSET(g_iSocketFd, &readfds))
                    {
                        _UC pucRecvBuf[1024]   = {0};
                        iRet =  AutoConn_RecvData(g_iSocketFd, aucSharekey, pucRecvBuf);
                        if (iRet == MOS_OK)
                        {
                            if (MOS_STRSTR(pucRecvBuf,"allow") != MOS_NULL)
                            {
                                //获取正常上网的WiFi账号密码
                                AutoConn_GetSSID(g_iSocketFd,aucSharekey,aucGetSSID,aucGetKey,aucGetAuth,pucRecvBuf);
                                iGetSSidFlag = 1;                               
                            }		
                        }
                    }
                } 
                break;
            }

            if (iGetSSidFlag == 1)
            {        
                //设备端设置并切换正常上网的WIFI
                if (ZJ_GetFuncTable()->pFunSetAutoConnSsid)
                {
                    iRet = ZJ_GetFuncTable()->pFunSetAutoConnSsid(EN_ZJ_NETWORK_TYPE_WIFI, aucGetSSID, aucGetKey, 0);
                    if (iRet == MOS_ERR)
                    {
                        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pFunSetAutoConnSsid err"); 
                        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
                    }
                }
                else if (ZJ_GetFuncTable()->pfuncSetWifi)
                {
                    iRet = ZJ_GetFuncTable()->pfuncSetWifi(EN_ZJ_NETWORK_TYPE_WIFI, aucGetSSID, aucGetKey, 0);
                    if (iRet == MOS_ERR)
                    {
                        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pfuncSetWifi err"); 
                        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
                    }
                }
                else
                {
                    iRet = MOS_ERR;
                    MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pFunSetwifiSsid is NULL!");
                    Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
                }
                break;
            }
            else if(i%3 == 0)
            {
                iRet = AutoConn_Keepalive(g_iSocketFd, &iSequence, aucSharekey);
                if (iRet < MOS_OK)
                {
                    break;    
                }
            }

            Mos_Sleep(1000);
        }  

        break;
    }
    
    //关闭TCP连接
    Mos_SocketClose(g_iSocketFd);
    g_iSocketFd = 0;
    iRetryCount = 0;

    while(AutoConn_GetTaskMng ()->ucRunFlag && iGetSSidFlag == 1)
    {
        //生成UDP套接字
        g_iSocketFd = Mos_SocketOpen(EN_CINET_TYPE_IPV4, EN_CINET_PRTL_UDP, MOS_TRUE, MOS_TRUE);
        if (g_iSocketFd == MOS_SOCKET_INVALID)
        {        
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_Sleep(5*1000);
                continue;
            }            
            MOS_LOG_ERR(AUTO_CONN_LOGSTR, "Create iUdpSocket error \n");
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            iRet = MOS_ERR;
            break;    
        }
 
        //进行UDP连接
        inet_aton(aucGateway, &addr);
        ST_MOS_INET_IP tUdpServerAddr = {0};

        tUdpServerAddr.usType = EN_CINET_TYPE_IPV4;
        tUdpServerAddr.usPort = 32767;
        tUdpServerAddr.u.uiIp = addr.s_addr;

        iRet = Mos_SocketConnect(g_iSocketFd, &tUdpServerAddr, &bConnect);
        if (iRet != MOS_OK)
        {
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_SocketClose(g_iSocketFd);
                g_iSocketFd = 0;
                Mos_Sleep(5*1000);
                continue;
            }    
            MOS_LOG_ERR(AUTO_CONN_LOGSTR, "udp Socket_Connect is failed \n");
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            iRet = MOS_ERR;
            break;    
        }
        else
        {    
            MOS_LOG_INF(AUTO_CONN_LOGSTR, "udp Socket_Connect is successful \n");
        }

        iTimeOutSec = 15;
        Mos_SocketSetRecvTimeOut(g_iSocketFd, iTimeOutSec);
        Mos_SocketSetSendTimeOut(g_iSocketFd, iTimeOutSec);

        //发送UDP报文，通知入网成功
        iRet = AutoConn_SendUdppack(g_iSocketFd,&iSequence);
        if (iRet < MOS_OK)
        {
            if (iRetryCount < 3)
            {
                iRetryCount++;
                Mos_SocketClose(g_iSocketFd);
                g_iSocketFd = 0;
                Mos_Sleep(1000);
                continue;
            }    
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            iRet = MOS_ERR;
            break;    
        }
        else
        {
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
        }

        break;
    }

    //释放dh
    Adpt_DHDeleteCrypto(hDHCtx);

    g_iNormalWifiStatus = 0;

    //通知设备端无感配网结果
    if (ZJ_GetFuncTable()->pFunAutoConnResult)
    {
        if (iRet < MOS_OK)
        {
            ZJ_GetFuncTable()->pFunAutoConnResult(MOS_ERR);
        }
        else
        {
            ZJ_GetFuncTable()->pFunAutoConnResult(1);
        }
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pFunAutoConnResult is NULL!");
    }

    // 关闭socket
    if (g_iSocketFd && Mos_SocketClose(g_iSocketFd) == MOS_ERR)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "Close socket fail error: %s(errno: %d)", strerror(errno), errno);
    }    

    AutoConn_GetTaskMng ()->ucRunFlag = 0;
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_ServerTask_Loop end \n");
    // Mos_ThreadDelete(AutoConn_GetTaskMng ()->hThread);  /*自行退出的线程没有释放内存， Mos_ThreadFree(AutoConn_GetTaskMng()->hThread)*/
    return MOS_OK;
}

_INT AutoConn_Task_Stop()
{
    if (AutoConn_GetTaskMng ()->ucRunFlag == 0)
    {
        if (AutoConn_GetTaskMng ()->hThread){
            Mos_ThreadDelete(AutoConn_GetTaskMng ()->hThread);
        }
        MOS_LOG_WARN(AUTO_CONN_LOGSTR, "Already Stop");
        return MOS_OK;
    }
    AutoConn_GetTaskMng ()->ucRunFlag  = 0;
    // Mos_MsgQueueWake(AutoConn_GetTaskMng ()->hMsgQueque,MOS_TRUE);
    Mos_ThreadDelete(AutoConn_GetTaskMng ()->hThread);
    
    // 关闭socket
    if (g_iSocketFd && Mos_SocketClose(g_iSocketFd) == MOS_ERR)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "Close socket fail error: %s(errno: %d)", strerror(errno), errno);
    }

    MOS_PRINTF("auto conn task stop ok \r\n");
    return MOS_OK;
}

_INT AutoConn_Task_Destroy()
{
    if (AutoConn_GetTaskMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(AUTO_CONN_LOGSTR, "Already Destroy");
        return MOS_OK;
    }
    
    // Mos_MsgQueueDelete(AutoConn_GetTaskMng ()->hMsgQueque);
    AutoConn_GetTaskMng()->ucInitFlag = 0;
    MOS_MEMSET(&g_stAutoConnMng, 0, sizeof(g_stAutoConnMng));
    MOS_LOG_INF(AUTO_CONN_LOGSTR,"auto conn task Destroy ok \r\n");
    return MOS_OK;
}

static _INT AutoConn_GetAesCBCOutputLength(_UC *plainString)
{
    _INT cipher_len = ((strlen(plainString)) / 16 + 1) * 16;
    return cipher_len;
}

static _INT AutoConn_SocketSend(_INT iSocketFd, _VPTR pBuf, _INT iLen, _INT iProtoType)
{
    _INT iTimeout   = 0;
    _INT iSendLen   = 0; 
    _INT iRetLen    = 0;
    _INT iLeftLen   = iLen;
    _VPTR pTmpBuf   = pBuf;
    _BOOL pbOutWait = MOS_FALSE;

    if (pBuf == MOS_NULL)
    {
        return MOS_ERR;
    }

    if (iProtoType == EN_CINET_PRTL_UDP)
    {
        iRetLen = Mos_SocketSend(iSocketFd, pTmpBuf, iLeftLen, &pbOutWait);
        iSendLen = iRetLen;
    }
    else
    {    
        while (iLeftLen)
        {   
            iRetLen = Mos_SocketSend(iSocketFd, pTmpBuf, iLeftLen, &pbOutWait);
            if (iRetLen <= 0)
            {
                if (pbOutWait)
                {
                    ++iTimeout;
                    if(iTimeout >= 10)
                    {
                        return iSendLen;
                    }
                    continue;
                }
                return iSendLen;
            }
            pTmpBuf  += iRetLen;
            iLeftLen -= iRetLen;
            iSendLen += iRetLen;
        }
    }

    return iSendLen;
}

static _INT AutoConn_SocketRecv(_INT iSocketFd, _VPTR pBuf, _INT iLen, _INT iProtoType)
{
    _INT iTimeout  = 0;
    _INT iRetLen   = 0;
    _INT iRecvLen  = 0;
    _INT iLeftLen  = iLen;
    _VPTR pTmpBuf  = pBuf;
    _BOOL bClosed = MOS_FALSE;

    if (pBuf == MOS_NULL)
    {
        return MOS_ERR;
    }

    if (iProtoType == EN_CINET_PRTL_UDP)
    {
        iRetLen = Mos_SocketRecv(iSocketFd, pTmpBuf, iLeftLen, &bClosed);
        iRecvLen = iRetLen;
    }
    else
    {
        while (iLeftLen)
        {
            iRetLen = Mos_SocketRecv(iSocketFd, pTmpBuf, iLeftLen, &bClosed);
            if (iRetLen <= 0)
            {
                if (bClosed == MOS_TRUE ) 
                {
                    return iRecvLen;
                }

                ++iTimeout;
                if(iTimeout >= 10)
                {
                    return iRecvLen;
                }
                continue;      
            }
            
            pTmpBuf  += iRetLen;
            iLeftLen -= iRetLen;
            iRecvLen += iRetLen; 
        }      
    }

    return iRecvLen;
}

static _INT AutoConn_CheckHead(_UC *pBuf)
{
    _INT iDataLen  = 0;

    if (pBuf == MOS_NULL)
    {
        return MOS_ERR;
    }
    //检验校验头标志位
    if(pBuf[0] ==  0x3f && pBuf[1] == 0x72 && pBuf[2] == 0x1f && pBuf[3] == 0xb5)
    {
        //获取接收的数据长度
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "Recv Data Len is (%02x %02x %02x %02x)\n",pBuf[4],pBuf[5],pBuf[6],pBuf[7]);
        iDataLen |= ((pBuf[4])<<24)&0xff000000;
        iDataLen |= ((pBuf[5])<<16)&0xff0000;
        iDataLen |= ((pBuf[6])<<8)&0xff00;
        iDataLen |= (pBuf[7])&0xff;
    }

    return iDataLen;
}

static _INT AutoConn_MakeHead(_UC *pBuf, _INT iDataLen)
{
    _INT iRet  = 0;

    if (pBuf == MOS_NULL)
    {
        return MOS_ERR;
    }

    pBuf[0] = 0x3f;
    pBuf[1] = 0x72;
    pBuf[2] = 0x1f;
    pBuf[3] = 0xb5;
    pBuf[4] = (_UC)(((iDataLen)>>24)&0xff);
    pBuf[5] = (_UC)(((iDataLen)>>16)&0x00ff);
    pBuf[6] = (_UC)(((iDataLen)>>8)&0x0000ff);
    pBuf[7] = (_UC)(iDataLen&0x000000ff);  

    return iRet;
}

static _INT AutoConn_Keyngreq(_INT iSocketFd,_INT *piSequence)
{
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Start\n");
    _INT iLen           = 0;
    _INT iDataLen       = 0;
    _UC aucFramehead[8] = {0};
    _BOOL pbOutWait     = MOS_FALSE;
    _UC *pucStrJson     = MOS_NULL;

    ST_ZJ_NETWORK_INFO stNetWorkInf = {0};
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetWorkInf);
        if (iRet == MOS_ERR)
        {
             MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pfunGetCurNetInfo err");  
        }
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pfunGetCurNetInfo is NULL!");
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"type", Adpt_Json_CreateString("keyngreq"));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"sequence", Adpt_Json_CreateNumber(*piSequence));
    _UC pucOutMac[16] = {0};
    AutoConn_MacRemoveColon(stNetWorkInf.aucMacAddr, pucOutMac);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"mac", Adpt_Json_CreateString(pucOutMac));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"version", Adpt_Json_CreateString("V2019.1.0"));

    JSON_HANDLE hStatusInfo = Adpt_Json_CreateObject();
    JSON_HANDLE hStatusSerial = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hStatusInfo, "keymode", Adpt_Json_CreateString("dh"));
    Adpt_Json_AddItemToArray(hStatusSerial, hStatusInfo);
    Adpt_Json_AddItemToObject(hRoot, "keymodelist", hStatusSerial);

    pucStrJson = Adpt_Json_Print(hRoot);
    iDataLen  = strlen(pucStrJson);
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucSendBuf = %s \n",pucStrJson);

    _INT iHeadLen = sizeof(aucFramehead);

    // 封装数据头
    AutoConn_MakeHead(aucFramehead, iDataLen);

    // 发送数据头
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucFramehead, iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        Adpt_Json_DePrint(pucStrJson);
        Adpt_Json_Delete(hRoot);        
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;       
    }

    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)pucStrJson, iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        Adpt_Json_DePrint(pucStrJson);
        Adpt_Json_Delete(hRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_DePrint(pucStrJson);
    Adpt_Json_Delete(hRoot);

    _INT iGetSequence   = 0;
    _UC aucResBuf[128]  = {0};
    _C acGetTyte[16]    = {0};
    _C acGetKeymode[8]  = {0};

    // 接收8个字节的回复头数据
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }

    iDataLen = AutoConn_CheckHead(aucResBuf);
    if (iDataLen <= 0) 
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    } 

    MOS_MEMSET(aucResBuf,0,sizeof(aucResBuf));
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }

    _UC *pStrTmp = MOS_NULL;

    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucRecvBuf = %s \n",aucResBuf);
    JSON_HANDLE hResRoot = Adpt_Json_Parse(aucResBuf);
    if (hResRoot == NULL)
    {    
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }

    JSON_HANDLE hTheType = Adpt_Json_GetObjectItem(hResRoot,(_UC*)"type");
    if (hTheType == NULL)
    {
        Adpt_Json_Delete(hResRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheType is NULL\n");
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }
    Adpt_Json_GetString(hTheType, &pStrTmp);
    strncpy(acGetTyte, pStrTmp,  strlen(pStrTmp));

    JSON_HANDLE hTheSequence = Adpt_Json_GetObjectItem(hResRoot,(_UC*)"sequence");
    if (hTheSequence == NULL)
    {
        Adpt_Json_Delete(hResRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheSequence is NULL\n");    
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(hTheSequence, &iGetSequence);

    JSON_HANDLE hTheKeymode = Adpt_Json_GetObjectItem(hResRoot,(_UC*)"keymode");
    if (hTheKeymode == NULL)
    {            
        Adpt_Json_Delete(hResRoot);    
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheKeymode is NULL\n");
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }
    Adpt_Json_GetString(hTheKeymode, &pStrTmp);
    strncpy(acGetKeymode, pStrTmp,  strlen(pStrTmp));

    if (strstr(acGetTyte,"keyngack") && iGetSequence == *piSequence && strstr(acGetKeymode,"dh"))
    {
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Successfully\n");
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        Adpt_Json_Delete(hResRoot);
        return MOS_ERR;
    }

    Adpt_Json_Delete(hResRoot);

    *piSequence = *piSequence + 1;
    return MOS_OK;
}


static _INT AutoConn_Sendkey(_INT iSocketFd,_INT *piSequence,_UC *pucPubKey,_UC *pucPValueAes,_UC *pucGValueAes,_UC *pucDHKey)
{
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Start\n");
    _INT i          = 0;
    _INT iLen       = 0;
    _INT iDataLen   = 0;
    _UC aucFramehead[8] = {0};
    _UC *pucStrJson = MOS_NULL;

    ST_ZJ_NETWORK_INFO stNetWorkInf = {0};
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetWorkInf);
        if (iRet == MOS_ERR)
        {
             MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pfunGetCurNetInfo err");  
        }
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pfunGetCurNetInfo is NULL!");
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"type", Adpt_Json_CreateString("dh"));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"sequence", Adpt_Json_CreateNumber(*piSequence));
    _UC pucOutMac[16] = {0};
    AutoConn_MacRemoveColon(stNetWorkInf.aucMacAddr, pucOutMac);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"mac", Adpt_Json_CreateString(pucOutMac));

    JSON_HANDLE hStatusInfo = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"dh_key", Adpt_Json_CreateString((_UC*)pucPubKey));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"dh_p", Adpt_Json_CreateString((_UC*)pucPValueAes));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"dh_g", Adpt_Json_CreateString((_UC*)pucGValueAes));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"data", hStatusInfo);

    pucStrJson = Adpt_Json_Print(hRoot);
    iDataLen = strlen(pucStrJson);
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucSendBuf = %s \n",pucStrJson);

        _INT iHeadLen = sizeof(aucFramehead);

    // 封装数据头
    AutoConn_MakeHead(aucFramehead, iDataLen);

    // 发送数据头
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucFramehead, iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        Adpt_Json_DePrint(pucStrJson);
        Adpt_Json_Delete(hRoot);
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Failed\n");
        return MOS_ERR;
    }

    //发送数据
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)pucStrJson, iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        Adpt_Json_DePrint(pucStrJson);
        Adpt_Json_Delete(hRoot);    
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_DePrint(pucStrJson);
    Adpt_Json_Delete(hRoot);   

    char aucResBuf[1024] = {0};
    // 接收8个字节的回复头数据
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }

    // 检测8个字节的回复头数据
    iDataLen = AutoConn_CheckHead(aucResBuf);
    if (iDataLen <= 0) 
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }    

    // 接收指定长度数据
    MOS_MEMSET(aucResBuf,0,sizeof(aucResBuf));
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keyngreq Failed\n");
        return MOS_ERR;
    }

    _UC *pStrTmp = MOS_NULL;
    _INT iGetSequence = 0;

    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucRecvBuf = %s \n",aucResBuf);

    JSON_HANDLE hResRoot = Adpt_Json_Parse(aucResBuf);
    if (hResRoot == NULL)
    {      
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Failed\n");
        return MOS_ERR;            
    }

    JSON_HANDLE hTheSequence = Adpt_Json_GetObjectItem(hResRoot, (_UC*)"sequence");
    if(hTheSequence == NULL)
    {
        Adpt_Json_Delete(hResRoot);
        
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheSequence is NULL\n");
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Failed\n");
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(hTheSequence, &iGetSequence);

    JSON_HANDLE hTheDatalist  = Adpt_Json_GetObjectItem(hResRoot, (_UC*)"data");
    if (NULL != hTheDatalist)
    {
        JSON_HANDLE hTheDHKey = Adpt_Json_GetObjectItem(hTheDatalist, (_UC*)"dh_key");
        if (hTheDHKey == NULL)
        {
            Adpt_Json_Delete(hResRoot);
            
            MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheDHKey is NULL\n");
            MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Failed\n");
            return MOS_ERR;
        }
        Adpt_Json_GetString(hTheDHKey, &pStrTmp);
        strncpy(pucDHKey, pStrTmp,  strlen(pStrTmp));
    }
    else
    {
        Adpt_Json_Delete(hResRoot);    
        
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheData is NULL\n");
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Failed\n");
        return MOS_ERR;
    }

    if (iGetSequence == *piSequence)
    {
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Successfully\n");
    }
    else
    {
        Adpt_Json_Delete(hResRoot);        
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Sendkey Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_Delete(hResRoot);

    *piSequence = *piSequence + 1;
    return MOS_OK;
}

static _INT AutoConn_Keepalive(_INT iSocketFd,_INT *piSequence,_UC *pucSharekey)
{
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_Keepalive Start\n");
    _INT iLen       = 0;
    _INT iDataLen   = 0;
    _UC aucFramehead[8] = {0};
    _UC *pucStrJson = MOS_NULL;

    ST_ZJ_NETWORK_INFO stNetWorkInf = {0};
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetWorkInf);
        if (iRet == MOS_ERR)
        {
             MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pfunGetCurNetInfo err");  
        }
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pfunGetCurNetInfo is NULL!");
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"type", Adpt_Json_CreateString((_UC*)"keepalive"));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"sequence", Adpt_Json_CreateNumber(*piSequence));
    _UC pucOutMac[16] = {0};
    AutoConn_MacRemoveColon(stNetWorkInf.aucMacAddr, pucOutMac);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"mac", Adpt_Json_CreateString(pucOutMac));

    pucStrJson = Adpt_Json_Print(hRoot);
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucSendBuf = %s \n",pucStrJson);

    _INT iTotalLen  = 0;
    _INT iFixLen    = 0;
    _INT iLoop = 0;
    _UC aucStrJsonTmp[1024] = {0};
    _UC aucParamsstr[128]   = {0};
    _UC aucParamsstr1[128]  = {0};
    _UC aucIV[16] = {0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};

    // 补齐16字节
    iTotalLen = strlen(pucStrJson);
    MOS_MEMCPY(aucStrJsonTmp, pucStrJson, iTotalLen);
    iFixLen = 16 - (iTotalLen % 16);
    if (iFixLen != 0)   
    {
        iTotalLen = iTotalLen + iFixLen;
            
        for (iLoop=0; iLoop<iFixLen; iLoop++)
        {
            aucStrJsonTmp[iTotalLen - iFixLen + iLoop] = iFixLen;
        }

        aucStrJsonTmp[iTotalLen] = '\0';
    }
    iDataLen = AutoConn_GetAesCBCOutputLength(aucStrJsonTmp);

    Adpt_Json_DePrint(pucStrJson);

    Adpt_Aec_Encrypt(pucSharekey, aucIV, aucStrJsonTmp, aucParamsstr, strlen(aucStrJsonTmp));

    _INT iHeadLen = sizeof(aucFramehead);
    // 封装数据头
    AutoConn_MakeHead(aucFramehead, iDataLen);

    // 发送数据头
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucFramehead, iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        Adpt_Json_Delete(hRoot);
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SocketSend Failed\n");
        return MOS_ERR;
    }

    //发送数据
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucParamsstr, iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        Adpt_Json_Delete(hRoot);    
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SocketSend Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_Delete(hRoot);

#if 0    
    char aucResBuf[1024] = {0};
    // 接收8个字节的回复头数据
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_SocketRecv Failed\n");
        return MOS_ERR;
    }

    // 检测8个字节的回复头数据
    iDataLen = AutoConn_CheckHead(aucResBuf);
    if (iDataLen <= 0) 
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_CheckHead Failed\n");
        return MOS_ERR;
    }    

    // 接收指定长度数据
    MOS_MEMSET(aucResBuf,0,sizeof(aucResBuf));
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_SocketRecv Failed\n");
        return MOS_ERR;
    }

    _INT iGetSequence = 0;
    _UC aucDeData[256] = {0};

    Adpt_Aec_Decrypt(pucSharekey, aucIV, aucResBuf, aucDeData, iLen);
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucRecvBuf = %s \n",aucDeData);

    JSON_HANDLE hResRoot = Adpt_Json_Parse(aucDeData);
    if (hResRoot == NULL)
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "Adpt_Json_Parse Failed\n");
    {   
        return MOS_ERR;
    }

    JSON_HANDLE hTheSequence = Adpt_Json_GetObjectItem(hResRoot, (_UC*)"sequence");
    if (hTheSequence == NULL)
    {
        Adpt_Json_Delete(hResRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheSequence is NULL\n");            
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(hTheSequence, &iGetSequence);

    if (iGetSequence == *piSequence)
    {
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_Keepalive Successfully\n");
    }
    else
    {
        Adpt_Json_Delete(hResRoot);        
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_Keepalive Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_Delete(hResRoot);
#endif

    *piSequence = *piSequence + 1;
    return MOS_OK;
}

static _INT AutoConn_DevReg(_INT iSocketFd, _INT *piSequence, _UC *pucSharekey)
{
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_DevReg Start\n");

    _INT iLen       = 0;
    _INT iDataLen   = 0;
    _UC aucFramehead[8] = {0};
    _UC *pucStrJson = MOS_NULL;

    ST_ZJ_NETWORK_INFO stNetWorkInf;
    MOS_MEMSET(&stNetWorkInf, 0, sizeof(stNetWorkInf));
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetWorkInf);
        if (iRet == MOS_ERR)
        {
             MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pfunGetCurNetInfo err");  
        }
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pfunGetCurNetInfo is NULL!");
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"type", Adpt_Json_CreateString("dev_reg"));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"sequence", Adpt_Json_CreateNumber(*piSequence));
    _UC pucOutMac[16] = {0};
    AutoConn_MacRemoveColon(stNetWorkInf.aucMacAddr, pucOutMac);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"mac", Adpt_Json_CreateString(pucOutMac));

    JSON_HANDLE hStatusInfo = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"vendor", Adpt_Json_CreateString(""));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"model", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevModel));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"swversion", Adpt_Json_CreateString("2.0.0.5"));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"hdversion", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"sn", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"ipaddr", Adpt_Json_CreateString(stNetWorkInf.aucIPAddr));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"url", Adpt_Json_CreateString((_UC*)"null"));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"wireless", Adpt_Json_CreateString((_UC*)"yes"));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"CTEI", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"devtype", Adpt_Json_CreateString((_UC*)"IOT"));
    Adpt_Json_AddItemToObject(hStatusInfo, (_UC*)"description", Adpt_Json_CreateString(""));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"data", hStatusInfo);

    pucStrJson = Adpt_Json_Print(hRoot);
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucSendBuf = %s \n",pucStrJson);

    _INT iTotalLen  = 0;
    _INT iFixLen    = 0;
    _INT iLoop = 0;
    _UC aucParamsstr[1024]  = {0};
    _UC aucStrJsonTmp[1024] = {0};
    _UC aucIV[16] = {0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
    // 补齐16字节
    iTotalLen = strlen(pucStrJson);
    MOS_MEMCPY(aucStrJsonTmp, pucStrJson, iTotalLen);
    iFixLen = 16 - (iTotalLen % 16);
    if (iFixLen != 0)   
    {
        iTotalLen = iTotalLen + iFixLen;
            
        for (iLoop=0; iLoop<iFixLen; iLoop++)
        {
            aucStrJsonTmp[iTotalLen - iFixLen + iLoop] = iFixLen;
        }

        aucStrJsonTmp[iTotalLen] = '\0';
    }
    iDataLen = AutoConn_GetAesCBCOutputLength(aucStrJsonTmp);

    Adpt_Json_DePrint(pucStrJson);
    
    Adpt_Aec_Encrypt(pucSharekey, aucIV, aucStrJsonTmp, aucParamsstr, strlen(aucStrJsonTmp));

        _INT iHeadLen = sizeof(aucFramehead);

    // 封装数据头
    AutoConn_MakeHead(aucFramehead, iDataLen);

    // 发送数据头
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucFramehead, iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        Adpt_Json_Delete(hRoot);
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SocketSend Failed\n");
        return MOS_ERR;
    }

    //发送数据
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucParamsstr, iDataLen, EN_CINET_PRTL_TCP);
    if (iLen < MOS_OK)
    {
        Adpt_Json_Delete(hRoot);    
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SocketSend Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_Delete(hRoot);

    char aucResBuf[1024] = {0};
    // 接收8个字节的回复头数据
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_SocketRecv Failed\n");
        return MOS_ERR;
    }

    // 检测8个字节的回复头数据
    iDataLen = AutoConn_CheckHead(aucResBuf);
    if (iDataLen <= 0) 
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_CheckHead Failed\n");
        return MOS_ERR;
    }    

    // 接收指定长度数据
    MOS_MEMSET(aucResBuf,0,sizeof(aucResBuf));
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_SocketRecv Failed\n");
        return MOS_ERR;
    }

    _INT iGetSequence = 0;
    _UC aucDeData[1024] = {0};

    Adpt_Aec_Decrypt(pucSharekey, aucIV, aucResBuf, aucDeData, iLen);
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucRecvBuf = %s \n",aucDeData);

    JSON_HANDLE hResRoot = Adpt_Json_Parse(aucDeData);
    if (hResRoot == NULL)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_DevReg Failed\n");
        return MOS_ERR;
    }

    JSON_HANDLE hTheSequence = Adpt_Json_GetObjectItem(hResRoot, (_UC*)"sequence");
    if (hTheSequence == NULL)
    {
        Adpt_Json_Delete(hResRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheSequence is NULL\n");
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_DevReg Failed\n");
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(hTheSequence, &iGetSequence);

    if (iGetSequence == *piSequence)
    {
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_DevReg Successfully\n");
    }
    else
    {
        Adpt_Json_Delete(hResRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_DevReg Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_Delete(hResRoot);

    *piSequence = *piSequence + 1;

    return MOS_OK;
}

static _INT AutoConn_RecvData(_INT iSocketFd, _UC *pucSharekey, _UC *pucRecvBuf)
{
    _INT iLen            = 0;
    _INT iDataLen        = 0;
    _C aucResBuf[1024]   = {0};

    _UC aucFramehead[8] = {0};
    _INT iHeadLen       = sizeof(aucFramehead);   

    // 接收8个字节的回复头数据
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_SocketRecv(iLen = %d) Failed\n",iLen);
        return MOS_ERR;
    }

    // 检测8个字节的回复头数据
    iDataLen = AutoConn_CheckHead(aucResBuf);
    if (iDataLen <= 0) 
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_CheckHead Failed\n");
        return MOS_ERR;
    }    

    // 接收指定长度数据
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "iDataLen = %d\n",iDataLen);
    MOS_MEMSET(aucResBuf,0,sizeof(aucResBuf));
    iLen = AutoConn_SocketRecv(iSocketFd, (_VPTR)(aucResBuf), iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_SocketRecv Failed\n");
        return MOS_ERR;
    }    

    _UC *pStrTmp = MOS_NULL;
    _INT iGetSequence  = 0;
    _C acGetResult[16] = {0};

    _UC aucIV[16] = {0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};

    Adpt_Aec_Decrypt(pucSharekey, aucIV, aucResBuf, pucRecvBuf, iLen);

    MOS_LOG_INF(AUTO_CONN_LOGSTR, "aucRecvBuf = %s \n",pucRecvBuf);

    return MOS_OK;
}

static _INT AutoConn_GetSSID(_INT iSocketFd, _UC *pucSharekey,_UC *pucGetSSID,_UC *pucGetKey,_UC *pucGetAuth,_UC *pucDeData)
{
    _INT iGetSequence    = 0;
    _INT iCompleteFlag   = 0;
    _C aucGetMode[16]    = {0};
    _C acGetResult[16]   = {0};
    _UC *pStrTmp         = MOS_NULL;
    _UC aucIV[16]        = {0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};

    JSON_HANDLE hResRoot = Adpt_Json_Parse(pucDeData);
    if (hResRoot == NULL)
    {       
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "Adpt_Json_Parse Failed\n");
        return MOS_ERR;
    }

    JSON_HANDLE hTheSequence = Adpt_Json_GetObjectItem(hResRoot, (_UC*)"sequence");
    if (hTheSequence == NULL)
    {
        Adpt_Json_Delete(hResRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheSequence is NULL\n");        
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(hTheSequence, &iGetSequence);

    JSON_HANDLE hTheResult = Adpt_Json_GetObjectItem(hResRoot, (_UC*)"result");
    if (hTheResult == NULL)
    {
        Adpt_Json_Delete(hResRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheResult is NULL\n");        
        return MOS_ERR;
    }
    Adpt_Json_GetString(hTheResult, &pStrTmp);
    strncpy(acGetResult, pStrTmp,  strlen(pStrTmp));

    if (strstr(acGetResult,"allow"))
    {
        JSON_HANDLE hTheWifiList  = Adpt_Json_GetObjectItem(hResRoot, (_UC*)"wifi");
        if (NULL != hTheWifiList)
        {
            JSON_HANDLE hChildWifiList    = Adpt_Json_GetChild(hTheWifiList);
            while (hChildWifiList != NULL)
            {
                JSON_HANDLE hTheRadioList  = Adpt_Json_GetObjectItem(hChildWifiList, (_UC*)"radio");
                if (NULL != hTheRadioList)
                {
                    JSON_HANDLE hTheMode = Adpt_Json_GetObjectItem(hTheRadioList, (_UC*)"mode");
                    if (hTheMode == NULL)
                    {
                        Adpt_Json_Delete(hResRoot);
                        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheMode is NULL\n");        
                        return MOS_ERR;
                    }
                    Adpt_Json_GetString(hTheMode, &pStrTmp);
                    strncpy(aucGetMode, pStrTmp,  strlen(pStrTmp));
                }

                if (strstr(aucGetMode,"2.4G"))
                {
                    JSON_HANDLE hAPList  = Adpt_Json_GetObjectItem(hChildWifiList, (_UC*)"ap");
                    if (NULL != hAPList)
                    {
                        JSON_HANDLE hChildAPList    = Adpt_Json_GetChild(hAPList);
                        if (hChildAPList != NULL)
                        {
                            JSON_HANDLE hTheSSID = Adpt_Json_GetObjectItem(hChildAPList, (_UC*)"ssid");
                            if (hTheSSID == NULL)
                            {
                                Adpt_Json_Delete(hResRoot);
                                MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheSSID is NULL\n");        
                                return MOS_ERR;
                            }
                            Adpt_Json_GetString(hTheSSID, &pStrTmp);
                            strncpy(pucGetSSID, pStrTmp,  strlen(pStrTmp));

                            JSON_HANDLE hTheKey = Adpt_Json_GetObjectItem(hChildAPList, (_UC*)"key");
                            if (hTheKey == NULL)
                            {
                                Adpt_Json_Delete(hResRoot);
                                MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheKey is NULL\n");        
                                return MOS_ERR;
                            }
                            Adpt_Json_GetString(hTheKey, &pStrTmp);
                            strncpy(pucGetKey, pStrTmp,  strlen(pStrTmp));


                            JSON_HANDLE hTheAuth = Adpt_Json_GetObjectItem(hChildAPList, (_UC*)"auth");
                            if (hTheAuth == NULL)
                            {
                                Adpt_Json_Delete(hResRoot);
                                MOS_LOG_ERR(AUTO_CONN_LOGSTR, "TheAuth is NULL\n");        
                                return MOS_ERR;
                            }
                            Adpt_Json_GetString(hTheAuth, &pStrTmp);
                            strncpy(pucGetAuth, pStrTmp,  strlen(pStrTmp));

                            iCompleteFlag = 1;
                            MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_GetSSID Successfully\n");
                            break;
                        }
                    }
                }

                if (iCompleteFlag == 1)
                {
                    break;
                }
                hChildWifiList = Adpt_Json_GetNext(hChildWifiList);
            }
        }
        else
        {
            Adpt_Json_Delete(hResRoot);            
            MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_GetSSID Failed\n");
            return MOS_ERR;
        }

    }
    else
    {
        Adpt_Json_Delete(hResRoot);
        MOS_LOG_ERR(AUTO_CONN_LOGSTR, "AutoConn_GetSSID Failed\n");
        return MOS_ERR;
    }

    if (hResRoot != NULL)
    {
        Adpt_Json_Delete(hResRoot);
    }

    _INT iHeadFlag      = 0;
    _INT iLen           = 0;
    _INT iDataLen       = 0;
    _UC aucFramehead[8] = {0};   
    _UC *pucStrJson     = MOS_NULL;
    _INT iHeadLen       = sizeof(aucFramehead);

    ST_ZJ_NETWORK_INFO stNetWorkInf;
    MOS_MEMSET(&stNetWorkInf, 0, sizeof(stNetWorkInf));
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetWorkInf);
        if (iRet == MOS_ERR)
        {
             MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pfunGetCurNetInfo err");  
        }
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pfunGetCurNetInfo is NULL!");
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"type", Adpt_Json_CreateString((_UC*)"ack"));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"sequence", Adpt_Json_CreateNumber(iGetSequence));
    _UC pucOutMac[16] = {0};
    AutoConn_MacRemoveColon(stNetWorkInf.aucMacAddr, pucOutMac);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"mac", Adpt_Json_CreateString(pucOutMac));
    pucStrJson = Adpt_Json_Print(hRoot);

    _INT iTotalLen  = 0;
    _INT iFixLen    = 0;
    _INT iLoop      = 0;
    _UC aucStrJsonTmp[1024] = {0};
    _UC aucParamsstr[128] = {0};
    // 补齐16字节
    iTotalLen = strlen(pucStrJson);
    MOS_MEMCPY(aucStrJsonTmp, pucStrJson, iTotalLen);
    iFixLen = 16 - (iTotalLen % 16);
    if (iFixLen != 0)   
    {
        iTotalLen = iTotalLen + iFixLen;
            
        for (iLoop=0; iLoop<iFixLen; iLoop++)
        {
            aucStrJsonTmp[iTotalLen - iFixLen + iLoop] = iFixLen;
        }

        aucStrJsonTmp[iTotalLen] = '\0';
    }
    iDataLen = AutoConn_GetAesCBCOutputLength(aucStrJsonTmp);

    Adpt_Json_DePrint(pucStrJson);

    Adpt_Aec_Encrypt(pucSharekey, aucIV, aucStrJsonTmp, aucParamsstr, strlen(aucStrJsonTmp));

    // 封装数据头
    AutoConn_MakeHead(aucFramehead, iLen);

    // 发送数据头
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucFramehead, iHeadLen, EN_CINET_PRTL_TCP);
    if (iLen != iHeadLen)
    {
        Adpt_Json_Delete(hRoot);
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_GetSSID Failed\n");
        return MOS_ERR;
    }

    //发送数据
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucParamsstr, iDataLen, EN_CINET_PRTL_TCP);
    if (iLen != iDataLen)
    {
        Adpt_Json_Delete(hRoot);    
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_GetSSID Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_Delete(hRoot);

    return MOS_OK;
}

static _INT AutoConn_SendUdppack(_INT iSocketFd,_INT *piSequence)
{
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SendUdppack Start\n");

    _INT iLen       = 0;
    _INT iDataLen   = 0;
    _UC aucFramehead[8] = {0};
    _UC *pucStrJson = MOS_NULL;

    ST_ZJ_NETWORK_INFO stNetWorkInf;
    MOS_MEMSET(&stNetWorkInf, 0, sizeof(stNetWorkInf));
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetWorkInf);
        if (iRet == MOS_ERR)
        {
             MOS_LOG_ERR(AUTO_CONN_LOGSTR,"Device pfunGetCurNetInfo err");  
        }
    }
    else
    {
        MOS_LOG_ERR(AUTO_CONN_LOGSTR,"pfunGetCurNetInfo is NULL!");
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"type", Adpt_Json_CreateString((_UC*)"qlinkFinish"));
    _UC pucOutMac[16] = {0};
    AutoConn_MacRemoveColon(stNetWorkInf.aucMacAddr, pucOutMac);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"mac", Adpt_Json_CreateString(pucOutMac));

    pucStrJson = Adpt_Json_Print(hRoot);

    iDataLen = strlen(pucStrJson);
     _INT iHeadLen = sizeof(aucFramehead);

    // 封装数据头
    AutoConn_MakeHead(aucFramehead, iDataLen);

    // 发送数据头
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)aucFramehead, iHeadLen, EN_CINET_PRTL_UDP);
    if (iLen != iHeadLen)
    {
        Adpt_Json_DePrint(pucStrJson);
        Adpt_Json_Delete(hRoot);
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SendUdppack Failed\n");
        return MOS_ERR;
    }

    //发送数据
    iLen = AutoConn_SocketSend(iSocketFd, (_VPTR)pucStrJson, iDataLen, EN_CINET_PRTL_UDP);
    if (iLen != iDataLen)
    {
        Adpt_Json_DePrint(pucStrJson);
        Adpt_Json_Delete(hRoot);    
        MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SendUdppack Failed\n");
        return MOS_ERR;
    }

    Adpt_Json_DePrint(pucStrJson);
    Adpt_Json_Delete(hRoot);
    
    MOS_LOG_INF(AUTO_CONN_LOGSTR, "AutoConn_SendUdppack SUccessfully\n");
    return MOS_OK;
}
