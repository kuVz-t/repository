#include "config_ap.h"
#include "http_api.h"
#include "kj_timer.h"
#include "msgmng_api.h"
#include "adpt_json_adapt.h"
#include "qualityprobe_api.h"

static _INT g_iconnfd   = 0;
static _INT g_iListenfd = 0;
static ST_CFGAP_MNG g_stCdgApMng = {0};
_INT Cfgap_ServerTask_Loop(_VPTR pstArg);

ST_CFGAP_MNG *Cfgap_GetTaskMng()
{
    return &g_stCdgApMng;
}

_INT Cfgap_Task_Init()
{
    if(Cfgap_GetTaskMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(AP_LOGSTR, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stCdgApMng , 0, sizeof(g_stCdgApMng ));
    Cfgap_GetTaskMng()->hMsgQueue = Mos_MsgQueueCreate(MOS_FALSE,3,__FUNCTION__);
    Cfgap_GetTaskMng()->ucInitFlag = 1;
    // MOS_PRINTF("cfgap msg queue %p  \r\n",Cfgap_GetTaskMng ()->hMsgQueue);
    MOS_LOG_INF(AP_LOGSTR, "AP INIT OK !!!!!!!!!!!!!!!!");
    return MOS_OK;
}

_INT Cfgap_Task_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;

    if(Cfgap_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    
    if(Cfgap_GetTaskMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(AP_LOGSTR, "Already Start");
        return MOS_OK;
    }

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif

#if 0
    ST_MOS_INET_IP stLocalIp = {0};

    // 创建socket
    g_iListenfd = Mos_SocketOpen(EN_CINET_TYPE_IPV4, EN_CINET_PRTL_TCP, MOS_TRUE, MOS_TRUE);
    if (g_iListenfd == MOS_SOCKET_INVALID)
    {
        MOS_LOG_ERR(AP_LOGSTR, "Open socket fail error: %s(errno: %d)", strerror(errno), errno);
        return MOS_ERR;
    }

    MOS_LOG_INF(AP_LOGSTR, "Open socket SuccessFul g_iListenfd:%d !!!!!!!!!!!!!!!!", g_iListenfd);
    

    memset(&stLocalIp,0,sizeof(stLocalIp));
    stLocalIp.usType = EN_CINET_TYPE_IPV4;
    stLocalIp.usPort = htons(CONFIG_AP_PORT);      // 80008
    stLocalIp.u.uiIp = htonl(INADDR_ANY);

    // 绑定
    if( Mos_SocketBind(g_iListenfd, &stLocalIp) == -1)
    {
        MOS_LOG_ERR(AP_LOGSTR, "Bind socket fail error: %s(errno: %d)", strerror(errno), errno);
        return MOS_ERR;
    }

    MOS_LOG_INF(AP_LOGSTR, "Bind socket SuccessFul g_iListenfd:%d Type:%d Port:%u(%u) IP:%u !!!!!!!!!!!!!!!!", 
                            g_iListenfd, stLocalIp.usType, stLocalIp.usPort, CONFIG_AP_PORT, stLocalIp.u.uiIp);

    // 监听
    if( Mos_SocketListen(g_iListenfd) == -1)
    {
        MOS_LOG_ERR(AP_LOGSTR, "Listen socket fail error: %s(errno: %d)", strerror(errno), errno);
        return MOS_ERR;
    }

    MOS_LOG_INF(AP_LOGSTR, "Listen socket SuccessFul g_iListenfd:%d !!!!!!!!!!!!!!!!", g_iListenfd);
#endif
    Cfgap_GetTaskMng()->ucRunFlag  = 1;
    if(Mos_ThreadCreate((_UC*)"CfgAp_task",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        Cfgap_ServerTask_Loop,MOS_NULL,MOS_NULL,&Cfgap_GetTaskMng()->hThread) == MOS_ERR)
    {
        Cfgap_GetTaskMng ()->ucRunFlag = 0;
        return MOS_ERR;
    }
    MOS_LOG_INF(AP_LOGSTR, "AP Start OK !!!!!!!!!!!!!!!!");

    return MOS_OK;
}

_INT Cfgap_ServerTask_Loop(_VPTR pstArg)
{
    #if 0
    // ST_MOS_MSGHEAD *pstMsgHead;
    // kj_timer_t  tCheckAliveTimeout;
    // kj_timer_init(&tCheckAliveTimeout);
    // getDiffTimems(&tCheckAliveTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);

    _INT iConnfd             =  0;
    _INT iRecvLen            =  0;
    ST_MOS_INET_IP stRmtAddr = {0};
    char cRecvBuff[SOCKET_RECV_MAX_BUFLEN] = {0};

    memset(&stRmtAddr,0,sizeof(stRmtAddr));
    stRmtAddr.usType = EN_CINET_TYPE_IPV4;

    MOS_PRINTF("======waiting for client's request======\n");
    while(Cfgap_GetTaskMng()->ucRunFlag)
    {
        #if 1
        // Accept
        if( (iConnfd = Mos_SocketAccept(g_iListenfd, &stRmtAddr, MOS_NULL)) == -1)
		{
            MOS_LOG_ERR(AP_LOGSTR, "Accept socket fail error: %s(errno: %d)", strerror(errno), errno);
			continue;
		}

        MOS_LOG_INF(AP_LOGSTR, "AP Accept OK !!!!!!!!!!!!!!!!");

        // 接收数据
        iRecvLen = Mos_SocketRecv(iConnfd, cRecvBuff, SOCKET_RECV_MAX_BUFLEN, 0);
		cRecvBuff[iRecvLen] = '\0';

		MOS_PRINTF("%s %d: !!!!!!!!!!!!!!!! recv msg from client: %s \r\n", __func__, __LINE__, cRecvBuff);

        // 关闭socket
        if( Mos_SocketClose(g_iListenfd) == -1)
        {
            MOS_LOG_ERR(AP_LOGSTR, "Close socket fail error: %s(errno: %d)", strerror(errno), errno);
        }
        #else
        pstMsgHead = Mos_MsgQueuePop(Cfgap_GetTaskMng()->hMsgQueue);
        if(pstMsgHead)
        {
//          switch(pstMsgHead->usMsgType)
//          {
//              default:
//              {
//                  break;
//             }
//          }
            MOS_FREE(pstMsgHead);
        }
        else
        {
            _INT keepAliveMseconds = getDiffTimems(&tCheckAliveTimeout, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
            if (keepAliveMseconds >= 5*1000)
            {
                getDiffTimems(&tCheckAliveTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
            }

            Mos_Sleep(1*1000);
        }
        #endif
    }
    return MOS_OK;
    #else
    _INT iRet = MOS_OK;
    _INT iMsgBuffLen                  =  0;
    struct sockaddr_in servaddr       = {0};
    unsigned char buff[SOCKET_RECV_MAX_BUFLEN] = {0};
    ST_AP_ONLINESTATUS_MSG *pstApMsg;

    do{
        if( (g_iListenfd = socket(AF_INET, SOCK_STREAM,0)) == -1)
        {
            iRet = MOS_ERR;
            MOS_LOG_ERR(AP_LOGSTR,"create socket error: %s(errno: %d) \r\n", strerror(errno), errno);
            break;
        }

        int flags = fcntl(g_iListenfd, F_GETFL, 0);         //获取文件状态标志
        fcntl(g_iListenfd, F_SETFL, flags | O_NONBLOCK);    //设置文件状态标志

        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family      = AF_INET;
        servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
        servaddr.sin_port        = htons(CONFIG_AP_PORT);

        if( bind(g_iListenfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) == -1)
        {
            iRet = MOS_ERR;
            MOS_LOG_ERR(AP_LOGSTR,"bind socket error: %s(errno: %d)", strerror(errno), errno);
            break;
        }

        MOS_LOG_INF(AP_LOGSTR, "Bind socket SuccessFul g_iListenfd:%d Port:%u(%u) IP:%u !!!!!!!!!!!!!!!!", 
                                g_iListenfd, servaddr.sin_port, CONFIG_AP_PORT, servaddr.sin_addr.s_addr);

        if( listen(g_iListenfd,10) == -1)
        {
            iRet = MOS_ERR;
            MOS_LOG_ERR(AP_LOGSTR,"listen socket error: %s(errno: %d)", strerror(errno), errno);
            break;
        }
    }while(0);
    if (iRet == MOS_ERR)
    {
        Cfgap_GetTaskMng()->ucRunFlag = 0;
        if (g_iListenfd != MOS_SOCKET_INVALID)
        {
            Mos_SocketClose(g_iListenfd);
            g_iListenfd = MOS_SOCKET_INVALID;
        }
        // Mos_ThreadDelete(Cfgap_GetTaskMng()->hThread);  /*Mos_ThreadFree(AutoConn_GetTaskMng()->hThread)*/
        return MOS_ERR;
    }

    MOS_PRINTF("======waiting for client's request====== \r\n");

    while(Cfgap_GetTaskMng()->ucRunFlag)
    {
        if(Mos_MsgQueueGetCount(Cfgap_GetTaskMng()->hMsgQueue) > 0)
        {  
            pstApMsg = (ST_AP_ONLINESTATUS_MSG *)Mos_MsgQueuePop(Cfgap_GetTaskMng()->hMsgQueue);
            if (pstApMsg != NULL)
            {
                if( pstApMsg->uiOnlineStatus == EN_ZJ_DEVICE_STATUS_ONLINE )
                {
                    MOS_FREE(pstApMsg);
                    break;
                }
                MOS_FREE(pstApMsg);
            }
        }

        if( (g_iconnfd = accept(g_iListenfd, (struct sockaddr*)NULL, NULL)) == -1)
        {
            //MOS_PRINTF("accept socket error: %s(errno: %d) \r\n", strerror(errno), errno);
            Mos_Sleep(10);
            continue;
        }

        while(Cfgap_GetTaskMng()->ucRunFlag)
        {    
            // MOS_PRINTF("\r\n\r\n Cfgap_ServerTask_Loop accept socket success g_iListenfd:%d  g_iconnfd:%d  !!!!!!!!! \r\n\r\n", g_iListenfd, g_iconnfd);
            iMsgBuffLen = recv(g_iconnfd, buff, SOCKET_RECV_MAX_BUFLEN,0);
            if (iMsgBuffLen <= 0)
            {
                MOS_LOG_ERR(AP_LOGSTR,"recv socket error: %s(errno: %d)", strerror(errno), errno);
                break;
            }

            buff[iMsgBuffLen] = '\0';
            BUF_PRINTF_EX("AP RecvData", buff, iMsgBuffLen);

            ST_OGCT_PROTOCAL_HEAD stOgctHead;

            if(iMsgBuffLen < sizeof(stOgctHead))
            {
                MOS_LOG_ERR(AP_LOGSTR,"msg Buf err");
                break;
            }
            MOS_MEMCPY(&stOgctHead, buff, sizeof(ST_OGCT_PROTOCAL_HEAD));

            if(stOgctHead.aucheck[0] != '#' || stOgctHead.aucheck[1] != '$')
            {
                MOS_LOG_ERR(AP_LOGSTR,"parse msg head err");
                break;
            }

            stOgctHead.usBodyLen = MOS_INET_NTOHS(stOgctHead.usBodyLen);
            if(stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD) > (_US)iMsgBuffLen)
            {
                MOS_LOG_ERR(AP_LOGSTR,"parse msg len err");
                break;
            }
            MOS_PRINTF("\r\n\r\n Cfgap_ServerTask_Loop ucMsgId:0x%x, ucMsgType:0x%x, usBodyLen:0x%x(%d)   \r\n\r\n", 
                            stOgctHead.ucMsgId, stOgctHead.ucMsgType, stOgctHead.usBodyLen, stOgctHead.usBodyLen);

            //buff      += sizeof(ST_OGCT_PROTOCAL_HEAD);
            iMsgBuffLen -= sizeof(ST_OGCT_PROTOCAL_HEAD);

            _INT iSeqID       =  0;
            _UC  aucMethod[8] = {0};
            _UC  *pucMethod   = MOS_NULL;
            JSON_HANDLE hRoot = MOS_NULL;
            hRoot = Adpt_Json_Parse(buff + sizeof(ST_OGCT_PROTOCAL_HEAD));
            if(hRoot == MOS_NULL)
            {
                MOS_LOG_ERR(AP_LOGSTR, "parse net msg body err");
                break;
            }

            do
            {
                MOS_SPRINTF(aucMethod, "%02X%02X",stOgctHead.ucMsgType, stOgctHead.ucMsgId);
                
                // 解析 方法METHOD 字段
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot, (_UC*)"METHOD"), &pucMethod);
                if(MOS_STRCMP(aucMethod, pucMethod) != 0)
                {
                    MOS_LOG_ERR(AP_LOGSTR, "msg check method err");
                    break;
                }

                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"), &iSeqID);
                
                // 处理下发的信令
                iRet = MsgMng_DispatchMsg(MSGMNG_AP_SERVER_ID, stOgctHead.ucMsgType, stOgctHead.ucMsgId, hRoot);
            }while(0);

            Adpt_Json_Delete(hRoot);

            if (iRet == MOS_OK && stOgctHead.ucMsgType == 0x34 && stOgctHead.ucMsgId == 0x70)
            {
                MOS_PRINTF("AP send server success\r\n");
                break;
            }
        }
        MOS_PRINTF("======Cfgap_ServerTask_Loop close socket Client FD:%d ====== \r\n", g_iconnfd);
        Mos_SocketClose(g_iconnfd);
        g_iconnfd = MOS_SOCKET_INVALID;
    }

    MOS_PRINTF("======Cfgap_ServerTask_Loop close socket Server FD:%d ====== \r\n", g_iListenfd);
    Mos_SocketClose(g_iListenfd);
    g_iListenfd = MOS_SOCKET_INVALID;
    Cfgap_GetTaskMng()->ucRunFlag = 0;
    Cfgap_GetTaskMng()->ucInitFlag = 0;
    while((pstApMsg = Mos_MsgQueuePop(Cfgap_GetTaskMng()->hMsgQueue)) != MOS_NULL)
    {
        MOS_FREE(pstApMsg);
    }
    Mos_MsgQueueDelete(Cfgap_GetTaskMng()->hMsgQueue);
    // Mos_ThreadDelete(Cfgap_GetTaskMng()->hThread); /*自行退出的线程没有释放内存， Mos_ThreadFree(AutoConn_GetTaskMng()->hThread)*/
    MOS_LOG_INF(AP_LOGSTR, "delete cfgap success");
    return MOS_OK;
    #endif
}

_INT Cfgap_Task_Stop()
{
    if(Cfgap_GetTaskMng()->ucRunFlag == 0)
    {
        if (Cfgap_GetTaskMng()->hThread){
            Mos_ThreadDelete(Cfgap_GetTaskMng()->hThread);
        }
        MOS_LOG_WARN(AP_LOGSTR, "Already Stop");
        return MOS_OK;
    }
    Cfgap_GetTaskMng()->ucRunFlag  = 0;
    // Mos_MsgQueueWake(Cfgap_GetTaskMng ()->hMsgQueue,MOS_TRUE);
    Mos_ThreadDelete(Cfgap_GetTaskMng ()->hThread);

    // 关闭socket
    if(g_iconnfd && Mos_SocketClose(g_iconnfd) == -1)
    {
        MOS_LOG_ERR(AP_LOGSTR, "Close socket fail error: %s(errno: %d)", strerror(errno), errno);
    }
    if(g_iListenfd && Mos_SocketClose(g_iListenfd) == -1)
    {
        MOS_LOG_ERR(AP_LOGSTR, "Close socket fail error: %s(errno: %d)", strerror(errno), errno);
    }

    MOS_LOG_INF(AP_LOGSTR, "cfgap task stop ok");
    return MOS_OK;
}

_INT Cfgap_Task_Destroy()
{
    if(Cfgap_GetTaskMng ()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(AP_LOGSTR, "Already Destroy");
        return MOS_OK;
    }

    ST_AP_ONLINESTATUS_MSG *pstApMsg = NULL;
    while((pstApMsg = Mos_MsgQueuePop(Cfgap_GetTaskMng()->hMsgQueue)) != MOS_NULL)
    {
        MOS_FREE(pstApMsg);
    }
    Mos_MsgQueueDelete(Cfgap_GetTaskMng ()->hMsgQueue);
    Cfgap_GetTaskMng()->ucInitFlag = 0;
    MOS_MEMSET(&g_stCdgApMng , 0, sizeof(g_stCdgApMng ));
    MOS_LOG_INF(AP_LOGSTR, "cfgap task Destroy ok ");
    return MOS_OK;
}

// 发送数据到AP热点客户端
_INT AP_SendDataToApClient(_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen)
{
    _INT iRet          =  0;
    _UI  uiHeadlen     =  sizeof(ST_OGCT_PROTOCAL_HEAD);
    _UI  uiDataLenEx   =  MOS_HEX_NUM(uiDatalen);
    ST_OGCT_PROTOCAL_HEAD *pstOgctHead  = (ST_OGCT_PROTOCAL_HEAD *)MOS_MALLOC(uiHeadlen);

    // 设备回复的数据 包头加加密后的接送数据
    _INT iOutputBufLen =  0;
    _UC  *pucOutputBuf =  (_UC *)MOS_MALLOC(uiHeadlen + uiDataLenEx + 1);

    Http_EncMsgHead(pstOgctHead, ucMsgType, ucMsgId, uiDataLenEx, 0x00);
 
    MOS_MEMCPY(pucOutputBuf, pstOgctHead, uiHeadlen);
    MOS_MEMCPY(pucOutputBuf + uiHeadlen, pucData, uiDataLenEx);
    iOutputBufLen = uiHeadlen + uiDataLenEx;

    BUF_PRINTF_EX("APRecvData", pucOutputBuf, iOutputBufLen);

    iRet = send(g_iconnfd, (char *)pucOutputBuf, iOutputBufLen, 0);
    if (iRet < 0)
    {
        MOS_LOG_ERR(AP_LOGSTR, "cfgap send error iRet:%d  error: %s(errno: %d)", iRet, strerror(errno), errno);
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
    }
    else
    {
        MOS_LOG_INF(AP_LOGSTR, "cfgap send OK SendLen:%d", iRet);
    }
    
    MOS_FREE(pstOgctHead);
    MOS_FREE(pucOutputBuf);

    return iOutputBufLen;
}
