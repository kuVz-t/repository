#ifndef _CONFIG_AP_H
#define _CONFIG_AP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"

#define AP_LOGSTR              (_UC*)"AP"
#define CONFIG_AP_PORT          8008
#define SOCKET_RECV_MAX_BUFLEN  4096

typedef struct stru_CFGAP_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _UC             ucRsv[2];
    _HTHREAD        hThread;
    _HQUEUE         hMsgQueue;
    _UI             uiFormatFlag;
}ST_CFGAP_MNG;

typedef struct str_AP_ONLINESTATUS_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UI uiOnlineStatus;
}ST_AP_ONLINESTATUS_MSG;

ST_CFGAP_MNG *Cfgap_GetTaskMng();

_INT Cfgap_Task_Init();

_INT Cfgap_Task_Start();

_INT Cfgap_Task_Stop();

_INT Cfgap_Task_Destroy();

_INT Cfgap_Task_SendDataToApClient(_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen);

// 发送数据到AP热点客户端
_INT AP_SendDataToApClient(_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen);

#ifdef __cplusplus
}
#endif
#endif