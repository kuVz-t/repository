#ifndef _CONFIG_AUTO_CONN_H
#define _CONFIG_AUTO_CONN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"

#define AUTO_CONN_LOGSTR    (_UC*)"AC"


typedef struct stru_AUTO_CONN_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _UC             ucRsv[2];
    _HTHREAD        hThread;
    _HQUEUE         hMsgQueque;
    _UI             uiFormatFlag;
}ST_AUTO_CONN_MNG;

ST_AUTO_CONN_MNG *AutoConn_GetTaskMng();

_INT AutoConn_Task_Init();

_INT AutoConn_Task_Start();

_INT AutoConn_Task_Stop();

_INT AutoConn_Task_Destroy();

_INT AutoConn_SetNormalWifi_Status();

#ifdef __cplusplus
}
#endif
#endif