#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_type.h"
#include "media_cache_api.h"
#include "media_type_prv.h"
#include "media_api.h"
#include "http_api.h"
#include "msgmng_multimedia.h"

#define MSGMNG_MEDIA_TASK_LOG_STR   "MSG_MEDIA_MODULE"

static ST_MEDIA_TASKMNG  g_stMediaTaskMng;
/*******************************************************************************************************
                                       局部函数声明
********************************************************************************************************/
//static _INT Media_NtyPlayStatus(_UC* pucPeerID, _UI uiSessionID,_UI uiOption,_INT iOptCode);

/*******************************************************************************************************
                                        全局函数实现区间
********************************************************************************************************/
ST_MEDIA_TASKMNG * Media_GetTaskMng()
{
    return &g_stMediaTaskMng;
}

// 流媒体转发初始化
_INT Media_Task_Init()
{
    if (Media_GetTaskMng()->uiInitFlag == 1)
    {
        MOS_LOG_WARN(MS_TASKLOGSTR, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stMediaTaskMng,0,sizeof(ST_MEDIA_TASKMNG));
    Mos_MutexCreate(&Media_GetTaskMng()->hMutex);
    Media_GetTaskMng()->uiMdStatus = EN_MD_LOOP_NONE;
    Media_GetTaskMng()->uiInitFlag = 1;
    MOS_LOG_INF(MS_TASKLOGSTR,"Media init task ok");

    // 设置播放流通知CB
    //Http_SetPlayStreamNoticeCB(Media_NtyPlayStatus);
    return MOS_OK;
}

// 流媒体转发销毁
_INT Media_Task_Destroy()
{
    if (Media_GetTaskMng()->uiInitFlag == 0)
    {
        MOS_LOG_WARN(MS_TASKLOGSTR, "Already Destroy");
        return MOS_OK;
    }
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MEDIA_BUSSNODE *pstBussNode= MOS_NULL;

#if 0
    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stBussList,pstBussNode,stIterator)
    {
        if(pstBussNode->hAudioRead)
        {
            Media_AudioPlayDestroyReadHandle(pstBussNode->hAudioRead);
            pstBussNode->hAudioRead = MOS_NULL;
        }
        if(pstBussNode->hVideoRead)
        {
            Media_VideoPlayDestroyReadHandle(pstBussNode->hVideoRead);
            pstBussNode->hVideoRead = MOS_NULL;
        }
        MOS_LIST_RMVNODE(&Media_GetTaskMng()->stBussList, pstBussNode);
        MOS_FREE(pstBussNode);
    }
    Mos_MutexDelete(&Media_GetTaskMng()->hMutex);
#endif
    Mos_MutexDelete(&Media_GetTaskMng()->hMutex);
    MOS_LIST_RMVALL(&Media_GetTaskMng()->stActiveFunList, MOS_TRUE);
    MOS_LIST_RMVALL(&Media_GetTaskMng()->stRspList, MOS_TRUE);
    Media_GetTaskMng()->uiInitFlag = 0;
    MOS_LOG_INF(MS_TASKLOGSTR,"media Task destroy ok");
    return MOS_OK;
}

// 流媒体转发线程
_INT Media_Task_Start()
{
    if (Media_GetTaskMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(MS_TASKLOGSTR, "Already Start");
        return MOS_OK;
    }
    _INT iRet = 0;
    ZJ_LOG_INF("md task start \n");
    Media_GetTaskMng()->ucRunFlag = 1;
    // if(-1 == (iRet = Mos_ThreadCreate((_UC *)"MD_MODULE", EN_THREAD_PRIORITY_NORMAL, MOS_THREAD_STACK_NORMAL_SIZE,
    //     MsgMng_MultiMediaLoopProc, MOS_NULL, MOS_NULL, &Media_GetTaskMng()->hMgrThread)))
    // {
    //     Media_GetTaskMng()->ucRunFlag = 0;
    //     ZJ_LOG_INF("md task create pthread failed\n");
    //     return -1;
    // }
    return 0;
}
// 停止流媒体转发线程
_INT Media_Task_Stop()
{
    if(Media_GetTaskMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(MS_TASKLOGSTR, "Already Stop");
        return MOS_OK;
    }
    Media_GetTaskMng()->ucRunFlag = 0;
    // Mos_ThreadDelete(Media_GetTaskMng()->hMgrThread);
    MOS_LOG_INF(MS_TASKLOGSTR,"md task stop ok");
    return 0;
}
#if USER_MEDIA_MODULE
// 分配Buss节点
ST_MEDIA_BUSSNODE *Media_AllocBussNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MEDIA_BUSSNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stBussList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 0)
        {
            break;
        }
    }
    if(pstBussNode == MOS_NULL)
    {
        pstBussNode = (ST_MEDIA_BUSSNODE*)MOS_MALLOCCLR(sizeof(ST_MEDIA_BUSSNODE));
        if(pstBussNode == MOS_NULL)
        {
            return MOS_NULL;
        }
        MOS_LIST_ADDTAIL(&Media_GetTaskMng()->stBussList, pstBussNode);
    }
    pstBussNode->uiBussType = EN_MD_BUSS_UNKNOWN;
    pstBussNode->enStatus   = EN_MEDIA_PLAY_INIT;
    pstBussNode->uiPlayId   = ++Media_GetTaskMng()->uiPlayId;
    pstBussNode->uiUseFlag  = 1;
    return pstBussNode;
}

// 通过ID找到Buss节点
ST_MEDIA_BUSSNODE *Media_FindBussNodeByPlayId(_UI uiPlayId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MEDIA_BUSSNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stBussList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 && pstBussNode->uiPlayId == uiPlayId)
        {
            break;
        }
    }
    return pstBussNode;
}

// 通过SessionId找到Buss节点
ST_MEDIA_BUSSNODE *Media_FindBussNodeBySessionId(_UC *pucPeerId,_UI uiSessionId)
{
    MOS_PARAM_NULL_RETNULL(pucPeerId);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_MEDIA_BUSSNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stBussList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 && pstBussNode->uiSessionID == uiSessionId
            && MOS_STRCMP(pucPeerId, pstBussNode->aucPeerId) == 0)
        {
            break;
        }
    }
    return pstBussNode;
}

// 通过PeerId找到Buss节点
ST_MEDIA_BUSSNODE *Media_GetRsvBussNodeByPeerId(_UC *pucPeerId)
{
    MOS_PARAM_NULL_RETNULL(pucPeerId);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_MEDIA_BUSSNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stBussList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 && pstBussNode->uiBussType == EN_MD_BUSS_RSVALIVE 
            && MOS_STRCMP(pstBussNode->aucPeerId, pucPeerId) == 0 )
        {
            break;
        }
    }
    return pstBussNode;
}

// 获取当前流数量
_INT Media_GetNormalSessionNum()
{
    return Media_GetTaskMng()->uiAliveCnt;
}

// 创建实时流
_UI Media_CreatAliveStream(_UC *pucPeerId,_INT iCamid,_INT iStreamid,_INT iMicId)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);

    ST_MEDIA_BUSSNODE *pstBussNode = MOS_NULL;
    Mos_MutexLock(&Media_GetTaskMng()->hMutex);
    pstBussNode = Media_AllocBussNode();
    if(pstBussNode == MOS_NULL)
    {
        Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
        return 0;
    }
    pstBussNode->uiSessionID = Http_CreateLiveStream(pucPeerId,iCamid,iStreamid,iMicId);
    if(pstBussNode->uiSessionID == 0)
    {
        pstBussNode->uiUseFlag = 0;
        Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
        return 0;
    }
    pstBussNode->enStatus = EN_MEDIA_PLAY_CREAT;
    MOS_STRNCPY(pstBussNode->aucPeerId, pucPeerId,sizeof(pstBussNode->aucPeerId));
    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
    MOS_LOG_INF(MS_TASKLOGSTR,"creat alive stream cam [%u %u] playid %u sessionid %u",
        iCamid,iStreamid,pstBussNode->uiSessionID,pstBussNode->uiPlayId);
    return pstBussNode->uiPlayId;
}

// 获取流和音频信息
_INT Media_GetSessionStreamInf(_UC *pucPeerID,_UI uiPlayId,_INT *piCamId,_INT *piStreamId,_INT *piMicId)
{
    ST_MEDIA_BUSSNODE *pstBussNode =  Media_FindBussNodeByPlayId(uiPlayId);
    if(pstBussNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    return Http_GetPlayStreamAndMicInf(pucPeerID,pstBussNode->uiSessionID,piCamId,piStreamId,piMicId);
}

// 获取video帧
_INT Media_GetVideoFrame(_UI uiPlayId,_OUT _UC **ppucStream,_OUT _UI *puiFrameType, _OUT _UI *puiTimeStamp,_OUT _UI *puiFrmCnt)
{
    ST_MEDIA_BUSSNODE *pstBussNode = Media_FindBussNodeByPlayId(uiPlayId);
    if(pstBussNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstBussNode->enStatus != EN_MEDIA_PLAY_RUN)
    {
        return MOS_OK;
    }
    return Media_VideoPlayReadFrame(pstBussNode->hVideoRead,ppucStream,puiFrameType,puiTimeStamp,puiFrmCnt);
}

// 获取音频帧
_INT Media_GetAudioFrame(_UI uiPlayId,_OUT _UC **ppucStream, _OUT _UI *puiTimeStamp,_OUT _UI *puiFrmCnt)
{
    ST_MEDIA_BUSSNODE *pstBussNode = Media_FindBussNodeByPlayId(uiPlayId);
    if(pstBussNode == MOS_NULL )
    {
        return MOS_ERR;
    }
    if(pstBussNode->enStatus != EN_MEDIA_PLAY_RUN)
    {
        return MOS_OK;
    }
    return Media_AudioPlayReadFrame(pstBussNode->hAudioRead,ppucStream,puiTimeStamp,puiFrmCnt);
}

// 获取视频描述
_INT Media_GetVideoDescribe(_UI uiPlayId,_UI *puiLensType,ST_ZJ_VIDEO_PARAM *pstVideoParm,ST_ZJ_VIDEO_CIRCLE *pstVideoCircle)
{
    ST_MEDIA_BUSSNODE *pstBussNode = Media_FindBussNodeByPlayId(uiPlayId);
    
    if(pstBussNode == MOS_NULL || pstBussNode->hVideoRead== MOS_NULL)
    {
        return MOS_ERR;
    }
    return Media_VideoPlayGetStreamInfo(pstBussNode->hVideoRead,puiLensType,pstVideoParm,pstVideoCircle);
}

// 获取音频描述
_INT Media_GetAudioDescribe(_UI uiPlayId,ST_ZJ_AUDIO_PARAM *pstAudioDes)
{
    ST_MEDIA_BUSSNODE *pstBussNode = Media_FindBussNodeByPlayId(uiPlayId);
    if(pstBussNode == MOS_NULL || pstBussNode->hAudioRead == MOS_NULL || pstAudioDes == MOS_NULL)
    {
        return MOS_ERR;
    }
    return Media_AudioPlayGetStreamInfo(pstBussNode->hAudioRead,pstAudioDes);
}

// 暂停播放
_INT Media_PausePlay(_UI uiPlayId,_UI uiAvFlag)
{
    ST_MEDIA_BUSSNODE *pstBussNode = Media_FindBussNodeByPlayId(uiPlayId);
    if(pstBussNode == MOS_NULL || pstBussNode->enStatus != EN_MEDIA_PLAY_RUN)
    {
        return MOS_ERR;
    }
    return Http_PausePlay(pstBussNode->aucPeerId,pstBussNode->uiSessionID,uiAvFlag);
}

// 回复播放
_INT Media_ResumePlay(_UI uiPlayId,_UI uiAvFlag)
{
    ST_MEDIA_BUSSNODE *pstBussNode = Media_FindBussNodeByPlayId(uiPlayId);
    if(pstBussNode == MOS_NULL || pstBussNode->enStatus != EN_MEDIA_PLAY_RUN)
    {
        return MOS_ERR;
    }
    return Http_ResumePlay(pstBussNode->aucPeerId,pstBussNode->uiSessionID,uiAvFlag);
}

// 停止播放
_INT Media_StopPlay(_UI uiPlayId)
{
    ST_MEDIA_BUSSNODE *pstBussNode = Media_FindBussNodeByPlayId(uiPlayId);
    if(pstBussNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstBussNode->enStatus = EN_MEDIA_PLAY_STOP;
    if(pstBussNode->hAudioRead)
    {
        Media_AudioPlayDestroyReadHandle(pstBussNode->hAudioRead);
        pstBussNode->hAudioRead = MOS_NULL;
    }
    if(pstBussNode->hVideoRead)
    {
        Media_VideoPlayDestroyReadHandle(pstBussNode->hVideoRead);
        pstBussNode->hVideoRead = MOS_NULL;
    }
    pstBussNode->uiUseFlag = 0;
    return Http_StopPlay(pstBussNode->aucPeerId,pstBussNode->uiSessionID);
}

/*******************************************************************************************
typedef enum enum_HTTP_STREAM_MEDIA_TYPE{
    EN_HTTP_STREAM_MEDIA_TYPE_INIT          = 0, // NOT SET
    EN_HTTP_STREAM_MEDIA_TYPE_LIVEPLAY      = 1, // 实时点播流
    EN_HTTP_STREAM_MEDIA_TYPE_RECORD        = 2, // 录制点播流
    EN_HTTP_STREAM_MEDIA_TYPE_PICTURE       = 3, // 图片请求流
    EN_HTTP_STREAM_MEDIA_TYPE_LOGFILE       = 4, // 日志文件请求流
    EN_HTTP_STREAM_MEDIA_TYPE_LIVEPUSH      = 5, // 逆向推送流
    EN_HTTP_STREAM_MEDIA_TYPE_SOUNDFILE     = 6  // 声音文件流
}EN_HTTP_STREAM_MEDIA_TYPE;

uiStreamType: 0.SEND;1.RECV
********************************************************************************************/
// 流媒体播放状态
static _INT Media_NtyPlayStatus(_UC* pucPeerID, _UI uiSessionID,_UI uiOption,_INT iOptCode)
{
    MOS_PARAM_NULL_RETERR(pucPeerID);

    _UI uiStreamType = 0,uiMeidaType = 0;
    ST_MEDIA_BUSSNODE *pstBussNode = MOS_NULL;
    
    // 获取流类型
    Http_GetPlayStreamType(pucPeerID,uiSessionID,&uiMeidaType,&uiStreamType);
    // 逆向流
    if(EN_HTTP_STREAM_EVENT_OPTION_CREATE_REQ == uiOption && iOptCode == MOS_OK && uiStreamType == 1)
    {
        pstBussNode = Media_GetRsvBussNodeByPeerId(pucPeerID);
        if(pstBussNode && pstBussNode->hVideoRead == MOS_NULL && ZJ_GetFuncTable()->pfunMediaToPlay)
        {
            // 通知厂商 逆向语音流关闭
            ZJ_GetFuncTable()->pfunMediaToPlay(pstBussNode->aucPeerId,(_VPTR)pstBussNode->uiPlayId,EN_ZJ_MEDIA_AUDIO,0);
            Media_StopPlay(pstBussNode->uiPlayId);
        }
        pstBussNode = Media_AllocBussNode();
        pstBussNode->uiSessionID = uiSessionID;
        pstBussNode->uiBussType  = EN_MD_BUSS_RSVALIVE;
        MOS_STRNCPY(pstBussNode->aucPeerId, pucPeerID,sizeof(pstBussNode->aucPeerId));
    }
     // 实时视频 或者 录像点播
    else if((uiMeidaType == 1 || uiMeidaType == 2) && uiStreamType == 0)
    {
        if(EN_HTTP_STREAM_EVENT_OPTION_CREATE_REQ == uiOption)
        {
            if(Media_GetTaskMng()->uiAliveCnt >= Config_GetDeviceMng()->uiMaxSessionCnt)
            {
                return MOS_ERR_FULL;
            }
            Media_GetTaskMng()->uiAliveCnt++;
            pstBussNode = Media_AllocBussNode();
            pstBussNode->uiSessionID = uiSessionID;
            pstBussNode->uiBussType  = uiMeidaType;
            MOS_STRNCPY(pstBussNode->aucPeerId, pucPeerID,sizeof(pstBussNode->aucPeerId));
        }
        else
        {
            pstBussNode = Media_FindBussNodeBySessionId(pucPeerID,uiSessionID);
            if(pstBussNode != MOS_NULL)
            {
                if(Media_GetTaskMng()->uiAliveCnt > 0)
                {
                    Media_GetTaskMng()->uiAliveCnt--;
                }
                pstBussNode->aucPeerId[0] = 0;
                pstBussNode->uiSessionID  = 0;
                pstBussNode->uiUseFlag    = 0;
            }
        }
        if(Media_GetTaskMng()->uiAliveCnt == 0 && Config_GetCamaraMng()->stSensors.usAutoFlag == 1
            && Config_GetCamaraMng()->stSensors.usDefaultLenId != Config_GetCamaraMng()->stSensors.usCurLenId)
        {
            if(ZJ_GetFuncTable()->pfunSwitchLen)
            {
                ZJ_GetFuncTable()->pfunSwitchLen(Config_GetCamaraMng()->stSensors.usDefaultLenId);
            }
            Config_SetEnableLenId(Config_GetCamaraMng()->stSensors.usDefaultLenId);
        }
        MOS_LOG_INF(MS_TASKLOGSTR,"alive session cnt %u",Media_GetTaskMng()->uiAliveCnt);
        return MOS_OK;
    }
    else
    {
        pstBussNode = Media_FindBussNodeBySessionId(pucPeerID,uiSessionID);
    }
     
    if(pstBussNode == MOS_NULL)
    {
        MOS_LOG_INF(MS_TASKLOGSTR,"can't find sessionid %u peerid %s",uiSessionID,pucPeerID);
        return MOS_OK;
    }
    
    if((uiOption == EN_HTTP_STREAM_EVENT_OPTION_CREATE_RSP || uiOption == EN_HTTP_STREAM_EVENT_OPTION_CREATE_REQ)
        && iOptCode == MOS_OK)
    {
        pstBussNode->hVideoRead = Media_VideoPlayCreatReadHandle(pstBussNode->aucPeerId,uiSessionID);
        pstBussNode->hAudioRead = Media_AudioPlayCreatReadHandle(pstBussNode->aucPeerId,uiSessionID);
        pstBussNode->enStatus   = EN_MEDIA_PLAY_RUN;
        MOS_LOG_INF(MS_TASKLOGSTR, "SessionID %u creat video handle %p audio handle %p ",
                    uiSessionID,pstBussNode->hVideoRead,pstBussNode->hAudioRead);
    }
    else
    {
        MOS_LOG_INF(MS_TASKLOGSTR,"SessionID %u peerid %s close",uiSessionID,pucPeerID);
    }
    
    if(ZJ_GetFuncTable()->pfunMediaToPlay)
    {
        MOS_LOG_INF(MS_TASKLOGSTR,"SessionID %u recv option %d",pstBussNode->uiPlayId,uiOption);
        if(uiStreamType == 1)
        {
            if(EN_HTTP_STREAM_EVENT_OPTION_CREATE_REQ == uiOption)
            {
                ZJ_GetFuncTable()->pfunMediaToPlay(pstBussNode->aucPeerId,(_VPTR)pstBussNode->uiPlayId,EN_ZJ_MEDIA_AUDIO,1);
            }
            else
            {
                ZJ_GetFuncTable()->pfunMediaToPlay(pstBussNode->aucPeerId,(_VPTR)pstBussNode->uiPlayId,EN_ZJ_MEDIA_AUDIO,0);
                Media_StopPlay(pstBussNode->uiPlayId);
            }
        }
    }
    return MOS_OK;
}
#endif
