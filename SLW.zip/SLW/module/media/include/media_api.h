#ifndef _MEDIA_API_H
#define _MEDIA_API_H
/***************************************************************************************************************
1 media server 和 media client 公用 两个线程  ， 发送和接受 线程 
        接收线程 不仅处理 avs的 数据 也处理 亚马逊上的数据 

2 ms 单独一个任务  处理 录像 相关的 

3 mc 单独一个任务  处理查询下载，客户端手动录像等任务(包括 云 播放 和云下载 等 功能， 云录像查询 等 ) 
         录像 列表信息  客户端缓存 ， 然后 和avs 对比  天的信息  ， 如果不存在 则删除 
****************************************************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************************************************
*******************************************************************************************************************/
_INT Media_Task_Init();
_INT Media_Task_Start();
_INT Media_Task_Stop();
_INT Media_Task_Destroy();

#if USER_MEDIA_MODULE
_INT Media_GetNormalSessionNum();

/**********************************************************************************************************************
                                                    音视频点播
***********************************************************************************************************************/
_UI  Media_CreatAliveStream(_UC *pucPeerId,_INT iCamid,_INT istreamid,_INT iMicId);
_INT Media_GetVideoFrame(_UI uiPlayId,_OUT _UC **ppucStream,_OUT _UI *puiFrameType, _OUT _UI *puiTimeStamp,_OUT _UI *puiFrmCnt);
_INT Media_GetAudioFrame(_UI uiPlayId,_OUT _UC **ppucStream, _OUT _UI *puiTimeStamp,_OUT _UI *puiFrmCnt);

_INT Media_GetVideoDescribe(_UI uiPlayId,_UI *puiLensType,ST_ZJ_VIDEO_PARAM *pstVideoParm,ST_ZJ_VIDEO_CIRCLE *pstVideoCircle);
_INT Media_GetAudioDescribe(_UI uiPlayId,ST_ZJ_AUDIO_PARAM *pstAudioParm);
_INT Media_PausePlay(_UI uiPlayId,_UI uiAvFlag);
_INT Media_ResumePlay(_UI uiPlayId,_UI uiAvFlag);
_INT Media_StopPlay(_UI uiPlayId);

_INT Media_GetSessionStreamInf(_UC *pucPeerID,_UI uiPlayId,_INT *piCamId,_INT *piStreamId,_INT *piMicId);
#endif

#ifdef __cplusplus
}
#endif

#endif

