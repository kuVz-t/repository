#ifndef _MEDIA_TYPE_PRV_H
#define _MEDIA_TYPE_PRV_H

#ifdef __cplusplus
extern "C" {
#endif

#include "http_api.h"
#include "media_audioplay.h"
#include "media_audio.h"
#include "media_video.h"
#include "kj_pollfd.h"
#include "kj_timer.h"
#include "record_api.h"

#define MS_TASKLOGSTR   (_UC*)"MD"
#define MSGMNG_MULTI_MEDIA_LIVE_CONNECT_MAX_COUNT       3      //直播流媒体连接最大数
#define MSGMNG_MULTI_MEDIA_PLAYBACK_CONNECT_MAX_COUNT   6      //卡回放流媒体连接最大数

typedef _INT (*PFUN_NTYSESSIONSTATUS)(_UC* pucPeerDid,_UI uiSessionID,_UI uiOption,_INT iOptCode);

typedef enum EN_MEDIA_MSG_TYPE
{
    EN_MEDIA_MSG_MOTION_AREA = 1,
        
}EN_MEDIA_MSG_TYPE;


typedef enum EN_MEDIA_PLAYSTATUS
{
    EN_MEDIA_PLAY_INIT      = 0,
    EN_MEDIA_PLAY_CREAT     = 1,
    EN_MEDIA_PLAY_RUN       = 2,
    EN_MEDIA_PLAY_STOP      = 3
}EN_MEDIA_PLAYSTATUS;

typedef enum enum_MD_BUSS_TYPE
{
    EN_MD_BUSS_UNKNOWN      = 0,
    EN_MD_BUSS_ALIVE        = 1,   // 实时流
    EN_MD_BUSS_RECORD       = 2,   // 录像
    EN_MD_BUSS_RSVALIVE     = 3    // 逆向语音
}EN_MD_BUSS_TYPE;

typedef enum EN_MD_LOOP_STATUS
{
    EN_MD_LOOP_NONE       = -1,     // DEFAULT
    EN_MD_LOOP_INIT       = 0,      // 初始化
    EN_MD_LOOP_LOGIN      = 1,      // 登录
    EN_MD_LOOP_LOGIN_RSP  = 2,      // 登录回复
    EN_MD_LOOP_STREAM     = 3,      // 取流，组包
    EN_MD_LOOP_SEND       = 4,      // 发送
    EN_MD_LOOP_DEINIT     = 5       // 反初始化
}EN_MD_LOOP_STATUS;


typedef enum enum_MSGMNG_MULTI_MEDIA_STREAM_STATUS{
    EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_NONE  = 0,
    EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_START,
    EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_PAUSE,
    EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_RESUME,
    EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_CLOSE,
}EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS;

typedef struct ST_MULTI_MEDIA_LOGIN_INF{
    _UC pucPeerId[16];
    _UI uiSeqId;
}ST_MULTI_MEDIA_LOGIN_INF;

typedef enum enum_MSGMNG_MULTI_MEDIA_TYPE{
    EN_MSGMNG_MULTI_MEDIA_LIVE      = 0,
    EN_MSGMNG_MULTI_MEDIA_PLAYBACK,
}EN_MSGMNG_MULTI_MEDIA_TYPE;
typedef struct ST_PLAYBACK_FRAME_NODE
{
    _UI  uiTimeStamp;           // 时间戳
    ST_FRAME_NODE stNote;
    struct ST_PLAYBACK_FRAME_NODE *pstnext;
}ST_PLAYBACK_FRAME_NODE;
// #define SEND_DATA_DEBUG
typedef struct ST_MSGMNG_MULTI_MEDIA{
    ST_MOS_INET_IP      stInetIPv4;         // 信令服务器IP 端口 IP类型
    ST_MOS_INET_IP      stInetIPv6;         // 信令服务器IP 端口 IP类型
    _UI                 uiConnectType;      // connect type
    _BOOL               bRollbackToIPv4;    // v6回落v4的状态值 0 保持当前状态 1 回落 
    _UI                 uiConnectFlag;	    // 流媒体服务器连接标志 0. Not Connect; 1. Connecting; 2. Connnected. 3.Connect Err.
    _UI                 uiType;             // 类型-EN_MSGMNG_MULTI_MEDIA_TYPE
    _US                 usPort;             // 信令服务器端口
    _UI                 uiIp;               // 信令服务器IP地址
    _UI                 uiIpType;           // 信令服务器IP类型
    _UC                 pucResourceID[33];  // 资源ID
    _INT                iNeedIframe[2];     // 需要I帧标志
    _UI                 uiVideoSeq[2];      // 视频数据网络字节序，报文打包序列号。用来判断丢包和乱序。
    _UI                 uiAudioSeq[2];      // 音频数据网络字节序
    _INT                iStatusCountDown;   // 状态机倒计时，单位毫秒; 0.执行状态逻辑
    _UC                 aucDevUID[CFG_STRING_LEN];// 设备uid
    _UI                 uiMark;             // 标记，用于打印区分多路流
    _UC                 aucMaskName[32];    // 标记名称
    _UI                 uiSleepMonitorId;   // 休眠监听id
    _VOID *             hMgrThread;         // 线程句柄-多线程版本

    _UC                 aucOutFrameFlag[32];// 出帧打印标志,可通过MSGMNG_MULTIPATH_DEBUG_OUTFRAME打开出帧功能
    _UC                 ucOutFramePrintfIF; // 出帧打印I帧标记
    kj_timer_t          stOutFrameTimer;    // 出帧定时
    
    _UC                 ucStatus;           // 信令服务器状态
    _UC                 ucConnectFlag;      // 0. Not Connect; 1. Connecting; 2. Connnected. 3.Connect Err.
    _UC                 ucLoginFlag;        // 0. Not login;   1.logining;2.logined.3.login err.    
    _UI                 uiHeartInterval;    // 心跳间隔-毫秒
    
    _UC                 ucConnFailCount;    // 连接失败数
    _UC                 ucSendDataFailCount;// 发送数据失败次数 
    _UC                 ucRunFlag;          // run flag

    _UC                 ucBeOccupyFlag;     // 被抢占标志
    _UC                 ucResetFlag;        // 重置设备标识
    _UI                 uiReqID;            // 请求ID
    _ULLID              ullTimeReq;         // 请求时间 tick
    _ULLID              ullReiveAudioTime;  //对端对讲数据接收时间
    // _CTIME_T            timeReq;        // 请求时间 秒
    _SOCKET             isockFd;            // socket id
    _HMUTEX             hMutexSendB;        // 发送数据的互斥锁

    _UI                 uiPayloadLen;       // 有效数据长度
    _HSOCKBUFF          hSockBuffPool;      // 
    ST_MOS_SOCKBUF*     pstSendB;           // 发送到信令服务器的json数据
    ST_MOS_SOCKBUF*     pstRecvB;           // 接收到信令服务器的json数据
    ST_HTTP_ENCRYPTO_INF stPlatEncryInf;
    ST_HTTP_ENCRYPTO_INF stEncrypInf;

    _US                 m_sAudioSpeakChn;
    _BOOL               m_bEnableAudio;
    _BOOL               m_bEnableSpeaker;
    _HAUDIOPLAY         m_hAudioPlay;    


    ST_MULTI_MEDIA_LOGIN_INF stLoginInfo;   // 请求登录信息

    _INT                iLastVideoUsedFlag[2];
    _HVIDEOREAD         m_hVideoHandel[2];
    _HAUDIOREAD         m_hAudioHandel[2];
    _HMUTEX             hMutexStatus;        // setting status 互斥锁
    EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS ucStreamStatus[2];     // 流状态, 0: 主码流 1：次码流

    struct pollfd       stPollFd;           // 当前线程poll监听句柄

    _US                 usChannel;          // 卡回放通道
    _UC                 ucPBDownFlag;       // 卡回放下载标志位
    _UI                 uiPBMode;           // 卡回放模式 0-单文件播放 1-下载连续播放
    _UC                 ucPBPlayStatus;     // 卡回放播放状态
    _UC                 aucPBSessionId[64]; // 卡回放回话ID
    _UC                 aucPBClinetToken[128];// 卡回放客户端token
    _UC                 aucPBFilePath[128]; // 卡回放录像文件名称
    _RDFILEFD *         pstPBRdFileFD;      // 卡回放录像文件句柄

    _UI                 uiPBFileEndFlag;    // 卡回放文件结束标志
    kj_timer_t          stPBSendTimer;      // 卡回放定时器 - 用于播放时序
    _UI                 uiPBPauseTimeStamp; // 卡回放暂停的时间戳
    ST_PLAYBACK_FRAME_NODE* pstPBVFrameHead;// 卡回放视频帧列表头
    ST_PLAYBACK_FRAME_NODE* pstPBAFrameHead;// 卡回放音频帧列表头
    _UI                 uiPBVFrameCnt;      // 卡回放视频帧数量
    _UI                 uiPBAFrameCnt;      // 卡回放音频帧数量
    _UI                 uiPBNextVSendTimeStamp;//卡回放视频帧下一帧发送时间戳-毫秒
    _UI                 uiPBNextASendTimeStamp;//卡回放音频帧下一帧发送时间戳-毫秒
    _UI                 uiPBLastVFrameTimeStamp;//卡回放最新一帧视频帧的真实时间戳
    _INT                iPBFastSendTimeStamp;   //卡回凯苏发送的时间
    _UC                 ucPBVideoSendFrameDone; //卡回放发送帧尾标志, 

    _UI                 uiTheardSleepMescond;//线程休眠时长
#ifdef SEND_DATA_DEBUG
    _VOID *             hFile;
#endif
}ST_MSGMNG_MULTI_MEDIA;

typedef struct stru_MSGMNG_MULTI_MEDIA_CMD_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UC  ucMsgType;
    _UC  ucMsgId;
    _UC  ucRsv[2];
    _INT iSeqNum;
    _UC aucMsgBody[0];
}ST_MSGMNG_MULTI_MEDIA_CMD_MSG;

typedef struct stru_MEDIA_BUSSNODE
{
    _UI uiUseFlag;                           // 0：未分配内存 1：分配内存
    _UI uiPlayId;                            // 流媒体管理ID
    _UI uiSessionID;                         // 流媒体通道ID
    _UI uiBussType;                          // 流媒体类型
     EN_MEDIA_PLAYSTATUS enStatus;           // 流媒体状态
    //_HVPLAYREAD hVideoRead;                  // video句柄
    _HAPLAYREAD hAudioRead;                  // audio句柄
    _UC aucPeerId[CFG_STRING_COMMONLEN +4];  // 假设：用户ID
    ST_MOS_LIST_NODE stNode;
}ST_MEDIA_BUSSNODE;

typedef struct stru_msgmng_multimedia_Connect_Node
{
    _UI uiType;     // 类型
    _UI uiTime;     // 创建时间
    ST_MSGMNG_MULTI_MEDIA *pstMultiMedia;
    ST_MOS_LIST_NODE stNode;
}ST_MSGMNG_MULTIMEDIA_CONNECT_NODE;

typedef struct stru_MEDIA_TASKMNG
{
    _UI uiInitFlag;
    _UI uiMaxCnt;
    _UI uiAliveCnt;
    _UI uiPlayId;
    _UI uiMdStatus;
    _UI ucNetChangFlag;

    _UC ucRunFlag;
    _HMUTEX hMutex;                         // 互斥体
    void *hMgrThread;                       // 线程
    ST_MOS_LIST stBussList;

    ST_MOS_LIST stActiveFunList;            // 注册的信令recv回调函数
    ST_MOS_LIST stRspList;                  // ST_MSGMNG_RSP_NODE

    ST_MOS_LIST stConnectList;              // 多媒体连接列表
    _UI uiConnectLiveCnt;                   // 直播链接数量
    _UI uiConnectPlayBackCnt;               // 卡回放连接数量

    _UI uiSleepMonitorId;                   // 休眠监控ID

    _UC aucIPv6Addr[CFG_STRING_LEN];        // 设备本地IPv6地址
}ST_MEDIA_TASKMNG;

ST_MEDIA_TASKMNG * Media_GetTaskMng();

ST_MEDIA_BUSSNODE *Media_AllocBussNode();

ST_MEDIA_BUSSNODE *Media_FindBussNodeByPlayId(_UI uiPlayId);

ST_MEDIA_BUSSNODE *Media_FindBussNodeBySessionId(_UC *pucPeerId,_UI uiSessionId);

#ifdef __cplusplus
}
#endif

#endif

