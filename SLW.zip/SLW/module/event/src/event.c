#include "mos.h"
#include "IoManage_api.h"
#include "zj_interface.h"
#include "config_api.h"
#include "event_api.h"
#include "event_prv.h"
#include "http_api.h"
#include "adpt_json_adapt.h"
#include "kjiot_device_api.h"
#include "msgmng_api.h"
#include "msgmng_event.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

static ST_EVENT_TASK_MNG g_EventTaskMng;

ST_EVENT_TASK_MNG *Event_GetMng()
{
    return &g_EventTaskMng;
}

//检查相关文件路径是否存在OK
_VOID Event_CheckDir()
{
    _UC aucSnapDir[256]={0};
    if(Event_GetMng()->iInitFlag == 0){
        return;
    }
    Mos_DirMake(Event_GetMng()->aucPathName,MOS_DIR_MAKE_FLAG);
    MOS_VSNPRINTF(aucSnapDir,256,"%s/%s",Event_GetMng()->aucPathName,EVENT_DIR);
    Mos_DirMake(aucSnapDir,MOS_DIR_MAKE_FLAG);

    Event_GetMng()->iChangePathFlag = 0;
    return;
}

//向EventDate文件中添加日期信息OK
_INT Event_AddDate(_UC *aucDay)
{
    MOS_PARAM_NULL_RETERR(aucDay);

    _HFILE hFile;
    _INT iRet  = 0;
    _INT iSize = sizeof(ST_EVENT_DATE);
    _UC aucVersion[20]={0};
    _UC aucFileName[256]={0};
    ST_EVENT_DATE stDateInf;

    if(MOS_STRLEN(Event_GetMng()->aucPathName)==0)
    {
        MOS_LOG_ERR(EVENT_LOG,"Event path err :%s",Event_GetMng()->aucPathName);
        return MOS_ERR;
    }
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s",Event_GetMng()->aucPathName,EVENT_DIR,EVENT_DATECFG_NAME);
    if(Mos_FileIsExist(aucFileName)==MOS_FALSE)
    {
        Mos_FileWriteAppend(aucFileName,(_UC*)EVENT_DATECFG_VERSION,MOS_STRLEN(EVENT_DATECFG_VERSION));
    }
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);

    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(EVENT_DATECFG_VERSION));
    
    if(MOS_STRCMP(aucVersion,EVENT_DATECFG_VERSION)){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(EVENT_LOG,"Event Date File Version error");
        return MOS_ERR;
    }
    
    while(Mos_FileEof(hFile) == MOS_FALSE)
    {
        iRet=Mos_FileRead(hFile,(_UC*)&stDateInf,iSize);
        if(iRet > 0 && iRet < iSize)
        {
            stDateInf.ucBInUse = ' ';
            stDateInf.ucCheck = '$';
            Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iRet);
            Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
            Mos_FileFlush(hFile);
            break;
        }
    }
    stDateInf.ucCheck = '$';
    stDateInf.ucBInUse = 1;
    if(MOS_STRCMP(aucDay,stDateInf.aucDate) == 0)
    {
        Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iSize);
        Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
    }
    else
    {
        MOS_STRNCPY(stDateInf.aucDate,aucDay,sizeof(stDateInf.aucDate));
        Mos_FileSeek(hFile,MOS_FILE_SEEK_END,0);
        Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
    }
    Mos_FileClose(hFile); 
    return MOS_OK;
}

//删除对应日期event记录信息
_INT Event_DeleteByDay(_UC *pucDay)
{
    MOS_PARAM_NULL_RETERR(pucDay);

    _INT iRet=0;
    _INT iSize=0;
    _HFILE hDateFile = MOS_NULL;
    _UC aucVersion[20]={0};
    _UC aucEventName[256]={0};
    ST_EVENT_DATE stTmpDate={0};

    MOS_VSNPRINTF(aucEventName,256,"%s/%s",Event_GetMng()->aucPathName,EVENT_DIR);
    iSize=sizeof(ST_EVENT_DATE);
    
    if(!Mos_DirIsExist(aucEventName))
        return MOS_OK;
    
    MOS_VSNPRINTF(aucEventName,256,"%s/%s/%s",Event_GetMng()->aucPathName,EVENT_DIR,EVENT_DATECFG_NAME);

    hDateFile=Mos_FileOpen(aucEventName,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hDateFile == MOS_NULL)
    {
        return MOS_OK;
    }
    Mos_FileRead(hDateFile,aucVersion,MOS_STRLEN(EVENT_DATECFG_VERSION));
    
    if(MOS_STRCMP(aucVersion,EVENT_DATECFG_VERSION)){
        Mos_FileClose(hDateFile);
        Mos_FileRmv(aucEventName);
        MOS_LOG_ERR(EVENT_LOG,"Event Date File Version error");
        return MOS_ERR;
    }

    while(!Mos_FileEof(hDateFile))
    {
        iRet=Mos_FileRead(hDateFile,(_UC*)&stTmpDate,iSize);
        if(iRet < iSize || stTmpDate.ucCheck != '$')
            break;

        if(stTmpDate.ucBInUse == 1 && MOS_STRNCMP(stTmpDate.aucDate,pucDay,12)==0)
        {
            MOS_VSNPRINTF(aucEventName,256,"%s/%s/%s%s",Event_GetMng()->aucPathName,EVENT_DIR,stTmpDate.aucDate,EVENT_FILEDES_NAME);
            if(Mos_FileIsExist(aucEventName))
                Mos_FileRmv(aucEventName);
            stTmpDate.ucBInUse=' ';
            Mos_FileSeek(hDateFile,MOS_FILE_SEEK_CUR,-iSize);
            Mos_FileWrite(hDateFile,(_UC*)&stTmpDate,iSize);
            break;
        }
    }
    Mos_FileClose(hDateFile);
    MOS_LOG_INF(EVENT_LOG,"delete event OK,Date %s",pucDay);
    return MOS_OK;
}

//删除对应信息记录
_INT Event_DeleteOnlyOne(_UC *pucTime,_UI uiKjIoTType,_LLID uillKjIoTId,_UI uiKjIoTEventId)
{
    MOS_PARAM_NULL_RETERR(pucTime);

    _HFILE hFile;
    _INT iRet=0,iSize=0;
    _UC aucVersion[20]={0};
    _UC aucFileName[256];
    _CTIME_T cNowTime;
    ST_MOS_SYS_TIME stSysTime={0};
    ST_EVENT_INF stEventInf;

    iSize=sizeof(stEventInf);
    MOS_MEMSET(&stEventInf,0,iSize);
    Mos_GetSysTime(&stSysTime);
    MOS_SSCANF(pucTime,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",&stSysTime.usYear,&stSysTime.usMonth,
        &stSysTime.usDay,&stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
    cNowTime=Mos_SysTimetoTime(&stSysTime);

    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%04u-%02u-%02u%s",Event_GetMng()->aucPathName,EVENT_DIR,
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,EVENT_FILEDES_NAME);
    
    hFile=Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
    if(hFile == MOS_NULL)
    {
        return MOS_OK;
    }
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(EVENT_FILEDESCFG_VERSION));
    if(MOS_STRCMP(aucVersion,EVENT_FILEDESCFG_VERSION)){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(EVENT_LOG,"Event Des File Version error");
        return MOS_ERR;
    }

    while(!Mos_FileEof(hFile))
    {
        iRet=Mos_FileRead(hFile,(_UC*)&stEventInf,iSize);
        if(iRet<iSize){
            break;
        }
        if(cNowTime == stEventInf.cEventTime && stEventInf.uiKjIoTType==uiKjIoTType &&
            stEventInf.uillKjIoTId==uillKjIoTId && stEventInf.uiKjIoTEventId==uiKjIoTEventId && stEventInf.ucBInUse=='Z')
        {
            stEventInf.ucBInUse=' ';
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,-iSize);
            Mos_FileWrite(hFile,(_UC*)&stEventInf,iSize);
            break;
        }
    }
    Mos_FileClose(hFile);
    MOS_LOG_INF(EVENT_LOG,"delete event OK,Time %s,IotType %u,IotId %llu,EventId %d",pucTime,uiKjIoTType,uillKjIoTId,uiKjIoTEventId);
    return MOS_OK;
}

//查找结点
static ST_EVENT_INNODE *Event_FindNode(_UI uiKjIoTType,_LLID uillKjIoTId,_UI uiKjIoTEventId)
{
    _INT iFindNodeFlag = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_EVENT_INNODE *pstEventNode = MOS_NULL;
 
    FOR_EACHDATA_INLIST(&Event_GetMng()->stEventList, pstEventNode, stIterator)
    {
        if(pstEventNode->stEventInf.uiKjIoTType    == uiKjIoTType &&
           pstEventNode->stEventInf.uillKjIoTId    == uillKjIoTId &&
           pstEventNode->stEventInf.uiKjIoTEventId == uiKjIoTEventId)
        {
            iFindNodeFlag = 1;
            break;
            // return pstEventNode;
        }
    }

    if (iFindNodeFlag == 1)
    {
        return pstEventNode;
    }
    else
    {
        MOS_LOG_ERR(EVENT_LOG,"uiKjIoTType:%d uillKjIoTId:%llu uiKjIoTEventId:%d FindNode ERR", uiKjIoTType, uillKjIoTId, uiKjIoTEventId);
        return MOS_NULL;
    }
}

static ST_EVENT_INNODE *Event_FindOrCreatNode(_UI uiKjIoTType,_LLID uillKjIoTId,_UI uiKjIoTEventId,_CTIME_T cNowTime)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_EVENT_INNODE *pstEventNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Event_GetMng()->stEventList, pstEventNode, stIterator)
    {
        if(pstEventNode->stEventInf.uiKjIoTType     == uiKjIoTType    &&
            pstEventNode->stEventInf.uillKjIoTId    == uillKjIoTId    &&
            pstEventNode->stEventInf.uiKjIoTEventId == uiKjIoTEventId &&
            pstEventNode->iStatus == EN_EVENT_NODE_IDLE)
        {
            return pstEventNode;
        }
    }
    pstEventNode = (ST_EVENT_INNODE*)MOS_MALLOCCLR(sizeof(ST_EVENT_INNODE));
    pstEventNode->cPushTime                 = 0;    // cNowTime
    pstEventNode->stEventInf.ucCheckFlag    = 'S';
    pstEventNode->stEventInf.ucBInUse       = 'Z';
    pstEventNode->stEventInf.uiKjIoTType    = uiKjIoTType;
    pstEventNode->stEventInf.uillKjIoTId    = uillKjIoTId;
    pstEventNode->stEventInf.uiKjIoTEventId = uiKjIoTEventId;
    pstEventNode->iStatus                   = EN_EVENT_NODE_IDLE;
    MOS_LIST_ADDTAIL(&Event_GetMng()->stEventList, pstEventNode);
    MOS_LOG_INF(EVENT_LOG,"event add node success,KjIottype :%u,KjIotid :%lld,eventid :%u",uiKjIoTType,uillKjIoTId,uiKjIoTEventId);
    return pstEventNode;
}

//消息队列处理
_VOID Event_TaskProcMsg(_VPTR pstMsg)
{
    MOS_PARAM_NULL_NORET(pstMsg);

    ST_MOS_MSGHEAD *pstMsgHead = (ST_MOS_MSGHEAD*)pstMsg;
    ST_EVENT_INNODE *pstEventNode = MOS_NULL;

    if(EN_EVENT_MSG_START == pstMsgHead->usMsgType)
    {
        ST_EVENTDATA_MSG *pstEventMsgInf = (ST_EVENTDATA_MSG*)pstMsg;
        Mos_MutexLock(&(Event_GetMng()->hMutex));
        pstEventNode = Event_FindOrCreatNode(pstEventMsgInf->uiKjIoTType,pstEventMsgInf->uillKjIoTId,pstEventMsgInf->uiKjIoTEventId,pstEventMsgInf->tCreateTime);
        pstEventNode->stEventInf.uiDuration = pstEventMsgInf->uiDuration;
        pstEventNode->stEventInf.cEventTime = pstEventMsgInf->tCreateTime;
        pstEventNode->cPushTime = pstEventMsgInf->tCreateTime;
        pstEventNode->iStatus = EN_EVENT_NODE_START;
        Mos_MutexUnLock(&(Event_GetMng()->hMutex));
        return;
    }
    else if(EN_EVENT_MSG_SETPATH == pstMsgHead->usMsgType)
    {
        ST_EVENT_SETPATH_MSG *pstEventMsgInf = (ST_EVENT_SETPATH_MSG*)pstMsg;
        if(!MOS_STRISEMPTY(pstEventMsgInf->aucBuf)){
            MOS_STRNCPY(Event_GetMng()->aucPathName,pstEventMsgInf->aucBuf,sizeof(Event_GetMng()->aucPathName));
            Event_GetMng()->iStopAll=0;
        }
        Event_GetMng()->iChangePathFlag=1;
        MOS_LOG_INF(EVENT_LOG,"set path %s",pstEventMsgInf->aucBuf);
    }
    else if(EN_EVENT_MSG_DELETE == pstMsgHead->usMsgType)
    {
        ST_EVENT_DELETE_MSG *pstEventMsgInf = (ST_EVENT_DELETE_MSG*)pstMsg;
        switch(pstEventMsgInf->iDeleteType)
        {
        case EN_EVENT_DAY:
            Event_DeleteByDay(pstEventMsgInf->aucDay);
            break;
        case EN_EVENT_ONE:
            Event_DeleteOnlyOne(pstEventMsgInf->aucTime,pstEventMsgInf->uiKjIoTType,pstEventMsgInf->uillKjIoTId,pstEventMsgInf->uiKjIoTEventId);
            break;
        default:
            break;
        }
    }
    return;
}

//任务处理
_INT Event_IoProcess()
{
    _CTIME_T cNowTime = Mos_Time();
    _INT iSize = sizeof(ST_EVENT_INF);
    _HFILE hFile=MOS_NULL;
    _VPTR pstMsg = MOS_NULL;
    _UC aucDay[12]={0};
    ST_MOS_SYS_TIME stSysTime;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_EVENT_INNODE *pstEventNode = MOS_NULL;
    
    while(Mos_MsgQueueGetCount(Event_GetMng()->hMsgQueue) > 0)
    {
        pstMsg = Mos_MsgQueuePop(Event_GetMng()->hMsgQueue);
        Event_TaskProcMsg(pstMsg);
        MOS_FREE(pstMsg);
    }

    if(Event_GetMng()->iStopAll == 1 || MOS_STRLEN(Event_GetMng()->aucPathName) == 0){
        // MOS_LOG_INF(EVENT_LOG,"event stop,path :%s",Event_GetMng()->aucPathName);
        return MOS_OK;
    }

    if(Event_GetMng()->iCount++ >= 100 || Event_GetMng()->iChangePathFlag == 1)
    {
        Mos_TimetoSysTime(&cNowTime,&stSysTime);
        MOS_VSNPRINTF(aucDay,12,"%02hu-%02hu-%02hu",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
        if(0 != MOS_STRNCMP(Event_GetMng()->aucDay,aucDay,MOS_STRLEN(aucDay)) || Event_GetMng()->iChangePathFlag == 1)
        {
            Event_CheckDir();
            MOS_STRNCPY(Event_GetMng()->aucDay,aucDay,sizeof(Event_GetMng()->aucDay));
            MOS_VSNPRINTF(Event_GetMng()->aucFileName,256,"%s/%s/%sEvent.txt",Event_GetMng()->aucPathName,EVENT_DIR,Event_GetMng()->aucDay);
            Event_GetMng()->iChangeFlag = 1;
        }
        Event_GetMng()->iCount = 0;
    }

    Mos_MutexLock(&(Event_GetMng()->hMutex));
    FOR_EACHDATA_INLIST(&Event_GetMng()->stEventList, pstEventNode, stIterator)
    {
        if(Event_GetMng()->iChangeFlag == 1 && pstEventNode->iStatus == EN_EVENT_NODE_START){
            pstEventNode->stEventInf.uiDuration = (_UI)pstEventNode->stEventInf.cEventTime + pstEventNode->stEventInf.uiDuration - (_UI)cNowTime;
            pstEventNode->stEventInf.cEventTime = cNowTime;
        }
        
        if(EN_EVENT_NODE_START == pstEventNode->iStatus)
        {
            if(Event_GetMng()->iChangeFlag == 1){
                Event_AddDate(Event_GetMng()->aucDay);
                Event_GetMng()->iChangeFlag = 0;
            }

            if(!Mos_FileIsExist(Event_GetMng()->aucFileName)){
                Mos_FileWriteAppend(Event_GetMng()->aucFileName,EVENT_FILEDESCFG_VERSION,MOS_STRLEN(EVENT_FILEDESCFG_VERSION));
            }
            hFile = Mos_FileOpen(Event_GetMng()->aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);

            Mos_TimetoSysTime(&cNowTime,&stSysTime);
            MOS_VSNPRINTF(pstEventNode->stEventInf.aucEventName,32,"%04hu%02hu%02hu%02hu%02hu%02hu_%u_%d",stSysTime.usYear,stSysTime.usMonth,
                stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond,pstEventNode->stEventInf.uiKjIoTType,Event_GetMng()->iNum++);
            Mos_FileSeek(hFile,MOS_FILE_SEEK_END,0);
            Mos_FileWrite(hFile,(_UC*)&pstEventNode->stEventInf,iSize);
            pstEventNode->iStatus = EN_EVENT_NODE_IDLE;
            Mos_FileClose(hFile);
        }
    }
    Mos_MutexUnLock(&(Event_GetMng()->hMutex));
    return MOS_OK;
}

//删除给定时间前所有文件OK
_VOID Event_DeleteManyDays(_UC *pucDayAgo)
{
    MOS_PARAM_NULL_NORET(pucDayAgo);

    _INT iRet  = 0;
    _INT iSize = sizeof(ST_EVENT_DATE);
    _HFILE hDateFile = MOS_NULL;
    _UC aucVersion[20] = {0};
    _UC aucEventPath[256];
    ST_EVENT_DATE stTmpDate={0};

    MOS_VSNPRINTF(aucEventPath,256,"%s/%s/%s",Event_GetMng()->aucPathName,EVENT_DIR,EVENT_DATECFG_NAME);
    hDateFile=Mos_FileOpen(aucEventPath,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hDateFile == MOS_NULL){
        return;
    }
    Mos_FileRead(hDateFile,aucVersion,MOS_STRLEN(EVENT_DATECFG_VERSION));
    if(MOS_STRCMP(aucVersion,EVENT_DATECFG_VERSION)){
        Mos_FileClose(hDateFile);
        Mos_FileRmv(aucEventPath);
        MOS_LOG_ERR(EVENT_LOG,"Event Date File Version error");
        return;
    }
    while(!Mos_FileEof(hDateFile))
    {
        iRet=Mos_FileRead(hDateFile,(_UC*)&stTmpDate,iSize);
        if(iRet < iSize || stTmpDate.ucCheck != '$'){
            break;
        }
        if(stTmpDate.ucBInUse != 1){
            continue;
        }
        if(MOS_STRCMP(stTmpDate.aucDate,pucDayAgo) < 0){
            MOS_VSNPRINTF(aucEventPath,256,"%s/%s/%s%s",Event_GetMng()->aucPathName,EVENT_DIR,stTmpDate.aucDate,EVENT_FILEDES_NAME);
            Mos_FileRmv(aucEventPath);
            stTmpDate.ucBInUse=' ';
            Mos_FileSeek(hDateFile,MOS_FILE_SEEK_CUR,-iSize);
            Mos_FileWrite(hDateFile,(_UC*)&stTmpDate,iSize);
        }
        else
        {
            break;
        }
    }
    Mos_FileClose(hDateFile);
    return;
}

//查找或建立新的事件节点OK
_INT Event_AddOneItem(_UI uiKjIoTType,_LLID uillKjIoTId,_UI uiKjIoTEventId,_UI uiDuration,_CTIME_T tCreateTime)
{
    ST_EVENTDATA_MSG *pstEventMsg;
    // if(Event_GetMng()->iStopAll == 1 || MOS_STRLEN(Event_GetMng()->aucPathName) == 0){
    //     MOS_LOG_INF(EVENT_LOG,"event stop,path :%s",Event_GetMng()->aucPathName);
    //     return MOS_OK;
    // }
    pstEventMsg = (ST_EVENTDATA_MSG*)MOS_MALLOCCLR(sizeof(ST_EVENTDATA_MSG));
    pstEventMsg->stMsgHead.usMsgType = EN_EVENT_MSG_START;
    pstEventMsg->uiKjIoTType         = uiKjIoTType;
    pstEventMsg->uillKjIoTId         = uillKjIoTId;
    pstEventMsg->uiKjIoTEventId      = uiKjIoTEventId;
    pstEventMsg->uiDuration          = uiDuration;
    pstEventMsg->tCreateTime         = tCreateTime;
    MOS_LOG_INF(EVENT_LOG,"add event,IotType %u,IotId %llu,EventId %u,Duration %u,time %u",
        uiKjIoTType,uillKjIoTId,uiKjIoTEventId,uiDuration,tCreateTime);

    _INT iRet = Mos_MsgQueuePush(Event_GetMng()->hMsgQueue,pstEventMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstEventMsg);
        return MOS_ERR;
    }

    Mos_Sleep(100);
    return iRet;
}

//查找有图片的日期OK
ST_MOS_LIST *Event_QueryCanlender(_UC *pucDay)
{
    MOS_PARAM_NULL_RETNULL(pucDay);

    _HFILE hFile = MOS_NULL;
    _INT iSize = 0,iRet = 0;
    _UC aucVersion[20] ={0};
    _UC aucFileName[256];
    ST_EVENT_DATE stDate;
    ST_MOS_LIST *pstList = MOS_NULL;
    ST_EVENT_DATENODE *pstEventDateNode=MOS_NULL;

    MOS_LOG_INF(EVENT_LOG,"query canlender start,StartDay %s",pucDay);
    iSize=sizeof(ST_EVENT_DATE);

    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s",Event_GetMng()->aucPathName, EVENT_DIR,EVENT_DATECFG_NAME);
    
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDONLY);

    if(hFile == MOS_NULL)
    {
        return MOS_NULL;
    }
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(EVENT_DATECFG_VERSION));
    
    if(MOS_STRCMP(aucVersion,EVENT_DATECFG_VERSION) != 0)
    {
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(EVENT_LOG,"Event desfile Version error");
        return MOS_NULL;
    }
    
    pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
    if(pstList == MOS_NULL)
    {
        Mos_FileClose(hFile);
        return MOS_NULL;
    }

    while(!Mos_FileEof(hFile))
    {
        iRet=Mos_FileRead(hFile,(_UC*)&stDate,iSize);
        if(iRet < iSize){
            break;
        }
        if(stDate.ucBInUse==1 && stDate.ucCheck=='$' && MOS_STRNCMP(stDate.aucDate,pucDay,MOS_STRLEN(pucDay)) >= 0)
        {
            pstEventDateNode= (ST_EVENT_DATENODE *)MOS_MALLOCCLR(sizeof(ST_EVENT_DATENODE));
            if(pstEventDateNode != MOS_NULL){
                MOS_MEMCPY(&pstEventDateNode->stDate,&stDate, sizeof(ST_EVENT_DATE));
                MOS_LIST_ADDTAIL(pstList, pstEventDateNode);
            }
        }
    }
    Mos_FileClose(hFile);
    return pstList;
}

//从文件中获取对应event信息，返回链表OK
ST_MOS_LIST *Event_QueryInfoByTime(_UC *pucFromTime,_UI uiPageSize)
{
    MOS_PARAM_NULL_RETNULL(pucFromTime);

    _HFILE hFile = MOS_NULL;
    _INT iRet    = 0;
    _INT iSize   = sizeof(ST_EVENT_INF);
    _UC aucVersion[20]={0};
    _UC aucFileName[256];
    _CTIME_T cFromTime;
    ST_EVENT_INF stEventInf; 
    ST_MOS_SYS_TIME stSysTime;
    ST_MOS_LIST *pstList=MOS_NULL;
    ST_EVENT_NODE *pstEventNode=MOS_NULL;

    MOS_LOG_INF(EVENT_LOG,"query info by time start,StartTime %s,PageSize %u",pucFromTime,uiPageSize);

    Mos_GetSysTime(&stSysTime);
    
    MOS_SSCANF(pucFromTime,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",&stSysTime.usYear,&stSysTime.usMonth,
        &stSysTime.usDay,&stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
    
    cFromTime=Mos_SysTimetoTime(&stSysTime);
    
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%04u-%02u-%02u%s",Event_GetMng()->aucPathName,EVENT_DIR,
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,EVENT_FILEDES_NAME);
    
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDONLY);
    if(hFile == MOS_NULL)
    {
        return MOS_NULL;
    }
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(EVENT_FILEDESCFG_VERSION));
    if(MOS_STRCMP(aucVersion,EVENT_FILEDESCFG_VERSION))
    {
        Mos_FileClose(hFile);
        MOS_LOG_ERR(EVENT_LOG,"Event Des File Version error");
        return MOS_NULL;
    }
    pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
    if(pstList == MOS_NULL)
    {
        Mos_FileClose(hFile);
        return MOS_NULL;
    }

    while(!Mos_FileEof(hFile))
    {
        if(pstList->uiTotalCount >= uiPageSize){
            break;
        }
        iRet=Mos_FileRead(hFile,(_UC*)&stEventInf,iSize);
        if(iRet < iSize){
            break;
        }
        if(cFromTime <= stEventInf.cEventTime && stEventInf.ucBInUse == 'Z')
        {
            pstEventNode = (ST_EVENT_NODE *)MOS_MALLOCCLR(sizeof(ST_EVENT_NODE));
            if(pstEventNode != MOS_NULL){
                MOS_MEMCPY(&pstEventNode->stEventInf,&stEventInf, sizeof(ST_EVENT_INF));
                MOS_LIST_ADDTAIL(pstList,pstEventNode);
            }
        }
    }
    Mos_FileClose(hFile);
    MOS_LOG_INF(EVENT_LOG,"query info by time OK,Result %u",pstList->uiTotalCount);
    return pstList;
}

//获取指定类型给定数量个事件记录OK
ST_MOS_LIST *Event_QueryInfoByType(_UC *pucFromTime,_UI uiKjIoTType,_UI uiPageSize)
{
    MOS_PARAM_NULL_RETNULL(pucFromTime);

    _HFILE hFile;
    _INT iRet  = 0;
    _INT iSize = sizeof(ST_EVENT_INF);
    _UC aucVersion[20];
    _UC aucFileName[256];
    _CTIME_T cFromTime;
    ST_EVENT_INF stEventInf; 
    ST_MOS_SYS_TIME stSysTime;
    ST_MOS_LIST   *pstList      = MOS_NULL;
    ST_EVENT_NODE *pstEventNode = MOS_NULL;

    MOS_LOG_INF(EVENT_LOG,"query info by type start,StartTime %s,IotType %u,PageSize %u",pucFromTime,uiKjIoTType,uiPageSize);

    Mos_GetSysTime(&stSysTime);
    
    MOS_SSCANF(pucFromTime,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",&stSysTime.usYear,&stSysTime.usMonth,
        &stSysTime.usDay,&stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
    
    cFromTime=Mos_SysTimetoTime(&stSysTime);

    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%04u-%02u-%02u%s",Event_GetMng()->aucPathName,EVENT_DIR,
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,EVENT_FILEDES_NAME);

    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDONLY);
    if(hFile == MOS_NULL)
    {
        return MOS_NULL;
    }
    MOS_MEMSET(aucVersion,0,20);
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(EVENT_FILEDESCFG_VERSION));
    if(MOS_STRCMP(aucVersion,EVENT_FILEDESCFG_VERSION))
    {
        Mos_FileClose(hFile);
        MOS_LOG_ERR(EVENT_LOG,"Event Des File Version error");
        return MOS_NULL;
    }

    pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
    if(pstList == MOS_NULL){
        Mos_FileClose(hFile);
        return MOS_NULL;
    }

    while(!Mos_FileEof(hFile))
    {
        if(pstList->uiTotalCount >= uiPageSize){
            break;
        }
        iRet=Mos_FileRead(hFile,(_UC*)&stEventInf,iSize);
        if(iRet<iSize){
            break;
        }
        if(stEventInf.uiKjIoTType == uiKjIoTType && stEventInf.cEventTime >= cFromTime && stEventInf.ucBInUse == 'Z')
        {
            pstEventNode = (ST_EVENT_NODE *)MOS_MALLOCCLR(sizeof(ST_EVENT_NODE));
            if(pstEventNode != MOS_NULL)
            {
                MOS_MEMCPY(&pstEventNode->stEventInf,&stEventInf, sizeof(ST_EVENT_INF));
                MOS_LIST_ADDTAIL(pstList, pstEventNode);
            }
        }
    }
    Mos_FileClose(hFile);
    MOS_LOG_INF(EVENT_LOG,"query info by type OK,Result %u",pstList->uiTotalCount);
    return pstList;
}

//文件信息自动老化
_INT Event_IoAutoDelete()
{
    _UC aucDay[20];
    _CTIME_T cTimeNow = Mos_Time() - 7*86400;
    ST_MOS_SYS_TIME stSysTime;

    Mos_TimetoSysTime(&cTimeNow ,&stSysTime);
    MOS_VSNPRINTF(aucDay, 20, "%04u-%02u-%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    
    Event_DeleteManyDays(aucDay);
    MOS_LOG_INF(EVENT_LOG,"auto delete OK");
    return MOS_OK;
}

//发送删除信息
_INT Event_DeleteItem(_INT iDeleteType,_UC *pucDay,_UC *pucTime,_UI uiKjIoTType,_LLID uillKjIoTId,_UI uiKjIoTEventId)
{
    MOS_PARAM_NULL_RETERR(pucDay);
    MOS_PARAM_NULL_RETERR(pucTime);

    ST_EVENT_DELETE_MSG *pstEventMsg = MOS_NULL;
    
    MOS_LOG_INF(EVENT_LOG,"send delete msg start,Type %d",iDeleteType);
    if(Event_GetMng()->iStopAll == 1 ||MOS_STRLEN(Event_GetMng()->aucPathName) == 0){
        MOS_LOG_WARN(EVENT_LOG,"send delete msg fail,Stop status %d,Path %s",Event_GetMng()->iStopAll,Event_GetMng()->aucPathName);
        return MOS_OK;
    }
    
    pstEventMsg = (ST_EVENT_DELETE_MSG*)MOS_MALLOCCLR(sizeof(ST_EVENT_DELETE_MSG));
    pstEventMsg->stMsgHead.usMsgType=EN_EVENT_MSG_DELETE;
    switch(iDeleteType)
    {
        case EN_EVENT_DAY:
        {
            pstEventMsg->iDeleteType = 1;
            MOS_STRNCPY(pstEventMsg->aucDay,pucDay,sizeof(pstEventMsg->aucDay));
            break;
        }
        case EN_EVENT_ONE:
        {
            pstEventMsg->iDeleteType = 2;
            pstEventMsg->uiKjIoTEventId = uiKjIoTEventId;
            pstEventMsg->uiKjIoTType = uiKjIoTType;
            pstEventMsg->uillKjIoTId = uillKjIoTId;
            MOS_STRNCPY(pstEventMsg->aucTime,pucTime,sizeof(pstEventMsg->aucTime));
            break;
        }
        default:{

        }
    }

    _INT iRet = Mos_MsgQueuePush(Event_GetMng()->hMsgQueue,pstEventMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstEventMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Event_SetPath(_UC *pucBuf)
{
    MOS_PARAM_NULL_RETERR(pucBuf);

    ST_EVENT_SETPATH_MSG *pstEventMsg = (ST_EVENT_SETPATH_MSG*)MOS_MALLOCCLR(sizeof(ST_EVENT_SETPATH_MSG));

    MOS_LOG_INF(EVENT_LOG,"send set path msg start,Path %s",pucBuf);
    pstEventMsg->stMsgHead.usMsgType = EN_EVENT_MSG_SETPATH;
    MOS_STRNCPY(pstEventMsg->aucBuf,pucBuf,sizeof(pstEventMsg->aucBuf));
    _INT iRet = Mos_MsgQueuePush(Event_GetMng()->hMsgQueue,pstEventMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstEventMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Event_IoStop()
{
    ST_EVENT_INNODE *pstEventNode;
    ST_MOS_LIST_ITERATOR stIteator;

    Mos_MutexLock(&(Event_GetMng()->hMutex));
    FOR_EACHDATA_INLIST(&Event_GetMng()->stEventList,pstEventNode,stIteator)
    {
        pstEventNode->iStatus = EN_EVENT_NODE_IDLE;
    }
    Mos_MutexUnLock(&(Event_GetMng()->hMutex));
    Event_GetMng()->iStopAll=1;
    MOS_LOG_INF(EVENT_LOG,"Event io stop ok");
    return MOS_OK;
}

_INT Event_IoReStart(_UC *pucLocalPath)
{
    MOS_PARAM_NULL_RETERR(pucLocalPath);

    if(MOS_STRISEMPTY(pucLocalPath)){
        Event_GetMng()->iStopAll = 1; 
    }
    else{
        Event_GetMng()->iStopAll = 0;
    }
    Event_GetMng()->iChangePathFlag = 1;
    MOS_STRNCPY(Event_GetMng()->aucPathName,pucLocalPath,sizeof(Event_GetMng()->aucPathName));
    MOS_LOG_INF(EVENT_LOG,"Event io restart ok,set path :%s",Event_GetMng()->aucPathName);
    return MOS_OK;
}

_INT Event_IotTypeOutput(_UI uiAIIoTType, _LLID uiAIIoTID, _UC* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    MOS_PARAM_NULL_RETERR(pSignalValue);
    MOS_PARAM_NULL_RETERR(pstTriggerInf);

    JSON_HANDLE hRoot     = MOS_NULL;
    _UC aucHappenTime[32] = {0};
    _UI uiPushFlag=0,uiSmsFlag=0,uiEmailFlag=0,uiInterval=0,uiUpInterval=0;
    _UI uiWeekDay=0,uiStartTime=0,uiEndTime=0,uiSecInDay=0,uiSpanFlag=0;
    _UI uiOutFlag =0;
    _UC aucEmalAddr[256] = {0};
    ST_MOS_SYS_TIME stSysTime;
    _CTIME_T cHappentime;
    _CTIME_T cNowTime;
    ST_HTTP_EVENT_EXT stEventExt;
    ST_EVENT_INNODE *pstEventNode = MOS_NULL;

    MOS_MEMSET(&stEventExt,0,sizeof(stEventExt));
    cNowTime    = pstTriggerInf->tCreateTime;
    cHappentime = cNowTime;
    Mos_TimetoSysTime(&cHappentime,&stSysTime);

    
    MOS_VSNPRINTF(aucHappenTime, 32, "%04u-%02u-%02u %02u:%02u:%02u",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    // 获取事件推送1013的参数
    Config_GetEventProp(&uiPushFlag,&uiSmsFlag,&uiEmailFlag,&uiInterval,aucEmalAddr,&stEventExt.uiCostomType,&uiStartTime,&uiEndTime,&uiSpanFlag);

//    MOS_LOG_INF(EVENT_LOG,"uiIotType:%u lluIotId:%u uiEventId:%u uiPushFlag:%u uiInterval:%u uiStartTime:%u uiEndTime:%u",
//                        pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, pstTriggerInf->uiEventId, uiPushFlag, uiInterval, uiStartTime, uiEndTime);

    MOS_PRINTF("iot [%u %llu %u] JSON pSignalValue: %s \r\n", pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, pstTriggerInf->uiEventId, pSignalValue);
    // output 1013的联动参数 
    hRoot = Adpt_Json_Parse(pSignalValue);

    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PushFlag"), (_INT*)&uiOutFlag) == MOS_OK)
    {
        uiPushFlag = (uiPushFlag&uiOutFlag);
    }
    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SMSFlag"),(_INT*) &uiOutFlag) == MOS_OK)
    {
        uiSmsFlag = (uiSmsFlag&uiOutFlag);
    }
    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EmailFlag"), (_INT*)&uiOutFlag) == MOS_OK)
    {
        uiEmailFlag = (uiEmailFlag&uiOutFlag);
    }
    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CustomType"),(_INT*) &uiOutFlag) == MOS_OK)
    {
        stEventExt.uiCostomType = (stEventExt.uiCostomType&uiOutFlag);
    }
    stEventExt.uiDuration = pstTriggerInf->uiDuration;
    // IOT事件上报的开始,结束,跨天是1013 IOT属性决定的
    // if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StartTime"),(_INT*) &uiOutFlag) == MOS_OK)
    // {
    //     uiStartTime = uiOutFlag >= uiStartTime ? uiOutFlag : uiStartTime;
    // }
    // if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EndTime"),(_INT*) &uiOutFlag) == MOS_OK)
    // {
    //     uiEndTime   = uiOutFlag <= uiEndTime ? uiOutFlag : uiEndTime;
    // }
    // if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SpanFlag"),(_INT*) &uiOutFlag) == MOS_OK)
    // {
    //     uiSpanFlag = (uiSpanFlag&uiOutFlag);
    // }
    // if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Interval"), &uiUpInterval) != MOS_OK || uiUpInterval == 0)
    {
        uiUpInterval = uiInterval;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Interval"), &uiOutFlag);
    
    if(uiUpInterval == 0)
    {
        uiUpInterval = 60;
    }
    // TUDO:临时修改无间隔推送
    // if(pstTriggerInf->uiIotType == EN_ZJ_AIIOT_TYPE_HIGHPARABOLIC || 
    //    pstTriggerInf->uiIotType == EN_ZJ_AIIOT_TYPE_BATTERYBIKE ||
    //    pstTriggerInf->uiIotType == EN_ZJ_AIIOT_TYPE_MASK)
    // {
    //     uiUpInterval = 0;    // 没有推送间隔
    //     // uiPushFlag = 1;   是否考虑与移动侦测推送互斥
    // }

    Mos_GetTimeInDay(Mos_Time(), &uiWeekDay, &uiSecInDay);

    Mos_MutexLock(&(Event_GetMng()->hMutex));
    pstEventNode = Event_FindNode(pstTriggerInf->uiIotType,pstTriggerInf->lluIotId,pstTriggerInf->uiEventId);
    Mos_MutexUnLock(&(Event_GetMng()->hMutex));
    if (pstEventNode == MOS_NULL)
    {
        MOS_LOG_WARN(EVENT_LOG,"iot [%u %llu %u] pstEventNode==NULL,PushFlag:%d", pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, pstTriggerInf->uiEventId, uiPushFlag);
    }
    else
    {
        MOS_LOG_INF(EVENT_LOG,"iot [%u %llu %u] PushFlag:%d UpInterval:%u  SecInDay: %u subTime==%d",
        pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, pstTriggerInf->uiEventId, uiPushFlag, uiUpInterval, uiSecInDay, (cNowTime - pstEventNode->cPushTime));
    }

    // 看家推送开关(打开)  大于推送间隔  推送时间段范围内  
    if(uiPushFlag && (pstEventNode == MOS_NULL||(_UI)(cNowTime - pstEventNode->cPushTime) >= uiUpInterval) && 
        ((uiSpanFlag == 0 && uiSecInDay >= uiStartTime && uiSecInDay <= uiEndTime) || 
         (uiSpanFlag == 1 && (uiSecInDay >= uiStartTime || uiSecInDay <= uiEndTime))) )
    {
        ST_ZJ_IOT_INF stIoTInf = {0};
        stIoTInf.uiIoTType    = pstTriggerInf->uiIotType;
        stIoTInf.lluIoTId     = pstTriggerInf->lluIotId;
        stIoTInf.uiIoTEventId = pstTriggerInf->uiEventId;
        // 事件推送到云端
        MsgMng_UploadEventToDxServer(&stIoTInf,cHappentime,uiPushFlag,pstTriggerInf->pstHandler);
        if(pstEventNode != MOS_NULL)
        {
            pstEventNode->cPushTime = cNowTime;
        }

        //建立新的事件节点
        Event_AddOneItem(pstTriggerInf->uiIotType,pstTriggerInf->lluIotId,pstTriggerInf->uiEventId,uiInterval,cNowTime);
    
#if ALARMEVENT_SNAP
        // 推送的消息告警联动云端抓图和本地抓图
        _UC aucSnapBuff[256] = {0};
        MOS_VSNPRINTF(aucSnapBuff,  256, "{\"PicType\":\"2\",\"GifFlag\":\"0\"}");
        ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = MOS_NULL;
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_SNAPSHORT);
        if (pstDevCtrlNode)
        {
            // 调用output回调接口
            if(pstDevCtrlNode->pFunContrlDev && pstDevCtrlNode->uiInTimerCtrl == 0)
            {
                pstDevCtrlNode->pFunContrlDev(pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, aucSnapBuff, pstTriggerInf);
            }
        }
        else
        {
            MOS_LOG_ERR(EVENT_LOG, "EN_ZJ_AIIOT_TYPE_SNAPSHORT pstDevCtrlNode == MOS_NULL");
        }

        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_CLOUDSNAP);
        if (pstDevCtrlNode)
        {
            // 调用output回调接口
            if(pstDevCtrlNode->pFunContrlDev && pstDevCtrlNode->uiInTimerCtrl == 0)
            {
                pstDevCtrlNode->pFunContrlDev(pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, aucSnapBuff, pstTriggerInf);
            }
        }
        else
        {
            MOS_LOG_INF(EVENT_LOG, "EN_ZJ_AIIOT_TYPE_CLOUDSNAP pstDevCtrlNode == MOS_NULL");
        }
#endif
    }
    else
    {
        // 不推送事件,通知厂商释放上传数据
        ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf = (ST_ZJ_AI_AlARM_UPLOAD_INF* )pstTriggerInf->pstHandler;
        if (pstAIAlarmUploadInf)
        {
            if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
            {
                _INT iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
                if (MOS_OK != iRet)
                {
                    MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s  VideoPath:%s failed", pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
                }
            }
            else
            {
                MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
            }
        }
    }

    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

// add by zn_liuwj  告警推送
_INT Event_IotTypeOutputEx(_UI uiAIIoTType, _LLID uiAIIoTID, _UC* pSignalValue, ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    MOS_PARAM_NULL_RETERR(pSignalValue);
    MOS_PARAM_NULL_RETERR(pstTriggerInf);

    _UI uiOutFlag = 0;
    JSON_HANDLE hRoot = MOS_NULL;
    _UI uiPushFlag=0,uiSmsFlag=0,uiEmailFlag=0,uiUpInterval=0;
    _UI uiWeekDay=0,uiStartTime=0,uiEndTime=0,uiSecInDay=0,uiSpanFlag=0;
    _UC aucEmalAddr[256] = {0};
    _CTIME_T cNowTime    =  0;
    _CTIME_T cHappentime =  0;
    ST_HTTP_EVENT_EXT stEventExt  = {0};
    ST_EVENT_INNODE *pstEventNode = MOS_NULL;

    MOS_MEMSET(&stEventExt,0,sizeof(stEventExt));
    cNowTime    = pstTriggerInf->tCreateTime;
    cHappentime = cNowTime;

    // 移动侦测和人形侦测的 告警消息推送参数 使用全局的1013的属性
    if (pstTriggerInf->uiIotType  == EN_ZJ_AIIOT_TYPE_MOTION   && 
        (pstTriggerInf->uiEventId == EN_ZJ_MOTION_EVENT_MOTION || pstTriggerInf->uiEventId == EN_ZJ_MOTION_EVENT_HUMAN))
    {
        // 获取 告警事件消息推送 全局1013的属性参数
        Config_GetEventProp(&uiPushFlag,&uiSmsFlag,&uiEmailFlag,&uiUpInterval,aucEmalAddr,&stEventExt.uiCostomType,&uiStartTime,&uiEndTime,&uiSpanFlag);

        // output 1013的联动参数 
        hRoot = Adpt_Json_Parse(pSignalValue);
        if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PushFlag"), (_INT*)&uiOutFlag) == MOS_OK)
        {
            uiPushFlag = (uiPushFlag&uiOutFlag);
        }
        if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SMSFlag"),(_INT*) &uiOutFlag) == MOS_OK)
        {
            uiSmsFlag = (uiSmsFlag&uiOutFlag);
        }
        if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EmailFlag"), (_INT*)&uiOutFlag) == MOS_OK)
        {
            uiEmailFlag = (uiEmailFlag&uiOutFlag);
        }
        if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CustomType"),(_INT*) &uiOutFlag) == MOS_OK)
        {
            stEventExt.uiCostomType = (stEventExt.uiCostomType&uiOutFlag);
        }
        stEventExt.uiDuration = pstTriggerInf->uiDuration;
        Adpt_Json_Delete(hRoot);
        hRoot =  MOS_NULL;
    }
    else // 其他AI告警的消息推送 使用策略内的1013的output的属性参数
    {
        MOS_PRINTF("iot [%u %llu %u] JSON pSignalValue: %s \r\n", pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, pstTriggerInf->uiEventId, pSignalValue);
        hRoot = Adpt_Json_Parse(pSignalValue);
        if (hRoot != MOS_NULL)
        {
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PushFlag"),  (_INT*)&uiPushFlag);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SMSFlag"),   (_INT*)&uiSmsFlag);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EmailFlag"), (_INT*)&uiEmailFlag);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CustomType"),(_INT*)&stEventExt.uiCostomType);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StartTime"), (_INT*)&uiStartTime);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EndTime"),   (_INT*)&uiEndTime);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SpanFlag"),  (_INT*)&uiSpanFlag);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Interval"),  (_INT*)&uiUpInterval);
            stEventExt.uiDuration = pstTriggerInf->uiDuration;
            Adpt_Json_Delete(hRoot);
            hRoot =  MOS_NULL;
        }
    }

    // 获取触发事件的时间戳在当天的秒数和周几
    Mos_GetTimeInDay(cHappentime, &uiWeekDay, &uiSecInDay);

    // 查找该IOT告警的事件节点 获取上次的事件触发时间
    Mos_MutexLock(&(Event_GetMng()->hMutex));
    pstEventNode = Event_FindNode(pstTriggerInf->uiIotType,pstTriggerInf->lluIotId,pstTriggerInf->uiEventId);
    Mos_MutexUnLock(&(Event_GetMng()->hMutex));
    if (pstEventNode == MOS_NULL)
    {
        // 该IOT告警第一次触发时间推送
        MOS_LOG_INF(EVENT_LOG,"IoT[%u %llu %u] First Event PushFlag:%d StartTime:%u EndTime:%u SpanFlag:%u UpInterval:%u SecInDay:%u",
        pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, pstTriggerInf->uiEventId, uiPushFlag, uiStartTime, uiEndTime, uiSpanFlag, uiUpInterval, uiSecInDay);
    }
    else
    {
        // 该IOT告警非第一次触发时间推送
        MOS_LOG_INF(EVENT_LOG,"IoT[%u %llu %u] Event PushFlag:%d StartTime:%u EndTime:%u SpanFlag:%u UpInterval:%u SecInDay:%u SubTime:%u",
        pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, pstTriggerInf->uiEventId, uiPushFlag, uiStartTime, uiEndTime, uiSpanFlag, uiUpInterval, uiSecInDay, (_UI)(cNowTime - pstEventNode->cPushTime));
    }

    // 看家推送开关(打开)  大于推送间隔  推送时间段范围内  
    if  (uiPushFlag && (pstEventNode == MOS_NULL || (_UI)(cNowTime - pstEventNode->cPushTime) >= uiUpInterval) && 
        ((uiSpanFlag == 0 && (uiSecInDay >= uiStartTime && uiSecInDay <= uiEndTime)) || 
         (uiSpanFlag == 1 && (uiSecInDay >= uiStartTime || uiSecInDay <= uiEndTime)) ))
    {
        // 事件推送到云端
        ST_ZJ_IOT_INF stIoTInf = {0};
        stIoTInf.uiIoTType    = pstTriggerInf->uiIotType;
        stIoTInf.lluIoTId     = pstTriggerInf->lluIotId;
        stIoTInf.uiIoTEventId = pstTriggerInf->uiEventId;
        MsgMng_UploadEventToDxServer(&stIoTInf,cHappentime,uiPushFlag,pstTriggerInf->pstHandler);

        Mos_MutexLock(&(Event_GetMng()->hMutex));
        if (pstEventNode)
        {
            pstEventNode->cPushTime = cNowTime;
        }
        else
        {
            pstEventNode = Event_FindOrCreatNode(pstTriggerInf->uiIotType,pstTriggerInf->lluIotId,pstTriggerInf->uiEventId,cNowTime);
            pstEventNode->cPushTime = cNowTime;
        }
        Mos_MutexUnLock(&(Event_GetMng()->hMutex));

        //建立新的事件节点
        Event_AddOneItem(pstTriggerInf->uiIotType,pstTriggerInf->lluIotId,pstTriggerInf->uiEventId,uiUpInterval,cNowTime);
    
#if ALARMEVENT_SNAP
        // 推送的消息告警联动云端抓图和本地抓图
        _UC aucSnapBuff[256] = {0};
        MOS_VSNPRINTF(aucSnapBuff,  256, "{\"PicType\":\"2\",\"GifFlag\":\"0\"}");
        ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = MOS_NULL;
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_SNAPSHORT);
        if (pstDevCtrlNode)
        {
            // 调用output回调接口
            if(pstDevCtrlNode->pFunContrlDev && pstDevCtrlNode->uiInTimerCtrl == 0)
            {
                pstDevCtrlNode->pFunContrlDev(pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, aucSnapBuff, pstTriggerInf);
            }
        }
        else
        {
            MOS_LOG_ERR(EVENT_LOG, "EN_ZJ_AIIOT_TYPE_SNAPSHORT pstDevCtrlNode == MOS_NULL");
        }

        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_CLOUDSNAP);
        if (pstDevCtrlNode)
        {
            // 调用output回调接口
            if(pstDevCtrlNode->pFunContrlDev && pstDevCtrlNode->uiInTimerCtrl == 0)
            {
                pstDevCtrlNode->pFunContrlDev(pstTriggerInf->uiIotType, pstTriggerInf->lluIotId, aucSnapBuff, pstTriggerInf);
            }
        }
        else
        {
            MOS_LOG_INF(EVENT_LOG, "EN_ZJ_AIIOT_TYPE_CLOUDSNAP pstDevCtrlNode == MOS_NULL");
        }
#endif
    }
    else
    {
        // 不推送事件,通知厂商释放上传数据
        ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf = (ST_ZJ_AI_AlARM_UPLOAD_INF* )pstTriggerInf->pstHandler;
        if (pstAIAlarmUploadInf)
        {
            if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
            {
                _INT iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
                if (MOS_OK != iRet)
                {
                    MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s  VideoPath:%s failed", pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
                }
            }
            else
            {
                MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
            }
        }
    }
    return MOS_OK;
}

_INT Event_Init()
{
    if(Event_GetMng()->iInitFlag == 1)
    {
        MOS_LOG_WARN(EVENT_LOG,"Already Init");
        return MOS_OK;
    }

    MOS_MEMSET(&g_EventTaskMng, 0, sizeof(g_EventTaskMng));
    Event_GetMng()->iChangeFlag = 0;
    Event_GetMng()->iNum = 1;
    Event_GetMng()->iStopAll=0;
    Event_GetMng()->iCount =0;
    Event_GetMng()->iChangePathFlag = 1;

    #if 0
    KjIoT_AddDevContrlFun(EN_ZJ_AIIOT_TYPE_EVENT,Event_IotTypeOutput,MOS_NULL,MOS_NULL,MOS_NULL);
    #else
    KjIoT_AddDevContrlFun(EN_ZJ_AIIOT_TYPE_EVENT,Event_IotTypeOutputEx,MOS_NULL,MOS_NULL,MOS_NULL);
    #endif

    Mos_MutexCreate(&Event_GetMng()->hMutex);
    Event_GetMng()->hMsgQueue = Mos_MsgQueueCreate(MOS_FALSE,10, __FUNCTION__);
    IoMng_Register((_UC*)"Event", Event_IoProcess, Event_IoStop, Event_IoReStart, Event_IoAutoDelete);
    Event_GetMng()->iInitFlag = 1;
    MOS_LOG_INF(EVENT_LOG,"Event init task ok msg queue %p",Event_GetMng()->hMsgQueue);
    return MOS_OK;
}

_INT Event_Destory()
{
    _VPTR pstMsg = MOS_NULL;
    if(Event_GetMng()->iInitFlag == 0){
        MOS_LOG_WARN(EVENT_LOG,"Already Init");
        return MOS_OK;
    }
    
    while(Mos_MsgQueueGetCount(Event_GetMng()->hMsgQueue) > 0)
    {
        pstMsg=Mos_MsgQueuePop(Event_GetMng()->hMsgQueue);
        MOS_FREE(pstMsg);
    }
    Mos_MsgQueueDelete(Event_GetMng()->hMsgQueue);

    Mos_MutexLock(&(Event_GetMng()->hMutex));
    MOS_LIST_RMVALL(&Event_GetMng()->stEventList,MOS_TRUE);
    Mos_MutexUnLock(&(Event_GetMng()->hMutex));

    Mos_MutexDelete(&Event_GetMng()->hMutex);

    Event_GetMng()->hMsgQueue = MOS_NULL;
    Event_GetMng()->iInitFlag = 0;
    MOS_LOG_INF(EVENT_LOG,"Event task destory ok");
    return MOS_OK;
}

_INT Event_AddCompatibleDate(_UC *pucDate)
{
    MOS_PARAM_NULL_RETERR(pucDate);

    Event_CheckDir();
    Event_GetMng()->uiCurrentNum = 0;
    return Event_AddDate(pucDate);
}

_INT Event_AddCompatibleFile(_UC *pucDate,_CTIME_T cEventTime,_UI uiDuration,_UI uiKjIoTType,_UI uiKjIoTEventId)
{
    MOS_PARAM_NULL_RETERR(pucDate);

    _UC aucFileName[256];
    _INT iSize = sizeof(ST_EVENT_INF);
    ST_EVENT_INF stFileDes;
    ST_MOS_SYS_TIME stSysTime;

    Mos_TimetoSysTime(&cEventTime,&stSysTime);
    MOS_VSNPRINTF(aucFileName, 255, "%s/%s/%s",Event_GetMng()->aucPathName,EVENT_DIR,pucDate,EVENT_FILEDES_NAME);

    if(Mos_FileIsExist(aucFileName) == MOS_FALSE){
        Mos_FileSave(aucFileName, EVENT_FILEDESCFG_VERSION, MOS_STRLEN(EVENT_FILEDESCFG_VERSION));
    }

    if(Event_GetMng()->uiCurrentNum == 0)
    {
        _HFILE hFile = MOS_NULL;
        hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN | MOS_FILE_O_RDONLY);
        if(hFile == MOS_NULL)
        {
            return MOS_ERR;
        }
        Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iSize);
        Mos_FileRead(hFile,(_UC*)&stFileDes,iSize);
        if(stFileDes.ucCheckFlag == 'S')
        {
            MOS_SSCANF(stFileDes.aucEventName,"%*s_%*u_%*u_%d",&Event_GetMng()->uiCurrentNum);
        }
        Mos_FileClose(hFile);
    }

    MOS_VSNPRINTF(stFileDes.aucEventName,32,"%04hu%02hu%02hu%02hu%02hu%02hu_%u_%u_%d",stSysTime.usYear,stSysTime.usMonth,
        stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond,uiKjIoTType,uiDuration,++Event_GetMng()->uiCurrentNum);

    stFileDes.cEventTime          = cEventTime;
    stFileDes.uiDuration          = uiDuration;
    stFileDes.uillKjIoTId         = 0;
    stFileDes.uiKjIoTType         = uiKjIoTType;
    stFileDes.uiKjIoTEventId      = uiKjIoTEventId;
    stFileDes.ucRsv[1]            = 1;
    stFileDes.ucCheckFlag         = 'S';
    stFileDes.ucBInUse            = 'Z';

    if(Mos_FileWriteAppend(aucFileName,(_UC*)&stFileDes, iSize) == MOS_FALSE){
        MOS_LOG_ERR(EVENT_LOG,"write file %s fail errno = %u",aucFileName,errno);
        return MOS_ERR;
    }
    return MOS_OK;
}
