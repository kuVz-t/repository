#ifndef _EVENT_PRV_H
#define _EVENT_PRV_H

#ifdef __cplusplus
extern "C" {
#endif

#define EVENT_LOG                               (_UC*)"ET"
#define EVENT_DIR                               (_UC*)"Event"
#define EVENT_DATECFG_NAME                      (_UC*)"EventDate.txt"
#define EVENT_FILEDES_NAME                      (_UC*)"Event.txt"
#define EVENT_DATECFG_VERSION                   (_UC*)"0001000100010001"
#define EVENT_FILEDESCFG_VERSION                (_UC*)"0001000100010001"

#define EVENT_AUTODELETE 7

typedef enum enum_EVENT_NODE_STATUS
{
    EN_EVENT_NODE_IDLE     = 0X00,
    EN_EVENT_NODE_START    = 0X01,
}EN_EVENT_NODE_STATUS;

typedef enum EN_EVENT_MSG{
    EN_EVENT_MSG_START      = 1,
    EN_EVENT_MSG_SETPATH    = 2,
    EN_EVENT_MSG_DELETE     = 3
}EN_EVENT_MSG;

typedef struct str_EVENTDATA_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UI uiKjIoTType;
    _LLID uillKjIoTId;
    _UI uiKjIoTEventId;
    _UI uiDuration;
    _CTIME_T tCreateTime;
}ST_EVENTDATA_MSG;

typedef struct str_EVENT_DELETE_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _INT iDeleteType;
    _UC aucDay[12];
    _UC aucTime[32];
    _UI uiKjIoTType;
    _LLID uillKjIoTId;
    _UI uiKjIoTEventId;
}ST_EVENT_DELETE_MSG;

typedef struct str_EVENT_SETPATH_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UC aucBuf[256];
}ST_EVENT_SETPATH_MSG;

typedef struct st_EVENT_INNODE
{
    _INT iStatus;
    _CTIME_T     cPushTime;
    ST_EVENT_INF stEventInf;
    ST_MOS_LIST_NODE stNode;
}ST_EVENT_INNODE;

typedef struct stru_Event_Task_Mng
{
    _INT iChangeFlag;
    _INT iChangePathFlag;
    _INT iStopAll;
    _INT iInitFlag;
    _INT iNum;
    _INT iCount;
    _UI uiCurrentNum;
    _UC aucDay[12];
    _UC aucFileName[256];
    _UC aucPathName[256];
    _HMUTEX hMutex;
    _HQUEUE hMsgQueue;
    ST_MOS_LIST stEventList;        // ST_EVENT_INNODE
}ST_EVENT_TASK_MNG;


#ifdef __cplusplus
}
#endif

#endif