#ifndef _EVENT_H
#define _EVENT_H

#ifdef __cplusplus
extern "C" {
#endif
typedef enum enum_event_delete_TYPE
{
    EN_EVENT_DAY     = 1,
    EN_EVENT_ONE     = 2
}EN_EVENT_DELETE_TYPE;

typedef struct st_event_inf
{
    _UC ucCheckFlag;
    _UC ucBInUse;
    _UC ucRsv[2];
    _UC aucEventName[32];
    _CTIME_T cEventTime;
    _UI uiKjIoTType; //设备类型
    _LLID uillKjIoTId;  //设备编号
    _UI uiKjIoTEventId;
    _UI uiDuration;
}ST_EVENT_INF;

typedef struct st_EVENT_DATE
{
    _UC ucCheck;
    _UC ucBInUse;
    _UC ucRsv[2];
    _UC aucDate[12];
}ST_EVENT_DATE;

typedef struct st_EVENT_DATENODE
{
    ST_EVENT_DATE stDate;
    ST_MOS_LIST_NODE stNode;
}ST_EVENT_DATENODE;

typedef struct st_EVENT_NODE
{
    ST_EVENT_INF stEventInf;
    ST_MOS_LIST_NODE stNode;
}ST_EVENT_NODE;
//初始化OK
_INT Event_Init();

//触发事件记录
_INT Event_AddOneItem(_UI uiKjIoTType,_LLID uillKjIoTId,_UI uiKjIoTEventId,_UI uiDuration,_CTIME_T tCreateTime);

//删除指定记录
_INT Event_DeleteItem(_INT iDeleteType,_UC *pucDay,_UC *pucTime,_UI uiKjIoTType,_LLID uillKjIoTId,_UI uiKjIoTEventId);

//查找有图片的日期OK
ST_MOS_LIST *Event_QueryCanlender(_UC *pucDay);

//获取当前时间点后给定数量个事件记录/xxxx-xx-xx xx:xx:xx
ST_MOS_LIST *Event_QueryInfoByTime(_UC *pucFromTime,_UI uiPageSize);

//获取指定类型给定数量个事件记录
ST_MOS_LIST *Event_QueryInfoByType(_UC *pucFromTime,_UI uiKjIoTType,_UI uiPageSize);

//销毁接口
_INT Event_Destory();

//设置存储路径
_INT Event_SetPath(_UC *pucBuf);//OK

_INT Event_IotTypeOutput(_UI uiAIIoTType, _LLID uiAIIoTID, _UC* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf);
_INT Event_IotTypeOutputEx(_UI uiAIIoTType, _LLID uiAIIoTID, _UC* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf);

_INT Event_AddCompatibleDate(_UC *pucDate);

_INT Event_AddCompatibleFile(_UC *pucDate,_CTIME_T cEventTime,_UI uiDuration,_UI uiKjIoTType,_UI uiKjIoTEventId);

#ifdef __cplusplus
}
#endif
#endif
