#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_type.h"

#include "qualityprobe_type_prv.h"
#include "qualityprobe_api.h"


ST_COUNT_RS gstCountStatics;

// 接口调用计数变量锁
_HMUTEX hCountIFMutex;


static char* apucQpInterfacePrint[]={
    "COUNT_TYPE_CLOUDSTORE",
    "COUNT_TYPE_OTA",
    "COUNT_TYPE_WIFICFG",
    "COUNT_TYPE_CMD",
    "COUNT_TYPE_VOD",
    "COUNT_TYPE_WARNING",
    "COUNT_TYPE_DEVREGISTER",
    "COUNT_TYPE_CLOUD_STOREFILE",
    "COUNT_TYPE_P2P_CALL"
};


/*******************************************************************************************************
    Private Function Prototypes
********************************************************************************************************/


/*******************************************************************************************************
    Exported Functions
********************************************************************************************************/
/* initial */
_INT Qp_CountIF_Init(void)
{
    Mos_MutexCreate(&hCountIFMutex);

    MOS_MEMSET(&gstCountStatics, 0, sizeof(ST_COUNT_RS));

    return MOS_OK;
}

// 清空统计计数
_INT Qp_CountIF_Clear(void)
{
    Mos_MutexLock(&hCountIFMutex);
    MOS_MEMSET(&gstCountStatics, 0, sizeof(ST_COUNT_RS));
    Mos_MutexUnLock(&hCountIFMutex);

    return MOS_OK;
}


// 读取统计计数
_INT Qp_CountIF_ReadClear(ST_COUNT_RS_PTR pstCountStatics)
{
    Mos_MutexLock(&hCountIFMutex);

    MOS_MEMCPY(pstCountStatics, &gstCountStatics, sizeof(ST_COUNT_RS));

    MOS_MEMSET(&gstCountStatics, 0, sizeof(ST_COUNT_RS));

    Mos_MutexUnLock(&hCountIFMutex);

    return MOS_OK;
}

// 由业务层埋点，相关业务启动时调用，统计相关业务调用情况
_INT Qp_CountIF_Post(EN_COUNT_TYPE emCountType, EN_COUNT_VALUE iCountResult,EN_COUNT_VALUE iCountLess2Result)
{
    // 仅在任务启动后接收统计计数，避免任务因无网络延迟启动，而计数未停止引起的技术不准
    if (0 == Qp_Task_GetTaskMng()->ucRunFlag)
    {
        MOS_PRINTF("qp count task is not running\n");

        return MOS_ERR;
    }

    Mos_MutexLock(&hCountIFMutex);
    
    MOS_PRINTF("call qp count task, type %s  iCountResult : %d  iCountLess2Result : %d\n",apucQpInterfacePrint[emCountType],iCountResult,iCountLess2Result);

    if (emCountType > (COUNT_TYPE_MAX_NUM - 1))
    {
        MOS_LOG_INF(QP_TASK, "para error emCountType[%d]", emCountType);
        Mos_MutexUnLock(&hCountIFMutex);
        return MOS_ERR;
    }

    if (COUNT_VALUE_SUCCESS == iCountResult)
    {
        gstCountStatics.iSuccessCnt[emCountType] ++;
        if (COUNT_VALUE_SUCCESS == iCountLess2Result)
        {
            gstCountStatics.iLess2Cnt[emCountType] ++;
        }    
    }
    else
    {
        gstCountStatics.iFailCnt[emCountType] ++;
    }

    gstCountStatics.iTotalCnt[emCountType] ++;

    Mos_MutexUnLock(&hCountIFMutex);

    return MOS_OK;
}
