#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_type.h"

#include "qualityprobe_type_prv.h"
#include "qualityprobe_api.h"

#include "kj_timer.h"
#include "watchdog_api.h"

#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

static ST_QP_TASK_MNG g_stQPTaskMng;


/*******************************************************************************************************
    Private Function Prototypes
********************************************************************************************************/


/*******************************************************************************************************
    Exported Functions
********************************************************************************************************/
ST_QP_TASK_MNG * Qp_Task_GetTaskMng()
{
    return &g_stQPTaskMng;
}

_INT Qp_Task_Loop(_VPTR pParam)
{

    //启动时候循环检测网络连接是否正常，异常则10s检测一次
    //否则等待网络正常后再启动发送流程
    while ((EN_ZJ_NETWORK_TYPE_NONET == Http_GetNetWorkType()) || (EN_ZJ_NETWORK_TYPE_AP == Http_GetNetWorkType()))
    {
        // 每10秒轮询一次
        Mos_Sleep(5*1000);
    }    
    MOS_LOG_INF(QP_TASK, "Qp_Task_Loop Start \n");

    ST_MOS_SYS_TIME minBeginTime;
    ST_MOS_SYS_TIME hourBeginTime;

    // 设置探测的起始时间点
    Mos_GetSysTime(&minBeginTime);
    Mos_GetSysTime(&hourBeginTime);

    _HSWDWRITE    hSwdQPFeedDog;
    kj_timer_t    tQPFeedDogTimeOut;
    hSwdQPFeedDog = Swd_AppThreadRegist(QP_CHECK_MNG, FEED_DOG_SUPER_MAXEX_TIMESEC);
    kj_timer_init(&tQPFeedDogTimeOut);
    getDiffTimems(&tQPFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);

    while (Qp_Task_GetTaskMng()->ucRunFlag)
    {
        // 软看门狗检测喂狗
        if (getDiffTimems(&tQPFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
        {
            Swd_AppThreadFeedDog(hSwdQPFeedDog);
            getDiffTimems(&tQPFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }
        
        Mos_Sleep(500);

        Qp_TaskCount_Entry(&minBeginTime, &hourBeginTime);
        
        Qp_TaskCheck_Entry();
        
        Qp_TaskAi_Entry();
        
    }
    
    /*在Qp_Task_Stop已释放*/
    // Mos_ThreadDelete(Qp_Task_GetTaskMng ()->hThread_quality);

    Swd_AppThreadUnRegist(hSwdQPFeedDog); 
    
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, -1, -1, "QualityProbe Qp_Task_Loop End", 1);
    MOS_LOG_ERR(QP_TASK, "Qp_Task_Loop End");
    
    return MOS_OK;
}

_INT Qp_Task_Init()
{
    MOS_LOG_INF(QP_TASK, "Init Start");
    if (Qp_Task_GetTaskMng()->ucInitFlag == 1)
    {        
        MOS_LOG_WARN(QP_TASK, "Already Init");    
        return MOS_OK;
    }
    
    MOS_MEMSET(&g_stQPTaskMng, 0, sizeof(ST_QP_TASK_MNG));

    Mos_MutexCreate(&Qp_Task_GetTaskMng()->hConfFileMutex);
    Mos_MutexCreate(&Qp_Task_GetTaskMng()->hCheckFileMutex);
    Mos_MutexCreate(&Qp_Task_GetTaskMng()->hAiFileMutex);

    // 巡检文件数据初始化
    Qp_Store_FileInitialize();

    // 任务相关信息初始化
    Qp_CountIF_Init();

    // 全部初始化完成，更新标记
    Qp_Task_GetTaskMng()->ucInitFlag = 1;
    
    MOS_LOG_INF(QP_TASK, "Init Successfully");
    
    return MOS_OK;
}

_INT Qp_Task_Start()
{
    if (0 == Qp_Task_GetTaskMng()->ucInitFlag)
    {
        MOS_LOG_ERR(QP_TASK, "Not Init");
        return MOS_ERR;
    }

    if (1 == Qp_Task_GetTaskMng()->ucRunFlag)
    {
        MOS_LOG_WARN(QP_TASK, "Already Start");  
        return MOS_OK;
    }
    
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE; // MOS_THREAD_STACK_HIGH_SIZE

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif

    // 读取工作参数
    MOS_LOG_INF(QP_TASK, "Start Read The Config File");
    if (MOS_ERR == Qp_Utils_Config_Read(&(Qp_Task_GetTaskMng()->stQpConfig)))
    {
        // 读取失败，设置默认参数并保存
        //新设备需要初始上报
        //小概率出现设备在停止上报的时间段内，配置文件被破坏，这时候就会异常上报数据
        //todo
        MOS_LOG_INF(QP_TASK, "The Config File Is Non-Existent,Need To Set Default Config");
        
        Qp_Task_GetTaskMng()->stQpConfig.uiQpDataPauseFlag = 0;      // 打开上报
        Qp_Task_GetTaskMng()->stQpConfig.cQpPauseTimestamp = Mos_Time();      //停止上报的截止时间点

        Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckModeCtrl = 0;    // 默认发送巡检请求报文
        Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.uiCheckDataCycleTime = 0;    // 巡检周期，默认0小时，不上报数据

        MOS_MEMSET(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataCloud, 0, DEFAULT_URL_LEN);
        MOS_STRCPY(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataCloud, "beta.ehome.21cn.com");

        MOS_MEMSET(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget, 0, DEFAULT_URL_LEN);
        MOS_STRCPY(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget, "www.baidu.com");

        MOS_MEMSET(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID, 0, sizeof(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID));
        MOS_STRCPY(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID, "000000");  // 默认归属地为全国

        Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl = 0;   // 归属地有效期由服务器配置，默认设置为0天

        Mos_MutexLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
        if (MOS_OK != Qp_Utils_Config_Write(&(Qp_Task_GetTaskMng()->stQpConfig)))
        {
            MOS_LOG_ERR(QP_TASK, "Set Default Config Failed");
        }
        Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
    }
    MOS_LOG_INF(QP_TASK, "Read The Config File Fished");

    Qp_Task_GetTaskMng()->ucRunFlag = 1;
    if (Mos_ThreadCreate(QP_TASK, EN_THREAD_PRIORITY_NORMAL, uiStackSize,
                        Qp_Task_Loop, MOS_NULL, MOS_NULL, &Qp_Task_GetTaskMng()->hThread_quality) == MOS_ERR)
    {
        Qp_Task_GetTaskMng()->ucRunFlag = 0;
        MOS_LOG_ERR(QP_TASK, "Create Qp_Task_Loop Failed");
        return MOS_ERR;
    }
    
    return MOS_OK;
}

_INT Qp_Task_Stop()
{
    if (Qp_Task_GetTaskMng()->ucRunFlag == 1)
    {
        Qp_Task_GetTaskMng()->ucRunFlag = 0;
        Mos_ThreadDelete(Qp_Task_GetTaskMng()->hThread_quality);
        Qp_Task_GetTaskMng()->hThread_quality = MOS_NULL;
        MOS_LOG_INF(QP_TASK, "task stop ok");
    }
    else
    {
        MOS_LOG_WARN(QP_TASK, "Already Stop");  
        return MOS_ERR;
    }

    return MOS_OK;
}

_INT Qp_Task_Destroy()
{
    //判断destory之前有没有stop
    if (Qp_Task_GetTaskMng()->ucRunFlag == 1)
    {
        //手动调用停止
    }
    
    if (Qp_Task_GetTaskMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(QP_TASK, "Already Destroy");  
        return MOS_OK;
    }
    
    Mos_MutexDelete(&Qp_Task_GetTaskMng()->hConfFileMutex);
    Mos_MutexDelete(&Qp_Task_GetTaskMng()->hCheckFileMutex);
    Mos_MutexDelete(&Qp_Task_GetTaskMng()->hAiFileMutex);

    MOS_MEMSET(&g_stQPTaskMng, 0, sizeof(ST_QP_TASK_MNG));
    Qp_Task_GetTaskMng()->ucInitFlag = 0;
    MOS_LOG_INF(QP_TASK, "task destroy ok");
    
    return MOS_OK;
}
