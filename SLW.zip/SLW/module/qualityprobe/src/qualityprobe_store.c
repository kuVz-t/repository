#include "mos.h"

#include "qualityprobe_api.h"
#include "qualityprobe_type_prv.h"

_INT Qp_Store_GetFileRecordsNumBydir(_UC *outRecdCnt,_UC* inFileDir){  
    _INT retV = MOS_ERR;

    _HFILE * pFile;
    _INT tempSize=0;
    _INT structSize= 0;
    pFile = Mos_FileOpen (inFileDir,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if ( pFile!=MOS_NULL ){
        tempSize = Mos_FileSize(pFile);
        structSize = sizeof(ST_QP_MSG);
        //MOS_LOG_INF(QP_STORE,"filesize : %d+++++++++++++struct size : %d\n",tempSize,structSize);
        if (0 != structSize){
            *outRecdCnt =  tempSize/(sizeof(ST_QP_MSG));
        }
        Mos_FileClose(pFile);
        retV = MOS_OK;
    }else{
        MOS_LOG_INF(QP_STORE,"file %s open failed",inFileDir);
    }
    return retV;
}

_INT Qp_Store_GetAIRecordsNumBydir(_UC *outRecdCnt,_UC* inFileDir){  
    _INT retV = MOS_ERR;

    _HFILE * pFile;
    _INT tempSize=0;
    _INT structSize= 0;
    pFile = Mos_FileOpen (inFileDir,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if ( pFile!=MOS_NULL ){
        tempSize = Mos_FileSize(pFile);
        structSize = sizeof(ST_QP_AI_INSECPTION_MSG);
        if (0 != structSize){
            *outRecdCnt =  tempSize/(sizeof(ST_QP_AI_INSECPTION_MSG));
        }
        Mos_FileClose(pFile);
        retV = MOS_OK;
    }else{
        MOS_LOG_INF(QP_STORE,"file %s open failed",inFileDir);
    }
    return retV;
}


_INT Qp_Store_ClearFile(_UC* inFileDir)
{
    _INT retV = MOS_ERR;
    _HFILE * pFile;
    pFile = Mos_FileOpen (inFileDir,MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);
    if ( pFile!=MOS_NULL ){
        MOS_LOG_INF(QP_STORE,"clear file %s success\n",inFileDir);
        Mos_FileClose(pFile);
        retV = MOS_OK;
    }else{        
        MOS_LOG_INF(QP_STORE,"clear file %s failed\n",inFileDir);
    }
    return retV;
}


_INT Qp_Store_DeleteFileContenBySizeADir(_UC* pucFileDir,_UC ucDeleteNum){  
    _INT retV = MOS_ERR;
    _UI filesize = 0;
    _UI clrBuffSize = 0;
    _HFILE *fileP = MOS_NULL;
    _HFILE *fp = MOS_NULL;
    _UC *buf = MOS_NULL;

    clrBuffSize = (_UI)ucDeleteNum*sizeof(ST_QP_MSG);
    //检测文件是否能够正常打开
    fileP = Mos_FileOpen(pucFileDir,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if (fileP == MOS_NULL){
        return retV;
    }
    else{
        filesize = Mos_FileSize(fileP);
        if (filesize > MSG_CHECK_MAX_STORE_SIZE){
            filesize = MSG_CHECK_MAX_STORE_SIZE;
        }
        MOS_LOG_INF(QP_STORE,"filesize : %d\n",filesize);
        Mos_FileClose(fileP);
    }
    
    if (filesize>clrBuffSize){    
        //每读取一行，都将内容放到该数组中
        buf = (_UC *)MOS_MALLOC(MSG_CHECK_MAX_STORE_SIZE);
        if (buf == MOS_NULL){
            MOS_LOG_INF(QP_STORE,"malloc failed\n");
            return retV;
        }
        
        //filepath里是原内容
        fp = Mos_FileOpen(pucFileDir,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
        if (fp !=MOS_NULL){
            //跳过前clrSize条数据
            MOS_MEMSET(buf, 0, MSG_CHECK_MAX_STORE_SIZE);
            Mos_FileSeek(fp, MOS_FILE_SEEK_BEGIN, clrBuffSize);
            Mos_FileRead(fp, buf, filesize-clrBuffSize);
            Mos_FileClose(fp);
            //clr old file
//            fp = Mos_FileOpen(pFileDir,MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);
//            Mos_FileClose(fp);
            //buf to empty file
            fp = Mos_FileOpen(pucFileDir,MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);            
            Mos_FileWrite(fp, buf,filesize-clrBuffSize);
            Mos_FileClose(fp);
            retV = MOS_OK;
        }
        MOS_FREE(buf);            
    
    }
    else if (filesize== clrBuffSize){  //相等直接清空            
        fp = Mos_FileOpen(pucFileDir,MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);
        Mos_FileClose(fp);
        retV = MOS_OK;
    }
    Qp_Task_GetTaskMng()->Records_check -= ucDeleteNum;
    return retV;    
}


_INT Qp_Store_DeleteAIContenBySizeADir(_UC* pucFileDir,_UC ucDeleteNum){  
    _INT retV = MOS_ERR;
    _UI filesize = 0;
    _UI clrBuffSize = 0;
    _HFILE *fileP = MOS_NULL;
    _HFILE *fp = MOS_NULL;
    _UC *buf = MOS_NULL;

    clrBuffSize = (_UI)ucDeleteNum*sizeof(ST_QP_AI_INSECPTION_MSG);
    //检测文件是否能够正常打开
    fileP = Mos_FileOpen(pucFileDir,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if (fileP == MOS_NULL){
        return retV;
    }
    else{
        filesize = Mos_FileSize(fileP);
        if (filesize > MSG_AI_REQUEST_MAX_STORE_SIZE){
            filesize = MSG_AI_REQUEST_MAX_STORE_SIZE;
        }
        MOS_LOG_INF(QP_STORE,"filesize : %d",filesize);
        Mos_FileClose(fileP);
    }
    
    if (filesize>clrBuffSize){    
        //每读取一行，都将内容放到该数组中
        buf = (_UC *)MOS_MALLOC(MSG_AI_REQUEST_MAX_STORE_SIZE);
        if (buf == MOS_NULL){
            MOS_LOG_INF(QP_STORE,"malloc failed\n");
            return retV;
        }
        
        //filepath里是原内容
        fp = Mos_FileOpen(pucFileDir,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
        if (fp !=MOS_NULL){
            //跳过前clrSize条数据
            MOS_MEMSET(buf, 0, MSG_AI_REQUEST_MAX_STORE_SIZE);
            Mos_FileSeek(fp, MOS_FILE_SEEK_BEGIN, clrBuffSize);
            Mos_FileRead(fp, buf, filesize-clrBuffSize);
            Mos_FileClose(fp);
            //clr old file
//            fp = Mos_FileOpen(pFileDir,MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);
//            Mos_FileClose(fp);
            //buf to empty file
            fp = Mos_FileOpen(pucFileDir,MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);            
            Mos_FileWrite(fp, buf,filesize-clrBuffSize);
            Mos_FileClose(fp);
            retV = MOS_OK;
        }
        MOS_FREE(buf);            
    
    }
    else if (filesize== clrBuffSize){  //相等直接清空            
        fp = Mos_FileOpen(pucFileDir,MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);
        Mos_FileClose(fp);
        retV = MOS_OK;
    }
    Qp_Task_GetTaskMng()->Records_ai -= ucDeleteNum;
    MOS_LOG_INF(QP_STORE,"remains record num %d",Qp_Task_GetTaskMng()->Records_ai);
    return retV;    
}


static _INT Qp_Store_CheckDataSt2Filebuff(ST_QP_MSG* inRecrdSt,_UC* retBuff){  
    MOS_MEMCPY(retBuff, inRecrdSt, sizeof(ST_QP_MSG));    
    return MOS_OK;
}

static _INT Qp_Store_Filebuff2CheckDataSt(_UC* inBuff,ST_QP_MSG* retRecrdSt){  
    MOS_MEMCPY(retRecrdSt, inBuff, sizeof(ST_QP_MSG));    
    return MOS_OK;
}

static _INT Qp_Store_AIDataSt2Filebuff(ST_QP_AI_INSECPTION_MSG* inRecrdSt,_UC* retBuff){  
    MOS_MEMCPY(retBuff, inRecrdSt, sizeof(ST_QP_AI_INSECPTION_MSG));    
    return MOS_OK;
}

static _INT Qp_Store_Filebuff2AIDataSt(_UC* inBuff,ST_QP_AI_INSECPTION_MSG* retRecrdSt){  
    MOS_MEMCPY(retRecrdSt, inBuff, sizeof(ST_QP_AI_INSECPTION_MSG));    
    return MOS_OK;
}


_INT Qp_Store_FileInitialize(){
    _INT retV = MOS_OK;
    _INT iCheckFileSize = 0;
    _INT iAIFileSize = 0;
//    _INT iOffset;
//    _INT iStructSize;
    _HFILE *fileP,*fileCreateP;
    _UC tempName[QP_CHECK_FILE_MAX_LEN];

    //1、检查文件存储路径，不存在创建    
    MOS_MEMSET(tempName, 0, QP_CHECK_FILE_MAX_LEN);
    MOS_VSNPRINTF(tempName, QP_CHECK_FILE_MAX_LEN, "%s/%s", Mos_GetWorkPath(), QP_FOLDER);
    tempName[QP_CHECK_FILE_MAX_LEN - 1] = 0;
    if ( MOS_FALSE ==Mos_DirIsExist((_UC*)tempName)){
        Mos_DirMake((_UC*)tempName, MOS_DIR_MAKE_FLAG);
    }


    //2、创建巡检日志存储文件
    MOS_MEMSET(tempName, 0, QP_CHECK_FILE_MAX_LEN);
    MOS_VSNPRINTF(tempName, QP_CHECK_FILE_MAX_LEN, "%s/%s", Mos_GetWorkPath(), QP_CHECK_FILENAME);
    tempName[QP_CHECK_FILE_MAX_LEN - 1] = 0;
    
    //记录巡检数据存储文件位置
    MOS_MEMCPY(Qp_Task_GetTaskMng()->aucCheckDataFileName, tempName, QP_CHECK_FILE_MAX_LEN);

    //检测巡检数据文件是否能正常打开
    fileP = Mos_FileOpen(tempName, MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if (fileP == MOS_NULL){ 
        //配置文件打开失败，则创建新文件
        fileCreateP = Mos_FileOpen(tempName, MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);
        if (fileCreateP == MOS_NULL){
            MOS_LOG_INF(QP_TASK,"%s create failed.\n", tempName);
            retV = MOS_ERR;
            //return MOS_ERR;
        }else{
            Mos_FileClose(fileCreateP);
            MOS_LOG_INF(QP_TASK,"%s is created.\n", tempName);
        }
    }
    else{
        iCheckFileSize = Mos_FileSize(fileP);
        Mos_FileClose(fileP);
        MOS_LOG_INF(QP_TASK,"file %s no created.\n", tempName);  
    }

    //计算文件中存储的巡检数据个数
    Qp_Task_GetTaskMng()->Records_check = iCheckFileSize/sizeof(ST_QP_MSG);
    MOS_LOG_INF(QP_TASK,"file %s has %d check records, filesize %d", tempName,Qp_Task_GetTaskMng()->Records_check,iCheckFileSize);

    //3、创建AI画面巡检请求数据存储文件
    MOS_MEMSET(tempName, 0, QP_CHECK_FILE_MAX_LEN);
    MOS_VSNPRINTF(tempName, QP_CHECK_FILE_MAX_LEN, "%s/%s", Mos_GetWorkPath(), QP_AI_INSECPTION_FILENAME);
    tempName[QP_CHECK_FILE_MAX_LEN - 1] = 0;
    
    //记录AI画面巡检数据存储文件位置
    MOS_MEMCPY(Qp_Task_GetTaskMng()->aucAIInsecptionDataFileName, tempName, QP_CHECK_FILE_MAX_LEN);

    //检测AI画面巡检数据文件是否能正常打开
    fileP = Mos_FileOpen(tempName, MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if (fileP == MOS_NULL){ 
        //配置文件打开失败，则创建新文件
        fileCreateP = Mos_FileOpen(tempName, MOS_FILE_O_WRONLY|MOS_FILE_O_BIN);
        if (fileCreateP == MOS_NULL){
            MOS_LOG_INF(QP_TASK,"%s create failed.\n", tempName);
            retV = MOS_ERR;
            //return MOS_ERR;
        }else{
            Mos_FileClose(fileCreateP);
            MOS_LOG_INF(QP_TASK,"%s is created.\n", tempName);
        }
    }
    else{
        iAIFileSize = Mos_FileSize(fileP);
        Mos_FileClose(fileP);
        MOS_LOG_INF(QP_TASK,"file %s no created.\n", tempName);  
    }

    //计算文件中存储的巡检数据个数
    Qp_Task_GetTaskMng()->Records_ai = iAIFileSize/sizeof(ST_QP_AI_INSECPTION_MSG);
    MOS_LOG_INF(QP_TASK,"file %s has %d ai request records, filesize %d", tempName,Qp_Task_GetTaskMng()->Records_ai,iAIFileSize);


    return retV;    
}

_INT Qp_Store_WriteCheckDataByDir(ST_QP_MSG * pstQPMsgNode, _UC* saveFileDir){
    _INT retV = MOS_ERR;
    _HFILE * pFile = MOS_NULL;
    _UI correctPos;
    _UI structsize;
    _UC* pstMsgNodeBuf = (_UC*)MOS_MALLOCCLR(sizeof(ST_QP_MSG)+10);
    
    //将结构体转换为字节流
    Qp_Store_CheckDataSt2Filebuff(pstQPMsgNode,pstMsgNodeBuf);

    //打开文件进行写入
    //Cos_MutexLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);

    //获取当前的巡检数据的条数
    Qp_Store_GetFileRecordsNumBydir(&Qp_Task_GetTaskMng()->Records_check, saveFileDir);
    MOS_LOG_INF(QP_STORE,"check data records : %d",Qp_Task_GetTaskMng()->Records_check);
     
    //判断文件是否能够正确创建/打开 
    pFile = Mos_FileOpen(saveFileDir,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if ( pFile == MOS_NULL ){  
         MOS_LOG_INF(QP_STORE,"open file error!:%s",saveFileDir);
         MOS_LOG_INF(QP_STORE,"save check record info failed! %s\n\r",saveFileDir);
    }     
    else{
        //判断缓存巡检数据是不是达到上限,到达则移除最旧的
        //预留一个做缓存
        if ( Qp_Task_GetTaskMng()->Records_check >= MSG_QUEUE_CHECK_MAX_SIZE)
        {
            Mos_FileClose(pFile);
            //删除第一个,确保最旧的记录在第一个
            Qp_Store_DeleteFileContenBySizeADir(saveFileDir,1);
            MOS_LOG_INF(QP_STORE,"remove oldest records");
            //重新打开文件进行新数据写入
            pFile = Mos_FileOpen(saveFileDir,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
            if (pFile == MOS_NULL){
                MOS_LOG_INF(QP_STORE,"open file error!:%s\n\r",saveFileDir);
                MOS_LOG_INF(QP_STORE,"save check record info failed! %s\n\r",saveFileDir);
                MOS_FREE(pstMsgNodeBuf);
                return MOS_ERR;
            }
        }
        
         //计算该节点需要写入到文件中的位置
        structsize = sizeof(ST_QP_MSG);
        correctPos = Mos_FileSize(pFile);
        //检测文件内数据数量是否是整数个结构体大小
        if (0 != (correctPos%structsize))
        {
            MOS_LOG_WARN(QP_STORE,"abnormal:correctPos offset:%d in file:%s\n\r",correctPos%sizeof(ST_QP_MSG),saveFileDir);    
            //修正写入位置
            correctPos= (correctPos/sizeof(ST_QP_MSG))*sizeof(ST_QP_MSG);
        }
        Mos_FileSeek(pFile,MOS_FILE_SEEK_BEGIN, correctPos);
        Mos_FileWrite(pFile, pstMsgNodeBuf, sizeof(ST_QP_MSG));
        //写入成功，巡检数据数量加一
        Qp_Task_GetTaskMng()->Records_check++;
        Mos_FileClose(pFile);
        MOS_LOG_INF(QP_STORE,"save check record info in file! %s",saveFileDir);
        retV = MOS_OK;
    }
    //Cos_MutexUnLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);
    MOS_FREE(pstMsgNodeBuf);
    return retV;
}

_INT Qp_Store_ReadCheckDataByDir(ST_QP_MSG * pstMsgNode, _INT index, _UC* fileDir){
    _HFILE * pFile = MOS_NULL;
    _INT iCorrectPos = 0;
    _INT iStructSize = 0;
    _INT iFileSize = 0;
    _UC* pstMsgNodeBuf = MOS_NULL;

    //判断index的合法性
    if (index > Qp_Task_GetTaskMng()->Records_check){
        MOS_LOG_INF(QP_STORE,"index exceed check record num");
        return MOS_ERR;
    }
    
    if (index <= 0 ){
        MOS_LOG_INF(QP_STORE,"index is illgeal, %d",index);
        return MOS_ERR;
    }

    
    //判断文件是否能够正确打开 
    pFile = Mos_FileOpen(fileDir,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if ( pFile == MOS_NULL ){  
         MOS_LOG_INF(QP_STORE,"open file error!:%s",fileDir);
         return MOS_ERR;
    }     
    else{    
         //计算index需要在文件中读取的位置
        iStructSize = sizeof(ST_QP_MSG);
        iFileSize = Mos_FileSize(pFile);
        iCorrectPos = (index -1)*iStructSize;
        //准备读取数据
        pstMsgNodeBuf = (_UC*)MOS_MALLOCCLR(sizeof(ST_QP_MSG)+10);
        Mos_FileSeek(pFile,MOS_FILE_SEEK_BEGIN, iCorrectPos);
        //todo
        //若文件内容被破坏，数据损坏，平台会处理异常，设备会一直重试，直到数据被清除
        Mos_FileRead(pFile, pstMsgNodeBuf, sizeof(ST_QP_MSG));
        //将字节流转换为结构体
        Qp_Store_Filebuff2CheckDataSt(pstMsgNodeBuf, pstMsgNode);
        MOS_FREE(pstMsgNodeBuf);
        Mos_FileClose(pFile);
        MOS_LOG_INF(QP_STORE,"read check record info success");
    }
    return MOS_OK;
}

_INT Qp_Store_WriteAIDataByDir(ST_QP_AI_INSECPTION_MSG * pstQPMsgNode, _UC* saveFileDir){
    _INT retV = MOS_ERR;
    _HFILE * pFile = MOS_NULL;
    _UI correctPos;
    _UI structsize;
    _UC* pstMsgNodeBuf = (_UC*)MOS_MALLOCCLR(sizeof(ST_QP_AI_INSECPTION_MSG)+10);
    
    //将结构体转换为字节流
    Qp_Store_AIDataSt2Filebuff(pstQPMsgNode,pstMsgNodeBuf);

    //获取当前的AI请求数据的条数
    Qp_Store_GetAIRecordsNumBydir(&Qp_Task_GetTaskMng()->Records_ai, saveFileDir);
    MOS_LOG_INF(QP_STORE,"ai request data records : %d",Qp_Task_GetTaskMng()->Records_ai);
     
    //判断文件是否能够正确创建/打开 
    pFile = Mos_FileOpen(saveFileDir,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if ( pFile == MOS_NULL ){  
         MOS_LOG_INF(QP_STORE,"open file error!:%s",saveFileDir);
         MOS_LOG_INF(QP_STORE,"save check record info failed! %s\n\r",saveFileDir);
    }     
    else{
        //判断缓存数据是不是达到上限,到达则移除最旧的
        //预留一个做缓存
        if ( Qp_Task_GetTaskMng()->Records_ai >= MSG_QUEUE_AI_REQUEST_MAX_SIZE)
        {
            Mos_FileClose(pFile);
            //ai请求数据的发送状态重置为未发送
            Qp_Task_GetTaskMng()->stAIInsecptionTransMgr.uiPostStep = EN_QP_STATE_ASYNC_POST_RESET;
            //删除第一个,确保最旧的记录在第一个
            Qp_Store_DeleteAIContenBySizeADir(saveFileDir,1);
            MOS_LOG_INF(QP_STORE,"remove oldest ai request records");
            //重新打开文件进行新数据写入
            pFile = Mos_FileOpen(saveFileDir,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
            if (pFile == MOS_NULL){
                MOS_LOG_INF(QP_STORE,"open file error!:%s\n\r",saveFileDir);
                MOS_LOG_INF(QP_STORE,"save check record info failed! %s\n\r",saveFileDir);
                MOS_FREE(pstMsgNodeBuf);
                return MOS_ERR;
            }
        }
        
         //计算该节点需要写入到文件中的位置
        structsize = sizeof(ST_QP_AI_INSECPTION_MSG);
        correctPos = Mos_FileSize(pFile);
        //检测文件内数据数量是否是整数个结构体大小
        if (0 != (correctPos%structsize))
        {
            MOS_LOG_WARN(QP_STORE,"abnormal:correctPos offset:%d in file:%s\n\r",correctPos%sizeof(ST_QP_AI_INSECPTION_MSG),saveFileDir);    
            //修正写入位置
            correctPos= (correctPos/sizeof(ST_QP_AI_INSECPTION_MSG))*sizeof(ST_QP_AI_INSECPTION_MSG);
        }
        Mos_FileSeek(pFile,MOS_FILE_SEEK_BEGIN, correctPos);
        Mos_FileWrite(pFile, pstMsgNodeBuf, sizeof(ST_QP_AI_INSECPTION_MSG));
        //写入成功，ai请求数据数量加一
        Qp_Task_GetTaskMng()->Records_ai++;
        Mos_FileClose(pFile);
        MOS_LOG_INF(QP_STORE,"save ai request record info in file! %s",saveFileDir);
        retV = MOS_OK;
    }
    MOS_FREE(pstMsgNodeBuf);
    return retV;
}


_INT Qp_Store_ReadAIDataByDir(ST_QP_AI_INSECPTION_MSG * pstMsgNode, _INT index, _UC* fileDir){
    _HFILE * pFile = MOS_NULL;
    _INT iCorrectPos = 0;
    _INT iStructSize = 0;
    _INT iFileSize = 0;
    _UC* pstMsgNodeBuf = MOS_NULL;

    //判断index的合法性
    if (index > Qp_Task_GetTaskMng()->Records_ai){
        MOS_LOG_INF(QP_STORE,"index exceed ai request record num");
        return MOS_ERR;
    }
    
    if (index <= 0 ){
        MOS_LOG_INF(QP_STORE,"index is illgeal, %d",index);
        return MOS_ERR;
    }

    
    //判断文件是否能够正确打开 
    pFile = Mos_FileOpen(fileDir,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if ( pFile == MOS_NULL ){  
         MOS_LOG_INF(QP_STORE,"open file error!:%s",fileDir);
         return MOS_ERR;
    }     
    else{    
         //计算index需要在文件中读取的位置
        iStructSize = sizeof(ST_QP_AI_INSECPTION_MSG);
        iFileSize = Mos_FileSize(pFile);
        iCorrectPos = (index -1)*iStructSize;
        //准备读取数据
        pstMsgNodeBuf = (_UC*)MOS_MALLOCCLR(sizeof(ST_QP_AI_INSECPTION_MSG)+10);
        Mos_FileSeek(pFile,MOS_FILE_SEEK_BEGIN, iCorrectPos);
        //todo
        //若文件内容被破坏，数据损坏，平台会处理异常，设备会一直重试，直到数据被清除
        Mos_FileRead(pFile, pstMsgNodeBuf, sizeof(ST_QP_AI_INSECPTION_MSG));
        //将字节流转换为结构体
        Qp_Store_Filebuff2AIDataSt(pstMsgNodeBuf, pstMsgNode);
        MOS_FREE(pstMsgNodeBuf);
        Mos_FileClose(pFile);
        MOS_LOG_INF(QP_STORE,"read ai request record info success");
    }
    return MOS_OK;
}

