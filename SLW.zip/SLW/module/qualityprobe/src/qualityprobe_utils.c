#include "mos.h"
#include "zj_interface.h"
#include "adpt_crypto_adapt.h"
#include "config_api.h"

#include "qualityprobe_api.h"
#include "qualityprobe_type_prv.h"

#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

#include <errno.h>
#include <netinet/ip_icmp.h>
#include <netdb.h>

#define DNS_RETRY_TIME              3
#define SEND_TIMEOUT_SEC            3

#define ICMP_DATA_LEN    56         //ICMP默认数据长度
#define ICMP_HEAD_LEN    8          //ICMP默认头部长度
#define ICMP_LEN         (ICMP_DATA_LEN + ICMP_HEAD_LEN)
#define SEND_BUFFER_SIZE 128        //发送缓冲区大小
#define RECV_BUFFER_SIZE 128        //接收缓冲区大小

typedef struct stru_QP_PING_INFO
{
    _UI iMin;
    _UI iAvg;
    _UI iMax;
    _UI iMdev;
    _INT iSend;
    _INT iRecv;
    _INT iSock_icmp;
    _C SendBuffer[SEND_BUFFER_SIZE];
    _C RecvBuffer[RECV_BUFFER_SIZE];
    struct timeval FirstSendTime;
    struct timeval LastRecvTime;   
}ST_QP_PING_INFO;

_UI Qp_utils_Compute_cksum(struct icmp *pIcmp)
{
    _US *usData = (_US *)pIcmp;
    _INT iLen   = ICMP_LEN;
    _UI iSum    = 0;

    while (iLen > 1)
    {
        iSum += *usData++;
        iLen -= 2;
    }
    if (1 == iLen)
    {
        _US tmp = *usData;
        tmp &= 0xff00;
        iSum += tmp;
    }
 
    //ICMP校验和带进位
    while (iSum >> 16)
    {
        iSum = (iSum >> 16) + (iSum & 0x0000ffff);
    }  
    iSum = ~iSum;
    
    return iSum;
}

_INT Qp_utils_SetICMP(ST_QP_PING_INFO *stPingInfo)
{
    struct icmp *pIcmp;
    struct timeval *pTime;

    pIcmp = (struct icmp*)stPingInfo->SendBuffer;

    /* 类型和代码分别为ICMP_ECHO,0代表请求回送 */
    pIcmp->icmp_type = ICMP_ECHO;
    pIcmp->icmp_code = 0;
    pIcmp->icmp_cksum = 0;      //校验和
    pIcmp->icmp_seq = stPingInfo->iSend;     //序号
    pIcmp->icmp_id = getpid();  //取进程号作为标志
    pTime = (struct timeval *)pIcmp->icmp_data;
    gettimeofday(pTime, NULL);  //数据段存放发送时间
    pIcmp->icmp_cksum = Qp_utils_Compute_cksum(pIcmp);
    
    if (1 == stPingInfo->iSend)
    {
        stPingInfo->FirstSendTime = *pTime;
    }
    return MOS_OK;
}
 
_INT Qp_utils_SendPacket(ST_QP_PING_INFO *stPingInfo, struct sockaddr_in *dest_addr)
{
    Qp_utils_SetICMP(stPingInfo);
    if (sendto(stPingInfo->iSock_icmp, stPingInfo->SendBuffer, ICMP_LEN, 0,
        (struct sockaddr *)dest_addr, sizeof(struct sockaddr_in)) < 0)
    {
        MOS_LOG_ERR(QP_TASK, "Packet Sendto Failed");
        return MOS_ERR;
    }
        
    return MOS_OK;
}

_UI Qp_utils_GetRtt(struct timeval *RecvTime, struct timeval *SendTime)
{
    struct timeval subtime = *RecvTime;

    if ((subtime.tv_usec -= SendTime->tv_usec) < 0)
    {
        --(subtime.tv_sec);
        subtime.tv_usec += 1000000;
    }
    subtime.tv_sec -= SendTime->tv_sec;

    return subtime.tv_sec * 1000 + subtime.tv_usec / 1000; //转换单位为毫秒
}

_INT Qp_utils_Unpack(ST_QP_PING_INFO *stPingInfo)
{
    struct ip *Ip = (struct ip *)stPingInfo->RecvBuffer;
    struct icmp *Icmp;
    _INT ipHeadLen = 0;
    _UI  iRtt = 0;

    ipHeadLen = Ip->ip_hl << 2;	//ip_hl字段单位为4字节
    Icmp = (struct icmp *)(stPingInfo->RecvBuffer + ipHeadLen);
 
    //判断接收到的报文是否是自己所发报文的响应
    if ((Icmp->icmp_type == ICMP_ECHOREPLY) && Icmp->icmp_id == (unsigned short)getpid())
    {
        struct timeval *SendTime = (struct timeval *)Icmp->icmp_data;
        iRtt = Qp_utils_GetRtt(&stPingInfo->LastRecvTime, SendTime);
        if (iRtt < stPingInfo->iMin || 0 == stPingInfo->iMin)
        {
            stPingInfo->iMin = iRtt;
        }
        if (iRtt > stPingInfo->iMax)
        {
            stPingInfo->iMax = iRtt;
        }
        stPingInfo->iAvg += iRtt;
        stPingInfo->iMdev += iRtt * iRtt;

        return MOS_OK;
    }
    return MOS_ERR;
}

_INT Qp_utils_RecvPacket(ST_QP_PING_INFO *stPingInfo, struct sockaddr_in *dest_addr)
{
    _INT iRecvBytes = 0;
    _INT iAddrlen   = sizeof(struct sockaddr_in);
    struct timeval RecvTime;
    
    if ((iRecvBytes = recvfrom(stPingInfo->iSock_icmp, stPingInfo->RecvBuffer, RECV_BUFFER_SIZE, 0, (struct sockaddr *)dest_addr, &iAddrlen)) < 0)
    {
        MOS_LOG_ERR(QP_TASK, "Packet Recvfrom Failed");
        return -2;
    }
    gettimeofday(&RecvTime, NULL);
    stPingInfo->LastRecvTime = RecvTime;

    if (Qp_utils_Unpack(stPingInfo) == MOS_ERR)
    {
        return MOS_ERR; 
    }
    stPingInfo->iRecv++;
    return MOS_OK;
}

_INT Qp_utils_ResetValue(ST_QP_PING_INFO *stPingInfo)
{
    MOS_MEMSET(stPingInfo,0,sizeof(ST_QP_PING_INFO));
    stPingInfo->iSend = 1;
    return MOS_OK;
}

/*******************************************************************************************************
    Private Function Prototypes
********************************************************************************************************/
static _UC Qp_utils_Num2Char(_UC num)
{
    if (num >= 0 && num <= 9)
    {
        return num+'0';
    }
    if (num >= 10 && num <= 15)
    {
        return num+'a'-10;
    }
    return '0';
}


/*******************************************************************************************************
    Exported Functions
********************************************************************************************************/
//ret 0:timeout, -1: no timeout  other value: use not succeed 
_INT Qp_utils_TimeCompare(ST_MOS_SYS_TIME compUseT, ST_MOS_SYS_TIME currentT, long compareValue)
{ 
    _INT retV = MOS_ERR;
    long converV_compUseT;
    long converV_currentT;

    converV_compUseT = (long)Mos_SysTimetoTime(&compUseT);
    converV_currentT = (long)Mos_SysTimetoTime(&currentT);

    if ( converV_currentT - converV_compUseT > compareValue )
    {
        retV = MOS_OK;
    }

    return retV;
}

_INT Qp_utils_DNSParse(_UC * pucUrl, _UC * pucIp)
{
    _INT iRet;
    _INT i;

    _BOOL boolWait;
    ST_MOS_INET_IPARRAY stIpArrayInfo;

    //dns解析重试
    _UC dnsRryCnt = 0;
    _BOOL boolDnsResolve = MOS_FALSE;


    if ((MOS_NULL == pucUrl) || (MOS_NULL == pucIp))
    {
        MOS_LOG_ERR(QP_TASK, "dns parse paras error");

        return MOS_ERR;
    }

    //解析服务器网址
    do{
        dnsRryCnt++;
        iRet = Mos_InetGetHostByName((_UC*)pucUrl, &stIpArrayInfo, &boolWait);
        if (MOS_OK != iRet)
        {
            MOS_LOG_INF(QP_TASK, "[%d] : Get host by name failed, host: %s", dnsRryCnt, pucUrl);
            if (dnsRryCnt >= DNS_RETRY_TIME )
            {
                return MOS_ERR;
            }else
            {
                continue;
            }       
        }

        //解析成功
        boolDnsResolve = MOS_TRUE;
        for (i = 0; i < stIpArrayInfo.uiCount; i++)
        {
            if (stIpArrayInfo.astIps[i].usType == EN_CINET_TYPE_IPV4)
            {
                break;
            }
        }
    }while ((dnsRryCnt <= DNS_RETRY_TIME) && (boolDnsResolve == MOS_FALSE));
 
    MOS_LOG_INF(QP_TASK, "host %s ip= 0x%x", pucUrl, stIpArrayInfo.astIps[i].u.uiIp);

    //输出服务器的ip地址方便查看
    Mos_InetAddrNtop(EN_CINET_TYPE_IPV4, &(stIpArrayInfo.astIps[i].u.uiIp), pucIp, DEFAULT_IP_LEN);
    MOS_LOG_INF(QP_TASK, "server ip: %s", pucIp);

    return MOS_OK;
}

_INT Qp_utils_PingIP(_UC * pucIP, ST_QP_PING_RESULT_PTR pstPingRs, _UI ping_delay, _UI uiPingNum)
{
#ifdef MOS_LINUX_RTOS
     if ((MOS_NULL == pucIP) || (MOS_NULL == pstPingRs))
     {
         MOS_LOG_ERR(QP_TASK, "ping paras error");
         return MOS_ERR;
     }

     if (ZJ_GetFuncTable()->pfunGetPingInfo == MOS_NULL)
     {
        MOS_LOG_INF(QP_TASK, "pfunGetPingInfo not registered");     
        return MOS_ERR;
     }
    else
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetPingInfo(pucIP, uiPingNum, &pstPingRs->mindelay, &pstPingRs->maxdelay, &pstPingRs->avgdelay, &pstPingRs->missrate);
        if (iRet = MOS_OK)
        {
            pstPingRs->result = PROBE_SUCCESS;
        }
        MOS_LOG_INF(QP_TASK, "pfunGetPingInfo Packets  Result=%d Min= %dms, Max= %dms, Average= %dms (%d%% loss)",
                 pstPingRs->result,
                 pstPingRs->mindelay,
                 pstPingRs->maxdelay,
                 pstPingRs->avgdelay,
                 pstPingRs->missrate);
        
        _UC aucLogBuf[128] = {0};
        MOS_MEMSET(aucLogBuf, 0, sizeof(aucLogBuf));
        MOS_SPRINTF(aucLogBuf, "QualityProbe pfunGetPingInfo, Result=%d Min= %dms, Max= %dms, Average= %dms (%d%% loss)",
                 pstPingRs->result,
                 pstPingRs->mindelay,
                 pstPingRs->maxdelay,
                 pstPingRs->avgdelay,
                 pstPingRs->missrate);
    } 
#else
    _INT iRet = MOS_ERR;
    struct protoent *protocol;
    struct sockaddr_in dest_addr;
    in_addr_t inaddr;
    
    if ((MOS_NULL == pucIP) || (MOS_NULL == pstPingRs))
    {
        MOS_LOG_ERR(QP_TASK, "ping paras error");
        return MOS_ERR;
    }
    
    ST_QP_PING_INFO stPingInfo;   
    Qp_utils_ResetValue(&stPingInfo);
    
    /*if ((protocol = getprotobyname("icmp")) == NULL)
    {   
        MOS_LOG_ERR(QP_TASK, "Icmp Getprotobyname Failed");
        return MOS_ERR;
    }*/

    /* 创建ICMP套接字 */
    //AF_INET:IPv4, SOCK_RAW:IP协议数据报接口, IPPROTO_ICMP:ICMP协议
    if ((stPingInfo.iSock_icmp = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP)) < 0)
    {
        MOS_LOG_ERR(QP_TASK, "Icmp Socket Failed");
    	return MOS_ERR;
    }
    dest_addr.sin_family = AF_INET;

    struct timeval tv;
    tv.tv_sec  = 2;
    tv.tv_usec = 0;
    if (setsockopt(stPingInfo.iSock_icmp, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv)) < 0)
    {
        printf("option SO_RCVTIMEO not support\n");
        return MOS_ERR;
    }

    /* 将点分十进制ip地址转换为网络字节序 */
    if ((inaddr = inet_addr(pucIP)) == INADDR_NONE)
    {
        /* 转换失败，表明是主机名,需通过主机名获取ip */
        /*if ((pHost = gethostbyname(pucIP)) == NULL)
        {
            MOS_LOG_ERR(QP_TASK, "Icmp Gethostbyname Failed");
            close(stPingInfo.iSock_icmp);
            return MOS_ERR;
        }
        memmove(&dest_addr.sin_addr, pHost->h_addr_list[0], pHost->h_length);*/
        MOS_LOG_ERR(QP_TASK, "Icmp Inet_addr Failed");
        close(stPingInfo.iSock_icmp);   
        return MOS_ERR;
    }
    else
    {
        memmove(&dest_addr.sin_addr, &inaddr, sizeof(struct in_addr));
    }

    MOS_LOG_INF(QP_TASK, "PING %s (%s) %d bytes of data", pucIP, inet_ntoa(dest_addr.sin_addr), ICMP_LEN);        
    MOS_PRINTF("PING %s (%s) %d bytes of data\n", pucIP, inet_ntoa(dest_addr.sin_addr), ICMP_LEN);

    while (stPingInfo.iSend <= uiPingNum)
    {
        iRet = Qp_utils_SendPacket(&stPingInfo, &dest_addr);
        if(MOS_OK == iRet)
        {
            iRet = Qp_utils_RecvPacket(&stPingInfo, &dest_addr);
            if (MOS_ERR == iRet)	//（ping回环时）收到了自己发出的报文,重新等待接收
            {   
                Qp_utils_RecvPacket(&stPingInfo, &dest_addr);
            }            
        }
        usleep(200*1000);
        stPingInfo.iSend++;
    }
    
    close(stPingInfo.iSock_icmp);    

    if(stPingInfo.iRecv > 0)
    {
        if(stPingInfo.iAvg >= stPingInfo.iRecv)
        {           
            stPingInfo.iMdev = (_UI)(stPingInfo.iAvg/stPingInfo.iRecv);
        }
        else
        {           
            stPingInfo.iMdev = 1;
        }      
    }
    _INT iFailed_cnt = uiPingNum - stPingInfo.iRecv;
    if (stPingInfo.iRecv > 0)
    {
        pstPingRs->result   = PROBE_SUCCESS;
        pstPingRs->mindelay = stPingInfo.iMin;
        pstPingRs->maxdelay = stPingInfo.iMax;
        pstPingRs->avgdelay = stPingInfo.iMdev;
        pstPingRs->missrate = (_UI)(iFailed_cnt*100.0/uiPingNum+0.5);
        
        MOS_LOG_INF(QP_TASK, "Packets: Sent = %d, Received = %d, Lost = %d (%u%% loss)",
                             uiPingNum,
                             stPingInfo.iRecv,
                             iFailed_cnt,
                             pstPingRs->missrate);
    
        MOS_LOG_INF(QP_TASK, "Min= %ums, Max= %ums, Average= %ums",
                             pstPingRs->mindelay,
                             pstPingRs->maxdelay,
                             pstPingRs->avgdelay);
        MOS_PRINTF("Packets: Sent = %d, Received = %d, Lost = %d (%u%% loss)\n",
                             uiPingNum,
                             stPingInfo.iRecv,
                             iFailed_cnt,
                             pstPingRs->missrate);
        
        MOS_PRINTF("Min= %ums, Max= %ums, Average= %ums\n",
                             pstPingRs->mindelay,
                             pstPingRs->maxdelay,
                             pstPingRs->avgdelay);
        _UC aucLogBuf[128] = {0};
        MOS_MEMSET(aucLogBuf, 0, sizeof(aucLogBuf));
        MOS_SPRINTF(aucLogBuf, "QualityProbe Get PingInfo, Result=%d Min= %dms, Max= %dms, Average= %dms (%d%% loss)",
                 pstPingRs->result,
                 pstPingRs->mindelay,
                 pstPingRs->maxdelay,
                 pstPingRs->avgdelay,
                 pstPingRs->missrate);
    }
    else
    {       
        MOS_LOG_INF(QP_TASK, "Error: All Packets Loss");
        return MOS_ERR;
    }   

    return MOS_OK;    
#endif
}

//uuid为36个字节
_INT Qp_utils_UUID(_UC * pucUUID)
{
    const _UC * aucTag = (_UC *)"89ab";
 
    _UC * pucBuf = MOS_NULL;
 
    _UI iLoop = 0;
    _UI iTemp = 0;


    pucBuf = pucUUID;
    if (MOS_NULL == pucBuf)
    {
        return MOS_ERR;
    }

    for (iLoop=0; iLoop < 16; ++iLoop)
    {
        iTemp = rand()%255;

        switch (iLoop)
        {
            case 6:
                sprintf((char *)pucBuf, "4%x", iTemp%15 );
                break;

            case 8:
                sprintf((char *)pucBuf, "%c%x", aucTag[rand() % strlen((char *)aucTag)], iTemp%15 );
                break;

            default:
                sprintf((char *)pucBuf, "%02x", iTemp);
                break;
        }

        pucBuf += 2;

        switch (iLoop)
        {
            case 3:
            case 5:
            case 7:
            case 9:
                *pucBuf ++ = '-';
                break;
        }
    }

    *pucBuf = 0;

    return MOS_OK;
}


//uuid为36个字节
_INT Qp_utils_UUID_NoCrossBar(_UC * pucUUID)
{
    _UC aucRndNum[16]={0};//生成随机128位的数字
    _INT i = 0;

    //生成随机数种子
    srand((unsigned)time(NULL));

    //生成128位的随机数
    //The C standard states that RAND_MAX has a minimum value of 32767 (0x7fff)
    //the function will only return 15 random bits
    for (i=0; i<16; i++) {
        aucRndNum[i] = rand() & 0xff;
    }

    // 2. Adjust certain bits according to RFC 4122 section 4.4.
    // This just means do the following
    // (a) set the high nibble of the 7th byte equal to 4 and
    // (b) set the two most significant bits of the 9th byte to 10'B,
    //     so the high nibble will be one of {8,9,A,B}.
    aucRndNum[6] = 0x40 | (aucRndNum[6] & 0xf);
    aucRndNum[8] = 0x80 | (aucRndNum[8] & 0x3f);

    //结果转换成字符串
    for (i = 0;i<16;i++)
    {
        pucUUID[2*i] = Qp_utils_Num2Char((_UC)(aucRndNum[i]/16));
        pucUUID[2*i+1] = Qp_utils_Num2Char((_UC)(aucRndNum[i]%16));
    }
    pucUUID[32] = '\0';
    return MOS_OK;
}


//// to do ... 依赖mbedtls库，正式合入时应该放在Adpt_hmac.c里定义，接口定义放到Adpt_crypto_adapt.h里，并且应该添加openssl支持。
//_INT Qp_utils_Sha1Encode(_UC * input, _UI inlen, _UC* output)
//{
//    _UI i = 0;
//    _UC aucBuff[20];
//
//     mbedtls_sha1((_UC *)input, inlen, aucBuff);
//
//    for (i=0; i<20; i++)
//    {
//        sprintf((char *)output, "%02X", (_UC)aucBuff[i]);
//        
//        if (*output >= 65 && *output <= 90)
//        {
//            *output += 32;
//        }
//        
//        output++;
//        if (*output >= 65 && *output <= 90)
//        {
//            *output += 32;
//        }
//        
//        output++;
//    }
//    
//    *output = '\0';
//    
//    return 0;
//}


//解析单独的url
ST_MOS_INET_IP* Qp_utils_ParseUrl(_UC *url, _UC *aucHost, _UC *aucPath, ST_MOS_INET_IPARRAY *pstIpArray, _UI* puiHttpsFlag)
{
    _UI i;
    _US usPort = 80;
    _UC *pStrStart = MOS_NULL;
    _UC *pStrTmp  = MOS_NULL;
    _UC aucPort[8] ={'8','0'};
    ST_MOS_INET_IP *pstNetIp = MOS_NULL;
    _UC ipAddr[32]={0};

    //判断协议类型,默认是http协议
    *puiHttpsFlag = 0;
    if (MOS_STRSTR(url, "https") != MOS_NULL)
    {
        *puiHttpsFlag = 1;
        usPort = 443;
        MOS_MEMCPY(aucPort, "443", MOS_STRLEN("443"));
    }

    //解析网址
    pStrStart = MOS_STRSTR(url, "//");
    if (pStrStart == MOS_NULL)
    {
        pStrStart = url;
    }
    else{
        pStrStart += 2;
    }

    //获取host名称+port
    pStrTmp = MOS_STRSTR(pStrStart, ":");
    //存在自定义端口
    if (pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(aucHost, pStrStart, pStrTmp - pStrStart);
        pStrStart = pStrTmp + 1;
        pStrTmp = MOS_STRSTR(pStrStart, "/");
        MOS_MEMSET(aucPort, 0, sizeof(aucPort));
        MOS_STRNCPY(aucPort, pStrStart, pStrTmp - pStrStart);
        usPort = MOS_ATOI(aucPort);
    }
    else{
        pStrTmp = MOS_STRSTR(pStrStart, "/");
        MOS_STRNCPY(aucHost, pStrStart, pStrTmp - pStrStart);
    }

    //获取路径
    if (aucPath!=MOS_NULL)
    {
        MOS_STRNCPY(aucPath, pStrTmp, 256);
    }
    
    //获取ST_MOS_INET_IP
    if (Mos_InetGetAddrInfo(aucHost,usPort,EN_CINET_PRTL_TCP,MOS_FALSE,pstIpArray) != MOS_OK)
    {
        MOS_LOG_INF(QP_TASK,"url[%s:%s], Mos_InetGetAddrInfo failed",aucHost,aucPort);
        return MOS_NULL;
    }
    for (i = 0; i < pstIpArray->uiCount; i++)
    {
        pstNetIp = &pstIpArray->astIps[i];
        if (pstNetIp->usType == EN_CINET_TYPE_IPV4)
        {
            break;
        }
    }

    Mos_InetAddrNtop(EN_CINET_TYPE_IPV4, pstNetIp->u.aucIp, ipAddr, sizeof(ipAddr));

    //将port也加入到host字段
    MOS_STRNCAT(aucHost, ":", MOS_STRLEN(":"));
    MOS_STRNCAT(aucHost, aucPort, MOS_STRLEN(aucPort));
//    MOS_LOG_INF(QP_TASK,"\nQp_utils_ParseUrl:\nurl : %s\nip : %s\nport : %u\nhost : %s\npath : %s\n",
//        url,ipAddr,pstNetIp->usPort,aucHost,aucPath);
//    MOS_LOG_INF(QP_TASK,"\n%p,%p\n",pstNetIp,&pstNetIp->usPort);

    return pstNetIp;
}

_INT Qp_utils_AsyncHttps_AesBase64_Encrypt(_UC * pucInBuf, _UC * pucLv, _UC * pucOutBuf)
{  
    _INT iTotalLen  = 0;
    _INT iFixLen    = 0;
    _INT iLoop = 0;

    _UC * pucAesInBuf;
    _UC * pucAesOutBuf;

    pucAesInBuf = (_UC *)MOS_MALLOC(TRANS_MSG_ENCRYPT_BUF_LEN);
    if (MOS_NULL == pucAesInBuf)
    {
        return MOS_ERR;
    }

    pucAesOutBuf =(_UC *)MOS_MALLOC(TRANS_MSG_ENCRYPT_BUF_LEN);
    if (MOS_NULL == pucAesOutBuf)
    {
        MOS_FREE(pucAesInBuf);
        return MOS_ERR;
    }

    MOS_MEMSET(pucAesInBuf,  0, TRANS_MSG_ENCRYPT_BUF_LEN);
    MOS_MEMSET(pucAesOutBuf, 0, TRANS_MSG_ENCRYPT_BUF_LEN);
    
    iTotalLen = MOS_STRLEN(pucInBuf);
    MOS_MEMCPY(pucAesInBuf, pucInBuf, iTotalLen);

    // 补齐16字节
    iFixLen = 16 - (iTotalLen % 16);
    if (iFixLen != 0)   
    {
        iTotalLen = iTotalLen + iFixLen;
            
        for (iLoop=0; iLoop<iFixLen; iLoop++)
        {
            pucAesInBuf[iTotalLen - iFixLen + iLoop] = iFixLen;
        }

        pucAesInBuf[iTotalLen] = '\0';
    }

    Adpt_Aec_Encrypt((_UC*)PROBE_ENCRYPT_AUCKEY, (_UC*)pucLv, pucAesInBuf, pucAesOutBuf, iTotalLen);
    Adpt_Base64_Enc(pucAesOutBuf, iTotalLen, (_UC*)pucOutBuf);

    MOS_FREE(pucAesInBuf);
    MOS_FREE(pucAesOutBuf);    
    
    return MOS_OK;
}

_INT Qp_utils_AsyncHttps_AesBase64_Decrypt(_UC * pucInBuf, _UC * pucLv, _UC * pucOutBuf)
{  
    _INT iTotalLen  = 0;
    _INT iFillNum = 0;

    _UC * pucAesMidBuf = (_UC *)MOS_MALLOC(TRANS_MSG_DECRYPT_BUF_LEN);
    if (MOS_NULL == pucAesMidBuf)
    {
        return MOS_ERR;
    }

    MOS_MEMSET(pucAesMidBuf,0,TRANS_MSG_DECRYPT_BUF_LEN);        
    Adpt_Base64_Dec(pucInBuf,pucAesMidBuf);
    //由于base解码后可能会出现'\0'，导致c语言字符串被截断，因此需要用如下的公式计算实际长度
    iTotalLen = MOS_STRLEN(pucInBuf);
    //获得填充字符个数
    iFillNum = 0;
    if (pucInBuf[iTotalLen-1]=='='){
        iFillNum++;
        if (pucInBuf[iTotalLen-2]=='='){
            iFillNum++;
        }
    }
    iTotalLen = iTotalLen*3/4-iFillNum;
    Adpt_Aec_Decrypt((_UC*)PROBE_ENCRYPT_AUCKEY,pucLv, pucAesMidBuf,pucOutBuf,iTotalLen);    
    MOS_FREE(pucAesMidBuf);    
    
    return MOS_OK;
}

//PKCS7Padding 128bit key
_INT Qp_utils_AsyncHttps_AesBase64_ECB_Encrypt(_UC * pucInBuf, _UC * pucOutBuf)
{  
    _INT iTotalLen  = 0;
    _INT iFixLen    = 0;
    _INT iNum = 0;
    _UC  aucECBKey[17]={0};

    _UC * pucAesInBuf;
    _UC * pucAesOutBuf;

    pucAesInBuf = (_UC *)MOS_MALLOC(TRANS_MSG_ENCRYPT_BUF_LEN);
    if (MOS_NULL == pucAesInBuf)
    {
        return MOS_ERR;
    }

    pucAesOutBuf =(_UC *)MOS_MALLOC(TRANS_MSG_ENCRYPT_BUF_LEN);
    if (MOS_NULL == pucAesOutBuf)
    {
        MOS_FREE(pucAesInBuf);
        return MOS_ERR;
    }

    MOS_MEMSET(pucAesInBuf,  0, TRANS_MSG_ENCRYPT_BUF_LEN);
    MOS_MEMSET(pucAesOutBuf, 0, TRANS_MSG_ENCRYPT_BUF_LEN);
    
    iTotalLen = MOS_STRLEN(pucInBuf);
    MOS_MEMCPY(pucAesInBuf, pucInBuf, iTotalLen);

    // 补齐16字节
    iNum = iTotalLen%16;
    iFixLen = 16 - (iTotalLen % 16);

    //如果是16字节，那么就填充16个0x10
    if (iNum!=0)
    {
//        //如果是8的倍数，那么还要补齐8个0x08
//        if (iNum % 8)
//        {
//                memset(cpbuf + length%16, padding, 16-length%16);//2021.3.21更改，原先是16-length%8，长度计算错误
//        }
//        else
//        {
//                memset(cpbuf+8, 0x08, 8);
//        }
        MOS_MEMSET(pucAesInBuf+iTotalLen, iFixLen, iFixLen);
        iTotalLen = iTotalLen + iFixLen;

    }
    else
    {
        MOS_MEMSET(pucAesInBuf+iTotalLen, 0x10, 16);
        iTotalLen = iTotalLen + 16;
    }
    pucAesInBuf[iTotalLen] = '\0';
    
//    if (iFixLen != 0)
//    {
//        iTotalLen = iTotalLen + iFixLen;    
//        for (iLoop=0; iLoop<iFixLen; iLoop++)
//        {
//            pucAesInBuf[iTotalLen - iFixLen + iLoop] = iFixLen;
//        }
//        pucAesInBuf[iTotalLen] = '\0';
//    }


    //secret key 的前16字节
    MOS_MEMCPY(aucECBKey, X_AISecretKey, 16);
    aucECBKey[16]='\0';

    Adpt_Aec_Ecb_Encrypt(aucECBKey,128,pucAesInBuf,pucAesOutBuf);
    Adpt_Base64_Enc(pucAesOutBuf, iTotalLen, (_UC*)pucOutBuf);

    MOS_FREE(pucAesInBuf);
    MOS_FREE(pucAesOutBuf);    
    
    return MOS_OK;
}

_UC* Qp_utils_GetUID()
{ 
    return (_UC *)(Config_GetSystemMng()->aucDevUID);
}

