#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_type.h"

#include "qualityprobe_type_prv.h"
#include "qualityprobe_api.h"

#include "adpt_json_adapt.h"
#include "tras_httpclient.h" 
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

#define AI_SERVER_STATUS_MSG_LENGTH    30

#define GW_PING_SLEEP_TIME_MSEC        100 //探测间隔时间
#define GW_PING_NUM                    10 //网关探测报文数量

#define PT_PING_SLEEP_TIME_MSEC        300 //探测间隔时间
#define PT_PING_NUM                    10 //平台探测报文数量

#define TARGET_PING_SLEEP_TIME_MSEC    300 //探测间隔时间
#define TARGET_PING_NUM                10 //指定地址探测报文数量

static ST_QP_MSG gstCheckSendBufMsg = {0};

//header中的时间戳用于request body的aes加密
static long gstCheckTimeStamp = {0};

_UC gstAiServerStatusMsg[EN_QP_STATE_CHECK_CAMERA_SIZE][AI_SERVER_STATUS_MSG_LENGTH] = {{"open cloud store failed"},      // 云存网关开通异常
                                                                                        {"refresh token failed"},         // 刷新token异常
                                                                                        {"get file url failed"},          // 获取文件上传地址异常
                                                                                        {"file upload failed"},           // 文件上传异常
                                                                                        {"commit file failed"},           // 上传文件提交异常
                                                                                        {"ok"}};                          // 正常

/*******************************************************************************************************
    Private Function Prototypes
********************************************************************************************************/
// 由信令通道函数调用，实现指定地址探测功能
_INT Qp_TaskCheck_Target_TargetCfg(ST_QP_CHECKTARGET_CONF* policy)
{
    _INT iRet = MOS_OK;
    MOS_MEMCMP(&(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg), policy, sizeof(ST_QP_CHECKTARGET_CONF));
    Mos_MutexLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
    if (MOS_OK != Qp_Utils_Config_Write(&(Qp_Task_GetTaskMng()->stQpConfig)))
    {
        MOS_LOG_INF(QP_CHECK, "update config failed");

        iRet = MOS_ERR;
    }
    Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
    return iRet;
}

_INT Qp_TaskCheck_Target_Probe(ST_QP_PING_RESULT_PTR pstTargetProbeInfo)
{
    _UC  ucIp[DEFAULT_IP_LEN] = {0};
    _UC  ucUrl[DEFAULT_URL_LEN] = {0};


    if (NULL == pstTargetProbeInfo)
    {
        MOS_LOG_ERR(QP_CHECK, "target Probe Result is Nullptr");

        return MOS_ERR;
    }

    //默认为失败
    pstTargetProbeInfo->result   = PROBE_FAILED;
    pstTargetProbeInfo->mindelay = 0;
    pstTargetProbeInfo->maxdelay = 0;
    pstTargetProbeInfo->avgdelay = 0;
    pstTargetProbeInfo->missrate = 100;
    
    // 检查url是否为空，以"www.xx.cn"为例，有效的url起码有5个字符
    if (MOS_STRLEN(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget) < 5)
    {
        MOS_LOG_ERR(QP_CHECK, "target url error [%s]", Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget);

        return MOS_ERR;
    }

    MOS_STRCPY(ucUrl, Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget);
    
    MOS_LOG_INF(QP_CHECK, "target url : %s", ucUrl);

    // ping test
    if ((MOS_ERR == Qp_utils_DNSParse(ucUrl, ucIp)) ||\
       (MOS_ERR == Qp_utils_PingIP(ucIp, pstTargetProbeInfo, TARGET_PING_SLEEP_TIME_MSEC, TARGET_PING_NUM)))
    {
        MOS_LOG_ERR(QP_CHECK, "target ping test failed");
        return MOS_ERR;
    }

    return MOS_OK;
}


_INT Qp_TaskCheck_Pt_Probe(ST_QP_PING_RESULT_PTR pstPTProbeInfo)
{
    _UC ucIp[DEFAULT_IP_LEN]  = {0};
    _UC ucUrl[DEFAULT_URL_LEN]= {0};


    if (NULL == pstPTProbeInfo)
    {
        MOS_LOG_ERR(QP_CHECK, "pstPTProbeInfo is Nullptr");

        return MOS_ERR;
    }

    //默认为失败
    pstPTProbeInfo->result   = PROBE_FAILED;
    pstPTProbeInfo->mindelay = 0;
    pstPTProbeInfo->maxdelay = 0;
    pstPTProbeInfo->avgdelay = 0;
    pstPTProbeInfo->missrate = 100;
    
    // 检查url是否为空
    if (MOS_STRLEN(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget) < 1)
    {
        MOS_LOG_ERR(QP_CHECK, "platform url error [%s]", Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget);

        return MOS_ERR;
    }

    MOS_STRCPY(ucUrl, Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget);

    MOS_LOG_INF(QP_CHECK, "platform url: %s", ucUrl);

    // check platform
    if ((MOS_ERR == Qp_utils_DNSParse(ucUrl, ucIp)) ||\
       (MOS_ERR == Qp_utils_PingIP(ucIp, pstPTProbeInfo, PT_PING_SLEEP_TIME_MSEC, PT_PING_NUM)))
    {    
        MOS_LOG_ERR(QP_CHECK, "platform ping test failed");

        return MOS_ERR;
    }
    
    return MOS_OK;
}

static _INT Qp_TaskCheck_Gw_Probe(ST_QP_PING_RESULT_PTR pstGWProbeInfo)
{

    _UC  ucIp[DEFAULT_IP_LEN] = {0};

    ST_ZJ_NETWORK_INFO stNetInfo;

    if (NULL == pstGWProbeInfo)
    {
        MOS_LOG_ERR(QP_CHECK, "pstGWProbeInfo is Nullptr");

        return MOS_ERR;
    }

    //默认为失败
    pstGWProbeInfo->result   = PROBE_FAILED;
    pstGWProbeInfo->mindelay = 0;
    pstGWProbeInfo->maxdelay = 0;
    pstGWProbeInfo->avgdelay = 0;
    pstGWProbeInfo->missrate = 100;

    // 获取网关地址
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo == NULL)
    {  
        MOS_LOG_ERR(QP_CHECK, "pfunGetCurNetInfo not registered");

        return MOS_ERR;
    }
    else
    {
        // get device info once
        MOS_MEMSET(&stNetInfo, 0, sizeof(ST_ZJ_NETWORK_INFO));
        ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetInfo);

        MOS_MEMCPY(ucIp, stNetInfo.aucGateway, MOS_STRLEN(stNetInfo.aucGateway));
        MOS_LOG_INF(QP_CHECK, "Gateway ip: %s", ucIp);
    }

    if (MOS_ERR == Qp_utils_PingIP(ucIp, pstGWProbeInfo, GW_PING_SLEEP_TIME_MSEC, GW_PING_NUM))
    {
        MOS_LOG_ERR(QP_CHECK, "gateway ping test failed");
        return MOS_ERR;
    }

    return MOS_OK;
}

static _INT Qp_TaskCheck_ParseCheckRsp(_UC *pucJson)
{
    _INT iRet = MOS_ERR;
    _UC * pucStrTmp = MOS_NULL;

    _UC  ucUpdateConfigFlag = 0;    // 是否需要保持配置标记，0-不保存，0x55-保存

    _INT iResultCode = 0;
    _INT iAreaIdTtl = 0;
    _INT iNeedInspect = 0;
    _INT iCheckDataCycle = 0;
    
    long timestamp = 0;
    ST_MOS_SYS_TIME stCurTime;

    _UC *pucEncryptBuf = MOS_NULL;
    _UC *pucDecryptBuf = MOS_NULL;
    
    _UC aucLv[18] = {0};
    _INT iLvLen = 0;

    JSON_HANDLE hJsonRoot    = MOS_NULL;
    JSON_HANDLE hResponseObj = MOS_NULL;
    JSON_HANDLE hTempObj     = MOS_NULL;

    _UC *pucStart = MOS_NULL;
    
    hJsonRoot = Adpt_Json_Parse(pucJson);
    if (hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"result"), &iResultCode);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"message"), &pucStrTmp);

    if (0== iResultCode)
    {
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"response"), &pucEncryptBuf);
        //hResponseObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"response");
        //对数据进行解密
        pucDecryptBuf = (_UC*)MOS_MALLOCCLR(TRANS_MSG_DECRYPT_BUF_LEN);
        // 使用时间戳解密
        MOS_SPRINTF(aucLv, "%ld", gstCheckTimeStamp);
        aucLv[16] = '\0';
        iLvLen = MOS_STRLEN(aucLv);

        //填充到16字节
        while (iLvLen < 16)
        {
            aucLv[iLvLen] = '0';
            iLvLen ++;
        }
        //解密
        Qp_utils_AsyncHttps_AesBase64_Decrypt(pucEncryptBuf,aucLv,pucDecryptBuf);

        //解析解密后的内容
        hResponseObj = Adpt_Json_Parse(pucDecryptBuf);
        MOS_LOG_INF(QP_CHECK, "Decrypt Check Data Respone : %s",pucDecryptBuf);
        if (MOS_NULL != hResponseObj)
        {
            //可选
            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"area_Id");
            if (MOS_NULL != hTempObj)
            {
                Adpt_Json_GetString(hTempObj, &pucStrTmp);
                if (6 == MOS_STRLEN(pucStrTmp))
                {
                    if(MOS_STRSTR(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID, pucStrTmp) == MOS_NULL)
                    {
                        ucUpdateConfigFlag = 0x55;
                        MOS_STRNCPY(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID, pucStrTmp, AREA_ID_LEN-1);
                        Qp_Task_GetTaskMng()->stQpConfig.aucAreaID[AREA_ID_LEN-1] = '\0';
                    }
                }
                else
                {
                    MOS_LOG_INF(QP_CHECK, "Receive Wrong Area Id");
                }
            }

            //可选
            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"areaId_ttl");
            if (MOS_NULL != hTempObj)
            {
                Adpt_Json_GetIntegerEx(hTempObj, &iAreaIdTtl);

                if ((iAreaIdTtl >= 3) && (iAreaIdTtl <= 15))
                {
                    Mos_GetSysTime(&stCurTime);
                    timestamp = (long)Mos_SysTimetoTime(&stCurTime);
                    if(timestamp >= Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl)
                    {
                        ucUpdateConfigFlag = 0x55;
                        // 接收到服务器配置的有效期天数后，根据当前日期计算转换为失效那天的时间戳
                        // iAreaIdTtl单位是天，需转为秒时间戳60*60*24=86400
                        Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl = timestamp + iAreaIdTtl*PROBE_CHECK_TIME_DAY;
                    }
                }
                else
                {
                    MOS_LOG_INF(QP_CHECK, "Receive Wrong Areaid Ttl[%d]", iAreaIdTtl);
                }
            }

            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"is_inspect");
            if (MOS_NULL != hResponseObj)
            {
                Adpt_Json_GetIntegerEx(hTempObj, &iNeedInspect);
                //说明本次需要立即巡检
                if ((iNeedInspect == 1) && (Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckModeCtrl == 0))
                {
                    ucUpdateConfigFlag = 0x55;
                    Qp_Task_GetTaskMng()->stQpConfig.iImmSendFlag = 1;
                }
                Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckModeCtrl = iNeedInspect;
            }
            
            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"check_data_cycle");
            if (MOS_NULL != hResponseObj)
            {
                Adpt_Json_GetIntegerEx(hTempObj, &iCheckDataCycle);

                if ((iCheckDataCycle >= 0) && (iCheckDataCycle <= 24))
                {
                    //只有新的策略的周期小于当前的才会覆盖
                    //或者当前没有巡检周期
                    if (Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.uiCheckDataCycleTime != iCheckDataCycle)
                    {
                        ucUpdateConfigFlag = 0x55;
                        Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.uiCheckDataCycleTime = iCheckDataCycle;
                    }
                }
                else
                {
                    MOS_LOG_INF(QP_CHECK, "Receive Wrong Check Cycle[%d]", iCheckDataCycle);
                }
            }

            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"check_data_cloud");
            if (MOS_NULL != hResponseObj)
            {
                Adpt_Json_GetString(hTempObj, &pucStrTmp);
                //平台返回的地址携带http://前缀，需要移除该前缀
                pucStart = MOS_STRSTR(pucStrTmp, "//");
                if (pucStart != MOS_NULL){
                    if(MOS_STRCMP(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataCloud, pucStart+2) != 0)
                    {
                        ucUpdateConfigFlag = 0x55;
                        MOS_STRNCPY(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataCloud, pucStart+2, DEFAULT_URL_LEN);
                    }
                }else{
                    if(MOS_STRCMP(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataCloud, pucStrTmp) != 0)
                    {
                        ucUpdateConfigFlag = 0x55;
                        MOS_STRNCPY(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataCloud, pucStrTmp, DEFAULT_URL_LEN);
                    }
                }
            }

            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"check_data_target");
            if (MOS_NULL != hResponseObj)
            {
                Adpt_Json_GetString(hTempObj, &pucStrTmp);
                pucStart = MOS_STRSTR(pucStrTmp, "//");
                if (pucStart != MOS_NULL){
                    if(MOS_STRCMP(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget, pucStart+2) != 0)
                    {
                        ucUpdateConfigFlag = 0x55;
                        MOS_STRNCPY(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget, pucStart+2, DEFAULT_URL_LEN);
                    }
                }else{
                    if(MOS_STRCMP(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget, pucStrTmp) != 0)
                    {
                        ucUpdateConfigFlag = 0x55;
                        MOS_STRNCPY(Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckDataTarget, pucStrTmp, DEFAULT_URL_LEN);
                    }
                }
            }

            iRet = MOS_OK;
        }
    }
    else
    {
        MOS_LOG_INF(QP_CHECK, "Respone Error, iResultCode[%d], Message %s", iResultCode,pucStrTmp);
    }

    if (0x55 == ucUpdateConfigFlag)
    {
        Mos_MutexLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
        if (MOS_OK != Qp_Utils_Config_Write(&(Qp_Task_GetTaskMng()->stQpConfig)))
        {
            MOS_LOG_INF(QP_CHECK, "Update Config Failed");
        }
         Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
    }

    Adpt_Json_Delete(hJsonRoot);
    Adpt_Json_Delete(hResponseObj);
    MOS_FREE(pucDecryptBuf);
    return iRet;
}


static _VOID Qp_TaskCheck_RecvCheckRspFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    ST_QP_CHECK_TRANS_MGR* pstCheckTransMgr = &Qp_Task_GetTaskMng()->stCheckTransMgr;

    MOS_LOG_INF(QP_CHECK, "Recv Check Data Fail");

    if (pstCheckTransMgr)
    {
        if (pstCheckTransMgr->pucRecvBuf)
        {
               MOS_FREE(pstCheckTransMgr->pucRecvBuf);            
        }
        
        pstCheckTransMgr->ucRetransFlag= 1;            
        if (pstCheckTransMgr->iFailCnt < 24)
        {
            pstCheckTransMgr->iFailCnt++;
        }
        pstCheckTransMgr->cRetransTime = Mos_Time() + (pstCheckTransMgr->iFailCnt * 5 * 60);
        pstCheckTransMgr->uiPostStep= EN_QP_STATE_ASYNC_POST_NOTRANS;
        // 复位发送过程中的标记
        // pstCheckTransMgr->uiOgctId     = 0;
        pstCheckTransMgr->uiHasRecvLen = 0;
        pstCheckTransMgr->uiRecvBufLen = 0;
        pstCheckTransMgr->pucRecvBuf = MOS_NULL;
                    
    }

    return;
}

static _VOID Qp_TaskCheck_RecvCheckRspFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iRet = 0;
    ST_QP_CHECK_TRANS_MGR* pstCheckTransMgr = &Qp_Task_GetTaskMng()->stCheckTransMgr;

    if (pstCheckTransMgr == MOS_NULL)
    {
        MOS_LOG_INF(QP_CHECK, "PstCheckTransMgr Is Null");
        return;
    }

    // 接收完毕，解析服务返回的数据
    if (pstCheckTransMgr->pucRecvBuf == MOS_NULL)
    {
        MOS_LOG_INF(QP_CHECK, "Data Rsp Is Null");

        //删除发送成功的数据
        Mos_MutexLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);
        Qp_Store_DeleteFileContenBySizeADir(Qp_Task_GetTaskMng()->aucCheckDataFileName,1);
        Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);

        pstCheckTransMgr->ucRetransFlag  = 0;            
        pstCheckTransMgr->iFailCnt       = 0;
        pstCheckTransMgr->uiPostStep     = EN_QP_STATE_ASYNC_POST_NOTRANS;        
        return;
    }
    pstCheckTransMgr->pucRecvBuf[pstCheckTransMgr->uiHasRecvLen] = 0;
        
    iRet = Qp_TaskCheck_ParseCheckRsp(pstCheckTransMgr->pucRecvBuf);
    if (iRet == MOS_ERR)
    {   
        MOS_LOG_ERR(QP_CHECK, "Parse Server Check Data Rsp Error");
    }
    else
    {
        MOS_LOG_INF(QP_CHECK, "Parse Server Check Data Rsp Success");
    }

    MOS_FREE(pstCheckTransMgr->pucRecvBuf);

    // 复位发送过程中的标记
    // pstCheckTransMgr->uiOgctId     = 0;
    pstCheckTransMgr->ucRetransFlag= 0;
    pstCheckTransMgr->uiHasRecvLen = 0;
    pstCheckTransMgr->uiRecvBufLen = 0;
    pstCheckTransMgr->pucRecvBuf = MOS_NULL;

    if (gstCheckSendBufMsg.ucMsgType == QP_MSG_TYPE_CHECK_DATA)
    {
        //删除发送成功的数据
        Mos_MutexLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);
        Qp_Store_DeleteFileContenBySizeADir(Qp_Task_GetTaskMng()->aucCheckDataFileName,1);
        Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);

        pstCheckTransMgr->ucRetransFlag = 0;            
        pstCheckTransMgr->iFailCnt        = 0;

        if (MOS_STRLEN(gstCheckSendBufMsg.aucUUID) >= 32)
        {
            ST_QP_AI_INSECPTION_MSG stQPAIMsgNode = {0};            
            MOS_MEMCPY(stQPAIMsgNode.aucUUID, gstCheckSendBufMsg.aucUUID, sizeof(stQPAIMsgNode.aucUUID));
            MOS_MEMCPY(stQPAIMsgNode.aucFileCreateTime, gstCheckSendBufMsg.aucFileCreateTime, sizeof(stQPAIMsgNode.aucFileCreateTime));
            Qp_TaskAi_SaveFile(&stQPAIMsgNode);            
        }

    }

    pstCheckTransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_NOTRANS;

    return;
}

static _VOID Qp_TaskCheck_RecvCheckRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
       ST_QP_CHECK_TRANS_MGR* pstCheckTransMgr = &Qp_Task_GetTaskMng()->stCheckTransMgr;

    JSON_HANDLE hJsonRoot    = MOS_NULL;    
    hJsonRoot = Adpt_Json_Parse(pucData);
    if (hJsonRoot == MOS_NULL)
    {
        MOS_LOG_INF(QP_CHECK, "Buf Is Not The Json");
        return;
    }
    _UC *pucEncryptBuf = MOS_NULL;
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"seq_no"), &pucEncryptBuf);

    if (pstCheckTransMgr != MOS_NULL && pucEncryptBuf != MOS_NULL && MOS_STRCMP(pstCheckTransMgr->aucUUID,pucEncryptBuf) != MOS_OK)
    {
        MOS_LOG_INF(QP_CHECK, "Uuid Is Error");
        Adpt_Json_Delete(hJsonRoot);
        return;
    }

    // 如果当前接收buf还没有分配空间
    if (pstCheckTransMgr->uiRecvBufLen == 0)
    {
        pstCheckTransMgr->uiRecvBufLen = TRANS_RECV_BUF_LENGTH;
        pstCheckTransMgr->pucRecvBuf   = (_UC*)MOS_MALLOCCLR(TRANS_RECV_BUF_LENGTH);
    }

    // 还剩空余的空间则缓存下来
    if (pstCheckTransMgr->uiHasRecvLen + uiLen < pstCheckTransMgr->uiRecvBufLen)
    {
        MOS_MEMCPY(pstCheckTransMgr->pucRecvBuf + pstCheckTransMgr->uiHasRecvLen, pucData, uiLen);
        pstCheckTransMgr->uiHasRecvLen += uiLen;
    }
    else
    {
        MOS_LOG_INF(QP_CHECK, "Without Enough Buf");
    }

    Adpt_Json_Delete(hJsonRoot);

    return;
}

static _UC* Qp_TaskCheck_BuildCheckReqData(ST_QP_MSG *pQPMsgNode)
{
    _UC *pstrTmp = MOS_NULL;
    _UC aucLv[18] = {0};
    _INT iLvLen = 0;

    _UC aucBuf[TRANS_MSG_ENCRYPT_BUF_LEN];
    _UC *pucEncryptBuf = MOS_NULL;

    JSON_HANDLE hRoot  = MOS_NULL;
    JSON_HANDLE hValue = MOS_NULL;
    JSON_HANDLE hDataJson = MOS_NULL;
    long timestamp = 0;

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    // build request
    hValue = Adpt_Json_CreateObject();    
    Adpt_Json_AddItemToObject(hValue, (_UC *)"did", Adpt_Json_CreateString(Qp_utils_GetUID()));
    Adpt_Json_AddItemToObject(hValue, (_UC *)"ctei", Adpt_Json_CreateString((_UC *)(Config_GetSystemMng()->aucDevCTEI)));

    if ((0 != Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl) && (timestamp <= Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl))
    {
        Adpt_Json_AddItemToObject(hValue, (_UC*)"area_id", Adpt_Json_CreateString((_UC*)(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID)));
    }

    //add dev_type
    Adpt_Json_AddItemToObject(hValue, (_UC*)"dev_type", Adpt_Json_CreateString((_UC*)(Config_GetDeviceMng()->aucDevModel)));

    //add firm_type
    Adpt_Json_AddItemToObject(hValue, (_UC*)"firm_ver", Adpt_Json_CreateString((_UC*)(Config_GetDeviceMng()->aucDevVerSion)));

    hDataJson = Adpt_Json_Parse(pQPMsgNode->ucData);

    Adpt_Json_AddItemToObject(hValue, (_UC*)"data", hDataJson);

    pucEncryptBuf = Adpt_Json_Print(hValue);
    Adpt_Json_Delete(hValue);

    // 使用时间戳加密
    MOS_SPRINTF(aucLv, "%ld", gstCheckTimeStamp);
    aucLv[16] = '\0';
    iLvLen = MOS_STRLEN(aucLv);

    //填充到16字节
    while (iLvLen < 16)
    {
        aucLv[iLvLen] = '0';
        iLvLen ++;
    }

    MOS_LOG_INF(QP_CHECK,"check data : %s\n",pucEncryptBuf);

    Qp_utils_AsyncHttps_AesBase64_Encrypt(pucEncryptBuf, aucLv, aucBuf);

    MOS_FREE(pucEncryptBuf);

    // add request
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"request", Adpt_Json_CreateString(aucBuf));

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pstrTmp;
}

static _INT Qp_TaskCheck_AsycPostCheckData(ST_QP_MSG *pQPMsgNode)
{
    _INT iRet        = MOS_ERR;
    _UC *pStrTmp     = MOS_NULL;
    _UC aucHost[256] = {0};
    _UC aucPath[256] = {0};
    _UC aucUUID[64]  = {0};
    _UC aucHttpHeader[256] = {0};
    _UI uiHttpsFlag = 0;
    ST_MOS_SYS_TIME stCurTime;
    
    ST_QP_CHECK_TRANS_MGR* pstCheckTransMgr = &Qp_Task_GetTaskMng()->stCheckTransMgr;
    if (pstCheckTransMgr == MOS_NULL)
    {
        return MOS_ERR; 
    }
    
    //pstCheckTransMgr->iSendCnt ++;
    pstCheckTransMgr->cSendTime= Mos_Time();
    // pstCheckTransMgr->uiOgctId = Mos_GetSessionId();

    //时间戳
    Mos_GetSysTime(&stCurTime);
    gstCheckTimeStamp = (long)Mos_SysTimetoTime(&stCurTime);
    Qp_utils_UUID_NoCrossBar(aucUUID);
    MOS_MEMSET(pstCheckTransMgr->aucUUID, 0, sizeof(pstCheckTransMgr->aucUUID));
    MOS_MEMCPY(pstCheckTransMgr->aucUUID, aucUUID, sizeof(pstCheckTransMgr->aucUUID));

    iRet = Http_Parse_Url(QUALITY_PROBE_CHECK_REPORT_URL, aucHost, aucPath, &uiHttpsFlag);
    if (iRet == MOS_ERR){
        MOS_LOG_ERR(QP_AI, "Http_Parse_Url error");
    }
    //构建http header
    MOS_VSNPRINTF(aucHttpHeader, 256, "Plug-Version: %u\r\nTime: %ld000\r\nSeq-No: %s\r\n",Config_GetDeviceMng()->uiSdkVersion,gstCheckTimeStamp,aucUUID);

    //构建http body
    pStrTmp = Qp_TaskCheck_BuildCheckReqData(pQPMsgNode);
    if (pStrTmp == MOS_NULL)
    { 
        return MOS_ERR; 
    }

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = Qp_TaskCheck_RecvCheckRsp;
    stHttpInfoNode.pfuncFinished   = Qp_TaskCheck_RecvCheckRspFinish;
    stHttpInfoNode.pfuncFailed     = Qp_TaskCheck_RecvCheckRspFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    stHttpInfoNode.pucExpandHeader = aucHttpHeader;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, aucHost, aucPath, EN_HTTP_METHOD_POST, Mos_GetSessionId());

    MOS_FREE(pStrTmp);
    
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}



static _INT Qp_TaskCheck_Request_Post(void)
{
    ST_MOS_SYS_TIME stCurTime;
    _UC ucDataOccurTime[DATE_TIME_LEN];

    ST_QP_MSG *pQPMsgNode = NULL;

    pQPMsgNode = (ST_QP_MSG *)MOS_MALLOC(sizeof(ST_QP_MSG));
    if (pQPMsgNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    pQPMsgNode->ucMsgType = QP_MSG_TYPE_CHECK_REQUEST;

    // occur time
    Mos_GetSysTime(&stCurTime);
    MOS_SPRINTF(ucDataOccurTime, "%ld000", (long)Mos_SysTimetoTime(&stCurTime));

    MOS_SPRINTF(pQPMsgNode->ucData, "{\"timestamp\":%s}", ucDataOccurTime);

    MOS_MEMSET(&gstCheckSendBufMsg, 0, sizeof(ST_QP_MSG));
    MOS_MEMCPY(&gstCheckSendBufMsg, pQPMsgNode, sizeof(ST_QP_MSG));

    MOS_FREE(pQPMsgNode);    

    return Qp_TaskCheck_AsycPostCheckData(&gstCheckSendBufMsg);

}

static _INT Qp_TaskCheck_Data_Post(void)
{
    _UC ucDataOccurTime[DATE_TIME_LEN];
    
    ST_MOS_SYS_TIME   stCurTime;
    ST_QP_PING_RESULT stGWProbeInfo;
    ST_QP_PING_RESULT stPTProbeInfo;
    ST_QP_PING_RESULT stTargetProbeInfo;

    ST_QP_MSG * pQPMsgNode = NULL;

    ST_QP_CHECK_CAMERA_MGR* pstCheckCameraMgr = MOS_NULL;

    pstCheckCameraMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    // 整理数据
    // 巡检传输数据有：
    // - 网关通讯质量
    // - 云存平台通讯质量
    // - 指定地址联通质量
    // - 摄像头抓拍画面

    // occur time
    Mos_GetSysTime(&stCurTime);
    MOS_SPRINTF(ucDataOccurTime, "%ld000", (long)Mos_SysTimetoTime(&stCurTime));

    // check gw
    MOS_MEMSET(&stGWProbeInfo, 0, sizeof(ST_QP_PING_RESULT));
    (_VOID)Qp_TaskCheck_Gw_Probe(&stGWProbeInfo);

    // check platform
    MOS_MEMSET(&stPTProbeInfo, 0, sizeof(ST_QP_PING_RESULT));
    (_VOID)Qp_TaskCheck_Pt_Probe(&stPTProbeInfo);

    // check platform
    MOS_MEMSET(&stTargetProbeInfo, 0, sizeof(ST_QP_PING_RESULT));
    (_VOID)Qp_TaskCheck_Target_Probe(&stTargetProbeInfo);

    // check camera
    // 已提前完成camera质检画面传输，这里直接上传质检画面传输情况


    // 统一至发送格式
    pQPMsgNode = (ST_QP_MSG *)MOS_MALLOC(sizeof(ST_QP_MSG));
    if (pQPMsgNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    pQPMsgNode->ucMsgType = QP_MSG_TYPE_CHECK_DATA;
    MOS_MEMCPY(pQPMsgNode->aucUUID, pstCheckCameraMgr->aucUUID, sizeof(pstCheckCameraMgr->aucUUID));
    MOS_MEMCPY(pQPMsgNode->aucFileCreateTime, pstCheckCameraMgr->ucFileCreateTime, sizeof(pstCheckCameraMgr->ucFileCreateTime));

    MOS_SPRINTF(pQPMsgNode->ucData, "{\"timestamp\":%s,\"gateway\":[%d,%d,%d,%d],\"cloud\":[%d,%d,%d,%d],\"target\":[%d,%d,%d,%d],\"camera_test\":[%d,\"%s\",\"%s\",\"%s\"]}",
                                    ucDataOccurTime,
                                    stGWProbeInfo.mindelay,
                                    stGWProbeInfo.maxdelay,
                                    stGWProbeInfo.avgdelay,
                                    stGWProbeInfo.missrate,
                                    stPTProbeInfo.mindelay,
                                    stPTProbeInfo.maxdelay,
                                    stPTProbeInfo.avgdelay,
                                    stPTProbeInfo.missrate,
                                    stTargetProbeInfo.mindelay,
                                    stTargetProbeInfo.maxdelay,
                                    stTargetProbeInfo.avgdelay,
                                    stTargetProbeInfo.missrate,
                                    pstCheckCameraMgr->iSnapshotStatusCode,
                                    gstAiServerStatusMsg[pstCheckCameraMgr->iSnapshotStatusCode],
                                    pstCheckCameraMgr->ucFileName,
                                    pstCheckCameraMgr->aucUUID);
                                
    Mos_MutexLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);
    Qp_Store_WriteCheckDataByDir(pQPMsgNode,Qp_Task_GetTaskMng()->aucCheckDataFileName);
    Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);

    ST_QP_CHECK_TRANS_MGR* pstCheckTransMgr = &Qp_Task_GetTaskMng()->stCheckTransMgr;
    pstCheckTransMgr->ucRetransFlag = 0;            
    
    MOS_FREE(pQPMsgNode);    

    return MOS_OK;

    //return Qp_TaskCheck_AsycPostCheckData(&gstCheckSendBufMsg);

}

static _INT Qp_TaskCheck_Request_Entry(void)
{
    ST_MOS_SYS_TIME stCurTime;
    long lCurTimestamp = 0;
    
    Mos_GetSysTime(&stCurTime);
    lCurTimestamp = (long)Mos_SysTimetoTime(&stCurTime);

    // check last cycle here
    if ((lCurTimestamp - Qp_Task_GetTaskMng()->stQpConfig.cQpLastTimestamp) > CHECK_REQUEST_CYCLE_TIME )
    {
        MOS_LOG_INF(QP_CHECK, "Time To Send Check Request, Cur[%d], Last[%d], Cycle[%d]", lCurTimestamp, 
            Qp_Task_GetTaskMng()->stQpConfig.cQpLastTimestamp, CHECK_REQUEST_CYCLE_TIME); 

        Qp_TaskCheck_Request_Post();
        
         Qp_Task_GetTaskMng()->stQpConfig.cQpLastTimestamp = lCurTimestamp;
         Mos_MutexLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
         if (MOS_OK != Qp_Utils_Config_Write(&(Qp_Task_GetTaskMng()->stQpConfig)))
         {
            MOS_LOG_INF(QP_CHECK, "update last check time failed");
         }
         Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
    }

    return MOS_OK;

}

static _INT Qp_TaskCheck_Data_Entry(void)
{
    ST_MOS_SYS_TIME stCurTime;
    long lCurTimestamp = 0;

    static _UC ucCheckFlag = 0;   // 巡检启动标志，0-停止，1-启动
    //static long slLastTimestamp = 0;
    
    ST_QP_CHECK_CAMERA_MGR* pstCheckCamera = MOS_NULL;

    // CurTime 时间戳，小时制
    Mos_GetSysTime(&stCurTime);
    lCurTimestamp = (long)Mos_SysTimetoTime(&stCurTime);
    
    //当从无策略到检测到策略就立即发送
    if (Qp_Task_GetTaskMng()->stQpConfig.iImmSendFlag == 1)
    {    
        MOS_LOG_INF(QP_CHECK, "Send Check Fata Immediately");        

        // set check flag
        ucCheckFlag = 1;
    }
    
    // check last cycle here 
    if ((lCurTimestamp - Qp_Task_GetTaskMng()->stQpConfig.cQpLastTimestamp) > Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.uiCheckDataCycleTime * PROBE_CHECK_TIME_HOUR)
    {
    
        MOS_LOG_INF(QP_CHECK, "Time To Send Check Data, Cur[%d], Last[%d], Cycle[%d], Unit_time[%d]", lCurTimestamp, 
            Qp_Task_GetTaskMng()->stQpConfig.cQpLastTimestamp, Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.uiCheckDataCycleTime,PROBE_CHECK_TIME_HOUR);
        
        // set check flag
        ucCheckFlag = 1;
    }

    if (1 == ucCheckFlag)
    {
        // check camera       
        if (EN_QP_STATE_CHECK_CAMERA_FINISH == Qp_Check_Camera_Probe())
        {    
            pstCheckCamera = &Qp_Task_GetTaskMng()->stCheckCameraMgr;
            //判断是否提交成功
            if (pstCheckCamera->iSnapshotStatusCode != EN_QP_STATE_CHECK_CAMERA_FINISH)
            {
                _UC aucMsg[64] = {0};
                MOS_SPRINTF(aucMsg, "QualityProbe CheckCamera Failed,And The SnapshotStatusCode Is %d",pstCheckCamera->iSnapshotStatusCode);
                MOS_MEMSET(pstCheckCamera->aucUUID, 0, sizeof(pstCheckCamera->aucUUID));                
                if (pstCheckCamera->iSnapshotStatusCode < EN_QP_STATE_CHECK_CAMERA_SEND_SNAPSHOT)
                {
                    MOS_MEMCPY(pstCheckCamera->ucFileName, "00000000000000-00000000000000.jpg", MOS_STRLEN("00000000000000-00000000000000.jpg"));
                }
            }
            else
            {
                //生成用于画面巡检结果关联的UUID
                MOS_MEMSET(pstCheckCamera->aucUUID, 0, sizeof(pstCheckCamera->aucUUID));
                Qp_utils_UUID_NoCrossBar(pstCheckCamera->aucUUID);
            }
            
            if (MOS_OK == Qp_TaskCheck_Data_Post())
            {
                pstCheckCamera->iSendCnt = 0;
                Qp_Task_GetTaskMng()->stQpConfig.iImmSendFlag = 0;
                Qp_Task_GetTaskMng()->stQpConfig.cQpLastTimestamp = lCurTimestamp;
                
                Mos_MutexLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
                if (MOS_OK != Qp_Utils_Config_Write(&(Qp_Task_GetTaskMng()->stQpConfig)))
                {
                    MOS_LOG_INF(QP_CHECK, "Update Config Failed");
                }
                Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
            }
            else
            {
                if (pstCheckCamera->iSendCnt >= 1)
                {
                    pstCheckCamera->iSendCnt = 0;
                }
                pstCheckCamera->iSendCnt++;
            }
            // reset check flag
            ucCheckFlag = 0;
        }
    }

    return MOS_OK;    
}


_INT Qp_TaskCheck_Entry()
{    
    ST_QP_CHECK_TRANS_MGR* pstCheckTransMgr = &Qp_Task_GetTaskMng()->stCheckTransMgr;
    if (pstCheckTransMgr->uiPostStep == EN_QP_STATE_ASYNC_POST_TRANSED)
    {
        return MOS_OK;
    }

    if ((1 == Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.ucCheckModeCtrl) && 
        (Qp_Task_GetTaskMng()->stQpConfig.stCheckTargetCfg.uiCheckDataCycleTime > 0))
    {
       Qp_TaskCheck_Data_Entry();
    }
    else
    {
        Qp_TaskCheck_Request_Entry(); 
    }

    _CTIME_T cNowTime = Mos_Time();
    if (Qp_Task_GetTaskMng()->Records_check > 0 && 
        (pstCheckTransMgr->ucRetransFlag == 0 || (pstCheckTransMgr->ucRetransFlag == 1 && cNowTime >= pstCheckTransMgr->cRetransTime)))
    {
        MOS_LOG_INF(QP_CHECK, "start send check data");
        //从文件里面读取待发送数据
        MOS_MEMSET(&gstCheckSendBufMsg, 0, sizeof(ST_QP_MSG));
        Mos_MutexLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);
        Qp_Store_ReadCheckDataByDir(&gstCheckSendBufMsg, 1, Qp_Task_GetTaskMng()->aucCheckDataFileName);
        Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hCheckFileMutex);

        pstCheckTransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_TRANSED;        
        if (MOS_OK != Qp_TaskCheck_AsycPostCheckData(&gstCheckSendBufMsg))
        {
            pstCheckTransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_NOTRANS;
            MOS_LOG_ERR(QP_TASK, "send check data error");
        }            
    }
    
    return MOS_OK;
}

