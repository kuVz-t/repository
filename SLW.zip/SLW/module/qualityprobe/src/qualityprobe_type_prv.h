#ifndef _QUALITYPROBE_TYPE_PRV_H
#define _QUALITYPROBE_TYPE_PRV_H

#ifdef __cplusplus
extern "C" {
#endif


/* Includes ------------------------------------------------------------------*/
#include "config_type.h"
#include "qualityprobe_api.h"


// 调试模式
#define PROBE_DEBUG_MODE               1

/* Exported macro ------------------------------------------------------------*/
// 线程名称
#define QP_TASK                        (_UC *)"QP_TASK"

// 模块名称
#define QP_COUNT                       (_UC *)"QP_COUNT"
#define QP_CHECK                       (_UC *)"QP_CHECK"
#define QP_CAMERA                      (_UC *)"QP_CAMERA"
#define QP_AI                          (_UC *)"QP_AI"
#define QP_STORE                       (_UC *)"QP_STORE"

#define QP_CONFIG_FILE_MAX_LEN         256
#define QP_CONFIG_FILE_MAX_SIZE        1024

#define QP_FOLDER                      (_UC *)"qpdata"
#define QP_CONF_FILENAME               (_UC *)"qpdata/conf.json"
#define QP_CHECK_FILENAME              (_UC *)"qpdata/check_data.bin"
#define QP_AI_INSECPTION_FILENAME      (_UC *)"qpdata/ai_insecption.bin"


#define DEFAULT_IP_LEN                 64        // 与统一sdk中aucGateway长度定义保持一致
#define DEFAULT_URL_LEN                512

#define DATE_TIME_LEN                  20        // 探针数据长度

#define AREA_ID_LEN                    7         // 归属地有6个字符，含结束符共7个


// 重新截图次数，默认重试1次, 0则不重试
#define CHECK_CAMERA_REGET_NUM         0
    
// 重新截图间隔,单位s
#define CHECK_CAMERA_RETGET_TIME       1
    
// 重发次数，默认重试1次, 0则不重试
#define CHECK_CAMERA_RETRANS_NUM       0
    
// 重发时间间隔,单位s
#define CHECK_CAMERA_RETRANS_TIME      5
    
// 鉴权头长度
#define AUTHENTICATION_HEAD_LEN        512

#define AUTHENTICATION_DATA_LEN        128

    
#define AI_ACCOUNT_INVALID             0    // account 无效
#define AI_ACCOUNT_VALID               0x55 // account 有效
    
#define TRANS_MSG_TIMEOUT  30 //摄像头画面巡检超时


#define AI_HTTPS_URL                        (_UC *)"https://seopapi.189smarthome.com:38018"
#define AI_HTTPS_URL_API_GET_TOKEN          (_UC *)"/ebp/AIPlatform/openAIService/openAIService"                      // 云存网关服务开通
#define AI_HTTPS_URL_API_UPDATE_TOKEN       (_UC *)"/ebp/AIPlatform/AIPlartformRefreshToken/refreshToken"            // 刷新token
#define AI_HTTPS_URL_API_REPORT_SNAPSHOT    (_UC *)"/ebp/AIPlatform/pushDeviceRoundMessage/pushDeviceRoundMessage"   // 推送时刻消息

#define CLOUD_STORE_HTTPS_URL                         (_UC *)"https://seopapi.189smarthome.com:38018"
#define CLOUD_STORE_HTTPS_URL_API_GET_UPLOADURL       (_UC *)"/ebp/homeCloud/getUploadUrl/homeCloud/getUploadUrl"    // 获取文件上传地址
#define CLOUD_STORE_HTTPS_URL_API_COMMIT_SNAPSHOT     (_UC *)"/ebp/homeCloud/commitFileName/homeCloud/commitFileName"// 上传文件提交

#define X_AIAPP_ID                          "58c4f98407f5ba063113fe2776a6ed8f"
#define X_AIAPP_KEY                         "5b10f8d66c1428abda8f6527c5a689df"
#define X_AISecretKey                       "93b37b263bd04a848a74d06d7544e441"

#define QUALITY_PROBE_COUNT_REPORT_URL                (_UC *)"https://inspquality.ehome.21cn.com/insp-quality/plug/api/quality/data/report"
#define QUALITY_PROBE_CHECK_REPORT_URL                (_UC *)"https://inspquality.ehome.21cn.com/insp-inspection/plug/api/inspection/data/report"

// 各种标记
#define PROBE_SUCCESS                  1
#define PROBE_FAILED                   0

// 检测单位时间
#define PROBE_CHECK_TIME_DAY       86400 // 正式设置为1天，86400秒
#define PROBE_CHECK_TIME_HOUR      3600 // 正式设置为1小时，3600秒
#define PROBE_CHECK_TIME_MINUTE    60    // 正式设置为1分钟，60秒
#define CHECK_REQUEST_CYCLE_TIME   28800 // 巡检请求周期，正式设置为8小时，28800秒

#define PROBE_ENCRYPT_AUCKEY       "\xe0\x2a\x56\x63\xda\x0a\xc8\x63\x8b\x62\xe3\x1a\x65\x63\x32\x6a"  // 转码后的加密密钥，转码前为4CpWY9oKyGOLYuMaZWMyag==

// ST_QP_MSG消息类型
#define QP_MSG_TYPE_UNDEFINE           0
#define QP_MSG_TYPE_COUNT_MINUTE       11
#define QP_MSG_TYPE_COUNT_HOUR         22
#define QP_MSG_TYPE_CHECK_REQUEST      33
#define QP_MSG_TYPE_CHECK_DATA         44

// ST_QP_MSG参数
#define PROBE_MSG_MAX_TIME_LEN         20
#define PROBE_MSG_MAXLEN               1024
#define TRANS_MSG_ENCRYPT_BUF_LEN      PROBE_MSG_MAXLEN + 100
#define TRANS_MSG_DECRYPT_BUF_LEN      PROBE_MSG_MAXLEN + 100

// trans任务相关参数
#define TRANS_RECV_BUF_LENGTH          2048      // trans接收缓冲区长度

// 云存相关参数
#define CLOUDSTORE_API_MAXLEN          512       // url, api最大长度

#define CLOUDSTORE_ACCOUNT_LENGTH      15
#define CLOUDSTORE_TOKEN_LENGTH        40
#define CLOUDSTORE_FILE_OPS_LENGTH     70
#define CLOUDSTORE_FILE_URL_LENGTH     500


// 各种长度
#define MSG_QUEUE_COUNT_MAX_SIZE       30        // 质态队列的最大长度
#define MSG_QUEUE_CHECK_MAX_SIZE       10        // 巡检队列的最大长度
#define MSG_QUEUE_AI_REQUEST_MAX_SIZE  30        // AI画面巡检请求队列的最大长度

#define PROBE_AI_MSG_MAXLEN            128
#define QP_CONFIG_FILE_MAX_LEN         256
#define QP_CONFIG_FILE_MAX_SIZE        1024
#define QP_CHECK_FILE_MAX_LEN          256

#define MSG_CHECK_MAX_STORE_SIZE           (MSG_QUEUE_CHECK_MAX_SIZE+1)*PROBE_MSG_MAXLEN //预留空间
#define MSG_AI_REQUEST_MAX_STORE_SIZE       (MSG_QUEUE_AI_REQUEST_MAX_SIZE+1)*PROBE_AI_MSG_MAXLEN //预留空间



/* Exported typedef ----------------------------------------------------------*/
// async https post传输状态机
typedef enum enum_QP_state_async_post_step
{
    EN_QP_STATE_ASYNC_POST_NOTRANS = 0x00, // 0 未上报
    EN_QP_STATE_ASYNC_POST_TRANSED = 0x01, // 1 已上报
    EN_QP_STATE_ASYNC_POST_SUCCESS = 0x02, // 2 发送失败
    EN_QP_STATE_ASYNC_POST_FAILED  = 0x03, // 3 发送失败
    EN_QP_STATE_ASYNC_POST_RETRY   = 0x04, // 4 重发
    EN_QP_STATE_ASYNC_POST_FINISH  = 0x05, // 5 结束发送
    EN_QP_STATE_ASYNC_POST_RESET   = 0x06, // 6 发送重置
    EN_QP_STATE_ASYNC_POST_EXT     = 0x07  // 7 扩展使用
}EN_QP_STATE_ASYNC_POST_STEP;

// sync https put传输状态机
typedef enum enum_QP_state_sync_put_step
{
    EN_QP_STATE_SYNC_PUT_PERMIT_CHECK = 0x00, // 0 传输内容检查
    EN_QP_STATE_SYNC_PUT_SEND         = 0x01, // 1 put发送
    EN_QP_STATE_SYNC_PUT_RETRY_CFG    = 0x02, // 2 重发配置
    EN_QP_STATE_SYNC_PUT_RETRY_CHECK  = 0x03, // 3 重发延迟
    EN_QP_STATE_SYNC_PUT_FINISH       = 0x04, // 4 结束发送    
    EN_QP_STATE_SYNC_PUT_FAILED       = 0x05  // 5 发送失败
}EN_QP_STATE_SYNC_PUT_STEP;

// camera检测状态机
typedef enum enum_QP_checkcamera_step
{
    EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT = 0x00, // 1.是否已开通云存网关，获取账号
    EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN,       // 2.get or check token
    EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL,      // 3.get snapshot file upload url
    EN_QP_STATE_CHECK_CAMERA_SEND_SNAPSHOT,      // 4.get and send picture to cloud store
    EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT,    // 5.commit and confirm snapshot upload
    EN_QP_STATE_CHECK_CAMERA_FINISH,             // 6.camera检测结束
    EN_QP_STATE_CHECK_CAMERA_SIZE                // 7.EN_QP_CHECK_CAMERA_STEP大小标记
}EN_QP_CHECK_CAMERA_STEP;

// camera检测结果类型
typedef enum enum_QP_checkcamera_https_result
{
    EN_QP_CHECK_CAMERA_HTTPS_INIT = 0x00,        // put或post初始值
    EN_QP_CHECK_CAMERA_HTTPS_WORKING,            // put或post异步工作中
    EN_QP_CHECK_CAMERA_HTTPS_OK,                   // put或post成功
    EN_QP_CHECK_CAMERA_HTTPS_ERR,                // put或post失败

    EN_QP_CHECK_CAMERA_GET_SNAPSHOT_ERROR        // 获取snapshot错误
}EN_QP_CHECK_CAMERA_HTTPS_RESULT;

// 质态数据发送trans传输数据类型
typedef enum enum_QP_trans_post_type
{
    EN_QP_TRANS_TYPE_COUNT = 1,
    EN_QP_TRANS_TYPE_CHECK
}EN_QP_TRANS_POST_TYPE;

// 质态巡检工作参数
// 指令下发的巡检参数
typedef struct stru_QP_CHECKTARGET_CONF
{
    _UC ucCheckModeCtrl;          // 巡检控制：0-巡检请求，1-巡检数据
    _UI uiCheckDataCycleTime;     // 巡检数据周期，单位：小时
    _UC ucCheckDataCloud[DEFAULT_URL_LEN];  // 待测试云存服务器
    _UC ucCheckDataTarget[DEFAULT_URL_LEN]; // 待测试指定服务器
}ST_QP_CHECKTARGET_CONF, *ST_QP_CHECKTARGET_CONF_PTR;

// 掉电保持
typedef struct st_QP_CONF
{
    _UI uiQpDataPauseFlag;        // 质态数据是否需要停止上报
    _CTIME_T cQpPauseTimestamp;       // 质态数据停止上报到哪个时间点
    _CTIME_T cQpLastTimestamp;       // 巡检数据最后一次上传的时间点

    _INT iImmSendFlag;//用于判断是否需要立即发送
    ST_QP_CHECKTARGET_CONF stCheckTargetCfg;// 巡检配置

    _UC aucAreaID[AREA_ID_LEN];   // 归属地
    _UI uiAreaIDTtl;              // 归属地有效期，接收到服务器配置的有效期天数后，根据当前日期计算转换为失效那天的时间戳
}ST_QP_CONF, * ST_QP_CONF_PTR;

// 质态传输数据管理
typedef struct st_QP_count_trans_mgr
{

    EN_QP_STATE_ASYNC_POST_STEP uiPostStep;    // post state for quality probe server

    _CTIME_T cSendTime;    // 本次请求发送时间
    _CTIME_T cNextSendTime; // 下次数据发送时间
    _UI      uiHasRecvLen; // 已接收数据长度

    _UI      uiRecvBufLen;
    _UC    * pucRecvBuf;

    // _UI      uiHttpHandle;
    // _UI      uiOgctId;

    _UC      aucUUID[64];
}ST_QP_COUNT_TRANS_MGR, * ST_QP_COUNT_TRANS_MGR_PTR;

// 巡检传输数据管理
typedef struct st_QP_check_trans_mgr
{
    _UC      ucRetransFlag;// 重发标记,1-重发，0-正常发送

    EN_QP_TRANS_POST_TYPE ucTransType; // 当前传输数据类型

    EN_QP_STATE_ASYNC_POST_STEP uiPostStep;    // post state for quality probe server

    _CTIME_T cSendTime;    // 请求发送时间
    _CTIME_T cRetransTime; // 重传时间

    _UI      iSendCnt;     // 发送次数
    _UI      iFailCnt;     // 失败次数
    _UI      uiHasRecvLen; // 已接收数据长度

    _UI      uiRecvBufLen;
    _UC    * pucRecvBuf;

    // _UI      uiHttpHandle;
    // _UI      uiOgctId;
    _UC      aucUUID[64];
}ST_QP_CHECK_TRANS_MGR, * ST_QP_CHECK_TRANS_MGR_PTR;

// 画面AI巡检请求数据管理
typedef struct st_QP_AI_insecption_trans_mgr
{
    _UC      ucRetransFlag;// 重发标记,1-重发，0-正常发送

    EN_QP_STATE_ASYNC_POST_STEP uiPostStep;    // post state for quality probe server

    _CTIME_T cSendTime;    // 请求发送时间
    _CTIME_T cRetransTime; // 重传时间

    _UI      iSendCnt;     // 发送次数
    _UI      iFailCnt;     // 失败次数
    _UI      uiHasRecvLen; // 已接收数据长度

    _UI      uiRecvBufLen;
    _UC    * pucRecvBuf;

    // _UI      uiHttpHandle;
    // _UI      uiOgctId;
}ST_QP_AI_INSECPTION_TRANS_MGR, * ST_QP_AI_INSECPTION_TRANS_MGR_PTR;


// 传输数据管理
typedef struct st_QP_check_camera_mgr
{
    EN_QP_CHECK_CAMERA_STEP iSnapshotStatusCode;    // 摄像头将画面发送至云存平台结果代码，详细结果在 gstAiServerStatusMsg 中定义

    EN_QP_CHECK_CAMERA_STEP uiCheckCameraStep;      // camera检测状态机

    EN_QP_CHECK_CAMERA_HTTPS_RESULT ucHttpsResult;  // 当前Https结果

    EN_QP_STATE_ASYNC_POST_STEP uiPostStep;         // post state for ai server
    EN_QP_STATE_SYNC_PUT_STEP   uiPutStep;          // put state for cloud store server

    _UI      iCheckCnt;      // Snapshot_PermitCheck次数

    _UC    * pucSendBuf;     // 发送数据缓存区
    _UI      uiSendBufLength;// 发送数据大小

    _UI      iSendCnt;       // 发送次数
    _UI      iFailCnt;     // 失败次数
    _CTIME_T cSendTime;      // 请求发送时间

    _CTIME_T cRetransTime;   // 重传时间

    _UI      uiHasRecvLen;   // 已接收数据长度

    _UI      uiRecvBufLen;
    _UC    * pucRecvBuf;

    _UI      uiHttpHandle;
    // _UI      uiOgctId;

    _UC      ucAccount[CLOUDSTORE_ACCOUNT_LENGTH];    // 云存网关账号
    _UC      ucAccountFlag;           // account 标记：0-无account，1-已获取

    _UC      ucToken[CLOUDSTORE_TOKEN_LENGTH];
    long     lTokenValidTimestamp;  // token有效时间

    _UC      ucFileID[CLOUDSTORE_FILE_OPS_LENGTH];   // 文件ID
    _UC      ucFileName[CLOUDSTORE_FILE_OPS_LENGTH]; // 文件Name
    _UC      ucFileCreateTime[PROBE_MSG_MAX_TIME_LEN]; // 文件CreateTime
    _UI      iFileSize; // 文件Size

    _UC      ucFileUploadUrl[CLOUDSTORE_FILE_URL_LENGTH];  // 获取到的云存文件上传地址
    _UC      aucUUID[40];// 用于信息技术部与智家平台的图片关联
}ST_QP_CHECK_CAMERA_MGR, * ST_QP_CHECK_CAMERA_MGR_PTR;

//质量探针任务需要的数据结构
typedef struct stru_QUALITYPROBE_TASKMNG
{
    _UI ucInitFlag;
    _UC ucRunFlag;
    
    _UI Records_check;
    _UI Records_ai;
    
    // 线程ID
    _HTHREAD hThread_quality;
    
    // 质态数据、巡检数据、AI画面检测请求传输管理
    ST_QP_COUNT_TRANS_MGR stCountTransMgr;
    ST_QP_CHECK_TRANS_MGR stCheckTransMgr;
    ST_QP_AI_INSECPTION_TRANS_MGR stAIInsecptionTransMgr;

    // AI平台、云存平台传输管理
    ST_QP_CHECK_CAMERA_MGR stCheckCameraMgr;

    //配置文件锁
    _HMUTEX hConfFileMutex;
    
    //巡检数据文件锁
    _HMUTEX hCheckFileMutex;

    //Ai数据文件锁
    _HMUTEX hAiFileMutex;    
        
    // 工作配置
    ST_QP_CONF stQpConfig;

    _UC aucCheckDataFileName[QP_CHECK_FILE_MAX_LEN];
    
    _UC aucAIInsecptionDataFileName[QP_CHECK_FILE_MAX_LEN];
}ST_QP_TASK_MNG, *ST_QP_TASK_MNG_PTR;

//质量探针上报的数据格式
typedef struct stru_QP_MSG
{
    _UC ucMsgType;
    _UC aucUUID[40];// 用于信息技术部与智家平台的图片关联
    _UC aucFileCreateTime[PROBE_MSG_MAX_TIME_LEN]; // 文件CreateTime
    _UC ucData[PROBE_MSG_MAXLEN];//实际上报的数据
}ST_QP_MSG, * ST_QP_MSG_PTR;

//AI画面巡检上报的数据格式
typedef struct stru_QP_AI_INSECPTION_MSG
{
    _UC aucUUID[40];// 用于信息技术部与智家平台的图片关联
    _UC aucFileCreateTime[PROBE_MSG_MAX_TIME_LEN]; // 文件CreateTime    
}ST_QP_AI_INSECPTION_MSG, * ST_QP_AI_INSECPTION_MSG_PTR;

// 质态数据
// 接口调用结果
typedef struct stru_IFCALL_RS
{
    _INT iSuccessCnt[COUNT_TYPE_MAX_NUM];
    _INT iFailCnt[COUNT_TYPE_MAX_NUM];
    _INT iLess2Cnt[COUNT_TYPE_MAX_NUM];
    _INT iTotalCnt[COUNT_TYPE_MAX_NUM];
}ST_COUNT_RS, * ST_COUNT_RS_PTR;

// 每分钟质态数据
typedef struct stru_QP_MINUTE_INFO
{
    _UC  dataOccurTime[DATE_TIME_LEN];

    // 接口调用情况
    _INT iCloudStoreCnt;
    _INT iCloudStoreSucessCnt;
    _INT iCloudStoreLess2Cnt;

    _INT iOtaCnt;
    _INT iOtaSucessCnt;
    _INT iOtaLess2Cnt;

    _INT iWifiCfgCnt;
    _INT iWifiCfgSucessCnt;
    _INT iWifiCfgLess2Cnt;

    _INT iCmdCnt;
    _INT iCmdSucessCnt;
    _INT iCmdLess2Cnt;

    _INT iVodCnt;
    _INT iVodSucessCnt;
    _INT iVodLess2Cnt;

    _INT iWarningCnt;
    _INT iWarningSucessCnt;
    _INT iWarningLess2Cnt;

    _INT iDevRegisterCnt;
    _INT iDevRegisterSucessCnt;
    _INT iDevRegisterLess2Cnt;

    // 云存文件上传情况
    _INT iCloudStoreFileCnt;
    _INT iCloudStoreFileSucessCnt;
    _INT iCloudStoreFileLess2Cnt;

    // p2p调用情况
    _INT iP2PCallCnt;
    _INT iP2PCallSucessCnt;    
    _INT iP2PCallLess2Cnt;
}ST_QP_MINUTE_INFO, *ST_QP_MINUTE_INFO_PTR;

// 每小时质态数据
typedef struct stru_QP_HOUR_INFO
{
    _UC  dataOccurTime[DATE_TIME_LEN];

    _UC  ipaddr[64];

    // 云存储流量
    _INT  send_flow;

    // 云存储速率
    _INT send_speed;

    // 设备负载信息
    _INT cpu_usage;
    _INT ram_usage;
    _INT sd_status;     // 0-正常, 1-卡不可用, 2-无卡, 3-异常
    _INT sd_reserve;
    _INT sd_total;
    _INT net_mode;
    _INT sigstrength;
}ST_QP_HOUR_INFO, *ST_QP_HOUR_INFO_PTR;

// ping测试结果
typedef struct stru_QP_PING_RESULT
{
    _INT result;

    _UI  mindelay;
    _UI  maxdelay;
    _UI  avgdelay;
    _UI  missrate;
}ST_QP_PING_RESULT, *ST_QP_PING_RESULT_PTR;


/* Exported variables --------------------------------------------------------*/


/* Exported functions --------------------------------------------------------*/
// qualityprobe_checkcamera.c
EN_QP_CHECK_CAMERA_STEP Qp_Check_Camera_Probe(void);

// qualityprobe_countifcall.c
_INT Qp_CountIF_Init(void);
_INT Qp_CountIF_ReadClear(ST_COUNT_RS_PTR pstCountStatics);

_INT Qp_Task_Loop(_VPTR pParam);


// qualityprobe_taskcount.c
_INT Qp_TaskCount_Entry(ST_MOS_SYS_TIME *minBeginTime, ST_MOS_SYS_TIME *hourBeginTime);

// qualityprobe_taskcheck.c
_INT Qp_TaskCheck_Entry();

// qualityprobe_taskai.c
_INT Qp_TaskAi_Entry();

_INT Qp_TaskAi_SaveFile(ST_QP_AI_INSECPTION_MSG *stQPAIMsgNode);

// qualityprobe_taskmain.c
ST_QP_TASK_MNG * Qp_Task_GetTaskMng(void);

// qualityprobe_utils_https.c
_INT Qp_Utils_Https_Putfile(_UC *url, _UC *putbuf, _UI putbufsize);

// qualityprobe_utils_rw_config.c
_INT Qp_Utils_Config_Read(ST_QP_CONF_PTR pstQpConfig);
_INT Qp_Utils_Config_Write(ST_QP_CONF_PTR pstQpConfig);

// qualityprobe_utils.c
_INT Qp_utils_TimeCompare(ST_MOS_SYS_TIME compUseT, ST_MOS_SYS_TIME currentT, long compareValue);
_INT Qp_utils_DNSParse(_UC * pucUrl, _UC * pucIp);
_INT Qp_utils_PingIP(_UC * pucIP, ST_QP_PING_RESULT_PTR pstPingRs, _UI ping_delay, _UI uiPingNum);
_INT Qp_utils_UUID(_UC * pucUUID);
_INT Qp_utils_UUID_NoCrossBar(_UC * pucUUID);
_INT Qp_utils_Sha1Encode(_UC * input, _UI inlen, _UC* output);
ST_MOS_INET_IP* Qp_utils_ParseUrl(_UC *url, _UC *aucHost, _UC *aucPath, ST_MOS_INET_IPARRAY *pstIpArray, _UI* puiHttpsFlag);
_INT Qp_Store_WriteCheckDataByDir(ST_QP_MSG * pstQPMsgNode, _UC* saveFileDir);
_UC* Qp_utils_GetUID();
_INT Qp_CountIF_Clear();
_INT Qp_Store_ReadCheckDataByDir(ST_QP_MSG * pstMsgNode, _INT index, _UC* fileDir);
_INT Qp_Store_DeleteFileContenBySizeADir(_UC* pucFileDir,_UC ucDeleteNum);
_INT Qp_Store_FileInitialize();
_INT Qp_utils_AsyncHttps_AesBase64_Decrypt(_UC * pucInBuf, _UC * pucLv, _UC * pucOutBuf);
_INT Qp_utils_AsyncHttps_AesBase64_ECB_Encrypt(_UC * pucInBuf, _UC * pucOutBuf);
_INT Qp_utils_AsyncHttps_AesBase64_Encrypt(_UC * pucInBuf, _UC * pucLv, _UC * pucOutBuf);
_UC * Qp_Check_Camera_AsyncHttps_BuildEncryptReqData(_UC* pucData);
void Qp_Check_Camera_AsyncHttps_BuildReqData_AuthenticationHeadWithSign(_UC * pucAddBuff,_UC* pucData);


#ifdef __cplusplus
}
#endif

#endif
