#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"

#include "qualityprobe_api.h"
#include "qualityprobe_type_prv.h"

#include "mos_socket.h"
#include "tras_httpclient.h" 

#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

static long gstAITimeStamp    = {0};
static ST_QP_AI_INSECPTION_MSG gstAISendBufMsg = {0};

/*******************************************************************************************************
    Private Function Prototypes
********************************************************************************************************/

/*******************************************************************************************************
    Check Data Functions
********************************************************************************************************/
static _INT Qp_TaskAi_ParseAIRsp(_UC *pucJson)
{
    _UC *pucStrTmp = MOS_NULL;
    
    _INT  uiResultCode = 0;

    JSON_HANDLE hJsonRoot = MOS_NULL;

    hJsonRoot = Adpt_Json_Parse(pucJson);
    if (hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"CODE"),    &uiResultCode);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"CodeMsg"), &pucStrTmp);

    // 检测是否接收成功
    if (uiResultCode != 0)
    {
        MOS_LOG_ERR(QP_AI, "post trans msg err, code[%d], msg[%s]", uiResultCode, pucStrTmp);
        Adpt_Json_Delete(hJsonRoot);
        return MOS_ERR;
    }

    Adpt_Json_Delete(hJsonRoot);

    return MOS_OK;
}

static _VOID Qp_TaskAi_RecvAIRspFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    ST_QP_AI_INSECPTION_TRANS_MGR* pstAITransMgr = &Qp_Task_GetTaskMng()->stAIInsecptionTransMgr;

    MOS_LOG_INF(QP_AI, "recv ai data fail");

    if (pstAITransMgr)
    {
        if (pstAITransMgr->pucRecvBuf)
        {
               MOS_FREE(pstAITransMgr->pucRecvBuf);            
        }

        pstAITransMgr->ucRetransFlag= 1;            
        if (pstAITransMgr->iFailCnt < 24)
        {
            pstAITransMgr->iFailCnt++;    
        }
        pstAITransMgr->cRetransTime = Mos_Time() + (pstAITransMgr->iFailCnt * 5 * 60);

        pstAITransMgr->uiPostStep= EN_QP_STATE_ASYNC_POST_NOTRANS;
        // 复位发送过程中的标记
        // pstAITransMgr->uiOgctId     = 0;
        pstAITransMgr->uiHasRecvLen = 0;
        pstAITransMgr->uiRecvBufLen = 0;
        pstAITransMgr->pucRecvBuf = MOS_NULL;
        
    }

    return;
}

static _VOID Qp_TaskAi_RecvAIRspFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iRet = 0;
    ST_QP_AI_INSECPTION_TRANS_MGR* pstAITransMgr = &Qp_Task_GetTaskMng()->stAIInsecptionTransMgr;
    if (pstAITransMgr == MOS_NULL)
    {        
        return;
    }

    /*if (pstAITransMgr->uiOgctId != (_UI)vpUserPtr)
    {
        MOS_LOG_INF(QP_AI, "ogct %u different form net %u", pstAITransMgr->uiOgctId, (_UI)vpUserPtr);
        
        Http_Httpclient_CancelAsyncRequest(pstAITransMgr->uiHttpHandle);
        pstAITransMgr->uiHttpHandle = 0;
        
        return;
    }*/

    // 接收完毕，解析服务返回的数据
    if (pstAITransMgr->pucRecvBuf)
    {
        pstAITransMgr->pucRecvBuf[pstAITransMgr->uiHasRecvLen] = 0;
        MOS_LOG_INF(QP_AI, "Ai rsp : %s",pstAITransMgr->pucRecvBuf);
    }
    
    iRet = Qp_TaskAi_ParseAIRsp(pstAITransMgr->pucRecvBuf);    
    if (iRet == MOS_ERR)
    {    
        MOS_LOG_ERR(QP_AI, "parse server ai request data rsp error");
    }
    else
    {
        MOS_LOG_INF(QP_AI, "parse server ai request rsp success");
    }

    MOS_FREE(pstAITransMgr->pucRecvBuf);

    // 复位发送过程中的标记
    // pstAITransMgr->uiOgctId     = 0;
    pstAITransMgr->ucRetransFlag= 0;
    pstAITransMgr->uiHasRecvLen = 0;
    pstAITransMgr->uiRecvBufLen = 0;
    pstAITransMgr->pucRecvBuf = MOS_NULL;

    //删除发送成功的数据
    Mos_MutexLock(&Qp_Task_GetTaskMng()->hAiFileMutex);
    Qp_Store_DeleteAIContenBySizeADir(Qp_Task_GetTaskMng()->aucAIInsecptionDataFileName,1);
    Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hAiFileMutex);

    pstAITransMgr->ucRetransFlag = 0;            
    pstAITransMgr->iFailCnt      = 0;    
    pstAITransMgr->uiPostStep    = EN_QP_STATE_ASYNC_POST_NOTRANS;
    
    return;
}

static _VOID Qp_TaskAi_RecvAIRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
       ST_QP_AI_INSECPTION_TRANS_MGR* pstAITransMgr = &Qp_Task_GetTaskMng()->stAIInsecptionTransMgr;

    /*if (pstAITransMgr == MOS_NULL || pstAITransMgr->uiOgctId != (_UI)vpUserPtr)
    {
        MOS_LOG_INF(QP_AI, "ogct %u different form net %u", pstAITransMgr->uiOgctId, (_UI)vpUserPtr); 
        return;
    }*/

    // 如果当前接收buf还没有分配空间
    if (pstAITransMgr->uiRecvBufLen == 0)
    {
        pstAITransMgr->uiRecvBufLen = TRANS_RECV_BUF_LENGTH;
        pstAITransMgr->pucRecvBuf   = (_UC*)MOS_MALLOCCLR(TRANS_RECV_BUF_LENGTH);
    }

    // 还剩空余的空间则缓存下来
    if (pstAITransMgr->uiHasRecvLen + uiLen < pstAITransMgr->uiRecvBufLen)
    {
        MOS_MEMCPY(pstAITransMgr->pucRecvBuf + pstAITransMgr->uiHasRecvLen, pucData, uiLen);
        pstAITransMgr->uiHasRecvLen += uiLen;
    }
    else
    {
        MOS_LOG_INF(QP_AI, "without enough buf");
    }

    return;
}

static _UC * Qp_TaskAi_BuildAIReqData(ST_QP_AI_INSECPTION_MSG *stQPAIMsgNode)
{
    _UC *pstrTmp = MOS_NULL;

    _UC aucBuf[20] = {0};

    JSON_HANDLE hRoot = MOS_NULL, hValue = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    // add METHOD, SEQID
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"METHOD", Adpt_Json_CreateString((_UC *)"3510"));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"SEQID", Adpt_Json_CreateString(stQPAIMsgNode->aucUUID));

    // body
    // build body
    hValue = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hValue, (_UC *)"DID", Adpt_Json_CreateString(Qp_utils_GetUID()));
    Adpt_Json_AddItemToObject(hValue, (_UC *)"ctei", Adpt_Json_CreateString((_UC *)(Config_GetSystemMng()->aucDevCTEI)));
    Adpt_Json_AddItemToObject(hValue, (_UC *)"AIIoTType", Adpt_Json_CreateString((_UC *)"deviceround"));
    Adpt_Json_AddItemToObject(hValue, (_UC *)"EventID", Adpt_Json_CreateString((_UC *)"0"));

    // add timestamp

    MOS_VSNPRINTF(aucBuf, 16, (_UC *)"%ld000", gstAITimeStamp);
    Adpt_Json_AddItemToObject(hValue, (_UC *)"Time",       Adpt_Json_CreateString(aucBuf));
    Adpt_Json_AddItemToObject(hValue, (_UC *)"TimeStamp",  Adpt_Json_CreateString(aucBuf));
    Adpt_Json_AddItemToObject(hValue, (_UC *)"CreateTime", Adpt_Json_CreateString(stQPAIMsgNode->aucFileCreateTime));

    Adpt_Json_AddItemToObject(hValue, (_UC *)"deviceType", Adpt_Json_CreateString((_UC *)(Config_GetDeviceMng()->aucDevModel)));
    Adpt_Json_AddItemToObject(hValue, (_UC *)"Describe",   Adpt_Json_CreateString(aucBuf));

    // add body
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"BODY", hValue);

    pstrTmp = Adpt_Json_Print(hRoot);
    MOS_LOG_INF(QP_AI, "Send Ai Data : %s",pstrTmp);

    
    Adpt_Json_Delete(hRoot);
    
    return pstrTmp;
}

void Qp_TaskAi_BuildReqData_AuthenticationHeadWithSign(_UC * pucAddBuff,_UC* pucData)
{
    _UC aucUUID[40] = {0};
    _UC aucTempBuf[100] = {0};
    _UC aucCheckNum[150] = {0};
    _UC aucSign[64] = {0};
    _UC *pucSignBuff = MOS_NULL;
    _INT iDataLen = 0;
    long lNonce = 0;
    long timestamp = 0;
    ST_MOS_SYS_TIME stCurTime;


    // UUID,格式如：4a10453a-bce3-4246-ab47-74b0d1132b63
    Qp_utils_UUID(aucUUID);

    // CurTime 时间戳
    Mos_GetSysTime(&stCurTime);
    timestamp = (long)Mos_SysTimetoTime(&stCurTime);

    // Nonce 随机数
    lNonce = timestamp;

    // CheckNum 校验值
    MOS_SPRINTF(aucTempBuf, "%ld%s%ld000", lNonce, X_AISecretKey, timestamp);
    Adpt_Sha_Encrypt(aucTempBuf,MOS_STRLEN(aucTempBuf),aucCheckNum);

    //签名
    iDataLen = MOS_STRLEN(pucData);
    pucSignBuff = (_UC*)MOS_MALLOCCLR(iDataLen+128);
    MOS_SPRINTF(pucSignBuff, "%s%s", X_AISecretKey, pucData);
    Adpt_Sha_Encrypt(pucSignBuff,MOS_STRLEN(pucSignBuff),aucSign);

    MOS_VSNPRINTF(pucAddBuff, AUTHENTICATION_HEAD_LEN, "X-APP-ID: %s\r\n"
                                                        "X-APP-KEY: %s\r\n"
                                                        "X-CTG-Request-Id: %s\r\n"
                                                        "Nonce: %ld\r\n"
                                                        "CurTime: %ld000\r\n"
                                                        "CheckNum: %s\r\n"
                                                        "Sign: %s\r\n",
                                                        X_AIAPP_ID,
                                                        X_AIAPP_KEY,
                                                        aucUUID,
                                                        lNonce,
                                                        timestamp,
                                                        aucCheckNum,
                                                        aucSign);
    MOS_FREE(pucSignBuff);
    return;
}

static _UC * Qp_TaskAi_AsyncHttps_BuildEncryptReqData(_UC* pucData)
{
    JSON_HANDLE hRoot = MOS_NULL;
    _UC* pstrTmp = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    // add METHOD, SEQID
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"params", Adpt_Json_CreateString(pucData));

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pstrTmp;
}

static _INT Qp_TaskAi_AsycPostAIData(ST_QP_AI_INSECPTION_MSG *stQPAIMsgNode)
{
    _INT iRet        = MOS_ERR;
    _UC *pStrTmp     = MOS_NULL;
    _UC *pStrAddhead = MOS_NULL;
    _UC *pEncryptStr = MOS_NULL;
    _UC *pFinalStr   = MOS_NULL;
    
    _UC aucHost[256] = {0};
    _UC aucPath[256] = {0};
    _UC aucUUID[64] = {0};
    _UI uiHttpsFlag = 0;
    ST_MOS_SYS_TIME stCurTime;
    _UC aucServerAddr[CLOUDSTORE_API_MAXLEN]   = {0};  //平台地址
    
    ST_QP_AI_INSECPTION_TRANS_MGR* pstAITransMgr = &Qp_Task_GetTaskMng()->stAIInsecptionTransMgr;

    //时间戳
    Mos_GetSysTime(&stCurTime);
    gstAITimeStamp = (long)Mos_SysTimetoTime(&stCurTime);

    //记录上传的图片信息，用于后续的画面巡检推送功能
    //MOS_MEMSET(aucServerAddr, 0, CLOUDSTORE_API_MAXLEN);
    //MOS_VSNPRINTF(aucServerAddr, sizeof(aucServerAddr), "%s", QUALITY_PROBE_CHECK_PICTURE_REPORT_URL);
    MOS_MEMSET(aucServerAddr, 0, CLOUDSTORE_API_MAXLEN);
    MOS_VSNPRINTF(aucServerAddr, sizeof(aucServerAddr), "%s%s", AI_HTTPS_URL,AI_HTTPS_URL_API_REPORT_SNAPSHOT);

    //获取ST_MOS_INET_IP
    iRet = Http_Parse_Url(aucServerAddr, aucHost, aucPath, &uiHttpsFlag);
    if (iRet == MOS_ERR){
        MOS_LOG_ERR(QP_AI, "Http_Parse_Url error");
        return MOS_ERR;
    }
    //构建未加密前的请求数据
    pStrTmp = Qp_TaskAi_BuildAIReqData(stQPAIMsgNode);

    //推送巡检，都是信息技术部接口，需要自定义header跟加密的body
    //构建请求头
    pStrAddhead = (_UC *)MOS_MALLOCCLR(AUTHENTICATION_HEAD_LEN);
    if (MOS_NULL == pStrAddhead)
    {
        MOS_LOG_INF(QP_AI, "MOS_MALLOCCLR Failed");
        MOS_FREE(pStrTmp);
        return MOS_ERR;
    }
    Qp_TaskAi_BuildReqData_AuthenticationHeadWithSign(pStrAddhead,pStrTmp);

    //encrypt request body 
    pEncryptStr = MOS_MALLOCCLR(MOS_STRLEN(pStrTmp)/3*4+32);
    if (MOS_NULL == pEncryptStr)
    {
        MOS_LOG_ERR(QP_AI, "MOS_MALLOCCLR Failed");
        MOS_FREE(pStrTmp);
        MOS_FREE(pStrAddhead);
        return MOS_ERR;
    }
    Qp_utils_AsyncHttps_AesBase64_ECB_Encrypt(pStrTmp,pEncryptStr);


    pFinalStr = Qp_TaskAi_AsyncHttps_BuildEncryptReqData(pEncryptStr);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = Qp_TaskAi_RecvAIRsp;
    stHttpInfoNode.pfuncFinished   = Qp_TaskAi_RecvAIRspFinish;
    stHttpInfoNode.pfuncFailed     = Qp_TaskAi_RecvAIRspFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pFinalStr;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pFinalStr);
    stHttpInfoNode.pucExpandHeader = pStrAddhead;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, aucHost, aucPath, EN_HTTP_METHOD_POST, Mos_GetSessionId());

    MOS_FREE(pStrTmp);
    MOS_FREE(pEncryptStr);
    MOS_FREE(pFinalStr);
    MOS_FREE(pStrAddhead);
    
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

_INT Qp_TaskAi_SaveFile(ST_QP_AI_INSECPTION_MSG *stQPAIMsgNode)
{
    //写入待发送数据到文件中
    Mos_MutexLock(&Qp_Task_GetTaskMng()->hAiFileMutex);
    Qp_Store_WriteAIDataByDir(stQPAIMsgNode,Qp_Task_GetTaskMng()->aucAIInsecptionDataFileName);
    Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hAiFileMutex);

    ST_QP_AI_INSECPTION_TRANS_MGR* pstAITransMgr = &Qp_Task_GetTaskMng()->stAIInsecptionTransMgr;
    pstAITransMgr->ucRetransFlag = 0;    

    return MOS_OK;
}

/*******************************************************************************************************
    Exported Functions
********************************************************************************************************/
_INT Qp_TaskAi_Entry()
{
    ST_QP_AI_INSECPTION_TRANS_MGR* pstAITransMgr = &Qp_Task_GetTaskMng()->stAIInsecptionTransMgr;
    if (pstAITransMgr->uiPostStep == EN_QP_STATE_ASYNC_POST_TRANSED)
    {
        return MOS_OK;
    }

    _CTIME_T cNowTime = Mos_Time();    
    if (Qp_Task_GetTaskMng()->Records_ai > 0  &&
        (pstAITransMgr->ucRetransFlag == 0 || (pstAITransMgr->ucRetransFlag == 1 && cNowTime >= pstAITransMgr->cRetransTime)))
    {
        MOS_LOG_INF(QP_CHECK, "Start Send Ai Request Data");
        
        pstAITransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_TRANSED;    
        pstAITransMgr->iSendCnt ++;
        pstAITransMgr->cSendTime = Mos_Time();
        // pstAITransMgr->uiOgctId  = Mos_GetSessionId();    
        
        //从文件里面读取待发送数据
        MOS_MEMSET(&gstAISendBufMsg, 0, sizeof(ST_QP_AI_INSECPTION_MSG));
        Mos_MutexLock(&Qp_Task_GetTaskMng()->hAiFileMutex);
        Qp_Store_ReadAIDataByDir(&gstAISendBufMsg, 1, Qp_Task_GetTaskMng()->aucAIInsecptionDataFileName);
        Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hAiFileMutex);
 
        if (MOS_OK != Qp_TaskAi_AsycPostAIData(&gstAISendBufMsg))
        {
            pstAITransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_NOTRANS;
            MOS_LOG_ERR(QP_TASK, "Send Ai Request Data Error");
        }            
    }
    return MOS_OK;   
}
