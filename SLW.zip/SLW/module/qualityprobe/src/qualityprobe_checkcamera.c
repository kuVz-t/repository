#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"

#include "qualityprobe_api.h"
#include "qualityprobe_type_prv.h"

#include "mos_socket.h"
#include "tras_httpclient.h" 

#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"

static char* apucQpStatePrint[]={
    "EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT",
    "EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN",
    "EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL",
    "EN_QP_STATE_CHECK_CAMERA_SEND_SNAPSHOT",
    "EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT",
    "EN_QP_STATE_CHECK_CAMERA_FINISH"
};

static char* apucQpPutStatePrint[]={
    "EN_QP_STATE_SYNC_PUT_PERMIT_CHECK",
    "EN_QP_STATE_SYNC_PUT_SEND",
    "EN_QP_STATE_SYNC_PUT_RETRY_CFG",
    "EN_QP_STATE_SYNC_PUT_RETRY_CHECK",
    "EN_QP_STATE_SYNC_PUT_FINISH"
};

/*******************************************************************************************************
    Private Function Prototypes
********************************************************************************************************/
static void Qp_Check_Camera_AsyncHttps_BuildReqData_AuthenticationHead(_UC * pucAddBuff)
{
    _UC aucUUID[40]      = {0};
    _UC aucTempBuf[100]  = {0};
    _UC aucCheckNum[150] = {0};

    long lNonce    = 0;
    long timestamp = 0;
    ST_MOS_SYS_TIME stCurTime;


    // UUID,格式如：4a10453a-bce3-4246-ab47-74b0d1132b63
    Qp_utils_UUID(aucUUID);

    // CurTime 时间戳
    Mos_GetSysTime(&stCurTime);
    timestamp = (long)Mos_SysTimetoTime(&stCurTime);

    // Nonce 随机数
    lNonce = timestamp;

    // CheckNum 校验值
    MOS_SPRINTF(aucTempBuf, "%ld%s%ld000", lNonce, X_AISecretKey, timestamp);
    Adpt_Sha_Encrypt(aucTempBuf,MOS_STRLEN(aucTempBuf),aucCheckNum);

    MOS_VSNPRINTF(pucAddBuff, AUTHENTICATION_HEAD_LEN, "X-APP-ID: %s\r\n"
                                                       "X-APP-KEY: %s\r\n"
                                                       "X-CTG-Request-Id: %s\r\n"
                                                       "Nonce: %ld\r\n"
                                                       "CurTime: %ld000\r\n"
                                                       "CheckNum: %s\r\n",
                                                       X_AIAPP_ID,
                                                       X_AIAPP_KEY,
                                                       aucUUID,
                                                       lNonce,
                                                       timestamp,
                                                       aucCheckNum);

    return;
}

#if 0
static void Qp_Check_Camera_AsyncHttps_BuildReqData_AuthenticationHead_Debug(_UC * pucAddBuff)
{
    _UC aucUUID[40] = {0};
    _UC aucTempBuf[100] = {0};
    _UC aucCheckNum[150] = {0};

    long lNonce = 0;
    long timestamp = 0;
    ST_MOS_SYS_TIME stCurTime;


    // UUID,格式如：4a10453a-bce3-4246-ab47-74b0d1132b63
    Qp_utils_UUID(aucUUID);

    // CurTime 时间戳
    Mos_GetSysTime(&stCurTime);
    timestamp = (long)Mos_SysTimetoTime(&stCurTime);

    // Nonce 随机数
    lNonce = timestamp;

    // CheckNum 校验值
    MOS_SPRINTF(aucTempBuf, "%ld%s%ld000", lNonce, "93b37b263bd04a848a74d06d7544e441", timestamp);
    Adpt_HmacSha256_Encrypt(aucTempBuf,aucCheckNum,128,Config_GetSystemMng()->aucDevkey);

    MOS_VSNPRINTF(pucAddBuff, AUTHENTICATION_HEAD_LEN, "X-APP-ID: %s\r\n"
                                                       "X-APP-KEY: %s\r\n"
                                                       "X-CTG-Request-Id: %s\r\n"
                                                       "Nonce: %ld\r\n"
                                                       "CurTime: %ld000\r\n"
                                                       "CheckNum: %s\r\n",
                                                       "58c4f98407f5ba063113fe2776a6ed8f",
                                                       "5b10f8d66c1428abda8f6527c5a689df",
                                                       aucUUID,
                                                       lNonce,
                                                       timestamp,
                                                       aucCheckNum);

    return;
}
#endif


void Qp_Check_Camera_AsyncHttps_BuildReqData_AuthenticationHeadWithSign(_UC * pucAddBuff,_UC* pucData)
{
    _UC aucUUID[40]      = {0};
    _UC aucTempBuf[100]  = {0};
    _UC aucCheckNum[150] = {0};
    _UC aucSign[64]      = {0};
    _UC *pucSignBuff     = MOS_NULL;
    _INT iDataLen        = 0;
    long lNonce          = 0;
    long timestamp       = 0;
    ST_MOS_SYS_TIME stCurTime;


    // UUID,格式如：4a10453a-bce3-4246-ab47-74b0d1132b63
    Qp_utils_UUID(aucUUID);

    // CurTime 时间戳
    Mos_GetSysTime(&stCurTime);
    timestamp = (long)Mos_SysTimetoTime(&stCurTime);

    // Nonce 随机数
    lNonce = timestamp;

    // CheckNum 校验值
    MOS_SPRINTF(aucTempBuf, "%ld%s%ld000", lNonce, X_AISecretKey, timestamp);
    Adpt_Sha_Encrypt(aucTempBuf,MOS_STRLEN(aucTempBuf),aucCheckNum);

    //签名
    iDataLen = MOS_STRLEN(pucData);
    pucSignBuff = (_UC*)MOS_MALLOCCLR(iDataLen+128);
    MOS_SPRINTF(pucSignBuff, "%s%s", X_AISecretKey, pucData);
    Adpt_Sha_Encrypt(pucSignBuff,MOS_STRLEN(pucSignBuff),aucSign);

    MOS_VSNPRINTF(pucAddBuff, AUTHENTICATION_HEAD_LEN, "X-APP-ID: %s\r\n"
                                                        "X-APP-KEY: %s\r\n"
                                                        "X-CTG-Request-Id: %s\r\n"
                                                        "Nonce: %ld\r\n"
                                                        "CurTime: %ld000\r\n"
                                                        "CheckNum: %s\r\n"
                                                        "Sign: %s\r\n",
                                                        X_AIAPP_ID,
                                                        X_AIAPP_KEY,
                                                        aucUUID,
                                                        lNonce,
                                                        timestamp,
                                                        aucCheckNum,
                                                        aucSign);
    MOS_FREE(pucSignBuff);
    return;
}

static _UC * Qp_Check_Camera_AsyncHttps_BuildReqData_GetAccount(_UI uiTaskId)
{
    _UC *pstrTmp       = MOS_NULL;
    _UC aucBuf[20]     = {0};
    _UC aucProvince[7] = {0};

    JSON_HANDLE hRoot  = MOS_NULL;

    long timestamp     = 0;
    ST_MOS_SYS_TIME stCurTime;


    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    // add ctei, areaId, remark, 
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"DID", Adpt_Json_CreateString(Qp_utils_GetUID()));

    Mos_GetSysTime(&stCurTime);
    timestamp = (long)Mos_SysTimetoTime(&stCurTime);

    // uiAreaIDTtl为0表明无归属地信息，或当前时间戳大于uiAreaIDTtl存储的时间戳，表明uiAreaIDTtl失效
    if ((0 == Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl) || (timestamp > Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl))
    {
        Adpt_Json_AddItemToObject(hRoot, (_UC*)"areaId", Adpt_Json_CreateString((_UC*)"000000"));
    }
    else
    {
        MOS_VSNPRINTF(aucProvince, sizeof(aucProvince), "%c%c0000", Qp_Task_GetTaskMng()->stQpConfig.aucAreaID[0],Qp_Task_GetTaskMng()->stQpConfig.aucAreaID[1]);
        Adpt_Json_AddItemToObject(hRoot, (_UC*)"areaId", Adpt_Json_CreateString(aucProvince));
    }

    Adpt_Json_AddItemToObject(hRoot, (_UC *)"remark", Adpt_Json_CreateString((_UC *)""));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"serviceType", Adpt_Json_CreateString((_UC *)"tyai_deviceround"));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"userAccount", Adpt_Json_CreateString((_UC *)"tyai_deviceround"));

    MOS_VSNPRINTF(aucBuf, 16, (_UC *)"%ld000", timestamp);
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"TimeStamp", Adpt_Json_CreateString(aucBuf));

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pstrTmp;
}

static _UC * Qp_Check_Camera_AsyncHttps_BuildReqData_UpdateToken(_UI uiTaskId)
{
    _UC *pstrTmp   = MOS_NULL;

    _UC aucBuf[20] = {0};

    JSON_HANDLE hRoot = MOS_NULL;

    long timestamp = 0;
    ST_MOS_SYS_TIME stCurTime;

    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    // add ctei, areaId, remark, 
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"DID", Adpt_Json_CreateString(Qp_utils_GetUID()));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"account", Adpt_Json_CreateString((_UC *)pstAsyncHttpsPostMgr->ucAccount));

    // add timestamp
    Mos_GetSysTime(&stCurTime);
    timestamp = (long)Mos_SysTimetoTime(&stCurTime);

    MOS_VSNPRINTF(aucBuf, 16, (_UC *)"%ld000", timestamp);
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"TimeStamp", Adpt_Json_CreateString(aucBuf));

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pstrTmp;
}

static _UC * Qp_Check_Camera_AsyncHttps_BuildReqData_GetUploadUrl(_UI uiTaskId)
{
    _UC *pstrTmp = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;

    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    Adpt_Json_AddItemToObject(hRoot, (_UC *)"account", Adpt_Json_CreateString((_UC *)pstAsyncHttpsPostMgr->ucAccount));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"token", Adpt_Json_CreateString((_UC *)pstAsyncHttpsPostMgr->ucToken));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"num", Adpt_Json_CreateNumber(1));
    
    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pstrTmp;
}


static _UC * Qp_Check_Camera_AsyncHttps_BuildReqData_CommitFileName(_UI uiTaskId)
{
    _UC *pstrTmp = MOS_NULL;

    JSON_HANDLE hRoot = MOS_NULL;

    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    Adpt_Json_AddItemToObject(hRoot, (_UC *)"account", Adpt_Json_CreateString((_UC *)pstAsyncHttpsPostMgr->ucAccount));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"token", Adpt_Json_CreateString((_UC *)pstAsyncHttpsPostMgr->ucToken));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"fileID", Adpt_Json_CreateString((_UC *)pstAsyncHttpsPostMgr->ucFileID));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"fileName", Adpt_Json_CreateString((_UC *)pstAsyncHttpsPostMgr->ucFileName));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"fileSize", Adpt_Json_CreateNumber(pstAsyncHttpsPostMgr->iFileSize));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"errorCode", Adpt_Json_CreateNumber(0));
    //Adpt_Json_AddItemToObject(hRoot, (_UC *)"errorInfo", Adpt_Json_CreateString((_UC *)"error"));

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pstrTmp;
}




_UC * Qp_Check_Camera_AsyncHttps_BuildEncryptReqData(_UC* pucData)
{
    JSON_HANDLE hRoot = MOS_NULL;
    _UC* pstrTmp = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    // add METHOD, SEQID
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"params", Adpt_Json_CreateString(pucData));

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pstrTmp;
}


static _VOID Qp_Check_Camera_AsyncHttps_RecvRsp(_UC * pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    /*if (pstAsyncHttpsPostMgr->uiOgctId != (_UI)vpUserPtr)
    {
        MOS_LOG_INF(QP_CAMERA, "Trans result : ogct %u different form net %u", pstAsyncHttpsPostMgr->uiOgctId, (_UI)vpUserPtr);

        return;
    }*/

    // 如果当前接收buf还没有分配空间
    if (pstAsyncHttpsPostMgr->uiRecvBufLen == 0)
    {
        pstAsyncHttpsPostMgr->uiRecvBufLen = TRANS_RECV_BUF_LENGTH;
        pstAsyncHttpsPostMgr->pucRecvBuf   = (_UC *)MOS_MALLOCCLR(TRANS_RECV_BUF_LENGTH);
    }

    // 还剩空余的空间则缓存下来
    if (pstAsyncHttpsPostMgr->uiHasRecvLen + uiLen < pstAsyncHttpsPostMgr->uiRecvBufLen)
    {
        MOS_MEMCPY(pstAsyncHttpsPostMgr->pucRecvBuf + pstAsyncHttpsPostMgr->uiHasRecvLen, pucData, uiLen);
        pstAsyncHttpsPostMgr->uiHasRecvLen += uiLen;
    }
    else
    {
        MOS_LOG_INF(QP_CAMERA, "without enough buf, uiHasRecvLen[%d], uiRecvBufLen[%d]", pstAsyncHttpsPostMgr->uiHasRecvLen, pstAsyncHttpsPostMgr->uiRecvBufLen);
    }

    return;
}

static _VOID Qp_Check_Camera_AsyncHttps_RecvRspFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    MOS_LOG_INF(QP_CAMERA, "Recv Check Data Fail");

    if (pstAsyncHttpsPostMgr)
    {
        if (pstAsyncHttpsPostMgr->pucRecvBuf)
        {
               MOS_FREE(pstAsyncHttpsPostMgr->pucRecvBuf);            
        }

        // 复位发送过程中的标记
        // pstAsyncHttpsPostMgr->uiOgctId     = 0;
        pstAsyncHttpsPostMgr->uiHasRecvLen = 0;
        pstAsyncHttpsPostMgr->uiRecvBufLen = 0;
        pstAsyncHttpsPostMgr->pucRecvBuf   = MOS_NULL;

        pstAsyncHttpsPostMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_FINISH;
        pstAsyncHttpsPostMgr->iFailCnt++;

        pstAsyncHttpsPostMgr->ucHttpsResult       = EN_QP_CHECK_CAMERA_HTTPS_INIT;
        
    }

    return;
}

static _INT Qp_Check_Camera_AsyncHttps_ParseRsp_GetAccount(_UC *pucJson)
{
    printf("*******Qp_Check_Camera_AsyncHttps_ParseRsp_GetAccount***********\n");

    _UC *pucStrTmp = MOS_NULL;

    _INT  uiResultCode = 0;

    JSON_HANDLE hResultObj = MOS_NULL;
    JSON_HANDLE hDataObj = MOS_NULL;
    JSON_HANDLE hJsonRoot = MOS_NULL;

    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    hJsonRoot = Adpt_Json_Parse(pucJson);
    if (hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"resultCode"), &uiResultCode);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"resultMsg"), &pucStrTmp);

    // 检测是否接收成功
    if (uiResultCode != 0)
    {
        MOS_LOG_ERR(QP_CAMERA, "post trans msg err, code[%d], msg[%s]", uiResultCode, pucStrTmp);

        pstAsyncHttpsPostMgr->ucHttpsResult = EN_QP_CHECK_CAMERA_HTTPS_ERR;

        Adpt_Json_Delete(hJsonRoot);

        return MOS_ERR;
    }

    //获取具体的数据
    hResultObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"resultData");
    //避免接收到空数据
    if (hResultObj == MOS_NULL)
    {
        MOS_LOG_ERR(QP_CAMERA, "data invalid");
        Adpt_Json_Delete(hJsonRoot);
        return MOS_ERR;
    }
    hDataObj   = Adpt_Json_GetObjectItem(hResultObj, (_UC *)"data");

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj, (_UC *)"account"), &pucStrTmp);
    MOS_STRNCPY(pstAsyncHttpsPostMgr->ucAccount, pucStrTmp, CLOUDSTORE_ACCOUNT_LENGTH);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj, (_UC *)"token"), &pucStrTmp);
    MOS_STRNCPY(pstAsyncHttpsPostMgr->ucToken, pucStrTmp, CLOUDSTORE_TOKEN_LENGTH);

    // 返回expiresIn中存储的有效时间单位是时间戳，目前不用时间戳
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj, (_UC *)"expiresIn"), &pucStrTmp);
    //返回的毫秒，截断为秒
    pucStrTmp[MOS_STRLEN(pucStrTmp)-3]=0;
    pstAsyncHttpsPostMgr->lTokenValidTimestamp = MOS_ATOI(pucStrTmp);

    pstAsyncHttpsPostMgr->ucAccountFlag = AI_ACCOUNT_VALID;

    // account、token及有效期等数据无需掉电保持，设备重新上电后可再次获取

    Adpt_Json_Delete(hJsonRoot);

    return MOS_OK;
}

static _INT Qp_Check_Camera_AsyncHttps_ParseRsp_UpdateToken(_UC *pucJson)
{
    _UC *pucStrTmp = MOS_NULL;

    _INT  uiResultCode = 0;

    JSON_HANDLE hResultObj = MOS_NULL;
    JSON_HANDLE hDataObj = MOS_NULL;
    JSON_HANDLE hJsonRoot = MOS_NULL;

    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    hJsonRoot = Adpt_Json_Parse(pucJson);
    if (hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"resultCode"), &uiResultCode);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"resultMsg"), &pucStrTmp);

    // 检测是否接收成功
    if (uiResultCode != 0)
    {
        MOS_LOG_ERR(QP_CAMERA, "post trans msg err, code[%d], msg[%s]", uiResultCode, pucStrTmp);

        pstAsyncHttpsPostMgr->ucHttpsResult = EN_QP_CHECK_CAMERA_HTTPS_ERR;

        Adpt_Json_Delete(hJsonRoot);

        return MOS_ERR;
    }

    //获取具体的数据
    hResultObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"resultData");
    if (hResultObj == MOS_NULL)
    {
        MOS_LOG_ERR(QP_CAMERA, "data invalid");
        Adpt_Json_Delete(hJsonRoot);
        return MOS_ERR;
    }
    hDataObj   = Adpt_Json_GetObjectItem(hResultObj, (_UC *)"data");

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj, (_UC *)"token"), &pucStrTmp);
    MOS_STRNCPY(pstAsyncHttpsPostMgr->ucToken, pucStrTmp, CLOUDSTORE_TOKEN_LENGTH);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj, (_UC *)"expiresIn"), &pucStrTmp);
    //返回的毫秒，截断为秒
    pucStrTmp[MOS_STRLEN(pucStrTmp)-3]=0;
    pstAsyncHttpsPostMgr->lTokenValidTimestamp = MOS_ATOI(pucStrTmp);;

    // account、token及有效期等数据无需掉电保持，设备重新上电后可再次获取

    Adpt_Json_Delete(hJsonRoot);

    return MOS_OK;
}

static _INT Qp_Check_Camera_AsyncHttps_ParseRsp_GetUploadUrl(_UC *pucJson)
{
    _UC *pucStrTmp = MOS_NULL;

    _INT  uiResultCode = 0;
    _INT  uiUrlArrySize = 0;
    _INT  uiStatus = 0;

    JSON_HANDLE hJsonRoot  = MOS_NULL;
    JSON_HANDLE hResultObj = MOS_NULL;
    JSON_HANDLE hUrlArry   = MOS_NULL;
    JSON_HANDLE hArryItem  = MOS_NULL;

    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    hJsonRoot = Adpt_Json_Parse(pucJson);
    if (hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"result"), &uiResultCode);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"msg"), &pucStrTmp);

    // 检测是否接收成功
    if (uiResultCode != 0)
    {
        MOS_LOG_ERR(QP_CAMERA, "post trans msg err, code[%d], msg[%s]", uiResultCode, pucStrTmp);

        pstAsyncHttpsPostMgr->ucHttpsResult = EN_QP_CHECK_CAMERA_HTTPS_ERR;

        Adpt_Json_Delete(hJsonRoot);

        return MOS_ERR;
    }

    //获取具体的数据
    hResultObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"uploadFileUrlAll");
    hUrlArry   = Adpt_Json_GetObjectItem(hResultObj, (_UC *)"uploadFileUrls");

    // uiUrlArrySize不应为0
    uiUrlArrySize = Adpt_Json_GetArraySize(hUrlArry);
    if (0 == uiUrlArrySize)
    {
        MOS_LOG_ERR(QP_CAMERA, "uiUrlArrySize error");

        pstAsyncHttpsPostMgr->ucHttpsResult = EN_QP_CHECK_CAMERA_HTTPS_ERR;

        Adpt_Json_Delete(hJsonRoot);

        return MOS_ERR;
    }

    // 根据协议约定，仅返回1一个url，不考虑uiUrlArrySize大于1的情况，只解析1个url地址
    hArryItem = Adpt_Json_GetArrayItem(hUrlArry, 0);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem, (_UC *)"status"), &uiStatus);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC *)"fileID"), &pucStrTmp);
    MOS_STRNCPY(pstAsyncHttpsPostMgr->ucFileID, pucStrTmp, CLOUDSTORE_FILE_OPS_LENGTH);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC *)"uploadUrl"), &pucStrTmp);
    MOS_STRNCPY(pstAsyncHttpsPostMgr->ucFileUploadUrl, pucStrTmp, CLOUDSTORE_FILE_URL_LENGTH);

    Adpt_Json_Delete(hJsonRoot);

    return MOS_OK;
}

static _INT Qp_Check_Camera_AsyncHttps_ParseRsp_CommitSnapshot(_UC *pucJson)
{
    _UC *pucStrTmp = MOS_NULL;

    _INT  uiResultCode = 0;

    JSON_HANDLE hJsonRoot = MOS_NULL;

    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    hJsonRoot = Adpt_Json_Parse(pucJson);
    if (hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"Result"), &uiResultCode);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC *)"Msg"), &pucStrTmp);

    // 检测是否接收成功
    if (uiResultCode != 0)
    {
        MOS_LOG_ERR(QP_CAMERA, "post trans msg err, code[%d], msg[%s]", uiResultCode, pucStrTmp);

        pstAsyncHttpsPostMgr->ucHttpsResult = EN_QP_CHECK_CAMERA_HTTPS_ERR;

        Adpt_Json_Delete(hJsonRoot);

        return MOS_ERR;
    }

    Adpt_Json_Delete(hJsonRoot);

    return MOS_OK;
}

static _VOID Qp_Check_Camera_AsyncHttps_RecvRspFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iRet = MOS_ERR;
    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;

    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    if (pstAsyncHttpsPostMgr->pucRecvBuf == MOS_NULL)
    {
        MOS_FREE(pstAsyncHttpsPostMgr->pucRecvBuf);
        pstAsyncHttpsPostMgr->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_FINISH;
        pstAsyncHttpsPostMgr->ucHttpsResult     = EN_QP_CHECK_CAMERA_HTTPS_INIT;
        pstAsyncHttpsPostMgr->iFailCnt++;
        return;
    }    

    /*if (pstAsyncHttpsPostMgr->uiOgctId != (_UI)vpUserPtr)
    {
        MOS_LOG_INF(QP_CAMERA, "ogct %u different form net %u", pstAsyncHttpsPostMgr->uiOgctId, (_UI)vpUserPtr);
           pstAsyncHttpsPostMgr->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_FINISH;        
        Http_Httpclient_CancelAsyncRequest(pstAsyncHttpsPostMgr->uiHttpHandle);
        pstAsyncHttpsPostMgr->uiHttpHandle = 0;
        return;
    }*/

    // 接收完毕，解析服务返回的数据
    if (pstAsyncHttpsPostMgr->pucRecvBuf)
    {
        pstAsyncHttpsPostMgr->pucRecvBuf[pstAsyncHttpsPostMgr->uiHasRecvLen] = 0;        
        MOS_LOG_INF(QP_CAMERA,"pucRecvBuf data : %s",pstAsyncHttpsPostMgr->pucRecvBuf);
    }

    if (EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        iRet = Qp_Check_Camera_AsyncHttps_ParseRsp_GetAccount(pstAsyncHttpsPostMgr->pucRecvBuf);
    }
    else if (EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN == pstAsyncHttpsPostMgr->uiCheckCameraStep)    
    {
        iRet = Qp_Check_Camera_AsyncHttps_ParseRsp_UpdateToken(pstAsyncHttpsPostMgr->pucRecvBuf);
    }
    else if (EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {    
        iRet = Qp_Check_Camera_AsyncHttps_ParseRsp_GetUploadUrl(pstAsyncHttpsPostMgr->pucRecvBuf);
    }
    else if (EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        iRet = Qp_Check_Camera_AsyncHttps_ParseRsp_CommitSnapshot(pstAsyncHttpsPostMgr->pucRecvBuf);
    }
    else
    {
        MOS_LOG_INF(QP_CAMERA, "wrong https type");

        iRet = MOS_ERR;
    }

    if (MOS_NULL != pstAsyncHttpsPostMgr->pucRecvBuf)
    {
        MOS_FREE(pstAsyncHttpsPostMgr->pucRecvBuf);
    }

    // pstAsyncHttpsPostMgr->uiOgctId     = 0;
    pstAsyncHttpsPostMgr->uiHasRecvLen = 0;
    pstAsyncHttpsPostMgr->uiRecvBufLen = 0;
    pstAsyncHttpsPostMgr->pucRecvBuf = MOS_NULL;
    

    if (iRet == MOS_ERR)
    {
        MOS_LOG_ERR(QP_CAMERA, "parse server rspdata err");
        pstAsyncHttpsPostMgr->iFailCnt++;
        pstAsyncHttpsPostMgr->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_FINISH;    
    }
    else
    {
        MOS_LOG_INF(QP_CAMERA, "post server rspdata ok");
        if (EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT == pstAsyncHttpsPostMgr->uiCheckCameraStep)
        {
            pstAsyncHttpsPostMgr->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL;            
        }
        else if (EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN == pstAsyncHttpsPostMgr->uiCheckCameraStep)    
        {
            pstAsyncHttpsPostMgr->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL;    
        }
        else if (EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL == pstAsyncHttpsPostMgr->uiCheckCameraStep)
        {    
            pstAsyncHttpsPostMgr->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_SEND_SNAPSHOT;    
        }
        else if (EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT == pstAsyncHttpsPostMgr->uiCheckCameraStep)
        {
            pstAsyncHttpsPostMgr->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_FINISH;    
            pstAsyncHttpsPostMgr->iSnapshotStatusCode = EN_QP_STATE_CHECK_CAMERA_FINISH;    
        }
        pstAsyncHttpsPostMgr->iFailCnt = 0;
    }

    pstAsyncHttpsPostMgr->ucHttpsResult     = EN_QP_CHECK_CAMERA_HTTPS_INIT;

    return;
}

static _INT Qp_Check_Camera_AsyncHttps_Post(void)
{
    _INT iRet = MOS_ERR;
    _UI i;
    _US usPort = 443;

    _UC *pStrTmp     = MOS_NULL;
    _UC *pStrAddhead = MOS_NULL;
    _UC *pStrStart   = MOS_NULL;
    _UC *pEncryptStr = MOS_NULL;
    _UC *pFinalStr = MOS_NULL;

    _UC auAdmonAddr[CLOUDSTORE_API_MAXLEN]     = {0};
    _UC serverip[MOS_INET_IPV4_STR_SIZE]       = {0};
    _UC auAdmonAddrPort[CLOUDSTORE_API_MAXLEN] = {0};  // 区别于auAdmonAddr，带有port后缀

    _UC aucServerAddr[CLOUDSTORE_API_MAXLEN]   = {0};  //平台地址
    _UC aucServerApi[CLOUDSTORE_API_MAXLEN]    = {0};  //平台API接口
    _UC aucServerApiTemp[CLOUDSTORE_API_MAXLEN]= {0};  //拼接平台API接口缓存

    // ST_MOS_INET_IPARRAY *pstIpArray = MOS_NULL;
    // ST_MOS_INET_IP *pstNetIp = MOS_NULL;

    ST_QP_CHECK_CAMERA_MGR* pstAsyncHttpsPostMgr = MOS_NULL;


    pstAsyncHttpsPostMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    MOS_MEMSET(auAdmonAddr, 0, CLOUDSTORE_API_MAXLEN);

    if (EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        MOS_MEMSET(aucServerAddr, 0, CLOUDSTORE_API_MAXLEN);
        MOS_MEMSET(aucServerApi, 0, CLOUDSTORE_API_MAXLEN);

        MOS_STRCPY(aucServerAddr, AI_HTTPS_URL);
        MOS_STRCPY(aucServerApi, AI_HTTPS_URL_API_GET_TOKEN);
    }
    else if (EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        MOS_MEMSET(aucServerAddr, 0, CLOUDSTORE_API_MAXLEN);
        MOS_MEMSET(aucServerApi, 0, CLOUDSTORE_API_MAXLEN);

        MOS_STRCPY(aucServerAddr, AI_HTTPS_URL);
        MOS_STRCPY(aucServerApi, AI_HTTPS_URL_API_UPDATE_TOKEN);
    }
    else if (EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        MOS_MEMSET(aucServerAddr, 0, CLOUDSTORE_API_MAXLEN);
        MOS_MEMSET(aucServerApi, 0, CLOUDSTORE_API_MAXLEN);
        MOS_MEMSET(aucServerApiTemp, 0, CLOUDSTORE_API_MAXLEN);

        MOS_STRCPY(aucServerAddr, CLOUD_STORE_HTTPS_URL);
        MOS_STRCPY(aucServerApiTemp, CLOUD_STORE_HTTPS_URL_API_GET_UPLOADURL);

        // add command in api
        MOS_SPRINTF(aucServerApi, "%s?account=%s&token=%s&num=1", aucServerApiTemp, pstAsyncHttpsPostMgr->ucAccount, pstAsyncHttpsPostMgr->ucToken);
        //MOS_SPRINTF(aucServerApi, "%s", aucServerApiTemp);
    }
    else if (EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        MOS_MEMSET(aucServerAddr, 0, CLOUDSTORE_API_MAXLEN);
        MOS_MEMSET(aucServerApi, 0, CLOUDSTORE_API_MAXLEN);
        MOS_MEMSET(aucServerApiTemp, 0, CLOUDSTORE_API_MAXLEN);

        MOS_STRCPY(aucServerAddr, CLOUD_STORE_HTTPS_URL);
        MOS_STRCPY(aucServerApiTemp, CLOUD_STORE_HTTPS_URL_API_COMMIT_SNAPSHOT);

        // add command in api
        MOS_SPRINTF(aucServerApi, "%s?account=%s&token=%s&fileID=%s&fileName=%s&fileSize=%d&errorCode=0&errorInfo=success",
                                    aucServerApiTemp,
                                    pstAsyncHttpsPostMgr->ucAccount,
                                    pstAsyncHttpsPostMgr->ucToken,
                                    pstAsyncHttpsPostMgr->ucFileID,
                                    pstAsyncHttpsPostMgr->ucFileName,
                                    pstAsyncHttpsPostMgr->iFileSize);
    }
    else
    {
        MOS_LOG_INF(QP_CAMERA, "post type error");

        return MOS_ERR;
    }

    pStrStart = MOS_STRSTR(aucServerAddr, "//");
    if (pStrStart == MOS_NULL)
    {
        pStrStart = (_UC *)aucServerAddr;
    }
    else
    {
        pStrStart += 2;
    }

    pStrTmp = MOS_STRSTR(pStrStart,":");
    if (pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr, pStrStart, pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else
    {
        MOS_STRNCPY(auAdmonAddr, pStrStart, 128);
    }

    // pstIpArray = (ST_MOS_INET_IPARRAY *)MOS_MALLOCCLR(sizeof(ST_MOS_INET_IPARRAY));
    // if (MOS_NULL == pstIpArray)
    // {
    //     MOS_LOG_INF(QP_CAMERA, "pstIpArray MOS_MALLOCCLR failed");
    //     return MOS_ERR;
    // }

    // if (Mos_InetGetAddrInfo(auAdmonAddr, usPort, EN_CINET_PRTL_TCP, MOS_FALSE, pstIpArray) != MOS_OK)
    // {
    //     MOS_LOG_INF(QP_CAMERA, "Mos_InetGetAddrInfo failed");
    //     MOS_FREE(pstIpArray);
        
    //     return MOS_ERR;
    // }

    // #ifdef SDK_ADPT_IPV6
    // pstNetIp = &pstIpArray->astIps[0];
    // #else
    // for (i = 0; i < pstIpArray->uiCount; i++)
    // {
    //     pstNetIp = &pstIpArray->astIps[i];
    //     if (pstNetIp->usType == EN_CINET_TYPE_IPV4)
    //     {
    //         break;
    //     }
    // }
    // #endif

    // if (EN_CINET_TYPE_IPV4 == pstNetIp->usType)
    // {
    //     MOS_MEMSET(serverip, 0, MOS_INET_IPV4_STR_SIZE);
    //     Mos_InetAddrNtop(EN_CINET_TYPE_IPV4, &(pstNetIp->u.uiIp), serverip, MOS_INET_IPV4_STR_SIZE);

    //     MOS_LOG_INF(QP_CAMERA, "\nserver [%s]-[%s]-[%d]\npath : \n%s", auAdmonAddr, serverip, usPort, aucServerApi);    
    // }
    MOS_SPRINTF(auAdmonAddrPort, "%s:%d", auAdmonAddr, usPort);

    // build header and request
    if (EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        // pStrTmp = Qp_Check_Camera_AsyncHttps_BuildReqData_GetAccount(pstAsyncHttpsPostMgr->uiOgctId);
        pStrTmp = Qp_Check_Camera_AsyncHttps_BuildReqData_GetAccount(0);
    }
    else if (EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        // pStrTmp = Qp_Check_Camera_AsyncHttps_BuildReqData_UpdateToken(pstAsyncHttpsPostMgr->uiOgctId);
        pStrTmp = Qp_Check_Camera_AsyncHttps_BuildReqData_UpdateToken(0);
    }
    else if (EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        pStrTmp = MOS_NULL;
    }
    else if (EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT == pstAsyncHttpsPostMgr->uiCheckCameraStep)
    {
        pStrTmp = MOS_NULL;
    }
    else
    {
        MOS_LOG_INF(QP_CAMERA, "post type error");

        return MOS_ERR;
    }

    //开通账号、刷新token和推送巡检，都是信息技术部接口，需要自定义header跟加密的body
    if ((EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT == pstAsyncHttpsPostMgr->uiCheckCameraStep)||
        (EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN == pstAsyncHttpsPostMgr->uiCheckCameraStep))
    {
        //构建请求头
        pStrAddhead = (_UC *)MOS_MALLOCCLR(AUTHENTICATION_HEAD_LEN);
        if (MOS_NULL == pStrAddhead)
        {
            MOS_LOG_INF(QP_CAMERA, "MOS_MALLOCCLR failed");
            // MOS_FREE(pstIpArray);
            MOS_FREE(pStrTmp);
            return MOS_ERR;
        }
        Qp_Check_Camera_AsyncHttps_BuildReqData_AuthenticationHeadWithSign(pStrAddhead,pStrTmp);
        
        //encrypt request body 
        pEncryptStr = MOS_MALLOCCLR(MOS_STRLEN(pStrTmp)/3*4+32);
        if (MOS_NULL == pEncryptStr)
        {
            MOS_LOG_INF(QP_CAMERA, "MOS_MALLOCCLR failed");
            // MOS_FREE(pstIpArray);
            MOS_FREE(pStrTmp);
            MOS_FREE(pStrAddhead);
            return MOS_ERR;
        }
        Qp_utils_AsyncHttps_AesBase64_ECB_Encrypt(pStrTmp,pEncryptStr);

        MOS_LOG_INF(QP_CAMERA, "%s\n", pStrTmp);

        pFinalStr = Qp_Check_Camera_AsyncHttps_BuildEncryptReqData(pEncryptStr);

    }
    else
    {
        //构建请求头
        pStrAddhead = (_UC *)MOS_MALLOCCLR(AUTHENTICATION_HEAD_LEN);
        if (MOS_NULL == pStrAddhead)
        {
            MOS_LOG_INF(QP_CAMERA, "MOS_MALLOCCLR failed");
            // MOS_FREE(pstIpArray);
            MOS_FREE(pStrTmp);
            return MOS_ERR;
        }

        Qp_Check_Camera_AsyncHttps_BuildReqData_AuthenticationHead(pStrAddhead);
    }

    pstAsyncHttpsPostMgr->uiHttpHandle = Mos_GetSessionId();
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.pfuncRecv       = Qp_Check_Camera_AsyncHttps_RecvRsp;
    stHttpInfoNode.pfuncFinished   = Qp_Check_Camera_AsyncHttps_RecvRspFinish;
    stHttpInfoNode.pfuncFailed     = Qp_Check_Camera_AsyncHttps_RecvRspFail;
    stHttpInfoNode.pucContent      = pFinalStr;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pFinalStr);
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucExpandHeader = pStrAddhead;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddrPort, aucServerApi, EN_HTTP_METHOD_POST, pstAsyncHttpsPostMgr->uiHttpHandle);                                                

    MOS_FREE(pStrTmp);
    // MOS_FREE(pstIpArray);
    MOS_FREE(pEncryptStr);
    MOS_FREE(pFinalStr);
    MOS_FREE(pStrAddhead);
    
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

static _INT Qp_Check_Camera_PostData(void)
{
    ST_QP_CHECK_CAMERA_MGR* pstAiTransMgr = MOS_NULL;

    pstAiTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    pstAiTransMgr->iSendCnt ++;
    pstAiTransMgr->cSendTime = Mos_Time();
    // pstAiTransMgr->uiOgctId = Mos_GetSessionId();

    MOS_LOG_INF(QP_CAMERA, "-\n--\n---\n----\n-----%s  cSendTime : %d\n----\n---\n--\n-\n", apucQpStatePrint[pstAiTransMgr->uiCheckCameraStep],pstAiTransMgr->cSendTime);

    return  Qp_Check_Camera_AsyncHttps_Post();

}

//检查是否达到发送要求
static void Qp_Check_Camera_Snapshot_PermitCheck(void)
{
    MOS_LOG_INF(QP_CAMERA, "Qp_Check_Camera_Snapshot_PermitCheck");

    _INT  iJpgLen = 0;

    _UC *pucJpgBuf = MOS_NULL;

    ST_MOS_SYS_TIME stCurTime;

    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;

    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    pstCloudStoreTransMgr->uiPutStep     = EN_QP_STATE_SYNC_PUT_PERMIT_CHECK;

    ZJ_GetJpgLock();

    pstCloudStoreTransMgr->iCheckCnt ++;

    iJpgLen = ZJ_GetOneJpg(0, EN_ZJ_PICTURE_NORMAL, &pucJpgBuf);

    if (iJpgLen >= 0 && pucJpgBuf != MOS_NULL)
    {
        pstCloudStoreTransMgr->pucSendBuf = MOS_MALLOCCLR(iJpgLen);
        if (MOS_NULL != pstCloudStoreTransMgr->pucSendBuf)
        {
            MOS_MEMCPY(pstCloudStoreTransMgr->pucSendBuf, pucJpgBuf, iJpgLen);
            pstCloudStoreTransMgr->uiSendBufLength = iJpgLen;
            
            pstCloudStoreTransMgr->iFileSize = iJpgLen;

            Mos_GetSysTime(&stCurTime);
            MOS_SPRINTF(pstCloudStoreTransMgr->ucFileName, "%d%02d%02d%02d%02d%02d-%d%02d%02d%02d%02d%02d.jpg",
                                                            stCurTime.usYear, stCurTime.usMonth, stCurTime.usDay, stCurTime.usHour, stCurTime.usMinute, stCurTime.usSecond,
                                                            stCurTime.usYear, stCurTime.usMonth, stCurTime.usDay, stCurTime.usHour, stCurTime.usMinute, stCurTime.usSecond);

            MOS_SPRINTF(pstCloudStoreTransMgr->ucFileCreateTime, "%d%02d%02d%02d%02d%02d",
                                                                 stCurTime.usYear, stCurTime.usMonth, stCurTime.usDay, stCurTime.usHour, stCurTime.usMinute, stCurTime.usSecond);

    
            ZJ_GetJpgUnlock();
    
            // 默认切换成发送状态
            pstCloudStoreTransMgr->uiPutStep = EN_QP_STATE_SYNC_PUT_SEND;

            return;
        }
        else
        {
            MOS_LOG_INF(QP_CAMERA, "malloc failed");
        }
    }
    else
    {
        MOS_LOG_INF(QP_CAMERA, "ZJ_GetOneJpg failed iJpgLen=[%d]", iJpgLen);
    }

    pstCloudStoreTransMgr->uiPutStep   = EN_QP_STATE_SYNC_PUT_FAILED;    

    ZJ_GetJpgUnlock();

    return;
}

static void Qp_Check_Camera_Snapshot_Send(void)
{
    MOS_LOG_INF(QP_CAMERA, "Qp_Check_Camera_Snapshot_Send");

    _INT iRet = MOS_OK;

    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;


    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    iRet = Qp_Utils_Https_Putfile(pstCloudStoreTransMgr->ucFileUploadUrl,
                                    pstCloudStoreTransMgr->pucSendBuf,
                                    pstCloudStoreTransMgr->uiSendBufLength);

    if (MOS_OK == iRet)
    {
        MOS_LOG_INF(QP_CAMERA, "put file ok");

        //本次数据发送成功
        pstCloudStoreTransMgr->uiPutStep     = EN_QP_STATE_SYNC_PUT_FINISH;
        return;
    }

    MOS_LOG_INF(QP_CAMERA, "put failed");
    pstCloudStoreTransMgr->uiPutStep   = EN_QP_STATE_SYNC_PUT_FAILED;    

    pstCloudStoreTransMgr->iSendCnt ++;

    return;
}

static _VOID Qp_Check_Camera_Snapshot_RetryCfg(void)
{
    MOS_LOG_INF(QP_CAMERA, "Qp_Check_Camera_Snapshot_RetryCfg");

    _CTIME_T cRetryDelayTime;
    _CTIME_T cCurTime = Mos_Time();

    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;

    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    // 根据不同的错误原因确定下一步
    switch (pstCloudStoreTransMgr->ucHttpsResult)
    {
        // 截图失败，间隔1秒，重试3次，失败后不继续
        case EN_QP_CHECK_CAMERA_GET_SNAPSHOT_ERROR:
        {
            if (pstCloudStoreTransMgr->iCheckCnt > CHECK_CAMERA_REGET_NUM)
            {
                cRetryDelayTime = 0;
            }
            else
            {
                cRetryDelayTime = CHECK_CAMERA_RETGET_TIME;
            }
            break;
        }

        // 发送失败，间隔5秒，重试3次，失败后不继续
        case EN_QP_CHECK_CAMERA_HTTPS_ERR:
        {
            if (pstCloudStoreTransMgr->iSendCnt > CHECK_CAMERA_RETRANS_NUM)
            {
                cRetryDelayTime = 0;
            }
            else
            {
                cRetryDelayTime = CHECK_CAMERA_RETRANS_TIME;
            }
            break;
        }

        case EN_QP_CHECK_CAMERA_HTTPS_OK:
        default:
            // 默认重试延时未0，不再重试
            cRetryDelayTime = 0;
            break;
    }

    if (0 == cRetryDelayTime)
    {
        // 不再重试，结束
        pstCloudStoreTransMgr->uiPutStep = EN_QP_STATE_SYNC_PUT_FINISH;
    }
    else
    {
        pstCloudStoreTransMgr->cRetransTime = cCurTime + cRetryDelayTime;

        // 切换至重传延时状态
        pstCloudStoreTransMgr->uiPutStep = EN_QP_STATE_SYNC_PUT_RETRY_CHECK;
    }

    return;
}

static _VOID Qp_Check_Camera_Snapshot_RetryCheck(void)
{
    MOS_LOG_INF(QP_CAMERA, "Qp_Check_Camera_Snapshot_RetryCheck");

    _CTIME_T cRetryCheckTime = Mos_Time();

    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;


    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    // 判断重传延时是否结束
    if (cRetryCheckTime > pstCloudStoreTransMgr->cRetransTime)
    {
        if (EN_QP_CHECK_CAMERA_GET_SNAPSHOT_ERROR == pstCloudStoreTransMgr->ucHttpsResult)
        {
            // 重新获取图片
            pstCloudStoreTransMgr->uiPutStep = EN_QP_STATE_SYNC_PUT_PERMIT_CHECK;
        }
        else
        {
            // 重新发送
            pstCloudStoreTransMgr->uiPutStep = EN_QP_STATE_SYNC_PUT_SEND;
        }
    }

    return;
}

static _VOID Qp_Check_Camera_Snapshot_Failed(void)
{
    MOS_LOG_INF(QP_CAMERA, "Qp_Check_Camera_Snapshot_Failed");

    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;

    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    // 回收申请的资源
    if (MOS_NULL != pstCloudStoreTransMgr->pucSendBuf)
    {
        MOS_FREE(pstCloudStoreTransMgr->pucSendBuf);
        pstCloudStoreTransMgr->pucSendBuf = MOS_NULL;
    }

    pstCloudStoreTransMgr->iFailCnt++;

    pstCloudStoreTransMgr->uiPutStep = EN_QP_STATE_SYNC_PUT_PERMIT_CHECK;
    
    pstCloudStoreTransMgr->uiCheckCameraStep  = EN_QP_STATE_CHECK_CAMERA_FINISH;

    return;
}

static _VOID Qp_Check_Camera_Snapshot_Finish(void)
{
    MOS_LOG_INF(QP_CAMERA, "Qp_Check_Camera_Snapshot_Finish");

    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;

    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    // 回收申请的资源
    if (MOS_NULL != pstCloudStoreTransMgr->pucSendBuf)
    {
        MOS_FREE(pstCloudStoreTransMgr->pucSendBuf);
        pstCloudStoreTransMgr->pucSendBuf = MOS_NULL;
    }

    pstCloudStoreTransMgr->uiPutStep = EN_QP_STATE_SYNC_PUT_PERMIT_CHECK;
    
    pstCloudStoreTransMgr->uiCheckCameraStep  = EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT;
	pstCloudStoreTransMgr->iFailCnt = 0;    
    return;
}

static void Qp_Check_Camera_Finish(void)
{
    ST_QP_CHECK_CAMERA_MGR* pstCheckCamera = MOS_NULL;


    pstCheckCamera = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    MOS_LOG_INF(QP_CAMERA, "Qp_Check_Camera_Finish,StatusCode = %d  iFailCnt = %d",pstCheckCamera->iSnapshotStatusCode,pstCheckCamera->iFailCnt);
    
    MOS_PRINTF("***Qp_Check_Camera_Finish*** StatusCode = %d  iFailCnt = %d\n",pstCheckCamera->iSnapshotStatusCode,pstCheckCamera->iFailCnt);


    if (pstCheckCamera->iSnapshotStatusCode != EN_QP_STATE_CHECK_CAMERA_FINISH && pstCheckCamera->iFailCnt < 3 && pstCheckCamera->iFailCnt > 0)
    {
        pstCheckCamera->uiCheckCameraStep = pstCheckCamera->iSnapshotStatusCode;
    }
    else
    {
        pstCheckCamera->iFailCnt = 0;
        // account 有效，下一次直接进入刷新token流程
        if (AI_ACCOUNT_VALID == pstCheckCamera->ucAccountFlag)
        {
            pstCheckCamera->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN;
        }
        // account 无效，下一次仍然要重新获取account
        else
        {
            pstCheckCamera->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT;
        }        
    }
    
    pstCheckCamera->ucHttpsResult = EN_QP_CHECK_CAMERA_HTTPS_INIT;

    return;
}

static void Qp_Check_Camera_Working(void)
{
    _CTIME_T cNowTime = 0;

    ST_QP_CHECK_CAMERA_MGR* pstCheckCamera = MOS_NULL;
    pstCheckCamera = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    cNowTime = Mos_Time();
    if ((cNowTime - pstCheckCamera->cSendTime) > TRANS_MSG_TIMEOUT)
    {
        MOS_LOG_INF(QP_CAMERA, "qp camera check time out");

        if (pstCheckCamera->pucRecvBuf)
        {
               MOS_FREE(pstCheckCamera->pucRecvBuf);            
        }

        // 复位发送过程中的标记
        // pstCheckCamera->uiOgctId     = 0;
        pstCheckCamera->uiHasRecvLen = 0;
        pstCheckCamera->uiRecvBufLen = 0;
        pstCheckCamera->pucRecvBuf   = MOS_NULL;
        pstCheckCamera->iFailCnt     = 0;

        pstCheckCamera->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_FINISH;
        pstCheckCamera->ucHttpsResult = EN_QP_CHECK_CAMERA_HTTPS_INIT;
        
        // 被赋值为seqID
        if (pstCheckCamera->uiHttpHandle)
        {
            Http_Httpclient_CancelAsyncRequestEx(pstCheckCamera->uiHttpHandle);
            pstCheckCamera->uiHttpHandle = 0;
        }
    }

    return;
}

static void Qp_Check_Camera_CommitSnapshot(void)
{
    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;

    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    pstCloudStoreTransMgr->iSnapshotStatusCode = EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT;
    pstCloudStoreTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT;    
    
    if (MOS_OK != Qp_Check_Camera_PostData())
    {
        pstCloudStoreTransMgr->ucAccountFlag        = AI_ACCOUNT_INVALID;
        pstCloudStoreTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_FINISH;
    }
    else
    {
        pstCloudStoreTransMgr->ucHttpsResult   = EN_QP_CHECK_CAMERA_HTTPS_WORKING;
    }


    return;
}

static void Qp_Check_Camera_SendSnapshot(void)
{
    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;


    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    pstCloudStoreTransMgr->iSnapshotStatusCode = EN_QP_STATE_CHECK_CAMERA_SEND_SNAPSHOT;
    pstCloudStoreTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_SEND_SNAPSHOT;    

    switch (pstCloudStoreTransMgr->uiPutStep)
    {
        case EN_QP_STATE_SYNC_PUT_PERMIT_CHECK: Qp_Check_Camera_Snapshot_PermitCheck(); break;
        case EN_QP_STATE_SYNC_PUT_SEND:         Qp_Check_Camera_Snapshot_Send();        break;
        case EN_QP_STATE_SYNC_PUT_FINISH:       Qp_Check_Camera_Snapshot_Finish();      break;
        case EN_QP_STATE_SYNC_PUT_FAILED:        Qp_Check_Camera_Snapshot_Failed();        break;
        default:                                 Qp_Check_Camera_Snapshot_Failed();        break;
    }

    return;
}

static void Qp_Check_Camera_GetUploadUrl(void)
{
    ST_QP_CHECK_CAMERA_MGR* pstCloudStoreTransMgr = MOS_NULL;


    pstCloudStoreTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    pstCloudStoreTransMgr->iSnapshotStatusCode = EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL;
    pstCloudStoreTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL;    
    
    if (MOS_OK != Qp_Check_Camera_PostData())
    {
        pstCloudStoreTransMgr->ucAccountFlag        = AI_ACCOUNT_INVALID;
        pstCloudStoreTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_FINISH;
    }
    else
    {
        pstCloudStoreTransMgr->ucHttpsResult   = EN_QP_CHECK_CAMERA_HTTPS_WORKING;
    }    

    return;
}

static void Qp_Check_Camera_UpdateToken(void)
{
    ST_QP_CHECK_CAMERA_MGR* pstAiTransMgr = MOS_NULL;

    pstAiTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    pstAiTransMgr->iSnapshotStatusCode = EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN;
    pstAiTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN;

    if (AI_ACCOUNT_VALID == pstAiTransMgr->ucAccountFlag)//无论过不过期都会去获取新的token
    {
        if (MOS_OK != Qp_Check_Camera_PostData())
        {
            pstAiTransMgr->ucAccountFlag        = AI_ACCOUNT_INVALID;
            pstAiTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_FINISH;
        }
        else
        {
            pstAiTransMgr->ucHttpsResult   = EN_QP_CHECK_CAMERA_HTTPS_WORKING;
        }    
    }
    else// account 无效，下一次仍然要重新获取account
    {
        pstAiTransMgr->ucAccountFlag = EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT;
    }
    
    return;
}

static void Qp_Check_Camera_GetAccount(void)
{
    ST_QP_CHECK_CAMERA_MGR* pstAiTransMgr = MOS_NULL;


    pstAiTransMgr = &Qp_Task_GetTaskMng()->stCheckCameraMgr;
    
    pstAiTransMgr->iSnapshotStatusCode = EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT;
    pstAiTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT;    

    // account 有效
    if (AI_ACCOUNT_VALID == pstAiTransMgr->ucAccountFlag)
    {
        pstAiTransMgr->uiCheckCameraStep = EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN;
    }
    else
    {
        if (MOS_OK != Qp_Check_Camera_PostData())
        {
        
            pstAiTransMgr->ucAccountFlag        = AI_ACCOUNT_INVALID;
            pstAiTransMgr->uiCheckCameraStep   = EN_QP_STATE_CHECK_CAMERA_FINISH;            
            pstAiTransMgr->iFailCnt++;
        }
        else
        {
            pstAiTransMgr->ucHttpsResult   = EN_QP_CHECK_CAMERA_HTTPS_WORKING;
        }    
    }

    return;
}

/*******************************************************************************************************
    Exported Functions
********************************************************************************************************/
EN_QP_CHECK_CAMERA_STEP Qp_Check_Camera_Probe(void)
{
    ST_QP_CHECK_CAMERA_MGR* pstCheckCamera = MOS_NULL;

    pstCheckCamera = &Qp_Task_GetTaskMng()->stCheckCameraMgr;

    EN_QP_CHECK_CAMERA_STEP uiCheckCameraStep = pstCheckCamera->uiCheckCameraStep;
    if (pstCheckCamera->ucHttpsResult == EN_QP_CHECK_CAMERA_HTTPS_WORKING)
    {
        Qp_Check_Camera_Working();
        return uiCheckCameraStep;
    }

    switch (uiCheckCameraStep)
    {
        case EN_QP_STATE_CHECK_CAMERA_GET_ACCOUNT:     Qp_Check_Camera_GetAccount();     break;
        case EN_QP_STATE_CHECK_CAMERA_UPDATE_TOKEN:    Qp_Check_Camera_UpdateToken();    break;
        case EN_QP_STATE_CHECK_CAMERA_GET_UPLOADURL:   Qp_Check_Camera_GetUploadUrl();   break;
        case EN_QP_STATE_CHECK_CAMERA_SEND_SNAPSHOT:   Qp_Check_Camera_SendSnapshot();   break;
        case EN_QP_STATE_CHECK_CAMERA_COMMIT_SNAPSHOT: Qp_Check_Camera_CommitSnapshot(); break;
        case EN_QP_STATE_CHECK_CAMERA_FINISH:          Qp_Check_Camera_Finish();         break;
        default: break;
    }

    if( pstCheckCamera->iFailCnt != 0)
    {
        return pstCheckCamera->iSnapshotStatusCode;
    }
    return uiCheckCameraStep;    
}


