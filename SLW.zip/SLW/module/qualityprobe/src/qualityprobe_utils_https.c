#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "adpt_ssl_adapt.h"
#include "http.h"
#include "tras_httpclient.h"
#include "qualityprobe_api.h"
#include "qualityprobe_type_prv.h"

/*******************************************************************************************************
    Exported Functions
********************************************************************************************************/
// put文件专用，解析到200成功，不处理响应body
static _VOID QP_UploadHttpRecv(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    /*必须要有这个回调函数*/
}

_INT Qp_Utils_Https_Putfile(_UC *url, _UC *putbuf, _UI putbufsize)
{
    _UI uiHttpType = 1;
    _UC aucExpandHeader[256]          = {0};
    _UC aucHostAddr[DEFAULT_URL_LEN]  = {0};
    _UC aucUploadUrl[DEFAULT_URL_LEN] = {0};

    MOS_VSNPRINTF(aucExpandHeader, sizeof(aucExpandHeader), "Expect: 100-continue\r\nConnection: keep-alive\r\n");
    if (Http_Parse_Url(url, aucHostAddr, aucUploadUrl, &uiHttpType) == MOS_ERR)
    {
        MOS_LOG_ERR(QP_TASK, "parse url fail");
        return MOS_ERR;
    }
    printf("len %d \nurl %s\nhost %s\npath %s",putbufsize, url, aucHostAddr, aucUploadUrl);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag        = uiHttpType;  /*iSslFlag*/
    stHttpInfoNode.pfuncRecv        = QP_UploadHttpRecv;
    stHttpInfoNode.pucExpandHeader  = aucExpandHeader;
    stHttpInfoNode.pucContent       = putbuf;
    stHttpInfoNode.uiContentLen     = putbufsize;  /*25KB*/
    stHttpInfoNode.iTimeOut         = 40;
    _INT iRet = Http_SendSyncRequest(&stHttpInfoNode, aucHostAddr, aucUploadUrl, EN_HTTP_METHOD_PUT, 0);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}