#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"

#include "qualityprobe_api.h"
#include "qualityprobe_type_prv.h"

#include "adpt_json_adapt.h"


/*******************************************************************************************************
    Private Function Prototypes
********************************************************************************************************/


/*******************************************************************************************************
    Exported Functions
********************************************************************************************************/
_INT Qp_Utils_Config_Read(ST_QP_CONF_PTR pstQpConfig)
{
    _INT iRet  = MOS_ERR;
    _INT iFileSize = 0;

    _UC aucReadBuf[QP_CONFIG_FILE_MAX_SIZE] = {0};

    _UC *pucStrTmp = MOS_NULL;

    _HFILE *fdConfig = MOS_NULL;

    JSON_HANDLE hRoot = MOS_NULL;
    _UC tempName[QP_CONFIG_FILE_MAX_LEN];


    //检查文件路径，不存在创建
    MOS_MEMSET(tempName, 0, QP_CONFIG_FILE_MAX_LEN);
    MOS_VSNPRINTF(tempName, QP_CONFIG_FILE_MAX_LEN, "%s/%s", Mos_GetWorkPath(), QP_FOLDER);

    if (MOS_FALSE == Mos_DirIsExist((_UC *)tempName))
    {
        MOS_LOG_INF(QP_TASK, "%s do not exist", tempName);

        return MOS_ERR;
    }

    // 检查文件
    MOS_MEMSET(tempName, 0, QP_CONFIG_FILE_MAX_LEN);
    MOS_VSNPRINTF(tempName, QP_CONFIG_FILE_MAX_LEN, "%s/%s", Mos_GetWorkPath(), QP_CONF_FILENAME);

    fdConfig = Mos_FileOpen((_UC *)tempName, MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
    if (fdConfig == MOS_NULL)
    {
        MOS_LOG_INF(QP_TASK, "%s open failed", tempName);

        return MOS_ERR;
    }

    iFileSize = Mos_FileSize(fdConfig);
    if (iFileSize <= 0 || iFileSize > QP_CONFIG_FILE_MAX_SIZE)
    {
        MOS_LOG_INF(QP_TASK, "%s size [%d] error", tempName, iFileSize);
        Mos_FileClose(fdConfig);
        return MOS_ERR;
    }

    // 读取文件
    iRet = Mos_FileRead(fdConfig, aucReadBuf, iFileSize);
    if (MOS_ERR == iRet)
    {
        MOS_LOG_INF(QP_TASK, "%s read failed", tempName);
        Mos_FileClose(fdConfig);
        return MOS_ERR;
    }

    // json反序列化
    hRoot = Adpt_Json_Parse(aucReadBuf);
    if (hRoot == MOS_NULL)
    {
        Mos_FileClose(fdConfig);
        return MOS_ERR;
    }

    MOS_LOG_INF(QP_TASK, "\n-\n--\n---read[%d]:%s\n--\n-\n", MOS_STRLEN(aucReadBuf), aucReadBuf);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC *)"qp_data_pauseflag"), (_INT *)&(pstQpConfig->uiQpDataPauseFlag));
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC *)"qp_data_pausetimestamp"), (_INT *)&(pstQpConfig->cQpPauseTimestamp));
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC *)"qp_data_lasttimestamp"), (_INT *)&(pstQpConfig->cQpLastTimestamp));
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC *)"check_data_immediately"), &pstQpConfig->iImmSendFlag);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC *)"check_mode_ctrl"), (_INT *)&(pstQpConfig->stCheckTargetCfg.ucCheckModeCtrl));
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC *)"check_data_cycletime"), (_INT *)&(pstQpConfig->stCheckTargetCfg.uiCheckDataCycleTime));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"check_data_cloudaddr"), &pucStrTmp);
    MOS_STRNCPY(pstQpConfig->stCheckTargetCfg.ucCheckDataCloud, pucStrTmp, DEFAULT_URL_LEN);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"check_data_targetaddr"), &pucStrTmp);
    MOS_STRNCPY(pstQpConfig->stCheckTargetCfg.ucCheckDataTarget, pucStrTmp, DEFAULT_URL_LEN);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"qp_data_arreaid"), &pucStrTmp);
    MOS_STRNCPY(pstQpConfig->aucAreaID, pucStrTmp, AREA_ID_LEN);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC *)"qp_data_arreattl"), (_INT *)&(pstQpConfig->uiAreaIDTtl));

    Adpt_Json_Delete(hRoot);

    Mos_FileClose(fdConfig);
    
    return MOS_OK;
}

_INT Qp_Utils_Config_Write(ST_QP_CONF_PTR pstQpConfig)
{
    _UI uiConfFileSize = 0;

    _HFILE *fdConfig;

    _UC *pstrTmp = MOS_NULL;

    JSON_HANDLE hRoot = MOS_NULL;
    _UC tempName[QP_CONFIG_FILE_MAX_LEN];

    //检查文件路径，不存在创建
    MOS_MEMSET(tempName, 0, QP_CONFIG_FILE_MAX_LEN);
    MOS_VSNPRINTF(tempName, QP_CONFIG_FILE_MAX_LEN, "%s/%s", Mos_GetWorkPath(), QP_FOLDER);
    if (MOS_FALSE == Mos_DirIsExist((_UC*)tempName))
    {
        Mos_DirMake((_UC *)tempName, MOS_DIR_MAKE_FLAG);
    }

    // 打开或创建配置文件
    MOS_MEMSET(tempName, 0, QP_CONFIG_FILE_MAX_LEN);
    MOS_VSNPRINTF(tempName, QP_CONFIG_FILE_MAX_LEN, "%s/%s", Mos_GetWorkPath(), QP_CONF_FILENAME);
    fdConfig = Mos_FileOpen((_UC *)tempName, MOS_FILE_O_WRONLY | MOS_FILE_O_BIN);
    if (MOS_NULL == fdConfig)
    { 
        // 打开失败，则创建新文件
        fdConfig = Mos_FileOpen((_UC *)tempName, MOS_FILE_O_WRONLY | MOS_FILE_O_CREAT);
        if (MOS_NULL == fdConfig)
        {
            MOS_LOG_INF(QP_TASK, "%s create failed", QP_CONF_FILENAME);

            return MOS_ERR;
        }
        else
        {
            MOS_LOG_INF(QP_TASK, "%s is created", QP_CONF_FILENAME);
        }
    }

    MOS_LOG_INF(QP_TASK, "%s is opened", QP_CONF_FILENAME);

    // 结构体json序列化
    hRoot = Adpt_Json_CreateObject();
    if (MOS_NULL == hRoot)
    {
        return MOS_ERR;
    }

    // add node
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"qp_data_pauseflag", Adpt_Json_CreateNumber(pstQpConfig->uiQpDataPauseFlag));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"qp_data_pausetimestamp", Adpt_Json_CreateNumber((long)pstQpConfig->cQpPauseTimestamp));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"qp_data_lasttimestamp", Adpt_Json_CreateNumber((long)pstQpConfig->cQpLastTimestamp));

    Adpt_Json_AddItemToObject(hRoot, (_UC *)"check_mode_ctrl", Adpt_Json_CreateNumber(pstQpConfig->stCheckTargetCfg.ucCheckModeCtrl));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"check_data_immediately", Adpt_Json_CreateNumber(pstQpConfig->iImmSendFlag));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"check_data_cycletime", Adpt_Json_CreateNumber(pstQpConfig->stCheckTargetCfg.uiCheckDataCycleTime));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"check_data_cloudaddr", Adpt_Json_CreateString(pstQpConfig->stCheckTargetCfg.ucCheckDataCloud));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"check_data_targetaddr", Adpt_Json_CreateString(pstQpConfig->stCheckTargetCfg.ucCheckDataTarget));

    Adpt_Json_AddItemToObject(hRoot, (_UC *)"qp_data_arreaid", Adpt_Json_CreateString(pstQpConfig->aucAreaID));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"qp_data_arreattl", Adpt_Json_CreateNumber(pstQpConfig->uiAreaIDTtl));

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(QP_TASK, "\n---\nwrite[%d]:%s\n---\n", MOS_STRLEN(pstrTmp), pstrTmp);

    // 写入数据
    Mos_FileWrite(fdConfig, pstrTmp, MOS_STRLEN(pstrTmp));
    MOS_FREE(pstrTmp);
    
    uiConfFileSize = Mos_FileSize(fdConfig);

    MOS_LOG_INF(QP_TASK, "config [%d] is wrote", uiConfFileSize);

    Mos_FileClose(fdConfig);

    return MOS_OK;
}
