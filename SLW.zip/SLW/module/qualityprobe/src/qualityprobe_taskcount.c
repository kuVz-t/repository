#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_type.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

#include "qualityprobe_type_prv.h"
#include "qualityprobe_api.h"

#include "adpt_json_adapt.h"
#include "tras_httpclient.h" 
#include "cloudstg_logcode.h"


//header中的时间戳用于request body的aes加密
static long gstCountTimeStamp = {0};
static _INT iHourFirstSend    = 0;
static _INT iminuteFirstSend  = 0;

/*******************************************************************************************************
    Private Function Prototypes
********************************************************************************************************/
static _INT Qp_TaskCount_ParseCountRsp(_UC *pucJson)
{
    _UC * pucStrTmp = MOS_NULL;

    _UC  ucUpdateConfigFlag = 0;    // 是否需要保持配置标记，0-不保存，0x55-保存

    _INT iResultCode = 0;
    _INT iAreaIdTtl = 0;
    _INT iQpDataPausetime = 0;

    long timestamp = 0;
    ST_MOS_SYS_TIME stCurTime;

    JSON_HANDLE hJsonRoot    = MOS_NULL;
    JSON_HANDLE hResponseObj = MOS_NULL;
    JSON_HANDLE hTempObj     = MOS_NULL;


    hJsonRoot = Adpt_Json_Parse(pucJson);
    if (hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"result"), &iResultCode);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"message"), &pucStrTmp);

    if (0 == iResultCode)
    {
        hResponseObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"response");
        if (MOS_NULL != hResponseObj)
        {
            //可选
            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"area_Id");
            if (MOS_NULL != hTempObj)
            {
                Adpt_Json_GetString(hTempObj, &pucStrTmp);
                if (6 == MOS_STRLEN(pucStrTmp))
                {
                    if(MOS_STRSTR(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID, pucStrTmp) == MOS_NULL)
                    {
                        ucUpdateConfigFlag = 0x55;
                        MOS_STRNCPY(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID, pucStrTmp, AREA_ID_LEN-1);
                        Qp_Task_GetTaskMng()->stQpConfig.aucAreaID[AREA_ID_LEN-1] = '\0';
                    }
                }
                else
                {
                    MOS_LOG_INF(QP_COUNT, "Receive Wrong Area Id");
                }
            }

            //可选
            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"areaId_ttl");
            if (MOS_NULL != hTempObj)
            {
                Adpt_Json_GetIntegerEx(hTempObj, &iAreaIdTtl);

                if ((iAreaIdTtl >= 3) && (iAreaIdTtl <= 15))
                {
                    Mos_GetSysTime(&stCurTime);
                    timestamp = (long)Mos_SysTimetoTime(&stCurTime);
                    if(timestamp >= Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl)
                    {
                        ucUpdateConfigFlag = 0x55;
                        // 接收到服务器配置的有效期天数后，根据当前日期计算转换为失效那天的时间戳
                        // iAreaIdTtl单位是天，需转为秒时间戳60*60*24=86400
                        Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl = timestamp + iAreaIdTtl*PROBE_CHECK_TIME_DAY;
                    }
                }
                else
                {
                    MOS_LOG_INF(QP_COUNT, "Receive Wrong Areaid Ttl[%d]", iAreaIdTtl);
                }
            }

            //可选，单位分钟
            hTempObj = Adpt_Json_GetObjectItem(hResponseObj, (_UC *)"qp_data_offtime");
            if (MOS_NULL != hTempObj)
            {
                Mos_GetSysTime(&stCurTime);
                timestamp = (long)Mos_SysTimetoTime(&stCurTime);
                Adpt_Json_GetIntegerEx(hTempObj, &iQpDataPausetime);
                if ((iQpDataPausetime >= 1) && (iQpDataPausetime <= 1000))
                {
                    ucUpdateConfigFlag = 0x55;
                    Qp_Task_GetTaskMng()->stQpConfig.uiQpDataPauseFlag = 1;
                    Qp_Task_GetTaskMng()->stQpConfig.cQpPauseTimestamp = timestamp + iQpDataPausetime*PROBE_CHECK_TIME_MINUTE;
                }
                else
                {
                    MOS_LOG_INF(QP_COUNT, "Receive Wrong Data Pause Time[%d]", iQpDataPausetime);
                }
            }
        }
    }
    else
    {
        MOS_LOG_INF(QP_COUNT, "Respone Error, iResultCode[%d]", iResultCode);
    }

    if (0x55 == ucUpdateConfigFlag)
    {
        Mos_MutexLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
        if (MOS_OK != Qp_Utils_Config_Write(&(Qp_Task_GetTaskMng()->stQpConfig)))
        {
            MOS_LOG_INF(QP_COUNT, "Update Config Failed");
        }
        Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
    }

    Adpt_Json_Delete(hJsonRoot);

    return MOS_OK;
}

static _VOID Qp_TaskCount_RecvCountRspFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    ST_QP_COUNT_TRANS_MGR* pstCountTransMgr = &Qp_Task_GetTaskMng()->stCountTransMgr;
    
    MOS_LOG_INF(QP_COUNT, "Send Count Data Fail");

    if (pstCountTransMgr)
    {
        if (pstCountTransMgr->pucRecvBuf)
        {
               MOS_FREE(pstCountTransMgr->pucRecvBuf);            
        }

        pstCountTransMgr->uiPostStep= EN_QP_STATE_ASYNC_POST_NOTRANS;
        // 复位发送过程中的标记
        // pstCountTransMgr->uiOgctId     = 0;
        pstCountTransMgr->uiHasRecvLen = 0;
        pstCountTransMgr->uiRecvBufLen = 0;
        pstCountTransMgr->pucRecvBuf = MOS_NULL;
        
    }

    return;
}

static _VOID Qp_TaskCount_RecvCountRspFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iRet = 0;
    ST_QP_COUNT_TRANS_MGR* pstCountTransMgr = &Qp_Task_GetTaskMng()->stCountTransMgr;
    if (pstCountTransMgr == MOS_NULL)
    {
        MOS_LOG_INF(QP_COUNT, "CountTransMgr Is Null");
        pstCountTransMgr->uiPostStep= EN_QP_STATE_ASYNC_POST_NOTRANS;
        return;
    }

    if (pstCountTransMgr->pucRecvBuf == MOS_NULL)
    {
        MOS_LOG_INF(QP_COUNT, "Data Rsp Is Null");
        pstCountTransMgr->uiPostStep= EN_QP_STATE_ASYNC_POST_NOTRANS;
        return;
    }

    // 接收完毕，解析服务返回的数据
    if (pstCountTransMgr->pucRecvBuf)
    {
        pstCountTransMgr->pucRecvBuf[pstCountTransMgr->uiHasRecvLen] = 0;        
        MOS_LOG_INF(QP_COUNT, "Count rsp : %s",pstCountTransMgr->pucRecvBuf);
    }

    iRet = Qp_TaskCount_ParseCountRsp(pstCountTransMgr->pucRecvBuf);
    if (iRet == MOS_ERR)
    {
        MOS_LOG_ERR(QP_COUNT, "Parse Server Count Rspdata Err");
    }
    else
    {
        MOS_LOG_INF(QP_COUNT, "Parse Server Count Rspdata Ok");
    }

    MOS_FREE(pstCountTransMgr->pucRecvBuf);

    // 复位发送过程中的标记
    // pstCountTransMgr->uiOgctId     = 0;
    pstCountTransMgr->pucRecvBuf   = MOS_NULL;
    pstCountTransMgr->uiHasRecvLen = 0;
    pstCountTransMgr->uiRecvBufLen = 0;
    pstCountTransMgr->uiPostStep   = EN_QP_STATE_ASYNC_POST_NOTRANS;

    return;
}


static _VOID Qp_TaskCount_RecvCountRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    ST_QP_COUNT_TRANS_MGR* pstCountTransMgr = &Qp_Task_GetTaskMng()->stCountTransMgr;

    JSON_HANDLE hJsonRoot    = MOS_NULL;    
    hJsonRoot = Adpt_Json_Parse(pucData);
    if (hJsonRoot == MOS_NULL)
    {
        MOS_LOG_INF(QP_COUNT, "Buf Is Not The Json");        
        return;
    }
    _UC *pucEncryptBuf = MOS_NULL;
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"seq_no"), &pucEncryptBuf);

    if (pstCountTransMgr != MOS_NULL && pucEncryptBuf != MOS_NULL && MOS_STRCMP(pstCountTransMgr->aucUUID,pucEncryptBuf) != MOS_OK)
    {
        MOS_LOG_INF(QP_COUNT, "Uuid Is Error");
        Adpt_Json_Delete(hJsonRoot);
        return;
    }

    // 如果当前接收buf还没有分配空间
    if (pstCountTransMgr->uiRecvBufLen == 0)
    {
        pstCountTransMgr->uiRecvBufLen = TRANS_RECV_BUF_LENGTH;
        pstCountTransMgr->pucRecvBuf   = (_UC*)MOS_MALLOCCLR(TRANS_RECV_BUF_LENGTH);
    }

    // 还剩空余的空间则缓存下来
    if (pstCountTransMgr->uiHasRecvLen + uiLen < pstCountTransMgr->uiRecvBufLen)
    {
        MOS_MEMCPY(pstCountTransMgr->pucRecvBuf + pstCountTransMgr->uiHasRecvLen, pucData, uiLen);
        pstCountTransMgr->uiHasRecvLen += uiLen;
    }
    else
    {
        MOS_LOG_ERR(QP_COUNT, "Without Enough Buf");    
    }
    Adpt_Json_Delete(hJsonRoot);

    return;
}

static _UC* Qp_TaskCount_BuildCountReqData(ST_QP_MSG *pQPMsgNode)
{
    _UC *pstrTmp = MOS_NULL;
    _UC aucLv[18] = {0};
    _INT iLvLen = 0;

    _UC aucBuf[TRANS_MSG_ENCRYPT_BUF_LEN];
    _UC *pucEncryptBuf = MOS_NULL;

    JSON_HANDLE hRoot  = MOS_NULL;
    JSON_HANDLE hValue = MOS_NULL;
    JSON_HANDLE hDataJson = MOS_NULL;

    long timestamp = 0;

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    // request
    // build request
    hValue = Adpt_Json_CreateObject();
    
    //双向认证会有两种uid，需要易莱孚提供相应的接口进行判断
    //todo
    Adpt_Json_AddItemToObject(hValue, (_UC *)"did", Adpt_Json_CreateString(Qp_utils_GetUID()));
    Adpt_Json_AddItemToObject(hValue, (_UC *)"ctei", Adpt_Json_CreateString((_UC *)(Config_GetSystemMng()->aucDevCTEI)));
//    Adpt_Json_AddItemToObject(hValue, (_UC *)"area_id", Adpt_Json_CreateString((_UC *)"666666"));

    // uiAreaIDTtl为0表明无归属地信息，或当前时间戳大于uiAreaIDTtl存储的时间戳，表明uiAreaIDTtl失效
    if ((0 != Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl) && (timestamp <= Qp_Task_GetTaskMng()->stQpConfig.uiAreaIDTtl))
    {
        Adpt_Json_AddItemToObject(hValue, (_UC*)"area_id", Adpt_Json_CreateString((_UC*)(Qp_Task_GetTaskMng()->stQpConfig.aucAreaID)));
    }

    //add dev_type
    Adpt_Json_AddItemToObject(hValue, (_UC*)"dev_type", Adpt_Json_CreateString((_UC*)(Config_GetDeviceMng()->aucDevModel)));

    //add firm_type
    Adpt_Json_AddItemToObject(hValue, (_UC*)"firm_ver", Adpt_Json_CreateString((_UC*)(Config_GetDeviceMng()->aucDevVerSion)));

    Adpt_Json_AddItemToObject(hValue, (_UC*)"msg_type", Adpt_Json_CreateStrWithNum(pQPMsgNode->ucMsgType));
    
    hDataJson = Adpt_Json_Parse(pQPMsgNode->ucData);
    Adpt_Json_AddItemToObject(hValue, (_UC*)"data", hDataJson);

    pucEncryptBuf = Adpt_Json_Print(hValue);
    Adpt_Json_Delete(hValue);

    // 使用时间戳加密
    MOS_SPRINTF(aucLv, "%ld", gstCountTimeStamp);
    aucLv[16] = '\0';
    iLvLen = MOS_STRLEN(aucLv);

    //填充到16字节
    while (iLvLen < 16)
    {
        aucLv[iLvLen] = '0';
        iLvLen ++;
    }

    MOS_LOG_INF(QP_COUNT, "Count Data Before Encrypt:\r\n%s",pucEncryptBuf);
    
    Qp_utils_AsyncHttps_AesBase64_Encrypt(pucEncryptBuf, aucLv, aucBuf);

    MOS_FREE(pucEncryptBuf);

    // add request
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"request", Adpt_Json_CreateString(aucBuf));

    pstrTmp = Adpt_Json_Print(hRoot);

    Adpt_Json_Delete(hRoot);

    return pstrTmp;
}


static _INT Qp_TaskCount_AsycPostCountData(ST_QP_MSG *pQPMsgNode)
{
    _INT iRet        = MOS_ERR;
    _UC *pStrTmp     = MOS_NULL;
    _UC aucHost[256] = {0};
    _UC aucPath[256] = {0};
    _UC aucUUID[64]  = {0};
    _UC aucHttpHeader[256] = {0};
    _UI uiHttpsFlag = 0;
    ST_MOS_SYS_TIME stCurTime;
    
    ST_QP_COUNT_TRANS_MGR* pstCountTransMgr = &Qp_Task_GetTaskMng()->stCountTransMgr;

    //时间戳
    Mos_GetSysTime(&stCurTime);
    gstCountTimeStamp = (long)Mos_SysTimetoTime(&stCurTime);
    Qp_utils_UUID_NoCrossBar(aucUUID);
    MOS_MEMSET(pstCountTransMgr->aucUUID, 0, sizeof(pstCountTransMgr->aucUUID));
    MOS_MEMCPY(pstCountTransMgr->aucUUID, aucUUID, sizeof(pstCountTransMgr->aucUUID));

    iRet = Http_Parse_Url(QUALITY_PROBE_COUNT_REPORT_URL, aucHost, aucPath, &uiHttpsFlag);
    if (iRet == MOS_ERR){
        MOS_LOG_ERR(QP_AI, "Http_Parse_Url error");
    }
    //构建http header
    MOS_VSNPRINTF(aucHttpHeader, 256, "Plug-Version: %u\r\nTime: %ld000\r\nSeq-No: %s\r\n",Config_GetDeviceMng()->uiSdkVersion,gstCountTimeStamp,aucUUID);
    aucHttpHeader[255] = '\0';
    
    //构建http body
    pStrTmp = Qp_TaskCount_BuildCountReqData(pQPMsgNode);
    if (pStrTmp == MOS_NULL)
    {
        return MOS_ERR; 
    }

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = Qp_TaskCount_RecvCountRsp;
    stHttpInfoNode.pfuncFinished   = Qp_TaskCount_RecvCountRspFinish;
    stHttpInfoNode.pfuncFailed     = Qp_TaskCount_RecvCountRspFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    stHttpInfoNode.pucExpandHeader = aucHttpHeader;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, aucHost, aucPath, EN_HTTP_METHOD_POST, Mos_GetSessionId());
    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;

}

/* get interface call statics data */
static _INT Qp_TaskCount_MinuteInterval_CountPost(void)
{
    ST_QP_MINUTE_INFO stQpMinuteInfo;
    ST_MOS_SYS_TIME stCurTime;

    ST_QP_MSG * pQPMsgNode = NULL;

    ST_COUNT_RS stCountStatics;


    // 整理数据
    // 每分钟传输数据有：
    // - 接口调用次数统计
    // - 云存文件上传成功率

    // occur time
    Mos_GetSysTime(&stCurTime);
    MOS_SPRINTF(stQpMinuteInfo.dataOccurTime, "%ld000",(long)Mos_SysTimetoTime(&stCurTime));

    // 读清业务侧计数变量
    Qp_CountIF_ReadClear(&stCountStatics);

    // 接口调用情况
    stQpMinuteInfo.iCloudStoreSucessCnt  = stCountStatics.iSuccessCnt[COUNT_TYPE_CLOUDSTORE];
    stQpMinuteInfo.iCloudStoreCnt        = stCountStatics.iTotalCnt[COUNT_TYPE_CLOUDSTORE];
    stQpMinuteInfo.iCloudStoreLess2Cnt   = stCountStatics.iLess2Cnt[COUNT_TYPE_CLOUDSTORE];

    stQpMinuteInfo.iOtaSucessCnt         = stCountStatics.iSuccessCnt[COUNT_TYPE_OTA];
    stQpMinuteInfo.iOtaCnt               = stCountStatics.iTotalCnt[COUNT_TYPE_OTA];
    stQpMinuteInfo.iOtaLess2Cnt            = stCountStatics.iLess2Cnt[COUNT_TYPE_OTA];

    stQpMinuteInfo.iWifiCfgSucessCnt     = stCountStatics.iSuccessCnt[COUNT_TYPE_WIFICFG];
    stQpMinuteInfo.iWifiCfgCnt           = stCountStatics.iTotalCnt[COUNT_TYPE_WIFICFG];
    stQpMinuteInfo.iWifiCfgLess2Cnt        = stCountStatics.iLess2Cnt[COUNT_TYPE_WIFICFG];

    stQpMinuteInfo.iCmdSucessCnt         = stCountStatics.iSuccessCnt[COUNT_TYPE_CMD];
    stQpMinuteInfo.iCmdCnt               = stCountStatics.iTotalCnt[COUNT_TYPE_CMD];
    stQpMinuteInfo.iCmdLess2Cnt            = stCountStatics.iLess2Cnt[COUNT_TYPE_CMD];

    stQpMinuteInfo.iVodSucessCnt         = stCountStatics.iSuccessCnt[COUNT_TYPE_VOD];
    stQpMinuteInfo.iVodCnt               = stCountStatics.iTotalCnt[COUNT_TYPE_VOD];
    stQpMinuteInfo.iVodLess2Cnt            = stCountStatics.iLess2Cnt[COUNT_TYPE_VOD];

    stQpMinuteInfo.iWarningSucessCnt     = stCountStatics.iSuccessCnt[COUNT_TYPE_WARNING];
    stQpMinuteInfo.iWarningCnt           = stCountStatics.iTotalCnt[COUNT_TYPE_WARNING];
    stQpMinuteInfo.iWarningLess2Cnt      = stCountStatics.iLess2Cnt[COUNT_TYPE_WARNING];

    stQpMinuteInfo.iDevRegisterSucessCnt = stCountStatics.iSuccessCnt[COUNT_TYPE_DEVREGISTER];
    stQpMinuteInfo.iDevRegisterCnt       = stCountStatics.iTotalCnt[COUNT_TYPE_DEVREGISTER];
    stQpMinuteInfo.iDevRegisterLess2Cnt  = stCountStatics.iLess2Cnt[COUNT_TYPE_DEVREGISTER];

    // 云存文件上传情况
    stQpMinuteInfo.iCloudStoreFileSucessCnt = stCountStatics.iSuccessCnt[COUNT_TYPE_CLOUD_STOREFILE];
    stQpMinuteInfo.iCloudStoreFileCnt       = stCountStatics.iTotalCnt[COUNT_TYPE_CLOUD_STOREFILE];
    stQpMinuteInfo.iCloudStoreFileLess2Cnt  = stCountStatics.iLess2Cnt[COUNT_TYPE_CLOUD_STOREFILE];

    // p2p调用次数
    stQpMinuteInfo.iP2PCallSucessCnt     = stCountStatics.iSuccessCnt[COUNT_TYPE_P2P_CALL];
    stQpMinuteInfo.iP2PCallCnt           = stCountStatics.iTotalCnt[COUNT_TYPE_P2P_CALL];
    stQpMinuteInfo.iP2PCallLess2Cnt      = stCountStatics.iLess2Cnt[COUNT_TYPE_P2P_CALL];

    // 统一至发送格式
    pQPMsgNode = (ST_QP_MSG *)MOS_MALLOC(sizeof(ST_QP_MSG));
    if (pQPMsgNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    pQPMsgNode->ucMsgType = QP_MSG_TYPE_COUNT_MINUTE;

    MOS_VSNPRINTF(pQPMsgNode->ucData, sizeof(pQPMsgNode->ucData),"{\"timestamp\":%s,\"cloudstore\":[%d,%d,%d],\"ota\":[%d,%d,%d],\"wificfg\":[%d,%d,%d],\"cmd\":[%d,%d,%d],\"vod\":[%d,%d,%d],\"waning\":[%d,%d,%d],\"devregister\":[%d,%d,%d],\"cloudstore_filecount\":[%d,%d,%d],\"p2p\":[%d,%d,%d]}",
                                    stQpMinuteInfo.dataOccurTime,
                                    stQpMinuteInfo.iCloudStoreCnt,     stQpMinuteInfo.iCloudStoreSucessCnt,        stQpMinuteInfo.iCloudStoreLess2Cnt,
                                    stQpMinuteInfo.iOtaCnt,            stQpMinuteInfo.iOtaSucessCnt,            stQpMinuteInfo.iOtaLess2Cnt,
                                    stQpMinuteInfo.iWifiCfgCnt,        stQpMinuteInfo.iWifiCfgSucessCnt,        stQpMinuteInfo.iWifiCfgLess2Cnt,
                                    stQpMinuteInfo.iCmdCnt,            stQpMinuteInfo.iCmdSucessCnt,            stQpMinuteInfo.iCmdLess2Cnt,
                                    stQpMinuteInfo.iVodCnt,            stQpMinuteInfo.iVodSucessCnt,            stQpMinuteInfo.iVodLess2Cnt,
                                    stQpMinuteInfo.iWarningCnt,        stQpMinuteInfo.iWarningSucessCnt,        stQpMinuteInfo.iWarningLess2Cnt,
                                    stQpMinuteInfo.iDevRegisterCnt,    stQpMinuteInfo.iDevRegisterSucessCnt,    stQpMinuteInfo.iDevRegisterLess2Cnt,
                                    stQpMinuteInfo.iCloudStoreFileCnt, stQpMinuteInfo.iCloudStoreFileSucessCnt, stQpMinuteInfo.iCloudStoreFileLess2Cnt,
                                    stQpMinuteInfo.iP2PCallCnt,        stQpMinuteInfo.iP2PCallSucessCnt,        stQpMinuteInfo.iP2PCallLess2Cnt);

    _INT iRet = Qp_TaskCount_AsycPostCountData(pQPMsgNode);
    

    if (pQPMsgNode)
    {
        MOS_FREE(pQPMsgNode);        
    }

    return iRet;
}

static _INT Qp_TaskCount_HourInterval_GetCloudByteCount(_INT *llSendFlow, _INT *uiSendSpeed)
{
    CloudStg_GetQualityInfo(llSendFlow, uiSendSpeed);

    return MOS_OK;
}

static _INT Qp_TaskCount_HourInterval_CountPost(void)
{
    _INT llSendFlow = 0;
    _INT uiSendSpeed= 0;
    _UI uiCpuUsage  = 0;
    _UI uiRamUsage  = 0;
    _UI uiTotalsize = 0;
    _UI uiFreeSize  = 0;
    ST_QP_HOUR_INFO stHourinfo;
    ST_ZJ_NETWORK_INFO stNetInfo = {0};
    ST_MOS_SYS_TIME stCurTime;

    ST_QP_MSG * pQPMsgNode = NULL;


    // 整理数据
    // 每小时传输数据有：
    // - 云存储发送流量和发送速率
    // - 设备负载信息
    
    // occur time
    Mos_GetSysTime(&stCurTime);
    MOS_SPRINTF(stHourinfo.dataOccurTime, "%ld000",(long)Mos_SysTimetoTime(&stCurTime));

    //云存储发送流量和发送速率
    //统计当前上报周期内云存储发送流量（cloudstore_sendflow）,类型：整数，单位：KB；
    //当前上报周期内云存储发送速率（cloudstore_sendspeed）,类型：整数，单位KB/S；
    
    Qp_TaskCount_HourInterval_GetCloudByteCount(&llSendFlow,&uiSendSpeed);//need encapsulation
    stHourinfo.send_flow  = llSendFlow;
    stHourinfo.send_speed = uiSendSpeed;


    // - 设备负载信息
    if (ZJ_GetFuncTable()->pfunGetCpuRamUsage == MOS_NULL)//need encapsulation
    {
        MOS_LOG_INF(QP_COUNT, "pfunGetCpuRamUsage not registered");
        stHourinfo.cpu_usage  = 0;
        stHourinfo.ram_usage  = 0;
    }
    else
    {
        ZJ_GetFuncTable()->pfunGetCpuRamUsage(&uiCpuUsage, &uiRamUsage);

        stHourinfo.cpu_usage  = uiCpuUsage;
        stHourinfo.ram_usage  = uiRamUsage;
    }
        
    //tf卡信息
     if (ZJ_GetFuncTable()->pfunGetSDCardInfo == MOS_NULL)
     {
        MOS_LOG_INF(QP_COUNT, "pfunGetSDCardInfo not registered");        
        stHourinfo.sd_status  = 4;
        stHourinfo.sd_reserve = 0;
        stHourinfo.sd_total   = 0;
     }
    else
    {
        //单位M
        stHourinfo.sd_status = ZJ_GetFuncTable()->pfunGetSDCardInfo(&uiTotalsize, &uiFreeSize);
        if (stHourinfo.sd_status == 0)
        {
            stHourinfo.sd_reserve = uiFreeSize;
            stHourinfo.sd_total   = uiTotalsize;
        }
        else if (stHourinfo.sd_status> 0 && stHourinfo.sd_status < 4)
        {
            stHourinfo.sd_reserve = 0;
            stHourinfo.sd_total   = 0;
        }
        else
        {
            stHourinfo.sd_status  = 4;
            stHourinfo.sd_reserve = uiFreeSize;
            stHourinfo.sd_total   = uiTotalsize;
        }
    }
    
    if (ZJ_GetFuncTable()->pfunGetCurNetInfo == MOS_NULL)
    {
        MOS_LOG_INF(QP_COUNT, "pfunGetCurNetInfo Not Registered");
        stHourinfo.net_mode = 5;
    }
    else
    {
        // get device info once
        ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetInfo);

        MOS_MEMCPY(stHourinfo.ipaddr,stNetInfo.aucIPAddr,sizeof(stHourinfo.ipaddr));

        // 网络类型定义见 EN_ZJ_NETWORK_TYPE
        // 0 无网络 1 有线网络 2 wifi 4 ap 8 移动网络
        if (stNetInfo.iNetType == 0 || stNetInfo.iNetType == 1 || stNetInfo.iNetType == 2)
        {
            stHourinfo.net_mode = stNetInfo.iNetType;
        }
        else if (stNetInfo.iNetType == 4)
        {
            stHourinfo.net_mode = 3;
        }
        else if (stNetInfo.iNetType == 8)
        {
            stHourinfo.net_mode = 4;
        }
        else
        {
            stHourinfo.net_mode = 5;
        }

    }

    // set signal strength to 0 if the net type is wired or no network
    if ((0 == stHourinfo.net_mode) || (3 == stHourinfo.net_mode) || (5 == stHourinfo.net_mode))
    {
        stHourinfo.sigstrength = 0;
    }
    else
    {
        stHourinfo.sigstrength = stNetInfo.iSigStrength;
    }


    // 统一至发送格式
    pQPMsgNode = (ST_QP_MSG *)MOS_MALLOC(sizeof(ST_QP_MSG));
    if (pQPMsgNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    pQPMsgNode->ucMsgType = QP_MSG_TYPE_COUNT_HOUR;

    MOS_VSNPRINTF(pQPMsgNode->ucData, sizeof(pQPMsgNode->ucData),"{\"ip\":\"%s\",\"timestamp\":%s,\"cloudstore\":[%d,%d],\"dev_info\":[%d,%d,%d,%d,%d,%d,%d]}",
                                    stHourinfo.ipaddr,
                                    stHourinfo.dataOccurTime,
                                    stHourinfo.send_flow,
                                    stHourinfo.send_speed,
                                    stHourinfo.cpu_usage,
                                    stHourinfo.ram_usage,
                                    stHourinfo.sd_status,
                                    stHourinfo.sd_reserve,
                                    stHourinfo.sd_total,
                                    stHourinfo.net_mode,
                                    stHourinfo.sigstrength);

    _UC aucMsgString[1024] = {0}; 
    MOS_SPRINTF(aucMsgString, "%s Start Upload Hour Info (%s)", QUALITYPROBE_ID_LOG_STR, pQPMsgNode->ucData);
    CloudStg_UploadLog(Mos_GetSessionId(), QUALITY_PROBE_COUNT_REPORT_URL, 0, EN_QUALITYPROBE_RT_START_UPLOAD_HOURINFO, aucMsgString, 1);                                

    _INT iRet = Qp_TaskCount_AsycPostCountData(pQPMsgNode);

    if (pQPMsgNode)
    {
        MOS_FREE(pQPMsgNode);        
    }

    return iRet;

}

_INT Qp_TaskCount_Entry(ST_MOS_SYS_TIME *minBeginTime, ST_MOS_SYS_TIME *hourBeginTime)
{
    if ((EN_ZJ_NETWORK_TYPE_NONET == Http_GetNetWorkType()) || (EN_ZJ_NETWORK_TYPE_AP == Http_GetNetWorkType()))
    {
        MOS_PRINTF("Have No Network, Can Not Start TaskCount\n");
        return MOS_OK;
    }

    _CTIME_T cNowTime = 0;
    ST_MOS_SYS_TIME getNowTime;

    //检测是否暂停结束
    cNowTime = Mos_Time();    
    
    //判断是否需要暂停数据采集
    if (Qp_Task_GetTaskMng()->stQpConfig.uiQpDataPauseFlag == 1)
    {
        if (Qp_Task_GetTaskMng()->stQpConfig.cQpPauseTimestamp < cNowTime)
        {
            Qp_Task_GetTaskMng()->stQpConfig.uiQpDataPauseFlag = 0;
            Qp_Task_GetTaskMng()->stQpConfig.cQpPauseTimestamp = 0;
            Mos_MutexLock(&Qp_Task_GetTaskMng()->hConfFileMutex);
            if (MOS_OK != Qp_Utils_Config_Write(&(Qp_Task_GetTaskMng()->stQpConfig)))
            {
                MOS_LOG_INF(QP_COUNT, "update config failed");
            }
            Mos_MutexUnLock(&Qp_Task_GetTaskMng()->hConfFileMutex);            
        }
        else
        {
            //清空本次的数据
            (_VOID)Qp_CountIF_Clear();            
        }
    }
    else
    {            
        ST_QP_COUNT_TRANS_MGR* pstCountTransMgr = &Qp_Task_GetTaskMng()->stCountTransMgr;
        // 一分钟周期检测
        // 接口调用统计
        Mos_GetSysTime(&getNowTime);
        if ((MOS_OK == Qp_utils_TimeCompare(*minBeginTime, getNowTime, PROBE_CHECK_TIME_MINUTE) || iminuteFirstSend == 0) && pstCountTransMgr->uiPostStep == EN_QP_STATE_ASYNC_POST_NOTRANS)
        {
            MOS_LOG_INF(QP_COUNT, "Is Time To Send Count Minute Data");
            
            pstCountTransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_TRANSED;    
            iminuteFirstSend = 1;
            // 更新下次设备的检测时间
            *minBeginTime = getNowTime;
            // post count data every minute
            if (MOS_OK != Qp_TaskCount_MinuteInterval_CountPost())
            {
                pstCountTransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_NOTRANS;
                MOS_LOG_ERR(QP_COUNT, "Send Count Minute Data Error");
            } 
        }
    
        // 一小时周期检测
        // 设备信息检测
        if ((MOS_OK == Qp_utils_TimeCompare(*hourBeginTime, getNowTime, PROBE_CHECK_TIME_HOUR) || iHourFirstSend == 0) && pstCountTransMgr->uiPostStep == EN_QP_STATE_ASYNC_POST_NOTRANS)
        {
            MOS_LOG_INF(QP_COUNT, "Is Time To Send Count Hour Data");
            pstCountTransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_TRANSED; 
            iHourFirstSend = 1;    
            // 更新下次设备的检测时间
            *hourBeginTime = getNowTime;
    
            // post count data every hour
            if (MOS_OK != Qp_TaskCount_HourInterval_CountPost())
            {
                pstCountTransMgr->uiPostStep = EN_QP_STATE_ASYNC_POST_NOTRANS;
                MOS_LOG_ERR(QP_COUNT, "Send Count Hour Data Error");
            } 
        }    
    }

    return MOS_OK;
}




