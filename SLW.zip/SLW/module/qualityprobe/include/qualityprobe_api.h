#ifndef _QUALITYPROBE_API_H
#define _QUALITYPROBE_API_H

/***************************************************************************************************************
****************************************************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"


// 统计类型定义
typedef enum enum_COUNT_TYPE
{
    // 接口调用情况
    COUNT_TYPE_CLOUDSTORE,//云存上传
    COUNT_TYPE_OTA,//OTA升级
    COUNT_TYPE_WIFICFG,//wifi配网
    COUNT_TYPE_CMD,//信令
    COUNT_TYPE_VOD,//音视频点播
    COUNT_TYPE_WARNING,//事件告警
    COUNT_TYPE_DEVREGISTER,//自注册

    // 云存文件上传情况
    COUNT_TYPE_CLOUD_STOREFILE,

    // p2p调用次数
    COUNT_TYPE_P2P_CALL,

    COUNT_TYPE_MAX_NUM
}EN_COUNT_TYPE;


// 统计结果定义
typedef enum enum_COUNT_VALUE
{
    COUNT_VALUE_FAIL,
    COUNT_VALUE_SUCCESS,
    COUNT_VALUE_MAX_NUM
}EN_COUNT_VALUE;


/******************************************************************************************************************
*******************************************************************************************************************/
_INT Qp_Task_Init();
_INT Qp_Task_Start();
_INT Qp_Task_Stop();
_INT Qp_Task_Destroy();



/**********************************************************************************
由业务层埋点，统计相关业务调用情况
emCountType:  业务模块ID
iCountResult: 接口调用结果
iCountLess2Result:响应小于2秒结果（仅当iCountResult==COUNT_VALUE_SUCCESS时生效）
***********************************************************************************/
_INT Qp_CountIF_Post(EN_COUNT_TYPE emCountType, EN_COUNT_VALUE iCountResult,EN_COUNT_VALUE iCountLess2Result);


#ifdef __cplusplus
}
#endif

#endif
