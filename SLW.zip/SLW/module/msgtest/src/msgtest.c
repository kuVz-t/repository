
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <errno.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include "mos.h"
#include "adpt_json_adapt.h"
#include "msgmng_api.h"
#include "msgtest.h"

static _HTHREAD hListenThread        = MOS_NULL;
static _SOCKET iSocketFd             = 0;
static _UC pucMsgTestBuffer[32*1024] = {0};

_INT MsgTest_SendMsg(_UC *pucMsgBuff,_INT iMsgLen)
{
    _INT iMsgTmpLen = iMsgLen > sizeof(pucMsgTestBuffer) ? sizeof(pucMsgTestBuffer) : iMsgLen;
    MOS_MEMCPY(pucMsgTestBuffer, pucMsgBuff, iMsgTmpLen);
    return MOS_OK;
}

static _INT MsgTest_CreateTcpSocket()
{
    //生成UDP套接字
    iSocketFd = Mos_SocketOpen(EN_CINET_TYPE_IPV4, EN_CINET_PRTL_TCP, MOS_TRUE, MOS_TRUE);
    if (iSocketFd == MOS_SOCKET_INVALID)
    {                 
        MOS_PRINTF("%s %d: SocketOpen error \n", __func__, __LINE__);
        return MOS_ERR; 
    }

    ST_MOS_INET_IP stLocalIp = {0};
    stLocalIp.usType = EN_CINET_TYPE_IPV4;
    stLocalIp.usPort = 1085;
    stLocalIp.u.uiIp = htonl(INADDR_ANY);

    if (Mos_SocketBind(iSocketFd, &stLocalIp) != MOS_OK)
    {
        MOS_PRINTF("%s %d: SocketBind errno\n", __func__, __LINE__);
        Mos_SocketClose(iSocketFd);
        return MOS_ERR;
    }

    if (Mos_SocketListen(iSocketFd) != MOS_OK)
    {
        MOS_PRINTF("%s %d: SocketListen errno\n", __func__, __LINE__);
        Mos_SocketClose(iSocketFd);
        return MOS_ERR;
    }

    MOS_PRINTF("%s %d: Tcp Server Start Successfully\n", __func__, __LINE__);

    return MOS_OK;
}

static _INT MsgTest_FillHtmlPageResponse(_C* ResponseBuffer, _C* IpaddrStr)
{
    if ((ResponseBuffer == NULL) || (IpaddrStr == NULL) )
    {
        return MOS_ERR;
    }

    _C* pTemp = (_C *)ResponseBuffer;
    pTemp += MOS_SPRINTF(pTemp, "HTTP/1.0 200 OK\r\n");
    pTemp += MOS_SPRINTF(pTemp, "Server: Stupid Server/0.1.1\r\n");
    pTemp += MOS_SPRINTF(pTemp, "Connection: close\r\n");
    pTemp += MOS_SPRINTF(pTemp, "Content-Type: text/html; charset=UTF-8\r\n\r\n");
    pTemp += MOS_SPRINTF(pTemp, "<HTML><HEAD><TITLE>信令传输测试</TITLE></HEAD>\r\n");
    pTemp += MOS_SPRINTF(pTemp, "<BODY>\r\n");
    pTemp += MOS_SPRINTF(pTemp, "<div style=\"padding:10px\">\r\n");
    pTemp += MOS_SPRINTF(pTemp, "<p>信令下发内容:</p>\r\n");
    pTemp += MOS_SPRINTF(pTemp, "<textarea id=\"send\" style=\"font-size:1px;width:100%;\" rows=\"15\"></textarea>\r\n");
    pTemp += MOS_SPRINTF(pTemp, "<p><input type=\"button\" value=\"发送\" onclick = \"send()\"></p>");
    pTemp += MOS_SPRINTF(pTemp, "<p>设备回复内容:</p>\r\n");
    pTemp += MOS_SPRINTF(pTemp, "<div id=\"recv\" style=\"font-size:1px;height:250px;width:100%;border: 1px solid rgba(0,0,0,0.4);border-radius:1px;\"></div>");
    pTemp += MOS_SPRINTF(pTemp, "</div>");
    pTemp += MOS_SPRINTF(pTemp, "<script>");
    pTemp += MOS_SPRINTF(pTemp, "function send() {var xhr = new XMLHttpRequest()\r\n");
    pTemp += MOS_SPRINTF(pTemp, "xhr.open(\"POST\", 'http://%s/api/send')\r\n",IpaddrStr);
    pTemp += MOS_SPRINTF(pTemp, "let value = document.getElementById('send').value\r\n");
    pTemp += MOS_SPRINTF(pTemp, "let recvDom = document.getElementById('recv')\r\n");
    pTemp += MOS_SPRINTF(pTemp, "xhr.setRequestHeader('Content-Type', 'application/json');\r\n");
	// pTemp += MOS_SPRINTF(pTemp, "let data = {value}\r\n");
    // pTemp += MOS_SPRINTF(pTemp, "var jsonData = JSON.stringify(data);\r\n");
    pTemp += MOS_SPRINTF(pTemp, "xhr.send(value)\r\n");
    pTemp += MOS_SPRINTF(pTemp, "xhr.onreadystatechange = function (){if (xhr.readyState == 4 && xhr.status == 200){console.log(xhr.responseText);recvDom.innerHTML = xhr.responseText}}}\r\n");
    pTemp += MOS_SPRINTF(pTemp, "</script>");
    pTemp += MOS_SPRINTF(pTemp, "</BODY></HTML>\r\n");        
    return MOS_OK;
}
static _INT MsgTest_FillMsgResponse(_C* ResponseBuffer, _C* ResponseStr)
{
    _C* pTemp = (_C *)ResponseBuffer;
    pTemp += MOS_SPRINTF(pTemp, "HTTP/1.0 200 OK\r\n");
    pTemp += MOS_SPRINTF(pTemp, "Date: Fri, 25 Nov 2016 08:33:41 GMT\r\n");
    pTemp += MOS_SPRINTF(pTemp, "Server: Stupid Server/0.1.1\r\n");
    pTemp += MOS_SPRINTF(pTemp, "Connection: close\r\n");
    if (ResponseStr)
    {
        pTemp += MOS_SPRINTF(pTemp, "Content-Length: %ld\r\n", MOS_STRLEN(ResponseStr));
    }    
    pTemp += MOS_SPRINTF(pTemp, "Content-Type: text/html; charset=UTF-8\r\n\r\n");
    if (ResponseStr)
    {
        pTemp += MOS_SPRINTF(pTemp, "%s\r\n", ResponseStr);    
    }    
    
    return MOS_OK;
}

_INT MsgTest_HttpParseHeader(_SOCKET hSocket, _INT *piContentLength, _C *pucRedirectUrl)
{
    _UC aucBuffer[1]    = {0};
    _UC aucTemp[BUFSIZ] = {0};
    _UC *pucPtr         = MOS_NULL;
    _UC *pucPtrTmp      = MOS_NULL;
    _INT iLen           = 0;    
    _INT iTmp           = 0;
    _INT n              = 0;
    _INT iRet           = 0;
    _CTIME_T tBeginTime = 0;

    if ((!piContentLength) || (!pucRedirectUrl))
    {
        return MOS_ERR;
    }

    *piContentLength = 0;
    tBeginTime = Mos_Time();

    while (1)
    {
        iRet = Mos_SocketRecv(hSocket, (_UC *)aucBuffer, 1, &iTmp);
        //返回值为0表明断连，iTmp等于ture表示需要断开socket
        if ((iRet == 0) || (iTmp == MOS_TRUE))
        {
            MOS_PRINTF("Mos_SocketRecv error iRet[%d]  iTmp[%d]", iRet, iTmp);
            break;
        }
        aucTemp[n] = *aucBuffer;
        if (*aucBuffer == '\n')
        {
            pucPtr = MOS_STRSTR(aucTemp,"Content-Length:");
            if (pucPtr != NULL)
            {
                // 如果是keep alive，则content-length和chunk必然是二选一
                // 若是非keep alive，则和http1.0一样。content-length可有可无
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                *piContentLength = MOS_STRTOL(pucPtr, 10);
            }

            pucPtr = MOS_STRSTR(aucTemp,"Host:");
            if (pucPtr != NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                pucPtrTmp = MOS_STRCHR(pucPtr,'\r');
                iLen = pucPtrTmp - pucPtr;
                if (pucRedirectUrl)
                {
                    strncpy(pucRedirectUrl, pucPtr+1, iLen-1);
                }
            }
            // MOS_PRINTF("%s",aucTemp);
            //"\r\n"后接着"\r\n"
            if (aucTemp[0] == '\r' && aucTemp[1] == '\n')
            {
                return MOS_OK;
            }
            MOS_MEMSET(aucTemp, 0, sizeof(aucTemp));
            n = -1;
        }
        n++;

        if ((tBeginTime+5) < Mos_Time())
        {
            MOS_PRINTF("%s timeout error\n", __FUNCTION__);
            return MOS_ERR;
        }
    }
    return MOS_ERR;//接收数据失败
}

static _VPTR MsgTest_SocketThread(_VPTR arg)
{
    fd_set fd_sets;
    struct sockaddr_in peer_addr;
    _INT iConnectfd          = -1;
    struct timeval wait_time = {1, 5000};
    _INT iRet                = MOS_ERR;
    _BOOL pbOutWait          = MOS_FALSE;
    _INT iTmp                = 0;
    _INT ilen                = sizeof(struct sockaddr);
    _C RecvBuffer[32*1024]   = {0};
    _C SendBuffer[33*1024]   = {0};
    _C RecvIpaddr[96]        = {0};
    _UC* pStrTmp             = NULL;

    while(1)
    {
        FD_ZERO(&fd_sets);
        FD_CLR(iSocketFd, &fd_sets);
        FD_SET(iSocketFd, &fd_sets);

        switch (select(iSocketFd+1, &fd_sets, NULL, NULL, &wait_time))
        {
            case -1:
            case 0:
                usleep(20000);
                continue;
            default:
                break;
        }

        if (FD_ISSET(iSocketFd, &fd_sets))
        {
            iConnectfd = accept(iSocketFd, (struct sockaddr *)&peer_addr, (socklen_t *)&ilen);
            if (iConnectfd < 0)
            {
                MOS_PRINTF("%s %d: Accept iConnectfd < 0\n", __func__, __LINE__);
                sleep(1);
                continue;
            }
            fcntl(iConnectfd,F_SETFL,O_NONBLOCK);

            _INT piContentLength = 0;
            iRet = MsgTest_HttpParseHeader(iConnectfd, &piContentLength, RecvIpaddr);
            if ((iRet == 0) && (piContentLength > 0) && (piContentLength < 32*1024))
            {
                iRet = Mos_SocketRecv(iConnectfd, RecvBuffer, piContentLength, &iTmp);
                if(iRet > 0)
                {
                    MOS_PRINTF("%s\n", RecvBuffer);
                    JSON_HANDLE hRoot = Adpt_Json_Parse(RecvBuffer);
                    if (hRoot != NULL)
                    {                
                        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot, (_UC*)"METHOD"),&pStrTmp);              
                        long int cmdid = MOS_STRTOL(pStrTmp, 16);
                        _UC ucMsgType = (_UC)((cmdid >> 8) &  0x000000FF);
                        _UC ucMsgId   = (_UC)(cmdid &  0x000000FF);
                        MsgMng_DispatchMsg(MSGTEST_SERVER_ID, ucMsgType, ucMsgId, hRoot);

                        _INT iwaittime = 3*100;
                        while (iwaittime > 0)
                        {
                            if (MOS_STRLEN(pucMsgTestBuffer) > 0)
                            {
                                MOS_PRINTF("%s\n", pucMsgTestBuffer);
                                MsgTest_FillMsgResponse(SendBuffer,pucMsgTestBuffer);
                                break;
                            }
                            iwaittime--;
                            usleep(10*1000);
                        }
                        
                        Adpt_Json_Delete(hRoot);                        
                    }
  
                }            
            }
            else if(MOS_STRLEN(RecvIpaddr) > 0)
            {
                MsgTest_FillHtmlPageResponse(SendBuffer,RecvIpaddr);
            }

            if(MOS_STRLEN(SendBuffer) > 0)
            {
                Mos_SocketSend(iConnectfd, SendBuffer, MOS_STRLEN(SendBuffer), &pbOutWait);
            }
            MOS_MEMSET(RecvBuffer,0,sizeof(RecvBuffer));
            MOS_MEMSET(SendBuffer,0,sizeof(SendBuffer));
            MOS_MEMSET(RecvIpaddr,0,sizeof(RecvIpaddr));
            MOS_MEMSET(pucMsgTestBuffer,0,sizeof(pucMsgTestBuffer));

            close(iConnectfd);        
        }
        usleep(1);
    }

    Mos_SocketClose(iSocketFd);
    Mos_ThreadDelete(hListenThread);
    hListenThread = MOS_NULL;
    MOS_PRINTF("%s %d: Thread end!\n", __func__, __LINE__);
    return MOS_NULL;
}

_INT MsgTest_Start()
{
    _INT iRet = MsgTest_CreateTcpSocket();
    if (iRet != MOS_OK)
    {
        return MOS_ERR;
    }

    if(Mos_ThreadCreate((_UC*)"MNGTEST_TASK", EN_THREAD_PRIORITY_NORMAL, MOS_THREAD_STACK_HIGH_SIZE,
                        MsgTest_SocketThread, MOS_NULL,MOS_NULL, &hListenThread) == MOS_ERR)
    {
        Mos_SocketClose(iSocketFd);
        return MOS_ERR;
    }

    MOS_PRINTF("%s %d: MsgTest Server is SuccessFully!\n", __func__, __LINE__);

    return MOS_OK;
}