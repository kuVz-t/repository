
#ifndef _MSGTEST_H
#define _MSGTEST_H

#ifdef __cplusplus
extern "C" {
#endif

_INT MsgTest_SendMsg(_UC *pucMsgBuff, _INT iMsgLen);

_INT MsgTest_Start();

#ifdef __cplusplus
}
#endif

#endif
