#ifndef CLOUDSTG_NETCHECK_H 
#define CLOUDSTG_NETCHECK_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"

#define TASK_MAX_NUM 5
#define CHUNK_SIZE 1400 // 每个数据块的大小
#define CHUNK_NUM_SIZE 8 // 每个数据块的大小
#define DATA_MAX_SIZE 5242880 // 5MB
#define TCPING_TIMEOUT 1 // TCPING超时 1s
#define VIDEO_TEMPLATE   "PUT %s HTTP/1.1\r\n" \
                         "Host: %s\r\n" \
                         "Connection: keep-alive\r\n" \
                         "Date: %s\r\n" \
                         "Authorization: %s\r\n" \
                         "Content-Type: application/octet-stream\r\n" \
                         "Expect: 100-continue\r\n" \
                         "Transfer-Encoding: chunked\r\n" \
                         "\r\n"

typedef enum enum_CLOUDSTG_NETCHECK_TYPE
{
    EN_CLOUDSTG_NETCHECK_TCPING    = 0x01, // Tcping
    EN_CLOUDSTG_NETCHECK_DNS       = 0x02, // DNS
    EN_CLOUDSTG_NETCHECK_BANDWIDTH = 0x03, // Bandwidth
}EN_CLOUDSTG_NETCHECK_TYPE;

typedef struct stru_CloudStg_Netcheck_Tcping_Result
{
    _INT iDelay;        // 平均延时（ms）
    _INT iMinDelay;     // 最小延时（ms）
    _INT iMaxDelay;     // 最大延时（ms）
    _INT iTimeoutCount; // 超时次数
}ST_CLOUDSTG_NETCHECK_TCPING_RESULT;

typedef struct stru_CloudStg_Netcheck_Dns_Result
{
    _INT iDelay;        // 解析延时（ms）
    _INT iResult;       // 解析成功或失败：0-失败 1-成功
}ST_CLOUDSTG_NETCHECK_DNS_RESULT;

typedef struct stru_CloudStg_Netcheck_Bandwidth_Result
{
    _INT iSpeed;        // 速度（KB/s）
}ST_CLOUDSTG_NETCHECK_BANDWIDTH_RESULT;

typedef struct stru_CloudStg_Netcheck_Task
{
    _UI  uiTaskId;	
    _INT iType;
    _INT iNum;
    _INT iIndex;

    // 常驻
    _BOOL bIsPermanentRuning;
    _BOOL bIsPermanent;
    _UI  iNextReqTime;
    _INT iCollectFreq;

    // Tcping/DNS测试
    _UC	 aucHost[5][128];
    _INT iSiteId[5];
    _INT iDetectFreq;
    _INT iDetectCount;
    ST_CLOUDSTG_NETCHECK_TCPING_RESULT stTcpingResult[5];
    ST_CLOUDSTG_NETCHECK_DNS_RESULT    stDnsResult[5];

    // 带宽测试
    _UC aucAuthorization[2][64];
    _UC aucRequestURL[2][1024];
    _UC aucRequestDate[2][32];
    ST_CLOUDSTG_NETCHECK_BANDWIDTH_RESULT stBandwidthResult[2];

    ST_MOS_LIST_NODE stNode;
}ST_CLOUDSTG_NETCHECK_TASK;

typedef struct stru_CloudStg_Netcheck_Manage
{
    _UC         ucInitFlag;   // 初始化标志位
    _UC         ucRunFlag;    // 运行标志位
    _UC         ucChangeFlag; // 常驻配置变更
    _HTHREAD    hMgrThread;   // 线程句柄
    _HMUTEX     hMutex;       // 日志读写锁
    ST_MOS_LIST_NODE    *pstCurBufNode;
    ST_MOS_LIST stTaskList;   // 任务链表
}ST_CLOUDSTG_NETCHECK_MANAGE;

_INT CloudStg_Netcheck_Init();

_INT CloudStg_Netcheck_Start();

_INT CloudStg_Netcheck_Stop();

_INT CloudStg_Netcheck_Destroy();

_VOID CloudStg_NetcheckProc();

_VOID CloudStg_NetcheckTaskAdd_Tcping(_INT iNum, _UC **aucHost, _INT iHostSize, _INT *iSiteId, _INT iSiteIdSize, _INT iDetectFreq, _INT iDetectCount, _INT iCollectFreq, _BOOL bIsPermanent);

_VOID CloudStg_NetcheckTaskAdd_Dns(_INT iNum, _UC **aucHost, _INT iHostSize, _INT *iSiteId, _INT iSiteIdSize);

_VOID CloudStg_NetcheckTaskAdd_Bandwidth(_INT iNum, _UC **aucHost, _INT iHostSize, _INT *iSiteId, _INT iSiteIdSize, _UC **aucAuthorization, _INT iAuthorizationSize, _UC **aucRequestURL, _INT iRequestURLSize, _UC **aucRequestDate, _INT iRequestDateSize);

_VOID CloudStg_NetcheckTaskAdd(ST_CLOUDSTG_NETCHECK_TASK *pstTask);

_VOID CloudStg_NetcheckTaskDelete(_UI uiTaskId);

_VOID CloudStg_NetcheckTaskClosePermanent();

_INT CloudStg_NetcheckTcpingTest(_UC *pucHost, _INT iDetectFreq, _INT iDetectCount, ST_CLOUDSTG_NETCHECK_TCPING_RESULT *pstTcpingRes);

_INT CloudStg_NetcheckDnsTest(_UC *pucHost, ST_CLOUDSTG_NETCHECK_DNS_RESULT *pstDnsRes);

_INT CloudStg_NetcheckBandwidthTest(_UC *pucUrl, _UC *pucAuthorization, _UC *pucRequestDate, ST_CLOUDSTG_NETCHECK_BANDWIDTH_RESULT *pstBandWidthRes);

_UC *CloudStg_NetcheckBuildTcpingJson(ST_CLOUDSTG_NETCHECK_TASK *pstTask);

_UC *CloudStg_NetcheckBuildBandwidthJson(ST_CLOUDSTG_NETCHECK_TASK *pstTask);

_UC *CloudStg_NetcheckBuildDnsJson(ST_CLOUDSTG_NETCHECK_TASK *pstTask);

_INT CloudStg_NetcheckGetDns(_UC *pucBuf, _INT iLen);

#ifdef __cplusplus
}
#endif
#endif