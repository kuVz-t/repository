#ifndef CLOUDSTG_API_H
#define CLOUDSTG_API_H

#ifdef __cplusplus
extern "C" {
#endif

typedef _VOID (*PFUN_CLOUDFILESENDCB)(_UI uiReqId,_INT iStatus,_UC *pucFid);

// 云存初始化
_INT CloudStg_Init();

// 云存开始
_INT CloudStg_Start();

// 云存停止
_INT CloudStg_Stop();

// 云存销毁
_INT CloudStg_Destroy();

// 初始化参数
_INT CloudStg_InitChargeInfo();

// 创建云存上传任务
_INT CloudStg_StartAliveUpLoad(_INT iCamId,_INT iStreamId,_UI uiDuration);

// 停止云存上传任务
_INT CloudStg_StopAliveUpLoad(_INT iCamId,_INT iStreamId);

// 设置全天上传(deprecated)
_INT CloudStg_SetAllDayUpLoad(_INT iCamId,_INT iStreamId,_UI uiAllDayFlag);

// 设置cam状态
_INT CloudStg_SetCamOpenFlag(_INT iOpenFlag);

// 发送实时图片
_INT CloudStg_StartSendAlivePic(_UI uiReqId,_INT iCamId,_UI uiJpgCnt,_CTIME_T cSignTime,PFUN_CLOUDFILESENDCB pFunFileSendCb);

// 发送本地图片
_INT CloudStg_StartSendFilePic(_UI uiReqId,_INT iCamId,_UC *pucEidName);

// 人脸上传
_INT CloudStg_StartSendHumanFacePic(_UI uiReqId,_INT iCamId,_UC *pucFaceBuff,_UI uiBuffLen,PFUN_CLOUDFILESENDCB pFunFileSendCb);

// 本地日志上报
_INT CloudStg_UploadLocalLog(_UI uiReqId,_UC *pucFileName,_UC *pucDesInfo);

// 实时日志上报
_INT CloudStg_UploadLog(_UI uiReqId, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _INT iLevel);
_INT CloudStg_UploadLogEx(_UI uiReqId, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC *pucEt, _INT iLevel);
_INT CloudStg_UploadLogEx2(_UC *pucStrLog, _UI uiReqId, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC * pucEt, _INT iLevel);

// 通用实时错误日志上报 
// pucModuleName: 模块名 如：CD
// pucFunction: 功能名 cinfo
// pucUrl: 请求地址/函数名 如：https://cloud-ehome.21cn.com/unifyDev/cinfo
// iRt: 定义的错误码 如：30001
// enType: 错误类型枚举EN_CLOUDSTG_LOG_ERROR_TYPE 如：EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME
_INT Cloudstg_UploadLog_Error(_UC *pucModuleName, _UC *pucFunction, _UC *pucUrl, _INT iRt, _INT enType);

// 开始定时抓拍
_INT CloudStg_StartTimerSnap(_INT iCamId,_INT iPicType,_INT iSnapInterval ,_UI uiJpgCnt);

// 停止定时抓拍
_INT CloudStg_StopTimerSnap(_INT iCamId);

// 格式化SD卡
_INT CloudStg_FormatSDCard();

// 查询任务的开始时间(deprecated)
_INT CloudStg_FindMediaStartTime(_CTIME_T tEventTime,_CTIME_T *ptStartTIme);

// 质量探针 iTotalSentKBytes: 1小时内发送的数据量, iAverageSpeed: 平均速度
_INT CloudStg_GetQualityInfo(_INT *iTotalSentKBytes, _INT *iAverageSpeed);

_VOID CloudstgSetCloudEventUploadInitFlag(_UI uiInitFlag);

// 云存处理设备外网IP变更的逻辑
_INT CloudStg_NotifyOuterIPChange();

// 当前云存结束后自动创建下一个云存flag
_VOID CloudStg_SetStartNextEventCloudFlag(_UI uiFlag);

// 创建事件云存任务
_INT CloudStg_StartEventUpLoad(_INT iCamId,_INT iStreamId,_UI uiDuration,_CTIME_T cEventTime);

// 休眠状态变更标志，0 无变更 1 有变更
_VOID CloudstgSetCameraStatusChangeFlag(_UI uiChangeFlag);
#ifdef __cplusplus
}
#endif

#endif
