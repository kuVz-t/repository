#ifndef CLOUDSTG_LOG_CODE_H
#define CLOUDSTG_LOG_CODE_H

#ifdef __cplusplus
extern "C" {
#endif

#define MSGMNG_REGIST_INFO_STR      (_UC*)"REG"         // 信令注册登录及CTEI自注册信息上报
#define MSGMNG_MULTI_MEDIA_STR      (_UC*)"MM"          // 流媒体模块
#define RDSTG_LOGSTR_STR            (_UC*)"RD"          // 卡录像模块
#define MSGMNG_EVENT_STR            (_UC*)"ET"          // 消息告警模块
#define OVER_THE_AIR_STR            (_UC*)"OTA"         // OTA升级模块
#define GA1400_LOGSTR               (_UC*)"GA"          // GA1400模块
#define AICFG_LOGSTR                (_UC*)"AI"          // AI模块
#define MSGMNG_ID_LOG_STR           (_UC*)"MSG"         // 信令模块
#define BROADCAST_ID_LOG_STR        (_UC*)"BC"          // 云广播
#define QUALITYPROBE_ID_LOG_STR     (_UC*)"QP"          // 质量探针
#define DOWNFILE_LOGSTR             (_UC*)"DF"          // 文件下载
#define CLOUDCAMERA_LOG_STR         (_UC*)"CC"          // 云化摄像头

// OTA模块
typedef enum enum_OTA_RT_TYPE
{
    // 检查升级版本号
    EN_OTA_RT_NEED_CHECK_NEWVERSION     = 40100,    // 0x3414信令，平台通知检查设备版本
    EN_OTA_RT_RECV_NO_VERSION_UPGRADE   = 40101,    // 0x3335信令，平台返回没有可升级版本
    EN_OTA_RT_DEV_READY_TO_UPGRADE      = 40102,    // 设备准备完毕，通知SDK可升级
    EN_OTA_RT_LOCAL_VERSION_BIGGER      = 40103,    // 本地版本更高
    EN_OTA_RT_CHECK_VERSION_NULL        = 40104,    // 设备版本为空
    EN_OTA_RT_GET_MSG_TIMEOUT           = 40105,    // 0x3335信令，平台回复超时
    EN_OTA_RT_RSP_CHECK_VERSION         = 40106,    // 0x3415信令，回复平台检查固件版本信令
    EN_OTA_RT_NOTIFY_FACTORY_FAIL       = 40107,    // 通知设备有可升级版本，回调返回错误

    // 下载固件 
    EN_OTA_RT_GET_URL_NULL              = 40200,    // OTA下载地址为空
    EN_OTA_RT_GET_URL_FAIL              = 40201,    // OTA获取下载URL错误
    EN_OTA_RT_UNRECOGNIZE_URL           = 40202,    // OTA下载URL格式错误
    EN_OTA_RT_GET_IPADDR_FAIL           = 40203,    // OTA获取IP地址失败
    EN_OTA_RT_CREATE_THREAD_FAIL        = 40204,    // 创建固件下载线程失败
    EN_OTA_RT_HTTP_CONNECT_FAIL         = 40205,    // 创建http连接失败
    EN_OTA_RT_GET_HEADER_FAIL           = 40206,    // 线程读取http头部失败
    EN_OTA_RT_GET_HTTP_WRONG_CODE       = 40207,    // http返回码错误
    EN_OTA_RT_DOWNLOAD_TIMEOUT          = 40208,    // 接受固件包超时
    EN_OTA_RT_IMAGE_DOWNLOAD_SUCCESS    = 40209,    // 固件下载完成
    EN_OTA_RT_IMAGE_VERITY_FAIL         = 40210,    // MD5校验失败
    EN_OTA_RT_NOTIFY_DEVICE_COVER       = 40211,    // 通知设备覆盖固件

    // APP升级
    EN_OTA_RT_RECV_START_UPGRDE         = 40300,    // SDK接收到通知设备开始升级信令0x3484
    EN_OTA_RT_RECV_STOP_UPGRDE          = 40301,    // SDK接收到通知设备停止升级信令0x3486

    EN_OTA_RT_REPORT_RATE               = 40400,    // OTA升级上报进度
    
}EN_OTA_RT_TYPE;


//信令注册登录及自注册终端信息上报模块
typedef enum enum_REGISTINFO_RT_TYPE
{
    EN_REGISTINFO_RT_PARSE_ABLITYPLAT_ADDR_FAIL     = 70010,    // 解析能力域名地址失败
    EN_REGISTINFO_RT_CHECK_ABLITYPLAT_JOSN_FAIL     = 70011,    // 接收到能力平台的返回，但Json解析失败
    EN_REGISTINFO_RT_RECV_ABLITYPLAT_RSP_FAIL       = 70012,    // 获取信令服务器ip与端口号失败
    EN_REGISTINFO_RT_CHECK_ABLITYPLAT_PARAM_FAIL    = 70013,    // 接收到平台的返回，但返回的参数错误
    EN_REGISTINFO_RT_CHECK_ABLITYPLAT_HEART_TIMEOUT = 70014,    // 信令服务器心跳包3次超时
    EN_REGISTINFO_RT_CMDSERVER_ONLINE               = 70015,    // 信令服务器上线
    EN_REGISTINFO_RT_CMDSERVER_OFFLINE              = 70016,    // 信令服务器离线

    EN_REGISTINFO_RT_PARSE_SELFREGIST_ADDR_FAIL     = 70020,    // 解析自注册域名地址失败
    EN_REGISTINFO_RT_RECV_SELFREGIST_RSP_FAIL       = 70021,    // 自注册CTEI设备信息上报失败
    EN_REGISTINFO_RT_CHECK_SELFREGIST_JOSN_FAIL     = 70022,    // 接收到自注册平台的返回，但Json解析失败
    EN_REGISTINFO_RT_CHECK_SELFREGIST_PARAM_FAIL    = 70023,    // 接收到自注册平台的返回，但返回的参数错误

    EN_REGISTINFO_RT_PARSE_PDM_ADDR_FAIL            = 70030,    // 解析北京终端域名地址失败
    EN_REGISTINFO_RT_RECV_PDM_RSP_FAIL              = 70031,    // 北京终端CTEI设备信息上报失败
    EN_REGISTINFO_RT_CHECK_PDM_JOSN_FAIL            = 70032,    // 接收到北京终端平台的返回，但Json解析失败
    EN_REGISTINFO_RT_CHECK_PDM_PARAM_FAIL           = 70033,    // 接收到北京终端平台的返回，但返回的参数错误
    EN_REGISTINFO_RT_UPLOADINFO_PDM_SUC             = 70034,    // 北京终端CTEI设备信息上报成功


    EN_REGISTINFO_RT_PARSE_SRTHOME_ADDR_FAIL        = 70040,    // 解析南京智家域名地址失败
    EN_REGISTINFO_RT_RECV_SRTHOME_RSP_FAIL          = 70041,    // 南京智家CTEI设备信息上报失败
    EN_REGISTINFO_RT_CHECK_SRTHOME_JOSN_FAIL        = 70042,    // 接收到南京智家平台的返回，但Json解析失败
    EN_REGISTINFO_RT_CHECK_SRTHOME_PARAM_FAIL       = 70043,    // 接收到南京智家平台的返回，但返回的参数错误
    EN_REGISTINFO_RT_UPLOADINFO_SRTHOME_SUC         = 70044,    // 南京智家CTEI设备信息上报成功

    EN_REGISTINFO_RT_PARSE_GETOUTERIP_ADDR_FAIL     = 70050,    // 解析获取外网IP域名地址失败
    EN_REGISTINFO_RT_RECV_GETOUTERIP_RSP_FAIL       = 70051,    // 获取外网IP回复失败
    EN_REGISTINFO_RT_CHECK_GETOUTERIP_JOSN_FAIL     = 70052,    // 接收到获取外网IP平台的返回，但Json解析失败
    EN_REGISTINFO_RT_CHECK_GETOUTERIP_PARAM_FAIL    = 70053,    // 接收到获取外网IP平台的返回，但返回的参数错误
    EN_REGISTINFO_RT_GETOUTERIP_SUC                 = 70054,    // 获取外网IP成功 
    EN_REGISTINFO_RT_UPLOAD_GETOUTERIP_DATA         = 70055,    // 上报时间段内获取设备外网IP的统计数据 
}EN_REGISTINFO_RT_TYPE;

//云广播模块
typedef enum enum_BROADCAST_RT_TYPE
{
    EN_BROADCAST_RT_RECV_MSG                        = 90010,    // 接收到服务器下发的广播任务
    EN_BROADCAST_RT_NO_SUPPORT                      = 90011,    // 接收到下发的广播任务，但sdk不支持云广播功能
    EN_BROADCAST_RT_ABILITY_DISABLE                 = 90012,    // 接收到下发的广播任务，但sdk与广播能力值为0
    EN_BROADCAST_RT_CHECK_BODY_FAIL                 = 90013,    // 接收到下发的广播任务，但Json Body解析失败
    EN_BROADCAST_RT_CREATE_LIVE_TASK_FAIL           = 90014,    // 接收到下发的广播任务，但创建实时广播会话失败
    EN_BROADCAST_RT_CREATE_PLAYBACK_TASK_FAIL       = 90015,    // 接收到下发的广播任务，但创建定时广播会话失败
    EN_BROADCAST_RT_RECV_STATUS                     = 90016,    // 云广播sdk下发会话状态及当前状态展示
    
}EN_BROADCAST_RT_TYPE;

//质量探针模块
typedef enum enum_QUALITYPROBE_RT_TYPE
{
    EN_QUALITYPROBE_RT_START_UPLOAD_HOURINFO         = 100000,    // 开始质态小时数据上报
}EN_QUALITYPROBE_RT_TYPE;

// 流媒体模块
typedef enum enum_MULTIMEDIA_RT_TYPE
{
    EN_MULTIMEDIA_RT_SOCKET_POLL_ERROR          = 120100,       // 流媒体socket poll错误
    EN_MULTIMEDIA_RT_SOCKET_SEND_ERROR          = 120101,       // 流媒体socket send错误
    EN_MULTIMEDIA_RT_SOCKET_RECV_ERROR          = 120102,       // 流媒体socket recv错误
    EN_MULTIMEDIA_RT_SOCKET_CONNECT_ERROR       = 120103,       // 流媒体socket 连接错误
    EN_MULTIMEDIA_RT_SOCKET_TIMEOUT_ERROR       = 120104,       // 流媒体socket 超时错误
    EN_MULTIMEDIA_RT_UPDATE_ENCKEY_SUCCESS      = 120105,       // 流媒体更新秘钥
    EN_MULTIMEDIA_RT_BE_OCCUPY                  = 120106,       // 流媒体被抢占-直播

    EN_MULTIMEDIA_RT_LIVE_NTC_FAIL              = 120200,        // 流媒体直播分配失败
    EN_MULTIMEDIA_RT_LIVE_LOGIN_RSP_FAIL        = 120201,        // 流媒体直播登录失败
    EN_MULTIMEDIA_RT_LIVE_LOGIN_RSP_SUCCESS     = 120202,        // 流媒体直播登录成功
    EN_MULTIMEDIA_RT_LIVE_START_STREAM_FAIL     = 120203,        // 流媒体直播取流失败
    EN_MULTIMEDIA_RT_LIVE_START_STREAM_SUCCESS  = 120204,        // 流媒体直播取流成功
    EN_MULTIMEDIA_RT_LIVE_PAUSE_STREAM_SUCCESS  = 120205,        // 流媒体直播暂停
    EN_MULTIMEDIA_RT_LIVE_RESUME_STREAM_SUCCESS = 120206,        // 流媒体直播恢复
    EN_MULTIMEDIA_RT_LIVE_CLOSE_STREAM_SUCCESS  = 120207,        // 流媒体直播关闭
    EN_MULTIMEDIA_RT_LIVE_IDR_SUCCESS           = 120208,        // 流媒体直播强制I帧
    EN_MULTIMEDIA_RT_LIVE_VIDEOPARAM_CHANGE     = 120210,        // 流媒体直播视频参数修改 - 释放直播连接

    EN_MULTIMEDIA_RT_PLAYBACK_NTC_FAIL          = 120300,        // 流媒体卡回放分配失败      
    EN_MULTIMEDIA_RT_PLAYBACK_LOGIN_RSP_FAIL    = 120301,        // 流媒体卡回放登录失败
    EN_MULTIMEDIA_RT_PLAYBACK_SEEK_FAIL         = 120302,        // 流媒体卡回放跳转文件失败

    EN_MULTIMEDIA_RT_VOICE_TALK_OPEN_FAIL       = 120400,        // 流媒体语音对讲打开失败
    EN_MULTIMEDIA_RT_VOICE_TALK_OPEN_SUCCESS    = 120401,        // 流媒体语音对讲打开成功
    EN_MULTIMEDIA_RT_VOICE_TALK_CLOSE_SUCCESS   = 120402,        // 流媒体语音对讲打关闭成功
}EN_MULTIMEDIA_RT_TYPE;

// 卡录像模块
typedef enum enum_RECORD_RT_TYPE
{
    EN_RDSTG_RT_SAVE_MP4                  = 130100,    // 录像跨天或分辨率修改，新建录像文件成功

}EN_RECORD_RT_TYPE;

// 消息告警模块
typedef enum enum_ALARM_RT_TYPE
{
    EN_ALARM_RT_ALARM_QUEUE_FAIL          = 150100,    // 事件结点推送队列失败

    EN_ALARM_RT_POLICY_OUTPUT_FAIL        = 150200,    // 事件策略回调失败
    EN_ALARM_RT_ALARM_SET_PROP_FAIL       = 150201,    // 告警消息设置属性失败
    EN_ALARM_RT_GET_IPADDR_FAIL           = 150202,    // 获取平台地址失败
    EN_ALARM_RT_PRASE_JSON_NULL           = 150203,    // 平台返回json为空
    EN_ALARM_RT_WRONG_CODE                = 150204,    // 解析得到json code错误值
    EN_ALARM_RT_ALARM_REPORT_FAIL         = 150205,    // 告警消息上报失败
    EN_ALARM_RT_ALARM_HTTP_FAIL           = 150206,    // 告警消息返回http失败
    EN_ALARM_RT_TIME_ABS_TOO_LARGE        = 150207,    // 平台时间和设备时间相差太大

}EN_ALARM_RT_TYPE;

// 1400模块
typedef enum enum_GA1400_RT_TYPE
{
    // 1400抓拍事件触发
    EN_1400_RT_EVENT_MAXCOUNT_ERR                       = 210101,   // 1400抓拍图片缓存处于最大值(暂不支持)
    EN_1400_RT_EVENT_UPLOAD_NOW_ERR                     = 210102,   // 正在上传1400抓拍图片(暂不支持)
    EN_1400_RT_EVENT_NOREG_ERR                          = 210103,   // 未注册登录1400平台(暂不支持)

    // GA1400开关下发(信令34DE)
    EN_1400_RT_34DE_JSON_NULL_ERR                       = 210201,   // 下发GA1400开关信令的Json Body为空
    EN_1400_RT_34DE_DEV_SLEEP_NOW_ERR                   = 210202,   // 下发GA1400开关信令时设备休眠(镜头关闭)
    
    // 获取1400业务配置
    EN_1400_RT_GET1400INFO_URL_GET_HOST_ADDRINFO_ERR    = 210301,   // 1400平台的域名解析失败
    EN_1400_RT_GET1400INFO_PLAT_RSP_JSON_NULL_ERR       = 210302,   // 获取1400业务配置1400平台回复的Json为空
    EN_1400_RT_GET1400INFO_PLAT_RSP_CODE_NOT_0_ERR      = 210303,   // 获取1400业务配置1400平台回复的CODE不为0
    EN_1400_RT_GET1400INFO_PLAT_RSP_CFG_NULL_ERR        = 210304,   // 获取1400业务配置1400平台回复的Json的GAT1400Config内容为空
    EN_1400_RT_GET1400INFO_PLAT_RSP_UID_ERR             = 210305,   // 获取1400业务配置1400平台回复的Json的UID错误
    EN_1400_RT_GET1400INFO_PLAT_RSP_ERR                 = 210306,   // 接收1400平台回复的1400业务信息数据失败
    EN_1400_RT_GET1400INFO_SUCCESS                      = 210307,   // 获取1400业务配置成功

    // 向1400平台注册
    EN_1400_RT_1ST_REG_URL_CONNET_ERR                   = 210401,   // 创建第一次向1400平台注册的链接失败
    EN_1400_RT_1ST_REG_URL_READ_HEAD_ERR                = 210402,   // 第一次注册接收回复头失败
    EN_1400_RT_1ST_REG_URL_RT_NOT_401_REDIRECT_ERR      = 210403,   // 第一次注册平台回复的https code不为401重定向失败
    EN_1400_RT_2ND_REG_URL_CONNET_ERR                   = 210404,   // 创建第二次向1400平台注册的链接失败
    EN_1400_RT_2ND_REG_URL_READ_HEAD_ERR                = 210405,   // 第二次注册接收回复头失败
    EN_1400_RT_2ND_REG_URL_RT_JSON_NULL_ERR             = 210406,   // 第二次注册接收回复回复json为空
    EN_1400_RT_2ND_REG_URL_RT_NOT_200_ERR               = 210407,   // 第二次注册平台回复的https code不为200
    EN_1400_RT_2ND_REG_URL_RT_STATUSCODE_NOT_0_ERR      = 210408,   // 第二次注册平台回复的内容StatusCode字段不为0
    EN_1400_RT_REGISTER_SUCCESS                         = 210409,   // 向1400平台注册成功
    EN_1400_RT_REG_FUNC1400STATUS_DEV_RT_ERR            = 210410,   // 调用通知1400在线状态的回调函数pFunSetGa1400StatusCb失败

    // 向1400平台保活
    EN_1400_RT_KEEPALIVE_URL_CONNET_ERR                 = 210501,   // 创建向1400平台保活的链接失败
    EN_1400_RT_KEEPALIVE_URL_READ_HEAD_ERR              = 210502,   // 向1400平台保活接收回复头失败
    EN_1400_RT_KEEPALIVE_URL_RT_JSON_NULL_ERR           = 210503,   // 向1400平台保活回复的Json为空
    EN_1400_RT_KEEPALIVE_URL_RT_NOT_200_ERR             = 210504,   // 向1400平台保活回复的https code不为200
    EN_1400_RT_KEEPALIVE_URL_RT_STATUSCODE_NOT_0_ERR    = 210505,   // 向1400平台保活回复的内容StatusCode字段不为0
    EN_1400_RT_KEEPALIVE_SUCCESS                        = 210506,   // 向1400平台保活成功(暂不支持)
    
    // 向1400平台注销
    EN_1400_RT_UNREG_URL_CONNET_ERR                     = 210601,   // 创建向1400平台注销的链接失败(暂不支持)
    EN_1400_RT_UNREG_URL_READ_HEAD_ERR                  = 210602,   // 向1400平台注销接收回复头失败(暂不支持)
    EN_1400_RT_UNREG_URL_RT_JSON_NULL_ERR               = 210603,   // 向1400平台注销回复的Json为空(暂不支持)
    EN_1400_RT_UNREG_URL_RT_NOT_200_ERR                 = 210604,   // 向1400平台注销回复的https code不为200(暂不支持)
    EN_1400_RT_UNREG_URL_RT_STATUSCODE_NOT_0_ERR        = 210605,   // 向1400平台注销回复的内容StatusCode字段不为0(暂不支持)
    EN_1400_RT_UNREGISTER_SUCCESS                       = 210606,   // 向1400平台注销成功(暂不支持)

    // 上传1400 抓拍图片到1400平台
    EN_1400_RT_UPLOAD_PIC_EVENTID_ERR                   = 210701,   // 抓拍图片的类型并非人脸抓拍或车牌抓拍(暂不支持)
    EN_1400_RT_UPLOAD_PIC_DATA_NULL_ERR                 = 210702,   // 厂商提供的人脸或车牌数据节点为空(暂不支持)
    EN_1400_RT_UPLOAD_PIC_URL_CONNET_ERR                = 210703,   // 创建上传1400 抓拍图片到1400平台的链接失败(暂不支持)
    EN_1400_RT_UPLOAD_PIC_URL_READ_HEAD_ERR             = 210704,   // 上传1400 抓拍图片到1400平台接收回复头失败(暂不支持)
    EN_1400_RT_UPLOAD_PIC_URL_RT_JSON_NULL_ERR          = 210705,   // 上传1400 抓拍图片到1400平台回复的Json为空(暂不支持)
    EN_1400_RT_UPLOAD_PIC_URL_RT_NOT_200_ERR            = 210706,   // 上传1400 抓拍图片到1400平台回复的https code不为200(暂不支持)
    EN_1400_RT_UPLOAD_PIC_URL_RT_STATUSCODE_NOT_0_ERR   = 210707,   // 上传1400 抓拍图片到1400平台回复的内容StatusCode字段不为0(暂不支持)
    EN_1400_RT_UPLOAD_PIC_SUCCESS                       = 210708,   // 上传1400 抓拍图片到1400平台成功(暂不支持)
    EN_1400_RT_UPLOAD_PIC_FUNCFREECACHE_DEV_RT_ERR      = 210709,   // 调用释放1400抓拍图片缓存的回调函数失败pFunFreeAiPicCache失败(暂不支持)   
}EN_GA1400_RT_TYPE;

// AI模块
typedef enum enum_AI_RT_TYPE
{
    // 下发布控图片下载信息(信令4420)
    EN_AI_RT_4420_JSON_NULL_ERR                         = 220001,   // 下发布控图片下载信息信令的Json Body为空
    EN_AI_RT_4420_DEV_SLEEP_NOW_ERR                     = 220002,   // 下发布控图片下载信息信令时设备休眠(镜头关闭)
    EN_AI_RT_4420_FUNCCREATELABEL_DEV_RT_ERR            = 220003,   // 调用创建lableID回调函数pFunCreateLabel失败
    EN_AI_RT_4420_NOT_CREATE_LABELID_ERR                = 220004,   // 没有创建lableID
    EN_AI_RT_4420_REPEAT_DISPOSITIONID_ERR              = 220005,   // 布控ID重复

    // 人脸布控图片下载
    EN_AI_RT_DOWNPIC_CREATE_THREAD_ERR                  = 220101,   // 人脸布控图片下载线程创建失败
    EN_AI_RT_DOWNPIC_URL_NULL_ERR                       = 220102,   // 下载布控图片的url为空
    EN_AI_RT_DOWNPIC_URL_RECOGNIZE_ERR                  = 220103,   // 下载布控图片的url识别失败
    EN_AI_RT_DOWNPIC_URL_FORMAT_ERR                     = 220104,   // 下载布控图片的url格式错误               /*已废弃，请求失败会有url打印*/
    EN_AI_RT_DOWNPIC_URL_GET_HOST_ADDRINFO_ERR          = 220105,   // 下载布控图片的url域名解析失败
    EN_AI_RT_DOWNPIC_URL_CONNET_ERR                     = 220106,   // 下载布控图片的url创建连接失败
    EN_AI_RT_DOWNPIC_URL_READ_HEAD_ERR                  = 220107,   // 下载布控图片的接收url协议头失败
    EN_AI_RT_DOWNPIC_URL_RT_NOT_302_REDIRECT_ERR        = 220108,   // 下载布控图片的接收302重定向url失败
    EN_AI_RT_DOWNPIC_REDIRECT_URL_CONNET_ERR            = 220109,   // 下载布控图片的重定向url创建连接失败
    EN_AI_RT_DOWNPIC_REDIRECT_URL_READ_HEAD_ERR         = 220110,   // 下载布控图片的接收重定向url协议头失败     /*已废弃，与220111重复*/
    EN_AI_RT_DOWNPIC_REDIRECT_URL_RT_NOT_200_ERR        = 220111,   // 下载布控图片的接收重定向url回复状态非200
    EN_AI_RT_DOWNPIC_URL_RECV_PIC_DATA_ERR              = 220112,   // 接收下载的布控图片数据失败               /*已废弃*/
    EN_AI_RT_DOWNPIC_SAVE_PIC_DATA_ERR                  = 220113,   // 存储下载的布控图片数据到指定文件失败  
    EN_AI_RT_DOWNPIC_FUNCADDSINGLEAIPIC_DEV_RT_ERR      = 220114,   // 调用读取AI图片并提取特征值的回调函数pFunAddSingleAiPic失败
    EN_AI_RT_DOWNPIC_FUNCADDSINGLEAIPIC_DEV_RT_OK       = 220115,   // 调用读取AI图片并提取特征值的回调函数成功，布控人脸图片成功

    // 删除人脸布控图片失败(信令4424)
    EN_AI_RT_4424_JSON_NULL_ERR                         = 220201,   // 下发删除人脸布控图片信令的Json Body为空
    EN_AI_RT_4424_DEV_SLEEP_NOW_ERR                     = 220202,   // 下发删除人脸布控图片信令时设备休眠(镜头关闭)
    EN_AI_RT_4424_FUNCDELSINGLEAIPIC_DEV_RT_ERR         = 220203,   // 调用删除布控图片的回调函数pFunDelSingleAiPic失败
    EN_AI_RT_4424_FUNCDELSINGLEAIPIC_DEV_RT_OK          = 220204,   // 调用删除布控图片的回调函数成功，删除布控人脸图片成功

    // 上传布控图片失败(351C)
    EN_AI_RT_UPLOAD_FACEREC_MAXCOUNT_ERR                = 220301,   // 布控图片缓存处于最大值(暂不支持)
    EN_AI_RT_UPLOAD_FACEREC_URL_GET_HOST_ADDRINFO_ERR   = 220302,   // 上传人脸布控消息的域名解析失败
    EN_AI_RT_UPLOAD_FACEREC_PLAT_RSP_ERR                = 220303,   // 上传人脸布控消息接收平台回复超时失败
    EN_AI_RT_UPLOAD_FACEREC_PLAT_RSP_JSON_NULL_ERR      = 220304,   // 上传人脸布控消息接收平台回复json为空
    EN_AI_RT_UPLOAD_FACEREC_PLAT_RSP_CODE_NOT_0_ERR     = 220305,   // 上传人脸布控消息接收平台回复CODE不为0
    EN_AI_RT_UPLOAD_FACEREC_PLAT_RSP_UID_ERR            = 220306,   // 上传人脸布控消息接收平台回复UID错误
    EN_AI_RT_UPLOAD_FACEREC_CREATE_THREAD_ERR           = 220307,   // 上传布控图片线程创建失败
    EN_AI_RT_UPLOAD_FACEREC_SEND_DATA_ERR               = 220308,   // 发送布控图片数据失败(暂不支持)
    EN_AI_RT_UPLOAD_FACEREC_FUNCFREECACHE_DEV_RT_ERR    = 220309,   // 调用清除AI图片数据缓存的回调函数pFunFreeAiPicCache失败

    // 上传车牌/人脸抓拍图片ZIP包失败(3522)
    EN_AI_RT_UPLOAD_ZIP_MAXCOUNT_ERR                    = 220401,   // 上传车牌/人脸抓拍图片ZIP包缓存处于最大值(暂不支持)
    EN_AI_RT_UPLOAD_ZIP_URL_GET_HOST_ADDRINFO_ERR       = 220402,   // 上传车牌/人脸抓拍图片ZIP包消息的域名解析失败
    EN_AI_RT_UPLOAD_ZIP_PLAT_RSP_ERR                    = 220403,   // 上传车牌/人脸抓拍图片ZIP包消息接收平台回复超时失败
    EN_AI_RT_UPLOAD_ZIP_PLAT_RSP_JSON_NULL_ERR          = 220404,   // 上传车牌/人脸抓拍图片ZIP包消息接收平台回复json为空
    EN_AI_RT_UPLOAD_ZIP_PLAT_RSP_CODE_NOT_0_ERR         = 220405,   // 上传车牌/人脸抓拍图片ZIP包消息接收平台回复CODE不为0
    EN_AI_RT_UPLOAD_ZIP_PLAT_RSP_UID_ERR                = 220406,   // 上传车牌/人脸抓拍图片ZIP包消息接收平台回复UID错误
    EN_AI_RT_UPLOAD_ZIP_CREATE_THREAD_ERR               = 220407,   // 上传车牌/人脸抓拍图片ZIP包线程创建失败
    EN_AI_RT_UPLOAD_ZIP_OPEN_FILE_ERR                   = 220408,   // 打开ZIP包文件失败(暂不支持)
    EN_AI_RT_UPLOAD_ZIP_READ_FILE_ERR                   = 220409,   // 读取ZIP包数据失败(暂不支持)
    EN_AI_RT_UPLOAD_ZIP_SEND_DATA_ERR                   = 220410,   // 发送ZIP包数据失败(暂不支持)

    // 客流统计参数失败(信令34D4)
    EN_AI_RT_34D4_JSON_NULL_ERR                         = 220501,   // 下发客流统计参数信令的Json Body为空
    EN_AI_RT_34D4_DEV_SLEEP_NOW_ERR                     = 220502,   // 下发客流统计参数信令时设备休眠(镜头关闭)
    EN_AI_RT_34D4_FUNCHUMCOUNTPARAM_DEV_RT_ERR          = 220503,   // 调用客流统计参数回调函数 pfunSetHumCountParam失败
    // 客流统计区域失败(信令34D2)
    EN_AI_RT_34D2_JSON_NULL_ERR                         = 220504,   // 下发客流统计区域信令的Json Body为空
    EN_AI_RT_34D2_DEV_SLEEP_NOW_ERR                     = 220505,   // 下发客流统计区域信令时设备休眠(镜头关闭)
    EN_AI_RT_34D2_FUNCHUMCOUNTREGIONS_DEV_RT_ERR        = 220506,   // 调用客流统计区域回调函数pfunSetHumCountRegions失败
    // 上报客流统计数据失败(3520)
    EN_AI_RT_UPLOAD_HUMCOUNT_URL_GET_HOST_ADDRINFO_ERR  = 220507,   // 上传客流统计数据消息解析告警域名地址失败
    EN_AI_RT_UPLOAD_HUMCOUNT_PLAT_RSP_ERR               = 220508,   // 上传客流统计数据消息接收平台回复超时失败
    EN_AI_RT_UPLOAD_HUMCOUNT_PLAT_RSP_JSON_NULL_ERR     = 220509,   // 上传客流统计数据消息接收平台回复json为空
    EN_AI_RT_UPLOAD_HUMCOUNT_PLAT_RSP_CODE_NOT_0_ERR    = 220510,   // 上传客流统计数据消息接收平台回复CODE不为0
}EN_AI_RT_TYPE;

// 文件下载模块
typedef enum enum_DOWNFILE_RT_TYPE
{
    EN_DOWNFILE_RT_START_TASK_SUCCEESS      = 240000,
    EN_DOWNFILE_RT_START_TASK_FAIL          = 240001,
    EN_DOWNFILE_RT_START_THREAD_FAIL        = 240002,
    EN_DOWNFILE_RT_NOTIFY_STATUS_FAIL       = 240003,
    EN_DOWNFILE_RT_NOTIFY_STATUS_SUCCESS    = 240004,

    // EN_DOWNFILE_RT_HTTP_URL_FAIL            = 240100,
    // EN_DOWNFILE_RT_HTTP_CONNECT_SERVER_FAIL = 240101,
    // EN_DOWNFILE_RT_HTTP_SEND_REQUEST_FAIL   = 240102,
    // EN_DOWNFILE_RT_HTTP_RECV_HEADER_FAIL    = 240103,
    // EN_DOWNFILE_RT_HTTP_RECV_BODY_FAIL      = 240104,
    // EN_DOWNFILE_RT_HTTP_TIMEOUT_ERROR       = 240105,
    // EN_DOWNFILE_RT_HTTP_DOWNDATANTC_ERROR   = 240106,
    // EN_DOWNFILE_RT_HTTP_DOWNDATATRANS_ERROR = 240107,
    // 文件下载http接口错误码
    EN_DOWNFILE_RT_HTTP_REQUEST_FAIL        = 240108,
}EN_DOWNFILE_RT_TYPE;

// 关键接口质量统计模块
typedef enum enum_QUALITY_STA_RT_TYPE
{
    EN_QUALITY_STA_RT_SMART_HOME            = 250000, // 终端信息上报北京终端平台接口质量
    EN_QUALITY_STA_RT_PDM                   = 250001, // 终端信息上报至南京智家平台接口质量
    EN_QUALITY_STA_RT_SELF_REGISTER         = 250002, // 设备自注册接口质量
    EN_QUALITY_STA_RT_GET_ROUTE             = 250003, // 单元化调度接口质量
    EN_QUALITY_STA_RT_ABLITY_PLAT_REGIST    = 250004, // 设备到信令服务注册接口质量
    EN_QUALITY_STA_RT_CLOUD_VIDEO_COMMIT    = 250005, // 提交创建直传文件接口质量
    EN_QUALITY_STA_RT_CLOUD_GETURL          = 250006, // 获取一次性直传地址接口质量
    EN_QUALITY_STA_RT_CLOUD_GETENCURL       = 250007, // 获取一次性直传地址（加密）接口质量
    EN_QUALITY_STA_RT_CLOUD_GET_CINFO       = 250008, // 获取云存开通信息接口质量

}EN_QUALITY_STA_RT_TYPE;
// 设备状态码
typedef enum enum_DEVICE_RT_TYPE
{
    EN_DEVICE_RT_GOTO_SLEEP                  = 990201,    // 设备进入休眠状态
    EN_DEVICE_RT_GOTO_AWAKE                  = 990202,    // 设备进入唤醒状态
}EN_DEVICE_RT_TYPE;


#ifdef __cplusplus
}
#endif

#endif// CLOUDSTG_LOG_CODE_H
