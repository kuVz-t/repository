#ifndef CLOUDSTG_CONFIG_H
#define CLOUDSTG_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"

typedef struct stru_CLOUDSTG_CONFIG
{
    /*****************事件云存追加********************/
    _INT iEventCloudSwitch;     // 事件云存追加开关
    _INT iEventCloudMaxTime;    // 事件云存最大秒数
    _INT iEventCloudMinTime;    // 事件云存最小秒数
    _INT iEventCloudDetectTime; // 事件云存检测秒数
    _INT iEventCloudAppendTime; // 事件云存追加录制秒数
    // TODO:
    /*****************XXXXXXXXXXX********************/
}ST_CLOUDSTG_CONFIG;

// 获取云存配置变量句柄
ST_CLOUDSTG_CONFIG *CloudStg_GetConfig();

// 设置事件云存追加开关
_INT CloudStg_SetEventCloudSwitch(_INT iEventCloudSwitch);

// 设置事件云存最大秒数
_INT CloudStg_SetEventCloudMaxTime(_INT iEventCloudMaxTime);

// 设置事件云存最小秒数
_INT CloudStg_SetEventCloudMinTime(_INT iEventCloudMinTime);

// 设置事件云存检测秒数
_INT CloudStg_SetEventCloudDetectTime(_INT iEventCloudDetectTime);

// 设置事件云存追加录制秒数
_INT CloudStg_SetEventCloudAppendTime(_INT iEventCloudAppendTime);

#ifdef __cplusplus
}
#endif
#endif