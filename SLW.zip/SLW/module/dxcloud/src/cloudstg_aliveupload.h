#ifndef CLOUDSTG_ALIVEUPLOAD_H
#define CLOUDSTG_ALIVEUPLOAD_H


#ifdef __cplusplus
extern "C"
{
#endif


// 打开云存任务
ST_CLOUDSTG_TASK_NODE *CloudStg_OpenAliveTask(_INT iCamId,_INT iStreamId,_INT iStoreType,_CTIME_T tCreatTime,_UI uiDuration);

// 云存任务主程序
_INT  CloudStg_AliveUploadProc(ST_CLOUDSTG_TASK_NODE *pstTaskNode);

// 停止云存任务
_VOID CloudStg_StopAliveTask(_UI uiCamId,_UI iStreamId);

// 删除云存节点
_INT CloudStg_DestroyAliveNode(ST_CLOUDSTG_TASK_NODE *pstMediaTaskNode);

// 获取云存加密信息(多线程调用)
_INT CloudStg_GetCloudEncInfo(ST_CLOUDSTG_TASK_NODE *pstTaskNode);

// 寻找指定的云存节点(多线程调用)
ST_CLOUDSTG_TASK_NODE *CloudStg_FindTaskNode(_UI uiIsPatch, _UI uiTaskId);

// 获取指定云存节点的state
_INT CloudStg_GetTaskNodeState(_UI uiIsPatch, _UI uiTaskId);

// 云存上传回调,通知成功或失败(多线程调用)
_INT CloudStg_AliveSliceStatusCallBack(_VPTR vpBase,_UI uiStatus,_UC *pucFid,_UC *pucETag,_UI uiTargetSize,_UC *pucBucket,_UC *pucStorageProvider);

// 发送第一帧
_INT CloudStg_SendFirstFrame(ST_CLOUDSTG_TASK_NODE *pstTaskNode);

// 云存节点状态检查：增加视频时间戳、判断视频时间戳是否到达指定的时间
_INT CloudStg_ProcAliveTaskStatus(ST_CLOUDSTG_TASK_NODE *pstTaskNode,_UI uiTimeStamp,_UI uibKeyFrame,_UI uiAvType, _UI uiIsPatch);

// 通知发送模块发送视频流
_VOID CloudStg_NotifyExChanToSend(_HSTREAM pstStreamTemp);

// 判断是否需要补录
_INT CloudStg_TaskIsNeedPatch(_CTIME_T cCreateTime);

// 记录端切片切片发送成功次数
_INT CloudStg_TaskAddOneExSentCount(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch);
_INT CloudStg_TaskGetExSentCount(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch);

// 记录端切片最后一包的时长
_INT CloudStg_TaskSetExLastSentInterval(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch, _INT iInterval);
_INT CloudStg_TaskGetExLastSentInterval(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch);

// 获取端切片速率
_INT CloudStg_TaskGetExSentSpeed(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch);

// 获取移动侦测状态
_INT CloudStg_TaskGetEventType(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch);

// 总共发送次数加1
_INT CloudStg_TotalSentCountAddOne(_UI uiIsPatch, _INT iCamId, _UI uiTaskId);

// 总共重传次数加1
_INT CloudStg_RetrySentCountAddOne(_UI uiIsPatch, _INT iCamId, _UI uiTaskId);

// 重传率计算
_INT CloudStg_RetrySentRateCheck(_UI uiIsPatch, _INT iCamId, _UI uiTaskId);

// Nalu验证
_INT CloudStg_NaluVaild(_C *buf);

// 强制commit所有任务（休眠前使用）
_INT CloudStg_CommitAllTask();

// 强制commit所有任务（重启前使用）
_INT CloudStg_CommitAllTaskBeforeReboot();

// 检测是否所有任务都commit（重启前使用）
_INT CloudStg_CheckAllTaskBeforeReboot();

// 通过taskid强制commit
_INT CloudStg_ForceCommitWithTaskId(_UI uiTaskId);

// 检测是否需要强制commit
_INT CloudStg_DetectForceCommit(ST_CLOUDSTG_TASK_NODE *pstTaskNode, _UI uiIsPatch);

#ifdef __cplusplus
}
#endif

#endif