#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_json_adapt.h"
#include "config_type.h"
#include "config_api.h"
#include "config_system.h"
#include "media_cache_api.h"
#include "record_api.h"
#include "http_api.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_stream_prv.h"
#include "cloudstg_manage.h"
#include "cloudstg_patch.h"
#include "mpeg_ps.h"
#include "stdio.h"

#define CLOUDSTG_STREAM_PRV_INDEX_TYPE    0x1
#define CLOUDSTG_STREAM_PRV_AUDIODES_TYPE 0x2
#define CLOUDSTG_STREAM_PRV_VIDEODES_TYPE 0x4
#define USE_SMALL_PACKET_SLICE 1

static _INT CloudStg_StreamBuildSlicenceInf(ST_CLOUDSTG_STREAM *pstStream);
static _UI CloudStg_GetStreamSliceSize(_UI uiBiteRate,_UI uiDuration)
{   
    _UI uiSliceSize = 0;
    switch(uiBiteRate)
    {
        case 0:
            {
                uiBiteRate = 512 * 1024;
                break;
            }
        case 1:
            break;
            {
                uiBiteRate = 96 * 1024;
                break;
            }
        case 2:
            {
                uiBiteRate = 128 * 1024;
                break;
            }
        case 3:
            {
                uiBiteRate = 196 * 1024;
                break;
            }
        case 4:
            {
                uiBiteRate = 256 * 1024;
                break;
            }
        case 5:
            {
                uiBiteRate = 384 * 1024;
                break;
            }
        case 6:
            {
                uiBiteRate = 512 * 1024;
                break;
            }
        case 7:
            {
                uiBiteRate = 768 * 1024;
                break;
            }
        case 8:
            {
                uiBiteRate = 1024 * 1024;
                break;
            }
        case 9:
            {
                uiBiteRate = 1536 * 1024;
                break;
            }
        case 10:
            {
                uiBiteRate = 2048 * 1024;
                break;
            }
        case 11:
            {
                uiBiteRate = 2560 * 1024;
                break;
            }
        case 12:
            {
                uiBiteRate = 3072 * 1024;
                break;
            }
        case 13:
            {
                uiBiteRate = 4096 * 1024;
                break;
            }
        default:
            {
                uiBiteRate = 128 * 1024;
            }
    }
    uiSliceSize = uiBiteRate * uiDuration / 8;
    return uiSliceSize;
}

_HSTREAM CloudStg_StreamOpen(_INT iCamId,_INT iAliveTaskId,_UI uiType,_UI uiBiteRate,_UI uiDuration,PFUN_SLICECALLBACK pFunUriAdd,_VPTR ptUseHandle, _UC ucIsPatch, _INT iCloudEncSwitch, _INT iDirectMode)
{
	_INT i = 0, j = 0;
    _HCSCONN hCSConn              = MOS_NULL; 
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)Mos_MemAlloc(MOS_NULL,sizeof(ST_CLOUDSTG_STREAM));
    if(pstStream == MOS_NULL)
    {
        return MOS_NULL;
    }

    // 设置流参数
    pstStream->uiVDuration      = 0;
    pstStream->uiATimeStamp     = 0;
    pstStream->uiADuration      = 0;
    pstStream->uiVTimeStamp     = 0;
    pstStream->uiStreamInfoLen  = 0;
    pstStream->iFirstFrame      = 1;
    pstStream->uiLITimeStamp    = 0;
    pstStream->uiICount         = 0;
    pstStream->uiIPos           = 0;
    pstStream->uiSliceLen       = CloudStg_GetStreamSliceSize(uiBiteRate,uiDuration);
    if (ucIsPatch && CloudStg_Patch_GetMng()->iLimitBandWidth == 0)
    {
       CloudStg_Patch_GetMng()->iLimitBandWidth    = pstStream->uiSliceLen / uiDuration / 1024 * 2;
       CloudStg_Patch_GetMng()->iLimitBandWidth    = CloudStg_Patch_GetMng()->iLimitBandWidth<10?10:CloudStg_Patch_GetMng()->iLimitBandWidth;
       CloudStg_Patch_GetMng()->iLimitBandWidthBak = CloudStg_Patch_GetMng()->iLimitBandWidth;
       MOS_LOG_WARN(CLOUDSTG_LOGSTR, "LimitBandWidth is set to %d", CloudStg_Patch_GetMng()->iLimitBandWidth);
    }
    pstStream->uiType           = uiType;
    pstStream->iCamId           = iCamId;
    pstStream->uiFirstSendFlag  = 0;
    pstStream->iDirectMode      = iDirectMode;
    pstStream->iExSentCount     = 0;
    pstStream->uiBiteRate       = uiBiteRate;
	Mos_MutexCreate(&pstStream->hMutex);
	Mos_MutexCreate(&pstStream->hTaskGroupMutex);
	Mos_MutexCreate(&pstStream->hTaskCurPosMutex);
    pstStream->iCloudEncSwitch  = iCloudEncSwitch;
    pstStream->iAliveTaskId     = iAliveTaskId;
    pstStream->iDropGopNum      = 0;
    pstStream->iDropGopFlag     = MOS_FALSE;
    pstStream->iExTransTaskReleaseCount = 0;

    Mos_MutexLock(&pstStream->hTaskGroupMutex);
    pstStream->hCSTask = CloudStg_TransTaskOpen(pstStream,iCamId,iAliveTaskId,uiType,pstStream->uiSliceLen,pFunUriAdd,ptUseHandle, ucIsPatch,iCloudEncSwitch,0,&hCSConn,pstStream->iDirectMode);
    Mos_MutexUnLock(&pstStream->hTaskGroupMutex);
    if(pstStream && pstStream->hCSTask == MOS_NULL)
    {
        Mos_MutexDelete(&pstStream->hMutex);
        Mos_MutexDelete(&pstStream->hTaskGroupMutex);
        Mos_MutexDelete(&pstStream->hTaskCurPosMutex);
        Mos_MemFree(pstStream);
        return MOS_NULL;
    }

    pstStream->stPacketData.aucPacket[0] = '$';
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"open stream %p,cam:%d,bitrate :%u,duration:%u,SliceLen %u,directmode %u",
        pstStream,iCamId,uiBiteRate,uiDuration,pstStream->uiSliceLen, pstStream->iDirectMode);
    return (_HSTREAM)pstStream;
}

_VOID CloudStg_StreamClose(_HSTREAM hStream)
{
    MOS_PARAM_NULL_NORET(hStream);
    _INT i = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FRAME_SEQ *pstFrameSeq = MOS_NULL;
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;
    
    FOR_EACHDATA_INLIST(&pstStream->stFrameSeqList, pstFrameSeq, stIterator)
    {
        MOS_LIST_RMVNODE(&pstStream->stFrameSeqList,pstFrameSeq);
        Mos_MemFree(pstFrameSeq);
    }
    if (pstStream->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstStream->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
    {
        Mos_MutexLock(&pstStream->hTaskGroupMutex);
        CloudStg_TransTaskCloseAsync(pstStream->hCSTask);
        Mos_MutexUnLock(&pstStream->hTaskGroupMutex);
    }
	MOS_LOG_INF(CLOUDSTG_LOGSTR,"close open stream %p",pstStream);
	Mos_MutexDelete(&pstStream->hMutex);
    Mos_MutexDelete(&pstStream->hTaskGroupMutex);
	Mos_MutexDelete(&pstStream->hTaskCurPosMutex);
    Mos_MemFree(pstStream);
    return;
}

_UI CloudStg_StreamGetSlicelen(_HSTREAM hStream)
{
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;
    if(hStream == MOS_NULL)
    {
        return 0;
    }
    return pstStream->uiSliceLen;
}
_UI CloudStg_StreamGetBufListCacheNodeCount(_HSTREAM hStream)
{
    _INT i    = 0;
    _INT iSum = 0;
    _INT iRet = 0;
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;
    if(hStream == MOS_NULL)
    {
        return 0;
    }

    Mos_MutexLock(&pstStream->hTaskGroupMutex);
    iRet = CloudStg_TransTaskGetCacheNodeCount(pstStream->hCSTask);
    Mos_MutexUnLock(&pstStream->hTaskGroupMutex);
    return iRet;
}

_INT CloudStg_StreamSetPara(_HSTREAM hStream,ST_CFG_VIDEODES *pstVideoDes,ST_ZJ_AUDIO_PARAM *pstAudioParm)
{
    MOS_PARAM_NULL_RETERR(pstVideoDes);
    MOS_PARAM_NULL_RETERR(pstAudioParm);

    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;
    if(hStream == MOS_NULL)
    {
        return 0;
    }
    MOS_MEMCPY(&pstStream->stAudioParm,pstAudioParm, sizeof(ST_ZJ_AUDIO_PARAM));
    MOS_MEMCPY(&pstStream->stVideoDes,pstVideoDes,sizeof(ST_CFG_VIDEODES));
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"width :%u,height :%u,videotype :%u,audiotype :%u",
        pstVideoDes->stVideoPara.uiWidth,pstVideoDes->stVideoPara.uiHeight,pstVideoDes->stVideoPara.uiEncodeType,pstAudioParm->uiEncodeType);
    return MOS_OK;
}


static _INT CloudStg_StreamSendOnePacket(ST_CLOUDSTG_STREAM *pstStream,_UC* pucHead,_UI uiHeadLen,
                                       _UC* pucData,_UI uiDataLen,_UI uiTimeStamp,_BOOL bIsVideo,_INT iCloudEncSwitch, _UC *aucCloudEncAesKey, _UC *aucCloudEncAesIv)
{
    MOS_PARAM_NULL_RETERR(pstStream);
    MOS_PARAM_NULL_RETERR(pucHead);
    // MOS_PARAM_NULL_RETERR(pucData);
    _INT iNeedEncFlag = 0;

    Mos_MutexLock(&pstStream->hTaskGroupMutex);
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)pstStream->hCSTask;
    Mos_MutexUnLock(&pstStream->hTaskGroupMutex);

    // 是否超过
    if(CloudStg_StreamSliceLenExceed((_HSTREAM)pstStream,uiHeadLen + uiDataLen))
    {
        if(pstTask)
        {
            ST_MECS_CONN *pstConn = (ST_MECS_CONN *)pstTask->hCSConn;
            if(pstConn && pstConn->pstConnUrl && pstConn->pstConnUrl->iStorageType != 2)
            {
                // 发送最后一包
                CloudStg_StreamSendLastData((_HSTREAM)pstStream);
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud slice end");
            }
        }
    }

    if(pstStream->uiCurSliceSendLen == 0)
    {
        pstStream->uiSliceStartStamp = uiTimeStamp;
        pstStream->uiSliceEndStamp   = uiTimeStamp;
    }

    if(uiTimeStamp > pstStream->uiSliceEndStamp)
    {
        pstStream->uiSliceEndStamp = uiTimeStamp;
    }

    // 音频
    if (!bIsVideo)
    {
        uiTimeStamp = 0;
    }

    // 添加到待发链表中
    if(uiHeadLen > 0)
    {
#if USE_SMALL_PACKET_SLICE
        _INT iHeadLenTmp = uiHeadLen;
        while(iHeadLenTmp > CLOUDSTG_BUF_UNIT_SIZE - 8)
        {
            if (iNeedEncFlag == 0)
            {
                iNeedEncFlag = 1;
                CloudStg_TransTaskAddBuf(pstTask, EN_CLOUDSTG_TRANS_BUF_SLICEDATA,pucHead+uiHeadLen-iHeadLenTmp,CLOUDSTG_BUF_UNIT_SIZE - 8,uiTimeStamp,iCloudEncSwitch,aucCloudEncAesKey,aucCloudEncAesIv);
            }
            else
            {
                CloudStg_TransTaskAddBuf(pstTask, EN_CLOUDSTG_TRANS_BUF_SLICEDATA,pucHead+uiHeadLen-iHeadLenTmp,CLOUDSTG_BUF_UNIT_SIZE - 8,uiTimeStamp,0,MOS_NULL,MOS_NULL);
            }
            iHeadLenTmp -= CLOUDSTG_BUF_UNIT_SIZE - 8;
        }
        if(iHeadLenTmp > 0)
        {
            if (iNeedEncFlag == 0)
            {
                iNeedEncFlag = 1;
                CloudStg_TransTaskAddBuf(pstTask, EN_CLOUDSTG_TRANS_BUF_SLICEDATA,pucHead+uiHeadLen-iHeadLenTmp,iHeadLenTmp,uiTimeStamp,iCloudEncSwitch,aucCloudEncAesKey,aucCloudEncAesIv);
            }
            else
            {
                CloudStg_TransTaskAddBuf(pstTask, EN_CLOUDSTG_TRANS_BUF_SLICEDATA,pucHead+uiHeadLen-iHeadLenTmp,iHeadLenTmp,uiTimeStamp,0,MOS_NULL,MOS_NULL);
            }
        }
#else
        CloudStg_TransTaskAddBuf(pstTask,EN_CLOUDSTG_TRANS_BUF_SLICEDATA,pucHead, uiHeadLen,uiTimeStamp,iCloudEncSwitch,aucCloudEncAesKey,aucCloudEncAesIv);
#endif
    }
    if(uiDataLen > 0)
    {
        CloudStg_TransTaskAddBuf(pstTask,EN_CLOUDSTG_TRANS_BUF_SLICEDATA,pucData, uiDataLen,uiTimeStamp,iCloudEncSwitch,aucCloudEncAesKey,aucCloudEncAesIv);
    }
    pstStream->uiCurSliceSendLen += uiHeadLen+uiDataLen;
    pstStream->uiTotalSendLen    += uiHeadLen+uiDataLen;
    return MOS_OK;
}

_INT CloudStg_StreamSendPrvHead(ST_CLOUDSTG_STREAM *pstStream, _INT iCloudEncSwitch)
{
    MOS_PARAM_NULL_RETERR(pstStream);

    _US usAVDesLen, usTemp;
    _US usType = CLOUDSTG_STREAM_PRV_VIDEODES_TYPE;
    pstStream->stPacketData.aucPacket[0] = 0;
    pstStream->stPacketData.aucPacket[1] = 0;
    pstStream->stPacketData.aucPacket[2] = 1;
    pstStream->stPacketData.aucPacket[3] = 0xBE;
    pstStream->uiStreamInfoLen += 8;


    usAVDesLen = MOS_VSNPRINTF(pstStream->stPacketData.aucPacket+ 8, sizeof(pstStream->stPacketData.aucPacket) - 8,
                  "VIDEO:W=%u;H=%u;EncType=%u;",
                  pstStream->stVideoDes.stVideoPara.uiWidth,
                  pstStream->stVideoDes.stVideoPara.uiHeight,
                  pstStream->stVideoDes.stVideoPara.uiEncodeType);
                  
    if(pstStream->stAudioParm.uiEncodeType){
        usType += CLOUDSTG_STREAM_PRV_AUDIODES_TYPE;

        if (iCloudEncSwitch == 1)
        {
            usAVDesLen += MOS_VSNPRINTF(pstStream->stPacketData.aucPacket + usAVDesLen + 8, sizeof(pstStream->stPacketData.aucPacket) - usAVDesLen - 8,
                "AUDIO:EncodeType=%u;SampleRate=%u;Channels=%u;depth=%u;ENC:EncLen=%u;EncryptType=%u;",
                pstStream->stAudioParm.uiEncodeType,pstStream->stAudioParm.uiSampleRate,pstStream->stAudioParm.uiChannel,pstStream->stAudioParm.uiDepth,
                    0, 51);
        }
        else
        {
            usAVDesLen += MOS_VSNPRINTF(pstStream->stPacketData.aucPacket + usAVDesLen + 8, sizeof(pstStream->stPacketData.aucPacket) - usAVDesLen - 8,
                "AUDIO:EncodeType=%u;SampleRate=%u;Channels=%u;depth=%u;",
                pstStream->stAudioParm.uiEncodeType,pstStream->stAudioParm.uiSampleRate,pstStream->stAudioParm.uiChannel,pstStream->stAudioParm.uiDepth);
        }
    }
    usTemp = MOS_INET_HTONS(usAVDesLen + 2);
    MOS_MEMCPY(pstStream->stPacketData.aucPacket + 4,&usTemp, 2);
    usTemp = MOS_INET_HTONS(usType);
    MOS_MEMCPY(pstStream->stPacketData.aucPacket + 6,&usTemp, 2);
    pstStream->uiStreamInfoLen += usAVDesLen;

    return MOS_OK;
}

_INT CloudStg_StreamSendVFrame(_HSTREAM hStream,ST_FRAME_NODE *pVFrameHead, _INT iFrameHeadLen, _UI uiTimeStamp,_UI bIFrame, _INT iCloudEncSwitch, _UC *aucCloudEncAesKey, _UC *aucCloudEncAesIv)
{
    MOS_PARAM_NULL_RETERR(hStream);
    MOS_PARAM_NULL_RETERR(pVFrameHead);

    _UC  aucEncData[64] = {0};
    _UI  iEncDataLen = 0;
    _UI  size;
    _INT iFrameLen = iFrameHeadLen;
    _UI  uiNeedWrite = 0;
    _UI  uiSendLen = 0;
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;

    // 第一帧
    if(pstStream->iFirstFrame){
        pstStream->uiIPos = 16;

        // 发送自定义头
        CloudStg_StreamSendPrvHead(pstStream, pstStream->iCloudEncSwitch);
        CloudStg_StreamSendOnePacket(pstStream,pstStream->stPacketData.aucPacket,pstStream->uiStreamInfoLen,MOS_NULL,0,uiTimeStamp,MOS_TRUE,0,MOS_NULL,MOS_NULL);
        // BUF_PRINTF_EX("CloudStg_SendFirstFrame....1",pstStream->stPacketData.aucPacket, pstStream->uiStreamInfoLen);

        pstStream->iFirstFrame  = 0;
        pstStream->uiVDuration  = 0;

        // 获取时间戳
        pstStream->uiVTimeStamp = uiTimeStamp;
    }

    // 重新计算uiVDuration
    if(uiTimeStamp >= pstStream->uiVTimeStamp)
    {
        pstStream->uiVDuration += uiTimeStamp - pstStream->uiVTimeStamp;
    }
    else
    {
        pstStream->uiVDuration += 40;
    }

    pstStream->uiVTimeStamp = uiTimeStamp;
    
    // PS头
    mpeg_ps_header_pack(pstStream->stPacketData.aucPacket,&size,pstStream->uiVDuration * 90,6150);
    CloudStg_StreamSendOnePacket(pstStream,pstStream->stPacketData.aucPacket,size, NULL,0,uiTimeStamp,MOS_TRUE,0,MOS_NULL,MOS_NULL);
    // BUF_PRINTF_EX("CloudStg_SendFirstFrame....ps",pstStream->stPacketData.aucPacket, size);

    if(bIFrame == 1)
    {
        // PS系统头
        mpeg_system_header_pack(pstStream->stPacketData.aucPacket,&size);
        CloudStg_StreamSendOnePacket(pstStream,pstStream->stPacketData.aucPacket,size,NULL,0,uiTimeStamp,MOS_TRUE,0,MOS_NULL,MOS_NULL);
        // BUF_PRINTF_EX("CloudStg_SendFirstFrame....pss",pstStream->stPacketData.aucPacket, size);

        // PSM头
        mpeg_psm_pack(pstStream->stPacketData.aucPacket,&size, (pstStream->stVideoDes.stVideoPara.uiEncodeType == EN_ZJ_VIDEOENC_TYPE_H265) ? 0x24  : 0x1b );

        CloudStg_StreamSendOnePacket(pstStream,pstStream->stPacketData.aucPacket,size,NULL,0,uiTimeStamp,MOS_TRUE,0,MOS_NULL,MOS_NULL);
        // BUF_PRINTF_EX("CloudStg_SendFirstFrame....psm",pstStream->stPacketData.aucPacket, size);

        if(MOS_ABS_NUM((_INT)(uiTimeStamp - pstStream->uiLITimeStamp)/1000) >= 2 && pstStream->uiIPos <= 4096)
        {
            _UI uiTemp = 0;
            uiTemp = MOS_INET_HTONL(pstStream->uiCurSliceSendLen);
            MOS_MEMCPY(pstStream->aucIndexInfo + pstStream->uiIPos,&uiTemp, 4);
            pstStream->uiIPos += 4;
            uiTemp = MOS_INET_HTONL(pstStream->uiVDuration * 90);
            MOS_MEMCPY(pstStream->aucIndexInfo + pstStream->uiIPos,&uiTemp, 4);
            pstStream->uiIPos += 4;
            pstStream->uiICount++;
            pstStream->uiLITimeStamp = uiTimeStamp;
        }
#if 0
        // 云存
        if (Mos_FileIsExist("/mnt/config/test_delay_idr") == MOS_TRUE)
        {
            _HFILE hFile;
            _UC aucSleepTime[32] = {0};
            _INT iSleepTime = 0;

            hFile = Mos_FileOpen("/mnt/config/test_delay_idr",MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
            Mos_FileRead(hFile,aucSleepTime,32);
            iSleepTime = atoi(aucSleepTime);

            Mos_FileClose(hFile);
            Mos_FileRmv("/mnt/config/test_delay_idr");

            MOS_PRINTF("now trans sleep %d.....\r\n", iSleepTime);
            Mos_Sleep(iSleepTime * 1000);
        }
#endif
    }

    while(iFrameLen > 0){

        /* PES头 */
        // 需要分包
        if(iFrameLen > MPEG_PS_SPLIT_SIZE){
            mpeg_pes_pack(MOS_NULL, MPEG_PS_SPLIT_SIZE,pstStream->uiVDuration * 90,MPEG_DEFAULT_VIDEO_STREAM,pstStream->stPacketData.aucPacket,&size);
            uiNeedWrite = MPEG_PS_SPLIT_SIZE;
        // 无需分包
        }else{
            mpeg_pes_pack(MOS_NULL, iFrameLen, pstStream->uiVDuration * 90 ,MPEG_DEFAULT_VIDEO_STREAM,pstStream->stPacketData.aucPacket,&size);
            uiNeedWrite = iFrameLen;
        }

        // 发送PES头
        CloudStg_StreamSendOnePacket(pstStream,pstStream->stPacketData.aucPacket,size,NULL,0,uiTimeStamp,MOS_TRUE,0,MOS_NULL,MOS_NULL);

        // 发送数据
        CloudStg_StreamSendOnePacket(pstStream,pVFrameHead->ptDatabuff + uiSendLen,uiNeedWrite,NULL,0,uiTimeStamp,MOS_TRUE,iCloudEncSwitch,aucCloudEncAesKey,aucCloudEncAesIv);

        uiSendLen  += uiNeedWrite;
        iFrameLen -= uiNeedWrite;
    }

    return MOS_OK;
}

_INT CloudStg_StreamSendAFrame(_HSTREAM hStream,ST_FRAME_NODE *pAFrameHead, _UI uiTimeStamp, _INT iCloudEncSwitch, _UC *aucCloudEncAesKey, _UC *aucCloudEncAesIv)
{
    MOS_PARAM_NULL_RETERR(hStream);
    MOS_PARAM_NULL_RETERR(pAFrameHead);

    _UC aucEncData[64] = {0};
    _UI iEncDataLen = 0;
    _UI size;
    _UI iFrameLen = pAFrameHead->uiRemFrameLen;
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;

    if( pstStream->uiATimeStamp == 0)
    {
        pstStream->uiATimeStamp = uiTimeStamp;
    }
    
    if(uiTimeStamp >= pstStream->uiATimeStamp)
    {
        pstStream->uiADuration += uiTimeStamp - pstStream->uiATimeStamp;
    }
    else
    {
        pstStream->uiADuration += 40;
    }

    pstStream->uiATimeStamp = uiTimeStamp;

    mpeg_pes_pack(MOS_NULL, iFrameLen, pstStream->uiADuration * 90,MPEG_DEFAULT_AUDIO_STREAM,pstStream->stPacketData.aucPacket,&size);

    CloudStg_StreamSendOnePacket(pstStream, pstStream->stPacketData.aucPacket,size,NULL,0,uiTimeStamp,MOS_FALSE,0,MOS_NULL,MOS_NULL);

    while(pAFrameHead != MOS_NULL ){
        CloudStg_StreamSendOnePacket(pstStream,pAFrameHead->ptDatabuff, pAFrameHead->usDatalen,NULL,0,uiTimeStamp,MOS_FALSE,iCloudEncSwitch,aucCloudEncAesKey,aucCloudEncAesIv);
        pAFrameHead = pAFrameHead->ptnest;
    }

    return MOS_OK;
}

_BOOL CloudStg_StreamSliceLenExceed(_HSTREAM hStream,_UI uiSendlen)
{
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;
    MOS_PARAM_NULL_RETFALSE(hStream);
    if(pstStream->uiCurSliceSendLen + uiSendlen > pstStream->uiSliceLen - 4104)
    {
        return MOS_TRUE;
    }
    return MOS_FALSE;
}

static _INT CloudStg_StreamSendEmptyBuf(ST_CLOUDSTG_STREAM *pstStream,_UI uiEmptyBufLen)
{
    MOS_PARAM_NULL_RETERR(pstStream);

    _INT iCnt = 0;
    _INT iRet = MOS_OK;
    Mos_MutexLock(&pstStream->hTaskGroupMutex);
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)pstStream->hCSTask;
    Mos_MutexUnLock(&pstStream->hTaskGroupMutex);
    if (pstTask == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"pstTask is null");
        return MOS_ERR;
    }

    ST_MECS_CONN *pstConn = (ST_MECS_CONN *)pstTask->hCSConn;
    if(uiEmptyBufLen == 0)
    {
        return MOS_OK;
    }
    if(pstConn && pstConn->pstConnUrl == MOS_NULL)
    {
	    Mos_MutexLock(&pstStream->hMutex);
        pstStream->uiTotalSendLen += uiEmptyBufLen;
        pstTask->uiSliceAddSize += uiEmptyBufLen;
        pstStream->uiCurSliceSendLen += uiEmptyBufLen;
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"connet close err,url is null");
		Mos_MutexUnLock(&pstStream->hMutex);
        return MOS_ERR;
    }
    pstStream->uiIndexLen = 4104;
    CloudStg_StreamBuildSlicenceInf(pstStream);

    Mos_MutexLock(&pstStream->hTaskGroupMutex);
    while((pstStream->uiIndexLen -  1400 * iCnt) > 1400)
    {
        CloudStg_TransTaskAddBuf(pstStream->hCSTask,EN_CLOUDSTG_TRANS_BUF_SLICEDATA,pstStream->aucIndexInfo + 1400 * iCnt,1400,pstStream->uiSliceEndStamp,0,MOS_NULL,MOS_NULL);
        iCnt++;
    }
    CloudStg_TransTaskAddBuf(pstStream->hCSTask,EN_CLOUDSTG_TRANS_BUF_SLICEDATA,pstStream->aucIndexInfo + 1400 * iCnt,pstStream->uiIndexLen -  1400 * iCnt,pstStream->uiSliceEndStamp,0,MOS_NULL,MOS_NULL);
    CloudStg_TransTaskAddBuf(pstStream->hCSTask,EN_CLOUDSTG_TRANS_BUF_CHUNKEDEND,(_UC*)"0\r\n\r\n",5,pstStream->uiSliceEndStamp,0,MOS_NULL,MOS_NULL);
    Mos_MutexUnLock(&pstStream->hTaskGroupMutex);

    Mos_MutexLock(&pstStream->hMutex);
    if (pstConn)
    {
        pstConn->uiTargetSize = pstStream->uiCurSliceSendLen + pstStream->uiIndexLen;
    }
    pstStream->uiTotalSendLen += uiEmptyBufLen;
    pstTask->uiSliceAddSize += uiEmptyBufLen;
    pstStream->uiCurSliceSendLen += uiEmptyBufLen;
    Mos_MutexUnLock(&pstStream->hMutex);
    return MOS_OK;
}

static _INT CloudStg_StreamBuildSlicenceInf(ST_CLOUDSTG_STREAM *pstStream)
{
    MOS_PARAM_NULL_RETERR(pstStream);

    _UI uiTemp = 0;
    pstStream->aucIndexInfo[0] = 0x00;
    pstStream->aucIndexInfo[1] = 0x00;
    pstStream->aucIndexInfo[2] = 0x01;
    pstStream->aucIndexInfo[3] = 0xBE;
    pstStream->aucIndexInfo[4] = 0x10;
    pstStream->aucIndexInfo[5] = 0x02;
    pstStream->aucIndexInfo[6] = 0x00;
    pstStream->aucIndexInfo[7] = 0x01;
    pstStream->aucIndexInfo[8] = 'i';
    pstStream->aucIndexInfo[9] = 'd';
    pstStream->aucIndexInfo[10] = 'e';
    pstStream->aucIndexInfo[11] = 'x';
    uiTemp = MOS_INET_HTONL(pstStream->uiICount);
    MOS_MEMCPY(pstStream->aucIndexInfo + 12,&uiTemp,4);
    return pstStream->uiIPos;
}

_INT CloudStg_StreamSendLastData(_HSTREAM hStream)
{
    _INT iRet = 0;
    _UI uiFillLen    = 0; 
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;

    MOS_PARAM_NULL_RETERR(hStream);
    if(pstStream->uiCurSliceSendLen == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"stream Cam:%d slice len is zero", pstStream->iCamId);
        return MOS_OK;
    }
    if (pstStream->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstStream->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
    {
        uiFillLen = pstStream->uiSliceLen - pstStream->uiCurSliceSendLen;
        if(uiFillLen >= 0)
        {
            iRet = CloudStg_StreamSendEmptyBuf(pstStream,uiFillLen);
            if(iRet == MOS_ERR)
            {
                return iRet;
            }
        }
    }
    Mos_MutexLock(&pstStream->hTaskGroupMutex);
    CloudStg_TransSendSliceInfo(pstStream->hCSTask);
    CloudStg_TransSetForceStopTime(pstStream->hCSTask, Mos_Time() + 60);
    Mos_MutexUnLock(&pstStream->hTaskGroupMutex);
    pstStream->uiCurSliceSendLen = 0;
    return MOS_OK;
}

_INT CloudStg_ExStreamSetDropGopNum(_HSTREAM hStream, _INT iDropNum)
{
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;
    if (pstStream == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 清零
    if (iDropNum <= 0)
    {
        pstStream->iDropGopFlag = MOS_FALSE;
        Mos_MutexLock(&pstStream->hMutex);
        pstStream->iDropGopNum = iDropNum;
        Mos_MutexUnLock(&pstStream->hMutex);
        return MOS_OK;
    }
    else if (iDropNum < pstStream->iDropGopNum || pstStream->iDropGopNum == 0)
    {
        pstStream->iDropGopFlag = MOS_TRUE;
        Mos_MutexLock(&pstStream->hMutex);
        pstStream->iDropGopNum = iDropNum;
        Mos_MutexUnLock(&pstStream->hMutex);
    }
    return MOS_OK;
}

_INT CloudStg_ExStreamGetDropGopNum(_HSTREAM hStream)
{
    _INT iDropGopNum = 0;
    if (hStream == MOS_NULL)
    {
        return iDropGopNum;
    }

    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;
    Mos_MutexLock(&pstStream->hMutex);
    iDropGopNum = pstStream->iDropGopNum;
    Mos_MutexUnLock(&pstStream->hMutex);

    return iDropGopNum;
}

_UI CloudStg_ExStreamGetBitRate(_HSTREAM hStream)
{
    _UI uiBiteRate = 0;
    if (hStream == MOS_NULL)
    {
        return uiBiteRate;
    }

    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;
    Mos_MutexLock(&pstStream->hMutex);
    uiBiteRate = pstStream->uiBiteRate;
    Mos_MutexUnLock(&pstStream->hMutex);

    return uiBiteRate;
}
