#include "mos.h"
#include "stdlib.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "config_api.h"
#include "media_cache_api.h"
#include "record_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_manage.h"
#include "cloudstg_logcode.h"
#include "cloudstg_transaddress.h"
#include "cloudstg_aliveupload.h"
#include "qualityprobe_api.h"
#include "config_camera.h"
#include "msgmng_quality_statistics.h"

/****************************************************************************************
*****************************************************************************************/
static ST_CLOUDSTG_RES_MNG g_StCloudResMng = {0};
static _INT CloudStg_Res_Loop(_VPTR pstParm);
static _INT CloudStg_Res_UpdateCloudEncInfo(ST_CLOUDSTG_URLBUCKET_NODE *pstCloudBucketNode);
/****************************************************************************************
*****************************************************************************************/
ST_CLOUDSTG_RES_MNG *CloudStg_ResGetMng()
{
    return &g_StCloudResMng;
}

_INT CloudStg_ResInit()
{
    if(CloudStg_ResGetMng()->ucInitFlag == 1)
    {
        return MOS_OK;
    }
    MOS_MEMSET(&g_StCloudResMng, 0, sizeof(g_StCloudResMng));
    CloudStg_ResGetMng()->ucInitFlag = 1;
    kj_timer_init(&CloudStg_ResGetMng()->tWatchDogTimer);
    Mos_MutexCreate(&CloudStg_ResGetMng()->hMutex);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud res init ok");
    return MOS_OK;
}

_INT CloudStg_ResDestroy()
{
    ST_MOS_LIST_ITERATOR stIterator0, stIterator1, stIterator2;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;
    ST_CLOUDSTG_RES_URL *pstUrlNode = MOS_NULL;
    if(CloudStg_ResGetMng()->ucInitFlag == 0)
    {
        return MOS_OK;
    }
    Mos_MutexDelete(&CloudStg_ResGetMng()->hMutex);
    // MOS_LIST_RMVALL(&CloudStg_ResGetMng()->stUrlPool,MOS_TRUE);
    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlPool, pstUrlNode, stIterator0)
    {
        if (pstUrlNode->pstStsUrlInfo)
        {
            MOS_FREE(pstUrlNode->pstStsUrlInfo);
            pstUrlNode->pstStsUrlInfo = MOS_NULL;
        }
        MOS_FREE(pstUrlNode);
    }
    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode, stIterator1)
    {
        Http_Httpclient_CancelAsyncRequestEx(pstUrlBucketNode->uiOgctId);
        // MOS_LIST_RMVALL(&pstUrlBucketNode->stUsrlist,MOS_TRUE);
        FOR_EACHDATA_INLIST(&pstUrlBucketNode->stUsrlist, pstUrlNode, stIterator2)
        {
            if (pstUrlNode->pstStsUrlInfo)
            {
                MOS_FREE(pstUrlNode->pstStsUrlInfo);
                pstUrlNode->pstStsUrlInfo = MOS_NULL;
            }
            MOS_FREE(pstUrlNode);
        }
        MOS_LIST_RMVNODE(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode);
        Mos_MemFree(pstUrlBucketNode);
    }
    MOS_LIST_RMVALL(&CloudStg_ResGetMng()->stConnMemList,MOS_TRUE);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud res destroy ok");
    return MOS_OK;
}

_INT CloudStg_ResStart()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    if(CloudStg_ResGetMng()->ucRunFlag == 1)
    {
        return MOS_OK;
    }
    CloudStg_ResGetMng()->ucRunFlag = 1;

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    
    // 初始化看门狗timeout
    CloudStg_Res_FeedWatchDog();

	// FIXME: 上电获取地址
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "Start request stream type url...\r\n");
    CloudStg_ResAllocUrl(EN_CLOUDSTG_RESOURCE_STREAM,EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL,0);
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "Start request pic type url...\r\n");
    CloudStg_ResAllocUrl(EN_CLOUDSTG_RESOURCE_PIC,EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL,0);

    // 创建线程
    if(Mos_ThreadCreate((_UC*)"CloudRes",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        CloudStg_Res_Loop,MOS_NULL,MOS_NULL,&CloudStg_ResGetMng()->hThread) == MOS_ERR)
    {
        CloudStg_ResGetMng()->ucRunFlag = 0;     
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud res start ok");
    return MOS_OK;
}

_INT CloudStg_ResStop()
{
    if(CloudStg_ResGetMng()->ucRunFlag == 0)
    {
        return MOS_OK;
    }
    CloudStg_ResGetMng()->ucRunFlag = 0;
    Mos_ThreadDelete(CloudStg_ResGetMng()->hThread);
    CloudStg_ResGetMng()->hThread = MOS_NULL;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud res stop ok");
    return MOS_OK;
}

static _UC* CloudStg_BuildPrefetchUrlReq(_UI uiOgctId, _CTIME_T cNowTime,_UI uiPicUrl, _INT iCloudEncSwitch, _UC *pucCloudEncHttpParamJson)
{
    _INT i;
    _INT iFixLen          = 0;
    _INT iTotalLen        = 0;
    _UC strURLEnc[512]    = {0};
    _UC *pstrTmp          = MOS_NULL;
    _UC *pucParams        = MOS_NULL;
    _UC *pucSignBuff      = MOS_NULL;
    _UC aucAesParams[512] = {0};
    _UC aucBuff[1024]     = {0};
    _UC aucAesKey[128]    = {'\0'};
    _UC aucDeviceInfo[64] = {0};
    _UC aucCloudMode[6]   = {0};
    
    JSON_HANDLE hRoot     = MOS_NULL;
    JSON_HANDLE hValueObj = MOS_NULL;
    ST_CFG_SYSTEM_MNG *pstCompanyInfo = Config_GetSystemMng();
    ST_CFG_CLOUDSTG_MNG *pstCloudInfo = Config_GetCloudMng();

    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }
    if(uiPicUrl == 1)
    {
        MOS_VSNPRINTF(aucBuff, 8, "%02x%02x", EN_CLOUDSTG_TRANS_BUFF, EN_CLOUDSTG_GETPICURL_REQ);
    }
    else
    {
        MOS_VSNPRINTF(aucBuff, 8, "%02x%02x", EN_CLOUDSTG_TRANS_BUFF, EN_CLOUDSTG_GETURL_REQ);
    }
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"METHOD", Adpt_Json_CreateString((_UC*)aucBuff));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiOgctId));

    hValueObj = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hValueObj, (_UC*)"uid", Adpt_Json_CreateString(pstCompanyInfo->aucDevUID));

    Adpt_Json_AddItemToObject(hValueObj, (_UC*)"appKey", Adpt_Json_CreateString(pstCloudInfo->aucAppKey));
    
    MOS_VSNPRINTF(aucDeviceInfo, sizeof(aucDeviceInfo), "%c%c_%d_%d_%s", Config_GetSystemMng()->aucDid[1], Config_GetSystemMng()->aucDid[2], Config_GetDeviceMng()->iDevType, Config_GetCloudMng()->iCloudUpLoadMode, Config_GetDeviceMng()->aucDevVerSion);

/* 端切片 deprecated
 *   if (Config_GetCamaraMng()->uiSliceCloudAbility >= 1)
 *   {
 *      MOS_STRCPY(aucCloudMode, EXCHAN_AND_NORMAL_CHAN);
 *   }
 */
    if (Config_GetCamaraMng()->uiStsCloudAbility >= 1)
    {
        MOS_STRCPY(aucCloudMode, STS_AND_NORMAL_CHAN);
    }
    else
    {
        MOS_STRCPY(aucCloudMode, NORMAL_CHAN);
    }

    // 端切片 Mos_SysGetDeviceAbility()==EN_MOS_DEVICE_ABILITY_RICH?XX:YY deprecated
    // 新增上报https能力flag: "isHttps"
#ifdef SUPPORT_HTTPS
    if (iCloudEncSwitch == 1)
    {
        // encrypt, check memory
        MOS_VSNPRINTF(aucBuff, sizeof(aucBuff), (_UC*)"timestamp=%u&sum=%s&di=%s&eem=%s&isHttps=1",cNowTime, aucCloudMode,
            aucDeviceInfo, pucCloudEncHttpParamJson);
    }
    else
    {
        // no encrypt
        MOS_VSNPRINTF(aucBuff, sizeof(aucBuff), (_UC*)"timestamp=%u&sum=%s&di=%s&isHttps=1",cNowTime, aucCloudMode,
            aucDeviceInfo);
    }
#else
    if (iCloudEncSwitch == 1)
    {
        // encrypt, check memory
        MOS_VSNPRINTF(aucBuff, sizeof(aucBuff), (_UC*)"timestamp=%u&sum=%s&di=%s&eem=%s",cNowTime, aucCloudMode,
            aucDeviceInfo, pucCloudEncHttpParamJson);
    }
    else
    {
        // no encrypt
        MOS_VSNPRINTF(aucBuff, sizeof(aucBuff), (_UC*)"timestamp=%u&sum=%s&di=%s",cNowTime, aucCloudMode,
            aucDeviceInfo);
    }
#endif

    pucParams = (_UC*)MOS_MALLOCCLR((int)((float)512 * (4/3.0) + 8));
    iTotalLen = MOS_STRLEN(pstCompanyInfo->aucDevkey);
    if(iTotalLen < 16)
    {
        MOS_STRNCPY(aucAesKey, pstCompanyInfo->aucDevkey, iTotalLen);
        MOS_STRNCPY(aucAesKey + iTotalLen, pstCompanyInfo->aucDevkey , 16 - iTotalLen);
    }else{
        MOS_STRNCPY(aucAesKey, pstCompanyInfo->aucDevkey, 16);
    }
    iTotalLen = MOS_STRLEN(aucBuff);
    iFixLen = 16 - (iTotalLen % 16);
    if(iFixLen != 0)
    {
        iTotalLen = iTotalLen + iFixLen;
        for(i=0;i<iFixLen;i++)
        {
            aucBuff[iTotalLen-iFixLen+i] = iFixLen;
        }
        aucBuff[iTotalLen] = '\0';
    }
    // MOS_PRINTF("aucBuff: %s\r\n", aucBuff);
    Adpt_Aec_Encrypt(aucAesKey,pstCloudInfo->aucAESVI,aucBuff,aucAesParams,iTotalLen);
    Adpt_Base64_Enc(aucAesParams,iTotalLen,pucParams);

    MOS_VSNPRINTF(aucBuff, 1024, "appKey=%s&params=%s&uid=%s", pstCloudInfo->aucAppKey, pucParams, pstCompanyInfo->aucDevUID);

    pucSignBuff = (_UC*)MOS_MALLOCCLR(1024);
    Adpt_HmacSha256_Encrypt(aucBuff, pucSignBuff, 1024, pstCloudInfo->aucAppSecret );

    CloudStg_URLEncode((const char* )pucParams, MOS_STRLEN(pucParams), strURLEnc, sizeof(strURLEnc));
    Adpt_Json_AddItemToObject(hValueObj, (_UC*)"sign", Adpt_Json_CreateString(pucSignBuff));
    Adpt_Json_AddItemToObject(hValueObj, (_UC*)"params", Adpt_Json_CreateString(strURLEnc));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"BODY", hValueObj);

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucSignBuff);
    MOS_FREE(pucParams);
    return pstrTmp;
}

static _INT CloudStg_RecvGetUrlRspData(ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode, _UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pstUrlBucketNode);
    MOS_PARAM_NULL_RETERR(pucJson);
	_INT iDirectMode = 0;
    _UC aucUrl[256] = {0};
    _UC aucMsg[128] = {0};
    _INT iValue = 0;
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(pucJson);
    JSON_HANDLE hDataObj = MOS_NULL;

    if (pstUrlBucketNode->iCloudEncSwitch == 1)
    {
        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETENCURL_ADDRESS);
    }
    else
    {
        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETURL_ADDRESS);
    }

    if (hJsonRoot == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "hJsonRoot is null");
        if (pstUrlBucketNode->iCloudEncSwitch == 1)
        {
            Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "get-EncryptUrls", aucUrl, EN_CLOUDSTG_RT_GETENCURLS_JSON_PARSE_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_JSON_PARSE);
        }
        else
        {
            Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "getUrls", aucUrl, EN_CLOUDSTG_RT_GETURLS_JSON_PARSE_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_JSON_PARSE);
        }
        return MOS_ERR;
    }

    // DEBUG: 打印出geturl的rsp
    MOS_PRINTF_DEBUG("Recv url json: %s...\r\n", pucJson);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"CODE"), &iValue);
    if (iValue != 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "recv http code %u ", iValue);
        if(iValue == 20001)
        {
            CloudStg_InitChargeInfo();
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"err cloud info");
        }
        Adpt_Json_Delete(hJsonRoot);
        if (pstUrlBucketNode->iCloudEncSwitch == 1)
        {
            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD get-EncryptUrls request fail, errcode: %d", iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_GETENCURLS_FAIL, aucMsg, 1);
        }
        else
        {
            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD getUrls request fail, errcode: %d", iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_GETURLS_FAIL, aucMsg, 1);
        }
        return MOS_ERR;
    }
    hDataObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");

    // 清除所有地址
    CloudStg_Res_CleanAllUrl();

    // 云存获取加密地址RSP
    if (pstUrlBucketNode->iCloudEncSwitch == 1)
    {
		CloudStg_Res_EncryptUrlParse(pstUrlBucketNode, hDataObj);
    }
    // 云存获取普通地址URL
    else
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"directModel"), &iDirectMode);
        iDirectMode = iDirectMode==0?1:iDirectMode;

        if (Config_GetCloudMng()->iDirectMode != iDirectMode)
        {
            if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL)
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD cloud upload mode switch to normal");
            }
            else if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD cloud upload mode switch to excloud");
            }
            else if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD cloud upload mode switch to sts");
            }
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 200, EN_CLOUDSTG_RT_MODE_SWITCH, aucMsg, 1);
            Config_GetCloudMng()->iDirectMode = iDirectMode;

            // 无地址的任务需要立马终止
            if (CloudStg_TaskNeedConnUrl(MOS_TRUE))
            {
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "Now turn off all normal alive task");
                Cloudstg_CloseAllNormalAliveTask();
            }
            if (CloudStg_PatchTaskNeedConnUrl(MOS_TRUE))
            {
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "Now turn off all patch alive task");
                Cloudstg_CloseAllPatchAliveTask();
            }
        }
		CloudStg_Res_NormalUrlParse(pstUrlBucketNode, hDataObj, iDirectMode);
    }

    Adpt_Json_Delete(hJsonRoot);
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "CloudEncSwitch=%d", pstUrlBucketNode->iCloudEncSwitch);
    return MOS_OK;
}

_VOID CloudStg_GetUrl_RecvAddrRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    _UI *uiTaskId = (_INT *)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode, stIterator)
    {
        if (pstUrlBucketNode->uiOgctId == *uiTaskId)
        {
            break;
        }
    }
    if (pstUrlBucketNode == MOS_NULL)
    {
        return;
    }
    if (CloudStg_ResGetMng()->uiBuffLen == 0)
    {
        CloudStg_ResGetMng()->uiBuffLen = 15360;
        CloudStg_ResGetMng()->pucRecvBuff = (_UC*)Mos_MemAlloc(MOS_NULL, 15360);
    }
    if (CloudStg_ResGetMng()->uiRecvLen + uiLen < CloudStg_ResGetMng()->uiBuffLen)
    {
        MOS_MEMCPY(CloudStg_ResGetMng()->pucRecvBuff + CloudStg_ResGetMng()->uiRecvLen, pucData, uiLen);
        CloudStg_ResGetMng()->uiRecvLen += uiLen;
    }
    return;
}

_VOID CloudStg_GetUrl_RecvAddrFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iRet                                    = 0;
    _UC aucUrl[256]                              = {0};
    _UI *uiTaskId                                = (_INT *)vpUserPtr;
    EN_QUALITY_STA_RT_TYPE enStatusCode          = EN_QUALITY_STA_RT_CLOUD_GETURL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;

    if (Config_GetCloudMng()->iCloudEncSwitch == 1)
    {
        enStatusCode = EN_QUALITY_STA_RT_CLOUD_GETENCURL;
    }
    else
    {
        enStatusCode = EN_QUALITY_STA_RT_CLOUD_GETURL;
    }

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(enStatusCode, uiUseTime);

    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode, stIterator)
    {
        if (pstUrlBucketNode->uiOgctId == *uiTaskId)
        {
            break;
        }
    }

    if (pstUrlBucketNode == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return;
    }
    if (CloudStg_ResGetMng()->pucRecvBuff)
    {
        CloudStg_ResGetMng()->pucRecvBuff[CloudStg_ResGetMng()->uiRecvLen] = 0;
    }
    iRet = CloudStg_RecvGetUrlRspData(pstUrlBucketNode,CloudStg_ResGetMng()->pucRecvBuff);
    if(iRet == MOS_ERR)
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        printf("<<<<<<<<<<<<<<<< ogctid %u get url err, content %s",pstUrlBucketNode->uiOgctId,CloudStg_ResGetMng()->pucRecvBuff);
        Mos_MemFree(CloudStg_ResGetMng()->pucRecvBuff);
        CloudStg_ResGetMng()->pucRecvBuff = MOS_NULL;
        CloudStg_ResGetMng()->uiStatus  = 0;
        pstUrlBucketNode->uiOgctId  = 0;
        CloudStg_ResGetMng()->uiBuffLen = 0;
        CloudStg_ResGetMng()->uiRecvLen = 0;
        CloudStg_ResGetMng()->cNextReqTime = CloudStg_Res_GetNextReqTime(Mos_Time());
        return;
    }
    EN_COUNT_VALUE CountLess2Value = Mos_Time() - CloudStg_ResGetMng()->cTimeReq >= 2 ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
    Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_SUCCESS, CountLess2Value);

    if (Config_GetCloudMng()->iCloudEncSwitch == 1)
    {
        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETENCURL_ADDRESS);
        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_GETENCURLS_SUCCESS, "CD get-EncryptUrls request successfully", 1);
    }
    else
    {
        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETURL_ADDRESS);
        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_GETURLS_SUCCESS, "CD getUrls request successfully", 1);
    }
    
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"Get url success");
    Config_GetCloudMng()->iAfterReqUrlFlag = 1;
    Mos_MemFree(CloudStg_ResGetMng()->pucRecvBuff);
    CloudStg_ResGetMng()->pucRecvBuff = MOS_NULL;
    CloudStg_ResGetMng()->uiStatus = 2;
    pstUrlBucketNode->uiOgctId  = 0;
    CloudStg_ResGetMng()->uiBuffLen = 0;
    CloudStg_ResGetMng()->uiRecvLen = 0;
    CloudStg_ResGetMng()->uiTryTime = 0;

    return;
}

_VOID CloudStg_GetUrl_RecvAddrFail(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    EN_QUALITY_STA_RT_TYPE enStatusCode          = EN_QUALITY_STA_RT_CLOUD_GETURL;
    _CTIME_T cNowTime                            = Mos_Time();
    _UI *uiTaskId                                = (_INT *)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;
    _UC aucUrl[256] = {0};

    // 该switch标志不影响实际功能
    if (Config_GetCloudMng()->iCloudEncSwitch == 1)
    {
        enStatusCode = EN_QUALITY_STA_RT_CLOUD_GETENCURL;

        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETENCURL_ADDRESS);
        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, uiErrCode, EN_CLOUDSTG_RT_GETENCURLS_TIMEOUT, "CD get-EncryptUrls request timeout", 1);
    }
    else
    {
        enStatusCode = EN_QUALITY_STA_RT_CLOUD_GETURL;

        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETURL_ADDRESS);
        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, uiErrCode, EN_CLOUDSTG_RT_GETURLS_TIMEOUT, "CD getUrls request timeout", 1);
    }

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(enStatusCode, uiUseTime);

    MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Get url fail");
    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode, stIterator)
    {
        if (pstUrlBucketNode->uiOgctId == *uiTaskId)
        {
            break;
        }
    }
    if (pstUrlBucketNode == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return;
    }
    if (CloudStg_ResGetMng()->uiBuffLen != 0)
    {
        Mos_MemFree(CloudStg_ResGetMng()->pucRecvBuff);
        CloudStg_ResGetMng()->pucRecvBuff = MOS_NULL;
    }
    Config_GetCloudMng()->iAfterReqUrlFlag = 1;

    CloudStg_ResGetMng()->uiStatus = 0;
    pstUrlBucketNode->uiOgctId = 0;
    CloudStg_ResGetMng()->uiRecvLen = 0;
    CloudStg_ResGetMng()->uiBuffLen = 0;
    Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
    CloudStg_ResGetMng()->cNextReqTime = CloudStg_Res_GetNextReqTime(Mos_Time());
    return;
}

_INT CloudStg_TransGetUrl(ST_CLOUDSTG_URLBUCKET_NODE *pstCloudBucketNode, _CTIME_T cNowTime)
{
    MOS_PARAM_NULL_RETERR(pstCloudBucketNode);

    _INT iRet                           = 0;
    _UI i                               = 0;
    _US usPort                          = 80;
    _UI uiHttpsFlag                     = 0;
    _UC *pStrTmp                        = MOS_NULL;
    _UC *pStrStart                      = MOS_NULL;
    _UC auAdmonAddr[128]                = {0};
    _UC aucUrl[256]                     = {0};
    EN_QUALITY_STA_RT_TYPE enStatusCode = EN_QUALITY_STA_RT_CLOUD_GETURL;

    if (pstCloudBucketNode->iCloudEncSwitch == 1)
    {
        enStatusCode = EN_QUALITY_STA_RT_CLOUD_GETENCURL;
        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETENCURL_ADDRESS);
    }
    else
    {
        enStatusCode = EN_QUALITY_STA_RT_CLOUD_GETURL;
        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETURL_ADDRESS);
    }

    // 创建关键接口质量信息节点 https://cloud-ehome.21cn.com/unifyDev/getEncryptUrls
    MsgMng_QualityStatistics_FindAndCreatNode(enStatusCode, aucUrl);

    MOS_MEMSET(auAdmonAddr, 0, 128);
    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucCloudAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 

    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucCloudAddr, "//");
    if (pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucCloudAddr;
    }
    else{
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart, ":");
    if (pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr, pStrStart, pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRLCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    if(pstCloudBucketNode->uiPicUrl == 0)
    {
        if (pstCloudBucketNode->iCloudEncSwitch == 1)
        {
            MOS_STRNCPY(aucUrl, CLOUDSTG_GETENCURL_ADDRESS, sizeof(aucUrl));
        }
        else
        {
            MOS_STRNCPY(aucUrl, CLOUDSTG_GETURL_ADDRESS, sizeof(aucUrl));
        }
    }
    else if(pstCloudBucketNode->uiPicUrl == 1)
    {
        MOS_STRNCPY(aucUrl, CLOUDSTG_GETPICURL_ADDRESS, sizeof(aucUrl));
    }
    pStrTmp = CloudStg_BuildPrefetchUrlReq(pstCloudBucketNode->uiOgctId, cNowTime, pstCloudBucketNode->uiPicUrl, 
                                            pstCloudBucketNode->iCloudEncSwitch, pstCloudBucketNode->aucCloudEncHttpParamJson);
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = CloudStg_GetUrl_RecvAddrRsp;
    stHttpInfoNode.pfuncFinished   = CloudStg_GetUrl_RecvAddrFinish;
    stHttpInfoNode.pfuncFailed     = CloudStg_GetUrl_RecvAddrFail;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.vpUserPtr       = &pstCloudBucketNode->uiOgctId;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, aucUrl, EN_HTTP_METHOD_POST, pstCloudBucketNode->uiOgctId);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        MOS_MEMSET(aucUrl, 0, sizeof(aucUrl));
        if (pstCloudBucketNode->iCloudEncSwitch == 1)
        {
            // MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETENCURL_ADDRESS);
            Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "get-EncryptUrls", aucUrl, EN_CLOUDSTG_RT_GETENCURLS_GETHOSTBYNAME_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME);
        }
        else
        {
            // MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETURL_ADDRESS);
            Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "getUrls", aucUrl, EN_CLOUDSTG_RT_GETURLS_GETHOSTBYNAME_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME);
        }
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"ogctid %u get url %s len %u type %u iret %d",
        pstCloudBucketNode->uiOgctId,pStrTmp,MOS_STRLEN(pStrTmp),pstCloudBucketNode->uiType,iRet);
    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

ST_CLOUDSTG_RES_URL *CloudStg_ResAllocUrl(_UI uiType, _INT iDirectMode, _UI uiPicUrl)
{
    _INT iLoopCnt = 0;
    _CTIME_T cNowTime = Mos_Time();
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_RES_URL  *pstResUrl = MOS_NULL;
    ST_CLOUDSTG_RES_URL  *pstResUrltmp = MOS_NULL;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;

    // 云存上传获取地址，喂狗并刷新暂停时间
    CloudStg_Res_FeedWatchDog();

    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode, stIterator)
    {
        if(pstUrlBucketNode->uiType == uiType)
        {
           break;
        }
    }
    if(pstUrlBucketNode == MOS_NULL)
    {
        pstUrlBucketNode = (ST_CLOUDSTG_URLBUCKET_NODE*)Mos_MemAlloc(MOS_NULL,sizeof(ST_CLOUDSTG_URLBUCKET_NODE));
        MOS_MEMSET(pstUrlBucketNode, 0, sizeof(ST_CLOUDSTG_URLBUCKET_NODE));
        pstUrlBucketNode->uiPicUrl = uiPicUrl;
        pstUrlBucketNode->uiType   = uiType;
        CloudStg_ResGetMng()->uiTryTime = 0;
        CloudStg_ResGetMng()->cNextReqTime = CloudStg_Res_GetNextReqTime(cNowTime);
        pstUrlBucketNode->uiResNum = CLOUDSTG_MAX_RES_NUM;

        MOS_LIST_ADDTAIL(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode);
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"res alloc new file type %u ",uiType);
        return MOS_NULL;
    }
    
    do{
        Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
        if(MOS_LIST_GETCOUNT(&pstUrlBucketNode->stUsrlist) > 0)
        {
            // STS模式需要复制出一份地址
            if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
            {      
                pstResUrltmp = MOS_LIST_GETHEAD(&pstUrlBucketNode->stUsrlist);
                if (pstResUrltmp == MOS_NULL)
                {
                    pstResUrl = MOS_NULL;
                    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                    break;
                }
                if(pstResUrltmp->cUrlTime < cNowTime)
                {
                    MOS_LIST_RMVNODE(&pstUrlBucketNode->stUsrlist, pstResUrltmp);
                    if (pstResUrltmp->pstStsUrlInfo)
                    {
                        MOS_FREE(pstResUrltmp->pstStsUrlInfo);
                        pstResUrltmp->pstStsUrlInfo = MOS_NULL;
                    }
                    // 填入Pool中
                    MOS_LIST_ADDTAIL(&CloudStg_ResGetMng()->stUrlPool, pstResUrltmp);
                    MOS_LOG_INF(CLOUDSTG_LOGSTR, "delete url node, type: %u, now time: %u, available time: %u ~ %u, left %d node", pstUrlBucketNode->uiType, cNowTime, pstResUrltmp->cPrvUrlTime, pstResUrltmp->cUrlTime, pstUrlBucketNode->stUsrlist.uiTotalCount);
                    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                    continue;
                }
                else
                {
                    pstResUrl = CloudStg_ResBackUpUrlBuff(pstResUrltmp);
                    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                    break;
                }
            }
            else
            {
                pstResUrltmp = MOS_LIST_RMVHEAD(&pstUrlBucketNode->stUsrlist);
                if (pstResUrltmp == MOS_NULL)
                {
                    pstResUrl = MOS_NULL;
                    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                    break;
                }
                // 云存地址request Date 超过±15分钟，扔掉
                if(cNowTime < pstResUrltmp->cPrvUrlTime || pstResUrltmp->cUrlTime < cNowTime)
                {

                    // 填入Pool中
                    MOS_LIST_ADDTAIL(&CloudStg_ResGetMng()->stUrlPool, pstResUrltmp);
                    MOS_LOG_INF(CLOUDSTG_LOGSTR, "delete url node, type: %u, now time: %u, available time: %u ~ %u, left %d node", pstUrlBucketNode->uiType, cNowTime, pstResUrltmp->cPrvUrlTime, pstResUrltmp->cUrlTime, pstUrlBucketNode->stUsrlist.uiTotalCount);
                    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                    continue;
                }
                else
                {
                    pstResUrl = pstResUrltmp;
                    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                    break;
                }
            }
        }
        Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
        Mos_Sleep(200);
    }while(iLoopCnt++ < 24); // FIXME
    
    // MOS_LOG_INF(CLOUDSTG_LOGSTR, "pstUrlBucketNode->stUsrlist length: %d, type: %d, find pstResUrl: %p", MOS_LIST_GETCOUNT(&pstUrlBucketNode->stUsrlist), pstUrlBucketNode->uiType, pstResUrl);

    return pstResUrl;
}

ST_CLOUDSTG_RES_URL *CloudStg_ResLocalFileUrl()
{
    ST_CLOUDSTG_RES_URL *pstResUrl = MOS_NULL;
    
    pstResUrl = (ST_CLOUDSTG_RES_URL*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_RES_URL));
    MOS_STRCPY(pstResUrl->aucUrl, CLOUDSTG_UPLOAD_LOCOL_LOG_PATH);

    return pstResUrl;
}

_VOID CloudStg_ResFreeUrl(ST_CLOUDSTG_RES_URL *pstCloudUrl)
{
    MOS_PARAM_NULL_NORET(pstCloudUrl);

    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
    MOS_LIST_ADDTAIL(&CloudStg_ResGetMng()->stUrlPool, pstCloudUrl);
    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    return ;
}

_INT CloudStg_ResGetHost(ST_CLOUDSTG_RES_URL *pstConnUri, _OUT _UC *pucOutHost, _OUT _US *pusOutPort, _OUT _UC *pucOutSubUri,_UI *uiHttpType)
{
    MOS_PARAM_NULL_RETERR(pstConnUri);
    MOS_PARAM_NULL_RETERR(pucOutHost);

    _INT iLen = 0;
    _INT iTmp = 0;
    _UC *pucSeparator = MOS_NULL;
    _UC *pucColon = MOS_NULL;
    _UC *pucURL      = pstConnUri->aucUrl;
// 启用SSL测试
#if 0
    MOS_PRINTF("ORI URL: %s\r\n", pucURL);
    _INT iOffset = 0;
    _UC pucTmp[CLOUDSTG_URI_LEN] = {0};

    MOS_MEMCPY(pucTmp, pstConnUri->aucUrl, 4);
    iOffset += 4;

    MOS_MEMCPY(pucTmp + iOffset, "s", 1);
    MOS_MEMCPY(pucTmp + iOffset + 1, pstConnUri->aucUrl + iOffset, CLOUDSTG_URI_LEN - (iOffset + 1));

    MOS_MEMSET(pstConnUri->aucUrl, 0x00, sizeof(pstConnUri->aucUrl));
    MOS_STRCPY(pstConnUri->aucUrl, pucTmp);
    pucURL = pstConnUri->aucUrl;
    MOS_PRINTF("DST URL: %s\r\n", pucURL);
#endif
    if (0 == MOS_STRNCMPNOCASE(pucURL, (_UC *)"https://", MOS_STRLEN("https://")))
    {
        *uiHttpType = 1;
        pucURL += MOS_STRLEN("https://");
    }
    else if (0 == MOS_STRNCMPNOCASE(pucURL,(_UC *)"http://", MOS_STRLEN("http://")))
    {
        *uiHttpType = 0;
        pucURL += MOS_STRLEN("http://");
    }

    pucColon = MOS_STRSTR(pucURL, ":");
    if (MOS_NULL == pucColon)
    {
        if(*uiHttpType == 1){
            *pusOutPort = CLOUDSTG_DEFAULT_HTTPS_PORT;
        }
        else if(*uiHttpType == 0){
            *pusOutPort = CLOUDSTG_DEFAULT_HTTP_PORT;
        }
    }
    else
    {
        *pusOutPort = (_US)MOS_ATOI(pucColon + 1);
    }

    pucSeparator = MOS_STRSTR(pucURL, "/");
    if (pucSeparator)
    {
        iLen = SAFE_INT(pucSeparator - pucURL);
    }

    if (pucColon)
    {
        iLen = SAFE_INT(pucColon - pucURL);
    }

    if (iLen <= 0 || iLen >= CLOUDSTG_URI_LEN)
    {
        return MOS_ERR;
    }
    MOS_MEMCPY(pucOutHost,pucURL,iLen);
    pucOutHost[iLen] = 0;
    if (pucSeparator && pucOutSubUri)
    {
        iLen = MOS_STRLEN(pucSeparator);
        MOS_MEMCPY(pucOutSubUri,pucSeparator,iLen);
        pucOutSubUri[iLen] = 0;
        iTmp = iLen - 1;
        if (iTmp >= 0  && '/' == pucOutSubUri[iTmp])
        {
            pucOutSubUri[iTmp] = 0;
        }
    }
    return MOS_OK;
}

ST_MECS_CONN *CloudStg_ResMallocConnMem()
{
    ST_MECS_CONN *pstMecsConn = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stConnMemList,pstMecsConn, stIterator)
    {
        if(pstMecsConn->uiUseFlag == 0)
        {
            break;
        }
    }
    if(pstMecsConn == MOS_NULL)
    {
        pstMecsConn = (ST_MECS_CONN*)MOS_MALLOC(sizeof(ST_MECS_CONN));
        MOS_LIST_ADDTAIL(&CloudStg_ResGetMng()->stConnMemList, pstMecsConn);
    }
    pstMecsConn->uiSliceSize = 0;
    pstMecsConn->uiType      = 0;
    pstMecsConn->bHeaderSent  = MOS_FALSE;
    pstMecsConn->bRsponseRecv = MOS_FALSE;
    pstMecsConn->pstConnUrl  = MOS_NULL;
    MOS_MEMSET(&pstMecsConn->stSocket, 0, sizeof(ST_MECS_CONN_SOCKET));
    pstMecsConn->stSocket.hSocket = MOS_SOCKET_INVALID;
    pstMecsConn->uiUseFlag   = 1;
    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    return pstMecsConn;
}

_INT CloudStg_ResFreeConnMem(ST_MECS_CONN *pstConnMem)
{
    if(pstConnMem == MOS_NULL || pstConnMem->uiUseFlag == 0)
    {
        return MOS_ERR;
    }
    pstConnMem->uiUseFlag = 0;
    return MOS_OK;
}

/*********************************************************************************
*********************************************************************************/
ST_CLOUDSTG_RES_URL *CloudStg_ResMallocUrlBuff()
{
    ST_CLOUDSTG_RES_URL *pstResUrl = MOS_NULL;
    if(MOS_LIST_GETCOUNT(&CloudStg_ResGetMng()->stUrlPool) > 0)
    {
        Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
        pstResUrl = MOS_LIST_RMVHEAD(&CloudStg_ResGetMng()->stUrlPool);
        Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    }
    if(pstResUrl == MOS_NULL)
    {
        pstResUrl = (ST_CLOUDSTG_RES_URL*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_RES_URL));
        // MOS_LOG_INF(CLOUDSTG_LOGSTR,"res alloc url buff node");
    }
    // 删除流直传切换为端切片的脏数据
    MOS_MEMSET(pstResUrl->aucAuthorization, 0x00, sizeof(pstResUrl->aucAuthorization));
    return pstResUrl;
}

ST_CLOUDSTG_RES_URL *CloudStg_ResBackUpUrlBuff(ST_CLOUDSTG_RES_URL *pstResUrl)
{
    ST_CLOUDSTG_RES_URL *pstResUrlTmp = MOS_NULL;
    if(MOS_LIST_GETCOUNT(&CloudStg_ResGetMng()->stUrlPool) > 0)
    {
        Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
        pstResUrlTmp = MOS_LIST_RMVHEAD(&CloudStg_ResGetMng()->stUrlPool);
        Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    }
    if(pstResUrlTmp == MOS_NULL)
    {
        pstResUrlTmp = (ST_CLOUDSTG_RES_URL*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_RES_URL));
    }

    // 删除脏数据
    MOS_MEMSET(pstResUrlTmp, 0x00, sizeof(ST_CLOUDSTG_RES_URL));

    // 拷贝结构体
    MOS_MEMCPY(pstResUrlTmp, pstResUrl, sizeof(ST_CLOUDSTG_RES_URL));
    return pstResUrlTmp;
}

static _INT CloudStg_Res_ProcUrl()
{
    _INT iRet    = 0;
    _UC *pStrTmp = MOS_NULL;
    _CTIME_T cNowTime = Mos_Time();
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator, stIterator2;
    ST_CFG_INIOT_NODE* pstIotNode =  Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);
    ST_CLOUDSTG_RES_URL *pstCloudResUrl = MOS_NULL;
    
    // 信令服务器更新config加密信息，通知重新生成加密信息
    if (CloudStg_ResGetMng()->iForceGenerateEncInfo)
    {
        // 防止mng线程task的加密信息与config加密信息不同步
        if (!CloudStg_TaskNeedConnUrl(MOS_FALSE) && !CloudStg_PatchTaskNeedConnUrl(MOS_FALSE))
        {
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "GenerateEncInfo Start Force!");

            // 清除原来的key对应的url，会将bucket节点清空，会立刻请求url
            // 重新生成加密信息     
            CloudStg_Res_GenerateEncInfo(MOS_TRUE);
            CloudStg_ResGetMng()->iForceGenerateEncInfo = 0;
        }
    }

    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode, stIterator)
    {
        Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
        FOR_EACHDATA_INLIST(&pstUrlBucketNode->stUsrlist,pstCloudResUrl,stIterator2)
        {
            // 超过14分钟
            if(MOS_ABS_NUM(cNowTime - pstCloudResUrl->cUrlTime) <= 1)
            {
                // 从bucket中删除节点
                MOS_LIST_RMVNODE(&pstUrlBucketNode->stUsrlist, pstCloudResUrl);

                if (pstCloudResUrl->pstStsUrlInfo)
                {
                    MOS_FREE(pstCloudResUrl->pstStsUrlInfo);
                    pstCloudResUrl->pstStsUrlInfo = MOS_NULL;
                }

                // 填入Pool中
                MOS_LIST_ADDTAIL(&CloudStg_ResGetMng()->stUrlPool, pstCloudResUrl);

                MOS_LOG_INF(CLOUDSTG_LOGSTR, "delete url node, available time: %u ~ %u, type: %u, left %d node", pstCloudResUrl->cPrvUrlTime, pstCloudResUrl->cUrlTime, pstUrlBucketNode->uiType, pstUrlBucketNode->stUsrlist.uiTotalCount);
            }
        }

        // bucket中没有节点了
        if(((Config_GetCloudMng()->iDirectMode != EN_CLOUDSTG_DIRECT_MODE_TYPE_STS && MOS_LIST_GETCOUNT(&pstUrlBucketNode->stUsrlist) <= CLOUDSTG_MIN_RES_NUM) ||
            (Config_GetCloudMng()->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS && MOS_LIST_GETCOUNT(&pstUrlBucketNode->stUsrlist) == 0)) &&
             CloudStg_ResGetMng()->uiStatus == 2)
        {
            CloudStg_ResGetMng()->cNextReqTime = Mos_Time();
            pstUrlBucketNode->uiOgctId = 0;
            CloudStg_ResGetMng()->uiStatus = 0;
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "pstUrlBucketNode->stUsrlist left %d, ready to request again", MOS_LIST_GETCOUNT(&pstUrlBucketNode->stUsrlist));
        }
        Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);

        // 摄像头休眠，不获取地址
        // 一段时间无喂狗，停止自动更新地址(事件云存)
        if ((pstIotNode == MOS_NULL) || (pstIotNode->uiOpenFlag == 0) || (CloudStg_GetMng()->iOpenFlag == 0) || 
            ((Config_GetCloudMng()->iCloudUpLoadMode == 1) && CloudStg_Res_IsWatchDogTimeout()))
        {
            return MOS_OK;
        }

        // 获取批量地址
        if(CloudStg_ResGetMng()->uiStatus == 0 && CloudStg_ResGetMng()->cNextReqTime <= cNowTime && Config_GetCloudMng()->iCloudAbility == 1)
        {
            if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "get url error, without network!");
                Config_GetCloudMng()->iAfterReqUrlFlag = 1;
                return MOS_OK;
            }

            if (pstUrlBucketNode->uiType == EN_CLOUDSTG_RESOURCE_STREAM)
            {
                // 检查云存任务是否需要连接url，防止云存任务的加密信息与res线程加密信息不同步
                if (MOS_LIST_GETCOUNT(&pstUrlBucketNode->stUsrlist) > 0 && 
                    (CloudStg_TaskNeedConnUrl(MOS_FALSE) || CloudStg_PatchTaskNeedConnUrl(MOS_FALSE)))
                {
                    CloudStg_ResGetMng()->cNextReqTime = cNowTime+2;//延迟更新url
                    MOS_LOG_WARN(CLOUDSTG_LOGSTR, "cloud task need url info!");
                    continue;
                }
                
                // 加密时才会重新生成加密信息
                if (Config_GetCloudMng()->iCloudEncSwitch == 1)
                {
                    MOS_LOG_WARN(CLOUDSTG_LOGSTR, "GenerateEncInfo Start!");
                    // 清除ResMng的url列表，重新生成config的加密信息
                    CloudStg_Res_GenerateEncInfo(MOS_FALSE);
                }
            }
            // 更新加密信息到res task；如果未加密只是为了更新switch开关
            CloudStg_Res_UpdateCloudEncInfo(pstUrlBucketNode);

            pstUrlBucketNode->uiOgctId = Mos_GetSessionId();
            CloudStg_ResGetMng()->cTimeReq = cNowTime;

            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "now start CloudStg_TransGetUrl, CloudStg_ResGetMng()->cTimeReq: %u, type: %d", CloudStg_ResGetMng()->cTimeReq, pstUrlBucketNode->uiType);
            iRet = CloudStg_TransGetUrl(pstUrlBucketNode,cNowTime);
            if(iRet == MOS_OK)
            {
                CloudStg_ResGetMng()->uiStatus = 1;
            }
            else
            {
                pstUrlBucketNode->uiOgctId = 0;
                CloudStg_ResGetMng()->cNextReqTime = CloudStg_Res_GetNextReqTime(cNowTime);
            }
        }

        // 请求timeout，重试
        else if( cNowTime - CloudStg_ResGetMng()->cTimeReq > 10 && CloudStg_ResGetMng()->uiStatus == 1)
        {
            Http_Httpclient_CancelAsyncRequestEx(pstUrlBucketNode->uiOgctId);
            pstUrlBucketNode->uiOgctId = 0;
            CloudStg_ResGetMng()->uiStatus = 0;
            CloudStg_ResGetMng()->uiRecvLen = 0;

            // FIXME: 获取地址重试时间
            CloudStg_ResGetMng()->cNextReqTime = CloudStg_Res_GetNextReqTime(cNowTime);
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cNowTime： %u, CloudStg_ResGetMng()->cTimeReq: %u\r\n", cNowTime, CloudStg_ResGetMng()->cTimeReq);
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"get cloud url fail,type: %d,try times %u,next try time %u,after %ds",pstUrlBucketNode->uiType,CloudStg_ResGetMng()->uiTryTime,CloudStg_ResGetMng()->cNextReqTime,CloudStg_ResGetMng()->cNextReqTime-cNowTime);
        }
    }
    return MOS_OK;
}
// 更新CloudStg_ResGetMng的加密信息
static _INT CloudStg_Res_UpdateCloudEncInfo(ST_CLOUDSTG_URLBUCKET_NODE *pstCloudBucketNode)
{
    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
    pstCloudBucketNode->iCloudEncSwitch = Config_GetCloudMng()->iCloudEncSwitch;
    MOS_STRCPY(pstCloudBucketNode->aucCloudEncHttpParamJson, Config_GetCloudMng()->aucCloudEncHttpParamJson);
    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);

    return MOS_OK;
}
_INT CloudStg_Res_NotifyGenerateEncInfo()
{
    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
    CloudStg_ResGetMng()->iForceGenerateEncInfo = 1;
    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    return MOS_OK;
}
_INT CloudStg_Res_GenerateEncInfo(_INT iForceFlag)
{
    static _INT iFirstFlag = MOS_TRUE;
    ST_CLOUDSTG_RES_URL  *pstCloudResUrl  = MOS_NULL;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator,stIterator2;
    _UC  *pucEnc        = MOS_NULL;
    _UC  *pucBase64Text = MOS_NULL;
    _UC  pucSrc[128]    = {0};
    _UC  aucJson[512]   = {0};
    _UC  aucDst[512]    = {0};
    _UC  aucURLEnc[512] = {0};
    _INT iEncLen        = 0;

    _UC  pucEncKey[33]  = {0};
    _UC  pucEncLv[17]   = {0};

    if (iForceFlag == MOS_FALSE)
    {
        if (iFirstFlag == MOS_TRUE )
        {
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "%s RES first not generate!", __FUNCTION__);
            iFirstFlag = MOS_FALSE;
            return MOS_ERR;
        }
    }

    // 清除所有地址
    CloudStg_Res_CleanAllUrl();

    // Create and save aes key, iv
    Adapt_GenerateString(pucEncKey, sizeof(pucEncKey));
    Adapt_GenerateString(pucEncLv, sizeof(pucEncLv));
    MOS_MEMSET(Config_GetCloudMng()->aucCloudEncAesKey, 0x00, sizeof(Config_GetCloudMng()->aucCloudEncAesKey));
    MOS_MEMSET(Config_GetCloudMng()->aucCloudEncAesIv, 0x00, sizeof(Config_GetCloudMng()->aucCloudEncAesIv));
    MOS_STRCPY(Config_GetCloudMng()->aucCloudEncAesKey, pucEncKey);
    MOS_STRCPY(Config_GetCloudMng()->aucCloudEncAesIv, pucEncLv);

    MOS_VSNPRINTF(pucSrc, sizeof(pucSrc), "%d:%s:%s", 1, pucEncKey, pucEncLv);

    pucEnc = MOS_MALLOC(256);

    // RSA
    Adpt_Public_Encrypt(ADPT_RSA_PKCS1_PADDING, Config_GetCloudMng()->aucCloudEncPKValue, pucSrc, strlen(pucSrc), pucEnc, 256, &iEncLen);

    // BASE64
    pucBase64Text = MOS_MALLOC((int)((float)iEncLen*(4/3.0)) + 8);

    Adpt_Base64_Enc(pucEnc, iEncLen, pucBase64Text);

    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
    // eem & x-amz-meta-vsec
    MOS_VSNPRINTF(aucJson,  sizeof(aucJson), "{\"vsec\":\"%d:%s\"}", Config_GetCloudMng()->iCloudEncPKId, pucBase64Text);
    CloudStg_URLEncode(aucJson, MOS_STRLEN(aucJson), aucURLEnc, sizeof(aucURLEnc));
    Config_SetCloudEncHttpParamJson(aucURLEnc);

    MOS_MEMSET(aucURLEnc, 0, sizeof(aucURLEnc));

    // videoCipher 
    MOS_VSNPRINTF(aucDst, sizeof(aucDst), "%d:%s", Config_GetCloudMng()->iCloudEncPKId, pucBase64Text);
    CloudStg_URLEncode(aucDst, MOS_STRLEN(aucDst), aucURLEnc, sizeof(aucURLEnc));
    Config_SetCloudEncHttpParam(aucURLEnc);

    // upload param 
    MOS_MEMSET(aucDst, 0x00, sizeof(aucDst));
    MOS_VSNPRINTF(aucDst, sizeof(aucDst), "%d:%s", Config_GetCloudMng()->iCloudEncPKId, pucBase64Text);
    Config_SetCloudEncHttpUploadParam(aucDst);
    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    // MOS_PRINTF("\r\n===========================CREATE CLOUD ENC===============================\r\n");
    // MOS_PRINTF("aucCloudEncAesKey: %s\r\naucCloudEncAesIv: %s\r\n", pucEncKey, pucEncLv);
    // MOS_PRINTF("Config_GetCloudMng()->aucCloudEncHttpParamJson: %s\r\n", Config_GetCloudMng()->aucCloudEncHttpParamJson);
    // MOS_PRINTF("Config_GetCloudMng()->aucCloudEncHttpParam: %s\r\n", Config_GetCloudMng()->aucCloudEncHttpParam);
    // MOS_PRINTF("Config_GetCloudMng()->aucCloudEncHttpUploadParam: %s\r\n", Config_GetCloudMng()->aucCloudEncHttpUploadParam);
    // MOS_PRINTF("\r\n============================================================\r\n");

    MOS_FREE(pucBase64Text);
    MOS_FREE(pucEnc);
    return MOS_OK;
}

_INT CloudStg_Res_EncryptUrlParse(ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode, JSON_HANDLE hDataObj)
{
    MOS_PARAM_NULL_RETERR(pstUrlBucketNode);
    MOS_PARAM_NULL_RETERR(hDataObj);

    _INT iDirectMode     = 0;
    _INT iProvinceId      = 0;
	_INT iSliceDuration   = 0;
	_INT iVideoDuration   = 0;
    _INT iIconValue       = 0;
    _INT iVideoValue      = 0;
    _INT iBucket          = 0;
    JSON_HANDLE hIconUrl   = MOS_NULL;
    JSON_HANDLE hVideoUrl  = MOS_NULL;
    JSON_HANDLE hIconArryItem  = MOS_NULL;
    JSON_HANDLE hVideoArryItem = MOS_NULL;
    _UC *pucRequestDate = MOS_NULL;

    _INT iStorageType = 0;
    _LLID llAuthorization = 0;
    _UC *pucStrTmp = MOS_NULL;
    _UC aucUrl[256] = {0};
    _INT i = 0, j = 0, k = 0, iValue = 0;
    _CTIME_T cNowTime = Mos_Time();
    JSON_HANDLE hUrlArry = MOS_NULL, hArryItem = MOS_NULL, hSubDataObj = MOS_NULL;
    ST_MOS_SYS_TIME stSysTime = { 0 };
    ST_CLOUDSTG_RES_URL *pstUrlNode = MOS_NULL;
    ST_CLOUDSTG_RES_URL *pstUrlNodeTmp = MOS_NULL;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNodeStream = MOS_NULL;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNodePic    = MOS_NULL;

    if (pstUrlBucketNode->uiType == EN_CLOUDSTG_RESOURCE_PIC)
    {
        pstUrlBucketNodeStream = CloudStg_Res_GetUrlBucketNodeFromType(EN_CLOUDSTG_RESOURCE_STREAM);
        pstUrlBucketNodePic    = pstUrlBucketNode;
    }
    else if (pstUrlBucketNode->uiType == EN_CLOUDSTG_RESOURCE_STREAM)
    {
        pstUrlBucketNodeStream = pstUrlBucketNode;
        pstUrlBucketNodePic    = CloudStg_Res_GetUrlBucketNodeFromType(EN_CLOUDSTG_RESOURCE_PIC);
    }
    
    if (pstUrlBucketNodeStream == MOS_NULL || pstUrlBucketNodePic == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "detect wrong UrlBucketNode, pstUrlBucketNodeStream: %p, pstUrlBucketNodePic: %p", pstUrlBucketNodeStream, pstUrlBucketNodePic);
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"directModel"), &iDirectMode);
    iDirectMode = iDirectMode==0?1:iDirectMode;
    
    if (Config_GetCloudMng()->iDirectMode != iDirectMode)
    {
        Config_GetCloudMng()->iDirectMode = iDirectMode;

        // 无地址的任务需要立马终止
        if (CloudStg_TaskNeedConnUrl(MOS_TRUE))
        {
            MOS_LOG_INF(CLOUDSTG_LOGSTR, "Now turn off all normal alive task");
            Cloudstg_CloseAllNormalAliveTask();
        }
        if (CloudStg_PatchTaskNeedConnUrl(MOS_TRUE))
        {
            MOS_LOG_INF(CLOUDSTG_LOGSTR, "Now turn off all patch alive task");
            Cloudstg_CloseAllPatchAliveTask();
        }
    }

    if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL)
    {
        hUrlArry = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"groupUploadUrls");

        iValue = Adpt_Json_GetArraySize(hUrlArry);
        if(iValue >= pstUrlBucketNode->uiResNum)
        {
            iValue = pstUrlBucketNode->uiResNum;
        }
        else if (iValue == 0)
        {
            MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETENCURL_ADDRESS);
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_GETENCURLS_VOID_ADDR, "CD get-EncryptUrls get void groupUploadUrls", 1);
        }
        for (i = 0; i < iValue; i++)
        {
            hArryItem = Adpt_Json_GetArrayItem(hUrlArry, i);

            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"requestDate"), &pucRequestDate);

            // 封面
            {
                hIconUrl  = Adpt_Json_GetObjectItem(hArryItem, (_UC*)"iconUrl");
                iIconValue = Adpt_Json_GetArraySize(hIconUrl);
                if(iIconValue >= 2)
                {
                    iIconValue = 2;
                }
                for (j = 0; j < iIconValue; j++)
                {
                    pstUrlNode = CloudStg_ResMallocUrlBuff();
                    if (pstUrlNode == MOS_NULL)
                    {
                        continue;
                    }
                    hIconArryItem = Adpt_Json_GetArrayItem(hIconUrl, j);

                    pstUrlNode->cPrvUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) - CLOUDSTG_GET_FIFTEENMINUTES;
                    pstUrlNode->cUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) + CLOUDSTG_GET_FIFTEENMINUTES;
                    MOS_STRLCPY(pstUrlNode->aucDate,pucRequestDate,sizeof(pstUrlNode->aucDate));

                    // MOS_PRINTF("[%d] url expire time: %u ~ %u\r\n", j, pstUrlNode->cPrvUrlTime, pstUrlNode->cUrlTime);
                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIconArryItem, (_UC*)"authorization"), &pucStrTmp);
                    MOS_STRLCPY(pstUrlNode->aucAuthorization, pucStrTmp, sizeof(pstUrlNode->aucAuthorization));

                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIconArryItem, (_UC*)"containerId"), &iBucket);
                    MOS_VSNPRINTF(pstUrlNode->aucBucket, sizeof(pstUrlNode->aucBucket), "%d", iBucket);

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIconArryItem, (_UC*)"exprise"), &pucStrTmp);

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIconArryItem, (_UC*)"objectId"), &pucStrTmp);
                    MOS_STRLCPY(pstUrlNode->aucFid, pucStrTmp, sizeof(pstUrlNode->aucFid));

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIconArryItem, (_UC*)"requestURL"), &pucStrTmp);
                    MOS_STRLCPY(pstUrlNode->aucUrl, pucStrTmp, sizeof(pstUrlNode->aucUrl));

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIconArryItem, (_UC*)"storageProvider"), &pucStrTmp);
                    MOS_STRLCPY(pstUrlNode->aucStorageProvider, pucStrTmp, sizeof(pstUrlNode->aucStorageProvider));

                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIconArryItem, (_UC*)"storageType"), &iStorageType);
                    pstUrlNode->iStorageType = iStorageType;

                    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
                    MOS_LIST_ADDTAIL(&pstUrlBucketNodePic->stUsrlist, pstUrlNode);
                    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                    MOS_LOG_INF(CLOUDSTG_LOGSTR, "UrlBucketNodePic has %d node now!", pstUrlBucketNodePic->stUsrlist.uiTotalCount);
                }
            }
            // 视频
            {
                hVideoUrl = Adpt_Json_GetObjectItem(hArryItem, (_UC*)"videoUrl");
                iVideoValue = Adpt_Json_GetArraySize(hVideoUrl);
                if(iVideoValue >= 2)
                {
                    iVideoValue = 2;
                }
                for (k = 0; k < iVideoValue; k++)
                {
                    pstUrlNode = CloudStg_ResMallocUrlBuff();
                    if (pstUrlNode == MOS_NULL)
                    {
                        continue;
                    }
                    hVideoArryItem = Adpt_Json_GetArrayItem(hVideoUrl, k);

                    pstUrlNode->cPrvUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) - CLOUDSTG_GET_FIFTEENMINUTES;
                    pstUrlNode->cUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) + CLOUDSTG_GET_FIFTEENMINUTES;
                    MOS_STRLCPY(pstUrlNode->aucDate,pucRequestDate,sizeof(pstUrlNode->aucDate));

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hVideoArryItem, (_UC*)"authorization"), &pucStrTmp);
                    MOS_STRLCPY(pstUrlNode->aucAuthorization, pucStrTmp, sizeof(pstUrlNode->aucAuthorization));

                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoArryItem, (_UC*)"containerId"), &iBucket);
                    MOS_VSNPRINTF(pstUrlNode->aucBucket, sizeof(pstUrlNode->aucBucket), "%d", iBucket);

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hVideoArryItem, (_UC*)"exprise"), &pucStrTmp);

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hVideoArryItem, (_UC*)"objectId"), &pucStrTmp);
                    MOS_STRLCPY(pstUrlNode->aucFid, pucStrTmp, sizeof(pstUrlNode->aucFid));

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hVideoArryItem, (_UC*)"requestURL"), &pucStrTmp);
                    MOS_STRLCPY(pstUrlNode->aucUrl, pucStrTmp, sizeof(pstUrlNode->aucUrl));

                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hVideoArryItem, (_UC*)"storageProvider"), &pucStrTmp);
                    MOS_STRLCPY(pstUrlNode->aucStorageProvider, pucStrTmp, sizeof(pstUrlNode->aucStorageProvider));

                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoArryItem, (_UC*)"storageType"), &iStorageType);
                    pstUrlNode->iStorageType = iStorageType;

                    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
                    MOS_LIST_ADDTAIL(&pstUrlBucketNodeStream->stUsrlist, pstUrlNode);
                    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                    MOS_LOG_INF(CLOUDSTG_LOGSTR, "UrlBucketNodeStream has %d node now!", pstUrlBucketNodeStream->stUsrlist.uiTotalCount);
                }
            }
        }
    }
    else if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"provinceId"), &iProvinceId);
        Config_GetCloudMng()->iProvinceId = iProvinceId;

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"sliceDuration"), &iSliceDuration);
        Config_GetCloudMng()->iSliceDuration = iSliceDuration;

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"videoDuration"), &iVideoDuration);
        Config_GetCloudMng()->iVideoDuration = iVideoDuration; 
        // Config_GetCloudMng()->iVideoDuration = 100; // TEST:

        hUrlArry = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"sliceList");
        iValue = Adpt_Json_GetArraySize(hUrlArry);
        if(iValue >= pstUrlBucketNode->uiResNum)
        {
            iValue = pstUrlBucketNode->uiResNum;
        }
        else if (iValue == 0)
        {
            MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETURL_ADDRESS);
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_GETURLS_VOID_ADDR, "CD getUrls get void groupUploadUrls", 1);
        }

        for (i = 0; i < iValue; i++)
        {
            hArryItem = Adpt_Json_GetArrayItem(hUrlArry, i);

            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"requestDate"), &pucRequestDate);
            // 封面
            {
                pstUrlNode = CloudStg_ResMallocUrlBuff();
                if (pstUrlNode == MOS_NULL)
                {
                    continue;
                }

                MOS_STRLCPY(pstUrlNode->aucDate,pucRequestDate,sizeof(pstUrlNode->aucDate));
                pstUrlNode->cPrvUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) - CLOUDSTG_GET_FIFTEENMINUTES;
                pstUrlNode->cUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) + CLOUDSTG_GET_FIFTEENMINUTES;

                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"cId"), &iBucket);
                MOS_VSNPRINTF(pstUrlNode->aucBucket, sizeof(pstUrlNode->aucBucket), "%d", iBucket);

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"iconObjectId"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucFid, pucStrTmp, sizeof(pstUrlNode->aucFid));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"iconURL"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucUrl, pucStrTmp, sizeof(pstUrlNode->aucUrl));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"SP"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucStorageProvider, pucStrTmp, sizeof(pstUrlNode->aucStorageProvider));

                pstUrlNode->iStorageType = 2;
                pstUrlNode->iUseContentLength = 1;

                Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LIST_ADDTAIL(&pstUrlBucketNodePic->stUsrlist, pstUrlNode);
                Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "UrlBucketNodePic has %d node now!", pstUrlBucketNodePic->stUsrlist.uiTotalCount);
            }
            // 视频
            {
                pstUrlNode = CloudStg_ResMallocUrlBuff();
                if (pstUrlNode == MOS_NULL)
                {
                    continue;
                }

                MOS_STRLCPY(pstUrlNode->aucDate,pucRequestDate,sizeof(pstUrlNode->aucDate));
                pstUrlNode->cPrvUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) - CLOUDSTG_GET_FIFTEENMINUTES;
                pstUrlNode->cUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) + CLOUDSTG_GET_FIFTEENMINUTES;

                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"cId"), &iBucket);
                MOS_VSNPRINTF(pstUrlNode->aucBucket, sizeof(pstUrlNode->aucBucket), "%d", iBucket);

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"videoObjectId"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucFid, pucStrTmp, sizeof(pstUrlNode->aucFid));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"videoURL"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucUrl, pucStrTmp, sizeof(pstUrlNode->aucUrl));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"SP"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucStorageProvider, pucStrTmp, sizeof(pstUrlNode->aucStorageProvider));

                pstUrlNode->iStorageType = 2;
                pstUrlNode->iUseContentLength = 1;

                Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LIST_ADDTAIL(&pstUrlBucketNodeStream->stUsrlist, pstUrlNode);
                Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "UrlBucketNodeStream has %d node now!", pstUrlBucketNodeStream->stUsrlist.uiTotalCount);
            }
        }
    }
    else if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
    {
        ST_CLOUDSTG_STS_URL stStsUrlInfo = {0};
        pstUrlNode = CloudStg_ResMallocUrlBuff();
        if (pstUrlNode == MOS_NULL)
        {
            return MOS_ERR;
        }
        pstUrlNodeTmp = CloudStg_ResMallocUrlBuff();
        if (pstUrlNodeTmp == MOS_NULL)
        {
            CloudStg_ResFreeUrl(pstUrlNode);
            return MOS_ERR;
        }
        hSubDataObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"uploadSTS");

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"sessionToken"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucSessionToken, pucStrTmp, sizeof(stStsUrlInfo.aucSessionToken));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"accessKeyId"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucAccessKeyId, pucStrTmp, sizeof(stStsUrlInfo.aucAccessKeyId));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"secretAccessKey"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucSecretAccessKey, pucStrTmp, sizeof(stStsUrlInfo.aucSecretAccessKey));

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"expiration"), &stStsUrlInfo.cExpiration);
        pstUrlNode->cUrlTime = stStsUrlInfo.cExpiration;

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"endpoint"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucEndpoint, pucStrTmp, sizeof(stStsUrlInfo.aucEndpoint));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"bktName"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucBktName, pucStrTmp, sizeof(stStsUrlInfo.aucBktName));

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"cId"), &stStsUrlInfo.iCid);
        MOS_VSNPRINTF(pstUrlNode->aucBucket, sizeof(pstUrlNode->aucBucket), "%d", stStsUrlInfo.iCid);

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"uploadPath"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucUploadPath, pucStrTmp, sizeof(stStsUrlInfo.aucUploadPath));

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"storageType"), &stStsUrlInfo.uiStorageType);
        pstUrlNode->iStorageType = stStsUrlInfo.uiStorageType;

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"x-amz-meta-upsec"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucX_amz_meta_upsec, pucStrTmp, sizeof(stStsUrlInfo.aucX_amz_meta_upsec));

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"x-amz-meta-commit"), &stStsUrlInfo.uiX_amz_meta_commit);

        MOS_MEMCPY(pstUrlNodeTmp, pstUrlNode, sizeof(ST_CLOUDSTG_RES_URL));
        if (pstUrlBucketNodeStream->stUsrlist.uiTotalCount == 0)
        {
            pstUrlNode->pstStsUrlInfo = (ST_CLOUDSTG_STS_URL *)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_STS_URL));
            MOS_MEMCPY(pstUrlNode->pstStsUrlInfo, &stStsUrlInfo, sizeof(ST_CLOUDSTG_STS_URL));
            Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
            MOS_LIST_ADDTAIL(&pstUrlBucketNodeStream->stUsrlist, pstUrlNode);
            Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
        }
        else
        {
            CloudStg_ResFreeUrl(pstUrlNode);
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "cloud sts mode ignore push url, type: %d", pstUrlBucketNodeStream->uiType);
        }

        if (pstUrlBucketNodePic->stUsrlist.uiTotalCount == 0)
        {
            pstUrlNodeTmp->pstStsUrlInfo = (ST_CLOUDSTG_STS_URL *)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_STS_URL));
            MOS_MEMCPY(pstUrlNodeTmp->pstStsUrlInfo, &stStsUrlInfo, sizeof(ST_CLOUDSTG_STS_URL));
            Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
            MOS_LIST_ADDTAIL(&pstUrlBucketNodePic->stUsrlist, pstUrlNodeTmp);
            Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
        }
        else
        {
            CloudStg_ResFreeUrl(pstUrlNodeTmp);
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "cloud sts mode ignore push url, type: %d", pstUrlBucketNodeStream->uiType);
        }
    }
    return MOS_OK;
}

_INT CloudStg_Res_NormalUrlParse(ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode, JSON_HANDLE hDataObj, _INT iDirectMode)
{
    MOS_PARAM_NULL_RETERR(pstUrlBucketNode);
    MOS_PARAM_NULL_RETERR(hDataObj);

    _INT iProvinceId      = 0;
	_INT iSliceDuration   = 0;
	_INT iVideoDuration   = 0;
    _INT iIconValue       = 0;
    _INT iVideoValue      = 0;
    _INT iBucket          = 0;
    JSON_HANDLE hIconUrl   = MOS_NULL;
    JSON_HANDLE hVideoUrl  = MOS_NULL;
    JSON_HANDLE hIconArryItem  = MOS_NULL;
    JSON_HANDLE hVideoArryItem = MOS_NULL;
    _UC *pucRequestDate = MOS_NULL;

    _INT iStorageType = 0;
    _LLID llAuthorization = 0;
    _UC *pucStrTmp = MOS_NULL;
    _UC aucUrl[256] = {0};
    _INT i = 0, j = 0, k = 0, iValue = 0;
    _CTIME_T cNowTime = Mos_Time();
    JSON_HANDLE hUrlArry = MOS_NULL, hArryItem = MOS_NULL, hSubDataObj = MOS_NULL;
    ST_MOS_SYS_TIME stSysTime = { 0 };
    ST_CLOUDSTG_RES_URL *pstUrlNode = MOS_NULL;
    ST_CLOUDSTG_RES_URL *pstUrlNodeTmp = MOS_NULL;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNodeStream = MOS_NULL;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNodePic    = MOS_NULL;

    if (pstUrlBucketNode->uiType == EN_CLOUDSTG_RESOURCE_PIC)
    {
        pstUrlBucketNodeStream = CloudStg_Res_GetUrlBucketNodeFromType(EN_CLOUDSTG_RESOURCE_STREAM);
        pstUrlBucketNodePic    = pstUrlBucketNode;
    }
    else if (pstUrlBucketNode->uiType == EN_CLOUDSTG_RESOURCE_STREAM)
    {
        pstUrlBucketNodeStream = pstUrlBucketNode;
        pstUrlBucketNodePic    = CloudStg_Res_GetUrlBucketNodeFromType(EN_CLOUDSTG_RESOURCE_PIC);
    }
    
    if (pstUrlBucketNodeStream == MOS_NULL || pstUrlBucketNodePic == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "detect wrong UrlBucketNode, pstUrlBucketNodeStream: %p, pstUrlBucketNodePic: %p", pstUrlBucketNodeStream, pstUrlBucketNodePic);
        return MOS_ERR;
    }

    // 直传流
    if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL)
    {
        hUrlArry = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"uploadFileList");
        iValue = Adpt_Json_GetArraySize(hUrlArry);
        if(iValue >= pstUrlBucketNode->uiResNum)
        {
            iValue = pstUrlBucketNode->uiResNum;
        }
        else if (iValue == 0)
        {
            MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETURL_ADDRESS);
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_GETURLS_VOID_ADDR, "CD getUrls get void groupUploadUrls", 1);
        }
        for (i = 0; i < iValue; i += 2)
        {
            // 封面
            {
                pstUrlNode = CloudStg_ResMallocUrlBuff();
                if (pstUrlNode == MOS_NULL)
                {
                    continue;
                }
                hArryItem = Adpt_Json_GetArrayItem(hUrlArry, i);
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"authorization"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucAuthorization, pucStrTmp, sizeof(pstUrlNode->aucAuthorization));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"exprise"), &pucStrTmp);

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"objectId"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucFid, pucStrTmp, sizeof(pstUrlNode->aucFid));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"requestDate"), &pucRequestDate);
                MOS_STRLCPY(pstUrlNode->aucDate,pucRequestDate,sizeof(pstUrlNode->aucDate));
                pstUrlNode->cPrvUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) - CLOUDSTG_GET_FIFTEENMINUTES;
                pstUrlNode->cUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) + CLOUDSTG_GET_FIFTEENMINUTES;
                
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"requestURL"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucUrl, pucStrTmp, sizeof(pstUrlNode->aucUrl));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"signature"), &pucStrTmp);

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"containerId"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucBucket, pucStrTmp, sizeof(pstUrlNode->aucBucket));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"storageProvider"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucStorageProvider, pucStrTmp, sizeof(pstUrlNode->aucStorageProvider));

                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"storageType"), &iStorageType);
                pstUrlNode->iStorageType = iStorageType;

                Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LIST_ADDTAIL(&pstUrlBucketNodePic->stUsrlist, pstUrlNode);
                Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "UrlBucketNodePic has %d node now!", pstUrlBucketNodePic->stUsrlist.uiTotalCount);
            }
            // 视频
            {
                pstUrlNode = CloudStg_ResMallocUrlBuff();
                if (pstUrlNode == MOS_NULL)
                {
                    continue;
                }
                hArryItem = Adpt_Json_GetArrayItem(hUrlArry, i+1);
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"authorization"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucAuthorization, pucStrTmp, sizeof(pstUrlNode->aucAuthorization));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"exprise"), &pucStrTmp);

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"objectId"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucFid, pucStrTmp, sizeof(pstUrlNode->aucFid));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"requestDate"), &pucRequestDate);
                MOS_STRLCPY(pstUrlNode->aucDate,pucRequestDate,sizeof(pstUrlNode->aucDate));
                pstUrlNode->cPrvUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) - CLOUDSTG_GET_FIFTEENMINUTES;
                pstUrlNode->cUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) + CLOUDSTG_GET_FIFTEENMINUTES;
                
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"requestURL"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucUrl, pucStrTmp, sizeof(pstUrlNode->aucUrl));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"signature"), &pucStrTmp);

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"containerId"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucBucket, pucStrTmp, sizeof(pstUrlNode->aucBucket));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"storageProvider"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucStorageProvider, pucStrTmp, sizeof(pstUrlNode->aucStorageProvider));

                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"storageType"), &iStorageType);
                pstUrlNode->iStorageType = iStorageType;

                Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LIST_ADDTAIL(&pstUrlBucketNodeStream->stUsrlist, pstUrlNode);
                Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "UrlBucketNodeStream has %d node now!", pstUrlBucketNodeStream->stUsrlist.uiTotalCount);
            }
        }
    }
    // 端切片
    else if (iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"provinceId"), &iProvinceId);
        Config_GetCloudMng()->iProvinceId = iProvinceId;

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"sliceDuration"), &iSliceDuration);
        Config_GetCloudMng()->iSliceDuration = iSliceDuration;

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"videoDuration"), &iVideoDuration);
        Config_GetCloudMng()->iVideoDuration = iVideoDuration; 
        // Config_GetCloudMng()->iVideoDuration = 100; // TEST:

        hUrlArry = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"uploadSlice");
        iValue = Adpt_Json_GetArraySize(hUrlArry);
        if(iValue >= pstUrlBucketNode->uiResNum)
        {
            iValue = pstUrlBucketNode->uiResNum;
        }
        else if (iValue == 0)
        {
            MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETURL_ADDRESS);
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_GETURLS_VOID_ADDR, "CD getUrls get void groupUploadUrls", 1);
        }

        for (i = 0; i < iValue; i++)
        {
            hArryItem = Adpt_Json_GetArrayItem(hUrlArry, i);

            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"requestDate"), &pucRequestDate);

            {
                pstUrlNode = CloudStg_ResMallocUrlBuff();
                if (pstUrlNode == MOS_NULL)
                {
                    continue;
                }

                MOS_STRLCPY(pstUrlNode->aucDate,pucRequestDate,sizeof(pstUrlNode->aucDate));
                pstUrlNode->cPrvUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) - CLOUDSTG_GET_FIFTEENMINUTES;
                pstUrlNode->cUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) + CLOUDSTG_GET_FIFTEENMINUTES;

                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"cId"), &iBucket);
                MOS_VSNPRINTF(pstUrlNode->aucBucket, sizeof(pstUrlNode->aucBucket), "%d", iBucket);

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"iconObjectId"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucFid, pucStrTmp, sizeof(pstUrlNode->aucFid));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"iconURL"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucUrl, pucStrTmp, sizeof(pstUrlNode->aucUrl));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"SP"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucStorageProvider, pucStrTmp, sizeof(pstUrlNode->aucStorageProvider));

                pstUrlNode->iStorageType = 2;
                pstUrlNode->iUseContentLength = 1;

                Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LIST_ADDTAIL(&pstUrlBucketNodePic->stUsrlist, pstUrlNode);
                Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "UrlBucketNodePic has %d node now!", pstUrlBucketNodePic->stUsrlist.uiTotalCount);
            }
            {
                pstUrlNode = CloudStg_ResMallocUrlBuff();
                if (pstUrlNode == MOS_NULL)
                {
                    continue;
                }

                MOS_STRLCPY(pstUrlNode->aucDate,pucRequestDate,sizeof(pstUrlNode->aucDate));
                pstUrlNode->cPrvUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) - CLOUDSTG_GET_FIFTEENMINUTES;
                pstUrlNode->cUrlTime = CloudStg_Res_RFC1123ToTimestamp(pucRequestDate) + CLOUDSTG_GET_FIFTEENMINUTES;

                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"cId"), &iBucket);
                MOS_VSNPRINTF(pstUrlNode->aucBucket, sizeof(pstUrlNode->aucBucket), "%d", iBucket);

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"videoObjectId"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucFid, pucStrTmp, sizeof(pstUrlNode->aucFid));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"videoURL"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucUrl, pucStrTmp, sizeof(pstUrlNode->aucUrl));

                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem, (_UC*)"SP"), &pucStrTmp);
                MOS_STRLCPY(pstUrlNode->aucStorageProvider, pucStrTmp, sizeof(pstUrlNode->aucStorageProvider));

                pstUrlNode->iStorageType = 2;
                pstUrlNode->iUseContentLength = 1;

                Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LIST_ADDTAIL(&pstUrlBucketNodeStream->stUsrlist, pstUrlNode);
                Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "UrlBucketNodeStream has %d node now!", pstUrlBucketNodeStream->stUsrlist.uiTotalCount);
            }
        }
    }
    else if(iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
    {
        ST_CLOUDSTG_STS_URL stStsUrlInfo = {0};
        pstUrlNode = CloudStg_ResMallocUrlBuff();
        if (pstUrlNode == MOS_NULL)
        {
            return MOS_ERR;
        }
        pstUrlNodeTmp = CloudStg_ResMallocUrlBuff();
        if (pstUrlNodeTmp == MOS_NULL)
        {
            CloudStg_ResFreeUrl(pstUrlNode);
            return MOS_ERR;
        }
        hSubDataObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"uploadSTS");

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"sessionToken"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucSessionToken, pucStrTmp, sizeof(stStsUrlInfo.aucSessionToken));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"accessKeyId"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucAccessKeyId, pucStrTmp, sizeof(stStsUrlInfo.aucAccessKeyId));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"secretAccessKey"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucSecretAccessKey, pucStrTmp, sizeof(stStsUrlInfo.aucSecretAccessKey));

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"expiration"), &stStsUrlInfo.cExpiration);
        // DEBUG:
        // pstUrlNode->cUrlTime = cNowTime + 60;
        pstUrlNode->cUrlTime = stStsUrlInfo.cExpiration;

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"endpoint"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucEndpoint, pucStrTmp, sizeof(stStsUrlInfo.aucEndpoint));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"bktName"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucBktName, pucStrTmp, sizeof(stStsUrlInfo.aucBktName));

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"cId"), &stStsUrlInfo.iCid);
        MOS_VSNPRINTF(pstUrlNode->aucBucket, sizeof(pstUrlNode->aucBucket), "%d", stStsUrlInfo.iCid);

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"uploadPath"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucUploadPath, pucStrTmp, sizeof(stStsUrlInfo.aucUploadPath));

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"storageType"), &stStsUrlInfo.uiStorageType);
        pstUrlNode->iStorageType = stStsUrlInfo.uiStorageType;

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"x-amz-meta-upsec"), &pucStrTmp);
        MOS_STRLCPY(stStsUrlInfo.aucX_amz_meta_upsec, pucStrTmp, sizeof(stStsUrlInfo.aucX_amz_meta_upsec));

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubDataObj, (_UC*)"x-amz-meta-commit"), &stStsUrlInfo.uiX_amz_meta_commit);
        
        MOS_MEMCPY(pstUrlNodeTmp, pstUrlNode, sizeof(ST_CLOUDSTG_RES_URL));
        if (pstUrlBucketNodeStream->stUsrlist.uiTotalCount == 0)
        {
            pstUrlNode->pstStsUrlInfo = (ST_CLOUDSTG_STS_URL *)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_STS_URL));
            MOS_MEMCPY(pstUrlNode->pstStsUrlInfo, &stStsUrlInfo, sizeof(ST_CLOUDSTG_STS_URL));
            Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
            MOS_LIST_ADDTAIL(&pstUrlBucketNodeStream->stUsrlist, pstUrlNode);
            Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
        }
        else
        {
            CloudStg_ResFreeUrl(pstUrlNode);
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "cloud sts mode ignore push url, type: %d", pstUrlBucketNodeStream->uiType);
        }

        if (pstUrlBucketNodePic->stUsrlist.uiTotalCount == 0)
        {
            pstUrlNodeTmp->pstStsUrlInfo = (ST_CLOUDSTG_STS_URL *)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_STS_URL));
            MOS_MEMCPY(pstUrlNodeTmp->pstStsUrlInfo, &stStsUrlInfo, sizeof(ST_CLOUDSTG_STS_URL));
            Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
            MOS_LIST_ADDTAIL(&pstUrlBucketNodePic->stUsrlist, pstUrlNodeTmp);
            Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
        }
        else
        {
            CloudStg_ResFreeUrl(pstUrlNodeTmp);
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "cloud sts mode ignore push url, type: %d", pstUrlBucketNodePic->uiType);
        }
    }

    return MOS_OK;
}

_INT CloudStg_Res_DataEncrypt(_UC *pucAesKey, _UC *pucAesIv, _UC *Data, _UI DataLen, _UC *OutputData)
{
    MOS_PARAM_NULL_RETERR(Data);
    _INT Len = 0;
    if (DataLen > 32)
    {
        Len = 32;
        Adpt_Aec_Encrypt256(pucAesKey, pucAesIv, Data, OutputData, Len);
        // kj_aes_encrypt_cbc(Data, &Len, OutputData, pucAesKey, pucAesIv, KJ_AES_NOPadding, KJ_AES_256);
        return 32;
    }
    else if (DataLen > 16 && DataLen < 32)
    {
        Len = 16;
        Adpt_Aec_Encrypt256(pucAesKey, pucAesIv, Data, OutputData, Len);
        // kj_aes_encrypt_cbc(Data, &Len, OutputData, pucAesKey, pucAesIv, KJ_AES_NOPadding, KJ_AES_256);
        return 16;
    }
    return 0;
}

_INT CloudStg_Res_GenStsAuthorization(ST_MECS_CONN* pstConn, _UC *pucAuthorization, _UI uiAuthorizationLen, _BOOL bIsPic)
{
    MOS_PARAM_NULL_RETERR(pstConn);
    MOS_PARAM_NULL_RETERR(pucAuthorization);
    ST_CLOUDSTG_RES_URL *pstUrlNode = (ST_CLOUDSTG_RES_URL *)pstConn->pstConnUrl;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
    _UC *pucSignBuff = MOS_NULL;
    _UC *pucBase64Text = MOS_NULL;
    _UC aucStringToSign[1024] = {0};
    _UC aucSignBuff[64] = {0};
    _UC aucHexSignBuff[64] = {0};
    _INT iLen = 0;

    pstTaskNode = CloudStg_FindTaskNode(pstConn->uiIsPatch, pstConn->iAliveTaskId);
    if (pstTaskNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"Can't find proper tasknode with parameters: %u, %d", 
                    pstConn->uiIsPatch, pstConn->iAliveTaskId);
        return MOS_ERR;
    }
    if (pstConn->iCloudEncSwitch == 1)
    {
        // 自动commit
        if (pstUrlNode->pstStsUrlInfo->uiX_amz_meta_commit != 0)
        {
            if (bIsPic)
            {
                MOS_VSNPRINTF(aucStringToSign, sizeof(aucStringToSign), "PUT\n\napplication/octet-stream\n%s\nx-amz-meta-vsec:%s\nx-amz-security-token:%s\n%s", 
                                pstUrlNode->aucDate,pstTaskNode->aucCloudEncHttpUploadParam, 
                                pstUrlNode->pstStsUrlInfo->aucSessionToken, pstConn->stSocket.aucSubUri);
            }
            else
            {
                MOS_VSNPRINTF(aucStringToSign, sizeof(aucStringToSign), "PUT\n\napplication/octet-stream\n%s\nx-amz-meta-commit:%d\nx-amz-meta-file:%s\nx-amz-meta-upsec:%s\nx-amz-meta-vsec:%s\nx-amz-security-token:%s\n%s", 
                                pstUrlNode->aucDate, pstUrlNode->pstStsUrlInfo->uiX_amz_meta_commit, 
                                pstUrlNode->pstStsUrlInfo->aucX_amz_meta_file, pstUrlNode->pstStsUrlInfo->aucX_amz_meta_upsec, 
                                pstTaskNode->aucCloudEncHttpUploadParam, 
                                pstUrlNode->pstStsUrlInfo->aucSessionToken, pstConn->stSocket.aucSubUri);
            }
        }
        else
        {
            MOS_VSNPRINTF(aucStringToSign, sizeof(aucStringToSign), "PUT\n\napplication/octet-stream\n%s\nx-amz-meta-vsec:%s\nx-amz-security-token:%s\n%s", 
                            pstUrlNode->aucDate,pstTaskNode->aucCloudEncHttpUploadParam, 
                            pstUrlNode->pstStsUrlInfo->aucSessionToken, pstConn->stSocket.aucSubUri);
        }
    }
    else
    {
        // 自动commit
        if (pstUrlNode->pstStsUrlInfo->uiX_amz_meta_commit != 0)
        {
            if (bIsPic)
            {
                MOS_VSNPRINTF(aucStringToSign, sizeof(aucStringToSign), "PUT\n\napplication/octet-stream\n%s\nx-amz-security-token:%s\n%s", 
                                pstUrlNode->aucDate,pstUrlNode->pstStsUrlInfo->aucSessionToken, pstConn->stSocket.aucSubUri);
            }
            else
            {
                MOS_VSNPRINTF(aucStringToSign, sizeof(aucStringToSign), "PUT\n\napplication/octet-stream\n%s\nx-amz-meta-commit:%d\nx-amz-meta-file:%s\nx-amz-meta-upsec:%s\nx-amz-security-token:%s\n%s", 
                                pstUrlNode->aucDate, pstUrlNode->pstStsUrlInfo->uiX_amz_meta_commit, 
                                pstUrlNode->pstStsUrlInfo->aucX_amz_meta_file, pstUrlNode->pstStsUrlInfo->aucX_amz_meta_upsec, 
                                pstUrlNode->pstStsUrlInfo->aucSessionToken, pstConn->stSocket.aucSubUri);
            }
        }
        else
        {
            MOS_VSNPRINTF(aucStringToSign, sizeof(aucStringToSign), "PUT\n\napplication/octet-stream\n%s\nx-amz-security-token:%s\n%s", 
                            pstUrlNode->aucDate,pstUrlNode->pstStsUrlInfo->aucSessionToken, pstConn->stSocket.aucSubUri);
        }
    }
    // MOS_PRINTF("StringToSign: %s\r\n", aucStringToSign);
    Adpt_HmacSha1_Encrypt(aucStringToSign, aucSignBuff, sizeof(aucSignBuff), pstUrlNode->pstStsUrlInfo->aucSecretAccessKey);
    // MOS_PRINTF("SignBuff: %s\r\n", aucSignBuff);

    iLen = 40;
    sagHexToBin(aucHexSignBuff, sizeof(aucHexSignBuff), aucSignBuff, iLen);
    iLen = iLen / 2;
    pucBase64Text = MOS_MALLOC((int)((float)iLen*(4/3.0)) + 8);
    Adpt_Base64_Enc(aucHexSignBuff, iLen, pucBase64Text);

    MOS_VSNPRINTF(pucAuthorization, uiAuthorizationLen, "AWS %s:%s", pstUrlNode->pstStsUrlInfo->aucAccessKeyId, pucBase64Text);
    // MOS_PRINTF("Authorization: %s\r\n", pucAuthorization);
    
    return MOS_OK;
}

_CTIME_T CloudStg_Res_RFC1123ToTimestamp(_UC* ucRFC1123)
{
    _INT i = 0;
    _CTIME_T tTimestamp       = 0;
    _CTIME_T tNowTimestamp    = Mos_Time();
    ST_MOS_SYS_TIME stSysTime = {0};
    _UC ucMonth[4]  = {0};
    _UC* months[12] = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    };

    if (ucRFC1123 == MOS_NULL)
    {
        return tNowTimestamp;
    }

    // 解析RFC1123时间
    Mos_GetSysTime(&stSysTime);
    sscanf(ucRFC1123, "%*[a-zA-Z,] %d %3s %d %d:%d:%d",
	   &stSysTime.usDay, ucMonth, &stSysTime.usYear,
	   &stSysTime.usHour, &stSysTime.usMinute, &stSysTime.usSecond);
    for (i = 0; i < 12; i++) 
    {
        if (strncmp(ucMonth, months[i], 3) == 0) 
        {
            stSysTime.usMonth = i + 1;
            break;
        }
    }
    
    // UTC转成北京时间
    stSysTime.usHour += 8;
    tTimestamp = Mos_SysTimetoTime(&stSysTime);

    // 防止解析为异常值
    if (tTimestamp + 5 < tNowTimestamp)
    {
        tTimestamp = tNowTimestamp;
    }
    return tTimestamp;
}

_INT CloudStg_Res_CleanAllUrl()
{
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;
    ST_CLOUDSTG_RES_URL *pstCloudResUrl = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator,stIterator2;
    // 清除原来的key对应的url
    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode, stIterator)
    {
        Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
        FOR_EACHDATA_INLIST(&pstUrlBucketNode->stUsrlist,pstCloudResUrl,stIterator2)
        {
            // 从bucket中删除节点
            MOS_LIST_RMVNODE(&pstUrlBucketNode->stUsrlist, pstCloudResUrl);
            if (pstCloudResUrl->pstStsUrlInfo)
            {
                MOS_FREE(pstCloudResUrl->pstStsUrlInfo);
                pstCloudResUrl->pstStsUrlInfo = MOS_NULL;
            }
            // 填入Pool中
            MOS_LIST_ADDTAIL(&CloudStg_ResGetMng()->stUrlPool, pstCloudResUrl);
        }
        Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "All cloud urls have been released!");
    return MOS_OK;
}

_CTIME_T CloudStg_Res_GetNextReqTime(_CTIME_T cNowTime)
{
    _INT iDelaySecond = 0;
    switch (CloudStg_ResGetMng()->uiTryTime)
    {
        // 3-5s
        case 0:
        {
            iDelaySecond = rand() % 3 + 3;
        }
        break;
        // 5-10s
        case 1:
        {
            iDelaySecond = rand() % 6 + 5;
        }
        break;
        // 10-30s
        case 2:
        {
            iDelaySecond = rand() % 21 + 10;
        }
        break;
        // 30-60s
        default:
        {
            iDelaySecond = rand() % 31 + 30;
        }
        break;
    }
    MOS_PRINTF("CloudStg_Res_GetNextReqTime tryTime: %d, iDelaySecond: %d, nextReqTime: %u\r\n", CloudStg_ResGetMng()->uiTryTime, iDelaySecond, cNowTime + iDelaySecond);
    CloudStg_ResGetMng()->uiTryTime++;
    return cNowTime + iDelaySecond;
}

ST_CLOUDSTG_URLBUCKET_NODE *CloudStg_Res_GetUrlBucketNodeFromType(_UI uiType)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&CloudStg_ResGetMng()->stUrlBucketkList, pstUrlBucketNode, stIterator)
    {
        if(pstUrlBucketNode->uiType == uiType)
        {
           break;
        }
    }
    return pstUrlBucketNode;
}

_VOID CloudStg_Res_FeedWatchDog()
{
    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
    getDiffTimems(&CloudStg_ResGetMng()->tWatchDogTimer, 1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    // MOS_PRINTF("%s refresh watchdog %u\r\n", __FUNCTION__, Mos_Time());
}

_BOOL CloudStg_Res_IsWatchDogTimeout()
{
    static _INT iCount = 0;
    _BOOL bRet = MOS_FALSE;
    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
    bRet = (getDiffTimems(&CloudStg_ResGetMng()->tWatchDogTimer,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= (Config_GetCloudMng()->iUrlTimerInterval*60))?MOS_TRUE:MOS_FALSE;
    // printf("Config_GetCloudMng()->iUrlTimerInterval*60: %d\r\n", Config_GetCloudMng()->iUrlTimerInterval*60);
    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);

    if (bRet == MOS_TRUE && (++iCount % 20 == 0))
    {
        iCount = 0;
        MOS_PRINTF("%s watchdog timeout !!!%u\r\n", __FUNCTION__, Mos_Time());
    }
    return bRet;
}

static _INT CloudStg_Res_Loop(_VPTR pstParm)
{
    while(CloudStg_ResGetMng()->ucRunFlag)
    {
        CloudStg_Res_ProcUrl();
        Mos_Sleep(500);
    }
    return MOS_OK;
}
