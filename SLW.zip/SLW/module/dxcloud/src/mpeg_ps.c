#include "mos.h"
#include "zj_type.h"
#include "mpeg_ps.h"

//#define MPEG_DEBUG
#define MPEG_INVALID_TIMESTAMP	(0xFFFFFFFF)

/****************************************************************************
* timestamp list NK_Interfaces
****************************************************************************/

/**
 * 检测系统是否为小端模式。
 * 小端模式返回 True，大端模式返回 False。
 */
static inline int NK_IS_LITTLE_END()
{
	union{
    	   _UI dword;
    	   _UC bytes[4];
	} un;

	un.dword = 0x12345678;
	return (0x78 == un.bytes[0]);
}

ST_MOS_LIST stPsMuxerList;  // 巡航位

/**
 * 16 位大小端转换。
 */
#define NK_SWAP16(__v)  ((((_US)(__v) & 0xff00) >> 8) | (((_US)(__v) & 0x00ff) << 8))

/**
 * 32 位大小端转换。
 */
#define NK_SWAP32(__v)  ((((_UI)(__v) & 0xff000000) >> 24) |\
                            (((_UI)(__v) & 0x00ff0000) >> 8) |\
                            (((_UI)(__v) & 0x0000ff00) << 8) |\
                            (((_UI)(__v) & 0x000000ff) << 24))

/**
 * 64 位大小端转换。
 */
#define Swap64(__v) (((__v) >> 56) |\
						(((__v) & 0x00ff000000000000) >> 40) |\
						(((__v) & 0x0000ff0000000000) >> 24) |\
						(((__v) & 0x000000ff00000000) >> 8)	  |\
						(((__v) & 0x00000000ff000000) << 8)	  |\
						(((__v) & 0x0000000000ff0000) << 24) |\
						(((__v) & 0x000000000000ff00) << 40) |\
						(((__v) << 56)))


/**
 * 2 字节数据实现本地序到网络序的转换。
 */
static inline _US NK_HTON16(_US h)
{
	/// 若本机为大端，与网络字节序同，直接返回
	/// 若本机为小端，转换成大端再返回
	return NK_IS_LITTLE_END() ? NK_SWAP16(h) : h;
}

/**
 * 4 字节数据实现本地序到网络序的转换。
 */
static inline _UI NK_HTON32(_UI h)
{
	/// 若本机为大端，与网络字节序同，直接返回
	/// 若本机为小端，转换成大端再返回
	return NK_IS_LITTLE_END() ? NK_SWAP32(h) : h;
}

/**
 * 8 字节数据实现本地序到网络序的转换。
 */
static inline _UI NK_HTON64(unsigned long h)
{
	/// 若本机为大端，与网络字节序同，直接返回
	/// 若本机为小端，转换成大端再返回
	return NK_IS_LITTLE_END() ? NK_SWAP32(h) : h;
}


_INT mpeg_ts_list_init(TimestampList_t **tsl)
{
	*tsl = (TimestampList_t *)malloc(sizeof(TimestampList_t));
	if(*tsl == NULL){
		printf("TS-LIST-ERR: malloc failed!\r\n");
		return -1;
	}
	(*tsl)->next = NULL;
	(*tsl)->tail = *tsl;
	(*tsl)->data.size = 0;
	printf("TS-LIST-INFO: init ok!\r\n");
	return 0;
}

_INT mpeg_ts_list_destroy(TimestampList_t *tsl)
{
	
	TimestampNode_t *p=tsl->next,*q=tsl;
	while(q){
		free(q);
		q = p;
		if(p) p = p->next;
		else p = NULL;
	}
	printf("TS-LIST-INFO: destroy ok!\r\n");
	return 0;
}


_INT mpeg_ts_list_push(TimestampList_t *tsl,_UI timestamp,_UI size)
{
	TimestampNode_t *p;
	p = (TimestampNode_t *)malloc(sizeof(TimestampNode_t));
	if(p == NULL){
		printf("TS-LIST-ERR: malloc failed!\r\n");
		return -1;
	}
	p->next = NULL;
	p->tail = NULL;
	p->data.flag = MOS_TRUE;
	p->data.size = size;
	p->data.timestamp = timestamp;

	tsl->tail->next = p;
	tsl->data.size ++;
	//
	tsl->tail = p;
#ifdef MPEG_DEBUG
	printf("TS-LIST-INFO: push %u(size:%u) ok!\r\n",timestamp,size);
#endif
	return 0;
}

_INT mpeg_ts_list_pull(TimestampList_t *tsl,_UI ss,_UI * const out_ts)
{
	TimestampNode_t *p=tsl->next,*q=tsl;
	*out_ts = MPEG_INVALID_TIMESTAMP;
	while(p && (ss > 0)){
		if(p->data.flag){
			*out_ts = p->data.timestamp;
			p->data.flag = MOS_FALSE;
		}
		if(p->data.size > ss){
			p->data.size -= ss;
			ss = 0;
		}else if(p->data.size == ss){
			p->data.size -= ss;
			ss = 0;
			// delete this node
			if(p->next == NULL) tsl->tail = q;
			tsl->data.size --;
			q->next = p->next;
			free(p);
			//
			//q = p;
			p = q->next;
		}else{
			ss -= p->data.size;
			p->data.size = 0;
			//delete this node
			if(p->next == NULL) tsl->tail = q;
			tsl->data.size --;
			q->next = p->next;
			free(p);
			//
			//q = p;
			p = q->next;
		}
	}
	if(ss == 0){
#ifdef MPEG_DEBUG
		printf("TS-LIST-INFO: pull %u(%x) ok!\r\n",*out_ts,*out_ts);
#endif
		return 0;
	}else{
		printf("TS-LIST-ERR: pull fail!\r\n");
		return -1;
	}
}

/****************************************************************************
* mpeg2 NK_Interfaces
****************************************************************************/
static _UI mpeg_do_crc32(_VOID* data, _INT data_sz)
{
	_UI i = 0;
	_UI* data_32 = data;
	_UI data_sz_32 = data_sz / sizeof(_UI);
	_UI const crc32_origin = 0xfefeef11;
	_UI crc32_result = crc32_origin;
	for(i = 0; i < data_sz_32; ++i){
		crc32_result ^= data_32[i];
	}
	return crc32_result;
}

inline _UI mpeg_compute_program_mute_rate(_UI vr,_UI ar)
{
	double ret=sizeof(MpegPesHeader_t)+sizeof(MpegStreamSpecs_t)*2+
		(double)((double)sizeof(MpegPsHeader_t)+(double)sizeof(MpegPsSystemHeader_t)*MPEG_PES_PACKETS_PER_PS/MPEG_PS_SYSTEM_HEADER_PERIOD)/MPEG_PES_PACKETS_PER_PS;
	ret = ret/MPEG_PS_SPLIT_SIZE;
	ret = (double)(vr+ar)*(ret + 1);
	return (_UI)ret;
}

#ifdef MPEG_FAST_MODE
static _INT mpeg_psm_pack(_UC *out,_UI *ret_size)
{
	_UC pack[30]={
		0x00,0x00,0x01,0xBC,
		0x00,0x18,0xE1,0xFF,
		0x00,0x00,
		0x00,0x0E,	
		//element_info
		//h264
		0x1B,0xE0,0x00,0x06,
		//avc timming and hrd descriptor
		0x0a,0x04,0x65,0x6e,0x67,0x00,
		// audio
		0x90,0xc0,0x00,0x00,
		0x23,0xb9,0x0f,0x3d,
	};
	memcpy(out,pack,30);
	*ret_size = 30;
	return 0;
}

static _INT mpeg_system_header_pack(_UC *out,_UI *ret_size)
{	
	_UC pack[18]={
		0x00,0x00,0x01,0xBB,
		0x00,0x0C,
		0x80,0x1E,0xFF,0xFE,0xE1,0x7F,
		0xE0,0xE0,0xD8,
		0xC0,0xC0,0x20,  
	};
	memcpy(out,pack,18);
    *ret_size = 18;  
	return 0;
}

static _INT mpeg_ps_header_pack(_UC *out,_UI *ret_size,_UI ts,_UI mute_rate)
{
	_UC pack[16]={
		0x00,0x00,0x01,0xBA,
		0x00,0x00,0x00,0x00,0x03,0x01,
		0xff,0xfF,0xff,
		0xFA,0xFF,0xFF,
	};
	char temp = 0x00;
	ts = ts*90;
	
	pack[4]=((0x38&(ts>>26))|0x44);
	pack[4]=(pack[4]|((ts>>28)&0x03));
				
	pack[5]=((ts>>20)&(0xFF));
	temp = ((ts>>12)&(0xF8));
	pack[6]=(temp|0x04|((ts>>13)&0x03));
				
	pack[7]=((ts>>5)&(0xFF));
	temp=((((ts & 0x1f)<<3)&0xf8)|0x04);
				
	pack[10]=(mute_rate>>14)&0xff;
	pack[11]=(mute_rate>>6)&0xff;
	pack[12]=(((mute_rate<<2)&0xfc)|0x03);

	memcpy(out,pack,16);
	*ret_size = 16;
				
	return 0;
}

static _INT mpeg_pes_pack(_UC * src,_UI in_size,
	_UI timestamp/*ms*/,_UC type,
	_UC *out,_UI *ret_size)
{
	_UC pack[19]={
		0x00,0x00,0x01,0xFF,
		0x00,0x00,
		0x88,0x80,0x05,
		0x21,0x00,0x01,0x00,0x01
	};
	_INT iLen = 0;
	timestamp = timestamp*90;
	
	pack[3] = type;
	//PES length	
	iLen = 8 + in_size;
	pack[4] = (iLen >> 8) & 0xFF;
	pack[5] = iLen & 0xFF;
	
	pack[9]=((0x0E&(timestamp>>29))|0x31);
	pack[10] = ((timestamp>>22)&(0xFF));
	pack[11]=(((timestamp>>14)&(0xFE))|0x01);
	pack[12]=((timestamp>>7)&(0xFF));
	pack[13] = (((timestamp<<1)&0xFE)|0x01);
	
	iLen = 14;
	memcpy(out,pack,iLen);
	memcpy(out + iLen , src , in_size);

	*ret_size = iLen + in_size;
	return 0;
}

#else

_INT mpeg_psm_pack(_UC *out,_UI *ret_size, _UC type)
{
	_UC *ptr=out;
	_UI crc;
	MpegPsMap_t psm,*p_psm;
	MpegEsMapInfo_t mvinfo,mainfo;
	p_psm = (MpegPsMap_t *)&psm;

	p_psm->pack_start_code[0]=0;
	p_psm->pack_start_code[1]=0;
	p_psm->pack_start_code[2]=1;
	p_psm->map_stream_id = MPEG_PROGRAM_STREAM_MAP;
	p_psm->map_length = NK_HTON16(sizeof(MpegPsMap_t) - 6 +4 + sizeof(MpegEsMapInfo_t)*2);
	p_psm->program_steam_map_version = 1;
	p_psm->reserved1 = 3;
	p_psm->current_next_indicator = 1;
	p_psm->marker_bit = 1;
	p_psm->reserved2=0x7f;
	p_psm->program_stream_info_length = 0;
	p_psm->elementary_stream_map_length = NK_HTON16(sizeof(MpegEsMapInfo_t)*2);
	memcpy(ptr,p_psm,sizeof(MpegPsMap_t));
	ptr+=sizeof(MpegPsMap_t);
	//
	mvinfo.stream_type = type;//H.265:0x24 H.264:0x1B;
	mvinfo.es_id = MPEG_DEFAULT_VIDEO_STREAM;
	mvinfo.es_info_len = 0;
	memcpy(ptr,&mvinfo,sizeof(MpegEsMapInfo_t));
	ptr+=sizeof(MpegEsMapInfo_t);
	//
	mainfo.stream_type=0x90;
	mainfo.es_id = MPEG_DEFAULT_AUDIO_STREAM;
	mainfo.es_info_len = 0;
	memcpy(ptr,&mainfo,sizeof(MpegEsMapInfo_t));
	ptr+=sizeof(MpegEsMapInfo_t);
	//crc
	//ptr[0]=0xff;
	//ptr[1]=0xff;
	//ptr[2]=0xff;
	//ptr[3]=0xff;
	crc=mpeg_do_crc32(out,ptr-out);
	memcpy(ptr,&crc,sizeof(crc));
	ptr+=4;
	
	*ret_size = ptr-out;
	return 0;
}

_INT mpeg_system_header_pack(_UC *out,_UI *ret_size)
{	
	_UC *ptr = out;
	MpegPsSystemHeader_t m_system,*p_sys=NULL;
	MpegStreamSpecs_t m_stream,*p_stream=NULL;
	_UI rate_bound = 3967;

	p_sys = (MpegPsSystemHeader_t *)&m_system;
	p_sys->system_start_code[0] = 0;
	p_sys->system_start_code[1] = 0;
	p_sys->system_start_code[2] = 1;
	p_sys->system_start_code[3] = 0xBB;
	MPEG_SYS_SET_RATE_BOUND(p_sys,rate_bound);
	MPEG_SYS_SET_MARKERBIT(p_sys);
	p_sys->header_length = NK_HTON16(sizeof(MpegPsSystemHeader_t)-6+sizeof(MpegStreamSpecs_t)*2+2/*to algin 32bits*/);
	p_sys->audio_bound = 63;
	p_sys->video_bound = 31;
	p_sys->fixed_flag = 1;
	p_sys->system_audio_lock_flag = 1;
	p_sys->system_video_lock_flag = 1;
	p_sys->csps_flag = 0;
	p_sys->reserved = 0x3f;
	p_sys->pack_rate_restriction_flag = 0;

	memcpy(ptr,p_sys,sizeof(MpegPsSystemHeader_t));
	ptr += sizeof(MpegPsSystemHeader_t);
	// setup video stream spec
	p_stream = (MpegStreamSpecs_t *)&m_stream;
	p_stream->stream_id = MPEG_DEFAULT_VIDEO_STREAM;
	p_stream->fix_bits = 3;
	p_stream->p_std_buffer_bound_scale = 1;
	MPEG_STREAM_SET_SIZEBOUND(p_stream,0xD8);
	memcpy(ptr,p_stream,sizeof(MpegStreamSpecs_t));
	ptr += sizeof(MpegStreamSpecs_t);
	// setup audio stream here....
	//
	p_stream->stream_id = MPEG_DEFAULT_AUDIO_STREAM;
	p_stream->p_std_buffer_bound_scale = 0;
	MPEG_STREAM_SET_SIZEBOUND(p_stream,0x20);
	memcpy(ptr,p_stream,sizeof(MpegStreamSpecs_t));
	ptr += sizeof(MpegStreamSpecs_t);

	//padding 2bytes
	ptr[0]=0xff;
	ptr[1]=0xff;
	ptr+=2;

	*ret_size = ptr - out;
#ifdef MPEG_DEBUG
	printf("MPEG-INFO: pack system header ok,size:%d scr:%u\r\n",*ret_size);
#endif
	return 0;
}

_INT mpeg_ps_header_pack(_UC *out,_UI *ret_size,_UI ts,_UI mux_rate)
{
	_UC *ptr = out;
	MpegPsHeader_t m_ps,*p_ps=NULL;
	unsigned long scr_base = ts;
	unsigned long scr_ext = 0;

	// setup ps header
	p_ps = (MpegPsHeader_t *)&m_ps;
	p_ps->pack_start_code[0] = 0;
	p_ps->pack_start_code[1] = 0;
	p_ps->pack_start_code[2] = 1;
	p_ps->pack_start_code[3] = 0xBA;
	MPEGPS_SET_MARKER_BIT(p_ps);
	MPEGPS_SET_SCR_BASE(p_ps,scr_base);
	MPEGPS_SET_SCR_EXT(p_ps,scr_ext);
	MPEGPS_SET_MUX_RATE(p_ps,mux_rate);
	p_ps->reserved = 0x1f ;
	p_ps->pack_stuffing_length = 2;
	memcpy(ptr,p_ps,sizeof(MpegPsHeader_t));
	ptr += sizeof(MpegPsHeader_t);
	ptr[0]= 0xff;
	ptr[1]= 0xff;
	ptr+=2;

	*ret_size = ptr - out;
#ifdef MPEG_DEBUG
	printf("MPEG-INFO: pack ps header ok,size:%d scr:%u\r\n",*ret_size,ts);
#endif
	return 0;

}

_INT mpeg_pes_pack_ex(_UC * src,_UI in_size,
	_UI timestamp/*ms*/,_UC type,
	_UC *out,_UI *ret_size, _UI externFlag, unsigned char aucPesPriData[16])
{
	_UC *ptr = out;
	MpegPesHeader_t m_pes = {0};
	MpegPesPtsDts_t m_ts,*p_ts =NULL;
    MpegPesExtention m_pex_ext;
	_UI iTS = timestamp;
	_INT pts_dts_type  = 2;
	_INT pts_dts_size = 5;
	_INT header_padding = 0;
	_INT i;

	if(type == MPEG_DEFAULT_VIDEO_STREAM){
		pts_dts_type = 2;
		pts_dts_size = 5;//10;
	}
    else{
		pts_dts_type = 2;
		pts_dts_size = 5;
	}
	header_padding = (sizeof(MpegPesHeader_t)+((timestamp != MPEG_INVALID_TIMESTAMP) ? pts_dts_size : 0) +3)/4*4-sizeof(MpegPesHeader_t);

	// setup pes header
	m_pes.pack_start_code_prefix[0] = 0;
	m_pes.pack_start_code_prefix[1] = 0;
	m_pes.pack_start_code_prefix[2] = 1;
	m_pes.stream_id = type;
	if(in_size <= 64*1000){
		m_pes.pes_packet_length = NK_HTON16(in_size + 3 + ((timestamp != MPEG_INVALID_TIMESTAMP) ? pts_dts_size : 0)+header_padding);
	}else
		m_pes.pes_packet_length = 0;
	//
	m_pes.fix_bit = 2;
	m_pes.PES_scrambling_control = 0;
	m_pes.PES_priority = 1;
	m_pes.data_alignment_indicator = 0;
	m_pes.copyright = 0;
	m_pes.original_or_copy = 0;
	//
	m_pes.ESCR_flag = 0;
	m_pes.ES_rate_flag = 0;
	m_pes.DSM_trick_mode_flag= 0;
	m_pes.additional_copy_info_flag = 0;
	m_pes.PES_CRC_flag= 0;
	
	if(timestamp != MPEG_INVALID_TIMESTAMP){
		m_pes.PTS_DTS_flags = pts_dts_type;
		m_pes.PES_header_data_length = pts_dts_size+header_padding;
	}else{
		m_pes.PTS_DTS_flags = 0;
		m_pes.PES_header_data_length = header_padding;
	}
	//
	memcpy(ptr,&m_pes,sizeof(MpegPesHeader_t));
	ptr += sizeof(MpegPesHeader_t);
	//// setup pts & dts
	if(timestamp != MPEG_INVALID_TIMESTAMP){
		if(pts_dts_size == 10){
			// pts
			p_ts = (MpegPesPtsDts_t *)&m_ts;
			MPEG_SET_PTS_DTS(p_ts,iTS+33*90);
			p_ts->fix_bits = 2;
			memcpy(ptr,p_ts,sizeof(MpegPesPtsDts_t));
			ptr += sizeof(MpegPesPtsDts_t);
			// setup dts		
			p_ts = (MpegPesPtsDts_t *)&m_ts;
			MPEG_SET_PTS_DTS(p_ts,iTS);
			p_ts->fix_bits = 3;
			memcpy(ptr,p_ts,sizeof(MpegPesPtsDts_t));
			ptr += sizeof(MpegPesPtsDts_t);
		}else{
			// pts
			p_ts = (MpegPesPtsDts_t *)&m_ts;
			MPEG_SET_PTS_DTS(p_ts,iTS);
			p_ts->fix_bits = 2;
			memcpy(ptr,p_ts,sizeof(MpegPesPtsDts_t));
			ptr += sizeof(MpegPesPtsDts_t);
		}
	}

    if (externFlag)
    {
        m_pes.PES_extension_flag = 1;
        if (m_pes.PES_extension_flag)
        {
            m_pex_ext.PES_private_data_flag = 1;
            m_pex_ext.pack_header_field_flag = 0;
            m_pex_ext.program_packet_sequence_counter_flag = 0;
            m_pex_ext.P_STD_buffer_flag = 0;
            m_pex_ext.PES_extension_flag_2 = 0;
            if (m_pex_ext.P_STD_buffer_flag)
            {
                MOS_MEMCPY(m_pex_ext.PES_private_data, aucPesPriData, 16);
            }
            memcpy(ptr,&m_pex_ext,sizeof(MpegPesExtention));
            ptr += sizeof(MpegPesExtention);
        }   
    }
    else
    {
	    m_pes.PES_extension_flag = 0;
    }
    
	//
	for(i=0;i<header_padding;i++){
		*ptr=0xff;
		ptr++;
	}
	//
	// setup data source
	//memcpy(ptr,src,in_size);
	//ptr += in_size;

	*ret_size = (ptr-out);
#ifdef MPEG_DEBUG
	printf("MPEG-INFO: pack pes ok,size:%d timestamp:%u\r\n",*ret_size,(timestamp==MPEG_INVALID_TIMESTAMP) ? 0 : timestamp);
#endif
	return 0;
}

_INT mpeg_pes_pack(_UC * src,_UI in_size,
	_UI timestamp/*ms*/,_UC type,
	_UC *out,_UI *ret_size)
{
	return mpeg_pes_pack_ex(src, in_size, timestamp, type, out, ret_size, 0, MOS_NULL);
}
#endif

int ps_add_ext_header(char *psheader)
{
	int total_len = 4;
	if (psheader == NULL)
		return -1;
	psheader[0] = 0x49;
	psheader[1] = 0x4D;
	psheader[2] = 0x4B;
	psheader[3] = 0x48;
	return total_len;
}


_INT MPEG_muxer_video(_UC *src,_UI in_size,
	_UI ts,_UC stream_type,_UC type,_INT isidr,
	_UC *out,
	_UI *ret_size)
{
	
	_INT i=0;
	_UI size,pes_size;
	//NK_UInt32 mux_rate = 8*1024*1024/8/50;//6150;
	_UI mux_rate = 6150;
	_UC *ptr = out;
	_UC *psrc = src;
//	NK_UInt8 ext_frame[8]={0,0,0,1,0x09,0x30,0,0};

	mpeg_ps_header_pack(ptr,&size,ts,mux_rate);
	ptr += size;
	if(isidr){
		mpeg_system_header_pack(ptr,&size);
		ptr+=size;
		mpeg_psm_pack(ptr,&size, stream_type);
		ptr+=size;
	}
//	mpeg_pes_pack(ext_frame,sizeof(ext_frame),MPEG_INVALID_TIMESTAMP,type,ptr,&size);
	ptr+=size;
	//ts+=10;
	while(in_size >0){
		if(in_size >= MPEG_PS_SPLIT_SIZE){
			pes_size = MPEG_PS_SPLIT_SIZE;
		}else{
			pes_size = in_size;
		}
//		mpeg_pes_pack(psrc,pes_size,(i==0) ? ts : ts,type,ptr,&size);
		mpeg_pes_pack(psrc,pes_size,ts,type,ptr,&size);
		ptr+=size;
		psrc += pes_size;
		in_size -= pes_size;
		i++;
	}

	*ret_size = ptr-out;
#ifdef MPEG_DEBUG
	printf("packet num:%d totalsize:%u\n",i,ptr-out);
#endif
	return 0;
}

_INT MPEG_muxer_audio(_UC * src,_UI in_size,
	_UI timestamp/*ms*/,_UC type,
	_UC *out,_UI *ret_size)
{
	return mpeg_pes_pack(src,in_size,timestamp,type,out,ret_size);
}

_INT mpeg_ps_pack(_UC *out,_UI uiAvFlag,_UI uiIFrame,_UI uiAddPes,_UI uiDuration,_UI uiEncType,_UI uiFrameRemLen)
{
    _INT iTotalLen = 0;
    _UI uiSize = 0;
    _UC *ptr = out;

    if(uiAvFlag == EN_ZJ_MEDIA_VIDEO)
    {
        mpeg_ps_header_pack(ptr,&uiSize,uiDuration * 90,6150);
        ptr += uiSize;
        iTotalLen += (_INT)uiSize;
    }
    if(uiAddPes == 0)
    {
        if(uiIFrame == 1 && uiAvFlag == EN_ZJ_MEDIA_VIDEO)
        {
            mpeg_system_header_pack(ptr,&uiSize);
            ptr += uiSize;
            iTotalLen += (_INT)uiSize;
            mpeg_psm_pack(ptr,&uiSize, (uiEncType == EN_ZJ_VIDEOENC_TYPE_H265) ? 0x24  : 0x1b );
            ptr += uiSize;
            iTotalLen += (_INT)uiSize;
        }
    }
    if(uiFrameRemLen > MPEG_PS_SPLIT_SIZE)
    {
        mpeg_pes_pack(MOS_NULL, MPEG_PS_SPLIT_SIZE,uiDuration * 90,MPEG_DEFAULT_VIDEO_STREAM,ptr,&uiSize);
        iTotalLen += (_INT)uiSize;
    }
    else
    {
        mpeg_pes_pack(MOS_NULL, uiFrameRemLen, uiDuration * 90 ,MPEG_DEFAULT_VIDEO_STREAM,ptr,&uiSize);
        iTotalLen += (_INT)uiSize;
    }
    return iTotalLen;
}


#if defined(NOCROSS) && false
#include "netstream.h"
#include "wav.h"

static FILE* file_new(const char *name)
{
	FILE *f=fopen(name,"wb+");
	if(f==NULL){
		printf("open file failed\n");
		return NULL;
	}
	printf("create file:%s success",name);
	return f;
}

static _INT file_write(FILE *f,char *buf,_INT size)
{
	if(fwrite(buf,size,1,f)!=1){
		printf("write file failed\n");
		return -1;
	}
	return 0;
}

// test split ,but no multi-AU
_INT main2(_INT argc,char *argv[])
{
#define AUDIO_FRAME_SIZE	320
#define BUF_SIZE	(1024*1024)
	_INT i;
	RtspStream_t m_stream;
	_UC *buf=NULL;
	_UC *ptr;
	_UI iRetSize=0;
	FILE *f=NULL;
	_UC wavbuf[AUDIO_FRAME_SIZE];

	
	RTSP_STREAM_init(&m_stream,DEFAULT_STREAM);
	if(WAV_init(TEST_WAV)<0) return -1;
	if((f=file_new("test.mpg")) == NULL){
		return -1;
	}
	
	buf = (char *)malloc(BUF_SIZE);
	if(buf == NULL){
		printf("malloc for buffer size failed!\n");
		return -1;
	}

	printf("s_ps:%d s_es:%d s_sys:%d s_pts:%d s_media:%d\n",
		sizeof(MpegPsHeader_t),sizeof(MpegPesHeader_t),sizeof(MpegPsSystemHeader_t),
		sizeof(MpegPesPtsDts_t),sizeof(MpegStreamSpecs_t));

	for(i=0;i<400;i++){
		if(RTSP_STREAM_next(&m_stream)==0){
			if(MPEG_muxer_video(m_stream.data,m_stream.size,m_stream.timestamp,
				MPEG_DEFAULT_VIDEO_STREAM,m_stream.isKeyFrame,buf,BUF_SIZE,&iRetSize)==0)
			{
				if(file_write(f,buf,iRetSize)<0){
					break;
				}
			}else{
				break;
			}
		}else{
			break;
		}
		if(WAV_read(wavbuf,AUDIO_FRAME_SIZE)==0){
			if(MPEG_muxer_audio(wavbuf,AUDIO_FRAME_SIZE,m_stream.timestamp,
				MPEG_DEFAULT_AUDIO_STREAM,buf,&iRetSize)==0)
			{
				if(file_write(f,buf,iRetSize)<0){
					break;
				}
			}else{
				break;
			}
		}
	}
	RTSP_STREAM_destroy(&m_stream);
	free(buf);
	return 0;
}


_INT main(_INT argc,char *argv[])
{
	//return main1(argc,argv);
	return main2(argc,argv);
	//return main3(argc,argv);
}
#endif
#define CLOUDSTG_STREAM_PRV_VIDEODES_TYPE 0x4
#define CLOUDSTG_STREAM_PRV_AUDIODES_TYPE 0x2
static _INT PsMuxer_buildPrvHead(ST_PS_MUXER *pstPsMuxer, int iCloudEncSwitch)
{
    MOS_PARAM_NULL_RETERR(pstPsMuxer);

    _US usAVDesLen, usTemp;
    _US usType = CLOUDSTG_STREAM_PRV_VIDEODES_TYPE;
    pstPsMuxer->stPacketData.aucPacket[0] = 0;
    pstPsMuxer->stPacketData.aucPacket[1] = 0;
    pstPsMuxer->stPacketData.aucPacket[2] = 1;
    pstPsMuxer->stPacketData.aucPacket[3] = 0xBE;
    pstPsMuxer->uiDataLen += 8;


    usAVDesLen = MOS_VSNPRINTF(pstPsMuxer->stPacketData.aucPacket + 8, sizeof(pstPsMuxer->stPacketData.aucPacket) - 8,
                  "VIDEO:W=%u;H=%u;EncType=%u;",
                  pstPsMuxer->stVideoDes.stVideoPara.uiWidth,
                  pstPsMuxer->stVideoDes.stVideoPara.uiHeight,
                  pstPsMuxer->stVideoDes.stVideoPara.uiEncodeType);
                  
    if(pstPsMuxer->stAudioParam.uiEncodeType){
        usType += CLOUDSTG_STREAM_PRV_AUDIODES_TYPE;

        if (iCloudEncSwitch == 1)
        {
            usAVDesLen += MOS_VSNPRINTF(pstPsMuxer->stPacketData.aucPacket + usAVDesLen + 8, sizeof(pstPsMuxer->stPacketData.aucPacket) - usAVDesLen - 8,
                "AUDIO:EncodeType=%u;SampleRate=%u;Channels=%u;depth=%u;ENC:EncLen=%u;EncryptType=%u;Alarm:hta=%u",
                pstPsMuxer->stAudioParam.uiEncodeType,pstPsMuxer->stAudioParam.uiSampleRate,pstPsMuxer->stAudioParam.uiChannel,pstPsMuxer->stAudioParam.uiDepth,
                    0, 51, 1);
        }
        else
        {
            usAVDesLen += MOS_VSNPRINTF(pstPsMuxer->stPacketData.aucPacket + usAVDesLen + 8, sizeof(pstPsMuxer->stPacketData.aucPacket) - usAVDesLen - 8,
                "AUDIO:EncodeType=%u;SampleRate=%u;Channels=%u;depth=%u;",
                pstPsMuxer->stAudioParam.uiEncodeType,pstPsMuxer->stAudioParam.uiSampleRate,pstPsMuxer->stAudioParam.uiChannel,pstPsMuxer->stAudioParam.uiDepth);
        }
    }
    usTemp = MOS_INET_HTONS(usAVDesLen + 2);
    MOS_MEMCPY(pstPsMuxer->stPacketData.aucPacket + 4,&usTemp, 2);
    usTemp = MOS_INET_HTONS(usType);
    MOS_MEMCPY(pstPsMuxer->stPacketData.aucPacket + 6,&usTemp, 2);
    pstPsMuxer->uiDataLen += usAVDesLen;

    return MOS_OK;
}

static _INT PsMuxer_WriteOnePacket(ST_PS_MUXER *pstPsMuxer, _UC* pucData, _UI uiDataLen, _INT iEncSwitch)
{
    MOS_PARAM_NULL_RETERR(pstPsMuxer);
    MOS_PARAM_NULL_RETERR(pucData);
    
    if (Mos_FileWriteAppend(pstPsMuxer->ucFilePath, pucData, uiDataLen))
    {
        pstPsMuxer->uiTotalSendLen += uiDataLen;
    }
	return MOS_OK;
}

static ST_PS_MUXER* PsMuxer_FindPsMuxerById(int iPsMuxerId)
{
    ST_PS_MUXER *pstPsMuxer;
    ST_MOS_LIST_ITERATOR stIterator;
    FOR_EACHDATA_INLIST(&stPsMuxerList, pstPsMuxer, stIterator)
    {
        if (pstPsMuxer->iPsMuxerId == iPsMuxerId)
        {
            return pstPsMuxer;
        }
    }
	return MOS_NULL;
}

// 创建PS MUXER句柄
_ZJ_API _INT PsMuxer_CreateHandle(unsigned char *pucFilePath, EN_PS_CONTENT_TYPE uiContentType)
{
    ST_PS_MUXER *pstPsMuxer = (ST_PS_MUXER*)MOS_MALLOCCLR(sizeof(ST_PS_MUXER));
    pstPsMuxer->ucFilePath = pucFilePath;
    pstPsMuxer->uiContentType = uiContentType;
    pstPsMuxer->iFirstFrame = 1;
    pstPsMuxer->uiTotalSendLen = 0;
    pstPsMuxer->iEncSwitch = 1;
    pstPsMuxer->uiVDuration = 0;
    pstPsMuxer->uiDataLen = 0;
    pstPsMuxer->uiTotalSendLen = 0;
    // pstPsMuxer->stVideoDes.stCircle = 
    // pstPsMuxer->stVideoDes.stDistortion = 
    // pstPsMuxer->stVideoDes.stVideoPara = 
    // pstPsMuxer->stVideoDes.uiLensType = 
    // pstPsMuxer->stAudioParam.uiChannel = 
    // pstPsMuxer->stAudioParam.uiDepth = 
    // pstPsMuxer->stAudioParam.uiEncodeType = 
    // pstPsMuxer->stAudioParam.uiSampleRate =
    pstPsMuxer->iPsMuxerId = MOS_LIST_GETCOUNT(&stPsMuxerList);

    MOS_LIST_ADDTAIL(&stPsMuxerList, pstPsMuxer);
    return pstPsMuxer->iPsMuxerId;
}

// 销毁PS MUXER句柄
_ZJ_API _INT PsMuxer_DestoryHandle(int iPsMuxerId)
{
    ST_PS_MUXER *pstPsMuxer;
    ST_MOS_LIST_ITERATOR stIterator;
    FOR_EACHDATA_INLIST(&stPsMuxerList, pstPsMuxer, stIterator)
    {
        if (pstPsMuxer->iPsMuxerId == iPsMuxerId)
        {
            MOS_LIST_RMVALL(&stPsMuxerList, pstPsMuxer);
            MOS_FREE(pstPsMuxer);
            return MOS_OK;
        }
    }
    
    return MOS_ERR;

}

// 写视频数据
_ZJ_API _INT PsMuxer_WriteVideo(int iPsMuxerId, char *ptDatabuff, unsigned int uiDatabuffLen, unsigned int uiTimeStamp, unsigned int bIFrame, unsigned char aucPesPriData[16])
{
    _UI uiSize = 0;
    _UI uiExtFlag = 0;
    _UI uiNeedWrite = 0;
    _UI uiSendLen = 0;
    
    ST_PS_MUXER *pstPsMuxer = PsMuxer_FindPsMuxerById(iPsMuxerId);

    if (aucPesPriData != MOS_NULL)
    {
        uiExtFlag = 0;
    }

    // 1.发送私有数据头
    if (pstPsMuxer->iFirstFrame)
    {
        PsMuxer_buildPrvHead(pstPsMuxer, pstPsMuxer->iEncSwitch);
        PsMuxer_WriteOnePacket(pstPsMuxer, pstPsMuxer->stPacketData.aucPacket, pstPsMuxer->uiDataLen, pstPsMuxer->iEncSwitch);
        pstPsMuxer->iFirstFrame = 0;

        pstPsMuxer->uiVTimeStamp = uiTimeStamp;
    }

    // 重新计算uiVDuration
    if(uiTimeStamp >= pstPsMuxer->uiVTimeStamp)
    {
        pstPsMuxer->uiVDuration += uiTimeStamp - pstPsMuxer->uiVTimeStamp;
    }
    else
    {
        pstPsMuxer->uiVDuration += 40;
    }

    pstPsMuxer->uiVTimeStamp = uiTimeStamp;

    // 2.发送PS头
    mpeg_ps_header_pack(pstPsMuxer->stPacketData.aucPacket,&uiSize,pstPsMuxer->uiVDuration * 90,6150);
    PsMuxer_WriteOnePacket(pstPsMuxer, pstPsMuxer->stPacketData.aucPacket, uiSize, pstPsMuxer->iEncSwitch);

    if (bIFrame)
    {
        // 3.发送PSM头部
        mpeg_system_header_pack(pstPsMuxer->stPacketData.aucPacket, &uiSize);
        PsMuxer_WriteOnePacket(pstPsMuxer, pstPsMuxer->stPacketData.aucPacket, uiSize, pstPsMuxer->iEncSwitch);

        // 4.PSM头
        mpeg_psm_pack(pstPsMuxer->stPacketData.aucPacket,&uiSize, (pstPsMuxer->stVideoDes.stVideoPara.uiEncodeType == EN_ZJ_VIDEOENC_TYPE_H265) ? 0x24  : 0x1b );
        PsMuxer_WriteOnePacket(pstPsMuxer, pstPsMuxer->stPacketData.aucPacket, uiSize, pstPsMuxer->iEncSwitch);
        
    }

    while (uiDatabuffLen > 0)
    {     
        // 分段发送
        if (uiDatabuffLen > MPEG_PS_SPLIT_SIZE)
        {
            mpeg_pes_pack_ex(MOS_NULL, MPEG_PS_SPLIT_SIZE,pstPsMuxer->uiVDuration * 90,MPEG_DEFAULT_VIDEO_STREAM,pstPsMuxer->stPacketData.aucPacket,&uiSize, uiExtFlag, aucPesPriData);
            // mpeg_pes_pack(MOS_NULL, MPEG_PS_SPLIT_SIZE,pstPsMuxer->uiVDuration * 90,MPEG_DEFAULT_VIDEO_STREAM,pstPsMuxer->stPacketData.aucPacket,&uiSize);
            uiNeedWrite = MPEG_PS_SPLIT_SIZE;
        }
        else
        {
            mpeg_pes_pack_ex(MOS_NULL, uiDatabuffLen, pstPsMuxer->uiVDuration * 90 ,MPEG_DEFAULT_VIDEO_STREAM,pstPsMuxer->stPacketData.aucPacket,&uiSize, uiExtFlag, aucPesPriData);
            // mpeg_pes_pack(MOS_NULL, uiDatabuffLen,pstPsMuxer->uiVDuration * 90,MPEG_DEFAULT_VIDEO_STREAM,pstPsMuxer->stPacketData.aucPacket,&uiSize);
            uiNeedWrite = uiDatabuffLen;
        }

        // 5.发送PES头部
        PsMuxer_WriteOnePacket(pstPsMuxer, pstPsMuxer->stPacketData.aucPacket, uiSize, pstPsMuxer->iEncSwitch);
        // 6.发送数据
        PsMuxer_WriteOnePacket(pstPsMuxer, ptDatabuff + uiSendLen, uiNeedWrite, pstPsMuxer->iEncSwitch);
        uiSendLen += uiNeedWrite;
        uiDatabuffLen -= uiSendLen;
        uiExtFlag = 0;
    }
    return MOS_OK;
}

// 写音频数据
_ZJ_API _INT PsMuxer_WriteAudio(int iPsMuxerId, char *ptDatabuff, unsigned int uiDatabuffLen, unsigned int uiTimeStamp)
{
    ST_PS_MUXER *pstPsMuxer = PsMuxer_FindPsMuxerById(iPsMuxerId);
    MOS_PARAM_NULL_RETERR(pstPsMuxer);
    MOS_PARAM_NULL_RETERR(ptDatabuff);

    _UI size;
    if( pstPsMuxer->uiATimeStamp == 0)
    {
        pstPsMuxer->uiATimeStamp = uiTimeStamp;
    }
    
    if(uiTimeStamp >= pstPsMuxer->uiATimeStamp)
    {
        pstPsMuxer->uiADuration += uiTimeStamp - pstPsMuxer->uiATimeStamp;
    }
    else
    {
        pstPsMuxer->uiADuration += 40;
    }

    pstPsMuxer->uiATimeStamp = uiTimeStamp;

    mpeg_pes_pack(MOS_NULL, uiDatabuffLen, pstPsMuxer->uiADuration * 90,MPEG_DEFAULT_AUDIO_STREAM,pstPsMuxer->stPacketData.aucPacket,&size);
    // 发送Pes头部
    PsMuxer_WriteOnePacket(pstPsMuxer, pstPsMuxer->stPacketData.aucPacket,size,pstPsMuxer->iEncSwitch);

    // 发送音频数据
    PsMuxer_WriteOnePacket(pstPsMuxer,ptDatabuff, uiDatabuffLen,pstPsMuxer->iEncSwitch);
	return MOS_OK;
}
