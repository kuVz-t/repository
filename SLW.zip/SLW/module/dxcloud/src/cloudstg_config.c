#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_crypto_adapt.h"
#include "config_api.h"
#include "record_api.h"
#include "http_api.h"
#include "media_cache_api.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_logger.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_manage.h"
#include "cloudstg_aliveupload.h"
#include "cloudstg_transaddress.h"
#include "cloudstg_event.h"
#include "cloudstg_patch.h"
#include "cloudstg_stream_prv.h"
#include "watchdog_api.h"
#include "config_api.h"

// 获取云存配置变量句柄
ST_CLOUDSTG_CONFIG *CloudStg_GetConfig()
{
    return &CloudStg_GetMng()->stCloudConfig;
}

// 设置事件云存追加开关
_INT CloudStg_SetEventCloudSwitch(_INT iEventCloudSwitch)
{
    if(iEventCloudSwitch == CloudStg_GetConfig()->iEventCloudSwitch)
    {
        return MOS_OK;
    }
    CloudStg_GetConfig()->iEventCloudSwitch = iEventCloudSwitch;
    return MOS_OK;
}

// 设置事件云存最大秒数
_INT CloudStg_SetEventCloudMaxTime(_INT iEventCloudMaxTime)
{
    if(iEventCloudMaxTime == CloudStg_GetConfig()->iEventCloudMaxTime)
    {
        return MOS_OK;
    }
    CloudStg_GetConfig()->iEventCloudMaxTime = iEventCloudMaxTime;
    return MOS_OK;
}

// 设置事件云存最小秒数
_INT CloudStg_SetEventCloudMinTime(_INT iEventCloudMinTime)
{
    if(iEventCloudMinTime == CloudStg_GetConfig()->iEventCloudMinTime)
    {
        return MOS_OK;
    }
    CloudStg_GetConfig()->iEventCloudMinTime = iEventCloudMinTime;
    return MOS_OK;
}

// 设置事件云存检测秒数
_INT CloudStg_SetEventCloudDetectTime(_INT iEventCloudDetectTime)
{
    if(iEventCloudDetectTime == CloudStg_GetConfig()->iEventCloudDetectTime)
    {
        return MOS_OK;
    }
    CloudStg_GetConfig()->iEventCloudDetectTime = iEventCloudDetectTime;
    return MOS_OK;
}

// 设置事件云存追加录制秒数
_INT CloudStg_SetEventCloudAppendTime(_INT iEventCloudAppendTime)
{
    if(iEventCloudAppendTime == CloudStg_GetConfig()->iEventCloudAppendTime)
    {
        return MOS_OK;
    }
    CloudStg_GetConfig()->iEventCloudAppendTime = iEventCloudAppendTime;
    return MOS_OK;
}