#ifndef _CLOUDSTG_RES_PRV_H_
#define _CLOUDSTG_RES_PRV_H_

#ifdef __cplusplus
extern "C"
{
#endif
#include "kj_timer.h"
#define  CLOUDSTG_URL_OVERTIME         840
#define  CLOUDSTG_URL_LOCALTIME        60*60*8
#define  CLOUDSTG_MAX_RES_NUM          40
#define  CLOUDSTG_MIN_RES_NUM          2

typedef struct struct_MECS_CONN_SOCKET
{
    _UI          uiHttpType;
    _UI          uiConnType;            // IPv4/IPv6连接
    _UC          aucHeader[CLOUDSTG_HTTP_HEADER_MAX_LEN];
    _UC          aucSubUri[CLOUDSTG_URI_LEN];
    _UC          aucHost[CLOUDSTG_HOST_LEN];
    _UC          aucETag[128];
    _US          usPort;
    _UC          aucReserv[2];           //for packet alignment
    _SOCKET      hSocket;
    _SSL_HANDLE  hSSL;
    _UI          uiSentCount;
    _UI          uiHasIpv6;
}ST_MECS_CONN_SOCKET;

typedef struct stru_CloudStg_Sts_Url
{
    _UC aucSessionToken[512];
    _UC aucAccessKeyId[32];
    _UC aucSecretAccessKey[64];
    _CTIME_T cExpiration;
    _UC aucEndpoint[64];
    _UC aucBktName[64];
    _INT iCid;
    _UC aucUploadPath[32];
    _UI uiStorageType;
    _UC aucX_amz_meta_upsec[256];
    _UC aucX_amz_meta_file[64];
    _UI uiX_amz_meta_commit;
}ST_CLOUDSTG_STS_URL;

typedef struct stru_CloudStg_Res_Url
{
    _INT iStorageType;
    _INT iUseContentLength;
    _UC aucDate[32];
    _UC aucAuthorization[64];
    _UC aucUrl[CLOUDSTG_URI_LEN+4];
    _UC aucFid[128];
    _UC aucBucket[128];
    _UC aucStorageProvider[16];
    _UC aucName[CLOUDSTG_KEY_LEN];
    ST_CLOUDSTG_STS_URL *pstStsUrlInfo;
    // _UC aucCloudEncHttpUploadParam[CFG_STRING_SDP_LENGTH + 4];
    _CTIME_T cPrvUrlTime;
    _CTIME_T cUrlTime;
    ST_MOS_LIST_NODE stNode;
}ST_CLOUDSTG_RES_URL;

typedef struct stru_MECS_CONN
{
    _VPTR                hChanTask;
    _UI                  uiUseFlag;
    _UI                  uiType;
    _UI                  uiSliceSize;
    _UI                  uiTargetSize;
    _INT                 iCloudEncSwitch;
    _BOOL                bHeaderSent;
    _BOOL                bRsponseRecv;
    _INT                 iSendTimes;
    _INT                 iAliveTaskId;
    _UI                  uiIsPatch;
    _UC                  aucBoundary[64];
    _UC                  aucBoundaryHeader[256];
    _UC                  aucBoundaryEnd[64];
    _UC                  aucFileName[256];
    _INT                 iDirectMode;
    ST_CLOUDSTG_RES_URL *pstConnUrl;
    ST_MECS_CONN_SOCKET  stSocket;
    ST_MOS_LIST_NODE     stNode;
}ST_MECS_CONN;

typedef struct stru_CloudStg_UrlBucket_Node
{
    _UI uiOgctId;
    _UI uiType;
    _UI uiPicUrl;
    _UI uiResNum;  // 资源保留数目
    _UI uiTryTime;
    _UI uiRecvLen;
    _UI uiBuffLen;
    _UC *pucRecvBuff;
    _UI uiHttpHandle;
    _CTIME_T cTimeReq;
    _CTIME_T cNextReqTime;
    ST_MOS_LIST stUsrlist;
    ST_MOS_LIST_NODE stNode;
    // 加密信息
    _INT iCloudEncSwitch;
    _UC aucCloudEncHttpParamJson[CFG_STRING_SDP_LENGTH + 4];    
}ST_CLOUDSTG_URLBUCKET_NODE;

typedef struct stru_CloudStg_Res_Mng
{
    _UC         ucInitFlag;
    _UC         ucRunFlag;
    _UC         uiStatus; // 0 没有 请求  1 正在请求  2 完成请求
    _UC         ucRsv[2];
    _INT        iForceGenerateEncInfo;
    kj_timer_t  tWatchDogTimer; // 看门狗Timer
    _HMUTEX     hMutex;
    _HTHREAD    hThread;
    _CTIME_T    cNextReqTime;
    _UI         uiTryTime;
    _UI         uiOgctId;
    _UI         uiRecvLen;
    _UI         uiBuffLen;
    _UC         *pucRecvBuff;
    _CTIME_T    cTimeReq;
    ST_MOS_LIST stConnMemList;    // ST_MECS_CONN
    ST_MOS_LIST stUrlPool;
    ST_MOS_LIST stUrlBucketkList; // ST_CLOUDSTG_URLBUCKET_NODE
}ST_CLOUDSTG_RES_MNG;

// 获取云存资源全局变量句柄
ST_CLOUDSTG_RES_MNG *CloudStg_ResGetMng();

#ifdef __cplusplus
}
#endif

#endif 