#ifndef _CLOUDSTG_PATCH_H_
#define _CLOUDSTG_PATCH_H_

#ifdef __cplusplus
extern "C"
{
#endif
// #include "cloudstg_stream.h"
#include "cloudstg_manage.h"
// #include "record_api.h"

#define CLOUDSTG_PATCH_LIMIT_BANDWIDTH          0           // 限制补录云存带宽
#define CLOUDSTG_PATCH_TASK_MIN_INTERVAL_SECOND 1           // At least 1s
#define CLOUDSTG_PATCH_TASK_AVAILABLE_HOURS     (24 * 3600) // Within 24 hours file will be uploaded 
#define CLOUDSTG_PATCH_TASK_BEFORE_START_SECOND (10 * 60)   // start patching task after 10 mins

typedef struct stru_CLOUDSTG_PATCH_MANAGE
{
    _INT                   iInitail;
    _UC                    ucInitFlag;           
    _UC                    ucRunFlag;
    _UC                    ucStopFlag;   // 限制带宽使用
    _HMUTEX                hMutex;
    _HQUEUE                hMsgQueue;    // 消息队列
    _HTHREAD               hMgrThread;
    _UI                    uiCurNetStatus;
    _CTIME_T               tDisconnetTime;
    _INT                   iLimitBandWidth;
    _INT                   iLimitBandWidthBak;
    _INT                   iSleepTime;
    ST_MOS_LIST            stPatchTaskList;
}ST_CLOUDSTG_PATCH_MANAGE;

// 获取云存patch全局变量句柄
ST_CLOUDSTG_PATCH_MANAGE *CloudStg_Patch_GetMng();

// 云存patch Mng预初始化
_INT CloudStg_Patch_MngPrvInit();

// 云存patch预初始化
_INT CloudStg_Patch_PreInit();

// 云存patch初始化
_INT CloudStg_Patch_Init();

// 云存patch开始
_INT CloudStg_Patch_Start();

// 云存patch停止
_INT CloudStg_Patch_Stop();

// 云存patch销毁
_INT CloudStg_Patch_Destroy();

// 云存patch主程序
_INT CloudStg_PatchAliveUploadProc(ST_CLOUDSTG_TASK_NODE *pstTaskNode);

// 云存patch循环程序
static _INT CloudStg_PatchTaskLoop(_VPTR pParam);

// 云存patch新增节点至TaskList
_INT CloudStg_Patch_AddItemToTaskList(_UC *pucUuid, _INT iCamId, _INT iEventType, _INT iTaskType, _INT iStorageType, _INT iCloudUpLoadMode, _UI uiDuration, _CTIME_T tCreateTime, _CTIME_T tFailTime);

// 云存patch新增节点至CfgTaskList
_INT CloudStg_Patch_AddItemToCfgTaskList(_INT iCamId, _INT iEventType, _INT iTaskType, _INT iStorageType, _INT iCloudUpLoadMode, _UI uiDuration, _UI uiMaxDuration, _CTIME_T tCreateTime, _CTIME_T tFailTime);

// 云存patch关闭alive节点
_INT CloudStg_PatchDestroyAliveNode(ST_CLOUDSTG_TASK_NODE *pstAliveTaskNode);

// 云存patch回调
_INT CloudStg_Patch_AliveSliceStatusCallBack(_VPTR vpBase,_UI uiStatus,_UC *pucFid,_UC *pucETag,_UI uiTargetSize,_UC *pucBucket,_UC *pucStorageProvider);

// 云存patch关闭alive节点
_INT CloudStg_Patch_CloseAliveTaskWithUuid(_UC *pucUuid);

// 云存patch根据创建时间删除任务
_INT CloudStg_Patch_DeleteTaskWithTime(_CTIME_T cCreateTime);

/***********************transfer**************************/

// 获取云存patch全局变量句柄
ST_CLOUDSTG_TRANS_MGR* CloudStg_Trans_PatchGetMgr();

// 云存patch主程序
_INT CloudStg_Trans_PatchProc(_VPTR pParam);

// 云存patch上传停止
_INT CloudStg_Trans_PatchStop();

// 云存patch上传遍历链表主程序
static _INT CloudStg_Trans_PatchProcessTask(ST_CLOUDSTG_TRANS_MGR *pstCloudTransMgr,_CTIME_T ctime);

// 云存patch上传获取DID
_VOID CloudStg_Trans_PatchGetDeviceId();

// 云存任务是否需要连接url信息
_BOOL CloudStg_PatchTaskNeedConnUrl(_INT iIsDirectModeChange);

// 降低补录上传速率
_INT CloudStg_Patch_DesLimitBandWidth(float fRate);
#ifdef __cplusplus
}
#endif
#endif
