#ifndef _CLOUDSTG_CONN_H_
#define _CLOUDSTG_CONN_H_

#ifdef __cplusplus
extern "C"
{
#endif

typedef  MOS_MASK_HANDLE_TYPE(_HCSCONN) _HCSCONN;

/******************************************************************************
conn 下面 集合了 url  res　和 ssl 的 调用 
******************************************************************************/
// 打开连接(多线程调用)
_HCSCONN CloudStg_ConnOpen(_VPTR pstTask, _INT iAliveTaskId, _UI uiType, _UI uiTargetSize, _UI uiIsPatch, _INT iCloudEncSwitch, _INT iDirectMode);

// 关闭连接(多线程调用)
_INT   CloudStg_ConnClose(_HCSCONN hCSConn, _INT iForce);

// 开始连接(多线程调用)
_INT   CloudStg_ConnStart(_HCSCONN hCSConn,_UI uiPicUrl);

// 停止连接(多线程调用)
_INT   CloudStg_ConnStop(_HCSCONN hCSConn, _INT iForce);

// 关闭socket(多线程调用)
_INT   CloudStg_ConnSocketClose(_HCSCONN hCSConn);

// 暂时关闭socket(多线程调用)
_VOID  CloudStg_ConnShutDown(_HCSCONN hCSConn);

// 发送(多线程调用)
_INT   CloudStg_ConnSend(_HCSCONN hCSConn, _UC *pucData, _UI uiLen, _UI uiFlag,_UI *puiSendLen);

// 接受(多线程调用)
_INT   CloudStg_ConnRecvRsp(_HCSCONN hCSConn);

// Deprecated
_INT   CloudStg_ConnSendExt(_UC *pucData, _UI uiLen,_UI uiType,_UC aucFid[CLOUDSTG_FID_LEN],_UC aucBucket[CLOUDSTG_BUCKET_LEN],_UC aucName[CLOUDSTG_KEY_LEN]);

_INT CloudStg_ConnStsInfoPrepare(ST_MECS_CONN *pstConn, _UI uiType);
#ifdef __cplusplus
}
#endif

#endif 
