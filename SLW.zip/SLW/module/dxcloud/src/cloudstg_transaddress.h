#ifndef CLOUDSTG_TRANSADDRESS_H
#define CLOUDSTG_TRANSADDRESS_H

#ifdef __cplusplus
extern "C"{
#endif

#define CLOUDSTG_GETINFO_ADDRESS          (_UC*)"/unifyDev/cinfo"
#define CLOUDSTG_GETURL_ADDRESS           (_UC*)"/unifyDev/getUrls"
#define CLOUDSTG_GETENCURL_ADDRESS        (_UC*)"/unifyDev/getEncryptUrls"
#define CLOUDSTG_GETPICURL_ADDRESS        (_UC*)"/unifyDev/getPicUrls"
#define CLOUDSTG_GETCOMMIT_ADDRESS        (_UC*)"/unifyDev/commit"
#define CLOUDSTG_GETPICCOMMIT_ADDRESS     (_UC*)"/unifyDev/picCommit"
#define CLOUDSTG_MEDIAFILE                (_UC*)"ps"
#define CLOUDSTG_PICFILE                  (_UC*)"jpg"
#define CLOUDSTG_ENCFILE                  (_UC*)"IE"
#define CLOUDSTG_ALARMFILE                (_UC*)"ALARM"

typedef enum enum_CLOUDSTG_TRANS_SIGN
{
    EN_CLOUDSTG_TRANS_BUFF      = 0x60,
    EN_CLOUDSTG_GETINFO_REQ     = 0x10,
    EN_CLOUDSTG_GETINFO_RSP     = 0x11,
    EN_CLOUDSTG_GETURL_REQ      = 0x12,
    EN_CLOUDSTG_GETURL_RSP      = 0x13,
    EN_CLOUDSTG_UPLOAD_FILE_REQ = 0x14,
    EN_CLOUDSTG_UPLOAD_FILE_RSP = 0x15,
    EN_CLOUDSTG_GETPICURL_REQ   = 0x16,
    EN_CLOUDSTG_GETPICURL_RSP   = 0x17,
    EN_CLOUDSTG_UPLOAD_PIC_REQ  = 0x18,
    EN_CLOUDSTG_UPLOAD_PIC_RSP  = 0x18,
}EN_CLOUDSTG_TRANS_SIGN_TYPE;

// 视频COMMIT
_INT CloudStg_ProcGetMediaCommit(ST_CLOUDSTG_TASK_NODE *pstTaskNode, _UI uiIsPatch);

// 图片COMMIT
_INT CloudStg_ProcGetPicCommit(ST_CLOUDSTG_FILE_NODE *pstFileTask);

#ifdef __cplusplus
}
#endif

#endif
