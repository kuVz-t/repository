#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_json_adapt.h"
#include "http.h"
#include "config_type.h"
#include "config_api.h"
#include "media_cache_api.h"
#include "record_api.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_manage.h"
#include "cloudstg_aliveupload.h"
#include "cloudstg_transaddress.h"
#include "cloudstg_event.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "qualityprobe_api.h"

#include <netinet/in.h>
#include <arpa/nameser.h>
#include <resolv.h>

_INT CloudStg_CreateSocket(ST_CLOUDSTG_RES_URL *pstConnUri, ST_MECS_CONN_SOCKET *pstConnSocket)
{
    MOS_PARAM_NULL_RETERR(pstConnUri);
    MOS_PARAM_NULL_RETERR(pstConnSocket);

    _INT iRet = MOS_ERR;
    _SOCKET hSocket = MOS_SOCKET_INVALID;
    iRet = CloudStg_ResGetHost(pstConnUri, pstConnSocket->aucHost, &pstConnSocket->usPort, pstConnSocket->aucSubUri,&pstConnSocket->uiHttpType);
    if (MOS_OK != iRet)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "failed to parse uri: %s, pstConnSocket->aucSubUri", pstConnSocket->aucHost, pstConnSocket->aucSubUri);
        return iRet;
    }
    hSocket = Http_CreateSocketBlockAndConnect2(pstConnSocket->aucHost, pstConnSocket->usPort, 10, CLOUDSTG_SOCKET_SEND_TIMEOUT, CLOUDSTG_SOCKET_RECV_TIMEOUT,
                                                 MOS_TRUE, &pstConnSocket->uiConnType, &pstConnSocket->uiHasIpv6);
    pstConnSocket->hSocket = hSocket;
    if (hSocket == MOS_SOCKET_INVALID)
    {
        return MOS_ERR;
    }
    do
    {
        // 手动设置云存socket发送buf
        iRet = Mos_SocketSetSendBuf(hSocket, CLOUDSTG_SOCKET_SEND_SIZE);
        if (iRet != MOS_OK)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Mos_SocketSetSendBuf failed ipv%d", ((pstConnSocket->uiConnType==EN_CINET_TYPE_IPV6)?6:4));
            break;
        }
        // 手动设置云存socket接收buf
        iRet = Mos_SocketSetRecvBuf(hSocket, CLOUDSTG_SOCKET_RECV_SIZE);
        if (iRet != MOS_OK)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Mos_SocketSetRecvBuf failed ipv%d", ((pstConnSocket->uiConnType==EN_CINET_TYPE_IPV6)?6:4));
            break;
        }
    }
    while (0);
    if (iRet != MOS_OK)
    {
        return MOS_ERR;
    }
    return MOS_OK;
}

_INT CloudStg_OpenSocket(ST_MECS_CONN_SOCKET *pstConnSocket, _UC ucType)
{
    MOS_PARAM_NULL_RETERR(pstConnSocket);
    _UC aucUrl[256] = {0};
    _INT iTmp = 0;

    if (MOS_SOCKET_INVALID == pstConnSocket->hSocket)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "socket connect failed,socket: %d", pstConnSocket->hSocket);
        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", pstConnSocket->aucHost, pstConnSocket->aucSubUri);
        switch (ucType)
        {
            case EN_CLOUDSTG_RESOURCE_STREAM:
            {
                Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "type: video", aucUrl, EN_CLOUDSTG_RT_VIDEO_UPLOAD_GETHOSTBYNAME_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME);
            }
            break;
            case EN_CLOUDSTG_RESOURCE_PIC:
            {
                Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "type: pic", aucUrl, EN_CLOUDSTG_RT_PIC_UPLOAD_GETHOSTBYNAME_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME);
            }
            break;
            case EN_CLOUDSTG_RESOURCE_LOGFILE:
            {
                Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "type: logfile", aucUrl, EN_CLOUDSTG_RT_LOGFILE_UPLOAD_GETHOSTBYNAME_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME);
            }
            default:
            break;
        }
        return MOS_ERR;
    }

    if(pstConnSocket->uiHttpType == 1)
    {
        iTmp = Adpt_SSL_Create(pstConnSocket->hSocket, &pstConnSocket->hSSL);
        if (ITRD_OK != iTmp)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"ssl creat err ");
            return MOS_ERR;
        }
	    iTmp = Adpt_SSL_SetClientMode(pstConnSocket->hSSL,MOS_TRUE);
	    if (ITRD_OK != iTmp) 
	    {
	        MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"SSL connect err: %u,errno %u", Adpt_SSL_GetLastError(pstConnSocket->hSSL),errno);
	        Adpt_SSL_Destroy(pstConnSocket->hSSL);
	        pstConnSocket->hSSL = MOS_NULL;
	        return MOS_ERR;
	    }
        iTmp = Adpt_SSL_Connect(pstConnSocket->hSSL,pstConnSocket->aucHost);
        if (ITRD_OK != iTmp) 
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"SSL connect err: %u,errno %u port %u ", Adpt_SSL_GetLastError(pstConnSocket->hSSL),errno,pstConnSocket->usPort);
            Adpt_SSL_Destroy(pstConnSocket->hSSL);
            pstConnSocket->hSSL = MOS_NULL;
            return MOS_ERR;
        }
    }
    return MOS_OK;
}

_VOID CloudStg_CloseSocket(ST_MECS_CONN_SOCKET *pstConnSocket)
{
    MOS_PARAM_NULL_NORET(pstConnSocket);
    if (MOS_NULL != pstConnSocket->hSSL)
    {
        Adpt_SSL_Destroy(pstConnSocket->hSSL);
        pstConnSocket->hSSL = MOS_NULL;
    }
    else if (MOS_SOCKET_INVALID != pstConnSocket->hSocket)
    {
        Mos_SocketShutDown(pstConnSocket->hSocket, EN_CINET_SHTDWN_BOTH);
        Mos_SocketClose(pstConnSocket->hSocket);     
    }
    MOS_MEMSET(pstConnSocket, 0 ,sizeof(ST_MECS_CONN_SOCKET));
    pstConnSocket->hSocket = MOS_SOCKET_INVALID;
    return;
}

_INT CloudStg_GenChunkedReqHeader(ST_MECS_CONN *pstConn)
{
    MOS_PARAM_NULL_RETERR(pstConn);
    _UI  ilen = 0 ;
    _INT iRet = MOS_OK;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    pstTaskNode = CloudStg_FindTaskNode(pstConn->uiIsPatch,pstConn->iAliveTaskId);
    if (pstTaskNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"Can't find proper tasknode with parameters: %u, %d", 
                    pstConn->uiIsPatch, pstConn->iAliveTaskId);
        return MOS_ERR;
    }
    if (pstConn->iCloudEncSwitch == 1)
    {
        ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
            "PUT %s HTTP/1.1\r\n"
            "Host: %s\r\n"
            "Connection: keep-alive\r\n"
            "Date: %s\r\n"
            "Authorization: %s\r\n"
            "Content-Type: application/octet-stream\r\n"
            "Expect: 100-continue\r\n"
            "x-amz-meta-vsec: %s\r\n"
            "Transfer-Encoding: chunked\r\n\r\n",
            pstConn->stSocket.aucSubUri, pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, pstConn->pstConnUrl->aucAuthorization, pstTaskNode->aucCloudEncHttpUploadParam);
    }
    else
    {
        ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
            "PUT %s HTTP/1.1\r\n"
            "Host: %s\r\n"
            "Connection: keep-alive\r\n"
            "Date: %s\r\n"
            "Authorization: %s\r\n"
            "Content-Type: application/octet-stream\r\n"
            "Expect: 100-continue\r\n"
            "Transfer-Encoding: chunked\r\n\r\n",
            pstConn->stSocket.aucSubUri, pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, pstConn->pstConnUrl->aucAuthorization);
    }
    
    if(ilen >= CLOUDSTG_HTTP_HEADER_MAX_LEN)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Http header len over maxlen");
        return MOS_ERR;
    }
    return iRet;
}

_INT CloudStg_GenStsChunkedReqHeader(ST_MECS_CONN *pstConn)
{
    MOS_PARAM_NULL_RETERR(pstConn);
    _UI  ilen = 0 ;
    _INT iRet = MOS_OK;
    ST_CLOUDSTG_RES_URL *pstConnUri = (ST_CLOUDSTG_RES_URL *)pstConn->pstConnUrl;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    pstTaskNode = CloudStg_FindTaskNode(pstConn->uiIsPatch,pstConn->iAliveTaskId);
    if (pstTaskNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"Can't find proper tasknode with parameters: %u, %d", 
                    pstConn->uiIsPatch, pstConn->iAliveTaskId);
        return MOS_ERR;
    }
    iRet = CloudStg_Res_GenStsAuthorization(pstConn, pstConn->pstConnUrl->aucAuthorization, sizeof(pstConn->pstConnUrl->aucAuthorization), MOS_FALSE);
    MOS_FUNRET_ERR_RETERR(CLOUDSTG_LOGSTR, iRet, CloudStg_Res_GenStsAuthorization);
    if (pstConn->iCloudEncSwitch == 1)
    {
        // 自动commit
        if (pstConnUri->pstStsUrlInfo->uiX_amz_meta_commit != 0)
        {
            ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
                "PUT %s HTTP/1.1\r\n"
                "Host: %s\r\n"
                "Connection: keep-alive\r\n"
                "Date: %s\r\n"
                "Authorization: %s\r\n"
                "X-Amz-Security-Token: %s\r\n"
                "x-amz-meta-commit: %d\r\n"
                "x-amz-meta-upsec: %s\r\n"
                "x-amz-meta-file: %s\r\n"
                "x-amz-meta-vsec: %s\r\n"
                "Content-Type: application/octet-stream\r\n"
                "Expect: 100-continue\r\n"
                "Transfer-Encoding: chunked\r\n\r\n",
                pstConn->stSocket.aucSubUri,pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, 
                pstConn->pstConnUrl->aucAuthorization,pstConn->pstConnUrl->pstStsUrlInfo->aucSessionToken,
                pstConnUri->pstStsUrlInfo->uiX_amz_meta_commit,pstConnUri->pstStsUrlInfo->aucX_amz_meta_upsec,
                pstConnUri->pstStsUrlInfo->aucX_amz_meta_file,pstTaskNode->aucCloudEncHttpUploadParam);
        }
        // 非自动commit
        else
        {
            ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
                "PUT %s HTTP/1.1\r\n"
                "Host: %s\r\n"
                "Connection: keep-alive\r\n"
                "Date: %s\r\n"
                "Authorization: %s\r\n"
                "X-Amz-Security-Token: %s\r\n"
                "x-amz-meta-vsec: %s\r\n"
                "Content-Type: application/octet-stream\r\n"
                "Expect: 100-continue\r\n"
                "Transfer-Encoding: chunked\r\n\r\n",
                pstConn->stSocket.aucSubUri,pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, 
                pstConn->pstConnUrl->aucAuthorization,pstConn->pstConnUrl->pstStsUrlInfo->aucSessionToken,
                pstTaskNode->aucCloudEncHttpUploadParam);
        }
    }
    else
    {
        if (pstConnUri->pstStsUrlInfo->uiX_amz_meta_commit != 0)
        {
            ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
                "PUT %s HTTP/1.1\r\n"
                "Host: %s\r\n"
                "Connection: keep-alive\r\n"
                "Date: %s\r\n"
                "Authorization: %s\r\n"
                "X-Amz-Security-Token: %s\r\n"
                "x-amz-meta-commit: %d\r\n"
                "x-amz-meta-upsec: %s\r\n"
                "x-amz-meta-file: %s\r\n"
                "Content-Type: application/octet-stream\r\n"
                "Expect: 100-continue\r\n"
                "Transfer-Encoding: chunked\r\n\r\n",
                pstConn->stSocket.aucSubUri,pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, 
                pstConn->pstConnUrl->aucAuthorization,pstConn->pstConnUrl->pstStsUrlInfo->aucSessionToken,
                pstConnUri->pstStsUrlInfo->uiX_amz_meta_commit,pstConnUri->pstStsUrlInfo->aucX_amz_meta_upsec,
                pstConnUri->pstStsUrlInfo->aucX_amz_meta_file);
        }
        else
        {
            ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
                "PUT %s HTTP/1.1\r\n"
                "Host: %s\r\n"
                "Connection: keep-alive\r\n"
                "Date: %s\r\n"
                "Authorization: %s\r\n"
                "X-Amz-Security-Token: %s\r\n"
                "Content-Type: application/octet-stream\r\n"
                "Expect: 100-continue\r\n"
                "Transfer-Encoding: chunked\r\n\r\n",
                pstConn->stSocket.aucSubUri,pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, 
                pstConn->pstConnUrl->aucAuthorization,pstConn->pstConnUrl->pstStsUrlInfo->aucSessionToken);
        }
    }

    if(ilen >= CLOUDSTG_HTTP_HEADER_MAX_LEN)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Http header len: %d over maxlen", ilen);
        return MOS_ERR;
    }
    return iRet;
}
_INT CloudStg_GenReqHeader(ST_MECS_CONN *pstConn, _UI uiTargetSize)
{
    _UI  ilen = 0 ;
    _INT iRet = MOS_OK;
    MOS_PARAM_NULL_RETERR(pstConn);

    if (pstConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL)
    {
        ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
            "PUT %s HTTP/1.1\r\n"
            "Host: %s\r\n"
            "Date: %s\r\n"
            "Authorization: %s\r\n"
            "Content-Type: application/octet-stream\r\n"
            "Expect: 100-continue\r\n"
            "Content-Length: %u\r\n\r\n",
            pstConn->stSocket.aucSubUri, pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, pstConn->pstConnUrl->aucAuthorization,uiTargetSize);
    }
    else if(pstConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE && pstConn->uiType == EN_CLOUDSTG_RESOURCE_STREAM)
    {
        ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
            "PUT %s%d HTTP/1.1\r\n"
            "Host: %s\r\n"
            "Date: %s\r\n"
            "Content-Type: application/octet-stream\r\n"
            "Expect: 100-continue\r\n"
            "Content-Length: %u\r\n\r\n",
            pstConn->stSocket.aucSubUri,CloudStg_ExChanGetSentPosition(pstConn->hChanTask),pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate,uiTargetSize);
    }
    else if(pstConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE && pstConn->uiType == EN_CLOUDSTG_RESOURCE_PIC)
    {
        ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
            "PUT %s HTTP/1.1\r\n"
            "Host: %s\r\n"
            "Date: %s\r\n"
            "Content-Type: application/octet-stream\r\n"
            "Expect: 100-continue\r\n"
            "Content-Length: %u\r\n\r\n",
            pstConn->stSocket.aucSubUri,pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate,uiTargetSize);
    }
    else if (pstConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS && pstConn->uiType == EN_CLOUDSTG_RESOURCE_PIC)
    {
        iRet = CloudStg_Res_GenStsAuthorization(pstConn, pstConn->pstConnUrl->aucAuthorization, sizeof(pstConn->pstConnUrl->aucAuthorization), MOS_TRUE);
        MOS_FUNRET_ERR_RETERR(CLOUDSTG_LOGSTR, iRet, CloudStg_Res_GenStsAuthorization);
        if (pstConn->pstConnUrl->pstStsUrlInfo->uiX_amz_meta_commit != 0)
        {
            ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
                "PUT %s HTTP/1.1\r\n"
                "Host: %s\r\n"
                "Date: %s\r\n"
                "Authorization: %s\r\n"
                "X-Amz-Security-Token: %s\r\n"
                "Content-Type: application/octet-stream\r\n"
                "Expect: 100-continue\r\n"
                "Content-Length: %u\r\n\r\n",
                pstConn->stSocket.aucSubUri,pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, 
                pstConn->pstConnUrl->aucAuthorization,pstConn->pstConnUrl->pstStsUrlInfo->aucSessionToken,
                uiTargetSize);
        }
        else
        {
            ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
                "PUT %s HTTP/1.1\r\n"
                "Host: %s\r\n"
                "Date: %s\r\n"
                "Authorization: %s\r\n"
                "X-Amz-Security-Token: %s\r\n"
                "Content-Type: application/octet-stream\r\n"
                "Expect: 100-continue\r\n"
                "Content-Length: %u\r\n\r\n",
                pstConn->stSocket.aucSubUri,pstConn->stSocket.aucHost,pstConn->pstConnUrl->aucDate, 
                pstConn->pstConnUrl->aucAuthorization,pstConn->pstConnUrl->pstStsUrlInfo->aucSessionToken,uiTargetSize);
        }
    }

    pstConn->uiTargetSize = uiTargetSize;
    if(ilen >= CLOUDSTG_HTTP_HEADER_MAX_LEN)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Http header len over maxlen");
        return MOS_ERR;
    }
    return iRet;
}

_INT CloudStg_GenLocalFileReqHeader(ST_MECS_CONN *pstConn, _UI uiTargetSize)
{
    MOS_PARAM_NULL_RETERR(pstConn);

    _INT iRet = MOS_OK;
    _INT ilen = 0;
    _CTIME_T cTime = 0;
    _UC aucRandom[32] = {0};
    _UC aucPreMd5Buf[64] = {0};
    _UC aucOutput16[16] = {0};
    _UC aucMd5Sign[32 + 1] = {0};
    _UC aucDate[64] = {0};
    ST_MOS_SYS_TIME stSysTime;
    
    cTime = Mos_Time();

    // 创建handle时会输入开始时间戳、结束时间戳，需要返回若干个（数组或链表）修正（靠近I帧或出现跨文件现象）的开始时间戳、结束时间戳。
    Mos_TimetoSysTime(&cTime,&stSysTime);
    MOS_VSNPRINTF(aucDate,64,"%04hu-%02hu-%02hu %02hu-%02hu-%02hu",
                stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    MOS_VSNPRINTF(aucPreMd5Buf,sizeof(aucPreMd5Buf),"%u%s", cTime, CLOUDSTG_LOCAL_LOG_PUBLICKEY);
    Mos_MD5(aucPreMd5Buf, MOS_STRLEN(aucPreMd5Buf), aucOutput16);
    Mos_MD5_Decode16To32(aucOutput16, aucMd5Sign);

    MOS_MEMSET(pstConn->aucBoundary, 0x00, sizeof(pstConn->aucBoundary));
    Adapt_GenerateString(aucRandom, 25);
    MOS_VSNPRINTF(pstConn->aucBoundary, sizeof(pstConn->aucBoundary), "--------------------------%s", aucRandom);

    MOS_MEMSET(pstConn->aucFileName, 0x00, sizeof(pstConn->aucFileName));
    MOS_VSNPRINTF(pstConn->aucFileName, sizeof(pstConn->aucFileName), "DEV_%s_%s_%s.zip", Config_GetDeviceMng()->aucDevVerSion, Config_GetSystemMng()->aucDevUID, aucDate);

    uiTargetSize += CloudStg_GenLocalFileBoundaryHeader(pstConn) + CloudStg_GenLocalFileBoundaryEnd(pstConn);

    ilen = MOS_VSNPRINTF(pstConn->stSocket.aucHeader,CLOUDSTG_HTTP_HEADER_MAX_LEN ,
        "POST %s HTTP/1.1\r\n"
        "Host: %s\r\n"
        "date: %s\r\n"
        "deviceId: %s\r\n"
        "logVersion: %s\r\n"
        "sdkVersion: %d\r\n"
        "deviceVersion: %s\r\n"
        "t: %u\r\n"
        "sign: %s\r\n"
        "Connection: Keep-Alive\r\n"
        "Content-Type: multipart/form-data; boundary=%s\r\n"
        "Content-Length: %u\r\n\r\n",
        pstConn->stSocket.aucSubUri, pstConn->stSocket.aucHost,aucDate,Config_GetSystemMng()->aucDevUID,CLOUDSTG_LOCAL_LOG_VERSION,Config_GetDeviceMng()->uiSdkVersion,Config_GetDeviceMng()->aucDevVerSion,cTime,aucMd5Sign,pstConn->aucBoundary,uiTargetSize);
    pstConn->uiTargetSize = uiTargetSize;
    if(ilen >= CLOUDSTG_HTTP_HEADER_MAX_LEN)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Http header len over maxlen");
        return MOS_ERR;
    }
    return iRet;
}

_INT CloudStg_GenLocalFileBoundaryHeader(ST_MECS_CONN *pstConn)
{
    _INT iRet = MOS_OK;
    _INT ilen = 0;
    _UC  aucBoundaryHeader[256] = {0};
    
    ilen = MOS_VSNPRINTF(aucBoundaryHeader,sizeof(aucBoundaryHeader),
        "--%s\r\n"
        "Content-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n"
        "Content-Type: application/zip\r\n\r\n",
        pstConn->aucBoundary, pstConn->aucFileName);
    MOS_MEMSET(pstConn->aucBoundaryHeader, 0x00, sizeof(pstConn->aucBoundaryHeader));
    MOS_STRCPY(pstConn->aucBoundaryHeader, aucBoundaryHeader);

    return ilen;
}

_INT CloudStg_GenLocalFileBoundaryEnd(ST_MECS_CONN *pstConn)
{
    _INT iRet = MOS_OK;
    _INT ilen = 0;
    _UC  aucBoundaryEnd[64] = {0};
    
    ilen = MOS_VSNPRINTF(aucBoundaryEnd,sizeof(aucBoundaryEnd),
        "\r\n--%s--\r\n",
        pstConn->aucBoundary);
    MOS_MEMSET(pstConn->aucBoundaryEnd, 0x00, sizeof(pstConn->aucBoundaryEnd));
    MOS_STRCPY(pstConn->aucBoundaryEnd, aucBoundaryEnd);

    return ilen;
}

_INT CloudStg_HttpsRecvResHeader(_SSL_HANDLE hSSL, _UC *pucBuffer, _INT iBufSize, _UI *uiErrorCode)
{
    _INT iReadLen = 0;
    _INT iDataLen = 0;
    _UI uiTimeNow = 0;
    _UI uiMaxWaitTime = CLOUDSTG_HTTP_RES_WAIT_MAX_TIME;
    *uiErrorCode = 0;
    if (!hSSL || !pucBuffer)
    {
        return -100;
    }
    uiTimeNow = Mos_GetTickCount();
    while (iDataLen < iBufSize)
    {
        Adpt_SSL_Read(hSSL, pucBuffer + iDataLen, iBufSize - iDataLen, &iReadLen);
        if (0 >= iReadLen)
        {
            *uiErrorCode = Adpt_SSL_GetLastError(hSSL);
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "recv data len: %d, err=%u", iReadLen, *uiErrorCode);
            break;
        }
        iDataLen += iReadLen;
        if (iDataLen >= iBufSize)
        {
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "recv data too large: %d >= %d",iDataLen, iBufSize);
        }
        if (iDataLen > 4 && MOS_STRSTR(pucBuffer, (_UC *)"\r\n\r\n"))
        {
            break;
        }
        if (Mos_GetTickCount() - uiTimeNow > uiMaxWaitTime)
        {
            break;
        }
    }
    pucBuffer[iDataLen] = 0;
    return iDataLen;
}

_INT CloudStg_HttpRecvResHeader(_SOCKET hSocket, _UC *pucBuffer, _INT iBufSize, _UI *uiErrorCode)
{
    if ((hSocket == 0) || (hSocket == MOS_SOCKET_INVALID) || (pucBuffer == MOS_NULL))
    {
        return -100;
    }

    _INT iTmp = 0;
    _INT iReadLen = 0;
    _INT iDataLen = 0;
    _UI uiTimeNow = 0;
    _UI uiMaxWaitTime = CLOUDSTG_HTTP_RES_WAIT_MAX_TIME;
    *uiErrorCode = 0;
    uiTimeNow = Mos_GetTickCount();
    _INT iReRecvCount = 0;

    while (iDataLen < iBufSize)
    {
        iReadLen = Mos_SocketRecv(hSocket, pucBuffer + iDataLen, iBufSize - iDataLen, &iTmp);
        //返回值为0表明断连，iTmp等于ture表示需要断开socket              
        if ((iReadLen == 0)  ||  (iTmp == MOS_TRUE))
        {
            *uiErrorCode = Mos_SocketGetLastErr();
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "recv data len: %d, err=%u", iReadLen, *uiErrorCode);
            break;
        }
        else if (iReadLen < 0)//返回值为负数，且iTmp不为MOS_TRUE，表明需要重试
        {
            iReRecvCount++;
            if (iReRecvCount > 10)//连续重试10次都失败，则断开socket
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "recv data len: %d, err=%u ,ErrCount=%d",iReadLen, Mos_SocketGetLastErr(),iReRecvCount);
                break;
            }

            Mos_Sleep(10);
            continue;
        }

        iReRecvCount = 0;

        iDataLen += iReadLen;
        if (iDataLen >= iBufSize)
        {
            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "recv data too large: %d >= %d",iDataLen, iBufSize);
        }
        if (iDataLen > 4 && MOS_STRSTR(pucBuffer, (_UC *)"\r\n\r\n"))
        {
            break;
        }
        if (Mos_GetTickCount() - uiTimeNow > uiMaxWaitTime)
        {
            break;
        }
    }

    if (iDataLen >= 0)
    {
        pucBuffer[iDataLen] = 0;
    }
    
    return iDataLen;
}

_INT CloudStg_ProcResponse(ST_MECS_CONN* pstCSConn, ST_MECS_CONN_SOCKET *pstConnSocket, _UI uiType)
{
    MOS_PARAM_NULL_RETERR(pstConnSocket);

    _INT iTmp = 0;
    _INT iReadLen = 0;
    _UC aucRecvBuf[1024] = {0};
    _INT iResponseCode = 0;
    _UC *pucStr = 0;
    _UC aucUrl[512] = {0};
    _UC aucMsg[128] = {0};
    _UI uiErrorCode = 0;

    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", pstConnSocket->aucHost, pstConnSocket->aucSubUri);
    switch(pstConnSocket->uiHttpType)
    {
        case 1:
            {
                if (CloudStg_HttpsRecvResHeader(pstConnSocket->hSSL, aucRecvBuf, sizeof(aucRecvBuf) - 1, &uiErrorCode) <= 0)
                {
                    switch (uiType)
                    {
                        case EN_CLOUDSTG_RESOURCE_STREAM:
                        {
                            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [%staskid: %u] type: video recv fail, socket error: %u", 
                                         (pstCSConn->uiIsPatch==0)?"":"patch ", pstCSConn->iAliveTaskId, uiErrorCode);
                            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_VIDEO_UPLOAD_RECV_FAIL, aucMsg, 1);
                        }
                        break;
                        case EN_CLOUDSTG_RESOURCE_PIC:
                        {
                            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [taskid: %u] type: pic recv fail, socket error: %u", 
                                          pstCSConn->iAliveTaskId, uiErrorCode);
                            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_PIC_UPLOAD_RECV_FAIL, aucMsg, 1);
                        }
                        break;
                        case EN_CLOUDSTG_RESOURCE_LOGFILE:
                        {
                            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD type: logfile recv fail, socket error: %u", uiErrorCode);
                            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_LOGFILE_UPLOAD_RECV_FAIL, aucMsg, 1);
                        }
                        default:
                        break;
                    }
                    Qp_CountIF_Post(COUNT_TYPE_CLOUD_STOREFILE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
                    return MOS_ERR;
                }
                break;
            }
        case 0:
            {
                if (CloudStg_HttpRecvResHeader(pstConnSocket->hSocket, aucRecvBuf, sizeof(aucRecvBuf) - 1, &uiErrorCode) <= 0)
                {
                    switch (uiType)
                    {
                        case EN_CLOUDSTG_RESOURCE_STREAM:
                        {
                            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [%staskid: %u] type: video recv fail, socket error: %u", 
                                         (pstCSConn->uiIsPatch==0)?"":"patch ", pstCSConn->iAliveTaskId, uiErrorCode);
                            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_VIDEO_UPLOAD_RECV_FAIL, aucMsg, 1);
                        }
                        break;
                        case EN_CLOUDSTG_RESOURCE_PIC:
                        {
                            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [taskid: %u] type: pic recv fail, socket error: %u", 
                                          pstCSConn->iAliveTaskId, uiErrorCode);
                            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_PIC_UPLOAD_RECV_FAIL, aucMsg, 1);
                        }
                        break;
                        case EN_CLOUDSTG_RESOURCE_LOGFILE:
                        {
                            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD type: logfile recv fail, socket error: %u", uiErrorCode);
                            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_LOGFILE_UPLOAD_RECV_FAIL, aucMsg, 1);
                        }
                        default:
                        break;
                    }
                    Qp_CountIF_Post(COUNT_TYPE_CLOUD_STOREFILE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
                    return MOS_ERR;
                }
                break;
            }
    }
    pucStr = MOS_STRSTR(aucRecvBuf, (_UC *)"HTTP/1.1");
    if (pucStr == NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"invalid http %p : %s", pstConnSocket, aucRecvBuf);
        Qp_CountIF_Post(COUNT_TYPE_CLOUD_STOREFILE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    pucStr += MOS_STRLEN("HTTP/1.1");
    if ((pucStr==MOS_NULL) || ((++pucStr) ==MOS_NULL) )////add by hejh
    {
       MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"HTTP/1.1 parse error!!");
       return MOS_ERR;
    }
    //pucStr += 1;
    iResponseCode = MOS_ATOI(pucStr);
    if (100 == iResponseCode || 200 == iResponseCode)
    {
        if(iResponseCode == 200)
        {
            if (uiType != EN_CLOUDSTG_RESOURCE_LOGFILE)
            {
                pucStr = MOS_STRSTR(aucRecvBuf, (_UC *)"ETag: ");
                if ((pucStr != MOS_NULL) && ((pucStr+7)!=MOS_NULL))//add by hejh
                {
                    pucStr += 7;
                    MOS_SSCANF(pucStr,"%[^\"]",pstConnSocket->aucETag);
                }
                else
                {
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"ETag: parse error!!");
                }
            }
            Qp_CountIF_Post(COUNT_TYPE_CLOUD_STOREFILE, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
            if (uiType == EN_CLOUDSTG_RESOURCE_PIC)
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [taskid: %u] type: pic HTTP/1.1 200 OK", pstCSConn->iAliveTaskId);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_PIC_UPLOAD_SUCCESS, aucMsg, 1);
            }
            else if (uiType == EN_CLOUDSTG_RESOURCE_LOGFILE)
            {
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_LOGFILE_SUCCESS, "CD type: logfile HTTP/1.1 200 OK", 1);
            }
        }
        if (pstCSConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
        {
            if ((pucStr = MOS_STRSTR(aucRecvBuf, "x-rgw-next-append-position: ")))
            {
                if ((pucStr+28) != MOS_NULL)
                {
                    pucStr += 28;
                    CloudStg_ExChanSetSentPosition(pstCSConn->hChanTask, MOS_ATOI(pucStr));
                    // MOS_PRINTF("%s:%d set sent position: %d\r\n", __FUNCTION__, __LINE__, MOS_ATOI(pucStr));
                }
                else
                {
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"ETag: parse error!!");
                }
            }
        }
        MOS_PRINTF((_UC *)"http response(0x%x)[type:%d]: %s", pstConnSocket, uiType, aucRecvBuf);
        return MOS_OK;
    }
    else
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUD_STOREFILE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        switch (uiType)
        {
            case EN_CLOUDSTG_RESOURCE_STREAM:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [%staskid: %u] type: video HTTP/1.1 %d", 
                                (pstCSConn->uiIsPatch==0)?"":"patch ", pstCSConn->iAliveTaskId, iResponseCode);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, iResponseCode, EN_CLOUDSTG_RT_VIDEO_UPLOAD_RSP_ERR, aucMsg, 1);
            }
            break;
            case EN_CLOUDSTG_RESOURCE_PIC:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [taskid: %u] type: pic HTTP/1.1 %d", 
                                pstCSConn->iAliveTaskId, iResponseCode);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, iResponseCode, EN_CLOUDSTG_RT_PIC_UPLOAD_RSP_ERR, aucMsg, 1);
            }
            break;
            case EN_CLOUDSTG_RESOURCE_LOGFILE:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD type: logfile HTTP/1.1 %d", iResponseCode);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, iResponseCode, EN_CLOUDSTG_RT_LOGFILE_UPLOAD_RSP_ERR, aucMsg, 1);
            }
            default:
            break;
        }
        switch(pstConnSocket->uiHttpType)
        {
            case 1:
                {
                    Adpt_SSL_Read(pstConnSocket->hSSL, aucRecvBuf, (_INT)sizeof(aucRecvBuf) - 1, &iReadLen);
                    break;
                }
            case 0:
                {
                    iReadLen = Mos_SocketRecv(pstConnSocket->hSocket, aucRecvBuf, (_INT)sizeof(aucRecvBuf) - 1,&iTmp);
                    break;
                }
            default:
                {

                }
        }
        if (iReadLen > 0)
        {
            aucRecvBuf[iReadLen] = 0;
            MOS_PRINTF(CLOUDSTG_LOGSTR, (_UC *)"http response(0x%x): %s",  pstConnSocket, aucRecvBuf);
        }
        else
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "failed to recv http response body(0x%x): %d", pstConnSocket, iReadLen);
        }
    }
    return MOS_ERR;
}

_INT CloudStg_SendData(ST_MECS_CONN* pstCSConn, _UC *paucData, _UI uiLen, _UI *puiSendLen, _INT *iError)
{
    MOS_PARAM_NULL_RETERR(pstCSConn);
    MOS_PARAM_NULL_RETERR(paucData);

    _INT iTmp = 0;
    _INT iWrittenLen = 0;
    _UI uiBeginTick = 0;
    _UI uiEndTick = 0;
    ST_MECS_CONN_SOCKET *pstConnSocket = MOS_NULL;
    pstConnSocket = &pstCSConn->stSocket;
    *iError = 0;
    
    uiBeginTick = Mos_GetTickCount();
    switch(pstConnSocket->uiHttpType)
    {
        case 1:
            {
                iTmp = Adpt_SSL_Write(pstConnSocket->hSSL, paucData , uiLen, &iWrittenLen);
                if (ITRD_OK != iTmp || iWrittenLen < 0 || iWrittenLen != uiLen)
                {
                    *iError = Adpt_SSL_GetLastError(pstConnSocket->hSSL);
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR, "[%staskid: %u]failed to ssl_write [%s%s] len:%d bytes:ssl error=%d, iWrittenLen=%d, sent=%u"
                        , pstCSConn->uiIsPatch==1?"patch ":""
                        , pstCSConn->iAliveTaskId
                        , pstConnSocket->aucHost
                        , pstConnSocket->aucSubUri, uiLen
                        , *iError,iWrittenLen,pstConnSocket->uiSentCount);
                    
                    if((((*iError == 11) || (*iError == 38) || (*iError == 4)) && (puiSendLen != MOS_NULL)) || (iWrittenLen > 0))
                    {
                        if (iWrittenLen >= 0)
                        {
                            *puiSendLen = iWrittenLen;
                            pstConnSocket->uiSentCount += iWrittenLen;
                        }
                        else
                        {
                            *puiSendLen = 0;
                        }
                        return MOS_ERR_TRYAGAIN;
                    }
                    return MOS_ERR;
                }
                break;
            }
        case 0:
            {
                iWrittenLen = Mos_SocketSend(pstConnSocket->hSocket, paucData , uiLen, &iTmp);
                if (iWrittenLen < 0 || iWrittenLen != uiLen)
                {
                    *iError = Mos_SocketGetLastErr();
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR, "[%staskid: %u]failed to write [%s%s] len:%d bytes:error=%d, iWrittenLen=%d, sent=%u"
                        , pstCSConn->uiIsPatch==1?"patch ":""
                        , pstCSConn->iAliveTaskId
                        , pstConnSocket->aucHost
                        , pstConnSocket->aucSubUri, uiLen
                        , *iError,iWrittenLen,pstConnSocket->uiSentCount);

                    if((((*iError == 11) || (*iError == 38) || (*iError == 4)) && (puiSendLen != MOS_NULL)) || (iWrittenLen > 0))
                    {
                        if (iWrittenLen >= 0)
                        {
                            *puiSendLen = iWrittenLen;
                            pstConnSocket->uiSentCount += iWrittenLen;
                        }
                        else
                        {
                            *puiSendLen = 0;
                        }
                        return MOS_ERR_TRYAGAIN;
                    }
                    return MOS_ERR;
                }
                break;
            }
        default:
            {
          
            }
    }
    pstConnSocket->uiSentCount += iWrittenLen;
    uiEndTick = Mos_GetTickCount();
    if (uiEndTick - uiBeginTick >= 1500)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "[%staskid: %u]too long time (%u) to send: connsocket=0x%x", pstCSConn->uiIsPatch==1?"patch ":"", pstCSConn->iAliveTaskId, uiEndTick - uiBeginTick, pstConnSocket);
    }
    return MOS_OK;
}

_INT CloudStg_ProcHeader(ST_MECS_CONN* pstCSConn, _UI uiTargetSize)
{
    MOS_PARAM_NULL_RETERR(pstCSConn);
    MOS_PARAM_NULL_RETERR(pstCSConn->pstConnUrl);

    _INT iRet = MOS_ERR;
    _INT iError = 0;
    _UI uiLenToSend = 0;
    _UC aucUrl[256] = {0};
    _UC aucMsg[512] = {0};
    
    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", pstCSConn->stSocket.aucHost, pstCSConn->stSocket.aucSubUri);
    if(pstCSConn->pstConnUrl->iStorageType == 2 && pstCSConn->uiType == EN_CLOUDSTG_RESOURCE_STREAM && pstCSConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL)
    {
        iRet = CloudStg_GenChunkedReqHeader(pstCSConn);
        MOS_FUNRET_ERR_RETERR(CLOUDSTG_LOGSTR, iRet, CloudStg_GenChunkedReqHeader);
    }
    else if (pstCSConn->pstConnUrl->iStorageType == 2 && pstCSConn->uiType == EN_CLOUDSTG_RESOURCE_STREAM && pstCSConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
    {
        iRet = CloudStg_GenStsChunkedReqHeader(pstCSConn);
        MOS_FUNRET_ERR_RETERR(CLOUDSTG_LOGSTR, iRet, CloudStg_GenStsChunkedReqHeader);
    }
    else if(pstCSConn->uiType == EN_CLOUDSTG_RESOURCE_LOGFILE)
    {
        iRet = CloudStg_GenLocalFileReqHeader(pstCSConn, uiTargetSize);
        MOS_FUNRET_ERR_RETERR(CLOUDSTG_LOGSTR, iRet, CloudStg_GenLocalFileReqHeader);
    }
    else
    {
        iRet = CloudStg_GenReqHeader(pstCSConn, uiTargetSize);
        MOS_FUNRET_ERR_RETERR(CLOUDSTG_LOGSTR, iRet, CloudStg_GenReqHeader);
    }
    uiLenToSend = MOS_STRLEN(pstCSConn->stSocket.aucHeader);
    MOS_PRINTF("req header(0x%x)[type: %d][len: %d]: %s\r\n", &pstCSConn->stSocket, pstCSConn->uiType, uiLenToSend, pstCSConn->stSocket.aucHeader);
    iRet = CloudStg_SendData(pstCSConn, pstCSConn->stSocket.aucHeader, uiLenToSend, MOS_NULL, &iError);
    if (iRet == MOS_OK)
    {
        CloudStg_AddSentBytes(pstCSConn->uiIsPatch, 0, pstCSConn->iAliveTaskId, uiLenToSend);
    }
    else
    {
        switch (pstCSConn->uiType)
        {
            case EN_CLOUDSTG_RESOURCE_STREAM:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [%staskid: %u] type: video send data error, socket error: %d, linkv%d, hasipv6addr: %d", 
                                (pstCSConn->uiIsPatch==0)?"":"patch ", pstCSConn->iAliveTaskId, iError, 
                                pstCSConn->stSocket.uiConnType==EN_CINET_TYPE_IPV4?4:6, pstCSConn->stSocket.uiHasIpv6);
                // 用于统计设备是否具备IPv6地址
                if (MOS_STRLEN(Config_GetCamaraMng()->aucLocalIPv6Addr) > 0)
                {
                    _UC aucStrcatBuf[128] = {0};
                    MOS_SPRINTF(aucStrcatBuf, ", localv6: %s", Config_GetCamaraMng()->aucLocalIPv6Addr);
                    MOS_STRCAT(aucMsg, aucStrcatBuf);
                }
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_VIDEO_UPLOAD_FAIL, aucMsg, 1);
            }
            break;
            case EN_CLOUDSTG_RESOURCE_PIC:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [taskid: %u] type: pic send data error, socket error: %d", 
                                pstCSConn->iAliveTaskId, iError);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_PIC_UPLOAD_FAIL, aucMsg, 1);
            }
            break;
            case EN_CLOUDSTG_RESOURCE_LOGFILE:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD type: logfile send data error, socket error: %d", iError);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_LOGFILE_UPLOAD_FAIL, aucMsg, 1);
            }
            default:
            break;
        }
        return MOS_ERR;
    }
    if(pstCSConn->uiType != EN_CLOUDSTG_RESOURCE_LOGFILE)
    {
        iRet = CloudStg_ProcResponse(pstCSConn, &pstCSConn->stSocket, pstCSConn->uiType);
        MOS_FUNRET_ERR_RETERR(CLOUDSTG_LOGSTR, iRet, CloudStg_ProcResponse);
    }
    return MOS_OK;
}

_INT CloudStg_ConnRecvRsp(_HCSCONN hCSConn)
{
    _INT iRet = MOS_ERR;
    ST_MECS_CONN* pstCSConn = (ST_MECS_CONN*)hCSConn;
    if (pstCSConn == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstCSConn->bRsponseRecv == MOS_FALSE)
    {
        iRet = CloudStg_ProcResponse(hCSConn, &pstCSConn->stSocket, pstCSConn->uiType);
    }
    MOS_FUNRET_ERR_RETERR(CLOUDSTG_LOGSTR, iRet, CloudStg_ProcResponse);

    pstCSConn->bRsponseRecv = MOS_TRUE;
    return MOS_OK;
}

/************************************************************************
分配资源
*************************************************************************/
_HCSCONN CloudStg_ConnOpen(_VPTR pstTask, _INT iAliveTaskId, _UI uiType, _UI uiTargetSize, _UI uiIsPatch, _INT iCloudEncSwitch, _INT iDirectMode)
{
    ST_MECS_CONN *pstCSConn = MOS_NULL;
    pstCSConn = (ST_MECS_CONN *)CloudStg_ResMallocConnMem();
    pstCSConn->uiType        = uiType;
    pstCSConn->uiSliceSize   = uiTargetSize;
    pstCSConn->pstConnUrl    = MOS_NULL;
    pstCSConn->bHeaderSent   = MOS_FALSE;
    pstCSConn->bRsponseRecv  = MOS_FALSE;
    pstCSConn->iSendTimes    = 0;
    pstCSConn->uiIsPatch     = uiIsPatch;
    pstCSConn->iAliveTaskId  = iAliveTaskId;
    pstCSConn->stSocket.hSocket = MOS_SOCKET_INVALID;
    pstCSConn->iCloudEncSwitch  = iCloudEncSwitch;
	pstCSConn->hChanTask     = pstTask;
    pstCSConn->iDirectMode   = iDirectMode;
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "Open Conn, The address is 0x%x, useflag:%d", pstCSConn, pstCSConn->uiUseFlag);
    return (_HCSCONN)pstCSConn;
}

/******************************************************************
建立连接 
******************************************************************/
_INT CloudStg_ConnStart(_HCSCONN hCSConn,_UI uiPicUrl)
{
    _INT iRet = MOS_ERR;
    ST_MECS_CONN *pstCSConn = (ST_MECS_CONN *)hCSConn;

    if(pstCSConn == MOS_NULL)
    {
        return MOS_ERR;
    }

    if (1 != pstCSConn->uiUseFlag)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "invalid resource magic, address: 0x%x, UseFlag: %d", pstCSConn, pstCSConn->uiUseFlag);
        return MOS_ERR;
    }

    // 获取上传地址
    if(MOS_NULL == pstCSConn->pstConnUrl)
    {
        if (pstCSConn->uiType == EN_CLOUDSTG_RESOURCE_LOGFILE)
        {
            pstCSConn->pstConnUrl = CloudStg_ResLocalFileUrl();
        }
        else
        {
            MOS_LOG_INF(CLOUDSTG_LOGSTR, "Get a url from urlpool, type: %u", pstCSConn->uiType);
            for(;;)
            {
                pstCSConn->pstConnUrl = CloudStg_ResAllocUrl(pstCSConn->uiType,pstCSConn->iDirectMode,uiPicUrl);

                if (pstCSConn->pstConnUrl != MOS_NULL)
                {
                    if (pstCSConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstCSConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
                    {
                        break;
                    }
                    else if (pstCSConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
                    {
                        // 保证视频的时长仍在地址的生命周期内
                        if (Mos_Time() + Config_GetCloudMng()->iVideoDuration + CLOUDSTG_GET_THREEMINUTE > pstCSConn->pstConnUrl->cUrlTime)
                        {
                            MOS_LOG_INF(CLOUDSTG_LOGSTR, "Get almost expired url %u, free now one and recvive again!", pstCSConn->pstConnUrl->cUrlTime);
                            CloudStg_ResFreeUrl(pstCSConn->pstConnUrl);
                            pstCSConn->pstConnUrl = MOS_NULL;
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                else
                {
                    break;
                }
            }
            MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstCSConn->pstConnUrl,CloudStg_ResAllocUrl);
        }
    }

    // 准备sts的参数
    if (pstCSConn->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS && (pstCSConn->uiType == EN_CLOUDSTG_RESOURCE_STREAM || pstCSConn->uiType == EN_CLOUDSTG_RESOURCE_PIC))
    {
        if (CloudStg_ConnStsInfoPrepare(pstCSConn, pstCSConn->uiType) == MOS_ERR)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "failed to prepare sts info");
            return MOS_ERR;
        }
    }
    // 创建连接
    iRet = CloudStg_CreateSocket(pstCSConn->pstConnUrl,&pstCSConn->stSocket);
    if (MOS_OK != iRet)
    {
        CloudStg_CloseSocket(&pstCSConn->stSocket);
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "failed to create socket");
        return MOS_ERR; 
    }

    // 连接服务器
    iRet = CloudStg_OpenSocket(&pstCSConn->stSocket, pstCSConn->uiType);
    if (MOS_OK != iRet)
    {
        _UC aucMsg[512] = {0};
        CloudStg_CloseSocket(&pstCSConn->stSocket);
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "failed to open conn %p ", pstCSConn);
        MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "cloud file connect failed, hasipv6addr: %d", pstCSConn->stSocket.uiHasIpv6);
        // 用于统计设备是否具备IPv6地址
        if (MOS_STRLEN(Config_GetCamaraMng()->aucLocalIPv6Addr) > 0)
        {
            _UC aucStrcatBuf[128] = {0};
            MOS_SPRINTF(aucStrcatBuf, ", localv6: %s", Config_GetCamaraMng()->aucLocalIPv6Addr);
            MOS_STRCAT(aucMsg, aucStrcatBuf);
        }
        CloudStg_UploadLog(Mos_GetSessionId(), pstCSConn->pstConnUrl, 0, EN_CLOUDSTG_RT_VIDEO_UPLOAD_FAIL, aucMsg, 1);
        return MOS_ERR;
    }
    if (pstCSConn->uiType == EN_CLOUDSTG_RESOURCE_STREAM)
    {
        ST_CLOUDSTG_TASK_NODE *pstTaskTmp = CloudStg_FindTaskNode(pstCSConn->uiIsPatch,pstCSConn->iAliveTaskId);
        if (pstTaskTmp)
        {
            pstTaskTmp->uiConnType = pstCSConn->stSocket.uiConnType;// 获取socket的连接状态
            pstTaskTmp->uiHasIpv6 = pstCSConn->stSocket.uiHasIpv6;
        }
    }

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud conn open conn (0x%x) url %p", pstCSConn,pstCSConn->pstConnUrl);
    return MOS_OK;
}

_INT CloudStg_ConnStop(_HCSCONN hCSConn, _INT iForce)
{
    ST_MECS_CONN *pstCSConn = (ST_MECS_CONN *)hCSConn;
    if(pstCSConn == MOS_NULL || pstCSConn->uiUseFlag == 0)
    {
        return MOS_OK;
    }
    CloudStg_CloseSocket(&pstCSConn->stSocket);
    if (iForce)
    {
        if(pstCSConn->pstConnUrl)
        {
            CloudStg_ResFreeUrl(pstCSConn->pstConnUrl);
            pstCSConn->pstConnUrl = MOS_NULL;
        }
    }
    pstCSConn->bRsponseRecv = MOS_FALSE;
    pstCSConn->bHeaderSent  = MOS_FALSE;
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "Mecs conn stop, conn(0x%x) %s", pstCSConn, iForce?", force free url":"");
    return MOS_OK;
}

_INT CloudStg_ConnClose(_HCSCONN hCSConn, _INT iForce)
{
    ST_MECS_CONN *pstCSConn = (ST_MECS_CONN *)hCSConn;

    if (pstCSConn == MOS_NULL || pstCSConn->uiUseFlag == 0)
    {
        return MOS_OK;
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "close Conn, conn(%p),uri(%p) %s", pstCSConn, pstCSConn->pstConnUrl, iForce?", force free url":"");
    CloudStg_CloseSocket(&pstCSConn->stSocket);
	if (iForce)
    {
        if(pstCSConn->pstConnUrl)
        {
            CloudStg_ResFreeUrl(pstCSConn->pstConnUrl);
            pstCSConn->pstConnUrl = MOS_NULL;
        }
        CloudStg_ResFreeConnMem((_VOID*)pstCSConn);
    }
    return MOS_OK;
}

_INT CloudStg_ConnSocketClose(_HCSCONN hCSConn)
{
    ST_MECS_CONN *pstCSConn = (ST_MECS_CONN *)hCSConn;
    if(pstCSConn == MOS_NULL)
    {
        return MOS_ERR;
    }
    CloudStg_CloseSocket(&pstCSConn->stSocket);
    pstCSConn->bRsponseRecv  = MOS_FALSE;
    pstCSConn->bHeaderSent   = MOS_FALSE;
    return MOS_OK;
}

_VOID CloudStg_ConnShutDown(_HCSCONN hCSConn)
{
    ST_MECS_CONN *pstCSConn = (ST_MECS_CONN *)hCSConn;
    if(pstCSConn == MOS_NULL)
    {
        return;
    }
    if (MOS_NULL != pstCSConn->stSocket.hSSL)
    {
        Adpt_SSL_ShutDown(pstCSConn->stSocket.hSSL);
    }    
    if (MOS_SOCKET_INVALID != pstCSConn->stSocket.hSocket)
    {
        Mos_SocketShutDown(pstCSConn->stSocket.hSocket,EN_CINET_SHTDWN_BOTH);
    }
    return;
}

/****************************************************************************
推送到 亚马逊 
首先发送 请求 ， 然后发送数据
*****************************************************************************/
_INT CloudStg_ConnSend(_HCSCONN hCSConn, _UC *pucData, _UI uiLen, _UI uiFlag,_UI *puiSendLen)
{
    MOS_PARAM_NULL_RETERR(pucData);

    _INT i = 0,iRet = 0,iLen = 0;
    _INT iError      =  0;
    _UC  aucUrl[512] = {0};
    _UC  aucMsg[512] = {0};
    ST_MECS_CONN *pstCSConn = (ST_MECS_CONN*)hCSConn;

    if(pstCSConn == MOS_NULL || pstCSConn->uiUseFlag == 0 || pucData == MOS_NULL)
    {
        return MOS_ERR;
    }
    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", pstCSConn->stSocket.aucHost, pstCSConn->stSocket.aucSubUri);

    // 先发头, 重试2次
    if(pstCSConn->bHeaderSent == MOS_FALSE)
    {
        for (i = 0; i < 2; ++ i)
        {
            iRet = CloudStg_ProcHeader(pstCSConn, pstCSConn->uiSliceSize);
            if (MOS_OK != iRet)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "failed(%d) to send header(%p): %s", i, pstCSConn, pstCSConn->stSocket.aucSubUri);
                Mos_Sleep(100);
            }
            else
            {
                if (pstCSConn->uiType != EN_CLOUDSTG_RESOURCE_LOGFILE)
                {
                    pstCSConn->bHeaderSent = MOS_TRUE;
                }
                break;
            }
        }
    }

    // logfile发送Boundary头部
    if(pstCSConn->uiType == EN_CLOUDSTG_RESOURCE_LOGFILE && pstCSConn->bHeaderSent != MOS_TRUE)
    {
        iLen = MOS_STRLEN(pstCSConn->aucBoundaryHeader);
        MOS_PRINTF(CLOUDSTG_LOGSTR, "2...req header(0x%x)[%d]: %s", &pstCSConn->stSocket, iLen, pstCSConn->aucBoundaryHeader);
        iRet = CloudStg_SendData(pstCSConn, pstCSConn->aucBoundaryHeader, iLen, MOS_NULL, &iError);
        if (iRet == MOS_OK)
        {
            CloudStg_AddSentBytes(pstCSConn->uiIsPatch, 0, pstCSConn->iAliveTaskId, iLen);
        }
        else
        {
            MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD type: logfile send data error, socket error: %d", iError);
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_LOGFILE_UPLOAD_FAIL, aucMsg, 1);
            return MOS_ERR;
        }
        pstCSConn->bHeaderSent = MOS_TRUE;
    }

    if (pstCSConn->bHeaderSent != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "have not sent header(%p): %s", pstCSConn, pstCSConn->stSocket.aucSubUri);
        if(uiFlag == 1)
        {
            // 请求头发送失败
            CloudStg_ConnStop((_HCSCONN)pstCSConn, 1);
        }
        return MOS_ERR;
    }

    // 解决萤石等设备在fttr路由器上发包数据错乱问题，
    // 在每包间隔加0.1ms延时，加asm volatile防止被编译器优化
    for (i = 0; i < 10000; i++){asm volatile("");}

    // 再发内容
    iRet = CloudStg_SendData(pstCSConn, pucData, uiLen, puiSendLen, &iError);
    if (iRet == MOS_ERR)
    {
        switch (pstCSConn->uiType)
        {
            case EN_CLOUDSTG_RESOURCE_STREAM:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [%staskid: %u] type: video send data error, socket error: %d, hasipv6addr: %d", 
                                (pstCSConn->uiIsPatch==0)?"":"patch ", pstCSConn->iAliveTaskId, iError, pstCSConn->stSocket.uiHasIpv6);
                // 用于统计设备是否具备IPv6地址
                if (MOS_STRLEN(Config_GetCamaraMng()->aucLocalIPv6Addr) > 0)
                {
                    _UC aucStrcatBuf[128] = {0};
                    MOS_SPRINTF(aucStrcatBuf, ", localv6: %s", Config_GetCamaraMng()->aucLocalIPv6Addr);
                    MOS_STRCAT(aucMsg, aucStrcatBuf);
                }
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_VIDEO_UPLOAD_FAIL, aucMsg, 1);
            }
            break;
            case EN_CLOUDSTG_RESOURCE_PIC:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD [taskid: %u] type: pic send data error, socket error: %d", 
                                pstCSConn->iAliveTaskId, iError);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_PIC_UPLOAD_FAIL, aucMsg, 1);
            }
            break;
            case EN_CLOUDSTG_RESOURCE_LOGFILE:
            {
                MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD type: logfile send data error, socket error: %d", iError);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_LOGFILE_UPLOAD_FAIL, aucMsg, 1);
            }
            default:
            break;
        }
    }
    return iRet; 
}

// Deprecated
_INT CloudStg_ConnSendExt(_UC *pucData, _UI uiLen,_UI uiType,
    _UC aucFid[CLOUDSTG_FID_LEN],_UC aucBucket[CLOUDSTG_BUCKET_LEN],_UC aucName[CLOUDSTG_KEY_LEN])
{
    MOS_PARAM_NULL_RETERR(pucData);

    _INT iRet = MOS_OK;
    ST_MECS_CONN *pstCSConn = (ST_MECS_CONN *)CloudStg_ResMallocConnMem();
    if(pstCSConn == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCSConn->uiType        = uiType;
    pstCSConn->uiSliceSize   = uiLen;
    pstCSConn->bHeaderSent   = MOS_FALSE;
    pstCSConn->bRsponseRecv  = MOS_FALSE;

    iRet = CloudStg_ConnStart((_HCSCONN)pstCSConn,0);
    if(iRet != MOS_OK)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Mecs conn start fail,%p",pstCSConn); 
        CloudStg_ConnClose((_HCSCONN)pstCSConn, 1);
        return iRet;
    }
    iRet =  CloudStg_ConnSend((_HCSCONN)pstCSConn, pucData, uiLen,0,MOS_NULL);
    if(iRet == MOS_OK)
    {
        CloudStg_AddSentBytes(pstCSConn->uiIsPatch, 0, pstCSConn->iAliveTaskId, uiLen);
        MOS_STRLCPY(aucFid, pstCSConn->pstConnUrl->aucFid, CLOUDSTG_FID_LEN);
        MOS_STRLCPY(aucBucket, pstCSConn->pstConnUrl->aucBucket, CLOUDSTG_BUCKET_LEN);
        MOS_STRLCPY(aucName, pstCSConn->pstConnUrl->aucName, CLOUDSTG_KEY_LEN);
        printf("%s:%d call CloudStg_ConnRecvRsp\r\n", __FUNCTION__, __LINE__);
        CloudStg_ConnRecvRsp((_HCSCONN)pstCSConn);
    }
    else
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Mecs conn send fail,%p",pstCSConn);
    }
    CloudStg_ConnClose((_HCSCONN)pstCSConn, 1);
    return iRet;
}

_INT CloudStg_ConnStsInfoPrepare(ST_MECS_CONN *pstConn, _UI uiType)
{
    MOS_PARAM_NULL_RETERR(pstConn);
    ST_CLOUDSTG_RES_URL *pstConnUri = (ST_CLOUDSTG_RES_URL *)pstConn->pstConnUrl;
    _UC aucUrl[1024] = {0};
    _UC aucFileName[128] = {0};
    _CTIME_T cNowTime = 0;
    _CTIME_T cEndTime = 0;
    ST_MOS_SYS_TIME stSysTime;	
    ST_MOS_SYS_TIME stTmpSysTime;	
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
    
    pstTaskNode = CloudStg_FindTaskNode(pstConn->uiIsPatch,pstConn->iAliveTaskId);
    if (pstTaskNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, (_UC *)"Can't find proper tasknode with parameters: %u, %d", 
                    pstConn->uiIsPatch, pstConn->iAliveTaskId);
        return MOS_ERR;
    }

    if (pstTaskNode->tStsCreateTime == 0)
    {
        cNowTime = Mos_Time();
        pstTaskNode->tStsCreateTime = cNowTime;
    }
    else
    {
        cNowTime = pstTaskNode->tStsCreateTime;
    }
    Mos_TimetoSysTime(&cNowTime,&stSysTime);

    if (uiType == EN_CLOUDSTG_RESOURCE_STREAM)
    {
        MOS_VSNPRINTF(aucFileName, sizeof(aucFileName),"%04hu%02hu%02hu%02hu%02hu%02hu",
                    stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
    }
    else if (uiType == EN_CLOUDSTG_RESOURCE_PIC)
    {
        MOS_VSNPRINTF(aucFileName, sizeof(aucFileName),"%04hu%02hu%02hu%02hu%02hu%02huP",
                    stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
    }

    // 准备地址
    MOS_MEMSET(aucUrl, 0x00, sizeof(aucUrl));
    MOS_MEMSET(pstConnUri->aucUrl, 0x00, sizeof(pstConnUri->aucUrl));
    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "http://%s/%s/%s/%s/%s", pstConnUri->pstStsUrlInfo->aucEndpoint, pstConnUri->pstStsUrlInfo->aucBktName, pstConnUri->pstStsUrlInfo->aucUploadPath, Config_GetSystemMng()->aucDid, aucFileName);
    MOS_STRLCPY(pstConnUri->aucUrl, aucUrl, sizeof(pstConnUri->aucUrl));
    // MOS_PRINTF("Url: %s, type: %d\r\n", pstConnUri->aucUrl, uiType);

    // 准备objId、SP
    MOS_VSNPRINTF(pstConnUri->aucFid, sizeof(pstConnUri->aucFid), "%s/%s/%s", pstConnUri->pstStsUrlInfo->aucUploadPath, Config_GetSystemMng()->aucDid, aucFileName);
    MOS_STRLCPY(pstConnUri->aucStorageProvider, "OOS", sizeof(pstConnUri->aucStorageProvider));
    // MOS_PRINTF("pstConnUri->aucFid: %s\r\n", pstConnUri->aucFid);

    // 准备时间
    Mos_TimestampToRFC1123(cNowTime-28800, pstConnUri->aucDate);

    // 准备自动commit info
    if (pstConnUri->pstStsUrlInfo->uiX_amz_meta_commit != 0)
    {
        if (uiType == EN_CLOUDSTG_RESOURCE_STREAM)
        {
            cEndTime = cNowTime + pstTaskNode->uiDuration;
            Mos_TimetoSysTime(&cEndTime,&stTmpSysTime);
            MOS_VSNPRINTF(pstConnUri->pstStsUrlInfo->aucX_amz_meta_file, sizeof(pstConnUri->pstStsUrlInfo->aucX_amz_meta_file),
                        "%04hu%02hu%02hu%02hu%02hu%02hu-%04hu%02hu%02hu%02hu%02hu%02hu.ps|1|%d|%d",
                        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond,
                        stTmpSysTime.usYear,stTmpSysTime.usMonth,stTmpSysTime.usDay,stTmpSysTime.usHour,stTmpSysTime.usMinute,stTmpSysTime.usSecond,
                        pstTaskNode->iCloudUpLoadMode,Config_GetCloudMng()->iCloudIconType);
        }
        else if (uiType == EN_CLOUDSTG_RESOURCE_PIC)
        {
            MOS_VSNPRINTF(pstConnUri->pstStsUrlInfo->aucX_amz_meta_file, sizeof(pstConnUri->pstStsUrlInfo->aucX_amz_meta_file),
                        "%04hu%02hu%02hu%02hu%02hu%02hu.jpg|2|%d|%d",
                        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond,
                        pstTaskNode->iCloudUpLoadMode,Config_GetCloudMng()->iCloudIconType);
        }
    }
    pstTaskNode->uiAutoCommit = pstConnUri->pstStsUrlInfo->uiX_amz_meta_commit;
    // MOS_PRINTF("AliveTaskId: %d uiX_amz_meta_commit: %d pstTaskNode->uiAutoCommit: %d\r\n", pstConn->iAliveTaskId, pstConnUri->pstStsUrlInfo->uiX_amz_meta_commit, pstTaskNode->uiAutoCommit);
    return MOS_OK;
}
