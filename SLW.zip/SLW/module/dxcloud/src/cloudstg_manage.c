#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "config_type.h"
#include "config_api.h"
#include "config_system.h"
#include "media_cache_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "record_api.h"
#include "snap_api.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_stream_prv.h"
#include "cloudstg_manage.h"
#include "cloudstg_aliveupload.h"
#include "cloudstg_transaddress.h"
#include "cloudstg_event.h"
#include "cloudstg_patch.h"
#include "cloudstg_logcode.h"
#include "kjiot_device_api.h"
#include "msgmng_cmdserver.h"
#include "watchdog_api.h"
#include "msgmng_event.h"
#include "qualityprobe_api.h"
#include "msgmng_quality_statistics.h"

static ST_CLOUDSTG_MANAGE g_stCloudMng;

static _INT CloudStg_TaskLoop(_VPTR pParam);

static _VOID CloudstgEventInfUploadProc(_CTIME_T cNowTime);


/**********************************************************************
***********************************************************************/
ST_CLOUDSTG_MANAGE *CloudStg_GetMng()
{
    return &g_stCloudMng;
}

_VOID CloudstgSetCameraStatusChangeFlag(_UI uiChangeFlag)
{
    CloudStg_GetMng()->ucCameraStatusChangeFlag = uiChangeFlag;
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud Camera Status Change Flag %d",CloudStg_GetMng()->ucCameraStatusChangeFlag);
}

static _UC* CloudStg_BuildGetInfoReqData(_UI uiTaskId, _CTIME_T cNowTime)
{
    _INT i;
    _INT iCinfoVersion = 1;
    _INT iFixLen = 0;
    _INT iTotalLen = 0;
    _UC aucURLEnc[512] = {0};
    _UC *pstrTmp = MOS_NULL;
    _UC *pucParams = MOS_NULL;
    _UC *pucSignBuff = MOS_NULL;
    _UC aucAesParams[32] = {0};
    _UC aucBuff[512];
    _UC aucAesKey[128] = {'\0'};
    JSON_HANDLE hRoot = MOS_NULL, hValue = MOS_NULL;
    ST_CFG_SYSTEM_MNG *pstCompanyInf = Config_GetSystemMng();
    ST_CFG_CLOUDSTG_MNG *pstCloudInfo = Config_GetCloudMng();
    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    MOS_VSNPRINTF(aucBuff, 8, (_UC*)"%02x%02x", EN_CLOUDSTG_TRANS_BUFF, EN_CLOUDSTG_GETINFO_REQ);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"METHOD", Adpt_Json_CreateString((_UC*)aucBuff));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiTaskId));

    hValue = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hValue, (_UC*)"uid", Adpt_Json_CreateString(pstCompanyInf->aucDevUID));

    Adpt_Json_AddItemToObject(hValue, (_UC*)"appKey", Adpt_Json_CreateString(pstCloudInfo->aucAppKey));

    MOS_VSNPRINTF(aucBuff, 64, (_UC*)"timestamp=%u&ruleNum=%d",cNowTime, iCinfoVersion);
    pucParams = (_UC*)MOS_MALLOCCLR(256);
    iTotalLen = MOS_STRLEN(pstCompanyInf->aucDevkey);
    if(iTotalLen < 16)
    {
        MOS_STRNCPY(aucAesKey, pstCompanyInf->aucDevkey, iTotalLen);
        MOS_STRNCPY(aucAesKey + iTotalLen, pstCompanyInf->aucDevkey , 16 - iTotalLen);
    }else{
        MOS_STRNCPY(aucAesKey, pstCompanyInf->aucDevkey, 16);
    }
    iTotalLen = MOS_STRLEN(aucBuff);
    iFixLen = 16 - (iTotalLen % 16);
    if(iFixLen != 0)
    {
        iTotalLen = iTotalLen + iFixLen;
        for(i=0;i<iFixLen;i++)
        {
            aucBuff[iTotalLen-iFixLen+i] = iFixLen;
        }
        aucBuff[iTotalLen] = '\0';
    }
    Adpt_Aec_Encrypt(aucAesKey,pstCloudInfo->aucAESVI,aucBuff,aucAesParams,iTotalLen);
    Adpt_Base64_Enc(aucAesParams,iTotalLen,pucParams);

    MOS_VSNPRINTF(aucBuff, 512, "appKey=%s&params=%s&uid=%s", pstCloudInfo->aucAppKey, pucParams, pstCompanyInf->aucDevUID);
    pucSignBuff = (_UC*)MOS_MALLOCCLR(128);
    Adpt_HmacSha256_Encrypt(aucBuff, pucSignBuff, 128, pstCloudInfo->aucAppSecret);

    CloudStg_URLEncode((const char* )pucParams, MOS_STRLEN(pucParams), aucURLEnc, sizeof(aucURLEnc));

    Adpt_Json_AddItemToObject(hValue, (_UC*)"sign", Adpt_Json_CreateString(pucSignBuff));
    Adpt_Json_AddItemToObject(hValue, (_UC*)"params", Adpt_Json_CreateString(aucURLEnc));

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"BODY", hValue);
    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucSignBuff);
    MOS_FREE(pucParams);
    return pstrTmp;
}

_INT CloudStg_ChangeVideoParam(_INT iPackageType)
{
    if(iPackageType == Config_GetCloudMng()->iPackageType)
    {
        return MOS_OK;
    }
    // EN_ZJ_CAMERA_BITRATE_TYPE_1024K     = 8,
    // EN_ZJ_CAMERA_BITRATE_TYPE_1536K     = 9,
    // EN_ZJ_CAMERA_BITRATE_TYPE_2048K     = 10,
    // EN_ZJ_CAMERA_BITRATE_TYPE_2560K     = 11,
    // EN_ZJ_CAMERA_BITRATE_TYPE_3072K     = 12,
    // EN_ZJ_CAMERA_BITRATE_TYPE_4096K     = 13
    // EN_ZJ_CARERA_RESOLUTION_ABILITY_300W        = 0x0040, //支持2048*1536分辨率（支持高清套餐）
    // EN_ZJ_CARERA_RESOLUTION_ABILITY_400W        = 0x0080, //支持2500*1600分辨率（支持高清套餐）
    _INT iRet        = MOS_ERR;
    _INT iStream     = 0;
    _INT iChangeFlag = 0;
    ST_CFG_VIDEODES *pstVideoDes  = MOS_NULL;
    pstVideoDes = Config_GetVideoDes(0, iStream);

    if (pstVideoDes->stVideoPara.uiResolution == EN_ZJ_CARERA_RESOLUTION_ABILITY_300W)
    {
        if (iPackageType == 2)
        {
            // 高清套餐开通
            if (Config_GetCloudMng()->iPackageType != 2 && pstVideoDes->stVideoPara.uiBitrate <  EN_ZJ_CAMERA_BITRATE_TYPE_2048K)
            {
                pstVideoDes->stVideoPara.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_2048K;
                iChangeFlag = 1;
            }
        }
        else
        {
            // 高清套餐过期或者取消
            if (Config_GetCloudMng()->iPackageType == 2 && pstVideoDes->stVideoPara.uiBitrate != EN_ZJ_CAMERA_BITRATE_TYPE_1024K)
            {
                pstVideoDes->stVideoPara.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_1024K;
                iChangeFlag = 1;
            }
        }
    }
    else if (pstVideoDes->stVideoPara.uiResolution == EN_ZJ_CARERA_RESOLUTION_ABILITY_400W || pstVideoDes->stVideoPara.uiResolution == EN_ZJ_CARERA_RESOLUTION_ABILITY_500W \
    || pstVideoDes->stVideoPara.uiResolution == EN_ZJ_CAMERA_RESOLUTION_ABILITY_600W || pstVideoDes->stVideoPara.uiResolution == EN_ZJ_CAMERA_RESOLUTION_ABILITY_1440P)
    {
        if (iPackageType == 2)
        {
            // 高清套餐开通
            if (Config_GetCloudMng()->iPackageType != 2 && pstVideoDes->stVideoPara.uiBitrate <  EN_ZJ_CAMERA_BITRATE_TYPE_2560K)
            {
                pstVideoDes->stVideoPara.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_2560K;
                iChangeFlag = 1;
            }
        }
        else
        {
            // 高清套餐过期或者取消
            if (Config_GetCloudMng()->iPackageType == 2 && pstVideoDes->stVideoPara.uiBitrate !=  EN_ZJ_CAMERA_BITRATE_TYPE_1536K)
            {
                pstVideoDes->stVideoPara.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_1536K;
                iChangeFlag = 1;
            }
        }
    }
    else if (pstVideoDes->stVideoPara.uiResolution == EN_ZJ_CARERA_RESOLUTION_ABILITY_4K)
    {
        if (iPackageType == 2)
        {
            // 高清套餐开通
            if (Config_GetCloudMng()->iPackageType != 2 && pstVideoDes->stVideoPara.uiBitrate <  EN_ZJ_CAMERA_BITRATE_TYPE_3072K)
            {
                pstVideoDes->stVideoPara.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_3072K;
                iChangeFlag = 1;
            }
        }
        else
        {
            // 高清套餐过期或者取消
            if (Config_GetCloudMng()->iPackageType == 2 && pstVideoDes->stVideoPara.uiBitrate !=  EN_ZJ_CAMERA_BITRATE_TYPE_2048K)
            {
                pstVideoDes->stVideoPara.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_2048K;
                iChangeFlag = 1;
            }
        }
    }

    if (iChangeFlag == 1)
    {
        if(ZJ_GetFuncTable()->pfunSetVideoParm)
        {
            iRet = ZJ_GetFuncTable()->pfunSetVideoParm(iStream ,&pstVideoDes->stVideoPara);
            if (MOS_OK != iRet)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Device pfunSetVideoParm(iStreamId:%d, uiBitrate:%d) return err", iStream, pstVideoDes->stVideoPara.uiBitrate);
                return MOS_ERR;
            }
        }
        else
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "pfunSetVideoParm is NULL!");
            return MOS_ERR;
        }

        if (MOS_OK == iRet)
        {
            // FIXME
            Config_SetCameraStreamParam(0, iStream, &pstVideoDes->stVideoPara);
        }
    }

    return MOS_OK;
}

static _INT CloudStg_ParseGetChargrRspData(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT iRet         = MOS_ERR;
    _UI  uiDration    = 0;
    _INT iHaveCould   = 0;
    _INT iUploadMode  = 0;
    _INT ipackageType = 0;
    _INT iUrlTimerInterval = 0;
    _UC *pucStrTmp    = MOS_NULL;
    _UC *pucStrTmp2   = MOS_NULL;
    _INT iValue       = 0;
    _UC  aucUrl[256]  = {0};
    _UC  aucMsg[128]  = {0};
    JSON_HANDLE hRoot = MOS_NULL;
    JSON_HANDLE hDataObj  = MOS_NULL;
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(pucJson);

    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETINFO_ADDRESS);
    if(hJsonRoot == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"recv error json %s ",pucJson);
        Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "cinfo", aucUrl, EN_CLOUDSTG_RT_CINFO_JSON_PARSE_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_JSON_PARSE);
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"),&iValue);
    if(iValue != 0)
    {
        // 函数返回后已调用CloudStg_UploadLog
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"recv http code %u ",iValue);
        Adpt_Json_Delete(hJsonRoot);
        MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD cinfo request fail, errcode: %d", iValue);
        CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_CINFO_FAIL, aucMsg, pucJson, 1);
        return MOS_ERR;
    }
    hDataObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"haveCloud"), &iHaveCould);

    // 当云存套餐存在变更，重置看门狗时间
    if(Config_GetCloudMng()->iCloudAbility != iHaveCould)
    {
        CloudStg_Res_FeedWatchDog();
    }

    Config_SetCloudAbility(iHaveCould);
    MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD cinfo request successfully, cloud is %s", iHaveCould==0?"unbinded":"binded");
    CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_CINFO_SUCCESS, aucMsg, pucJson, 1);
    if(iHaveCould == 1)
    {
        // FIXME: 获取url地址, 需要测试是否会对加密造成影响
        // CloudStg_ResStart();
        do
        {
            ST_CFG_INIOT_NODE *pstInKjIoTNode = Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);
            if(pstInKjIoTNode && pstInKjIoTNode->uiDefaultSetFlag == 1)
            {
                break;
            }
            Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);
            if(Config_GetLocalRecordProp(MOS_NULL,MOS_NULL,MOS_NULL,MOS_NULL,&uiDration) != MOS_OK || uiDration == 0)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"get localRecord duration err!");
                uiDration = 6;
            }
            hRoot = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"LoopDays",Adpt_Json_CreateStrWithNum(30));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"RecordFull",Adpt_Json_CreateStrWithNum(1));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"StreamID",Adpt_Json_CreateStrWithNum(0));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDration));
            pucStrTmp2 = Adpt_Json_Print(hRoot);
            Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0, pucStrTmp2);
            MOS_FREE(pucStrTmp2);
            Adpt_Json_Delete(hRoot);
        } while (0);

    }
    else
    {
        Config_RemoveInIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);
    }
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"cloudId"), &pucStrTmp);
    Config_SetCloudId(pucStrTmp);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"packageType"), &ipackageType);
    iRet = CloudStg_ChangeVideoParam(ipackageType);
    if (MOS_OK == iRet)
    {
        Config_SetPackageType(ipackageType);
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"uploadMode"), &iUploadMode);
#ifdef DX_DOORBELL
    if(iUploadMode > 0)
        iUploadMode = 1;
#endif
    Config_SetCloudUpLoadMode(iUploadMode); 

    if (iHaveCould == 0 || iUploadMode != 1)
    {
        CloudStg_GetMng()->uiCloudEventUploadInfInitFlag = 0;
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud event upload inf deinit...");
    }
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj, (_UC*)"urlTimerInterval"), &iUrlTimerInterval);    
    Config_SetUrlTimerInterval((iUrlTimerInterval<=0)?CLOUDSTG_GET_THIRTYSECONDS:iUrlTimerInterval);

    MOS_LOG_INF(CLOUDSTG_LOGSTR,"Cloud Info: havecloud :%u cloudid :%s uploadmode:%u packageType:%u urlTimerInterval: %d",
                                            iHaveCould, pucStrTmp, iUploadMode, ipackageType, iUrlTimerInterval);
    Adpt_Json_Delete(hJsonRoot);
    return MOS_OK;
}

_VOID CloudStg_GetInfo_RecvAddrRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    ST_CLOUDSTG_CHARGE *pstChargeInf = &CloudStg_GetMng()->stCloudCharge;

    if(pstChargeInf->uiOgctId != *((_UI *)vpUserPtr))
    {
        return ;
    }
    if (pstChargeInf->uiBuffLen == 0)
    {
        pstChargeInf->uiBuffLen = 2048;
        pstChargeInf->pucRecvBuff = (_UC*)MOS_MALLOCCLR(2048);
    }
    if (pstChargeInf->uiRecvLen + uiLen < pstChargeInf->uiBuffLen)
    {
        MOS_MEMCPY(pstChargeInf->pucRecvBuff + pstChargeInf->uiRecvLen, pucData, uiLen);
        pstChargeInf->uiRecvLen += uiLen;
    }
    return;
}

_VOID CloudStg_GetInfo_RecvAddrFail(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC aucUrl[256]                  = {0};
    ST_CLOUDSTG_CHARGE *pstChargeInf = &CloudStg_GetMng()->stCloudCharge;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_CLOUD_GET_CINFO, uiUseTime);

    if(pstChargeInf->uiOgctId != *((_UI *)vpUserPtr))
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"ogct %u difrent form net %u",pstChargeInf->uiOgctId,(_UI)vpUserPtr);
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return ;
    }
    if (pstChargeInf->uiRecvLen < pstChargeInf->uiBuffLen)
    {
        pstChargeInf->pucRecvBuff[pstChargeInf->uiRecvLen] = 0;
    }
    else if (pstChargeInf->pucRecvBuff && pstChargeInf->uiBuffLen)// 防止缓存指向NULL
    {
        pstChargeInf->pucRecvBuff[pstChargeInf->uiBuffLen-1] = 0;
    }
    Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETINFO_ADDRESS);
    CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, uiErrCode, EN_CLOUDSTG_RT_CINFO_TIMEOUT, "CD cinfo request timeout", pstChargeInf->pucRecvBuff, 1);

    MOS_FREE(pstChargeInf->pucRecvBuff);
    pstChargeInf->pucRecvBuff  = MOS_NULL;
    pstChargeInf->cNextReqTime = Mos_Time() + CLOUDSTG_GET_ONEHOUR;
    pstChargeInf->uiOgctId  = 0;
    pstChargeInf->uiState   = 0;
    pstChargeInf->uiRecvLen = 0;
    pstChargeInf->uiBuffLen = 0;
    pstChargeInf->uiTryTime = 0;

    return;
}

_VOID CloudStg_GetInfo_RecvAddrFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iRet                        = 0;
    ST_CLOUDSTG_CHARGE *pstChargeInf = &CloudStg_GetMng()->stCloudCharge;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_CLOUD_GET_CINFO, uiUseTime);

    if(pstChargeInf->uiOgctId != *((_UI *)vpUserPtr))
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"ogct %u difrent form net %u",pstChargeInf->uiOgctId,*((_UI *)vpUserPtr));
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return ;
    }
    if(pstChargeInf->pucRecvBuff)
    {
        pstChargeInf->pucRecvBuff[pstChargeInf->uiRecvLen] = 0;
    }
    iRet = CloudStg_ParseGetChargrRspData(pstChargeInf->pucRecvBuff);
    if(iRet == MOS_ERR)
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        pstChargeInf->uiRecvLen = 0;
        pstChargeInf->uiBuffLen = 0;
        pstChargeInf->cNextReqTime = Mos_Time() + CLOUDSTG_GET_TENSECONDS;
        MOS_FREE(pstChargeInf->pucRecvBuff);
        pstChargeInf->pucRecvBuff = MOS_NULL;
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"get cloud info err");
        return;
    }
    EN_COUNT_VALUE CountLess2Value = Mos_Time() - pstChargeInf->cReqTime >= 2 ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
    Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_SUCCESS, CountLess2Value);   
    pstChargeInf->cNextReqTime = Mos_Time() + CLOUDSTG_GET_ONEHOUR;
    pstChargeInf->uiOgctId  = 0;
    pstChargeInf->uiRecvLen = 0;
    pstChargeInf->uiState   = 0;
    pstChargeInf->uiBuffLen = 0;
    pstChargeInf->uiTryTime = 0;
    MOS_FREE(pstChargeInf->pucRecvBuff);
    pstChargeInf->pucRecvBuff = MOS_NULL;
    return;
}

_INT CloudStg_AsycGetChargeInfo(ST_CLOUDSTG_CHARGE *pstChargeInf)
{
    MOS_PARAM_NULL_RETERR(pstChargeInf);

    _INT iRet = 0;
    _US usPort = 80;
    _UI uiHttpsFlag = 0;
    _UC *pStrTmp  = MOS_NULL;
    _UC *pStrStart = MOS_NULL;
    _UC aucErrorStr[256] = {0};
    _UC auAdmonAddr[128] = {0};

    // 获取云存开通信息接口质量 https://cloud-ehome.21cn.com/unifyDev/cinfo
    MOS_VSNPRINTF(auAdmonAddr, sizeof(auAdmonAddr), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETINFO_ADDRESS);
    MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_CLOUD_GET_CINFO, auAdmonAddr);

    MOS_MEMSET(auAdmonAddr, 0, 128);

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucCloudAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 

    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucCloudAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucCloudAddr;
    }
    else{
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRLCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    pStrTmp = CloudStg_BuildGetInfoReqData(pstChargeInf->uiOgctId,pstChargeInf->cReqTime);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"ogct %u get cloud info %s len %u",pstChargeInf->uiOgctId,pStrTmp,MOS_STRLEN(pStrTmp));

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = CloudStg_GetInfo_RecvAddrRsp;
    stHttpInfoNode.pfuncFinished   = CloudStg_GetInfo_RecvAddrFinish;
    stHttpInfoNode.pfuncFailed     = CloudStg_GetInfo_RecvAddrFail;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.vpUserPtr       = &pstChargeInf->uiOgctId;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, CLOUDSTG_GETINFO_ADDRESS, EN_HTTP_METHOD_POST, pstChargeInf->uiOgctId);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {    
        MOS_VSNPRINTF(aucErrorStr, sizeof(aucErrorStr), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETINFO_ADDRESS);
        Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "cinfo", aucErrorStr, EN_CLOUDSTG_RT_CINFO_GETHOSTBYNAME_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME);
    }
    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

static _INT CloudStg_CheckChargeInfo(_UI uiAliveTaskCnt,_CTIME_T cNowTime)
{
    ST_CLOUDSTG_CHARGE *pstChargeInf = &CloudStg_GetMng()->stCloudCharge;
    
    if(CloudStg_GetMng()->uiCurNetStatus == 0)
    {
        return MOS_OK;
    }

    // 超时重试
    if(pstChargeInf->uiState == 1 && cNowTime - pstChargeInf->cReqTime >= 30)
    {
        Http_Httpclient_CancelAsyncRequestEx(pstChargeInf->uiOgctId);
        pstChargeInf->uiOgctId  = 0;
        if(pstChargeInf->uiTryTime++ <= 10)
        {
            pstChargeInf->cNextReqTime = cNowTime + 60*pstChargeInf->uiTryTime;
        }
        else
        {
            pstChargeInf->cNextReqTime = cNowTime + CLOUDSTG_GET_THIRTYMINUTES;
        }
        pstChargeInf->uiState = 0;
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"get charge info fail,try times %u,next try time %u,after %ds ",pstChargeInf->uiTryTime,pstChargeInf->cNextReqTime,pstChargeInf->cNextReqTime-cNowTime);
    }
    
    if(pstChargeInf->uiState == 0 )
    {

        if(cNowTime >= pstChargeInf->cNextReqTime && pstChargeInf->uiOgctId == 0)
        {
            pstChargeInf->uiOgctId = Mos_GetSessionId();
            pstChargeInf->cReqTime = cNowTime;
            if(CloudStg_AsycGetChargeInfo(pstChargeInf) == MOS_OK)
            {
                pstChargeInf->uiState = 1;
            }
            else{
                 pstChargeInf->uiOgctId = 0; 
                 pstChargeInf->cNextReqTime = cNowTime + 5;
            }
        }
        else if(Config_GetCloudMng()->iCloudAbility == 1 && Config_GetCloudMng()->iCloudUpLoadMode == 2 && uiAliveTaskCnt == 0 && CloudStg_GetMng()->iOpenFlag != 0)
        {
            // MOS_LOG_INF(CLOUDSTG_LOGSTR,"Cloud record allday start by cloud info, timestamp: %u",Mos_Time());
			
            if (Config_GetCloudMng()->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
            {
                CloudStg_StartAliveUpLoad(0,Config_GetCloudMng()->iStreamID,Config_GetCloudMng()->iVideoDuration);
            }
            else if (Config_GetCloudMng()->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || Config_GetCloudMng()->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
            {
                // 重新触发下一次5分钟的云存上报
                CloudStg_StartAliveUpLoad(0,Config_GetCloudMng()->iStreamID,CLOUDSTG_UPLOAD_TIME);
            }
        }
    }
    return MOS_OK;
}

static _INT CloudStg_CheckNetStatus(_INT iCamId, _CTIME_T cNowTime)
{
    _UI uiTmpStatus = 0;

    if(cNowTime - CloudStg_GetMng()->tNetCheckTIme >= CLOUDSTG_UPLOAD_TIME)
    {
        if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
        {
            uiTmpStatus = 0;
        }
        else
        {
            uiTmpStatus = 1;
        }
        
        if(CloudStg_GetMng()->uiCurNetStatus == 1 && uiTmpStatus == 0)
        {
            CloudStg_GetMng()->tDisconnetTime = cNowTime;
        }
        else if(CloudStg_GetMng()->uiCurNetStatus == 0 && uiTmpStatus == 0 && MOS_ABS_NUM(cNowTime - CloudStg_GetMng()->tDisconnetTime) >= CLOUDSTG_UPLOAD_TIME)
        {
            CloudStg_AddDefaultEvent(iCamId,CloudStg_GetMng()->tDisconnetTime,2);
            CloudStg_GetMng()->tDisconnetTime = cNowTime;
        }
        else if(CloudStg_GetMng()->uiCurNetStatus == 0 && uiTmpStatus == 1)
        {
            CloudStg_AddDefaultEvent(iCamId,CloudStg_GetMng()->tDisconnetTime,2);
            CloudStg_GetMng()->tDisconnetTime = 0;
        }
        CloudStg_GetMng()->uiCurNetStatus = uiTmpStatus;
        CloudStg_GetMng()->tNetCheckTIme = cNowTime;
    }
    return MOS_OK;
}

_INT CloudStg_StartSendHumanFacePic(_UI uiReqId,_INT iCamId,_UC *pucFaceBuff,_UI uiBuffLen,PFUN_CLOUDFILESENDCB pFunFileSendCb)
{
    MOS_PARAM_NULL_RETERR(pucFaceBuff);

    return MOS_OK;
}

_VOID CloudStg_MediaTaskSendJpgCb(_UI uiReqId,_INT iStatus,_UC *pucIconInfo)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->iUseFlag && pstTaskNode->uiTaskId == uiReqId && pstTaskNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
        {
            if(iStatus == 0)
            {
                MOS_STRLCPY(pstTaskNode->stCommitInfo.aucIconInfo,pucIconInfo,sizeof(pstTaskNode->stCommitInfo.aucIconInfo));
                pstTaskNode->uiIconStatus = EN_CLOUDSTG_ICON_UPLOAD_TYPE_SUCCESS;
            }
            if(iStatus == 400)
            {
                MOS_MEMSET(&pstTaskNode->stCommitInfo,0,256);
                pstTaskNode->uiIconStatus = EN_CLOUDSTG_ICON_UPLOAD_TYPE_FAIL;
            }
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u recv upload icon file status %u fid %s",pstTaskNode->uiTaskId,iStatus,pucIconInfo);
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    return ;
}

_INT CloudStg_InitChargeInfo()
{
    _INT iTime = CloudStg_GetMng()->stCloudCharge.cNextReqTime - Mos_Time();
    if(CloudStg_GetMng()->stCloudCharge.uiOgctId != 0 || MOS_ABS_NUM(iTime) <= 3)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"ignore repeat request!");
        return MOS_OK;
    }
    CloudStg_GetMng()->tNetCheckTIme         = 0;
    CloudStg_GetMng()->stCloudCharge.uiState = 0;
    CloudStg_GetMng()->stCloudCharge.uiTryTime = 0;
    CloudStg_GetMng()->stCloudCharge.cNextReqTime = Mos_Time();
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"Init cloud info");
    return MOS_OK;
}

_INT CloudStg_SetAlarmUpload(_INT iCamId,_INT iStreamId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTmpNode = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTmpNode, stIterator)
    {
        if(pstTmpNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
        {
            if(pstTmpNode->iUseFlag == 1 && pstTmpNode->iState < EN_CLOUDSTG_TASK_COMMINT && pstTmpNode->iCamId == iCamId)
            {
                pstTmpNode->iEventType = 1;
                pstTmpNode->stEventInfo.uiEventType = 1;
            }
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    return MOS_OK;
}

_INT CloudStg_SetAlarmTimeStamp(_INT iCamId,_INT iStreamId, _CTIME_T tTimeStamp)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTmpNode = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTmpNode, stIterator)
    {
        if(pstTmpNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
        {
            if(pstTmpNode->iUseFlag == 1 && pstTmpNode->iState < EN_CLOUDSTG_TASK_COMMINT && pstTmpNode->iCamId == iCamId)
            {
                if (tTimeStamp == 0)
                {
                    tTimeStamp = Mos_Time();
                }
                pstTmpNode->tAlarmTimeStamp = tTimeStamp;
            }
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    return MOS_OK;
}

_INT CloudStg_ProcRecordOutput(_UI uiAIIoTType,_LLID lluAIIoTID, _UC* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    MOS_PARAM_NULL_RETERR(pSignalValue);
    MOS_PARAM_NULL_RETERR(pstTriggerInf);

    _INT iOpenFlag     = 0;
    _INT iOutStreamId  = 0;
    _INT iStreamId     = 0;
    _INT iContrlType   = 0;
    _INT iOutDuration  = 0;
    _UI  uiDuration    = 0;
    _UI  uiEventCloudDuration = 0;
    JSON_HANDLE hRoot = MOS_NULL;

    // 创建事件云存任务，喂狗并刷新暂停时间
    CloudStg_Res_FeedWatchDog();

    if(Config_GetCloudRecordProp(MOS_NULL,MOS_NULL,(_UI*)&iStreamId,(_UI*)&iOpenFlag,(_UI*)&uiDuration) == MOS_ERR || iOpenFlag == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"have no cloud record bussness, streamid: %d, openflag: %d, duration: %d\r\n", iStreamId, iOpenFlag, uiDuration);
        return MOS_OK;
    }
    if(pSignalValue == MOS_NULL || MOS_STRLEN(pSignalValue) == 0)
    {
        return MOS_OK;
    }

    hRoot = Adpt_Json_Parse(pSignalValue);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),&iContrlType);

    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Duration"),&iOutDuration) == MOS_OK)
    {
        if(iOutDuration == 0)
        {
            iOutDuration = uiDuration;
        }
#if SDK_AWAKE_SLEEP_ENABLE
        if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //支持低功耗设备
        {
            // 门铃设备或低功耗设备使用统一自定义录像时长
            iOutDuration = uiDuration;
        }        
#endif
    }
   
    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StreamID"),&iOutStreamId) == MOS_OK)
    {
        if(iOutStreamId < iStreamId)
        {
            iStreamId = iOutStreamId;
        }
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"event proc %s",pSignalValue);
    if(iContrlType == 1)
    {
        // 事件上报
        if(Config_GetCloudMng()->iCloudUpLoadMode == 1)
        {
            _UI uiTaskCnt = 0;
            ST_MOS_LIST_ITERATOR stIterator;
            ST_CLOUDSTG_TASK_NODE *pstTmpNode = MOS_NULL;

            Mos_MutexLock(&CloudStg_GetMng()->hMutex);
            FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTmpNode, stIterator)
            {
                if(pstTmpNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
                {
                    if(pstTmpNode->iUseFlag == 0)
                    {
                        continue;
                    }
                    if(pstTmpNode->iState <= EN_CLOUDSTG_TASK_STOP)
                    {
                        CloudStg_EventCloudAppendHandler(pstTmpNode);
                        uiTaskCnt++;
                    }
                }
            }
            Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

            if(uiTaskCnt == 0)
            {
                // 触发一次视频上报
                if (CloudStg_GetConfig()->iEventCloudSwitch == 1)
                {
                    CloudStg_StartEventUpLoad(0,Config_GetCloudMng()->iStreamID,CloudStg_GetConfig()->iEventCloudMinTime,pstTriggerInf->tCreateTime);
                }
                else
                {
                    CloudStg_StartEventUpLoad(0,Config_GetCloudMng()->iStreamID,iOutDuration,pstTriggerInf->tCreateTime);
                }
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"Event cloud upload start");
            }
        }
        // 全天上报
        else if(Config_GetCloudMng()->iCloudUpLoadMode == 2)
        {
            CloudStg_SetAlarmUpload(0,Config_GetCloudMng()->iStreamID);
        }
    }
    else{
        // 停止云存功能
        CloudStg_StopAliveUpLoad(0,iStreamId);
    }
    Adpt_Json_Delete( hRoot);
    return MOS_OK;
}

_INT CloudStg_ProcSnapShotOutput(_UI uiAIIoTType,_LLID lluAIIoTID, _UC* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    return MOS_OK;//实现接口存在奔溃问题，暂时屏蔽

    MOS_PARAM_NULL_RETERR(pSignalValue);
    MOS_PARAM_NULL_RETERR(pstTriggerInf);
    _INT iPicType = 0;
    _INT iGifFlag = 0;
    _INT iOutPicType = 0;
    _UI uiOpenFlag = 0;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_EVENTTASK_NODE *pstEventNode = MOS_NULL;

    MOS_LOG_INF(CLOUDSTG_LOGSTR,"Cloud Snap Time: %u !", pstTriggerInf->tCreateTime);

    pstEventNode = MsgMng_FindEventNodeByCTime(pstTriggerInf->tCreateTime);
    if (!pstEventNode)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"can not find EventNodeByCTime:%u !", pstTriggerInf->tCreateTime);
        return MOS_ERR;
    }

    if(Config_GetCloudSnapProp(MOS_NULL,MOS_NULL,&iPicType,MOS_NULL,&uiOpenFlag) == MOS_ERR || uiOpenFlag == 0)
    {
        return MOS_ERR;
    }
    
    hRoot = Adpt_Json_Parse(pSignalValue);

    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PicType"),&iOutPicType) == MOS_OK)
    {
        if(iPicType > iOutPicType)
        {
            iPicType = iOutPicType;
        }
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GifFlag"),&iGifFlag);
    if(iGifFlag == 0)
        CloudStg_StartSendAlivePic(Mos_GetSessionId(),0,1,pstTriggerInf->tCreateTime,MOS_NULL);
    else{
        CloudStg_StartSendAlivePic(Mos_GetSessionId(),0,5,pstTriggerInf->tCreateTime,MOS_NULL);
    }

    // FIXME: NVR 设置视频的Alarm时间戳
    CloudStg_SetAlarmTimeStamp(0, 0, pstTriggerInf->tCreateTime);

    Adpt_Json_Delete( hRoot);
    return MOS_OK;
}

_INT CloudStg_Init()
{
    if(CloudStg_GetMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stCloudMng, 0, sizeof(ST_CLOUDSTG_MANAGE));
    Mos_MutexCreate(&CloudStg_GetMng()->hMutex);
    CloudStg_GetMng()->tCheckTime = Mos_Time();
    CloudStg_GetMng()->iOpenFlag  = Config_GetCamaraMng()->uiCamOpenFlag;
    CloudStg_GetMng()->iReadyToRebootFlag = 0;
    CloudStg_GetMng()->uiCurNetStatus = 0;
    CloudStg_GetMng()->hMsgQueue  = Mos_MsgQueueCreate(MOS_FALSE,10, __FUNCTION__);
    CloudStg_GetMng()->iQualityTotalSentBytes = 0;
    CloudStg_GetMng()->iQualityTotalPatchSentBytes = 0;
    CloudStg_GetMng()->iQualityTotalSentInterval = 0;
    CloudStg_GetMng()->iQualityTotalPatchSentInterval = 0;
    CloudStg_GetMng()->tQualityLastReqTime = Mos_Time();
    CloudStg_GetMng()->uiFirstCommitFlag = 0;
    // 默认为普通模式云存
    Config_GetCloudMng()->iVideoDuration = CLOUDSTG_UPLOAD_TIME;
    Config_GetCloudMng()->iDirectMode    = EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL;
#ifndef USE_SNAP_STACK
    CloudStg_GetMng()->pucPicBuf  = MOS_NULL;
    CloudStg_GetMng()->iPicBufLen = 0;
#endif
    CloudStg_ResInit();
    // 事件云存追加能力值设置为1
    Config_SetEventCloudAppendAbility(0, 1);
    /*************************读取配置************************/
    // 读取事件云存追加配置
    CloudStg_SetEventCloudSwitch(Config_GetCamaraMng()->iEventCloudSwitch);
    CloudStg_SetEventCloudMaxTime(Config_GetCamaraMng()->iEventCloudMaxTime);
    CloudStg_SetEventCloudMinTime(Config_GetCamaraMng()->iEventCloudMinTime);
    CloudStg_SetEventCloudDetectTime(Config_GetCamaraMng()->iEventCloudDetectTime);
    CloudStg_SetEventCloudAppendTime(Config_GetCamaraMng()->iEventCloudAppendTime);
    // TODO: 读取其他配置
    CloudStg_GetMng()->ucInitFlag = 1;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task init ok");
    return MOS_OK;
}

_INT CloudStg_Start()
{
    _UI uiDration = 0;
    _INT iRet;
    _UC *pucStrTmp = MOS_NULL;
    _UC *pucAppKey = "600982120";
    _UC *pucAppSecret = "e804cbebb0d81e61e40d026680227794";
    _UC aucAESVI[17] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',0};
    JSON_HANDLE hRoot = MOS_NULL;
    _UI uiStackSize   = MOS_THREAD_STACK_NORMAL_SIZE;

    // 设置AES KEY(暂时无用)
    Config_SetAppKey(pucAppKey);
    Config_SetAppSecret(pucAppSecret);
    Config_SetAESVI(aucAESVI);


    // 如果开启了云存能力
    if(Config_GetCloudMng()->iCloudAbility == 1)
    {
        do
        {
            JSON_HANDLE hRoot = MOS_NULL;
            _UC *pucStrTmp = MOS_NULL;
            ST_CFG_INIOT_NODE *pstInKjIoTNode  = MOS_NULL;

            // 查询内部IOT是否有云端录像
            pstInKjIoTNode = Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);
            if(pstInKjIoTNode && pstInKjIoTNode->uiDefaultSetFlag == 1)
            {
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"find cloud iot node!");
                break;
            }

            // 添加IOT设备（云端录像）
            Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);

            // 获取本地录像参数(录像时长)
            if(Config_GetLocalRecordProp(MOS_NULL,MOS_NULL,MOS_NULL,MOS_NULL,&uiDration) != MOS_OK || uiDration == 0)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"get localRecord duration err!");
                uiDration = 6;
            }

            // 重新设置参数
            hRoot = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"LoopDays",Adpt_Json_CreateStrWithNum(30));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"RecordFull",Adpt_Json_CreateStrWithNum(1));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"StreamID",Adpt_Json_CreateStrWithNum(1)); // FIXME: 使用辅码流
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDration));
            pucStrTmp = Adpt_Json_Print(hRoot);
            Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0, pucStrTmp);
            MOS_FREE(pucStrTmp);
            Adpt_Json_Delete(hRoot);
        } while (0);   
    }

    // 添加IOT设备（截图）
    Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDSNAP,0);

    // 重新设置参数
    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"LoopDays",Adpt_Json_CreateStrWithNum(30));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Interval",Adpt_Json_CreateStrWithNum(30));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"PicType",Adpt_Json_CreateStrWithNum(2));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"FullFlag",Adpt_Json_CreateStrWithNum(0));
    pucStrTmp = Adpt_Json_Print(hRoot);
    Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_CLOUDSNAP,0, pucStrTmp);

    MOS_FREE(pucStrTmp);
    Adpt_Json_Delete(hRoot);
    if(CloudStg_GetMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    if(CloudStg_GetMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Already Start");
        return MOS_OK;
    }

    // 增加回调 开启/关闭 （事件/全天）云存功能
    KjIoT_AddDevContrlFun(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,CloudStg_ProcRecordOutput,MOS_NULL,MOS_NULL,MOS_NULL); 
    
    // 增加回调 开启/关闭 云抓功能
    KjIoT_AddDevContrlFun(EN_ZJ_AIIOT_TYPE_CLOUDSNAP,CloudStg_ProcSnapShotOutput,MOS_NULL,MOS_NULL,MOS_NULL); 

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif

    // 获取url地址
    CloudStg_ResStart();

    // 实时监听缓存器的流，获取并云存上传
    CloudStg_TransStart();

    CloudStg_GetMng()->ucRunFlag = 1;
    // 负责获取流，发流到缓存器中
    iRet = Mos_ThreadCreate((_UC*)"CloudMng",  EN_THREAD_PRIORITY_NORMAL, uiStackSize,  
            CloudStg_TaskLoop, MOS_NULL, MOS_NULL, &CloudStg_GetMng()->hMgrThread);
    if(iRet == MOS_ERR)
    {
        CloudStg_GetMng()->ucRunFlag = 0;
        Mos_ThreadDelete(CloudStg_GetMng()->hMgrThread);
        return MOS_ERR;
    }
    
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task start ok");
    return MOS_OK; 
}

_INT CloudStg_Stop()
{
    _VOID *pstMsg = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode   = MOS_NULL;
    if(CloudStg_GetMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Already Stop");
        return MOS_OK;
    }
    CloudStg_GetMng()->ucRunFlag = 0;

    Mos_ThreadDelete(CloudStg_GetMng()->hMgrThread);
    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList , pstTaskNode, stIterator)
    {
        if(pstTaskNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
        {
            CloudStg_DestroyAliveNode(pstTaskNode);
        }

        MOS_LIST_RMVNODE(&CloudStg_GetMng()->stTaskList,pstTaskNode);
        Mos_MemFree(pstTaskNode);
    }
    while((pstMsg = Mos_MsgQueuePop(CloudStg_GetMng()->hMsgQueue)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    CloudStg_ResStop();
    CloudStg_TransStop();

    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task stop ok");
    return MOS_OK;
}

_INT CloudStg_Destroy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pstFileNode ;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task destroy ok");

    if(CloudStg_GetMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Already Destroy");
        return MOS_OK;
    }
    
    Mos_MsgQueueDelete(CloudStg_GetMng()->hMsgQueue);
    CloudStg_GetMng()->hMsgQueue = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    MOS_LIST_RMVALL(&CloudStg_GetMng()->stTaskList, MOS_TRUE);
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pstFileNode, stIterator)
    {
#ifndef USE_SNAP_STACK
        if (CloudStg_GetMng()->pucPicBuf)
        {
            MOS_FREE(CloudStg_GetMng()->pucPicBuf);
            CloudStg_GetMng()->pucPicBuf  = MOS_NULL;
            CloudStg_GetMng()->iPicBufLen = 0;
        }
#endif

        MOS_LIST_RMVNODE(&CloudStg_GetMng()->stFileList, pstFileNode);
        if (pstFileNode)
        {
            if (pstFileNode->pucUrl)
            {
                MOS_FREE(pstFileNode->pucUrl);
            }
            if (pstFileNode->pucMsg)
            {
                MOS_FREE(pstFileNode->pucMsg);
            }
            if (pstFileNode->pucEt)
            {
                MOS_FREE(pstFileNode->pucEt);
            }
            MOS_FREE(pstFileNode);
        }
    }

    CloudStg_ResDestroy();
    Mos_MutexDelete(&CloudStg_GetMng()->hMutex);
    CloudStg_GetMng()->ucInitFlag = 0;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task destroy ok");
    return MOS_OK;
}

_INT CloudStg_FileNodeSetUsed(_UI uiTaskId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pstFileNode;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pstFileNode, stIterator)
    {
        if (uiTaskId == pstFileNode->uiTaskId)
        {
            pstFileNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
        }
    }

    return MOS_OK;
}

_INT CloudStg_StartEventUpLoad(_INT iCamId,_INT iStreamId,_UI uiDuration,_CTIME_T cEventTime)
{
    _INT iOpenFlag = 0;
    ST_CLOUDSTG_ALIVE_UPLOAD_MSG *pstAliveUpLoadMsg;

    if(CloudStg_GetMng()->iReadyToRebootFlag == 1)
    {
        return MOS_OK;
    }
    if(CloudStg_GetMng()->iOpenFlag == 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"device is sleep");
        return MOS_OK;
    }
    if(Config_GetCloudRecordProp(MOS_NULL,MOS_NULL,MOS_NULL,&iOpenFlag,MOS_NULL) == MOS_ERR || iOpenFlag == 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Have No This Bussness");
        return MOS_ERR;
    }
    if(CloudStg_GetMng()->uiCurNetStatus == 0)
    {
        CloudStg_AddDefaultEvent(iCamId,cEventTime,1);
        return MOS_OK;
    }
    pstAliveUpLoadMsg = (ST_CLOUDSTG_ALIVE_UPLOAD_MSG*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_ALIVE_UPLOAD_MSG));
    pstAliveUpLoadMsg->stMsgHead.usMsgType = EN_CLOUDSTG_MSG_ALIVE_UPLOAD;
    pstAliveUpLoadMsg->iCamid     = iCamId;
    pstAliveUpLoadMsg->iStreamId  = iStreamId;
    pstAliveUpLoadMsg->uiDuration = uiDuration;
    pstAliveUpLoadMsg->iEventType = 1;
    pstAliveUpLoadMsg->uiContrlType = 1;
    pstAliveUpLoadMsg->tCreateTime = cEventTime;
     _INT iRet = Mos_MsgQueuePush(CloudStg_GetMng()->hMsgQueue, pstAliveUpLoadMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstAliveUpLoadMsg);
        return MOS_ERR;
    }

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cam [%u %u ]send upload alivedata msg duration %u",iCamId,iStreamId,uiDuration);
    return MOS_OK;
}

// 触发云存上报
_INT CloudStg_StartAliveUpLoad(_INT iCamId,_INT iStreamId,_UI uiDuration)
{
    _INT iOpenFlag = 0;
    ST_CLOUDSTG_ALIVE_UPLOAD_MSG *pstAliveUpLoadMsg = MOS_NULL;

    // 创建全天云存任务，喂狗并刷新暂停时间
    CloudStg_Res_FeedWatchDog();

    if(CloudStg_GetMng()->iReadyToRebootFlag == 1)
    {
        return MOS_OK;
    }
    if(CloudStg_GetMng()->iOpenFlag == 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"device is sleep");
        return MOS_OK;
    }
    if(Config_GetCloudRecordProp(MOS_NULL,MOS_NULL,MOS_NULL,&iOpenFlag,MOS_NULL) == MOS_ERR || iOpenFlag == 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Have No This Bussness");
        return MOS_ERR;
    }
    pstAliveUpLoadMsg = (ST_CLOUDSTG_ALIVE_UPLOAD_MSG*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_ALIVE_UPLOAD_MSG));
    pstAliveUpLoadMsg->stMsgHead.usMsgType = EN_CLOUDSTG_MSG_ALIVE_UPLOAD;
    pstAliveUpLoadMsg->iCamid     = iCamId;
    pstAliveUpLoadMsg->iStreamId  = iStreamId;
    pstAliveUpLoadMsg->uiDuration = uiDuration;
    pstAliveUpLoadMsg->iEventType = Config_GetCloudMng()->iCloudUpLoadMode;
    pstAliveUpLoadMsg->uiContrlType = 1;
    pstAliveUpLoadMsg->tCreateTime = Mos_Time();

    _INT iRet = Mos_MsgQueuePush(CloudStg_GetMng()->hMsgQueue, pstAliveUpLoadMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstAliveUpLoadMsg);
        return MOS_ERR;
    }
    // MOS_LOG_INF(CLOUDSTG_LOGSTR, "cam [%u %u ]send upload alivedata msg duration %u",iCamId,iStreamId,uiDuration);
    return MOS_OK;
}

_INT CloudStg_FormatSDCard()
{
    _INT iOpenFlag = 0;
    ST_CLOUDSTG_ALIVE_UPLOAD_MSG *pstAliveUpLoadMsg = MOS_NULL;

    if(CloudStg_GetMng()->iOpenFlag == 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"device is sleep");
        return MOS_OK;
    }
    if(Config_GetCloudRecordProp(MOS_NULL,MOS_NULL,MOS_NULL,&iOpenFlag,MOS_NULL) == MOS_ERR || iOpenFlag == 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Have No This Bussness");
        return MOS_ERR;
    }
    pstAliveUpLoadMsg = (ST_CLOUDSTG_ALIVE_UPLOAD_MSG*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_ALIVE_UPLOAD_MSG));
    pstAliveUpLoadMsg->stMsgHead.usMsgType = EN_CLOUDSTG_MSG_TF_FORMAT;

    _INT iRet = Mos_MsgQueuePush(CloudStg_GetMng()->hMsgQueue, pstAliveUpLoadMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstAliveUpLoadMsg);
        return MOS_ERR;
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "sd card start format");
    return MOS_OK;
}

_INT CloudStg_StartTFUpLoad(ST_CLOUDSTG_EVENT_INFO *pstEventInfo)
{
    MOS_PARAM_NULL_RETERR(pstEventInfo);

    _INT iOpenFlag = 0;
    ST_CLOUDSTG_ALIVE_UPLOAD_MSG *pstAliveUpLoadMsg = MOS_NULL;

    if(CloudStg_GetMng()->iOpenFlag == 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"device is sleep");
        return MOS_OK;
    }
    if(Config_GetCloudRecordProp(MOS_NULL,MOS_NULL,MOS_NULL,(_UI*)&iOpenFlag,MOS_NULL) == MOS_ERR || iOpenFlag == 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Have No This Bussness");
        return MOS_ERR;
    }
    pstAliveUpLoadMsg = (ST_CLOUDSTG_ALIVE_UPLOAD_MSG*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_ALIVE_UPLOAD_MSG));
    MOS_MEMCPY(&pstAliveUpLoadMsg->stEventInfo,pstEventInfo,sizeof(ST_CLOUDSTG_EVENT_INFO));
    pstAliveUpLoadMsg->stMsgHead.usMsgType = EN_CLOUDSTG_MSG_TF_UPLOAD;
    pstAliveUpLoadMsg->uiContrlType = 1;
    _INT iRet = Mos_MsgQueuePush(CloudStg_GetMng()->hMsgQueue, pstAliveUpLoadMsg);
   if (iRet != MOS_OK)
   {
       MOS_FREE(pstAliveUpLoadMsg);
       return MOS_ERR;
   }

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "start send upload TFdata msg start time %u event type %u",pstEventInfo->tStartTime,pstEventInfo->uiEventType);
    return MOS_OK;
}

_INT CloudStg_StopAliveUpLoad(_INT iCamId,_INT iStreamId)
{
    ST_CLOUDSTG_ALIVE_UPLOAD_MSG *pstCloudMsg = (ST_CLOUDSTG_ALIVE_UPLOAD_MSG*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_ALIVE_UPLOAD_MSG));

    pstCloudMsg->stMsgHead.usMsgType = EN_CLOUDSTG_MSG_ALIVE_UPLOAD;
    pstCloudMsg->iCamid    = iCamId;
    pstCloudMsg->iStreamId = iStreamId;
    pstCloudMsg->uiContrlType = 0; // 关闭云存通知flag

    _INT iRet = Mos_MsgQueuePush(CloudStg_GetMng()->hMsgQueue, pstCloudMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCloudMsg);
        return MOS_ERR;
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cam [%u %u]stop upload alivedata msg ",iCamId,iStreamId);
    return iRet;
}

_INT CloudStg_SetAllDayUpLoad(_INT iCamId,_INT iStreamId,_UI uiAllDayFlag)
{
    return MOS_OK;
}

_INT CloudStg_SetCamOpenFlag(_INT iOpenFlag)
{
    _UI uiTaskCnt = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTmpNode = MOS_NULL;

    CloudStg_GetMng()->iOpenFlag = iOpenFlag;
    // 摄像头打开完毕，且是全天云存，需要主动创建全天云存任务；事件云存由IoT Output触发
    if(CloudStg_GetMng()->iOpenFlag == 1 && Config_GetCloudMng()->iCloudUpLoadMode == 2)
    {

        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTmpNode, stIterator)
        {
            if(pstTmpNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
            {
                if(pstTmpNode->iUseFlag == 0)
                {
                    continue;
                }
                if(pstTmpNode->iState <= EN_CLOUDSTG_TASK_STOP)
                {
                    uiTaskCnt++;
                }
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

        if(uiTaskCnt == 0)
        {
            if (Config_GetCloudMng()->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
            {
                CloudStg_StartAliveUpLoad(0,Config_GetCloudMng()->iStreamID,Config_GetCloudMng()->iVideoDuration);
            }
            else if (Config_GetCloudMng()->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || Config_GetCloudMng()->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
            {
                // 重新触发下一次5分钟的云存上报
                CloudStg_StartAliveUpLoad(0,Config_GetCloudMng()->iStreamID,CLOUDSTG_UPLOAD_TIME);
            }
        }
    }
    // 摄像头关闭
    else if (CloudStg_GetMng()->iOpenFlag == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"Detected camera close, commit cloud tasks now...");
        // commmit所有云存任务
        CloudStg_CommitAllTask();
    }
    return MOS_OK;
}

_INT CloudStg_FindMediaStartTime(_CTIME_T tEventTime,_CTIME_T *ptStartTIme)
{
    MOS_PARAM_NULL_RETERR(ptStartTIme);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTmpNode = MOS_NULL;

    if(Config_GetCloudMng()->iCloudAbility != 1 || CloudStg_GetMng()->iOpenFlag != 1)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Have no cloud ability");
        ptStartTIme = 0;
        return MOS_OK;
    }

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTmpNode, stIterator)
    {
        if(pstTmpNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
        {
            if(pstTmpNode->iUseFlag == 0)
            {
                continue;
            }
            if(pstTmpNode->iState <= EN_CLOUDSTG_TASK_COMMINT && pstTmpNode->iEventType == 1 && pstTmpNode->tCreateTime + pstTmpNode->uiDuration >= tEventTime)
            {
                *ptStartTIme = pstTmpNode->tCreateTime;
                Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
                return MOS_OK;
            }
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    return MOS_OK;
}

_INT CloudStg_PicTaskAddNode(_UI uiReqId,_INT iCamId,_UI uiJpgCnt,_UI uiIcon,_CTIME_T cSignTime,PFUN_CLOUDFILESENDCB pFunFileSendCb)
{
    _UI uiCnt = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;
    ST_CLOUDSTG_FILE_NODE *pFileTaskTmpNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskTmpNode, stIterator)
    {
        if(pFileTaskTmpNode->uiUseFlag == 0)
        {
            pFileTaskNode = pFileTaskTmpNode;
        }
        else if(pFileTaskTmpNode->uiTaskType == 0 || pFileTaskTmpNode->uiTaskType == 3){
            uiCnt++;
        }
    }
    if(uiCnt >= 5 || uiJpgCnt >= 10)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"task cnt %u so not upload alive jpg",uiCnt);
        return MOS_ERR;
    }
    if(pFileTaskNode == MOS_NULL)
    {
        pFileTaskNode = (ST_CLOUDSTG_FILE_NODE*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_FILE_NODE));
        MOS_LIST_ADDTAIL(&CloudStg_GetMng()->stFileList, pFileTaskNode);
    }
    pFileTaskNode->uiMediaTaskId = uiReqId;
    if(cSignTime == 0)
    {
        pFileTaskNode->tCreatTime = Mos_Time();
    }
    else
    {
        pFileTaskNode->tCreatTime = cSignTime;
    }
    pFileTaskNode->uiIcon       = uiIcon;
    pFileTaskNode->iEventType   = Config_GetCloudMng()->iCloudUpLoadMode;
    pFileTaskNode->uiTaskId     = uiReqId;
    pFileTaskNode->uiTaskType   = 0;
    pFileTaskNode->uiUpDateFlag = 0;
    pFileTaskNode->uiUpLoadFileFlag = 0;
    pFileTaskNode->uiStatus    = EN_CLOUDSTG_TASK_INIT;
    pFileTaskNode->iCamId      = iCamId;
    pFileTaskNode->uiPicNum    = uiJpgCnt;
    pFileTaskNode->uiSnapCnt   = 0;
    pFileTaskNode->uiRealCnt   = 0;
    pFileTaskNode->iStopFlag   = 0;
    pFileTaskNode->uiUseFlag   = 1;
    pFileTaskNode->pucBuff     = MOS_NULL;
    pFileTaskNode->uiBuffLen   = 0;
    pFileTaskNode->pFunCloudFileSendCb = pFunFileSendCb;
    pFileTaskNode->iSnapRetry  = 0;
    MOS_MEMSET(&pFileTaskNode->stCommitInfo,0,sizeof(ST_CLOUDSTG_COMMITINFO));
    pFileTaskNode->stCommitInfo.uiType = EN_CLOUDSTG_RESOURCE_PIC;
    return MOS_OK;
}

_INT CloudStg_StartSendAlivePic(_UI uiReqId,_INT iCamId,_UI uiJpgCnt,_CTIME_T cSignTime,PFUN_CLOUDFILESENDCB pFunFileSendCb)
{
    _UI uiOpenFlag = 0;
    if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Have No net");
        return MOS_ERR;
    }

    if(Config_GetCloudSnapProp(MOS_NULL,MOS_NULL,MOS_NULL,MOS_NULL,&uiOpenFlag) == MOS_ERR || uiOpenFlag == 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Have No Cloud Snapshot Buss");
        return MOS_ERR;
    }
    
    CloudStg_PicTaskAddNode(uiReqId,iCamId,uiJpgCnt,0,cSignTime,pFunFileSendCb);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u start send alive jpg camid %u jpg cnt %u",uiReqId,iCamId,uiJpgCnt);
    return MOS_OK;
}

_INT CloudStg_StartSendIconPic(_UI uiReqId,_INT iCamId,_UI uiJpgCnt,_CTIME_T cSignTime,PFUN_CLOUDFILESENDCB pFunFileSendCb)
{
    _UI uiOpenFlag = 0;
    if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Have No net");
        return MOS_ERR;
    }

    // 获取云端拍照参数
    if(Config_GetCloudSnapProp(MOS_NULL,MOS_NULL,MOS_NULL,MOS_NULL,&uiOpenFlag) == MOS_ERR || uiOpenFlag == 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Have No Cloud Snapshot Buss");
        return MOS_ERR;
    }

    // 添加拍照任务
    CloudStg_PicTaskAddNode(uiReqId,iCamId,uiJpgCnt,1,cSignTime,pFunFileSendCb);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u start send icon jpg camid %u jpg cnt %u",uiReqId,iCamId,uiJpgCnt);
    return MOS_OK;
}

_INT CloudStg_StartTimerSnap(_INT iCamId,_INT iPicType,_INT iSnapInterval ,_UI uiJpgCnt)
{
    _UI uiCnt = 0;
    _UI uiOpenFlag = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;
    ST_CLOUDSTG_FILE_NODE *pFileTaskTmpNode = MOS_NULL;

    if(Config_GetCloudMng()->iCloudAbility == 0){
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Have No Cloud Bussness");
        return MOS_OK;
    }
    if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Have No net");
        return MOS_ERR;
    }
    if(Config_GetCloudSnapProp(MOS_NULL,MOS_NULL,MOS_NULL,MOS_NULL,&uiOpenFlag) == MOS_ERR || uiOpenFlag == 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Have No Cloud Snapshot Buss");
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskTmpNode, stIterator)
    {
        if(pFileTaskTmpNode->iCamId == iCamId && pFileTaskTmpNode->uiTaskType == 3)
        {
            pFileTaskNode = pFileTaskTmpNode;
        }
        else{
            uiCnt++;
        }
    }
    if(uiCnt >= 2 || uiJpgCnt > 10)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"task cnt %u so not upload alive jpg",uiCnt);
        return MOS_ERR;
    }
    if(pFileTaskNode == MOS_NULL)
    {
        pFileTaskNode = (ST_CLOUDSTG_FILE_NODE*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_FILE_NODE));
        MOS_LIST_ADDTAIL(&CloudStg_GetMng()->stFileList, pFileTaskNode);
    }
    pFileTaskNode->iStopFlag    = 0;
    pFileTaskNode->tCreatTime   = Mos_Time();
    pFileTaskNode->uiTaskType   = 3;
    pFileTaskNode->uiFileType   = 2;
    pFileTaskNode->iSnapInterval     = iSnapInterval;
    pFileTaskNode->tNextSnTime  = Mos_Time();
    pFileTaskNode->iPicType     = iPicType;
    pFileTaskNode->uiUpDateFlag = 0;
    pFileTaskNode->uiUpLoadFileFlag = 0;
    pFileTaskNode->uiStatus    = EN_CLOUDSTG_TASK_INIT;
    pFileTaskNode->iCamId      = iCamId;
    pFileTaskNode->uiPicNum    = uiJpgCnt;
    pFileTaskNode->uiSnapCnt   = 0;
    pFileTaskNode->uiRealCnt   = 0;
    pFileTaskNode->uiUseFlag   = 1;
    pFileTaskNode->pucBuff     = MOS_NULL;
    pFileTaskNode->uiBuffLen   = 0;
    pFileTaskNode->pFunCloudFileSendCb = MOS_NULL;
    pFileTaskNode->iSnapRetry  = 0;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"start taskid %u send alive jpg camid %u get jpg cnt %u timer interval %d",
        pFileTaskNode->uiTaskId,iCamId,uiJpgCnt,iSnapInterval);
    return MOS_OK;
}

_INT CloudStg_StartSendFilePic(_UI uiReqId,_INT iCamId,_UC *pucEidName)
{
    MOS_PARAM_NULL_RETERR(pucEidName);

    _UI uiUseCnt = 0;
    _UI uiOpenFlag = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;
    ST_CLOUDSTG_FILE_NODE *pFileTaskFreeNode = MOS_NULL;

    if(Config_GetCloudMng()->iCloudAbility == 0){
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Have No Cloud Bussness");
        return MOS_OK;
    }
    if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Have No net");
        return MOS_ERR;
    }
    if(Config_GetCloudSnapProp(MOS_NULL,MOS_NULL,MOS_NULL,MOS_NULL,&uiOpenFlag) == MOS_ERR || uiOpenFlag == 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Have No Cloud Snapshot Buss");
        return MOS_ERR;
    }
    
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskNode, stIterator)
    {
        if(pFileTaskNode->uiUseFlag == 0)
        {
            pFileTaskFreeNode = pFileTaskNode;
        }
        else
        {
            uiUseCnt++;
        }
    }
    if(uiUseCnt >= 5)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"task cnt %u so not upload ",uiUseCnt);
        return MOS_ERR;
    }
    if(pFileTaskFreeNode == MOS_NULL)
    {
        pFileTaskFreeNode = (ST_CLOUDSTG_FILE_NODE*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_FILE_NODE));
        MOS_LIST_ADDTAIL(&CloudStg_GetMng()->stFileList, pFileTaskFreeNode);
    }
    pFileTaskNode->iStopFlag        = 0;
    pFileTaskFreeNode->uiRealCnt    = 0;
    pFileTaskFreeNode->uiSnapCnt    = 0;
    pFileTaskFreeNode->uiTaskType   = 1;
    pFileTaskFreeNode->uiFileType   = 2;
    pFileTaskFreeNode->uiUpDateFlag = 0;
    pFileTaskFreeNode->uiUpLoadFileFlag = 0;
    pFileTaskFreeNode->tCreatTime   = Mos_Time();
    pFileTaskFreeNode->iCamId       = iCamId;
    pFileTaskFreeNode->uiTaskId     = uiReqId;
    pFileTaskFreeNode->uiPicNum     = 1;
    pFileTaskFreeNode->uiStatus     = EN_CLOUDSTG_TASK_INIT;
    MOS_MEMSET(pFileTaskFreeNode->aucToken,0,256);
    MOS_STRLCPY(pFileTaskFreeNode->aucEidName, pucEidName, sizeof(pFileTaskFreeNode->aucEidName));
    pFileTaskNode->pFunCloudFileSendCb = MOS_NULL;
    pFileTaskFreeNode->uiUseFlag    = 1;
    pFileTaskFreeNode->iSnapRetry   = 0;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"start taskid %u handle %p  send file jpg %s camid %u ",
        pFileTaskFreeNode->uiTaskId,pFileTaskFreeNode,pucEidName,iCamId);
    return MOS_OK;
}

_INT CloudStg_UploadLocalLog(_UI uiReqId,_UC *pucFileName,_UC *pucDesInfo)
{
    MOS_PARAM_NULL_RETERR(pucFileName);
    // MOS_PARAM_NULL_RETERR(pucDesInfo);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;
    ST_CLOUDSTG_FILE_NODE *pFileTaskFreeNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskNode, stIterator)
    {
        if(pFileTaskNode->uiUseFlag == 0)
        {
            pFileTaskFreeNode = pFileTaskNode;
            break;
        }
    }
    if(pFileTaskFreeNode == MOS_NULL)
    {
        pFileTaskFreeNode = (ST_CLOUDSTG_FILE_NODE*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_FILE_NODE));
        MOS_LIST_ADDTAIL(&CloudStg_GetMng()->stFileList, pFileTaskFreeNode);
    }
    pFileTaskFreeNode->iStopFlag        = 0;
    pFileTaskFreeNode->uiTaskType   = 2;
    pFileTaskFreeNode->uiFileType   = 3;
    pFileTaskFreeNode->uiUpDateFlag = 0;
    pFileTaskFreeNode->uiUpLoadFileFlag = 0;
    pFileTaskFreeNode->tCreatTime   = Mos_Time();
    pFileTaskFreeNode->uiTaskId     = uiReqId;
    pFileTaskFreeNode->uiStatus     = EN_CLOUDSTG_TASK_INIT;
    pFileTaskFreeNode->pucDesBuff   = MOS_STRCPYALLOC(pucDesInfo);
    MOS_MEMSET(pFileTaskFreeNode->aucToken,0,256);
    MOS_STRLCPY(pFileTaskFreeNode->aucFileName, pucFileName, sizeof(pFileTaskFreeNode->aucFileName));
    pFileTaskFreeNode->pFunCloudFileSendCb = MOS_NULL;
    pFileTaskFreeNode->uiUseFlag    = 1;
    pFileTaskFreeNode->iSnapRetry   = 0;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"start taskid %u handle %p send log file %s",
        pFileTaskFreeNode->uiTaskId,pFileTaskFreeNode,pucFileName);
    return MOS_OK;
}
_INT CloudStg_UploadLogEx2(_UC *pucStrLog, _UI uiReqId, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC * pucEt, _INT iLevel)
{
#if CLOUDSTG_USE_LOGGER_MODULE
    MOS_PARAM_NULL_RETERR(pucStrLog);
    _UC aucMsgBuf[CFG_STRING_MAXLEN] = {0};
    MOS_VSNPRINTF(aucMsgBuf, sizeof(aucMsgBuf),"%s %s", pucStrLog, pucMsg);
    MOS_LOG_INF(pucStrLog, "[%s][%s]", pucUrl, pucMsg);
    return CloudStg_LoggerPushLog(uiReqId, pucUrl, iHostStatus, iRt, aucMsgBuf, pucEt, iLevel);
#else
    MOS_PARAM_NULL_RETERR(pucUrl);
    MOS_PARAM_NULL_RETERR(pucMsg);
    // MOS_PARAM_NULL_RETERR(pucEt);
    MOS_PARAM_NULL_RETERR(pucStrLog);

    if (!CloudStg_GetMng()->ucRunFlag)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"CloudStg service is unavailable. %d", CloudStg_GetMng()->ucRunFlag);
        return MOS_FALSE;
    }

    if ((Config_GetSystemMng()->iCloudUploadLogLe==0?2:Config_GetSystemMng()->iCloudUploadLogLe) < iLevel)
    {
        return MOS_FALSE;
    }

    _UC  ucMsgBuf[CFG_STRING_MAXLEN] = {0};
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;
    ST_CLOUDSTG_FILE_NODE *pFileTaskFreeNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskNode, stIterator)
    {
        if(pFileTaskNode->uiUseFlag == 0)
        {
            pFileTaskFreeNode = pFileTaskNode;
            break;
        }
    }
    if(pFileTaskFreeNode == MOS_NULL)
    {
        pFileTaskFreeNode = (ST_CLOUDSTG_FILE_NODE*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_FILE_NODE));
        MOS_LIST_ADDTAIL(&CloudStg_GetMng()->stFileList, pFileTaskFreeNode);
    }
    pFileTaskFreeNode->iStopFlag    = 0;
    pFileTaskFreeNode->uiTaskType   = 4;
    pFileTaskFreeNode->uiFileType   = 3;
    pFileTaskFreeNode->uiUpDateFlag = 0;
    pFileTaskFreeNode->uiUpLoadFileFlag = 0;
    pFileTaskFreeNode->tCreatTime   = Mos_Time();
    pFileTaskFreeNode->uiTaskId     = uiReqId;
    pFileTaskFreeNode->uiStatus     = EN_CLOUDSTG_TASK_INIT;
    pFileTaskFreeNode->pucDesBuff   = MOS_NULL;
    pFileTaskFreeNode->iSnapRetry   = 0;

    MOS_VSNPRINTF(ucMsgBuf, sizeof(ucMsgBuf),"[%s]: %s", pucStrLog, pucMsg);
    /*log*/
    pFileTaskFreeNode->pucUrl       = MOS_STRCPYALLOC(pucUrl);
    pFileTaskFreeNode->pucMsg       = MOS_STRCPYALLOC(ucMsgBuf);
    if (pucEt && MOS_STRLEN(pucEt) <= CFG_STRING_MAXLEN)
    {
        pFileTaskFreeNode->pucEt    = MOS_STRCPYALLOC(pucEt);
    }
    pFileTaskFreeNode->iHostStatus  = iHostStatus;
    pFileTaskFreeNode->iRt          = iRt;

    MOS_MEMSET(pFileTaskFreeNode->aucToken,0,256);
    pFileTaskFreeNode->pFunCloudFileSendCb = MOS_NULL;
    pFileTaskFreeNode->uiUseFlag    = 1;

    MOS_LOG_INF(pucStrLog,"Url %s, Msg %s", pucUrl, pucMsg);
    return MOS_OK;
#endif
}

_INT CloudStg_UploadLogEx(_UI uiReqId, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC * pucEt, _INT iLevel)
{
#if CLOUDSTG_USE_LOGGER_MODULE
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"[%s][%s]", pucUrl, pucMsg);
    return CloudStg_LoggerPushLog(uiReqId, pucUrl, iHostStatus, iRt, pucMsg, pucEt, iLevel);
#else
    MOS_PARAM_NULL_RETERR(pucUrl);
    MOS_PARAM_NULL_RETERR(pucMsg);
    // MOS_PARAM_NULL_RETERR(pucEt);

    if (!CloudStg_GetMng()->ucRunFlag)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"CloudStg service is unavailable. %d", CloudStg_GetMng()->ucRunFlag);
        return MOS_FALSE;
    }

    if ((Config_GetSystemMng()->iCloudUploadLogLe==0?2:Config_GetSystemMng()->iCloudUploadLogLe) < iLevel)
    {
        return MOS_FALSE;
    }

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;
    ST_CLOUDSTG_FILE_NODE *pFileTaskFreeNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskNode, stIterator)
    {
        if(pFileTaskNode->uiUseFlag == 0)
        {
            pFileTaskFreeNode = pFileTaskNode;
            break;
        }
    }
    if(pFileTaskFreeNode == MOS_NULL)
    {
        pFileTaskFreeNode = (ST_CLOUDSTG_FILE_NODE*)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_FILE_NODE));
        MOS_LIST_ADDTAIL(&CloudStg_GetMng()->stFileList, pFileTaskFreeNode);
    }
    pFileTaskFreeNode->iStopFlag    = 0;
    pFileTaskFreeNode->uiTaskType   = 4;
    pFileTaskFreeNode->uiFileType   = 3;
    pFileTaskFreeNode->uiUpDateFlag = 0;
    pFileTaskFreeNode->uiUpLoadFileFlag = 0;
    pFileTaskFreeNode->tCreatTime   = Mos_Time();
    pFileTaskFreeNode->uiTaskId     = uiReqId;
    pFileTaskFreeNode->uiStatus     = EN_CLOUDSTG_TASK_INIT;
    pFileTaskFreeNode->pucDesBuff   = MOS_NULL;
    pFileTaskFreeNode->iSnapRetry   = 0;

    /*log*/
    pFileTaskFreeNode->pucUrl       = MOS_STRCPYALLOC(pucUrl);
    pFileTaskFreeNode->pucMsg       = MOS_STRCPYALLOC(pucMsg);
    pFileTaskFreeNode->pucEt        = MOS_STRCPYALLOC(pucEt);
    pFileTaskFreeNode->iHostStatus  = iHostStatus;
    pFileTaskFreeNode->iRt          = iRt;

    MOS_MEMSET(pFileTaskFreeNode->aucToken,0,256);
    pFileTaskFreeNode->pFunCloudFileSendCb = MOS_NULL;
    pFileTaskFreeNode->uiUseFlag    = 1;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"start taskid %u handle %p upload log, pucUrl %s, pucMsg %s",
        pFileTaskFreeNode->uiTaskId,pFileTaskFreeNode, pucUrl, pucMsg);
    return MOS_OK;
#endif
}
_INT CloudStg_UploadLog(_UI uiReqId, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _INT iLevel)
{
#if CLOUDSTG_USE_LOGGER_MODULE
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"[%s][%s]", pucUrl, pucMsg);
    return CloudStg_LoggerPushLog(uiReqId, pucUrl, iHostStatus, iRt, pucMsg, NULL, iLevel);
#else
    return CloudStg_UploadLogEx(uiReqId, pucUrl, iHostStatus, iRt, pucMsg, NULL, iLevel);
#endif
}

/************************************************************************************************
*************************************************************************************************/
_INT CloudStg_ProcMediaUpdate(ST_CLOUDSTG_TASK_NODE *pstTaskNode, _UC isPatch)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);

    _INT iRet = 0;
    if(pstTaskNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
    {
        if (isPatch)
        {
            iRet = CloudStg_PatchAliveUploadProc(pstTaskNode);
        }
        else
        {
            iRet = CloudStg_AliveUploadProc(pstTaskNode);
        }
        
    }
    return iRet;
}

_VOID CloudStg_ProcFileUpLoadStatus(_VPTR vpBase,_UI uiStatus,_UC *pucFid,_UC *pucETag,_UI uiTargetSize,_UC *pucBucket,_UC *pucStorageProvider)
{
    MOS_PARAM_NULL_NORET(pucFid);
    MOS_PARAM_NULL_NORET(pucETag);
    MOS_PARAM_NULL_NORET(pucBucket);
    MOS_PARAM_NULL_NORET(pucStorageProvider);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskNode, stIterator)
    {
        if(pFileTaskNode->uiUseFlag && pFileTaskNode->uiTaskId == (_UI)vpBase)
        {
            if(uiStatus == 0)
            {
                // 设置消息告警时间
                pFileTaskNode->stCommitInfo.cAlarmTime = pFileTaskNode->tCreatTime;
                MOS_STRLCPY(pFileTaskNode->stCommitInfo.aucObjId,pucFid,sizeof(pFileTaskNode->stCommitInfo.aucObjId));
                MOS_STRLCPY(pFileTaskNode->stCommitInfo.aucETag,pucETag,sizeof(pFileTaskNode->stCommitInfo.aucETag));
                pFileTaskNode->stCommitInfo.uiFileLen = uiTargetSize;
                MOS_STRLCPY(pFileTaskNode->stCommitInfo.aucFileCId,pucBucket,sizeof(pFileTaskNode->stCommitInfo.aucFileCId));
                MOS_STRLCPY(pFileTaskNode->stCommitInfo.aucFileSP,pucStorageProvider,sizeof(pFileTaskNode->stCommitInfo.aucFileSP));
                pFileTaskNode->uiUpLoadFileFlag = 1;
            }
            else
            {
                pFileTaskNode->uiUpLoadFileFlag = 2;
            }
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u recv upload file status %u fid %s",pFileTaskNode->uiTaskId,uiStatus,pucFid);
            break;
        }
    }
    return;
}

/******************************************************************************
��λ �汾 �� ��λ jpg ��Ŀ 4λ ���� ����
*******************************************************************************/
static _INT CloudStg_SendAlivePicitures(ST_CLOUDSTG_FILE_NODE *pFileTaskNode)
{
    MOS_PARAM_NULL_RETERR(pFileTaskNode);

    _UC *pucJpgBuff = MOS_NULL;
    _INT  iJpgLen  = 0,iLenTmp = 0;
    _CTIME_T cTime = Mos_Time();

    if(3 == pFileTaskNode->uiTaskType && cTime < pFileTaskNode->tNextSnTime)
    {
        if(pFileTaskNode->iStopFlag == 1)
        {
            pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
        }
        return MOS_OK;
    }
    if(Mos_GetTickCount() - pFileTaskNode->uiTickCnt < 500)
    {
        return MOS_OK;
    }
    ZJ_GetJpgLock();

    // 获取JPG图片
    if(3 == pFileTaskNode->uiTaskType)
    {
        iJpgLen = ZJ_GetOneJpg(pFileTaskNode->iCamId,pFileTaskNode->iPicType,&pucJpgBuff);
    }
    else if(3 != pFileTaskNode->uiTaskType && 1 == pFileTaskNode->uiIcon){
        iJpgLen = ZJ_GetOneJpg(pFileTaskNode->iCamId,EN_ZJ_PICTURE_SMALL,&pucJpgBuff);
    }
    else
    {
        iJpgLen = ZJ_GetOneJpg(pFileTaskNode->iCamId,EN_ZJ_PICTURE_MIDDLE,&pucJpgBuff);
    }
    if(iJpgLen <= 0 || pucJpgBuff == MOS_NULL)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Recv err para, iJpgLen: %d, pucJpgBuff: %p\r\n", iJpgLen, pucJpgBuff);

        // 重试抓拍3次
        if (++pFileTaskNode->iSnapRetry >= 3)
        {
            pFileTaskNode->iSnapRetry = 0;
            pFileTaskNode->uiUpLoadFileFlag = 2;
            pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_START;
        }
        ZJ_GetJpgUnlock();
        return MOS_OK;
    }
    if(pFileTaskNode->uiSnapCnt == 0)
    {
        if(pFileTaskNode->uiBuffLen < iJpgLen)
        {
#ifdef USE_SNAP_STACK 
            pFileTaskNode->uiBuffLen = iJpgLen;  
            MOS_MEMSET(CloudStg_GetMng()->pucPicBuf, 0, sizeof(CloudStg_GetMng()->pucPicBuf));
            pFileTaskNode->pucBuff = CloudStg_GetMng()->pucPicBuf;
#else
            pFileTaskNode->uiBuffLen = iJpgLen;
            if (CloudStg_GetMng()->iPicBufLen < pFileTaskNode->uiBuffLen)
            {
                if (CloudStg_GetMng()->pucPicBuf)
                {
                    MOS_FREE(CloudStg_GetMng()->pucPicBuf);
                }
                CloudStg_GetMng()->pucPicBuf  = (_VPTR)Mos_MallocClr(pFileTaskNode->uiBuffLen);
                CloudStg_GetMng()->iPicBufLen = pFileTaskNode->uiBuffLen;
            }
            pFileTaskNode->pucBuff = (_UC*)CloudStg_GetMng()->pucPicBuf;
#endif
        }
        if(pFileTaskNode->pucBuff == MOS_NULL)
        {
            ZJ_GetJpgUnlock();
            return MOS_ERR;
        }
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"alive alloc jpg buff %p , size: %d",pFileTaskNode->pucBuff, pFileTaskNode->uiBuffLen);
    }
    pFileTaskNode->uiSnapCnt++;
    pFileTaskNode->uiTickCnt = Mos_GetTickCount();
    pFileTaskNode->uiRealCnt++;
    MOS_MEMCPY(pFileTaskNode->pucBuff, pucJpgBuff,iJpgLen);

    ZJ_GetJpgUnlock();
    if(pFileTaskNode->uiSnapCnt >= pFileTaskNode->uiPicNum)
    {
        if(pFileTaskNode->uiRealCnt > 0)
        {
            CloudStg_TransSendExtUriWithMem(pFileTaskNode->uiTaskId,pFileTaskNode->pucBuff, pFileTaskNode->uiBuffLen ,pFileTaskNode->uiIcon,
                EN_CLOUDSTG_RESOURCE_PIC,CloudStg_ProcFileUpLoadStatus,(_VPTR)pFileTaskNode->uiTaskId,pFileTaskNode->tCreatTime);
        }
        else
        {
            pFileTaskNode->uiUpLoadFileFlag = 2;
        }
        pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_START;
        pFileTaskNode->tUpInfoTime = 0;
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u buff %p send alive jpg cnt %d ok",pFileTaskNode->uiTaskId,pFileTaskNode->pucBuff,pFileTaskNode->uiRealCnt);
    }
    return MOS_OK;
}

_INT CloudStg_StopTimerSnap(_INT iCamId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;

    MOS_LOG_INF(CLOUDSTG_LOGSTR,"camid %d stop timer snap",iCamId);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskNode, stIterator)
    {
        if(pFileTaskNode->iCamId == iCamId && pFileTaskNode->uiTaskType == 3)
        {
            pFileTaskNode->iStopFlag = 1;
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u buff %p send Timer jpg %u end",pFileTaskNode->uiTaskId,pFileTaskNode->pucBuff,pFileTaskNode->uiRealCnt);
            break;
        }
    }
    if(pFileTaskNode == MOS_NULL)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Can't find node camid :%d");
    }
    return MOS_OK;
}

/******************************************************************************
��λ �汾 �� ��λ jpg ��Ŀ 4λ ���� ����
*******************************************************************************/
static _INT CloudStg_SendFilePicitures(ST_CLOUDSTG_FILE_NODE *pFileTaskNode)
{
    MOS_PARAM_NULL_RETERR(pFileTaskNode);

    _UI i = 0;
    _US usLenTmp = 0;
    _UI uiLenTmp = 0;
    _UI uiLocalBuffLen = 0;
    _HFILE hFile = MOS_NULL;
    _UC aucFilePath[256];
    _CTIME_T cSignTime = 0;
    ST_MOS_FILE_INF stFileInf;
    ST_MOS_SYS_TIME stSysTime = {0};

    // 设置名字
    Snap_GetJpgPathByName(pFileTaskNode->iCamId,pFileTaskNode->aucEidName,aucFilePath,256);
    MOS_SSCANF(pFileTaskNode->aucEidName,"%04hu-%02hu-%02hu%02hu%02hu%02hu%*s",&stSysTime.usYear,&stSysTime.usMonth,&stSysTime.usDay,
                                                                            &stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
    // 获取系统时间
    cSignTime = Mos_SysTimetoTime(&stSysTime);
    if(MOS_STRLEN(aucFilePath) == 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"taskid %u get jpg path  err ",pFileTaskNode->uiTaskId);
        pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
        return MOS_ERR;
    }

    // 遍历文件节点，打开文件，读文件
    for( i = 0;i < pFileTaskNode->uiPicNum;i++)
    {
        if(Mos_FileStat(aucFilePath,&stFileInf) == MOS_ERR || stFileInf.uiSize == 0)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"taskid %u file %s len is 0",pFileTaskNode->uiTaskId,aucFilePath);
            continue;
        }
        
        if(pFileTaskNode->uiSnapCnt == 0)
        {
            uiLocalBuffLen = stFileInf.uiSize*pFileTaskNode->uiPicNum + stFileInf.uiSize/2;
            if(uiLocalBuffLen > pFileTaskNode->uiBuffLen)
            {
#ifdef USE_SNAP_STACK
                pFileTaskNode->uiBuffLen = uiLocalBuffLen + stFileInf.uiSize/2;
                MOS_MEMSET(CloudStg_GetMng()->pucPicBuf, 0, sizeof(CloudStg_GetMng()->pucPicBuf));
                pFileTaskNode->pucBuff = CloudStg_GetMng()->pucPicBuf;
#else
                pFileTaskNode->uiBuffLen = uiLocalBuffLen + stFileInf.uiSize/2;
                if (CloudStg_GetMng()->iPicBufLen < pFileTaskNode->uiBuffLen)
                {
                    if (CloudStg_GetMng()->pucPicBuf)
                    {
                        MOS_FREE(CloudStg_GetMng()->pucPicBuf);
                    }
                    CloudStg_GetMng()->pucPicBuf  = (_VPTR)Mos_MallocClr(pFileTaskNode->uiBuffLen);
                    CloudStg_GetMng()->iPicBufLen = pFileTaskNode->uiBuffLen;
                }
                pFileTaskNode->pucBuff = (_UC*)CloudStg_GetMng()->pucPicBuf;
#endif
            }
            if(pFileTaskNode->pucBuff == MOS_NULL)
            {
                pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
                return MOS_ERR;
            }
            pFileTaskNode->pucBuff[0] = 0;
            pFileTaskNode->pucBuff[1] = 1;
            pFileTaskNode->uiOffset   = 4;
        }
        if(pFileTaskNode->uiOffset + stFileInf.uiSize + 4 > pFileTaskNode->uiBuffLen)
        {
            continue;;
        }
        uiLenTmp = MOS_INET_HTONL(stFileInf.uiSize);
        hFile = Mos_FileOpen(aucFilePath, MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
        if(hFile == MOS_NULL)
        {
            continue;
        }
        if(Mos_FileRead(hFile,pFileTaskNode->pucBuff+pFileTaskNode->uiOffset+4,stFileInf.uiSize) != stFileInf.uiSize)
        {
            continue;
        }
        pFileTaskNode->uiSnapCnt++;
        MOS_MEMCPY(pFileTaskNode->pucBuff+pFileTaskNode->uiOffset,&uiLenTmp,sizeof(uiLenTmp));
        pFileTaskNode->uiOffset += 4 + stFileInf.uiSize;
    }
    if(pFileTaskNode->uiSnapCnt == 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"taskid %u have no jpg");
        pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
        return MOS_ERR;
    }
    usLenTmp = MOS_INET_HTONS(pFileTaskNode->uiPicNum);
    MOS_MEMCPY(pFileTaskNode->pucBuff + 2, &usLenTmp, 2);
    // 发送
    CloudStg_TransSendExtUriWithMem(pFileTaskNode->uiTaskId,pFileTaskNode->pucBuff,pFileTaskNode->uiOffset,pFileTaskNode->uiIcon,
        EN_CLOUDSTG_RESOURCE_PIC,CloudStg_ProcFileUpLoadStatus,(_VPTR)pFileTaskNode->uiTaskId,cSignTime);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u send file jpg ok pFileTaskNode->pucBuff %p ",pFileTaskNode->uiTaskId,pFileTaskNode->pucBuff);
    pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_START;
    pFileTaskNode->tUpInfoTime = 0;
    return MOS_OK;
}

_INT CloudStg_RecvStoreFileInfRspData(_UI uiReqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp = MOS_NULL;
    _INT iCode = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pFileTaskNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskNode, stIterator)
    {
        if(pFileTaskNode->uiUseFlag && pFileTaskNode->uiTaskId == uiReqId)
        {
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"),&iCode);
            if(iCode != 0)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"recv http code %u ",iCode);
            }
            pFileTaskNode->uiUpDateFlag  = 1;
            break;
        }
    }
    Adpt_Json_Delete(hJsonRoot);
    return MOS_OK;
}

static _INT CloudStg_StartSendLoacalFile(ST_CLOUDSTG_FILE_NODE *pFileTaskNode)
{
    MOS_PARAM_NULL_RETERR(pFileTaskNode);

    pFileTaskNode->tUpInfoTime = 0;
    pFileTaskNode->uiStatus    = EN_CLOUDSTG_TASK_START;
    return CloudStg_TransSendLocalFile(pFileTaskNode->aucFileName,EN_CLOUDSTG_RESOURCE_LOGFILE,
        CloudStg_ProcFileUpLoadStatus,(_VPTR)pFileTaskNode->uiTaskId);
}

static _INT CloudStg_StartUploadLog(ST_CLOUDSTG_FILE_NODE *pFileTaskNode)
{
    MOS_PARAM_NULL_RETERR(pFileTaskNode);

    pFileTaskNode->tUpInfoTime = 0;
    pFileTaskNode->uiStatus    = EN_CLOUDSTG_TASK_START;
    return CloudStg_TransUploadLog(EN_CLOUDSTG_RESOURCE_LOG,
        MOS_NULL,(_VPTR)pFileTaskNode->uiTaskId, pFileTaskNode->pucUrl, 
        pFileTaskNode->iHostStatus, pFileTaskNode->iRt, pFileTaskNode->pucMsg, pFileTaskNode->pucEt, pFileTaskNode->tCreatTime);
}

static _INT CloudStg_ProcFileUpdate(ST_CLOUDSTG_FILE_NODE *pFileTaskNode)
{
    MOS_PARAM_NULL_RETERR(pFileTaskNode);

    _INT iRet    = 0;
    if(pFileTaskNode->uiStatus == EN_CLOUDSTG_TASK_INIT)
    {
        if(pFileTaskNode->uiTaskType == 0 || pFileTaskNode->uiTaskType == 3)
        {
            // 发送实时图片
            CloudStg_SendAlivePicitures(pFileTaskNode);
        }
        else if(pFileTaskNode->uiTaskType == 1)
        {
            // 发送本地图片
            CloudStg_SendFilePicitures(pFileTaskNode);
        }
        else if(pFileTaskNode->uiTaskType == 2)
        {
            // 发送LOG FILE
            CloudStg_StartSendLoacalFile(pFileTaskNode);
        }
        else if(pFileTaskNode->uiTaskType == 4)
        {
            // 发送LOG
            CloudStg_StartUploadLog(pFileTaskNode);
        }
    }
    else if(pFileTaskNode->uiStatus == EN_CLOUDSTG_TASK_START)
    {
        if(pFileTaskNode->uiUpLoadFileFlag == 1 && MOS_ABS_NUM(Mos_Time() - pFileTaskNode->tUpInfoTime) > 5)
        {
            if(pFileTaskNode->pFunCloudFileSendCb)
            {
                MOS_VSNPRINTF(pFileTaskNode->stCommitInfo.aucIconInfo,256,"iconObjId=%s&iconETag=%s&iconFileLen=%u&iconCId=%s&iconSP=%s",
                    pFileTaskNode->stCommitInfo.aucObjId,pFileTaskNode->stCommitInfo.aucETag,pFileTaskNode->stCommitInfo.uiFileLen,
                    pFileTaskNode->stCommitInfo.aucFileCId,pFileTaskNode->stCommitInfo.aucFileSP);
                pFileTaskNode->pFunCloudFileSendCb(pFileTaskNode->uiMediaTaskId,0,pFileTaskNode->stCommitInfo.aucIconInfo);
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u upload icon ok",pFileTaskNode->uiTaskId,pFileTaskNode->uiFileType);
                pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
            }
            else if(pFileTaskNode->uiTaskType != 2 && pFileTaskNode->uiTaskType != 4)
            {
                CloudStg_ProcGetPicCommit(pFileTaskNode);
            }
            else if(pFileTaskNode->uiFileType == 3)
            {
                pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
            }
            pFileTaskNode->tUpInfoTime = Mos_Time();
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u send upload file data reqt ,type :%d",pFileTaskNode->uiTaskId,pFileTaskNode->uiFileType);
        }
        else if(pFileTaskNode->uiUpLoadFileFlag == 2)
        {
            if(pFileTaskNode->pFunCloudFileSendCb)
            {
                pFileTaskNode->pFunCloudFileSendCb(pFileTaskNode->uiMediaTaskId,400,MOS_NULL);
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u upload icon ok",pFileTaskNode->uiTaskId,pFileTaskNode->uiFileType);
                pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
            }
            MOS_LOG_WARN(CLOUDSTG_LOGSTR,"taskid %u type :%d upload err",pFileTaskNode->uiTaskId,pFileTaskNode->uiFileType);
            pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
        }
    }
    else if(pFileTaskNode->uiStatus == EN_CLOUDSTG_TASK_STOP)
    {
        if(pFileTaskNode->uiUpDateFlag == 1 )
        {
            pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
        }
        else if(pFileTaskNode->uiUpDateFlag == 0 && MOS_ABS_NUM(Mos_Time() - pFileTaskNode->tUpInfoTime) > 5)
        {
            MOS_LOG_WARN(CLOUDSTG_LOGSTR,"taskid %u type :%d Commit too long time",pFileTaskNode->uiTaskId,pFileTaskNode->uiFileType);
            pFileTaskNode->uiStatus = EN_CLOUDSTG_TASK_OVER;
        }
    }
    else if(pFileTaskNode->uiStatus == EN_CLOUDSTG_TASK_OVER)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u, type: %u send over",pFileTaskNode->uiTaskId, pFileTaskNode->uiTaskType);
        if (pFileTaskNode->pucDesBuff)
        {
            MOS_FREE(pFileTaskNode->pucDesBuff);
        }
        if (pFileTaskNode->pucUrl)
        {
            MOS_FREE(pFileTaskNode->pucUrl);
        }
        if (pFileTaskNode->pucMsg)
        {
            MOS_FREE(pFileTaskNode->pucMsg);
        }
        if (pFileTaskNode->pucEt)
        {
            MOS_FREE(pFileTaskNode->pucEt);
        }
        pFileTaskNode->uiOffset  = 0;
        pFileTaskNode->uiUseFlag = 0;
    }
    return MOS_OK;
}

static _INT CloudStg_TaskProcMsg(_VPTR pstMsg)
{
    MOS_PARAM_NULL_RETERR(pstMsg);

    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
    ST_MOS_MSGHEAD *pstMsgHead = (ST_MOS_MSGHEAD*)pstMsg;
    if(pstMsgHead == MOS_NULL)
    {
        return MOS_OK;
    }
    // 上电时需要等待请求一次“获取云存直传地址”接口，无论成功或失败。
    if (Config_GetCloudMng()->iAfterReqUrlFlag == 0)
    {
        return MOS_OK;
    }

    switch(pstMsgHead->usMsgType)
    {
        case EN_CLOUDSTG_MSG_ALIVE_UPLOAD:
        {
            ST_CLOUDSTG_ALIVE_UPLOAD_MSG *pstUpdateMsg = (ST_CLOUDSTG_ALIVE_UPLOAD_MSG*)pstMsg;
            if(pstUpdateMsg->uiContrlType == 1)
            {
                _CTIME_T cNowTime = Mos_Time();
                
                // 产生云存消息的时间与云存任务创建的时间相差3s以内，则以产生云存消息的时间为准
                if (MOS_ABS_NUM(pstUpdateMsg->tCreateTime - cNowTime) <= 3)
                {
                    cNowTime = pstUpdateMsg->tCreateTime;
                }
                else
                {
                    MOS_LOG_WARN(CLOUDSTG_LOGSTR, "the message created time: %u, now time: %u", pstUpdateMsg->tCreateTime, cNowTime);
                }
                // 开启任务
                pstTaskNode = CloudStg_OpenAliveTask(pstUpdateMsg->iCamid,pstUpdateMsg->iStreamId,EN_CLOUDSTG_STORAGE_TYPE_ALIVE,cNowTime,pstUpdateMsg->uiDuration);
                // DEBUG: 设置云存上传时间为XXs
                // pstTaskNode = CloudStg_OpenAliveTask(pstUpdateMsg->iCamid,pstUpdateMsg->iStreamId,EN_CLOUDSTG_STORAGE_TYPE_ALIVE,cNowTime,30);
                if(pstTaskNode == MOS_NULL)
                {
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR,"creat alive task err");
                    break;
                }
                pstTaskNode->iEventType = pstUpdateMsg->iEventType;
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "add taskid %u cam [%u %u] eventtype %u duration %u starttime %u",
                    pstTaskNode->uiTaskId,pstUpdateMsg->iCamid,pstUpdateMsg->iStreamId,
                    pstTaskNode->iEventType, pstUpdateMsg->uiDuration,pstTaskNode->tCreateTime);
                if(Config_GetCloudMng()->iCloudIconType == 0)
                {
                    // 上传云存图片
                    pstTaskNode->uiIconStatus = EN_CLOUDSTG_ICON_UPLOAD_TYPE_SENT;
                    CloudStg_StartSendIconPic(pstTaskNode->uiTaskId,pstTaskNode->iCamId,1,pstTaskNode->tCreateTime,CloudStg_MediaTaskSendJpgCb);
                }
            }
            else
            {
                // 停止全天候云存任务
                CloudStg_StopAliveTask(pstUpdateMsg->iCamid,pstUpdateMsg->iStreamId);
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"stop cloud update");
            }
            break;
        }
        default:
        {

        }
    }
    return MOS_OK;
}

_INT CloudStg_GetQualityInfo(_INT *piTotalSentKBytes, _INT *piAverageSpeed)
{
    MOS_PARAM_NULL_RETFALSE(piTotalSentKBytes);
    MOS_PARAM_NULL_RETFALSE(piAverageSpeed);

    _INT iRet = MOS_OK;
    _INT iTotalSentBytes = 0;
    _CTIME_T tQualityNowReqTime = Mos_Time();
    _CTIME_T tQualityTmpTime    = CloudStg_GetMng()->iQualityTotalSentInterval + CloudStg_GetMng()->iQualityTotalPatchSentInterval;

    // 计时超过一日视为错误
    if (MOS_ABS_NUM(tQualityNowReqTime - CloudStg_GetMng()->tQualityLastReqTime) > CLOUDSTG_GET_ONEDAY)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Err time interval");
        CloudStg_GetMng()->tQualityLastReqTime      = tQualityNowReqTime;
        CloudStg_GetMng()->iQualityTotalSentBytes = 0;
        CloudStg_GetMng()->iQualityTotalPatchSentBytes = 0;
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, "QualityProbe Get CloudByteCount Failed", 1);
        iRet = MOS_ERR;
    }
    else
    {
        // 计算发送字节与平均传输速率
        iTotalSentBytes  = CloudStg_GetMng()->iQualityTotalSentBytes + CloudStg_GetMng()->iQualityTotalPatchSentBytes;
        *piTotalSentKBytes = iTotalSentBytes / 1024;
        if (tQualityTmpTime)
        {
            *piAverageSpeed = *piTotalSentKBytes / tQualityTmpTime;
        }
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "Get TotalSentKBytes: %dKB, QualityTmpTime: %ds, AverageSpeed: %dKB/s", *piTotalSentKBytes, tQualityTmpTime, *piAverageSpeed);
    }
    
    CloudStg_GetMng()->tQualityLastReqTime            = tQualityNowReqTime;
    CloudStg_GetMng()->iQualityTotalSentBytes         = 0;
    CloudStg_GetMng()->iQualityTotalPatchSentBytes    = 0;
    CloudStg_GetMng()->iQualityTotalSentInterval      = 0;
    CloudStg_GetMng()->iQualityTotalPatchSentInterval = 0;
    return iRet;
}
_BOOL CloudStg_TaskNeedConnUrl(_INT iIsDirectModeChange)
{
    ST_MOS_LIST_ITERATOR stIterator     = {0};
    ST_CLOUDSTG_TASK_NODE  *pstTaskNode = MOS_NULL;
    ST_CLOUDSTG_TASK_INF *pstTansTask   = MOS_NULL;
    ST_MECS_CONN *pstTansConn           = MOS_NULL;
    _BOOL bNeed                         = MOS_FALSE;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskNode, stIterator)
    {
        if (pstTaskNode->iUseFlag == 0)
        {
            continue;
        }
        // 云存task未使用加密信息
        if (iIsDirectModeChange == MOS_FALSE && pstTaskNode->iCloudEncSwitch == -1)
        {
            continue;
        }
        
        if (pstTaskNode->hStream)
        {
            Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
            // 获取指向的网络线程任务
            // CloudStg_ConnStart->CloudStg_ResAllocUrl->等待res线程获取url
            pstTansTask = (ST_CLOUDSTG_TASK_INF*)(((ST_CLOUDSTG_STREAM *)(pstTaskNode->hStream))->hCSTask);
            pstTansConn = (ST_MECS_CONN *)pstTansTask->hCSConn;
            if (pstTansConn)
            {
                // 云存模式改变
                if (iIsDirectModeChange == MOS_TRUE)
                {
                    // 还没开始传，可以立即结束
                    if (pstTansConn->pstConnUrl == MOS_NULL && pstTaskNode->iState <= EN_CLOUDSTG_TASK_START)
                    {
                        // MOS_PRINTF("%s connurl=null\n", __FUNCTION__);
                        bNeed = MOS_TRUE;
                        Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
                        break;
                    }
                }
                // 加密方式改变
                else
                {
                    if (pstTansConn->pstConnUrl == MOS_NULL)
                    {
                        // MOS_PRINTF("%s connurl=null\n", __FUNCTION__);
                        bNeed = MOS_TRUE;
                        Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
                        break;
                    }
                }
            }
            Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
        }
        else
        {
            // MOS_PRINTF("%s stream=null\n", __FUNCTION__);
            bNeed = MOS_TRUE;
            break;
        }        
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    MOS_PRINTF("%s need=%d\n", __FUNCTION__, bNeed);
    return bNeed;
}
static _INT CloudStg_TaskLoop(_VPTR pParam)
{
    _UI uiAliveTaskCnt = 0;
    _INT iLoopFlag = 0;
    _VPTR pstMsg = MOS_NULL;
    _CTIME_T cNowTime = 0;
    _CTIME_T cOldTime = 0;
    _CTIME_T cOldTimeSwd = 0;
    _CTIME_T cAliveTime = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE  *pstTaskNode   = MOS_NULL;
    ST_CLOUDSTG_FILE_NODE  *pFileTaskNode = MOS_NULL;
    ST_CLOUDSTG_COMMITINFO *pstCommitNode = MOS_NULL;
    _HSWDWRITE hSwdFeedDog = MOS_NULL;

#if CLOUDSTG_NET_CHECK
    // 检测网络状态，通网才能继续
    do
    {
        if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET)
        {
            iLoopFlag++;
        }
        else if(Http_GetNetWorkType() != EN_ZJ_NETWORK_TYPE_AP)
        {
            CloudStg_GetMng()->uiCurNetStatus = 1;
            break;
        }
        Mos_Sleep(1000);
    }while(iLoopFlag < 40);
#else
    CloudStg_GetMng()->uiCurNetStatus = 1;
#endif

    // 检测单元话调度是否已经成功获取过云存域名地址
    while (1)
    {
        if (MsgMng_GetStartWorkFlag() == 1)
        {
            break;
        }
        Mos_Sleep(1000);
    }

    hSwdFeedDog = Swd_AppThreadRegist(CLOUDSTG_NORMAL_APP, FEED_DOG_MAX_TIMESEC);
        
    while(CloudStg_GetMng()->ucRunFlag == 1)
    {
        iLoopFlag = 0;
        uiAliveTaskCnt = 0;
        cNowTime = Mos_Time();

        // 查询消息队列
        if(Mos_MsgQueueGetCount(CloudStg_GetMng()->hMsgQueue) > 0)
        {
            pstMsg = Mos_MsgQueuePop(CloudStg_GetMng()->hMsgQueue);
            // 收到云存上传消息，添加到任务链表中
            CloudStg_TaskProcMsg(pstMsg);
            MOS_FREE(pstMsg);
        }
        
        // 获取消息
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskNode, stIterator)
        {
            if(pstTaskNode->iUseFlag == 0)
            {
                continue;
            }
            else if(pstTaskNode->iState <= EN_CLOUDSTG_TASK_STOP)
            {
                uiAliveTaskCnt++;
            }
            
            // 开始云存上传流程
            if(CloudStg_ProcMediaUpdate(pstTaskNode, MOS_FALSE) <= 0)
            {
                iLoopFlag = 1;
            }
        }

#if 0
        // 云存
        if (Mos_FileIsExist("/mnt/config/test_cloud_ban_read_video") == MOS_TRUE)
        {
            _HFILE hFile;
            _UC aucSleepTime[32] = {0};
            _INT iSleepTime = 0;

            hFile = Mos_FileOpen("/mnt/config/test_cloud_ban_read_video",MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
            Mos_FileRead(hFile,aucSleepTime,32);
            iSleepTime = atoi(aucSleepTime);

            Mos_FileClose(hFile);
            Mos_FileRmv("/mnt/config/test_cloud_ban_read_video");

            // Mos_Sleep(iSleepTime * 1000);
            CloudStg_GetMng()->iBanReadVideoFlag = ~CloudStg_GetMng()->iBanReadVideoFlag;

            MOS_PRINTF("now set iBanReadVideoFlag to %d\r\n", CloudStg_GetMng()->iBanReadVideoFlag);
        }
#endif
        // 60秒打印一次
        if (MOS_ABS_NUM(cNowTime - cOldTime) >= CLOUDSTG_GET_ONEMINUTE)
        {
            cOldTime = cNowTime;
            Mos_MutexLock(&CloudStg_GetMng()->hMutex);
            FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskNode, stIterator)
            {
                if(pstTaskNode->iUseFlag == 0)
                {
                    continue;
                }
                if (cNowTime != pstTaskNode->tCreateTime)
                {
                    cAliveTime = MOS_ABS_NUM(cNowTime - pstTaskNode->tCreateTime);
                    if (cAliveTime != 0)
                    {
                        MOS_LOG_INF(CLOUDSTG_LOGSTR,"[taskid: %d]STATE: %d, directmode: %d, alivetime: %us, buflist: %d, speed: %dKB/s", 
                                    pstTaskNode->uiTaskId, pstTaskNode->iState, pstTaskNode->iDirectMode, cAliveTime,
                                    CloudStg_StreamGetBufListCacheNodeCount(pstTaskNode->hStream),
                                    (pstTaskNode->iAllSentBytes / 1024) / cAliveTime);
                    }
                }
            }
            Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
        }

        if (MOS_ABS_NUM(cNowTime - cOldTimeSwd) >= 1)
        {
            cOldTimeSwd = cNowTime;
            Swd_AppThreadFeedDog(hSwdFeedDog);
        }

        if (CloudStg_GetMng()->iOpenFlag != 0)
        {
            // 获取套餐变更信息
            CloudStg_CheckChargeInfo(uiAliveTaskCnt,cNowTime);
        }
        
        // 判断网络状态，超时是否超过300秒
        // FIXME: ADAPT TO NVR
#if CLOUDSTG_NET_CHECK
        CloudStg_CheckNetStatus(0, cNowTime);
#endif
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList, pFileTaskNode, stIterator)
        {
            if(pFileTaskNode->uiUseFlag == 0)
            {
                continue;
            }

            // 上传文件
            CloudStg_ProcFileUpdate(pFileTaskNode);
        }

        // 事件云存埋点处理
        CloudstgEventInfUploadProc(cNowTime);

        if(iLoopFlag > 0)
        {
            Mos_Sleep(10);
        }
        else
        {
            Mos_Sleep(50);
        }
    }

    Swd_AppThreadUnRegist(hSwdFeedDog);

    return MOS_OK;
}

_INT CloudStg_RandomUuid(_UC ucBuf[37])
{
    const _UC *c = "89ab";
    _UC *p = ucBuf;
    int n;
    srand((unsigned)time(NULL));
    for( n = 0; n < 16; ++n )
    {
        int b = rand()%255;
        switch( n )
        {
            case 6:
                sprintf(
                    p,
                    "4%x",
                    b%15 );
                break;
            case 8:
                sprintf(
                    p,
                    "%c%x",
                    c[rand()%strlen( c )],
                    b%15 );
                break;
            default:
                sprintf(
                    p,
                    "%02x",
                    b );
                break;
        }
        p += 2;
        // switch( n )
        // {
        //     case 3:
        //     case 5:
        //     case 7:
        //     case 9:
        //         *p++ = '-';
        //         break;
        // }
    }
    *p = 0;
    return MOS_OK;
}

_UC *CloudStg_AesBase64Enc(_UC *pucInput)
{
    _UC *pucOutput = MOS_NULL;
    _UC *ucEncrypttext = MOS_NULL;
    _INT Len = 0;

    Len = strlen(pucInput);
    //ucEncrypttext = kj_aes_encrypt_cbc(pucInput, &Len,  MOS_NULL, CLOUDSTG_UPLOADLOG_AES_KEY, CLOUDSTG_UPLOADLOG_AES_IV, KJ_AES_ZeroPadding, KJ_AES_128);
    ucEncrypttext = Adpt_Aes_Encrypt_Ex(pucInput, Len, CLOUDSTG_UPLOADLOG_AES_KEY, CLOUDSTG_UPLOADLOG_AES_IV, &Len, ADPT_AES_ZERO_PADDING);
    pucOutput = (_UC*)MOS_MALLOCCLR((int)((float)Len*(4/3.0)) + 8);
    Adpt_Base64_Enc(ucEncrypttext, Len, pucOutput);

    MOS_FREE(ucEncrypttext);
    return pucOutput;
}

int CloudStg_URLEncode(const char* str, const int strSize, char* result, const int resultSize)
{
    int i;
    int j = 0;//for result index
    char ch;

    if ((str==NULL) || (result==NULL) || (strSize<=0) || (resultSize<=0)) {
        return 0;
    }

    for ( i=0; (i<strSize)&&(j<resultSize); ++i) {
        ch = str[i];
        if (((ch>='A') && (ch<'Z')) ||
            ((ch>='a') && (ch<'z')) ||
            ((ch>='0') && (ch<'9'))) {
                result[j++] = ch;
        } else if (ch == ' ') {
            result[j++] = '+';
        } else if (ch == '.' || ch == '-' || ch == '_' || ch == '*') {
            result[j++] = ch;
        } else {
            if (j+3 < resultSize) {
                sprintf(result+j, "%%%02X", (unsigned char)ch);
                j += 3;
            } else {
                return 0;
            }
        }
    }

    result[j] = '\0';
    return j;
}


_INT Cloudstg_GetTimeMixUuid(_UC *ucString, _INT iSize)
{
    MOS_PARAM_NULL_RETERR(ucString);

    _CTIME_T cTime = Mos_Time();
    _UC aucRandom[4] = {0};

    Adapt_GenerateString(aucRandom, 4);
    MOS_MEMSET(ucString, 0, iSize);
    MOS_SPRINTF(ucString, "%u%s", cTime, aucRandom);

    return MOS_OK;
}

_INT Cloudstg_CloseAllNormalAliveTask()
{
    _CTIME_T tFailTime = Mos_Time();
    _CTIME_T tDuration = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode   = MOS_NULL;
    
    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList , pstTaskNode, stIterator)
    {
        if(pstTaskNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
        {
            CloudStg_DestroyAliveNode(pstTaskNode);
            if (tFailTime > pstTaskNode->tCreateTime)
            {
                tDuration = tFailTime - pstTaskNode->tCreateTime;
                MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->tCreateTime,tFailTime,tFailTime-pstTaskNode->tCreateTime,pstTaskNode->iCloudUpLoadMode);
                CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                    pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tCreateTime, tFailTime);
            }
        }

        MOS_LIST_RMVNODE(&CloudStg_GetMng()->stTaskList,pstTaskNode);
        Mos_MemFree(pstTaskNode);
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    return MOS_OK;
}


_INT Cloudstg_CloseAllPatchAliveTask()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode   = MOS_NULL;

    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList , pstTaskNode, stIterator)
    {
        CloudStg_Patch_RemoveItemFromTaskList(pstTaskNode);
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    return MOS_OK;
}

_INT Cloudstg_UploadLog_Error(_UC *pucModuleName, _UC *pucFunction, _UC *pucUrl, _INT iRt, _INT enType)
{
    _UC pucMsg[128] = {0};
    switch (enType)
    {
        case EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME:
        {
            MOS_VSNPRINTF(pucMsg, sizeof(pucMsg), "%s %s GetHostByName error", pucModuleName, pucFunction);
        }   
        break;
        case EN_CLOUDSTG_LOG_ERROR_TYPE_JSON_PARSE:
        {
            MOS_VSNPRINTF(pucMsg, sizeof(pucMsg), "%s %s json parse fail", pucModuleName, pucFunction);
        }
        break;
        case EN_CLOUDSTG_LOG_ERROR_TYPE_JSON_PARA:
        {
            MOS_VSNPRINTF(pucMsg, sizeof(pucMsg), "%s %s json parameter error", pucModuleName, pucFunction);
        }
        break;
        default:
        break;
    }
    return CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iRt, pucMsg, 1);
}

_UC *Cloudstg_EventInfUploadJsonify()
{
    _UC *pstrTmp = MOS_NULL;
    _INT i = 0;
    _CTIME_T cNowTime = Mos_Time();
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"start_timestamp", Adpt_Json_CreateStrWithNum(CloudStg_GetMng()->stCloudEventUploadInf.cStarTime));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"end_timestamp", Adpt_Json_CreateStrWithNum(CloudStg_GetMng()->stCloudEventUploadInf.cUploadTime));

    JSON_HANDLE hEventCloudUpload = Adpt_Json_CreateObject();
    JSON_HANDLE hEventCloudUploadArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hEventCloudUpload, (_UC*)"count", Adpt_Json_CreateStrWithNum(CloudStg_GetMng()->stCloudEventUploadInf.uiUploadNum));
    for (i = 0; i < CloudStg_GetMng()->stCloudEventUploadInf.uiUploadNum; i++)
    {
        Adpt_Json_AddItemToArray(hEventCloudUploadArray, Adpt_Json_CreateStrWithNum(CloudStg_GetMng()->stCloudEventUploadInf.ausUploadOffset[i]));
    }
    Adpt_Json_AddItemToObject(hEventCloudUpload, (_UC*)"offset", hEventCloudUploadArray);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"event_cloud_upload", hEventCloudUpload);

    JSON_HANDLE hEventCloudSuccessUpload = Adpt_Json_CreateObject();
    JSON_HANDLE hEventCloudSuccessUploadArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hEventCloudSuccessUpload, (_UC*)"count", Adpt_Json_CreateStrWithNum(CloudStg_GetMng()->stCloudEventUploadInf.uiSuccessUploadNum));
    for (i = 0; i < CloudStg_GetMng()->stCloudEventUploadInf.uiSuccessUploadNum; i++)
    {
        Adpt_Json_AddItemToArray(hEventCloudSuccessUploadArray, Adpt_Json_CreateStrWithNum(CloudStg_GetMng()->stCloudEventUploadInf.ausSuccessUploadOffset[i]));
    }
    Adpt_Json_AddItemToObject(hEventCloudSuccessUpload, (_UC*)"offset", hEventCloudSuccessUploadArray);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"event_cloud_success_upload", hEventCloudSuccessUpload);

    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pstrTmp;
}

_VOID Cloudstg_EventInfUploadInit()
{
    _CTIME_T cNowTime = Mos_Time();
    MOS_MEMSET(&CloudStg_GetMng()->stCloudEventUploadInf, 0x00, sizeof(CloudStg_GetMng()->stCloudEventUploadInf));
    CloudStg_GetMng()->stCloudEventUploadInf.cStarTime   = cNowTime;
    CloudStg_GetMng()->stCloudEventUploadInf.cUploadTime = cNowTime + Config_GetDeviceMng()->uiCloudLogInterval * 60;
    MOS_LOG_WARN(CLOUDSTG_LOGSTR, "cStarTime: %u, cUploadTime: %u", CloudStg_GetMng()->stCloudEventUploadInf.cStarTime, CloudStg_GetMng()->stCloudEventUploadInf.cUploadTime);
}

_VOID Cloudstg_IncEventCloudUpload(_CTIME_T cNowTime)
{
    // 事件云存监控为关闭状态或云存不为事件套餐
    if (Config_GetDeviceMng()->uiCloudLogStatus == 0 || Config_GetCloudMng()->iCloudUpLoadMode != 1)
    {
        return;
    }
    CloudStg_GetMng()->stCloudEventUploadInf.ausUploadOffset[CloudStg_GetMng()->stCloudEventUploadInf.uiUploadNum] = cNowTime - CloudStg_GetMng()->stCloudEventUploadInf.cStarTime;
    CloudStg_GetMng()->stCloudEventUploadInf.uiUploadNum++;
    MOS_LOG_WARN(CLOUDSTG_LOGSTR, "num: %d", CloudStg_GetMng()->stCloudEventUploadInf.uiUploadNum);
}

_VOID Cloudstg_IncEventCloudSuccessUpload()
{
    _CTIME_T cNowTime = 0;

    // 事件云存监控为关闭状态或云存不为事件套餐
    if (Config_GetDeviceMng()->uiCloudLogStatus == 0 || Config_GetCloudMng()->iCloudUpLoadMode != 1)
    {
        return;
    }
    cNowTime = Mos_Time();
    CloudStg_GetMng()->stCloudEventUploadInf.ausSuccessUploadOffset[CloudStg_GetMng()->stCloudEventUploadInf.uiSuccessUploadNum] = cNowTime - CloudStg_GetMng()->stCloudEventUploadInf.cStarTime;
    CloudStg_GetMng()->stCloudEventUploadInf.uiSuccessUploadNum++;
    MOS_LOG_WARN(CLOUDSTG_LOGSTR, "num: %d", CloudStg_GetMng()->stCloudEventUploadInf.uiSuccessUploadNum);
}

_VOID CloudstgEventInfUploadProc(_CTIME_T cNowTime)
{
    _UC *pstrTmp = MOS_NULL;
    
    // 事件云存监控为关闭状态或云存不为事件套餐
    if (Config_GetDeviceMng()->uiCloudLogStatus == 0 || Config_GetCloudMng()->iCloudUpLoadMode != 1)
    {
        // printf("switch: %d, interval: %d\r\n", Config_GetDeviceMng()->uiCloudLogStatus, Config_GetDeviceMng()->uiCloudLogInterval);
        return;
    }

    // 事件云存配置初始化
    if (CloudStg_GetMng()->uiCloudEventUploadInfInitFlag == 0)
    {
        Cloudstg_EventInfUploadInit();
        CloudStg_GetMng()->uiCloudEventUploadInfInitFlag = 1;
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud event upload inf init...");
    }

    // 开始上传
    if (cNowTime >= CloudStg_GetMng()->stCloudEventUploadInf.cUploadTime)
    {
        // json化
        pstrTmp = Cloudstg_EventInfUploadJsonify();

        // 上报事件云存埋点
        // TEST:
        MOS_PRINTF("pstrTmp: %s\r\n", pstrTmp);
        CloudStg_UploadLogEx(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_EVENT_CLOUD_INF_UPLOAD, "CD event cloud inf upload", pstrTmp, 0);

        // 初始化
        Cloudstg_EventInfUploadInit();
        CloudStg_GetMng()->uiCloudEventUploadInfInitFlag = 1;
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud event upload inf init...");
        MOS_FREE(pstrTmp);
    }
}

_VOID CloudstgSetCloudEventUploadInitFlag(_UI uiInitFlag)
{
    CloudStg_GetMng()->uiCloudEventUploadInfInitFlag = uiInitFlag;
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud event upload inf deinit...");
}

_VOID CloudStg_SetStartNextEventCloudFlag(_UI uiFlag)
{
    CloudStg_GetMng()->uiStartNextEventCloudFlag = uiFlag;
}

_VOID CloudStg_EventCloudAppendHandler(ST_CLOUDSTG_TASK_NODE *pstTmpNode)
{
    _UI uiDetectStartStamp = 0;
    _UI uiDetectEndStamp   = 0;
    _UI uiTotalStampTmp    = 0;
    _UI uiNowTimeStamp     = 0;

    // 事件云存追加
    if (pstTmpNode && (pstTmpNode->stEventCloud.iSwitch == 1))
    {
        uiDetectStartStamp = pstTmpNode->uiTotalStamp - (pstTmpNode->stEventCloud.iDetectTime * 1000); // 开始检测时间
        uiDetectEndStamp   = pstTmpNode->uiTotalStamp; // 结束检测时间
        uiNowTimeStamp     = pstTmpNode->uiAllStamp; // 当前时间
        
        // 符合检测区间
        if ((uiDetectStartStamp <= uiNowTimeStamp) && (uiNowTimeStamp < uiDetectEndStamp))
        {
            // 计算追加后总时长
            uiTotalStampTmp = pstTmpNode->uiTotalStamp + (pstTmpNode->stEventCloud.iAppendTime * 1000);
            if (uiTotalStampTmp <= pstTmpNode->stEventCloud.iMaxTime * 1000)
            {
                // 追加后小于最大时长，允许追加
                pstTmpNode->uiTotalStamp = uiTotalStampTmp;
                pstTmpNode->uiDuration += pstTmpNode->stEventCloud.iAppendTime;
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "[taskid: %u]Event cloud appends %us, total: %us", pstTmpNode->uiTaskId, pstTmpNode->stEventCloud.iAppendTime, (uiTotalStampTmp/1000));
            }
            else
            {
                // 追加后大于最大时长，在当前任务结束后，立即创建下一个任务
                CloudStg_SetStartNextEventCloudFlag(MOS_TRUE);
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "[taskid: %u]Event cloud reaches max time %us, auto start next event cloud!", pstTmpNode->uiTaskId, pstTmpNode->stEventCloud.iMaxTime);
            }
        }
    }
}