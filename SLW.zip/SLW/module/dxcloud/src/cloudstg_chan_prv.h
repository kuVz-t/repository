#ifndef _MECS_TRANS_PRV_H_
#define _MECS_TRANS_PRV_H_

#ifdef __cplusplus
extern "C"
{
#endif
#include "cloudstg_stream.h"
#define MECS_TASK_MAX_EMPTY_BUF_UNIT 1408
#define MECS_TASK_MAX_SEND_DELAY     3600
#define MECS_BASIC_TASK_ID           10000
#define MECS_NEED_DELAY(ErrCode) ((EN_HTTP_STATUS_TIMEOUT == ErrCode) || (EN_HTTP_STATUS_CONTIMEOUT == ErrCode) || (EN_HTTP_STATUS_CONERR == ErrCode) || (EN_HTTP_STATUS_ERRCODE == ErrCode) || (EN_HTTP_STATUS_SOCKETERR == ErrCode))
#define MECS_MAX_TRY_NUM             10
#define MECS_MAX_HTTP_RECV_LEN       80

#define CLOUDSTG_BUF_UNIT_SIZE     1408
#define CLOUDSTG_BUF_MID_SIZE     (1200 * CLOUDSTG_BUF_UNIT_SIZE)
#define CLOUDSTG_BUF_MAX_SIZE     (2400 * CLOUDSTG_BUF_UNIT_SIZE)
#define CLOUDSTG_BUF_SPEED_DETECT_TIMEOUT 5

typedef enum enum_MECS_EXTTASK_STATUS
{
    EN_MECS_EXTTASK_INIT,
    EN_MECS_EXTTASK_PROC,
    EN_MECS_EXTTASK_FINISH,
    EN_MECS_EXTTASK_CLOSE
}EN_MECS_EXTTASK_STATUS;

typedef struct stru_CLOUDSTG_SLICE_INFO
{
    _VPTR ptJson;
    _CTIME_T cEndTime;
}ST_CLOUDSTG_SLICE_INFO;

typedef struct stru_MECS_BUF_NODE
{
    EN_CLOUDSTG_TRANS_BUF_TYPE     enType;
    _HANDLE                    hTask;
    _UI                        uiSendLen;
    _UI                        uiLen;
    _UI                        uiAddChunkFlag;
    _UC                        ucOffSet;
    _UC                       *pucBuf;
    _UI                        uiTimeStamp;
    _CTIME_T                   cTime;
    _UI                        uiIsIdrFlag;
    ST_MOS_LIST_NODE           stNode;
}ST_CLOUDSTG_BUF_NODE;

typedef struct stru_MECS_TASK_INF
{
    _INT                iFailFlag;
    _INT                iCamId;
    _UI                 uiType;
    _UI                 uiFileSize;
    _BOOL               bStart;
    _UI                 uiSliceNum;
    _UI                 uiSliceId;
    _HCSCONN            hCSConn;
    _UI                 uiTaskID;
    _UI                 uiExUploadStatus;
    _UI                 uiExUploadLen;

    _INT                iExUploadUsed;          // 端切片task状态 0：未使用 1：已使用
    _HSTREAM            hParentStream;
    _INT                iIndex;                 // 端切片chan task组的index
    _INT                iExUploadSum;           // 端切片chan 一个切片的sum
    _INT                iExUploadOverFlag;      // 端切片发送结束的flag
    _INT                iDirectMode;            // 发送模式
    _CTIME_T            tStartTime;             // task开始时间, 用于计算端切片丢GOP的时间段
    _UI                 uiSleeptime;
    _UI                 uiSentLen;
    _UI                 uiLastPacketSendTimes;
    _UI                 uiAllStamp;
    _UI                 uiLastStamp;
    _CTIME_T            uiNeedSentLen;
    _CTIME_T            tFailTime;
    _CTIME_T            tFailCount;
    _CTIME_T            cForceStopTime;
    _UI                 uiWaitSendLen;
    _UC                 *pucWaitSendBuf;
    _HMEMOWNER          hMem;
    _BOOL               bSendOver;
    PFUN_SLICECALLBACK  pFunSliceSend;
    _VPTR               ptUseHandle;
    _HMUTEX             hBufMutex;
    _HMUTEX             hMutex;
    _UI                 uiSliceAddSize;
    _INT                iAliveTaskId;
    _UI                 uiIsPatch;
    _UI                 uiPosition;
    ST_MOS_LIST_NODE    *pstCurBufNode;
    ST_MOS_LIST_NODE    *pstHeadBufNode;
    ST_MOS_LIST_NODE    *pstTailBufNode;
    ST_MOS_LIST         stBufferList;
    ST_MOS_LIST_NODE    stNode;
}ST_CLOUDSTG_TASK_INF;

typedef struct stru_MECS_BUF_TASK
{
    _UC                      *pucbuf;
    _UI                      uiIcon;//1为icon     0为正常
    _UI                      uiLen;
    _UI                      uiOffsetLen;
    _UI                      uiBuffLen;
    _UI                      uiStatus; //
    _UI                      uiSendTotalLen;
    _UI                      uiFileTotalLen; //  文件总长度
    _UI                      uiType;         // 2 图片 3 日志文件上传 4 日志上报
    _UI                      uiSendtimes;
    _CTIME_T                 cSendTime;
    _CTIME_T                 cCreateTime;
    _CTIME_T                 cStartTime;
    _CTIME_T                 cConnectTime;
    _UI                      uiTargetSize;
    _UC                      aucFileName[256]; //  文件名字
    _UC                      aucFid[128];
    _UC                      aucETag[128];
    _UC                      aucBucket[128];
    _UC                      aucStorageProvider[16];
    _UI                      uiUsedFlag;
    _INT                     iAliveTaskId;
    _INT                     iDirectMode;
    PFUN_FINISHED            pfuncFinished;

    /* log */
    _UC                      *pucUrl;
    _UC                      *pucMsg;
    _UC                      *pucEt;
    _INT                     iHostStatus;
    _INT                     iRt;

    _VPTR                    vpBase;//回掉 的 handle
    _HFILE                   hFile;
    _HCSCONN                 hCsConn;             
    ST_MOS_LIST_NODE         stNode;
}ST_MECS_EXT_TASK;

typedef struct stru_MECS_TRANS_MGR
{
    _BOOL           bRun;
    _UC             aucDid[CFG_STRING_COMMONLEN+4];
    _UI             uiSentPacks;
    _HTHREAD        hThread;
    _HTHREAD        hExtThread;
    _HMEMOWNER      hMem;
    _HMUTEX         hTaskMutex;
    _HMUTEX         hExtUriMutex;
    ST_MOS_LIST     stTaskList;
    ST_MOS_LIST     stExtUriList;
    _UI             uiHttpResponseIndex;
    _UC*            pucHttpResponse;
}ST_CLOUDSTG_TRANS_MGR;

// 云存上传主程序
_INT   CloudStg_TransProc(_VPTR pParam);

// 云存EXT上传主程序 PS：EXT包括本地图片、实时图片、本地LOG、实时LOG
_INT CloudStg_TransExtProc(_VPTR pParam);

// 云存chan任务关闭
_VOID CloudStg_TransTaskClose(ST_CLOUDSTG_TASK_INF *pstTask);

// 云存上传任务主程序(多线程调用)
_INT CloudStg_TransTaskProc(ST_CLOUDSTG_TASK_INF *pstTask,_CTIME_T ctime, _UI uiIsPatch);

// 端切片云存上传任务主程序(多线程调用)
_INT CloudStg_TransTaskProcEx(ST_CLOUDSTG_TASK_INF *pstTask,_CTIME_T ctime, _UI uiIsPatch, _INT iNetCheckFlag);

// 云存EXT上传任务主程序
_INT CloudStg_TransExtTaskProc(ST_MECS_EXT_TASK *pstExtTask);

// 云存任务发送Buf
_INT CloudStg_TransTaskSendBuf(ST_CLOUDSTG_TASK_INF *pstTask, ST_CLOUDSTG_BUF_NODE *pstBuf);

// 云存chan清除buflist
_VOID  CloudStg_TransTaskClearBufList( ST_MOS_LIST *pstBufList, ST_CLOUDSTG_BUF_NODE *pstClearEndNode);

// 云存任务清除BufList
_VOID  CloudStg_TransTaskClearBufList( ST_MOS_LIST *pstBufList, ST_CLOUDSTG_BUF_NODE *pstClearEndNode);

// 刷新已发送的时间戳
_INT CloudStg_TransAllStampRefresh(_HCSTASK hCSTask, _UI uiTimeStamp);
#ifdef __cplusplus
}
#endif 

#endif 
