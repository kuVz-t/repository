#include "mos.h"
#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_crypto_adapt.h"
#include "config_api.h"
#include "record_api.h"
#include "http_api.h"
#include "media_cache_api.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_logger.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_manage.h"
#include "cloudstg_aliveupload.h"
#include "cloudstg_transaddress.h"
#include "cloudstg_event.h"
#include "cloudstg_patch.h"
#include "cloudstg_stream_prv.h"
#include "watchdog_api.h"
#include "config_api.h"

#define DEBUG 0

static _UC *g_aucLoggerQueueName[CLOUDSTG_LOGGER_QUEUE_NUM]    = {"Important", "Error", "Core", "Normal"};  // 队列：重要、错误、核心、普通
static _UC g_ucLoggerQueueMaxCount[CLOUDSTG_LOGGER_QUEUE_NUM]  = {5, 15, 15, 10};                           // 队列缓存数量
static _UC g_ucLoggerQueueThreshold[CLOUDSTG_LOGGER_QUEUE_NUM] = {1, 10, 10, 10};                           // 队列发送数量阈值
static _UI g_uiLoggerQueueTimeout[CLOUDSTG_LOGGER_QUEUE_NUM]   = {0, 600, 300, 600};                        // 队列发送时间(秒)阈值

ST_CLOUDSTG_LOGGER_MANAGE stCloudstgLoggerManage = {0};
ST_CLOUDSTG_LOGGER_MANAGE *CloudStg_LoggerGetMng()
{
    return &stCloudstgLoggerManage;
}

_INT CloudStg_LoggerInit()
{
    _INT iLoggerIndex = 0;
    if (CloudStg_LoggerGetMng()->ucInitFlag) 
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Already Init");
        return MOS_ERR;
    }

    MOS_MEMSET(&stCloudstgLoggerManage, 0, sizeof(stCloudstgLoggerManage));
    for (iLoggerIndex = 0; iLoggerIndex < CLOUDSTG_LOGGER_QUEUE_NUM; iLoggerIndex++)
    {
        MOS_LIST_INIT(&CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex]);
        Mos_MutexCreate(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
    }
    
    CloudStg_LoggerGetMng()->uiLogNum   = 0;
    CloudStg_LoggerGetMng()->ucInitFlag = 1;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud logger init ok");
    return MOS_OK;
}

_INT CloudStg_LoggerStart()
{
#if SINGLE_THREAD
    _INT iRet = 0;
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    iRet = Mos_ThreadCreate((_UC*)"CloudLogger",  EN_THREAD_PRIORITY_NORMAL, uiStackSize,  
            CloudStg_LoggerProc, MOS_NULL, MOS_NULL, &CloudStg_LoggerGetMng()->hMgrThread);
    if(iRet == MOS_ERR)
    {
        CloudStg_LoggerGetMng()->ucRunFlag = 0;
        Mos_ThreadDelete(CloudStg_LoggerGetMng()->hMgrThread);
        return MOS_ERR;
    }
#endif
    CloudStg_LoggerGetMng()->ucRunFlag = 1;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud logger start ok");
    return MOS_OK;
}

_INT CloudStg_LoggerStop()
{
    if(CloudStg_LoggerGetMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Already Stop");
        return MOS_ERR;
    }
    CloudStg_LoggerGetMng()->ucRunFlag = 0;
#if SINGLE_THREAD
    Mos_ThreadDelete(CloudStg_LoggerGetMng()->hMgrThread);
#endif
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud logger stop ok");
    return MOS_OK;
}

_INT CloudStg_LoggerDestroy()
{
    _INT iLoggerIndex = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_LOGGER_NODE *pstLoggerNode = MOS_NULL;

    if(CloudStg_LoggerGetMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Already Destroy");
        return MOS_ERR;
    }
    
    for (iLoggerIndex = 0; iLoggerIndex < CLOUDSTG_LOGGER_QUEUE_NUM; iLoggerIndex++)
    {
        Mos_MutexLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
        FOR_EACHDATA_INLIST(&CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex], pstLoggerNode, stIterator)
        {
            CloudStg_LoggerDeleteNode(&CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex], pstLoggerNode);
        }
        Mos_MutexUnLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
        Mos_MutexDelete(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
    }
    CloudStg_LoggerGetMng()->ucInitFlag = 0;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud logger destory ok");
    return MOS_OK;
}

#if SINGLE_THREAD
_INT CloudStg_LoggerProc()
#else
_INT CloudStg_LoggerProc(_CTIME_T cNowTime)
#endif
{
    _UC         aucBuf[64]   ={0};
    _INT        iLoggerCount = 0;
    static _INT iLoggerIndex = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_LOGGER_NODE *pstLoggerNode = MOS_NULL;
#if SINGLE_THREAD
    _UI        uiSleep      = 0;
    _CTIME_T   cNowTime     = 0;
    _CTIME_T   cOldTimeSwd  = 0;
    _HSWDWRITE hSwdFeedDog  = MOS_NULL;
#endif

#if SINGLE_THREAD
    hSwdFeedDog = Swd_AppThreadRegist(CLOUDSTG_LOGGER_APP, FEED_DOG_SUPER_MAX_TIMESEC);
    while (CloudStg_LoggerGetMng()->ucRunFlag == 1)
    {
        if(uiSleep++ % 8 == 0)
        {
            cNowTime = Mos_Time();
        }
        if (MOS_ABS_NUM(cNowTime - cOldTimeSwd) >= 1)
        {
            cOldTimeSwd = cNowTime;
            Swd_AppThreadFeedDog(hSwdFeedDog);
        }
#endif
        iLoggerIndex = ++iLoggerIndex % CLOUDSTG_LOGGER_QUEUE_NUM;
        if (CloudStg_LoggerGetMng()->ucDropNumSendFlag == 0 && CloudStg_LoggerGetMng()->uiDropNum != 0 && cNowTime >= CloudStg_LoggerGetMng()->tDropNumSendTime)
        {
            MOS_VSNPRINTF(aucBuf, sizeof(aucBuf), "CD logger drop num %d", CloudStg_LoggerGetMng()->uiDropNum);
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_LOGGER_DROP_NUM, aucBuf, EN_CLOUDSTG_LOGGER_LEVEL_IMPORTANT);
            CloudStg_LoggerGetMng()->ucDropNumSendFlag = 1;
        }

        iLoggerCount = CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex].uiTotalCount;

        // 到达阈值
        if (iLoggerCount >= g_ucLoggerQueueThreshold[iLoggerIndex]
         || (CloudStg_LoggerGetMng()->tSendTime[iLoggerIndex] != 0 && cNowTime >= CloudStg_LoggerGetMng()->tSendTime[iLoggerIndex]))
        {
            // 发送
            MOS_LOG_INF(CLOUDSTG_LOGSTR, "ready to send %s queue log, reach threshold num (%d >= %d) or sendtime (%u >= %u)", g_aucLoggerQueueName[iLoggerIndex], iLoggerCount, g_ucLoggerQueueThreshold[iLoggerIndex], cNowTime, CloudStg_LoggerGetMng()->tSendTime[iLoggerIndex]);
            CloudStg_LoggerSend(iLoggerIndex);
        }
#if SINGLE_THREA
        Mos_Sleep(100);
    }

    Swd_AppThreadUnRegist(hSwdFeedDog);
#endif
    return MOS_OK;
}

_INT CloudStg_LoggerPushLog(_UI uiReqId, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC *pucEt, _INT iLevel)
{
    MOS_PARAM_NULL_RETERR(pucUrl);
    MOS_PARAM_NULL_RETERR(pucMsg);
    if (iLevel >= CLOUDSTG_LOGGER_QUEUE_NUM)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"input iLevel: %d is error", iLevel);
        return MOS_ERR;
    }

    _INT iLoggerCount = 0;
    _INT iLoggerIndex = iLevel;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_LOGGER_NODE *stLoggerNode     = MOS_NULL;
    ST_CLOUDSTG_LOGGER_NODE *stLoggerNodeTmp  = MOS_NULL;

    if (!CloudStg_LoggerGetMng()->ucRunFlag)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"CloudStg service is unavailable. %d", CloudStg_LoggerGetMng()->ucRunFlag);
        return MOS_FALSE;
    }

    // FIXME:
    if ((Config_GetSystemMng()->iCloudUploadLogLe==0?2:Config_GetSystemMng()->iCloudUploadLogLe) < iLevel)
    {
        return MOS_FALSE;
    }

    // 去重
    Mos_MutexLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
    if (CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex].uiTotalCount != 0)
    {
        stLoggerNodeTmp = (ST_CLOUDSTG_LOGGER_NODE *)(CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex].pstTail->ptrData);
        if (MOS_STRCMP(stLoggerNodeTmp->pucMsg, pucMsg) == 0)
        {
            Mos_MutexUnLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
            stLoggerNodeTmp->uiRepeatCount++;
            return MOS_OK;
        }
    }
    stLoggerNode = (ST_CLOUDSTG_LOGGER_NODE *)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_LOGGER_NODE));
    iLoggerCount = CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex].uiTotalCount;
    if (iLoggerCount >= g_ucLoggerQueueMaxCount[iLoggerIndex])
    {
        CloudStg_LoggerAddDropNum(1, 0);
        stLoggerNodeTmp = (ST_CLOUDSTG_LOGGER_NODE *)CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex].pstHead->ptrData;
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"%s queue is full, drop num: %d, now delete one log pucUrl %s, pucMsg %s", 
                    g_aucLoggerQueueName[iLoggerIndex], 
                    CloudStg_LoggerGetMng()->uiDropNum,
                    stLoggerNodeTmp->pucUrl, 
                    stLoggerNodeTmp->pucMsg);
        CloudStg_LoggerDeleteNode(&CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex], stLoggerNodeTmp);
    }
    MOS_LIST_ADDTAIL(&CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex], stLoggerNode);
    if (CloudStg_LoggerGetMng()->tSendTime[iLoggerIndex] == 0)
    {
        CloudStg_LoggerGetMng()->tSendTime[iLoggerIndex] = Mos_Time() + g_uiLoggerQueueTimeout[iLoggerIndex];
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "now time: %u, queue %s next send time is %u", Mos_Time(), g_aucLoggerQueueName[iLoggerIndex], CloudStg_LoggerGetMng()->tSendTime[iLoggerIndex]);
    }
    stLoggerNode->uiNodeId      = uiReqId;
    stLoggerNode->uiRepeatCount = 1;
    stLoggerNode->tCreateTime   = Mos_Time();
    if (MOS_STRLEN(pucUrl) >= CLOUDSTG_LOGGER_URL_MAX_LEN)
    {
        stLoggerNode->pucUrl = MOS_MALLOCCLR(CLOUDSTG_LOGGER_URL_MAX_LEN);
        MOS_VSNPRINTF(stLoggerNode->pucUrl, CLOUDSTG_LOGGER_URL_MAX_LEN, "%s", pucUrl);
    }
    else
    {
        stLoggerNode->pucUrl = MOS_STRCPYALLOC(pucUrl);
    }
    if (MOS_STRLEN(pucMsg) >= CLOUDSTG_LOOGER_MSG_MAX_LEN - CLOUDSTG_LOGGER_REPEAT_STR_RESERVE_BYTE)
    {
        stLoggerNode->pucMsg = MOS_MALLOCCLR(CLOUDSTG_LOOGER_MSG_MAX_LEN);
        MOS_VSNPRINTF(stLoggerNode->pucMsg, CLOUDSTG_LOOGER_MSG_MAX_LEN - CLOUDSTG_LOGGER_REPEAT_STR_RESERVE_BYTE, "%s", pucMsg);
    }
    else
    {
        stLoggerNode->pucMsg = MOS_MALLOCCLR(MOS_STRLEN(pucMsg) + CLOUDSTG_LOGGER_REPEAT_STR_RESERVE_BYTE);
        MOS_STRCPY(stLoggerNode->pucMsg, pucMsg);
    }
    if (MOS_STRLEN(pucEt) >= CLOUDSTG_LOOGER_EXTRA_DATA_MAX_LEN)
    {
        stLoggerNode->pucEt = MOS_MALLOCCLR(CLOUDSTG_LOOGER_EXTRA_DATA_MAX_LEN);
        MOS_VSNPRINTF(stLoggerNode->pucEt, CLOUDSTG_LOOGER_EXTRA_DATA_MAX_LEN, "%s", pucEt);
    }
    else
    {
        stLoggerNode->pucEt = MOS_STRCPYALLOC(pucEt);
    }
    stLoggerNode->iHostStatus   = iHostStatus;
    stLoggerNode->iRt           = iRt;
    stLoggerNode->iLevel        = iLevel;

    Mos_MutexUnLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);

    return MOS_OK;
}

_INT CloudStg_LoggerSend(_INT iLoggerIndex)
{
    _INT iRet        = 0;
    _INT iTaskCount  = 0;
    _INT iCount = 0;
    _UC  aucTmp[8]   = {0};
    _UC *pucParams   = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_LOGGER_NODE *stLoggerNode = MOS_NULL;
    JSON_HANDLE hRootArray = Adpt_Json_CreateArray();

    // 遍历当前所有的LOG任务，JSON化后合并一起发送
#if DEBUG
    MOS_PRINTF("=================begining upload these msg==================\r\n");
#endif
    Mos_MutexLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
    FOR_EACHDATA_INLIST(&CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex], stLoggerNode, stIterator)
    {
        // 在msg后追加重复的次数
        if (stLoggerNode->uiRepeatCount > 1)
        {
            MOS_VSNPRINTF(aucTmp, sizeof(aucTmp), " x%d", stLoggerNode->uiRepeatCount);
            MOS_STRCAT(stLoggerNode->pucMsg, aucTmp);
            stLoggerNode->uiRepeatCount = 1;
        }
        
        // 合并不能超过指定数量的log或读到链表尾部
        if (++iTaskCount >= g_ucLoggerQueueThreshold[iLoggerIndex] || stIterator.pstNext == MOS_NULL)
        {
            pucParams = CloudStg_BuildUploadLogJson(&hRootArray, stLoggerNode->pucUrl, 
                stLoggerNode->iHostStatus, stLoggerNode->iRt, stLoggerNode->pucMsg, stLoggerNode->pucEt, stLoggerNode->tCreateTime, iTaskCount, 1);
            stLoggerNode->uiUsed = 1;
            // MOS_PRINTF("iTaskCount: %d, g_ucLoggerQueueThreshold[iLoggerIndex]: %d, stIterator.pstNext: %p\r\n", iTaskCount, g_ucLoggerQueueThreshold[iLoggerIndex], stIterator.pstNext);
            break;
        }
        else
        {
            CloudStg_BuildUploadLogJson(&hRootArray, stLoggerNode->pucUrl, 
                stLoggerNode->iHostStatus, stLoggerNode->iRt, stLoggerNode->pucMsg, stLoggerNode->pucEt, stLoggerNode->tCreateTime, iTaskCount, 0);
            stLoggerNode->uiUsed = 1;
        }
#if DEBUG
	    MOS_PRINTF("(%d) %s\r\n", iTaskCount, stLoggerNode->pucMsg);
#endif
    }
    Mos_MutexUnLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
#if DEBUG
    MOS_PRINTF("============================================================\r\n");
#endif

    // 发送
    // 重要队列失败可重试2次
    do 
    {
        iCount++;
        iRet = CloudStg_HttpUploadLog(pucParams);
        if (iRet == MOS_OK)
        {
            break;
        }
        else
        {
            Mos_Sleep(50);
        }
    }
    while((iLoggerIndex == EN_CLOUDSTG_LOGGER_LEVEL_IMPORTANT) && (iCount < 3));
    if (iRet == MOS_ERR)
    {
        CloudStg_LoggerAddDropNum(iTaskCount, 1);
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "logger upload request timeout, drop num: %d", CloudStg_LoggerGetMng()->uiDropNum);
    }
    else
    {
        // 检测到drop num日志发送成功
        if (iLoggerIndex == EN_CLOUDSTG_LOGGER_LEVEL_IMPORTANT && CloudStg_LoggerGetMng()->ucDropNumSendFlag == 1)
        {
            CloudStg_LoggerGetMng()->uiDropNum         = 0;
            CloudStg_LoggerGetMng()->tDropNumSendTime  = 0;
            CloudStg_LoggerGetMng()->ucDropNumSendFlag = 0;
        }
    }
    Mos_MutexLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);
    CloudStg_LoggerGetMng()->tSendTime[iLoggerIndex] = 0;
    FOR_EACHDATA_INLIST(&CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex], stLoggerNode, stIterator)
    {
        if (stLoggerNode->uiUsed == 1) 
        {
            CloudStg_LoggerDeleteNode(&CloudStg_LoggerGetMng()->stLoggerList[iLoggerIndex], stLoggerNode);
        }
    }
    Mos_MutexUnLock(&CloudStg_LoggerGetMng()->hMutex[iLoggerIndex]);

    Adpt_Json_Delete(hRootArray);
    if (pucParams)
    {
        MOS_FREE(pucParams);
    }
    return iRet;
}

_INT CloudStg_LoggerDeleteNode(ST_MOS_LIST *stLoggerList, ST_CLOUDSTG_LOGGER_NODE *stLoggerNode)
{
    MOS_PARAM_NULL_RETERR(stLoggerList);
    MOS_PARAM_NULL_RETERR(stLoggerNode);

    MOS_LIST_RMVNODE(stLoggerList, stLoggerNode);
    if (stLoggerNode)
    {
        if (stLoggerNode->pucMsg)
        {
            MOS_FREE(stLoggerNode->pucMsg);
        }
        if (stLoggerNode->pucEt)
        {
            MOS_FREE(stLoggerNode->pucEt);
        }
        if (stLoggerNode->pucUrl)
        {
            MOS_FREE(stLoggerNode->pucUrl);
        }
        MOS_FREE(stLoggerNode);
    }
    return MOS_OK;
}

_INT CloudStg_LoggerAddDropNum(_INT iDropNum, _UC ucForceReset)
{
    // 10分钟后上传丢失数量的提醒
    if (CloudStg_LoggerGetMng()->uiDropNum == 0 || ucForceReset == 1)
    {
        CloudStg_LoggerGetMng()->tDropNumSendTime = Mos_Time() + 600;
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "next drop num send time is: %u", CloudStg_LoggerGetMng()->tDropNumSendTime);
    }
    CloudStg_LoggerGetMng()->uiDropNum += iDropNum;
    return MOS_OK;
}
