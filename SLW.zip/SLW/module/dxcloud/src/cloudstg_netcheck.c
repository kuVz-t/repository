#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <resolv.h>
#include "watchdog_api.h"
#include "config_api.h"
#include "cloudstg_netcheck.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"

#define SINGLE_IP
// #define NET_CHECK_DEBUG

struct hostent *g_server = MOS_NULL;

ST_CLOUDSTG_NETCHECK_MANAGE stCloudstgNetcheckManage = {0};
ST_CLOUDSTG_NETCHECK_MANAGE *CloudStg_NetcheckGetMng()
{
    return &stCloudstgNetcheckManage;
}

void print_buf(_C *buf, _INT length)
{
    _INT i = 0;
    length = length>8?8:length;
    MOS_PRINTF("======================\r\n");
    for (i = 0; i < length; i++)
    {
        MOS_PRINTF("%02x ", buf[i]);
    }
    MOS_PRINTF("\r\n======================\r\n");
}

_INT CloudStg_Netcheck_Init()
{
    if (CloudStg_NetcheckGetMng()->ucInitFlag) 
    {
        return MOS_ERR;
    }

    MOS_LIST_INIT(&CloudStg_NetcheckGetMng()->stTaskList);
    Mos_MutexCreate(&CloudStg_NetcheckGetMng()->hMutex);
    CloudStg_NetcheckGetMng()->ucInitFlag   = 1;
    CloudStg_NetcheckGetMng()->ucChangeFlag = 0;

    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud netcheck init ok");
    return MOS_OK;
}

_INT CloudStg_Netcheck_Start()
{
    CloudStg_NetcheckGetMng()->ucRunFlag = 1;
    _INT iRet = 0;
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;

    iRet = Mos_ThreadCreate((_UC*)"CloudNetcheck",  EN_THREAD_PRIORITY_NORMAL, uiStackSize,  
            CloudStg_NetcheckProc, MOS_NULL, MOS_NULL, &CloudStg_NetcheckGetMng()->hMgrThread);
    if (iRet == MOS_ERR)
    {
        CloudStg_NetcheckGetMng()->ucRunFlag = 0;
        Mos_ThreadDelete(CloudStg_NetcheckGetMng()->hMgrThread);
        return MOS_ERR;
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud netcheck start ok");
    return MOS_OK;
}

_INT CloudStg_Netcheck_Stop()
{
    if (CloudStg_NetcheckGetMng()->ucRunFlag == 0)
    {
        return MOS_ERR;
    }
    CloudStg_NetcheckGetMng()->ucRunFlag = 0;
    Mos_ThreadDelete(CloudStg_NetcheckGetMng()->hMgrThread);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud netcheck stop ok");
    return MOS_OK;
}

_INT CloudStg_Netcheck_Destroy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_NETCHECK_TASK *pstNetcheckTask = MOS_NULL;

    if (CloudStg_NetcheckGetMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    CloudStg_NetcheckGetMng()->ucInitFlag = 0;

    do
    {
        Mos_MutexLock(&CloudStg_NetcheckGetMng()->hMutex);
        pstNetcheckTask = (ST_CLOUDSTG_NETCHECK_MANAGE *)MOS_LIST_GETNEXT(&CloudStg_NetcheckGetMng()->stTaskList, MOS_NULL);
        Mos_MutexUnLock(&CloudStg_NetcheckGetMng()->hMutex);
        if (pstNetcheckTask)
        {
            CloudStg_NetcheckTaskDelete(pstNetcheckTask->uiTaskId);
        }
    }
    while (CloudStg_NetcheckGetMng()->stTaskList.uiTotalCount > 0);

    Mos_MutexDelete(&CloudStg_NetcheckGetMng()->hMutex);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud netcheck destory ok");
    return MOS_OK;
}

_VOID CloudStg_NetcheckProc()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_NETCHECK_TASK *pstNetcheckTask = MOS_NULL;
    _UI        uiSleep      = 0;
    _CTIME_T   cNowTime     = 0;
    _CTIME_T   cOldTimeSwd  = 0;
    _UC        *pucResult   = MOS_NULL;          
    _HSWDWRITE hSwdFeedDog  = MOS_NULL;
    _UI        uiTmp        = 0;

    // 设置看门狗
    hSwdFeedDog = Swd_AppThreadRegist(CLOUDSTG_NETCHECK_APP, FEED_DOG_ULTRA_MAX_TIMESEC);

    // 读取常驻配置并添加到任务列表中
    if (Config_GetCloudMng()->bNetCheckPermanent == MOS_TRUE)
    {
        CloudStg_NetcheckTaskAdd_Tcping(Config_GetCloudMng()->iNetCheckHostNum, Config_GetCloudMng()->aucNetCheckHost, 
                                        sizeof(Config_GetCloudMng()->aucNetCheckHost), Config_GetCloudMng()->piNetCheckSiteId, 
                                        sizeof(Config_GetCloudMng()->piNetCheckSiteId), Config_GetCloudMng()->iNetCheckDetectFreq, 
                                        Config_GetCloudMng()->iNetCheckDetectCount, Config_GetCloudMng()->iNetCheckCollectFreq, MOS_TRUE);
    }

    while (CloudStg_NetcheckGetMng()->ucRunFlag == 1)
    {
        if(uiSleep++ % 8 == 0)
        {
            cNowTime = Mos_Time();
        }

        // 定时喂狗
        if (MOS_ABS_NUM(cNowTime - cOldTimeSwd) >= 1)
        {
            cOldTimeSwd = cNowTime;
            Swd_AppThreadFeedDog(hSwdFeedDog);
        }

        Mos_MutexLock(&CloudStg_NetcheckGetMng()->hMutex);
        pstNetcheckTask = (ST_CLOUDSTG_NETCHECK_MANAGE *)MOS_LIST_GETNEXT(&CloudStg_NetcheckGetMng()->stTaskList, CloudStg_NetcheckGetMng()->pstCurBufNode);
        Mos_MutexUnLock(&CloudStg_NetcheckGetMng()->hMutex);

        if (pstNetcheckTask)
        {
            switch (pstNetcheckTask->iType)
            {
                // TCPING测试
                case EN_CLOUDSTG_NETCHECK_TCPING:
                {
                    // 常驻tcping按照CollectFreq周期性测试并上报
                    if (pstNetcheckTask->bIsPermanent)
                    {
                        uiTmp = Mos_GetTickCount() / 1000;
                        
                        // 常驻tcping未到达上报时间
                        if (uiTmp < pstNetcheckTask->iNextReqTime)
                        {
                            CloudStg_NetcheckGetMng()->pstCurBufNode = &pstNetcheckTask->stNode;
                            continue;
                        }
                        // 常驻Tcping开始上报
                        else
                        {
                            pstNetcheckTask->iNextReqTime = (Mos_GetTickCount() / 1000) + pstNetcheckTask->iCollectFreq;
                            pstNetcheckTask->bIsPermanentRuning = MOS_TRUE;
                        }
                    }

                    // 轮询Tcping测试
                    for (pstNetcheckTask->iIndex = 0; pstNetcheckTask->iIndex < pstNetcheckTask->iNum; pstNetcheckTask->iIndex++)
                    {
                        MOS_LOG_INF(CLOUDSTG_LOGSTR, "Start tcping test, DetectFreq: %d, DetectCount: %d, Host: %s, IsPermanent: %d", 
                                    pstNetcheckTask->iDetectFreq, pstNetcheckTask->iDetectCount, 
                                    pstNetcheckTask->aucHost[pstNetcheckTask->iIndex], 
                                    pstNetcheckTask->bIsPermanent);
                        CloudStg_NetcheckTcpingTest(pstNetcheckTask->aucHost[pstNetcheckTask->iIndex],
                                                    pstNetcheckTask->iDetectFreq,
                                                    pstNetcheckTask->iDetectCount,
                                                    &pstNetcheckTask->stTcpingResult[pstNetcheckTask->iIndex]);

                        // 避免网络异常，Tcping测试过久不喂狗
                        Swd_AppThreadFeedDog(hSwdFeedDog);
                    }

                    // 测试运行中检测到常驻配置变更，退出当前测试
                    if (CloudStg_NetcheckGetMng()->ucChangeFlag == 1)
                    {
                        // 重置配置变更flag
                        CloudStg_NetcheckGetMng()->ucChangeFlag = 0;
                        break;
                    }

                    // 上报云涛日志
                    pucResult = CloudStg_NetcheckBuildTcpingJson(pstNetcheckTask);
                    CloudStg_UploadLogEx(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_NETWORK_CHECK_INF_UPLOAD, "CD network check inf upload", pucResult, 0);

                    // 常驻保留任务
                    if (!pstNetcheckTask->bIsPermanent)
                    {
                        CloudStg_NetcheckTaskDelete(pstNetcheckTask->uiTaskId);
                    }
                    // 常驻Tcping结束上报
                    else
                    {
                        pstNetcheckTask->bIsPermanentRuning = MOS_FALSE;
                    }
                }
                break;

                // DNS测试
                case EN_CLOUDSTG_NETCHECK_DNS:
                {
                    for (pstNetcheckTask->iIndex = 0; pstNetcheckTask->iIndex < pstNetcheckTask->iNum; pstNetcheckTask->iIndex++)
                    {
                        MOS_LOG_INF(CLOUDSTG_LOGSTR, "Start dns test, Host: %s", pstNetcheckTask->aucHost[pstNetcheckTask->iIndex]);
                        CloudStg_NetcheckDnsTest(pstNetcheckTask->aucHost[pstNetcheckTask->iIndex],  &pstNetcheckTask->stDnsResult[pstNetcheckTask->iIndex]);
                    }

                    // 上报云涛日志
                    pucResult = CloudStg_NetcheckBuildDnsJson(pstNetcheckTask);
                    CloudStg_UploadLogEx(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_NETWORK_CHECK_INF_UPLOAD, "CD network check inf upload", pucResult, 0);
                    CloudStg_NetcheckTaskDelete(pstNetcheckTask->uiTaskId);
                }
                break;

                // 带宽测试
                case EN_CLOUDSTG_NETCHECK_BANDWIDTH:
                {
                    for (pstNetcheckTask->iIndex = 0; pstNetcheckTask->iIndex < pstNetcheckTask->iNum; pstNetcheckTask->iIndex++)
                    {
                        MOS_LOG_INF(CLOUDSTG_LOGSTR, "Start bandwidth test, url: %s", pstNetcheckTask->aucRequestURL[pstNetcheckTask->iIndex]);
                        CloudStg_NetcheckBandwidthTest(pstNetcheckTask->aucRequestURL[pstNetcheckTask->iIndex],
                                                    pstNetcheckTask->aucAuthorization[pstNetcheckTask->iIndex],
                                                    pstNetcheckTask->aucRequestDate[pstNetcheckTask->iIndex],
                                                    &pstNetcheckTask->stBandwidthResult[pstNetcheckTask->iIndex]);
                    }
                    // 上报云涛日志
                    pucResult = CloudStg_NetcheckBuildBandwidthJson(pstNetcheckTask);
                    CloudStg_UploadLogEx(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_NETWORK_CHECK_INF_UPLOAD, "CD network check inf upload", pucResult, 0);
                    CloudStg_NetcheckTaskDelete(pstNetcheckTask->uiTaskId);
                }
                break;
            }
            if (pucResult)
            {
                MOS_FREE(pucResult);
                pucResult = MOS_NULL;
            }
        }
        else
        {
            CloudStg_NetcheckGetMng()->pstCurBufNode = MOS_NULL;
        }
        Mos_Sleep(100);
    }

    Swd_AppThreadUnRegist(hSwdFeedDog);
}

_VOID CloudStg_NetcheckTaskAdd_Tcping(_INT iNum, _UC **aucHost, _INT iHostSize, _INT *iSiteId, _INT iSiteIdSize, _INT iDetectFreq, _INT iDetectCount, _INT iCollectFreq, _BOOL bIsPermanent)
{
    MOS_PARAM_NULL_RETERR(aucHost);
    MOS_PARAM_NULL_RETERR(iSiteId);

    _INT i = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_NETCHECK_TASK *pstTask = MOS_NULL;
    ST_CLOUDSTG_NETCHECK_TASK *pstTaskTmp = MOS_NULL;

    // 常驻Tcping
    if (bIsPermanent == MOS_TRUE)
    {
        Mos_MutexLock(&CloudStg_NetcheckGetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_NetcheckGetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->bIsPermanent == MOS_TRUE)
            {
                pstTask = pstTaskTmp;

                // 旧常驻Tcping正在运行，需要立即停止
                if (pstTask->bIsPermanentRuning == MOS_TRUE)
                {
                    CloudStg_NetcheckGetMng()->ucChangeFlag = 1;
                }
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_NetcheckGetMng()->hMutex);
    }

    if (pstTask == MOS_NULL)
    {
        pstTask = (ST_CLOUDSTG_NETCHECK_TASK *)Mos_MallocClr(sizeof(ST_CLOUDSTG_NETCHECK_TASK));
        CloudStg_NetcheckTaskAdd(pstTask);
    }

    pstTask->iType     = EN_CLOUDSTG_NETCHECK_TCPING;
    pstTask->iNum      = iNum;
    MOS_MEMSET(pstTask->aucHost, 0x00, sizeof(pstTask->aucHost));
    MOS_MEMSET(pstTask->iSiteId, 0x00, sizeof(pstTask->iSiteId));
    MOS_MEMCPY(pstTask->aucHost, aucHost, iHostSize);
    MOS_MEMCPY(pstTask->iSiteId, iSiteId, iSiteIdSize);
    pstTask->iDetectFreq  = iDetectFreq;
    pstTask->iDetectCount = iDetectCount;
    pstTask->iCollectFreq = iCollectFreq;
    pstTask->bIsPermanent = bIsPermanent;
    if (pstTask->bIsPermanent)
    {
        pstTask->iNextReqTime = (Mos_GetTickCount() / 1000);
    }

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "push in new task, type: Tcping, num: %d, DetectFreq: %d, DetectCount: %d, CollectFreq: %d, IsPermanent: %d, NextReqTime: %d", 
                                    pstTask->iNum, pstTask->iDetectFreq, pstTask->iDetectCount, pstTask->iCollectFreq, pstTask->bIsPermanent, pstTask->iNextReqTime);
#ifdef NET_CHECK_DEBUG
    for (i = 0; i < pstTask->iNum; i++)
    {
        MOS_PRINTF("==============%d=============", i);
        MOS_PRINTF("Host: %s", pstTask->aucHost[i]);
        MOS_PRINTF("SiteId: %d", pstTask->iSiteId[i]);
    }
#endif
}

_VOID CloudStg_NetcheckTaskAdd_Dns(_INT iNum, _UC **aucHost, _INT iHostSize, _INT *iSiteId, _INT iSiteIdSize)
{
    MOS_PARAM_NULL_RETERR(aucHost);
    MOS_PARAM_NULL_RETERR(iSiteId);

    _INT i = 0;
    ST_CLOUDSTG_NETCHECK_TASK *pstTask = (ST_CLOUDSTG_NETCHECK_TASK *)Mos_MallocClr(sizeof(ST_CLOUDSTG_NETCHECK_TASK));
    pstTask->iType     = EN_CLOUDSTG_NETCHECK_DNS;
    pstTask->iNum      = iNum;
    MOS_MEMCPY(pstTask->aucHost, aucHost, iHostSize);
    MOS_MEMCPY(pstTask->iSiteId, iSiteId, iSiteIdSize);

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "push in new task, type: Dns, num: %d", iNum);
#ifdef NET_CHECK_DEBUG
    for (i = 0; i < iNum; i++)
    {
        MOS_PRINTF("==============%d=============", i);
        MOS_PRINTF("Host: %s", pstTask->aucHost[i]);
        MOS_PRINTF("SiteId: %d", pstTask->iSiteId[i]);
    }
#endif
    CloudStg_NetcheckTaskAdd(pstTask);
}

_VOID CloudStg_NetcheckTaskAdd_Bandwidth(_INT iNum, _UC **aucHost, _INT iHostSize, _INT *iSiteId, _INT iSiteIdSize, _UC **aucAuthorization, _INT iAuthorizationSize, _UC **aucRequestURL, _INT iRequestURLSize, _UC **aucRequestDate, _INT iRequestDateSize)
{
    MOS_PARAM_NULL_RETERR(aucAuthorization);
    MOS_PARAM_NULL_RETERR(aucRequestURL);
    MOS_PARAM_NULL_RETERR(aucRequestDate);

    _INT i = 0;
    ST_CLOUDSTG_NETCHECK_TASK *pstTask = (ST_CLOUDSTG_NETCHECK_TASK *)Mos_MallocClr(sizeof(ST_CLOUDSTG_NETCHECK_TASK));
    pstTask->iType     = EN_CLOUDSTG_NETCHECK_BANDWIDTH;
    pstTask->iNum      = iNum;
    MOS_MEMCPY(pstTask->aucHost, aucHost, iHostSize);
    MOS_MEMCPY(pstTask->iSiteId, iSiteId, iSiteIdSize);
    MOS_MEMCPY(pstTask->aucAuthorization, aucAuthorization, iAuthorizationSize);
    MOS_MEMCPY(pstTask->aucRequestURL, aucRequestURL, iRequestURLSize);
    MOS_MEMCPY(pstTask->aucRequestDate, aucRequestDate, iRequestDateSize);

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "push in new task, type: Bandwidth, num: %d", iNum);
#ifdef NET_CHECK_DEBUG
    for (i = 0; i < iNum; i++)
    {
        MOS_PRINTF("==============%d=============", i);
        MOS_PRINTF("Authorization: %s", pstTask->aucAuthorization[i]);
        MOS_PRINTF("RequestURL: %s", pstTask->aucRequestURL[i]);
        MOS_PRINTF("RequestDat: %s", pstTask->aucRequestDate[i]);
    }
#endif
    CloudStg_NetcheckTaskAdd(pstTask);
}

_VOID CloudStg_NetcheckTaskAdd(ST_CLOUDSTG_NETCHECK_TASK *pstTask)
{
    MOS_PARAM_NULL_RETERR(pstTask);
    pstTask->uiTaskId = Mos_GetSessionId();
    Mos_MutexLock(&CloudStg_NetcheckGetMng()->hMutex);
    MOS_LIST_ADDTAIL(&CloudStg_NetcheckGetMng()->stTaskList, pstTask);
    Mos_MutexUnLock(&CloudStg_NetcheckGetMng()->hMutex);
}

_VOID CloudStg_NetcheckTaskDelete(_UI uiTaskId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_NETCHECK_TASK *pstNetcheckTask = MOS_NULL;

    Mos_MutexLock(&CloudStg_NetcheckGetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_NetcheckGetMng()->stTaskList, pstNetcheckTask, stIterator)
    {
        if (pstNetcheckTask->uiTaskId == uiTaskId)
        {
            MOS_LIST_RMVNODE(&CloudStg_NetcheckGetMng()->stTaskList, pstNetcheckTask);
            if (pstNetcheckTask)
            {
                MOS_FREE(pstNetcheckTask);
            }
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_NetcheckGetMng()->hMutex);
}

_VOID CloudStg_NetcheckTaskClosePermanent()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_NETCHECK_TASK *pstNetcheckTask = MOS_NULL;

    Mos_MutexLock(&CloudStg_NetcheckGetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_NetcheckGetMng()->stTaskList, pstNetcheckTask, stIterator)
    {
        if (pstNetcheckTask->bIsPermanent == MOS_TRUE)
        {
            pstNetcheckTask->bIsPermanent = MOS_FALSE;

            // 常驻任务未运行，直接删除
            if (pstNetcheckTask->bIsPermanentRuning == MOS_FALSE)
            {
                MOS_LIST_RMVNODE(&CloudStg_NetcheckGetMng()->stTaskList, pstNetcheckTask);
                if (pstNetcheckTask)
                {
                    MOS_FREE(pstNetcheckTask);
                }
            }
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_NetcheckGetMng()->hMutex);
}

_INT CloudStg_NetcheckTcpingTest(_UC *pucHost, _INT iDetectFreq, _INT iDetectCount, ST_CLOUDSTG_NETCHECK_TCPING_RESULT *pstTcpingRes)
{
    MOS_PARAM_NULL_RETERR(pucHost);

    _INT i = 0;
    _INT iRet = 0;
    _INT error = 0;
    _INT iPort = 80;
    _INT iCurncount = 0;
    _INT iOk = 0, iErr = 0;
    _INT iErrcode = MOS_OK;
    _DOUBLE dMin = 999999999999999.0, dAvg = 0.0, dMax = 0.0, dMs = 0.0;
    _BOOL bConnected = MOS_TRUE;
    ST_MOS_INET_IPARRAY stIpArrayInfo = {0};
    ST_MOS_INET_IP *pstIpInfo = MOS_NULL;
    _SOCKET hSocket   = MOS_SOCKET_INVALID;
    fd_set fdrset, fdwset;
    socklen_t errlen;
    struct timeval start = {0};
    struct timeval stTimeout = {0};
    struct timeval timeout_tmp = {0};
    struct timeval rtt = {0};
    stTimeout.tv_sec  = TCPING_TIMEOUT;
    stTimeout.tv_usec = 0;

    if(Mos_GetInetSysFuncSenv()->pfun_InetGetAddrInfo)
    {
        if(Mos_GetInetSysFuncSenv()->pfun_InetGetAddrInfo(pucHost, iPort, 0, MOS_FALSE, &stIpArrayInfo) != MOS_OK)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Mos_InetGetAddrInf %s failed", pucHost);
            return MOS_ERR;
        }
    }

#ifdef NET_CHECK_DEBUG
        MOS_PRINTF("PING %s:%d\n", pucHost, iPort);
#endif

    while((iCurncount < iDetectCount || iDetectCount == -1) && CloudStg_NetcheckGetMng()->ucRunFlag == 1)
    {
        // 测试运行中检测到常驻配置变更，立即关闭测试。
        if (CloudStg_NetcheckGetMng()->ucChangeFlag == 1)
        {
            break;
        }

        // 连接IP
        for (i = 0;i < stIpArrayInfo.uiCount; i++)
        {
            if(stIpArrayInfo.astIps[i].usType != EN_CINET_TYPE_IPV4)
            {
                continue;
            }
            pstIpInfo = &stIpArrayInfo.astIps[i];
            pstIpInfo->usType = stIpArrayInfo.astIps[i].usType;
            pstIpInfo->usPort = iPort;

            if (gettimeofday(&start, MOS_NULL) == -1)
            {
                return MOS_ERR;
            }

            // 打开socket
            hSocket = Mos_SocketOpen(EN_CINET_TYPE_IPV4, EN_CINET_PRTL_TCP, MOS_FALSE, MOS_TRUE);
            if (hSocket == MOS_SOCKET_INVALID)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "open socket fail");
                return MOS_ERR;
            }
            iRet = Mos_SocketConnect(hSocket, pstIpInfo, &bConnected);
            if(MOS_OK == iRet)
            {
                FD_ZERO(&fdrset);
                FD_SET(hSocket, &fdrset);
                fdwset = fdrset;

                MOS_MEMCPY(&timeout_tmp, &stTimeout, sizeof(struct timeval));
                if (select(hSocket+1, &fdrset, &fdwset, MOS_NULL, (timeout_tmp.tv_sec + timeout_tmp.tv_usec) > 0 ? &timeout_tmp : MOS_NULL) == 0) 
                {
#ifdef NET_CHECK_DEBUG
                    fprintf(stdout, "tcping timeout.\n");
#endif
                    /* timeout */
                    Mos_SocketClose(hSocket);
                    hSocket = MOS_SOCKET_INVALID;
                    iErrcode = -ETIMEDOUT;
#ifdef SINGLE_IP
                    break;
#else
                    continue;
#endif
                }
                if (FD_ISSET(hSocket, &fdrset) || FD_ISSET(hSocket, &fdwset)) 
                {
                    errlen = sizeof(error);
                    if (getsockopt(hSocket, SOL_SOCKET, SO_ERROR, &error, &errlen) != 0) 
                    {
                        /* getsockopt error */
#ifdef NET_CHECK_DEBUG
                        fprintf(stderr, "getsockopt err, %s\n", strerror(errno));
#endif
                        Mos_SocketClose(hSocket);
                        hSocket = MOS_SOCKET_INVALID;
                        iErrcode = -errno;
#ifdef SINGLE_IP
                        break;
#else
                        continue;
#endif
                    }
                    if (error != 0) 
                    {
#ifdef NET_CHECK_DEBUG
                        fprintf(stdout, "connection closed.\n");
#endif
                        Mos_SocketClose(hSocket);
                        hSocket = MOS_SOCKET_INVALID;
                        iErrcode = -errno;
#ifdef SINGLE_IP
                        break;
#else
                        continue;
#endif
                    }
                }
                else 
                {
#ifdef NET_CHECK_DEBUG
                    fprintf(stderr, "error: select: hSocket not set\n");
#endif
                    iErrcode = -errno;
#ifdef SINGLE_IP
                    break;
#else
                    continue;
#endif
                }
                break;
            }
            else
            {
                if (errno != EINPROGRESS) 
                {
#ifdef NET_CHECK_DEBUG
                    fprintf(stderr, "connect error: %s\n", strerror(errno));
#endif
                    Mos_SocketClose(hSocket);
                    hSocket = MOS_SOCKET_INVALID;
#ifdef SINGLE_IP
                    iErrcode = -errno;
                    break;
#else
                    continue;
#endif
                }
            }
        }

        if (gettimeofday(&rtt, MOS_NULL) == -1)
        {
            Mos_SocketClose(hSocket);
            hSocket = MOS_SOCKET_INVALID;
            return MOS_ERR;
        }

        rtt.tv_sec = rtt.tv_sec - start.tv_sec;
        rtt.tv_usec = rtt.tv_usec - start.tv_usec;
        if (hSocket != MOS_SOCKET_INVALID)
        {
            Mos_SocketClose(hSocket);
            hSocket = MOS_SOCKET_INVALID;
        }

        if (iErrcode == MOS_OK)
        {
            iOk++;

            dMs = ((double)rtt.tv_sec * 1000.0) + ((double)rtt.tv_usec / 1000.0);
            dAvg += dMs;
            dMin = dMin > dMs ? dMs : dMin;
            dMax = dMax < dMs ? dMs : dMax;

            MOS_PRINTF("response from %s:%d, seq=%d time=%.2f ms\n", pucHost, iPort, iCurncount, dMs);
            // if (dMs > 500) break; /* Stop the test on the first long connect() */
        }
        else if (iErrcode != -EADDRNOTAVAIL)
        {
            MOS_PRINTF("error connecting to host (%d): %s\n", -iErrcode, strerror(-iErrcode));
            iErr++;
        }
        else
        {
            MOS_PRINTF("error connecting to host (%d): %s\n", -iErrcode, strerror(-iErrcode));
        }

        iErrcode = MOS_OK;
        iCurncount++;
        Mos_Sleep(iDetectFreq * 1000);
    }
    dAvg = dAvg / (double)iOk;
#ifdef NET_CHECK_DEBUG
        MOS_PRINTF("--- %s:%d ping statistics ---\n", pucHost, iPort);
        MOS_PRINTF("%d responses, %d iOk, %3.2f%% failed\n", iCurncount, iOk, (((double)iErr) / abs(((double)iCurncount)) * 100.0));
        MOS_PRINTF("round-trip dMin/dAvg/dMax = %.1f/%.1f/%.1f dMs\n", dMin, dAvg, dMax);
#endif
    if (pstTcpingRes)
    {
        pstTcpingRes->iDelay = (_INT)dAvg;
        pstTcpingRes->iMinDelay = (_INT)dMin;
        pstTcpingRes->iMaxDelay = (_INT)dMax;
        pstTcpingRes->iTimeoutCount = iErr;
    }
    return MOS_OK;
}

_INT CloudStg_NetcheckDnsTest(_UC *pucHost, ST_CLOUDSTG_NETCHECK_DNS_RESULT *pstDnsRes)
{
    MOS_PARAM_NULL_RETERR(pucHost);

    _INT iPort = 80;
    _UI uiStartTime = 0;
    ST_MOS_INET_IPARRAY stIpArrayInfo = {0};

    uiStartTime = Mos_GetTickCount();
    if(Mos_GetInetSysFuncSenv()->pfun_InetGetAddrInfo)
    {
        if(Mos_GetInetSysFuncSenv()->pfun_InetGetAddrInfo(pucHost, iPort, 0, MOS_FALSE, &stIpArrayInfo) != MOS_OK)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Mos_InetGetAddrInf %s failed", pucHost);
            return MOS_ERR;
        }
    }

    if (pstDnsRes)
    {
        pstDnsRes->iDelay  = Mos_GetTickCount() - uiStartTime;
        pstDnsRes->iResult = 1;
    }
    return MOS_OK;
}

_INT CloudStg_NetcheckBandwidthTest(_UC *pucUrl, _UC *pucAuthorization, _UC *pucRequestDate, ST_CLOUDSTG_NETCHECK_BANDWIDTH_RESULT *pstBandWidthRes)
{
    MOS_PARAM_NULL_RETERR(pucUrl);
    MOS_PARAM_NULL_RETERR(pucAuthorization);
    MOS_PARAM_NULL_RETERR(pucRequestDate);

    _UI i = 0;
    _UI uiStartTick       = 0;
    _UI uiTotalTime       = 0;
    _UI uiHttpsFlag       = 0;
    _UC *pucSubUrl        = MOS_NULL;
    _UC *pStrTmp          = MOS_NULL;
    _UC aucHost[256]      = {0};
    _C buffer[CHUNK_SIZE] = {0};
    _C header[1024]       = {0};
    _C chunk[CHUNK_SIZE+CHUNK_NUM_SIZE] = {0};
    _INT iRet             = MOS_ERR;
    _INT n                = 0;
    _INT iBytesSent       = 0;
    _INT iBytesTotalSent  = 0;
    _INT iTmp             = 0;
    _INT iCount           = 0;
    _INT iBandWidth       = 0;
    _INT chunk_size       = 0;
    _BOOL bWait           = MOS_FALSE;
    _BOOL bConnected      = MOS_TRUE;
    FILE *write_file      = MOS_NULL;
    _SOCKET hSocket       = MOS_SOCKET_INVALID;
    ST_MOS_INET_IP *pstIpInfo = MOS_NULL;
    ST_MOS_INET_IPARRAY stIpArrayInfo = {0};

    // 解析URL：1、是否https；2、解析出域名；3、解析出URI
    pStrTmp = MOS_STRSTR(pucUrl, "https");
    if (pStrTmp == MOS_NULL) 
    {
        pStrTmp = MOS_STRSTR(pucUrl, "http");
        if (pStrTmp == MOS_NULL)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Url is Unrecognized %s", pucUrl);
            return MOS_ERR;
        }
        pStrTmp += MOS_STRLEN("http://");
    }
    else
    {
        uiHttpsFlag = 1;
        pStrTmp += MOS_STRLEN("https://");
    }
    pucSubUrl = MOS_STRSTR(pStrTmp, "/");
    if (pucSubUrl == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Url is Incorrect format %s", pucSubUrl);
        return MOS_ERR;
    }
    MOS_STRNCPY(aucHost, pStrTmp, pucSubUrl - pStrTmp);

    // 打开socket
    hSocket = Mos_SocketOpen(EN_CINET_TYPE_IPV4, EN_CINET_PRTL_TCP, MOS_TRUE, MOS_TRUE);
    if (hSocket == MOS_SOCKET_INVALID)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "open socket fail");
        return MOS_ERR;
    }
    // 设置socket参数
    do
    {
        iRet = Mos_SocketSetSendBuf(hSocket, CLOUDSTG_SOCKET_SEND_SIZE);
        if (iRet != MOS_OK)
        {
            break;
        }
        iRet = Mos_SocketSetRecvBuf(hSocket, CLOUDSTG_SOCKET_RECV_SIZE);
        if (iRet != MOS_OK)
        {
            break;
        }
        iRet = Mos_SocketSetOptNodelay(hSocket, MOS_TRUE);
        if (iRet != MOS_OK)
        {
            break;
        }
        iRet = Mos_SocketSetSendTimeOut(hSocket, CLOUDSTG_SOCKET_SEND_TIMEOUT);
        if (iRet != MOS_OK)
        {
            break;
        }
        iRet = Mos_SocketSetRecvTimeOut(hSocket, CLOUDSTG_SOCKET_RECV_TIMEOUT);
        if (iRet != MOS_OK)
        {
            break;
        }

    }while(0);
    if (iRet != MOS_OK)
    {        
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "socket set config fail");
        Mos_SocketClose(hSocket);
        return MOS_ERR;
    }

    // 解析域名为IP
    if(Mos_GetInetSysFuncSenv()->pfun_InetGetAddrInfo)
    {
        if(Mos_GetInetSysFuncSenv()->pfun_InetGetAddrInfo(aucHost, (uiHttpsFlag==1)?443:80, 0, MOS_FALSE, &stIpArrayInfo) != MOS_OK)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Mos_InetGetAddrInf %s failed", aucHost);
            Mos_SocketClose(hSocket);
            return MOS_ERR;
        }
    }
    else
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Can't find pfun_InetGetAddrInfo");
        Mos_SocketClose(hSocket);
        return MOS_ERR;
    }

    // 连接IP
    for (i = 0;i < stIpArrayInfo.uiCount; i++)
    {
        if(stIpArrayInfo.astIps[i].usType != EN_CINET_TYPE_IPV4)
        {
            continue;
        }
        pstIpInfo = &stIpArrayInfo.astIps[i];
        pstIpInfo->usType = stIpArrayInfo.astIps[i].usType;
        pstIpInfo->usPort = (uiHttpsFlag==1)?443:80;
        iRet = Mos_SocketConnect(hSocket, pstIpInfo, &bConnected);
        if(MOS_OK == iRet)
        {
           break;
        }
    }

    uiStartTick = Mos_GetTickCount();
    // 构造HTTP请求头
    MOS_MEMSET(header, 0x00, sizeof(header));
    MOS_SPRINTF(header, VIDEO_TEMPLATE, pucSubUrl, aucHost, pucRequestDate, pucAuthorization);
#ifdef NET_CHECK_DEBUG
    MOS_PRINTF("%s", header);
#endif
    // 发送HTTP请求头
    n = Mos_SocketSend(hSocket, header, MOS_STRLEN(header), &iTmp);
    if (n < 0) {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "ERROR sending header %d", errno);
        Mos_SocketClose(hSocket);
        return MOS_ERR;
    }
    // MOS_PRINTF("↓↓↓↓↓↓↓↓↓↓↓↓starting upload cloud↓↓↓↓↓↓↓↓↓↓↓↓\r\n%s", header);
    // print_buf(header, MOS_STRLEN(header));

    // 接收HTTP 100响应
    n = Mos_SocketRecv(hSocket, buffer, sizeof(buffer), &iTmp);
    if (n < 0) {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "ERROR recving header: %d", errno);
        Mos_SocketClose(hSocket);
        return MOS_ERR;
    }
#ifdef NET_CHECK_DEBUG
    MOS_PRINTF("%s", buffer);
#endif
    MOS_MEMSET(buffer, 0x00, sizeof(buffer));

    // 发送文件内容
    while (iBytesTotalSent < DATA_MAX_SIZE && CloudStg_NetcheckGetMng()->ucRunFlag == 1) 
    {
        iBytesSent = ((DATA_MAX_SIZE-iBytesTotalSent)>CHUNK_SIZE)?CHUNK_SIZE:(DATA_MAX_SIZE-iBytesTotalSent);
        // Generate random data
        for (i = 0; i < iBytesSent; i++) {
            buffer[i] = rand() % 256;
        }

        MOS_MEMSET(chunk, 0x00, sizeof(chunk));
        chunk_size = MOS_SPRINTF(chunk, "%x\r\n", iBytesSent);
        MOS_MEMCPY(chunk + chunk_size, buffer, iBytesSent);
        MOS_MEMCPY(chunk + chunk_size + iBytesSent, "\r\n", 2);

        // 发送文件数据
        iBytesSent = Mos_SocketSend(hSocket, chunk, chunk_size + iBytesSent + 2, &iTmp);
        if (iBytesSent < 0) {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "ERROR sending chunk");
            Mos_SocketClose(hSocket);
            return MOS_ERR;
        }

        iBytesTotalSent += iBytesSent;
        // MOS_PRINTF("Sent %d bytes\n", iBytesSent);
#ifdef NET_CHECK_DEBUG
        MOS_PRINTF(".");
#endif
        // usleep(50*1000);
    }
    // 结束
    {
        // 文件读取完成，发送最后的0字节数据块
        _C zero_chunk[] = "0\r\n\r\n";
        
        // 发送chunked结束符
        n = Mos_SocketSend(hSocket, zero_chunk, MOS_STRLEN(zero_chunk), &iTmp);
        if (n < 0) {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "ERROR sending zero chunk");
            Mos_SocketClose(hSocket);
            return MOS_ERR;
        }
        MOS_MEMSET(buffer, 0x00, sizeof(buffer));
        
        // 接收HTTP响应 200
        n = Mos_SocketRecv(hSocket, buffer, sizeof(buffer), &iTmp);
        if (n < 0) {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "ERROR recving response");
            Mos_SocketClose(hSocket);
            return MOS_ERR;
        }
#ifdef NET_CHECK_DEBUG
        MOS_PRINTF("\r\nrecv[%d]:%s", n, buffer);
#endif
    }
    uiTotalTime = (Mos_GetTickCount() - uiStartTick);
    iBandWidth  = (_INT)(((float)(iBytesTotalSent / 1024.0) / (float)(uiTotalTime / 1000.0)));

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "Send %dKB file over, time: %.2fs, bandwidth %dKB/s", 
                (_INT)(iBytesTotalSent / 1024), (float)(uiTotalTime / 1000.0), iBandWidth);

    if (pstBandWidthRes)
    {
        pstBandWidthRes->iSpeed = iBandWidth;
    }

    // 关闭套接字和文件
    Mos_SocketClose(hSocket);
    return MOS_OK;
}


_UC *CloudStg_NetcheckBuildTcpingJson(ST_CLOUDSTG_NETCHECK_TASK *pstTask)
{
    MOS_PARAM_NULL_RETNULL(pstTask);
    _INT i = 0;
    _UC *pucStr = MOS_NULL;
    JSON_HANDLE hObject      = Adpt_Json_CreateObject();
    JSON_HANDLE hDataArray   = Adpt_Json_CreateArray();

    Adpt_Json_AddItemToObject(hObject, (_UC*)"type", Adpt_Json_CreateNumber(EN_CLOUDSTG_NETCHECK_TCPING));
    for (i = 0; i < pstTask->iNum; i++)
    {
        JSON_HANDLE hArrayObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"detectTarget", Adpt_Json_CreateString(pstTask->aucHost[i]));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"siteId", Adpt_Json_CreateNumber(pstTask->iSiteId[i]));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"count", Adpt_Json_CreateNumber(pstTask->iDetectCount));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"delay", Adpt_Json_CreateNumber(pstTask->stTcpingResult[i].iDelay));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"minDelay", Adpt_Json_CreateNumber(pstTask->stTcpingResult[i].iMinDelay));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"maxDelay", Adpt_Json_CreateNumber(pstTask->stTcpingResult[i].iMaxDelay));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"timeoutCount", Adpt_Json_CreateNumber(pstTask->stTcpingResult[i].iTimeoutCount));
        Adpt_Json_AddItemToObject(hDataArray, "", hArrayObject);
    }
    Adpt_Json_AddItemToObject(hObject, (_UC*)"detectData", hDataArray);
    pucStr = Adpt_Json_Print(hObject);
    MOS_PRINTF("%s, %s\r\n", __FUNCTION__, pucStr);
    Adpt_Json_Delete(hObject);
    return pucStr;
}

_UC *CloudStg_NetcheckBuildDnsJson(ST_CLOUDSTG_NETCHECK_TASK *pstTask)
{
    MOS_PARAM_NULL_RETNULL(pstTask);
    _INT i = 0;
    _UC *pucStr = MOS_NULL;
    _UC aucBuf[128] = {0};
    JSON_HANDLE hObject      = Adpt_Json_CreateObject();
    JSON_HANDLE hDataArray   = Adpt_Json_CreateArray();

    Adpt_Json_AddItemToObject(hObject, (_UC*)"type", Adpt_Json_CreateNumber(EN_CLOUDSTG_NETCHECK_DNS));

    // 获取设备DNS配置，多个ip用,拼接成字符串
    if (CloudStg_NetcheckGetDns(aucBuf, sizeof(aucBuf)) == MOS_OK)
    {
        Adpt_Json_AddItemToObject(hObject, (_UC*)"deviceDns", Adpt_Json_CreateString(aucBuf));
    }
    for (i = 0; i < pstTask->iNum; i++)
    {
        JSON_HANDLE hArrayObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"detectTarget", Adpt_Json_CreateString(pstTask->aucHost[i]));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"siteId", Adpt_Json_CreateNumber(pstTask->iSiteId[i]));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"delay", Adpt_Json_CreateNumber(pstTask->stDnsResult[i].iDelay));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"result", Adpt_Json_CreateNumber(pstTask->stDnsResult[i].iResult));
        Adpt_Json_AddItemToObject(hDataArray, "", hArrayObject);
    }
    Adpt_Json_AddItemToObject(hObject, (_UC*)"detectData", hDataArray);
    pucStr = Adpt_Json_Print(hObject);
    MOS_PRINTF("%s, %s\r\n", __FUNCTION__, pucStr);
    Adpt_Json_Delete(hObject);
    return pucStr;
}

_UC *CloudStg_NetcheckBuildBandwidthJson(ST_CLOUDSTG_NETCHECK_TASK *pstTask)
{
    MOS_PARAM_NULL_RETNULL(pstTask);
    _INT i = 0;
    _UC *pucStr = MOS_NULL;
    JSON_HANDLE hObject      = Adpt_Json_CreateObject();
    JSON_HANDLE hDataArray   = Adpt_Json_CreateArray();

    Adpt_Json_AddItemToObject(hObject, (_UC*)"type", Adpt_Json_CreateNumber(EN_CLOUDSTG_NETCHECK_BANDWIDTH));
    for (i = 0; i < pstTask->iNum; i++)
    {
        JSON_HANDLE hArrayObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"detectTarget", Adpt_Json_CreateString(pstTask->aucHost[i]));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"siteId", Adpt_Json_CreateNumber(pstTask->iSiteId[i]));
        Adpt_Json_AddItemToObject(hArrayObject, (_UC*)"speed", Adpt_Json_CreateNumber(pstTask->stBandwidthResult[i].iSpeed));
        Adpt_Json_AddItemToObject(hDataArray, "", hArrayObject);
    }
    Adpt_Json_AddItemToObject(hObject, (_UC*)"detectData", hDataArray);
    pucStr = Adpt_Json_Print(hObject);
    MOS_PRINTF("%s, %s\r\n", __FUNCTION__, pucStr);
    Adpt_Json_Delete(hObject);
    return pucStr;
}

_INT CloudStg_NetcheckGetDns(_UC *pucBuf, _INT iLen)
{
    _INT i       = 0;
    _INT iTmpLen = 0;
    _INT icount  = 0;
    _INT iOffset = 0;
    ssize_t sRead = 0;
    _C *pucTmp   = NULL;
    FILE *fp;
    fp = Mos_FileOpen("/etc/hosts", "r"); // open the file in read mode
    if (fp == MOS_NULL) {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Error opening file\n");
        return MOS_ERR;
    }

    while ((sRead = getline(&pucTmp, &iTmpLen, fp)) != -1 && icount < 3) // read the first 3 lines
    {
        for (i = 0; i < MOS_STRLEN(pucTmp); i++) {
            if (pucTmp[i] == '\n') {
                pucTmp[i] = '\0';
            }
        }
        // MOS_PRINTF("Retrieved line of length %s, %zu \r\n", pucTmp, sRead);
        MOS_VSNPRINTF(pucBuf + iOffset, iLen - iOffset, "%s;", pucTmp);
        iOffset += MOS_STRLEN(pucTmp) + 1;
        icount++;
        if (iOffset > iLen)
        {
            pucBuf[iLen-1] = '\0';
        }
    }
    if (pucTmp)
    {
        MOS_FREE(pucTmp);
    }
    Mos_FileClose(fp); // close the file
    return MOS_OK;
}
