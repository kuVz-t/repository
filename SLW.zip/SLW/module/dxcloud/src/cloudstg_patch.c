#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "config_type.h"
#include "config_api.h"
#include "config_system.h"
#include "media_cache_api.h"
#include "http_api.h"
#include "record_api.h"
#include "snap_api.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_stream_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_manage.h"
#include "cloudstg_aliveupload.h"
#include "cloudstg_transaddress.h"
#include "cloudstg_event.h"
#include "cloudstg_patch.h"
#include "cloudstg_logcode.h"
#include "kjiot_device_api.h"
#include "msgmng_cmdserver.h"
#include "msgmng_multimedia.h"
#include "media_retras_reader.h"
#include "cloudstg_stream_prv.h"
#include "watchdog_api.h"
#include "http.h"

static ST_CLOUDSTG_PATCH_MANAGE g_stCloudStgPatchMng = {0};
static ST_CLOUDSTG_TRANS_MGR g_stCloudTransPatchMgr = {0};
static _INT CloudStg_PatchTaskLoop(_VPTR pParam);

ST_CLOUDSTG_TRANS_MGR* CloudStg_Trans_PatchGetMgr()
{
    return &g_stCloudTransPatchMgr;
}

ST_CLOUDSTG_PATCH_MANAGE *CloudStg_Patch_GetMng()
{
    return &g_stCloudStgPatchMng;
} 

_INT CloudStg_Patch_MngPrvInit()
{
    MOS_MEMSET(&g_stCloudStgPatchMng, 0, sizeof(ST_CLOUDSTG_PATCH_MANAGE));
    return MOS_OK;
}

_INT CloudStg_Patch_Init()
{
    if(CloudStg_Patch_GetMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Patch Already Init");
        return MOS_OK;
    }

    MOS_MEMSET(&g_stCloudStgPatchMng, 0, sizeof(g_stCloudStgPatchMng));
    CloudStg_Patch_GetMng()->hMsgQueue  = Mos_MsgQueueCreate(MOS_FALSE,10, __FUNCTION__);
    CloudStg_Patch_GetMng()->iSleepTime = 1;
    CloudStg_Patch_GetMng()->ucInitFlag = 1;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud patch task init ok");
    return MOS_OK;
}

_INT CloudStg_Patch_Start()
{
    _INT iRet;
    _UI uiStackSize   = MOS_THREAD_STACK_NORMAL_SIZE;
    _UI uiStreamSliceSize = 0;

    if(CloudStg_Patch_GetMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    if(CloudStg_Patch_GetMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Patch Already Start");
        return MOS_OK;
    }
    
    CloudStg_Patch_GetMng()->ucStopFlag = 0;

    // 获取系统参数句柄
    ST_CFG_SYSTEM_MNG * pstCompanyInfo = Config_GetSystemMng();

    // 获取trans管理句柄，不能重复运行
    if (CloudStg_Trans_PatchGetMgr()->bRun == MOS_TRUE)
    {
        return MOS_OK;
    }

    // 设置为运行状态
    CloudStg_Trans_PatchGetMgr()->bRun    = MOS_TRUE;

    // 读取云存补录配置文件
    Config_LoadCloudPatchFile();

    Mos_MutexCreate(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    
    // 获取did
    MOS_MEMCPY(CloudStg_Trans_PatchGetMgr()->aucDid,pstCompanyInfo->aucDid,CFG_STRING_COMMONLEN);

    // 初始化链表
    MOS_LIST_INIT(&CloudStg_Trans_PatchGetMgr()->stTaskList);

    if (CloudStg_Patch_GetMng()->iInitail == MOS_FALSE)
    {
        Mos_MutexCreate(&CloudStg_Patch_GetMng()->hMutex);
        MOS_LIST_INIT(&CloudStg_Patch_GetMng()->stPatchTaskList);
    }

    CloudStg_Patch_GetMng()->ucRunFlag  = 1; 
    // 负责获取流，发流到缓存器中
    iRet = Mos_ThreadCreate((_UC*)"CloudPatchMng",  EN_THREAD_PRIORITY_NORMAL, uiStackSize,  
            CloudStg_PatchTaskLoop, MOS_NULL, MOS_NULL, &CloudStg_Patch_GetMng()->hMgrThread);
    if(iRet == MOS_ERR)
    {
        CloudStg_Patch_GetMng()->ucRunFlag = 0;
        Mos_ThreadDelete(CloudStg_Patch_GetMng()->hMgrThread);
        return MOS_ERR;
    }

    // 云存上传
    iRet = Mos_ThreadCreate((_UC*)"CloudPatchTrans",  EN_THREAD_PRIORITY_NORMAL, uiStackSize,  
            CloudStg_Trans_PatchProc, MOS_NULL, MOS_NULL, &CloudStg_Trans_PatchGetMgr()->hThread);
    if(iRet == MOS_ERR)
    {
        CloudStg_Trans_PatchGetMgr()->bRun = 0;
        Mos_MutexDelete(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        return MOS_ERR;
    }
 
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud patch task start ok");
    return MOS_OK; 
}

_INT CloudStg_Patch_Stop()
{
    _VOID *pstMsg = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstPatchTaskNode   = MOS_NULL;
    if(CloudStg_Patch_GetMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Patch Already Stop");
        return MOS_OK;
    }
    CloudStg_Patch_GetMng()->ucRunFlag = 0;

    CloudStg_Trans_PatchStop();
    Mos_Sleep(3000);

    Mos_ThreadDelete(CloudStg_Patch_GetMng()->hMgrThread);
    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList , pstPatchTaskNode, stIterator)
    {
        CloudStg_Patch_RemoveItemFromTaskList(pstPatchTaskNode);
    }
    while((pstMsg = Mos_MsgQueuePop(CloudStg_Patch_GetMng()->hMsgQueue)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud patch task stop ok");
    return MOS_OK;
}

_INT CloudStg_Trans_PatchStop()
{
    ST_MECS_EXT_TASK *pstExtTask =  MOS_NULL;
    ST_CLOUDSTG_TASK_INF *pstTask = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    if (CloudStg_Trans_PatchGetMgr()->bRun == MOS_FALSE)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "has been stoped before");
        return MOS_OK;
    }
    CloudStg_Trans_PatchGetMgr()->bRun = MOS_FALSE;

    Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Trans_PatchGetMgr()->stTaskList, pstTask, stIterator)
    {
        CloudStg_ConnShutDown(pstTask->hCSConn);
    }
    Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    Mos_ThreadDelete(CloudStg_Trans_PatchGetMgr()->hThread);
    
    Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Trans_PatchGetMgr()->stTaskList, pstTask, stIterator)
    {
        MOS_LIST_RMVNODE(&CloudStg_Trans_PatchGetMgr()->stTaskList, pstTask);
        CloudStg_TransTaskClose(pstTask);
    }
    Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    
    Mos_MutexDelete(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    return MOS_OK;
}

_INT CloudStg_Patch_Destroy()
{
    if(CloudStg_Patch_GetMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Patch Already Destroy");
        return MOS_OK;
    }
    CloudStg_Patch_GetMng()->ucInitFlag = 0;
    Mos_MsgQueueDelete(CloudStg_Patch_GetMng()->hMsgQueue);
    CloudStg_Patch_GetMng()->hMsgQueue = MOS_NULL;

    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    MOS_LIST_RMVALL(&CloudStg_Patch_GetMng()->stPatchTaskList, MOS_TRUE);
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    Mos_MutexDelete(&CloudStg_Patch_GetMng()->hMutex);

    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud patch task destroy ok");
    return MOS_OK;
}

_INT CloudStg_Patch_AddItemToCfgTaskList(_INT iCamId, _INT iEventType, _INT iTaskType, _INT iStorageType, _INT iCloudUpLoadMode, _UI uiDuration, _UI uiMaxDuration, _CTIME_T tCreateTime, _CTIME_T tFailTime)
{
    // 补录时长间隔异常
    if (uiDuration >= CLOUDSTG_GET_ONEHOUR)
    {
        MOS_LOG_ERR(CLOUDSTG_PATCH_LOGSTR, "input error patch task: create time: %u, end time: %u, duration: %u", 
                    tCreateTime, tFailTime, uiDuration);
        return MOS_ERR;
    }

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskTmp  = MOS_NULL;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskPrv  = MOS_NULL;
    _CTIME_T cTimeTemp  = 0;
    _UC  pucUuid[17]    = {0};
    _UI  uiDurationTemp = 0;
    _UI  uiSubDuration  = 0;

    if (uiDuration < CLOUDSTG_PATCH_TASK_MIN_INTERVAL_SECOND)
    {
        MOS_LOG_ERR(CLOUDSTG_PATCH_LOGSTR,"This duration of task is too small to push in patch tasklist!");
    }

    // 有序插入
    while (uiDuration > 0)
    {

        uiSubDuration = (uiDuration>uiMaxDuration)?uiMaxDuration:uiDuration;
        tFailTime = tCreateTime + uiSubDuration;

        // 时间与当前的云存任务时间吻合，无需补录
        if (CloudStg_TaskIsNeedPatch(tCreateTime) == MOS_FALSE)
        {
            break;
        }
        else
        {
            Cloudstg_GetTimeMixUuid(pucUuid, sizeof(pucUuid));

            // 检查当前插入的事件云存会不会与前一个任务重叠
            if ((iCloudUpLoadMode == 1) && (CloudStg_GetConfig()->iEventCloudSwitch == 0))
            {
                pstPatchTaskTmp = MOS_LIST_GETTAIL(&Config_GetCloudMng()->stPatchTaskCfgList);

                // 前一个事件的结束时间大于当前的起始时间，则抛弃这条事件
                if (pstPatchTaskTmp != MOS_NULL && pstPatchTaskTmp->tFailTime > tCreateTime)
                {
                    MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "ignore these patch task, create time: %u, end time: %u, duration: %u", 
                                 tCreateTime, tFailTime, uiSubDuration);
                    break;
                }
            }
            
            // 添加新的节点到config中
            Config_AddOneCloudPatchInfoToCfgTaskList(pucUuid, iCamId, iEventType, iTaskType, 
                                        iStorageType, iCloudUpLoadMode, uiSubDuration, tCreateTime, 
                                        tFailTime);
                                        
            MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "push in new patch task: uuid: %s, create time: %u, end time: %u, duration: %u", 
                pucUuid, tCreateTime, tFailTime, uiSubDuration);
            uiDuration -= uiSubDuration;
            tCreateTime = tFailTime;
        }
    }

    Mos_MutexLock(&Config_GetCloudMng()->hCloudPatchMutex);
    {
        pstPatchTaskPrv = MOS_LIST_GETHEAD(&Config_GetCloudMng()->stPatchTaskCfgList);

        FOR_EACHDATA_INLIST(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskTmp, stIterator)
        {
            // 事件上报不合并
            if (((CloudStg_GetConfig()->iEventCloudSwitch == 0) && (pstPatchTaskTmp->iCloudUpLoadMode == 1 || pstPatchTaskPrv->iCloudUpLoadMode == 1)) || pstPatchTaskPrv == pstPatchTaskTmp)
            {
                pstPatchTaskPrv = pstPatchTaskTmp;
                continue;
            }

            // MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "pstPatchTaskPrv->tFailTime: %u, pstPatchTaskTmp->tCreateTime: %u", pstPatchTaskPrv->tFailTime, pstPatchTaskTmp->tCreateTime);
            
            // 两个补录存在相交部分
            if ((pstPatchTaskPrv->tFailTime - pstPatchTaskTmp->tCreateTime) > 0)
            {
                pstPatchTaskTmp->tCreateTime = pstPatchTaskPrv->tFailTime;

                cTimeTemp = pstPatchTaskTmp->tFailTime - pstPatchTaskTmp->tCreateTime;
                if (cTimeTemp <= 0)
                {
                    pstPatchTaskTmp->uiDuration  = 0;
                }
                else
                {
                    pstPatchTaskTmp->uiDuration  = cTimeTemp;
                }
                

                // 删除当前运行的task
                CloudStg_Patch_CloseAliveTaskWithUuid(pstPatchTaskTmp->pucUuid);

                if (pstPatchTaskTmp->uiDuration == 0)
                {
                    // 删除多余的节点，并同步config
                    Config_RemoveOneCloudPatchInfoFromCfgTaskList(pstPatchTaskTmp->pucUuid, pstPatchTaskTmp->iCamId);
                    pstPatchTaskPrv = pstPatchTaskPrv;
                    continue;
                }
                else
                {
                    MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "modify %u ~ %u, duration: %u", 
                                pstPatchTaskTmp->tCreateTime, 
                                pstPatchTaskTmp->tCreateTime + pstPatchTaskTmp->uiDuration, 
                                pstPatchTaskTmp->uiDuration);
                    Config_ModifyOneCloudPatchInfoFromCfgTaskList(pstPatchTaskTmp->pucUuid, pstPatchTaskTmp->iCamId, pstPatchTaskTmp->iEventType, pstPatchTaskTmp->iTaskType, 
                                        pstPatchTaskTmp->iStorageType, pstPatchTaskTmp->iCloudUpLoadMode, pstPatchTaskTmp->uiDuration, pstPatchTaskTmp->tCreateTime, 
                                        pstPatchTaskTmp->tFailTime);
                }
                // MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "delete the same duration");
            }

            // 两个补录不相交或相邻
            if ((MOS_ABS_NUM(((_CTIME_T)(pstPatchTaskTmp->tCreateTime - pstPatchTaskPrv->tFailTime))) <= 3) && pstPatchTaskPrv->uiDuration != uiMaxDuration)
            {
                // MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "pstPatchTaskTmp->tCreateTime: %u, pstPatchTaskPrv->tFailTime: %u", pstPatchTaskTmp->tCreateTime, pstPatchTaskPrv->tFailTime);
                pstPatchTaskTmp->tCreateTime = pstPatchTaskPrv->tFailTime;
                pstPatchTaskTmp->uiDuration  = pstPatchTaskTmp->tFailTime - pstPatchTaskTmp->tCreateTime;

                // 小于300s
                if (pstPatchTaskPrv->uiDuration + pstPatchTaskTmp->uiDuration < uiMaxDuration)
                {
                    MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "merge %u and %u to %u", 
                    pstPatchTaskPrv->uiDuration, pstPatchTaskTmp->uiDuration, 
                    pstPatchTaskPrv->uiDuration + pstPatchTaskTmp->uiDuration);

                    // 删除当前运行的task
                    CloudStg_Patch_CloseAliveTaskWithUuid(pstPatchTaskPrv->pucUuid);
                    CloudStg_Patch_CloseAliveTaskWithUuid(pstPatchTaskTmp->pucUuid);

                    // 合并短时长，并同步config
                    pstPatchTaskTmp->uiDuration += pstPatchTaskPrv->uiDuration;
                    pstPatchTaskTmp->tCreateTime = pstPatchTaskPrv->tCreateTime;
                    pstPatchTaskTmp->tFailTime   = pstPatchTaskTmp->tCreateTime + pstPatchTaskTmp->uiDuration;
                    Config_ModifyOneCloudPatchInfoFromCfgTaskList(pstPatchTaskTmp->pucUuid, pstPatchTaskTmp->iCamId, pstPatchTaskTmp->iEventType, pstPatchTaskTmp->iTaskType, 
                                        pstPatchTaskTmp->iStorageType, pstPatchTaskTmp->iCloudUpLoadMode, pstPatchTaskTmp->uiDuration, pstPatchTaskTmp->tCreateTime, 
                                        pstPatchTaskTmp->tFailTime);

                    MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "now new patch task: create time: %u, end time: %u, duration: %u", 
                    pstPatchTaskTmp->tCreateTime, pstPatchTaskTmp->tFailTime, pstPatchTaskTmp->uiDuration);

                    // 删除多余的节点，并同步config
                    Config_RemoveOneCloudPatchInfoFromCfgTaskList(pstPatchTaskPrv->pucUuid, pstPatchTaskPrv->iCamId);
                    pstPatchTaskPrv = pstPatchTaskTmp;
                    continue;
                }
                else
                {
                    // 删除当前运行的task
                    CloudStg_Patch_CloseAliveTaskWithUuid(pstPatchTaskPrv->pucUuid);

                    // 计算下一个duration的长度
                    uiDurationTemp = pstPatchTaskPrv->uiDuration + pstPatchTaskTmp->uiDuration - uiMaxDuration;

                    // 创建补录任务
                    pstPatchTaskPrv->uiDuration = uiMaxDuration;
                    pstPatchTaskPrv->tFailTime = pstPatchTaskPrv->tCreateTime + pstPatchTaskPrv->uiDuration;
                    Config_ModifyOneCloudPatchInfoFromCfgTaskList(pstPatchTaskPrv->pucUuid, pstPatchTaskPrv->iCamId, pstPatchTaskPrv->iEventType, pstPatchTaskPrv->iTaskType, 
                                        pstPatchTaskPrv->iStorageType, pstPatchTaskTmp->iCloudUpLoadMode, pstPatchTaskPrv->uiDuration, pstPatchTaskPrv->tCreateTime, 
                                        pstPatchTaskPrv->tFailTime);

                    MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "merge 300s patch task: create time: %u, end time: %u, duration: %u", 
                    pstPatchTaskPrv->tCreateTime, pstPatchTaskPrv->tFailTime, pstPatchTaskPrv->uiDuration);

                    // 创建另一个任务
                    if (uiDurationTemp != 0)
                    {
                        CloudStg_Patch_CloseAliveTaskWithUuid(pstPatchTaskTmp->pucUuid);

                        pstPatchTaskTmp->tCreateTime = pstPatchTaskPrv->tCreateTime + pstPatchTaskPrv->uiDuration;
                        pstPatchTaskTmp->uiDuration  = uiDurationTemp;
                        pstPatchTaskTmp->tFailTime = pstPatchTaskTmp->tCreateTime + pstPatchTaskTmp->uiDuration;
                        Config_ModifyOneCloudPatchInfoFromCfgTaskList(pstPatchTaskTmp->pucUuid, pstPatchTaskTmp->iCamId, pstPatchTaskTmp->iEventType, pstPatchTaskTmp->iTaskType, 
                                            pstPatchTaskTmp->iStorageType, pstPatchTaskTmp->iCloudUpLoadMode, pstPatchTaskTmp->uiDuration, pstPatchTaskTmp->tCreateTime, 
                                            pstPatchTaskTmp->tFailTime);

                        MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "another patch task: create time: %u, end time: %u, duration: %u", 
                        pstPatchTaskTmp->tCreateTime, pstPatchTaskTmp->tFailTime, pstPatchTaskTmp->uiDuration);
                    }
                }
            }
            pstPatchTaskPrv = pstPatchTaskTmp;
        }
    }
    // MOS_PRINTF("================list stPatchTaskCfgList===================");
    // FOR_EACHDATA_INLIST(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskTmp, stIterator)
    // {
    //     MOS_PRINTF("uuid: %s, create time: %u, end time: %u, duration: %u", 
    //         pstPatchTaskTmp->pucUuid, pstPatchTaskTmp->tCreateTime, pstPatchTaskTmp->tFailTime, pstPatchTaskTmp->uiDuration);
    // }
    // MOS_PRINTF("==========================================================");
    Mos_MutexUnLock(&Config_GetCloudMng()->hCloudPatchMutex);

    // MOS_LOG_WARN(CLOUDSTG_LOGSTR, "~~~~~~~~~~~~~~~~~~~~~~~~~~MOS_LIST_GETCOUNT:%d", MOS_LIST_GETCOUNT(&Config_GetCloudMng()->stPatchTaskCfgList));

    return MOS_OK;
}

_INT CloudStg_Patch_AddItemToTaskList(_UC *pucUuid, _INT iCamId, _INT iEventType, _INT iTaskType, _INT iStorageType, _INT iCloudUpLoadMode, _UI uiDuration, _CTIME_T tCreateTime, _CTIME_T tFailTime)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstPatchTaskTmp  = MOS_NULL;
    ST_CLOUDSTG_TASK_NODE *pstPatchTaskPrv  = MOS_NULL;
    ST_CLOUDSTG_TASK_NODE *pstPatchTaskNode = MOS_NULL;

    pstPatchTaskNode = (ST_CLOUDSTG_TASK_NODE*)Mos_MemAlloc(MOS_NULL,sizeof(ST_CLOUDSTG_TASK_NODE));
    MOS_MEMSET(pstPatchTaskNode, 0x00, sizeof(ST_CLOUDSTG_TASK_NODE));
    MOS_MEMSET(pstPatchTaskNode->pucUuid, 0x00, sizeof(pstPatchTaskNode->pucUuid));
    MOS_STRCPY(pstPatchTaskNode->pucUuid, pucUuid);
    pstPatchTaskNode->iCamId = iCamId;
    pstPatchTaskNode->iEventType = iEventType;
    pstPatchTaskNode->iTaskType = iTaskType;
    pstPatchTaskNode->iStorageType = iStorageType;
    pstPatchTaskNode->iCloudUpLoadMode = iCloudUpLoadMode;
    pstPatchTaskNode->uiDuration = uiDuration;
    pstPatchTaskNode->tCreateTime = tCreateTime;
    pstPatchTaskNode->tFailTime = tFailTime;

    pstPatchTaskNode->uiTotalCnt   = 0;
    pstPatchTaskNode->hStream      = MOS_NULL;
    pstPatchTaskNode->iStreamId    = 0;
    pstPatchTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NONE;
    pstPatchTaskNode->uiTotalStamp = uiDuration*1000;
    pstPatchTaskNode->iForceCommit = 0;
    pstPatchTaskNode->uiTaskId     = Mos_GetSessionId();
    pstPatchTaskNode->iTaskType    = EN_CLOUDSTG_RESOURCE_STREAM;
    pstPatchTaskNode->uiIconStatus = EN_CLOUDSTG_ICON_UPLOAD_TYPE_SUCCESS;
    pstPatchTaskNode->uiAllStamp   = 0;
    pstPatchTaskNode->uiLastStamp  = 0;
    MOS_MEMSET(&pstPatchTaskNode->u,0,sizeof(pstPatchTaskNode->u));
    MOS_MEMSET(&pstPatchTaskNode->stCommitInfo,0,sizeof(ST_CLOUDSTG_COMMITINFO));
    MOS_MEMSET(&pstPatchTaskNode->stEventInfo,0,sizeof(ST_CLOUDSTG_EVENT_INFO));
    pstPatchTaskNode->stCommitInfo.uiType = EN_CLOUDSTG_RESOURCE_STREAM;
    pstPatchTaskNode->stCommitInfo.cCreatTime = tCreateTime;
    pstPatchTaskNode->iState       = EN_CLOUDSTG_TASK_INIT;
    pstPatchTaskNode->iUseFlag     = 0;
    pstPatchTaskNode->tStartTime   = Mos_Time();
    pstPatchTaskNode->iCloudEncSwitch = -1;//标记未使用加密信息，重置设备运行后该值一开始可能为0
    pstPatchTaskNode->iDirectMode  = Config_GetCloudMng()->iDirectMode;
    pstPatchTaskNode->iExSentCount = 0;
    pstPatchTaskNode->iExLastSentInterval = 0;
    pstPatchTaskNode->uiFailInMid  = 0;
    pstPatchTaskNode->tFailInMidStartTime = 0;
    pstPatchTaskNode->iTotalSentCount = 0;
    pstPatchTaskNode->iRetrySentCount = 0;
    pstPatchTaskNode->uiAutoCommit    = 0;
    pstPatchTaskNode->tStsCreateTime  = 0;
    pstPatchTaskNode->uiIsPatch       = 1;
    if(Mos_SysGetDeviceAbility() == EN_MOS_DEVICE_ABILITY_POOR)
    {
        pstPatchTaskNode->uiMaxBuffNum = 400;
    }
    else
    {
        pstPatchTaskNode->uiMaxBuffNum = 1200;
    }
    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    // 添加新的节点并同步到config中
    MOS_LIST_ADDTAIL(&CloudStg_Patch_GetMng()->stPatchTaskList, pstPatchTaskNode);
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    // 创建补录云存任务，喂狗并刷新暂停时间
    CloudStg_Res_FeedWatchDog();
    return MOS_OK;
}

_INT CloudStg_Patch_RemoveItemFromTaskList(ST_CLOUDSTG_TASK_NODE *pstPatchTaskNode)
{
    MOS_PARAM_NULL_RETERR(pstPatchTaskNode);

    MOS_LIST_RMVNODE(&CloudStg_Patch_GetMng()->stPatchTaskList, pstPatchTaskNode);
    if(pstPatchTaskNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
    {
        CloudStg_PatchDestroyAliveNode(pstPatchTaskNode);
    }
    Mos_MemFree(pstPatchTaskNode);

    return MOS_OK;
}

_INT CloudStg_Patch_PreInit()
{
    if (CloudStg_Patch_GetMng()->iInitail == MOS_FALSE)
    {
        Mos_MutexCreate(&CloudStg_Patch_GetMng()->hMutex);
        MOS_LIST_INIT(&CloudStg_Patch_GetMng()->stPatchTaskList);
        CloudStg_Patch_GetMng()->iInitail = MOS_TRUE;
        CloudStg_Patch_MngPrvInit();
    }

    return MOS_OK;
}

_INT CloudStg_PatchDestroyAliveNode(ST_CLOUDSTG_TASK_NODE *pstAliveTaskNode)
{
    MOS_PARAM_NULL_RETERR(pstAliveTaskNode);
    ST_CLOUDSTG_RTIMEPARA *pstRtimeParam = &pstAliveTaskNode->u.stRTimePara;

    if(pstAliveTaskNode->hStream != MOS_NULL)
    {
        CloudStg_StreamClose(pstAliveTaskNode->hStream);
        pstAliveTaskNode->hStream = MOS_NULL;
    }

    if(pstRtimeParam->hMediaRead)
    {
        Media_RetrasSetFrameUsed(pstRtimeParam->hMediaRead);
        Media_RetrasDestroyReadHandle(pstRtimeParam->hMediaRead);
        pstRtimeParam->hMediaRead = MOS_NULL;
    }

    return MOS_OK;
}

static _INT CloudStg_PatchSendFirstFrame(ST_CLOUDSTG_TASK_NODE *pstTaskNode)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);

    _INT iRet = 0;
    _UI uiRetryCount = 0;
    _UC ucFrametype = 0;
    _UI uiTimeStamp = 0;
    _UI uiTimeStamp1 = 0;
    _UC ucAvType = 0;
    ST_FRAME_NODE *pMediaFrame = MOS_NULL;
    ST_CLOUDSTG_RTIMEPARA *pstRtimeParam = &pstTaskNode->u.stRTimePara;
    
    // 只发视频
    if(pstRtimeParam->hAudioRead == MOS_NULL) 
    {
        iRet = Media_RetrasGetFrame(pstRtimeParam->hMediaRead,&pMediaFrame,&ucAvType,&uiTimeStamp, MOS_TRUE);
        if (iRet < 0)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Media_RetrasGetFrame error, ret: %d", iRet);
            return MOS_ERR;
        }
        if (ucAvType == EN_ZJ_MEDIA_VIDEO)
        {
            if(pMediaFrame == MOS_NULL)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "can not find first frame");
                return MOS_ERR;
            }
            ucFrametype = MD_GETFRAMETYPE(pMediaFrame->ucFramPos);
            CloudStg_StreamSendVFrame(pstTaskNode->hStream,pMediaFrame,pMediaFrame->uiRemFrameLen,uiTimeStamp,ucFrametype, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
            Media_RetrasSetFrameUsed(pstRtimeParam->hMediaRead);
            return MOS_OK;
        }
    }
    uiRetryCount = 0;

    /*VIDEO*/
    if(pMediaFrame == MOS_NULL)
    {
        iRet = Media_RetrasGetFrame(pstRtimeParam->hMediaRead,&pMediaFrame,&ucAvType,&uiTimeStamp, MOS_TRUE);
        if (iRet < 0)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Media_RetrasGetFrame error, ret: %d", iRet);
            return MOS_ERR;
        }
    }
    // 如果获取不到视频则删除视频读句柄
    if(MOS_NULL == pMediaFrame)
    {
        ST_RDSTG_FILEDES pstMediaParm;
        ST_ZJ_AUDIO_PARAM *pstAudioParm = MOS_NULL;
        ST_CFG_VIDEODES   *pstVideo     = MOS_NULL;
        ST_MOS_SYS_TIME stSysTime1,stSysTime2;
        _UC aucStartTime[64] = {0};
        _UC aucEndTime[64] = {0};

        Media_RetrasSetFrameUsed(pstRtimeParam->hMediaRead);
        Media_RetrasDestroyReadHandle(pstRtimeParam->hMediaRead);
        pstRtimeParam->hMediaRead = MOS_NULL;

        Mos_TimetoSysTime(&pstTaskNode->tCreateTime,&stSysTime1);
        Mos_TimetoSysTime(&pstTaskNode->tFailTime,&stSysTime2);
        MOS_VSNPRINTF(aucStartTime,64,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                    stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond);
        MOS_VSNPRINTF(aucEndTime,64,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                    stSysTime2.usYear,stSysTime2.usMonth,stSysTime2.usDay,stSysTime2.usHour,stSysTime2.usMinute,stSysTime2.usSecond);

        pstRtimeParam->hMediaRead = Media_RetrasCreatReadHandle(pstTaskNode->iCamId, 0, pstTaskNode->tCreateTime, pstTaskNode->tFailTime, &pstAudioParm, &pstVideo);
        
        if (pstRtimeParam->hMediaRead == MOS_NULL)
        {
            MOS_LOG_ERR(CLOUDSTG_PATCH_LOGSTR, "Ready to remove this node from tasklist");
            Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
            Config_RemoveOneCloudPatchInfoFromCfgTaskList(pstTaskNode->pucUuid, pstTaskNode->iCamId);
            CloudStg_Patch_RemoveItemFromTaskList(pstTaskNode);
            Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
        }

        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "media handle %p can not find first frame",pstRtimeParam->hMediaRead);
        return MOS_ERR;
    }

    ucFrametype = MD_GETFRAMETYPE(pMediaFrame->ucFramPos); 
    CloudStg_ProcAliveTaskStatus(pstTaskNode,uiTimeStamp,ucFrametype,EN_ZJ_MEDIA_VIDEO,1);
    CloudStg_StreamSendVFrame(pstTaskNode->hStream,pMediaFrame,pMediaFrame->uiRemFrameLen,uiTimeStamp,ucFrametype, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
    Media_RetrasSetFrameUsed(pstRtimeParam->hMediaRead);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"send first frame stamp video:%u",uiTimeStamp);
    return MOS_OK;
}

_INT CloudStg_PatchAliveUploadProc(ST_CLOUDSTG_TASK_NODE *pstTaskNode)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);

    _INT iIndex       = 0;
    _INT iRet         = 0;
    _INT iRetCode     = 0;
    _UC ucFrametype   = 0;
    _INT iFrameCnt   = 0;
    _UI  uiTimeStamp  = 0;
    _UC ucAvType      = 0;
    _UC aucStartTime[64] = {0};
    _UC aucEndTime[64]   = {0};
    _UC aucMsg[128] = {0};
    _CTIME_T tTimeTmp = 0;
    ST_MOS_SYS_TIME stSysTime1,stSysTime2;
    ST_FRAME_NODE *pMediaFrame = MOS_NULL;
    ST_RDSTG_FILEDES pstMediaParm = {0};
    ST_CLOUDSTG_RTIMEPARA *pstRtimeParam = &pstTaskNode->u.stRTimePara;

    if (pstTaskNode->iOldState != pstTaskNode->iState)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"[patch taskid: %d]STATE: %d", pstTaskNode->uiTaskId, pstTaskNode->iState);
        pstTaskNode->iOldState = pstTaskNode->iState;
    }

    // 云存任务初始化
    if(pstTaskNode->iState == EN_CLOUDSTG_TASK_INIT)
    {
        ST_ZJ_AUDIO_PARAM *pstAudioParm = MOS_NULL;
        ST_CFG_VIDEODES   *pstVideo     = MOS_NULL;
        // 创建handle时会输入开始时间戳、结束时间戳，需要返回若干个（数组或链表）修正（靠近I帧或出现跨文件现象）的开始时间戳、结束时间戳。
        Mos_TimetoSysTime(&pstTaskNode->tCreateTime,&stSysTime1);
        Mos_TimetoSysTime(&pstTaskNode->tFailTime,&stSysTime2);
        MOS_VSNPRINTF(aucStartTime,64,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                    stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond);
        MOS_VSNPRINTF(aucEndTime,64,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                    stSysTime2.usYear,stSysTime2.usMonth,stSysTime2.usDay,stSysTime2.usHour,stSysTime2.usMinute,stSysTime2.usSecond);

        // 获取音频、视频句柄
        if(pstRtimeParam->hMediaRead == MOS_NULL)
        {
            MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "input aucStartTime: %s, aucEndTime: %s", aucStartTime, aucEndTime);
            pstRtimeParam->hMediaRead = Media_RetrasCreatReadHandle(pstTaskNode->iCamId, 0, &aucStartTime, &aucEndTime, &pstAudioParm, &pstVideo);
            MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "output aucStartTime: %s, raucEndTime: %s", aucStartTime, aucEndTime);
            
            if (pstRtimeParam->hMediaRead == MOS_NULL)
            {
                MOS_LOG_ERR(CLOUDSTG_PATCH_LOGSTR, "Ready to remove this node from tasklist");
                Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
                Config_RemoveOneCloudPatchInfoFromCfgTaskList(pstTaskNode->pucUuid, pstTaskNode->iCamId);
                CloudStg_Patch_RemoveItemFromTaskList(pstTaskNode);
                Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex); 
                CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_LOAD_FILE_ERR, "CD patch load file err", 1);
                return MOS_ERR;
            }
            // // 获取音频、视频参数 Modify to patch mode in late time.
            MOS_MEMSET(&stSysTime1, 0x00, sizeof(ST_MOS_SYS_TIME));
            MOS_MEMSET(&stSysTime2, 0x00, sizeof(ST_MOS_SYS_TIME));
            iRet = MOS_SSCANF(aucStartTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                &stSysTime1.usYear,&stSysTime1.usMonth,&stSysTime1.usDay,
                &stSysTime1.usHour,&stSysTime1.usMinute,&stSysTime1.usSecond);
            iRet = MOS_SSCANF(aucEndTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                &stSysTime2.usYear,&stSysTime2.usMonth,&stSysTime2.usDay,
                &stSysTime2.usHour,&stSysTime2.usMinute,&stSysTime2.usSecond);

            // modify time from return parameter
            tTimeTmp = Mos_SysTimetoTime(&stSysTime1);
            if (tTimeTmp != pstTaskNode->tCreateTime)
            {
                // pstTaskNode->tCreateTime = tTimeTmp + 1;
                pstTaskNode->tCreateTime = tTimeTmp;
            }
            tTimeTmp = Mos_SysTimetoTime(&stSysTime2);

            // Create new task
            if (pstTaskNode->tFailTime >= tTimeTmp + CLOUDSTG_PATCH_TASK_MIN_INTERVAL_SECOND)
            {
                CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, pstTaskNode->tFailTime - tTimeTmp, pstTaskNode->uiDuration, tTimeTmp, pstTaskNode->tFailTime);
            }
            pstTaskNode->tFailTime = tTimeTmp;
            pstTaskNode->uiDuration = pstTaskNode->tFailTime - pstTaskNode->tCreateTime;
            pstTaskNode->uiTotalStamp = pstTaskNode->uiDuration*1000;
            // MOS_PRINTF("pstTaskNode->tCreateTime: %u\r\npstTaskNode->tFailTime: %u\r\npstTaskNode->uiDuration: %d\r\npstTaskNode->uiTotalStamp: %u\r\n", pstTaskNode->tCreateTime, pstTaskNode->tFailTime, pstTaskNode->uiDuration, pstTaskNode->uiTotalStamp);
        }

        // 获取加密密钥参数
        CloudStg_GetCloudEncInfo(pstTaskNode);
        pstTaskNode->iLogCount = 0;

        // 打开获取音频、视频流
        if(pstTaskNode->hStream == MOS_NULL)
        {
            // 使用流直传模式
            pstTaskNode->hStream = CloudStg_StreamOpen(pstTaskNode->iCamId,pstTaskNode->uiTaskId,EN_CLOUDSTG_RESOURCE_STREAM,pstVideo->stVideoPara.uiBitrate,
                pstTaskNode->uiDuration,CloudStg_Patch_AliveSliceStatusCallBack,(_VPTR)pstTaskNode->uiTaskId, MOS_TRUE, pstTaskNode->iCloudEncSwitch, pstTaskNode->iDirectMode);     
            
            if (pstTaskNode->hStream == MOS_NULL)
            {
                #if 0
                Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
                Media_AudioDestroyReadHandle(pstRtimeParam->hAudioRead);
                #else
                Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
                Media_AudioDestroyReadHandle2(pstRtimeParam->hAudioRead);
                #endif

                #if 0
                Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
                Media_VideoDestroyReadHandle(pstRtimeParam->hVideoRead);
                #else
                Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
                Media_VideoDestroyReadHandle2(pstRtimeParam->hVideoRead);
                #endif
                return MOS_ERR;
            }
            
            CloudStg_StreamSetPara(pstTaskNode->hStream, pstVideo, pstAudioParm); 
        }

        pstTaskNode->iState = EN_CLOUDSTG_TASK_START;
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u start send media",pstTaskNode->uiTaskId);
    }
    // 云存任务开始
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_START)
    {
        if(pstRtimeParam->bSendFstFrame == MOS_FALSE)
        {
#if CLOUDSTG_NET_CHECK
            // 当处于无网络或配网模式时暂停任务
            if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
            {
                if(CloudStg_Patch_GetMng()->uiCurNetStatus == 1)
                {
                    CloudStg_Patch_GetMng()->tDisconnetTime = Mos_Time();
                    CloudStg_Patch_GetMng()->uiCurNetStatus = 0;
                    pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_LOCAL_FAIL;
                }
                pstTaskNode->iState = EN_CLOUDSTG_TASK_STOP;
                return iRetCode;
            }
#endif
            // 发送第一帧 I FRAME
            if(CloudStg_PatchSendFirstFrame(pstTaskNode) == MOS_ERR)
            {
                Media_RetrasSetFrameUsed(pstRtimeParam->hMediaRead);
                Media_RetrasDestroyReadHandle(pstRtimeParam->hMediaRead);
                pstRtimeParam->hMediaRead = MOS_NULL;

                Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
                Config_RemoveOneCloudPatchInfoFromCfgTaskList(pstTaskNode->pucUuid, pstTaskNode->iCamId);
                CloudStg_Patch_RemoveItemFromTaskList(pstTaskNode);
                Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
                return iRetCode;
            }
            pstRtimeParam->bSendFstFrame = MOS_TRUE;
            pstTaskNode->stEventInfo.tStartTime  = pstTaskNode->tCreateTime;
            pstTaskNode->stEventInfo.uiEventType = pstTaskNode->iEventType;
            pstTaskNode->stEventInfo.uiUseFlag = 1;
        }
        do
        {                    
            if ((pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS) && CloudStg_StreamGetBufListCacheNodeCount(pstTaskNode->hStream) >= 30)
            {
                Mos_Sleep(50);
                break;
            }
            else if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE && CloudStg_StreamGetBufListCacheNodeCount(pstTaskNode->hStream) >= pstTaskNode->uiMaxBuffNum)
            {
                Mos_Sleep(50);
                break;
            }
            else
            {
                iRet = Media_RetrasGetFrame(pstRtimeParam->hMediaRead,&pMediaFrame,&ucAvType,&uiTimeStamp, MOS_TRUE);
                if (iRet < 0)
                {
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Media_RetrasGetFrame error, ret: %d", iRet);
                    // FIXME: commit immediately
                    pstTaskNode->uiDuration = Mos_Time() - pstTaskNode->tCreateTime;
                    pstTaskNode->uiTotalStamp = pstTaskNode->uiDuration*1000;
                    pstTaskNode->iForceCommit = 1;
                    pstTaskNode->iState = EN_CLOUDSTG_TASK_STOP;
                    return MOS_ERR;
                }
            }
            if(pMediaFrame == MOS_NULL)
            {
                break;
            }
            // VIDEO
            if (ucAvType == EN_ZJ_MEDIA_VIDEO)
            {
                ucFrametype = MD_GETFRAMETYPE(pMediaFrame->ucFramPos); 
                // 获取状态
                if (CloudStg_ProcAliveTaskStatus(pstTaskNode,uiTimeStamp,ucFrametype,EN_ZJ_MEDIA_VIDEO, 1) == 11)
                {
                    break;
                }
                if(pstTaskNode->iState == EN_CLOUDSTG_TASK_STOP)
                {
                    break;
                }

                // 打包为PS，并发送
                CloudStg_StreamSendVFrame(pstTaskNode->hStream,pMediaFrame,pMediaFrame->uiRemFrameLen,uiTimeStamp,ucFrametype, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
            }
            // AUDIO
            else if (ucAvType == EN_ZJ_MEDIA_AUDIO)
            {
                CloudStg_StreamSendAFrame(pstTaskNode->hStream,pMediaFrame,uiTimeStamp, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
            }
            Media_RetrasSetFrameUsed(pstRtimeParam->hMediaRead);
            iRetCode++;
        }while(iFrameCnt++ < 5);
    }
    // 云存暂停
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_STOP)
    {
        _INT iRet = 0;
        ST_MOS_LIST_ITERATOR stIterator;
        ST_CLOUDSTG_TASK_NODE *pstTmpNode = MOS_NULL;

        pstTaskNode->iState = EN_CLOUDSTG_TASK_WAITING;

        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTmpNode, stIterator)
        {
            if(pstTmpNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
            {
                if(pstTmpNode->iUseFlag == 0)
                {
                    continue;
                }
                pstTaskNode->uiTotalCnt++;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

        // if (pstTaskNode->uiUploadFlag < EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL)
        {
            // 发送最后一包
            iRet = CloudStg_StreamSendLastData(pstTaskNode->hStream);
            if(iRet == MOS_ERR)
            {
                pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"send last data err");
            }
        }
        CloudStg_StreamClose(pstTaskNode->hStream);
        pstTaskNode->hStream      = MOS_NULL;

        if(pstRtimeParam->hMediaRead)
        {
            Media_RetrasSetFrameUsed(pstRtimeParam->hMediaRead);
            Media_RetrasDestroyReadHandle(pstRtimeParam->hMediaRead);
            pstRtimeParam->hMediaRead = MOS_NULL;
        }

        if(Config_GetCloudMng()->iCloudAbility == 1 && pstTaskNode->iCloudUpLoadMode == 2 
            && pstTaskNode->uiTotalCnt == 1 && CloudStg_Patch_GetMng()->uiCurNetStatus == 1)
        {
            ST_CLOUDSTG_TASK_NODE  *pstPatchTaskNodeTmp = MOS_NULL;

            Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
            pstPatchTaskNodeTmp = MOS_LIST_GETNEXT(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskNode);
            if (pstPatchTaskNodeTmp)
            {
                pstPatchTaskNodeTmp->iUseFlag = 1;
            }
            Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
        }
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u stop send file",pstTaskNode->uiTaskId);
    }
    // 云存任务等待上传结束
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_WAITING)
    {
        //  MOS_LOG_INF(CLOUDSTG_LOGSTR,"pstTaskNode->uiUploadFlag: %d", pstTaskNode->uiUploadFlag);
        if(pstTaskNode->uiUploadFlag >= EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS || Config_GetCloudMng()->iCloudAbility == 0)
        {
            pstTaskNode->iState = EN_CLOUDSTG_TASK_OVER;
        }
    }
    // 云存任务结束，释放句柄
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_OVER)
    {
        if(Config_GetCloudMng()->iCloudAbility == 1 && pstTaskNode->iCloudUpLoadMode == 2
            && pstTaskNode->uiTotalCnt > 1)
        {
            ST_CLOUDSTG_TASK_NODE  *pstPatchTaskNodeTmp = MOS_NULL;

            Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
            pstPatchTaskNodeTmp = MOS_LIST_GETNEXT(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskNode);
            if (pstPatchTaskNodeTmp)
            {
                pstPatchTaskNodeTmp->iUseFlag = 1;
            }
            Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
        }
        pstTaskNode->iState       = EN_CLOUDSTG_TASK_COMMINT;
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u send media over,uploadflag %u",pstTaskNode->uiTaskId,pstTaskNode->uiUploadFlag);
        return iRetCode;
    }
    
    // 云存commit
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_COMMINT || pstTaskNode->iState == EN_CLOUDSTG_TASK_COMMINTINF)
    {
        // 平台自动commit
        if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS && pstTaskNode->uiAutoCommit != 0)
        {
            pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
        }
        else
        {
            // 传首帧图片及
            if(((pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS) && pstTaskNode->uiIconStatus != EN_CLOUDSTG_ICON_UPLOAD_TYPE_SENT && pstTaskNode->uiUploadFlag < EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL) || 
            (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE && pstTaskNode->uiUploadFlag < EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL))
            {
                CloudStg_ProcGetMediaCommit(pstTaskNode, MOS_TRUE);
            }
            else
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"taskid %u commit fail, uiIconStatus: %d, uiUploadFlag: %d",pstTaskNode->uiTaskId,pstTaskNode->uiIconStatus,pstTaskNode->uiUploadFlag);
                pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
                pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
                Http_Httpclient_CancelAsyncRequestEx(pstTaskNode->uiTaskId);
            }
        }
    }

    // 云存结束
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_END)
    {
        CloudStg_GetMng()->iQualityTotalPatchSentBytes    += pstTaskNode->iAllSentBytes;
        CloudStg_GetMng()->iQualityTotalPatchSentInterval += pstTaskNode->uiDuration;
        if (pstTaskNode->uiUploadFlag == EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS && pstTaskNode->uiDuration != 0)
        {
            _INT iKiloByte     = 0;
            _UC aucLogBuf[512] = {0};
            _UC *pucCreateTime = MOS_NULL;
            _UC *pucEndTime    = MOS_NULL;
            
            iKiloByte = pstTaskNode->iAllSentBytes / 1024;
            pucCreateTime = Mos_PrintTime(pstTaskNode->tCreateTime);
            pucEndTime    = Mos_PrintTime(pstTaskNode->tCreateTime + pstTaskNode->uiDuration);
            if (pstTaskNode->uiConnType == EN_CINET_TYPE_IPV4)
            {
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud file patch request succeed ipv4");
            }
            else if (pstTaskNode->uiConnType == EN_CINET_TYPE_IPV6)
            {
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud file patch request succeed ipv6");
            }
            MOS_MEMSET(aucLogBuf, 0, sizeof(aucLogBuf));
            MOS_VSNPRINTF(aucLogBuf, sizeof(aucLogBuf), "CD [patch taskid: %u] type: video HTTP/1.1 200 OK, duration: %s ~ %s, enc switch: %d, size: %dKB, time: %ds, avg speed: %dKB/s, linkv%d, hasipv6addr: %d", 
                            pstTaskNode->uiTaskId, pucCreateTime, pucEndTime, pstTaskNode->iCloudEncSwitch==1?1:0, iKiloByte, pstTaskNode->uiDuration, pstTaskNode->uiDuration?(iKiloByte / pstTaskNode->uiDuration):0, 
                            pstTaskNode->uiConnType==EN_CINET_TYPE_IPV4?4:6, pstTaskNode->uiHasIpv6);
            // 用于统计设备是否具备IPv6地址
            if (MOS_STRLEN(Config_GetCamaraMng()->aucLocalIPv6Addr) > 0)
            {
                _UC aucStrcatBuf[128] = {0};
                MOS_SPRINTF(aucStrcatBuf, ", localv6: %s", Config_GetCamaraMng()->aucLocalIPv6Addr);
                MOS_STRCAT(aucLogBuf, aucStrcatBuf);
            }
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_VIDEO_UPLOAD_SUCCESS, aucLogBuf, 1);
            MOS_FREE(pucCreateTime);
            MOS_FREE(pucEndTime);

            MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "Remove pstTaskNode from pstTaskNode");
            Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
            Config_RemoveOneCloudPatchInfoFromCfgTaskList(pstTaskNode->pucUuid, pstTaskNode->iCamId);
            CloudStg_Patch_RemoveItemFromTaskList(pstTaskNode);
            Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
        }
        else
        {
            Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
            CloudStg_Patch_RemoveItemFromTaskList(pstTaskNode);
            Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
        }
    }
    return iRetCode;
}
_BOOL CloudStg_PatchTaskNeedConnUrl(_INT iIsDirectModeChange)
{
    ST_MOS_LIST_ITERATOR stIterator     = {0};
    ST_CLOUDSTG_TASK_NODE  *pstTaskNode = MOS_NULL;
    ST_CLOUDSTG_TASK_INF *pstTansTask   = MOS_NULL;
    ST_MECS_CONN *pstTansConn           = MOS_NULL;
    _BOOL bNeed                         = MOS_FALSE;

    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskNode, stIterator)
    {
        if (pstTaskNode->iUseFlag == 0)
        {
            continue;
        }

        // 云存task未使用加密信息，云存补录task加入链表后可能要等10分钟才会执行task
        if (iIsDirectModeChange == MOS_FALSE && pstTaskNode->iCloudEncSwitch == -1)
        {
            continue;
        }

        if (pstTaskNode->hStream)
        {
            Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
            // 获取指向的网络线程任务
            // CloudStg_ConnStart->CloudStg_ResAllocUrl->等待res线程获取url
            pstTansTask = (ST_CLOUDSTG_TASK_INF*)(((ST_CLOUDSTG_STREAM *)(pstTaskNode->hStream))->hCSTask);
            pstTansConn = (ST_MECS_CONN *)pstTansTask->hCSConn;
            if (pstTansConn)
            {
                // 云存模式改变
                if (iIsDirectModeChange == MOS_TRUE)
                {
                    // 还没开始传，可以立即结束
                    if (pstTansConn->pstConnUrl == MOS_NULL && pstTaskNode->iState <= EN_CLOUDSTG_TASK_START)
                    {
                        // MOS_PRINTF("%s connurl=null\n", __FUNCTION__);
                        bNeed = MOS_TRUE;
                        Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
                        break;
                    }
                }
                // 加密方式改变
                else
                {
                    if (pstTansConn->pstConnUrl == MOS_NULL)
                    {
                        // MOS_PRINTF("%s connurl=null\n", __FUNCTION__);
                        bNeed = MOS_TRUE;
                        Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
                        break;
                    }
                }
            }
            Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        }
        else
        {
            // MOS_PRINTF("%s stream=null\n", __FUNCTION__);
            bNeed = MOS_TRUE;
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    MOS_PRINTF("%s need=%d\n", __FUNCTION__, bNeed);
    return bNeed;
}
static _INT CloudStg_PatchTaskLoop(_VPTR pParam)
{
    _UI uiPatchTaskListCnt = 0;
    _UI uiAliveTaskCnt = 0;
    _INT iSentBytesPreSecond = 0;
    _INT iAllSentBytesTmp = 0;
    _INT iSentSpeed = 0;
    _INT iLoopFlag = 0;
    _INT iHourCount = 0;
    _VPTR pstMsg = MOS_NULL;
    _CTIME_T cNowTime = 0;
    _CTIME_T cOldTime = 0;
    _CTIME_T cOldTime1s = 0;
    _CTIME_T cOldTimeSwd = 0;
    _CTIME_T cAliveTime = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE  *pstPatchTaskNode = MOS_NULL;
    ST_CLOUDSTG_FILE_NODE  *pFileTaskNode = MOS_NULL;
    ST_CLOUDSTG_COMMITINFO *pstCommitNode = MOS_NULL;
    _HSWDWRITE hSwdFeedDog = MOS_NULL;

#if CLOUDSTG_NET_CHECK
    // 检测网络状态，通网才能继续
    do
    {
        if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET)
        {
            iLoopFlag++;
        }
        else if(Http_GetNetWorkType() != EN_ZJ_NETWORK_TYPE_AP)
        {
            break;
        }
        Mos_Sleep(1000);
    }while(iLoopFlag < 40);
#endif

    // 检测单元话调度是否已经成功获取过云存域名地址
    while (1)
    {
        if (MsgMng_GetStartWorkFlag() == 1)
        {
            break;
        }
        Mos_Sleep(1000);
    }

    hSwdFeedDog = Swd_AppThreadRegist(CLOUDSTG_PATCH_APP, FEED_DOG_MAX_TIMESEC);

    // _CTIME_T tStartTime = 1636514280;
    // _CTIME_T tEndTime   = 1636514400;
    // CloudStg_Patch_AddItemToCfgTaskList(0, 2, 1, 1, Config_GetCloudMng()->iCloudUpLoadMode, tEndTime - tStartTime, tStartTime, tEndTime);
    // MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "input demo CloudStg_Patch_AddItemToCfgTaskList");
    // FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstPatchTaskNode, stIterator)
    // {
    //     MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "uuid: %s, UseFlag: %d", pstPatchTaskNode->pucUuid, pstPatchTaskNode->iUseFlag);
    // }

    while(CloudStg_Patch_GetMng()->ucRunFlag == 1)
    {
        iLoopFlag = 0;
        uiAliveTaskCnt = 0;
        cNowTime = Mos_Time();

        // 喂狗
        if (MOS_ABS_NUM(cNowTime - cOldTimeSwd) >= 1)
        {
            cOldTimeSwd = cNowTime;
            Swd_AppThreadFeedDog(hSwdFeedDog);
        }

        // 设备无网络或AP模式中
        if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
        {
            Mos_Sleep(1000);
            continue;
        }

        // 获取消息
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstPatchTaskNode, stIterator)
        {
            // 未使用
            if(pstPatchTaskNode->iUseFlag == 0)
            {
                continue;
            }
            // 正在使用
            else if(pstPatchTaskNode->iState <= EN_CLOUDSTG_TASK_STOP)
            {
                uiAliveTaskCnt++;
            }
            
            // 当前时间要比补录时间多10分钟才能开始补录
            if (pstPatchTaskNode->tFailTime + CLOUDSTG_PATCH_TASK_BEFORE_START_SECOND < cNowTime)
            {
                // 开始云存上传流程
                if(CloudStg_ProcMediaUpdate(pstPatchTaskNode, MOS_TRUE) <= 0)
                {
                    iLoopFlag = 1;
                }
            }
        }

        if(Config_GetCloudMng()->iCloudAbility == 1 && CloudStg_GetMng()->iOpenFlag == 1)
        {
            Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
            uiPatchTaskListCnt = MOS_LIST_GETCOUNT(&CloudStg_Patch_GetMng()->stPatchTaskList);
            Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

            // 当前无任务运行，从保存列表中取出一节点放入内存列表中运行(需要连接信令服务器成功，防止设备长时间图断线导致双云存同时运行消耗大量内存) 等待请求一次getul
            if (uiAliveTaskCnt == 0 && uiPatchTaskListCnt == 0 && MsgMng_GetCmdServer()->ucLoginFlag == 2 && Config_GetCloudMng()->iAfterReqUrlFlag == 1 && CloudStg_Patch_GetMng()->ucStopFlag == 0)
            {
                ST_CLOUDSTG_TASK_NODE  *pstPatchTaskNodeTmp = MOS_NULL;

                Mos_MutexLock(&Config_GetCloudMng()->hCloudPatchMutex);
                ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskNode = (ST_CFG_CLOUDSTG_PATCH_MNG *)MOS_LIST_GETHEAD(&Config_GetCloudMng()->stPatchTaskCfgList);
                if (pstPatchTaskNode)
                {
                    // 删除超过24小时的任务
                    if (pstPatchTaskNode->tCreateTime + CLOUDSTG_PATCH_TASK_AVAILABLE_HOURS < cNowTime)
                    {
                        Config_RemoveOneCloudPatchInfoFromCfgTaskList(pstPatchTaskNode->pucUuid, pstPatchTaskNode->iCamId);
                    }
                    else
                    {
                        CloudStg_Patch_AddItemToTaskList(pstPatchTaskNode->pucUuid, pstPatchTaskNode->iCamId, pstPatchTaskNode->iEventType, 
                                        pstPatchTaskNode->iTaskType, pstPatchTaskNode->iStorageType, pstPatchTaskNode->iCloudUpLoadMode, pstPatchTaskNode->uiDuration, 
                                        pstPatchTaskNode->tCreateTime, pstPatchTaskNode->tFailTime);

                        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
                        pstPatchTaskNodeTmp = MOS_LIST_GETHEAD(&CloudStg_Patch_GetMng()->stPatchTaskList);
                        if (pstPatchTaskNodeTmp)
                        {
                            pstPatchTaskNodeTmp->iUseFlag = 1;
                        }
                        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
                    }
                }
                Mos_MutexUnLock(&Config_GetCloudMng()->hCloudPatchMutex);
            }

            // 60秒打印一次
            if (MOS_ABS_NUM(cNowTime - cOldTime) >=  CLOUDSTG_GET_ONEMINUTE)
            {
                cOldTime = cNowTime;

                Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
                FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstPatchTaskNode, stIterator)
                {
                    if(pstPatchTaskNode->iUseFlag == 0)
                    {
                        continue;
                    }
                    if (cNowTime != pstPatchTaskNode->tStartTime)
                    {
                        cAliveTime = MOS_ABS_NUM(cNowTime - pstPatchTaskNode->tStartTime);
                        if (cAliveTime != 0)
                        {
                            MOS_LOG_INF(CLOUDSTG_LOGSTR,"[patch taskid: %d]STATE: %d, directmode: %d, alivetime: %us, buflist: %d, speed: %dKB/s", 
                                        pstPatchTaskNode->uiTaskId, pstPatchTaskNode->iState, pstPatchTaskNode->iDirectMode, cAliveTime,
                                        CloudStg_StreamGetBufListCacheNodeCount(pstPatchTaskNode->hStream),
                                        (pstPatchTaskNode->iAllSentBytes / 1024) / cAliveTime);
                        }
                    }
                }
                Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
            }
#if CLOUDSTG_PATCH_LIMIT_BANDWIDTH
            if (MOS_ABS_NUM(cNowTime - cOldTime1s) >= CLOUDSTG_GET_TENSECONDS)
            {
                cOldTime1s = cNowTime;

                // 6小时清除一次限速参数
                if (((iHourCount++) * CLOUDSTG_GET_TENSECONDS) >= CLOUDSTG_GET_SIXHOUR)
                {
                    iHourCount = 0;
                    CloudStg_Patch_GetMng()->iSleepTime = 1;
                    CloudStg_Patch_GetMng()->ucStopFlag = 0;
                    CloudStg_Patch_GetMng()->iLimitBandWidth = (CloudStg_Patch_GetMng()->iLimitBandWidthBak + CloudStg_Patch_GetMng()->iLimitBandWidth) / 2;
                    MOS_LOG_WARN(CLOUDSTG_LOGSTR, "restore sleep time: %d, limit bandwidth: %d", CloudStg_Patch_GetMng()->iSleepTime, CloudStg_Patch_GetMng()->iLimitBandWidth);
                }
                Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
                FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstPatchTaskNode, stIterator)
                {
                    if (pstPatchTaskNode->iUseFlag == 0)
                    {
                        continue;
                    }
                    if (pstPatchTaskNode->iAllSentBytes >= iAllSentBytesTmp)
                    {
                        iSentBytesPreSecond = pstPatchTaskNode->iAllSentBytes - iAllSentBytesTmp;
                        iAllSentBytesTmp = pstPatchTaskNode->iAllSentBytes;
                        iSentSpeed = (iSentBytesPreSecond / 1024) / CLOUDSTG_GET_TENSECONDS;
                    }
                    else
                    {
                        iAllSentBytesTmp = 0;
                        iSentSpeed = 0;
                    }
                    // 需要限速处理
                    if (iSentSpeed > CloudStg_Patch_GetMng()->iLimitBandWidth)
                    {
                        CloudStg_Patch_GetMng()->iSleepTime = 1 + CloudStg_Patch_GetMng()->iSleepTime * 1.05;
                        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "[patch taskid: %u] current speed: %dKB/s, sleep time adpat to %d\r\n", pstPatchTaskNode->uiTaskId, iSentSpeed, CloudStg_Patch_GetMng()->iSleepTime);
                    }
                }
                Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
            }
#endif
        }

        if(iLoopFlag > 0)
        {
            Mos_Sleep(10);
        }
        else
        {
            Mos_Sleep(50);
        }
    }

    Swd_AppThreadUnRegist(hSwdFeedDog);

    return MOS_OK;
}

_INT CloudStg_Trans_PatchProc(_VPTR pParam)
{ 
    _UI uiSleep       = 0;
    _UI uiDelayCount  = 0;
    _UI uiDelayTime   = 1;
    _CTIME_T ctime    = 0;
    _CTIME_T cOldTime = 0;
    _INT iCountSize   = 0;
    // 等待获取DeviceId
    CloudStg_Trans_PatchGetDeviceId();

    // 当状态为True，则运行
    while(CloudStg_Trans_PatchGetMgr()->bRun)
    {
        uiSleep++;
        if(uiSleep%8 == 0)
        {
            ctime = Mos_Time();
        }

        // 进行上传流程
        CloudStg_Trans_PatchProcessTask(CloudStg_Trans_PatchGetMgr(), ctime);

        Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        iCountSize = MOS_LIST_GETCOUNT(&CloudStg_Trans_PatchGetMgr()->stTaskList);
        Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        // 没有任务可睡眠更长时间
        if(iCountSize == 0)
        {
            Mos_Sleep(100);
        }
#if CLOUDSTG_PATCH_LIMIT_BANDWIDTH
        else
        {
            Mos_Sleep(10 * CloudStg_Patch_GetMng()->iSleepTime);
        }
#else
        else if(uiSleep%10 == 0)
        {
            Mos_Sleep(10 * uiDelayTime);
        }
#endif

        if (MOS_ABS_NUM(ctime - cOldTime) >= CLOUDSTG_GET_TENSECONDS)
        {
            cOldTime = ctime;
            uiDelayCount = 0;

            // TODO: 添加视频流路数
            if (0)
            {
                uiDelayCount++;
                uiDelayTime = uiDelayCount * 5;
            }
        }
    }
    return MOS_OK;
}

static _INT CloudStg_Trans_PatchProcessTask(ST_CLOUDSTG_TRANS_MGR *pstCloudTransMgr,_CTIME_T ctime)
{
    MOS_PARAM_NULL_RETERR(pstCloudTransMgr);

    _INT iCount = 0;
    _INT iNetCheckFlag = 0;
    static _CTIME_T cOldtime = 0;
    ST_CLOUDSTG_TASK_INF *pstTask = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator = {0};

    if (MOS_ABS_NUM(ctime - cOldtime) >= CLOUDSTG_BUF_SPEED_DETECT_TIMEOUT)
    {
        cOldtime = ctime;
        iNetCheckFlag = 1;
    }

    // 遍历stTaskList链表
    Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    FOR_EACHDATA_INLIST(&pstCloudTransMgr->stTaskList,pstTask,stIterator)
    {
        Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        if (pstCloudTransMgr->bRun)
        {
            if (pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
            {
                iCount += CloudStg_TransTaskProcEx(pstTask,ctime, MOS_TRUE, iNetCheckFlag);
            }
            else if (pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
            {
                iCount += CloudStg_TransTaskProc(pstTask,ctime, MOS_TRUE);
            }
        }
        Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    }
    Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
    return iCount;
}

// pstTask->pFunSliceSend patch
_INT CloudStg_Patch_AliveSliceStatusCallBack(_VPTR vpBase,_UI uiStatus,_UC *pucFid,_UC *pucETag,_UI uiTargetSize,_UC *pucBucket,_UC *pucStorageProvider)
{
    // MOS_PARAM_NULL_RETERR(pucFid);
    // MOS_PARAM_NULL_RETERR(pucETag);
    // MOS_PARAM_NULL_RETERR(pucBucket);
    // MOS_PARAM_NULL_RETERR(pucStorageProvider);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->uiTaskId == (_UI)vpBase)
        {
            if(uiStatus == 400 || MOS_STRLEN(pucETag) == 0)
            {
                pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
                if(pstTaskNode->iState < EN_CLOUDSTG_TASK_STOP)
                {
                    pstTaskNode->iState = EN_CLOUDSTG_TASK_STOP;
                }
                pstTaskNode->stEventInfo.tBreakTime = Mos_Time();
                Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"status 400");
                return MOS_OK;
            }
            MOS_STRLCPY(pstTaskNode->stCommitInfo.aucObjId,pucFid,sizeof(pstTaskNode->stCommitInfo.aucObjId));
            MOS_STRLCPY(pstTaskNode->stCommitInfo.aucETag,pucETag,sizeof(pstTaskNode->stCommitInfo.aucETag));
            pstTaskNode->stCommitInfo.uiFileLen = uiTargetSize;
            MOS_STRLCPY(pstTaskNode->stCommitInfo.aucFileCId,pucBucket,sizeof(pstTaskNode->stCommitInfo.aucFileCId));
            MOS_STRLCPY(pstTaskNode->stCommitInfo.aucFileSP,pucStorageProvider,sizeof(pstTaskNode->stCommitInfo.aucFileSP));
            pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS;
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u tunnel to over ",pstTaskNode->uiTaskId);
        }
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    return MOS_OK;
}

_VOID CloudStg_Trans_PatchGetDeviceId()
{
    ST_CFG_SYSTEM_MNG * pstCompanyInfo = Config_GetSystemMng();
    do
    {
        if(MOS_STRLEN(pstCompanyInfo->aucDid) > 0)
        {
            MOS_STRLCPY(CloudStg_Trans_PatchGetMgr()->aucDid, pstCompanyInfo->aucDid, sizeof(CloudStg_Trans_PatchGetMgr()->aucDid));
            break;
        }
        Mos_Sleep(100);
    }while(CloudStg_Trans_PatchGetMgr()->bRun);
    
    return;
}

_INT CloudStg_Patch_CloseAliveTaskWithUuid(_UC *pucUuid)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    // MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "needed delete patch task, uuid: %s", pucUuid);
    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskNode, stIterator)
    {

        // MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "find running patch task, uuid: %s", pstTaskNode->pucUuid);
        // 找到对应的uuid
        if (MOS_STRCMP(pucUuid, pstTaskNode->pucUuid) == 0)
        {
            CloudStg_Patch_RemoveItemFromTaskList(pstTaskNode);
            // MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "delete running patch task, uuid: %s", pucUuid);
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    return MOS_OK;
}

_INT CloudStg_Patch_DeleteTaskWithTime(_CTIME_T cCreateTime)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskNode, stIterator)
    {
        // 找到对应的CreateTime
        if (pstTaskNode->tCreateTime == cCreateTime)
        {
            MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "delete repeat patch task, uuid: %s", pstTaskNode->pucUuid);
            Config_RemoveOneCloudPatchInfoFromCfgTaskList(pstTaskNode->pucUuid, pstTaskNode->iCamId);
            CloudStg_Patch_RemoveItemFromTaskList(pstTaskNode);
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    return MOS_OK;
}

_INT CloudStg_Patch_DesLimitBandWidth(float fRate)
{
#if CLOUDSTG_PATCH_LIMIT_BANDWIDTH
    if (CloudStg_Patch_GetMng()->ucStopFlag == 1)
    {
        return MOS_OK;
    }
    CloudStg_Patch_GetMng()->iLimitBandWidth *= fRate;
    if (CloudStg_Patch_GetMng()->iLimitBandWidth < 10)
    {
        CloudStg_Patch_GetMng()->iLimitBandWidth = 10;
        CloudStg_Patch_GetMng()->ucStopFlag      = 1; 
    }
    MOS_LOG_WARN(CLOUDSTG_LOGSTR, "auto decrease limited bandwidth of patch cloud to %d, stop flag: %d\r\n", CloudStg_Patch_GetMng()->iLimitBandWidth, CloudStg_Patch_GetMng()->ucStopFlag);
#endif
    return MOS_OK;
}
