#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_crypto_adapt.h"
#include "config_api.h"
#include "record_api.h"
#include "http_api.h"
#include "media_cache_api.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_manage.h"
#include "cloudstg_aliveupload.h"
#include "cloudstg_transaddress.h"
#include "cloudstg_event.h"
#include "cloudstg_patch.h"
#include "cloudstg_stream_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "cloudstg_config.h"

#define AUDIO_VIDEO_SYNC 1 // 音视频同步开关
#define DEBUG 0 // 保存帧数据及当时的变量值
#if DEBUG
    FILE *fp = MOS_NULL;
    FILE *fpd = MOS_NULL;
    FILE *fp1 = MOS_NULL;
    FILE *fpd1 = MOS_NULL;
    _UC aucBuff[256] = {0};
    _UC aucBuffDesc[256] = {0};
    _UC aucBuff1[256] = {0};
    _UC aucBuffDesc1[256] = {0};
    _UC aucData[512] = {0};
#endif
// #define USE_SUB_STREAM

/*********************************************************************************/

ST_CLOUDSTG_TASK_NODE *CloudStg_OpenAliveTask(_INT iCamID,_INT iStreamId,_INT iStoreType,_CTIME_T tCreatTime,_UI uiDuration)
{
    _UI uiSubTime = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
    
    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
    {
        if(pstTaskTmp->iUseFlag == 0)
        {
            pstTaskNode = pstTaskTmp;
        }
        else if(pstTaskTmp->iState <= EN_CLOUDSTG_TASK_STOP && pstTaskTmp->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
        {
            Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
            return MOS_NULL;
        }
    }

    // 添加视频上传任务
    if(pstTaskNode == MOS_NULL)
    {
        pstTaskNode = (ST_CLOUDSTG_TASK_NODE*)Mos_MemAlloc(MOS_NULL,sizeof(ST_CLOUDSTG_TASK_NODE));
        MOS_MEMSET(pstTaskNode, 0, sizeof(ST_CLOUDSTG_TASK_NODE));
        MOS_LIST_ADDTAIL(&CloudStg_GetMng()->stTaskList, pstTaskNode);
    }
    MOS_MEMSET(pstTaskNode->pucUuid, 0, sizeof(pstTaskNode->pucUuid));
    pstTaskNode->uiTotalCnt   = 0;
    pstTaskNode->iCamId       = iCamID;
    pstTaskNode->hStream      = MOS_NULL;
    pstTaskNode->iStreamId    = iStreamId;
    pstTaskNode->iStorageType = iStoreType;
    pstTaskNode->iCloudUpLoadMode = Config_GetCloudMng()->iCloudUpLoadMode;
    pstTaskNode->uiDuration   = uiDuration;
    pstTaskNode->tCreateTime  = tCreatTime;
    pstTaskNode->tFailTime    = 0; 
    pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NONE;
    pstTaskNode->uiTotalStamp = uiDuration*1000;
    pstTaskNode->iForceCommit = 0;
    pstTaskNode->uiTaskId     = Mos_GetSessionId();
    pstTaskNode->iTaskType    = EN_CLOUDSTG_RESOURCE_STREAM;
    pstTaskNode->uiIconStatus = EN_CLOUDSTG_ICON_UPLOAD_TYPE_NONE;
    pstTaskNode->uiAllStamp   = 0;
    pstTaskNode->uiLastStamp  = 0;
    MOS_MEMSET(&pstTaskNode->u,0,sizeof(pstTaskNode->u));
    MOS_MEMSET(&pstTaskNode->stCommitInfo,0,sizeof(ST_CLOUDSTG_COMMITINFO));
    MOS_MEMSET(&pstTaskNode->stEventInfo,0,sizeof(ST_CLOUDSTG_EVENT_INFO));
    pstTaskNode->stCommitInfo.uiType = EN_CLOUDSTG_RESOURCE_STREAM;
    pstTaskNode->stCommitInfo.cCreatTime = tCreatTime;
    pstTaskNode->iState       = EN_CLOUDSTG_TASK_INIT;
    pstTaskNode->iUseFlag     = 1;
    pstTaskNode->iAllSentBytes= 0;
    pstTaskNode->iCloudEncSwitch = -1;//标记未使用加密信息，重置设备运行后该值一开始可能为0
	pstTaskNode->uiSliceStamp = 0;
    pstTaskNode->iDirectMode  = Config_GetCloudMng()->iDirectMode; // 赋值全局变量
    pstTaskNode->iExSentCount = 0;
    pstTaskNode->iExLastSentInterval = 0;
    pstTaskNode->uiFailInMid  = 0;
    pstTaskNode->tFailInMidStartTime = 0;
    pstTaskNode->iTotalSentCount = 0;
    pstTaskNode->iRetrySentCount = 0;
    pstTaskNode->uiAutoCommit    = 0;
    pstTaskNode->tStsCreateTime  = 0;
    pstTaskNode->uiIsPatch       = 0;
    // 事件云存追加信息填充
    MOS_MEMSET(&pstTaskNode->stEventCloud, 0, sizeof(ST_CLOUDSTG_EVENTCLOUD));
    if ((pstTaskNode->iCloudUpLoadMode == CLOUDSTG_UPLOAD_MODE_EVENT) && 
        (CloudStg_GetConfig()->iEventCloudSwitch == 1))
    {
        pstTaskNode->stEventCloud.iSwitch     = CloudStg_GetConfig()->iEventCloudSwitch;
        pstTaskNode->stEventCloud.iMaxTime    = CloudStg_GetConfig()->iEventCloudMaxTime;
        pstTaskNode->stEventCloud.iMinTime    = CloudStg_GetConfig()->iEventCloudMinTime;
        pstTaskNode->stEventCloud.iDetectTime = CloudStg_GetConfig()->iEventCloudDetectTime;
        pstTaskNode->stEventCloud.iAppendTime = CloudStg_GetConfig()->iEventCloudAppendTime;
    }
    if(Mos_SysGetDeviceAbility() == EN_MOS_DEVICE_ABILITY_POOR)
    {
        pstTaskNode->uiMaxBuffNum = 400;
    }
    else
    {
        pstTaskNode->uiMaxBuffNum = 1200;
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    // 删除补录相同create时间
    CloudStg_Patch_DeleteTaskWithTime(pstTaskNode->tCreateTime);

    // 记录一次事件云存上传
    Cloudstg_IncEventCloudUpload(tCreatTime);

    return pstTaskNode;
}


_VOID CloudStg_StopAliveTask(_UI uiCamId,_UI iStreamId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->iState == EN_CLOUDSTG_TASK_INIT)
        {
            pstTaskNode->iUseFlag = 0;
        }
        else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_START)
        {
            pstTaskNode->uiTotalStamp = pstTaskNode->uiAllStamp ;
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    return;
}

_INT CloudStg_AliveUploadProc(ST_CLOUDSTG_TASK_NODE *pstTaskNode)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);

    _INT iIndex        = 0;
    _INT iRetCode      = 0;
    _INT iFrameCnt     = 0;
    _INT iRetryCount   = 0;
    _UC  ucFrametype   = 0;
    _UI  uiIdrDuration = 0;
    _UI  uiTimeStamp   = 0;
    _UI  uiTimeStamp1  = 0;
    _LLID llTimePts    = 0;
    _INT iDataLen      = 0;
    static _UI  uiPrintCount   = 0;
    _CTIME_T tTmpTimestamp     = 0;
    ST_FRAME_NODE *pVideoFrame = MOS_NULL;
    ST_FRAME_NODE *pAudioFrame = MOS_NULL;
    ST_CLOUDSTG_RTIMEPARA *pstRtimeParam = &pstTaskNode->u.stRTimePara;
    MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstRtimeParam, CloudStg_AliveUploadProc);

    if (pstTaskNode->iOldState != pstTaskNode->iState)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"[taskid: %d]STATE: %d", pstTaskNode->uiTaskId, pstTaskNode->iState);
        pstTaskNode->iOldState = pstTaskNode->iState;
    }

    // 云存任务初始化
    if(pstTaskNode->iState == EN_CLOUDSTG_TASK_INIT)
    {
        // 获取音频、视频参数
        ST_ZJ_AUDIO_PARAM *pstAudioParm = Config_GetCamAudioParm(0);
        #ifdef USE_SUB_STREAM
        pstTaskNode->iStreamId = 1;
        #endif
        ST_CFG_VIDEODES   *pstVideo     = Config_GetVideoDes(pstTaskNode->iCamId,pstTaskNode->iStreamId);
        pstRtimeParam->bSendFstFrame    = MOS_FALSE; 
        if(pstVideo == MOS_NULL)
        {
            pstTaskNode->iStreamId = 0;
            #ifdef USE_SUB_STREAM
            pstTaskNode->iStreamId = 1;
            #endif
            pstVideo = Config_GetVideoDes(pstTaskNode->iCamId,pstTaskNode->iStreamId);
        }

        // 获取音频、视频句柄
        if(pstRtimeParam->hAudioRead == MOS_NULL)
        {
            MOS_PRINTF("%s %d creat audio hander!!\n", __FUNCTION__, __LINE__);
            if (CloudStg_GetMng()->ucCameraStatusChangeFlag == 1)
            {
                pstRtimeParam->hAudioRead = Media_AudioCreatReadHandle2(0,EN_READ_NEWKEY, __FUNCTION__);
            }
            else
            {
                pstRtimeParam->hAudioRead = Media_AudioCreatReadHandle2(0,(pstTaskNode->iCloudUpLoadMode==CLOUDSTG_UPLOAD_MODE_EVENT)?EN_READ_PRE:EN_READ_NEWKEY, __FUNCTION__);
            }
            MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstRtimeParam->hAudioRead, Media_AudioCreatReadHandle2);
        }
        if(pstRtimeParam->hVideoRead == MOS_NULL)
        {
            if (CloudStg_GetMng()->ucCameraStatusChangeFlag == 1)
            {
                CloudStg_GetMng()->ucCameraStatusChangeFlag = 0;
                pstRtimeParam->hVideoRead = Media_VideoCreatReadHandle2(pstTaskNode->iCamId,pstTaskNode->iStreamId,EN_READ_NEWKEY,EN_ZJ_KEYFRAME_QUALITY_NORMAL, __FUNCTION__);
            }
            else
            {
                pstRtimeParam->hVideoRead = Media_VideoCreatReadHandle2(pstTaskNode->iCamId,pstTaskNode->iStreamId, (pstTaskNode->iCloudUpLoadMode==CLOUDSTG_UPLOAD_MODE_EVENT)?EN_READ_PRE:EN_READ_NEWKEY,EN_ZJ_KEYFRAME_QUALITY_NORMAL, __FUNCTION__);
            }
            MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstRtimeParam->hVideoRead, Media_VideoCreatReadHandle2);
        }
        
        // 获取加密密钥
        CloudStg_GetCloudEncInfo(pstTaskNode);
        pstTaskNode->iLogCount = 0;

        // 打开获取音频、视频流
        if(pstTaskNode->hStream == MOS_NULL)
        {
            MOS_PRINTF("👇👇👇👇alive task id %u ready to open chan task👇👇👇👇\r\n", pstTaskNode->uiTaskId);
            pstTaskNode->hStream = CloudStg_StreamOpen(pstTaskNode->iCamId,pstTaskNode->uiTaskId,EN_CLOUDSTG_RESOURCE_STREAM,pstVideo->stVideoPara.uiBitrate,
                pstTaskNode->uiDuration,CloudStg_AliveSliceStatusCallBack,(_VPTR)pstTaskNode->uiTaskId, MOS_FALSE, pstTaskNode->iCloudEncSwitch, pstTaskNode->iDirectMode);

            if (pstTaskNode->hStream == MOS_NULL)
            {
                #if 0
                Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
                Media_AudioDestroyReadHandle(pstRtimeParam->hAudioRead);
                #else
                Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
                Media_AudioDestroyReadHandle2(pstRtimeParam->hAudioRead);
                #endif

                #if 0
                Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
                Media_VideoDestroyReadHandle(pstRtimeParam->hVideoRead);
                #else
                Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
                Media_VideoDestroyReadHandle2(pstRtimeParam->hVideoRead);
                #endif
                return MOS_ERR;
            }

            CloudStg_StreamSetPara(pstTaskNode->hStream,pstVideo,pstAudioParm);
        }

        pstTaskNode->iState = EN_CLOUDSTG_TASK_START;
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u start send media",pstTaskNode->uiTaskId);
    }
    // 云存任务开始
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_START)
    {
        // 检测是否需要强制commit, 如果是则设置STATE为STOP
        CloudStg_DetectForceCommit(pstTaskNode, 0);
        
        if(pstRtimeParam->bSendFstFrame == MOS_FALSE)
        {
#if CLOUDSTG_NET_CHECK
            // 当处于无网络或配网模式时暂停任务
            if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET || Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_AP)
            {
                if(CloudStg_GetMng()->uiCurNetStatus == 1)
                {
                    CloudStg_GetMng()->tDisconnetTime = Mos_Time();
                    CloudStg_GetMng()->uiCurNetStatus = 0;
                    pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_LOCAL_FAIL;
                }
                pstTaskNode->iState = EN_CLOUDSTG_TASK_STOP;
                return iRetCode;
            }
#endif
            // 发送第一帧
            if(CloudStg_SendFirstFrame(pstTaskNode) == MOS_ERR)
            {
                return iRetCode;
            }
            pstRtimeParam->bSendFstFrame = MOS_TRUE;
            pstTaskNode->stEventInfo.tStartTime  = pstTaskNode->tCreateTime;
            pstTaskNode->stEventInfo.uiEventType = pstTaskNode->iEventType;
            pstTaskNode->stEventInfo.uiUseFlag = 1;
        }
        do
        {
            pVideoFrame = MOS_NULL;
            // 获取视频流
            #if 0
            Media_VideoGetFrame(pstRtimeParam->hVideoRead,&pVideoFrame,&uiTimeStamp);
            #else
            iDataLen = Media_VideoGetFrame2(pstRtimeParam->hVideoRead,&pVideoFrame,&uiTimeStamp,&llTimePts);
            #endif
            if(pVideoFrame == MOS_NULL)
            {
                #if 0
                Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
                #else
                Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
                #endif
                break;
            }
            ucFrametype = MD_GETFRAMETYPE(pVideoFrame->ucFramPos); 
            if (ucFrametype != 0 && ucFrametype != 1)
            {
                #if 0
                Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
                #else
                Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
                #endif
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "read error data from video cahce, err: %d", ucFrametype);
                break;
            }

            // I帧出现时，do-while循环次数清零
            if (ucFrametype == 1 && uiIdrDuration == 0)
            {
                uiIdrDuration = 1;
                iFrameCnt = 0;
            }
            // p帧
            else if(ucFrametype == 0)
            {
                uiIdrDuration = 0;
            }

            /* P帧 */
            if( pstTaskNode->iForceCommit != 1
                && ((pstTaskNode->iNeedKeyFlag == 1 && ucFrametype != 1) 
                || (CloudStg_StreamGetBufListCacheNodeCount(pstTaskNode->hStream) >= pstTaskNode->uiMaxBuffNum)))
            {
                if (uiPrintCount++ == 10)
                {
                    MOS_PRINTF("now buflist cache node count: %d, max buff num: %d\r\n", CloudStg_StreamGetBufListCacheNodeCount(pstTaskNode->hStream), pstTaskNode->uiMaxBuffNum);
                    uiPrintCount = 0;
                }
                // 标记视频流为已使用
                #if 0
                Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
                #else
                Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
                #endif
                iRetryCount = 0;
                do
                {
                    pAudioFrame = MOS_NULL;
                    
                    // 获取音频流
                    #if 0
                    Media_AudioGetFrame(pstRtimeParam->hAudioRead,&pAudioFrame,&uiTimeStamp1);
                    #else
                    Media_AudioGetFrame2(pstRtimeParam->hAudioRead,&pAudioFrame,&uiTimeStamp1);
                    #endif
                    if(pAudioFrame == MOS_NULL)
                    {
                        //MOS_LOG_ERR(CLOUDSTG_LOGSTR,"read audio null");
                        break;
                    }

                    // 标记音频流为已使用
                    #if 0
                    Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
                    #else
                    Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
                    #endif
                    if(uiTimeStamp1 >= uiTimeStamp)
                    {
                        break;
                    }
                    Mos_Sleep(5);
                }while(iRetryCount++ < 50);
                pstTaskNode->iNeedKeyFlag = 1;
                break;
            }
            pstTaskNode->iNeedKeyFlag  = 0;

            // 发送Icon失败处理
            if(pstTaskNode->uiIconStatus == EN_CLOUDSTG_ICON_UPLOAD_TYPE_FAIL)
            {
                pstTaskNode->uiIconStatus = EN_CLOUDSTG_ICON_UPLOAD_TYPE_NONE;
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"icon status change %u",pstTaskNode->uiIconStatus);
            }
            if(pVideoFrame != MOS_NULL && 
			  (pVideoFrame->ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_RES || 
			   pVideoFrame->ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_ENC))
            {
                if(pstTaskNode->iState >= EN_CLOUDSTG_TASK_STOP)
                {
                    #if 0
                    Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
                    #else
                    Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
                    #endif
                    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task has stoped");
                    return MOS_OK;
                }
                else
                {
                    pstTaskNode->iState = EN_CLOUDSTG_TASK_STOP;
                    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task status change to EN_CLOUDSTG_TASK_STOP");
                }
            }

            // 获取状态
            CloudStg_ProcAliveTaskStatus(pstTaskNode,uiTimeStamp,ucFrametype,EN_ZJ_MEDIA_VIDEO, 0);
            
            if(pstTaskNode->iState == EN_CLOUDSTG_TASK_STOP)
            {
                if (pVideoFrame != MOS_NULL)
                {
                    #if 0
                    Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
                    #else
                    Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
                    #endif
                }
                break;
            }

            // 打包为PS，并发送
            if (CloudStg_NaluVaild(pVideoFrame->ptDatabuff) == MOS_ERR)
            {
                if (pVideoFrame != MOS_NULL)
                {
                    Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
                }
                if (pAudioFrame != MOS_NULL)
                {
                    Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
                }
                pstTaskNode->iNeedKeyFlag == 1;
                break;
            }
#if DEBUG
            MOS_MEMSET(aucData, 0, sizeof(aucData));
            MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_GetCoreMng()->aucCachePath,"sample.h265");
            MOS_VSNPRINTF(aucBuffDesc,256,"%s/%s",Config_GetCoreMng()->aucCachePath,"sample.h265.desc");
            fp = fopen(aucBuff, "a+");
            if (fp)
            {
                fwrite(pVideoFrame->ptDatabuff, pVideoFrame->uiRemFrameLen, 1, fp);
                fclose(fp);
            }
            fpd = fopen(aucBuffDesc, "a+");
            if (fpd)
            {
                MOS_VSNPRINTF(aucData, sizeof(aucData), "Video ptDatabuff: %p; ptnest: %p; ucFramPos: %d; ucVideoResolutionChangeFlag: %d; uiNaluLen: %u; uiRemFrameLen: %u; usDatalen: %u", 
                            pVideoFrame->ptDatabuff, pVideoFrame->ptnest, pVideoFrame->ucFramPos, pVideoFrame->ucVideoResolutionChangeFlag, 
                            pVideoFrame->uiNaluLen, pVideoFrame->uiRemFrameLen, pVideoFrame->usDatalen);
                fwrite(aucData, MOS_STRLEN(aucData), 1, fpd);
                fclose(fpd);
            }
#endif
            CloudStg_StreamSendVFrame(pstTaskNode->hStream,pVideoFrame,iDataLen,uiTimeStamp,ucFrametype, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
            #if 0
            Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
            #else
            Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
            #endif
            iRetCode++;
            iRetryCount = 0;
            do
            {
                pAudioFrame = MOS_NULL;
                #if 0
                Media_AudioGetFrame(pstRtimeParam->hAudioRead,&pAudioFrame,&uiTimeStamp1);
                #else
                Media_AudioGetFrame2(pstRtimeParam->hAudioRead,&pAudioFrame,&uiTimeStamp1);
                #endif
                if(pAudioFrame == MOS_NULL)
                {
                    break;
                }
#if DEBUG
                MOS_MEMSET(aucData, 0, sizeof(aucData));
                MOS_VSNPRINTF(aucBuff1,256,"%s/%s",Config_GetCoreMng()->aucCachePath,"sample.g711");
                MOS_VSNPRINTF(aucBuffDesc,256,"%s/%s",Config_GetCoreMng()->aucCachePath,"sample.g711.desc");
                fp1 = fopen(aucBuff1, "wb");
                if (fp1)
                {
                    fwrite(pAudioFrame->ptDatabuff, pAudioFrame->uiRemFrameLen, 1, fp1);
                    fclose(fp1);
                }
                fpd1 = fopen(aucBuffDesc, "wb");
                if (fpd1)
                {
                    MOS_VSNPRINTF(aucData, sizeof(aucData), "Audio ptDatabuff: %p; ptnest: %p; ucFramPos: %d; ucVideoResolutionChangeFlag: %d; uiNaluLen: %u; uiRemFrameLen: %u; usDatalen: %u", 
                                pAudioFrame->ptDatabuff, pAudioFrame->ptnest, pAudioFrame->ucFramPos, pAudioFrame->ucVideoResolutionChangeFlag, 
                                pAudioFrame->uiNaluLen, pAudioFrame->uiRemFrameLen, pAudioFrame->usDatalen);
                    fwrite(aucData, MOS_STRLEN(aucData), 1, fpd1);
                    fclose(fpd1);
                }
#endif
                CloudStg_StreamSendAFrame(pstTaskNode->hStream,pAudioFrame,uiTimeStamp1, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
                #if 0
                Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
                #else
                Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
                #endif
                if(uiTimeStamp1 >= uiTimeStamp)
                {
                    break;
                }
                Mos_Sleep(5);
            }while(iRetryCount++ < 50);
        }while(iFrameCnt++ < 5);
    }
    // 云存暂停
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_STOP)
    {
        _INT iRet = 0;
        ST_MOS_LIST_ITERATOR stIterator;
        ST_CLOUDSTG_TASK_NODE *pstTmpNode = MOS_NULL;

        pstTaskNode->iState = EN_CLOUDSTG_TASK_WAITING;
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTmpNode, stIterator)
        {
            if(pstTmpNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_ALIVE)
            {
                if(pstTmpNode->iUseFlag == 0)
                {
                    continue;
                }
                pstTaskNode->uiTotalCnt++;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

        // if (pstTaskNode->uiUploadFlag < EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL)
        {
            // 发送最后一包
            iRet = CloudStg_StreamSendLastData(pstTaskNode->hStream);
            if(iRet == MOS_ERR)
            {
                pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"send last data err");
            }
        }
        CloudStg_StreamClose(pstTaskNode->hStream);
        pstTaskNode->hStream      = MOS_NULL;

        if(pstRtimeParam->hAudioRead)
        {
            #if 0
            Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
            Media_AudioDestroyReadHandle(pstRtimeParam->hAudioRead);
            #else
            Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
            Media_AudioDestroyReadHandle2(pstRtimeParam->hAudioRead);
            #endif
        }
        if(pstRtimeParam->hVideoRead)
        {
            #if 0
            Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
            Media_VideoDestroyReadHandle(pstRtimeParam->hVideoRead);
            #else
            Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
            Media_VideoDestroyReadHandle2(pstRtimeParam->hVideoRead);
            #endif
        }
        
        pstRtimeParam->hVideoRead = MOS_NULL;
        pstRtimeParam->hAudioRead = MOS_NULL;

        if ((Config_GetCloudMng()->iCloudAbility == 1) && (CloudStg_GetMng()->uiCurNetStatus == 1) && (pstTaskNode->uiTotalCnt == 1))
        {
            // 事件云存追加下一个云存
            if (pstTaskNode->iCloudUpLoadMode == 1)
            {
                if ((CloudStg_GetConfig()->iEventCloudSwitch == 1) && (CloudStg_GetMng()->uiStartNextEventCloudFlag == MOS_TRUE))
                {
                    CloudStg_SetStartNextEventCloudFlag(MOS_FALSE);
                    CloudStg_StartEventUpLoad(0,Config_GetCloudMng()->iStreamID,CloudStg_GetConfig()->iEventCloudMinTime,Mos_Time());
                }
            }
            else if (pstTaskNode->iCloudUpLoadMode == 2)
            {
                //  MOS_LOG_INF(CLOUDSTG_LOGSTR,"Config_GetCloudMng()->iCloudAbility: %d, Config_GetCloudMng()->iCloudUpLoadMode: %d, \
                //         pstTaskNode->uiTotalCnt: %d, CloudStg_GetMng()->uiCurNetStatus: %d", \
                //         Config_GetCloudMng()->iCloudAbility, Config_GetCloudMng()->iCloudUpLoadMode, \
                //         pstTaskNode->uiTotalCnt, CloudStg_GetMng()->uiCurNetStatus);
                // 端切片以指定的时间传
                if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
                {
                    CloudStg_StartAliveUpLoad(pstTaskNode->iCamId,Config_GetCloudMng()->iStreamID,Config_GetCloudMng()->iVideoDuration);
                }
                else if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
                {
                    // 继续触发5分钟的云存上报
                    CloudStg_StartAliveUpLoad(pstTaskNode->iCamId,Config_GetCloudMng()->iStreamID,CLOUDSTG_UPLOAD_TIME);
                }
            }
        }

        tTmpTimestamp = Mos_Time() - pstTaskNode->tCreateTime;
        tTmpTimestamp = (tTmpTimestamp>=pstTaskNode->uiDuration)?pstTaskNode->uiDuration:tTmpTimestamp;
        pstTaskNode->stEventInfo.tBreakTime = (pstTaskNode->stEventInfo.tBreakTime==0)?(pstTaskNode->tCreateTime + tTmpTimestamp):pstTaskNode->stEventInfo.tBreakTime;
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u stop send file",pstTaskNode->uiTaskId);
    }
    // 云存任务等待上传结束
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_WAITING)
    {
        //  MOS_LOG_INF(CLOUDSTG_LOGSTR,"pstTaskNode->uiUploadFlag: %d", pstTaskNode->uiUploadFlag);
        if(pstTaskNode->uiUploadFlag >= EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS || Config_GetCloudMng()->iCloudAbility == 0)
        {
            pstTaskNode->iState = EN_CLOUDSTG_TASK_OVER;
        }
    }
    // 云存任务结束，释放句柄
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_OVER)
    {
        if ((Config_GetCloudMng()->iCloudAbility == 1) && (pstTaskNode->uiTotalCnt > 1))
        {
            // 事件云存追加下一个云存
            if (pstTaskNode->iCloudUpLoadMode == 1)
            {
                if ((CloudStg_GetConfig()->iEventCloudSwitch == 1) && (CloudStg_GetMng()->uiStartNextEventCloudFlag == MOS_TRUE))
                {
                    CloudStg_SetStartNextEventCloudFlag(MOS_FALSE);
                    CloudStg_StartEventUpLoad(0,Config_GetCloudMng()->iStreamID,CloudStg_GetConfig()->iEventCloudMinTime,Mos_Time());
                }
            }
            else if (pstTaskNode->iCloudUpLoadMode == 2)
            {
                // 端切片以指定的时间传
                if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
                {
                    CloudStg_StartAliveUpLoad(pstTaskNode->iCamId,Config_GetCloudMng()->iStreamID,Config_GetCloudMng()->iVideoDuration);
                }
                else if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL)
                {
                    // 重新触发下一次5分钟的云存上报
                    CloudStg_StartAliveUpLoad(pstTaskNode->iCamId,Config_GetCloudMng()->iStreamID,CLOUDSTG_UPLOAD_TIME);
                }
            }
        }
        pstTaskNode->iState       = EN_CLOUDSTG_TASK_COMMINT;
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u send media over,uploadflag %u",pstTaskNode->uiTaskId,pstTaskNode->uiUploadFlag);
        return iRetCode;
    }
    
    // 云存commit
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_COMMINT || pstTaskNode->iState == EN_CLOUDSTG_TASK_COMMINTINF)
    {
        // 传首帧图片及
        if((pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL && pstTaskNode->uiUploadFlag < EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL) || 
           (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE && pstTaskNode->uiUploadFlag < EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL))
        {
            CloudStg_ProcGetMediaCommit(pstTaskNode, MOS_FALSE);
        }
        // STS自动commit
        else if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS && pstTaskNode->uiAutoCommit != 0)
        {
            pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
        }
        else
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"taskid %u commit fail, uiIconStatus: %d, uiUploadFlag: %d",pstTaskNode->uiTaskId,pstTaskNode->uiIconStatus,pstTaskNode->uiUploadFlag);
            pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
            pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
            if (pstTaskNode->uiConnType == EN_CINET_TYPE_IPV4)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud file request failed ipv4");
            }
            else if (pstTaskNode->uiConnType == EN_CINET_TYPE_IPV6)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud file request failed ipv6");
            }
            Http_Httpclient_CancelAsyncRequestEx(pstTaskNode->uiTaskId);
        }
    }

    // 云存结束
    else if(pstTaskNode->iState == EN_CLOUDSTG_TASK_END)
    {
        // FIXME: 只跑一次云存
        // static _INT i = 0;
        // if (++i == 5)
        //     exit(0);
        _INT iKiloByte     = 0;
        _UC aucLogBuf[512] = {0};
        _CTIME_T tDuration = 0;
        _UC *pucCreateTime = MOS_NULL;
        _UC *pucEndTime    = MOS_NULL;
        tDuration = MOS_ABS_NUM(pstTaskNode->stEventInfo.tBreakTime - pstTaskNode->tCreateTime);

        // 上传失败或中途失败需要添加至补录列表
        if(Config_GetCamaraMng()->uiStorageStatus != 0 && 
          (pstTaskNode->uiUploadFlag != EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS || pstTaskNode->uiFailInMid == 1))
        {
            // 流模式无中途失败
            if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS) 
            {
#if 0
                // 中途失败
                if (pstTaskNode->tFailInMidStartTime != 0)
                {
                    if (pstTaskNode->stEventInfo.tBreakTime > pstTaskNode->tFailInMidStartTime)
                    {
                        if ((pstTaskNode->iCloudUpLoadMode == 1) && (SDK_AWAKE_SLEEP_ENABLE == 1) && (Config_GetDeviceMng()->iAwakeAbility == EN_ZJ_AWAKE_ABILITY_NOTSUPPORT))
                        {
                            tDuration = CLOUDSTG_EVENT_UPLOAD_TIME - (pstTaskNode->tFailInMidStartTime - pstTaskNode->tCreateTime);
                            MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->tFailInMidStartTime,pstTaskNode->tFailInMidStartTime + tDuration,tDuration,pstTaskNode->iCloudUpLoadMode);
                            CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tFailInMidStartTime, pstTaskNode->tFailInMidStartTime + tDuration);
                        }
                        else
                        {
                            tDuration = pstTaskNode->stEventInfo.tBreakTime - pstTaskNode->tFailInMidStartTime;
                            MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->tFailInMidStartTime,pstTaskNode->stEventInfo.tBreakTime,pstTaskNode->stEventInfo.tBreakTime-pstTaskNode->tFailInMidStartTime,pstTaskNode->iCloudUpLoadMode);
                            CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tFailInMidStartTime, pstTaskNode->stEventInfo.tBreakTime);
                        }
                    }
                }
                else
                {
#endif
                    // 事件云存补录不一定为1分钟
                    if (pstTaskNode->iCloudUpLoadMode == 1)
                    {
                        if ((SDK_AWAKE_SLEEP_ENABLE == 1) && (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT))   //低功耗设备
                        {
                            MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tStartTime + tDuration,tDuration,Config_GetCloudMng()->iCloudUpLoadMode);
                            CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tCreateTime, pstTaskNode->tCreateTime + tDuration);                                            
                        }
                        else
                        {
                            if (pstTaskNode->stEventCloud.iSwitch == 1)
                            {
                                if (tDuration <= pstTaskNode->stEventCloud.iMinTime)
                                {
                                    MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tStartTime + pstTaskNode->stEventCloud.iMinTime,pstTaskNode->stEventCloud.iMinTime,pstTaskNode->iCloudUpLoadMode);
                                    CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                        pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, pstTaskNode->stEventCloud.iMinTime, pstTaskNode->stEventCloud.iMaxTime, pstTaskNode->tCreateTime, pstTaskNode->tCreateTime + pstTaskNode->stEventCloud.iMinTime);
                                }
                                else
                                {
                                    MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tBreakTime,pstTaskNode->stEventInfo.tBreakTime-pstTaskNode->stEventInfo.tStartTime,pstTaskNode->iCloudUpLoadMode);
                                    CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                        pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->stEventCloud.iMaxTime, pstTaskNode->tCreateTime, pstTaskNode->stEventInfo.tBreakTime);
                                }
                            }
                            else
                            {
                                MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tBreakTime,pstTaskNode->stEventInfo.tBreakTime-pstTaskNode->stEventInfo.tStartTime,pstTaskNode->iCloudUpLoadMode);
                                CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                    pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tCreateTime, pstTaskNode->stEventInfo.tBreakTime);
                            }
                        }
                    }
                    else
                    {
                        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tBreakTime,pstTaskNode->stEventInfo.tBreakTime-pstTaskNode->stEventInfo.tStartTime,pstTaskNode->iCloudUpLoadMode);
                        CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                            pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tCreateTime, pstTaskNode->stEventInfo.tBreakTime);
                    }
#if 0
                }
#endif
            }
            // 端切片中途失败，事件无需强制设置1分种
            else if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
            {
                // 中途失败的start time
                if (pstTaskNode->tFailInMidStartTime != 0)
                {
                    // 重新计算结束时间
                    _CTIME_T tEndTime = pstTaskNode->tCreateTime + pstTaskNode->uiDuration;
                    pstTaskNode->stEventInfo.tBreakTime = MOS_MIN_NUM(tEndTime, pstTaskNode->stEventInfo.tBreakTime);
                    if (pstTaskNode->stEventInfo.tBreakTime > pstTaskNode->tFailInMidStartTime)
                    {
                        if ((pstTaskNode->iCloudUpLoadMode == 1) && (SDK_AWAKE_SLEEP_ENABLE == 1) && (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT))
                        {
                            tDuration = CLOUDSTG_EVENT_UPLOAD_TIME - (pstTaskNode->tFailInMidStartTime - pstTaskNode->tCreateTime);
                            MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->tFailInMidStartTime,pstTaskNode->tFailInMidStartTime + tDuration,tDuration,pstTaskNode->iCloudUpLoadMode);
                            CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tFailInMidStartTime, pstTaskNode->tFailInMidStartTime + tDuration);
                        }
                        else
                        {
                            tDuration = pstTaskNode->stEventInfo.tBreakTime - pstTaskNode->tFailInMidStartTime;
                            MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->tFailInMidStartTime,pstTaskNode->stEventInfo.tBreakTime,pstTaskNode->stEventInfo.tBreakTime-pstTaskNode->tFailInMidStartTime,pstTaskNode->iCloudUpLoadMode);
                            CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tFailInMidStartTime, pstTaskNode->stEventInfo.tBreakTime);
                        }

                    }
                }
                else if (pstTaskNode->stEventInfo.tBreakTime > pstTaskNode->tCreateTime)
                {
                    tDuration = pstTaskNode->stEventInfo.tBreakTime - pstTaskNode->tCreateTime;

                    // 事件云存补录不一定为1分钟
                    if ((pstTaskNode->iCloudUpLoadMode == 1) && (SDK_AWAKE_SLEEP_ENABLE == 1) && (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT))
                    {
                        if (pstTaskNode->stEventCloud.iSwitch == 1)
                        {
                            if (tDuration <= pstTaskNode->stEventCloud.iMinTime)
                            {
                                MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tStartTime + pstTaskNode->stEventCloud.iMinTime,pstTaskNode->stEventCloud.iMinTime,pstTaskNode->iCloudUpLoadMode);
                                CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                    pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, pstTaskNode->stEventCloud.iMinTime, pstTaskNode->stEventCloud.iMaxTime, pstTaskNode->tCreateTime, pstTaskNode->tCreateTime + pstTaskNode->stEventCloud.iMinTime);
                            }
                            else
                            {
                                MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tStartTime + pstTaskNode->stEventCloud.iMinTime,pstTaskNode->stEventCloud.iMinTime,pstTaskNode->iCloudUpLoadMode);
                                CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                    pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->stEventCloud.iMaxTime, pstTaskNode->tCreateTime, pstTaskNode->tCreateTime + pstTaskNode->stEventCloud.iMinTime);
                            }
                        }
                        else
                        {
                            MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tBreakTime,pstTaskNode->stEventInfo.tBreakTime-pstTaskNode->stEventInfo.tStartTime,pstTaskNode->iCloudUpLoadMode);
                            CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                                pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tCreateTime, pstTaskNode->stEventInfo.tBreakTime);
                        }
                    }
                    else
                    {
                        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"add one event,start time %u,break time %u,duration: %u,type %u",pstTaskNode->stEventInfo.tStartTime,pstTaskNode->stEventInfo.tBreakTime,pstTaskNode->stEventInfo.tBreakTime-pstTaskNode->stEventInfo.tStartTime,pstTaskNode->iCloudUpLoadMode);
                        CloudStg_Patch_AddItemToCfgTaskList(pstTaskNode->iCamId, pstTaskNode->iEventType, pstTaskNode->iTaskType, 
                            pstTaskNode->iStorageType, pstTaskNode->iCloudUpLoadMode, tDuration, pstTaskNode->uiDuration, pstTaskNode->tCreateTime, pstTaskNode->stEventInfo.tBreakTime);
                    }
                }
            }
        }
        
        if (pstTaskNode->uiUploadFlag == EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS)
        {
            // 记录一次事件云存上传成功
            Cloudstg_IncEventCloudSuccessUpload();
            CloudStg_GetMng()->uiFirstCommitFlag = 1;
            iKiloByte = pstTaskNode->iAllSentBytes / 1024;
            MOS_MEMSET(aucLogBuf, 0, sizeof(aucLogBuf));
            pucCreateTime = Mos_PrintTime(pstTaskNode->tCreateTime);
            pucEndTime    = Mos_PrintTime(pstTaskNode->tCreateTime + tDuration);
            MOS_VSNPRINTF(aucLogBuf, sizeof(aucLogBuf), "CD [taskid: %u] type: video HTTP/1.1 200 OK, %s, duration: %s ~ %s, upload icon: %d, enc switch: %d, size: %dKB, time: %ds, avg speed: %dKB/s, linkv%d, hasipv6addr: %d", 
                            pstTaskNode->uiTaskId, pstTaskNode->iCloudUpLoadMode==1?"alarm":"normal", pucCreateTime, pucEndTime, pstTaskNode->uiIconStatus==EN_CLOUDSTG_ICON_UPLOAD_TYPE_SUCCESS?1:0, 
                            pstTaskNode->iCloudEncSwitch==1?1:0, iKiloByte, tDuration, tDuration?(iKiloByte / tDuration):0, pstTaskNode->uiConnType==EN_CINET_TYPE_IPV4?4:6, pstTaskNode->uiHasIpv6);
            // 用于统计设备是否具备IPv6地址
            if (MOS_STRLEN(Config_GetCamaraMng()->aucLocalIPv6Addr) > 0)
            {
                _UC aucStrcatBuf[128] = {0};
                MOS_SPRINTF(aucStrcatBuf, ", localv6: %s", Config_GetCamaraMng()->aucLocalIPv6Addr);
                MOS_STRCAT(aucLogBuf, aucStrcatBuf);
            }
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_VIDEO_UPLOAD_SUCCESS, aucLogBuf, 1);
            if (pstTaskNode->uiConnType == EN_CINET_TYPE_IPV4)
            {
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud file request succeed ipv4");
            }
            else if (pstTaskNode->uiConnType == EN_CINET_TYPE_IPV6)
            {
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud file request succeed ipv6");
            }
            MOS_FREE(pucCreateTime);
            MOS_FREE(pucEndTime);
        }
        CloudStg_GetMng()->iQualityTotalSentBytes += pstTaskNode->iAllSentBytes;
        CloudStg_GetMng()->iQualityTotalSentInterval += tDuration;

        pstTaskNode->iUseFlag = 0;
    }
    return iRetCode;
}

_INT CloudStg_DestroyAliveNode(ST_CLOUDSTG_TASK_NODE *pstAliveTaskNode)
{
    MOS_PARAM_NULL_RETERR(pstAliveTaskNode);

    if(pstAliveTaskNode->hStream != MOS_NULL)
    {
        CloudStg_StreamClose(pstAliveTaskNode->hStream);
        pstAliveTaskNode->hStream = MOS_NULL;
    }
    if(pstAliveTaskNode->u.stRTimePara.hAudioRead)
    {
        #if 0
        Media_AudioDestroyReadHandle(pstAliveTaskNode->u.stRTimePara.hAudioRead);
        #else
        Media_AudioSetFrameUsed2(pstAliveTaskNode->u.stRTimePara.hAudioRead);
        Media_AudioDestroyReadHandle2(pstAliveTaskNode->u.stRTimePara.hAudioRead);
        #endif
    }
    if(pstAliveTaskNode->u.stRTimePara.hVideoRead)
    {
        #if 0
        Media_VideoDestroyReadHandle(pstAliveTaskNode->u.stRTimePara.hVideoRead);
        #else
        Media_VideoSetFrameUsed2(pstAliveTaskNode->u.stRTimePara.hVideoRead);
        Media_VideoDestroyReadHandle2(pstAliveTaskNode->u.stRTimePara.hVideoRead);
        #endif
    }
    pstAliveTaskNode->u.stRTimePara.hVideoRead = MOS_NULL;
    pstAliveTaskNode->u.stRTimePara.hAudioRead = MOS_NULL;

    return MOS_OK;
}
/******************************************************************************************
*******************************************************************************************/
// pstTask->pFunSliceSend
_INT CloudStg_AliveSliceStatusCallBack(_VPTR vpBase,_UI uiStatus,_UC *pucFid,_UC *pucETag,_UI uiTargetSize,_UC *pucBucket,_UC *pucStorageProvider)
{
    // MOS_PARAM_NULL_RETERR(pucFid);
    // MOS_PARAM_NULL_RETERR(pucETag);
    // MOS_PARAM_NULL_RETERR(pucBucket);
    // MOS_PARAM_NULL_RETERR(pucStorageProvider);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->uiTaskId == (_UI)vpBase)
        {
            if(uiStatus == 400 || MOS_STRLEN(pucETag) == 0)
            {
                Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"status 400");

                // 端切片免死金牌，中途commit
                if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE && CloudStg_TaskGetExSentCount(0, pstTaskNode->uiTaskId, pstTaskNode->uiIsPatch) != 0 && pucFid && pucETag && pucBucket && pucStorageProvider)
                {
                    MOS_LOG_INF(CLOUDSTG_LOGSTR,"Still commit upload video...");
                    pstTaskNode->stCommitInfo.cAlarmTime = pstTaskNode->tAlarmTimeStamp;
                    MOS_STRLCPY(pstTaskNode->stCommitInfo.aucObjId, pucFid,  sizeof(pstTaskNode->stCommitInfo.aucObjId));
                    MOS_STRLCPY(pstTaskNode->stCommitInfo.aucETag,  pucETag, sizeof(pstTaskNode->stCommitInfo.aucETag));
                    pstTaskNode->stCommitInfo.uiFileLen = uiTargetSize;
                    MOS_STRLCPY(pstTaskNode->stCommitInfo.aucFileCId,pucBucket, sizeof(pstTaskNode->stCommitInfo.aucFileCId));
                    MOS_STRLCPY(pstTaskNode->stCommitInfo.aucFileSP, pucStorageProvider, sizeof(pstTaskNode->stCommitInfo.aucFileSP));
                    pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS;
                    pstTaskNode->uiFailInMid  = 1;
                }
                else
                {
                    pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
                }
                if(pstTaskNode->iState < EN_CLOUDSTG_TASK_STOP)
                {
                    pstTaskNode->iState = EN_CLOUDSTG_TASK_STOP;
                }
                pstTaskNode->stEventInfo.tBreakTime = Mos_Time();
 
                return MOS_OK;
            }
            // 设置消息告警时间
            pstTaskNode->stCommitInfo.cAlarmTime = pstTaskNode->tAlarmTimeStamp;
            MOS_STRLCPY(pstTaskNode->stCommitInfo.aucObjId, pucFid,  sizeof(pstTaskNode->stCommitInfo.aucObjId));
            MOS_STRLCPY(pstTaskNode->stCommitInfo.aucETag,  pucETag, sizeof(pstTaskNode->stCommitInfo.aucETag));
            pstTaskNode->stCommitInfo.uiFileLen = uiTargetSize;
            MOS_STRLCPY(pstTaskNode->stCommitInfo.aucFileCId,pucBucket, sizeof(pstTaskNode->stCommitInfo.aucFileCId));
            MOS_STRLCPY(pstTaskNode->stCommitInfo.aucFileSP, pucStorageProvider, sizeof(pstTaskNode->stCommitInfo.aucFileSP));
            pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS;
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u tunnel to over ",pstTaskNode->uiTaskId);
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    return MOS_OK;
}

_INT CloudStg_ProcAliveTaskStatus(ST_CLOUDSTG_TASK_NODE *pstTaskNode,_UI uiTimeStamp,_UI uibKeyFrame,_UI uiAvType,_UI uiIsPatch)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);

    _INT iRet = 0;
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM *)pstTaskNode->hStream;
    ST_CFG_INIOT_NODE* pstIotNode =  Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);
    _UI uiTimeStampTmp = 0;
    _CTIME_T cNowTime = 0;

    // 上电未完成第一次commit，需要判断当前系统时间是否远大于任务创建时间
    if (CloudStg_GetMng()->uiFirstCommitFlag == 0 && uiIsPatch == 0)
    {
        cNowTime = Mos_Time();
        if (cNowTime - pstTaskNode->tCreateTime >= CLOUDSTG_GET_ONEWEEK)
        {
            // 强制commit
            pstTaskNode->iForceCommit = 1;
        }
    }

    if(uiAvType == EN_ZJ_MEDIA_VIDEO)
    {
        if(pstTaskNode->uiLastStamp != 0)
        {
            if(uiTimeStamp > pstTaskNode->uiLastStamp)
            {
                uiTimeStampTmp = uiTimeStamp - pstTaskNode->uiLastStamp;
                // 不正常现象
                if (uiTimeStampTmp > 100000)
                {
                    MOS_LOG_WARN(CLOUDSTG_LOGSTR,"catch wrong uiTimeStampTmp %u\r\n", uiTimeStampTmp);
                }
                pstTaskNode->uiAllStamp += uiTimeStampTmp;
                pstTaskNode->uiSliceStamp += uiTimeStampTmp;
            }
            // else
            // {
            //     pstTaskNode->uiAllStamp += 40;
            // }
        }
        pstTaskNode->uiLastStamp = uiTimeStamp;
    }
    // 到达5分钟
    if(pstTaskNode->iForceCommit || pstTaskNode->uiAllStamp > pstTaskNode->uiTotalStamp || pstIotNode == MOS_NULL || pstIotNode->uiOpenFlag == 0 || CloudStg_GetMng()->iOpenFlag == 0)
    {
        MOS_PRINTF("pstTaskNode->uiSliceStamp: %u, Config_GetCloudMng()->iSliceDuration: %d, nowtime: %u\r\n", pstTaskNode->uiSliceStamp, Config_GetCloudMng()->iSliceDuration, Mos_Time());
        if(pstTaskNode->iState >= EN_CLOUDSTG_TASK_STOP)
        {
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task has stoped");
            return MOS_OK;
        }
        else
        {
            if(pstIotNode == MOS_NULL || pstIotNode->uiOpenFlag == 0)
            {
                pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"have no cloud ability,uploadflag %u",pstTaskNode->uiUploadFlag);
            }

			// FIXME:
            if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
            {
                CloudStg_TaskSetExLastSentInterval(0, pstTaskNode->uiTaskId, uiIsPatch, pstTaskNode->uiSliceStamp);
            }
            pstTaskNode->iState = EN_CLOUDSTG_TASK_STOP;
        }
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u send media over turn to stop, uiAllStamp: %u, uiTotalStamp: %u",pstTaskNode->uiTaskId, pstTaskNode->uiAllStamp, pstTaskNode->uiTotalStamp);
    }
    // 到达切片秒数,默认4s
    else if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE && pstTaskNode->uiSliceStamp >= Config_GetCloudMng()->iSliceDuration * 1000)
    {
        // FIXME:
		CloudStg_NotifyExChanToSend(pstStream);
        pstTaskNode->uiSliceStamp = 0;
    }
	return MOS_OK;
}

_INT CloudStg_SendFirstFrame(ST_CLOUDSTG_TASK_NODE *pstTaskNode)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);

    _INT iRetryCount = 0;
    _UC  ucFrametype = 0;
    _UI  uiTimeStamp = 0;
    _UI  uiTimeStamp1 = 0;
    _LLID llTimePts   = 0;
    _INT iDataLen = 0;
    _CTIME_T tPreTimeStamp = 0;
    ST_FRAME_NODE *pVideoFrame = MOS_NULL;
    ST_FRAME_NODE *pAudioFrame = MOS_NULL;
    ST_CLOUDSTG_RTIMEPARA *pstRtimeParam = &pstTaskNode->u.stRTimePara;
    
    //  MOS_LOG_INF(CLOUDSTG_LOGSTR,"[%u]CloudStg_SendFirstFrame", pstTaskNode->uiTaskId);
    // 只发视频
    if(pstRtimeParam->hAudioRead == MOS_NULL) 
    {
        #if 0
        Media_VideoGetFrame(pstRtimeParam->hVideoRead,&pVideoFrame,&uiTimeStamp);
        #else
        iDataLen = Media_VideoGetFrame2(pstRtimeParam->hVideoRead,&pVideoFrame,&uiTimeStamp,&llTimePts);
        #endif
        if(pVideoFrame == MOS_NULL)
        {
            #if 0
            Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
            #else
            Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
            #endif
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "can not find first frame");
            return MOS_ERR;
        }
        ucFrametype = MD_GETFRAMETYPE(pVideoFrame->ucFramPos);
        if (ucFrametype != 0 && ucFrametype != 1)
        {
            #if 0
            Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
            #else
            Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
            #endif
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "read error data from video cahce, err: %d", ucFrametype);
            return MOS_ERR;
        }
        if (CloudStg_NaluVaild(pVideoFrame->ptDatabuff) == MOS_ERR)
        {
            if (pVideoFrame != MOS_NULL)
            {
                Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
            }
            return MOS_ERR;
        }
        CloudStg_StreamSendVFrame(pstTaskNode->hStream,pVideoFrame,iDataLen,uiTimeStamp,ucFrametype, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
        #if 0     
        Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
        #else
        Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
        #endif
        return MOS_OK;
    }
    iRetryCount = 0;

    // 发送音视频
    do
    {
        if(pVideoFrame == MOS_NULL)
        {
            #if 0
            Media_VideoGetFrame(pstRtimeParam->hVideoRead,&pVideoFrame,&uiTimeStamp);
            #else
            iDataLen = Media_VideoGetFrame2(pstRtimeParam->hVideoRead,&pVideoFrame,&uiTimeStamp,&llTimePts);
            #endif
        }
        
        if(pAudioFrame == MOS_NULL)
        {
            #if 0
            Media_AudioGetFrame(pstRtimeParam->hAudioRead,&pAudioFrame,&uiTimeStamp1);
            #else
            Media_AudioGetFrame2(pstRtimeParam->hAudioRead,&pAudioFrame,&uiTimeStamp1);
            #endif
        }
        
        if(MOS_NULL != pVideoFrame && MOS_NULL != pAudioFrame)
        {
            break;
        }
        Mos_Sleep(5);
        // MOS_LOG_INF(CLOUDSTG_LOGSTR,"[%u]CloudStg_SendFirstFrame retry: %d", pstTaskNode->uiTaskId, uiRetryCount);
    }while(iRetryCount++ < 50*4);
    

    if (iRetryCount >= 50*4)
    {
        #if 0
        Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
        #else
        Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
        #endif
        #if 0
        Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
        #else
        Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
        #endif
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"Can't get video and audio, iRetryCount: %d", iRetryCount);
    }

    // 如果获取不到视频则删除视频读句柄
    if(MOS_NULL == pVideoFrame)
    {
        Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
        Media_VideoDestroyReadHandle2(pstRtimeParam->hVideoRead);
        pstRtimeParam->hVideoRead = Media_VideoCreatReadHandle2(pstTaskNode->iCamId,pstTaskNode->iStreamId,(pstTaskNode->iCloudUpLoadMode==CLOUDSTG_UPLOAD_MODE_EVENT)?EN_READ_PRE:EN_READ_NEWKEY,EN_ZJ_KEYFRAME_QUALITY_NORMAL, __FUNCTION__);
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "video handle %p can not find first frame",pstRtimeParam->hVideoRead);
        return MOS_ERR;
    }

    ucFrametype = MD_GETFRAMETYPE(pVideoFrame->ucFramPos); 
    if (ucFrametype != 1)
    {
        #if 0
        Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
        #else
        Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
        #endif
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "read error data from video cahce, ucFrametype: %d", ucFrametype);
        return MOS_ERR;
    }
    CloudStg_ProcAliveTaskStatus(pstTaskNode,uiTimeStamp,ucFrametype,EN_ZJ_MEDIA_VIDEO,0);
    if (CloudStg_NaluVaild(pVideoFrame->ptDatabuff) == MOS_ERR)
    {
        if (pVideoFrame != MOS_NULL)
        {
            Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
        }
        if (pAudioFrame != MOS_NULL)
        {
            Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
        }
        return MOS_ERR;
    }
    // 获取首次I帧时间并设为云存开始时间
    // 注：预录时间点应小于当前时间，且避免设置出厂时间
    tPreTimeStamp = (_CTIME_T)(llTimePts / 1000);
    if ((tPreTimeStamp < pstTaskNode->tCreateTime) && ((pstTaskNode->tCreateTime - tPreTimeStamp) <= CLOUDSTG_GET_ONEMINUTE))
    {
        pstTaskNode->tCreateTime = tPreTimeStamp;
    }
    CloudStg_StreamSendVFrame(pstTaskNode->hStream,pVideoFrame,iDataLen,uiTimeStamp,ucFrametype, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
    #if 0      
    Media_VideoSetFrameUsed(pstRtimeParam->hVideoRead);
    #else
    Media_VideoSetFrameUsed2(pstRtimeParam->hVideoRead);
    #endif

    if(pAudioFrame)
    {
        #if 0
        Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
        #else
        Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
        #endif
        pAudioFrame = MOS_NULL;
    } 
    iRetryCount = 0;
#if AUDIO_VIDEO_SYNC
    // 视频timeStamp大于音频timeStamp+200，重新获取音频
    while (uiTimeStamp > uiTimeStamp1 + 200 && (iRetryCount < 2))
    {
        if(pAudioFrame)
        {
            #if 0
            Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
            #else
            Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
            #endif
            pAudioFrame = MOS_NULL;
        }
        #if 0
        Media_AudioGetFrame(pstRtimeParam->hAudioRead,&pAudioFrame,&uiTimeStamp1);
        #else
        Media_AudioGetFrame2(pstRtimeParam->hAudioRead,&pAudioFrame,&uiTimeStamp1);
        #endif
        if (pAudioFrame == MOS_NULL)
        {
            iRetryCount++;
        }
    }
#endif
    if(pAudioFrame != MOS_NULL)
    {
        CloudStg_StreamSendAFrame(pstTaskNode->hStream,pAudioFrame,uiTimeStamp1, pstTaskNode->iCloudEncSwitch, pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
        #if 0
        Media_AudioSetFrameUsed(pstRtimeParam->hAudioRead);
        #else
        Media_AudioSetFrameUsed2(pstRtimeParam->hAudioRead);
        #endif
    }
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"send first frame stamp video:%u,audio :%u",uiTimeStamp,uiTimeStamp1);
    return MOS_OK;
}

_INT CloudStg_GetCloudEncInfo(ST_CLOUDSTG_TASK_NODE *pstTaskNode)
{
    MOS_PARAM_NULL_RETFALSE(pstTaskNode);

    Mos_MutexLock(&CloudStg_ResGetMng()->hMutex);
    pstTaskNode->iCloudEncPKId   = Config_GetCloudMng()->iCloudEncPKId;
    pstTaskNode->iCloudEncSwitch = Config_GetCloudMng()->iCloudEncSwitch;
    pstTaskNode->iCloudEncType   = Config_GetCloudMng()->iCloudEncType;
    pstTaskNode->iCloudEncLen    = Config_GetCloudMng()->iCloudEncLen;

    MOS_STRCPY(pstTaskNode->aucCloudEncPKValue, Config_GetCloudMng()->aucCloudEncPKValue);
    MOS_STRCPY(pstTaskNode->aucCloudEncAesKey, Config_GetCloudMng()->aucCloudEncAesKey);
    MOS_STRCPY(pstTaskNode->aucCloudEncAesIv, Config_GetCloudMng()->aucCloudEncAesIv);
    MOS_STRCPY(pstTaskNode->aucCloudEncHttpParamJson, Config_GetCloudMng()->aucCloudEncHttpParamJson);
    MOS_STRCPY(pstTaskNode->aucCloudEncHttpParam, Config_GetCloudMng()->aucCloudEncHttpParam);
    MOS_STRCPY(pstTaskNode->aucCloudEncHttpUploadParam, Config_GetCloudMng()->aucCloudEncHttpUploadParam);
    Mos_MutexUnLock(&CloudStg_ResGetMng()->hMutex);
    // MOS_PRINTF("\r\n===========================USE CLOUD ENC===============================\r\n");
    // MOS_PRINTF("aucCloudEncAesKey: %s\r\naucCloudEncAesIv: %s\r\n", pstTaskNode->aucCloudEncAesKey, pstTaskNode->aucCloudEncAesIv);
    // MOS_PRINTF("pstTaskNode->aucCloudEncHttpParamJson: %s\r\n", pstTaskNode->aucCloudEncHttpParamJson);
    // MOS_PRINTF("pstTaskNode->aucCloudEncHttpParam: %s\r\n", pstTaskNode->aucCloudEncHttpParam);
    // MOS_PRINTF("pstTaskNode->aucCloudEncHttpUploadParam: %s\r\n", pstTaskNode->aucCloudEncHttpUploadParam);
    // MOS_PRINTF("\r\n============================================================\r\n");

    return MOS_OK;
}

ST_CLOUDSTG_TASK_NODE *CloudStg_FindTaskNode(_UI uiIsPatch, _UI uiTaskId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }

    return pstTaskTmp;
}

_INT CloudStg_GetTaskNodeState(_UI uiIsPatch, _UI uiTaskId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    if (pstTaskTmp)
    {
        return pstTaskTmp->iState;
    }
    else
    {
        return EN_CLOUDSTG_TASK_END;
    }
    return MOS_ERR;
}

_INT CloudStg_AddSentBytes(_UI uiIsPatch, _INT iCamId, _UI uiTaskId, _INT iSentBytes)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    if (pstTaskTmp)
    {
        pstTaskTmp->iAllSentBytes += iSentBytes;
    }
    else
    {
        // MOS_PRINTF("=====================orphan len: %d\r\n", iSentBytes);
    }
    return MOS_OK;
}

_VOID CloudStg_NotifyExChanToSend(_HSTREAM pstStreamTemp)
{
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM *)pstStreamTemp;
    ST_CLOUDSTG_TASK_INF *pstTask = MOS_NULL;

    Mos_MutexLock(&pstStream->hTaskGroupMutex);
    pstTask = (ST_CLOUDSTG_TASK_INF *)pstStream->hCSTask;
    Mos_MutexUnLock(&pstStream->hTaskGroupMutex);

    CloudStg_TransSendSliceEnd(pstTask);
}

_INT CloudStg_TaskIsNeedPatch(_CTIME_T cCreateTime)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
    {
        // 找到对应的CreateTime且task正在取流中
        if (pstTaskTmp->tCreateTime == cCreateTime && pstTaskTmp->iState <= EN_CLOUDSTG_TASK_STOP)
        {
            MOS_LOG_WARN(CLOUDSTG_PATCH_LOGSTR, "find the same create time: %u in alive task state: %d", pstTaskTmp->tCreateTime, pstTaskTmp->iState);
            Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
            return MOS_FALSE;
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    return MOS_TRUE;
}

_INT CloudStg_TaskAddOneExSentCount(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                pstTaskTmp->iExSentCount++;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                pstTaskTmp->iExSentCount++;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    // if (pstTaskTmp)
    // {
    //     MOS_PRINTF("Successfully upload one ex chan, now total %d\r\n", pstTaskTmp->iExSentCount);
    // }

    return MOS_OK;
}

_INT CloudStg_TaskGetExSentCount(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch)
{
    _INT iExSentCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                iExSentCount = pstTaskTmp->iExSentCount;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                iExSentCount = pstTaskTmp->iExSentCount;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    return iExSentCount;
}

_INT CloudStg_TaskSetExLastSentInterval(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch, _INT iInterval)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                pstTaskTmp->iExLastSentInterval = iInterval;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                pstTaskTmp->iExLastSentInterval = iInterval;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    return MOS_OK;
}

_INT CloudStg_TaskGetExLastSentInterval(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch)
{
    _INT iExLastSentInterval = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                iExLastSentInterval = pstTaskTmp->iExLastSentInterval;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                iExLastSentInterval = pstTaskTmp->iExLastSentInterval;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    return iExLastSentInterval;
}

_INT CloudStg_TaskGetExSentSpeed(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch)
{
    _INT iSentSpeed = 0;
    _CTIME_T cAliveTime = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                cAliveTime = MOS_ABS_NUM(Mos_Time() - pstTaskTmp->tCreateTime);
                if (cAliveTime != 0)
                {
                    iSentSpeed = (pstTaskTmp->iAllSentBytes / 1024) / cAliveTime;
                }
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                cAliveTime = MOS_ABS_NUM(Mos_Time() - pstTaskTmp->tCreateTime);
                if (cAliveTime != 0)
                {
                    iSentSpeed = (pstTaskTmp->iAllSentBytes / 1024) / cAliveTime;
                }
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    return iSentSpeed;
}

_INT CloudStg_TaskGetEventType(_UI uiCamId, _UI uiTaskId, _UI uiIsPatch)
{
    _INT iEventType = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                iEventType = pstTaskTmp->iEventType;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                iEventType = pstTaskTmp->iEventType;
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    return iEventType;
}

_INT CloudStg_TotalSentCountAddOne(_UI uiIsPatch, _INT iCamId, _UI uiTaskId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    if (pstTaskTmp)
    {
        pstTaskTmp->iTotalSentCount++;
    }
    return MOS_OK;
}

_INT CloudStg_RetrySentCountAddOne(_UI uiIsPatch, _INT iCamId, _UI uiTaskId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    if (pstTaskTmp)
    {
        pstTaskTmp->iRetrySentCount++;
    }
    return MOS_OK;
}

_INT CloudStg_RetrySentRateCheck(_UI uiIsPatch, _INT iCamId, _UI uiTaskId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    if (uiIsPatch)
    {
        Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);
    }
    else
    {
        Mos_MutexLock(&CloudStg_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
        {
            if (pstTaskTmp->uiTaskId == uiTaskId)
            {
                break;
            }
        }
        Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    }
    if (pstTaskTmp)
    {
        // MOS_PRINTF("iRetrySentCount: %d, iTotalSentCount: %d\r\n", pstTaskTmp->iRetrySentCount, pstTaskTmp->iTotalSentCount);
        // if (pstTaskTmp->iRetrySentCount >= 3)
        CloudStg_Patch_DesLimitBandWidth(0.8);
    }
    return MOS_OK;
}

_INT CloudStg_NaluVaild(_C *buf)
{
    int debug_index = 0;
    if ((_C)(buf)[0] == 0x00 && (_C)(buf)[1] == 0x00 && (_C)(buf)[2] == 0x00 && (_C)(buf)[3] == 0x01)
        return MOS_OK;
    else if ((_C)(buf)[0] == 0x00 && (_C)(buf)[1] == 0x00 && (_C)(buf)[2] == 0x01)
        return MOS_OK;
    else
    {
        MOS_PRINTF("=====================Detect error nula data!!!\r\n"); 
        for (debug_index = 0; debug_index < 5; debug_index++) 
        {
            MOS_PRINTF("%02x ", (_C)(buf)[debug_index]);
        }
        MOS_PRINTF("\r\n=====================End\r\n");
        return MOS_ERR;
    }
    return MOS_OK;
}

_INT CloudStg_CommitAllTask()
{
    _INT iCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
    {
        pstTaskTmp->iForceCommit = 1;
        iCount++;
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "all cloud task[%d] is closing...", iCount);
    return MOS_OK;
}

_INT CloudStg_CommitAllTaskBeforeReboot()
{
    _INT iCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    CloudStg_GetMng()->iReadyToRebootFlag = 1;
    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
    {
        pstTaskTmp->iForceCommit = 1;
        iCount++;
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    CloudStg_GetMng()->iForceCommitTaskCount = iCount;
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "all cloud task[%d] is closing...", CloudStg_GetMng()->iForceCommitTaskCount);
    return MOS_OK;
}

_INT CloudStg_CheckAllTaskBeforeReboot()
{
    _INT iCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
    {
        if (CloudStg_GetTaskNodeState(0, pstTaskTmp->uiTaskId) == EN_CLOUDSTG_TASK_END || pstTaskTmp->iUseFlag == 0)
        {
            iCount++;
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    if (CloudStg_GetMng()->iForceCommitTaskCount == iCount)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "all cloud task[%d] close ok!", CloudStg_GetMng()->iForceCommitTaskCount);
        return MOS_OK;
    }
    return MOS_ERR;
}

_INT CloudStg_ForceCommitWithTaskId(_UI uiTaskId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskTmp = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList, pstTaskTmp, stIterator)
    {
        if (pstTaskTmp->uiTaskId == uiTaskId)
        {
            pstTaskTmp->iForceCommit = 1;
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "force commit cloud task[%u]", uiTaskId);
    return MOS_OK;
}

// 云存处理设备外网IP变更的逻辑
_INT CloudStg_NotifyOuterIPChange()
{
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "GOTO Handle Dev OuterIP Change For Cloud");
    CloudStg_CommitAllTask();
    return MOS_OK;
}

_INT CloudStg_DetectForceCommit(ST_CLOUDSTG_TASK_NODE *pstTaskNode, _UI uiIsPatch)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM *)pstTaskNode->hStream;
    if(pstTaskNode->iForceCommit)
    {
        if(pstTaskNode->iState >= EN_CLOUDSTG_TASK_STOP)
        {
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud task has stoped");
            return MOS_OK;
        }
        else
        {
            if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
            {
                CloudStg_NotifyExChanToSend(pstStream);
                CloudStg_TaskSetExLastSentInterval(0, pstTaskNode->uiTaskId, uiIsPatch, pstTaskNode->uiSliceStamp);
            }
            pstTaskNode->iState = EN_CLOUDSTG_TASK_STOP;
        }
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"taskid %u send media over turn to stop, uiAllStamp: %u, uiTotalStamp: %u",pstTaskNode->uiTaskId, pstTaskNode->uiAllStamp, pstTaskNode->uiTotalStamp);
    }
    return MOS_OK;
}