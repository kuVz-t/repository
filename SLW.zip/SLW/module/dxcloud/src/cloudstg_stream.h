#ifndef CLOUDSTG_STREAM_H
#define CLOUDSTG_STREAM_H

#ifdef __cplusplus
extern "C"
{
#endif

typedef  MOS_MASK_HANDLE_TYPE(_HSTREAM) _HSTREAM;

// 打开流(多线程调用)
_HSTREAM CloudStg_StreamOpen(_INT iCamId,_INT iAliveTaskId,_UI uiType,_UI uiBiteRate,_UI uiDuration,PFUN_SLICECALLBACK pFunUriAdd,_VPTR ptUseHandle, _UC ucIsPatch, _INT iCloudEncSwitch, _INT iDirectMode);

// 关闭流(多线程调用)
_VOID CloudStg_StreamClose(_HSTREAM hStream);

// 获取当前流下的任务的BufList长度(多线程调用)
_UI CloudStg_StreamGetBufListCacheNodeCount(_HSTREAM hStream);

_UI CloudStg_StreamGetSlicelen(_HSTREAM hStream);

// 设置流参数(多线程调用)
_INT CloudStg_StreamSetPara(_HSTREAM hStream,ST_CFG_VIDEODES *pstVideoDes,ST_ZJ_AUDIO_PARAM *pstAudioParm);

// 发送Video帧(多线程调用)
_INT CloudStg_StreamSendVFrame(_HSTREAM hStream,ST_FRAME_NODE *pVFrameHead, _INT iFrameHeadLen, _UI uiTimeStamp,_UI bIFrame, _INT iCloudEncSwitch, _UC *aucCloudEncAesKey, _UC *aucCloudEncAesIv);

// 发送Audio帧(多线程调用)
_INT CloudStg_StreamSendAFrame(_HSTREAM hStream,ST_FRAME_NODE *pAFrameHead, _UI uiTimeStamp, _INT iCloudEncSwitch, _UC *aucCloudEncAesKey, _UC *aucCloudEncAesIv);

// 判断是否超过指定长度
_BOOL CloudStg_StreamSliceLenExceed(_HSTREAM hStream,_UI uiSendlen);

// 发送最后一包:补零(多线程调用)
_INT CloudStg_StreamSendLastData(_HSTREAM hStream);

// deprecated：获得比特率
_UI CloudStg_ExStreamGetBitRate(_HSTREAM hStream);

// deprecated：设置需要丢失的gop数量
_INT CloudStg_ExStreamSetDropGopNum(_HSTREAM hStream, _INT iDropNum);

// deprecated：获得需要丢失的gop数量
_INT CloudStg_ExStreamGetDropGopNum(_HSTREAM hStream);
#ifdef __cplusplus
}
#endif

#endif
