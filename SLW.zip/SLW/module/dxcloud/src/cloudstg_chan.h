#ifndef _CLOUDSTG_TRANS_H_
#define _CLOUDSTG_TRANS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "adpt_json_adapt.h"
#include "cloudstg_type.h"

#define CLOUDSTG_UPLOAD_FORCE_STOP         0        // 云存上传强制停止
#define CLOUDSTG_UPLOAD_DELAY_SEND         0        // 云存上传第二个任务延时发送（一次只允许一个任务上传）
#define CLOUDSTG_UPLOAD_LIMIT_SEND         1        // 云存上传第二个任务限速发送（让第一个任务发的快点）

#define CLOUDSTG_UPLOAD_LIMIT_SEND_PACKETS 30       // 云存上传第二个任务限速发送，每隔第一个任务发送30个包发送1包

#define CLOUDSTG_UPLOADLOG_MAX_COUNT      10
#define CLOUDSTG_UPLOADLOG_TIMEOUT        300
#define CLOUDSTG_UPLOADLOG_AES_KEY        "aP0gB1gL4mN1hB4h"
#define CLOUDSTG_UPLOADLOG_AES_IV         "aN5fI4dB1eL2aD1a"
#define CLOUDSTG_UPLOADLOG_HOST           "http://cte.ux.21cn.com"
#define CLOUDSTG_UPLOADLOG_URL            "/msg/ehome/custom/4.0"

#define CLOUDSTG_LOCAL_LOG_VERSION        "1.0"
#define CLOUDSTG_UPLOAD_LOCOL_LOG_PATH    "http://cte.ux.21cn.com/connect/api/ehome/logFileUpload"
#define CLOUDSTG_LOCAL_LOG_PRODUCTID      "85D5C0E0B7BD4289B50234FCB6AF70E9"
#define CLOUDSTG_LOCAL_LOG_PUBLICKEY      "838f6a163818b3ee49d8f4c22526d64e"

typedef  MOS_MASK_HANDLE_TYPE(_HCSTASK) _HCSTASK;

typedef _INT (*PFUN_SLICECALLBACK)(_VPTR vpBase,_UI uiStatus,_UC *pucFid,_UC *pucETag,_UI uiTargetSize,_UC *pucBucket,_UC *pucStorageProvider);
typedef _VOID (*PFUN_FINISHED)(_VPTR vpBase,_UI uiStatus,_UC *pucFid,_UC *pucETag,_UI uiTargetSize,_UC *pucBucket,_UC *pucStorageProvider);

typedef enum EX_TRANS_NETWORK_STATUS
{
    EX_TRANS_NETWORK_STATUS_DEFAULT  = -1, 
    EX_TRANS_NETWORK_NO_LATENCY      = 0, 
    EX_TRANS_NETWORK_LOW_LATENCY     = 1,
    EX_TRANS_NETWORK_MID_LATENCY     = 2,
    EX_TRANS_NETWORK_HIGH_LATENCY    = 3
}ENUM_EX_TRANS_NETWORK_STATUS;

typedef enum EX_TRANS_STATUS
{
    EX_TRANS_STATUS_START            = 0, 
    EX_TRANS_STATUS_PROCESS          = 1, 
    EX_TRANS_STATUS_END              = 2,
}ENUM_EX_TRANS_STATUS;

#include "cloudstg_chan_prv.h"

ST_CLOUDSTG_TRANS_MGR* CloudStg_TransGetMgr();
_INT      CloudStg_TransStart();
_INT      CloudStg_TransStop();
/****************************************************************************************************************
trans 下面集合了 con 
****************************************************************************************************************/
// 云存任务打开(多线程调用)
_HCSTASK  CloudStg_TransTaskOpen(_VPTR hStream, _INT iCamId, _INT iAliveTaskId, _UI uiType, _UI uiFilesize, PFUN_SLICECALLBACK pFun,_VPTR ptUseHandle, _UI uiIsPatch, _INT iCloudEncSwitch, _INT iIndex, _HCSCONN *phCSConn, _INT iDirectMode);

// 关闭云存上传任务(多线程调用)
_VOID CloudStg_TransTaskClose(ST_CLOUDSTG_TASK_INF *pstTask);

// 云存任务异步关闭(多线程调用)
_VOID CloudStg_TransTaskCloseAsync(_HCSTASK hCSTask);

// 添加buf至云存上传BufList(多线程调用)
_INT CloudStg_TransTaskAddBuf(_HCSTASK hCSTask, EN_CLOUDSTG_TRANS_BUF_TYPE enType, _UC *pucBuf, _UI uiBufLen, _UI uiTimeStamp, _INT iCloudEncSwitch, _UC *aucCloudEncAesKey, _UC *aucCloudEncAesIv);

// 填充0到BufList(预测长度方式)
_INT CloudStg_TransTaskFillData(_HCSTASK hCSTask,_UI uiFillLen);

// 获取SliceNum
_UI CloudStg_TransTaskSliceNum(_HCSTASK hCSTask);

// 获取BufList的长度
_UI CloudStg_TransTaskGetCacheNodeCount(_HCSTASK hCSTask);

// 添加BufNode到BufList, 发送结束标志
_INT CloudStg_TransSendSliceInfo(_HCSTASK hCSTask);

// 添加BufNode到BufList, 发送切片结束标志（端切片使用）
_INT CloudStg_TransSendSliceEnd(_HCSTASK hCSTask);

// 端切片发送最后一包数据
_INT CloudStg_TransSendLastData(_HCSTASK hCSTask);

// 创建发送内存保存的资源任务
_INT CloudStg_TransSendExtUriWithMem(_INT iAliveTaskId,_UC *pucBuf,_UI uiLen,_UI uiFileType,_UI uiIcon,PFUN_FINISHED pfuncFinished,_VPTR vpBase,_CTIME_T cStartTime);

// 创建发送本地文件的任务
_INT CloudStg_TransSendLocalFile(_UC *pucFileName,_UI uiType,PFUN_FINISHED pfuncFinished,_VPTR vpBase);

// 获取设备ID(多线程调用)
_VOID CloudStg_TransGetDeviceId();

/****************************实时日志******************************/

// 创建发送实时日志的任务
_INT CloudStg_TransUploadLog(_UI uiType,PFUN_FINISHED pfuncFinished,_VPTR vpBase, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC *pucEt, _CTIME_T cCreateTime);

// 同步HTTPS上传日志LOG
_INT CloudStg_HttpUploadLog(_UC *puaData);

// 实时日志JSON组包
_UC *CloudStg_BuildUploadLogJson(JSON_HANDLE *hRootArray, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC *pucEt, _CTIME_T cTime, _INT iIndex, _INT iNeedOutput);

// 实时日志返回CB
_VOID CloudStg_UploadLogRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId);

// 实时日志完成CB
_VOID CloudStg_UploadLogFinish(_VPTR vpUserPtr);

// 实时日志失败CB
_VOID CloudStg_UploadLogFail(_VPTR vpUserPtr,_UI uiErrCode);

// 阻塞获取设备ID
_VOID CloudStg_TransGetDeviceId();

// 通过type找到buflist节点
ST_CLOUDSTG_BUF_NODE *CloudStg_TransFindBufNodeWithType(ST_MOS_LIST *pstBufList, _INT iType);

// 检测是否有资格发送buf
_INT CloudStg_TransQualificationCheck(_HCSTASK hCSTask);

// 设置传输强制停止时间
_INT CloudStg_TransSetForceStopTime(_HCSTASK hCSTask, _CTIME_T cForceStopTime);

// 关闭发送任务（端切片使用）
_VOID CloudStg_ExTransTaskTempClose(ST_CLOUDSTG_TASK_INF *pstTask);

// 判断当前buflist节点是否为空
_INT Cloudstg_ExTransCurBufNodeIsEmpty(ST_CLOUDSTG_TASK_INF *pstTask);

// 设置下一个切片的position
_INT CloudStg_ExChanSetSentPosition(_HCSTASK hStream, _UI uiPostion);

// 获取下一个切片的position
_INT CloudStg_ExChanGetSentPosition(_HCSTASK hStream);

// deprecated：检测速率，控制发包速度
_INT Cloudstg_ExTransNetCheck(ST_CLOUDSTG_TASK_INF *pstTask, _INT iKiloBitSpeed);
_INT Cloudstg_ExTransNetHandle(ST_CLOUDSTG_TASK_INF *pstTask);
#ifdef __cplusplus
}
#endif 

#endif

