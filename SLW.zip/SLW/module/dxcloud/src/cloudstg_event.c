#include "mos.h"
#include "IoManage_api.h"
#include "adpt_ssl_adapt.h"
#include "adpt_json_adapt.h"
#include "zj_interface.h"
#include "config_api.h"
#include "record_api.h"
#include "media_cache_api.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_manage.h"
#include "cloudstg_event.h"

//检查相关文件路径是否存在OK
static _VOID CloudStg_CheckDir()
{
    _UC aucCloudDir[256];
    MOS_VSNPRINTF(aucCloudDir,256,"%s/%s",Config_GetCoreMng()->aucCachePath,CLOUDSTG_DIR);
    Mos_DirMake(aucCloudDir,MOS_DIR_MAKE_FLAG);
    return;
}

//向CloudDate文件中添加日期信息OK
_INT CloudStg_AddDate(_UC *aucDay)
{
    MOS_PARAM_NULL_RETERR(aucDay);

    _HFILE hFile;
    _INT iRet  = 0;
    _INT iSize     = sizeof(ST_CLOUDSTG_DATE);
    _UC aucDid[32]={0};
    _UC aucFileName[256]={0};
    ST_CLOUDSTG_DATE stDateInf;

    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s",Config_GetCoreMng()->aucCachePath,CLOUDSTG_DIR,CLOUDSTG_DATECFG_NAME);
    if(Mos_FileIsExist(aucFileName)==MOS_FALSE)
    {
        Mos_FileWriteAppend(aucFileName,Config_GetSystemMng()->aucDid,32);
    }
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);

    Mos_FileRead(hFile,aucDid,32);
    
    if(MOS_STRCMP(aucDid,Config_GetSystemMng()->aucDid)){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Cloud Date File Version error");
        return MOS_ERR;
    }
    
    while(Mos_FileEof(hFile) == MOS_FALSE)
    {
        iRet=Mos_FileRead(hFile,(_UC*)&stDateInf,iSize);
        if(iRet > 0 && iRet < iSize)
        {
            stDateInf.ucBInUse = ' ';
            stDateInf.ucCheck = '$';
            Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iRet);
            Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
            Mos_FileFlush(hFile);
            break;
        }
    }
    stDateInf.ucCheck = '$';
    stDateInf.ucBInUse = 1;
    if(MOS_STRCMP(aucDay,stDateInf.aucDate) == 0)
    {
        Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iSize);
        Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
    }
    else
    {
        MOS_STRLCPY(stDateInf.aucDate,aucDay,sizeof(stDateInf.aucDate));
        Mos_FileSeek(hFile,MOS_FILE_SEEK_END,0);
        Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
    }
    Mos_FileClose(hFile); 
    return MOS_OK;
}

//删除给定时间前所有文件OK
_VOID CloudStg_DeleteManyDays(_UC *pucDayAgo)
{
    MOS_PARAM_NULL_NORET(pucDayAgo);

    _INT iRet  = 0;
    _INT iSize = sizeof(ST_CLOUDSTG_DATE);
    _HFILE hDateFile = MOS_NULL;
    _UC aucDid[32];
    _UC aucCloudPath[256];
    ST_CLOUDSTG_DATE stTmpDate;

    MOS_VSNPRINTF(aucCloudPath,256,"%s/%s/%s",Config_GetCoreMng()->aucCachePath,CLOUDSTG_DIR,CLOUDSTG_DATECFG_NAME);
    hDateFile = Mos_FileOpen(aucCloudPath,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hDateFile == MOS_NULL)
    {
        return;
    }
    Mos_FileRead(hDateFile,aucDid,32);
    if(MOS_STRCMP(aucDid,Config_GetSystemMng()->aucDid)){
        Mos_FileClose(hDateFile);
        Mos_FileRmv(aucCloudPath);
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Cloud Date File Version error");
        return;
    }
    while(!Mos_FileEof(hDateFile))
    {
        iRet = Mos_FileRead(hDateFile,(_UC*)&stTmpDate,iSize);
        if(iRet < iSize || stTmpDate.ucCheck != '$'){
            break;
        }
        if(stTmpDate.ucBInUse != 1){
            continue;
        }
        if(MOS_STRCMP(stTmpDate.aucDate,pucDayAgo) < 0){
            MOS_VSNPRINTF(aucCloudPath,256,"%s/%s/%s%s",Config_GetCoreMng()->aucCachePath,CLOUDSTG_DIR,stTmpDate.aucDate,CLOUDSTG_FILEDES_NAME);
            Mos_FileRmv(aucCloudPath);
            stTmpDate.ucBInUse=0;
            Mos_FileSeek(hDateFile,MOS_FILE_SEEK_CUR,-iSize);
            Mos_FileWrite(hDateFile,(_UC*)&stTmpDate,iSize);
        }
        else
        {
            break;
        }
    }
    Mos_FileClose(hDateFile);
    return;
}

//文件信息自动老化OK
_INT CloudStg_AutoDelete()
{
    _UC aucDay[20];
    _CTIME_T cTimeNow = Mos_Time() - CLOUDSTG_AUTODELETE * 86400;
    ST_MOS_SYS_TIME stSysTime;

    Mos_TimetoSysTime(&cTimeNow ,&stSysTime);
    MOS_VSNPRINTF(aucDay, 20, "%04u-%02u-%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    
    CloudStg_DeleteManyDays(aucDay);

    return MOS_OK;
}

//添加补录记录OK
_INT CloudStg_AddOneEvent(ST_CLOUDSTG_EVENT_INFO *pstEventinfo)
{
    MOS_PARAM_NULL_RETERR(pstEventinfo);

    _HFILE hFile = MOS_NULL;
    _UC aucFileName[256];
    _UC aucBuff[32];
    ST_MOS_SYS_TIME stSysTime;
    
    CloudStg_CheckDir();
    if(MOS_ABS_NUM(pstEventinfo->tStartTime - pstEventinfo->tBreakTime) >= 0 || MOS_ABS_NUM(pstEventinfo->tBreakTime - pstEventinfo->tStartTime) < 5)
    {
        return MOS_OK;
    }
    if(MOS_ABS_NUM(pstEventinfo->tBreakTime - pstEventinfo->tStartTime) > 300)
    {
        pstEventinfo->tBreakTime = pstEventinfo->tStartTime + 300;
    }
    Mos_TimetoSysTime(&pstEventinfo->tStartTime,&stSysTime);
    MOS_VSNPRINTF(aucBuff,32,"%04hu-%02hu-%02hu",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    CloudStg_AddDate(aucBuff);
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s%s",Config_GetCoreMng()->aucCachePath,CLOUDSTG_DIR,aucBuff,CLOUDSTG_FILEDES_NAME);
    if(Mos_FileIsExist(aucFileName) == MOS_FALSE)
    {
        Mos_FileWriteAppend(aucFileName,Config_GetSystemMng()->aucDid,32);
    }
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
    
    MOS_MEMSET(aucBuff, 0, 32);
    Mos_FileRead(hFile,aucBuff,32);

    if(MOS_STRCMP(aucBuff,Config_GetSystemMng()->aucDid)){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Cloud Filedes Version error");
        return MOS_ERR;
    }
    Mos_FileSeek(hFile,MOS_FILE_SEEK_END,0);
    Mos_FileWrite(hFile,(_UC*)pstEventinfo,sizeof(ST_CLOUDSTG_EVENT_INFO));
    Mos_FileClose(hFile);
    return MOS_OK;
}

//删除补录记录
_INT CloudStg_DeleteOneEvent(_CTIME_T cStartTime)
{
    _INT iRet = 0;
    _INT iSize = 0;
    _HFILE hFile = MOS_NULL;
    _UC aucFileName[256];
    _UC aucBuff[32];
    ST_MOS_SYS_TIME stSysTime;
    ST_CLOUDSTG_EVENT_INFO stEventInfo;

    Mos_TimetoSysTime(&cStartTime,&stSysTime);
    MOS_VSNPRINTF(aucBuff,32,"%04hu-%02hu-%02hu",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s%s",Config_GetCoreMng()->aucCachePath,CLOUDSTG_DIR,aucBuff,CLOUDSTG_FILEDES_NAME);

    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
    if(hFile == MOS_NULL)
    {
        return MOS_OK;
    }
    MOS_MEMSET(aucBuff,0,32);
    Mos_FileRead(hFile,aucBuff,32);
    if(MOS_STRCMP(aucBuff,Config_GetSystemMng()->aucDid) != 0){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Cloud Filedes Version error");
        return MOS_ERR;
    }
   
    iSize = sizeof(ST_CLOUDSTG_EVENT_INFO);
    while(Mos_FileEof(hFile) == MOS_FALSE)
    {
        iRet = Mos_FileRead(hFile,(_UC*)&stEventInfo,iSize);
        if(iRet != iSize){
            break;
        }
        if(stEventInfo.tStartTime == cStartTime)
        {
            stEventInfo.uiUseFlag = 0;
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,-iSize);
            Mos_FileWrite(hFile,(_UC*)&stEventInfo,iSize);
            break;
        }
    }
    Mos_FileClose(hFile);
    return MOS_OK;
}

//查询补录记录OK
ST_MOS_LIST *CloudStg_QueryInfo()
{
    _HFILE hFile    = MOS_NULL;
    _HFILE hDesFile = MOS_NULL;
    _INT iRet    = 0;
    _INT iSize   = 0;
    _UC aucDid[32];
    _UC aucFileName[256];
    _CTIME_T cNowTime = Mos_Time();
    ST_MOS_LIST *pstList = MOS_NULL;
    ST_CLOUDSTG_DATE stDate;
    ST_CLOUDSTG_EVENT_INFO stEventInf; 
    ST_CLOUDSTG_EVENT_NODE *pstEventNode = MOS_NULL;

    if(MOS_STRLEN(Config_GetCoreMng()->aucCachePath) == 0)
    {
        return MOS_NULL;
    }
    
    MOS_MEMSET(&stDate,0,sizeof(ST_CLOUDSTG_DATE));
    MOS_MEMSET(&stEventInf,0,sizeof(ST_CLOUDSTG_EVENT_INFO));

    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s",Config_GetCoreMng()->aucCachePath, CLOUDSTG_DIR,CLOUDSTG_DATECFG_NAME);
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDONLY);
    if(hFile == MOS_NULL)
    {
        return MOS_NULL;
    }
    Mos_FileRead(hFile,aucDid,32);
    if(MOS_STRCMP(aucDid,Config_GetSystemMng()->aucDid) != 0)
    {
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Cloud Datefile Version error");
        return MOS_NULL;
    }

    while(!Mos_FileEof(hFile))
    {
        iSize = sizeof(ST_CLOUDSTG_DATE);
        iRet  = Mos_FileRead(hFile,(_UC*)&stDate,iSize);
        if(iRet != iSize){
            break;
        }
        if(stDate.ucBInUse == 1)
        {
            MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s%s",Config_GetCoreMng()->aucCachePath,CLOUDSTG_DIR,stDate.aucDate,CLOUDSTG_FILEDES_NAME);
            hDesFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDONLY);
            if(hDesFile == MOS_NULL)
            {
                continue;
            }
            Mos_FileRead(hDesFile,aucDid,32);
            if(MOS_STRCMP(aucDid,Config_GetSystemMng()->aucDid))
            {
                Mos_FileClose(hDesFile);
                Mos_FileRmv(aucFileName);
                continue;
            }
            iSize = sizeof(ST_CLOUDSTG_EVENT_INFO);
            while(!Mos_FileEof(hDesFile))
            {
                iRet = Mos_FileRead(hDesFile,(_UC*)&stEventInf,iSize);
                if(iRet != iSize)
                {
                    break;
                }
                // 24小时内恢复可以补录
                if(stEventInf.uiUseFlag == 0 || MOS_ABS_NUM(cNowTime - stEventInf.tStartTime) >= 86400 
                    || MOS_ABS_NUM(stEventInf.tStartTime - stEventInf.tBreakTime) >= 0)
                {
                   continue;
                }
                if(pstList == MOS_NULL)
                {
                    pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
                }
                pstEventNode = (ST_CLOUDSTG_EVENT_NODE *)MOS_MALLOCCLR(sizeof(ST_CLOUDSTG_EVENT_NODE));
                if(pstEventNode != MOS_NULL)
                {
                    MOS_MEMCPY(&pstEventNode->stEventInfo,&stEventInf, sizeof(ST_CLOUDSTG_EVENT_INFO));
                    MOS_LIST_ADDTAIL(pstList,pstEventNode);
                }
            }
            Mos_FileClose(hDesFile);
        }
    }
    Mos_FileClose(hFile);
    return pstList;
}

_INT CloudStg_AddDefaultEvent(_INT iCamId, _CTIME_T cNowTime,_UI uiEventType)
{
    // if(Config_GetCamaraMng()->uiStorageStatus == 0 || Config_GetCloudMng()->iCloudAbility != 1)
    // {
    //     return MOS_OK;
    // }

    // if(uiEventType == 1){
    // CloudStg_Patch_AddItemToCfgTaskList(iCamId, uiEventType, EN_CLOUDSTG_RESOURCE_STREAM, 
    //     EN_CLOUDSTG_STORAGE_TYPE_ALIVE, Config_GetCloudMng()->iCloudUpLoadMode, cNowTime + 60, cNowTime, cNowTime);
    // }else if(uiEventType == 2){
    // CloudStg_Patch_AddItemToCfgTaskList(iCamId, uiEventType, EN_CLOUDSTG_RESOURCE_STREAM, 
    //     EN_CLOUDSTG_STORAGE_TYPE_ALIVE, Config_GetCloudMng()->iCloudUpLoadMode, cNowTime + 300, cNowTime, cNowTime);
    // }
    return MOS_OK;
}