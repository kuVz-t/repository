#ifndef CLOUDSTG_RES_H
#define CLOUDSTG_RES_H
#ifdef __cplusplus
extern "C"
{
#endif

#define NORMAL_CHAN            "1"
#define EXCHAN_AND_NORMAL_CHAN "1_3"
#define STS_AND_NORMAL_CHAN    "1_4"

// #define SUPPORT_HTTPS

// 云存资源初始化
_INT CloudStg_ResInit();

// 云存资源销毁
_INT CloudStg_ResDestroy();

// 云存资源开始
_INT CloudStg_ResStart();

// 云存资源停止
_INT CloudStg_ResStop();

// 分配资源内存
ST_CLOUDSTG_RES_URL *CloudStg_ResMallocUrlBuff();
ST_CLOUDSTG_RES_URL *CloudStg_ResBackUpUrlBuff(ST_CLOUDSTG_RES_URL *pstResUrl);

// 获取云存url
ST_CLOUDSTG_RES_URL *CloudStg_ResAllocUrl(_UI uiType,_INT iDirectMode,_UI uiPicUrl);

// 获取本地上传url(deprecated)
ST_CLOUDSTG_RES_URL *CloudStg_ResLocalFileUrl();

// 将url放入stUrlPool
_VOID CloudStg_ResFreeUrl(ST_CLOUDSTG_RES_URL *pstCloudUrl);

// 解析域名
_INT CloudStg_ResGetHost(ST_CLOUDSTG_RES_URL *pstConnUri, _OUT _UC *pucOutHost, _OUT _US *pusOutPort, _OUT _UC *pucOutSubUri,_UI *uiHttpType);

// 分配连接内存
ST_MECS_CONN *CloudStg_ResMallocConnMem();

// 释放连接内存
_INT CloudStg_ResFreeConnMem(ST_MECS_CONN *pstConnMem);

// 生成加密信息
_INT CloudStg_Res_GenerateEncInfo(_INT iForceFlag);

// 通知res线程生成加密信息
_INT CloudStg_Res_NotifyGenerateEncInfo();

// 加密data
_INT CloudStg_Res_DataEncrypt(_UC *pucAesKey, _UC *pucAesIv, _UC *Data, _UI DataLen, _UC *OutputData);

// 解析加密的地址
_INT CloudStg_Res_EncryptUrlParse(ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode, JSON_HANDLE hDataObj);

// 解析普通的地址 iDirectMode: 1:直传流 3:端切片 4:STS
_INT CloudStg_Res_NormalUrlParse(ST_CLOUDSTG_URLBUCKET_NODE *pstUrlBucketNode, JSON_HANDLE hDataObj, _INT iDirectMode);

ST_CLOUDSTG_URLBUCKET_NODE *CloudStg_Res_GetUrlBucketNodeFromType(_UI uiType);

// 解析RFC1123到时间戳
_CTIME_T CloudStg_Res_RFC1123ToTimestamp(_UC* ucRFC1123);

_INT CloudStg_Res_CleanAllUrl();

_CTIME_T CloudStg_Res_GetNextReqTime(_CTIME_T cNowTime);

_INT CloudStg_Res_GenStsAuthorization(ST_MECS_CONN* pstConn, _UC *pucAuthorization, _UI uiAuthorizationLen, _BOOL bIsPic);

_VOID CloudStg_Res_FeedWatchDog();

// ret TRUE: 看门狗超时; FALSE: 看门狗不超时
_BOOL CloudStg_Res_IsWatchDogTimeout();
#ifdef __cplusplus
}
#endif

#endif

