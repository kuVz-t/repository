#ifndef CLOUDSTG_TYPE_PRV_H 
#define CLOUDSTG_TYPE_PRV_H

#define CLOUDSTG_LOGSTR             (_UC*)"CD"          // 云存模块
#define CLOUDSTG_PATCH_LOGSTR       (_UC*)"CDPH"        // 云存补录模块

#define CLOUDSTG_DEFAULT_HTTP_PORT       80 
#define CLOUDSTG_DEFAULT_HTTPS_PORT      443 

#define CLOUDSTG_URI_LEN                 1020
#define CLOUDSTG_FID_LEN                 32
#define CLOUDSTG_BUCKET_LEN              32
#define CLOUDSTG_KEY_LEN                 128
#define CLOUDSTG_HOST_LEN                128
#define CLOUDSTG_SOCKET_SEND_SIZE        64000
#define CLOUDSTG_SOCKET_RECV_SIZE        16000
#define CLOUDSTG_SOCKET_SEND_TIMEOUT     5
#define CLOUDSTG_SOCKET_RECV_TIMEOUT     30
#define CLOUDSTG_HTTP_HEADER_MAX_LEN     2048 

#define CLOUDSTG_HTTP_RES_WAIT_MAX_TIME  15000

#define  CLOUDSTG_GET_ONESECOND        1
#define  CLOUDSTG_GET_FIVESECONDS      5
#define  CLOUDSTG_GET_TENSECONDS       10
#define  CLOUDSTG_GET_THIRTYSECONDS    30
#define  CLOUDSTG_GET_ONEMINUTE        60
#define  CLOUDSTG_GET_THREEMINUTE      180
#define  CLOUDSTG_GET_FIVEMINUTES      300
#define  CLOUDSTG_GET_TENMINUTES       600
#define  CLOUDSTG_GET_FIFTEENMINUTES   900
#define  CLOUDSTG_GET_THIRTYMINUTES    1800
#define  CLOUDSTG_GET_ONEHOUR          3600
#define  CLOUDSTG_GET_SIXHOUR          (6 * 3600)
#define  CLOUDSTG_GET_ONEDAY           (24 * 3600)
#define  CLOUDSTG_GET_ONEWEEK          (7 * 24 * 3600)

#define  CLOUDSTG_NET_CHECK 0

typedef enum enum_cloudstg_msg_type
{
    EN_CLOUDSTG_MSG_ALIVE_UPLOAD = 1,
    EN_CLOUDSTG_MSG_TF_UPLOAD    = 2,
    EN_CLOUDSTG_MSG_TF_FORMAT    = 3,
}EN_CLOUDSTG_MSG_TYPE;

typedef struct stru_CLOUDSTG_EVENT_INFO
{
    _UI              uiUseFlag;
    _UI              uiEventType;
    _CTIME_T         tStartTime;
    _CTIME_T         tBreakTime;
}ST_CLOUDSTG_EVENT_INFO;

typedef struct stru_cloudstg_alive_upload_msg
{
    ST_MOS_MSGHEAD stMsgHead;
    _INT iCamid;
    _INT iStreamId;
    _INT iEventType;   // 2 定时 1 报警
    _UI  uiDuration;
    _UI  uiContrlType; // 0 停止 1 开始 
    _CTIME_T tCreateTime;
    ST_CLOUDSTG_EVENT_INFO stEventInfo;
}ST_CLOUDSTG_ALIVE_UPLOAD_MSG;
    

#endif