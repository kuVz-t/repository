#ifndef  CLOUDSTG_MANAGE_H
#define CLOUDSTG_MANAGE_H
#ifdef __cplusplus
extern "C"
{
#endif

#include "record_api.h"
#include "cloudstg_config.h"

#define CLOUDSTG_USE_LOGGER_MODULE        1     // 使用单独的日志模块

typedef enum enum_CLOUDSTG_DIRECT_MODE_TYPE
{
    EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL = 0X01, // 文件上传模式
    EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE  = 0X03, // 端切片模式
    EN_CLOUDSTG_DIRECT_MODE_TYPE_STS    = 0X04, // STS模式
}EN_CLOUDSTG_DIRECT_MODE_TYPE;

typedef enum enum_CLOUDSTG_ICON_UPLOAD_TYPE
{
    EN_CLOUDSTG_ICON_UPLOAD_TYPE_NONE    = 0X00, // ICON未上传
    EN_CLOUDSTG_ICON_UPLOAD_TYPE_SENT    = 0X01, // ICON已上传
    EN_CLOUDSTG_ICON_UPLOAD_TYPE_SUCCESS = 0X02, // ICON上传成功
    EN_CLOUDSTG_ICON_UPLOAD_TYPE_FAIL    = 0X03, // ICON上传失败
}EN_CLOUDSTG_ICON_UPLOAD_TYPE;

typedef enum enum_CLOUDSTG_VIDEO_UPLOAD_TYPE
{
    EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NONE         = 0X00, // VIDEO未上传
    EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_SUCCESS      = 0X01, // VIDEO上传成功
    EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL = 0X02, // VIDEO上传失败
    EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_LOCAL_FAIL   = 0X03, // VIDEO本地文件错误
}EN_CLOUDSTG_VIDEO_UPLOAD_TYPE;

typedef enum enum_CLOUDSTG_STORAGE_TYPE
{
    EN_CLOUDSTG_STORAGE_TYPE_UNKNOWN = 0X00,
    EN_CLOUDSTG_STORAGE_TYPE_ALIVE   = 0X01,
    EN_CLOUDSTG_STORAGE_TYPE_TFCARD   = 0X02    
}EN_CLOUDSTG_STORAGE_TYPE;

typedef enum enum_CLOUDSTG_TASK_STATUS
{
    EN_CLOUDSTG_TASK_INIT        = 0x00,
    EN_CLOUDSTG_TASK_START       = 0x01,
    EN_CLOUDSTG_TASK_STOP        = 0x02,
    EN_CLOUDSTG_TASK_WAITING     = 0x03,
    EN_CLOUDSTG_TASK_OVER        = 0x04,
    EN_CLOUDSTG_TASK_COMMINT     = 0X05,
    EN_CLOUDSTG_TASK_COMMINTINF  = 0X06,
    EN_CLOUDSTG_TASK_END         = 0X07
}EN_CLOUDSTG_TASK_STATUS;

typedef enum enum_CLOUDSTG_LOG_ERROR_TYPE
{
    EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME = 0X00, // GetHostByName失败
    EN_CLOUDSTG_LOG_ERROR_TYPE_JSON_PARSE    = 0X01, // json解析失败
    EN_CLOUDSTG_LOG_ERROR_TYPE_JSON_PARA     = 0X02  // json参数错误（缺失）
    // TODO:
}EN_CLOUDSTG_LOG_ERROR_TYPE;

typedef enum enum_CLOUDSTG_UPLOAD_MODE
{
    CLOUDSTG_UPLOAD_MODE_EVENT  = 0x01,
    CLOUDSTG_UPLOAD_MODE_ALLDAY = 0x02,
}EN_CLOUDSTG_UPLOAD_MODE;

typedef struct stru_CLOUDSTG_FILE_PACKET
{
    _UC aucPacket[1500];
    _UI uiAvFlag;
    _UI uiOffSet;
    _UI uiFramePos; 
    _UI uiPacketLen;
    _UI uiTimeStamp;
    
}ST_CLOUDSTG_FILE_PACKET;

typedef struct stru_CBRD_CLOUDSTG_LOCALPARA
{
    _BOOL                      bReadEvent;      //是否需要读取下一个event.当前的event开始处理时，就要读取下一个event.如果下一个event还没发生，会置uiNextTimeBase为max，且要不停读取
    _BOOL                      bFisrtframe;     //是否是读取的第一帧
    _UI                        uiReadPos;
    
    _HANDLE                    hDataFile;       //文件句柄
    _CTIME_T                   tReadEventTime;
    ST_MOS_SYS_TIME            tReadEventSystime;      //当前正在处理的event，属于哪一天
    ST_CLOUDSTG_EVENT_INFO        stCurEvent;
    ST_CLOUDSTG_FILE_PACKET       stPacketInfo;    //读取的包信息
}ST_CLOUDSTG_LOCALPARA;


typedef struct stru_CLOUDSTG_RTIMEPARA
{
    _BOOL                      bSendFstFrame;
    _HVIDEOREAD                hVideoRead;
    _HAUDIOREAD                hAudioRead; 
    _HRTSMEDIAREAD             hMediaRead;   // include audio & video, used for cloud patch.
}ST_CLOUDSTG_RTIMEPARA;

typedef struct stru_CLOUDSTG_COMMIT_NODE
{
    _UI             uiType;
    _UI             uiUseStatus;
    _UI             uiTaskId;
    _UI             uiState;//0 等待填充 1申请commit 2commit成功
    _UI             uiRecvLen;
    _UI             uiBuffLen;
    _UC             *pucRecvBuff;
    _UI             uiHttpHandle;
    _UI             uiTryTime;
    _UC             aucCloudId[64];
    _UC             aucFileName[64];
    _UC             aucObjId[128];
    _UC             aucETag[128];
    _UI             uiFileLen;
    _UC             aucFileCId[128];
    _UC             aucFileSP[16];
    _UC             aucIconInfo[256];
    _CTIME_T        cReqTime;
    _CTIME_T        cNextReqTime;
    _CTIME_T        cCreatTime;
    _CTIME_T        cAlarmTime;
}ST_CLOUDSTG_COMMITINFO;

typedef struct stru_CLOUDSTG_EVENTCLOUD
{
    _INT iSwitch;      // 事件云存追加开关
    _INT iMaxTime;     // 事件云存最大秒数
    _INT iMinTime;     // 事件云存最小秒数
    _INT iDetectTime;  // 事件云存检测秒数
    _INT iAppendTime;  // 事件云存追加录制秒数
}ST_CLOUDSTG_EVENTCLOUD;

typedef struct stru_CLOUDSTG_TASK_NODE
{
    /*****************需保存****************/
    _UC                        pucUuid[17];  // uuid
    _INT                       iCamId;       // 摄像头ID
    _INT                       iEventType;   // 1：移动侦测 2：无移动侦测
    /*EN_CLOUDSTG_RESOURCE_NONE       参数无意义 EN_CLOUDSTG_RESOURCE_STREAM 视频文件 EN_CLOUDSTG_RESOURCE_PIC  图片
      EN_CLOUDSTG_RESOURCE_LOGFILE    本地日志   EN_CLOUDSTG_RESOURCE_LOG    日志*/
    _INT                       iTaskType;
    _INT                       iStorageType; // EN_CLOUDSTG_STORAGE_TYPE
    _INT                       iCloudUpLoadMode;// 云存上传模式
    _UI                        uiDuration;   // 上传持续时间
    _CTIME_T                   tCreateTime;  // 任务创建时间
    _CTIME_T                   tFailTime;    // 任务失败时间

    /*****************无需保存****************/
    _UI                        uiTaskId;     // 任务ID
    _INT                       iStreamId;    // 码流ID
    _INT                       iUseFlag;     // 0：未使用 1：使用中
    _INT                       iState;       // 状态 EN_CLOUDSTG_TASK_STATUS

    _INT                       iNeedKeyFlag; // 需要关键帧
    _UI                        uiHttpHandle; // http句柄
    _UI                        uiIconStatus; // 1 已发送,2 发送成功, 3 发送失败
    
    _UI                        uiUploadFlag; // 0 未上传 1 上传成功 2 上传失败 3 本地文件错误
    _UI                        uiTotalCnt;   // 当前任务总数
    _UI                        uiLastStamp;  // 用于计算累计时间戳长度
    
    _UI                        uiAllStamp;   // 总的时间戳长度
    _UI                        uiSliceStamp; // 切片时间戳长度
    _UI                        uiTotalStamp; // 需要上传 多久 
    _INT                       iForceCommit; // 强制commit
    _INT                       iAllSentBytes;   // 当前任务发送的bytes
    _CTIME_T                   tAlarmTimeStamp; // 消息告警时间戳
    _CTIME_T                   tStartTime;   // 任务开始时间
    _INT                       iDirectMode;  // 传输模式:1、流直传；3、端切片；4、STS
    _INT                       iExSentCount; // 端切片切片发送成功次数
    _INT                       iExLastSentInterval; // 最后发送的时长
    _UI                        uiFailInMid; // 中途失败commit
    _CTIME_T                   tFailInMidStartTime; // 中途失败时间，也是补录的开始时间
    _INT                       iTotalSentCount; // 总共发送次数
    _INT                       iRetrySentCount; // 总共重传次数
    _UI                        uiMaxBuffNum; // 最大支持BufList节点
    _UI                        uiAutoCommit; // 0: 设备commit 其他：平台commit
    _CTIME_T                   tStsCreateTime; // 构建STS文件名使用
    _UI                        uiIsPatch; // 是否补录

    /*加密信息*/
    _INT                       iCloudEncPKId;
    _UC                        aucCloudEncPKValue[CFG_STRING_SDP_LENGTH + 4];
    _INT                       iCloudEncSwitch;
    _INT                       iCloudEncType;
    _INT                       iCloudEncLen;
    _UC                        aucCloudEncAesKey[CFG_STRING_COMMONLEN + 4];
    _UC                        aucCloudEncAesIv[CFG_STRING_COMMONLEN + 4];
    _UC                        aucCloudEncHttpParamJson[CFG_STRING_SDP_LENGTH + 4];
    _UC                        aucCloudEncHttpParam[CFG_STRING_SDP_LENGTH + 4];
    _UC                        aucCloudEncHttpUploadParam[CFG_STRING_SDP_LENGTH + 4];

    _RDFILEFD                  hHandle;
    _HSTREAM                   hStream;
    union
    {
       ST_CLOUDSTG_LOCALPARA   stLocalPara;
       ST_CLOUDSTG_RTIMEPARA   stRTimePara;
    }u;
    ST_CLOUDSTG_COMMITINFO     stCommitInfo;
    ST_CLOUDSTG_EVENT_INFO     stEventInfo;
    ST_CLOUDSTG_EVENTCLOUD     stEventCloud; // 事件云存追加信息
    ST_MOS_LIST_NODE           stNode;
    _UI                        iOldState;
    _UI                        iLogCount;
    _UI                        uiConnType;    // IPv4/IPv6连接
    _UI                        uiHasIpv6;
}ST_CLOUDSTG_TASK_NODE;

typedef struct stru_CLOUDSTG_FILE_NODE
{
    _UI                        uiMediaTaskId;
    _UI                        uiUseFlag;
    _UI                        uiStatus;
    _UI                        uiIcon;
    _UI                        uiUpLoadFileFlag; // 1 上传 文件 成功 2 上传文件失败
    _UI                        uiUpDateFlag;  // 1 跟新文件描述成功 ， 2 跟新文件描述失败
    _UI                        uiTaskType;  // 0 实时图片 1 本地文件图片 2 日志文件 3 定时抓图
    _UI                        uiFileType;  // 0 none     1 视频     2 图片     3 日志
    _UI                        uiTickCnt; // 
    _UI                        uiSnapCnt;
    _UI                        uiRealCnt;
    _UI                        uiPicNum; // 总的 图片 数
    _INT                       iSnapInterval;
    _INT                       iStopFlag;
    _INT                       iPicType;
    _INT                       iCamId; 
    _INT                       iEventType;  //1 事件     2 全天
    _INT                       iSnapRetry;
    _UI                        uiTaskId;
    _UI                        uiBuffLen;
    _UI                        uiOffset;
    _UI                        uiHttpHandle;
    _UC                        *pucBuff;
    _UC                        aucEidName[64];
    _UC                        aucToken[256];
    _UC                        aucFileName[256];
    _UC                        *pucDesBuff;

    /* log */
    _UC                        *pucUrl;
    _UC                        *pucMsg;
    _UC                        *pucEt;
    _INT                       iHostStatus;
    _INT                       iRt;

    _CTIME_T                   tNextSnTime;
    _CTIME_T                   tUpInfoTime;
    _CTIME_T                   tCreatTime;

    PFUN_CLOUDFILESENDCB       pFunCloudFileSendCb;
    ST_CLOUDSTG_COMMITINFO        stCommitInfo;
    ST_MOS_LIST_NODE           stNode;
}ST_CLOUDSTG_FILE_NODE;

typedef struct stru_CLOUDSTG_CHARGE
{
    _UI                        uiRecvLen;
    _UI                        uiBuffLen;
    _UC                        *pucRecvBuff;
    _UI                        uiHttpHandle;
    _UI                        uiTryTime;
    _UI                        uiState; //0 正在请求 1已发请求
    _UI                        uiOgctId;
    _CTIME_T                   cReqTime;
    _CTIME_T                   cNextReqTime;
}ST_CLOUDSTG_CHARGE;

typedef struct stru_CLOUDSTG_EVENT_UPLOAD_INF
{
    _CTIME_T                    cStarTime;                    // 事件云存埋点开始时间
    _CTIME_T                    cUploadTime;                  // 事件云存埋点上报时间
    _UI                         uiTriggerNum;                 // 事件触发次数
    _UI                         uiUploadNum;                  // 事件云存上传次数
    _UI                         uiSuccessUploadNum;           // 事件云存上传成功次数
    _US                         ausUploadOffset[512];         // 事件云存上传时间偏移值(s)
    _US                         ausSuccessUploadOffset[512];  // 事件云存上传成功时间偏移值(s)
}ST_CLOUDSTG_EVENT_UPLOAD_INF;

// #define USE_SNAP_STACK
typedef struct stru_CLOUDSTG_MANAGE
{
    _UC                    ucInitFlag;           
    _UC                    ucRunFlag;
    _UC                    ucCameraStatusChangeFlag;       // 休眠状态变更标志，0 无变更 1 有变更
    _UC                    ucRsv;
    _INT                   iOpenFlag;
    _INT                   iReadyToRebootFlag;             // 设备即将重启
    _INT                   iForceCommitTaskCount;          // 需要强制commit的task数量
    _INT                   iQualityTotalSentBytes;         // 质量探针总发送字节（正常）
    _INT                   iQualityTotalPatchSentBytes;    // 质量探针总发送字节（补录）
    _INT                   iQualityTotalSentInterval;      // 质量探针总发送时间（正常）
    _INT                   iQualityTotalPatchSentInterval; // 质量探针总发送时间（补录）
    _HMUTEX                hMutex;
    _HQUEUE                hMsgQueue;                   // 消息队列
    _HTHREAD               hMgrThread;
    _CTIME_T               tCheckTime;
    _CTIME_T               tNetCheckTIme;
    _CTIME_T               tDisconnetTime;
    _CTIME_T               tQualityLastReqTime;         // 质量探针上次请求时间
    _UI                    uiCurNetStatus;              // 0 无网 1 有网 
    _INT                   iBanReadVideoFlag;           // DEBUG:
    _UI                    uiFirstCommitFlag;           // 第一次Commit Flag
    ST_CLOUDSTG_CHARGE     stCloudCharge;               // 判断 云存是否 开通 套餐
    ST_MOS_LIST            stTaskList;                  // 上传任务队列 ST_CLOUDSTG_TASK_NODE
    ST_MOS_LIST            stFileList;                  // 文件上传 ST_CLOUDSTG_FILE_NODE
#ifdef USE_SNAP_STACK
    _UC                    pucPicBuf[350*1024];
#else
    _UC                    *pucPicBuf;
    _INT                   iPicBufLen;
#endif
    _UI                          uiCloudEventUploadInfSwitch;   // 事件云存埋点上报开关
    _UI                          uiCloudEventUploadInfInterval; // 事件云存埋点上报周期(m)
    _UI                          uiCloudEventUploadInfInitFlag; // 事件云存埋点上报初始化标志，0：未初始化，1：已初始化
    _UI                          uiStartNextEventCloudFlag;     // 事件云存追加超过最大秒数，立即创建下一个云存
    ST_CLOUDSTG_EVENT_UPLOAD_INF stCloudEventUploadInf;
    ST_CLOUDSTG_CONFIG           stCloudConfig;
}ST_CLOUDSTG_MANAGE;

// 获取云存全局变量句柄
ST_CLOUDSTG_MANAGE *CloudStg_GetMng();

// 云存ExtFileNode设置Used
_INT CloudStg_FileNodeSetUsed(_UI uiTaskId);

// 用于选择正常/补录云存主程序
_INT CloudStg_ProcMediaUpdate(ST_CLOUDSTG_TASK_NODE *pstTaskNode, _UC isPatch);

// 设置消息告警的时间戳
_INT CloudStg_SetAlarmTimeStamp(_INT iCamId,_INT iStreamId, _CTIME_T tTimeStamp);

// 统计发送数据量
_INT CloudStg_AddSentBytes(_UI uiIsPatch, _INT iCamId, _UI uiTaskId, _INT iSentBytes);

// 生成随机UUID
_INT CloudStg_RandomUuid(_UC ucBuf[37]);

// 实时日志aes加密base64签名
_UC *CloudStg_AesBase64Enc(_UC *pucInput);

// 云存URL ENCODE
_INT CloudStg_URLEncode(const char* str, const int strSize, char* result, const int resultSize);

// 时间戳+随机值
_INT Cloudstg_GetTimeMixUuid(_UC *ucString, _INT iSize);

// 云存任务判断是否需要连接url信息
_BOOL CloudStg_TaskNeedConnUrl(_INT iIsDirectModeChange);

// 关闭云存所有普通任务
_INT Cloudstg_CloseAllNormalAliveTask();

// 关闭云存所有补录任务
_INT Cloudstg_CloseAllPatchAliveTask();

// 事件云存追加逻辑处理函数
_VOID CloudStg_EventCloudAppendHandler(ST_CLOUDSTG_TASK_NODE *pstTmpNode);

#ifdef __cplusplus
}
#endif
#endif
