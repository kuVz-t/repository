#ifndef  CLOUDSTG_STREAM_PRV_H
#define  CLOUDSTG_STREAM_PRV_H

typedef struct stru_CBRD_CLOUDSTG_FRAME_SEQ
{
   _UI uiPos;
   _UI uiTimeStamp;
   ST_MOS_LIST_NODE stNode;
}ST_CLOUDSTG_FRAME_SEQ;

typedef struct stru_cLoud_Packet_data
{
    _US usVSeqNum;
    _US usASeqNum;
    _UC aucPacket[1500];
}ST_CLOUDSTG_PACKET_DATA;

typedef struct stru_CBRD_CLOUDSTG_STREAM
{
    _INT                          iCamId;
    _INT                          iFirstFrame;
    _INT                          iCloudEncSwitch;
    _UI                           uiTotalSendLen;
    _UI                           uiCurSliceSendLen;  // cur slice send len
    _UI                           uiSliceLen;
    _UI                           uiMediaLen;
    _UI                           uiStreamInfoLen;
    _UI                           uiType;// 上传类型

    _UI                           uiNeedWrite;
    _UI                           uiLeftNodeSize;
    _INT                          iFrameLen;

    _UI                           uiATimeStamp;
    _UI                           uiVTimeStamp;
    _UI                           uiVDuration;
    _UI                           uiADuration;

    _UI                           uiSliceStartStamp;
    _UI                           uiSliceEndStamp;

    _UI                           uiIndexLen;
    _UC                           aucIndexInfo[4104];
    _UI                           uiLITimeStamp;
    _UI                           uiICount;
    _UI                           uiIPos;
    _HCSTASK                      hCSTask;

    // 端切片
    _UI                           uiWriteTaskCurPos;
    _UI                           uiReadTaskCurPos;
    _UI                           uiFirstSendFlag;
    _HMUTEX                       hMutex;
    _HMUTEX                       hTaskGroupMutex;
    _HMUTEX                       hTaskCurPosMutex;
    _INT                          iDirectMode;
    _INT                          iExSentCount;
    _INT                          iAliveTaskId;
    _UI                           uiBiteRate;
    _INT                          iDropGopNum; // 端切片即将丢弃指定数量的GOP
    _INT                          iDropGopFlag;
    _UI                           uiForceCloseFlag;
    _INT                          iExTransTaskReleaseCount; // 端切片已释放的chan数量

    ST_MOS_LIST                   stFrameSeqList;  // ST_CLOUDSTG_FRAME_SEQ
    ST_ZJ_AUDIO_PARAM             stAudioParm;
    ST_CFG_VIDEODES               stVideoDes;
    ST_CLOUDSTG_PACKET_DATA          stPacketData;
    
}ST_CLOUDSTG_STREAM;

#endif


