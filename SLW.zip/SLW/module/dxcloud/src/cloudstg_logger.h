#ifndef _CLOUDSTG_LOGGER_H_
#define _CLOUDSTG_LOGGER_H_

#ifdef __cplusplus
extern "C"
{
#endif

#define SINGLE_THREAD                           0    // 是否独立线程

#define CLOUDSTG_LOGGER_QUEUE_NUM               4    // 日志队列数量
#define CLOUDSTG_LOGGER_URL_MAX_LEN             256  // 日志URL最大长度
#define CLOUDSTG_LOOGER_MSG_MAX_LEN             256  // 日志MSG最大长度
#define CLOUDSTG_LOOGER_EXTRA_DATA_MAX_LEN      10240  // 日志额外数据最大长度
#define CLOUDSTG_LOGGER_REPEAT_STR_RESERVE_BYTE 8    // 日志上传重复字段（"xN"）预留空间大小

typedef enum enum_CLOUDSTG_LOGGER_LEVEL
{
    EN_CLOUDSTG_LOGGER_LEVEL_IMPORTANT   = 0,        // 重要日志
    EN_CLOUDSTG_LOGGER_LEVEL_ERROR       = 1,        // 错误日志
    EN_CLOUDSTG_LOGGER_LEVEL_CORE        = 2,        // 核心日志
    EN_CLOUDSTG_LOGGER_LEVEL_NORMAL      = 3         // 普通日志
}ENUM_CLOUDSTG_LOGGER_LEVEL;

typedef struct stru_CLOUDSTG_LOGGER_NODE
{
    _UI                      uiNodeId;               // 节点ID
    _UI                      uiUsed;                 // 是否正在使用
    _UI                      uiRepeatCount;          // 重复次数
    _CTIME_T                 tCreateTime;            // 创建时间

    /*日志*/
    _UC                      *pucUrl;                // 请求地址
    _UC                      *pucMsg;                // 消息
    _UC                      *pucEt;                 // 额外数据
    _INT                     iHostStatus;            // http状态码
    _INT                     iRt;                    // 返回值
    _INT                     iLevel;                 // 等级：详情见ENUM_CLOUDSTG_LOGGER_LEVEL枚举定义

    ST_MOS_LIST_NODE         stNode;
}ST_CLOUDSTG_LOGGER_NODE;

typedef struct stru_CLOUDSTG_LOGGER_MANAGE   
{   
    _UC                    ucInitFlag;                              // 初始化标志位
    _UC                    ucRunFlag;                               // 运行标志位
    _HTHREAD               hMgrThread;                              // 线程句柄
    _UI                    uiLogNum;                                // 日志的数量
    _UI                    uiDropNum;                               // 日志被丢失的数量
    _UC                    ucDropNumSendFlag;                       // 日志被丢失的数量发送状态 0: 未发送 1：正在发送
    _CTIME_T               tDropNumSendTime;                        // 日志被丢失的数量提醒发送时间

    _HMUTEX                hMutex[CLOUDSTG_LOGGER_QUEUE_NUM];       // 日志读写锁
    _CTIME_T               tSendTime[CLOUDSTG_LOGGER_QUEUE_NUM];    // 日志发送时间
    ST_MOS_LIST            stLoggerList[CLOUDSTG_LOGGER_QUEUE_NUM]; // 日志模块链表
}ST_CLOUDSTG_LOGGER_MANAGE;

ST_CLOUDSTG_LOGGER_MANAGE *CloudStg_LoggerGetMng();
_INT CloudStg_LoggerInit();
_INT CloudStg_LoggerStart();
_INT CloudStg_LoggerStop();
_INT CloudStg_LoggerDestroy();
#if SINGLE_THREAD
_INT CloudStg_LoggerProc();
#else
_INT CloudStg_LoggerProc(_CTIME_T cNowTime);
#endif
_INT CloudStg_LoggerPushLog(_UI uiReqId, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC *pucEt, _INT iLevel);
_INT CloudStg_LoggerSend(_INT iLoggerIndex);
_INT CloudStg_LoggerDeleteNode(ST_MOS_LIST *stLoggerList, ST_CLOUDSTG_LOGGER_NODE *stLoggerNode);
_INT CloudStg_LoggerAddDropNum(_INT iDropNum, _UC ucForceReset);
#ifdef __cplusplus
}
#endif

#endif