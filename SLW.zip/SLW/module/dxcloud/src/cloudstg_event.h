#ifndef _CLOUDSTG_EVENT_H
#define _CLOUDSTG_EVENT_H

#ifdef __cplusplus
extern "C" {
#endif

#define CLOUDSTG_DIR                               (_UC*)"cloud"
#define CLOUDSTG_DATECFG_NAME                      (_UC*)"CloudDate.txt"
#define CLOUDSTG_FILEDES_NAME                      (_UC*)"Cloud.txt"

#define CLOUDSTG_AUTODELETE 2

typedef struct st_CLOUDSTG_DATE
{
    _UC ucCheck;
    _UC ucBInUse;
    _UC ucRsv[2];
    _UC aucDate[12];
}ST_CLOUDSTG_DATE;

typedef struct st_CLOUDSTG_EVENT_NODE
{
    ST_CLOUDSTG_EVENT_INFO stEventInfo;
    ST_MOS_LIST_NODE stNode;
}ST_CLOUDSTG_EVENT_NODE;

_INT CloudStg_AddDefaultEvent(_INT iCamId,_CTIME_T cNowTime,_UI uiEventType);

_INT CloudStg_AddOneEvent(ST_CLOUDSTG_EVENT_INFO *pstEventinfo);

_INT CloudStg_DeleteOneEvent(_CTIME_T cStartTime);

_INT CloudStg_AutoDelete();

ST_MOS_LIST *CloudStg_QueryInfo();

#ifdef __cplusplus
}
#endif

#endif