#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "config_api.h"
#include "record_api.h"
#include "media_cache_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_stream.h"
#include "cloudstg_manage.h"
#include "cloudstg_transaddress.h"
#include "cloudstg_event.h"
#include "cloudstg_patch.h"
#include "cloudstg_logcode.h"
#include "msgmng_event.h"
#include "msgmng_api.h"
#include "cloudstg_aliveupload.h"
#include "qualityprobe_api.h"
#include "cloudstg_logcode.h"
#include "msgmng_quality_statistics.h"

static _UC* CloudStg_BuildMediaCommitReqData(ST_CLOUDSTG_TASK_NODE *pstTaskNode, _UI uiIsPatch)
{
    MOS_PARAM_NULL_RETNULL(pstTaskNode);

    _INT i;
    _INT iFixLen = 0;
    _INT iTotalLen = 0;
    _UC aucURLEnc[2048] = {0};
    _UC *pstrTmp = MOS_NULL;
    _UC *pucParams = MOS_NULL;
    _UC *pucSignBuff = MOS_NULL;
    _UC aucTime[32] = {0};
    _UC aucAesParams[2048] = {0};
    _UC aucBuff[2048] = {0}; // FIXME: For cloud enc
    _UC aucAesKey[128] = {'\0'};
    _LLID llMilliSecTime = 0;
    _CTIME_T cExEndTime = 0;
    _CTIME_T cEndTime = 0;
    _CTIME_T cDuration = 0;
    _CTIME_T cNowTime = Mos_Time();
    ST_MOS_SYS_TIME stSysTime1,stSysTime2;

    JSON_HANDLE hRoot = MOS_NULL, hValue = MOS_NULL;
    ST_CFG_CLOUDSTG_MNG *pstCloudInfo = Config_GetCloudMng();
    ST_CFG_SYSTEM_MNG *pstCompanyInf = Config_GetSystemMng();
    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }
    
    // 中途失败commit
    if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL && pstTaskNode->uiFailInMid)
    {
        cEndTime = pstTaskNode->tFailInMidStartTime;
        Mos_TimetoSysTime(&pstTaskNode->tCreateTime,&stSysTime1);
        Mos_TimetoSysTime(&cEndTime,&stSysTime2);
    }
    else if (pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE && pstTaskNode->uiFailInMid)
    {
        cExEndTime = pstTaskNode->tCreateTime + (CloudStg_TaskGetExSentCount(0, pstTaskNode->uiTaskId, uiIsPatch) * Config_GetCloudMng()->iSliceDuration) + CloudStg_TaskGetExLastSentInterval(0, pstTaskNode->uiTaskId, uiIsPatch) / 1000;
        pstTaskNode->tFailInMidStartTime = cExEndTime;
        Mos_TimetoSysTime(&pstTaskNode->tCreateTime,&stSysTime1);
        Mos_TimetoSysTime(&cExEndTime,&stSysTime2);
    }
    else
    {
        cEndTime = pstTaskNode->tCreateTime + pstTaskNode->uiAllStamp / 1000;
        Mos_TimetoSysTime(&pstTaskNode->tCreateTime,&stSysTime1);
        Mos_TimetoSysTime(&cEndTime,&stSysTime2);
    }

    if (uiIsPatch)
    {
#if 0
        // 移动检测
        if(pstTaskNode->iEventType == 1)
        {
            MOS_VSNPRINTF(pstTaskNode->stCommitInfo.aucFileName,64,"%04hu%02hu%02hu%02hu%02hu%02hu-%04hu%02hu%02hu%02hu%02hu%02hu_ALARM#.ps",
                stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond,
                stSysTime2.usYear,stSysTime2.usMonth,stSysTime2.usDay,stSysTime2.usHour,stSysTime2.usMinute,stSysTime2.usSecond);
        }
        // 无移动检测
        else if(pstTaskNode->iEventType == 2)
        {
            MOS_VSNPRINTF(pstTaskNode->stCommitInfo.aucFileName,64,"%04hu%02hu%02hu%02hu%02hu%02hu-%04hu%02hu%02hu%02hu%02hu%02hu#.ps",
                stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond,
                stSysTime2.usYear,stSysTime2.usMonth,stSysTime2.usDay,stSysTime2.usHour,stSysTime2.usMinute,stSysTime2.usSecond);
        }
#else
        // 移动检测
        if(pstTaskNode->iEventType == 1)
        {
            MOS_VSNPRINTF(pstTaskNode->stCommitInfo.aucFileName,64,"%04hu%02hu%02hu%02hu%02hu%02hu-%04hu%02hu%02hu%02hu%02hu%02hu_ALARM.ps",
                stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond,
                stSysTime2.usYear,stSysTime2.usMonth,stSysTime2.usDay,stSysTime2.usHour,stSysTime2.usMinute,stSysTime2.usSecond);
        }
        // 无移动检测
        else if(pstTaskNode->iEventType == 2)
        {
            MOS_VSNPRINTF(pstTaskNode->stCommitInfo.aucFileName,64,"%04hu%02hu%02hu%02hu%02hu%02hu-%04hu%02hu%02hu%02hu%02hu%02hu.ps",
                stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond,
                stSysTime2.usYear,stSysTime2.usMonth,stSysTime2.usDay,stSysTime2.usHour,stSysTime2.usMinute,stSysTime2.usSecond);
        }
#endif
    }
    else
    {
        // 移动检测
        if(pstTaskNode->iEventType == 1)
        {
            MOS_VSNPRINTF(pstTaskNode->stCommitInfo.aucFileName,64,"%04hu%02hu%02hu%02hu%02hu%02hu-%04hu%02hu%02hu%02hu%02hu%02hu_ALARM.ps",
                stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond,
                stSysTime2.usYear,stSysTime2.usMonth,stSysTime2.usDay,stSysTime2.usHour,stSysTime2.usMinute,stSysTime2.usSecond);
        }
        // 无移动检测
        else if(pstTaskNode->iEventType == 2)
        {
            MOS_VSNPRINTF(pstTaskNode->stCommitInfo.aucFileName,64,"%04hu%02hu%02hu%02hu%02hu%02hu-%04hu%02hu%02hu%02hu%02hu%02hu.ps",
                stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond,
                stSysTime2.usYear,stSysTime2.usMonth,stSysTime2.usDay,stSysTime2.usHour,stSysTime2.usMinute,stSysTime2.usSecond);
        }
    }

    MOS_VSNPRINTF(aucTime,32,"timestamp=%u",cNowTime);
    MOS_VSNPRINTF(aucBuff, 8, (_UC*)"%02x%02x", EN_CLOUDSTG_TRANS_BUFF, EN_CLOUDSTG_UPLOAD_FILE_REQ);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"METHOD", Adpt_Json_CreateString((_UC*)aucBuff));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstTaskNode->uiTaskId));

    hValue = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hValue, (_UC*)"uid", Adpt_Json_CreateString(pstCompanyInf->aucDevUID));
    Adpt_Json_AddItemToObject(hValue, (_UC*)"appKey", Adpt_Json_CreateString(pstCloudInfo->aucAppKey));

    llMilliSecTime = pstTaskNode->tCreateTime ;
    llMilliSecTime = llMilliSecTime * 1000;
    if (pstTaskNode->iCloudEncSwitch == 1)
    {
        MOS_VSNPRINTF(aucBuff, 2048, (_UC*)"%s&cloudId=%s&fileName=%s&objId=%s&ETag=%s&fileLen=%u&cId=%s&SP=%s&%s&fileUploadTime=%llu&videoCipher=%s",
                                        aucTime,
                                        pstCloudInfo->aucCloudId,
                                        pstTaskNode->stCommitInfo.aucFileName,
                                        pstTaskNode->stCommitInfo.aucObjId,
                                        pstTaskNode->stCommitInfo.aucETag,
                                        pstTaskNode->stCommitInfo.uiFileLen,
                                        pstTaskNode->stCommitInfo.aucFileCId,
                                        pstTaskNode->stCommitInfo.aucFileSP,
                                        pstTaskNode->stCommitInfo.aucIconInfo,
                                        llMilliSecTime,
                                        pstTaskNode->aucCloudEncHttpParam);
    }
    else
    {
        MOS_VSNPRINTF(aucBuff, 2048, (_UC*)"%s&cloudId=%s&fileName=%s&objId=%s&ETag=%s&fileLen=%u&cId=%s&SP=%s&%s&fileUploadTime=%llu",
                                        aucTime,
                                        pstCloudInfo->aucCloudId,
                                        pstTaskNode->stCommitInfo.aucFileName,
                                        pstTaskNode->stCommitInfo.aucObjId,
                                        pstTaskNode->stCommitInfo.aucETag,
                                        pstTaskNode->stCommitInfo.uiFileLen,
                                        pstTaskNode->stCommitInfo.aucFileCId,
                                        pstTaskNode->stCommitInfo.aucFileSP,
                                        pstTaskNode->stCommitInfo.aucIconInfo,
                                        llMilliSecTime);
    }

    // DEBUG: 打印云存commit参数
    // MOS_PRINTF("aucBuff: %s\r\n", aucBuff);
    pucParams = (_UC*)MOS_MALLOCCLR(2048);

    iTotalLen = MOS_STRLEN(pstCompanyInf->aucDevkey);
    if(iTotalLen < 16)
    {
        MOS_STRNCPY(aucAesKey, pstCompanyInf->aucDevkey, iTotalLen);
        MOS_STRNCPY(aucAesKey + iTotalLen, pstCompanyInf->aucDevkey , 16 - iTotalLen);
    }else{
        MOS_STRNCPY(aucAesKey, pstCompanyInf->aucDevkey, 16);
    }
    iTotalLen = MOS_STRLEN(aucBuff);
    iFixLen = 16 - (iTotalLen % 16);
    if(iFixLen != 0)
    {
        iTotalLen = iTotalLen + iFixLen;
        for(i=0;i<iFixLen;i++)
        {
            aucBuff[iTotalLen-iFixLen+i] = iFixLen;
        }
        aucBuff[iTotalLen] = '\0';
    }
    Adpt_Aec_Encrypt(aucAesKey,pstCloudInfo->aucAESVI,aucBuff,aucAesParams,iTotalLen);
    Adpt_Base64_Enc(aucAesParams,iTotalLen,pucParams);

    MOS_VSNPRINTF(aucBuff, 2048, "appKey=%s&params=%s&uid=%s", pstCloudInfo->aucAppKey, pucParams, pstCompanyInf->aucDevUID);
    pucSignBuff = (_UC*)MOS_MALLOCCLR(2048);
    Adpt_HmacSha256_Encrypt(aucBuff, pucSignBuff, 2048, pstCloudInfo->aucAppSecret );

    CloudStg_URLEncode((const char* )pucParams, strlen(pucParams), aucURLEnc, sizeof(aucURLEnc));
    Adpt_Json_AddItemToObject(hValue, (_UC*)"sign", Adpt_Json_CreateString(pucSignBuff));
    Adpt_Json_AddItemToObject(hValue, (_UC*)"params", Adpt_Json_CreateString(aucURLEnc));

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"BODY", hValue);
    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucSignBuff);
    MOS_FREE(pucParams);

    return pstrTmp;
}

static _INT CloudStg_RecvMediaCommitRspData(_UC *pucJson, _UC ucIsPatch)
{
    MOS_PARAM_NULL_RETERR(pucJson);
    _UC aucUrl[256]  = {0};
    _UC aucMsg[128]  = {0};
    _UC aucFunc[16]  = {0};
    _INT iValue = 0;
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(pucJson);

    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETCOMMIT_ADDRESS);
    if(hJsonRoot == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"recv null");
        MOS_VSNPRINTF(aucFunc, sizeof(aucFunc), "%scommit", ucIsPatch==0?"":"patch ");
        Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, aucFunc, aucUrl, EN_CLOUDSTG_RT_COMMIT_JSON_PARSE_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_JSON_PARSE);
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"),&iValue);
    if(iValue != 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"recv http code %u ",iValue);
        if(iValue == 20004)
        {
            CloudStg_InitChargeInfo();
        }
        // 函数返回已调用CloudStg_UploadLog
        MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD %scommit request fail, errocode: %d", ucIsPatch==0?"":"patch ", iValue);
        CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_COMMIT_FAIL, aucMsg, pucJson, 1);
        Adpt_Json_Delete(hJsonRoot);
        return MOS_ERR;
    }
    Adpt_Json_Delete(hJsonRoot);

    return MOS_OK;
}

_VOID CloudStg_GetMediaCommit_RecvAddrRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    _UI *uiTaskId = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList,pstTaskNode,stIterator)
    {
        if(pstTaskNode->iUseFlag == 1 && pstTaskNode->uiTaskId == *uiTaskId)
        {
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    if (pstTaskNode == MOS_NULL)
    {
        return;
    }
    if (pstTaskNode->stCommitInfo.uiBuffLen == 0)
    {
        pstTaskNode->stCommitInfo.uiBuffLen = 1024;
        pstTaskNode->stCommitInfo.pucRecvBuff = (_UC*)MOS_MALLOCCLR(1024);
    }
    if (pstTaskNode->stCommitInfo.uiRecvLen + uiLen < pstTaskNode->stCommitInfo.uiBuffLen)
    {
        MOS_MEMCPY(pstTaskNode->stCommitInfo.pucRecvBuff + pstTaskNode->stCommitInfo.uiRecvLen, pucData, uiLen);
        pstTaskNode->stCommitInfo.uiRecvLen += uiLen;
    }
    return;
}

_VOID CloudStg_GetMediaCommit_RecvAddrFail(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UI *uiTaskId                      = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
    _UC aucUrl[256] = {0};

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_CLOUD_VIDEO_COMMIT, uiUseTime);

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList,pstTaskNode,stIterator)
    {
        if(pstTaskNode->iUseFlag == 1 && pstTaskNode->uiTaskId == *uiTaskId)
        {
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    if (pstTaskNode == MOS_NULL)
    {
        return;
    }

    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETCOMMIT_ADDRESS);
    CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, uiErrCode, EN_CLOUDSTG_RT_COMMIT_TIMEOUT, "CD commit request timeout", pstTaskNode->stCommitInfo.pucRecvBuff, 1);

    MOS_FREE(pstTaskNode->stCommitInfo.pucRecvBuff);
    pstTaskNode->stCommitInfo.pucRecvBuff = MOS_NULL;
    // pstTaskNode->uiTaskId = 0;
    // pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
    pstTaskNode->stCommitInfo.uiRecvLen = 0;
    pstTaskNode->stCommitInfo.uiBuffLen = 0;
    // pstTaskNode->stCommitInfo.uiTryTime = 0;
    // pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;

    return;
}

_VOID CloudStg_GetMediaCommit_RecvAddrFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _UC aucUrl[256]                    = {0};
    _INT iRet                          = 0;
    _UI *uiTaskId                      = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
    ST_EVENTTASK_NODE *pstEventNode    = MOS_NULL;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_CLOUD_VIDEO_COMMIT, uiUseTime);

    Mos_MutexLock(&CloudStg_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stTaskList,pstTaskNode,stIterator)
    {
        if(pstTaskNode->iUseFlag == 1 && pstTaskNode->uiTaskId == *uiTaskId)
        {
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_GetMng()->hMutex);

    if (pstTaskNode == MOS_NULL)
    {
        return;
    }
    if (pstTaskNode->stCommitInfo.pucRecvBuff)
    {
        pstTaskNode->stCommitInfo.pucRecvBuff[pstTaskNode->stCommitInfo.uiRecvLen] = 0;
    }
    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETCOMMIT_ADDRESS);
    iRet = CloudStg_RecvMediaCommitRspData(pstTaskNode->stCommitInfo.pucRecvBuff, 0);
    if(iRet == MOS_ERR)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"ogctid %u Commit type Media fail,content %s",pstTaskNode->uiTaskId,pstTaskNode->stCommitInfo.pucRecvBuff);
        pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
    }
    else
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"ogctid %u Commit type Media success,content %s",pstTaskNode->uiTaskId,pstTaskNode->stCommitInfo.pucRecvBuff);
        if(pstTaskNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_TFCARD)
        {
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"TF card fix upload success,start time %u",pstTaskNode->tCreateTime);
        }
        CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_COMMIT_SUCCESS, "CD commit request successfully", pstTaskNode->stCommitInfo.pucRecvBuff, 1);
    }

    MOS_FREE(pstTaskNode->stCommitInfo.pucRecvBuff);
    pstTaskNode->stCommitInfo.pucRecvBuff = MOS_NULL;
    // pstTaskNode->uiTaskId = 0;
    pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
    pstTaskNode->stCommitInfo.uiBuffLen = 0;
    pstTaskNode->stCommitInfo.uiRecvLen = 0;
    pstTaskNode->stCommitInfo.uiTryTime = 0;

    // 传视频信息给相应的消息告警
#if 0
    pstEventNode = MsgMng_FindEventNodeByCTime(pstTaskNode->stCommitInfo.cAlarmTime);
    if (pstEventNode)// && pstEventNode->uiEventPushFlag == 1)
    {
        MOS_MEMSET(pstEventNode->ucFileCid, 0, sizeof(pstEventNode->ucFileCid));
        MOS_STRLCPY(pstEventNode->ucFileCid, pstTaskNode->stCommitInfo.aucFileCId, sizeof(pstEventNode->ucFileCid));

        MOS_MEMSET(pstEventNode->ucFileObjId, 0, sizeof(pstEventNode->ucFileObjId));
        MOS_STRLCPY(pstEventNode->ucFileObjId, pstTaskNode->stCommitInfo.aucObjId, sizeof(pstEventNode->ucFileObjId));

        // MOS_LOG_WARN(CLOUDSTG_LOGSTR, "uiIoTType: %d, ucEventNo: %s, ucPicObjId: %s, ucPicCid: %s, ucFileObjId: %s, ucFileCid: %s",
        //                                 pstEventNode->uiIoTType, pstEventNode->ucEventNo, pstEventNode->ucPicObjId, 
        //                                 pstEventNode->ucPicCid, pstEventNode->ucFileObjId, pstEventNode->ucFileCid);

        MsgMng_UploadEventMappingToDxServer(pstEventNode);
    }
#endif
    return;
}

_VOID CloudStg_Patch_GetMediaCommit_RecvAddrRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    _UI *uiTaskId = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList,pstTaskNode,stIterator)
    {
        if(pstTaskNode->iUseFlag == 1 && pstTaskNode->uiTaskId == *uiTaskId)
        {
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    if (pstTaskNode == MOS_NULL)
    {
        return;
    }
    if (pstTaskNode->stCommitInfo.uiBuffLen == 0)
    {
        pstTaskNode->stCommitInfo.uiBuffLen = 1024;
        pstTaskNode->stCommitInfo.pucRecvBuff = (_UC*)MOS_MALLOCCLR(1024);
    }
    if (pstTaskNode->stCommitInfo.uiRecvLen + uiLen < pstTaskNode->stCommitInfo.uiBuffLen)
    {
        MOS_MEMCPY(pstTaskNode->stCommitInfo.pucRecvBuff + pstTaskNode->stCommitInfo.uiRecvLen, pucData, uiLen);
        pstTaskNode->stCommitInfo.uiRecvLen += uiLen;
    }
    return;
}

_VOID CloudStg_Patch_GetMediaCommit_RecvAddrFail(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UI *uiTaskId                      = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
    _UC aucUrl[256] = {0};

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_CLOUD_VIDEO_COMMIT, uiUseTime);

    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList,pstTaskNode,stIterator)
    {
        if(pstTaskNode->iUseFlag == 1 && pstTaskNode->uiTaskId == *uiTaskId)
        {
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    if (pstTaskNode == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return;
    }

    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETCOMMIT_ADDRESS);
    CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, uiErrCode, EN_CLOUDSTG_RT_COMMIT_TIMEOUT, "CD patch commit request timeout", pstTaskNode->stCommitInfo.pucRecvBuff, 1);

    MOS_FREE(pstTaskNode->stCommitInfo.pucRecvBuff);
    pstTaskNode->stCommitInfo.pucRecvBuff = MOS_NULL;
    // pstTaskNode->uiTaskId = 0;
    // pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
    pstTaskNode->stCommitInfo.uiRecvLen = 0;
    pstTaskNode->stCommitInfo.uiBuffLen = 0;
    // pstTaskNode->stCommitInfo.uiTryTime = 0;
    // pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
    Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);

    return;
}

_VOID CloudStg_Patch_GetMediaCommit_RecvAddrFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _UC aucUrl[256]                    = {0};
    _UC aucMsg[128]                    = {0};
    _INT iRet                          = 0;
    _UI *uiTaskId                      = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_CLOUD_VIDEO_COMMIT, uiUseTime);

    Mos_MutexLock(&CloudStg_Patch_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&CloudStg_Patch_GetMng()->stPatchTaskList,pstTaskNode,stIterator)
    {
        if(pstTaskNode->iUseFlag == 1 && pstTaskNode->uiTaskId == *uiTaskId)
        {
            break;
        }
    }
    Mos_MutexUnLock(&CloudStg_Patch_GetMng()->hMutex);

    if (pstTaskNode == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return;
    }

    if (pstTaskNode->stCommitInfo.pucRecvBuff)
    {
        pstTaskNode->stCommitInfo.pucRecvBuff[pstTaskNode->stCommitInfo.uiRecvLen] = 0;
    }
    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETCOMMIT_ADDRESS);
    iRet = CloudStg_RecvMediaCommitRspData(pstTaskNode->stCommitInfo.pucRecvBuff, 1);
    if(iRet == MOS_ERR)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"ogctid %u Commit type Media fail,content %s",pstTaskNode->uiTaskId,pstTaskNode->stCommitInfo.pucRecvBuff);
        pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
    }
    else
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"ogctid %u Commit type Media success,content %s",pstTaskNode->uiTaskId,pstTaskNode->stCommitInfo.pucRecvBuff);
        if(pstTaskNode->iStorageType == EN_CLOUDSTG_STORAGE_TYPE_TFCARD)
        {
            MOS_LOG_INF(CLOUDSTG_LOGSTR,"TF card fix upload success,start time %u",pstTaskNode->tCreateTime);
        }

        CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, 200, EN_CLOUDSTG_RT_COMMIT_SUCCESS, "CD patch commit request successfully", pstTaskNode->stCommitInfo.pucRecvBuff, 1);
    }

    MOS_FREE(pstTaskNode->stCommitInfo.pucRecvBuff);
    pstTaskNode->stCommitInfo.pucRecvBuff = MOS_NULL;
    // pstTaskNode->uiTaskId = 0;
    pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
    pstTaskNode->stCommitInfo.uiBuffLen = 0;
    pstTaskNode->stCommitInfo.uiRecvLen = 0;
    pstTaskNode->stCommitInfo.uiTryTime = 0;
    EN_COUNT_VALUE CountLess2Value = Mos_Time() - pstTaskNode->stCommitInfo.cReqTime >= 2 ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
    Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_SUCCESS, CountLess2Value);
    return;
}

_INT CloudStg_TransMediaCommit(ST_CLOUDSTG_TASK_NODE *pstTaskNode, _UI uiIsPatch)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);

    _INT iRet = 0;
    _UI i;
    _US usPort = 80;
    _UI uiHttpsFlag = 0;
    _UC *pStrTmp = MOS_NULL;
    _UC *pStrStart = MOS_NULL;
    _UC auAdmonAddr[128] = {0};

    // 创建关键接口质量信息节点 https://cloud-ehome.21cn.com/unifyDev/commit
    MOS_VSNPRINTF(auAdmonAddr, sizeof(auAdmonAddr), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETCOMMIT_ADDRESS);
    MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_CLOUD_VIDEO_COMMIT, auAdmonAddr);

    MOS_MEMSET(auAdmonAddr, 0, 128);
    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucCloudAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 

    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucCloudAddr, "//");
    if (pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucCloudAddr;
    }
    else{
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart, ":");
    if (pStrTmp != MOS_NULL){
        MOS_MEMCPY(auAdmonAddr, pStrStart, pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRLCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    pStrTmp = CloudStg_BuildMediaCommitReqData(pstTaskNode, uiIsPatch);
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"ogctid %u commit %s",pstTaskNode->uiTaskId, pStrTmp);//source %s len %u ,pStrTmp,MOS_STRLEN(pStrTmp));

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    if (uiIsPatch){
        stHttpInfoNode.pfuncRecv       = CloudStg_Patch_GetMediaCommit_RecvAddrRsp;
        stHttpInfoNode.pfuncFinished   = CloudStg_Patch_GetMediaCommit_RecvAddrFinish;
        stHttpInfoNode.pfuncFailed     = CloudStg_Patch_GetMediaCommit_RecvAddrFail;
    }
    else{
        stHttpInfoNode.pfuncRecv       = CloudStg_GetMediaCommit_RecvAddrRsp;
        stHttpInfoNode.pfuncFinished   = CloudStg_GetMediaCommit_RecvAddrFinish;
        stHttpInfoNode.pfuncFailed     = CloudStg_GetMediaCommit_RecvAddrFail;
    }
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.vpUserPtr       = &pstTaskNode->uiTaskId;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, CLOUDSTG_GETCOMMIT_ADDRESS, EN_HTTP_METHOD_POST, pstTaskNode->uiTaskId);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC aucErrorStr[256]      = {0};
        MOS_VSNPRINTF(aucErrorStr, sizeof(aucErrorStr), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETCOMMIT_ADDRESS);
        Cloudstg_UploadLog_Error(CLOUDSTG_LOGSTR, "commit", aucErrorStr, EN_CLOUDSTG_RT_COMMIT_GETHOSTBYNAME_ERR, EN_CLOUDSTG_LOG_ERROR_TYPE_GETHOSTBYNAME);
    }
    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

_INT CloudStg_ProcGetMediaCommit(ST_CLOUDSTG_TASK_NODE *pstTaskNode, _UI uiIsPatch)
{
    MOS_PARAM_NULL_RETERR(pstTaskNode);

    _INT iRet = 0;
    _UC *pStrTmp = MOS_NULL;
    _CTIME_T cNowTime = Mos_Time();
    if(pstTaskNode->uiTaskId == 0){
        pstTaskNode->uiTaskId = Mos_GetSessionId();
    }

    // commit 重试
    if(pstTaskNode->iState == EN_CLOUDSTG_TASK_COMMINTINF && (cNowTime - pstTaskNode->stCommitInfo.cReqTime > 10))
    {
        Http_Httpclient_CancelAsyncRequestEx(pstTaskNode->uiTaskId);
        pstTaskNode->stCommitInfo.uiTryTime++;
        pstTaskNode->iState = EN_CLOUDSTG_TASK_COMMINT;
        if(pstTaskNode->stCommitInfo.uiTryTime < 3)
        {
            pstTaskNode->stCommitInfo.cNextReqTime = cNowTime;
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"get cloud commit fail,try times %u,next try time %u",pstTaskNode->stCommitInfo.uiTryTime,pstTaskNode->stCommitInfo.cNextReqTime);
        }
        else
        {
            pstTaskNode->uiUploadFlag = EN_CLOUDSTG_VIDEO_UPLOAD_TYPE_NETWORK_FAIL;
            pstTaskNode->iState = EN_CLOUDSTG_TASK_END;
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"get cloud commit has try times %u but still failed, now close these task", pstTaskNode->stCommitInfo.uiTryTime);
        }
    }
    if(pstTaskNode->iState == EN_CLOUDSTG_TASK_COMMINT && cNowTime >= pstTaskNode->stCommitInfo.cNextReqTime)
    {
        pstTaskNode->stCommitInfo.cReqTime = cNowTime;
        iRet = CloudStg_TransMediaCommit(pstTaskNode, uiIsPatch);
        if(iRet != MOS_OK)
        {
            pstTaskNode->stCommitInfo.cNextReqTime = cNowTime + 5;
        }
        else
        {
            pstTaskNode->iState = EN_CLOUDSTG_TASK_COMMINTINF;
        }
    }
    return MOS_OK;
}

static _UC* CloudStg_BuildPicCommitReqData(ST_CLOUDSTG_FILE_NODE *pstFileTask)
{
    MOS_PARAM_NULL_RETNULL(pstFileTask);

    _INT i;
    _INT iFixLen = 0;
    _INT iTotalLen = 0;
    _UC aucURLEnc[1024] = {0};
    _UC *pstrTmp = MOS_NULL;
    _UC *pucParams = MOS_NULL;
    _UC *pucSignBuff = MOS_NULL;
    _UC aucTime[32] = {0};
    _UC aucAesParams[1024] = {0};
    _UC aucBuff[1024] = {0};
    _UC aucAesKey[128] = {'\0'};
    _CTIME_T cNowTime = Mos_Time();
    ST_MOS_SYS_TIME stSysTime1;

    JSON_HANDLE hRoot = MOS_NULL, hValue = MOS_NULL;
    ST_CFG_CLOUDSTG_MNG *pstCloudInfo = Config_GetCloudMng();
    ST_CFG_SYSTEM_MNG *pstCompanyInf = Config_GetSystemMng();
    hRoot = Adpt_Json_CreateObject();
    if (hRoot == MOS_NULL)
    {
        return MOS_NULL;
    }

    Mos_TimetoSysTime(&pstFileTask->tCreatTime,&stSysTime1);

    MOS_VSNPRINTF(aucBuff, 8, (_UC*)"%02x%02x", EN_CLOUDSTG_TRANS_BUFF, EN_CLOUDSTG_UPLOAD_PIC_REQ);
    MOS_VSNPRINTF(pstFileTask->stCommitInfo.aucFileName,64,"%04hu%02hu%02hu%02hu%02hu%02hu_ALARM.jpg",
        stSysTime1.usYear,stSysTime1.usMonth,stSysTime1.usDay,stSysTime1.usHour,stSysTime1.usMinute,stSysTime1.usSecond);

    MOS_VSNPRINTF(aucTime,32,"timestamp=%u",cNowTime);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"METHOD", Adpt_Json_CreateString((_UC*)aucBuff));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstFileTask->uiTaskId));

    hValue = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hValue, (_UC*)"uid", Adpt_Json_CreateString(pstCompanyInf->aucDevUID));
    Adpt_Json_AddItemToObject(hValue, (_UC*)"appKey", Adpt_Json_CreateString(pstCloudInfo->aucAppKey));

    MOS_VSNPRINTF(aucBuff, 1024, (_UC*)"%s&picUid=%d&type=%d&picName=%s&objId=%s&ETag=%s&picLen=%ld&cId=%s",
                                    aucTime,
                                    1000,
                                    1,
                                    pstFileTask->stCommitInfo.aucFileName,
                                    pstFileTask->stCommitInfo.aucObjId,
                                    pstFileTask->stCommitInfo.aucETag,
                                    pstFileTask->stCommitInfo.uiFileLen,
                                    pstFileTask->stCommitInfo.aucFileCId);

    pucParams = (_UC*)MOS_MALLOCCLR(1024);

    iTotalLen = MOS_STRLEN(pstCompanyInf->aucDevkey);
    if(iTotalLen < 16)
    {
        MOS_STRNCPY(aucAesKey, pstCompanyInf->aucDevkey, iTotalLen);
        MOS_STRNCPY(aucAesKey + iTotalLen, pstCompanyInf->aucDevkey , 16 - iTotalLen);
    }else{
        MOS_STRNCPY(aucAesKey, pstCompanyInf->aucDevkey, 16);
    }
    iTotalLen = MOS_STRLEN(aucBuff);
    iFixLen = 16 - (iTotalLen % 16);
    if(iFixLen != 0)
    {
        iTotalLen = iTotalLen + iFixLen;
        for(i=0;i<iFixLen;i++)
        {
            aucBuff[iTotalLen-iFixLen+i] = iFixLen;
        }
        aucBuff[iTotalLen] = '\0';
    }
    Adpt_Aec_Encrypt(aucAesKey,pstCloudInfo->aucAESVI,aucBuff,aucAesParams,iTotalLen);
    Adpt_Base64_Enc(aucAesParams,iTotalLen,pucParams);

    MOS_VSNPRINTF(aucBuff, 1024, "appKey=%s&params=%s&uid=%s", pstCloudInfo->aucAppKey, pucParams, pstCompanyInf->aucDevUID);
    pucSignBuff = (_UC*)MOS_MALLOCCLR(128);
    Adpt_HmacSha256_Encrypt(aucBuff, pucSignBuff, 128, pstCloudInfo->aucAppSecret );

    CloudStg_URLEncode((const char* )pucParams, strlen(pucParams), aucURLEnc, sizeof(aucURLEnc));
    Adpt_Json_AddItemToObject(hValue, (_UC*)"sign", Adpt_Json_CreateString(pucSignBuff));
    Adpt_Json_AddItemToObject(hValue, (_UC*)"params", Adpt_Json_CreateString(aucURLEnc));

    Adpt_Json_AddItemToObject(hRoot, (_UC*)"BODY", hValue);
    pstrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucSignBuff);
    MOS_FREE(pucParams);

    return pstrTmp;
}

static _INT CloudStg_RecvPicCommitRspData(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT iValue = 0;
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(pucJson);

    if(hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"),&iValue);
    if(iValue != 0)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"recv http code %u ",iValue);
        if(iValue == 20004)
        {
            CloudStg_InitChargeInfo();
        }
        Adpt_Json_Delete(hJsonRoot);
        return MOS_ERR;
    }
    Adpt_Json_Delete(hJsonRoot);

    return MOS_OK;
}

_VOID CloudStg_GetPicCommit_RecvAddrRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    _UI *uiTaskId = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pstFileTask = MOS_NULL;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList,pstFileTask,stIterator)
    {
        if(pstFileTask->uiUseFlag == 1 && pstFileTask->uiTaskId == *uiTaskId)
        {
            break;
        }
    }
    if (pstFileTask == MOS_NULL)
    {
        return;
    }
    if (pstFileTask->stCommitInfo.uiBuffLen == 0)
    {
        pstFileTask->stCommitInfo.uiBuffLen = 1024;
        pstFileTask->stCommitInfo.pucRecvBuff = (_UC*)MOS_MALLOCCLR(1024);
    }
    if (pstFileTask->stCommitInfo.uiRecvLen + uiLen < pstFileTask->stCommitInfo.uiBuffLen)
    {
        MOS_MEMCPY(pstFileTask->stCommitInfo.pucRecvBuff + pstFileTask->stCommitInfo.uiRecvLen, pucData, uiLen);
        pstFileTask->stCommitInfo.uiRecvLen += uiLen;
    }
    return;
}

_VOID CloudStg_GetPicCommit_RecvAddrFail(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UI *uiTaskId = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pstFileTask = MOS_NULL;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList,pstFileTask,stIterator)
    {
        if(pstFileTask->uiUseFlag == 1 && pstFileTask->uiTaskId == *uiTaskId)
        {
            break;
        }
    }
    if (pstFileTask == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return;
    }

    MOS_FREE(pstFileTask->stCommitInfo.pucRecvBuff);
    pstFileTask->stCommitInfo.pucRecvBuff = MOS_NULL;
    pstFileTask->uiTaskId = 0;
    pstFileTask->uiStatus = EN_CLOUDSTG_TASK_OVER;
    pstFileTask->stCommitInfo.uiRecvLen = 0;
    pstFileTask->stCommitInfo.uiBuffLen = 0;
    pstFileTask->stCommitInfo.uiTryTime = 0;
    MOS_LOG_ERR(CLOUDSTG_LOGSTR,"taskid %u commit type :%d fail errcode %u",pstFileTask->uiTaskId,pstFileTask->uiFileType,uiErrCode);
    Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
    return;
}

_VOID CloudStg_GetPicCommit_RecvAddrFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _UC aucUrl[256]                    = {0};
    _UI *uiTaskId                      = (_UI*)vpUserPtr;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_FILE_NODE *pstFileTask = MOS_NULL;
    ST_EVENTTASK_NODE *pstEventNode    = MOS_NULL;

    FOR_EACHDATA_INLIST(&CloudStg_GetMng()->stFileList,pstFileTask,stIterator)
    {
        if(pstFileTask->uiUseFlag == 1 && pstFileTask->uiTaskId == *uiTaskId)
        {
            break;
        }
    }

    if (pstFileTask == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return;
    }

    if (pstFileTask->stCommitInfo.pucRecvBuff)
    {
        pstFileTask->stCommitInfo.pucRecvBuff[pstFileTask->stCommitInfo.uiRecvLen] = 0;
    }
    CloudStg_RecvPicCommitRspData(pstFileTask->stCommitInfo.pucRecvBuff);
    
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"Commit type Pic success");
    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucCloudAddr, CLOUDSTG_GETPICCOMMIT_ADDRESS);
    CloudStg_UploadLogEx(Mos_GetSessionId(), aucUrl, 200, 0, "/unifyDev/picCommit request successfully", pstFileTask->stCommitInfo.pucRecvBuff, 1);

    MOS_FREE(pstFileTask->stCommitInfo.pucRecvBuff);
    pstFileTask->stCommitInfo.pucRecvBuff = MOS_NULL;
    pstFileTask->uiTaskId     = 0;
    pstFileTask->uiUpDateFlag = 1;
    pstFileTask->uiStatus = EN_CLOUDSTG_TASK_STOP;
    pstFileTask->stCommitInfo.uiBuffLen = 0;
    pstFileTask->stCommitInfo.uiRecvLen = 0;
    pstFileTask->stCommitInfo.uiTryTime = 0;

    // 传图片信息给相应的消息告警
    pstEventNode = MsgMng_FindEventNodeByCTime(pstFileTask->stCommitInfo.cAlarmTime);
    if (pstEventNode)// && pstEventNode->uiEventPushFlag == 1)
    {
        MOS_MEMSET(pstEventNode->ucPicCid, 0, sizeof(pstEventNode->ucPicCid));
        MOS_STRLCPY(pstEventNode->ucPicCid, pstFileTask->stCommitInfo.aucFileCId, sizeof(pstEventNode->ucPicCid));

        MOS_MEMSET(pstEventNode->ucPicObjId, 0, sizeof(pstEventNode->ucPicObjId));
        MOS_STRLCPY(pstEventNode->ucPicObjId, pstFileTask->stCommitInfo.aucObjId, sizeof(pstEventNode->ucPicObjId));

        // MOS_LOG_WARN(CLOUDSTG_LOGSTR, "uiIoTType: %d, ucEventNo: %s, ucPicObjId: %s, ucPicCid: %s, pushFlag: %d",
        //                                 pstEventNode->uiIoTType, pstEventNode->ucEventNo, pstEventNode->ucPicObjId, pstEventNode->ucPicCid, pstEventNode->uiEventPushFlag);
    }
    EN_COUNT_VALUE CountLess2Value = Mos_Time() - pstFileTask->stCommitInfo.cReqTime >= 2 ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
    Qp_CountIF_Post(COUNT_TYPE_CLOUDSTORE, COUNT_VALUE_SUCCESS, CountLess2Value);

    return;
}

_INT CloudStg_TransPicCommit(ST_CLOUDSTG_FILE_NODE *pstFileTask)
{
    MOS_PARAM_NULL_RETERR(pstFileTask);

    _INT iRet = 0;
    _UI i;
    _US usPort = 80;
    _UI uiHttpsFlag = 0;
    _UC *pStrTmp = MOS_NULL;
    _UC *pStrStart = MOS_NULL;
    _UC auAdmonAddr[128] = { 0 };

    MOS_MEMSET(auAdmonAddr, 0, 128);

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucCloudAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 

    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucCloudAddr, "//");
    if (pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucCloudAddr;
    }
    else{
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart, ":");
    if (pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr, pStrStart, pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRLCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    pStrTmp = CloudStg_BuildPicCommitReqData(pstFileTask);
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = CloudStg_GetPicCommit_RecvAddrRsp;
    stHttpInfoNode.pfuncFinished   = CloudStg_GetPicCommit_RecvAddrFinish;
    stHttpInfoNode.pfuncFailed     = CloudStg_GetPicCommit_RecvAddrFail;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.vpUserPtr       = &pstFileTask->uiTaskId;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, CLOUDSTG_GETPICCOMMIT_ADDRESS, EN_HTTP_METHOD_POST, pstFileTask->uiTaskId);

    MOS_LOG_INF(CLOUDSTG_LOGSTR,"ogctid %u commit source %s len %u",pstFileTask->uiTaskId,pStrTmp,MOS_STRLEN(pStrTmp));
    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

_INT CloudStg_ProcGetPicCommit(ST_CLOUDSTG_FILE_NODE *pstFileTask)
{
    MOS_PARAM_NULL_RETERR(pstFileTask);

    _INT iRet = 0;
    _UC *pStrTmp = MOS_NULL;
    _CTIME_T cNowTime = Mos_Time();
    if(pstFileTask->uiTaskId == 0){
        pstFileTask->uiTaskId = Mos_GetSessionId();
    }
    if(pstFileTask->uiUpDateFlag == 1 && cNowTime - pstFileTask->stCommitInfo.cReqTime > 30)
    {
        Http_Httpclient_CancelAsyncRequestEx(pstFileTask->uiTaskId);
        pstFileTask->stCommitInfo.uiTryTime++;
        pstFileTask->uiUpDateFlag = 0;
        if(pstFileTask->stCommitInfo.uiTryTime <= 5)
        {
            pstFileTask->stCommitInfo.cNextReqTime = cNowTime + 10;
        }
        else if(pstFileTask->stCommitInfo.uiTryTime == 5)
        {
            pstFileTask->uiStatus = EN_CLOUDSTG_TASK_STOP;
            return MOS_OK;
        }
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"get cloud commit fail,try times %u,next try time %u,after %ds",pstFileTask->stCommitInfo.uiTryTime,pstFileTask->stCommitInfo.cNextReqTime,pstFileTask->stCommitInfo.cNextReqTime-cNowTime);
    }
    if(pstFileTask->uiUpDateFlag == 0 && cNowTime >= pstFileTask->stCommitInfo.cNextReqTime)
    {
        pstFileTask->stCommitInfo.cReqTime = cNowTime;
        iRet = CloudStg_TransPicCommit(pstFileTask);
        pstFileTask->uiUpDateFlag = 1;
    }
    return MOS_OK;
}
