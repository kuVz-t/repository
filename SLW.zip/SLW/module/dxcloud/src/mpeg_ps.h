#ifndef __MPEG2_PS_H__
#define __MPEG2_PS_H__

#if defined(WIN32) && !defined(__cplusplus)

#define inline __inline

#endif

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
//typedef unsigned char uNK_Int8 _t;
//typedef unsigned short uNK_Int16 _t;
//typedef unsigned NK_Int uNK_Int32 _t;
//typedef unsigned long long uNK_Int64 _t;

/****************************************************************
* configure mirco
****************************************************************/
#define MPEG_PS_SPLIT_MODE
#define MPEG_PS_SPLIT_SIZE			(60000)
#define MPEG_PES_PACKETS_PER_PS		(5)
#define MPEG_PS_SYSTEM_HEADER_PERIOD (100)
#define MPEG_MUXER_DEFAULT_VIDEO_SIZE	(512*1024)
#define MPEG_MUXER_DEFAULT_AUDIO_SIZE	(8000)

#define MPEG_PS_STREAM_TYPE_H264	(0x1B)
#define MPEG_PS_STREAM_TYPE_H265	(0x24)

//#define MPEG_FAST_MODE
/*************************************************************************
* const micro relative to rtsp, must not modified
**************************************************************************/
#define MPEG_PS_START_CODE			(0x000001BA)
#define MPEG_PS_SYSTEM_START_CODE	(0x000001BB)
#define MPEG_PS_END_CODE			(0x000001B9)

#define MPEG_PES_START_CODE			(0x000001)
// PES STREAM ID
#define MPEG_PROGRAM_STREAM_MAP		(0xBC)
#define MPEG_PRIVATE_SREAM1			(0xBD)
#define MPEG_PADDING_STREAM			(0xBE)
#define MPEG_PRIVATE_SREAM2			(0xBF)
#define MPEG_AUDIO_STREAM_PERFIX	(0xC0)
#define MPEG_VIDEO_STREAM_PERFIX	(0xE0)
#define MPEG_ECM_STREAM				(0xF0)
#define MPEG_EMM_STREAM				(0xF1)
#define MPEG_DSM_CC_STREAM			(0xF2)
#define MPEG_ISOIEC_13522_STREAM	(0xF3)
#define MPEG_PROGRAM_STREAM_DIR		(0xFF)
//
#define MPEG_DEFAULT_VIDEO_STREAM	MPEG_VIDEO_STREAM_PERFIX
#define MPEG_DEFAULT_AUDIO_STREAM	MPEG_AUDIO_STREAM_PERFIX

#pragma pack(1)

/*********************************************************************
* mpeg program stream
* | pack header | pack 1 | pack header | pack 2 | ... | pack header | pack n |
* pack header
* | pack start code | '01' | SCR | program mux rate | | pack stuffing length | pack struffing byte | system header | PES packet 1 | PES packet 2 | ... | PES packet n |
* SCR (system clock reference): 42 bits(6 bytes)
* | always set to 01 (2b) | SCR base bits32...30 (3b) | marker (1b) | SCR base 29..15(15b) | marker (1b) | SCR base14...0(15b) | marker | SCR extension (9b) | marker (1b) |
**********************************************************************/
typedef struct mpeg_ps_header
{
	//byte1~byte4 start code
	_UC pack_start_code[4];  //'0x000001BA'
	// byte5 ~ byte10 system clock reference,
	//in 27MHz clock cycles, SCR = 300*base + extension
	// SCR-base = ((system_clock_frequency * t(i))/300)%2^33
	// SCR-extension = ((system_clock_frequency * t(i))/1)%300
	//byte5 
	_UC scr_base_28_2:2;
	_UC marker_bit1:1;
	_UC scr_base_30_3:3;
	_UC fix_bit:2;    //'01'
	// byte6
	_UC scr_base_20_8;
	// byte7
	_UC scr_base_13_2:2;
	_UC marker_bit2:1;
	_UC scr_base_15_5:5;
	// byte8
	_UC scr_base_5_8;
	// byte9
	_UC scr_extension_7_2:2;
	_UC marker_bit3:1;
	_UC scr_base_0_5:5; //system_clock_reference_base 33bit

	// byte10
	_UC marker_bit4:1;
	_UC scr_extension_0_7:7; //system_clock_reference_extension 9bit
	// byte11~byte13  program mux rate,valid bits:22, unit: 50bytes/sec
	// byte11
	_UC program_mux_rate_14_8;
	// byte 12
	_UC program_mux_rate_6_8;
	// byte 13
	_UC marker_bit6:1;
	_UC marker_bit5:1;
	_UC program_mux_rate_0_6:6;
	// byte 14
	_UC pack_stuffing_length:3;
	_UC reserved:5;
	// for ( i = 0;i< pack_stuffing_length;i++){
	//	stuffing_byte(0xff)
	//}
	// if ( nextbits = system_header_start_code){
	// 	system_header
	//}
}MpegPsHeader_t; // 14bytes
#define MPEGPS_SET_MARKER_BIT(pps)	\
	{\
		pps->marker_bit1=1;\
		pps->marker_bit2=1;\
		pps->marker_bit3=1;\
		pps->marker_bit4=1;\
		pps->marker_bit5=1;\
		pps->marker_bit6=1;\
		pps->fix_bit = 1;\
	}
#define MPEGPS_GET_SCR_BASE(pps)	\
	(pps->scr_base_30_3 << 30) | \
	(pps->scr_base_28_2 << 28) | \
	(pps->scr_base_20_8 << 20) | \
	(pps->scr_base_15_5 << 15) | \
	(pps->scr_base_13_2 << 13) | \
	(pps->scr_base_5_8  << 5 ) | \
	(pps->scr_base_0_5)
#define MPEGPS_SET_SCR_BASE(pps,scr) \
	pps->scr_base_0_5 = (scr) & 0x1f;\
	pps->scr_base_5_8 = ((scr) >> 5) & 0xff;\
	pps->scr_base_13_2 = ((scr) >> 13) & 0x03;\
	pps->scr_base_15_5 = ((scr) >> 15) & 0x1f;\
	pps->scr_base_20_8 = ((scr) >> 20) & 0xff;\
	pps->scr_base_28_2 = ((scr) >> 28) & 0x03;\
	pps->scr_base_30_3 = ((scr) >> 30) & 0x07;
#define MPEGPS_SET_SCR_EXT(pps,ext) \
	pps->scr_extension_0_7 = (ext) & 0x7f;\
	pps->scr_extension_7_2 = ((ext) >> 7) & 0x03;
#define MPEGPS_GET_SCR_EXT(pps) \
	(pps->scr_extension_7_2 << 7) | (pps->scr_extension_0_7)
#define MPEGPS_SET_MUX_RATE(pps,val) \
		pps->program_mux_rate_0_6 = (val) & 0x3f;\
		pps->program_mux_rate_6_8 = ((val) >> 6) & 0xff;\
		pps->program_mux_rate_14_8 = ((val) >> 14) & 0xff;
#define MPEGPS_GET_MUX_RATE(pps) \
	((pps->program_mux_rate_14_8 << 14) | (pps->program_mux_rate_6_8 << 6) | pps->program_mux_rate_0_6)

typedef struct mpeg_ps_system_header{
	// byte1~byte4  system header start code, must be 0x000001BB
	_UC system_start_code[4];
	// byte5~byte6 bytes in system header,from byte6
	_US header_length;
	// byte7~byte9 : rate bound , is equal and bigger than the maximum the 
	//program mux rate in the program header,it use to the decoder the decoder capibility
	// byte 7
	_UC rate_bound_15_7:7;
	_UC marker_bit1:1;
	//byte8
	_UC rate_bound_7_8;
	//byte9
	_UC marker_bit2:1;
	_UC rate_bound_0_7:7;
	// byte10
	_UC csps_flag:1;
	_UC fixed_flag:1; // fixed or variable bitrate
	_UC audio_bound:6;//max number of audio streams in this program stream
	// byte11
	_UC video_bound:5;// max number of video streams in this stream
	_UC marker_bit3:1;
	_UC system_video_lock_flag:1;
	_UC system_audio_lock_flag:1;
	//byte 12
	_UC reserved:6;
	_UC pack_rate_restriction_flag:1;
	// while(nextbits() = == '1'){
	// 	mpeg_stream_specs
	// }
}MpegPsSystemHeader_t;
#define MPEG_SYS_SET_MARKERBIT(psys) \
	psys->marker_bit1 = 1;\
	psys->marker_bit2 = 1;\
	psys->marker_bit3 = 1;
#define MPEG_SYS_SET_RATE_BOUND(psys,val) \
	psys->rate_bound_0_7 = (val) & 0x7f;\
	psys->rate_bound_7_8 = ((val) >> 7) & 0xff;\
	psys->rate_bound_15_7 = ((val) >> 15) & 0xff;
#define MPEG_SYS_GET_RATE_BOUND(psys) \
	((psys->rate_bound_15_7 << 15) | (psys->rate_bound_7_8 << 7) | psys->rate_bound_0_7)
	
typedef struct mpeg_stream_specs
{
	// byte1
	_UC stream_id;//0xB8 meaning audio & 0xB9 meaning video
	// byte 2
	_UC p_std_buffer_size_bound_8_5:5;// if bound scale is '0',the this unit is 128bytes,else 1024bytes
	_UC p_std_buffer_bound_scale:1;//it should be '0' for audio,and '1' for video
	_UC fix_bits:2;	//must be '11'
	// byte 3
	_UC p_std_buffer_size_bound_0_8;
}MpegStreamSpecs_t;
#define MPEG_STREAM_SET_SIZEBOUND(p_media,val) \
	p_media->p_std_buffer_size_bound_0_8 = (val) & 0xff;\
	p_media->p_std_buffer_size_bound_8_5 = (val >> 8) & 0x1f;
#define MPEG_STREAM_GET_SIZEBOUND(p_media) \
	((p_media->p_std_buffer_size_bound_8_5 << 8) | p_media->p_std_buffer_size_bound_0_8);

typedef struct mpeg_ps_map
{
	// byte1~byte3 , start code
	_UC pack_start_code[3]; // must be 0x000001
	// byte4 , map stream id
	_UC map_stream_id; // must be 0xBC
	// byte5~byte6 , program stream map length
	_US map_length; //total bytes in the program stream map from byte7 
	// byte7
	_UC program_steam_map_version:5;
	_UC reserved1:2;
	_UC current_next_indicator:1;// indicate this map applicable or not,if not,next table would become valid
	//byte8
	_UC marker_bit:1;
	_UC reserved2:7;
	//byte 9~byte10
	_US program_stream_info_length;// descriptor length from next byte
	//
	//for(i=0;i<N;i++){
	//	descriptor()
	//}
	_US elementary_stream_map_length; // total ES info map length
	// for (i=0;i<N1;i++){
	//	stream_type
	//	elementary_stream_id
	//	elementary_stream_info_length
	//	for(i=0;i<N2;i++){
	//		descriptor()
	//	}
	//}	
	//NK_UInt32 CRC_32;
}MpegPsMap_t;

typedef struct _mpeg_es_map_info
{
	//byte1
	_UC stream_type;
	//byte2
	_UC es_id;
	//byte3~byte4
	_US es_info_len;
	//	for(i=0;i<N2;i++){
	//		descriptor()
	//	}
}MpegEsMapInfo_t;

typedef struct mpeg_pes_header
{
	// byte1 ~ byte3 start code, must be 0x000001
	_UC pack_start_code_prefix[3];
	// bype 4 ,pes stream id
	_UC stream_id;
	// byte 5 & byte 6, PES packet length from byte 7 ,if this is zero
	_US pes_packet_length;
	
	//if	(stream_id != program_stream_map 
	// && stream_id != padding_stream 
	// && stream_id != private_stream_2 
	// && stream_id != ECM 
	// && stream_id != EMM 
	// && stream_id != program_stream_directory 
	// && stream_id != DSMCC_stream 
	// && stream_id != ITU-T Rec. H.222.1 type E stream)
	
	// byte 7
	_UC original_or_copy:1;
	_UC copyright:1;
	_UC data_alignment_indicator:1;
	_UC PES_priority:1;
	_UC PES_scrambling_control:2;
	_UC fix_bit:2; //'10'
	// byte 8
	_UC PES_extension_flag:1;
	_UC PES_CRC_flag:1;
	_UC additional_copy_info_flag:1;
	_UC DSM_trick_mode_flag:1;
	_UC ES_rate_flag:1;
	_UC ESCR_flag:1;
	_UC PTS_DTS_flags:2;
	// byte 9
	_UC PES_header_data_length;

}MpegPesHeader_t;	//9bytes

typedef struct mpeg_pes_extention
{
    _UC PES_private_data_flag:1;
    _UC pack_header_field_flag:1;
    _UC program_packet_sequence_counter_flag:1;
    _UC P_STD_buffer_flag:1;
    _UC reserved:3;
    _UC PES_extension_flag_2:1;
    _UC PES_private_data[16];
}MpegPesExtention;

// if PTS_DTS_flags == '10',only using pts, if '11' ,use all of pts and dts
typedef struct _pes_pts_dts
{
	
	//byte1
	_UC marker_bit1:1;
	_UC pts_dts_30_3:3;
	_UC fix_bits:4;//PTS: '0010'; DTS:'0011'
	//byte2
	_UC pts_dts_22_8;
	//byte3
	_UC marker_bit2:1;
	_UC pts_dts_15_7:7;
	//byte4
	_UC pts_dts_7_8;
	//byte5
	_UC marker_bit3:1;
	_UC pts_dts_0_7:7;
}MpegPesPtsDts_t;

#define MPEG_SET_PTS_DTS(pts,val) \
	pts->pts_dts_0_7 = (val) & 0x7f;\
	pts->pts_dts_7_8 = ((val) >> 7) & 0xff;\
	pts->pts_dts_15_7 = ((val) >> 15) & 0x7f;\
	pts->pts_dts_22_8 = ((val) >> 22) & 0xff;\
	pts->pts_dts_30_3 = ((val) >> 30) & 0x07;\
	pts->fix_bits = 0x02;\
	pts->marker_bit1 = 1;\
	pts->marker_bit2 = 1;\
	pts->marker_bit3 = 1;
//
typedef struct _mpeg_video_stream_descriptor
{
	// byte1
	_UC descriptor_tag;
	//byte2
	_UC descriptor_length;
	//byte3
	_UC still_picture_flag:1;
	_UC constrained_param_flag:1;
	_UC mpeg1_only_flag:1;
	_UC frame_rate_code:4;
	_UC multiple_frame_rate_flag:1;
	//if(mpeg1_only_flag=='0'){
	//	Mpeg1OnlyInfo_t
	//}
}MpegVideoDescriptor_t;

typedef struct _mpeg_avc_video_descriptor
{
	// byte1
	_UC descriptor_tag;
	//byte2
	_UC descriptor_length;
	//byte3
	_UC profile_idc;
	//byte4
	_UC avc_compatible_flags:5;
	_UC constraNK_Int_set2_flag:1;
	_UC constraNK_Int_set1_flag:1;
	_UC constraNK_Int_set0_flag:1;
	//byte5
	_UC level_idc;
	//byte6
	_UC reserved:6;
	_UC avc_24hour_picture_flag:1;
	_UC avc_still_preset:1;
}MpegAvcVideoDescriptor_t;

typedef struct _mpeg_avc_timing_hrd_descriptor
{
	// byte1
	_UC descriptor_tag;
	//byte2
	_UC descriptor_length;
	//byte3
	_UC picture_and_timing_info_present:1;
	_UC reserved1:6;
	_UC hrd_management_valid_flag:1;
	//byte4
	//if (picture_and_timing_info_present){
		_UC reserved2:7;
		_UC freq_90khz_flag:1;
	//	if(freq_90khz_flag){
	//		N:32
	//		K:32
	//	}
	//byte5
		_UI num_units_in_tick;
	//}
	_UC reserved3:5;
	_UC picture_to_display_conversion_flag:1;
	_UC temporal_poc_flag:1;
	_UC fixed_frame_rate_flag:1;
}MpegAvcTimingHrdDescriptor_t;


typedef struct _mpeg1_only_info
{
	_UC profile_level_indication;
	_UC reserved:5;
	_UC frame_rate_ext_flag:1;
	_UC chroma_format:2;
}Mpeg1OnlyInfo_t;

typedef struct _audio_descriptor
{
	// byte1
	_UC descriptor_tag;
	//byte2
	_UC descriptor_length;
	//byte3
	_UC reserved:3;
	_UC variable_rate_audio_indicator:1;
	_UC layer:2;
	_UC id:1;
	_UC free_format_flag:1;
}MpegAudioDescriptor_t;

#pragma pack()

typedef struct _timestamp_info
{
	_INT flag;
	_UI timestamp;
	_UI size;
}TimestampInfo_t;

typedef struct _timestamp_node
{
	TimestampInfo_t data;
	struct _timestamp_node *next;
	struct _timestamp_node *tail;
}TimestampNode_t,TimestampList_t;

typedef struct _mpeg_muxer
{
	// circle buffer for audio and video
	_VOID *m_videobuf;
	_VOID *m_audiobuf;
	// list about timestamp
	TimestampList_t *m_videots;
	TimestampList_t *m_audiots;
	//
	_UC *m_muxbuf;//use to contaNK_Int m_muxisze
	_UI m_pos;//current write postion in m_muxbuf
	_UI m_size;// allocated buffer size for m_muxbuf
	//
	_UI m_seq;
	//timestamp
	_UI m_scr;
	_INT m_audio_bound;
	_INT m_video_bound;
	_INT m_mux_rate;
}MpegMuxer_t;

typedef struct stru_ps_Packet_data
{
    _US usVSeqNum;
    _US usASeqNum;
    _UC aucPacket[1500];
}ST_PS_PACKET_DATA;

typedef struct str_PS_VIDEODES
{
    _UI uiLensType;
    ST_ZJ_VIDEO_CIRCLE stCircle;
    ST_ZJ_VIDEO_PARAM stVideoPara;
    ST_ZJ_VIDEO_DISTORTION stDistortion; // 扭曲度
}ST_PS_VIDEODES;


typedef struct struct_ps_muxer
{
    _UI uiVDuration;
    _UI uiADuration;
    _UI uiVTimeStamp;
    _UI uiATimeStamp;
    _UI uiLITimeStamp;
    _UI uiContentType;
    _UI uiDataLen;
    _UI uiTotalSendLen;
    _INT iPsMuxerId;
    _INT iFirstFrame;
    _INT iEncSwitch;
    _UC *ucFilePath;

    ST_PS_VIDEODES    stVideoDes;
    ST_ZJ_AUDIO_PARAM stAudioParam;
	ST_PS_PACKET_DATA stPacketData;
    ST_MOS_LIST_NODE stNode;
}ST_PS_MUXER;


/*****************************************************************
* public NK_Interfaces 
*****************************************************************/
extern ps_add_ext_header(char *psheader);

extern _INT MPEG_muxer_video(_UC *src,_UI in_size,
	_UI ts,_UC stream_type,_UC type,_INT isidr,
	_UC *out,
	_UI *ret_size);

extern _INT MPEG_muxer_audio(_UC * src,_UI in_size,
	_UI timestamp/*ms*/,_UC type,
	_UC *out,_UI *ret_size);

extern _INT mpeg_pes_pack(_UC * src,_UI in_size,
                          _UI timestamp/*ms*/,_UC type,
                          _UC *out,_UI *ret_size);
						  
extern _INT mpeg_ps_header_pack(_UC *out,_UI *ret_size,_UI ts,_UI mux_rate);

extern _INT mpeg_system_header_pack(_UC *out,_UI *ret_size);

extern _INT mpeg_psm_pack(_UC *out,_UI *ret_size, _UC type);

extern _INT mpeg_ps_pack(_UC *out,_UI uiAvFlag,_UI uiIFrame,_UI uiAddPes,_UI uiDuration,_UI uiEncType,_UI uiFrameRemLen);
#ifdef __cplusplus
}
#endif
#endif
