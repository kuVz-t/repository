#include "mos.h"
#include "zj_interface.h"
#include "adpt_ssl_adapt.h"
#include "adpt_json_adapt.h"
#include "config_type.h"
#include "config_api.h"
#include "config_system.h"
#include "media_cache_api.h"
#include "cloudstg_type.h"
#include "cloudstg_type_prv.h"
#include "cloudstg_res_prv.h"
#include "cloudstg_res.h"
#include "cloudstg_conn.h"
#include "cloudstg_chan.h"
#include "cloudstg_chan_prv.h"
#include "cloudstg_stream.h"
#include "cloudstg_patch.h"
#include "cloudstg_aliveupload.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "adpt_crypto_adapt.h"
#include "msgmng_cmdserver.h"
#include "cloudstg_stream_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "cloudstg_logger.h"
#define DEBUG 0

ST_CLOUDSTG_TRANS_MGR g_stCloudTransMgr = {0};

ST_CLOUDSTG_TRANS_MGR* CloudStg_TransGetMgr()
{
    return &g_stCloudTransMgr;
}

_INT CloudStg_AddChunkInfo(_UC *pucInBuf,_UI *uiLen,_INT *piOffSet)
{
    _UC aucBuff[8] = {0};
    _UI uiSizeLen = 0;
    uiSizeLen = MOS_VSNPRINTF(aucBuff,8,"%x\r\n",*uiLen);
    *piOffSet = 6 - uiSizeLen;
    MOS_MEMCPY(pucInBuf + *piOffSet,aucBuff,uiSizeLen);
    MOS_MEMCPY(pucInBuf + *uiLen + 6,"\r\n",2);
    *uiLen = uiSizeLen + *uiLen +2;

    return MOS_OK;
}

_INT CloudStg_GetPicInfo(ST_MECS_EXT_TASK *pstExtTask)
{
    ST_MECS_CONN *pstConn = (ST_MECS_CONN *)pstExtTask->hCsConn;
    if (pstConn && pstConn->pstConnUrl)
    {
        MOS_STRLCPY(pstExtTask->aucFid,pstConn->pstConnUrl->aucFid,sizeof(pstExtTask->aucFid));
        MOS_STRLCPY(pstExtTask->aucETag,pstConn->stSocket.aucETag,sizeof(pstExtTask->aucETag));
        pstExtTask->uiTargetSize = pstConn->uiTargetSize;
        MOS_STRLCPY(pstExtTask->aucBucket,pstConn->pstConnUrl->aucBucket,sizeof(pstExtTask->aucBucket));
        MOS_STRLCPY(pstExtTask->aucStorageProvider,pstConn->pstConnUrl->aucStorageProvider,sizeof(pstExtTask->aucStorageProvider));
    }
    
    return MOS_OK;
}

static _VOID CloudStg_HttpRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    if (CloudStg_TransGetMgr()->pucHttpResponse == MOS_NULL)
    {
        CloudStg_TransGetMgr()->pucHttpResponse = (_UC*)MOS_MALLOC(1024);
    }
    if (CloudStg_TransGetMgr()->uiHttpResponseIndex + uiLen < 1024 && CloudStg_TransGetMgr()->pucHttpResponse)
    {
        MOS_MEMCPY(CloudStg_TransGetMgr()->pucHttpResponse + CloudStg_TransGetMgr()->uiHttpResponseIndex, pucData, uiLen);
        CloudStg_TransGetMgr()->uiHttpResponseIndex += uiLen;
    }
}

static _VOID CloudStg_HttpFinished(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    if (CloudStg_TransGetMgr()->pucHttpResponse)
    {
        CloudStg_TransGetMgr()->pucHttpResponse[CloudStg_TransGetMgr()->uiHttpResponseIndex] = 0;
    }

    MsgMng_ParseUploadLogRsp(CloudStg_TransGetMgr()->pucHttpResponse);
    MOS_FREE(CloudStg_TransGetMgr()->pucHttpResponse);
    CloudStg_TransGetMgr()->uiHttpResponseIndex = 0;
}

static _VOID CloudStg_HttpFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    MOS_LOG_ERR(CLOUDSTG_LOGSTR, "CloudStg_log Upload Fail %d", uiErrCode);

    MOS_FREE(CloudStg_TransGetMgr()->pucHttpResponse);
    CloudStg_TransGetMgr()->uiHttpResponseIndex = 0;
}

// 云涛日志同步上传
_INT CloudStg_HttpUploadLog(_UC *puaData)
{
    MOS_PARAM_NULL_RETERR(puaData);
    _INT iRet  = 0;
    _UC *pStrTmp  = MOS_NULL;
    _UC *pStrStart = MOS_NULL;
    _UC auAdmonAddr[CFG_STRING_LEN] = {0};

    _UC aucPuAddr[CFG_STRING_MAXLEN + 4] = CLOUDSTG_UPLOADLOG_HOST;
    pStrStart = MOS_STRSTR(aucPuAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = aucPuAddr;
    }
    else
    {
        pStrStart += 2;
    }

    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
    }
    else
    {
        MOS_STRLCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    _UC eqBuf[64] = {0};
    MOS_SPRINTF(eqBuf, "eq:%s\r\n", Config_GetSystemMng()->aucEncDevUID);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.pfuncRecv        = CloudStg_HttpRecvFunc;
    stHttpInfoNode.pfuncFinished    = CloudStg_HttpFinished;
    stHttpInfoNode.pfuncFailed      = CloudStg_HttpFailed;
    stHttpInfoNode.pucExpandHeader  = eqBuf;
    stHttpInfoNode.pucContent       = puaData;
    stHttpInfoNode.uiContentLen     = MOS_STRLEN(puaData);
    iRet = Http_SendSyncRequest(&stHttpInfoNode, auAdmonAddr, CLOUDSTG_UPLOADLOG_URL, EN_HTTP_METHOD_POST, Mos_GetSessionId());
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

_INT CloudStg_UploadLogFormatedTime(_UC *pucTimeString, _INT iStringLen, ST_MOS_SYS_TIME *ptmTime, _INT iIndex)
{
    MOS_PARAM_NULL_RETERR(ptmTime);
    MOS_MEMSET(pucTimeString, 0x00, iStringLen);
    MOS_VSNPRINTF(pucTimeString, iStringLen, "%d%02d%02d-%02d%02d%02d.0%02d", ptmTime->usYear, ptmTime->usMonth, 
            ptmTime->usDay, ptmTime->usHour, ptmTime->usMinute, ptmTime->usSecond, iIndex);
    return MOS_OK;
}

// 获取向能力平台注册的json数据
_UC *CloudStg_BuildUploadLogJson(JSON_HANDLE *hRootArray, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC *pucEt, _CTIME_T cTime, _INT iIndex, _INT iNeedOutput)
{
    _UC *pStrTmp          = MOS_NULL;
    _UC aucTime[32]       = {0};
    _UC ucBuf[37]         = {0};
    _UC aucSdkVersion[32] = {0};
    _UC *ucEncrypttext = MOS_NULL;
    _UC *pucParams = MOS_NULL;
    _INT Len;
    ST_MOS_SYS_TIME ptmTime;
    JSON_HANDLE hObject    = Adpt_Json_CreateObject();

    if (*hRootArray == MOS_NULL)
    {
        *hRootArray = Adpt_Json_CreateArray();
    }

    if (MOS_STRLEN(Config_GetSystemMng()->aucEncDevUID) == 0)
    {
        pucParams = CloudStg_AesBase64Enc(Config_GetSystemMng()->aucDevUID);
        MOS_STRCPY(Config_GetSystemMng()->aucEncDevUID, pucParams);
        MOS_FREE(pucParams);
    }

    Adpt_Json_AddItemToObject(hObject,(_UC*)"at", Adpt_Json_CreateNumber(5));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"v", Adpt_Json_CreateString("1.2"));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"pid", Adpt_Json_CreateStrWithNum(1));

    // t
    Mos_TimetoSysTime(&cTime, &ptmTime); 
    CloudStg_UploadLogFormatedTime(aucTime, sizeof(aucTime), &ptmTime, iIndex);
    Adpt_Json_AddItemToObject(hObject,(_UC*)"t", Adpt_Json_CreateString(aucTime));

    // ut
    Mos_GetSysTime(&ptmTime);
    CloudStg_UploadLogFormatedTime(aucTime, sizeof(aucTime), &ptmTime, iIndex);
    Adpt_Json_AddItemToObject(hObject,(_UC*)"ut", Adpt_Json_CreateString(aucTime));

    // sut
    Mos_TimetoSysTime(&(Config_GetDeviceMng()->cFirstLaunchTime), &ptmTime); 
    CloudStg_UploadLogFormatedTime(aucTime, sizeof(aucTime), &ptmTime, iIndex);
    Adpt_Json_AddItemToObject(hObject,(_UC*)"sut", Adpt_Json_CreateString(aucTime));

    Adpt_Json_AddItemToObject(hObject,(_UC*)"dt", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevModel));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"dc", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"fv", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));

    Config_GetSdkVersion(aucSdkVersion);
    Adpt_Json_AddItemToObject(hObject,(_UC*)"sv", Adpt_Json_CreateString(aucSdkVersion));
    // ri
    CloudStg_RandomUuid(ucBuf);
    Adpt_Json_AddItemToObject(hObject,(_UC*)"ri", Adpt_Json_CreateString(ucBuf));

    Adpt_Json_AddItemToObject(hObject,(_UC*)"url", Adpt_Json_CreateString(pucUrl));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"rt", Adpt_Json_CreateNumber(iRt));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"msg", Adpt_Json_CreateString(pucMsg));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"hs", Adpt_Json_CreateNumber(iHostStatus));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"tt", Adpt_Json_CreateNumber(1000)); //FIXME:
    Adpt_Json_AddItemToObject(hObject,(_UC*)"ip", Adpt_Json_CreateString("")); // FIXME:
    Adpt_Json_AddItemToObject(hObject,(_UC*)"le", Adpt_Json_CreateNumber(Config_GetSystemMng()->iCloudUploadLogLe==0?2:Config_GetSystemMng()->iCloudUploadLogLe));
    Adpt_Json_AddItemToObject(hObject,(_UC*)"et", Adpt_Json_CreateString(pucEt));
    Adpt_Json_AddItemToObject(*hRootArray, "", hObject);
    if (iNeedOutput)
    {
        pStrTmp = Adpt_Json_Print(*hRootArray);
        pucParams = CloudStg_AesBase64Enc(pStrTmp);
        MOS_FREE(pStrTmp);
    }
    return pucParams;
}

_INT MsgMng_ParseUploadLogRsp(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _UC *pucMsg     = MOS_NULL;
    _INT iCode     = 0;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"regetAddr Rsp is NULL!");
        return MOS_ERR;
    }
    do
    {
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"msg"),&pucMsg);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"code"),&iCode);
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "upload log successfully! msg: %s, code: %d", pucMsg, iCode);
    }while(0);

    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_INT CloudStg_TransStart()
{
    // 线程栈大小
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    // _UI uiStackSize = MOS_THREAD_STACK_HIGH_SIZE;
    _INT iRet = MOS_OK;    
    MOS_MEMSET(&g_stCloudTransMgr, 0, sizeof(g_stCloudTransMgr));
    // 获取系统参数句柄
    ST_CFG_SYSTEM_MNG * pstCompanyInfo = Config_GetSystemMng();

    // 获取trans管理句柄，不能重复运行
    if (CloudStg_TransGetMgr()->bRun == MOS_TRUE)
    {
        return MOS_OK;
    }

    // 设置为运行状态
    CloudStg_TransGetMgr()->bRun    = MOS_TRUE;

    // 向内存管理器注册信息
    if(CloudStg_TransGetMgr()->hMem == MOS_NULL)
    {
        CloudStg_TransGetMgr()->hMem = Mos_MemOwnerCreate(MOS_NULL,(_UC*)"cloudtrans",CLOUDSTG_BUF_MID_SIZE);
    }
    // 获取did
    MOS_MEMCPY(CloudStg_TransGetMgr()->aucDid,pstCompanyInfo->aucDid,CFG_STRING_COMMONLEN);

    // 创建互斥锁
    Mos_MutexCreate(&CloudStg_TransGetMgr()->hTaskMutex);
    Mos_MutexCreate(&CloudStg_TransGetMgr()->hExtUriMutex);

    // 初始化链表
    MOS_LIST_INIT(&CloudStg_TransGetMgr()->stTaskList);
    MOS_LIST_INIT(&CloudStg_TransGetMgr()->stExtUriList);

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    
    // 云存上传
    iRet = Mos_ThreadCreate((_UC*)"CloudTrans",  EN_THREAD_PRIORITY_NORMAL, uiStackSize,  
            CloudStg_TransProc, MOS_NULL, MOS_NULL, &CloudStg_TransGetMgr()->hThread);
    if(iRet == MOS_ERR)
    {
        CloudStg_TransGetMgr()->bRun = MOS_FALSE;
        Mos_MutexDelete(&CloudStg_TransGetMgr()->hTaskMutex);
        return MOS_ERR;
    }

    // 上报日志
    iRet = Mos_ThreadCreate((_UC*)"CloudExternTrans",  EN_THREAD_PRIORITY_NORMAL, uiStackSize,  
        CloudStg_TransExtProc, MOS_NULL, MOS_NULL, &CloudStg_TransGetMgr()->hExtThread);
    if(iRet == MOS_ERR)
    {
        CloudStg_TransGetMgr()->bRun = MOS_FALSE;
        Mos_MutexDelete(&CloudStg_TransGetMgr()->hTaskMutex);
        Mos_MutexDelete(&CloudStg_TransGetMgr()->hExtUriMutex);
        return MOS_ERR;
    }
   
    return MOS_OK;
}

_INT CloudStg_TransStop()
{
    ST_MECS_EXT_TASK *pstExtTask =  MOS_NULL;
    ST_CLOUDSTG_TASK_INF *pstTask = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    if (CloudStg_TransGetMgr()->bRun == MOS_FALSE)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "has been stoped before");
        return MOS_OK;
    }
    CloudStg_TransGetMgr()->bRun = MOS_FALSE;

    Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
    FOR_EACHDATA_INLIST(&CloudStg_TransGetMgr()->stTaskList, pstTask, stIterator)
    {
        CloudStg_ConnShutDown(pstTask->hCSConn);
    }
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);

    Mos_ThreadDelete(CloudStg_TransGetMgr()->hThread);
    Mos_ThreadDelete(CloudStg_TransGetMgr()->hExtThread);
    
    Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
    FOR_EACHDATA_INLIST(&CloudStg_TransGetMgr()->stTaskList, pstTask, stIterator)
    {
        MOS_LIST_RMVNODE(&CloudStg_TransGetMgr()->stTaskList, pstTask);
        CloudStg_TransTaskClose(pstTask);
    }
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);

    Mos_MutexLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    FOR_EACHDATA_INLIST(&CloudStg_TransGetMgr()->stExtUriList, pstExtTask, stIterator)
    {
        MOS_LIST_RMVNODE(&CloudStg_TransGetMgr()->stExtUriList, pstExtTask);
        if (pstExtTask)
        {
            if (pstExtTask->uiType == EN_CLOUDSTG_RESOURCE_LOG)
            {
                if (pstExtTask->pucUrl)
                {
                    MOS_FREE(pstExtTask->pucUrl);
                }
                if (pstExtTask->pucMsg)
                {
                    MOS_FREE(pstExtTask->pucMsg);
                }
                if (pstExtTask->pucEt)
                {
                    MOS_FREE(pstExtTask->pucEt);
                }
            }
            Mos_MemFree(pstExtTask);
        }
    }
    Mos_MemOwnerDel(CloudStg_TransGetMgr()->hMem);
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    
    Mos_MutexDelete(&CloudStg_TransGetMgr()->hTaskMutex);
    Mos_MutexDelete(&CloudStg_TransGetMgr()->hExtUriMutex);
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloudstg chan stop....");
    return MOS_OK;
}

_UI CloudStg_TransGenTaskId(_UI uiType)
{
    static  _UI uiTaskid = 0;
    
    _MOS_FORM_MAP_BEGIN(uiType)
        MOS_FORM_MAP_VAL(EN_CLOUDSTG_RESOURCE_PIC,    uiType*MECS_BASIC_TASK_ID + uiTaskid++)
        MOS_FORM_MAP_VAL(EN_CLOUDSTG_RESOURCE_STREAM, uiType*MECS_BASIC_TASK_ID + uiTaskid++)
        MOS_FORM_MAP_VAL(EN_CLOUDSTG_RESOURCE_LOGFILE,     uiType*MECS_BASIC_TASK_ID + uiTaskid++)
    _MOS_FORM_MAP_END()

    MOS_LOG_ERR(CLOUDSTG_LOGSTR, "unkown task type :%d", uiType);

    return 0;
}

static _INT CloudStg_ProcessTask(ST_CLOUDSTG_TRANS_MGR *pstCloudTransMgr,_CTIME_T ctime)
{
    MOS_PARAM_NULL_RETERR(pstCloudTransMgr);

    _INT iNetCheckFlag = 0;
    _INT iCount = 0;
    _INT iSentSpeed = 0;
    static _CTIME_T cOldtime = 0;
    ST_CLOUDSTG_TASK_INF *pstTask = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator = {0};

    // FIXME:
    // if (MOS_ABS_NUM(ctime - cOldtime) >= CLOUDSTG_BUF_SPEED_DETECT_TIMEOUT)
    // {
    //     cOldtime = ctime;
    //     iNetCheckFlag = 1;
    // }

    // 遍历stTaskList链表
    Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
    FOR_EACHDATA_INLIST(&pstCloudTransMgr->stTaskList,pstTask,stIterator)
    {
        Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
        if(pstCloudTransMgr->bRun)
        {
            // 端切片专用
            if (pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
            {
                iCount += CloudStg_TransTaskProcEx(pstTask,ctime, MOS_FALSE, iNetCheckFlag);
            }
            else if (pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
            {
#if CLOUDSTG_UPLOAD_LIMIT_SEND
                if (pstCloudTransMgr->stTaskList.uiTotalCount > 1)
                {
                    if (CloudStg_GetTaskNodeState(0, pstTask->ptUseHandle) < EN_CLOUDSTG_TASK_WAITING)
                    {
                        if (CloudStg_TransGetMgr()->uiSentPacks >= CLOUDSTG_UPLOAD_LIMIT_SEND_PACKETS)
                        {
                            CloudStg_TransGetMgr()->uiSentPacks = 0;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    else
                    {
                        CloudStg_TransGetMgr()->uiSentPacks++;
                    }
                }
#endif
                iCount += CloudStg_TransTaskProc(pstTask,ctime, MOS_FALSE);
            }
        }
        Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
    }
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
    return iCount;
}

_INT CloudStg_ProcessTaskEx(ST_CLOUDSTG_TRANS_MGR *pstCloudTransMgr)
{
    MOS_PARAM_NULL_RETERR(pstCloudTransMgr);

    _INT iRet = MOS_OK;
    _UI  uiStatus = 0;
    _CTIME_T cNowTime = Mos_Time();
    ST_MECS_EXT_TASK *pstExtTask =  MOS_NULL;

    Mos_MutexLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    pstExtTask = (ST_MECS_EXT_TASK*)MOS_LIST_GETHEAD(&pstCloudTransMgr->stExtUriList);
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hExtUriMutex);

    if(pstExtTask && pstCloudTransMgr->bRun 
        && (MOS_ABS_NUM(cNowTime - pstExtTask->cSendTime) >= 0 || MOS_ABS_NUM(pstExtTask->cSendTime - cNowTime) > 0 && MOS_ABS_NUM(pstExtTask->cSendTime - cNowTime) > 300))
    {   
        iRet = CloudStg_TransExtTaskProc(pstExtTask);
        if (pstExtTask)
        {
            if(pstExtTask->uiStatus == EN_MECS_EXTTASK_CLOSE)
            {
                Mos_MutexLock(&CloudStg_TransGetMgr()->hExtUriMutex);
                MOS_LIST_RMVNODE(&pstCloudTransMgr->stExtUriList,pstExtTask);
                Mos_MutexUnLock(&CloudStg_TransGetMgr()->hExtUriMutex);
                if(iRet != MOS_OK )
                {
                    uiStatus = 400;
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR,"trans ext task send over max try times");
                }
                if(pstExtTask->pfuncFinished)
                    pstExtTask->pfuncFinished(pstExtTask->vpBase,uiStatus,pstExtTask->aucFid,pstExtTask->aucETag,
                                    pstExtTask->uiTargetSize,pstExtTask->aucBucket,pstExtTask->aucStorageProvider);
                if (pstExtTask->uiType == EN_CLOUDSTG_RESOURCE_LOG)
                {
                    MOS_FREE(pstExtTask->pucUrl);
                    MOS_FREE(pstExtTask->pucMsg); 
                    MOS_FREE(pstExtTask->pucEt); 
                    CloudStg_FileNodeSetUsed((_UI)pstExtTask->vpBase);
                }
                Mos_MemFree(pstExtTask);
            }
            else if(iRet != MOS_OK)
            {
                pstExtTask->cSendTime = cNowTime + 2;
            }
        }
    }
    return MOS_OK;
}

_VOID CloudStg_TransGetDeviceId()
{
    ST_CFG_SYSTEM_MNG * pstCompanyInfo = Config_GetSystemMng();
    do
    {
        if(MOS_STRLEN(pstCompanyInfo->aucDid) > 0)
        {
            MOS_STRLCPY(CloudStg_TransGetMgr()->aucDid, pstCompanyInfo->aucDid, sizeof(CloudStg_TransGetMgr()->aucDid)); 
            break;
        }
        Mos_Sleep(100);
    }while(CloudStg_TransGetMgr()->bRun);
    
    return;
}

_INT CloudStg_TransExtProc(_VPTR pParam)
{
    _UI  uiSleep      = 0;
    _UI  uiUriCount   = 0;
    _CTIME_T cNowTime = 0;

    // 阻塞获取设备ID
    CloudStg_TransGetDeviceId();
    while(CloudStg_TransGetMgr()->bRun)
    {
        uiSleep++;
        if(uiSleep % 8 == 0)
        {
            cNowTime = Mos_Time();
        }

        // 上传云存封面、日志打捞
        CloudStg_ProcessTaskEx(CloudStg_TransGetMgr());

        // 上报日志
        CloudStg_LoggerProc(cNowTime);

        Mos_MutexLock(&CloudStg_TransGetMgr()->hExtUriMutex);
        uiUriCount = MOS_LIST_GETCOUNT(&CloudStg_TransGetMgr()->stExtUriList);
        Mos_MutexUnLock(&CloudStg_TransGetMgr()->hExtUriMutex);

        if( uiUriCount == 0)
        {
            Mos_Sleep(100);
        }
        else if(uiSleep%10 == 0)
        {
            Mos_Sleep(10);
        }
    }
	return MOS_OK;
}

_INT CloudStg_TransProc(_VPTR pParam)
{ 
    _UI  uiSleep   = 0;
    _CTIME_T ctime = 0;
    _INT iTaskSize = 0;
    // 等待获取DeviceId
    CloudStg_TransGetDeviceId();

    // 当状态为True，则运行
    while(CloudStg_TransGetMgr()->bRun)
    {
        uiSleep++;
        if(uiSleep%8 == 0)
        {
            ctime = Mos_Time();
        }

        // 进行上传流程
        CloudStg_ProcessTask(CloudStg_TransGetMgr(), ctime);
#if 0
        // 云存
        if (Mos_FileIsExist("/mnt/config/test_delay_trans") == MOS_TRUE)
        {
            _HFILE hFile;
            _UC aucSleepTime[32] = {0};
            _INT iSleepTime = 0;

            hFile = Mos_FileOpen("/mnt/config/test_delay_trans",MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
            Mos_FileRead(hFile,aucSleepTime,32);
            iSleepTime = atoi(aucSleepTime);

            Mos_FileClose(hFile);
            Mos_FileRmv("/mnt/config/test_delay_trans");

            MOS_PRINTF("now trans sleep %d.....\r\n", iSleepTime);
            Mos_Sleep(iSleepTime * 1000);
        }
#endif
        Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
        iTaskSize = MOS_LIST_GETCOUNT(&CloudStg_TransGetMgr()->stTaskList);
        Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
        // 没有任务可睡眠更长时间
        if(iTaskSize == 0)
        {
            Mos_Sleep(100);
        }
        else if (uiSleep%10 == 0)
        {
            Mos_Sleep(10);
        }
    }
    return MOS_OK;
}

_INT CloudStg_TransExtTaskProc(ST_MECS_EXT_TASK *pstExtTask)
{
    MOS_PARAM_NULL_RETERR(pstExtTask);

    _INT iLen      = 0;
    _INT iError    = 0;
    _UI uiPicUrl   = 0;
    _UI uiSendLen  = 0;
    _UI iTaskCount = 0;
    _CTIME_T ctime = 0;
    _INT iRet      = MOS_OK;
    _UC *pucParams = MOS_NULL;
    _INT iLogCount = 0;
    _UC aucMsg[128] = {0};
    _UC aucUrl[256] = {0};
    JSON_HANDLE hRootArray;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MECS_EXT_TASK *pstExtUriListNode = MOS_NULL;
    ST_MECS_CONN *pstCSConn = MOS_NULL;
    
    if(pstExtTask->uiSendtimes >= 3)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR, "After trying 3 Sendtimes, now close conn! type: %u", pstExtTask->uiType);
        iRet = MOS_ERR;
        CloudStg_ConnClose(pstExtTask->hCsConn, 1);
        pstExtTask->hCsConn  = MOS_NULL;
        pstExtTask->uiStatus = EN_MECS_EXTTASK_CLOSE;
        if(pstExtTask->uiType == EN_CLOUDSTG_RESOURCE_LOGFILE)
        {
            if(pstExtTask->hFile)
            {
                Mos_FileClose(pstExtTask->hFile);
                if (Mos_FileRmv(pstExtTask->aucFileName) == MOS_OK)
                {
                    MOS_LOG_INF(CLOUDSTG_LOGSTR,"Successfully remove file: %s\r\n", pstExtTask->aucFileName);
                }
                else
                {
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Failed to remove file: %s\r\n", pstExtTask->aucFileName);
                }
                pstExtTask->hFile = MOS_NULL;
            }
        }
    }

    if (pstExtTask->uiType != EN_CLOUDSTG_RESOURCE_LOG)
    {
        // 初始化
        if(pstExtTask->uiStatus == EN_MECS_EXTTASK_INIT)
        {
            pstExtTask->hCsConn = CloudStg_ConnOpen(MOS_NULL, pstExtTask->iAliveTaskId, pstExtTask->uiType,pstExtTask->uiFileTotalLen,0,0,pstExtTask->iDirectMode);

            if(pstExtTask->hCsConn == MOS_NULL)
            {
                pstExtTask->uiSendtimes++;
                return MOS_ERR;
            }
            if(pstExtTask->uiIcon == 0)
            {
                uiPicUrl = 1;
            }
            iRet = CloudStg_ConnStart((_HCSCONN)pstExtTask->hCsConn,uiPicUrl);
            if(iRet != MOS_OK)
            {
                if(MOS_ABS_NUM(Mos_Time() - pstExtTask->cConnectTime) >= 10)
                {
                    pstExtTask->uiSendtimes++;
                    pstExtTask->cConnectTime = Mos_Time();
                }
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Can't find available url,%p,type:%d",pstExtTask->hCsConn,pstExtTask->uiType); 
                CloudStg_ConnClose((_HCSCONN)pstExtTask->hCsConn, 1);
                return MOS_ERR;
            }
            if(pstExtTask->uiType == EN_CLOUDSTG_RESOURCE_LOGFILE)
            {
                pstExtTask->hFile = Mos_FileOpen(pstExtTask->aucFileName,MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
                if(pstExtTask->hFile == MOS_NULL)
                {
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Mos_FileOpen error!\r\n");
                    pstExtTask->uiSendtimes++;
                    CloudStg_ConnClose(pstExtTask->hCsConn, 1);
                    if (Mos_FileRmv(pstExtTask->aucFileName) == MOS_OK)
                    {
                        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Successfully remove file: %s\r\n", pstExtTask->aucFileName);
                    }
                    else
                    {
                        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Failed to remove file: %s\r\n", pstExtTask->aucFileName);
                    }
                    pstExtTask->uiStatus = EN_MECS_EXTTASK_CLOSE;
                    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_LOGFILE_LOAD_FAIL, "CD logfile load fail", 1);
                    return MOS_ERR;
                }
                pstExtTask->uiBuffLen      = 1440;
                pstExtTask->pucbuf = (_UC*)MOS_MALLOCCLR(pstExtTask->uiBuffLen);
            }
            pstExtTask->uiStatus = EN_MECS_EXTTASK_PROC;
        }
        else if(pstExtTask->uiStatus == EN_MECS_EXTTASK_PROC)
        {
            if(pstExtTask->uiType == EN_CLOUDSTG_RESOURCE_LOGFILE && pstExtTask->uiLen == 0)
            {
                pstExtTask->uiOffsetLen = 0;
                pstExtTask->uiLen = Mos_FileRead(pstExtTask->hFile,pstExtTask->pucbuf,pstExtTask->uiBuffLen);
            }
            if(pstExtTask->uiLen == 0)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"read file err");
                pstExtTask->uiStatus = EN_MECS_EXTTASK_FINISH;
                return MOS_ERR;
            }
            iRet = CloudStg_ConnSend(pstExtTask->hCsConn, pstExtTask->pucbuf + pstExtTask->uiOffsetLen, pstExtTask->uiLen,0,&uiSendLen);
            if(iRet == MOS_OK)
            {
                ST_MECS_CONN *pstCSConn = (ST_MECS_CONN *)pstExtTask->hCsConn;
                if (pstCSConn)
                {
                    CloudStg_AddSentBytes(pstCSConn->uiIsPatch, 0, pstCSConn->iAliveTaskId, pstExtTask->uiLen);
                }
                pstExtTask->uiSendtimes    = 0;
                pstExtTask->uiOffsetLen    += pstExtTask->uiLen;
                pstExtTask->uiSendTotalLen += pstExtTask->uiLen;
                pstExtTask->uiLen = 0;
            }
            else if(MOS_ERR_TRYAGAIN == iRet)
            {
                pstExtTask->uiSendtimes++;
                pstExtTask->uiLen          -= uiSendLen;
                pstExtTask->uiOffsetLen    += uiSendLen;
                pstExtTask->uiSendTotalLen += uiSendLen;
            }
            else if(iRet == MOS_ERR)
            {
                pstExtTask->uiSendtimes++;
            }
            if(pstExtTask->uiSendTotalLen >= pstExtTask->uiFileTotalLen)
            {
                pstExtTask->uiStatus = EN_MECS_EXTTASK_FINISH;
            }
        }
        else if(pstExtTask->uiStatus == EN_MECS_EXTTASK_FINISH)
        {
            if(pstExtTask->uiType == EN_CLOUDSTG_RESOURCE_LOGFILE)
            {
                if(pstExtTask->hFile)
                {
                    Mos_FileClose(pstExtTask->hFile);
                    if (Mos_FileRmv(pstExtTask->aucFileName) == MOS_OK)
                    {
                        MOS_LOG_INF(CLOUDSTG_LOGSTR,"Successfully remove file: %s\r\n", pstExtTask->aucFileName);
                    }
                    else
                    {
                        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Failed to remove file: %s\r\n", pstExtTask->aucFileName);
                    }
                    pstExtTask->hFile = MOS_NULL;
                }
                MOS_FREE(pstExtTask->pucbuf);
                pstCSConn = (ST_MECS_CONN *)pstExtTask->hCsConn;
                if (pstCSConn)
                {
                    iLen = MOS_STRLEN(pstCSConn->aucBoundaryEnd);
                    MOS_PRINTF(CLOUDSTG_LOGSTR, "%s:%d req header(0x%x)[%d]: %s", __FUNCTION__, __LINE__, &pstCSConn->stSocket, iLen, pstCSConn->aucBoundaryEnd);
                    iRet = CloudStg_SendData(pstCSConn, pstCSConn->aucBoundaryEnd, iLen, MOS_NULL, &iError);
                    if (iRet == MOS_OK)
                    {
                        CloudStg_AddSentBytes(pstCSConn->uiIsPatch, 0, pstCSConn->iAliveTaskId, iLen);
                    }
                    else
                    {
                        MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", pstCSConn->stSocket.aucHost, pstCSConn->stSocket.aucSubUri);
                        MOS_VSNPRINTF(aucMsg, sizeof(aucMsg), "CD type: logfile send data error, socket error: %d", iError);
                        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, EN_CLOUDSTG_RT_LOGFILE_UPLOAD_FAIL, aucMsg, 1);
                        return MOS_ERR;
                    }
                }
            }
            printf("%s:%d call CloudStg_ConnRecvRsp\r\n", __FUNCTION__, __LINE__);
            if (CloudStg_ConnRecvRsp(pstExtTask->hCsConn) != MOS_OK)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Recv error after sending file,%p,type:%d",pstExtTask->hCsConn,pstExtTask->uiType); 
                pstExtTask->uiSendtimes++;
                CloudStg_ConnClose((_HCSCONN)pstExtTask->hCsConn, 1);
                pstExtTask->hCsConn  = MOS_NULL;
                pstExtTask->uiLen = pstExtTask->uiFileTotalLen;
                pstExtTask->uiOffsetLen = 0;
                pstExtTask->uiSendTotalLen = 0;
                pstExtTask->uiStatus = EN_MECS_EXTTASK_INIT;
                return MOS_ERR;
            }
            CloudStg_GetPicInfo(pstExtTask);
            CloudStg_ConnClose(pstExtTask->hCsConn, 1);
            pstExtTask->hCsConn  = MOS_NULL;
            pstExtTask->uiStatus = EN_MECS_EXTTASK_CLOSE;
        }
    }
    else
    {
        // 云涛日志上传不会运行到当前逻辑，否则认为代码逻辑错误
        MOS_PRINTF("%s upload log task logic error\n", __FUNCTION__);
    }

    return iRet;
}

_INT CloudStg_TransTaskProcEx(ST_CLOUDSTG_TASK_INF *pstTask,_CTIME_T ctime, _UI uiIsPatch, _INT iNetCheckFlag)
{
    MOS_PARAM_NULL_RETERR(pstTask);

    _INT iIndex      = 0;
    _INT iCount      = 0;
    _INT iret        = 0;
    _INT iFlag       = 0;
    _INT iDropGopNum = 0;
    _UI uiBufferListCount = 0;
    ST_CLOUDSTG_BUF_NODE *pstBuf = MOS_NULL;

    //获取云能力
    if(Config_GetCloudMng()->iCloudAbility == 0)
    {
        pstTask->iFailFlag = 1;
    }

    Mos_MutexLock(&pstTask->hBufMutex);
    pstBuf = (ST_CLOUDSTG_BUF_NODE *)MOS_LIST_GETNEXT(&pstTask->stBufferList, pstTask->pstCurBufNode);
    Mos_MutexUnLock(&pstTask->hBufMutex);

    if(pstBuf != MOS_NULL)
    {
        switch (pstTask->uiExUploadStatus)
        {
            case EX_TRANS_STATUS_START:
            {
                // if (pstTask->pstHeadBufNode == MOS_NULL)
                // {
                //     pstTask->pstHeadBufNode = &pstBuf->stNode.pstPrv;
                // }
                if (pstBuf->enType == EN_CLOUDSTG_TRANS_BUF_SLICEEND || pstBuf->enType == EN_CLOUDSTG_TRANS_BUF_SLICEINFO)
                {
                    pstTask->pstTailBufNode   = &pstBuf->stNode;
                    pstTask->pstCurBufNode    = MOS_NULL;
                    pstTask->uiExUploadStatus = EX_TRANS_STATUS_PROCESS;
                    MOS_PRINTF("pstBuf type: %d, uiExUploadLen: %u, pstTask->pstTailBufNode: %p\r\n", pstBuf->enType, pstTask->uiExUploadLen, pstTask->pstTailBufNode);
                }
                else
                {
                    pstTask->pstCurBufNode  = &pstBuf->stNode;
                    pstTask->uiExUploadLen += pstBuf->uiLen;
                }
                break;
            }
            case EX_TRANS_STATUS_PROCESS:
            {
                if (&pstBuf->stNode == pstTask->pstTailBufNode)
                {
                    if (pstBuf->enType == EN_CLOUDSTG_TRANS_BUF_SLICEEND)
                    {
                        // 发送slice结束
                        if(pstTask->iFailFlag == 0)
                        {
                            // 发送
                            iret = CloudStg_TransTaskSendBuf(pstTask, pstBuf);
                        }
                        if( iret == 0)
                        {                
                            Mos_MutexLock(&pstTask->hBufMutex);
                            MOS_LIST_RMVNODE(&pstTask->stBufferList, pstBuf);
                            if(pstBuf) 
                            {
                                if(pstBuf->pucBuf)
                                {
                                    Mos_MemFree(pstBuf->pucBuf);
                                }
                                Mos_MemFree(pstBuf);
                            }
                            Mos_MutexUnLock(&pstTask->hBufMutex);
                            pstTask->tFailCount    = 0;
                        }
                        else
                        {
                            CloudStg_TransTaskSendHandleEx(pstTask, pstBuf, ctime, iret);
                        }
                        pstTask->pstCurBufNode    = MOS_NULL;
                        pstTask->pstHeadBufNode   = MOS_NULL;
                        pstTask->pstTailBufNode   = MOS_NULL;
                        pstTask->uiExUploadStatus = EX_TRANS_STATUS_START;
                    }
                    else if (pstBuf->enType == EN_CLOUDSTG_TRANS_BUF_SLICEINFO)
                    {
                        pstTask->uiExUploadStatus = EX_TRANS_STATUS_END;
                        MOS_PRINTF("send over!!!\r\n");
                        // 发送文件结束

                        //开始发送
                        if(pstTask->iFailFlag == 0)
                        {
                            MOS_PRINTF("send!!!!!!!\r\n");
                            // 发送
                            iret = CloudStg_TransTaskSendBuf(pstTask, pstBuf);
                        }
                        if( iret == 0)
                        {                
                            Mos_MutexLock(&pstTask->hBufMutex);
                            MOS_LIST_RMVNODE(&pstTask->stBufferList, pstBuf);
                            if(pstBuf) 
                            {
                                if(pstBuf->pucBuf)
                                {
                                    Mos_MemFree(pstBuf->pucBuf);
                                }
                                Mos_MemFree(pstBuf);
                            }
                            Mos_MutexUnLock(&pstTask->hBufMutex);
                            pstTask->tFailCount    = 0;
                        }
                        else
                        {
                            CloudStg_TransTaskSendHandleEx(pstTask, pstBuf, ctime, iret);
                        }
                        pstTask->pstCurBufNode = MOS_NULL;
                        pstTask->bSendOver     = MOS_TRUE;
                    }
                }
                else
                {
                    if (pstTask->uiExUploadLen != 0)
                    {
                        ST_MECS_CONN *pstCSConn = pstTask->hCSConn;
                        if (pstCSConn)
                        {
                            pstCSConn->uiSliceSize = pstTask->uiExUploadLen;
                        }
                        pstTask->uiExUploadLen = 0;
                    }

                    //开始发送
                    if(pstTask->iFailFlag == 0)
                    {
                        // 发送
                        iret = CloudStg_TransTaskSendBuf(pstTask, pstBuf);
                    }
                    CloudStg_TransTaskSendHandleEx(pstTask, pstBuf, ctime, iret);
                    iCount = 1;
                }
                break;
            }
            case EX_TRANS_STATUS_END:
            {
                // 释放全部资源
                break;
            }
            default:
                break;
        }
    }

    Mos_MutexLock(&pstTask->hBufMutex);
    uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
    // 清空当前任务的发送队列
    if (pstTask->iFailFlag == 1 && uiBufferListCount != 0)
    { 
        if(pstTask->stBufferList.pstHead == MOS_NULL){
            if(pstTask->tFailTime == 0 || MOS_ABS_NUM(ctime - (pstTask->tFailTime + 10)) > 0){
                pstTask->tFailTime = ctime;
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"buffer list num %u",uiBufferListCount);
            }
            Mos_MutexUnLock(&pstTask->hBufMutex);
            return iCount;
        }
        pstTask->pstCurBufNode = MOS_NULL;
        pstTask->bSendOver     = MOS_TRUE;
        CloudStg_TransTaskClearBufList(&pstTask->stBufferList, MOS_NULL);
    }
    Mos_MutexUnLock(&pstTask->hBufMutex);

    Mos_MutexLock(&pstTask->hBufMutex);
    uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
    Mos_MutexUnLock(&pstTask->hBufMutex);

    // 断开连接，关闭任务
    if ((uiBufferListCount == 0 && pstTask->bSendOver == MOS_TRUE && CloudStg_GetTaskNodeState(uiIsPatch, pstTask->ptUseHandle) >= EN_CLOUDSTG_TASK_STOP) 
        || CloudStg_GetTaskNodeState(uiIsPatch, pstTask->ptUseHandle) == EN_CLOUDSTG_TASK_END)
    {
        MOS_PRINTF("CloudStg_GetTaskNodeState(uiIsPatch, pstTask->ptUseHandle): %d\r\n", CloudStg_GetTaskNodeState(uiIsPatch, pstTask->ptUseHandle));
        MOS_PRINTF("MOS_LIST_GETCOUNT(&pstTask->stBufferList): %d\r\n", uiBufferListCount);
        MOS_PRINTF("pstTask->bSendOver: %d\r\n", pstTask->bSendOver);
        
        if (uiIsPatch)
        {
            Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
            MOS_LIST_RMVNODE(&CloudStg_Trans_PatchGetMgr()->stTaskList,pstTask);
            Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        }
        else
        {
            Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
            MOS_LIST_RMVNODE(&CloudStg_TransGetMgr()->stTaskList,pstTask);
            Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
        }
        CloudStg_ConnShutDown(pstTask->hCSConn);
        CloudStg_TransTaskClose(pstTask);

    }
    return iCount;
}

_INT CloudStg_TransTaskProc(ST_CLOUDSTG_TASK_INF *pstTask,_CTIME_T ctime, _UI uiIsPatch)
{
    MOS_PARAM_NULL_RETERR(pstTask);

    _INT  iCount = 0;
    _INT  iret  = 0;
    _INT  iFlag = 0;
    _UI uiBufferListCount = 0;
    _UI uiRetryMaxTimeout = 0;
    ST_CLOUDSTG_BUF_NODE *pstBuf = MOS_NULL;
    ST_MECS_CONN *pstConn = (ST_MECS_CONN *)pstTask->hCSConn;

#if CLOUDSTG_UPLOAD_DELAY_SEND
    if (CloudStg_TransQualificationCheck(pstTask) == MOS_ERR)
    {
        return 0;
    }
#endif
    Mos_MutexLock(&pstTask->hBufMutex);
    pstBuf = (ST_CLOUDSTG_BUF_NODE *)MOS_LIST_GETNEXT(&pstTask->stBufferList, pstTask->pstCurBufNode);
    Mos_MutexUnLock(&pstTask->hBufMutex);

    //获取云能力
    if(Config_GetCloudMng()->iCloudAbility == 0)
    {
        pstTask->iFailFlag = 1;
    }

    if(pstBuf != MOS_NULL)
    {   
        if ((ctime > pstBuf->cTime) || ((pstBuf->cTime > ctime) && (pstBuf->cTime > ctime + 600)))
        {
#if CLOUDSTG_UPLOAD_FORCE_STOP
            // 立即停止传输
            if (pstTask->cForceStopTime != 0 && ctime > pstTask->cForceStopTime)
            {
                Mos_MutexLock(&pstTask->hBufMutex);
                pstBuf = CloudStg_TransFindBufNodeWithType(&pstTask->stBufferList, EN_CLOUDSTG_TRANS_BUF_CHUNKEDEND);
                CloudStg_TransTaskClearBufList(&pstTask->stBufferList, pstBuf);
                MOS_PRINTF("taskid: %u is time to force stop!\r\n", pstTask->uiTaskID);
                Mos_MutexUnLock(&pstTask->hBufMutex);
                pstTask->cForceStopTime = 0;
            }
#endif
            if(pstTask->iFailFlag == 0)
            {
                // 发送
                iret = CloudStg_TransTaskSendBuf(pstTask, pstBuf);
            }

            // 释放资源
            if(pstBuf->enType == EN_CLOUDSTG_TRANS_BUF_SLICEINFO)
            {
                if( iret == 0)
                {                
                    Mos_MutexLock(&pstTask->hBufMutex);
                    MOS_LIST_RMVNODE(&pstTask->stBufferList, pstBuf);
                    if(pstBuf) 
                    {
                        if(pstBuf->pucBuf)
                        {
                            Mos_MemFree(pstBuf->pucBuf);
                        }
                        Mos_MemFree(pstBuf);
                    }
                    Mos_MutexUnLock(&pstTask->hBufMutex);
                }
                else
                {
                    pstTask->uiSentLen    = 0;
                    CloudStg_ConnSocketClose(pstTask->hCSConn);
                    pstTask->bStart        = MOS_FALSE;
                    pstTask->pstCurBufNode = MOS_NULL;
                    pstTask->iFailFlag     = 1;
                    pstTask->pFunSliceSend(pstTask->ptUseHandle,400,MOS_NULL,MOS_NULL,0,MOS_NULL,MOS_NULL);
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR,"trans task lost connect:%u",pstTask->uiTaskID);
                }
                pstTask->pstCurBufNode = MOS_NULL;
            }
            else
            {
                // 发送成功，释放已发送的资源
                if (iret == 0)
                {
                    CloudStg_TransAllStampRefresh(pstTask, pstBuf->uiTimeStamp);
                    pstTask->pstCurBufNode = &pstBuf->stNode;
                    Mos_MutexLock(&pstTask->hBufMutex);
                    CloudStg_TransTaskClearBufList(&pstTask->stBufferList, pstBuf);
                    Mos_MutexUnLock(&pstTask->hBufMutex);
                    pstTask->tFailTime     = 0;
                }
                // 发送失败，异常处理
                else
                {
                    if(pstTask->tFailTime == 0)
                    {
                        pstTask->tFailTime  = ctime;
                    }
                    if(iret == -1)
                    {
                        pstBuf->cTime = ctime + 5; //next retry time

                        // 插入TF卡重试15s，否则重试30s
                        uiRetryMaxTimeout = (Config_GetCamaraMng()->uiStorageStatus!=0)?15:30;
                        if(MOS_ABS_NUM(ctime - pstTask->tFailTime) > uiRetryMaxTimeout)
                        {
                            Mos_MutexLock(&pstTask->hBufMutex);
                            uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
                            Mos_MutexUnLock(&pstTask->hBufMutex);
                            CloudStg_RetrySentRateCheck(pstTask->uiIsPatch, 0, pstTask->iAliveTaskId);
                            CloudStg_ConnStop(pstTask->hCSConn, 1);
                            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"try %ds, but fail. Now conn stop taskid:%u, uiBufferListCount: %u", uiRetryMaxTimeout, pstTask->uiTaskID, uiBufferListCount);
                            iFlag = 1;
                        }
                        else
                        {
                            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"trans task retry send ctime: %u, pstTask->tFailTime: %u", pstBuf->cTime, pstTask->tFailTime);
                        }
                    }
                    else if (iret == -3)
                    {
                        ST_CLOUDSTG_TASK_NODE *pstTaskNode = MOS_NULL;
                        pstTaskNode = CloudStg_FindTaskNode(pstTask->uiIsPatch, pstTask->iAliveTaskId);
                        
                        // 文件上传方式：上传部分大于等于5s且无插入TF卡
                        if (pstTaskNode && pstTaskNode->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL && (Config_GetCamaraMng()->uiStorageStatus == 0) && ((ctime - 5) >= pstTaskNode->tCreateTime))
                        {
                            // 仍然在取流
                            if (pstTaskNode->iState < EN_CLOUDSTG_TASK_STOP)
                            {
                                // 中途commit信息填充
                                pstTaskNode->uiFailInMid = 1;
                                pstTaskNode->tFailInMidStartTime = pstTaskNode->tCreateTime + pstTask->uiAllStamp / 1000;

                                // 强制stop
                                pstTask->pstCurBufNode = MOS_NULL;
                                Mos_MutexLock(&pstTask->hBufMutex);
                                CloudStg_TransTaskClearBufList(&pstTask->stBufferList, MOS_NULL);
                                Mos_MutexUnLock(&pstTask->hBufMutex);
                                pstTask->tFailTime = 0;
                                CloudStg_ForceCommitWithTaskId(pstTask->iAliveTaskId);
                            }
                            else
                            {
                                // 发chunked end
                                if (pstTask->uiLastPacketSendTimes < 1)
                                {
                                    pstTask->uiLastPacketSendTimes++;
                                    CloudStg_TransSendSliceInfo(pstTask);
                                    MOS_LOG_WARN(CLOUDSTG_LOGSTR,"send last packet fail, now retry %d\r\n", pstTask->uiLastPacketSendTimes);
                                }
                                else
                                {
                                    MOS_LOG_ERR(CLOUDSTG_LOGSTR,"send last packet fail, now close\r\n");
                                    iFlag = 1;
                                }
                            }
                        }
                        else
                        {
                            iFlag = 1;
                        }
                    }
                    else
                    {
                        iFlag = 1;
                    }
                    if(iFlag == 1)
                    {
                        CloudStg_ConnStop(pstTask->hCSConn, 1);
                        pstTask->uiSentLen    = 0;
                        CloudStg_ConnSocketClose(pstTask->hCSConn);
                        pstTask->bStart        = MOS_FALSE;
                        pstTask->pstCurBufNode = MOS_NULL;
                        pstTask->iFailFlag     = 1;
                        pstTask->pFunSliceSend(pstTask->ptUseHandle,400,MOS_NULL,MOS_NULL,0,MOS_NULL,MOS_NULL);
                        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"trans task lost connect:%u",pstTask->uiTaskID);
                    }
                }
            }
            iCount = 1;
        }
    }

    Mos_MutexLock(&pstTask->hBufMutex);
    uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
    // 清空当前任务的发送队列
    if (pstTask->iFailFlag == 1 && uiBufferListCount != 0)
    { 
        if(pstTask->stBufferList.pstHead == MOS_NULL){
            if(pstTask->tFailTime == 0 || MOS_ABS_NUM(ctime - (pstTask->tFailTime + 10)) > 0){
                pstTask->tFailTime = ctime;
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"buffer list num %u",uiBufferListCount);
            }
            Mos_MutexUnLock(&pstTask->hBufMutex);
            return iCount;
        }
        pstTask->pstCurBufNode = MOS_NULL;
        CloudStg_TransTaskClearBufList(&pstTask->stBufferList, MOS_NULL);
    }
    else if (pstTask->bSendOver == MOS_TRUE && uiBufferListCount != 0)
    {
        if(pstTask->stBufferList.pstHead == MOS_NULL){
            if(pstTask->tFailTime == 0 || MOS_ABS_NUM(ctime - (pstTask->tFailTime + 10)) > 0){
                pstTask->tFailTime = ctime;
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"buffer list num %u",uiBufferListCount);
            }
            Mos_MutexUnLock(&pstTask->hBufMutex);
            return iCount;
        }
        pstBuf = MOS_LIST_RMVHEAD(&pstTask->stBufferList);
        if(pstBuf)
        {
            if(pstBuf->pucBuf)
            {
                Mos_MemFree(pstBuf->pucBuf);
            }
            Mos_MemFree(pstBuf);
            pstTask->pstCurBufNode = MOS_NULL;
        }
    }
    Mos_MutexUnLock(&pstTask->hBufMutex);

    Mos_MutexLock(&pstTask->hBufMutex);
    uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
    Mos_MutexUnLock(&pstTask->hBufMutex);

    // 断开连接，关闭任务
    if ((uiBufferListCount == 0 && pstTask->bSendOver == MOS_TRUE && CloudStg_GetTaskNodeState(uiIsPatch, pstTask->ptUseHandle) >= EN_CLOUDSTG_TASK_STOP) 
        || CloudStg_GetTaskNodeState(uiIsPatch, pstTask->ptUseHandle) == EN_CLOUDSTG_TASK_END)
    {
        MOS_PRINTF("CloudStg_GetTaskNodeState(uiIsPatch, pstTask->ptUseHandle): %d\r\n", CloudStg_GetTaskNodeState(uiIsPatch, pstTask->ptUseHandle));
        MOS_PRINTF("MOS_LIST_GETCOUNT(&pstTask->stBufferList): %d\r\n", uiBufferListCount);
        MOS_PRINTF("pstTask->bSendOver: %d\r\n", pstTask->bSendOver);
        
        if (uiIsPatch)
        {
            Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
            MOS_LIST_RMVNODE(&CloudStg_Trans_PatchGetMgr()->stTaskList,pstTask);
            Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        }
        else
        {
            Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
            MOS_LIST_RMVNODE(&CloudStg_TransGetMgr()->stTaskList,pstTask);
            Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
        }
        CloudStg_ConnShutDown(pstTask->hCSConn);
        CloudStg_TransTaskClose(pstTask);
    }
    return iCount;
}

/***********************************************************************************
************************************************************************************/
_HCSTASK  CloudStg_TransTaskOpen(_VPTR hStream,_INT iCamId, _INT iAliveTaskId, _UI uiType, _UI uiFilesize, PFUN_SLICECALLBACK pFun,_VPTR ptUseHandle, _UI uiIsPatch, _INT iCloudEncSwitch, _INT iIndex, _HCSCONN *phCSConn, _INT iDirectMode)
{
    ST_CLOUDSTG_TASK_INF *pstTask = MOS_NULL;
    ST_CLOUDSTG_STREAM *pstStream = (ST_CLOUDSTG_STREAM*)hStream;

    if (uiIsPatch)
    {
        if(CloudStg_Trans_PatchGetMgr()->bRun != MOS_TRUE)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"trans task does not run");
            return MOS_NULL;
        }
        pstTask = (ST_CLOUDSTG_TASK_INF*)Mos_MemAlloc(CloudStg_TransGetMgr()->hMem,sizeof(ST_CLOUDSTG_TASK_INF));
        if(pstTask == MOS_NULL)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"malloc trans task err ");
            return MOS_NULL;
        }
    }
    else
    {
        if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"trans task does not run");
            return MOS_NULL;
        }
        pstTask = (ST_CLOUDSTG_TASK_INF*)Mos_MemAlloc(CloudStg_TransGetMgr()->hMem,sizeof(ST_CLOUDSTG_TASK_INF));
        if(pstTask == MOS_NULL)
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"malloc trans task err ");
            return MOS_NULL;
        }
    }
    Mos_MutexCreate(&pstTask->hBufMutex);
    Mos_MutexCreate(&pstTask->hMutex);

    pstTask->iFailFlag      = 0;
    pstTask->iCamId         = iCamId;
    pstTask->bStart         = MOS_FALSE;
    pstTask->uiType         = uiType;
    pstTask->uiTaskID       = CloudStg_TransGenTaskId(uiType);  // 获取任务id
    pstTask->uiFileSize     = uiFilesize;
    pstTask->pFunSliceSend  = pFun;
    pstTask->ptUseHandle    = ptUseHandle;
    pstTask->pstCurBufNode  = MOS_NULL;
    pstTask->pstHeadBufNode = MOS_NULL;
    pstTask->pstTailBufNode = MOS_NULL;
    pstTask->pucWaitSendBuf = MOS_NULL;
    pstTask->uiPosition     = 0;
    pstTask->uiSentLen      = 0;
    pstTask->uiNeedSentLen  = 0;
    pstTask->uiWaitSendLen  = 0;
    pstTask->uiSliceNum     = 0;
    pstTask->uiSliceId      = 0;
    pstTask->uiSliceAddSize = 0;
    pstTask->tFailCount     = 0;
    pstTask->iExUploadUsed  = 0;
    pstTask->hParentStream  = pstStream;
    pstTask->iIndex         = iIndex;
    pstTask->iExUploadSum   = 0;
    pstTask->iExUploadOverFlag = 0;
    pstTask->iDirectMode    = iDirectMode;
    pstTask->iAliveTaskId   = iAliveTaskId;
    pstTask->uiIsPatch      = uiIsPatch;
    pstTask->uiExUploadLen  = 0;
    pstTask->uiExUploadStatus = EX_TRANS_STATUS_START;
    pstTask->uiLastPacketSendTimes = 0;
    pstTask->uiAllStamp     = 0;
    pstTask->uiLastStamp    = 0;
    if (*phCSConn!=MOS_NULL)
    {
        pstTask->hCSConn = *phCSConn;
    }
    else
    {
        pstTask->hCSConn = CloudStg_ConnOpen(pstTask,iAliveTaskId, uiType, uiFilesize, uiIsPatch, iCloudEncSwitch,pstTask->iDirectMode);
    }

    if(pstTask->hCSConn == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud trans open conn fail");
        MOS_FREE(pstTask);
        return MOS_NULL;
    }

    *phCSConn = pstTask->hCSConn;

    if (uiIsPatch)
    {
        pstTask->hMem   = Mos_MemOwnerCreate(MOS_NULL,(_UC*)"CloudPatchTask",(Mos_SysGetDeviceAbility()==EN_MOS_DEVICE_ABILITY_RICH)?CLOUDSTG_BUF_MAX_SIZE:CLOUDSTG_BUF_MID_SIZE);
        
        // 分配内存，并添加至表中
#ifdef MOS_MEM_USE_SEPARATE_MODE
        Mos_MemOwnerSetPriorSea(pstTask->hMem, CLOUDSTG_BUF_UNIT_SIZE, MOS_MEM_PATCH_CLOUD_MAX_POOL_SIZE);
#else
        Mos_MemOwnerSetPriorSea(pstTask->hMem, CLOUDSTG_BUF_UNIT_SIZE, (Mos_SysGetDeviceAbility()==EN_MOS_DEVICE_ABILITY_RICH)?MOS_MEM_EX_MAX_POOL_SIZE:MOS_MEM_MAX_POOL_SIZE);

#endif
        MOS_LIST_INIT(&pstTask->stBufferList);
        Mos_MutexLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        MOS_LIST_ADDTAIL(&CloudStg_Trans_PatchGetMgr()->stTaskList,pstTask);
        Mos_MutexUnLock(&CloudStg_Trans_PatchGetMgr()->hTaskMutex);
        // MOS_LOG_WARN(CLOUDSTG_LOGSTR, "cloud patch trans pstTask add: %d", MOS_LIST_GETCOUNT(&CloudStg_Trans_PatchGetMgr()->stTaskList));
        // MOS_LOG_WARN(CLOUDSTG_LOGSTR, "CloudStg_Trans_PatchGetMgr stTaskList count: %d", MOS_LIST_GETCOUNT(&CloudStg_Trans_PatchGetMgr()->stTaskList));
    }
    else
    {
        pstTask->hMem   = Mos_MemOwnerCreate(MOS_NULL,(_UC*)"CloudTask",(Mos_SysGetDeviceAbility()==EN_MOS_DEVICE_ABILITY_RICH)?CLOUDSTG_BUF_MAX_SIZE:CLOUDSTG_BUF_MID_SIZE);

        // 分配内存，并添加至表中
#ifdef MOS_MEM_USE_SEPARATE_MODE
        Mos_MemOwnerSetPriorSea(pstTask->hMem, CLOUDSTG_BUF_UNIT_SIZE, MOS_MEM_CLOUD_MAX_POOL_SIZE);
#else
        Mos_MemOwnerSetPriorSea(pstTask->hMem, CLOUDSTG_BUF_UNIT_SIZE, (Mos_SysGetDeviceAbility()==EN_MOS_DEVICE_ABILITY_RICH)?MOS_MEM_EX_MAX_POOL_SIZE:MOS_MEM_MAX_POOL_SIZE);
#endif
        MOS_LIST_INIT(&pstTask->stBufferList);
        Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
        MOS_LIST_ADDTAIL(&CloudStg_TransGetMgr()->stTaskList,pstTask);
        Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);
        // MOS_LOG_WARN(CLOUDSTG_LOGSTR, "CloudStg_TransGetMgr stTaskList count: %d", MOS_LIST_GETCOUNT(&CloudStg_TransGetMgr()->stTaskList));
    }

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud task %u open, cam:%d, conn: 0x%x, type:%u, hParentStream: %p",pstTask->uiTaskID,iCamId, pstTask->hCSConn, uiType, pstTask->hParentStream);
    return (_HCSTASK)pstTask;
}

_VOID CloudStg_TransTaskCloseAsync(_HCSTASK hCSTask)
{
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF*)hCSTask;
    if(pstTask != MOS_NULL)
    {
        pstTask->bSendOver = MOS_TRUE;
        MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud task %u close async",pstTask->uiTaskID);
    }
    return;
}

_VOID CloudStg_ExTransTaskTempClose(ST_CLOUDSTG_TASK_INF *pstTask)
{
    MOS_PARAM_NULL_NORET(pstTask);
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud TaskId: %u temp close, SentLen :%u slicenum %u ",
                      pstTask->uiTaskID,pstTask->uiSentLen,pstTask->uiSliceNum); 
    Mos_MutexLock(&pstTask->hBufMutex);
    CloudStg_TransTaskClearBufList(&pstTask->stBufferList, MOS_NULL);
    if(pstTask->pucWaitSendBuf)
    {
        Mos_MemFree(pstTask->pucWaitSendBuf);
    }
    Mos_MutexUnLock(&pstTask->hBufMutex);
    CloudStg_ConnStop(pstTask->hCSConn, 0);
    // CloudStg_ConnClose(pstTask->hCSConn, 0);
    return;
}

_VOID CloudStg_TransTaskClose(ST_CLOUDSTG_TASK_INF *pstTask)
{
    MOS_PARAM_NULL_NORET(pstTask);
    _INT iAliveTaskId = pstTask->iAliveTaskId;

    MOS_LOG_INF(CLOUDSTG_LOGSTR, "cloud TaskId: %u index: %d, close, SentLen :%u slicenum %u",
                      pstTask->uiTaskID,pstTask->iIndex,pstTask->uiSentLen,pstTask->uiSliceNum); 

    Mos_MutexLock(&pstTask->hBufMutex);
    CloudStg_TransTaskClearBufList(&pstTask->stBufferList, MOS_NULL);
    if(pstTask->pucWaitSendBuf)
    {
        Mos_MemFree(pstTask->pucWaitSendBuf);
    }
    Mos_MutexUnLock(&pstTask->hBufMutex);

    CloudStg_ConnClose(pstTask->hCSConn, 1);
    pstTask->hCSConn = MOS_NULL;

    Mos_MemOwnerDel(pstTask->hMem); 
    Mos_MutexDelete(&pstTask->hBufMutex);
    Mos_MutexDelete(&pstTask->hMutex);
    Mos_MemFree(pstTask);
    return;
}

_INT CloudStg_TransRecvSliceRspData(ST_CLOUDSTG_BUF_NODE *pstBuf,ST_CLOUDSTG_TASK_INF *pstTask)
{
    MOS_PARAM_NULL_RETERR(pstBuf);
    MOS_PARAM_NULL_RETERR(pstTask);

    _INT iCode = 0;
    ST_MECS_CONN *pstConn = (ST_MECS_CONN *)pstTask->hCSConn;

    Mos_MutexLock(&pstTask->hBufMutex);

    if(pstTask->uiSliceNum == 0)
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"trans task has no slice,taskid:%u",pstTask->uiTaskID);
    else
        pstTask->uiSliceNum--;
    Mos_MutexUnLock(&pstTask->hBufMutex);
    
    
    if(pstConn && pstConn->pstConnUrl && pstTask->pFunSliceSend)
        pstTask->pFunSliceSend(pstTask->ptUseHandle,0,pstConn->pstConnUrl->aucFid,pstConn->stSocket.aucETag,
                    pstConn->uiTargetSize,pstConn->pstConnUrl->aucBucket,pstConn->pstConnUrl->aucStorageProvider);
    pstBuf->uiSendLen = pstBuf->uiLen;
    pstBuf->cTime = Mos_Time() - 6;
    return MOS_OK;
}

_INT CloudStg_TransTaskSendBuf(ST_CLOUDSTG_TASK_INF *pstTask, ST_CLOUDSTG_BUF_NODE *pstBuf)
{
    MOS_PARAM_NULL_RETERR(pstBuf);
    MOS_PARAM_NULL_RETERR(pstTask);

    _INT iret = 0;
    _UI uiCurSendLen = 0;
    _INT iRet = MOS_OK;
    ST_MECS_CONN *pstConn = (ST_MECS_CONN *)pstTask->hCSConn;
    _UC aucEmptyBuf[MECS_TASK_MAX_EMPTY_BUF_UNIT] = {0};
#if DEBUG
    _UC pucFileName[16] = {0};
    static _INT index = 0;
    static FILE *fp = NULL;
    static _INT len = 0;

    static _INT count = 0;

    MOS_VSNPRINTF(pucFileName, sizeof(pucFileName), "/mnt/sdcard/%u.ps", pstTask->uiTaskID);
    if (!fp)
    {
        fp = fopen(pucFileName, "wb");
    }
#endif

    if (pstTask != pstBuf->hTask)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR, "engine[CloudService]  TaskId: %u is not normal", pstTask->uiTaskID);
        return 0;
    }

    // MOS_PRINTF("send type: %d, send len: %d\r\n", pstBuf->enType, pstBuf->uiLen - pstBuf->uiSendLen);

    switch (pstBuf->enType)
    {
        // 发送头+数据
        case EN_CLOUDSTG_TRANS_BUF_SLICEDATA:
        {
            if(pstTask->bStart == MOS_FALSE)
            {
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "TaskId:%u,cam:%d,SliceId:%u start send, pstTask->hCSConn addr: %p",pstTask->uiTaskID,pstTask->iCamId,pstTask->uiSliceId, pstTask->hCSConn);

                // 获取url，创建socket
                iRet = CloudStg_ConnStart(pstTask->hCSConn,0);
                if (MOS_OK != iRet)
                {
                    MOS_LOG_ERR(CLOUDSTG_LOGSTR, "start connect error for TaskId: %u", pstTask->uiTaskID);
                    return -2;
                }
                else
                {
                    pstTask->bStart = MOS_TRUE;
                }
            }
            if(pstConn && pstConn->pstConnUrl != MOS_NULL && pstBuf->uiLen > pstBuf->uiSendLen)
            {
                if((pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS) && pstConn->pstConnUrl->iStorageType == 2 && pstBuf->pucBuf != MOS_NULL && pstBuf->uiSendLen == 0 && pstBuf->uiAddChunkFlag == 0)
                {
                    // 组包
                    CloudStg_AddChunkInfo(pstBuf->pucBuf,&pstBuf->uiLen,&pstBuf->ucOffSet);
                    pstBuf->uiAddChunkFlag = 1;
                }
                else if (pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
                {
                    pstTask->iExUploadSum += pstBuf->uiLen - pstBuf->uiSendLen;
                    // MOS_PRINTF("uiLen: %d, uiSendLen: %d, sum: %d, uiSliceAddSize: %d\r\n", pstBuf->uiLen , pstBuf->uiSendLen, pstTask->iExUploadSum, pstTask->uiSliceAddSize);
                    if (pstTask->iExUploadSum == pstTask->uiSliceAddSize)
                    {
                        pstTask->iExUploadSum = 0;
                        MOS_PRINTF("EXCLOUD OVER!\r\n");
                    }
                }

                // 发送
                // MOS_PRINTF("position: pstBuf->pucBuf + %d + %d, len: %d\r\n", pstBuf->ucOffSet, pstBuf->uiSendLen, pstBuf->uiLen - pstBuf->uiSendLen);
                CloudStg_TotalSentCountAddOne(pstConn->uiIsPatch, 0, pstConn->iAliveTaskId);
                iRet = CloudStg_ConnSend(pstTask->hCSConn, pstBuf->pucBuf + pstBuf->ucOffSet + pstBuf->uiSendLen, pstBuf->uiLen - pstBuf->uiSendLen,1,&uiCurSendLen);
#if DEBUG
                if (count++ < 3)
                {
                    BUF_PRINTF_EX("SEND", pstBuf->pucBuf + pstBuf->ucOffSet + pstBuf->uiSendLen, pstBuf->uiLen - pstBuf->uiSendLen);
                }

                // 写文件
                len += pstBuf->uiLen - pstBuf->uiSendLen;
                fwrite(pstBuf->pucBuf + pstBuf->ucOffSet + pstBuf->uiSendLen, 1, pstBuf->uiLen - pstBuf->uiSendLen, fp);
#endif
            
            }
            // if (Mos_FileIsExist("/tmp/test1_a1") == MOS_TRUE)
            // {
            //     MOS_PRINTF("simulate network error!\r\n");
            //     iRet = MOS_ERR_TRYAGAIN;
            // }	
            if (MOS_OK == iRet)
            {
                if (pstConn)
                {
                    CloudStg_AddSentBytes(pstConn->uiIsPatch, 0, pstConn->iAliveTaskId, pstBuf->uiLen - pstBuf->uiSendLen);
                    pstConn->iSendTimes = 0;
                }
                pstTask->uiSentLen += pstBuf->uiLen;
            }
            else if(pstConn && pstConn->iSendTimes < 3 && MOS_ERR_TRYAGAIN == iRet)
            {
                CloudStg_RetrySentCountAddOne(pstConn->uiIsPatch, 0, pstConn->iAliveTaskId);
                pstConn->iSendTimes++;
                pstBuf->uiSendLen += uiCurSendLen;
                iret = -1;
            }
            else
            {
                // Mos_FileRmv("/tmp/test1_a1");
                pstConn->iSendTimes = 0;
                CloudStg_RetrySentRateCheck(pstConn->uiIsPatch, 0, pstConn->iAliveTaskId);
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "senddata error for TaskId: %u,cam:%d ,uiLen :%u, uiSendLen :%u, iRet: %d, SendTimes: %d",
                     pstTask->uiTaskID,pstTask->iCamId, pstBuf->uiLen,pstTask->uiSentLen,iRet,pstConn->iSendTimes);
                iret = -3;
            }
            break;
        }
        // 发送结尾
        case EN_CLOUDSTG_TRANS_BUF_CHUNKEDEND:
        {
            if(pstConn && pstConn->pstConnUrl != MOS_NULL && pstBuf->uiLen > pstBuf->uiSendLen)
            {
                iRet = CloudStg_ConnSend(pstTask->hCSConn, pstBuf->pucBuf + 6 +  pstBuf->uiSendLen, pstBuf->uiLen -  pstBuf->uiSendLen,1,&uiCurSendLen);
#if DEBUG
                len += pstBuf->uiLen - pstBuf->uiSendLen;
                fwrite(pstBuf->pucBuf + 6 +  pstBuf->uiSendLen, 1, pstBuf->uiLen - pstBuf->uiSendLen, fp);
#endif
            }
            
            if(pstConn && pstConn->iSendTimes < 3 && MOS_ERR_TRYAGAIN == iRet)
            {
                pstConn->iSendTimes++;
                pstBuf->uiSendLen += uiCurSendLen;
                iret = -1;
            }
            else if(MOS_OK != iRet)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "senddata error for TaskId: %u,cam:%d ,uiLen :%u, uiSendLen :%u", 
                    pstTask->uiTaskID,pstTask->iCamId, pstBuf->uiLen,pstTask->uiSentLen);
                iret = -2;
            }
            else
            {
                if (pstConn)
                {
                    CloudStg_AddSentBytes(pstConn->uiIsPatch, 0, pstConn->iAliveTaskId, pstBuf->uiLen -  pstBuf->uiSendLen);
                    pstConn->iSendTimes = 0;
                }
            }
            break;
        }
        // 发送空数据
        case EN_CLOUDSTG_TRANS_BUF_EMPTYDATA:
        {
            if(pstTask->bStart == MOS_FALSE)
            {
                pstBuf->uiSendLen += pstBuf->uiLen;
                break;
            }
            if (pstBuf->uiLen > MECS_TASK_MAX_EMPTY_BUF_UNIT || pstBuf->uiLen == 0)
            {
                break;
            }

            iRet = CloudStg_ConnSend(pstTask->hCSConn, aucEmptyBuf + pstBuf->uiSendLen , pstBuf->uiLen - pstBuf->uiSendLen,1,&uiCurSendLen);
            if (MOS_OK == iRet)
            {
                ST_MECS_CONN *pstCSConn = (ST_MECS_CONN *)pstTask->hCSConn;
                CloudStg_AddSentBytes(pstCSConn->uiIsPatch, 0, pstCSConn->iAliveTaskId, pstBuf->uiLen - pstBuf->uiSendLen);
                pstConn->iSendTimes = 0;
                pstTask->uiSentLen += pstBuf->uiLen;
            }
            else if(MOS_ERR_TRYAGAIN == iRet && pstConn->iSendTimes < 3)
            {
                pstConn->iSendTimes++;
                pstBuf->uiSendLen += uiCurSendLen;
                iret =  -1;
            }
            else
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "send empty data error for TaskId: %u, uiLen :%u, sentlen :%u", 
                     pstTask->uiTaskID, pstBuf->uiLen,pstTask->uiSentLen);
                iret = -2;
            }
            break;
        }
        // 最后一包
        case EN_CLOUDSTG_TRANS_BUF_SLICEEND:
        case EN_CLOUDSTG_TRANS_BUF_SLICEINFO:
        {
            if(pstBuf->cTime == 0)
            {
                pstBuf->cTime = Mos_Time() + 6;
                Mos_MutexLock(&pstTask->hBufMutex);
                CloudStg_TransTaskClearBufList(&pstTask->stBufferList, pstBuf);
                Mos_MutexUnLock(&pstTask->hBufMutex);
                pstTask->tFailTime = Mos_Time();
            }
            else if(pstBuf->uiSendLen != pstBuf->uiLen)
            {
                pstBuf->cTime   = 0;
            }
            // 确保发送完了
            if(pstBuf->uiSendLen == pstBuf->uiLen)
            {
                printf("%s:%d call CloudStg_ConnRecvRsp, pstTask->uiSentLen: %d, pstTask->hCSConn addr: %p\r\n", __FUNCTION__, __LINE__, pstTask->uiSentLen, pstTask->hCSConn);
                if((iRet = CloudStg_ConnRecvRsp(pstTask->hCSConn)) == MOS_OK || MOS_ABS_NUM(Mos_Time() - pstTask->tFailTime) > 4)// || MOS_ABS_NUM(Mos_Time() - pstTask->tFailTime) > 4)
                {
#if DEBUG
                    count = 0;
                    MOS_PRINTF("[%u]SAVE TO FILE OVER!", pstTask->uiTaskID);
                    if (fp)
                    {
                        fclose(fp);
                        fp = NULL;
                    }
#endif
                    // 返回
					if (pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_SLICE)
					{
                        if (pstBuf->enType == EN_CLOUDSTG_TRANS_BUF_SLICEINFO || iRet == MOS_ERR)
                        {
                            MOS_LOG_WARN(CLOUDSTG_LOGSTR, "Ready to close conn, iRet: %d", iRet);
                            CloudStg_TransRecvSliceRspData(pstBuf,pstTask);
                            CloudStg_ConnStop(pstTask->hCSConn, 1);
                        }
                        else
                        {
                            CloudStg_TaskAddOneExSentCount(0, pstTask->iAliveTaskId, pstTask->uiIsPatch);
                            CloudStg_ConnStop(pstTask->hCSConn, 0);
                        }
					}
					else if (pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_NORMAL || pstTask->iDirectMode == EN_CLOUDSTG_DIRECT_MODE_TYPE_STS)
					{
						CloudStg_TransRecvSliceRspData(pstBuf,pstTask);
                        CloudStg_ConnStop(pstTask->hCSConn, 1);
					}
                    pstTask->bStart = MOS_FALSE;
                }
                else
                {
                    // 重试时间
                    pstBuf->cTime = Mos_Time() + 1;
                    return -1;
                }
                MOS_LOG_INF(CLOUDSTG_LOGSTR, "stop slice for TaskId:%u,cam:%d,SliceId:%u,sentlen:%u", 
                     pstTask->uiTaskID, pstTask->iCamId,pstTask->uiSliceId++,pstTask->uiSentLen);
            }
            else{
                iret = -1;
            }
            break;
        }
        default:
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "engine[CloudService]   invalid param from TaskId: %u, enType:%d ",pstTask->uiTaskID, pstBuf->enType);
            break;
        }
    }
    return iret ;
}

_VOID  CloudStg_TransTaskClearBufList( ST_MOS_LIST *pstBufList, ST_CLOUDSTG_BUF_NODE *pstClearEndNode)
{
    MOS_PARAM_NULL_NORET(pstBufList);
    // MOS_PARAM_NULL_NORET(pstClearEndNode);
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_BUF_NODE *pstBufNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(pstBufList, pstBufNode, stIterator)
    {
        if( pstBufNode == pstClearEndNode)
        {
            if (pstClearEndNode != MOS_NULL)
            {
                break;
            }
        }
        MOS_LIST_RMVNODE(pstBufList, pstBufNode);
        if (pstBufNode)
        {
            if(pstBufNode->pucBuf)
            {
                Mos_MemFree(pstBufNode->pucBuf);
            }
            Mos_MemFree(pstBufNode);
        }
    }
    return;
}

_INT CloudStg_TransTaskAddBuf(_HCSTASK hCSTask, EN_CLOUDSTG_TRANS_BUF_TYPE enType, _UC *pucBuf, _UI uiBufLen, _UI uiTimeStamp, _INT iCloudEncSwitch, _UC *aucCloudEncAesKey, _UC *aucCloudEncAesIv)
{
    MOS_PARAM_NULL_RETERR(hCSTask);
    MOS_PARAM_NULL_RETERR(pucBuf);
    // return MOS_OK;

    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF*)hCSTask;
    ST_MECS_CONN *pstConn = (ST_MECS_CONN *)pstTask->hCSConn;
    ST_CLOUDSTG_BUF_NODE *pstBufNode = MOS_NULL;
    _UC aucEncData[64] = {0};
    _INT iEncDataLen = 0;

    pstTask->uiNeedSentLen += uiBufLen;

    // FIXME:默认补录trans也开了
    if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud task does not start");
        return MOS_ERR;
    }
    if(pstTask->bSendOver == MOS_TRUE)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"cloud task is send over, taskid:%u",pstTask->uiTaskID);
        return MOS_ERR;
    }
    pstTask->uiSliceAddSize += uiBufLen;
    if(pstTask->uiSliceAddSize > pstTask->uiFileSize)
    {
        if(pstConn && pstConn->pstConnUrl && pstConn->pstConnUrl->iStorageType)
        {
            if(Mos_Time() % 10 == 0 && pstConn->pstConnUrl->iStorageType == 1)
            {
                MOS_LOG_WARN(CLOUDSTG_LOGSTR,"cloud task add buf too long, taskid:%u, addsize:%u",pstTask->uiTaskID,pstTask->uiSliceAddSize);
            }
        }
    }
    //not data type or exceed size data will send wait data first, then send data immediately
    // 如果新传的buf 长度为0 或者大于1440 - 8，则新发送buf
    if(uiBufLen == 0 || uiBufLen >= CLOUDSTG_BUF_UNIT_SIZE - 8 || enType != EN_CLOUDSTG_TRANS_BUF_SLICEDATA)
    {
        // 先发送等待发送的buf
        Mos_MutexLock(&pstTask->hBufMutex);
        if(pstTask->uiWaitSendLen > 0)
        {
            pstBufNode = (ST_CLOUDSTG_BUF_NODE *)Mos_MemAlloc(pstTask->hMem, sizeof(ST_CLOUDSTG_BUF_NODE));
            MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstBufNode, Mos_MemAlloc);
            pstBufNode->hTask = (_HANDLE)pstTask;
            pstBufNode->enType = EN_CLOUDSTG_TRANS_BUF_SLICEDATA;
            pstBufNode->pucBuf = pstTask->pucWaitSendBuf;
            pstBufNode->uiLen  = pstTask->uiWaitSendLen;
            pstBufNode->cTime  = 0;
            pstBufNode->uiSendLen = 0;
            pstBufNode->uiAddChunkFlag = 0;
            pstBufNode->ucOffSet = 6;
            pstBufNode->uiTimeStamp = uiTimeStamp;
            MOS_LIST_ADDTAIL(&pstTask->stBufferList, pstBufNode);
            pstTask->uiWaitSendLen = 0;
            pstTask->pucWaitSendBuf = MOS_NULL;
        }
        // 再发送新传来的buf
        pstBufNode = (ST_CLOUDSTG_BUF_NODE *)Mos_MemAlloc(pstTask->hMem, sizeof(ST_CLOUDSTG_BUF_NODE));
        MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstBufNode, Mos_MemAlloc);
        pstBufNode->hTask  = (_HANDLE)pstTask;
        pstBufNode->enType = enType;
        pstBufNode->cTime  = 0;
        pstBufNode->uiSendLen = 0;
        pstBufNode->uiAddChunkFlag = 0;
        pstBufNode->ucOffSet = 6;
        pstBufNode->uiTimeStamp = uiTimeStamp;
        if (!pucBuf || uiBufLen == 0)
        {
            pstBufNode->pucBuf = MOS_NULL;
            pstBufNode->uiLen  = uiBufLen;
        }
        else
        {
            pstBufNode->pucBuf = (_UC *)Mos_MemAlloc(pstTask->hMem, uiBufLen); //FIXME: sizeof(ST_MOS_MEM_NODE) = 72
            if(!pstBufNode->pucBuf)
            {
                MOS_LOG_ERR(CLOUDSTG_LOGSTR, "memPool alloc failed");
                Mos_MemFree(pstBufNode);
                Mos_MutexUnLock(&pstTask->hBufMutex);
                return MOS_ERR;
            }
            if (iCloudEncSwitch == 1)
            {
                MOS_MEMSET(aucEncData, 0x00, sizeof(aucEncData));
                iEncDataLen = CloudStg_Res_DataEncrypt(aucCloudEncAesKey, aucCloudEncAesIv, pucBuf, uiBufLen, aucEncData);
                if (iEncDataLen > 0)
                {
                    MOS_MEMCPY(pstBufNode->pucBuf + 6, aucEncData, iEncDataLen); 
                    MOS_MEMCPY(pstBufNode->pucBuf + 6 + iEncDataLen, pucBuf + iEncDataLen, uiBufLen - iEncDataLen); 
                }
                else
                {
                    MOS_MEMCPY(pstBufNode->pucBuf + 6, pucBuf, uiBufLen); 
                }
            }
            else
            {
                MOS_MEMCPY(pstBufNode->pucBuf + 6, pucBuf, uiBufLen);   
            }
            pstBufNode->uiLen = uiBufLen;
        }
        MOS_LIST_ADDTAIL(&pstTask->stBufferList, pstBufNode);
        Mos_MutexUnLock(&pstTask->hBufMutex);
        return  MOS_OK;
    }
    //if wait buf is enough, copy int waitbuf.else send wait buffer first,malloc new wait buffer
    // 如果加上新传的buf不够1440，则新传的buf加入等待发送队列
    if(pstTask->uiWaitSendLen + uiBufLen + 8 < CLOUDSTG_BUF_UNIT_SIZE)
    {
        if(pstTask->uiWaitSendLen  == 0)
        {
            pstTask->pucWaitSendBuf = (_UC *)Mos_MemAlloc(pstTask->hMem, CLOUDSTG_BUF_UNIT_SIZE);
            MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstTask->pucWaitSendBuf, Mos_MemAlloc);
        }
        if (iCloudEncSwitch == 1)
        {
            MOS_MEMSET(aucEncData, 0x00, sizeof(aucEncData));
            iEncDataLen = CloudStg_Res_DataEncrypt(aucCloudEncAesKey, aucCloudEncAesIv, pucBuf, uiBufLen, aucEncData);
            if (iEncDataLen > 0)
            {
                MOS_MEMCPY(pstTask->pucWaitSendBuf + pstTask->uiWaitSendLen + 6, aucEncData, iEncDataLen);
                MOS_MEMCPY(pstTask->pucWaitSendBuf + pstTask->uiWaitSendLen + 6 + iEncDataLen, pucBuf + iEncDataLen, uiBufLen - iEncDataLen);
            }
            else
            {
                MOS_MEMCPY(pstTask->pucWaitSendBuf + pstTask->uiWaitSendLen + 6, pucBuf, uiBufLen);
            }
        }
        else
        {
            MOS_MEMCPY(pstTask->pucWaitSendBuf + pstTask->uiWaitSendLen + 6, pucBuf, uiBufLen);
        }
        pstTask->uiWaitSendLen += uiBufLen; 
 
        return  MOS_OK;
    }

    // 如果还有等待发送的buf，则发送
    if(pstTask->uiWaitSendLen > 0)
    {
        pstBufNode = (ST_CLOUDSTG_BUF_NODE *)Mos_MemAlloc(pstTask->hMem, sizeof(ST_CLOUDSTG_BUF_NODE));
        MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstBufNode, Mos_MemAlloc);
        pstBufNode->hTask = (_HANDLE)pstTask;
        pstBufNode->enType = EN_CLOUDSTG_TRANS_BUF_SLICEDATA;
        pstBufNode->pucBuf = pstTask->pucWaitSendBuf;
        pstBufNode->uiLen  = pstTask->uiWaitSendLen;
        pstBufNode->cTime  = 0;
        pstBufNode->uiSendLen = 0;
        pstBufNode->uiAddChunkFlag = 0;
        pstBufNode->ucOffSet = 6;
        pstBufNode->uiTimeStamp = uiTimeStamp;
        Mos_MutexLock(&pstTask->hBufMutex);
        MOS_LIST_ADDTAIL(&pstTask->stBufferList, pstBufNode);
        Mos_MutexUnLock(&pstTask->hBufMutex);
        pstTask->uiWaitSendLen = 0;
        pstTask->pucWaitSendBuf = MOS_NULL;
    }

    pstTask->pucWaitSendBuf = (_UC *)Mos_MemAlloc(pstTask->hMem, CLOUDSTG_BUF_UNIT_SIZE);
    MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstTask->pucWaitSendBuf, Mos_MemAlloc);
    if (iCloudEncSwitch == 1)
    {
        MOS_MEMSET(aucEncData, 0x00, sizeof(aucEncData));
        iEncDataLen = CloudStg_Res_DataEncrypt(aucCloudEncAesKey, aucCloudEncAesIv, pucBuf, uiBufLen, aucEncData);
        if (iEncDataLen > 0)
        {
            MOS_MEMCPY(pstTask->pucWaitSendBuf + 6, aucEncData, iEncDataLen);
            MOS_MEMCPY(pstTask->pucWaitSendBuf + 6 + iEncDataLen, pucBuf + iEncDataLen, uiBufLen - iEncDataLen);
        }
        else
        {
            MOS_MEMCPY(pstTask->pucWaitSendBuf + 6, pucBuf, uiBufLen);
        }
    }
    else
    {
        MOS_MEMCPY(pstTask->pucWaitSendBuf + 6, pucBuf, uiBufLen);
    }
    pstTask->uiWaitSendLen = uiBufLen;
    return  MOS_OK;
}

_INT CloudStg_TransTaskFillData(_HCSTASK hCSTask,_UI uiFillLen)
{ 
    // FIXME:默认补录trans也开了
    if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud trans does not start");
        return MOS_ERR;
    }
    if(uiFillLen == 0)
    {  
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud trans filled len zero");
        return MOS_ERR;
    }
    while(uiFillLen > CLOUDSTG_BUF_UNIT_SIZE - 8)
    {
        CloudStg_TransTaskAddBuf(hCSTask, EN_CLOUDSTG_TRANS_BUF_EMPTYDATA,MOS_NULL,CLOUDSTG_BUF_UNIT_SIZE - 8,0,0,MOS_NULL,MOS_NULL);
        uiFillLen -= CLOUDSTG_BUF_UNIT_SIZE - 8;
    }
    if(uiFillLen > 0)
        CloudStg_TransTaskAddBuf(hCSTask, EN_CLOUDSTG_TRANS_BUF_EMPTYDATA,MOS_NULL,uiFillLen,0,0,MOS_NULL,MOS_NULL);

    return MOS_OK;
}

_INT CloudStg_TransSendSliceInfo(_HCSTASK hCSTask)
{
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    ST_CLOUDSTG_BUF_NODE *pstBufNode = MOS_NULL;

    // FIXME:默认补录trans也开了
    if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"mecs does not start");
        return MOS_ERR;
    }
    if(pstTask->bSendOver == MOS_TRUE)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"cloud task send over, taskid:%u",pstTask->uiTaskID);
        return MOS_ERR;
    }
    if(pstTask->uiWaitSendLen > 0)
    {
        pstBufNode = (ST_CLOUDSTG_BUF_NODE *)Mos_MemAlloc(pstTask->hMem, sizeof(ST_CLOUDSTG_BUF_NODE));
        MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstBufNode, Mos_MemAlloc);

        pstBufNode->hTask = (_HANDLE)pstTask;
        pstBufNode->enType = EN_CLOUDSTG_TRANS_BUF_SLICEDATA;
        pstBufNode->pucBuf = pstTask->pucWaitSendBuf;
        pstBufNode->uiLen  = pstTask->uiWaitSendLen;
        pstBufNode->cTime  = 0;
        pstBufNode->uiSendLen = 0;
        pstBufNode->uiAddChunkFlag = 0;
        pstBufNode->ucOffSet = 6;
        pstBufNode->uiTimeStamp = 0;
        Mos_MutexLock(&pstTask->hBufMutex);
        MOS_LIST_ADDTAIL(&pstTask->stBufferList, pstBufNode);
        Mos_MutexUnLock(&pstTask->hBufMutex); 
        pstTask->uiWaitSendLen = 0;
        pstTask->pucWaitSendBuf = MOS_NULL;
    }
    // if(pstTask->uiSliceAddSize != pstTask->uiFileSize)
    // {
    //     MOS_LOG_WARN(CLOUDSTG_LOGSTR,"cloud task slice err size, taskid:%u, addsize:%u, filesize:%u",pstTask->uiTaskID,pstTask->uiSliceAddSize,pstTask->uiFileSize);
    // }    
    pstTask->uiSliceAddSize  = 0;
    
    pstBufNode = (ST_CLOUDSTG_BUF_NODE *)Mos_MemAlloc(pstTask->hMem, sizeof(ST_CLOUDSTG_BUF_NODE));
    MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstBufNode, Mos_MemAlloc);
    pstBufNode->hTask  = (_HANDLE)pstTask;
    pstBufNode->enType = EN_CLOUDSTG_TRANS_BUF_SLICEINFO;
    pstBufNode->uiLen  = 0;
    pstBufNode->pucBuf = MOS_NULL;
    pstBufNode->cTime  = 0;
    pstBufNode->uiSendLen = 0;
    pstBufNode->uiAddChunkFlag = 0;
    pstBufNode->ucOffSet = 6;
    pstBufNode->uiTimeStamp = 0;
    Mos_MutexLock(&pstTask->hBufMutex);
    MOS_LIST_ADDTAIL(&pstTask->stBufferList, pstBufNode);
    Mos_MutexUnLock(&pstTask->hBufMutex);
    pstTask->uiSliceNum++;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud send file license cnt %u, TaskId:%u",pstTask->uiSliceNum, pstTask->uiTaskID);
    return MOS_OK;
}

_INT CloudStg_TransSendSliceEnd(_HCSTASK hCSTask)
{
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    ST_CLOUDSTG_BUF_NODE *pstBufNode = MOS_NULL;

    // FIXME:默认补录trans也开了
    if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"mecs does not start");
        return MOS_ERR;
    }
    if(pstTask->bSendOver == MOS_TRUE)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"cloud task send over, taskid:%u",pstTask->uiTaskID);
        return MOS_ERR;
    }
    
    if(pstTask->uiWaitSendLen > 0)
    {
        MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud taskid:%u, WaitSend len: %d",pstTask->uiTaskID, pstTask->uiWaitSendLen);
        pstBufNode = (ST_CLOUDSTG_BUF_NODE *)Mos_MemAlloc(pstTask->hMem, sizeof(ST_CLOUDSTG_BUF_NODE));
        MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstBufNode, Mos_MemAlloc);

        pstBufNode->hTask = (_HANDLE)pstTask;
        pstBufNode->enType = EN_CLOUDSTG_TRANS_BUF_SLICEDATA;
        pstBufNode->pucBuf = pstTask->pucWaitSendBuf;
        pstBufNode->uiLen  = pstTask->uiWaitSendLen;
        pstBufNode->cTime  = 0;
        pstBufNode->uiSendLen = 0;
        pstBufNode->uiAddChunkFlag = 0;
        pstBufNode->ucOffSet = 6;
        Mos_MutexLock(&pstTask->hBufMutex);
        MOS_LIST_ADDTAIL(&pstTask->stBufferList, pstBufNode);
        Mos_MutexUnLock(&pstTask->hBufMutex); 
        pstTask->uiWaitSendLen = 0;
        pstTask->pucWaitSendBuf = MOS_NULL;
    }
    pstTask->uiSliceAddSize  = 0;

    pstBufNode = (ST_CLOUDSTG_BUF_NODE *)Mos_MemAlloc(pstTask->hMem, sizeof(ST_CLOUDSTG_BUF_NODE));
    MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstBufNode, Mos_MemAlloc);
    pstBufNode->hTask  = (_HANDLE)pstTask;
    pstBufNode->enType = EN_CLOUDSTG_TRANS_BUF_SLICEEND;
    pstBufNode->uiLen  = 0;
    pstBufNode->pucBuf = MOS_NULL;
    pstBufNode->cTime  = 0;
    pstBufNode->uiSendLen = 0;
    pstBufNode->uiAddChunkFlag = 0;
    pstBufNode->ucOffSet = 6;
    Mos_MutexLock(&pstTask->hBufMutex);
    MOS_LIST_ADDTAIL(&pstTask->stBufferList, pstBufNode);
    Mos_MutexUnLock(&pstTask->hBufMutex);
    pstTask->uiSliceNum++;
    MOS_LOG_INF(CLOUDSTG_LOGSTR,"cloud send file license cnt %u, TaskId:%u",pstTask->uiSliceNum, pstTask->uiTaskID);
    return MOS_OK;
}

_INT CloudStg_TransSendLastData(_HCSTASK hCSTask)
{
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    ST_CLOUDSTG_BUF_NODE *pstBufNode = MOS_NULL;

    // FIXME:默认补录chan也开了
    if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"mecs does not start");
        return MOS_ERR;
    }
    if(pstTask->bSendOver == MOS_TRUE)
    {
        MOS_LOG_WARN(CLOUDSTG_LOGSTR,"cloud task send over, taskid:%u",pstTask->uiTaskID);
        return MOS_ERR;
    }
    if(pstTask->uiWaitSendLen > 0)
    {
        pstBufNode = (ST_CLOUDSTG_BUF_NODE *)Mos_MemAlloc(pstTask->hMem, sizeof(ST_CLOUDSTG_BUF_NODE));
        MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstBufNode, Mos_MemAlloc);

        pstBufNode->hTask = (_HANDLE)pstTask;
        pstBufNode->enType = EN_CLOUDSTG_TRANS_BUF_SLICEDATA;
        pstBufNode->pucBuf = pstTask->pucWaitSendBuf;
        pstBufNode->uiLen  = pstTask->uiWaitSendLen;
        pstBufNode->cTime  = 0;
        pstBufNode->uiSendLen = 0;
        pstBufNode->uiAddChunkFlag = 0;
        pstBufNode->ucOffSet = 6;
        pstBufNode->uiTimeStamp = 0;
        Mos_MutexLock(&pstTask->hBufMutex);
        MOS_LIST_ADDTAIL(&pstTask->stBufferList, pstBufNode);
        Mos_MutexUnLock(&pstTask->hBufMutex); 
        pstTask->uiWaitSendLen = 0;
        pstTask->pucWaitSendBuf = MOS_NULL;
    }
    return MOS_OK;
}

_UI CloudStg_TransTaskSliceNum(_HCSTASK hCSTask)
{
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    if(pstTask == MOS_NULL)
    {
        return 0;
    }
    return pstTask->uiSliceNum;
}

_UI CloudStg_TransTaskGetCacheNodeCount(_HCSTASK hCSTask)
{
    _UI uiBufferListCount = 0;
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    if(pstTask == MOS_NULL)
    {
        return 0;
    }
    Mos_MutexLock(&pstTask->hBufMutex);
    uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
    Mos_MutexUnLock(&pstTask->hBufMutex);
    return uiBufferListCount;
}

_INT CloudStg_TransSendExtUriWithMem(_INT iAliveTaskId,_UC *pucBuf,_UI uiLen,_UI uiIcon,_UI uiType,PFUN_FINISHED pfuncFinished,_VPTR vpBase,_CTIME_T cStartTime)
{
    MOS_PARAM_NULL_RETERR(pucBuf);

    ST_MECS_EXT_TASK *pstExtTask = MOS_NULL;
    if(pucBuf == MOS_NULL || uiLen == 0)
    {
        return MOS_ERR;
    }
    if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud does not run");
        return MOS_ERR;
    }
    pstExtTask = (ST_MECS_EXT_TASK *)Mos_MemAlloc(CloudStg_TransGetMgr()->hMem,sizeof(ST_MECS_EXT_TASK));
    MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstExtTask,Mos_MemAlloc);
    pstExtTask->uiIcon = uiIcon;
    pstExtTask->cSendTime      = 0;
    pstExtTask->cConnectTime   = Mos_Time();
    pstExtTask->uiOffsetLen    = 0;
    pstExtTask->uiBuffLen      = 0;
    pstExtTask->uiSendTotalLen = 0;
    pstExtTask->uiFileTotalLen = uiLen;
    pstExtTask->cStartTime = cStartTime;
    pstExtTask->uiLen  = uiLen;
    pstExtTask->pucbuf = pucBuf;
    pstExtTask->uiType = uiType;
    pstExtTask->iAliveTaskId   = iAliveTaskId;
    pstExtTask->pfuncFinished = pfuncFinished;
    pstExtTask->iDirectMode = Config_GetCloudMng()->iDirectMode;
    pstExtTask->vpBase        = vpBase;
    Mos_MutexLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    MOS_LIST_ADDHEAD(&CloudStg_TransGetMgr()->stExtUriList,pstExtTask);
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    return MOS_OK;
}

_INT CloudStg_TransSendLocalFile(_UC *pucFileName,_UI uiType,PFUN_FINISHED pfuncFinished,_VPTR vpBase)
{
    MOS_PARAM_NULL_RETERR(pucFileName);

    ST_MOS_FILE_INF stFileInf;
    ST_MECS_EXT_TASK *pstExtTask = MOS_NULL;
    if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud does not run");
        return MOS_ERR;
    }
    MOS_MEMSET(&stFileInf, 0, sizeof(stFileInf));
    if(Mos_FileStat(pucFileName,&stFileInf) == MOS_ERR)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Local file get info err, file :%s",pucFileName);
        return MOS_ERR;
    }
    pstExtTask = (ST_MECS_EXT_TASK *)Mos_MemAlloc(CloudStg_TransGetMgr()->hMem,sizeof(ST_MECS_EXT_TASK));
    MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstExtTask,Mos_MemAlloc);
    pstExtTask->cSendTime      = 0;
    pstExtTask->uiOffsetLen    = 0;
    pstExtTask->uiBuffLen      = 0;
    pstExtTask->uiSendTotalLen = 0;
    pstExtTask->uiType         = uiType;
    pstExtTask->pfuncFinished  = pfuncFinished;
    pstExtTask->vpBase         = vpBase;
    pstExtTask->iAliveTaskId   = 0;

    pstExtTask->uiFileTotalLen = stFileInf.uiSize;
    MOS_MEMCPY(pstExtTask->aucFileName, pucFileName, 255);
    Mos_MutexLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    MOS_LIST_ADDHEAD(&CloudStg_TransGetMgr()->stExtUriList,pstExtTask);
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    MOS_LOG_INF(CLOUDSTG_LOGSTR, "send local file, name %s,type %u",pucFileName,uiType);
    return MOS_OK;
}

_INT CloudStg_TransUploadLog(_UI uiType,PFUN_FINISHED pfuncFinished,_VPTR vpBase, _UC *pucUrl, _INT iHostStatus, _INT iRt, _UC *pucMsg, _UC *pucEt, _CTIME_T cCreateTime)
{
    ST_MECS_EXT_TASK *pstExtTask = MOS_NULL;
    ST_MECS_EXT_TASK *pstExtUriListNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;

    _INT iLogCount =0;

    if(CloudStg_TransGetMgr()->bRun != MOS_TRUE)
    {
        MOS_LOG_ERR(CLOUDSTG_LOGSTR,"cloud does not run");
        return MOS_ERR;
    }

    pstExtTask = (ST_MECS_EXT_TASK *)Mos_MemAlloc(CloudStg_TransGetMgr()->hMem,sizeof(ST_MECS_EXT_TASK));
    MOS_FUNRET_NULL_RETERR(CLOUDSTG_LOGSTR,pstExtTask,Mos_MemAlloc);
    pstExtTask->cSendTime      = Mos_Time();
    pstExtTask->cCreateTime    = cCreateTime;
    pstExtTask->uiOffsetLen    = 0;
    pstExtTask->uiBuffLen      = 0;
    pstExtTask->uiSendTotalLen = 0;
    pstExtTask->uiType         = uiType;
    pstExtTask->pfuncFinished  = pfuncFinished;
    pstExtTask->vpBase         = vpBase;
    pstExtTask->iAliveTaskId   = 0;

    /*log*/
    pstExtTask->pucUrl         = MOS_STRCPYALLOC(pucUrl);
    pstExtTask->pucMsg         = MOS_STRCPYALLOC(pucMsg);
    pstExtTask->pucEt          = MOS_STRCPYALLOC(pucEt);
    pstExtTask->iHostStatus    = iHostStatus;
    pstExtTask->iRt            = iRt;

    Mos_MutexLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    FOR_EACHDATA_INLIST(&CloudStg_TransGetMgr()->stExtUriList, pstExtUriListNode, stIterator)
    {
        if (pstExtUriListNode->uiType == EN_CLOUDSTG_RESOURCE_LOG)
        {
            iLogCount++;
        }
    }

    if(iLogCount >= CLOUDSTG_UPLOADLOG_MAX_COUNT)
    {
        FOR_EACHDATA_INLIST(&CloudStg_TransGetMgr()->stExtUriList, pstExtUriListNode, stIterator)
        {
            if (pstExtUriListNode->uiType == EN_CLOUDSTG_RESOURCE_LOG)
            {
                MOS_LIST_RMVNODE(&CloudStg_TransGetMgr()->stExtUriList, pstExtUriListNode);
                MOS_FREE(pstExtUriListNode->pucUrl);
                MOS_FREE(pstExtUriListNode->pucMsg);
                MOS_FREE(pstExtUriListNode->pucEt);
                CloudStg_FileNodeSetUsed((_UI)pstExtUriListNode->vpBase);
                Mos_MemFree(pstExtUriListNode);
                break;
            }
        }
    }

    MOS_LIST_ADDTAIL(&CloudStg_TransGetMgr()->stExtUriList,pstExtTask);
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hExtUriMutex);
    //MOS_LOG_INF(CLOUDSTG_LOGSTR, "upload log now, type %u",uiType);
    return MOS_OK;
}

_INT CloudStg_ExChanSetUsed(_HCSTASK hCSTask, _INT iState)
{
    MOS_PARAM_NULL_RETERR(hCSTask);

    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF*)hCSTask;
    Mos_MutexLock(&pstTask->hMutex);
    pstTask->iExUploadUsed = iState;
    Mos_MutexUnLock(&pstTask->hMutex);

    return MOS_OK;
}

_INT CloudStg_ExChanGetUsed(_HCSTASK hCSTask)
{
    MOS_PARAM_NULL_RETERR(hCSTask);

    _INT iExUploadUsed = 0;
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF*)hCSTask;
    Mos_MutexLock(&pstTask->hMutex);
    iExUploadUsed = pstTask->iExUploadUsed;
    Mos_MutexUnLock(&pstTask->hMutex);
    return iExUploadUsed;
}

_INT CloudStg_TransTaskSendHandleEx(ST_CLOUDSTG_TASK_INF *pstTask, ST_CLOUDSTG_BUF_NODE *pstBuf, _CTIME_T ctime, _INT iret)
{
    _INT iFlag = 0;
    _UI uiRetryMaxTimeout = 0;
    _UI uiBufferListCount = 0;
    ST_MECS_CONN *pstConn = (ST_MECS_CONN *)pstTask->hCSConn;

    // 发送成功，释放已发送的资源
    if (iret == 0)
    {
        // MOS_PRINTF("send %d.., pstTask->->uiSentLen: %d\r\n", pstBuf->uiLen, pstTask->uiSentLen);
        pstTask->pstCurBufNode = &pstBuf->stNode;
        Mos_MutexLock(&pstTask->hBufMutex);
        CloudStg_TransTaskClearBufList(&pstTask->stBufferList, pstBuf);
        Mos_MutexUnLock(&pstTask->hBufMutex);
        pstTask->tFailTime     = 0;
        pstTask->tFailCount    = 0;
        return MOS_OK;
    }
    // 异常处理
    else
    {
        if(pstTask->tFailTime == 0)
        {
            pstTask->tFailTime  = ctime;
        }
        if(iret == -1)
        {
            Mos_MutexLock(&pstTask->hBufMutex);
            uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
            Mos_MutexUnLock(&pstTask->hBufMutex);
            CloudStg_ExChanSetUsed(pstTask, 0);
            CloudStg_ConnStop(pstTask->hCSConn, 0);
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"Now conn stop taskid:%u, uiBufferListCount: %u", pstTask->uiTaskID, uiBufferListCount);
            iFlag = 1;
        }
        else if(iret == -2)
        {
            iFlag = 1;
        }
        if(iFlag == 1)
        {
            pstTask->tFailCount    = 0;
            pstTask->uiSentLen     = 0;
            pstTask->bStart        = MOS_FALSE;
            pstTask->pstCurBufNode = MOS_NULL;
            pstTask->iFailFlag     = 1;

            // 必须发送成功1个或以上的切片才能commit
            if (pstConn && pstConn->pstConnUrl && CloudStg_TaskGetExSentCount(0, pstTask->iAliveTaskId, pstTask->uiIsPatch) > 0)
            {
                MOS_PRINTF("These stream has sent %d chan\r\n", CloudStg_TaskGetExSentCount(0, pstTask->iAliveTaskId, pstTask->uiIsPatch));
                pstTask->pFunSliceSend(pstTask->ptUseHandle,400,pstConn->pstConnUrl->aucFid,pstConn->stSocket.aucETag,
                            pstConn->uiTargetSize,pstConn->pstConnUrl->aucBucket,pstConn->pstConnUrl->aucStorageProvider);
            }
            else
            {
                pstTask->pFunSliceSend(pstTask->ptUseHandle,400,MOS_NULL,MOS_NULL,0,MOS_NULL,MOS_NULL);
            }
            CloudStg_ConnSocketClose(pstTask->hCSConn);
            MOS_LOG_ERR(CLOUDSTG_LOGSTR,"chan task lost connect:%u",pstTask->uiTaskID);
        }
    }    
    return MOS_ERR;
}

_INT CloudStg_ExTransTaskCleanBuflist(ST_CLOUDSTG_TASK_INF *pstTask, _CTIME_T ctime, _INT  iCount)
{
    MOS_PARAM_NULL_RETERR(pstTask);

	_UI uiBufferListCount = 0;
    ST_CLOUDSTG_BUF_NODE *pstBuf = MOS_NULL;
    
    Mos_MutexLock(&pstTask->hBufMutex);
    uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
    // 清空当前任务的发送队列
    if (pstTask->iFailFlag == 1 && uiBufferListCount != 0)
    { 
        // MOS_PRINTF("Clean all buflist\r\n");
        pstTask->iFailFlag     = 0;
        pstTask->tFailCount    = 0;
        pstTask->uiSentLen     = 0;
        pstTask->bStart        = MOS_FALSE;
        CloudStg_TransTaskClearBufList(&pstTask->stBufferList, MOS_NULL);
        pstTask->pstCurBufNode = MOS_NULL;
    }
    else if ((pstTask->bSendOver == MOS_TRUE && uiBufferListCount != 0) || (Cloudstg_ExTransCurBufNodeIsEmpty(pstTask) && uiBufferListCount != 0))
    {
        if ((Cloudstg_ExTransCurBufNodeIsEmpty(pstTask) && uiBufferListCount != 0))
        {
            MOS_PRINTF("%s:%d [%d]hunt you uiTotalCount: %d!!!!!!!!!!!!!\r\n", __FUNCTION__, __LINE__, pstTask->uiTaskID, uiBufferListCount);
        }
        if(pstTask->stBufferList.pstHead == MOS_NULL){
            if(pstTask->tFailTime == 0 || ctime > pstTask->tFailTime + 10){
                pstTask->tFailTime = ctime;
                MOS_LOG_INF(CLOUDSTG_LOGSTR,"buffer list num %u", uiBufferListCount);
            }
            Mos_MutexUnLock(&pstTask->hBufMutex);
            return iCount;
        }
        pstBuf = MOS_LIST_RMVHEAD(&pstTask->stBufferList);
        if(pstBuf)
        {
            if(pstBuf->pucBuf)
            {
                Mos_MemFree(pstBuf->pucBuf);
            }
            Mos_MemFree(pstBuf);
            pstTask->pstCurBufNode = MOS_NULL;
        }
    }
    Mos_MutexUnLock(&pstTask->hBufMutex);

    Mos_MutexLock(&pstTask->hBufMutex);
    uiBufferListCount = MOS_LIST_GETCOUNT(&pstTask->stBufferList);
    Mos_MutexUnLock(&pstTask->hBufMutex);

    // 暂时关闭断开连接
    if (uiBufferListCount == 0 && CloudStg_ExChanGetUsed(pstTask) == 1)
    {
        // 写操作设置未使用
        CloudStg_ExChanSetUsed(pstTask, 0);

        CloudStg_ConnShutDown(pstTask->hCSConn);
        CloudStg_ExTransTaskTempClose(pstTask);
    }

    return iCount;
}

_INT Cloudstg_ExTransCurBufNodeIsEmpty(ST_CLOUDSTG_TASK_INF *pstTask)
{
    MOS_PARAM_NULL_RETERR(pstTask);

    if (pstTask->pstCurBufNode)
    {
        if (pstTask->pstCurBufNode->pstPrv == MOS_NULL && pstTask->pstCurBufNode->pstNext == MOS_NULL)
        {
            return MOS_TRUE;
        }
    }
    
    return MOS_FALSE;
}

// FIXME: 存在段错误,暂时屏蔽
_INT Cloudstg_ExTransNetCheck(ST_CLOUDSTG_TASK_INF *pstTask, _INT iKiloBitSpeed)
{
    MOS_PARAM_NULL_RETERR(pstTask);

    _INT iConfigBitrate[] = {0, 96, 128, 196, 256, 384, 512, 768, 1024, 1536, 2048, 2560, 3072, 4096};
    _INT iCameraBitrate   = 0;
    _INT iDifference      = 0;
    _INT iLowBitSpeed     = 0;
    _INT iHighBitSpeed    = 0;

    iCameraBitrate = iConfigBitrate[CloudStg_ExStreamGetBitRate(pstTask->hParentStream)];
    MOS_PRINTF("CameraBitrate: %d\r\n", iCameraBitrate);

    iLowBitSpeed  = iCameraBitrate - iCameraBitrate * 0.6;
    iHighBitSpeed = iCameraBitrate - iCameraBitrate * 0.8;
    iDifference = iKiloBitSpeed - iCameraBitrate;
    MOS_PRINTF("Difference: %d\r\n", iDifference);

    // 正常网络
    if (iDifference >= 0)
    {
        return EX_TRANS_NETWORK_NO_LATENCY;
    }
    // 较弱网络
    else if (-iHighBitSpeed < iDifference && iDifference < 0)
    {
        return EX_TRANS_NETWORK_LOW_LATENCY;

    }
    // 差网络
    else if (-iLowBitSpeed < iDifference && iDifference < -iHighBitSpeed)
    {
        return EX_TRANS_NETWORK_MID_LATENCY;

    }
    // 极差网络
    else if (iDifference <= -iLowBitSpeed)
    {
        return EX_TRANS_NETWORK_HIGH_LATENCY;
    }
    return -1;
}

_INT Cloudstg_ExTransNetHandle(ST_CLOUDSTG_TASK_INF *pstTask)
{
    MOS_PARAM_NULL_RETERR(pstTask);
    _INT iSentSpeed     = 0;
    _INT iNetworkStatus = 0;

    iSentSpeed     = CloudStg_TaskGetExSentSpeed(0, pstTask->iAliveTaskId, pstTask->uiIsPatch);
    iNetworkStatus = Cloudstg_ExTransNetCheck(pstTask, iSentSpeed * 8);

    switch (iNetworkStatus)
    {
        case EX_TRANS_NETWORK_NO_LATENCY:
        case EX_TRANS_NETWORK_LOW_LATENCY:
        break;
        case EX_TRANS_NETWORK_MID_LATENCY:
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Network is bad now, ready to drop two gop, alivetask: %u, speed: %dKB/s", pstTask->iAliveTaskId, iSentSpeed);
        }
        break;
        case EX_TRANS_NETWORK_HIGH_LATENCY:
        {
            MOS_LOG_ERR(CLOUDSTG_LOGSTR, "Network is extremely bad now, ready to close these stream, alivetask: %u, speed: %dKB/s", pstTask->iAliveTaskId, iSentSpeed);
        }
        break;
        default:
        break;
    }
    return MOS_OK;
}

ST_CLOUDSTG_BUF_NODE *CloudStg_TransFindBufNodeWithType(ST_MOS_LIST *pstBufList, _INT iType)
{
#if CLOUDSTG_UPLOAD_FORCE_STOP
    MOS_PARAM_NULL_NORET(pstBufList);
    // MOS_PARAM_NULL_NORET(pstClearEndNode);
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLOUDSTG_BUF_NODE *pstBufNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST_CONVERSE(pstBufList, pstBufNode, stIterator)
    {
        if (pstBufNode->enType == iType)
        {
            return pstBufNode;
        }
    }
#endif
    return MOS_NULL;
}

_INT CloudStg_TransSetForceStopTime(_HCSTASK hCSTask, _CTIME_T cForceStopTime)
{
#if CLOUDSTG_UPLOAD_FORCE_STOP
    MOS_PARAM_NULL_RETERR(hCSTask);
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;

    MOS_PRINTF("taskid: %u will stop at %u\r\n", pstTask->uiTaskID, cForceStopTime);
    pstTask->cForceStopTime = cForceStopTime;
#endif
    return MOS_OK;
}

_INT CloudStg_TransQualificationCheck(_HCSTASK hCSTask)
{
#if CLOUDSTG_UPLOAD_DELAY_SEND
    MOS_PARAM_NULL_RETERR(hCSTask);
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    _UI uiTotalCount = 0;

    Mos_MutexLock(&CloudStg_TransGetMgr()->hTaskMutex);
    uiTotalCount = CloudStg_TransGetMgr()->stTaskList.uiTotalCount;
    Mos_MutexUnLock(&CloudStg_TransGetMgr()->hTaskMutex);

    if (uiTotalCount > 1)
    {
        if (CloudStg_GetTaskNodeState(0, pstTask->ptUseHandle) < EN_CLOUDSTG_TASK_WAITING)
        {
            return MOS_ERR;
        }
        else
        {
            return MOS_OK;
        }
    }
#endif
    return MOS_OK;
}

_INT CloudStg_ExChanSetSentPosition(_HCSTASK hCSTask, _UI uiPostion)
{
    MOS_PARAM_NULL_RETERR(hCSTask);
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    Mos_MutexLock(&pstTask->hMutex);
    pstTask->uiPosition = uiPostion;
    Mos_MutexUnLock(&pstTask->hMutex);

    return MOS_OK;
}

_INT CloudStg_ExChanGetSentPosition(_HCSTASK hCSTask)
{
    MOS_PARAM_NULL_RETERR(hCSTask);
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    _UI uiPosition = 0;

    Mos_MutexLock(&pstTask->hMutex);
    uiPosition = pstTask->uiPosition;
    Mos_MutexUnLock(&pstTask->hMutex);
    return uiPosition;
}

_INT CloudStg_TransAllStampRefresh(_HCSTASK hCSTask, _UI uiTimeStamp)
{
    MOS_PARAM_NULL_RETERR(hCSTask);
    _UI uiTimeStampTmp = 0;
    ST_CLOUDSTG_TASK_INF *pstTask = (ST_CLOUDSTG_TASK_INF *)hCSTask;
    
    if (uiTimeStamp == 0)
    {
        return MOS_OK;
    }

    if(pstTask->uiLastStamp != 0)
    {
        if(uiTimeStamp > pstTask->uiLastStamp)
        {
            uiTimeStampTmp = uiTimeStamp - pstTask->uiLastStamp;
            // 不正常现象
            if (uiTimeStampTmp > 100000)
            {
                MOS_LOG_WARN(CLOUDSTG_LOGSTR,"catch wrong uiTimeStampTmp %u\r\n", uiTimeStampTmp);
            }
            pstTask->uiAllStamp += uiTimeStampTmp;
            // MOS_PRINTF("pstTask->uiAllStamp: %u\r\n", pstTask->uiAllStamp);
        }
    }
    pstTask->uiLastStamp = uiTimeStamp;

    return MOS_OK;
}
