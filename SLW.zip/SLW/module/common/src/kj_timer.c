/*
 * @Author: your name
 * @Date: 2020-10-21 23:27:23
 * @LastEditTime: 2020-10-22 02:09:39
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /yjDeviceSdk/sdk/base/source/kj_timer.c
 */
#include "kj_timer.h"

void kj_timer_init(struct kj_timer_t* timerTicket)
{ 
    timerTicket->m_tmlast.tv_sec = 0;
    timerTicket->m_tmstart.tv_sec = 0;
}

unsigned int getDiffTimems(struct kj_timer_t* timerTicket,  int renew, int is_seconds, 
                           int diff_invalid_second)
{
    struct timeval tm;
    unsigned int tmptm;

    if (!timerTicket->m_tmstart.tv_sec && !timerTicket->m_tmstart.tv_usec)
    {
        gettimeofday(&timerTicket->m_tmstart,NULL);
        timerTicket->m_tmlast = timerTicket->m_tmstart;
        return 0;
    }

    gettimeofday(&tm,NULL);
    if((tm.tv_sec < timerTicket->m_tmlast.tv_sec))
    {
        //设备当前时间比上次进入函数判断的时间小
        //printf("tims is ellagel!! %d %ul < %ul \n", __LINE__, tm.tv_sec, timerTicket->m_tmlast.tv_sec);
        timerTicket->m_tmstart = tm;
    }
    if (((tm.tv_sec -timerTicket->m_tmlast.tv_sec)>=diff_invalid_second))
    {
        //进入函数判断时间超过了设置的最大无效时间间隔(判断时间需要调用需要定时调用到)
        //printf("tims is ellagel!!%d, tv_sec>m_tmlast \n", __LINE__);
        timerTicket->m_tmstart = tm;
    }
    if ((tm.tv_sec < timerTicket->m_tmstart.tv_sec))
    {
        timerTicket->m_tmstart = tm;
    }

    timerTicket->m_tmlast = tm;
    
    if (is_seconds == ENUM_SECONDS_TYPE_MSECONDS)
    {
        tmptm = (tm.tv_sec-timerTicket->m_tmstart.tv_sec)*1000+(tm.tv_usec-timerTicket->m_tmstart.tv_usec)/1000;
    }          
    else if(is_seconds == ENUM_SECONDS_TYPE_SECONDS)
    {
        tmptm = (tm.tv_sec-timerTicket->m_tmstart.tv_sec); 
    }
    else if(is_seconds == ENUM_SECONDS_TYPE_USECONDS)
    {
        tmptm = (tm.tv_sec-timerTicket->m_tmstart.tv_sec)*1000*1000+(tm.tv_usec-timerTicket->m_tmstart.tv_usec);
    }
        

    if(renew)
    {
        timerTicket->m_tmstart = tm;
        timerTicket->m_tmlast = timerTicket->m_tmstart;
    }

    return tmptm;
}
  
unsigned int getDiffTimems1(struct kj_timer_t* timerTicket, int renew, int is_seconds, int diff_second)
{
    struct timeval tm;
    unsigned int tmptm;

    if (!timerTicket->m_tmstart.tv_sec && !timerTicket->m_tmstart.tv_usec)
    {
        gettimeofday(&timerTicket->m_tmstart,NULL);
        timerTicket->m_tmlast = timerTicket->m_tmstart;
        return 0;
    }

    gettimeofday(&tm,NULL);
    if((tm.tv_sec < timerTicket->m_tmlast.tv_sec) || ((tm.tv_sec -timerTicket->m_tmlast.tv_sec)>=60)
            || ((tm.tv_sec < timerTicket->m_tmstart.tv_sec)))
    {
        printf("tims is ellagel!!\n");
        timerTicket->m_tmstart = tm;
    }

    timerTicket->m_tmstart.tv_sec +=diff_second;
    timerTicket->m_tmlast = tm;
    if (is_seconds == ENUM_SECONDS_TYPE_MSECONDS)
    {
        tmptm = (tm.tv_sec-timerTicket->m_tmstart.tv_sec)*1000+(tm.tv_usec-timerTicket->m_tmstart.tv_usec)/1000;
    }
    else if (is_seconds == ENUM_SECONDS_TYPE_SECONDS)
    {
        tmptm = (tm.tv_sec-timerTicket->m_tmstart.tv_sec); 
    }
    else if(is_seconds == ENUM_SECONDS_TYPE_USECONDS)
    {
        tmptm = (tm.tv_sec-timerTicket->m_tmstart.tv_sec)*1000*1000+(tm.tv_usec-timerTicket->m_tmstart.tv_usec);
    }

    if(renew)
    {
        timerTicket->m_tmstart = tm;
        timerTicket->m_tmlast = timerTicket->m_tmstart;
    }

    return tmptm;
}
