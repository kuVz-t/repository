#ifndef KJ_MUTEX_H
#define KJ_MUTEX_H
#include "mos.h"



class KjMutexLock
{
 public:
  KjMutexLock()
    : holder_(0)
  {
    int ret = Mos_MutexCreate(&m_mutex_);
  }

  ~KjMutexLock()
  {
      Mos_MutexDelete(&m_mutex_);
  }

  bool isLockedByThisThread()
  {
    return holder_ == Mos_ThreadGetCurId();
  }

  void assertLocked()
  {
    // (isLockedByThisThread());
  }

  // internal usage

  static int getFileEixst(const char *file_name)
  {
      return (access(file_name, F_OK) == 0)?0:-1;
  }

  void lock()
  {
    Mos_MutexLock(&m_mutex_);
    holder_ = Mos_ThreadGetCurId();
  }

  void unlock()
  {
    holder_ = 0;
    Mos_MutexUnLock(&m_mutex_);
  }

  _HMUTEX* getPthreadMutex() /* non-const */
  {
    return &m_mutex_;
  }

 private:
  _HMUTEX  m_mutex_;
  _UI      holder_;
};

class KjMutexLockGuard
{
 public:
  explicit KjMutexLockGuard(KjMutexLock& mutex)
    : mutex_(mutex)
  {
    mutex_.lock();
  }

  ~KjMutexLockGuard()
  {
    mutex_.unlock();
  }

 private:
  KjMutexLock& mutex_;
};

#include "rwlocker.h"

class KjRwMutexLock
{
 public:
  KjRwMutexLock()
    : holder_(0)
  {
    int ret = rwlocker_create(&m_mutex_);
  }

  ~KjRwMutexLock()
  {
      rwlocker_destroy(&m_mutex_);
  }

  bool isLockedByThisThread()
  {
    return holder_ == Mos_ThreadGetCurId();
  }

  void assertLocked()
  {
    // (isLockedByThisThread());
  }

  void rdLock()
  {
      //MOS_PRINTF("%s\n", __FUNCTION__);
    rwlocker_rdlock(&m_mutex_);
    holder_ = Mos_ThreadGetCurId();
  }

  void wrLock()
  {
      //MOS_PRINTF("%s\n", __FUNCTION__);
    rwlocker_wrlock(&m_mutex_);
    holder_ = Mos_ThreadGetCurId();
  }

  void unlock()
  {
    holder_ = 0;
    //MOS_PRINTF("%s\n", __FUNCTION__);
    pthread_rwlock_unlock(&m_mutex_);
  }

  rwlocker_t* getPthreadMutex() /* non-const */
  {
    return &m_mutex_;
  }

 private:
  rwlocker_t m_mutex_;
  _UI        holder_;
};


class KjRwMutexLockGuard
{
 public:
  explicit KjRwMutexLockGuard(KjRwMutexLock& mutex, bool isWriteLock=0, int iNoLock=0)
    : mutex_(mutex),iNoNeedLockFlag(0)
  {
        isWriteLock_    = isWriteLock;
        iNoNeedLockFlag = iNoLock;
        if (iNoNeedLockFlag == 0)
        {
          if (isWriteLock)
          {
              mutex_.wrLock();
          }
          else
          {
            mutex_.rdLock();
          }
        }
  }

  ~KjRwMutexLockGuard()
  {
    if (iNoNeedLockFlag == 0)
    {
      mutex_.unlock();
    }
  }

 private:
  KjRwMutexLock& mutex_;
  int            isWriteLock_;
  int            iNoNeedLockFlag;
};

#endif // KJ_MUTEX_H
