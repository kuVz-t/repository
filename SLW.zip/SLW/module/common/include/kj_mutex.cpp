#include "kj_mutex.h"


KjMutex::KjMutex()
{

}
