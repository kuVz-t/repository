/*
 * @Author: hejh
 * @Date: 2020-10-21 19:08:42
 * @LastEditTime: 2020-10-22 02:06:37
 * @LastEditors: Please set LastEditors
 * @Description: In User Timer count
 */
#ifndef KJ_TIME_H
#define KJ_TIME_H
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#ifdef __cplusplus
extern "C" {
#endif


typedef enum  ENUM_SECONDS_TYPE
{
    ENUM_SECONDS_TYPE_MSECONDS = 0,
    ENUM_SECONDS_TYPE_SECONDS  = 1,
    ENUM_SECONDS_TYPE_USECONDS = 2
}EN_SECONDS_TYPE ;

typedef struct kj_timer_t
{
	struct timeval m_tmstart ;
    struct timeval m_tmlast ;    
}kj_timer_t;

void kj_timer_init(struct kj_timer_t* timerTicket);
unsigned int getDiffTimems(struct kj_timer_t* timerTicket, int renew, int is_second, int diff_invalid_second);
unsigned int getDiffTimems1(struct kj_timer_t* timerTicket,int renew, int is_seconds, int add_second);
 
#ifdef __cplusplus
}
#endif
#endif // KJ_TIME_H
