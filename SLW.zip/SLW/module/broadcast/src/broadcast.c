#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "broadcast_api.h"
#include "http_api.h"
#include "http.h"
#include "adpt_json_adapt.h"
#include "msgmng_api.h"
#include "msgmng_cmdserver.h"
#include "AudioDeviceAPI.h"
#include "kj_timer.h"
#include "watchdog_api.h"

#include "adpt_ssl_adapt.h"
#include "cloudstg_logcode.h"

#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

#define BC_MAX 32635  

#define HTTPS_TIMEOUT       5

#define HTTPS_DEFAULT_PORT  443

#define HTTPS_BUFFER_SIZE   1024

//http header 需要添加"Connection: Close\r\n"强制关闭keep-alive
#define HTTPS_POST "POST /%s HTTP/1.1\r\nHOST: %s:%d\r\nAccept: */*\r\n"\
    "Content-Type: application/json\r\nConnection: Close\r\nContent-Length: %d\r\n"

#define HTTPS_GET "GET %s HTTP/1.1\r\nHOST: %s:%d\r\nAccept: */*\r\nConnection: Close\r\n"

//static _HSWDWRITE    g_hSwdBroadcastFeedDog;
//static kj_timer_t    g_tBroadcastFeedDogTimeOut;
typedef void * HTTPS_GETEX_HANLE;
static ST_BROADCAST_MNG g_Broadcast_TaskMng;

short test_seg_aend[8] = {0x1F, 0x3F, 0x7F, 0xFF, 0x1FF, 0x3FF, 0x7FF, 0xFFF};
short test_seg_uend[8] = {0x3F, 0x7F, 0xFF, 0x1FF,0x3FF, 0x7FF, 0xFFF, 0x1FFF};

ST_BROADCAST_MNG *Broadcast_GetTaskMng()
{
    return &g_Broadcast_TaskMng;
}

_INT  Broadcast_Https_GetEx_ReadData(HTTPS_GETEX_HANLE hHttpsGetEx, _UC *pucBuf, _INT iLen)
{
    _INT iOutLen = 0;
    if(Adpt_SSL_Read(hHttpsGetEx, (_UC *)pucBuf, iLen, &iOutLen) == ITRD_ERR)
    {
        return MOS_ERR;
    }
    else
    {
        return iOutLen;
    }
}
//parse url
_INT Broadcast_ParseUrl(_UC *pucInUrl, _UC *pucOutHost, short *pusOutPort,  _UC *pucOutSubUri,_UI *uiHttpType)
{
    _INT iLen = 0;
    _INT iTmp = 0;
    _UC *pucSeparator = MOS_NULL;
    _UC *pucColon = MOS_NULL;
    _UC *pucURL = pucInUrl;
    if (0 == MOS_STRNCMPNOCASE(pucURL, (_UC *)"https://", MOS_STRLEN("https://")))
    {
        *uiHttpType = 1;
        pucURL += MOS_STRLEN("https://");
    }
    else if (0 == MOS_STRNCMPNOCASE(pucURL,(_UC *)"http://", MOS_STRLEN("http://")))
    {
        *uiHttpType = 0;
        pucURL += MOS_STRLEN("http://");
    }

    pucColon = MOS_STRSTR(pucURL, ":");
    if (MOS_NULL == pucColon)
    {
        if(*uiHttpType == 1){
            *pusOutPort = 443;
        }
        else if(*uiHttpType == 0){
            *pusOutPort = 80;
        }
    }
    else
    {
        *pusOutPort = (short)MOS_ATOI(pucColon + 1);
    }

    pucSeparator = MOS_STRSTR(pucURL, "/");
    if (pucSeparator)
    {
        iLen = SAFE_INT(pucSeparator - pucURL);
    }

    if (pucColon)
    {
        iLen = SAFE_INT(pucColon - pucURL);
    }

    if (iLen <= 0 || iLen >= 512)
    {
        return MOS_ERR;
    }
    MOS_MEMCPY(pucOutHost,pucURL,iLen);
    pucOutHost[iLen] = 0;
    if (pucSeparator && pucOutSubUri)
    {
        iLen = MOS_STRLEN(pucSeparator);
        if ((iLen <= 0 ) || (iLen >= HTTPS_BUFFER_SIZE))
        {
            return MOS_ERR;
        }
        MOS_MEMCPY(pucOutSubUri,pucSeparator,iLen);
        pucOutSubUri[iLen] = 0;
        iTmp = iLen - 1;
        if (iTmp >= 0  && '/' == pucOutSubUri[iTmp])
        {
            pucOutSubUri[iTmp] = 0;
        }
    }
    return MOS_OK;
}


_SOCKET Broadcast_ConnectServer(_UC *pucHost, _INT iPort)
{
    _SOCKET hSocket = MOS_SOCKET_INVALID;
    hSocket = Http_CreateSocketBlockAndConnect2(pucHost, iPort, 10, HTTPS_TIMEOUT, HTTPS_TIMEOUT, MOS_FALSE, MOS_NULL, MOS_NULL);
    if (hSocket != MOS_SOCKET_INVALID)
    {
        // 手动设置云广播socket发送buf
        if (Mos_SocketSetSendBuf(hSocket, HTTP_SOCKET_BUFFER_SIZE) != MOS_OK)
        {
            MOS_LOG_ERR(BROADCAST_LOGSTR, "Mos_SocketSetSendBuf failed");
            Mos_SocketClose(hSocket);
            hSocket = MOS_SOCKET_INVALID;
        }
    }
    return hSocket;
}

static _INT Broadcast_SendReqMsgHttp(_SOCKET hSocket,_UC *aucHostAddr, _UC *pucSendBuf,_UI uiBuffLen)
{
    _UI uiTotalSend = 0;
    _INT iSendLen   = 0;
    _BOOL bOutWait;
    
    while (uiTotalSend < uiBuffLen) 
    {
        iSendLen =  Mos_SocketSend(hSocket,(pucSendBuf + uiTotalSend), uiBuffLen - uiTotalSend, &bOutWait);
        if (iSendLen <= 0) 
        {
            MOS_LOG_ERR(BROADCAST_LOGSTR, "send %s error %d,sendLen %d",pucSendBuf,Mos_SocketGetLastErr(),iSendLen);
            return MOS_ERR;
        }
        uiTotalSend += iSendLen;
    }

    MOS_LOG_INF(BROADCAST_LOGSTR,"Send header %s to server success",pucSendBuf);
    
    return MOS_OK;
}

static _INT Broadcast_SendReqMsgHttps(_SSL_HANDLE *phSSL,_SOCKET hSocket,_UC *aucHostAddr, _UC *pucSendBuf,_UI uiBuffLen)
{
    _UI  uiTotalSend     = 0;
    _UI  uiSendLen       = 0;
    
    if (Adpt_SSL_Create(hSocket, phSSL) == ITRD_ERR)
    {        
        MOS_LOG_ERR(BROADCAST_LOGSTR,"Adpt_SSL_Create error");
        return MOS_ERR;
    }
    
    if (Adpt_SSL_SetClientMode(*phSSL, ITRD_TRUE) == ITRD_ERR)
    {
        MOS_LOG_ERR(BROADCAST_LOGSTR,"Adpt_SSL_SetClientMode error");
        return MOS_ERR;
    }

    if (Adpt_SSL_Connect(*phSSL, (_UC*)aucHostAddr) == ITRD_ERR)
    {        
        MOS_LOG_ERR(BROADCAST_LOGSTR,"Adpt_SSL_Connect error");
        return MOS_ERR;
    }

    while (uiTotalSend < uiBuffLen) 
    {
        if(Adpt_SSL_Write(*phSSL,(pucSendBuf + uiTotalSend), uiBuffLen - uiTotalSend, (_INT*)&uiSendLen) != ITRD_OK) 
        {
            MOS_LOG_ERR(BROADCAST_LOGSTR, "send ssl %s error",pucSendBuf);        
            return MOS_ERR;
        }
        uiTotalSend += uiSendLen;
    }

    MOS_LOG_INF(BROADCAST_LOGSTR,"Send header %s to server success",pucSendBuf);
    
    return MOS_OK;
}

_INT Broadcast_HttpsParseHeader(_SSL_HANDLE hSSL, _INT *piResultCode, _INT *piContentLength, _UC *pucRedirectUrl)
{
    _UC aucBuffer[1]    = {0};
    _UC aucTemp[BUFSIZ] = {0};
    _UC *pucPtr         = MOS_NULL;
    _UC *pucPtrTmp      = MOS_NULL;
    _INT iLen           = 0;
    _INT n              = 0;
    _CTIME_T tBeginTime = 0;

    if (!hSSL || !piResultCode || !piContentLength)
    {
        return MOS_ERR;
    }

    *piResultCode    = 0;
    *piContentLength = 0;

    tBeginTime = Mos_Time();

    while (Adpt_SSL_Read(hSSL, (_UC *)aucBuffer, 1, &iLen) == ITRD_OK)
    {
        aucTemp[n] = *aucBuffer;
        if (*aucBuffer == '\n')
        {
            pucPtr = MOS_STRSTR(aucTemp,"HTTP/1.1");
            if (pucPtr != NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,' ');
                pucPtr++;
                *piResultCode = MOS_ATOI(pucPtr);
            }
            pucPtr = MOS_STRSTR(aucTemp,"Content-Length:");
            if (pucPtr != NULL)
            {
                // 如果是keep alive，则content-length和chunk必然是二选一
                // 若是非keep alive，则和http1.0一样。content-length可有可无
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                *piContentLength = MOS_STRTOL(pucPtr, 10);
            }
            pucPtr = MOS_STRSTR(aucTemp,"Location:");
            if (pucPtr != NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                pucPtrTmp = MOS_STRCHR(pucPtr,'\r');
                iLen = pucPtrTmp - pucPtr;
                if (pucRedirectUrl)
                {
                    MOS_STRNCPY(pucRedirectUrl, pucPtr+1, iLen-1);
                    // MOS_PRINTF("pucRedirectUrl:%s \r\n",pucRedirectUrl);
                }
            }

            MOS_PRINTF("%s",aucTemp);
            //"\r\n"后接着"\r\n"
            if (aucTemp[0] == '\r' && aucTemp[1] == '\n')
            {
                return MOS_OK;
            }
            MOS_MEMSET(aucTemp, 0, sizeof(aucTemp));
            n = -1;
        }
        n++;

        if ((tBeginTime+HTTPS_TIMEOUT) < Mos_Time())
        {
            MOS_PRINTF("%s timeout error\n", __FUNCTION__);
            return MOS_ERR;
        }
    }
    MOS_PRINTF("%s recv error\n", __FUNCTION__);
    return MOS_ERR;//接收数据失败
}

_INT Broadcast_HttpParseHeader(_SOCKET hSocket,_INT *piResultCode, _INT *piContentLength, _UC *pucRedirectUrl)
{
    _UC aucBuffer[1]    = {0};
    _UC aucTemp[BUFSIZ] = {0};
    _UC *pucPtr         = MOS_NULL;
    _UC *pucPtrTmp      = MOS_NULL;
    _INT iLen           = 0;    
    _INT iTmp             = 0;
    _INT n              = 0;
    _INT iRet           = 0;
    _CTIME_T tBeginTime = 0;
    _INT iReRecvCount   = 0;

    if (!piResultCode || !piContentLength)
    {
        return MOS_ERR;
    }

    *piResultCode    = 0;
    *piContentLength = 0;

    tBeginTime = Mos_Time();

    while (1)
    {
        iRet = Mos_SocketRecv(hSocket, (_UC *)aucBuffer, 1, &iTmp);
        //返回值为0表明断连，iTmp等于ture表示需要断开socket
        if ((iRet == 0) || (iTmp == MOS_TRUE))
        {
            MOS_LOG_ERR(BROADCAST_LOGSTR, "Mos_SocketRecv error iRet[%d]  iTmp[%d]", iRet, iTmp);
            break;
        }
        else if (iRet < 0)//返回值为负数，且iTmp不为MOS_TRUE，表明需要重试
        {
            iReRecvCount++;
            if (iReRecvCount > 10)//连续重试10次都失败，则断开socket
            {
                MOS_LOG_ERR(BROADCAST_LOGSTR, "recv data len: %d, err=%u ,ErrCount=%d",iRet, Mos_SocketGetLastErr(),iReRecvCount);
                break;
            }

            Mos_Sleep(10);
            continue;
        }

        iReRecvCount = 0;

        aucTemp[n] = *aucBuffer;
        if (*aucBuffer == '\n')
        {
            pucPtr = MOS_STRSTR(aucTemp,"HTTP/1.1");
            if (pucPtr != NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,' ');
                pucPtr++;
                *piResultCode = MOS_ATOI(pucPtr);
            }
            pucPtr = MOS_STRSTR(aucTemp,"Content-Length:");
            if (pucPtr != NULL)
            {
                // 如果是keep alive，则content-length和chunk必然是二选一
                // 若是非keep alive，则和http1.0一样。content-length可有可无
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                *piContentLength = MOS_STRTOL(pucPtr, 10);
            }
            pucPtr = MOS_STRSTR(aucTemp,"Location:");
            if (pucPtr != NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                pucPtrTmp = MOS_STRCHR(pucPtr,'\r');
                iLen = pucPtrTmp - pucPtr;
                if (pucRedirectUrl)
                {
                    MOS_STRNCPY(pucRedirectUrl, pucPtr+1, iLen-1);
                    // MOS_PRINTF("pucRedirectUrl:%s \r\n",pucRedirectUrl);
                }
            }

            MOS_PRINTF("%s",aucTemp);
            //"\r\n"后接着"\r\n"
            if (aucTemp[0] == '\r' && aucTemp[1] == '\n')
            {
                return MOS_OK;
            }
            MOS_MEMSET(aucTemp, 0, sizeof(aucTemp));
            n = -1;
        }
        n++;

        if ((tBeginTime+HTTPS_TIMEOUT) < Mos_Time())
        {
            MOS_PRINTF("%s timeout error\n", __FUNCTION__);
            return MOS_ERR;
        }
    }
    MOS_PRINTF("%s recv error\n", __FUNCTION__);
    return MOS_ERR;//接收数据失败
}

int Broadcast_HttpsGet_Cb(const char * url, void *data, int dataLen)
{
    if (Broadcast_GetTaskMng()->stState >= BROADCAST_STATE_LIVE)
    {
        return MOS_ERR;
    }

    _INT iRet                  = MOS_ERR;
    _SSL_HANDLE hSSL          = 0;
    _SOCKET hSocket              = MOS_SOCKET_INVALID;
    short usPort                          = 0;
    _UI uiHttpType                          = 0;
    _UC aucRequest[HTTPS_BUFFER_SIZE*2]  = {'\0'};
    _UC aucHostAddr[HTTPS_BUFFER_SIZE]   = {'\0'};
    _UC aucSubUrl[HTTPS_BUFFER_SIZE]     = {'\0'};

    iRet = Broadcast_ParseUrl(url,aucHostAddr,&usPort,aucSubUrl,&uiHttpType);
    if (iRet != MOS_OK)
    {                             
        MOS_LOG_ERR(BROADCAST_LOGSTR, "failed to parse url");        
        return iRet;
    }
     
    hSocket = Broadcast_ConnectServer(aucHostAddr,usPort);
    if (hSocket == MOS_SOCKET_INVALID)
    {        
        MOS_LOG_ERR(BROADCAST_LOGSTR, "failed to connect server");
        return MOS_ERR;
    }     

    MOS_SPRINTF(aucRequest, HTTPS_GET, aucSubUrl, aucHostAddr, usPort);
    MOS_STRCAT(aucRequest, "\r\n");    

    if (uiHttpType == 0)
    {
        iRet = Broadcast_SendReqMsgHttp(hSocket,aucHostAddr,aucRequest,MOS_STRLEN(aucRequest));
        if (iRet == MOS_OK)
        {
            // 接收头
            _INT iResultCode          = 0;
            _INT uiContentLen         = 0;
            _INT iReadLen             = 0; 
            _INT iRecvLen             = 0;
            _INT iTmp                 = 0;
            _INT iReRecvCount         = 0;

            Broadcast_HttpParseHeader(hSocket, &iResultCode, &uiContentLen, MOS_NULL);
            if (iResultCode != 200)
            {
                MOS_LOG_ERR(BROADCAST_LOGSTR, "Https_Parse_Header error iResultCode = %d",iResultCode);
                Mos_SocketClose(hSocket);
                
                return MOS_ERR;
            }

            MOS_LOG_INF(BROADCAST_LOGSTR, "download uiContentLen = %u",uiContentLen);

            uiContentLen = uiContentLen > dataLen ? dataLen : uiContentLen;

            while (iRecvLen < uiContentLen)
            {
                iReadLen = Mos_SocketRecv(hSocket, data + iRecvLen, uiContentLen - iRecvLen, &iTmp);
                //返回值为0表明断连，iTmp等于ture表示需要断开socket
                if ((iReadLen == 0) || (iTmp == MOS_TRUE))
                {                    
                    MOS_LOG_ERR(BROADCAST_LOGSTR, "recv data len: %d, err=%u",iReadLen, Mos_SocketGetLastErr());
                    break;
                }
                else if (iReadLen < 0)//返回值为负数，且iTmp不为MOS_TRUE，表明需要重试
                {
                    iReRecvCount++;
                    if (iReRecvCount > 10)//连续重试10次都失败，则断开socket
                    {
                        MOS_LOG_ERR(BROADCAST_LOGSTR, "recv data len: %d, err=%u ,ErrCount=%d",iReadLen, Mos_SocketGetLastErr(),iReRecvCount);
                        break;
                    }

                    Mos_Sleep(10);
                    continue;
                }

                iReRecvCount = 0;

                iRecvLen += iReadLen;
            }    
        }

        Mos_SocketClose(hSocket);
    }
    else if (uiHttpType == 1)
    {
        iRet = Broadcast_SendReqMsgHttps(&hSSL,hSocket,aucHostAddr,aucRequest,MOS_STRLEN(aucRequest));
        if (iRet == MOS_OK)
        {
            // 接收头
            _INT iResultCode         = 0;
            _INT uiContentLen         = 0;
            _UI  iReadLen             = 0; 
            _INT iRecvLen             = 0;        
            
            Broadcast_HttpsParseHeader(hSSL, &iResultCode, &uiContentLen, MOS_NULL);
            if (iResultCode != 200 || uiContentLen <=  0)
            {
                MOS_LOG_ERR(BROADCAST_LOGSTR, "Https_Parse_Header error iResultCode = %d",iResultCode);                
                // Mos_SocketClose(hSocket);
                Adpt_SSL_Destroy(hSSL);
                
                return MOS_ERR;
            }

            MOS_LOG_INF(BROADCAST_LOGSTR, "download uiContentLen = %u",uiContentLen);
            uiContentLen = uiContentLen > dataLen ? dataLen : uiContentLen;
                    
            while (iRecvLen < uiContentLen)
            {
                iReadLen = Broadcast_Https_GetEx_ReadData(hSSL, data + iRecvLen, uiContentLen - iRecvLen);
                if (0 >= iReadLen)
                {                    
                    MOS_LOG_ERR(BROADCAST_LOGSTR, "recv data len: %d, err=%u",iReadLen, Mos_SocketGetLastErr());
                    break;
                }
                iRecvLen += iReadLen;
            }

        }

        MOS_LOG_INF(BROADCAST_LOGSTR, "recv data = %s",data);
        
        // Mos_SocketClose(hSocket);

        Adpt_SSL_Destroy(hSSL);
    }

    return MOS_OK;
}

//**************************************************************************************
// Description: 厂商注册给sdk使用的回调接口
//                用于执行https get请求下载（需要支持断点续传）音频文件，并返回下载的字节数
// Parameter:    
//                url: 请求url，要兼容http和https请求
//                connTimeout：建链超时时间，单位：秒
//                recvSpeed: http请求速度限制，0-不限速；>0：接收限速，单位：字节/秒
//                httpBuffSize：设置为http请求的接收缓冲区尺寸
//                write_data_func: http请求响应数据处理的回调接口指针
//                stream：write_data_func回调函数中使用的回调指针
// Returns:     -1：http请求失败；>=0：http请求成功，数值为服务端响应的body字节数
//***************************************************************************************]
int Broadcast_HttpsDownload_Cb(const char * url, int connTimeout, int recvSpeed, int httpBuffSize, cb_audiocloud_https_writefunc write_data_func, void *stream, int mediaDuration)
{
    _INT iRet                  = MOS_ERR;    
    _INT iRetValue             = MOS_OK;
    _SSL_HANDLE hSSL           = 0;
    _SOCKET hSocket            = MOS_SOCKET_INVALID;
    short usPort               = 0;
    _UI uiHttpType             = 0;
    _INT uiContentLen          = 0;
    _UC aucRequest[HTTPS_BUFFER_SIZE*2]  = {'\0'};
    _UC aucHostAddr[HTTPS_BUFFER_SIZE]   = {'\0'};
    _UC aucSubUrl[HTTPS_BUFFER_SIZE]     = {'\0'};
    
    _INT uisleeptime = 10; 
    if(recvSpeed > 0)
    {
        uisleeptime = 1000.00/((float)recvSpeed/(float)httpBuffSize);
    }
    
    MOS_LOG_INF(BROADCAST_LOGSTR, "recvSpeed = %d  httpBuffSize = %d  uisleeptime = %d",recvSpeed,httpBuffSize,uisleeptime);

    iRet = Broadcast_ParseUrl(url,aucHostAddr,&usPort,aucSubUrl,&uiHttpType);
    if (iRet != MOS_OK)
    {                             
        MOS_LOG_ERR(BROADCAST_LOGSTR, "failed to parse uri");        
        return MOS_ERR;
    }
     
    hSocket = Broadcast_ConnectServer(aucHostAddr,usPort);
    if (hSocket == MOS_SOCKET_INVALID)
    {            
        MOS_LOG_ERR(BROADCAST_LOGSTR, "failed to connect server");        
        return MOS_ERR;
    }     

    MOS_SPRINTF(aucRequest, HTTPS_GET, aucSubUrl, aucHostAddr, usPort);
    MOS_STRCAT(aucRequest, "\r\n");
    
    if (uiHttpType == 0)
    {
        iRet = Broadcast_SendReqMsgHttp(hSocket,aucHostAddr,aucRequest,MOS_STRLEN(aucRequest));
        if (iRet == MOS_OK)
        {
            // 接收头
            _INT iResultCode           = 0;
            _INT iResponseSize         = 1280;
            _UC  aucResponse[1280]     = {0};
            _INT iReadLen              = 0; 
            _INT iRecvLen              = 0;            
            _INT iTmp                  = 0;
            
            Broadcast_HttpParseHeader(hSocket, &iResultCode, &uiContentLen, MOS_NULL);
            if (iResultCode != 200)
            {
                MOS_LOG_INF(BROADCAST_LOGSTR, "Https_Parse_Header error iResultCode = %d",iResultCode);
                Mos_SocketClose(hSocket);
                
                return MOS_ERR;
            }
            MOS_LOG_INF(BROADCAST_LOGSTR, "download uiContentLen = %d",uiContentLen);
            
            _INT iReRecvCount = 0;
            while (iRecvLen < uiContentLen)
            {            
                iReadLen = Mos_SocketRecv(hSocket, aucResponse,iResponseSize, &iTmp);                
                //返回值为0表明断连，iTmp等于ture表示需要断开socket              
                if ((iReadLen == 0)  ||  (iTmp == MOS_TRUE))
                {
                    MOS_LOG_ERR(BROADCAST_LOGSTR, "recv data len: %d, err=%u",iReadLen, Mos_SocketGetLastErr());
                    iRetValue = MOS_ERR;
                    break;
                }
                else if (iReadLen < 0)//返回值为负数，且iTmp不为MOS_TRUE，表明需要重试
                {
                    iReRecvCount++;
                    if (iReRecvCount > 10)//连续重试10次都失败，则断开socket
                    {
                        MOS_LOG_ERR(BROADCAST_LOGSTR, "recv data len: %d, err=%u ,ErrCount=%d",iReadLen, Mos_SocketGetLastErr(),iReRecvCount);
                        iRetValue = MOS_ERR;
                        break;
                    }

                    Mos_Sleep(10);
                    continue;
                }

                iReRecvCount = 0;
                
                if (write_data_func)
                {
                    iRet = write_data_func((void *)aucResponse,iReadLen,1,stream);
                    if (iRet <= 0)
                    {
                        iRetValue = MOS_ERR;
                        break;    
                    }
                }                
                
                iRecvLen += iReadLen;

                if (Broadcast_GetTaskMng()->stState != BROADCAST_STATE_PLAYBACK)
                {
                    //MOS_PRINTF("%s:%d use the speed for %d\n", __FUNCTION__, __LINE__,Broadcast_GetTaskMng()->stState);
                    Mos_Sleep(uisleeptime);
                }
                else
                {
                    Mos_Sleep(10);
                }
                
            }            
        }

        Mos_SocketClose(hSocket);
    }
    else if (uiHttpType == 1)
    {
        iRet = Broadcast_SendReqMsgHttps(&hSSL,hSocket,aucHostAddr,aucRequest,MOS_STRLEN(aucRequest));
        if (iRet == MOS_OK)
        {
            // 接收头
            _INT iResultCode           = 0;
            _INT iResponseSize         = 1280;
            _UC  aucResponse[1280]     = {0};
            _INT iReadLen              = 0; 
            _INT iRecvLen              = 0;
            
            Broadcast_HttpsParseHeader(hSSL, &iResultCode, &uiContentLen, MOS_NULL);
            if (iResultCode != 200)
            {
                MOS_LOG_INF(BROADCAST_LOGSTR, "Https_Parse_Header error iResultCode = %d",iResultCode);
                
                // Mos_SocketClose(hSocket);

                Adpt_SSL_Destroy(hSSL);
                
                return MOS_ERR;
            }

            MOS_LOG_INF(BROADCAST_LOGSTR, "download uiContentLen = %d",uiContentLen);
            
            while (iRecvLen < uiContentLen)
            {
                iReadLen = Broadcast_Https_GetEx_ReadData(hSSL, aucResponse, iResponseSize);
                if (iReadLen <= 0) 
                {                    
                    MOS_LOG_ERR(BROADCAST_LOGSTR, "recv data len: %d, err=%u",iReadLen, Mos_SocketGetLastErr());
                    iRetValue = MOS_ERR;
                    break;
                }

                if (write_data_func)
                {
                    iRet = write_data_func((void *)aucResponse, iReadLen,1,MOS_NULL);
                    if (iRet <= 0)
                    {
                        iRetValue = -1;
                        break;    
                    }
                }
                
                iRecvLen += iReadLen;
                
                if (Broadcast_GetTaskMng()->stState != BROADCAST_STATE_PLAYBACK)
                {
                    //MOS_PRINTF("%s:%d use the speed for %d\n", __FUNCTION__, __LINE__,Broadcast_GetTaskMng()->stState);
                    Mos_Sleep(uisleeptime);
                }
                else
                {
                    Mos_Sleep(10);
                }        
            }
        }

        // Mos_SocketClose(hSocket);

        Adpt_SSL_Destroy(hSSL);
    }
    
    return iRetValue;
}


int Broadcast_LivePlaybackState_Cb(LIVE_PLAYBACK_STATE session_state, _C* session_id, _ULLID user_data)
{
    if (session_id == MOS_NULL)
    {
        MOS_LOG_INF(BROADCAST_LOGSTR, "invalid param");
        return MOS_ERR;
    }
    
    MOS_LOG_INF(BROADCAST_LOGSTR, "session_state: %d, session_id: %s, cur_status: %d",session_state, session_id, Broadcast_GetTaskMng()->stState);

    // _UC aucMsgString[128] = {0}; 
    // MOS_SPRINTF(aucMsgString, "%s recv[%d %s], cur_status[%d]", BROADCAST_ID_LOG_STR, session_state,session_id, Broadcast_GetTaskMng()->stState);
    // CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_RECV_STATUS, aucMsgString, 1);

    if (LIVE_STATE_CONNECT_SUCCESS == session_state || LIVE_STATE_RECONNECTTED == session_state || PLAYBACK_ACTION_START_PLAY == session_state || LIVE_STATE_ACTION_RESUME_PLAY == session_state)
    {    
        if (Broadcast_GetTaskMng()->stState < BROADCAST_STATE_ALRAM)
        {            
            Media_AudioPlayCancelFrameBuff(Broadcast_GetTaskMng()->hAudioPlay);
        }

        Mos_MutexLock(&Broadcast_GetTaskMng()->hMutexStatus);
        if (Config_GetCamaraMng()->uiSpkOpenFlag == MOS_FALSE && Broadcast_GetTaskMng()->stState == BROADCAST_STATE_CLOSED)
        {    
            //Config_SetCamerSpkOpenFlag(0, MOS_TRUE);
                
            ST_ZJ_AUDIO_PARAM audioParams = {0};
            audioParams.uiEncodeType = EN_ZJ_AUDIOENC_TYPE_G711A;
            audioParams.uiSampleRate = 8000;
            audioParams.uiChannel = 1;
            audioParams.uiDepth = 16;            
            
            Broadcast_GetTaskMng()->hAudioPlay = Media_AudioPlayCreatWriteHandle("Broadcast", 0, &audioParams);
            Media_Notify_AudioPlay("Broadcast", 1, 1, 0);
            
            MOS_LOG_INF(BROADCAST_LOGSTR, "Opening audio reverse");

            _HFILE *hFile = MOS_NULL;
            _UC aucFile[256] = {0};
            MOS_MEMSET(aucFile, 0, sizeof(aucFile));
            MOS_VSNPRINTF(aucFile,256,"%s/broadcast.g711a",Config_GetCoreMng()->aucSoudFilePath);

            if (Mos_FileIsExist(aucFile) == MOS_TRUE)
            {
                hFile = Mos_FileOpen(aucFile, MOS_FILE_O_RDONLY | MOS_FILE_O_BIN);
                if (hFile != MOS_NULL)
                {
                    _UC pucAudioBuf[320] = {0};
                    _INT iRet = 0;
                    while (!Mos_FileEof(hFile))
                    {
                        iRet = Mos_FileRead(hFile,pucAudioBuf,320);
                        if (iRet > 0)
                        {
                                Media_AudioPlayWriteFrame2(Broadcast_GetTaskMng()->hAudioPlay, pucAudioBuf,iRet, 0);
                        }
                        else
                        {
                            MOS_LOG_INF(BROADCAST_LOGSTR, "File(%s) Read Is End", aucFile);
                            break;
                        }
                        Mos_Sleep(1);
                    }
                    Mos_FileClose(hFile);
                }
                else
                {
                    MOS_LOG_ERR(BROADCAST_LOGSTR, "File(%s) Open Failed", aucFile);
                }
            }
            else
            {
                MOS_LOG_ERR(BROADCAST_LOGSTR, "File(%s) Is Not Exist", aucFile);
            }

            _INT iRet  = 0;
            _INT iTime = 0;
            while (iTime < 200)
            {                
                iRet = Media_AudioPlayReadFrameIsEnd();
                if (iRet == MOS_OK)
                {
                    break;
                }
                iTime++;
                Mos_Sleep(10);
            }

            if (LIVE_STATE_CONNECT_SUCCESS == session_state)
            {            
                Mos_Sleep(1*1000);
            }

            Broadcast_GetTaskMng()->bEnableSpeaker = MOS_TRUE;
        }

        if (LIVE_STATE_CONNECT_SUCCESS == session_state)
        {            
            Broadcast_GetTaskMng()->stLastState =  BROADCAST_STATE_LIVE;
        }

        if (Broadcast_GetTaskMng()->stState < BROADCAST_STATE_ALRAM)
        {            
            Broadcast_GetTaskMng()->stState = session_state == PLAYBACK_ACTION_START_PLAY ? BROADCAST_STATE_PLAYBACK : BROADCAST_STATE_LIVE;
        }    
        Mos_MutexUnLock(&Broadcast_GetTaskMng()->hMutexStatus);    
    }

    if (LIVE_STATE_SESSION_CLOSED == session_state || PLAYBACK_ACTION_STOP_PLAY == session_state || LIVE_STATE_ACTION_PAUSE_PLAY == session_state)
    {
        Mos_MutexLock(&Broadcast_GetTaskMng()->hMutexStatus); 
        if (Broadcast_GetTaskMng()->bEnableSpeaker)
        {                             
            Media_Notify_AudioPlay("Broadcast", 1, 0, 0);
            Media_AudioPlayDestroyWriteHandle(Broadcast_GetTaskMng()->hAudioPlay);
            Broadcast_GetTaskMng()->hAudioPlay = MOS_NULL;
            
            Broadcast_GetTaskMng()->bEnableSpeaker  = MOS_FALSE;

            if (Broadcast_GetTaskMng()->stState < BROADCAST_STATE_ALRAM)
            {
                Broadcast_GetTaskMng()->stState = BROADCAST_STATE_CLOSED;
            }                
            
            //Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                                    
            MOS_LOG_INF(BROADCAST_LOGSTR, "Closing audio reverse");
        }        
   
        if (LIVE_STATE_SESSION_CLOSED == session_state)
        {            
            Broadcast_GetTaskMng()->stLastState =  BROADCAST_STATE_CLOSED;
        }

        if (LIVE_STATE_SESSION_CLOSED == session_state &&  Broadcast_GetTaskMng()->stState < BROADCAST_STATE_ALRAM)
        {
            resume_all_task();
        }

        Mos_MutexUnLock(&Broadcast_GetTaskMng()->hMutexStatus);
    }

    return MOS_OK;
}

static short Broadcast_search(short     val, short *table, short size)
{  
    short    i = 0;
    for (i = 0; i < size; i++) 
    {
        if (val <= *table++)
        return (i);
    }
    return (size);
}

_UC Broadcast_linear2alaw(short pcm_val)    /* 2's complement (16-bit range) */
{
    short    mask = 0;
    short    seg  = 0;
    _UC aval = 0;

    pcm_val = pcm_val >> 3;

    if (pcm_val >= 0) 
    {
        mask = 0xD5;        /* sign (7th) bit = 1 */
    } 
    else
    {
        mask = 0x55;        /* sign bit = 0 */
        pcm_val = -pcm_val - 1;
    }
    seg = Broadcast_search(pcm_val, test_seg_aend, 8);
    if (seg >= 8)
    {
        return (unsigned char) (0x7F ^ mask);
    }
    else
    {
        aval = (unsigned char) seg << 4;
        if (seg < 2)
        {
            aval |= (pcm_val >> 1) & 0xf;
        }
        else
        {
            aval |= (pcm_val >> seg) & 0xf;
        }
        return (aval ^ mask);
    }
}

_INT Broadcast_G711_EncAlaw(_UC *pucInframe, _UI uiInframeLen, _UC *pucOutFrame)
{
    _UI i = 0;
    _UI uiSampleNum = uiInframeLen / 2;
    short *sPcm = (short*)pucInframe;
    for (i = 0; i < uiSampleNum; i++)
    {
        pucOutFrame[i] = Broadcast_linear2alaw(sPcm[i]);
    }
    return (_INT)uiSampleNum;
}


_INT Broadcast_LiveAudioData_Cb(_C* session_id, _UC* p_audio_data, _INT audio_data_size, _INT audio_data_type, _ULLID user_data)
{
    if (session_id == MOS_NULL || p_audio_data == MOS_NULL || audio_data_size == 0)
    {        
        MOS_LOG_INF(BROADCAST_LOGSTR, "invalid param");
        return MOS_ERR;
    }
    
    //MOS_LOG_INF(BROADCAST_LOGSTR,"%s:%d session_id=%s, audio_data_size=%d audio_data_type=%d stState = %d", __FUNCTION__, __LINE__, session_id, audio_data_size,audio_data_type,Broadcast_GetTaskMng()->stState);
    
    _UI i = 0;
    _UI j = 0;
    _INT iRet        = MOS_ERR;
    _UI datecount   = audio_data_size / 640;
    
    if (Broadcast_GetTaskMng()->bEnableSpeaker && (Broadcast_GetTaskMng()->hAudioPlay != MOS_NULL) && audio_data_size >0)
    {
        _UC g711Buffer[640] = {0};
        for (i = 0;i < datecount;i++)
        {    
            _UI g711BufSize = Broadcast_G711_EncAlaw(p_audio_data+i*640, 640, g711Buffer);

            j = 0;
            while (j < 200 && Broadcast_GetTaskMng()->ucRunFlag == 1)
            {                
                iRet = Media_AudioPlayWriteFrame2(Broadcast_GetTaskMng()->hAudioPlay, g711Buffer,g711BufSize, 0);
                if (iRet == MOS_OK)
                {
                    break;
                }
                j++;
                Mos_Sleep(10);
            }

            if (j >= 200)
            {
                MOS_LOG_INF(BROADCAST_LOGSTR, " Media_AudioPlayWriteFrame2 Failed");
            }
        }
        
    }
    return MOS_OK;
}

_INT Broadcast_SetLog_Cb(unsigned char *pucFunName, unsigned int uiLine, unsigned char *pucPid, unsigned int uiLeval, const char *pucFormat, ...)
{
    if (pucFunName == MOS_NULL || pucFormat == MOS_NULL)
    {        
        MOS_LOG_ERR(BROADCAST_LOGSTR, "invalid param");
        return MOS_ERR;
    }

    char printStr[2048] = {0};

    va_list ap;    
    va_start(ap,pucFormat);
    vsnprintf(printStr,sizeof(printStr)-1,(const char*)pucFormat,ap);        
    va_end(ap);
    
    if (MOS_STRSTR(printStr,"index_need_to_play: -1, index_timeRange_to_play: -1, curr player_task_index: -1") != MOS_NULL)
    {
         return MOS_OK;
    }

    if (uiLeval == 1)
    {        
        MOS_LOG_ERR(BROADCAST_LOGSTR, "%s %d %s",pucFunName,uiLine,printStr);
    }
    else
    {
        MOS_LOG_INF(BROADCAST_LOGSTR, "%s %d %s",pucFunName,uiLine,printStr);
    }

    return MOS_OK;
}

// 云广播模块初始化
_INT Broadcast_Task_Init()
{
    if (Broadcast_GetTaskMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(BROADCAST_LOGSTR, "Already Init");
        return MOS_OK;
    }
    
    MOS_MEMSET(&g_Broadcast_TaskMng , 0, sizeof(g_Broadcast_TaskMng));
    // Broadcast_GetTaskMng()->hMsgQueque = Mos_MsgQueueCreate(MOS_FALSE, 30);
    g_Broadcast_TaskMng.stState = BROADCAST_STATE_CLOSED;
    Mos_MutexCreate(&Broadcast_GetTaskMng()->hMutexStatus);
    // MOS_PRINTF("BROADCAST msg queue %p  \r\n", Broadcast_GetTaskMng()->hMsgQueque);
    Broadcast_GetTaskMng()->ucInitFlag = 1;
    MOS_LOG_INF(BROADCAST_LOGSTR, "Broadcast Init Ok");
    return MOS_OK;
}

#if 0
_VOID Broadcast_CheckAndFeedDog()
{
    // 软看门狗喂狗
    if (getDiffTimems(&g_tBroadcastFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
    {            
        Swd_AppThreadFeedDog(g_hSwdBroadcastFeedDog);
        getDiffTimems(&g_tBroadcastFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
    }
}

// 云广播模块任务轮询
_INT Broadcast_Task_Loop(_VPTR pstArg)
{
    g_hSwdBroadcastFeedDog = Swd_AppThreadRegist(BROADCAST_APP, FEED_DOG_MAX_TIMESEC);
    kj_timer_init(&g_tBroadcastFeedDogTimeOut);
    getDiffTimems(&g_tBroadcastFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);

    while (Broadcast_GetTaskMng ()->ucRunFlag)
    {
        // 软看门狗检测喂狗
        Broadcast_CheckAndFeedDog();

        Mos_Sleep(1000);
    }

    //Swd_AppThreadUnRegist(g_hSwdBroadcastFeedDog);
    MOS_LOG_WARN(BROADCAST_LOGSTR,"Broadcast task out");
    return MOS_OK;
}
#endif

// 云广播模块启动
_INT Broadcast_Task_Start()
{
    _INT iRet          = MOS_ERR;    
    _ULLID uiUserData1 = 112233;
    _ULLID uiUserData2 = 223344;
    _ULLID uiUserData3 = 332233;
    _ULLID uiUserData4 = 443344;
    
    _UC aucCfgPath[MOS_DIR_NAME_LEN] = {0};
    _UI uiStackSize                  = MOS_THREAD_STACK_NORMAL_SIZE;
    #ifdef MOS_LINUX_RTOS
    uiStackSize                      = MOS_THREAD_STACK_MIN_SIZE;
    #endif
    if (Broadcast_GetTaskMng ()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    
    if (Broadcast_GetTaskMng ()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(BROADCAST_LOGSTR, "Already Start");
        return MOS_OK;
    }

    if (Config_GetCamaraMng()->uiCloudBroadcastAbility <= 0)
    {
        MOS_LOG_INF(BROADCAST_LOGSTR, "uiCloudBroadcastAbility is disabled,ignore run broadcast!");
        return MOS_OK;
    }
    
    iRet = set_log_output_callback(Broadcast_SetLog_Cb);
    if (MOS_ERR == iRet)
    {        
        MOS_LOG_INF(BROADCAST_LOGSTR, "set_log_output_callback failed!");
        return MOS_ERR;
    }
    MOS_LOG_INF(BROADCAST_LOGSTR, "set_log_output_callback succeed!");
    
    MOS_VSNPRINTF(aucCfgPath, MOS_DIR_NAME_LEN, "%s/config/caudiocloud.conf",Mos_GetWorkPath());
    // 云广播sdk初始化
    iRet = init_sdk(Config_GetSystemMng()->aucDevkey, Config_GetSystemMng()->aucDevUID,aucCfgPath);
    if (MOS_ERR == iRet)
    {        
        MOS_LOG_INF(BROADCAST_LOGSTR, "init broadcast sdk failed!");        
        return MOS_ERR;
    }
    MOS_LOG_INF(BROADCAST_LOGSTR, "init broadcast sdk succeed!");
    
    // 注册实时音频广播音频数据处理回调函数
    iRet = set_audio_data_callback(Broadcast_LiveAudioData_Cb, uiUserData1);
    if (MOS_ERR == iRet)
    {
        MOS_LOG_INF(BROADCAST_LOGSTR, "set_audio_data_callback failed!");    
        return MOS_ERR;
    }
    MOS_LOG_INF(BROADCAST_LOGSTR, "set_audio_data_callback succeed!");
    
    // 注册实时音频广播会话状态回调函数
    iRet = set_live_playback_state_callback(Broadcast_LivePlaybackState_Cb, uiUserData2);
    if (MOS_ERR == iRet)
    {        
        MOS_LOG_INF(BROADCAST_LOGSTR, "set_live_playback_state_callback failed!");
        return MOS_ERR;
    }
    MOS_LOG_INF(BROADCAST_LOGSTR, "set_live_playback_state_callback succeed!");

    // 注册http_get回调函数
    iRet = set_https_get_callback(Broadcast_HttpsGet_Cb, uiUserData3);
    if (MOS_ERR == iRet)
    {
        MOS_LOG_INF(BROADCAST_LOGSTR, "set_https_get_callback failed!");        
        return MOS_ERR;
    }    
    MOS_LOG_INF(BROADCAST_LOGSTR, "set_https_get_callback succeed!");


    // 注册实时音频下载回调函数
    iRet = set_https_download_callback(Broadcast_HttpsDownload_Cb, uiUserData4);
    if (MOS_ERR == iRet)
    {        
        MOS_LOG_INF(BROADCAST_LOGSTR, "set_https_download_callback failed!");        
        return MOS_ERR;
    }
    MOS_LOG_INF(BROADCAST_LOGSTR, "set_https_download_callback succeed!");
    Broadcast_GetTaskMng ()->ucRunFlag  = 1;

    // BROADCAST模块任务轮询
    /*if(Mos_ThreadCreate((_UC*)"BROADCAST_task", EN_THREAD_PRIORITY_NORMAL, uiStackSize,
                        Broadcast_Task_Loop, MOS_NULL,MOS_NULL, &Broadcast_GetTaskMng()->hThread) == MOS_ERR)
    {
        Broadcast_GetTaskMng()->ucRunFlag = 0;
        return MOS_ERR;
    }*/

    return MOS_OK;
}

// 云广播模块停止
_INT Broadcast_Task_Stop()
{
    if (Broadcast_GetTaskMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(BROADCAST_LOGSTR, "Already Stop");
        return MOS_OK;
    }
    Broadcast_GetTaskMng()->ucRunFlag = 0;

    // 云广播sdk注销
    // release_sdk();
    
    //Mos_MutexDelete(&Broadcast_GetTaskMng()->hMutexStatus);
    // Mos_MsgQueueWake(Broadcast_GetTaskMng()->hMsgQueque, MOS_TRUE);
    //Mos_ThreadDelete(Broadcast_GetTaskMng()->hThread);

    MOS_LOG_INF(BROADCAST_LOGSTR, "Broadcast Task Stop Ok");
    return MOS_OK;
}

// 云广播模块销毁
_INT Broadcast_Task_Destroy()
{
    if (Broadcast_GetTaskMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(BROADCAST_LOGSTR, "Already Destroy");
        return MOS_OK;
    }
    
    Mos_MutexDelete(&Broadcast_GetTaskMng()->hMutexStatus);
    // Mos_MsgQueueDelete(Broadcast_GetTaskMng()->hMsgQueque);
    MOS_MEMSET(&g_Broadcast_TaskMng, 0, sizeof(g_Broadcast_TaskMng));
    Broadcast_GetTaskMng()->ucInitFlag = 0;
    MOS_LOG_INF(BROADCAST_LOGSTR, "Broadcast Task Destroy Ok");
    return MOS_OK;
}

_INT Broadcast_Task_SetBroadcastState(ST_BROADCAST_STATE stState)
{
    if (Config_GetCamaraMng()->uiCloudBroadcastAbility)
    {
        Broadcast_GetTaskMng()->stState = stState;
    }

    return MOS_OK;
}

ST_BROADCAST_STATE Broadcast_Task_GetBroadcastState()
{
    return Broadcast_GetTaskMng()->stState;
}

_INT Broadcast_Task_Resume_CloseTalk()
{
    if (Config_GetCamaraMng()->uiCloudBroadcastAbility)
    {
        if (Broadcast_Task_GetBroadcastState() == BROADCAST_STATE_TALK)
        {
            Broadcast_Task_SetBroadcastState(BROADCAST_STATE_CLOSED);
            if (Broadcast_GetTaskMng()->stLastState == BROADCAST_STATE_LIVE)
            {
                resume_live_session();
            }
            else if(Broadcast_GetTaskMng()->stLastState == BROADCAST_STATE_PLAYBACK)
            {
                resume_all_task();
            }
            Broadcast_GetTaskMng()->stLastState =  BROADCAST_STATE_CLOSED;
        }
    }

    return MOS_OK;
}

_INT Broadcast_Task_Pause_OpenTalk()
{
    if (Config_GetCamaraMng()->uiCloudBroadcastAbility)
    {
        Mos_MutexLock(&Broadcast_GetTaskMng()->hMutexStatus); 
        if (Broadcast_Task_GetBroadcastState() == BROADCAST_STATE_PLAYBACK || Broadcast_Task_GetBroadcastState() == BROADCAST_STATE_LIVE)
        {
            if (Broadcast_GetTaskMng()->bEnableSpeaker)
            {                             
                Media_Notify_AudioPlay("TalkSpeaker", 1, 0, 0);
                Media_AudioPlayDestroyWriteHandle(Broadcast_GetTaskMng()->hAudioPlay);
                Broadcast_GetTaskMng()->hAudioPlay = MOS_NULL;
                
                Broadcast_GetTaskMng()->bEnableSpeaker  = MOS_FALSE;
                            
                Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                                        
                MOS_LOG_INF(BROADCAST_LOGSTR, "Closing audio reverse");
            }		
        
            Broadcast_GetTaskMng()->stLastState = Broadcast_Task_GetBroadcastState();
            if (Broadcast_Task_GetBroadcastState() == BROADCAST_STATE_PLAYBACK)
            {
                pause_all_task();
            }
            else
            {
                //stop_current_live_sesssion();
                pause_live_session();
            }
        }
        Broadcast_Task_SetBroadcastState(BROADCAST_STATE_TALK);
        Mos_MutexUnLock(&Broadcast_GetTaskMng()->hMutexStatus);
    }

    return MOS_OK;
}

_INT Broadcast_Task_Pause_StartLive()
{
    if (Config_GetCamaraMng()->uiCloudBroadcastAbility)
    {
        Mos_MutexLock(&Broadcast_GetTaskMng()->hMutexStatus); 
        if (Broadcast_Task_GetBroadcastState() == BROADCAST_STATE_PLAYBACK)
        {
            if (Broadcast_GetTaskMng()->bEnableSpeaker)
            {                             
                Media_Notify_AudioPlay("TalkSpeaker", 1, 0, 0);
                Media_AudioPlayDestroyWriteHandle(Broadcast_GetTaskMng()->hAudioPlay);
                Broadcast_GetTaskMng()->hAudioPlay = MOS_NULL;
                
                Broadcast_GetTaskMng()->bEnableSpeaker  = MOS_FALSE;
                            
                Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                                        
                MOS_LOG_INF(BROADCAST_LOGSTR, "Closing audio reverse");
            }

            Broadcast_GetTaskMng()->stState = BROADCAST_STATE_CLOSED;	
        }

        pause_all_task();

        Mos_MutexUnLock(&Broadcast_GetTaskMng()->hMutexStatus);
    }

    return MOS_OK;
}
