// 下列 ifdef 块是创建使从 DLL 导出更简单的
// 宏的标准方法。此 DLL 中的所有文件都是用命令行上定义的 RAYPLAYCORE_EXPORTS
// 符号编译的。在使用此 DLL 的
// 任何其他项目上不应定义此符号。这样，源文件中包含此文件的任何其他项目都会将
// RAYPLAYCORE_API 函数视为是从 DLL 导入的，而此 DLL 则将用此宏定义的
// 符号视为是被导出的。

// #ifdef AUDIO_DEVICE

#ifdef WIN32
#ifdef EXPORTS

#define AUDIODEVICEAPI extern "C" __declspec(dllexport)
#else
#define AUDIODEVICEAPI  extern "C"  __declspec(dllimport)
#endif
#else
#define AUDIODEVICEAPI  __attribute__ ((visibility("default")))
#endif

#ifdef WIN32
#define CALL __stdcall
#else
#define CALL __attribute__((__stdcall__))
#endif

#pragma once

typedef enum enum_LIVE_PLAYBACK_STATE
{
    LIVE_STATE_CONNECT_SUCCESS = 0,
    LIVE_STATE_CONNECT_FAILED = 1,
    LIVE_STATE_SESSION_NOT_AVAILABLE = 2,
    LIVE_STATE_SESSION_CLOSED = 3,
    LIVE_STATE_RECONNECTTING = 4,
    LIVE_STATE_RECONNECTTED = 5,
    PLAYBACK_ACTION_START_PLAY = 6,
    PLAYBACK_ACTION_STOP_PLAY = 7,
    LIVE_STATE_ACTION_RESUME_PLAY = 8,
    LIVE_STATE_ACTION_PAUSE_PLAY = 9,
}LIVE_PLAYBACK_STATE;


#ifdef __cplusplus
extern "C"
{
#endif


    //************************************
    // Method:    cb_live_playback_state
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家注册给sdk使用的回调接口，用于sdk将实时音频广播工作状态传递给厂家处理
    // Parameter: 
    //************************************
    typedef int(CALL *cb_live_playback_state)(LIVE_PLAYBACK_STATE session_state, char* session_id, unsigned long user_data);

    //************************************
    // Method:    cb_session_audio_data
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家注册给sdk使用的回调接口，用于sdk将实时音频广播数据传递给厂家处理
    // Parameter: audio_data_type 音频数据类型（当前为固定类型1，8K，16位，单声道 pcm数据）
    //************************************
    typedef int(CALL *cb_session_audio_data)(char* session_id, unsigned char* p_audio_data, int audio_data_size, int audio_data_type, unsigned long user_data);

    //************************************
    // Method:    init_sdk
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: sdk初始化
    // Parameter: 入参： 设备密码dev_password、设备uid、定时任务配置保存全路径文件名sch_task_cfg_file
    //************************************
    AUDIODEVICEAPI int CALL init_sdk(const char * dev_password, const char *uid, const char *sch_task_cfg_file);

    //************************************
    // Method:    get_sdk_version
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口，用于获取sdk版本号
    // Parameter: 入参： 云广播sdk版本号version、version的尺寸
    // 注意：version的尺寸不小于10
    //************************************
    AUDIODEVICEAPI int CALL get_sdk_version(char * version, unsigned int len);

    //************************************
    // Method:    set_live_playback_state_callback
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口， 注册实时连接状态回调 
    // Parameter: 
    //************************************
    AUDIODEVICEAPI    int CALL set_live_playback_state_callback(cb_live_playback_state func, unsigned long user_data);

    //************************************
    // Method:    set_audio_data_callback
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口， 注册实时音频广播数据处理回调函数
    // Parameter: 
    //************************************
    AUDIODEVICEAPI    int CALL set_audio_data_callback(cb_session_audio_data func, unsigned long user_data);

    //************************************
    // Method:    create_live_session
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口，创建实时连接session
    // Parameter:   入参： 网关IP、 网关端口、 设备uid、 以及 sessionID
    //************************************
    AUDIODEVICEAPI    int CALL create_live_session(char* voice_gw_ip, int voice_gw_port, char* camera_uid, char* session_id);

    //************************************
    // Method:    stop_current_live_sesssion
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口，关闭实时连接session，释放之前实时会话创建的资源
    // Parameter: 无
    //************************************
    AUDIODEVICEAPI    int CALL stop_current_live_sesssion();

    //************************************
    // Method:    pause_live_session
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口 暂停实时广播会话任务
    // Parameter:   
    //************************************
    AUDIODEVICEAPI	int CALL pause_live_session();

    //************************************
    // Method:    resume_live_session
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口 恢复实时广播会话任务
    // Parameter:   
    //************************************
    AUDIODEVICEAPI	int CALL resume_live_session();

    //************************************
    // Method:    create_playback_schedule
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口 用于指定某个session id 创建音频广播回放 任务时间表
    // Parameter:   
    //************************************
    AUDIODEVICEAPI    int CALL create_playback_schedule(char* session_id, char* schedule_json);

    //************************************
    // Method:    stop_playback_schedule
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口 停止某个回放音频广播会话任务
    // Parameter:   
    //************************************
    AUDIODEVICEAPI    int CALL stop_playback_schedule(char* task_id);
    
    //************************************
    // Method:    pause_all_task
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口 暂停所有回放音频广播会话任务
    // Parameter:   
    //************************************
    AUDIODEVICEAPI    int CALL pause_all_task();
    
    //************************************
    // Method:    resume_all_task
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口 恢复所有回放音频广播会话任务
    // Parameter:   
    //************************************
    AUDIODEVICEAPI    int CALL resume_all_task();
    
    //************************************
    // Method:    stop_all_task
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: 厂家调用接口 停止所有回放音频广播会话任务
    // Parameter:   
    //************************************
    AUDIODEVICEAPI    int CALL stop_all_task();

    //************************************
    // Method:    release_sdk
    // Returns:   返回错误码 0 成功  -1 失败
    // Description: sdk注销释放，停止一切当前的任务和释放所有资源
    // Parameter: 
    //************************************
    AUDIODEVICEAPI int CALL release_sdk();

    //**************************************************************************************
    // Method:        cb_audiocloud_log_output
    // Description: 输出日志，保存日志文件
    // Parameter:
    //                pucFunName:函数名称
    //                uiLine    :行数
    //                pucPid    :线程Pid
    //                uiType    :类型 -1:错误 0:正确
    //                uiLevel   :等级 暂无用
    //                pucFormat :输出内容
    // Returns:     -1：失败；0：成功
    //***************************************************************************************
    typedef int (*cb_audiocloud_log_output)(unsigned char *pucFunName, unsigned int uiLine, const char *pucPid, unsigned int uiLeval, const char *pucFormat, ...);

    //**************************************************************************************
    // Method:      cb_audiocloud_https_get
    // Description: 执行https get请求，并将响应body保存到data中
    // Parameter:   
    //              url: 请求url，要兼容http和https请求
    //              data: 保存http请求响应body的缓冲区指针
    //              dataLen：data缓冲区的大小，接口最多保存该大小的响应body到data中
    // Returns:     -1：http请求失败；>=0：http请求成功，数值为服务端响应的body字节数
    //***************************************************************************************
    typedef int (*cb_audiocloud_https_get)(const char * url, void *data, int dataLen);

    //************************************
    // Method:      cb_audiocloud_https_writefunc
    // Description: 提供给cb_audiocloud_https_download使用的http下载写回调接口
    //              用于将http请求的响应body传递给sdk
    // Parameter:   data：用于保存http请求响应body的缓冲区
    //              size：data缓冲区大小，单位：字节
    //              nmemb：data缓冲区个数，通常取值为1
    //              stream：sdk使用的回调指针
    // Returns:     返回0 - 结束http请求；返回其他值 - 继续http请求
    //************************************
    typedef size_t(* cb_audiocloud_https_writefunc)(void *data, size_t size, size_t nmemb, void *stream);

    //**************************************************************************************
    // Method:      cb_audiocloud_https_download
    // Description: 厂商注册给sdk使用的回调接口
    //              用于执行https get请求下载（需要支持断点续传）音频文件，并返回下载的字节数
    // Parameter:   
    //              url: 请求url，要兼容http和https请求
    //              connTimeout：建链超时时间，单位：秒
    //              recvSpeed: http请求速度限制，0-不限速；>0：接收限速，单位：字节/秒
    //              httpBuffSize：设置为http请求的接收缓冲区尺寸
    //              write_data_func: http请求响应数据处理的回调接口指针
    //              stream：write_data_func回调函数中使用的回调指针
    // Returns:     -1：http请求失败；>=0：http请求成功，数值为服务端响应的body字节数
    //***************************************************************************************
    typedef int (*cb_audiocloud_https_download)(const char *url, int connTimeout, int recvSpeed, int httpBuffSize, cb_audiocloud_https_writefunc write_data_func, void *stream, int mediaDuration);

    //***************************************************************************************
    // Method:      set_https_get_callback
    // Description: 厂家调用接口， 注册https get请求接口
    // Parameter: 
    // Returns:     返回错误码 0 成功  -1 失败
    //***************************************************************************************
    AUDIODEVICEAPI int set_https_get_callback(cb_audiocloud_https_get func, unsigned long user_data);

    //***************************************************************************************
    // Method:      set_https_download_callback
    // Description: 厂家调用接口， 注册https下载音频文件接口
    // Parameter: 
    // Returns:     返回错误码 0 成功  -1 失败
    //***************************************************************************************
    AUDIODEVICEAPI int set_https_download_callback(cb_audiocloud_https_download func, unsigned long user_data);

    //***************************************************************************************
    // Method:      set_log_output_callback
    // Description: 厂家调用接口， 注册日志输出接口
    // Parameter: 
    // Returns:     返回错误码 0 成功  -1 失败
    //***************************************************************************************
    AUDIODEVICEAPI int set_log_output_callback(cb_audiocloud_log_output func);

#ifdef __cplusplus
}
#endif

// #endif // #ifdef AUDIO_DEVICE
