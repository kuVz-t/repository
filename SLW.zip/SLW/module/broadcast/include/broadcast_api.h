#ifndef _BROADCAST_API_H
#define _BROADCAST_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include "media_audioplay.h"

#define BROADCAST_LOGSTR     (_UC*)"BC"

typedef enum enum_ST_BROADCAST_STATE
{
    BROADCAST_STATE_CLOSED    = 0,
    BROADCAST_STATE_PLAYBACK  = 1,
    BROADCAST_STATE_LIVE      = 2,
    BROADCAST_STATE_ALRAM     = 3,
    BROADCAST_STATE_TALK      = 4,
}ST_BROADCAST_STATE;

typedef struct stru_BROADCAST_MNG
{
    _UC                 ucInitFlag;
    _UC                 ucRunFlag;
    _UC                 ucRsv[2];
    _UI                 uiConnType;
    _HTHREAD            hThread;
    _HQUEUE             hMsgQueque;
    _BOOL               bEnableSpeaker;
    ST_BROADCAST_STATE  stState;
    ST_BROADCAST_STATE  stLastState;
    _HAUDIOPLAY         hAudioPlay;    
    _HMUTEX             hMutexStatus;        // setting status 互斥锁
}ST_BROADCAST_MNG;

ST_BROADCAST_MNG *Broadcast_GetTaskMng();

_INT Broadcast_Task_SetBroadcastState(ST_BROADCAST_STATE Status);

ST_BROADCAST_STATE Broadcast_Task_GetBroadcastState();

_INT Broadcast_Task_Resume_CloseTalk();

_INT Broadcast_Task_Pause_OpenTalk();

_INT Broadcast_Task_Pause_StartLive();

// 云广播模块初始化
_INT Broadcast_Task_Init();

// 云广播模块启动
_INT Broadcast_Task_Start();

// 云广播模块停止
_INT Broadcast_Task_Stop();

// 云广播模块销毁
_INT Broadcast_Task_Destroy();

// 云广播模块初始化
_INT Broadcast_Task_Init();


#ifdef __cplusplus
}
#endif
#endif
