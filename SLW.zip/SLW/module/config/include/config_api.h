#ifndef _CONFIG_SERVER_H
#define _CONFIG_SERVER_H

#include "mos.h"
#include "config_type.h"
#include "config_camera.h"
#include "config_core.h"
#include "config_device.h"
#include "config_inneriot.h"
#include "config_iothub.h"
#include "config_iotpolicy.h"
#include "config_system.h"
#include "config_timepolicy.h"
#include "config_group.h"
#include "config_ptz.h"
#include "config_json.h"
#include "config_serverset.h"
#include "config_ota.h"
#include "config_scenepolicy.h"
#include "config_cloud.h"
#include "config_cloud_patch.h"
#include "config_log.h" 
#include "config_ai.h" 
#include "config_downfile.h"
#include "config_ga1400.h" 
#include "config_ims.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CLOUD_RES_WATCHDOG_TIMEOUT               30  // 云存地址管理看门狗超时时间默认为30min
#define CLOUD_EVENTCLOUD_SWITCH_DEFAULT          1   // 事件云存追加开关默认为开
#define CLOUD_EVENTCLOUD_RANGE_MAXTIME_DEFAUL    300 // 事件云存最大秒数默认为300s
#define CLOUD_EVENTCLOUD_RANGE_MINTIME_DEFAUL    20  // 事件云存最小秒数默认为20s
#define CLOUD_EVENTCLOUD_RANGE_DETECTTIME_DEFAUL 5   // 事件云存检测秒数默认为5s
#define CLOUD_EVENTCLOUD_RANGE_APPENDTIME_DEFAUL 5   // 事件云存追加录制秒数默认为5s

_INT Config_Task_Init(_UC *pucSystemPath,_UC *pucWorkPath);
_INT Config_Task_Start();
_INT Config_Task_Stop();
_INT Config_Task_Destroy();

// 0 下线 , 1 上线
_INT Config_SetDeviOnlineStatus(_UI uiStatus);

_INT Config_SetSyncCfgByp2pFlag(_UC *pucPeerId,_UI uiOgctId,_UI uiCfgItem,_UI uiCfgSign, ST_CFG_MSGSRCINF *pstSrcInf);

_INT Config_SetDevNeedBindFlag(_UC *pucBindCode,_UC *pucGroupId);

_INT Config_GetExitGroupFlag();
_INT Config_SetLoginServerAddr(_INT offical_flag);
_INT Config_GetLoginServerFlag();
// 在使用 配置模块的列表, 要注意加锁 保护

// 读取云存补录配置文件
_VOID Config_LoadCloudPatchFile();

_INT Config_MutexLock();

_INT Config_MutexUnLock();

#ifdef __cplusplus
}
#endif

#endif
