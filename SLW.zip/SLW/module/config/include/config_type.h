#ifndef _CONFIG_TYPE_H
#define _CONFIG_TYPE_H

#ifdef __cplusplus
extern "C" {
#endif

#define  CFG_CTEI_LEN               24              
#define  CFG_STRING_COMMONLEN       32
#define  CFG_STRING_LEN             64
#define  CFG_STRING_MIDLEN          128
#define  CFG_STRING_MAXLEN          256
#define  CFG_STRING_BIGMAXLEN       512
#define  CFG_STRING_SDP_LENGTH      512
#define  CFG_MAX_P2P_CLIENT         10
#define  CFG_MAX_TURN_NAME_LENGTH   128

typedef enum enum_CFG_DEVICE_STATUS{
    EN_CFG_DEVICE_STATUS_INIT = 0,
    EN_CFG_DEVICE_STATUS_ONLINE,
    EN_CFG_DEVICE_STATUS_OFFLINE,
    EN_CFG_DEVICE_STATUS_SLEEP,
    EN_CFG_DEVICE_STATUS_UPGRADE,
    EN_CFG_DEVICE_STATUS_CANUSE
}EN_CFG_DEVICE_STATUS;


typedef enum enum_CFG_TYPE
{
    EN_CFG_TYPE_ABILITY       = 0X01,
    EN_CFG_TYPE_BUSSNESS      = 0x02,
    EN_CFG_TYPE_SIGNID        = 0X04,
    EN_CFG_TYPE_ALL           = 0XFF,
}EN_CFG_TYPE;

typedef struct stru_cfg_output_node
{
    _UI uiUseFlag;
    _UI uiSetDefaultFalg;
    _UI uiKjIoTType;
    _LLID lluKjIotId;
    _UI uiParamLen;
    _UC *pucParam;
    ST_MOS_LIST_NODE stNode;
}ST_CFG_OUTPUT_NODE;

typedef struct str_CFG_MSGSRCINF
{
    _UC aucUsrToken[CFG_STRING_COMMONLEN + 4];
    _UC aucServId[CFG_STRING_COMMONLEN + 4];
}ST_CFG_MSGSRCINF;

#ifdef __cplusplus
}
#endif

#endif


