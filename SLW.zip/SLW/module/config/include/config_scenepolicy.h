#ifndef CONFIG_SCENEPOLICY_H
#define CONFIG_SCENEPOLICY_H


#ifdef __cplusplus
extern "C" {
#endif

typedef struct str_cfg_scenepolicy_node
{
    _UI uiUseFlag;
    _UI uiSceneId;
    _UC aucPolicyName[32];

    ST_MOS_LIST stOutputList; //ST_CFG_OUTPUT_NODE
    ST_MOS_LIST_NODE stNode;
}ST_CFG_SCENEPOLICY_NODE;

ST_MOS_LIST *Config_GetScenePolicyList();

ST_CFG_SCENEPOLICY_NODE *Config_FindOrCreatScenePolicy(_UI uiSceneId);

ST_CFG_SCENEPOLICY_NODE *Config_FindScenePolicyNode(_UI uiSceneId);

_INT Config_SetScenePolicyName(ST_CFG_SCENEPOLICY_NODE *pstPolicyNode,_UC *pucPolicyName);

_INT Config_AddScenePolicyOutput(ST_CFG_SCENEPOLICY_NODE *pstPolicyNode,_UI uiOutIotType,_LLID lluOutIotId,_UC *pucParam);

_INT Config_DeleteScenePolicy(_UI uiSceneId);

_INT Config_ScenePolicyDestroy();

/****************************************************************************
*****************************************************************************/
_VPTR Config_BuildScenePolicyObject(_UI uiCfgType);

_UC *Config_BuildScenePolicyJson(_UI uiCfgType);

_INT Config_ParseScenePolicyJson(_UC *pStrJson,_UI uiCfgType);

#ifdef __cplusplus
}
#endif

#endif


