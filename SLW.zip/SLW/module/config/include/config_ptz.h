#ifndef CONFIG_PTZ_H
#define CONFIG_PTZ_H
#ifdef __cplusplus
extern "C" {
#endif

#define PTZ_LOGSTR     (_UC*)"PTZ" 

//摄像机PTZ协议操作类型
typedef enum enum_PTZ_CONTROL_TYPE{
    EN_PTZ_CONTROL_MOVE                 = 0,    // PTZ操作
    EN_PTZ_CONTROL_GOTO_PRESET_POINT    = 1,    // 预置位操作  移动到预置位
    EN_PTZ_CONTROL_POSITION_CRUISE      = 2,    // 位置巡航（自定义巡航）
    EN_PTZ_CONTROL_STOP                 = 3,    // 停止PTZ转动
    EN_PTZ_CONTROL_PRESET_POINT_ALARM   = 4,    // 移动到预置位，触发设备联动消息，如门磁联动摄像头转动到指定的预置位
    EN_PTZ_CONTROL_PANORAMIC_CRUISE     = 5,    // 全景巡航 
}EN_PTZ_CONTROL_TYPE;

typedef struct str_ZJ_PRESET_POINT  //PTZ ABS MOVE
{
    _INT     iX;                      //预置位x轴坐标    （底层）
    _INT     iY;                      //预置位y轴坐标    （底层）
    _DOUBLE  dZ;
}ST_CFG_PRESET_POINT;

typedef struct stru_CFG_PRESET_NODE //预置位点定义
{
    _UI  uiUseFlag;
    _UC  aucName[32];
    _UC  aucPicID[64];
    _UI  uiPresetId;
    ST_CFG_PRESET_POINT stPtzPreset;
    ST_MOS_LIST_NODE stNode;
}ST_CFG_PRESET_NODE;

typedef struct stru_CFG_CRUISE_PIOINT_NODE //预置位点定义
{
    _UI  uiUseFlag;
    _UI  uiIndex;
    _UI  uiPresetId;
    _UI  uiDwellTime;
    _UI  uiSpeed;
    ST_MOS_LIST_NODE stNode;
}ST_CFG_CRUISE_POINT_NODE;

typedef struct stru_CFG_CRUISE_NODE //预置位点定义
{
    _UI  uiUseFlag;
    _UC  aucName[32];
    _UI  uiCruiseId;
    ST_MOS_LIST stPointList; //ST_CFG_CRUISE_POINT_NODE
    ST_MOS_LIST_NODE stNode;
}ST_CFG_CRUISE_NODE;


typedef struct ST_CFG_PTZ_MNG
{
    _UI uiWatchPresetId;
    _UI uiWatchTime;
    _UI uiSetPreSetAbility;
    _UI uiSetCuriseAbility;
    ST_MOS_LIST    stPresetList;  // 预置位
    ST_MOS_LIST    stCruiseList;  // 巡航位
}ST_CFG_PTZ_MNG;

ST_CFG_PTZ_MNG *Config_GetPtzMng();

_INT Ptz_Task_Destroy();

_INT Config_AddPresetPoint(_INT iCamId,_UI uiPresetId, _UC *pucName, ST_CFG_PRESET_POINT *stAbsMove);

_INT Config_SetPresetPictureId(_INT iCamId,_UI uiPresetId, _UC *pucPicId);

_INT Config_DelPresetPointById(_INT iCamid,_UI uiPresetId);

_INT Config_DelAllPresetPoints();

_INT Config_FindPresetPointById(_INT iCamId,_UI uiPresetId,ST_CFG_PRESET_POINT *pstPtzPreset);

// 21cn 现网
_INT Config_FindAllPresetId(_INT iCamId,_UI uiPresetId,_INT *pstPresetIdArry,_INT iSize);

// 巡航预置位  
_INT Config_AddCurise(_INT iCamId,_UI uiCruiseID);

_INT Config_DeleteCurise(_INT iCamId,_UI uiCruiseID);

ST_CFG_CRUISE_NODE *Config_FindCuriseNode(_INT iCamId,_UI uiCruiseID);

_INT Config_SetCuriseName(_INT iCamId,_UI uiCruiseID,_UC *pucName);

_INT Config_AddPresetIdToCurise(_INT iCamId,_UI uiCruiseID,_UI uiIndex,_UI uiPresetId,_UI uiDwellTime,_UI uiSpeed);

_INT Config_AddPresetIdToCuriseEx(_INT iCamId,_UI uiCruiseID,_UI uiPresetId,_UI uiDwellTime,_UI uiSpeed);

_INT Config_BegainSyncCruise(_INT iCamId);

_INT Config_EndSyncCruise(_INT iCamId);

// 看守位设置  
_INT Config_AddWatchPoint(_INT iCamId,_UI uiPresetID,_UI uiWatchTime);
_INT Config_DeleteWatchPoint(_INT iCamId);

// 预置点设置能力支持  0.不支持； 1.支持；
_INT Config_SetPreSetAbility(_INT iCamID, _UI uiSetPresetAbility);
// 智能巡航能力支持  0.不支持； 1.支持；
_INT Config_SetCuriseAbility(_INT iCamID, _UI uiSetCuriseAbility);

/****************************************************************************
*****************************************************************************/
_VPTR Config_BuildPtzObject(_UI uiCfgType);

_UC *Config_BuildPtzJson(_UI uiCfgType);

_INT Config_ParsePtzJson(_UC *pStrJson,_UI uiCfgType);

#ifdef __cplusplus
}
#endif

#endif


