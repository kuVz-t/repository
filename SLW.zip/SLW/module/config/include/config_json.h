#ifndef _CONFIG_JSON_H
#define _CONFIG_JSON_H
#ifdef __cplusplus
extern "C" {
#endif

_VPTR Config_BuildLocalAbilityJson(_UC ucMsgType,_UC ucMsgId);

//EN_CFG_ITEM
_VPTR Config_BuildLocalBussJson(_UC ucMsgType,_UC ucMsgId,_UI uiBussItem);

_VPTR Config_BuildAllLocalBussJson();

_VPTR Config_BuildUpLoadStatusJson(_UC ucMsgType,_UC ucMsgId);


#ifdef __cplusplus
}
#endif
#endif

