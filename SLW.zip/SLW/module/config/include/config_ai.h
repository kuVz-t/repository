#ifndef _CONFIG_AI_H
#define _CONFIG_AI_H

#ifdef __cplusplus
extern "C" {
#endif
#include "adpt_ssl_adapt.h"
#include "zj_type.h"

#define  AIFACE_WRITEFILE   0

///////////////////// URL SOCKET /////////////////////////////
#define AI_DEFAULT_HTTP_PORT                    80 
#define AI_DEFAULT_HTTPS_PORT                   443 

#define AI_HOST_LEN                             128
#define AI_URI_LEN                              1020
#define AI_HTTP_HEADER_MAX_LEN                  1024
#define AI_SOCKET_BUF_SIZE                      16000
#define AI_SOCKET_SEND_TIMEOUT                  3           // FIXME: 5
#define AI_SOCKET_RECV_TIMEOUT                  3           // FIXME: 8

#define AI_BUF_UNIT_SIZE                        1440
#define AI_HTTP_RES_WAIT_MAX_TIME               15000

#define AI_ZIP_ALARM_LISTNODE_MAXCOUNT          10          // 抓拍ZIP告警事件链表最大节点数
#define AI_FACEREC_ALARM_LISTNODE_MAXCOUNT      25          // 人脸识别告警事件链表最大节点数
#define AI_IOTPV_ALARM_LISTNODE_MAXCOUNT        40          // AI告警上传图片和视频告警事件链表最大节点数

#define AI_ZIP_ALARM_REPORT_TIMEOUT_MSEC        (200 * 1000) // 抓拍ZIP告警事件消息上报超时时间(微秒)
#define AI_FACEREC_ALARM_REPORT_TIMEOUT_MSEC    (30 * 1000) // 人脸识别告警事件消息上报超时时间(微秒)
#define AI_IOTPV_ALARM_REPORT_TIMEOUT_SEC       15          // AI告警上传图片和视频告警事件消息上报超时时间

#define AI_ZIP_ALARM_UPLOAD_TIMEOUT_SEC         200         // 抓拍ZIP告警事件图片上传超时时间
#define AI_FACEREC_ALARM_UPLOAD_TIMEOUT_SEC     60          // 人脸识别告警事件图片上传超时时间
#define AI_IOTPV_ALARM_UPLOAD_TIMEOUT_SEC       30          // AI告警事件图片和视频上传超时时间

// AI配置Json是否带下载任务信息标志
typedef enum enum_AI_BUILD_DOWNTASK_FLAG
{
    EN_AI_BUILD_DOWNTASK_OFF,
    EN_AI_BUILD_DOWNTASK_ON,
}EN_BUILD_DOWNTASK_FLAG;

//Ai http执行状态状态
typedef enum enum_AI_HTTP_ASYNC_STATUS
{
    EN_AI_HTTP_ASYNC_STATUS_NOTRANS = 0x00, // 可用
    EN_AI_HTTP_ASYNC_STATUS_TRANSED = 0x01  // 正在上报中
}EN_AI_HTTP_ASYNC_STATUS;

typedef enum enum_WBLIST
{
    EN_WB_NONE    = 0, // 都不属于
    EN_BLACK_LIST = 1, // 黑名单
    EN_WHITE_LIST = 2  // 白名单
}EN_WBLIST;

// label
typedef enum enum_AICFG_LABEL
{
    EN_AICFG_LABEL_FACE_BLACKLIST, // 人脸黑名单
    EN_AICFG_LABEL_FACE_WHITELIST  // 人脸白名单
}EN_AICFG_LABEL;

typedef struct stru_AICFG_LABEL
{
    EN_AICFG_LABEL labelType;
    _UC *pucLabelID;
    _UC *pucLabelName;
    _UC *pucUserID;
}ST_AICFG_LABEL;

typedef struct stru_CFG_AI_HTTP_TASK
{
    _UI     uiHttpCancelFlag;               // http取消标志
    _UI     uiHttpHandle;                   // handle
    _US     usBuffLen;                      // 单次接收数据长度
    _US     usRecvLen;                      // 总共接收数据长度
    _UC*    pucHttpBuff;                    // httpbuf
    EN_AI_HTTP_ASYNC_STATUS  uiAsyncStatus; // Http任务上报状态 refer to  EN_AI_HTTP_ASYNC_STATUS
}ST_CFG_AI_HTTP_TASK;

typedef struct struct_UPLOAD_AIREC_ZIP_INF
{
    _UC          aucRequestURL[AI_URI_LEN]; 
    _UC          aucRequestDate[32];  
    _UC          aucAuthorization[64]; 
}ST_UPLOAD_AIREC_ZIP_INF;

typedef struct struct_URL_CONN_SOCKET
{
    _UI          uiHttpType;
    _UI          uiConnType;
    _UC          aucHeader[AI_HTTP_HEADER_MAX_LEN];
    _UC          aucSubUri[AI_URI_LEN];
    _UC          aucHost[AI_HOST_LEN];
    _UC          aucETag[128];
    _US          usPort;
    _UC          aucReserv[2];           //for packet alignment
    _SOCKET      hSocket;
    _SSL_HANDLE  hSSL;
    _UI          uiSentCount;
    _UC          aucRequestURL[AI_URI_LEN]; 
    _UC          aucRequestDate[32];  
    _UC          aucAuthorization[64]; 
    _UC          *pucHttpResponse; 
    _UI          uiHttpResponseIndex;
    _UC          *pucAIPicData;
    _UI          uiAiPicUploadIndex;
    _UI          uiAiPicDataLength;
}ST_URL_CONN_SOCKET;
//////////////////////////////////////////////////

// 图片信息
typedef struct stru_CFG_PICTURE_INF_NODE
{
    _UI uiUseFlag;
    _UC ucDispositionID[64];        // 布控id    底库图片ID
    _UC ucDesc[64];                 // 布控时平台下发的图片描述信息
    ST_MOS_LIST_NODE stNode;

}ST_CFG_PICTURE_INF_NODE;
typedef struct stru_CFG_LABELS_INF_NODE // Labels信息
{
    _UI  uiUseFlag;
    _UC  ucLabelID[32];                 // 人脸图片父集ID
    _UC  ucLabelName[32];               // 人脸图片父集名称
    _UI  uiPicType;                     // 人脸图片父集类型
    _UI  uiWBList;                      // 人脸图片父集所属名单 0.都不属于；1.黑名单；2.白名单
    _UC  ucUserID[32];                  // 这组图片所属用户
    ST_MOS_LIST stPictureInfList;       // 图片信息 ST_CFG_PICTURE_INF_NODE
    ST_MOS_LIST_NODE stNode;
}ST_CFG_LABELS_INF_NODE;

// 客流统计区域坐标，只支持1个区域和4个点
typedef struct stru_CFG_HUMAN_COUNT_REGION
{
    _DOUBLE iX[4];
    _DOUBLE iY[4];
}ST_CFG_HUMAN_COUNT_REGION;

typedef struct stru_CFG_UPLOAD_AIFACE_PIC_INF
{
    _UI    uiUseFlag;
    _UI    uiUploadFlag;                     // 上传图片标志
    _UI    uiReqId;                          // 请求ID
    _ULLID lluReqTime;                       // 人脸布控事件请求时间
    _UI    uiReportFlag;                     // 人脸布控事件上报标志 0.未上报 1.已上报
    _ULLID lluReportTimeStamp;               // 人脸布控事件上报应答时间

    _UC   ucDispositionID[64];               // 布控标识
    _UC   ucNotificationID[64];              // 告警标识（流水号）
    _UI   uiNotifyType;                      // 消息类型：1、人脸；2、车牌

    _UC  *pucFaceDataBuf;                    // 人脸/车牌图数据
    _UI   uiFaceDataBufLen;                  // 人脸/车牌图数据长度
    _UC   ucFaceRequestURL[256];             // 人脸/车牌图直连分流的资源池访问地址
    _UC   ucFaceRequestDate[32];             // 人脸/车牌图上传请求所需要的时间参数
    _UC   ucFaceAuthorization[64];           // 人脸/车牌图上传请求所需要的授权凭证

    _UC  *pucBgDataBuf;                      // 原始图像(背景图)数据
    _UI   uiBgDataBufLen;                    // 原始图像(背景图)数据长度
    _UC   ucBgRequestURL[256];               // 原始图像(背景图)直连分流的资源池访问地址
    _UC   ucBgRequestDate[32];               // 原始图像(背景图)上传请求所需要的时间参数
    _UC   ucBgAuthorization[64];             // 原始图像(背景图)上传请求所需要的授权凭证

    ST_CFG_AI_HTTP_TASK stDxUpAIPicAlarmData;// 人脸布控消息上报数据接收
    
    ST_MOS_LIST_NODE stNode;
}ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE;

typedef struct stru_CFG_UPLOAD_AI_ZIP_INF
{
    _UI    uiUseFlag;
    _UI    uiUploadFlag;                      // 上传图片标志

    _UI    uiReqId;                           // AI_ZIP事件请求ID
    _ULLID lluReqTime;                        // AI_ZIP事件请求时间
    _UI    uiReportFlag;                      // AI_ZIP事件上报标志 0.未上报 1.已上报
    _ULLID lluReportTimeStamp;                // AI_ZIP事件上报应答时间

    _UC    ucZipFilePath[128];                // AI_ZIP压缩包文件绝对路径 
    _UC    ucZipRequestURL[256];              // AI_ZIP压缩包直连分流的资源池访问地址
    _UC    ucZipRequestDate[32];              // AI_ZIP压缩包上传请求所需要的时间参数
    _UC    ucZipAuthorization[64];            // AI_ZIP压缩包上传请求所需要的授权凭证

    ST_CFG_AI_HTTP_TASK stDxUpAIZipEventData; // 抓拍ZIP方式上报数据接收
    
    ST_MOS_LIST_NODE stNode;
}ST_CFG_UPLOAD_AI_ZIP_INF_NODE;

typedef struct stru_CFG_UPLOAD_AIPIC_1400_INF
{
    _UI      uiUseFlag;
    _UI      uiUploadFlag;                     // 上传图片标志 0.不需上报 1.需上报 2.json组装完成
    _UI      uiReqId;                          // 请求ID
    _UI      uiAIIoTType;                      // IOT类型                 
    _ULLID   lluAIIoTID;      
    _UI      uiEventId;                        // 上传的图片类型
    _CTIME_T cAlarmTime;                       // 事件触发时间点(秒)
    _ULLID   lluReportTimeStamp;               // 上报应答时间点(秒)
    _UC     *pucBgPicBaseData;                 // 背景图的base数据
    _UI      uiBgPicBaseDataLen;               // 背景图的base数据长度
    _UC     *pucFaceOrCarPicBaseData;          // 抓拍图的base数据
    _UI      uiFaceOrCarPicBaseDataLen;        // 抓拍图的base数据长度
    ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo;   // 厂商上报的图像信息
    ST_MOS_LIST_NODE stNode;
}ST_CFG_UPLOAD_AIPIC_1400_INF_NODE;

// 待下载图片信息
typedef struct stru_CFG_DOWNLOAD_PICTURE_INF
{
    _UI  uiReqId;
    _UI  uiUseFlag;
    _UI  uiWBList;                   // 所属名单 0.都不属于；1.黑名单；2.白名单
    _UI  uiHttpCode;                 // http code
    _UC  ucDispositionID[64];        // 布控id    底库图片ID
    _UC  ucDesc[64];                 // 布控时平台下发的图片描述信息
    _UC  ucPicUrl[512];              // 图片下载地址
    _UC  aucRedirectUrl[512];        // 图片重定向下载地址
    ST_MOS_LIST_NODE stNode;
}ST_CFG_DOWNLOAD_PIC_INF_NODE;
typedef struct stru_CFG_DOWNLOAD_TASK_INF
{
    _UI  uiUseFlag;
    _UC  ucTaskID[16];                          // 任务ID
    _UC  ucUserID[16];                          // 用户标识
    _UI  uiPicType;                             // 图片类型 1、人脸；2、车牌
    ST_MOS_LIST stDownloadPicInfList;           // 待下载图片任务的信息  ST_CFG_DOWNLOAD_PIC_INF_NODE
    ST_MOS_LIST_NODE stNode;
}ST_CFG_DOWNLOAD_TASK_INF_NODE;

typedef struct stru_CFG_AIALARM_PV_NETINF
{
    _UC ucPicRequestUrl[512];                   // 图片上传地址
    _UC ucPicRequestDate[32];                   // 上传请求所需要的时间参数
    _UC ucPicAuthorization[64];                 // 上传请求所需要的授权凭证
    _UC ucVideoRequestUrl[512];                 // 视频上传地址
    _UC ucVideoRequestDate[32];                 // 上传请求所需要的时间参数
    _UC ucVideoAuthorization[64];               // 上传请求所需要的授权凭证
}ST_CFG_AIALARM_PV_NETINF;

// 上传AIIoT告警事件图片和视频的信息
typedef struct stru_CFG_UPLOAD_AIALARM_PV_INF_NODE
{
    _UI uiUseFlag;
    _UI uiReqId;                                    // AI事件请求ID
    _ULLID lluReportTimeStamp;                      // AI事件上报应答时间
    _UI uiReportFlag;                               // AI事件上报标志 0.未上报 1.已上报
    _UI uiPicUploadFlag;                            // AI事件图片上传标记 0.不需要上传 1.需要上传 2. 释放节点
    _UI uiVideoUploadFlag;                          // AI事件视频上传标记 0.不需要上传 1.需要上传 2. 释放节点 
    ST_ZJ_IOT_INF stAIIoTInf;                       // AIIoT告警类型 
    ST_CFG_AIALARM_PV_NETINF  stAIAlarmPVNetInf;    // 上传图片或视频的请求信息
    ST_ZJ_AI_AlARM_UPLOAD_INF stAIAlarmUploadInf;   // 厂家提供 事件信息节点
    ST_MOS_LIST_NODE stNode;
}ST_CFG_UPLOAD_AIALARM_PV_INF_NODE;

typedef struct stru_CFG_COMMON_AI_ABILITY_INF_NODE
{
    _UC aucName[64];
    _UI uiAbility;
    ST_MOS_LIST_NODE stNode;
}ST_CFG_COMMON_AI_ABILITY_INF_NODE;

typedef struct stru_CFG_AI_MNG
{
    _UC  ucInitFlag;
    _UC  ucRunFlag;
    _UI  uiOgctId;

    _HMUTEX  hUpLoadMutex;              // 上传人脸布控图片的锁
    _HMUTEX  hUpLoadZipMutex;           // 上传人脸抓拍图片(ZIP包方式)的锁
    _HMUTEX  hUpLoad1400Mutex;          // 上传人脸抓拍图片(1400方式)的锁
    _HMUTEX  hDownLoadMutex;            // 下载人脸布控图片的锁
    _HMUTEX  hUplaodAIAlarmPVMutex;     // 上传AI告警图片和视频的锁

    _HTHREAD hUpLoadThread;             // 上传人脸布控图片的线程
    _HTHREAD hUpLoadZipThread;          // 上传人脸抓拍图片(ZIP包方式)的线程
    _HTHREAD hDownLoadThread;           // 下载人脸布控图片的线程
    _HTHREAD hUplaodAIAlarmPVThread;    // 上传AI告警图片和视频的线程

    //   Ability
    ST_MOS_LIST stCommonAiAblitityList;                 // AI通用能力列表

    _INT iAiPicMaxNum;                                  // AI端侧识最大存储底图数目

    //   Busi
    _INT iAiPicCnt;                                     // 当前已经存储的AI端侧识别底库图片数目
    ST_MOS_LIST stLabelsInfList;                        // Labels信息             ST_CFG_LABELS_INF_NODE
    _INT iHumanCountFlag;                               // 客流统计开关             0.关，1.开
    _INT iHumanCountInterval;                           // 客流统计事件检测间隔      单位:分钟，默认1分钟
    ST_CFG_HUMAN_COUNT_REGION stHumanCountRegion[1];    // 客流统计区域坐标，只支持1个区域和4个点

    ST_MOS_LIST stDownloadTaskInfList;                  // 待下载布控图片任务的链表           ST_CFG_DOWNLOAD_TASK_INF_NODE
    ST_MOS_LIST stUploadCmdPlatTaskInfList;             // 待上传人脸布控图片到资源池的链表    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE
    ST_MOS_LIST stUploadZipTaskInfList;                 // 待上传AI_ZIP的信息                ST_CFG_UPLOAD_AI_ZIP_INF_NODE
    ST_MOS_LIST stUpload1400PlatTaskInfList;            // 待上传人脸抓拍图片到1400平台的链表  ST_CFG_UPLOAD_AIPIC_1400_INF_NODE
    ST_MOS_LIST stUplaodAIAlarmPVTaskInfList;           // 待上传AI告警图片和视频的链表       ST_CFG_UPLOAD_AIALARM_PV_INF_NODE
    _HQUEUE qIotAIUploadPreQueue;                       // IOTAI事件上报预队列
    _HQUEUE qIotAIUploadRdyQueue;                       // IOTAI事件上报结点队列

    ST_CFG_AI_HTTP_TASK stDxUpHumanCountData;           // 客流统计上报数据接收
}ST_CFG_AI_MNG;

/**************************************************************
***************************************************************/
ST_CFG_AI_MNG *Config_GetAIMng();

_UI Config_GetNewFaceAbility();

_INT Config_InitAIMng();

_INT AI_Task_Destroy();

_INT AI_ProcAiPicTimeOutList();

_INT AI_ProcAiZipTimeOutList();

_INT AI_ProcAiAlarmUploadPVTimeOutList();
/**************************************************************
***************************************************************/
_INT Config_SetCommonAiAbility(_UC *pucName, _INT iAbility);

_INT Config_SetAiMaxPicNum(_INT iAiMaxPicNum);

_INT Config_SetAiCurPicNum(_INT iAiCurPicNum);

_INT Config_SetHumanCountOpenFlag(_INT iHumanCountFlag);

_INT Config_SetHumanCountInterval(_INT iHumanCountInterval);

_INT Config_SetHumanCountRegions(ST_CFG_HUMAN_COUNT_REGION *pstHumanCountRegion);

_INT Config_SetFaceFileCachePath(unsigned char *pucFaceCachePath);

/**************************************************************
******************AI_LABEL***********************************/
ST_AICFG_LABEL *Get_AICfgLabel();

_INT Config_AddAILabelNode(_INT iCamId, _UC *pucLabelID);

_INT Config_DeleteAILabelNode(_INT iCamId, _UC *pucLabelID);

ST_CFG_LABELS_INF_NODE *Config_FindLabelNode(_INT iCamId, _UC *pucLabelID);

_INT Config_SetLabelNodeName(_INT iCamId, _UC *pucLabelID, _UC *pucLabelName);

_INT Config_SetLabelNodeUserID(_INT iCamId, _UC *pucLabelID, _UC *pucUserID);

_INT Config_SetLabelNodePicType(_INT iCamId, _UC *pucLabelID, _UI uiPicType);

_INT Config_SetLabelNodeWBList(_INT iCamId, _UC *pucLabelID, _UI uiWBList);

_INT Config_AddPictureToLabel(_INT iCamId,  _UC *pucLabelID, _UC *pucDesc, _UC *pucDispositionID);

_INT Config_DelPictureToLabel(_INT iCamId,  _UC *pucLabelID, _UC *pucDispositionID);

_INT Config_BeginSyncLabelAndPicture(_INT iCamId);

_INT Config_EndSyncLabelAndPicture(_INT iCamId);
/**************************************************************
***********************AI_DOWN********************************/
_INT Config_AddAIDownloadTaskNode(_INT iCamId, _UC *pucTaskID);

_INT Config_DeleteAIDownloadTaskNode(_INT iCamId, _UC *pucTaskID);

ST_CFG_DOWNLOAD_TASK_INF_NODE *Config_FindDownloadTaskNode(_INT iCamId, _UC *pucTaskID);

_INT Config_SetDownloadTaskNodeUserID(_INT iCamId, _UC *pucTaskID, _UC *pucUserID);

_INT Config_SetDownloadTaskNodePicType(_INT iCamId, _UC *pucTaskID, _UI uiPicType);

_INT Config_AddPictureToDownloadTask(_INT iCamId, _UC *pucTaskID, _UI uiWBList, _UC *pucDesc, _UC *pucDispositionID, _UC *pucPicUrl);

_INT Config_GetPictureToDownloadTaskNodeCount(_INT iCamId, _UC *pucTaskID, _UI *puiPictureToDownloadNodeCount);

_INT Config_DelPictureToDownloadTask(_INT iCamId, _UC *pucTaskID, _UC *pucDispositionID);

_INT AI_PubUpgradeDownPicStatus(ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskInfNode, ST_CFG_DOWNLOAD_PIC_INF_NODE  *pstDownloadPicInfNode,_INT istatus);
/**************************************************************
***********************AI_FACE_PIC***********************************/
_INT Config_AddUploadAIFacePicTaskNode(_INT iCamId, _UI uiReqId, _LLID lluHappenTime, _UC *pucNotificationID, ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInf);

ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *Config_FindUploadAIFacePicTaskNode(_INT iCamId, _UI uiReqId);

_INT Config_SetUploadAIFacePicTaskNodeInfo(_INT iCamId, ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNodeBak);

_INT Config_SetUploadAIFacePicTaskNodeReportInf(_INT iCamId, _UI uiReqId, _UI uiReportFlag, _ULLID lluReportTimeStamp);

_INT Config_DelUploadAIFacePicTaskNode(_INT iCamId, _UI uiReqId);

_INT Config_GetUploadAIFacePicTaskNodeCount(_INT iCamId, _UI *puiAIFaceUploadPicNodeCount);
/**************************************************************
************************AI_ZIP***********************************/
_INT Config_AddUploadAIZipTaskNode(_INT iCamId, _UI  uiReqId, _LLID lluHappenTime, _UC *pucZipFilePath);

ST_CFG_UPLOAD_AI_ZIP_INF_NODE *Config_FindUploadAIZipTaskNode(_INT iCamId, _UI uiReqId);

_INT Config_SetUploadAIZipTaskNodeInfo(_INT iCamId, ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNodeBak);

_INT Config_SetUploadAIZipTaskNodeReportInf(_INT iCamId, _UI uiReqId, _UI uiReportFlag, _ULLID lluReportTimeStamp);

_INT Config_DelUploadAIZipTaskNode(_INT iCamId, _UI uiReqId);

_INT Config_GetUploadAIZipTaskNodeCount(_INT iCamId, _UI *puiAIZipUploadPicNodeCount);
/**************************************************************
*************************AIAlARM_UPLOAD_PV********************/
_INT Config_AddUploadAIAlarmPVTaskNode(_INT iCamId, _UI uiReqId, ST_ZJ_IOT_INF* pstIoTInf, ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf);

ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *Config_FindUploadAIAlarmPVTaskNode(_INT iCamId, _UI uiReqId);

ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *Config_FindUploadAIAlarmPVTaskNodeByPath(_INT iCamId, _UC *pucPath);

_INT Config_SetUploadAIAlarmPVTaskNodeNetInfo(_INT iCamId, _UI uiReqId, ST_CFG_AIALARM_PV_NETINF* pstAIAlarmPVNetInf);

_INT Config_SetUploadAIAlarmPVTaskNodeReportInf(_INT iCamId, _UI uiReqId, _UI uiReportFlag, _ULLID lluReportTimeStamp);

_INT Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(_INT iCamId, _UI uiReqId, _UI uiPicUploadFlag);

_INT Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(_INT iCamId, _UI uiReqId, _UI uiVideoUploadFlag);

_INT Config_SetUploadAIAlarmPVTaskNodePicUploadFlagByPath(_INT iCamId, _UC* pucPath, _UI uiPicUploadFlag);

_INT Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlagByPath(_INT iCamId, _UC* pucPath, _UI uiVideoUploadFlag);

_INT Config_DelUploadAIAlarmPVTaskNode(_INT iCamId, _UI uiReqId);

_INT Config_GetUploadAIAlarmPVTaskNodeCount(_INT iCamId, _UI *puiUploadAIAlarmPVNodeCount);
/**************************************************************
**************************************************************/
_VPTR Config_BuildAIObject(_UI uiCfgType, EN_BUILD_DOWNTASK_FLAG enBuildDownTaskFlag);

_UC *Config_BuildAIJson(_UI uiCfgType);

_INT Config_ParseAIJson(_UC *pStrJson,_UI uiCfgType);
/**************************************************************
***************************************************************/
_VOID AI_ProcDownAIPicture();

_INT  AI_DownLoadAiPictureProc(ST_CFG_DOWNLOAD_PIC_INF_NODE  *pstDownloadPicInfNode);

_VOID AI_ProcUploadBgAndFacePic();

_VOID AI_ProcUploadAIRecZip();

_VOID AI_ProcUplaodAIAlarmPV();
/**************************************************************
***************************************************************/
#ifdef __cplusplus
}
#endif

#endif

