#ifndef CONFIG_TIMEPOLICY_H
#define CONFIG_TIMEPOLICY_H


#ifdef __cplusplus
extern "C" {
#endif

typedef struct str_cfg_common_param
{
    _UI uiStatus;

}ST_CFG_COMMON_PARM;

typedef struct str_cfg_timepolicy_node
{
    _UI uiUseFlag;              // 定时任务节点使用标记
    _UI uiWorkFlag;             // 定时任务工作状态 1 正在工作 0 没有工作
    _UI uiOpenFlag;             // 定时任务的开关
    _UC aucPolicyId[64];        // 策略ID string类型
    _UC aucPolicyName[32];      // 策略名
    _UI uiStartTime;            // 定时任务开始时间点
    _UI uiEndTime;              // 定时任务结束时间点
    _UI uiSpanFlag;             // 定时任务时间段是否跨天
    _UI uiLoopType;             // 0 循环定时任务 ， 1 一次性定时任务
    _UI uiWeekFlag;             // 循环定时任务 周几 掩码方式
    _UC aucDay[16];             // 一次性定时任务 执行日期 字符串
    _UI uiSceneId;              // 场景ID 目前未使用
    ST_MOS_LIST stOutputList;   // 定时任务的处理动作 ST_CFG_OUTPUT_NODE
    ST_MOS_LIST_NODE stNode;
}ST_CFG_TIMEPOLICY_NODE;

ST_MOS_LIST *Config_GetTimePolicyList();

ST_CFG_TIMEPOLICY_NODE *Config_FindTimePolicyNode(_UC *pucPolicyId);

ST_CFG_TIMEPOLICY_NODE* Config_FindOrCreatTimePolicy(_UC *pucPolicyId);

_INT Config_SetTimePolicyOpenFlag(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiOpenFlag);

_INT Config_SetTimePolicyName(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UC *pucPolicyName);

_INT Config_SetTimePolicyTime(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiLoopType, _UC *pucDay, _UI uiWeekFlag, _UI uiStartTime, _UI uiEndTime, _UI uiSpanFlag);

_INT Config_SetTimePolicyOutPutWorkFlag(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiWorkFlag);

_INT Config_SetTimePolicyOutPutSceneId(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiSceneId);

_INT Config_SetTimePolicyOutPutList(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, ST_MOS_LIST *pstOutputList);

_INT Config_AddTimerPolicyOutput(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiOutIotType, _LLID lluOutIotId, _UC *pucParam);

_INT Config_DeleteTimePolicyByStr(_UC *pucPolicyId);

_INT Config_BegainSyncTimerPolicy();

_INT Config_EndSyncTimerPolicy();

_INT Config_TimePolicyDestroy();

/****************************************************************************
*****************************************************************************/
_VPTR Config_BuildTimerPolicyObject(_UI uiCfgType);

_UC *Config_BuildTimePolicyJson(_UI uiCfgType);

_INT Config_ParseTimePolicyJson(_UC *pStrJson, _UI uiCfgType);

#ifdef __cplusplus
}
#endif

#endif


