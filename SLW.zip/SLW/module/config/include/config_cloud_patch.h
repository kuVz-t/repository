#ifndef _CONFIG_CLOUD_PATCH_H
#define _CONFIG_CLOUD_PATCH_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "adpt_json_adapt.h"
#include "cloudstg_api.h"

_INT Config_AddOneCloudPatchInfoToCfgTaskList(_UC *pucUuid, _INT iCamId, _INT iEventType, _INT iTaskType, _INT iStorageType, _INT iCloudUpLoadMode, _UI uiDuration, _CTIME_T tCreateTime, _CTIME_T tFailTime);

_INT Config_ModifyOneCloudPatchInfoFromCfgTaskList(_UC *pucUuid, _INT iCamId, _INT iEventType, _INT iTaskType, _INT iStorageType, _INT iCloudUpLoadMode, _UI uiDuration, _CTIME_T tCreateTime, _CTIME_T tFailTime);

_INT Config_RemoveOneCloudPatchInfoFromCfgTaskList(_UC *pucUuid, _INT iCamId);

_VPTR Config_BuildCloudPatchSetObject();

_UC *Config_BuildCloudPatchSetJson();

_INT Config_ParseCloudPatchSetJson(_UC *pStrJson);

#ifdef __cplusplus
}
#endif
#endif