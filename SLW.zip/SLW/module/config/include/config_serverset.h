#ifndef CONFIG_SERVERSET_H
#define CONFIG_SERVERSET_H

#ifdef __cplusplus
extern "C" {
#endif

#define SERVERSET_LOGSTR     (_UC*)"SERVERSET" 

typedef struct stru_Config_Package_Node
{
    _UI uiUseFlag;
    _UI uiPackageId;
    _UC aucStartData[24];
    _UC aucExpireData[24];
    _UC aucUid[32];
    ST_MOS_LIST_NODE stNode;
}ST_CFG_PACKAGE_NODE;


typedef struct stru_CFG_SERVERSET_MNG
{
    _UI uiCamResolution;
    _UI uiIotHubLimit;
    ST_MOS_LIST stPackageList;
}ST_CFG_SERVERSET_MNG;


ST_CFG_SERVERSET_MNG *Config_GetServerSetMng();

_INT ServerSet_Task_Destroy();

_INT Config_SetDeviceLimitAbility(_UI uiCamResolution,_UI uiHubLimit);

_INT Config_AddNewChargePackage(ST_CFG_PACKAGE_NODE *pstNewChargePackage);

_INT Config_RemoveChargePackage(_UI uiChargePackageId);

_VPTR Config_BuildServerSetObject();

_UC *Config_BuildServerSetJson();

_INT Config_ParseServerSetJson(_UC *pStrJson);

#ifdef __cplusplus
}
#endif


#endif


