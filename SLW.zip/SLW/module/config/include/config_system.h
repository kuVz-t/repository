#ifndef CONFIG_SYSTEM_H
#define CONFIG_SYSTEM_H

#ifdef __cplusplus
extern "C" {
#endif
#include "config_type.h"
typedef struct stru_CFG_SYSTEM_MNG
{
    _INT   iCtrlType;
    _INT   iTimeZone;
    _INT   iSetZoneFlag;
    _UI    uiChargeFlag;
    _UI    uiSetDomainFlag;                     // 是否已经成功设置过动态域名 1:是,0:否

    _INT   iPuType;                             // 能力平台类型  管理平台分配
    _INT   iCloudUploadLogLe;                   // 云存日志上传等级
    _UC    aucPuAddr[CFG_STRING_MAXLEN + 4];    // 能力平台的地址, 管理平台分配
    _UC    aucAlarmAddr[CFG_STRING_MAXLEN + 4]; // 事件告警平台的地址
    _UC    aucCloudAddr[CFG_STRING_MAXLEN + 4]; // 云存储平台地址
    
    _UC    aucDevSN[CFG_STRING_LEN + 4];        // 厂商的序列号
    _UC    aucDevCTEI[CFG_CTEI_LEN + 4];    
    _UC    aucSignV[CFG_STRING_MAXLEN]; 
    
    _UC    aucDevUID[CFG_STRING_LEN];       // 设备uid
    _UC    aucEncDevUID[CFG_STRING_LEN];    // 设备aes base64 uid
    _UC    aucDevkey[CFG_STRING_LEN + 4];   // 设备KEY

    _UC    aucCompanyId[CFG_STRING_COMMONLEN + 4];
    _UC    aucAppId[CFG_STRING_COMMONLEN + 4];
    
    _UC    aucSignAddr[CFG_STRING_MAXLEN + 4];   // 媒体管理平台
    _UC    aucDid[CFG_STRING_COMMONLEN + 4];     // 媒体平台的设备ID

#ifdef DX_SECOND_LINK
    _UC    aucGBDevCTEI[CFG_CTEI_LEN + 4];  
    _UC    aucGBSignAddr[CFG_STRING_MAXLEN + 4];   // 媒体管理平台
#endif
    _UC    aucGBDid[CFG_STRING_COMMONLEN + 4];     // 媒体平台的设备ID
    _UC    aucGa1400Addr[CFG_STRING_MAXLEN + 4];   // GA1400平台地址
    _UC    aucRouteAddr[CFG_STRING_MAXLEN + 4];    // 域名调度地址
    _UC    aucReportAddr[CFG_STRING_MAXLEN + 4];   // 自注册地址
    _UC    aucOtherAddr[CFG_STRING_MAXLEN + 4];    // 其他功能

    _UC    aucImsAddr[CFG_STRING_MAXLEN + 4];      // IMS平台地址
}ST_CFG_SYSTEM_MNG;

ST_CFG_SYSTEM_MNG *Config_GetSystemMng();

_INT Config_SetCompanyInfo(_UC *pucCompanyId,_UC* pucAppId);

_INT Config_SetCTEIID(_UC* pucCTEI);

_INT Config_SetChargeFlag(_INT iChargeFlag);

_INT Config_SetDomainFlag(_INT iSetDomainFlag);

_INT Config_SetLocalTimeZone(_INT iTimeZone);

_INT Config_SetDevCtrlType(_INT iCtrlType);

_INT Config_SetAblPlatAddr(_INT iPutype,_UC *pucPuAddr);

_INT Config_SetAlarmPlatAddr(_UC *pucAlarmAddr);

_INT Config_SetCloudPlatAddr(_UC *pucCloudAddr);

_INT Config_SetReportPlatAddr(_UC *pucReportAddr);

_INT Config_SetOtherPlatAddr(_UC *pucOtherAddr);

_INT Config_SetRoutePlatAddr(_UC *pucRouteAddr);

_INT Config_SetMngPlatDevUID(_UC *pucDevUID, _UC *pucDevKey);

_INT Config_SetDevSn(_UC *pucDevSn);

// 媒体平台
_INT Config_SetMediaPlatSignAddr(_UC *pucSignAddr);
_INT Config_SetMediaPlatDeviceId(_UC *pucDid);

_INT Config_SetGa1400PlatAddr(_UC *pucGa1400Addr);

_INT Config_SetImsPlatAddr(_UC *pucImsAddr);

#ifdef DX_SECOND_LINK
_INT Config_SetGBMediaPlatSignAddr(_UC *pucSignAddr);
_INT Config_SetGBMediaPlatDeviceId(_UC *pucDid);
_INT Config_SetGBCTEIID(_UC* pucCTEI);
#endif
/******************************************************
*******************************************************/

_VPTR Config_BuildSystemObject();

_UC *Config_BuildSystemJson();

_INT Config_ParseSystemJson(_UC *pStrJson);

#ifdef __cplusplus
}
#endif
#endif


