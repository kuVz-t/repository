#ifndef _CONFIG_CAMERA_H
#define _CONFIG_CAMERA_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "zj_type.h"

typedef struct str_CFG_VIDEODES
{
    _UI uiLensType;
    ST_ZJ_VIDEO_CIRCLE stCircle;
    ST_ZJ_VIDEO_PARAM stVideoPara;
    ST_ZJ_VIDEO_DISTORTION stDistortion; // 扭曲度
}ST_CFG_VIDEODES;

typedef struct str_CFG_STREAMER_NODE
{
    _UI  uiStreamId;
    _UI  uiCapAbility; //  支持的编码能力
    _UI  uiResolutionAbility;  // 支持的编码分辨率
    ST_CFG_VIDEODES stVideoDes;
    ST_MOS_LIST_NODE stNode;
}ST_CFG_STREAMER_NODE;

typedef struct stru_CFG_LEN_NODE
{
    _INT iLenId;
    _INT iLenType;
    _DOUBLE focalLenth;    //焦距
    _UC aucLenName[CFG_STRING_LEN];
    ST_MOS_LIST_NODE stNode;
}ST_CFG_LEN_NODE;

typedef struct stru_CFG_SERSORS
{
    _US usCurLenId;
    _US usLenMaxCount;
    _US usDefaultLenId;
    _US usAutoFlag;
    ST_MOS_LIST stLensList; //ST_CFG_LEN_NODE
}ST_CFG_SERSORS;

// 通用外接设备插入状态
typedef struct stru_CFG_COMMON_EXDEV_INSERTSTATUS_NODE
{
    _UC  aucExDevName[64];
    _INT iInsertStatus;
    ST_MOS_LIST_NODE stNode;
}ST_CFG_COMMON_EXDEV_INSERTSTATUS_NODE;

typedef struct stru_CFG_CAMERA_MNG
{
    // 设备的能力
    _UI uiStreamCnt;
    _UI uiVoicePlayAbility;                 // 0 不支持, 1 单工 , 双工
    _UI uiMicPhoneAbility;
    _UI uiOSDSetAbility;
    _UI uiOSDSetExpandAbility;              // OSD自定义(文本)拓展能力/四角水印同时显示
    _UI uiOSDCommonSetAbility;              // OSD默认(时间)水印设置能力 0.不支持，1.支持(支持0-10十一种水印格式), (预留2、3支持更多时间水印格式)
    _UI uiIrLedAbility;
    _UI uiInversionAbility;
    _UI uiStorageAbility; 
    _UI uiSetPresetAbility;                 // 是否支持预置位设置
    _UI uiWDRAbility;                       // 设备宽动态能力
    _UI uiRingToneSetAbility;               // 铃声设置能力;0.不支持；1.支持选择；2.支持自定义”
    _UI uiRingToneDecAbilty;                // 铃声编码能力
    _UI uiGAT1400Ability;                   // 1400能力
    _UI uiIPv6Ability;                      // IPv6能力支持, 0.不支持，1.支持
    // _UI uiIPv6Usability;                    // IPv6可用标志，0.不可用，1.可用
    _UI uiInterGAT1400Ability;              // 内嵌1400能力
    _UI uiP2PAbility;                       // P2P能力
    _UI uiExternalSpeakerAbility;           // 外接扬声器能力(音柱)，0.不支持，1.支持
    _UI uiZoomAbility;                      // 变倍能力值；0.不支持，1.支持
    _UI uiFocusAbility;                     // 变焦能力值；0.不支持，1.支持
    _UI uiQualityProbeAbility;				// 质量探针能力
    _UI uiCloudBroadcastAbility;            // 云广播能力, 0.不支持，1.支持
    _UI uiSliceCloudAbility;                // 云端切片支持, 0.不支持，1.支持
    _UI uiStsCloudAbility;                  // 云端sts支持, 0.不支持，1.支持
    _UI uiAlarmSoundSetAbility;             // 报警声音自定义能力，0.不支持，1.支持
    _UI uiAISwitchReturnErrAbility;         // AI开关返回错误能力，0.不支持，1.支持
    _UI uiPolicyDomainAbility;              // 单元化能力支持, 0.不支持，1.支持
    _UI uiMultiFocalLenthAbility;           // 多目摄像头能力, 0.不支持, 1.支持
    _UI uiIMSAbility;                       // IMS通话能力   0.不支持 1.支持IMS音频通话 2.支持IMS视频通话能力(VoLTE通话)
    _UI uiSuperCodesAbility;                // 超级编码能力,       0.不支持，1.支持
    _UI uiPhysicalMaskAbility;              // 物理遮蔽能力, 0.不支持，1.支持
    _UI uiAlarmSoundExecuteTimeAbility;     // 报警声音多时间段执行能力, 0.不支持，1.支持
    _UI uiAlarmSoundRemoteAbility;          // 支持远程触发播放能力(支持3468-播放指定警报音的信令下发), 0.不支持，1.支持
    _UI uiSilenceRestartAbility;            // 静默重启播放能力, 0.不支持，1.支持 SDK默认支持
    _UI uiEventCloudAppendAbility;          // 事件云存追加能力，0.不支持，1.支持 SDK默认支持

    _UI uiWithScreenAbility;                // 具备屏幕能力, 0.不支持，1.支持
    _UI uiVideoPlayAbility;                 // 业务支持双向视频能力,当uiWithScreenAbility=1时有效，详见EN_ZJ_VIDEOPLAY_ABILITY，若IMS与P2P支持双向视频通话，则uiVideoPlayAbility=EN_ZJ_VIDEOPLAY_ABILITY_P2P|EN_ZJ_VIDEOPLAY_ABILITY_IMS 
    _UI uiCallButtonAbility;                // 呼出物理按键能力值, 0.不支持，1.支持
    _UI uiHangUpButtonAbility;              // 挂断物理按键能力值, 0.不支持，1.支持

    _UI uiUploadDevStatusReqId;             // 设备状态（休眠、唤醒）上报请求ID 0x3410
    _HMUTEX hUploadDevStatusMutex;          // 设备状态（休眠、唤醒）上报请求锁 

    // 设备的配置
    _UI uiCamOpenFlag;                      // 镜头关闭
    _UI uiMicOpenFlag;
    _UI uiCamDataInputMode;                 // 缓存区取数据时是否不加锁 0:使用 1:不使用
    _UI uiSpkOpenFlag;          
    _UI uiDisPlayOpenFlag;                  // 设备屏幕显示标志
    _UI uiCurInversionType;                 // 当前上下翻转
    _UI uiCurIRWorkMode;                    // 白光红外的 工作 模式
    _UI uiCurScanFrequery;                  // 当前扫描频率
    _UI uiStorageStatus;                    // 当前tf 是否插入
    _UI uiCurMicVolume;                     // 当前音频采集音量 0-100大小
    _UI uiWDRFlag;                          // WDR开关

    _UI uiOSDCommonSwitch;                  // OSD默认(时间)水印显示开关    0.不显示 1.显示
    _UI uiOSDCommonPosition;                // OSD默认(时间)水印位置        参考: EN_ZJ_OSD_POSITION_TYPE 0.默认；1.左上；2.左下；3.右上；4.右下
    _UI uiOSDCommonFormat;                  // OSD默认(时间)水印格式        参考: EN_ZJ_OSD_TIMEFORMAT_TYPE

    _UI uiOSDCustomSwitch;                  // OSD自定义(文本)水印显示开关  0.不显示 1.显示
    _UI uiOSDPostion;                       // OSD自定义(文本)水印位置      参考: EN_ZJ_OSD_POSITION_TYPE 0.默认；1.左上；2.左下；3.右上；4.右下
    _UC ucOSDName[CFG_STRING_BIGMAXLEN];    // OSD自定义(文本)水印内容      格式:UTF-8，最大支持512字节
    _UI uiOSDCustomMode;                    // OSD自定义(文本)水印模式      0.默认，只能显示一个位置水印；1.支持同时显示四个位置水印
    _UC aucOSDTopLeftName[CFG_STRING_BIGMAXLEN];    // OSD左上自定义(文本),四角水印
    _UC aucOSDLowerLeftName[CFG_STRING_BIGMAXLEN];  // OSD左下自定义(文本),四角水印
    _UC aucOSDTopRightName[CFG_STRING_BIGMAXLEN];   // OSD右上自定义(文本),四角水印
    _UC aucOSDLowerRightName[CFG_STRING_BIGMAXLEN]; // OSD右下自定义(文本),四角水印

    _UI uiGAT1400Switch;                    // 1400 功能开关 0.关闭，1.开启
    _UI uiGAT1400UploadInterval;            // 1400 上传图片间隔
    _UC ucGAT1400ID[CFG_STRING_COMMONLEN];  // 1400 ID 20位
    _UC ucGAT1400Domain[CFG_STRING_LEN];    // 1400 配置接口域名
    _HMUTEX hGAT1400Mutex;                  // 1400 配置的锁

    _UI uiExternalSpeakerStatus;            // 外接扬声器连接状态(音柱), 0.不在线，1.在线
    _UI uiSuperCodesStatus;                 // 超级编码开关状态 0关闭，1打开
    _UI uiMsgConnectNetType;                // 信令连接网络类型，0.IPv4，1.IPv6
    _UI uiIPv6Switch;                       // IPv6开关标志，0.关，1.开
    _UC aucLocalIPv6Addr[CFG_STRING_LEN];   // 设备本地IPv6地址
    ST_MOS_LIST stStreamerList;             // ST_CFG_STREAMER_NODE
    ST_ZJ_AUDIO_PARAM stAudioParm;
    ST_CFG_SERSORS    stSensors;
    ST_ZJ_EXTERNAL_SPEAKER_INFO stExternalSpeakerInfo;  // 外接扬声器(音柱)信息

    ST_ZJ_VIDEOPLAY_SUPPORT_INFO stVideoPlaySupport;      // 双向视频通话对端出流支持能力信息（属于能力上报）
    ST_ZJ_SCREEN_HARDWARE_INFO   stScreenHardwareInf;     // 带屏设备的屏幕硬件属性
    ST_ZJ_VIDEO_PARAM            stVideoPlayInf;          // 双向视频通话对端出流信息

    _INT iEventCloudSwitch;                 // 事件云存追加开关
    _INT iEventCloudMaxTime;                // 事件云存最大秒数
    _INT iEventCloudMinTime;                // 事件云存最小秒数
    _INT iEventCloudDetectTime;             // 事件云存检测秒数
    _INT iEventCloudAppendTime;             // 事件云存追加录制秒数
    // ExDevInsertStatus
    ST_MOS_LIST stCommonExDevInsertStatusList; // 通用外接设备插入状态列表 ST_CFG_COMMON_EXDEV_INSERTSTATUS_NODE
}ST_CFG_CAMERA_MNG;

ST_CFG_CAMERA_MNG *Config_GetCamaraMng();

_INT Config_InitCamerMng();

/**********************************************************************
************************************************************************/
_INT Config_SetLensMaxCount(_INT iLensCount);

_INT Config_SetLensInf(_INT iLenId,_UC *pucLenName,EN_ZJ_CAMERA_LENS_TYPE enLensType,_DOUBLE focalLenth);

_INT Config_SetEnableLenId(_INT iEnableLenId);

_INT Config_SetDefaultLenId(_INT iDefaultLenId, _INT iAutoFlag);

ST_CFG_LEN_NODE *Config_GetCurLenNode();

// 能力设置
_INT Config_SetCameraStreamCount(_INT iCamIndex, _UI iStreamCount);

_INT Config_SetCameraVoicePlayAbility(_INT iCamId,_UI uiVoicePlayAbility);

_INT Config_SetCameraCloudBroadCastAbility(_INT iCamId,_UI uiCloudBroadcastAbility);

_INT Config_SetCameraMicPhoneAbility(_INT iCamId,_UI uiMicPhoneAbility);

_INT Config_SetCameraOSDAbility(_INT iCamId,_UI uiOSDSetAbility);

_INT Config_SetCameraOSDExpandAbility(_INT iCamId,_UI uiOSDSetExpandAbility);

_INT Config_SetCameraOSDCommonSetAbility(_INT iCamId,_UI uiOSDCommonSetAbility);

_INT Config_SetCameraIRLedAbility(_INT iCamId,_UI uiIrLedAbility);

_INT Config_SetCameraRotateAbility(_INT iCamId,_UI uiImageInversionAbility);

_INT Config_SetCameraWdrAbility(_INT iCamId,_UI uiWDRAbility);
_INT Config_SetCameraIMSAbility(_INT iCamId,_UI uiIMSAbility);
_INT Config_SetIPv6Ability(_INT iCamId, _UI uiIPv6Ability);

_INT Config_SetCamerStorageAbility(_INT iCamID, _UI uiStorageAbility);

_INT Config_SetStreamCaptureAbility(_INT iCamId,_INT iStreamId,_UI uiCaptureAbility);

_INT Config_SetStreamResolutionAbility(_INT iCamId,_INT iStreamId,_UI uiResolutionAbility);

_INT Config_SetCameraP2pAbility(_INT iCamId,_UI uiP2pAbility);

_INT Config_SetCameraPolicyDomainAbility(_INT iCamId,_UI uiPolicyDomainAbility);

_INT Config_SetCameraPhysicalMaskAbility(_INT iCamId, _UI uiPhysicalMaskAbility);

_INT Config_SetCameraAlarmSoundExecuteTimeAbility(_INT iCamId, _UI uiAlarmSoundExecuteTimeAbility);

_INT Config_SetCameraSuperCodesAbility(_INT iCamId, _UI uiSuperCodesAbility);

_INT Config_SetCameraSuperCodesStatus(_INT iCamID, _UI uiSuperCodesStatus);

_INT Config_SetCameraExternalSpeakerAbility(_INT iCamId,_UI uiExternalSpeakerAbility);

_INT Config_SetCameraExternalSpeakerStatus(_INT iCamID, _UI uiConnectStatus, ST_ZJ_EXTERNAL_SPEAKER_INFO *pstInfo);

_INT Config_SetCameraWithScreenAbility(_INT iCamId, _UI uiWithScreenAbility);

_INT Config_SetCameraVideoPlayAbility(_INT iCamId, _UI uiVideoPlayAbility);

_INT Config_SetCameraCallButtonAbility(_INT iCamId, _UI uiCallButtonAbility);

_INT Config_SetCameraHangUpButtonAbility(_INT iCamId, _UI uiHangUpButtonAbility);

_INT Config_SetCameraVideoPlaySupportAbility(_INT iCamID, ST_ZJ_VIDEOPLAY_SUPPORT_INFO *pstVideoPlaySupportAbility);

_INT Config_SetCameraScreenHardwareInfo(_INT iCamID, ST_ZJ_SCREEN_HARDWARE_INFO *pstScreenHardwareInf);

_INT Config_SetCameraVideoPlayInfo(_INT iCamID, ST_ZJ_VIDEO_PARAM *pstVideoPlayInf);

_INT Config_SetCameraZoomAbility(_INT iCamId,_UI uiZoomAbility);

_INT Config_SetCameraFocusAbility(_INT iCamId,_UI uiFocusAbility);

_INT Config_SetCameraQualityProbeAbility(_INT iCamId,_UI uiQualityProbeAbility);

_INT Config_SetCameraCustomizeAlarmSoundAbility(_INT iCamId,_UI uiCustimizeAbility);

_INT Config_SetCameraAISwitchReturnErrAbility(_INT iCamId,_UI uiReturnErrAbility);

_INT Config_SetCameraMultiFocalLenthAbility(_UI uiMultiFocalLenthAbility);

_INT Config_SetCameraSilenceRestartAbility(_INT iCamId, _UI uiSilenceRestartAbility);

_INT Config_SetCameraAlarmSoundRemoteAbility(_INT iCamId, _UI uiAlarmSoundRemoteAbility);

_INT Config_SetEventCloudAppendAbility(_INT iCamId, _UI uiEventCloudAppendAbility);

_INT Config_SetCamerOpenFlag(_INT iCamID, _UI uiCamOpenFlag);

_INT Config_SetCamerMicOpenFlag(_INT iCamID, _UI uiMicOpenFlag);

_INT Config_SetCamerSpkOpenFlag(_INT iCamID, _UI uiSpkOpenFlag);

_INT Config_SetCamerDisplayOpenFlag(_INT iCamID, _UI uiDisPlayOpenFlag);

_INT Config_SetCameraDataInputMode(_INT iCamID, _UI uiCamDataInputMode);

_INT Config_SetCamerCurInversionType(_INT iCamID, _UI uiCurRotateType);

_INT Config_SetCamerCurOSDInfo(_INT iCamID, _UI uiDisplayFlag, _UI uicurOSDPos, _UC* ucCurOSDName);

_INT Config_SetCamerCurOSDInfoEx(_INT iCamID, _UI uiDisplayFlag, _UC *pucTopLeftName, _UC *pucLowerLeftName, _UC *pucTopRightName,_UC *pucLowerRightName);

_INT Config_SetCamerCurTimeOSDDisplay(_INT iCamID, _UI iDisplayFlag);

_INT Config_SetCamerCurCustomOSDDisplay(_INT iCamID, _UI iDisplayFlag);

_INT Config_SetCamerCurOSDCommonInfo(_INT iCamID, _UI uiOSDCommonPosition, _UI uiOSDCommonFormat);

_INT Config_SetCamerCurIRWorkMode(_INT iCamID, _UI uiCurIRWorkMode);

_INT Config_SetCamerCurScanFrequery(_INT iCamID, _UI uiCurScanFrequery);

_INT Config_SetCamerStorageStatus(_INT iCamID, _UI uiStorageStatus);

_INT Config_SetCamVolume(_INT iCamId,_INT iVolume);

_INT Config_SetCameraStreamParam(_INT iCamID,_INT iStreamID, ST_ZJ_VIDEO_PARAM* pstVideoParam);

_INT Config_SetStreamerFisheyeInf(_INT iCamID,_INT iStreamerId,ST_ZJ_VIDEO_CIRCLE *pstCircle);

_INT Config_SetStreamerDistortion(_INT iCamID,_INT iStreamerId,ST_ZJ_VIDEO_DISTORTION *pstDistortion);

_INT Config_SetCamerWDR(_INT iCamID, _UI uiOpenFlag);

_INT Config_SetCamerGat1400Switch(_INT iCamID, _UI uiGat1400Switch);

_INT Config_SetCamerIPv6Switch(_INT iCamID, _UI uiIPv6Switch);

_INT Config_SetCamerMsgConnectNetType(_INT iCamID, _UI uiMsgConnectNetType);

_INT Config_GetCamerGat1400Switch(_INT iCamID);

_INT Config_SetCamerGat1400UploadInterval(_INT iCamID, _UI uiGAT1400UploadInterval);

_INT Config_GetCamerGat1400UploadInterval(_INT iCamID);

_INT Config_SetCamerGat1400Info(_INT iCamID, _UC *pucGAT1400ID, _UC *pucGAT1400Domain);

_INT Config_SetCamerLocalIPv6Addr(_INT iCamID, _UC *pucLocalIPv6Addr);

ST_CFG_CAMERA_MNG *Config_GetCamaraMng();

ST_CFG_STREAMER_NODE *Config_GetStreamerNode(_INT iCamid,_UI uiStreamid);

ST_CFG_VIDEODES *Config_GetVideoDes(_INT iCamid,_INT iStreamid);

/*音频 配置信息*/ 
_INT Config_SetCamAudioParam(_UI iCamId,ST_ZJ_AUDIO_PARAM *pstAudioParm);

ST_ZJ_AUDIO_PARAM* Config_GetCamAudioParm(_UI uiCamId);

//uiDecAblity :EN_ZJ_AUDIOENC_TYPE
_INT Config_SetRingToneAbilty(_UI uiBSupport,_UI uiDecAblity);

_INT Config_FreeCameraMng();

// 通用外接设备插入状态   0.未插入 1.已插入
_INT Config_SeCommonExDevInsertStatus(_UC *pucExDevName, _INT iInsertStatus);

_INT Config_SetEventCloudSwitch(_INT iEventCloudSwitch);

_INT Config_SetEventCloudMaxTime(_INT iEventCloudMaxTime);

_INT Config_SetEventCloudMinTime(_INT iEventCloudMinTime);

_INT Config_SetEventCloudDetectTime(_INT iEventCloudDetectTime);

_INT Config_SetEventCloudAppendTime(_INT iEventCloudAppendTime);
/*********************************************************************************
配置的build 和 parse 
**********************************************************************************/
_VPTR Config_BuildCameraObject(_UI uiCfgType);

_UC *Config_BuildCameraJson(_UI uiCfgType);

_INT Config_ParseCameraJson(_UC *pStrJson,_UI uiCfgType);

#ifdef __cplusplus
}
#endif

#endif

