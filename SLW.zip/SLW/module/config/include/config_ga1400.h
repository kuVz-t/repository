#ifndef _CONFIG_GA1400_H
#define _CONFIG_GA1400_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "zj_type.h"


_INT Config_SetCameraGat1400Ability(_INT iCamId,_UI uiGAT1400Ability);

/**************************************************************
************************AIPIC_1400*****************************/
#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDE
_INT Config_AddUploadAIPic1400TaskNode(_INT iCamId, _UI  uiReqId, _UI uiAIIoTType, _ULLID lluAIIoTID, _UI uiEventId, ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInfo);

ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *Config_FindUploadAIPic1400TaskNode(_INT iCamId, _UI uiReqId);

_INT Config_SetUploadAIPic1400TaskNodeUploadFlag(_INT iCamId, _UI uiReqId, _UI uiUploadFlag);

_INT Config_DelUploadAIPic1400TaskNode(_INT iCamId, _UI uiReqId);

_INT Config_GetUploadAIPic1400TaskNodeCount(_INT iCamId, _UI *puiGa1400UploadPicNodeCount);
#endif

#ifdef __cplusplus
}
#endif

#endif