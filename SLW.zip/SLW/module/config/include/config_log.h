#ifndef CONFIG_LOG_H
#define CONFIG_LOG_H
#ifdef __cplusplus
extern "C" {
#endif

#define LOG_MODULE     "LOG_PROC" 

typedef struct stru_CFG_LOG_NODE
{
    _INT iLogType; // 日志的类型
    _UC aucCpName[CFG_STRING_LEN];
    _UC aucModule[CFG_STRING_LEN]; //来自哪个模块的日志
    _UC aucLogContent[CFG_STRING_MAXLEN]; //日志内容
    ST_MOS_LIST_NODE stNode;

}ST_CFG_LOG_NODE;


typedef struct stru_CFG_LOG_MNG
{
    _UC aucAppId[CFG_STRING_LEN]; 
    _UC aucLocalIp[CFG_STRING_LEN]; 
    _UC aucRoom[CFG_STRING_LEN];  
    ST_MOS_LIST stLogList; //ST_CFG_LOG_NODE
}ST_CFG_LOG_MNG;

ST_CFG_LOG_MNG *Config_GetLogMng();

_INT Log_Task_Destroy();

_INT Config_SetLogCommomInfo(_UC *pucAppid, _UC *pucLocalIp,_UC *pucRoom);

_INT Config_SetData(_UC *pucAppid,_INT iLocalType,_UC *pucCpName,_UC *pucModule,_UC *pucContent);

_UC *Config_BuildLogJson();

_INT Config_ParseLogJson(_UC *pStrJson);

#ifdef __cplusplus
}
#endif

#endif


