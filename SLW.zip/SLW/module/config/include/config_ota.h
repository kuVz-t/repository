#ifndef _CONFIG_OTA_H
#define _CONFIG_OTA_H

#ifdef __cplusplus
extern "C" {
#endif

// 接收升级包数据间隔的最大时间
#define OTA_DOWNFILE_RECV_MAXTIME   180
// 下载完整升级包最大时间RECV_
#define OTA_DOWNFILE_FINISH_MAXTIME 1800

typedef enum enum_CFG_OTA_UPGRADE_STATUS    // 设备升级状态
{
    EN_CFG_OTA_UPGRADE_NONEED       = 0,    // 0:不需要升级
    EN_CFG_OTA_UPGRADE_DOWNING      = 1,    // 1:下载中
    EN_CFG_OTA_UPGRADE_DOWNFINISH   = 2,    // 2:下载完成
    EN_CFG_OTA_UPGRADE_DOWNFAIL     = 3,    // 3:下载失败
    EN_CFG_OTA_UPGRADE_NOW          = 4,    // 4:升级中
    EN_CFG_OTA_UPGRADE_SUCCESS      = 5,    // 5:升级成功
    EN_CFG_OTA_UPGRADE_FAIL         = 6     // 6:升级失败
}EN_CFG_OTA_UPGRADE_STATUS;

typedef enum enum_CFG_OTA_REQUEST          // 设备版本检测请求状态
{
    EN_CFG_OTA_REQUEST_NOT          = 0,    // 0:未请求
    EN_CFG_OTA_REQUEST_NOW          = 1,    // 1:请求中
    EN_CFG_OTA_REQUEST_SUCCESS      = 2,    // 2:请求成功
    EN_CFG_OTA_REQUEST_FAIL         = 3     // 3:请求失败
}EN_CFG_OTA_REQUEST;

typedef enum enum_CFG_OTA_DOWNFILE          // 设备升级包下载状态
{
    EN_CFG_OTA_DOWNFILE_NOT         = 0,    // 0:不需要下载
    EN_CFG_OTA_DOWNFILE_BEGIN       = 1,    // 1:开始下载
    EN_CFG_OTA_DOWNFILE_NOW         = 2,    // 2:下载中
    EN_CFG_OTA_DOWNFILE_SUCCESS     = 3,    // 3:下载成功
    EN_CFG_OTA_DOWNFILE_FAIL        = 4     // 4:下载失败
}EN_CFG_OTA_DOWNFILE;

typedef enum enum_CFG_OTA_UPGRADE_CODE          // 设备升级码
{
    EN_CFG_OTA_UPGRADE_CODE_NOT         = 0,    // 0:不需要升级
    EN_CFG_OTA_UPGRADE_CODE_NEEDUPGRADE = 1,    // 1:需要升级
    EN_CFG_OTA_UPGRADE_CODE_UPGRADING   = 2,    // 2:升级中
}EN_CFG_OTA_UPGRADE_CODE;

typedef enum enum_CFG_OTA_UPGRADE_TYPE          // 设备升级类型
{
    EN_CFG_OTA_UPGRADE_TYPE_NOT         = 0,    // 0:
    EN_CFG_OTA_UPGRADE_TYPE_APPUSER     = 1,    // 1:用户主动要求升级
    EN_CFG_OTA_UPGRADE_TYPE_DEVICEAUTO  = 2,    // 2:设备自动升级
}EN_CFG_OTA_UPGRADE_TYPE;

typedef int (*OTA_PFUN_CHECKVERSION_CB)(_VPTR pstUsrInf,_UI uiCode,_UC *pucNewVersion,_UC *pucDownUrl,_UC *pucDes);

_INT Ota_Task_Init();

_INT Ota_Task_Destroy();

_INT Ota_CheckNewVersion(_VPTR pstUsrInf,OTA_PFUN_CHECKVERSION_CB pFunCheckVersionCb);

_INT Ota_StartUpgrade();

_INT Ota_StopUpgrade();

_INT Ota_PubUpgradePrecentage(_UC ucPrecentage, _INT istatus);

_INT Ota_NoticeDevToUpgrade();

_VOID Ota_SignatureCheck();

/*****************************************************
*****************************************************/
_INT Ota_SetNewVersionInf(_UC *pucNewVersion,_UC *pucDownUrl,_UC *pucPubkey,_UC *pucSignature,_UC *pucDescURL,_UI uiFileSize);

_VOID Ota_ProcCheckVersion();

_VOID Ota_ProcDownVersion();

#ifdef __cplusplus
}
#endif

#endif


