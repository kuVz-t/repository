#ifndef CONFIG_GROUP_H
#define CONFIG_GROUP_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct str_CFG_GROUPINF
{
    _UC  aucGrpid[CFG_CTEI_LEN+4];
    _UC  aucOwnerId[CFG_STRING_COMMONLEN + 4];
    _UC  aucOwnerName[CFG_STRING_LEN + 4];
    _UC  aucOwnerAccout[CFG_STRING_LEN + 4];
    _UC  aucOwnerMobile[CFG_STRING_COMMONLEN + 4];
}ST_CFG_GROUPINF;

ST_CFG_GROUPINF *Config_GetGroupInf();

_INT Config_SetDevGrpId(_UC *pucGrpid);

_INT Config_SetDevGroupOwnerId(_UC *pucOwnerId);

_INT Config_SetDevOwnerPubInf(_UC *pucName,_UC *pucAccount,_UC *pucMobile);

/*******************************************************/
_UC *Config_BuildGroupInfItem();
_INT Config_ParseGroupInfItem(_UC *pucJsonBuff);

#ifdef __cplusplus
}
#endif

#endif


