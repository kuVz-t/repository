#ifndef CONFIG_IOTPOLICY_H
#define CONFIG_IOTPOLICY_H

#ifdef __cplusplus
extern "C" {
#endif

#define IOT_DEFAULT_POLICYID_MOTION     (_UI)100    // 运动侦测报警默认策略ID

typedef struct ST_CFG_POLICYEVENT_NODE
{
    _UI uiUseFlag;
    _UI uiKjIoTEventId;
    _UI uiScenceId;
    ST_MOS_LIST  stOutputList; // ST_CFG_OUTPUT_NODE
    ST_MOS_LIST_NODE stNode;
}ST_CFG_POLICYEVENT_NODE;

typedef struct stru_cfg_KjIotpolicy_node
{
    _UI uiUseFlag;              // KjIot设备添加标志
    _UI uiPolicyId;             // 策略id
    _UI uiOpenFlag;             // KjIot设备启动标志  
    _UC aucPolicyName[32];      // 策略名称
    _UI uiWeekFlag;             // 周几    
    _UI uiStartTime;            // 事件触发时间戳
    _UI uiEndTime;              // 事件结束时间戳
    _UI uiSpanFlag;             // 是否跨天
    
    _UI uiKjIoTType;            // KjIot设备类型
    _LLID lluKjIotId;           // KjIot设备id
    _UI uiPropLen;              // 属性长度
    _UC *pucProp;               // KjIot设备属性json string
    
    ST_MOS_LIST stEventList;    // ST_KJIOT_OUTPUT_NODE 事件链表
    ST_MOS_LIST_NODE stNode;
}ST_CFG_ALARMPOLICY_NODE;

ST_MOS_LIST *Config_GetAlarmPolicyList();

// 查找告警IoT策略节点
ST_CFG_ALARMPOLICY_NODE *Config_FindAlarmPolicyNode(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPolicyId);

// 创建/查找告警IoT策略节点
ST_CFG_ALARMPOLICY_NODE *Config_FindAndCreatAlarmPolicyNode(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPolicyId);

// 删除告警IoT策略节点
_INT Config_DeleteAlarmPolicyNode(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPolicyId);

// 添加/查找 告警IoT策略的事件 的 节点
ST_CFG_POLICYEVENT_NODE *Config_FindAndCreatAlarmEventNode(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId);

// 查找 告警IoT策略的事件 的 节点
ST_CFG_POLICYEVENT_NODE *Config_FindAlarmEventNode(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId);

// 删除 告警IoT策略的事件 的 节点
_INT Config_DelAlarmEventNode(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId);

_INT Config_SetAlarmPolicyOpenFlag(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiOpenFlag);

_INT Config_SetAlarmPolicyProp(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UC *pucProp);

_UC* Config_GetAlarmPolicyProp(_UI uiKjIoTType, _LLID lluKjIoTId, _UI uiPolicyId);

_INT Config_DelAlarmPolicyProp(_UI uiAIIoTType, _LLID lluAIIoTID, _UI uiAIIoTEventId, _UC* pucDelProp, _UC* pucObjName);

_INT Config_SetAlarmPolicyName(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UC *pucPolicyName);

_INT Config_SetAlarmPolicyTime(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiSpanFlag,_UI uiWeekFlag,_UI StartTime,_UI uiEndTime);

_INT Config_AddAlarmPolicyEvent(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId);

_INT Config_DelAlarmPolicyEvent(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId);

// 告警IOT设备 策略增加 联动响应的IOT设备
_INT Config_AddAlarmPolicyOutput(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId, _UI uiOutIotType,_LLID lluOutIotId,_UC *pucParam);

// 告警IOT设备 策略删除 联动响应的IOT设备
_INT Config_DeleteAlarmPolicyOutPut(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId, _UI uiOutIotType,_LLID lluOutIotId);

_INT Config_AddAlarmPolicyOutputScene(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId,_UI uiSceneId);

// 增加 联动响应的IOT设备的动作属性(字段)
_INT Config_AddAlarmPolicyOutputProp(_UI uiInIoTType,  _LLID lluInIoTId, _UI uiInIoTEventId,
                                     _UI uiOutIoTType, _LLID lluOutIoTId,
                                     _UC* pucAddOutputProp, _UI uiValue);

 // 删除 联动响应的IOT设备的动作属性(字段)
_INT Config_DelAlarmPolicyOutputProp(_UI uiInIoTType,  _LLID lluInIoTId,  _UI uiInIoTEventId,
                                     _UI uiOutIoTType, _LLID lluOutIoTId, _UC* pucDelOutputProp);

// 增加告警IOT设备策略类型
_INT Config_AddIoTDefaultPolicy(ST_ZJ_IOT_POLICY_INFO *pstIoTPolicyInfo);
// 删除告警IOT设备策略类型
_INT Config_DelIoTDefaultPolicy(_UI uiInIoTType, _LLID lluInIoTId);

_INT Config_AlarmPolicyBegainSync();

_INT Config_AlarmPolicyEndSync();

ST_CFG_POLICYEVENT_NODE *Config_FindAlarmEventNode(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId);

// 策略节点 同步
_INT Config_AlarmPolicyEventBegainSync(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode);

_INT Config_AlarmPolicyEventEndSync(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode);

_INT Config_AlarmPolicyDestroy();

// 添加通用默认策略
_VOID Config_AddCommonDefaultPolicy(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucPolicyName);

// 添加声音报警相关默认策略
_VOID Config_AddDefaultVoicePolicy(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucPolicyName);

//设置默认策略：uiKjIoTType KjIot类型、uiRecordFlag 是否开启录像、 uiSnapFlag 是否开启抓图、uiEventFlag 是否事件上报
_INT Config_SetDefaultIotPolicy(_UI uiKjIoTType, _UI uiOpenFlag, _UI uiKjIoTEventId, _UI uiTraceFlag, _UI uiBuzzerFlag,_UI uiSenstive,
    _UI uiRecordFlag, _UI uiSnapFlag, _UI uiEventFlag, _UI uiEventInterval,_UI uiDuration,_UI uiActiveTime,_UI uiSoundType,_UC *pucSoundFile);

/**********************************************************************************
 * 获取、设置告警策略的prop
************************************************************************************/
_INT Config_GetMotionSensitive();

_INT Config_SetMotionSensitive(_INT iSensitive);

/**********************************************************************************
 * 获取、设置人形追踪开关
************************************************************************************/
_INT Config_GetHumanTraceSwitch();

_INT Config_SetHumanTraceSwitch(_INT iOpenFlag);

/**********************************************************************************
************************************************************************************/
_VPTR Config_BuildAlarmPolicyObject(_UI uiCfgType);

_UC *Config_BuildIotPolicyJson(_UI uiCfgType);

_INT Config_ParseAlarmPolicyJson(_UC *pucJson,_UI uICfgType);

// MOTION 告警策略更新
_INT Config_MotionAlarmPolicyUpdate();
#ifdef __cplusplus
}
#endif

#endif



