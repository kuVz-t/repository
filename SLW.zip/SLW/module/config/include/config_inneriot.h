#ifndef CONFIG_KJIOT_H
#define CONFIG_KJIOT_H

#ifdef __cplusplus
extern "C" {
#endif
/************************************************************
内部设备 
*************************************************************/
typedef struct stru_Config_RECORD_DEFAULTINF
{
    _UI uiStatus;
    _UI uiStreamerId;
    _UI uiloopFlag;
    _UI uiFullFlag; // 1 全天 录制  0 按照策略 录制 

    _UI uiCloudAllDayFlag;
    _UI uiDuration;    //报警录制时长
}ST_CFG_RECORD_DEFAULTINF;

typedef struct stru_Config_SNAP_DEFAULTINF
{
    _UI uiStatus;
    _UI uiLoopFlag;
    _UI uiInterval; 
    _UI uiPicType;
    _UI uiFullFlag; // 1 全天 录制  0 按照策略 录制 
}ST_CFG_SNAP_DEFAULTINF;

typedef struct stru_CFG_INNERIOT_NODE
{
    _UI uiUseFlag; 
    _UI uiKjIoTType;
    _LLID lluKjIotId;
    _UI uiOpenFlag;
    _UI uiDefaultSetFlag; //是否默认生效
    _UI uiWorkStatus;     //工作状态
    _UI uiPropLen;
    _UC *pucProp;
    ST_MOS_LIST_NODE stNode;
}ST_CFG_INIOT_NODE;

typedef struct stru_CFG_INNERIOT_MNG
{
    _UI uiPtzAbility;      // EN_ZJ_CAMERA_PTZ_ABILITY 
    _UI uiAttachPtzAbility;
    _UI uiPtzSpeedAbility;
    _UI uiMotionAbility;

    _UI uiDoorBellAbility;
    _UI uiPirAbility;
    _UI uiVoiceAlarmAbility;
   
    _UI uiSnapJpgAbility;
    _UI uiBuzzerAbility;
    _UI uiStatusLampAbility;
    _UI uiLampAbility;

    _UI uiRecordAbility;
    _UI uiCloudAbility;

    _UI uiCloudSnapAbility;
    _UI uiCameraAbility;
    _UI uiEventAbility;

    _UI uiBreakAlarmAbility;  // force breake alarm
    _UI uiStayAlarmAbility;   // staty alarm 
    _UI uiDnAbility;          // 自动、红外、全彩 
    _UI uiColliSionAbility;   // 碰撞
    _UI uiCloudFaceAbility;   // 云端人脸
    _UI uiCloudLogAbility;    // 事件云存成功率上报

    _HMUTEX hMutex;
    ST_MOS_LIST stInIotList;   // 设备的默认配置  
    ST_CFG_RECORD_DEFAULTINF stRecordInf;
    ST_CFG_SNAP_DEFAULTINF   stSnapInf;
}ST_CFG_INNERIOT_MNG;

/************************************************************************
*************************************************************************/
_INT Config_InnerIot_Init();

_INT Config_AddDefaultInIots(_UI uiKjIoTType);

_INT Config_InnerIot_Destroy();

ST_CFG_INNERIOT_MNG *Config_GetInIotMng();

_INT Config_AddInIotDevice(_UI uiAotType,_LLID lluAotId);

_INT Config_RemoveInIotDevice(_UI uiAotType,_LLID lluAotId);

ST_CFG_INIOT_NODE* Config_FindInnerIotDevice(_UI uiAotType,_LLID lluAotId);

ST_CFG_INIOT_NODE* Config_FindAndCreatInnerIotDevice(_UI uiAotType,_LLID lluAotId);

_INT Config_SetInIotProp(_UI uiAotType,_LLID lluAotId,_UC *pucProp);

_UC* Config_GetInIotProp(_UI uiAotType,_LLID lluAotId);

// 增加 IOT设备属性 (字段)
_INT Config_AddIoTProp(_UI uiAIIoTType, _LLID lluAIIoTID, _UI uiAIIoTEventId, _UC* pucAddProp, _UI uiValue);
// 删除 IOT设备属性 (字段)
_INT Config_DelIoTProp(_UI uiAIIoTType, _LLID lluAIIoTID, _UI uiAIIoTEventId, _UC* pucDelProp, _UC* pucObjName);
                             
_INT Config_SetInIotOpenFlag(_UI uiAotType, _LLID lluAotId,_INT iOpenFlag);

_INT Config_SetAttachPtzAbility(_INT iAttachPtzAbility);

_INT Config_SetPtzSpeedAbility(_INT iPtzSpeedAbility);

_INT Config_SetPtzAbility(_UI uiPtzAbility);

/*************************************************************************************/
_INT Config_SetDefaultRecordProp(_UI uiLoopRecordFlag,_UI uiRecordFullFlag,_UI uiStreamId,_UI uiDuration);

_INT Config_SetRecordProp(_UI uiLoopRecordFlag,_UI uiRecordFullFlag,_UI uiStreamId,_UI uiDuration);

_INT Config_GetLocalRecordProp(_UI *puiRecordLoop,_UI *puiRecordFull,_UI *puiStreamId,_UI *puiOpenFlag,_UI *puiDuration);

_INT Config_SetDefaultSnapProp(_UI uiLoopFlag,_UI uiFullFlag,_UI uiInterval,_UI uiPicType);

_INT Config_SetSnapProp(_UI uiLoopFlag,_UI uiFullFlag,_UI uiInterval,_UI uiPicType);

// 返回值 MOS_ERR 表示 没有改项 业务
_INT Config_GetCloudRecordProp(_UI *puiLoopDays,_UI *puiRecordType,_UI *puiStreamId,_UI *puiOpenFlag,_UI *puiDuration);

_INT Config_GetCloudSnapProp(_UI *puiLoopDays,_UI *puiRecordType,_UI *puiPicType,_UI *puiInteraval,_UI *puiOpenFlag);

_INT Config_GetMotionProp(_UI *puiHumanAbility,_UI *puiFaceAbility);

_INT Config_GetEventProp(_UI *puiPushFlag,_UI *puiSmsFlag,_UI *puiEamilFlag,_UI *puiInterval,
    _UC aucEmalAddr[256],_UI *puiCustomType,_UI *puiStartTime, _UI *puiEndTime, _UI *uiSpanFlag);

_INT Config_SetInIotWorkStatus(_UI uiAotType,_LLID lluAotId,_INT iWorkStatus);

/*******************************************************************
JSON的组装和解析
********************************************************************/
_VPTR Config_BuildInnerIotObject(_UI uICfgType);

_UC *Config_BuildInnerIotJson(_UI uICfgType);

_INT Config_ParseInnerIotJson(_UC *pStrJson,_UI uICfgType);

#ifdef __cplusplus
}
#endif

#endif


