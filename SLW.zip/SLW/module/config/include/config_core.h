#ifndef CONFIG_CORE_H
#define CONFIG_CORE_H

#ifdef __cplusplus
extern "C" {
#endif
#include "config_type.h"

// 第一次登录信令服务状态 用于3244登录信令服务器initflag字段
typedef enum enum_CmdLoginStatus
{
    EN_CMDLOGIN_STATUS_REBOOT               = 0, // 重启，正常登录上线
    EN_CMDLOGIN_STATUS_UPGRADE_OR_FACTORY   = 1, // 固件升级后第一次登录上线，出厂第一次登录上线
    EN_CMDLOGIN_STATUS_RESET                = 2  // 重置后第一次登录上线
}EN_CMDLOGIN_STATUS;

typedef struct str_CFG_ISPINF
{
    _UC aucCountryId[CFG_STRING_LEN];      //国家
    _UC aucAreaId[CFG_STRING_LEN];         //地区
    _UC aucRegionId[CFG_STRING_LEN];       //省
    _UC aucCityId[CFG_STRING_LEN];         //市
    _UC aucCountyId[CFG_STRING_LEN];       //县
    _UC aucISPId[CFG_STRING_LEN];          //运营商
}ST_CFG_ISPINF;

typedef struct str_CFG_CORE_MNG
{
    _UC ucAbilityUpFlag;  // 上传能力标志 0 need 1、ing 2、OK
    _UC ucBussUpFlag;     // 上传配置标志
    _UC ucStatusUpFlag;   // 状态上传标志
    _UC ucRsv;
    _UI uiExtCfgUpFlag;   // 额外配置上传标志
    _US usHxLinkPort;        // CMD 服务器的端口
    _INT iEncType;            
    _UC aucEncKey[CFG_STRING_COMMONLEN + 4];
    _UC aucEncLoad[CFG_STRING_COMMONLEN + 4];
    _UC aucHxLinkAddr[CFG_STRING_LEN]; // CMD 服务器的IP
    _UC aucHxLinkIPv6Addr[CFG_STRING_LEN]; // CMD 服务器的IP
    
    _US usLinkPort;
    _UC aucLinkIpv4[CFG_STRING_LEN];
    _UC aucLinkIpv6[CFG_STRING_LEN];
    _UC aucRegionId[CFG_STRING_COMMONLEN];
    _UC aucLinkSrvId[CFG_STRING_LEN];
    _INT iLinkEncType;               // link 登录的加密方式和秘钥
    _UC aucLinkEncKey[CFG_STRING_COMMONLEN + 4];
    _UC aucLinkEncLoad[CFG_STRING_COMMONLEN + 4];
#ifdef DX_SECOND_LINK
    _US usGBLinkPort;
    _UC aucGBLinkIpv4[CFG_STRING_LEN];
    _UC aucGBLinkIpv6[CFG_STRING_LEN];
    _UC aucGBRegionId[CFG_STRING_COMMONLEN];
    _UC aucGBLinkSrvId[CFG_STRING_LEN];
    _INT iGBLinkEncType; 
    _UC aucGBLinkEncKey[CFG_STRING_COMMONLEN + 4];
    _UC aucGBLinkEncLoad[CFG_STRING_COMMONLEN + 4];
#endif
    _UC aucCachePath[MOS_DIR_NAME_LEN];
    _UC aucSoudFilePath[MOS_DIR_NAME_LEN]; // 声音文件存储路径
    _UC aucNetIp[CFG_STRING_LEN];          // 外网ip
    _UC aucDevToken[CFG_STRING_LEN];    //  能力平台 返回用于登录
    ST_CFG_ISPINF stIspInf;
	_UI uiAnchorFlag;
    _UI uiCmdLoginStatus;   // 第一次登录信令服务状态 用于3244登录信令服务器initflag字段 参考：EN_CMDLOGIN_STATUS 
                            // 0-重启，正常登录上线 1-固件升级后第一次登录上线，出厂第一次登录上线 2-重置后第一次登录上线
}ST_CFG_CORE_MNG;

ST_CFG_CORE_MNG *Config_GetCoreMng();

_INT Config_SetDevIspInf(ST_CFG_ISPINF *pstIspInf);
_INT Config_SetDevNetIp(_UC *pucNetIp);
/***************************************
LINK
***************************************/
_INT Config_SetLinkServerAddr(_UC aucLinkIpv4Addr[CFG_STRING_LEN],_UC aucLinkIpv6Addr[CFG_STRING_LEN],_US usLinkPort);
_INT Config_SetLinkServId(_UC *pucLinkSrvId);
_INT Config_SetLinkRegionId(_UC aucRegionId[CFG_CTEI_LEN+4]);
_INT Config_SetLinkPlatEncInf(_INT iEncType,_UC *pucEncKey,_UC *pucEncLoad);

/***************************************
GBLINK
***************************************/
#ifdef DX_SECOND_LINK
_INT Config_SetGBLinkServerAddr(_UC aucLinkIpv4Addr[CFG_STRING_LEN],_UC aucLinkIpv6Addr[CFG_STRING_LEN],_US usLinkPort);
_INT Config_SetGBLinkServId(_UC *pucLinkSrvId);
_INT Config_SetGBLinkRegionId(_UC aucRegionId[CFG_CTEI_LEN+4]);
_INT Config_SetGBLinkPlatEncInf(_INT iEncType,_UC *pucEncKey,_UC *pucEncLoad);
#endif
/* 录像存储 路径  */
_INT Config_SetDevCachePath(_UC *pucDevCachePath);

/**自定义声音文件存储路径**/
_INT Config_SetDevSoudFilePath(_UC *pucSoudFilePath);

_INT Config_SetHxLinkAddr(_UC *pucHxLinkAddr,_US usHxLinkPort);
_INT Config_SetHxLinkIPv6Addr(_UC *pucHxLinkIPv6Addr,_US usHxLinkPort);
_INT Config_SetCmdPlatEncrypInf(_INT iEncType,_UC *pucEncKey,_UC *pucEncLoad);


_INT Config_SetAbilityUpLoadFlag(_UC ucUploadFlag);
_INT Config_SetConfigUpLoadFlag(_UC ucUploadFlag);

_INT Config_SetAblPlatDevToken(_UC *pucDevToken);

_INT Config_SetConfigAnchorFlag(_UI uiAnchorFlag);

// 用于3244登录信令服务器initflag字段
_INT Config_SetCmdLoginStatus(_UI uiCmdLoginStatus);
/**************************************************************************
配置的组合和获取
****************************************************************************/
_UC *Config_BuildCoreInfJson();
_INT Config_ParseCoreInfJson(_UC *pStrJson);

#ifdef __cplusplus
}
#endif
#endif

