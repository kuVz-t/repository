#ifndef CONFIG_CLOUDSTG_H
#define CONFIG_CLOUDSTG_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct stru_CFG_CLOUDSTG_PATCH_MNG {
    /*****************需保存****************/
    _UC                        pucUuid[17];     // uuid
    _INT                       iCamId;          // 摄像头ID
    _INT                       iEventType;      // 1：移动侦测 2：无移动侦测
    /*EN_CLOUDSTG_RESOURCE_NONE       参数无意义 EN_CLOUDSTG_RESOURCE_STREAM 视频文件 EN_CLOUDSTG_RESOURCE_PIC  图片
      EN_CLOUDSTG_RESOURCE_LOGFILE    本地日志   EN_CLOUDSTG_RESOURCE_LOG    日志*/
    _INT                       iTaskType;
    _INT                       iStorageType;    // EN_CLOUDSTG_STORAGE_TYPE
    _INT                       iCloudUpLoadMode;// 云存上传模式 1：事件 2：全天
    _UI                        uiDuration;      // 上传持续时间
    _CTIME_T                   tCreateTime;     // 任务创建时间
    _CTIME_T                   tFailTime;       // 任务失败时间
    ST_MOS_LIST_NODE           stNode;
}ST_CFG_CLOUDSTG_PATCH_MNG;

typedef struct stru_CFG_CLOUDSTG_MNG
{
    _INT    iCloudUpLoadMode; // 1 事件 2 全天
    _INT    iCloudAbility;
    _INT    iStreamID;
    _INT    iCloudIconType;
    _INT    iCloudEncPKId;
    _INT    iCloudEncSwitch;
    _INT    iCloudEncType;
    _INT    iCloudEncLen;
    _INT    iDirectMode;
    _INT    iProvinceId;
    _INT    iSliceDuration;
    _INT    iVideoDuration;
    _INT    iAfterReqUrlFlag;
    _BOOL   bNetCheckPermanent; // 是否常驻Tcping
    _INT    iNetCheckHostNum; // tcping域名数量
    _INT    iNetCheckCollectFreq; // 采集周期（s）
    _INT    iNetCheckDetectFreq; // tcping间隔（s）
    _INT    iNetCheckDetectCount; // tcping数量
    _INT    piNetCheckSiteId[5]; // tcping域名id，协议规定Tcping最大支持5个域名
    _UC     aucNetCheckHost[5][CFG_STRING_MIDLEN]; // tcping域名
    _UC     aucCloudEncPKValue[CFG_STRING_SDP_LENGTH + 4];
    _UC     aucCloudEncAesKey[CFG_STRING_COMMONLEN + 4];
    _UC     aucCloudEncAesIv[CFG_STRING_COMMONLEN + 4];
    _UC     aucCloudEncHttpParamJson[CFG_STRING_SDP_LENGTH + 4];
    _UC     aucCloudEncHttpParam[CFG_STRING_SDP_LENGTH + 4];
    _UC     aucCloudEncHttpUploadParam[CFG_STRING_SDP_LENGTH + 4];
    _UC     aucAppKey[CFG_STRING_LEN + 4];
    _UC     aucAppSecret[CFG_STRING_LEN + 4];
    _UC     aucAESVI[CFG_STRING_LEN + 4];
    _UC     aucCloudId[CFG_STRING_LEN];
    _UC     aucIframeKey[CFG_STRING_LEN];
    _UC     aucCloudAccount[CFG_STRING_LEN];
    _INT    iPackageType;
    _INT    iCloudStreamType;
    _INT    iUrlTimerInterval;
    _HMUTEX hCloudPatchMutex;
    ST_MOS_LIST    stPatchTaskCfgList;
}ST_CFG_CLOUDSTG_MNG;

ST_CFG_CLOUDSTG_MNG *Config_GetCloudMng();

_INT Config_SetAppKey(_UC *pucAppKey);

_INT Config_SetAppSecret(_UC *pucAppSecret);

_INT Config_SetAESVI(_UC *pucAESVI);

_INT Config_SetCloudId(_UC *pucCloudId);

_INT Config_SetCloudAbility(_INT iCloudAbility);

_INT Config_SetCloudUpLoadMode(_INT iUpLoadMode);

_INT Config_SetStreamID(_INT iStreamID);

_INT Config_SetCloudIconType(_INT iCloudIconType);

_BOOL Config_NeedGenerateCloudEnc(_INT iNewCloudEncSwitch);

_INT Config_SetUrlTimerInterval(_INT iUrlTimerInterval);

_INT Config_SetCloudEncPKId(_INT iCloudEncPKId);

_INT Config_SetCloudEncPKValue(_UC *pucCloudEncPKValue);

_INT Config_SetCloudEncSwitch(_INT iCloudEncSwitch);

_INT Config_SetCloudEncType(_INT iCloudEncType);

_INT Config_SetCloudEncLen(_INT iCloudEncLen);

_INT Config_SetCloudEncHttpParamJson(_UC* pucCloudEncHttpParamJson);

_INT Config_SetCloudEncHttpParam(_UC* pucCloudEncHttpParam);

_INT Config_SetCloudEncHttpUploadParam(_UC* pucCloudEncHttpUploadParam);

_INT Config_SetIframeKey(_UC* pucKey);

_INT Config_SetPackageType(_INT iPackageType);

_INT Config_SetCloudStreamType(_INT iCloudStreamType);

_INT Config_SetCloudAccount(_UC* pucAccount);

_INT Config_setNetCheckPermanent(_BOOL bNetCheckPermanent);

_INT Config_SetNetCheckHostNum(_INT iNetCheckHostNum);

_INT Config_SetNetCheckCollectFreq(_INT iNetCheckCollectFreq);

_INT Config_SetNetCheckDetectFreq(_INT iNetCheckDetectFreq);

_INT Config_SetNetCheckDetectCount(_INT iNetCheckDetectCount);

_INT Config_SetNetCheckSiteId(_INT *piNetCheckSiteId, _INT iLen);

_INT Config_SetNetCheckHost(_UC **pucNetCheckHost, _INT iLen);

_VPTR Config_BuildCloudSetObject();

_UC *Config_BuildCloudSetJson();

_INT Config_ParseCloudSetJson(_UC *pStrJson);

_INT Config_Cloud_Init();

_INT Config_Cloud_Destroy();

#ifdef __cplusplus
}
#endif
#endif


