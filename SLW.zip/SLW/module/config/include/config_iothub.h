#ifndef CONFIG_IOTHUB_H
#define CONFIG_IOTHUB_H
#ifdef __cplusplus
extern "C" {
#endif
/************************************************************
外部 hub 接入 设备 
*************************************************************/
typedef struct stru_CFG_HUBIOT_NODE
{
    _UI uiUseFlag;
    _UI uiEnableFlag;
    _UI uiKjIoTType;
    _LLID lluKjIoTId;
    _UC aucIotName[128];
    _UI uiOpenFlag; // 1 打开 ， 非1 关闭
    _UI uiPowerLevel;
    _UI uiPropBuffLen;
    _UC *pucProp;
    ST_MOS_LIST_NODE stNode;
}ST_CFG_HUBIOT_NODE;

typedef struct stru_CFG_KJIOTHUB_MNG
{
    _UI uiIotHubAbility;
    _UI uiIotHubStatus;
    _UI uiIotMaxCount;
    _HMUTEX hMutex;
    ST_MOS_LIST stIotList;   // 设备的默认配置 
}ST_CFG_KJIOTHUB_MNG;

_INT Config_IotHub_Init();

_INT Config_IotHub_Destroy();

_INT Config_SetIotHubAbility(_UI uiHubAblity);

_INT Config_SetIotHubStatus(_UI uiHubStatus);

_INT Config_SetIotHubMaxCount(_UI uiIotMaxCnt);

_INT Config_AddIotToHub(_UI uiKjIoTType,_LLID lluKjIoTId);

_INT Config_AddIotToHubEx(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucIotName,_UI uiOpenFlag,_UC *pucProp); //add parameter by 

_INT Config_DeleteIotFromHub(_UI uiKjIoTType,_LLID lluKjIoTId);

_INT Config_SetIotPropInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucProp);

_INT Config_SetIotEnableFlagInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiEnableFlag);

_INT Config_SetIotOpenFlagInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiOpenFlag);

_INT Config_SetIotNameInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucIotName);

_INT Config_SetIotPowerLevelInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPowerLevel);

ST_CFG_KJIOTHUB_MNG *Config_GetIotHubMng();

ST_CFG_HUBIOT_NODE* Config_FindIotForHub(_UI uiKjIoTType,_LLID lluKjIoTId);

_INT Config_BegainSyncIotHubDevList();
_INT Config_EndSyncIotHubDevList();

/*********************************************************************************
**********************************************************************************/
_VPTR Config_BuildIotHubObject(_UI uiCfgItem);

_UC* Config_BuildIotHubJson(_UI uiCfgItem);

_INT Config_ParseIotHubJson(_UC *pucHubJson,_UI uiCfgItem);

#ifdef __cplusplus
}
#endif

#endif


