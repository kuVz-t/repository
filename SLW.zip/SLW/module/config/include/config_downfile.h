#ifndef _CONFIG_DOWN_FILE_H
#define _CONFIG_DOWN_FILE_H

#ifdef __cplusplus
extern "C" {
#endif


_INT DownFile_Task_Init();

_INT DownFile_Task_Destroy();

_INT DownFile_StartDownload(_UI uiFileType, _UC *pucFileName, _UC *pucSoundUrl);

_VOID DownFile_ProcStatus();

#ifdef __cplusplus
}
#endif

#endif


