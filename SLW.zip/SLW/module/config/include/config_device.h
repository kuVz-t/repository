#ifndef _CONFIG_DEVICE_H
#define _CONFIG_DEVICE_H

#ifdef __cplusplus
extern "C" {
#endif

#define DEVICE_AWAKE_INTERVAL_DEFAULT 60      
#define DEVICE_AWAKE_INTERVAL_MIN     10      
#define DEVICE_AWAKE_INTERVAL_MAX     1000
#define DEVICE_AWAKE_INTERVAL_OFFLINE (10*60)//未注册登录成功/未配网

// SDK空闲/繁忙状态
typedef enum enum_SDK_STATE
{
    EN_SDK_STATE_NONE = 0, //SDK空闲状态
    EN_SDK_STATE_BUSY = 1, //SDK繁忙状态
}EN_SDK_STATE;

// 获取设备外网IP开关状态，0.关闭， 1:开启 默认：关闭
typedef enum enum_GETOUTERIP_STATUS_TYPE
{
    EN_GETOUTERIP_STATUS_CLOSE  = 0,    // 关闭
    EN_GETOUTERIP_STATUS_OPEN   = 1,    // 开启
}EN_GETOUTERIP_STATUS_TYPE;

// 设备上线后在该值的随机时间点内获取外网IP 单位：分钟(min), 范围：[1-10] 默认：3分钟
typedef enum enum_GETOUTERIP_ONLINERANDOMTIME_TYPE
{
    EN_GETOUTERIP_ONLINERANDOMTIME_MIN      = 1,    // 最小值
    EN_GETOUTERIP_ONLINERANDOMTIME_DEFAULT  = 3,    // 默认值
    EN_GETOUTERIP_ONLINERANDOMTIME_MAX      = 10,   // 最大值
}EN_GETOUTERIP_ONLINERANDOMTIME_TYPE;

// 将获取外网IP统计数据上报云涛间隔(也可理解成数据统计周期) 单位：小时(h), 范围：[1-24] 默认：6小时
typedef enum enum_GETOUTERIP_UPLOADINTERVAL_TYPE
{
    EN_GETOUTERIP_UPLOADINTERVAL_MIN      = 1,      // 最小值
    EN_GETOUTERIP_UPLOADINTERVAL_DEFAULT  = 6,      // 默认值
    EN_GETOUTERIP_UPLOADINTERVAL_MAX      = 24,     // 最大值
}EN_GETOUTERIP_UPLOADINTERVAL_TYPE;

// 统计周期内外网IP变更次数最大值   范围：[3-10] 默认：5次
typedef enum enum_GETOUTERIP_MAXCHANGECOUNT_TYPE
{
    EN_GETOUTERIP_MAXCHANGECOUNT_MIN      = 3,      // 最小值
    EN_GETOUTERIP_MAXCHANGECOUNT_DEFAULT  = 5,      // 默认值
    EN_GETOUTERIP_MAXCHANGECOUNT_MAX      = 10,     // 最大值
}EN_GETOUTERIP_MAXCHANGECOUNT_TYPE;

// 统计周期内外网IP变更次数达到上限后,停止检查设备外网IP的时长  单位：小时(h), 范围：[1-24] 默认：12小时
typedef enum enum_GETOUTERIP_STOPCHECKDURATION_TYPE
{
    EN_GETOUTERIP_STOPCHECKDURATION_MIN      = 1,   // 最小值
    EN_GETOUTERIP_STOPCHECKDURATION_DEFAULT  = 12,  // 默认值
    EN_GETOUTERIP_STOPCHECKDURATION_MAX      = 24,  // 最大值
}EN_GETOUTERIP_STOPCHECKDURATION_TYPE;

typedef struct stru_SLEEP_MONITOR_MNG
{
    _UC             ucInitFlag; 
    _UI             uiMonitorId;
    _INT            iForceNotify;
    _HMUTEX         hMutex;
    ST_MOS_LIST     stAppInfoList;
}ST_SLEEP_MONITOR_MNG;

typedef struct stuct_SLeepMonotorNode
{
    _UI              uiMonitorId;
    _UC              ucAppName[32];
    _INT             iBusyStatus;
    ST_MOS_LIST_NODE stNode;
}ST_SLeepMonotorNode;

typedef struct stru_CFG_DEVICE_MNG
{
    // ability
    _INT iEncryAbility;                 // 加密能力类型
    _INT iOtaAbility;                   // 升级能力
    _INT iWifiSetAbility;               // WiFi配网支持类型能力
    _INT iEnergyType;                   // 电源供电节能模式  0 不带电池 1 带电池 2.太阳能电池
    _INT iAwakeAbility;                 // 休眠唤醒能力      0x00不支持休眠,0x01支持本地唤醒,0x02 支持远程唤醒
    _INT i4GAbility;                    // 是否支持4G       0.不支持；1支持
    _INT iPowerSupplyFlag;              // 是否插电源       0.不插电；1 插电
    _INT iMaxChnNum;                    //（NVR、多目摄像头共用）最大通道数，默认为1
    // 业务使用定时休眠去判断能不能使用定时休眠的下发
    _INT iTimingAwakeAbility;           // 定时休眠能力     0.不支持；1支持
    // 定时任务的能力字段包括任务ID可字符串及按照协议可嵌套当前已具备的所有定时任务能力，包括且不局限于语音、白光灯、休眠、预置位操作
    _INT iTimingTaskAbility;            // 定时任务能力     0.不支持；1支持 
    _INT iGetDevOuterIPAbility;         // 获取设备外网IP能力     0.不支持；1支持 

    // business
    _INT iPowerLevel;                   // 电源电量
    _INT iPresence;                     // 设备的在线状态
    _INT iOtaStatus;                    // OTA升级状态
    _INT iDevOsType;                    // 设备的操作系统类型
    _INT iLogUpLoadFlag;                // 日志上传开关
    _INT iPilotLightStatus;             // 指示灯开关状态
    _INT iLogErrType;                   // 错误日志上报类型
    _INT iDevType;                      // 设备类型：0x01.摄像机；0x02.分体门铃；0x03.单体门铃；0x04.NVR 0x05智能音箱
    _UI  uiMaxSessionCnt;               // 设置最大连接数
    _UI  uiUpgradedEndFlag;             // 固件升级状态
    _UI  uiXwUpgradedFlag;              // xw固件升级完成标志
    _UI  uiAutoUpgradeFlag;             // 设备自动升级检测模式: 0.关、1.定时检测"、2.开机检测（唤醒）
    _UI  uiUpgradeWeekDay;              // 周几升级  0x01 表示周一； 0x02 表示周二； 0x04 表示周三； 0x08表示周四； 0x10 表示周五； 0x20表示周六； 0x40表示周日；或的方式
    _UI  uiUpgradeTime;                 // 升级时间点
    _UI  uiSdkVersion;                  // sdk版本
    _UI  uiLastUseFlow;
    _UI  uiQRScanTime;
    _UI  uiLimitStreamFlag;             // 限制设备流标志:1 限制，0 放开
    _UI  uiCloudLogStatus;              // 事件云存上报开关：0关，1开
    _UI  uiCloudLogInterval;            // 10-180分钟，默认30分钟
    _UI  uiAwakeInterval;               // 休眠唤醒间隔
    _UC aucUpgradeDay[32];              // 升级日期
    _UC aucDevVerSion[CFG_STRING_LEN];  // 固件版本命名: V*.*.*-省份编码-yymmdd (固件版本号-省份编码-时间)
    _UC aucDevName[CFG_STRING_LEN];     // 设备名称
    _UC aucDev4GCardNum[CFG_STRING_LEN];// 4G卡号
    _UC aucDevModel[CFG_STRING_LEN];    // 设备的型号：EF-FH8632-0530-00  第一位 sdk 开发者 , 第二位厂商芯片信号 第三 产品型号 第四 省份
    _INT iDstUseFlag;                   // if use dst 
    _UC aucDstArea[CFG_STRING_LEN];     // dst area
    _UC aucDst[CFG_STRING_LEN];         // summer time
    _CTIME_T cFirstLaunchTime;          // 第一次上电时间
    ST_SLEEP_MONITOR_MNG stSleepMonitorMng;// 睡眠检测
    // 应用与获取设备外网IP处理方案
    _UI uiGetDevOuterIPStatus;          // 获取设备外网IP开关状态，0.关闭， 1:开启 默认：关闭
    _UI uiOnlineRandomTime;             // 设备上线后在该值的随机时间点内获取外网IP 单位：分钟(min), 范围：[1-10] 默认：3分钟
    _UI uiUploadInterval;               // 将获取外网IP统计数据上报云涛间隔(也可理解成数据统计周期) 单位：小时(h), 范围：[1-24] 默认：6小时
    _UI uiMaxChangeCount;               // 统计周期内外网IP变更次数最大值   范围：[3-10] 默认：5次
    _UI uiStopCheckDuration;            // 统计周期内外网IP变更次数达到上限后,停止检查设备外网IP的时长  单位：小时(h), 范围：[1-24] 默认：12小时
}ST_CFG_DEVICE_MNG;

ST_CFG_DEVICE_MNG *Config_GetDeviceMng();

_INT Config_InitDeviceMng();

_INT Config_SetSdkVersion(_UI uiSdkVersion);
_UC* Config_GetSdkVersion(_UC *aucSdkVersion);

_INT Config_SetAppVersion(_UC* pcVersion);

_INT Config_SetEncryptAbility(_INT iEncAbility);

_INT Config_SetOtaAbility(_INT iOtaAbility);

_INT Config_SetWifiSetAbility(_INT iWifiSetAbility);

_INT Config_SetEngeryType(_INT iEngeryType);

_INT Config_SetAwakeAbility(_INT iAwakeAbility);

_INT Config_SetPowerSupply( _INT iSupplyFlag);

_INT Config_Set4GAbility(_INT i4GAbility);

_INT Config_SetMaxChnNum(_INT iMaxChnNum);

_INT Config_SetTimingTaskAbility(_INT iTimingTaskAbility);

_INT Config_SetTimingAwakeAbility(_INT iTimingAwakeAbility);

_INT Config_SetGetDevOuterIPAbility(_INT iGetDevOuterIPAbility);

_INT Config_SetPowerLevel(_INT iPowerLevel);

_INT Config_SetDeviceName(_UC *pucDevName);

_INT Config_SetFirstLaunchTime();

_INT Config_SetDevAwakeInterval(_UI uiAwakeInterval);

_UI Config_GetDevAwakeInterval();

//低功耗设备上报休眠、唤醒状态 :0 休眠（离线） 1 唤醒（在线）
_INT Config_SetDevicePresenceFlag(_INT iPresence);

_INT Config_SetDevOtaStatus(_INT iOtaStatus);

_INT Config_SetDevOsType(_INT iDevOsType);

_INT Config_SetUpLogFlag(_INT iUpLogFlag,_INT iLogErrType);

_INT Config_SetSIMCardAccount(_UC *pucSIMCardAccount);

_INT Config_SetDevAutoUpgradeParam(_UI uiAutoUpgradeFlag, _UI uiWeekDay, _UI uiTime);

//设置设备的型号：EF-FH8632-0530-00  第一位 sdk 开发者 , 第二位厂商芯片信号 第三 产品型号 第四 省份
_INT Config_SetDevModel(_UC *pucDevModel);

//设置设备类型 1.摄像机；2.分体门铃；3.单体门铃；4.NVR
_INT Config_SetDevType(_INT iDevType);

//设置限制流的标志：云存切片上传之前需要判断此标志
_INT Config_SetDevLimitStreamFlag(_UI uiFlag);

_INT Config_SetMaxSessionCnt(_UI uiMaxSessionCnt);

_INT Config_SetCloudLogStatus(_UI uiCloudLogStatus);

_INT Config_SetCloudLogInterval(_UI uiCloudLogInterval);

// 应用与获取设备外网IP处理方案
// 对设备获取外网IP操作涉及的参数配置
_INT Config_SetGetOuterIPInf(_UI uiGetDevOuterIPStatus, _UI uiOnlineRandomTime, _UI uiUploadInterval, _UI uiMaxChangeCount, _UI uiStopCheckDuration);

//获取夏令时相关
_INT Config_SetAreaInfo(_INT iDstUseFlag,_UC *pucDstArea);

_INT Config_SetLocalAreaDst(_UC *pucDst);

/**************************************************************
***************************************************************/
_VPTR Config_BuildDeviceObject(_UI uiCfgType);

_UC *Config_BuildDeviceJson(_UI uiCfgType);

_INT Config_ParseDeviceJson(_UC *pStrJson,_UI uiCfgType);


/**************************************************************
 * 设备繁忙标志相关接口
***************************************************************/
_VOID Config_GetSLeepMonotorStatus(_INT *piBusyStatus, _INT *piForceNotify);

_UI Config_AppSLeepMonotorRegist(_UC *pucAppName);

_VOID Config_AppSLeepMonotorUnRegist(_UI uiMonitorId);

_VOID Config_AppSLeepMonotorUpdateStatus(_UI uiMonitorId, _INT iBusyStatus);

_VOID Config_SetSLeepMonotorForceNotify();

_INT Config_SetPilotLightStatus(_INT iPilotLightStatus);

#ifdef __cplusplus
}
#endif

#endif

