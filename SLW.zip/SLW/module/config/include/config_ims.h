#ifndef _CONFIG_IMS_H
#define _CONFIG_IMS_H

#ifdef __cplusplus
extern "C" {
#endif

#define  IMSCFG_LOGSTR       (_UC *)"IMS"

typedef struct stru_CFG_IMS_MNG
{
    _INT iImsAbility;
    _UC  ucSign[16];
    _UI  uiPollingStatus;
    _UI  uiPollingInterval;
    _UI  uiHaveIMS;
    _UC  ucBindKey[128];
    _UC  ucImsBusiParamJson[512];
} ST_CFG_IMS_MNG;

ST_CFG_IMS_MNG *Config_GetImsMng();

_VPTR Config_BuildImsSetObject();

_UC *Config_BuildImsSetJson();

_INT Config_ParseImsSetJson(_UC *pStrJson);

_INT Config_Ims_Init();

_INT Config_Ims_Destroy();

_INT Config_SetImsBindKey(_UC *pucBindKey);

_INT Config_SetImsSign(_UC *pucSign);

_INT Config_SetImsPollingStatus(_UI uiPollingStatus);

_INT Config_SetImsPollingInterval(_UI uiPollingInterval);

_INT Config_SetImsHaveIMSValue(_UI uiHaveIMS);

_INT Config_SetImsBusiParamJson(_UC *pucImsBusiParamJson);

#ifdef __cplusplus
}
#endif

#endif