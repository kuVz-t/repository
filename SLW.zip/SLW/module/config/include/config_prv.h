#ifndef _CONFIG_PRV_H
#define _CONFIG_PRV_H

#ifdef __cplusplus
extern "C" {
#endif

#define CFG_LOGSTR              (_UC*)"CFG"

#define CFG_CORE_FILE           (_UC*)"corecfg.db"
#define CFG_NEWSYSTEM_FILE      (_UC*)"systemencrycfg.db"
#define CFG_SYSTEM_FILE         (_UC*)"systemcfg.db"
#define CFG_DEVICE_FILE         (_UC*)"devcfg.db"
#define CFG_CAMERA_FILE         (_UC*)"camcfg.db"
#define CFG_INIOT_FILE          (_UC*)"iniotcfg.db"
#define CFG_IOTHUB_FILE         (_UC*)"iothubcfg.db"
#define CFG_TIMEPOLICY_FILE     (_UC*)"timepolicy.db"
#define CFG_ALARMPOLICY_FILE    (_UC*)"alarmpolicy.db"
#define CFG_SCENEPOLICY_FILE    (_UC*)"scenepolicy.db"
#define CFG_GROUP_FILE          (_UC*)"groupcfg.db"
#define CFG_PTZ_FILE            (_UC*)"ptzcfg.db"
#define CFG_SERVERSET_FILE      (_UC*)"servsetcfg.db"
#define CFG_CLOUDSTG_FILE       (_UC*)"cloudcfg.db"
#define CFG_CLOUDSTG_PATCH_FILE (_UC*)"cloudpatchcfg.db"
#define CFG_AI_FILE             (_UC*)"aicfg.db"
#define CFG_IMS_FILE            (_UC*)"imscfg.db"

#define CFG_ABILITYBINDDEV_URL  (_UC*)"/ehome_sdk1/uni-sdk/deviceFrontBind"

/****************************************************************************************/

typedef enum enum_CFGNET_RT_TYPE
{
    EN_CFGNET_RT_BIND_DEVICE             = 50001,    // 告警消息上报失败
    EN_CFGNET_RT_CREATE_QRCODE_THREAD    = 50002,    // 创建 QRDetector 线程失败
    EN_CFGNET_RT_APPLY_QRCODE_BUF        = 50003,    // 申请二维码缓冲区失败
    EN_CFGNET_RT_SCAN_QRCODE             = 50004,    // 二维码扫描失败
    EN_CFGNET_RT_INVALID_IPADDR          = 50005,    // 无效IP地址
    EN_CFGNET_RT_INVALID_SUBCODE_MASK    = 50006,    // 无效子码掩码
    EN_CFGNET_RT_INVALID_GATEWAY         = 50007,    // 无效网关
    EN_CFGNET_RT_INVALID_SSID            = 50008,    // 无效ssid
    EN_CFGNET_RT_INVALID_PWD             = 50009,    // 无效pwd
    EN_CFGNET_RT_WIFI_CONNECT_FAILED     = 50010,    // WIFI连接失败
    EN_CFGNET_RT_WIFI_CONNECT_OVERTIME   = 50011,    // WIFI连接超时
    EN_CFGNET_RT_INTERNAL_ERROR          = 50012     // 内部错误
    
}EN_CFGNET_RT_TYPE;

typedef enum enum_CFG_MSG_TYPE
{
    EN_CFG_MSG_SYNC_FROM_SERVER = 0,
    EN_CFG_MSG_ONLINESTATUS     = 1,  // 设备上线状态
}EN_CFG_MSG_TYPE;


typedef struct str_CFG_ONLINESTATUS_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UI uiOnlineStatus;
}ST_CFG_ONLINESTATUS_MSG;

typedef enum
{
    CFG_AP_MSG   = 0x01,
    CFG_1400_MSG = 0x02,
    CFG_IOT_MSG  = 0x04,
	CFG_IMS_MSG  = 0x08,
} EU_CFG_ONLINESTATUS_MSG;


typedef struct str_CFG_NETDATA_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UC ucNetMsgType;
    _UC ucNetMsgId;
    _UI uiOgctId;
    _VPTR hJsonRoot;
    _UC aucPeerId[CFG_STRING_COMMONLEN + 4];
}ST_CFG_NETDATA_MSG;

typedef struct str_CFG_SERVER_OPTMSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UI uiCfgItem;
}ST_CFG_SERVER_OPTMSG;


typedef struct str_CFG_ITEMSIGN
{
    _UC ucSaveSystem;
    _UC ucSaveCore;
    _UC ucSaveDev;
    _UC ucSaveCamInf;
    _UC ucSaveInIot;
    _UC ucSaveIotHub;
    _UC ucSaveTimePolicy;
    _UC ucSaveAlarmPolicy;
    _UC ucSaveScenePolicy;
    _UC ucSaveGroup;
    _UC ucSavePtz;
    _UC ucSaveServSetFlag;
    _UC ucSaveIotPolicy;
    _UC ucSaveCloudFlag;
    _UC ucSaveCloudPatchFlag;
    _UC ucSaveAiFlag;
    _UC ucSaveImsFlag;

    _UC ucCfgDevUpdate;
    _UC ucCfgCamUpdate;
    _UC ucCfgInIotUpdate;
    _UC ucCfgIotHubUpdate;
    _UC ucCfgTimePolicyUpdate;
    _UC ucAlarmPolicyUpdate;
    _UC ucCfgScenePolicyUpdate;
    _UC ucCfgPtzUpdate;
    _UC ucCfgAiUpdate;

    _UI uiSystemSign;
    _UI uiCoreSign;
    _UI uiDevSign;
    _UI uiCamSign;
    _UI uiInIotSign;
    _UI uiIotHubSign;
    _UI uiTimePolicySign;
    _UI uiAlarmPolicySign;
    _UI uiScenePolicySign;
    _UI uiGroupSign;
    _UI uiPtzSign;
    _UI uiServSetSign;
}ST_CFG_ITEMSIGN;


typedef struct stru_CFG_INF
{
    ST_CFG_GROUPINF             stGroupMng;
    ST_CFG_CORE_MNG             stCoreMng;          // 核心描述 
    ST_CFG_SYSTEM_MNG           stSystemMng;        // 系统信息 
    ST_CFG_DEVICE_MNG           stDeviceMng;        // 设备管理
    ST_CFG_CAMERA_MNG           stCameraMng;        // cam管理
    ST_CFG_INNERIOT_MNG         stInnerIotMng;      // 内置 
    ST_CFG_KJIOTHUB_MNG         stKjIoTHubMng;      // 外接
    ST_CFG_SERVERSET_MNG        stServerSetMng;
    ST_CFG_CLOUDSTG_MNG         stCloudMng;         // 云存
    ST_MOS_LIST                 stTimePolicyList;   // 定时策略
    ST_MOS_LIST                 stIotPolicyList;    // 报警策略
    ST_MOS_LIST                 stScenePolicyList;  // 场景策略
    ST_CFG_ITEMSIGN             stItemSign;
    ST_CFG_AI_MNG               stAiMng;            // AI管理
    ST_CFG_IMS_MNG              stImsMng;           // IMS管理
}ST_CFG_INF;

typedef struct stru_cfg_binddevinf
{
    _UC  ucBindFlag; // 1 需要bind 2 binding 3 binded 4 fail
    _UC  ucGetGroupInfFlag;
    _UC  ucGetUsrInfFlag;
    _UC  ucNeedExitGroup;

    _UC  ucGetDstFlag;

    _CTIME_T cGetDstTime;
    
    _UI  uiReqTime;
    _UI  uiReqID;
    _US  usBuffLen;
    _US  usRecvLen;
    _UC  *pucHttpBuff;
    _UC aucBindCode[CFG_STRING_COMMONLEN + 4];
    _UC aucBindGroupId[CFG_STRING_COMMONLEN];
}ST_CFG_BINDDEVINF;

typedef struct strct_cfg_register_server_info
{
    _UI uiOfficialFlag;
    _UC ucAblPlatRegistUrl[92];
    _UC ucRegisterAddr[92];
}ST_CFG_LOGIN_SERVER_INFO;

typedef struct struct_cfg_extern_info
{
    _UC *pucExtAbilityJson;
    _UI uiExtAbilityJsonLen;
}ST_CFG_EXTINFO;

typedef struct str_CONFIG_MNG
{
    _UC ucInitFlag;
    _UC ucRunFlag;
    _UC ucOnlineStatus;
    _UC ucRsv;
    _UI uiLastTime;
    _HMUTEX hMutex;
    _HQUEUE hMsgQueque;
    _HTHREAD hThread;
    _UC aucCfgPath[MOS_DIR_NAME_LEN];
    _UC aucSystemPath[MOS_DIR_NAME_LEN];
    _UC aucFaceCachePath[MOS_DIR_NAME_LEN];
    _UI uiLoginCount;
    _UI uiDevAbilityUploadRetry;
    _UI uiDevBussUploadRetry;
    _CTIME_T cLastLoginTime;

    ST_CFG_BINDDEVINF stBevBindInf;
    ST_CFG_INF stOwner;
    ST_CFG_EXTINFO stExtCfg;
    ST_CFG_LOGIN_SERVER_INFO stCfgLoginServer;
    ST_MOS_LIST stSyncList;
    ST_MOS_LIST stSyncPoolList;
    ST_MOS_LIST stServSyncList; // 上传 服务器的 配置 列表   
   // ST_MOS_LIST stLogServSyncList; // 上传 log服务器的log列表   
}ST_CONFIG_MNG;


typedef struct ST_CONIFG_COMMON_BUSS_NODE
{
    _UI uiUseFlag;
    ST_MOS_LIST_NODE stNode;
    
}ST_CONIFG_COMMON_BUSS_NODE;

ST_CONFIG_MNG   *Config_Task_GetMng();

ST_CFG_ITEMSIGN *Config_GetItemSign();

ST_CFG_INF      *Config_GetlocalCfgInf();

_INT Config_BegainSyncBussList(ST_MOS_LIST *pstBussList);

_INT Config_EndSyncBussList(ST_MOS_LIST *pstBussList);

ST_CFG_OUTPUT_NODE *Config_FindAndCreatOutNode(ST_MOS_LIST *pstOutputList,_UI uiKjIoTType,_LLID lluKjIotId);

ST_CFG_OUTPUT_NODE *Config_FindOutNode(ST_MOS_LIST *pstOutputList,_UI uiKjIoTType,_LLID lluKjIotId);

#ifdef __cplusplus
}
#endif

#endif

