#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "cloudstg_api.h"

ST_CFG_CLOUDSTG_MNG *Config_GetCloudMng()
{
    return &Config_GetlocalCfgInf()->stCloudMng;
}

_INT Config_Cloud_Init()
{
    CloudStg_Patch_PreInit();
    Mos_MutexCreate(&Config_GetCloudMng()->hCloudPatchMutex);
    MOS_LIST_INIT(&Config_GetCloudMng()->stPatchTaskCfgList);
    Config_GetCloudMng()->iUrlTimerInterval     = CLOUD_RES_WATCHDOG_TIMEOUT;
    return MOS_OK;
}

_INT Config_Cloud_Destroy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskNode = MOS_NULL;
   
    Mos_MutexLock(&Config_GetCloudMng()->hCloudPatchMutex);
    FOR_EACHDATA_INLIST(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode, stIterator)
    {
        MOS_LIST_RMVNODE(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode);
        Mos_MemFree(pstPatchTaskNode);
    }
    Mos_MutexUnLock(&Config_GetCloudMng()->hCloudPatchMutex);
    
    Mos_MutexDelete(&Config_GetCloudMng()->hCloudPatchMutex);
    MOS_LOG_INF(CFG_LOGSTR,"Config Cloud Destroy Ok");
    return MOS_OK;
}

_INT Config_SetAppKey(_UC *pucAppKey)
{
    MOS_PARAM_NULL_RETERR(pucAppKey);

    if(MOS_STRCMP(Config_GetCloudMng()->aucAppKey,pucAppKey) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCloudMng()->aucAppKey,pucAppKey,sizeof(Config_GetCloudMng()->aucAppKey));
    Config_GetItemSign()->ucSaveCloudFlag = 1;
    MOS_PRINTF_DEBUG(CFG_LOGSTR,"cloudstg_inf set AppKey %s",pucAppKey);
    return MOS_OK;
}

_INT Config_SetAppSecret(_UC *pucAppSecret)
{
    MOS_PARAM_NULL_RETERR(pucAppSecret);

    if(MOS_STRCMP(Config_GetCloudMng()->aucAppSecret,pucAppSecret) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCloudMng()->aucAppSecret,pucAppSecret,sizeof(Config_GetCloudMng()->aucAppSecret));
    Config_GetItemSign()->ucSaveCloudFlag = 1;
    MOS_PRINTF_DEBUG(CFG_LOGSTR,"cloudstg_inf set AppSecret %s",pucAppSecret);

    return MOS_OK;
}

_INT Config_SetAESVI(_UC *pucAESVI)
{
    MOS_PARAM_NULL_RETERR(pucAESVI);

    if(MOS_STRCMP(Config_GetCloudMng()->aucAESVI,pucAESVI) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetCloudMng()->aucAESVI,pucAESVI,sizeof(Config_GetCloudMng()->aucAESVI));
    Config_GetItemSign()->ucSaveCloudFlag = 1;
    MOS_PRINTF_DEBUG(CFG_LOGSTR,"cloudstg_inf set AESVI %s",pucAESVI);

    return MOS_OK;
}

_INT Config_SetCloudId(_UC *pucCloudId)
{
    MOS_PARAM_NULL_RETERR(pucCloudId);

    if(MOS_STRCMP(Config_GetCloudMng()->aucCloudId,pucCloudId) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudId,pucCloudId,sizeof(Config_GetCloudMng()->aucCloudId));
    Config_GetItemSign()->ucSaveCloudFlag = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudId %s",pucCloudId);
    return MOS_OK;

}

_INT Config_SetCloudAbility(_INT iCloudAbility)
{
    if(iCloudAbility == Config_GetCloudMng()->iCloudAbility)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iCloudAbility = iCloudAbility;
    Config_GetItemSign()->ucSaveCloudFlag = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudAbility %u",iCloudAbility);
    return MOS_OK;
}

_INT Config_SetCloudUpLoadMode(_INT iUpLoadMode)
{
    if(iUpLoadMode == Config_GetCloudMng()->iCloudUpLoadMode)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iCloudUpLoadMode = iUpLoadMode;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudUpLoadMode %u",iUpLoadMode);
    return MOS_OK;
}

_INT Config_SetStreamID(_INT iStreamID)
{
    if(iStreamID == Config_GetCloudMng()->iStreamID)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iStreamID = iStreamID;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set StreamID %u",iStreamID);
    return MOS_OK;
}

_INT Config_SetCloudIconType(_INT iCloudIconType)
{
    if(iCloudIconType == Config_GetCloudMng()->iCloudIconType)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iCloudIconType = iCloudIconType;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudIconType %u",iCloudIconType);
    return MOS_OK;
}
_BOOL Config_NeedGenerateCloudEnc(_INT iNewCloudEncSwitch)
{
    if(iNewCloudEncSwitch != 1 && iNewCloudEncSwitch != 2)
    {
        return MOS_FALSE;
    }
    if(iNewCloudEncSwitch == 2)
    {
        return MOS_TRUE;//更新加密信息
    }
    else if(iNewCloudEncSwitch != Config_GetCloudMng()->iCloudEncSwitch)
    {
        return MOS_TRUE;//切换加密开关
    }
    else
    {
        return MOS_FALSE;
    }
}

_INT Config_SetUrlTimerInterval(_INT iUrlTimerInterval)
{
    if(iUrlTimerInterval == Config_GetCloudMng()->iUrlTimerInterval)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iUrlTimerInterval = iUrlTimerInterval;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set UrlTimerInterval %u",iUrlTimerInterval);
    return MOS_OK;
}

_INT Config_SetCloudEncPKId(_INT iCloudEncPKId)
{
    MOS_PARAM_NULL_RETERR(iCloudEncPKId);
    if(iCloudEncPKId == Config_GetCloudMng()->iCloudEncPKId)
    {
        return MOS_OK;
    }

    Config_GetCloudMng()->iCloudEncPKId = iCloudEncPKId;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudEncPKId %d",iCloudEncPKId);
    return MOS_OK;
}

_INT Config_SetCloudEncPKValue(_UC *pucCloudEncPKValue)
{
    MOS_PARAM_NULL_RETERR(pucCloudEncPKValue);
    if (MOS_STRLEN(pucCloudEncPKValue) == 0)
    {
        return MOS_OK;
    }

    if(Config_GetCloudMng()->aucCloudEncPKValue && MOS_STRCMP(pucCloudEncPKValue, Config_GetCloudMng()->aucCloudEncPKValue) == 0)
    {
        return MOS_OK;
    }

    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncPKValue,pucCloudEncPKValue,sizeof(Config_GetCloudMng()->aucCloudEncPKValue));
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudEncPKValue %s",pucCloudEncPKValue);
    return MOS_OK;
}

_INT Config_SetCloudEncSwitch(_INT iCloudEncSwitch)
{
    if(iCloudEncSwitch != 1 && iCloudEncSwitch != 2)
    {
        return MOS_OK;
    }
    if(iCloudEncSwitch == Config_GetCloudMng()->iCloudEncSwitch)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iCloudEncSwitch = iCloudEncSwitch;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudEncSwitch %u",iCloudEncSwitch);
    return MOS_OK;
}

_INT Config_SetCloudEncType(_INT iCloudEncType)
{
    if(iCloudEncType == Config_GetCloudMng()->iCloudEncType)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iCloudEncType = iCloudEncType;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudEncType %u",iCloudEncType);
    return MOS_OK;
}

_INT Config_SetCloudEncLen(_INT iCloudEncLen)
{
    if(iCloudEncLen == Config_GetCloudMng()->iCloudEncLen)
    {
        return MOS_OK;
    }   
    if(iCloudEncLen != -1 && iCloudEncLen != 32)
    {
        return MOS_OK;
    }
    Config_GetCloudMng()->iCloudEncLen = iCloudEncLen;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set CloudEncLen %u",iCloudEncLen);
    return MOS_OK;
}

_INT Config_SetIframeKey(_UC* pucKey)
{
    MOS_PARAM_NULL_RETERR(pucKey);

    if(Config_GetCloudMng()->aucIframeKey && MOS_STRCMP(pucKey,Config_GetCloudMng()->aucIframeKey) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetCloudMng()->aucIframeKey,pucKey,sizeof(Config_GetCloudMng()->aucIframeKey));
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set IframeKey %s",pucKey);
    return MOS_OK;
}

_INT Config_SetCloudEncHttpParamJson(_UC* pucCloudEncHttpParamJson)
{
    MOS_PARAM_NULL_RETERR(pucCloudEncHttpParamJson);

    if(Config_GetCloudMng()->aucCloudEncHttpParamJson && MOS_STRCMP(pucCloudEncHttpParamJson,Config_GetCloudMng()->aucCloudEncHttpParamJson) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncHttpParamJson,pucCloudEncHttpParamJson,sizeof(Config_GetCloudMng()->aucCloudEncHttpParamJson));
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set pucCloudEncHttpParamJson %s",pucCloudEncHttpParamJson);
    return MOS_OK;
}

_INT Config_SetCloudEncHttpParam(_UC* pucCloudEncHttpParam)
{
    MOS_PARAM_NULL_RETERR(pucCloudEncHttpParam);

    if(Config_GetCloudMng()->aucCloudEncHttpParam && MOS_STRCMP(pucCloudEncHttpParam,Config_GetCloudMng()->aucCloudEncHttpParam) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncHttpParam,pucCloudEncHttpParam,sizeof(Config_GetCloudMng()->aucCloudEncHttpParam));
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set pucCloudEncHttpParam %s",pucCloudEncHttpParam);
    return MOS_OK;
}

_INT Config_SetCloudEncHttpUploadParam(_UC* pucCloudEncHttpUploadParam)
{
    MOS_PARAM_NULL_RETERR(pucCloudEncHttpUploadParam);

    if(Config_GetCloudMng()->aucCloudEncHttpUploadParam && MOS_STRCMP(pucCloudEncHttpUploadParam,Config_GetCloudMng()->aucCloudEncHttpUploadParam) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncHttpUploadParam,pucCloudEncHttpUploadParam,sizeof(Config_GetCloudMng()->aucCloudEncHttpUploadParam));
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    // MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set pucCloudEncHttpUploadParam %s",pucCloudEncHttpUploadParam);
    return MOS_OK;
}

_INT Config_SetPackageType(_INT iPackageType)
{
    if(iPackageType == Config_GetCloudMng()->iPackageType)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iPackageType = iPackageType;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set iPackageType %u",iPackageType);
    return MOS_OK;
}

_INT Config_SetCloudStreamType(_INT iCloudStreamType)
{
    if(iCloudStreamType == Config_GetCloudMng()->iCloudStreamType)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iCloudStreamType = iCloudStreamType;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set iCloudStreamType %u",iCloudStreamType);
    return MOS_OK;
}

_INT Config_SetCloudAccount(_UC* pucAccount)
{
    MOS_PARAM_NULL_RETERR(pucAccount);

    if(Config_GetCloudMng()->aucCloudAccount && MOS_STRCMP(pucAccount,Config_GetCloudMng()->aucCloudAccount) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudAccount,pucAccount,sizeof(Config_GetCloudMng()->aucCloudAccount));
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set cloud account %s",pucAccount);
    return MOS_OK;
}

// 设置常驻Tcping flag 0-非常驻，1-常驻
_INT Config_setNetCheckPermanent(_BOOL bNetCheckPermanent)
{
    if(bNetCheckPermanent == Config_GetCloudMng()->bNetCheckPermanent)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->bNetCheckPermanent = bNetCheckPermanent;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set NetCheckPermanent %d", bNetCheckPermanent);
    return MOS_OK;
}

// 设置常驻Tcping域名数量
_INT Config_SetNetCheckHostNum(_INT iNetCheckHostNum)
{
    if(iNetCheckHostNum == Config_GetCloudMng()->iNetCheckHostNum)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iNetCheckHostNum = iNetCheckHostNum;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set NetCheckHostNum %d", iNetCheckHostNum);
    return MOS_OK;
}

// 设置常驻Tcping采集周期（s）
_INT Config_SetNetCheckCollectFreq(_INT iNetCheckCollectFreq)
{
    if(iNetCheckCollectFreq == Config_GetCloudMng()->iNetCheckCollectFreq)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iNetCheckCollectFreq = iNetCheckCollectFreq;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set NetCheckCollectFreq %d", iNetCheckCollectFreq);
    return MOS_OK;
}

// 设置常驻Tcping间隔（s）
_INT Config_SetNetCheckDetectFreq(_INT iNetCheckDetectFreq)
{
    if(iNetCheckDetectFreq == Config_GetCloudMng()->iNetCheckDetectFreq)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iNetCheckDetectFreq = iNetCheckDetectFreq;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set NetCheckDetectFreq %d", iNetCheckDetectFreq);
    return MOS_OK;
}

// 设置常驻Tcping数量
_INT Config_SetNetCheckDetectCount(_INT iNetCheckDetectCount)
{
    if(iNetCheckDetectCount == Config_GetCloudMng()->iNetCheckDetectCount)
    {
        return MOS_OK;
    }   
    Config_GetCloudMng()->iNetCheckDetectCount = iNetCheckDetectCount;
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set NetCheckDetectCount %d", iNetCheckDetectCount);
    return MOS_OK;
}

// 设置常驻Tcping域名id
_INT Config_SetNetCheckSiteId(_INT *piNetCheckSiteId, _INT iLen)
{
    MOS_PARAM_NULL_RETERR(piNetCheckSiteId);
    _INT i = 0;

    if (iLen > sizeof(Config_GetCloudMng()->piNetCheckSiteId))
    {
        MOS_LOG_ERR(CFG_LOGSTR,"recv wrong NetCheckSiteId len: %d", iLen);
        return MOS_OK;
    }

    MOS_MEMCPY(Config_GetCloudMng()->piNetCheckSiteId, piNetCheckSiteId, iLen);
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set NetCheckSiteId");
    for (i = 0; i < Config_GetCloudMng()->iNetCheckHostNum; i++)
    {
        MOS_LOG_INF(CFG_LOGSTR,"%d", Config_GetCloudMng()->piNetCheckSiteId[i]);
    }

    return MOS_OK;
}

// 设置常驻Tcping域名
_INT Config_SetNetCheckHost(_UC **pucNetCheckHost, _INT iLen)
{
    MOS_PARAM_NULL_RETERR(pucNetCheckHost);
    _INT i = 0;

    if (iLen > sizeof(Config_GetCloudMng()->aucNetCheckHost))
    {
        MOS_LOG_ERR(CFG_LOGSTR,"recv wrong NetCheckHost len: %d", iLen);
        return MOS_OK;
    }

    MOS_MEMCPY(Config_GetCloudMng()->aucNetCheckHost, pucNetCheckHost, iLen);
    Config_GetItemSign()->ucSaveCloudFlag  = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cloudstg_inf set NetCheckHost");
    for (i = 0; i < Config_GetCloudMng()->iNetCheckHostNum; i++)
    {
        MOS_LOG_INF(CFG_LOGSTR,"%s", Config_GetCloudMng()->aucNetCheckHost[i]);
    }

    return MOS_OK;
}

_VPTR Config_BuildCloudSetObject()
{
    _INT i = 0;
    JSON_HANDLE hRoot        = Adpt_Json_CreateObject();
    JSON_HANDLE hSiteIdArray = Adpt_Json_CreateArray();
    JSON_HANDLE hHostArray   = Adpt_Json_CreateArray();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AESVI",Adpt_Json_CreateString(Config_GetCloudMng()->aucAESVI));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AppKey",Adpt_Json_CreateString(Config_GetCloudMng()->aucAppKey));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AppSecret",Adpt_Json_CreateString(Config_GetCloudMng()->aucAppSecret));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudId",Adpt_Json_CreateString(Config_GetCloudMng()->aucCloudId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudAbility",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iCloudAbility));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudLoadMode",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iCloudUpLoadMode));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"StreamID",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iStreamID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudIconType",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iCloudIconType));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudStreamType",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iCloudStreamType));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudAccount",Adpt_Json_CreateString(Config_GetCloudMng()->aucCloudAccount));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"UrlTimerInterval",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iUrlTimerInterval));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncPKId",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iCloudEncPKId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncPKValue",Adpt_Json_CreateString(Config_GetCloudMng()->aucCloudEncPKValue));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncSwitch",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iCloudEncSwitch));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncType",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iCloudEncType));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncLen",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iCloudEncLen));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncAesKey",Adpt_Json_CreateString(Config_GetCloudMng()->aucCloudEncAesKey));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncAesIv",Adpt_Json_CreateString(Config_GetCloudMng()->aucCloudEncAesIv));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncHttpParamJson",Adpt_Json_CreateString(Config_GetCloudMng()->aucCloudEncHttpParamJson));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncHttpParam",Adpt_Json_CreateString(Config_GetCloudMng()->aucCloudEncHttpParam));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudEncHttpUploadParam",Adpt_Json_CreateString(Config_GetCloudMng()->aucCloudEncHttpUploadParam));

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"NetCheckPermanent",Adpt_Json_CreateBool(Config_GetCloudMng()->bNetCheckPermanent));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"NetCheckHostNum",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iNetCheckHostNum));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"NetCheckCollectFreq",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iNetCheckCollectFreq));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"NetCheckDetectFreq",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iNetCheckDetectFreq));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"NetCheckDetectCount",Adpt_Json_CreateStrWithNum(Config_GetCloudMng()->iNetCheckDetectCount));
    
    for (i = 0; i < Config_GetCloudMng()->iNetCheckHostNum; i++)
    {
        Adpt_Json_AddItemToObject(hSiteIdArray, "", Adpt_Json_CreateNumber(Config_GetCloudMng()->piNetCheckSiteId[i]));
    }
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"NetCheckSiteId", hSiteIdArray);
    for (i = 0; i < Config_GetCloudMng()->iNetCheckHostNum; i++)
    {
        Adpt_Json_AddItemToObject(hHostArray, "", Adpt_Json_CreateString(Config_GetCloudMng()->aucNetCheckHost[i]));
    }
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"NetCheckHost", hHostArray);
    return hRoot;
}

_UC *Config_BuildCloudSetJson()
{
    _UC *pStrTmp = MOS_NULL;    
    JSON_HANDLE hRoot     = Config_BuildCloudSetObject();
    
    pStrTmp = Adpt_Json_Print(hRoot);
    // MOS_LOG_INF(CFG_LOGSTR,"build cloud info %s",pStrTmp);
    
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}

// 读取云存配置的字段
_INT Config_ParseCloudSetJson(_UC *pStrJson)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    MOS_PRINTF("pStrJson: %s\r\n", pStrJson);
    _INT i = 0;
    _UC *pStrTmp = MOS_NULL;
    _BOOL bTmp   = MOS_FALSE;
    JSON_HANDLE hRoot        = Adpt_Json_Parse(pStrJson);
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 云存加密算法，支持：1-AES128；2-AES192；3-AES256（默认） ？？？
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AESVI"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucAESVI, pStrTmp, sizeof(Config_GetCloudMng()->aucAESVI));
    
    // APP密钥
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AppKey"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucAppKey, pStrTmp, sizeof(Config_GetCloudMng()->aucAppKey));
    
    // APP加密
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AppSecret"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucAppSecret, pStrTmp, sizeof(Config_GetCloudMng()->aucAppSecret));
    
    // 云存ID
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudId"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudId, pStrTmp, sizeof(Config_GetCloudMng()->aucCloudId));

    // 云存账号
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudAccount"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudAccount, pStrTmp, sizeof(Config_GetCloudMng()->aucCloudAccount));
    
    // 是否支持云存能力 云存能力支持  0.不支持； 1.支持
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudAbility"),&Config_GetCloudMng()->iCloudAbility);
    // 云存加载上报模式 1.事件上报 2.全天上报
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudLoadMode"),&Config_GetCloudMng()->iCloudUpLoadMode);
    // 录制码流选择。0.主码流；1.次码流
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StreamID"),&Config_GetCloudMng()->iStreamID);
    // 是否需要上传封面（默认），0：开启；1：关闭
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudIconType"),&Config_GetCloudMng()->iCloudIconType);
    // 云存流的编码类型

    // 获取地址看门狗interval，默认30min
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"UrlTimerInterval"),&Config_GetCloudMng()->iUrlTimerInterval);
    Config_GetCloudMng()->iUrlTimerInterval = (Config_GetCloudMng()->iUrlTimerInterval<=0)?CLOUD_RES_WATCHDOG_TIMEOUT:Config_GetCloudMng()->iUrlTimerInterval;
    MOS_LOG_WARN(CFG_LOGSTR, "read UrlTimerInterval %dmin", Config_GetCloudMng()->iUrlTimerInterval);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncPKId"),&Config_GetCloudMng()->iCloudEncPKId);
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncPKValue"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncPKValue, pStrTmp, sizeof(Config_GetCloudMng()->aucCloudEncPKValue));

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncSwitch"),&Config_GetCloudMng()->iCloudEncSwitch);
    // DEBUG: 打开云存加密开关
    // Config_GetCloudMng()->iCloudEncSwitch = 1;
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncType"),&Config_GetCloudMng()->iCloudEncType);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncLen"),&Config_GetCloudMng()->iCloudEncLen);
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncAesKey"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncAesKey, pStrTmp, sizeof(Config_GetCloudMng()->aucCloudEncAesKey));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncAesIv"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncAesIv, pStrTmp, sizeof(Config_GetCloudMng()->aucCloudEncAesIv));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncHttpParamJson"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncHttpParamJson, pStrTmp, sizeof(Config_GetCloudMng()->aucCloudEncHttpParamJson));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncHttpParam"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncHttpParam, pStrTmp, sizeof(Config_GetCloudMng()->aucCloudEncHttpParam));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudEncHttpUploadParam"),&pStrTmp);
    MOS_STRNCPY(Config_GetCloudMng()->aucCloudEncHttpUploadParam, pStrTmp, sizeof(Config_GetCloudMng()->aucCloudEncHttpUploadParam));

    Adpt_Json_GetBool(Adpt_Json_GetObjectItem(hRoot,(_UC*)"NetCheckPermanent"),&bTmp);
    Config_GetCloudMng()->bNetCheckPermanent = (bTmp==EN_ITRD_JSON_NODE_TYPE_TRUE)?MOS_TRUE:MOS_FALSE;
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"NetCheckHostNum"),&Config_GetCloudMng()->iNetCheckHostNum);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"NetCheckCollectFreq"),&Config_GetCloudMng()->iNetCheckCollectFreq);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"NetCheckDetectFreq"),&Config_GetCloudMng()->iNetCheckDetectFreq);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"NetCheckDetectCount"),&Config_GetCloudMng()->iNetCheckDetectCount);
    for (i = 0; i < Config_GetCloudMng()->iNetCheckHostNum; i++)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetArrayItem(Adpt_Json_GetObjectItem(hRoot, (_UC*)"NetCheckSiteId"), i),&Config_GetCloudMng()->piNetCheckSiteId[i]);
        Adpt_Json_GetString(Adpt_Json_GetArrayItem(Adpt_Json_GetObjectItem(hRoot, (_UC*)"NetCheckHost"), i),&pStrTmp);
        MOS_STRNCPY(Config_GetCloudMng()->aucNetCheckHost[i], pStrTmp, sizeof(Config_GetCloudMng()->aucNetCheckHost[i]));
    }
    
    Adpt_Json_Delete( hRoot);
    return MOS_OK;
}


