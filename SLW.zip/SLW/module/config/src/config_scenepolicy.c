#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"

ST_MOS_LIST *Config_GetScenePolicyList()
{
    return &Config_GetlocalCfgInf()->stScenePolicyList;
}

ST_CFG_SCENEPOLICY_NODE *Config_FindScenePolicyNode(_UI uiSceneId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_SCENEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    FOR_EACHDATA_INLIST(Config_GetScenePolicyList(), pstPolicyNode, stIterator)
    {
        if(pstPolicyNode->uiSceneId == uiSceneId && pstPolicyNode->uiUseFlag == 1)
        {
            break;
        }
    }
    return pstPolicyNode;
}

ST_CFG_SCENEPOLICY_NODE* Config_FindOrCreatScenePolicy(_UI uiSceneId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_SCENEPOLICY_NODE *pstPolicyNode    = MOS_NULL;
    ST_CFG_SCENEPOLICY_NODE *pstPolicyNodeTmp = MOS_NULL;

    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(Config_GetScenePolicyList(), pstPolicyNode, stIterator)
    {
        if(pstPolicyNode->uiSceneId == uiSceneId && pstPolicyNode->uiUseFlag == 1)
        {
            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);  
            return pstPolicyNode;
        }
        else if(pstPolicyNode->uiUseFlag == 0)
        {
            pstPolicyNodeTmp = pstPolicyNode;
        }
    }
    if(pstPolicyNodeTmp == MOS_NULL)
    {
        pstPolicyNodeTmp = (ST_CFG_SCENEPOLICY_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_SCENEPOLICY_NODE));
        MOS_LIST_ADDTAIL(Config_GetScenePolicyList(), pstPolicyNodeTmp);
    }
    pstPolicyNodeTmp->uiSceneId  = uiSceneId;
    pstPolicyNodeTmp->uiUseFlag  = 1;
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);  
    return pstPolicyNode;
}

_INT Config_SetScenePolicyName(ST_CFG_SCENEPOLICY_NODE *pstPolicyNode,_UC *pucPolicyName)
{
    MOS_PARAM_NULL_RETERR(pstPolicyNode);
    MOS_PARAM_NULL_RETERR(pucPolicyName);

    if(MOS_STRCMP(pstPolicyNode->aucPolicyName ,pucPolicyName) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(pstPolicyNode->aucPolicyName, pucPolicyName, sizeof(pstPolicyNode->aucPolicyName));
    Config_GetItemSign()->ucSaveScenePolicy      = 1;
    Config_GetItemSign()->ucCfgScenePolicyUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_ScenePolicy set PolicyName %s",pucPolicyName);
    return MOS_OK;
}

_INT Config_AddScenePolicyOutput(ST_CFG_SCENEPOLICY_NODE *pstPolicyNode,_UI uiOutIotType,_LLID lluOutIotId,_UC *pucParam)
{
    MOS_PARAM_NULL_RETERR(pstPolicyNode);
    MOS_PARAM_NULL_RETERR(pucParam);

    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;

    Mos_MutexLock(&Config_Task_GetMng()->hMutex);  
    pstOutputNode = Config_FindAndCreatOutNode(&pstPolicyNode->stOutputList,uiOutIotType,lluOutIotId);
    if(pstOutputNode->uiParamLen < MOS_STRLEN(pucParam))
    {
        MOS_FREE(pstOutputNode->pucParam);
        pstOutputNode->uiParamLen = MOS_STRLEN(pucParam) + 128;
        pstOutputNode->pucParam   = MOS_MALLOCCLR(pstOutputNode->uiParamLen);
    }
    MOS_STRNCPY(pstOutputNode->pucParam,pucParam,pstOutputNode->uiParamLen);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    Config_GetItemSign()->ucSaveScenePolicy = 1;
    Config_GetItemSign()->ucCfgScenePolicyUpdate = 1;
    return MOS_OK;
}

// 场景策略删除
_INT Config_DeleteScenePolicy(_UI uiSceneId)
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_SCENEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(Config_GetScenePolicyList(), pstPolicyNode, stIterator)
    {
        if(pstPolicyNode->uiSceneId == uiSceneId)
        {
            pstPolicyNode->uiUseFlag = 0;  
            FOR_EACHDATA_INLIST(&pstPolicyNode->stOutputList, pstOutputNode, stIterator1)
            {
                pstOutputNode->uiUseFlag = 0;
            }
            break;
        }
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    Config_GetItemSign()->ucSaveScenePolicy = 1;
    Config_GetItemSign()->ucCfgScenePolicyUpdate = 1;
    return MOS_OK;
}

_INT Config_ScenePolicyDestroy()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_SCENEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);    
    FOR_EACHDATA_INLIST(Config_GetScenePolicyList(), pstPolicyNode, stIterator)
    {
        FOR_EACHDATA_INLIST(&pstPolicyNode->stOutputList, pstOutputNode, stIterator1)
        {
            MOS_FREE(pstOutputNode->pucParam);
            MOS_LIST_RMVNODE(&pstPolicyNode->stOutputList, pstOutputNode);
            MOS_FREE(pstOutputNode);
        }
        MOS_LIST_RMVNODE(Config_GetScenePolicyList(), pstPolicyNode);
        MOS_FREE(pstPolicyNode);
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    
    MOS_LOG_INF(CFG_LOGSTR,"cfg_ScenePolicy destroy ok");
    return MOS_OK;
}
/***********************************************************************
*************************************************************************/
_VPTR Config_BuildScenePolicyObject(_UI uiCfgType)
{
    _UC aucBuff[64];
    _UC *pStrTmp             = MOS_NULL;
    JSON_HANDLE hParam       = MOS_NULL;
    JSON_HANDLE hSceneArray    = MOS_NULL;
    JSON_HANDLE hSceneItem     = MOS_NULL;
    JSON_HANDLE hOutputItem  = MOS_NULL;
    JSON_HANDLE hOutPutArray = MOS_NULL; 
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    ST_CFG_SCENEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    JSON_HANDLE hRoot       = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiScenePolicySign));
    
    hSceneArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Scene",hSceneArray);
    
    FOR_EACHDATA_INLIST(Config_GetScenePolicyList(), pstPolicyNode, stIterator)
    {
        if(pstPolicyNode->uiUseFlag == 0)
        {
            continue;
        }
        hSceneItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hSceneArray,hSceneItem);

        Adpt_Json_AddItemToObject(hSceneItem,(_UC*)"SceneName",Adpt_Json_CreateString(pstPolicyNode->aucPolicyName));
        Adpt_Json_AddItemToObject(hSceneItem,(_UC*)"SceneID",Adpt_Json_CreateStrWithNum(pstPolicyNode->uiSceneId));

        hOutPutArray = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hSceneItem,(_UC*)"Action",hOutPutArray);
        
        FOR_EACHDATA_INLIST(&pstPolicyNode->stOutputList, pstOutputNode, stIterator1)
        {
            if(pstOutputNode->uiUseFlag == 0){
                continue;
            }
            hOutputItem = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hOutPutArray,hOutputItem);
            
            Adpt_Json_AddItemToObject(hOutputItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstOutputNode->uiKjIoTType));
            MOS_VSNPRINTF(aucBuff, 64, "%llu",pstOutputNode->lluKjIotId);
            Adpt_Json_AddItemToObject(hOutputItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));
            Mos_MutexLock(&Config_Task_GetMng()->hMutex); 
            if(pstOutputNode->pucParam)
            {
                hParam   = Adpt_Json_Parse(pstOutputNode->pucParam);
                Adpt_Json_AddItemToObject(hOutputItem,(_UC*)"Output",hParam);
            }
            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
        }
    }
    
    return hRoot;
}

_UC *Config_BuildScenePolicyJson(_UI uiCfgType)
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = Config_BuildScenePolicyObject(uiCfgType);
    
    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(CFG_LOGSTR,"build scene policy info %s",pStrTmp);
    return pStrTmp;
}

_INT Config_ParseScenePolicyJson(_UC *pStrJson,_UI uiCfgType)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _INT i,iArrySize;
    _INT j, jOutputArraySize = 0;
    _UI uiSceneId   = 0;
    _UI uiKjIoTType  = 0;
    _LLID lluKjIoTId = 0;
    _UC *pStrTmp            = MOS_NULL;
    JSON_HANDLE hObject     = MOS_NULL;
    JSON_HANDLE hSceneArray   = MOS_NULL;
    JSON_HANDLE hSceneItem    = MOS_NULL;
    JSON_HANDLE hArrayOutputItem   = MOS_NULL;
    JSON_HANDLE hArrayOutput = MOS_NULL;
    ST_CFG_OUTPUT_NODE *pstOutputNode     = MOS_NULL;
    ST_CFG_SCENEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);
    
    MOS_LOG_INF(CFG_LOGSTR,"parse json of cfg_ScenePolicy");
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiScenePolicySign);
    
    hSceneArray = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Scene"); 
    iArrySize = Adpt_Json_GetArraySize(hSceneArray);
    for(i = 0; i < iArrySize; i++)
    {
        hSceneItem = Adpt_Json_GetArrayItem(hSceneArray, i);

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSceneItem,(_UC*)"SceneID"),(_INT*)&uiSceneId);
        pstPolicyNode = Config_FindOrCreatScenePolicy(uiSceneId);
        
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSceneItem,(_UC*)"SceneName"),&pStrTmp);
        Config_SetScenePolicyName(pstPolicyNode,pStrTmp);
        
        hArrayOutput = Adpt_Json_GetObjectItem(hSceneItem,(_UC*)"Action");
        jOutputArraySize = Adpt_Json_GetArraySize(hArrayOutput);
        for(j = 0; j < jOutputArraySize; j++)
        {
            hArrayOutputItem = Adpt_Json_GetArrayItem(hArrayOutput,j);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayOutputItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayOutputItem,(_UC*)"AIIoTID"),&pStrTmp);
            MOS_SSCANF(pStrTmp, "%llu",&lluKjIoTId);

            pstOutputNode = Config_FindAndCreatOutNode(&pstPolicyNode->stOutputList,uiKjIoTType,lluKjIoTId);
            
            hObject = Adpt_Json_GetObjectItem(hArrayOutputItem,(_UC*)"Output");
            pStrTmp = Adpt_Json_Print(hObject);  

            Mos_MutexLock(&Config_Task_GetMng()->hMutex);
            if(pstOutputNode->uiParamLen < MOS_STRLEN(pStrTmp))
            {
                MOS_FREE(pstOutputNode->pucParam);
                pstOutputNode->uiParamLen = MOS_STRLEN(pStrTmp) + 128;
                pstOutputNode->pucParam = MOS_MALLOCCLR(pstOutputNode->uiParamLen);
            }
            MOS_STRNCPY(pstOutputNode->pucParam,pStrTmp,pstOutputNode->uiParamLen);
            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
            
            MOS_FREE(pStrTmp);
        }
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}



