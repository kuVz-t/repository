#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"

/************************************************************************
*************************************************************************/
ST_CFG_GROUPINF *Config_GetGroupInf() 
{
   return &Config_Task_GetMng()->stOwner.stGroupMng;
}

_INT Config_SetDevGrpId(_UC *pucGrpid)
{
    MOS_PARAM_NULL_RETERR(pucGrpid);

    if(MOS_STRCMP(Config_GetGroupInf()->aucGrpid,pucGrpid) == 0)
    {
        return MOS_OK;
    }
    Config_GetGroupInf()->aucOwnerId[0] = 0;
    MOS_STRNCPY(Config_GetGroupInf()->aucGrpid, pucGrpid,sizeof(Config_GetGroupInf()->aucGrpid));
    Config_GetItemSign()->ucSaveGroup = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_group set GroupId %s",pucGrpid);
    return MOS_OK;
}

_INT Config_SetDevGroupOwnerId(_UC *pucOwnerId)
{
    MOS_PARAM_NULL_RETERR(pucOwnerId);

    if(MOS_STRCMP(Config_GetGroupInf()->aucOwnerId,pucOwnerId) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetGroupInf()->aucOwnerId, pucOwnerId,sizeof(Config_GetGroupInf()->aucOwnerId));
    if(MOS_STRLEN(pucOwnerId) > 0)
    {
        Config_Task_GetMng()->stBevBindInf.ucGetUsrInfFlag = 1;
    }
    else
    {
        Config_Task_GetMng()->stBevBindInf.ucGetUsrInfFlag = 0;
    }
    Config_GetItemSign()->ucSaveGroup = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_group set Group OwnerId %s",pucOwnerId);
    return MOS_OK;
}

_INT Config_SetDevOwnerPubInf(_UC *pucName,_UC *pucAccount,_UC *pucMobile)
{
    MOS_PARAM_NULL_RETERR(pucName);
    MOS_PARAM_NULL_RETERR(pucAccount);
    MOS_PARAM_NULL_RETERR(pucMobile);

    if( MOS_STRCMP(Config_GetGroupInf()->aucOwnerName,pucName) == 0 && 
        MOS_STRCMP(Config_GetGroupInf()->aucOwnerAccout,pucAccount) == 0 && 
        MOS_STRCMP(Config_GetGroupInf()->aucOwnerMobile,pucMobile) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetGroupInf()->aucOwnerName,   pucName,   sizeof(Config_GetGroupInf()->aucOwnerName));
    MOS_STRNCPY(Config_GetGroupInf()->aucOwnerAccout, pucAccount,sizeof(Config_GetGroupInf()->aucOwnerAccout));
    MOS_STRNCPY(Config_GetGroupInf()->aucOwnerMobile, pucMobile, sizeof(Config_GetGroupInf()->aucOwnerMobile));
    Config_GetItemSign()->ucSaveGroup = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_group set Owner PubInf:Name %s,Accout %s,Mobile %s",
        Config_GetGroupInf()->aucOwnerName, Config_GetGroupInf()->aucOwnerAccout, Config_GetGroupInf()->aucOwnerMobile);
    return MOS_OK;
}

_UC *Config_BuildGroupInfItem()
{
    _UC *pstrTmp = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"grpid",Adpt_Json_CreateString(Config_GetGroupInf()->aucGrpid));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"OwnerId",Adpt_Json_CreateString(Config_GetGroupInf()->aucOwnerId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Name",Adpt_Json_CreateString(Config_GetGroupInf()->aucOwnerName));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Accout",Adpt_Json_CreateString(Config_GetGroupInf()->aucOwnerAccout));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Mobile",Adpt_Json_CreateString(Config_GetGroupInf()->aucOwnerMobile));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiGroupSign));
    pstrTmp = Adpt_Json_Print(hRoot);
    
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(CFG_LOGSTR,"build group info %s ",pstrTmp);
    return pstrTmp;
}

// 读取Group组配置的字段
_INT Config_ParseGroupInfItem(_UC *pucJsonBuff)
{
    MOS_PARAM_NULL_RETERR(pucJsonBuff);

    _UC *pstrTmp      = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJsonBuff);
    
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    // 组ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"grpid"),&pstrTmp);
    MOS_STRNCPY(Config_GetGroupInf()->aucGrpid, pstrTmp,sizeof(Config_GetGroupInf()->aucGrpid));
    
    // 拥有者ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OwnerId"),&pstrTmp);
    MOS_STRNCPY(Config_GetGroupInf()->aucOwnerId, pstrTmp,sizeof(Config_GetGroupInf()->aucOwnerId));

    // 拥有者名
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Name"),&pstrTmp);
    MOS_STRNCPY(Config_GetGroupInf()->aucOwnerName, pstrTmp,sizeof(Config_GetGroupInf()->aucOwnerName));

    // 拥有者账户
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Accout"),&pstrTmp);
    MOS_STRNCPY(Config_GetGroupInf()->aucOwnerAccout, pstrTmp,sizeof(Config_GetGroupInf()->aucOwnerAccout));

    // 拥有者手机
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Mobile"),&pstrTmp);
    MOS_STRNCPY(Config_GetGroupInf()->aucOwnerMobile, pstrTmp,sizeof(Config_GetGroupInf()->aucOwnerMobile));
    
    // 每个配置项的版本ID  设备端生成
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"sign"),(_INT*)&Config_GetItemSign()->uiGroupSign);

    Adpt_Json_Delete(hRoot);
    
    return MOS_OK;
}

