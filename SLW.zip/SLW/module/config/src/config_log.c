#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"


static ST_CFG_LOG_MNG g_CfgLogMng;

ST_CFG_LOG_MNG *Config_GetLogMng()
{
    return &g_CfgLogMng;
}

// LOG 模块销毁
_INT Log_Task_Destroy()
{
    MOS_LIST_RMVALL(&Config_GetLogMng()->stLogList, MOS_TRUE);
    MOS_LOG_INF(LOG_MODULE,"log task Destroy ok");

    return MOS_OK;
}

static _INT Config_AddLogNode(_INT iLocalType,_UC *pucCpName,_UC *pucModule,_UC *pucContent)
{
    MOS_PARAM_NULL_RETERR(pucCpName);
    MOS_PARAM_NULL_RETERR(pucModule);
    MOS_PARAM_NULL_RETERR(pucContent);

    ST_CFG_LOG_NODE *pstlogNode = MOS_NULL;

    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    pstlogNode = (ST_CFG_LOG_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_LOG_NODE)); 
    pstlogNode->iLogType      = iLocalType;
    MOS_STRNCPY(pstlogNode->aucCpName,pucCpName,sizeof(pstlogNode->aucCpName));
    MOS_STRNCPY(pstlogNode->aucModule,pucModule,sizeof(pstlogNode->aucModule));
    MOS_STRNCPY(pstlogNode->aucLogContent,pucContent,sizeof(pstlogNode->aucLogContent));
    
    MOS_LIST_ADDTAIL(&Config_GetLogMng()->stLogList, pstlogNode);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    return MOS_OK;
}

_INT Config_SetLogCommomInfo(_UC *pucAppid, _UC *pucLocalIp,_UC *pucRoom)
{
    MOS_PARAM_NULL_RETERR(pucAppid);
    MOS_PARAM_NULL_RETERR(pucLocalIp);
    MOS_PARAM_NULL_RETERR(pucRoom);

    if(MOS_STRCMP(Config_GetLogMng()->aucAppId,pucAppid) != 0)
    {
        MOS_STRNCPY(Config_GetLogMng()->aucAppId,pucAppid,sizeof(Config_GetLogMng()->aucAppId));
        //Config_GetItemSign()->ucSaveSystem = 1;
    }
    if(MOS_STRCMP(Config_GetLogMng()->aucLocalIp,pucLocalIp) != 0)
    {
        MOS_STRNCPY(Config_GetLogMng()->aucLocalIp,pucLocalIp,sizeof(Config_GetLogMng()->aucLocalIp));
    }
    if(MOS_STRCMP(Config_GetLogMng()->aucRoom,pucRoom) != 0)
    {
        MOS_STRNCPY(Config_GetLogMng()->aucRoom,pucRoom,sizeof(Config_GetLogMng()->aucRoom));    
    }
	return MOS_OK;

}

_INT Config_SetData(_UC *pucAppid,_INT iLocalType,_UC *pucCpName,_UC *pucModule,_UC *pucContent)
{
    MOS_PARAM_NULL_RETERR(pucAppid);
    MOS_PARAM_NULL_RETERR(pucCpName);
    MOS_PARAM_NULL_RETERR(pucModule);
    MOS_PARAM_NULL_RETERR(pucContent);

    if(MOS_STRCMP(Config_GetLogMng()->aucAppId,pucAppid) != 0)
    {
        MOS_LOG_ERR("AppId Error", "AppId  %s not match", pucAppid);
        return MOS_ERR;
    }

    Config_AddLogNode(iLocalType,pucCpName,pucModule,pucContent);

    return MOS_OK;
}
 
_UC *Config_BuildLogJson()
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot       = Adpt_Json_CreateObject();
    JSON_HANDLE hLogArray   = Adpt_Json_CreateArray();
    JSON_HANDLE hDataArray  = Adpt_Json_CreateArray();
    JSON_HANDLE hLogItem    = Adpt_Json_CreateObject();
    JSON_HANDLE hDataObj    = Adpt_Json_CreateObject();
    //ST_CFG_LOG_NODE *pstCfgLogNode = MOS_NULL;

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"logs",hLogArray);
    Adpt_Json_AddItemToArray(hLogArray,hLogItem);
    Adpt_Json_AddItemToObject(hLogItem,(_UC*)"logtype",Adpt_Json_CreateString((_UC*)"cameralog"));
    Adpt_Json_AddItemToObject(hLogItem,(_UC*)"appid",Adpt_Json_CreateString((_UC*)"100ime"));

    Adpt_Json_AddItemToObject(hLogItem,(_UC*)"data",hDataArray);
    Adpt_Json_AddItemToArray(hDataArray,hDataObj);
    Adpt_Json_AddItemToObject(hDataObj,(_UC*)"cpname",Adpt_Json_CreateString((_UC*)"baseinterface"));
    Adpt_Json_AddItemToObject(hDataObj,(_UC*)"localip",Adpt_Json_CreateString((_UC*)"127.0.0.1"));
    Adpt_Json_AddItemToObject(hDataObj,(_UC*)"room",Adpt_Json_CreateString((_UC*)"hefei"));

    //{"logs":[{"logtype":"cameralog","appid":"100ime","data":[{"cpname":"baseinterface","localip":"127.0.0.1","room":"hefei"}]}]}

/*
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&Config_GetLogMng()->stLogList, pstCfgLogNode, stIterator)
    {
        hArrayItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"logtype",Adpt_Json_CreateStrWithNum(pstCfgLogNode->iLogType));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"appid",Adpt_Json_CreateString(Config_GetLogMng()->aucAppId));
        hDataObj = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"data",hDataObj);
        Adpt_Json_AddItemToObject(hDataObj,(_UC*)"cpname",Adpt_Json_CreateString(pstCfgLogNode->aucCpName));
        Adpt_Json_AddItemToObject(hDataObj,(_UC*)"localip",Adpt_Json_CreateString(Config_GetLogMng()->aucLocalIp));
        Adpt_Json_AddItemToObject(hDataObj,(_UC*)"room",Adpt_Json_CreateString(Config_GetLogMng()->aucRoom));
        Adpt_Json_AddItemToObject(hDataObj,(_UC*)"key1",Adpt_Json_CreateString(pstCfgLogNode->aucModule));
        Adpt_Json_AddItemToObject(hDataObj,(_UC*)"key2",Adpt_Json_CreateString(pstCfgLogNode->aucLogContent));        
        Adpt_Json_AddItemToArray(hArray,hArrayItem);

        MOS_LIST_RMVNODE(&Config_GetLogMng()->stLogList, pstCfgLogNode);
        MOS_FREE(pstCfgLogNode);
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex); 
*/
    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}

_INT Config_ParseLogJson(_UC *pStrJson)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _UC *pStrTmp = MOS_NULL;
    _UC aucDesc[CFG_STRING_COMMONLEN]   = {0};
    _UC aucStatus[CFG_STRING_COMMONLEN] = {0};
    JSON_HANDLE hRoot  = Adpt_Json_Parse(pStrJson);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"status"),&pStrTmp);
    MOS_STRNCPY(aucStatus, pStrTmp, sizeof(aucStatus));
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"desc"),&pStrTmp);
    MOS_STRNCPY(aucDesc, pStrTmp, sizeof(aucDesc));

    if(MOS_STRCMP(aucStatus,"success") == 0)
    {
        Adpt_Json_Delete(hRoot);
        return MOS_OK;
    }
    else if(MOS_STRCMP(aucStatus,"failuer") == 0)
    {
        Adpt_Json_Delete(hRoot);
        MOS_LOG_ERR(LOG_MODULE,"LogServer return Failure %s",aucStatus);
        return MOS_ERR;
    }
	return MOS_OK;
}

