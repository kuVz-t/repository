#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "mos.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "http_api.h"
#include "msgmng_api.h"
#include "ga1400_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

_INT Config_SetCameraGat1400Ability(_INT iCamId,_UI uiGAT1400Ability)
{
    if(Config_GetCamaraMng()->uiGAT1400Ability == uiGAT1400Ability)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiGAT1400Ability = uiGAT1400Ability;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(GA1400_LOGSTR,"cfg_camera set camera %d set gat1400 ability %u",iCamId,uiGAT1400Ability);
    return MOS_OK;
}

/*******************AIPIC_1400 START********************/
// 添加 UPLOAD_AIPIC_1400_INF 链表节点
#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
// 获取上传AIPIC_1400任务已用节点数 UPLOAD_AIPIC_1400_INF
_INT Config_GetUploadAIPic1400TaskNodeCount(_INT iCamId, _UI *puiGa1400UploadPicNodeCount)
{
    if (puiGa1400UploadPicNodeCount == MOS_NULL)
    {
        return MOS_ERR;
    }
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode = MOS_NULL;

    // 初始赋值为0
    *puiGa1400UploadPicNodeCount = 0;

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoad1400Mutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfNode, stIterator)
    {
        if(pstUploadAIPic1400InfNode->uiUseFlag == 1)
        {
            (*puiGa1400UploadPicNodeCount)++;
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoad1400Mutex));

    return MOS_OK;
}

_INT Config_AddUploadAIPic1400TaskNode(_INT iCamId, _UI  uiReqId, _UI uiAIIoTType, _ULLID lluAIIoTID, _UI uiEventId, ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInfo)
{
    MOS_PARAM_NULL_RETERR(pstAiPicEventInfo);
    MOS_PARAM_NULL_RETERR(pstAiPicEventInfo->pstAiPicHead);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode     = MOS_NULL;
    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIZip1400InfTmpNode  = MOS_NULL;

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoad1400Mutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfNode, stIterator)
    {
        if(pstUploadAIPic1400InfNode->uiUseFlag == 1 && pstUploadAIPic1400InfNode->uiReqId == uiReqId)
        {
            break;
        }
        else if(pstUploadAIPic1400InfNode->uiUseFlag == 0)
        {
            pstUploadAIZip1400InfTmpNode = pstUploadAIPic1400InfNode;
        }
    }
    if(pstUploadAIPic1400InfNode == MOS_NULL)
    {
        if(pstUploadAIZip1400InfTmpNode == MOS_NULL)
        {
            pstUploadAIPic1400InfNode = (ST_CFG_UPLOAD_AIPIC_1400_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_UPLOAD_AIPIC_1400_INF_NODE));
            pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead = (ST_ZJ_AIPIC_NODE*)MOS_MALLOCCLR(sizeof(ST_ZJ_AIPIC_NODE));
            MOS_LIST_ADDTAIL(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfNode);
            MOS_LOG_INF(GA1400_LOGSTR,"ReqId:%u  Molloc Cache", uiReqId);
        }
        else
        {
            pstUploadAIPic1400InfNode = pstUploadAIZip1400InfTmpNode;
        }
    }

    pstUploadAIPic1400InfNode->uiReqId     = uiReqId;
    pstUploadAIPic1400InfNode->uiEventId   = uiEventId;
    pstUploadAIPic1400InfNode->lluAIIoTID  = lluAIIoTID;
    pstUploadAIPic1400InfNode->uiAIIoTType = uiAIIoTType;
    pstUploadAIPic1400InfNode->lluReportTimeStamp = Mos_Time();

    if (pstAiPicEventInfo->lluTimeStamp == 0)
    {
        pstUploadAIPic1400InfNode->cAlarmTime  = Mos_Time();
    }
    else
    {
        pstUploadAIPic1400InfNode->cAlarmTime  = pstAiPicEventInfo->lluTimeStamp;
    }

    pstUploadAIPic1400InfNode->stAiPicEventInfo.uiBgJpgLen       = pstAiPicEventInfo->uiBgJpgLen;
    if (pstAiPicEventInfo->pucBgJpgBuff)
    {
        pstUploadAIPic1400InfNode->stAiPicEventInfo.pucBgJpgBuff = pstAiPicEventInfo->pucBgJpgBuff;
    }

    pstUploadAIPic1400InfNode->stAiPicEventInfo.dBgWidth                    = pstAiPicEventInfo->dBgWidth;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.dBgHeight                   = pstAiPicEventInfo->dBgHeight;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.lluTimeStamp                = pstAiPicEventInfo->lluTimeStamp;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->dWidth        = pstAiPicEventInfo->pstAiPicHead->dWidth;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->dHeight       = pstAiPicEventInfo->pstAiPicHead->dHeight;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->dPointX       = pstAiPicEventInfo->pstAiPicHead->dPointX;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->dPointY       = pstAiPicEventInfo->pstAiPicHead->dPointY;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->uiPicLen      = pstAiPicEventInfo->pstAiPicHead->uiPicLen;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->uiLeftTopX    = pstAiPicEventInfo->pstAiPicHead->uiLeftTopX;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->uiLeftTopY    = pstAiPicEventInfo->pstAiPicHead->uiLeftTopY;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->uiRightBtmX   = pstAiPicEventInfo->pstAiPicHead->uiRightBtmX;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->uiRightBtmY   = pstAiPicEventInfo->pstAiPicHead->uiRightBtmY;
    pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->uiSimilarity  = pstAiPicEventInfo->pstAiPicHead->uiSimilarity;
    if (pstAiPicEventInfo->pstAiPicHead->pucDes)
    {
        pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->pucDes    = pstAiPicEventInfo->pstAiPicHead->pucDes;
    }
    if (pstAiPicEventInfo->pstAiPicHead->pucPicBuf)
    {
        pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf = pstAiPicEventInfo->pstAiPicHead->pucPicBuf;
    }
    if (pstAiPicEventInfo->pstAiPicHead->aucCarNum)
    {
        MOS_STRLCPY(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->aucCarNum,  pstAiPicEventInfo->pstAiPicHead->aucCarNum,  sizeof(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->aucCarNum));
    }
    if (pstAiPicEventInfo->pstAiPicHead->aucLabelID)
    {
        MOS_STRLCPY(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->aucLabelID, pstAiPicEventInfo->pstAiPicHead->aucLabelID, sizeof(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->aucLabelID));
    }
    if (pstAiPicEventInfo->aucEventExpandDes)
    {
        MOS_STRLCPY(pstUploadAIPic1400InfNode->stAiPicEventInfo.aucEventExpandDes, pstAiPicEventInfo->aucEventExpandDes, sizeof(pstUploadAIPic1400InfNode->stAiPicEventInfo.aucEventExpandDes));
    }
    if (pstAiPicEventInfo->aucBgPicExpandDes)
    {
        MOS_STRLCPY(pstUploadAIPic1400InfNode->stAiPicEventInfo.aucBgPicExpandDes, pstAiPicEventInfo->aucBgPicExpandDes, sizeof(pstUploadAIPic1400InfNode->stAiPicEventInfo.aucBgPicExpandDes));
    }
    if (pstAiPicEventInfo->pstAiPicHead->aucPicExpandDes)
    {
        MOS_STRLCPY(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, pstAiPicEventInfo->pstAiPicHead->aucPicExpandDes, sizeof(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes));
    }

    pstUploadAIPic1400InfNode->uiUseFlag    = 1;
    pstUploadAIPic1400InfNode->uiUploadFlag = 1;
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoad1400Mutex));

    _UI uiGa1400UploadPicNodeCount = 0;
    Config_GetUploadAIPic1400TaskNodeCount(0, &uiGa1400UploadPicNodeCount);
    // 排障必要日志
    MOS_LOG_INF(GA1400_LOGSTR,"ADD AIPIC 1400 ReqId:%u aucEventExpandDesOUT:%s aucEventExpandDesIN:%s Ga1400UploadPicNodeCount:%u", 
            uiReqId, pstUploadAIPic1400InfNode->stAiPicEventInfo.aucEventExpandDes, pstAiPicEventInfo->aucEventExpandDes, uiGa1400UploadPicNodeCount);

    return MOS_OK;
}

// 查找上传任务链表节点
ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *Config_FindUploadAIPic1400TaskNode(_INT iCamId, _UI uiReqId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode = MOS_NULL;

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoad1400Mutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfNode, stIterator)
    {
        if(pstUploadAIPic1400InfNode->uiUseFlag == 1 && pstUploadAIPic1400InfNode->uiReqId == uiReqId)
        {
            break;
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoad1400Mutex));

    return pstUploadAIPic1400InfNode;
}

// 设置UploadAIPic1400Task节点 UploadFlag 上报图片到1400状态
_INT Config_SetUploadAIPic1400TaskNodeUploadFlag(_INT iCamId, _UI uiReqId, _UI uiUploadFlag)
{
    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode = Config_FindUploadAIPic1400TaskNode(iCamId, uiReqId);
    if(pstUploadAIPic1400InfNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstUploadAIPic1400InfNode->uiUploadFlag != uiUploadFlag)
    {
        pstUploadAIPic1400InfNode->uiUploadFlag = uiUploadFlag;
    }
    // MOS_LOG_INF(GA1400_LOGSTR,"cfg_ai set uiUploadFlag %u for uiReqId %u", uiUploadFlag, uiReqId);
    return MOS_OK;
}

// 从上传AIPIC_1400任务节点删除人脸 UPLOAD_AIPIC_1400_INF
_INT Config_DelUploadAIPic1400TaskNode(_INT iCamId, _UI uiReqId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode = MOS_NULL;
    
    Mos_MutexLock(&(Config_GetAIMng()->hUpLoad1400Mutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfNode, stIterator)
    {
        if(pstUploadAIPic1400InfNode->uiUseFlag && pstUploadAIPic1400InfNode->uiReqId == uiReqId)
        {
            pstUploadAIPic1400InfNode->uiUseFlag                    = 0;
            pstUploadAIPic1400InfNode->uiEventId                    = 0;
            pstUploadAIPic1400InfNode->cAlarmTime                   = 0;
            pstUploadAIPic1400InfNode->lluReportTimeStamp           = 0;
            pstUploadAIPic1400InfNode->lluAIIoTID                   = 0;
            pstUploadAIPic1400InfNode->uiAIIoTType                  = 0;
            pstUploadAIPic1400InfNode->uiUploadFlag                 = 0;

            // 排障必要日志
            _UI uiGa1400UploadPicNodeCount = 0;
            Config_GetUploadAIPic1400TaskNodeCount(0, &uiGa1400UploadPicNodeCount);
            MOS_LOG_INF(GA1400_LOGSTR,"DEL AIPIC 1400 ReqId:%u Ga1400UploadPicNodeCount:%u", uiReqId, uiGa1400UploadPicNodeCount);

            break;
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoad1400Mutex));

    return MOS_OK;
}


#endif
/*******************AIPIC_1400 END**********************/
