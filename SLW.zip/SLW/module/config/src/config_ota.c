#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_api.h"
#include "qualityprobe_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "cmdhdl_type.h"
#include "cmdhdl_api.h"
#include "msgmng_multimedia.h"

#define OTA_LOGSTR                   (_UC*)"OTA"

typedef struct stru_Ota_CheckVersion_Node
{
    _UC ucUseFlag;
    _VPTR pstUsrInf;
    OTA_PFUN_CHECKVERSION_CB pfunCheckVersionCb;
    ST_MOS_LIST_NODE stNode; 
}ST_OTA_CHECKVERSION_NODE;

typedef struct stru_OTA_VERSIONINF
{
    _UC ucNeedCheckFlag;                    // 是否需要升级
    _UC ucStatus;                           // 设备版本检测请求状态 0 未请求 ，1 请求中  2 请求成功, 3 请求失败
    _UI uiOgctId;
    _UI uiCode;                             // 1 需要升级  2 升级中
    _UI uiFileSize;                         // 升级包文件大小
    _UI uiReqType;                          // 1 用户主动请求升级   2 设备自动升级  
    _UI uiUpgradeTime;                      // 升级日期
    _UI uiSetAutoUpgradeTimeFlag;           // 0 rand升级时间未设置 ，1 rand升级时间已经设置 
    _UI uiNoticeDevToUpgradeFlag;           // 1 通知固件准备升级  ，0 不通知
    _UC aucFileUrl[1024];                   // 固件下载url路径
    _UC aucMd5[CFG_STRING_LEN];             // 升级包的MD5码
    _UC aucNewVersion[CFG_STRING_LEN];      // 新版本号 固件版本命名: V*.*.*-省份编码-yymmdd (固件版本号-省份编码-时间)
    _UC aucSignature[CFG_STRING_MAXLEN];    // 签名
    _UC *pucPubKey;
    _UC *pucVersionDes;
    _CTIME_T cCheckTime;
}ST_OTA_VERSIONINF;

typedef struct stru_OTA_DOWNFILE
{
    _UC ucStatus;                           // 0 不需要下载, 1 开始下载, 2 下载中， 3 下载成功， 4 下载失败
    _UC ucStopFlag;                         // 停止升级标志
    _UI uiHttpId;
    _UI uiLastDownSize;                     // 上次下载大小
    _UI uiDownSize;                         // 下载大小
    ST_MD5_CONTEXT *pstMd5Contxt;
    _CTIME_T cTime;
    _CTIME_T cUpTime;
    _CTIME_T cBegainTime;                   // 下载开始时间
}ST_OTA_DOWNFILE;

typedef struct stru_OTATASK_MNG
{
    _UC               ucInitFlag;
    _UI               uiOgctId;
    _CTIME_T          cLastTime;            // OTA上报上一次时间
    _UC               ucLastPrecentage;     // OTA上报上一百分比
    _HMUTEX           hMutex;
    ST_OTA_DOWNFILE   stDownFile;
    ST_OTA_VERSIONINF stVersionInf;
    ST_MOS_LIST       stCheckVersionList; // ST_CHECKVERSION_NODE
    _UI               uiSleepMonitorId;
}ST_OTATASK_MNG;

/********************************************************************
*********************************************************************/
static ST_OTATASK_MNG g_stOtaTaskMng;

/**********************************************************************
***********************************************************************/
static ST_OTATASK_MNG *Ota_GetTaskMng()
{
    return &g_stOtaTaskMng;
}

// OTA 模块初始化
_INT Ota_Task_Init()
{
    if(Ota_GetTaskMng()->ucInitFlag == 1)
    {
        return MOS_OK;
    }
    MOS_MEMSET(&g_stOtaTaskMng,0,sizeof(g_stOtaTaskMng));
    Mos_MutexCreate(&g_stOtaTaskMng.hMutex);
    Ota_GetTaskMng()->cLastTime         = 0;
    Ota_GetTaskMng()->ucLastPrecentage  = 0;
    Ota_GetTaskMng()->uiSleepMonitorId  = Config_AppSLeepMonotorRegist("OTA");
    Ota_GetTaskMng()->ucInitFlag        = 1;
    return MOS_OK;
}

// OTA 模块销毁
_INT Ota_Task_Destroy()
{
    if(Ota_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_OK;
    }
    MOS_LIST_RMVALL(&Ota_GetTaskMng()->stCheckVersionList, MOS_TRUE);
    MOS_FREE(Ota_GetTaskMng()->stVersionInf.pucVersionDes);
    MOS_FREE(Ota_GetTaskMng()->stVersionInf.pucPubKey);
    Ota_GetTaskMng()->stVersionInf.uiCode = EN_CFG_OTA_UPGRADE_CODE_NOT;
    Mos_MutexDelete(&g_stOtaTaskMng.hMutex);
    Config_AppSLeepMonotorUnRegist(Ota_GetTaskMng()->uiSleepMonitorId);
    Ota_GetTaskMng()->ucInitFlag = 0;
    MOS_LOG_INF(OTA_LOGSTR,"ota task Destroy ok");

    return MOS_OK;
}

// 检查固件新版本
_INT Ota_CheckNewVersion(_VPTR pstUsrInf,OTA_PFUN_CHECKVERSION_CB pFunCheckVersionCb)
{
    MOS_PARAM_NULL_RETERR(pstUsrInf);
    MOS_PARAM_NULL_RETERR(pFunCheckVersionCb);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_OTA_CHECKVERSION_NODE *pstCheckNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Ota_GetTaskMng()->stCheckVersionList, pstCheckNode, stIterator)
    {
        if(pstCheckNode->ucUseFlag == 0)
        {
            break;
        }
    }
    if(pstCheckNode == MOS_NULL)
    {
        pstCheckNode = (ST_OTA_CHECKVERSION_NODE*)MOS_MALLOCCLR(sizeof(ST_OTA_CHECKVERSION_NODE));
        MOS_LIST_ADDTAIL(&Ota_GetTaskMng()->stCheckVersionList, pstCheckNode);
    } 
    pstCheckNode->pstUsrInf          = pstUsrInf;
    pstCheckNode->pfunCheckVersionCb = pFunCheckVersionCb;
    pstCheckNode->ucUseFlag          = 1;
    MOS_LOG_INF(OTA_LOGSTR,"start check new version from server");
    return MOS_OK;
}

// 比较新旧设备版本号
static _INT Ota_CompareLocalRemoteVersion(_UC *pucRemoteVersion, _UC *pucLocalVersion)
{
    _UC  aucUrl[64]          = {0};
    _UC  aucErrorString[128] = {0};

    if(MOS_NULL == pucRemoteVersion || MOS_NULL == pucLocalVersion)
    {
        MOS_SPRINTF(aucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_STARTUPGRADE);
        MOS_SPRINTF(aucErrorString, "version is null ,local version %s ,remote version %s",pucLocalVersion, pucRemoteVersion);
        CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), aucUrl, 0, EN_OTA_RT_CHECK_VERSION_NULL, aucErrorString,MOS_NULL, 1);
        MOS_LOG_ERR(OTA_LOGSTR, aucErrorString);
        return MOS_ERR;
    }
#if 0   // 匹配旧设备不规范命名版本号问题
    _UC *pucLocalTmp         = MOS_NULL;
    _UC *pucRemoteTmp        = MOS_NULL;
    _UC  aucLocal[16]        = {0};
    _UC  aucRemote[16]       = {0};

    MOS_MEMSET(aucLocal,  0, 16);
    MOS_MEMSET(aucRemote, 0, 16);

    pucRemoteTmp = MOS_STRSTR(pucRemoteVersion,"-");
    if(MOS_NULL !=  pucRemoteTmp)
    {
        MOS_STRNCPY(aucRemote,pucRemoteVersion,pucRemoteTmp - pucRemoteVersion);
        pucRemoteTmp += 4; 
    }
    pucLocalTmp = MOS_STRSTR(pucLocalVersion,"-");
    if(MOS_NULL !=  pucLocalTmp)
    {
        MOS_STRNCPY(aucLocal,pucLocalVersion,pucLocalTmp - pucLocalVersion);
        pucLocalTmp += 4;
    }
    if(MOS_STRCMP(aucRemote,aucLocal) < 0 || MOS_STRCMP(pucRemoteTmp, pucLocalTmp) <= 0)
    {
        MOS_SPRINTF(aucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_STARTUPGRADE);
        MOS_SPRINTF(aucErrorString, "remote version %s is not big than local version %s",pucRemoteVersion, pucLocalVersion);
        CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), aucUrl, 0, EN_OTA_RT_LOCAL_VERSION_BIGGER, aucErrorString,MOS_NULL, 1);
        MOS_LOG_ERR(OTA_LOGSTR, aucErrorString);
        return MOS_ERR;
    }
#else
    if(MOS_STRCMP(pucRemoteVersion, pucLocalVersion) <= 0)
    {
        MOS_SPRINTF(aucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_STARTUPGRADE);
        MOS_SPRINTF(aucErrorString, "remote version %s is not big than local version %s",pucRemoteVersion, pucLocalVersion);
        CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), aucUrl, 0, EN_OTA_RT_LOCAL_VERSION_BIGGER, aucErrorString,MOS_NULL, 1);
        MOS_LOG_ERR(OTA_LOGSTR, aucErrorString);        
        return MOS_ERR;
    }
#endif
    MOS_LOG_INF(OTA_LOGSTR,"have new version;local need update");
    return MOS_OK;
}

// OTA 开始升级
_INT Ota_StartUpgrade()
{
    _INT iRet;
    // 比较新旧设备版本号
    iRet = Ota_CompareLocalRemoteVersion(Ota_GetTaskMng()->stVersionInf.aucNewVersion, Config_GetDeviceMng()->aucDevVerSion);
    if(iRet == MOS_ERR)
    {
        return MOS_ERR;
    }
    Ota_GetTaskMng()->stDownFile.ucStopFlag  = 0;
    Ota_GetTaskMng()->stDownFile.cBegainTime = Mos_Time();
    if(Ota_GetTaskMng()->stDownFile.ucStatus == EN_CFG_OTA_DOWNFILE_NOT)
    {
        Ota_GetTaskMng()->stDownFile.ucStatus = EN_CFG_OTA_DOWNFILE_BEGIN;
    }
	Ota_GetTaskMng()->stVersionInf.uiCode = EN_CFG_OTA_UPGRADE_CODE_UPGRADING;  // 设备升级中
    MOS_LOG_INF(OTA_LOGSTR,"Start download new version status %u",Ota_GetTaskMng()->stDownFile.ucStatus);
    CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_OTA_RT_DEV_READY_TO_UPGRADE, "Device Notify Ready To Upgrade",MOS_NULL, 1);
    return MOS_OK;
}

/***********************************************************************************************
// OTA 停止升级
***********************************************************************************************/
_INT Ota_StopUpgrade()
{
    Ota_GetTaskMng()->stDownFile.ucStopFlag = 1;
    MOS_LOG_INF(OTA_LOGSTR,"Stop Upgrade OK");
    return MOS_OK;
}

// OTA MD5签名检测
_VOID Ota_SignatureCheck()
{
    _INT iRet         = 1;
    _UI  uiDecOutLen  = 0;
    _UC* pucDecOutBuf = MOS_NULL;
    ST_OTA_VERSIONINF *pucVersionInfo = &Ota_GetTaskMng()->stVersionInf;

    Mos_MutexLock(&Ota_GetTaskMng()->hMutex);
    
    // 检验升级包MD5
    if(!MOS_STRISEMPTY(pucVersionInfo->aucMd5) && !MOS_STRISEMPTY(pucVersionInfo->aucSignature) &&!MOS_STRISEMPTY(pucVersionInfo->pucPubKey))
    {
        // RSA验签  其中RSA证书格式是：X509， 填充格式是：PKCS#1 v1.5
        // RSA_VerifySign(md5(固件) base64_decode（signature）, 公钥)
        pucDecOutBuf = (_UC*)MOS_MALLOCCLR(2048);
        uiDecOutLen = Adpt_Base64_Dec(pucVersionInfo->aucSignature,pucDecOutBuf);
        if(Adpt_Public_Verify(pucVersionInfo->aucMd5, MOS_STRLEN(pucVersionInfo->aucMd5),pucDecOutBuf, uiDecOutLen,
			pucVersionInfo->pucPubKey,MOS_STRLEN(pucVersionInfo->pucPubKey)) != 1)
        {
            CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_OTA_RT_IMAGE_VERITY_FAIL, "image RSA verify error",MOS_NULL, 1);        
            iRet = 0;
        }
        else
        {
            MOS_LOG_INF(OTA_LOGSTR, "RSA Verify OK!");
        }
        MOS_FREE(pucDecOutBuf);
    }
    Mos_MutexUnLock(&Ota_GetTaskMng()->hMutex);
    
    // 通知固件覆盖镜像
    if(ZJ_GetFuncTable()->pFunCoverImageNotice)
    {
        // 关闭MP4、Commit云存任务，流媒体连接
        Cmdhdl_CloseSomethingBeforeReboot(MOS_FALSE);
        MsgMng_MultiMediaCloseAllConnect();
        CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), Ota_GetTaskMng()->stVersionInf.aucFileUrl, 0, EN_OTA_RT_NOTIFY_DEVICE_COVER, "notify device to cover image",MOS_NULL, 1); 
        ZJ_GetFuncTable()->pFunCoverImageNotice(iRet);
    }
    return ;
}

// 接收升级包数据
_VOID Ota_HttpRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    if(Ota_GetTaskMng()->stDownFile.pstMd5Contxt == MOS_NULL)
    {
        MOS_MEMSET(Ota_GetTaskMng()->stVersionInf.aucMd5, 0, CFG_STRING_LEN);
        Ota_GetTaskMng()->stDownFile.pstMd5Contxt = (ST_MD5_CONTEXT*)MOS_MALLOCCLR(sizeof(ST_MD5_CONTEXT));
        Mos_MD5Starts(Ota_GetTaskMng()->stDownFile.pstMd5Contxt);
    }
    // 更新MD5
    Mos_MD5Update(Ota_GetTaskMng()->stDownFile.pstMd5Contxt,pucData,uiLen);
    
    Ota_GetTaskMng()->stDownFile.uiDownSize += uiLen;

    if(ZJ_GetFuncTable()->pFunVersonDataDownCb)
    {
        // 将升级包数据回调给设备厂商
        if(Ota_GetTaskMng()->stDownFile.uiDownSize < Ota_GetTaskMng()->stVersionInf.uiFileSize)
        {
            // MOS_PRINTF("\r\n OTA DOWN IMAGE size:%u  totalSize:%u \r\n", uiLen, Ota_GetTaskMng()->stDownFile.uiDownSize);
            ZJ_GetFuncTable()->pFunVersonDataDownCb(pucData,uiLen,0);
        }
        else    // 升级包数据最后一包
        {
            ZJ_GetFuncTable()->pFunVersonDataDownCb(pucData,uiLen,1);
            MOS_LOG_INF(OTA_LOGSTR,"down img from remote finish!,downSize %d",Ota_GetTaskMng()->stDownFile.uiDownSize);
        }
    }
    return;
}

// OTA http 下载成功
_VOID Ota_HttpFinished(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _UC aucTmp[64];
    MOS_MEMSET(aucTmp , 0 ,64);
    Mos_MD5Finish(Ota_GetTaskMng()->stDownFile.pstMd5Contxt,aucTmp);
    Mos_MD5_Decode16To32(aucTmp,Ota_GetTaskMng()->stVersionInf.aucMd5);
    if(Ota_GetTaskMng()->stDownFile.uiDownSize == Ota_GetTaskMng()->stVersionInf.uiFileSize)
    {
        Ota_GetTaskMng()->stDownFile.ucStatus = EN_CFG_OTA_DOWNFILE_SUCCESS;
    }
    else
    {
        Ota_GetTaskMng()->stDownFile.ucStatus = EN_CFG_OTA_DOWNFILE_FAIL;
    }
    MOS_FREE(Ota_GetTaskMng()->stDownFile.pstMd5Contxt);
    Ota_GetTaskMng()->stDownFile.pstMd5Contxt = MOS_NULL;
    MOS_LOG_INF(OTA_LOGSTR,"Down newversion file finish down size %u/%u",Ota_GetTaskMng()->stDownFile.uiDownSize,Ota_GetTaskMng()->stVersionInf.uiFileSize);
    Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    return;
}

// OTA http 下载失败
_VOID Ota_HttpFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    Ota_GetTaskMng()->stDownFile.ucStatus = EN_CFG_OTA_DOWNFILE_FAIL;
    Ota_GetTaskMng()->stDownFile.uiHttpId = 0;
    MOS_FREE(Ota_GetTaskMng()->stDownFile.pstMd5Contxt);
    Ota_GetTaskMng()->stDownFile.pstMd5Contxt = MOS_NULL;
    MOS_LOG_ERR(OTA_LOGSTR,"Down newVersionfile err");
    Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
    return;
}

// OTA 开始下载固件镜像
_INT Ota_StartDownImage()
{
    _INT iRet  = 0;
    _UI uiHttpsFlag = 0;
    _UC *pucSubUrl  = MOS_NULL;
    _UC *pStrTmp = MOS_NULL;
    _UC aucHost[256] = {0};  
    ST_OTA_DOWNFILE *pstDownFile = &Ota_GetTaskMng()->stDownFile;
    
    if(MOS_STRLEN(Ota_GetTaskMng()->stVersionInf.aucFileUrl) == 0)
    {
        CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), __FUNCTION__ , -1, EN_OTA_RT_GET_URL_NULL, "DownloadUrl is Null",MOS_NULL, 1);
        return MOS_ERR;
    }
    pStrTmp = MOS_STRSTR(Ota_GetTaskMng()->stVersionInf.aucFileUrl,"https");
    if(pStrTmp == MOS_NULL)
    {
        pStrTmp = MOS_STRSTR(Ota_GetTaskMng()->stVersionInf.aucFileUrl,"http");
        if(pStrTmp == MOS_NULL)
        {
            _UC strLog[128] = {0};
            MOS_VSNPRINTF(strLog, sizeof(strLog), "Download Url is Unrecognized %s", Ota_GetTaskMng()->stVersionInf.aucFileUrl);
            CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), Ota_GetTaskMng()->stVersionInf.aucFileUrl, -1, EN_OTA_RT_UNRECOGNIZE_URL, strLog,MOS_NULL, 1);
            return MOS_ERR;
        }
        pStrTmp += MOS_STRLEN("http://");
    }
    else
    {
        uiHttpsFlag = 1;
        pStrTmp += MOS_STRLEN("https://");
    }

    pucSubUrl = MOS_STRSTR(pStrTmp,"/");
    if(pucSubUrl == MOS_NULL)
    {
        _UC strLog[128] = {0};
        MOS_VSNPRINTF(strLog, sizeof(strLog), "Download Url is Incorrect format %s", Ota_GetTaskMng()->stVersionInf.aucFileUrl);
        CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), Ota_GetTaskMng()->stVersionInf.aucFileUrl, -1, EN_OTA_RT_GET_URL_FAIL, strLog,MOS_NULL, 1);
        return MOS_ERR;
    }
    MOS_STRNCPY(aucHost, pStrTmp, pucSubUrl - pStrTmp);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = Ota_HttpRecvFunc;
    stHttpInfoNode.pfuncFinished   = Ota_HttpFinished;
    stHttpInfoNode.pfuncFailed     = Ota_HttpFailed;
#ifdef HIK_ADAPT_FLAG
    stHttpInfoNode.iTimeOut        = 15*60;    /*兼容hik升级包过大*/
#else
    stHttpInfoNode.iTimeOut        = 10*60;
#endif
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, aucHost, pucSubUrl, EN_HTTP_METHOD_GET, pstDownFile->uiHttpId);

    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

// OTA升级下载新固件
_VOID Ota_ProcDownVersion()
{
    _UC  ucPrecent    = 0;
    _INT iRet         = MOS_OK;
    _CTIME_T cNowTime = 0;
    ST_OTA_DOWNFILE   *pstDownFile   = &Ota_GetTaskMng()->stDownFile;
    ST_OTA_VERSIONINF *pstVersionInf = &Ota_GetTaskMng()->stVersionInf;

    // 未有下载升级包任务
    if(pstDownFile->ucStatus == EN_CFG_OTA_DOWNFILE_NOT)
	{
		return ;
	}
    
    cNowTime = Mos_Time();
    // 下载完整升级包超时, 或者下载停止
    if((_UI)(cNowTime - pstDownFile->cBegainTime) > OTA_DOWNFILE_FINISH_MAXTIME || pstDownFile->ucStopFlag == 1)
    {
        MOS_LOG_ERR(OTA_LOGSTR,"down image time out stop flag %u",pstDownFile->ucStopFlag);
        pstDownFile->ucStatus = EN_CFG_OTA_DOWNFILE_FAIL;
    }

    // 开始下载升级包
    if(pstDownFile->ucStatus == EN_CFG_OTA_DOWNFILE_BEGIN && (_UI)(cNowTime - pstDownFile->cTime) > 1)
    {
        pstDownFile->cTime          = cNowTime;
        pstDownFile->cUpTime        = cNowTime;
        pstDownFile->uiDownSize     = 0;
        pstDownFile->uiLastDownSize = 0;
        pstDownFile->uiHttpId       = Mos_GetSessionId();
        // 开始下载固件镜像
        Ota_PubUpgradePrecentage(0, EN_CFG_OTA_UPGRADE_DOWNING);
        iRet = Ota_StartDownImage();
        if(iRet == MOS_OK)
        {
            // 上报升级状态和进度
            pstDownFile->ucStatus  = EN_CFG_OTA_DOWNFILE_NOW;
        }
        else if(iRet != MOS_ERR_TRYAGAIN)  /*没有此返回值 fixme*/
        {
            pstDownFile->uiHttpId = 0;
            pstDownFile->ucStatus = EN_CFG_OTA_DOWNFILE_FAIL;
        }
        Config_AppSLeepMonotorUpdateStatus(Ota_GetTaskMng()->uiSleepMonitorId, 1);
        MOS_LOG_INF(OTA_LOGSTR,"down image start status %u iret %d",pstDownFile->ucStatus,iRet);
    }
    // 正在下载升级包
    else if(pstDownFile->ucStatus == EN_CFG_OTA_DOWNFILE_NOW && (_UI)(cNowTime - pstDownFile->cTime) >= 1)
    {
        pstDownFile->cTime = cNowTime;
        // 接收升级包数据超时
        if(pstDownFile->uiLastDownSize == pstDownFile->uiDownSize)
        {
            if(cNowTime - pstDownFile->cUpTime > OTA_DOWNFILE_RECV_MAXTIME)
            {
                CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), Ota_GetTaskMng()->stVersionInf.aucFileUrl, 0, EN_OTA_RT_DOWNLOAD_TIMEOUT, "Download Image had no data for a long time",MOS_NULL, 1);
                pstDownFile->ucStatus = EN_CFG_OTA_DOWNFILE_FAIL;
            }
            return ;
        }

        // 计算OTA升级完成百分比
        if(pstVersionInf->uiFileSize)
        {
            ucPrecent = pstDownFile->uiDownSize*100/pstVersionInf->uiFileSize;
        }

        pstDownFile->uiLastDownSize = pstDownFile->uiDownSize;
        pstDownFile->cUpTime = cNowTime;
        
        // 上报升级状态和进度
        Ota_PubUpgradePrecentage(ucPrecent*7/10, EN_CFG_OTA_UPGRADE_DOWNING);
    }
    // 下载升级包成功
    else if(pstDownFile->ucStatus == EN_CFG_OTA_DOWNFILE_SUCCESS)
    {
        pstDownFile->ucStatus = EN_CFG_OTA_DOWNFILE_NOT;
        // 上报升级状态和进度
        Ota_PubUpgradePrecentage(70, EN_CFG_OTA_UPGRADE_DOWNFINISH);
        // OTA MD5签名检测
        Ota_SignatureCheck();
    }
    // 下载升级包失败
    else if(pstDownFile->ucStatus == EN_CFG_OTA_DOWNFILE_FAIL || Ota_GetTaskMng()->stDownFile.ucStopFlag == 1)
    {    
        if(pstDownFile->uiHttpId)
        {
            // Http异步取消请求
            Http_Httpclient_CancelAsyncRequestEx(pstDownFile->uiHttpId);
        }

        // 回调通知设备厂商停止OTA升级
        if(ZJ_GetFuncTable()->pFunStopUpgrade)
        {
            ZJ_GetFuncTable()->pFunStopUpgrade();
        }
        pstDownFile->uiHttpId   = 0;
        pstDownFile->ucStatus   = EN_CFG_OTA_DOWNFILE_NOT;
        pstDownFile->ucStopFlag = 0;

        // 上报升级状态和进度
        Ota_PubUpgradePrecentage(0, EN_CFG_OTA_UPGRADE_DOWNFAIL);

        if( Ota_GetTaskMng()->stVersionInf.uiCode == EN_CFG_OTA_UPGRADE_CODE_UPGRADING) // 1:需要升级 2:升级中
        {
            Ota_GetTaskMng()->stVersionInf.uiCode = EN_CFG_OTA_UPGRADE_CODE_NEEDUPGRADE;
        }

        if (Ota_GetTaskMng()->stDownFile.ucStopFlag == 1)
        {
            MOS_LOG_INF(OTA_LOGSTR,"Upgrade  version %s image stop", pstVersionInf->aucNewVersion);
        }
        else
        {
            MOS_LOG_INF(OTA_LOGSTR,"download version %s image failed", pstVersionInf->aucNewVersion);
        }
        Config_AppSLeepMonotorUpdateStatus(Ota_GetTaskMng()->uiSleepMonitorId, 0);
    }

    return;
}
/******************************************************************************************
向服务器请求新版本检测 0x3334
********************************************************************************************/
static _UC* Ota_BuildCheckVersionJson(_UI uiOgctId, _UI uiReqType)
{
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[16];
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    // 0x3334 设备版本检测指令
    MOS_SPRINTF(aucMethod, "%0X%0X", EN_OGCT_METHOD_CFGBUSS, EN_OGCT_CFGBUSS_VERSION_CHECK);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiOgctId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY", hBody);
    // 设备当前版本号
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Version", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    // 设备型号
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Type", Adpt_Json_CreateStrWithNum(uiReqType));
    // 1：服务端通知设备进行校验（app手动升级）；2：设备端主动进行设备校验（设备自动升级）
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DeviceModel", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevModel));
    pStrTmp = Adpt_Json_Print(hRoot);

    Adpt_Json_Delete(hRoot);
    
    return pStrTmp;
}

// 设备版本检测指令回复处理3335
static _INT Ota_RecvCheckVersionRsp(_UI uiReqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hJsonRoot);
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    ST_OTA_VERSIONINF *pstVersionInf = &Ota_GetTaskMng()->stVersionInf;
    do
    {
        if(uiReqId != pstVersionInf->uiOgctId)
        {
            break;
        }
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"),&pstVersionInf->uiCode);
        if(pstVersionInf->uiCode != EN_CFG_OTA_UPGRADE_CODE_NEEDUPGRADE)
        {
            CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), __FUNCTION__, pstVersionInf->uiCode, EN_OTA_RT_RECV_NO_VERSION_UPGRADE, "No New Version To Upgrade",MOS_NULL, 1);
            pstVersionInf->uiOgctId = 0;
            pstVersionInf->ucStatus = EN_CFG_OTA_REQUEST_SUCCESS;
            break;
        }
        else
        {
            MOS_LOG_INF(OTA_LOGSTR,"Check A New Version To Upgrade");
        }

        hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
        
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Version"),&pStrTmp);
        MOS_STRNCPY(pstVersionInf->aucNewVersion,pStrTmp,sizeof(pstVersionInf->aucNewVersion));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"DownloadUrl"),&pStrTmp);
        MOS_STRNCPY(pstVersionInf->aucFileUrl,pStrTmp,sizeof(pstVersionInf->aucFileUrl));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Signature"),&pStrTmp);
        MOS_STRNCPY(pstVersionInf->aucSignature,pStrTmp,sizeof(pstVersionInf->aucSignature));
        
        Mos_MutexLock(&Ota_GetTaskMng()->hMutex);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"PublicKey"),&pStrTmp);
        MOS_FREE(pstVersionInf->pucPubKey);
        pstVersionInf->pucPubKey = MOS_STRCPYALLOC(pStrTmp);

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"DescURL"),&pStrTmp);
        MOS_FREE(pstVersionInf->pucVersionDes);
        pstVersionInf->pucVersionDes = MOS_STRCPYALLOC(pStrTmp);
        Mos_MutexUnLock(&Ota_GetTaskMng()->hMutex);

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"FileSize"),&pstVersionInf->uiFileSize);

        pstVersionInf->uiOgctId = 0;
        pstVersionInf->ucStatus = EN_CFG_OTA_REQUEST_SUCCESS;
        
    }while(0);

    Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    return MOS_OK;
}

// OTA升级检查固件版本
_VOID Ota_ProcCheckVersion()
{
    _UC *pStrTmp    = MOS_NULL;
    _UI uiWeekDay   =  0;
    _UI uiTime      =  0;
    _UI uiRanTime   =  0;
    _UC pucUrl[256] = {0};
    ST_MOS_LIST_ITERATOR      stIterator;
    ST_OTA_CHECKVERSION_NODE *pstCheckNode  = MOS_NULL;
    ST_OTA_VERSIONINF        *pstVersionInf = &Ota_GetTaskMng()->stVersionInf;

    // 判断设备是否在线
    if (Config_Task_GetMng()->ucOnlineStatus != 1)
    {
        return;
    }

    // 升级成功设备启动后 Config_SetAppVersion -->  uiUpgradedEndFlag --> 1
    if (Config_GetDeviceMng()->uiUpgradedEndFlag != 0)
    {
        if (Config_GetDeviceMng()->uiUpgradedEndFlag == 1)
        {
            pstVersionInf->cCheckTime = Mos_Time();
            Config_GetDeviceMng()->uiUpgradedEndFlag = 2;
            // 上报OTA升级进度和状态 升级完成
            Ota_PubUpgradePrecentage(100, EN_CFG_OTA_UPGRADE_SUCCESS); //  uiUpgradedEndFlag --> 0
        }
        else if ((_UI)(Mos_Time() - pstVersionInf->cCheckTime) > 30 && Config_GetDeviceMng()->uiUpgradedEndFlag == 2)
        {
            Config_GetDeviceMng()->uiUpgradedEndFlag = 1;
        }
        return;
    }
    
    // 设备自动升级
    if (Config_GetDeviceMng()->uiAutoUpgradeFlag == 1)
    {
        Mos_GetTimeInDay(Mos_Time(), &uiWeekDay,&uiTime);
        // 检验设备自动升级的时间点  
        if ((Config_GetDeviceMng()->uiUpgradeWeekDay & uiWeekDay) > 0 && Config_GetDeviceMng()->uiUpgradeTime == uiTime)
        {
            if (!pstVersionInf->uiSetAutoUpgradeTimeFlag)
            {
                //选择一个randtime升级
                srand((unsigned)time(NULL));
                uiRanTime = rand() % 3601;
                pstVersionInf->uiUpgradeTime = uiTime + uiRanTime;
                pstVersionInf->uiSetAutoUpgradeTimeFlag = 1;
                MOS_LOG_INF(OTA_LOGSTR,"AutoUpgradeTime %d Setted",pstVersionInf->uiUpgradeTime);
            }
        }
        if (uiTime >= pstVersionInf->uiUpgradeTime && pstVersionInf->uiSetAutoUpgradeTimeFlag == 1) 
        {
            // 修改标志值，设备开始检测版本并自动升级
            pstVersionInf->ucNeedCheckFlag = 1;
            pstVersionInf->ucStatus  = EN_CFG_OTA_REQUEST_NOT;
            pstVersionInf->uiNoticeDevToUpgradeFlag = 1;
            pstVersionInf->uiSetAutoUpgradeTimeFlag = 0;
            pstVersionInf->uiReqType = EN_CFG_OTA_UPGRADE_TYPE_DEVICEAUTO;   //设备自动升级
            MOS_LOG_INF(OTA_LOGSTR,"Auto Upgrade Begin CheckVersion");
        }   
    }
    else    // 非自动升级
    {
        FOR_EACHDATA_INLIST(&Ota_GetTaskMng()->stCheckVersionList, pstCheckNode, stIterator)
        {
            if (pstCheckNode->ucUseFlag == 0)
            {
                continue;
            }
            
            // 十分钟内只能向OTA平台检查设备升级版本号一次
            if ((_UI)(Mos_Time() - pstVersionInf->cCheckTime) < 600 && pstVersionInf->ucStatus == EN_CFG_OTA_REQUEST_SUCCESS)
            {
                MOS_LOG_INF(OTA_LOGSTR,"VersionCheck Finish ,NeedUpgradeFlag %d ,DevVersion %s",pstVersionInf->uiCode,pstVersionInf->aucNewVersion);
                // MsgMng_SendCheckNewVersionRsp 回复检查固件版本3415
                pstCheckNode->pfunCheckVersionCb(pstCheckNode->pstUsrInf,pstVersionInf->uiCode,pstVersionInf->aucNewVersion,
                    pstVersionInf->aucFileUrl,pstVersionInf->pucVersionDes);
                pstCheckNode->ucUseFlag = 0;
            }
            else if (pstVersionInf->ucNeedCheckFlag != 1)
            {
                pstVersionInf->ucNeedCheckFlag = 1;
                pstVersionInf->ucStatus  = EN_CFG_OTA_REQUEST_NOT;
                pstVersionInf->uiReqType = EN_CFG_OTA_UPGRADE_TYPE_APPUSER;   // 用户主动请求升级
                MOS_LOG_INF(OTA_LOGSTR,"APPUSER Upgrade Begin CheckVersion");
            }
        }
    }

    // OTA版本检查标志
    if(pstVersionInf->ucNeedCheckFlag == 1)
    {
        // 未发送版本请求
        if(pstVersionInf->ucStatus == EN_CFG_OTA_REQUEST_NOT)
        {
            pstVersionInf->uiOgctId = Mos_GetSessionId();
            // 设备版本检测指令 0x3334
            pStrTmp = Ota_BuildCheckVersionJson(pstVersionInf->uiOgctId, pstVersionInf->uiReqType);
            MOS_LOG_INF(OTA_LOGSTR,"Send CheckVersion Req");
            MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID,pstVersionInf->uiOgctId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_VERSION_CHECK,
                pStrTmp,MOS_STRLEN(pStrTmp),Ota_RecvCheckVersionRsp);

            pstVersionInf->cCheckTime = Mos_Time();
            pstVersionInf->ucStatus   = EN_CFG_OTA_REQUEST_NOW;
            MOS_LOG_INF(OTA_LOGSTR,"ogct %u check new version body %s",pstVersionInf->uiOgctId,pStrTmp);
            MOS_FREE(pStrTmp);
        }
        // 发送版本请求并回复成功
        else if(pstVersionInf->ucStatus == EN_CFG_OTA_REQUEST_SUCCESS)
        {
            MOS_LOG_INF(OTA_LOGSTR,"Recv CheckVersion Rsp Success");
            pstVersionInf->ucNeedCheckFlag = 0;
            pstVersionInf->uiReqType       = EN_CFG_OTA_UPGRADE_TYPE_NOT;
            if(pstVersionInf->uiNoticeDevToUpgradeFlag == 1)
            {
                // 通知设备去升级
                MOS_LOG_INF(OTA_LOGSTR,"Notice Dev Begin Auto Upgrade");
                Ota_NoticeDevToUpgrade();
                Ota_GetTaskMng()->stVersionInf.uiNoticeDevToUpgradeFlag = 0;
            }
        }
        // 已发送版本请求 并 超过30S没回复
        else if(pstVersionInf->ucStatus == EN_CFG_OTA_REQUEST_NOW && (_UI)(Mos_Time() - pstVersionInf->cCheckTime) > 30)
        {
            if(pstVersionInf->uiOgctId != 0)
            {
                // 取消请求
                MsgMng_CancleReqMsg(pstVersionInf->uiOgctId);
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CFGBUSS, EN_OGCT_CFGBUSS_VERSION_CHECK);
                Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
                CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), pucUrl, 0, EN_OTA_RT_GET_MSG_TIMEOUT, "Check device version over time platfrom without rsp",MOS_NULL, 1);
            }
            pstVersionInf->uiOgctId = 0;
            pstVersionInf->ucStatus = EN_CFG_OTA_REQUEST_NOT;
        }
    }
    return;
}

/****************************************************************
上传更新进度回复处理 0x3331
*****************************************************************/
static _INT Ota_RecvPubUpGradePrecentageRsp(_UI uiReqId,_VPTR hJsonRoot)
{
    if(Ota_GetTaskMng()->uiOgctId == uiReqId)
    {
        Ota_GetTaskMng()->uiOgctId = 0;
    }
    Config_GetDeviceMng()->uiUpgradedEndFlag = 0;
    MOS_LOG_INF(OTA_LOGSTR,"ogct %u recv Publish downfile precent rsp",uiReqId);
    Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    return MOS_OK;
}

// 上报升级状态和进度 0x3330
_INT Ota_PubUpgradePrecentage(_UC ucPrecentage, _INT istatus)
{
    // 首次上报
    // 进度大于95%，上报与上一次不同的进度
    // 上报时间间隔大于4s，并且进度间隔大于5%
    if ((Ota_GetTaskMng()->cLastTime == 0) 
       || (((_INT)ucPrecentage > 95) && Ota_GetTaskMng()->ucLastPrecentage != ucPrecentage) 
       || ((MOS_ABS_NUM(Mos_Time() - Ota_GetTaskMng()->cLastTime) >= 4.0) && ((_INT)ucPrecentage - (_INT)Ota_GetTaskMng()->ucLastPrecentage >= 5)))
    {
        Ota_GetTaskMng()->cLastTime = Mos_Time();
        Ota_GetTaskMng()->ucLastPrecentage = ucPrecentage;
    }
    // 开始和失败恢复初始值，并上报
    else if(istatus == EN_CFG_OTA_UPGRADE_NONEED || istatus == EN_CFG_OTA_UPGRADE_DOWNFAIL || istatus == EN_CFG_OTA_UPGRADE_FAIL)
    {
        Ota_GetTaskMng()->cLastTime        = 0;
        Ota_GetTaskMng()->ucLastPrecentage = 0;
    }
    else
    {
        MOS_LOG_INF(OTA_LOGSTR, "Wait Precentage=%d", ucPrecentage);
        return MOS_OK;
    }

    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[16]   = {0};
    _UC aucLogBuff[256] = {0};
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    
    if(Ota_GetTaskMng()->uiOgctId != 0)
    {
        MsgMng_CancleReqMsg(Ota_GetTaskMng()->uiOgctId);
    }
    Ota_GetTaskMng()->uiOgctId = Mos_GetSessionId();
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%0X%0X",EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_UPDATESTATTUS);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(Ota_GetTaskMng()->uiOgctId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY", hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"UpdateStatus", Adpt_Json_CreateStrWithNum(istatus));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Rate", Adpt_Json_CreateStrWithNum(ucPrecentage));
    
    pStrTmp = Adpt_Json_Print(hRoot);

    MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID,Ota_GetTaskMng()->uiOgctId,
        EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_UPDATESTATTUS,pStrTmp,MOS_STRLEN(pStrTmp),Ota_RecvPubUpGradePrecentageRsp);

    MOS_FREE(pStrTmp);
    Adpt_Json_Delete(hRoot);

    MOS_SPRINTF(aucLogBuff,"ogct %u Publish downfile precent %u status %d",Ota_GetTaskMng()->uiOgctId,ucPrecentage, istatus);
    CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_OTA_RT_REPORT_RATE, aucLogBuff, MOS_NULL, 1);
    
    return MOS_OK;
}

// 通知设备去升级
_INT Ota_NoticeDevToUpgrade()
{
    _INT iRet                = MOS_ERR;
    _UC  pucUrl[64]          = {0};
    _UC  pucErrorString[128] = {0};
    ST_OTA_VERSIONINF *pstVersionInf = &Ota_GetTaskMng()->stVersionInf;

    MOS_LOG_INF(OTA_LOGSTR,"Notice Dev Have NewVersion Upgrade");

    // 比较新旧设备版本号
    iRet = Ota_CompareLocalRemoteVersion(pstVersionInf->aucNewVersion,Config_GetDeviceMng()->aucDevVerSion);

    // 回调到设备  通知厂商 有新的 版本
    if(iRet == MOS_OK && ZJ_GetFuncTable()->pFunNewVersionCb)
    {
        iRet = ZJ_GetFuncTable()->pFunNewVersionCb(pstVersionInf->aucNewVersion,pstVersionInf->uiFileSize);
        if (iRet == MOS_ERR)
        {
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_STARTUPGRADE);
            MOS_SPRINTF(pucErrorString, "Device pFunNewVersionCb(aucNewVersion:%s, uiFileSize:%u) return err",
                                            pstVersionInf->aucNewVersion, pstVersionInf->uiFileSize);
            CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), pucUrl, 0, EN_OTA_RT_NOTIFY_FACTORY_FAIL, pucErrorString,MOS_NULL, 1);
            Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        }
        else
        {
            Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
        }
    }
    else
    {
        Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
    }
    return iRet;
}

// 平台通知升级 设置OTA升级所需要的参数
_INT Ota_SetNewVersionInf(_UC *pucNewVersion,_UC *pucDownUrl,_UC *pucPubkey,_UC *pucSignature,_UC *pucDescURL,_UI uiFileSize)
{
    MOS_PARAM_NULL_RETERR(pucNewVersion);
    MOS_PARAM_NULL_RETERR(pucDownUrl);
    MOS_PARAM_NULL_RETERR(pucPubkey);
    MOS_PARAM_NULL_RETERR(pucSignature);
    MOS_PARAM_NULL_RETERR(pucDescURL);

    ST_OTA_VERSIONINF  *pstVersionInf = &Ota_GetTaskMng()->stVersionInf;
    
    if(Ota_GetTaskMng()->stDownFile.ucStatus != EN_CFG_OTA_DOWNFILE_NOT)
    {
        MOS_LOG_INF(OTA_LOGSTR,"New version in downloading");
        return MOS_OK;
    }
    if(pstVersionInf->uiOgctId)
    {
        MsgMng_CancleReqMsg(pstVersionInf->uiOgctId);
    }
    pstVersionInf->uiOgctId   = 0;
    pstVersionInf->cCheckTime = Mos_Time(); 
    pstVersionInf->ucNeedCheckFlag = 0;
    pstVersionInf->ucStatus   = EN_CFG_OTA_REQUEST_SUCCESS;
    pstVersionInf->uiCode     = EN_CFG_OTA_UPGRADE_CODE_NEEDUPGRADE;
    
    MOS_STRNCPY(pstVersionInf->aucNewVersion,pucNewVersion,sizeof(pstVersionInf->aucNewVersion));
    MOS_STRNCPY(pstVersionInf->aucFileUrl,pucDownUrl,sizeof(pstVersionInf->aucFileUrl));

    Mos_MutexLock(&Ota_GetTaskMng()->hMutex);
    MOS_FREE(pstVersionInf->pucPubKey);
    pstVersionInf->pucPubKey = MOS_STRCPYALLOC(pucPubkey);

    MOS_STRNCPY(pstVersionInf->aucSignature,pucSignature,sizeof(pstVersionInf->aucSignature));

    MOS_FREE(pstVersionInf->pucVersionDes);
    if(MOS_STRLEN(pucDescURL) > 0)
        pstVersionInf->pucVersionDes = MOS_STRCPYALLOC(pucDescURL);
    Mos_MutexUnLock(&Ota_GetTaskMng()->hMutex);
    
    pstVersionInf->uiFileSize = uiFileSize;
    MOS_LOG_INF(OTA_LOGSTR,"set new version %s url %s size %d Signature %s",
        pstVersionInf->aucNewVersion,pstVersionInf->aucFileUrl,pstVersionInf->uiFileSize,pstVersionInf->aucSignature);
    // 通知设备去升级
    return Ota_NoticeDevToUpgrade();
}


