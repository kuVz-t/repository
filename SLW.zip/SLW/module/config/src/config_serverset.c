#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"

ST_CFG_SERVERSET_MNG *Config_GetServerSetMng()
{
    return &Config_GetlocalCfgInf()->stServerSetMng;
}

// 模块销毁
_INT ServerSet_Task_Destroy()
{
    MOS_LIST_RMVALL(&Config_GetServerSetMng()->stPackageList, MOS_TRUE);
    MOS_LOG_INF(SERVERSET_LOGSTR,"cfg_serverset task Destroy ok");

    return MOS_OK;
}

static ST_CFG_PACKAGE_NODE* Config_FindAndCreatPackageNode(_UI uiPackageId,_INT *piCreatFlag)
{
    MOS_PARAM_NULL_RETNULL(piCreatFlag);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PACKAGE_NODE *pstPackageNodeTmp = MOS_NULL;
    ST_CFG_PACKAGE_NODE *pstPackageNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetServerSetMng()->stPackageList, pstPackageNode, stIterator)
    {
        if(pstPackageNode->uiUseFlag && pstPackageNode->uiPackageId == uiPackageId)
        {
            if(piCreatFlag)
                *piCreatFlag = 0;
            return pstPackageNode;
        }
        else if(pstPackageNode->uiUseFlag == 0)
        {
            pstPackageNodeTmp = pstPackageNode;
        }
    }
    if(pstPackageNodeTmp == MOS_NULL)
    {
        pstPackageNodeTmp = (ST_CFG_PACKAGE_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_PACKAGE_NODE));
        MOS_LIST_ADDTAIL(&Config_GetServerSetMng()->stPackageList, pstPackageNodeTmp);
    }
    if(piCreatFlag)
        *piCreatFlag = 1;
    pstPackageNodeTmp->uiPackageId = uiPackageId;
    pstPackageNodeTmp->uiUseFlag   = 1;
    return pstPackageNodeTmp;
}

_INT Config_SetDeviceLimitAbility(_UI uiCamResolution,_UI uiHubLimit)
{
    if(Config_GetServerSetMng()->uiCamResolution == uiCamResolution && Config_GetServerSetMng()->uiIotHubLimit == uiHubLimit)
    {
        return MOS_OK;
    }
    Config_GetServerSetMng()->uiCamResolution = uiCamResolution;
    Config_GetServerSetMng()->uiIotHubLimit = uiHubLimit;

    if(Config_GetIotHubMng()->uiIotMaxCount > uiHubLimit)
    {
        Config_GetIotHubMng()->uiIotMaxCount = uiHubLimit;
    }
    Config_GetItemSign()->ucSaveServSetFlag = 1;
    MOS_LOG_INF(SERVERSET_LOGSTR,"cfg_serverset set CamResolution %d, HubLimit %d",uiCamResolution,uiHubLimit);
    return MOS_OK;
}

_INT Config_AddNewChargePackage(ST_CFG_PACKAGE_NODE *pstNewChargePackage)
{
    MOS_PARAM_NULL_RETERR(pstNewChargePackage);

    ST_CFG_PACKAGE_NODE *pstPackageNode = MOS_NULL;
    if(pstNewChargePackage == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstPackageNode = Config_FindAndCreatPackageNode(pstNewChargePackage->uiPackageId,MOS_NULL);
    
    pstPackageNode->uiPackageId = pstNewChargePackage->uiPackageId;
    MOS_STRNCPY(pstPackageNode->aucExpireData,pstNewChargePackage->aucExpireData,sizeof(pstPackageNode->aucExpireData));
    MOS_STRNCPY(pstPackageNode->aucStartData,pstNewChargePackage->aucStartData,sizeof(pstPackageNode->aucStartData));
    MOS_STRNCPY(pstPackageNode->aucUid,pstNewChargePackage->aucUid,sizeof(pstPackageNode->aucUid));
    Config_GetItemSign()->ucSaveServSetFlag = 1;
    return MOS_OK;
}

_INT Config_RemoveChargePackage(_UI uiChargePackageId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PACKAGE_NODE *pstPackageNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetServerSetMng()->stPackageList, pstPackageNode, stIterator)
    {
        if(pstPackageNode->uiUseFlag && pstPackageNode->uiPackageId == uiChargePackageId)
        {
            pstPackageNode->uiPackageId = 0;
            pstPackageNode->uiUseFlag    = 0;
            Config_GetItemSign()->ucSaveServSetFlag = 1;
            return MOS_OK;
        }
    }
    return MOS_OK;
}

_VPTR Config_BuildServerSetObject()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PACKAGE_NODE *pstPackageNode = MOS_NULL;
    JSON_HANDLE hArryItem = MOS_NULL;
    JSON_HANDLE hArry     = MOS_NULL;
    JSON_HANDLE hRoot     = Adpt_Json_CreateObject();
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"ResolutionLimit",Adpt_Json_CreateStrWithNum(Config_GetServerSetMng()->uiCamResolution));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"IoTHubLimit",Adpt_Json_CreateStrWithNum(Config_GetServerSetMng()->uiIotHubLimit));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiServSetSign));

    hArry = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"PackageList",hArry);

    FOR_EACHDATA_INLIST(&Config_GetServerSetMng()->stPackageList, pstPackageNode, stIterator)
    {
        if(pstPackageNode->uiUseFlag == 0)
        {
            continue;
        }
        hArryItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArry,hArryItem);

        Adpt_Json_AddItemToObject(hArryItem,(_UC*)"PackageID",Adpt_Json_CreateStrWithNum(pstPackageNode->uiPackageId));
        Adpt_Json_AddItemToObject(hArryItem,(_UC*)"StartDate",Adpt_Json_CreateString(pstPackageNode->aucStartData));
        Adpt_Json_AddItemToObject(hArryItem,(_UC*)"ExpireDate",Adpt_Json_CreateString(pstPackageNode->aucExpireData));
        Adpt_Json_AddItemToObject(hArryItem,(_UC*)"UID",Adpt_Json_CreateString(pstPackageNode->aucUid));
    }
    return hRoot;

}

_UC *Config_BuildServerSetJson()
{
    _UC *pStrTmp = MOS_NULL;    
    JSON_HANDLE hRoot     = Config_BuildServerSetObject();
    
    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(SERVERSET_LOGSTR,"build serverset info %s",pStrTmp);
    return pStrTmp;
}

// 读取服务器设置配置的字段
_INT Config_ParseServerSetJson(_UC *pStrJson)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _UC *pstrTmp = MOS_NULL;
    _INT iPackageId  = 0;
    _UI i,uiArrySize = 0;
    JSON_HANDLE hArrayItem = MOS_NULL;
    JSON_HANDLE hArray    = MOS_NULL;
    ST_CFG_PACKAGE_NODE *pstPackageNode = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);

    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    // 分辨率限制
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ResolutionLimit"),&Config_GetServerSetMng()->uiCamResolution);
    // 拓展IOT设备限制
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IoTHubLimit"),&Config_GetServerSetMng()->uiIotHubLimit);
    // 每个配置项的版本ID  设备端生成
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),&Config_GetItemSign()->uiServSetSign);
    
    // 包列表
    hArray = Adpt_Json_GetObjectItem(hRoot,(_UC*)"PackageList");
    uiArrySize = Adpt_Json_GetArraySize(hArray);

    for(i = 0; i < uiArrySize; i++)
    {
        hArrayItem = Adpt_Json_GetArrayItem(hArray, i);
        // 包ID
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PackageID"),&iPackageId);
        pstPackageNode = Config_FindAndCreatPackageNode(iPackageId,MOS_NULL);

        // 开始日期
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"StartDate"),&pstrTmp);
        MOS_STRNCPY(pstPackageNode->aucStartData, pstrTmp, sizeof(pstPackageNode->aucStartData));
        // 到期日期
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"ExpireDate"),&pstrTmp);
        MOS_STRNCPY(pstPackageNode->aucExpireData, pstrTmp, sizeof(pstPackageNode->aucExpireData));
        //UID
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"UID"),&pstrTmp);
        MOS_STRNCPY(pstPackageNode->aucUid, pstrTmp, sizeof(pstPackageNode->aucUid));
    }
    Adpt_Json_Delete( hRoot);
    return MOS_OK;
}



