#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "kjiot_device_prv.h"

ST_MOS_LIST *Config_GetTimePolicyList()
{
    return &Config_GetlocalCfgInf()->stTimePolicyList;
}

ST_CFG_TIMEPOLICY_NODE *Config_FindTimePolicyNode(_UC *pucPolicyId)
{
    if (pucPolicyId == MOS_NULL)
    {
        return MOS_NULL;
    }

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstPolicyNode, stIterator)
    {
        if ((MOS_STRNCMP(pstPolicyNode->aucPolicyId, pucPolicyId, sizeof(pstPolicyNode->aucPolicyId)) == 0) && (pstPolicyNode->uiUseFlag))
        {
            break;
        }
    }
    return pstPolicyNode;
}

ST_CFG_TIMEPOLICY_NODE* Config_FindOrCreatTimePolicy(_UC *pucPolicyId)
{
    if (pucPolicyId == MOS_NULL)
    {
        return MOS_NULL;
    }

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyTmpNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstPolicyNode, stIterator)
    {
        if ((MOS_STRNCMP(pstPolicyNode->aucPolicyId, pucPolicyId, sizeof(pstPolicyNode->aucPolicyId)) == 0) && (pstPolicyNode->uiUseFlag))
        {
            pstPolicyNode->uiUseFlag = 1;
            return pstPolicyNode;
        }
        else if (pstPolicyNode->uiUseFlag == 0)
        {
            pstPolicyTmpNode = pstPolicyNode;
        }   
    }
    if (pstPolicyTmpNode == MOS_NULL)
    {
        pstPolicyTmpNode = (ST_CFG_TIMEPOLICY_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_TIMEPOLICY_NODE));
        MOS_LIST_ADDTAIL(Config_GetTimePolicyList(), pstPolicyTmpNode);
    }

    MOS_STRNCPY(pstPolicyTmpNode->aucPolicyId, pucPolicyId, sizeof(pstPolicyTmpNode->aucPolicyId));
    pstPolicyTmpNode->uiUseFlag  = 1;
    pstPolicyTmpNode->uiWorkFlag = EN_TIMEPOLICY_STATUS_NOWORK;
    return pstPolicyTmpNode;
}

_INT Config_SetTimePolicyOpenFlag(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiOpenFlag)
{
    if (pstTimerNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if (pstTimerNode->uiOpenFlag == uiOpenFlag)
    {
        return MOS_OK;
    }
    pstTimerNode->uiOpenFlag = uiOpenFlag;
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    if (uiOpenFlag == 0)
    { 
        MOS_LIST_RMVNODE(Config_GetTimePolicyList(), pstTimerNode);
        MOS_LIST_ADDHEAD(Config_GetTimePolicyList(), pstTimerNode);
    }
    else
    {
        MOS_LIST_RMVNODE(Config_GetTimePolicyList(), pstTimerNode);
        MOS_LIST_ADDTAIL(Config_GetTimePolicyList(), pstTimerNode);
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    Config_GetItemSign()->ucSaveTimePolicy      = 1;
    Config_GetItemSign()->ucCfgTimePolicyUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR, "set timer policyId %s openflag %u", pstTimerNode->aucPolicyId, uiOpenFlag);
    return MOS_OK;
}

_INT Config_SetTimePolicyName(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UC *pucPolicyName)
{
    if ((pstTimerNode == MOS_NULL) || (pucPolicyName == MOS_NULL))
    {
        return MOS_ERR;
    }

    if (MOS_STRNCMP(pstTimerNode->aucPolicyName, pucPolicyName, sizeof(pstTimerNode->aucPolicyName)) == 0)
    {
        return MOS_ERR;
    }
    MOS_STRNCPY(pstTimerNode->aucPolicyName, pucPolicyName, sizeof(pstTimerNode->aucPolicyName));
    Config_GetItemSign()->ucSaveTimePolicy      = 1;
    Config_GetItemSign()->ucCfgTimePolicyUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR, "set timer policyId %s Name %s", pstTimerNode->aucPolicyId, pucPolicyName);
    return MOS_OK;
}

_INT Config_SetTimePolicyTime(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiLoopType, _UC *pucDay, _UI uiWeekFlag, _UI uiStartTime, _UI uiEndTime, _UI uiSpanFlag)
{
    if ((pstTimerNode == MOS_NULL) || (pucDay == MOS_NULL))
    {
        return MOS_ERR;
    }

    if ((pstTimerNode->uiStartTime == uiStartTime) && (pstTimerNode->uiEndTime  == uiEndTime)    && 
        (pstTimerNode->uiSpanFlag == uiSpanFlag)   && (pstTimerNode->uiLoopType  == uiLoopType)  && 
        (pstTimerNode->uiWeekFlag == uiWeekFlag)   && (MOS_STRNCMP(pstTimerNode->aucDay, pucDay, sizeof(pstTimerNode->aucDay)) == 0))
    {
        return MOS_ERR;
    }
    MOS_STRNCPY(pstTimerNode->aucDay, pucDay, sizeof(pstTimerNode->aucDay));
    pstTimerNode->uiLoopType  = uiLoopType;
    pstTimerNode->uiStartTime = uiStartTime;
    pstTimerNode->uiEndTime   = uiEndTime;
    pstTimerNode->uiSpanFlag  = uiSpanFlag;
    pstTimerNode->uiWeekFlag  = uiWeekFlag;
    Config_GetItemSign()->ucSaveTimePolicy      = 1;
    Config_GetItemSign()->ucCfgTimePolicyUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR, "set timer policyId:%s  WeekFlag:0x%02x time:%u-%u SpanFlag:%u looptype:%u",
        pstTimerNode->aucPolicyId, uiWeekFlag, uiStartTime, uiEndTime, uiSpanFlag, uiLoopType);
    return MOS_OK;
}

_INT Config_SetTimePolicyOutPutWorkFlag(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiWorkFlag)
{
    if (pstTimerNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    if (pstTimerNode->uiWorkFlag == uiWorkFlag)
    {
        return MOS_OK;
    }

    pstTimerNode->uiWorkFlag = uiWorkFlag;
    Config_GetItemSign()->ucSaveTimePolicy      = 1;
    // Config_GetItemSign()->ucCfgTimePolicyUpdate = 1;
    return MOS_OK;
}  

_INT Config_SetTimePolicyOutPutSceneId(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiSceneId)
{
    if (pstTimerNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstTimerNode->uiSceneId = uiSceneId;
    Config_GetItemSign()->ucSaveTimePolicy      = 1;
    Config_GetItemSign()->ucCfgTimePolicyUpdate = 1;
    return MOS_OK;
}   

_INT Config_SetTimePolicyOutPutList(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, ST_MOS_LIST *pstOutputList)
{  
    if ((pstTimerNode == MOS_NULL) || (pstOutputList == MOS_NULL))
    {
        return MOS_ERR;
    }

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_OUTPUT_NODE  *pstSrcNode = MOS_NULL;
    ST_CFG_OUTPUT_NODE  *pstDstNode = MOS_NULL;
    
    Config_BegainSyncBussList(&pstTimerNode->stOutputList);

    Mos_MutexLock(&Config_Task_GetMng()->hMutex);  
    FOR_EACHDATA_INLIST(pstOutputList, pstSrcNode, stIterator)
    {
        pstDstNode = Config_FindAndCreatOutNode(&pstTimerNode->stOutputList, pstSrcNode->uiKjIoTType, pstSrcNode->lluKjIotId);
        if (pstDstNode->uiParamLen < pstSrcNode->uiParamLen)
        {
            MOS_FREE(pstDstNode->pucParam);
            pstDstNode->uiParamLen = pstSrcNode->uiParamLen + 128;
            pstDstNode->pucParam = MOS_MALLOCCLR(pstSrcNode->uiParamLen);
        }
        MOS_STRNCPY(pstDstNode->pucParam, pstSrcNode->pucParam, pstDstNode->uiParamLen);
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    
    Config_EndSyncBussList(&pstTimerNode->stOutputList);
    
    Config_GetItemSign()->ucSaveTimePolicy = 1;
    return MOS_OK;
}

_INT Config_AddTimerPolicyOutput(ST_CFG_TIMEPOLICY_NODE *pstTimerNode, _UI uiOutIotType, _LLID lluOutIotId, _UC *pucParam)
{
    if ((pstTimerNode == MOS_NULL) || (pucParam == MOS_NULL))
    {
        return MOS_ERR;
    }

    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;
    pstOutputNode = Config_FindAndCreatOutNode(&pstTimerNode->stOutputList, uiOutIotType, lluOutIotId);
    
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);  
    if (pstOutputNode->uiParamLen < MOS_STRLEN(pucParam))
    {
        MOS_FREE(pstOutputNode->pucParam);
        pstOutputNode->uiParamLen = MOS_STRLEN(pucParam) + 128;
        pstOutputNode->pucParam   = MOS_MALLOCCLR(pstOutputNode->uiParamLen);
    }
    MOS_STRNCPY(pstOutputNode->pucParam, pucParam, pstOutputNode->uiParamLen);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    Config_GetItemSign()->ucSaveTimePolicy      = 1;
    Config_GetItemSign()->ucCfgTimePolicyUpdate = 1;
    return MOS_OK;
}

_INT Config_BegainSyncTimerPolicy()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstPolicyNode, stIterator)
    {
        if (pstPolicyNode->uiUseFlag)
        {
            pstPolicyNode->uiUseFlag = 2;
        }
        FOR_EACHDATA_INLIST(&pstPolicyNode->stOutputList, pstOutputNode, stIterator1)
        {
            if (pstOutputNode->uiUseFlag)
            {
                pstOutputNode->uiUseFlag = 2;
            }
        }
    }
    return MOS_OK;
}

_INT Config_EndSyncTimerPolicy()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstPolicyNode, stIterator)
    {
        if (pstPolicyNode->uiUseFlag == 2)
        {
            pstPolicyNode->uiWeekFlag = 0;
            pstPolicyNode->uiUseFlag  = 0;
        }
        FOR_EACHDATA_INLIST(&pstPolicyNode->stOutputList, pstOutputNode, stIterator1)
        {
            if (pstOutputNode->uiUseFlag == 2)
            {
                pstOutputNode->uiUseFlag = 0;
            }
        }
    }
    return MOS_OK;
}

// 策略删除 ， 需要手动 开启全天 录制的 开关
_INT Config_DeleteTimePolicyByStr(_UC *pucPolicyId)
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstPolicyNode, stIterator)
    {
        if ((MOS_STRNCMP(pstPolicyNode->aucPolicyId, pucPolicyId, sizeof(pstPolicyNode->aucPolicyId)) == 0) && (pstPolicyNode->uiUseFlag))
        {
            pstPolicyNode->uiUseFlag  = 0;
            pstPolicyNode->uiWeekFlag = 0;
            pstPolicyNode->uiWorkFlag = EN_TIMEPOLICY_STATUS_NOWORK;

            FOR_EACHDATA_INLIST(&pstPolicyNode->stOutputList, pstOutputNode, stIterator1)
            {
                pstOutputNode->uiUseFlag = 0;
            }
            MOS_LIST_RMVNODE(Config_GetTimePolicyList(), pstPolicyNode);
            MOS_LIST_ADDHEAD(Config_GetTimePolicyList(), pstPolicyNode);
            break;
        }
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    Config_GetItemSign()->ucSaveTimePolicy      = 1;
    Config_GetItemSign()->ucCfgTimePolicyUpdate = 1;
    return MOS_OK;
}

_INT Config_TimePolicyDestroy()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);    
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstPolicyNode, stIterator)
    {
        MOS_LIST_RMVNODE(Config_GetTimePolicyList(), pstPolicyNode);
        FOR_EACHDATA_INLIST(&pstPolicyNode->stOutputList, pstOutputNode, stIterator1)
        {
            MOS_LIST_RMVNODE(&pstPolicyNode->stOutputList, pstOutputNode);
            MOS_FREE(pstOutputNode->pucParam);
            MOS_FREE(pstOutputNode);
        }
        MOS_FREE(pstPolicyNode);
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR, "timer policy destroy ok");
    return MOS_OK;
}
/***********************************************************************
*************************************************************************/
_VPTR Config_BuildTimerPolicyObject(_UI uiCfgType)
{
    _UC aucBuff[64]          = {0};
    JSON_HANDLE hParam       = MOS_NULL;
    JSON_HANDLE hIotArray    = MOS_NULL;
    JSON_HANDLE hIotItem     = MOS_NULL;
    JSON_HANDLE hOutputItem  = MOS_NULL;
    JSON_HANDLE hOutPutArray = MOS_NULL; 
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    JSON_HANDLE hRoot       = Adpt_Json_CreateObject();

    MOS_LOG_INF(CFG_LOGSTR, "build json of cfg_timePolicy");
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiTimePolicySign));
    
    hIotArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Policys",hIotArray);
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstPolicyNode, stIterator)
    {
        if (pstPolicyNode->uiUseFlag == 0)
        {
            continue;
        }
        hIotItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hIotArray,hIotItem);

        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"WorkFlag",Adpt_Json_CreateStrWithNum(pstPolicyNode->uiWorkFlag));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"PolicyName",Adpt_Json_CreateString(pstPolicyNode->aucPolicyName));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"PolicyID",Adpt_Json_CreateString(pstPolicyNode->aucPolicyId));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"OpenFlag",Adpt_Json_CreateStrWithNum(pstPolicyNode->uiOpenFlag));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"Week",Adpt_Json_CreateStrWithNum(pstPolicyNode->uiWeekFlag));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"StartTime",Adpt_Json_CreateStrWithNum(pstPolicyNode->uiStartTime));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"EndTime",Adpt_Json_CreateStrWithNum(pstPolicyNode->uiEndTime));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"LoopType",Adpt_Json_CreateStrWithNum(pstPolicyNode->uiLoopType));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"SpanFlag",Adpt_Json_CreateStrWithNum(pstPolicyNode->uiSpanFlag));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"Day",Adpt_Json_CreateString(pstPolicyNode->aucDay));
        hOutPutArray = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"Action",hOutPutArray);
        
        FOR_EACHDATA_INLIST(&pstPolicyNode->stOutputList, pstOutputNode, stIterator1)
        {
            if (pstOutputNode->uiUseFlag == 0)
            {
                continue;
            }
            hOutputItem = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hOutPutArray,hOutputItem);
            
            Adpt_Json_AddItemToObject(hOutputItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstOutputNode->uiKjIoTType));
            MOS_VSNPRINTF(aucBuff, sizeof(aucBuff), "%llu", pstOutputNode->lluKjIotId);
            Adpt_Json_AddItemToObject(hOutputItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));
            if (pstOutputNode->pucParam)
            {
                hParam = Adpt_Json_Parse(pstOutputNode->pucParam);
                Adpt_Json_AddItemToObject(hOutputItem,(_UC*)"Output",hParam);
            }
        }
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    return hRoot;
}

_UC *Config_BuildTimePolicyJson(_UI uiCfgType)
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = Config_BuildTimerPolicyObject(uiCfgType);
    
    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(CFG_LOGSTR, "build timer policy info %s", pStrTmp);
    return pStrTmp;
}

// 读取定时件策略配置的字段
_INT Config_ParseTimePolicyJson(_UC *pStrJson,_UI uiCfgType)
{
    if (pStrJson == MOS_NULL)
    {
        return MOS_ERR;
    }

    _INT  i, iArrySize        = 0;
    _INT  j, jOutputArraySize = 0;
    _UI   uiKjIoTType         = 0;
    _LLID lluKjIoTId          = 0;
    _UC   aucPolicyId[64]     = {0};
    _UC  *pStrTmp             = MOS_NULL;
    JSON_HANDLE hObject       = MOS_NULL;
    JSON_HANDLE hIotArray     = MOS_NULL;
    JSON_HANDLE hIotItem      = MOS_NULL;
    JSON_HANDLE hArrayOutput  = MOS_NULL;
    JSON_HANDLE hArrayOutputItem          = MOS_NULL;
    ST_CFG_OUTPUT_NODE     *pstOutputNode = MOS_NULL;
    ST_CFG_TIMEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    
    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 签名
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiTimePolicySign);
    // 联动策略
    hIotArray = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Policys"); 
    iArrySize = Adpt_Json_GetArraySize(hIotArray);
    for (i = 0; i < iArrySize; i++)
    {
        hIotItem = Adpt_Json_GetArrayItem(hIotArray, i);
        // 策略ID，由客户端生成
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"PolicyID"),&pStrTmp);
        MOS_STRNCPY(aucPolicyId, pStrTmp, sizeof(aucPolicyId));
        pstPolicyNode = Config_FindOrCreatTimePolicy(aucPolicyId);
        
        // 定时任务工作状态 1 正在工作 0 没有工作
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"WorkFlag"),(_INT*)&pstPolicyNode->uiWorkFlag);
        // 开关 0.关闭；1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"OpenFlag"),(_INT*)&pstPolicyNode->uiOpenFlag);
        // 周几，为掩码代表一周中的一天或多天。0x01，为周一；0x02,为周二；0x04,为周三；0x08为周四；0x10为周五；0x20为周六；0x40为周日
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"Week"),(_INT*)&pstPolicyNode->uiWeekFlag);
        // 开始时间 (距离0点的秒数Hour*3600+Minute*60+usSecond)
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"StartTime"),(_INT*)&pstPolicyNode->uiStartTime);
        // 结束时间 (距离0点的秒数Hour*3600+Minute*60+usSecond)
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"EndTime"),(_INT*)&pstPolicyNode->uiEndTime); 
        // 是否跨天
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"SpanFlag"),(_INT*)&pstPolicyNode->uiSpanFlag);
        // 0 循环定时任务 ， 1 一次性定时任务
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"LoopType"),(_INT*)&pstPolicyNode->uiLoopType);
        // 日期
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"Day"),&pStrTmp);
        MOS_STRNCPY(pstPolicyNode->aucDay, pStrTmp, sizeof(pstPolicyNode->aucDay));
        
        // 策略名
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"PolicyName"),&pStrTmp);
        MOS_STRNCPY(pstPolicyNode->aucPolicyName, pStrTmp, sizeof(pstPolicyNode->aucPolicyName));
        
        // 定时任务动作
        hArrayOutput = Adpt_Json_GetObjectItem(hIotItem,(_UC*)"Action");
        jOutputArraySize = Adpt_Json_GetArraySize(hArrayOutput);
        for (j = 0; j < jOutputArraySize; j++)
        {
            hArrayOutputItem = Adpt_Json_GetArrayItem(hArrayOutput,j);
            // IoT类型
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayOutputItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
            // 非定时休眠的定时任务，设备启动时将定时任务的运行状态改为非运行状态
            if (uiKjIoTType != EN_ZJ_AIIOT_TYPE_CAMERA)
            {
                pstPolicyNode->uiWorkFlag = EN_TIMEPOLICY_STATUS_NOWORK;
            }
            // 设备ID
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayOutputItem,(_UC*)"AIIoTID"),&pStrTmp);
            MOS_SSCANF(pStrTmp, "%llu", &lluKjIoTId);
            pstOutputNode = Config_FindAndCreatOutNode(&pstPolicyNode->stOutputList,uiKjIoTType,lluKjIoTId);
            // 根据IoT类型定义OutPut
            hObject = Adpt_Json_GetObjectItem(hArrayOutputItem,(_UC*)"Output");
            pStrTmp = Adpt_Json_Print(hObject);  
            Mos_MutexLock(&Config_Task_GetMng()->hMutex);
            if (pstOutputNode->uiParamLen < MOS_STRLEN(pStrTmp))
            {
                MOS_FREE(pstOutputNode->pucParam);
                pstOutputNode->uiParamLen = MOS_STRLEN(pStrTmp) + 128;
                pstOutputNode->pucParam   = MOS_MALLOCCLR(pstOutputNode->uiParamLen);
            }
            MOS_STRNCPY(pstOutputNode->pucParam, pStrTmp, pstOutputNode->uiParamLen);
            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
            MOS_FREE(pStrTmp);
        }
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}



