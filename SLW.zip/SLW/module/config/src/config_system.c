#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"

ST_CFG_SYSTEM_MNG *Config_GetSystemMng()
{
    return &Config_GetlocalCfgInf()->stSystemMng;
}

_INT Config_SetCompanyInfo(_UC *pucCompanyId,_UC* pucAppId)
{
    MOS_PARAM_NULL_RETERR(pucCompanyId);
    MOS_PARAM_NULL_RETERR(pucAppId);

    if( MOS_STRCMP(Config_GetSystemMng()->aucCompanyId,pucCompanyId) == 0 && 
        MOS_STRCMP(Config_GetSystemMng()->aucAppId,pucAppId) == 0 )
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucCompanyId,pucCompanyId,sizeof(Config_GetSystemMng()->aucCompanyId));
    MOS_STRNCPY(Config_GetSystemMng()->aucAppId,pucAppId,sizeof(Config_GetSystemMng()->aucAppId));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set companyId %s, appId %s",pucCompanyId,pucAppId);
    return MOS_OK;
}

_INT Config_SetCTEIID(_UC* pucCTEI)
{
    MOS_PARAM_NULL_RETERR(pucCTEI);

    if(MOS_STRCMP(Config_GetSystemMng()->aucDevCTEI,pucCTEI) == 0)
    {
        return MOS_OK;
    }
    if(MOS_STRLEN(Config_GetSystemMng()->aucDevUID) == 0 || MOS_STRLEN(Config_GetSystemMng()->aucDevkey) == 0)
    {
        MOS_STRNCPY(Config_GetSystemMng()->aucDevUID,pucCTEI,sizeof(Config_GetSystemMng()->aucDevUID));
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucDevCTEI,pucCTEI,sizeof(Config_GetSystemMng()->aucDevCTEI));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set CTEI %s",pucCTEI);
    return MOS_OK;
}


_INT Config_SetDomainFlag(_INT iSetDomainFlag)
{
    if(Config_GetSystemMng()->uiSetDomainFlag == iSetDomainFlag)
    {
        return MOS_OK;
    }
    Config_GetSystemMng()->uiSetDomainFlag = iSetDomainFlag;
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set SetDomainFlag %d",iSetDomainFlag);
    return MOS_OK;
}

_INT Config_SetChargeFlag(_INT iChargeFlag)
{
    if(iChargeFlag == 0)
        Config_GetSystemMng()->uiChargeFlag = 0;
    else
        Config_GetSystemMng()->uiChargeFlag = (_UI)Mos_Time();
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set ChargeFlag %d",iChargeFlag);
    return MOS_OK;
}


_INT Config_SetLocalTimeZone(_INT iTimeZone)
{
    if(Config_GetSystemMng()->iTimeZone == iTimeZone)
    {
        return MOS_OK;
    }
    Config_GetSystemMng()->iTimeZone = iTimeZone;
    Config_GetSystemMng()->iSetZoneFlag = 1;
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set LocalTimeZone %d",iTimeZone);
    return MOS_OK;
}

_INT Config_SetDevCtrlType(_INT iCtrlType)
{
    if(Config_GetSystemMng()->iCtrlType == iCtrlType)
    {
        return MOS_OK;
    }
    if(iCtrlType == EN_ZJ_CTRLDID_EXITGROUP)
    {
        Config_Task_GetMng()->stBevBindInf.ucNeedExitGroup = 1;
    }
    Config_GetSystemMng()->iCtrlType   = iCtrlType;
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set DevCtrlType %d",iCtrlType);
    return MOS_OK;
}

_INT Config_SetAblPlatAddr(_INT iPutype,_UC *pucPuAddr)
{
    MOS_PARAM_NULL_RETERR(pucPuAddr);

    if(Config_GetSystemMng()->iPuType == iPutype && 
        MOS_STRCMP(Config_GetSystemMng()->aucPuAddr,pucPuAddr) == 0)
    {
        return MOS_OK;
    }
    Config_GetSystemMng()->iPuType = iPutype;
    MOS_STRNCPY(Config_GetSystemMng()->aucPuAddr,pucPuAddr,sizeof(Config_GetSystemMng()->aucPuAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set Putype %d, AblPlatAddr %s",iPutype,pucPuAddr);
    return MOS_OK;
}

_INT Config_SetAlarmPlatAddr(_UC *pucAlarmAddr)
{
    MOS_PARAM_NULL_RETERR(pucAlarmAddr);

    if(MOS_STRCMP(Config_GetSystemMng()->aucAlarmAddr,pucAlarmAddr) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMSET(Config_GetSystemMng()->aucAlarmAddr, 0,sizeof(Config_GetSystemMng()->aucAlarmAddr));
    MOS_STRNCPY(Config_GetSystemMng()->aucAlarmAddr,pucAlarmAddr,sizeof(Config_GetSystemMng()->aucAlarmAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set AlarmPlatAddr %s",pucAlarmAddr);
    return MOS_OK;
}

_INT Config_SetCloudPlatAddr(_UC *pucCloudAddr)
{
    MOS_PARAM_NULL_RETERR(pucCloudAddr);

    if(MOS_STRCMP(Config_GetSystemMng()->aucCloudAddr,pucCloudAddr) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMSET(Config_GetSystemMng()->aucCloudAddr, 0,sizeof(Config_GetSystemMng()->aucCloudAddr));
    MOS_STRNCPY(Config_GetSystemMng()->aucCloudAddr,pucCloudAddr,sizeof(Config_GetSystemMng()->aucCloudAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set CloudPlatAddr %s",pucCloudAddr);
    return MOS_OK;
}

_INT Config_SetOtherPlatAddr(_UC *pucOtherAddr)
{
    MOS_PARAM_NULL_RETERR(pucOtherAddr);

    if(MOS_STRCMP(Config_GetSystemMng()->aucOtherAddr,pucOtherAddr) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMSET(Config_GetSystemMng()->aucOtherAddr, 0,sizeof(Config_GetSystemMng()->aucOtherAddr));
    MOS_STRNCPY(Config_GetSystemMng()->aucOtherAddr,pucOtherAddr,sizeof(Config_GetSystemMng()->aucOtherAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set pucOtherAddr %s",pucOtherAddr);
    return MOS_OK;
}

_INT Config_SetReportPlatAddr(_UC *pucReportAddr)
{
    MOS_PARAM_NULL_RETERR(pucReportAddr);

    if(MOS_STRCMP(Config_GetSystemMng()->aucReportAddr,pucReportAddr) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMSET(Config_GetSystemMng()->aucReportAddr, 0,sizeof(Config_GetSystemMng()->aucReportAddr));
    MOS_STRNCPY(Config_GetSystemMng()->aucReportAddr,pucReportAddr,sizeof(Config_GetSystemMng()->aucReportAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set pucReportAddr %s",pucReportAddr);
    return MOS_OK;
}

_INT Config_SetRoutePlatAddr(_UC *pucRouteAddr)
{
    MOS_PARAM_NULL_RETERR(pucRouteAddr);

    if(MOS_STRCMP(Config_GetSystemMng()->aucRouteAddr,pucRouteAddr) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMSET(Config_GetSystemMng()->aucRouteAddr, 0,sizeof(Config_GetSystemMng()->aucRouteAddr));
    MOS_STRNCPY(Config_GetSystemMng()->aucRouteAddr,pucRouteAddr,sizeof(Config_GetSystemMng()->aucRouteAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set RoutePlatAddr %s",pucRouteAddr);
    return MOS_OK;
}

_INT Config_SetGa1400PlatAddr(_UC *pucGa1400Addr)
{
    MOS_PARAM_NULL_RETERR(pucGa1400Addr);

    if(MOS_STRCMP(Config_GetSystemMng()->aucGa1400Addr,pucGa1400Addr) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMSET(Config_GetSystemMng()->aucGa1400Addr, 0,sizeof(Config_GetSystemMng()->aucGa1400Addr));
    MOS_STRNCPY(Config_GetSystemMng()->aucGa1400Addr, pucGa1400Addr, sizeof(Config_GetSystemMng()->aucGa1400Addr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR, "cfg_system set Ga1400Addr %s", pucGa1400Addr);
    return MOS_OK;
}

_INT Config_SetImsPlatAddr(_UC *pucImsAddr)
{
    MOS_PARAM_NULL_RETERR(pucImsAddr);

    if(MOS_STRCMP(Config_GetSystemMng()->aucImsAddr,pucImsAddr) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMSET(Config_GetSystemMng()->aucImsAddr, 0,sizeof(Config_GetSystemMng()->aucImsAddr));
    MOS_STRNCPY(Config_GetSystemMng()->aucImsAddr, pucImsAddr, sizeof(Config_GetSystemMng()->aucImsAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR, "cfg_system set ImsAddr %s", pucImsAddr);
    return MOS_OK;
}

_INT Config_SetMngPlatDevUID(_UC *pucDevUID, _UC *pucDevKey)
{
    MOS_PARAM_NULL_RETERR(pucDevUID);
    MOS_PARAM_NULL_RETERR(pucDevKey);

    if( MOS_STRCMP(Config_GetSystemMng()->aucDevUID,pucDevUID) == 0 && 
        MOS_STRCMP(Config_GetSystemMng()->aucDevkey,pucDevKey) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucDevUID,pucDevUID,sizeof(Config_GetSystemMng()->aucDevUID));
    MOS_STRNCPY(Config_GetSystemMng()->aucDevkey,pucDevKey,sizeof(Config_GetSystemMng()->aucDevkey));
    Config_GetItemSign()->ucSaveSystem = 1;
	// MOS_LOG_INF(CFG_LOGSTR,"cfg_system set PlatDevSn %s, DevKey %s",pucDevUID,pucDevKey);
    return MOS_OK;
}

_INT Config_SetDevSn(_UC *pucDevSn)
{
    MOS_PARAM_NULL_RETERR(pucDevSn);

    if( MOS_STRCMP(Config_GetSystemMng()->aucDevSN,pucDevSn) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucDevSN,pucDevSn,sizeof(Config_GetSystemMng()->aucDevSN));
    Config_GetItemSign()->ucSaveSystem = 1;
	MOS_LOG_INF(CFG_LOGSTR,"cfg_system set DevSN  %s",pucDevSn);
    return MOS_OK;
}

_INT Config_SetMediaPlatSignAddr(_UC *pucSignAddr)
{
    MOS_PARAM_NULL_RETERR(pucSignAddr);

    if(MOS_STRCMP(Config_GetSystemMng()->aucSignAddr,pucSignAddr) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucSignAddr, pucSignAddr, sizeof(Config_GetSystemMng()->aucSignAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set MediaPlatSignAddr %s",pucSignAddr);
    return MOS_OK;
}

_INT Config_SetMediaPlatDeviceId(_UC *pucDid)
{
    MOS_PARAM_NULL_RETERR(pucDid);

    if(MOS_STRCMP(Config_GetSystemMng()->aucDid,pucDid) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucDid,pucDid,sizeof(Config_GetSystemMng()->aucDid));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set MediaPlatDeviceId %s",pucDid);
    return MOS_OK;
}

#ifdef DX_SECOND_LINK
_INT Config_SetGBMediaPlatSignAddr(_UC *pucSignAddr)
{
    if(MOS_STRCMP(Config_GetSystemMng()->aucGBSignAddr,pucSignAddr) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucGBSignAddr, pucSignAddr, sizeof(Config_GetSystemMng()->aucGBSignAddr));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set GbMediaPlat SignAddr %s",pucSignAddr);
    return MOS_OK;
}
_INT Config_SetGBMediaPlatDeviceId(_UC *pucDid)
{
    if(MOS_STRCMP(Config_GetSystemMng()->aucGBDid,pucDid) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucGBDid,pucDid,sizeof(Config_GetSystemMng()->aucGBDid));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set GBMediaPlat DeviceId %s",pucDid);
    return MOS_OK;
}

_INT Config_SetGBCTEIID(_UC* pucCTEI)
{
    if(MOS_STRCMP(Config_GetSystemMng()->aucGBDevCTEI,pucCTEI) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetSystemMng()->aucGBDevCTEI,pucCTEI,sizeof(Config_GetSystemMng()->aucGBDevCTEI));
    Config_GetItemSign()->ucSaveSystem = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_system set CTEI %s",pucCTEI);
    return MOS_OK;
}
#endif

/*********************************************************
 * 创建系统模块的json数据
***********************************************************/
_VPTR Config_BuildSystemObject()
{
    JSON_HANDLE hRoot  = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiSystemSign));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CtrlType",Adpt_Json_CreateStrWithNum(Config_GetSystemMng()->iCtrlType));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"TimeZone",Adpt_Json_CreateStrWithNum(Config_GetSystemMng()->iTimeZone));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SetZoneFlag",Adpt_Json_CreateStrWithNum(Config_GetSystemMng()->iSetZoneFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"ChargeFlag",Adpt_Json_CreateStrWithNum(Config_GetSystemMng()->uiChargeFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SetDomainFlag",Adpt_Json_CreateStrWithNum(Config_GetSystemMng()->uiSetDomainFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CTEI",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"PuType",Adpt_Json_CreateStrWithNum(Config_GetSystemMng()->iPuType));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"PuAddr",Adpt_Json_CreateString(Config_GetSystemMng()->aucPuAddr));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"DevSN",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"DevKey",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevkey));


    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CompanyID",Adpt_Json_CreateString(Config_GetSystemMng()->aucCompanyId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AppID",Adpt_Json_CreateString(Config_GetSystemMng()->aucAppId));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SignAddr",Adpt_Json_CreateString(Config_GetSystemMng()->aucSignAddr));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"DID",Adpt_Json_CreateString(Config_GetSystemMng()->aucDid));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudAddr",Adpt_Json_CreateString(Config_GetSystemMng()->aucCloudAddr));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AlarmAddr",Adpt_Json_CreateString(Config_GetSystemMng()->aucAlarmAddr));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Ga1400Addr",Adpt_Json_CreateString(Config_GetSystemMng()->aucGa1400Addr));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"ReportAddr",Adpt_Json_CreateString(Config_GetSystemMng()->aucReportAddr));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"OtherAddr",Adpt_Json_CreateString(Config_GetSystemMng()->aucOtherAddr));
    
#ifdef DX_SECOND_LINK     
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBDID",Adpt_Json_CreateString(Config_GetSystemMng()->aucGBDid));
#endif
    return hRoot;
}

_UC *Config_BuildSystemJson()
{
    _UC *pStrTmp = MOS_NULL;
    
    JSON_HANDLE hRoot  = Config_BuildSystemObject();

    pStrTmp = Adpt_Json_Print(hRoot);

    Adpt_Json_Delete(hRoot);

    // MOS_LOG_INF(CFG_LOGSTR,"build system json %s",pStrTmp);
    return pStrTmp;
}

// 读取系统配置的字段
_INT Config_ParseSystemJson(_UC *pStrJson)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot  = Adpt_Json_Parse(pStrJson);

    // 每个配置项的版本ID  设备端生成
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiSystemSign);
    // 对DID的操作类型 EN_ZJ_CTRLDEVICEID_TYPE
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),&Config_GetSystemMng()->iCtrlType);
    // 设备时区
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"TimeZone"),&Config_GetSystemMng()->iTimeZone);
    // 修改设备时区的标志
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SetZoneFlag"),&Config_GetSystemMng()->iSetZoneFlag);
    // 云存付费标志
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ChargeFlag"),&Config_GetSystemMng()->uiChargeFlag);

    // 是否已经成功设置过动态域名 1:是,0:否
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SetDomainFlag"),&Config_GetSystemMng()->uiSetDomainFlag);

    // 信令服务器的地址类型
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PuType"),&Config_GetSystemMng()->iPuType);
    
    // CTEI 码 设备的唯一标识
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CTEI"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucDevCTEI, pStrTmp, sizeof(Config_GetSystemMng()->aucDevCTEI));

    // 信令服务器的地址
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PuAddr"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucPuAddr, pStrTmp, sizeof(Config_GetSystemMng()->aucPuAddr));

    // 设备序列号
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevUID"),&pStrTmp);
    if (MOS_STRLEN(pStrTmp) >= 10)//适配SDK3.0
    {
        MOS_STRNCPY(Config_GetSystemMng()->aucDevUID, pStrTmp, sizeof(Config_GetSystemMng()->aucDevUID));		
        MOS_STRNCPY(Config_GetSystemMng()->aucDid, pStrTmp, sizeof(Config_GetSystemMng()->aucDid));
    }
    else
    {
        // 设备序列号
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevSN"),&pStrTmp);
        MOS_STRNCPY(Config_GetSystemMng()->aucDevUID, pStrTmp, sizeof(Config_GetSystemMng()->aucDevUID));

        // 设备ID
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DID"),&pStrTmp);
        MOS_STRNCPY(Config_GetSystemMng()->aucDid, pStrTmp, sizeof(Config_GetSystemMng()->aucDid));
    }	

    // 设备在能力平台的校验码  已弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevKey"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucDevkey, pStrTmp, sizeof(Config_GetSystemMng()->aucDevkey));

    // 签名地址 已弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SignAddr"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucSignAddr, pStrTmp, sizeof(Config_GetSystemMng()->aucSignAddr));

    // 公司ID 已弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CompanyID"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucCompanyId, pStrTmp, sizeof(Config_GetSystemMng()->aucCompanyId));

    // APP ID 已弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AppID"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucAppId, pStrTmp, sizeof(Config_GetSystemMng()->aucAppId));

    // 云存地址
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudAddr"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucCloudAddr, pStrTmp, sizeof(Config_GetSystemMng()->aucCloudAddr));

    // 告警地址
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AlarmAddr"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucAlarmAddr, pStrTmp, sizeof(Config_GetSystemMng()->aucAlarmAddr));

    // 自注册地址
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ReportAddr"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucReportAddr, pStrTmp, sizeof(Config_GetSystemMng()->aucReportAddr));

    // 其他地址
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OtherAddr"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucOtherAddr, pStrTmp, sizeof(Config_GetSystemMng()->aucOtherAddr));

    // 1400地址
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Ga1400Addr"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucGa1400Addr, pStrTmp, sizeof(Config_GetSystemMng()->aucGa1400Addr));

#ifdef DX_SECOND_LINK     
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBDID"),&pStrTmp);
    MOS_STRNCPY(Config_GetSystemMng()->aucGBDid, pStrTmp, sizeof(Config_GetSystemMng()->aucGBDid));
#endif
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}


