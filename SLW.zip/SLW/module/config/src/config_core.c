#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"

ST_CFG_CORE_MNG *Config_GetCoreMng()
{
    return &Config_GetlocalCfgInf()->stCoreMng;
}

_INT Config_SetDevIspInf(ST_CFG_ISPINF *pstIspInf)
{
    MOS_PARAM_NULL_RETERR(pstIspInf);

    if(MOS_MEMCMP(pstIspInf, &Config_GetCoreMng()->stIspInf, sizeof(ST_CFG_ISPINF)) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMCPY(&Config_GetCoreMng()->stIspInf, pstIspInf,sizeof(ST_CFG_ISPINF));
    Config_GetItemSign()->ucSaveCore = 1;
    return MOS_OK;
}

_INT Config_SetDevNetIp(_UC *pucNetIp)
{
    MOS_PARAM_NULL_RETERR(pucNetIp);

    if(MOS_STRCMP(Config_GetCoreMng()->aucNetIp, pucNetIp) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCoreMng()->aucNetIp, pucNetIp,sizeof(Config_GetCoreMng()->aucNetIp));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set DevNetIp %s",pucNetIp);
    return MOS_OK;
}

_INT Config_SetLinkServerAddr(_UC aucLinkIpv4Addr[CFG_STRING_LEN],_UC aucLinkIpv6Addr[CFG_STRING_LEN],_US usLinkPort)
{
    if( MOS_STRCMP(Config_GetCoreMng()->aucLinkIpv4, aucLinkIpv4Addr) == 0 && Config_GetCoreMng()->usLinkPort == usLinkPort
        && MOS_STRCMP(Config_GetCoreMng()->aucLinkIpv6, aucLinkIpv6Addr) == 0)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->usLinkPort = usLinkPort;
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkIpv4, aucLinkIpv4Addr,sizeof(Config_GetCoreMng()->aucLinkIpv4));
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkIpv6, aucLinkIpv6Addr,sizeof(Config_GetCoreMng()->aucLinkIpv6));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set link Addr ipV4 %s ipV6 %s linkPort %u",aucLinkIpv4Addr,aucLinkIpv6Addr,usLinkPort);
    return MOS_OK;

}

_INT Config_SetLinkServId(_UC *pucLinkSrvId)
{
    MOS_PARAM_NULL_RETERR(pucLinkSrvId);

    if( MOS_STRCMP(Config_GetCoreMng()->aucLinkSrvId, pucLinkSrvId) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkSrvId, pucLinkSrvId,sizeof(Config_GetCoreMng()->aucLinkSrvId));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set linkServerId %s",pucLinkSrvId);
    return MOS_OK;
}

_INT Config_SetLinkRegionId(_UC aucRegionId[CFG_CTEI_LEN+4])
{
    if(MOS_STRCMP(Config_GetCoreMng()->aucRegionId,aucRegionId) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCoreMng()->aucRegionId,aucRegionId,sizeof(Config_GetCoreMng()->aucRegionId));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set linkRegionId %s",aucRegionId);
    return MOS_OK;
}

_INT Config_SetLinkPlatEncInf(_INT iEncType,_UC *pucEncKey,_UC *pucEncLoad)
{
    MOS_PARAM_NULL_RETERR(pucEncKey);
    MOS_PARAM_NULL_RETERR(pucEncLoad);

    if( Config_GetCoreMng()->iLinkEncType == iEncType && 
        MOS_STRCMP(Config_GetCoreMng()->aucLinkEncKey,pucEncKey) == 0 &&
        MOS_STRCMP(Config_GetCoreMng()->aucLinkEncLoad,pucEncLoad) == 0)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->iLinkEncType = iEncType;
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkEncKey,pucEncKey,sizeof(Config_GetCoreMng()->aucLinkEncKey));
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkEncLoad,pucEncLoad,sizeof(Config_GetCoreMng()->aucLinkEncLoad));
    Config_GetItemSign()->ucSaveCore = 1;
    // MOS_LOG_INF(CFG_LOGSTR,"cfg_core set linkEncryptoInf encType %d, encKey %s, encLoad %s",iEncType, pucEncKey, pucEncLoad);
    return MOS_OK;
}

#ifdef DX_SECOND_LINK
_INT Config_SetGBLinkServerAddr(_UC aucLinkIpv4Addr[CFG_STRING_LEN],_UC aucLinkIpv6Addr[CFG_STRING_LEN],_US usLinkPort)
{
    if( MOS_STRCMP(Config_GetCoreMng()->aucGBLinkIpv4, aucLinkIpv4Addr) == 0 && Config_GetCoreMng()->usGBLinkPort == usLinkPort
        && MOS_STRCMP(Config_GetCoreMng()->aucGBLinkIpv6, aucLinkIpv6Addr) == 0)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->usGBLinkPort = usLinkPort;
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkIpv4, aucLinkIpv4Addr,sizeof(Config_GetCoreMng()->aucGBLinkIpv4));
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkIpv6, aucLinkIpv6Addr,sizeof(Config_GetCoreMng()->aucGBLinkIpv6));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set GBlink Addr ipV4 %s ipV6 %s linkPort %u",aucLinkIpv4Addr,aucLinkIpv6Addr,usLinkPort);
    return MOS_OK;
}
_INT Config_SetGBLinkServId(_UC *pucLinkSrvId)
{
    if( MOS_STRCMP(Config_GetCoreMng()->aucGBLinkSrvId, pucLinkSrvId) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkSrvId, pucLinkSrvId,sizeof(Config_GetCoreMng()->aucGBLinkSrvId));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set GBlinkServerId %s",pucLinkSrvId);
    return MOS_OK;
}
_INT Config_SetGBLinkRegionId(_UC aucRegionId[CFG_CTEI_LEN+4])
{
    if(MOS_STRCMP(Config_GetCoreMng()->aucGBRegionId,aucRegionId) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCoreMng()->aucGBRegionId,aucRegionId,sizeof(Config_GetCoreMng()->aucGBRegionId));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set GBlinkRegionId %s",aucRegionId);
    return MOS_OK;
}
_INT Config_SetGBLinkPlatEncInf(_INT iEncType,_UC *pucEncKey,_UC *pucEncLoad)
{
     if( Config_GetCoreMng()->iGBLinkEncType == iEncType && 
        MOS_STRCMP(Config_GetCoreMng()->aucGBLinkEncKey,pucEncKey) == 0 &&
        MOS_STRCMP(Config_GetCoreMng()->aucGBLinkEncLoad,pucEncLoad) == 0)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->iGBLinkEncType = iEncType;
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkEncKey,pucEncKey,sizeof(Config_GetCoreMng()->aucGBLinkEncKey));
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkEncLoad,pucEncLoad,sizeof(Config_GetCoreMng()->aucGBLinkEncLoad));
    Config_GetItemSign()->ucSaveCore = 1;
    // MOS_LOG_INF(CFG_LOGSTR,"cfg_core set GBlink EncryptoInf encType %d, encKey %s, encLoad %s",iEncType, pucEncKey, pucEncLoad);
    return MOS_OK;
}
#endif

_INT Config_SetDevCachePath(_UC *pucDevCachePath)
{
    MOS_PARAM_NULL_RETERR(pucDevCachePath);

    _UI uiLen = 0;
    if(MOS_STRLEN(pucDevCachePath) == 0)
    {
        pucDevCachePath = (_UC*)"";
    }
    MOS_LOG_INF(CFG_LOGSTR, "cfg_core set cache path %s",pucDevCachePath);

    uiLen = MOS_STRLEN(pucDevCachePath);

	if(MOS_STRLEN(pucDevCachePath) > 0){
        Mos_SetLogPath(pucDevCachePath,MOS_LOG_SDCARD_MAX_FILE_SIZE,MOS_LOG_SDCARD_MAX_FILE_NUM);
    }
    else{
        _INT iRet = 0;
        _UI uiLogSize = 0,uiLogNum = 0;
        iRet = Mos_SetGetLogSize(&uiLogSize, &uiLogNum, 0);
        if (iRet == MOS_OK && uiLogSize > 0 && uiLogNum > 0)
        {
            Mos_SetLogPath(Mos_GetWorkPath(),uiLogSize,uiLogNum);
        }
        else
        {
            MOS_LOG_ERR(CFG_LOGSTR, "set log size fail");
            uiLogSize = MOS_LOG_MAX_FILE_SIZE;
            uiLogNum = MOS_LOG_MAX_FILE_NUM;
            Mos_SetGetLogSize(&uiLogSize, &uiLogNum, 1);
            return MOS_ERR;
        }
    }

    if(MOS_STRCMP(Config_GetCoreMng()->aucCachePath, pucDevCachePath) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCoreMng()->aucCachePath, pucDevCachePath,sizeof(Config_GetCoreMng()->aucCachePath));
    if(uiLen > 0)
    {
        if(Config_GetCoreMng()->aucCachePath[uiLen - 1] == '/' || Config_GetCoreMng()->aucCachePath[uiLen - 1] == '\\')
        {
            Config_GetCoreMng()->aucCachePath[uiLen - 1] = 0;
        }
        Mos_DirMake(Config_GetCoreMng()->aucCachePath, MOS_DIR_MAKE_FLAG);
    }
    Config_GetItemSign()->ucSaveCore = 1;
    return MOS_OK;
}

_INT Config_SetDevSoudFilePath(_UC *pucSoudFilePath)
{
    MOS_PARAM_NULL_RETERR(pucSoudFilePath);

    _INT iLen =  MOS_STRLEN(pucSoudFilePath);
    
    if(MOS_STRCMP(Config_GetCoreMng()->aucSoudFilePath, pucSoudFilePath) == 0)
    {   
        return MOS_OK;
    }
    
    MOS_STRNCPY(Config_GetCoreMng()->aucSoudFilePath, pucSoudFilePath,sizeof(Config_GetCoreMng()->aucSoudFilePath));
    
    if(iLen > 0 && (Config_GetCoreMng()->aucSoudFilePath[iLen - 1] == '/' || Config_GetCoreMng()->aucSoudFilePath[iLen - 1] == '\\'))
    {
        Config_GetCoreMng()->aucSoudFilePath[iLen - 1] = 0;
    }
    MOS_LOG_INF(CFG_LOGSTR, "cfg_core set soud file path %s ",pucSoudFilePath);
    Config_GetItemSign()->ucSaveCore = 1;
    return MOS_OK;
}

_INT Config_SetHxLinkAddr(_UC *pucHxLinkAddr,_US usHxLinkPort)
{
    MOS_PARAM_NULL_RETERR(pucHxLinkAddr);

    if(Config_GetCoreMng()->usHxLinkPort == usHxLinkPort && MOS_STRCMP(Config_GetCoreMng()->aucHxLinkAddr,pucHxLinkAddr) == 0)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->usHxLinkPort = usHxLinkPort;
    MOS_STRNCPY(Config_GetCoreMng()->aucHxLinkAddr,pucHxLinkAddr,sizeof(Config_GetCoreMng()->aucHxLinkAddr));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set hxLinkAddr %s:%u",pucHxLinkAddr, usHxLinkPort);
    return MOS_OK;
}

_INT Config_SetHxLinkIPv6Addr(_UC *pucHxLinkIPv6Addr,_US usHxLinkPort)
{
    MOS_PARAM_NULL_RETERR(pucHxLinkIPv6Addr);

    if(Config_GetCoreMng()->usHxLinkPort == usHxLinkPort && MOS_STRCMP(Config_GetCoreMng()->aucHxLinkIPv6Addr,pucHxLinkIPv6Addr) == 0)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->usHxLinkPort = usHxLinkPort;
    MOS_STRNCPY(Config_GetCoreMng()->aucHxLinkIPv6Addr,pucHxLinkIPv6Addr,sizeof(Config_GetCoreMng()->aucHxLinkIPv6Addr));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set hxLinkAddr %s:%u",pucHxLinkIPv6Addr, usHxLinkPort);
    return MOS_OK;
}

_INT Config_SetCmdPlatEncrypInf(_INT iEncType,_UC *pucEncKey,_UC *pucEncLoad)
{
    MOS_PARAM_NULL_RETERR(pucEncKey);
    MOS_PARAM_NULL_RETERR(pucEncLoad);

    if( Config_GetCoreMng()->iEncType == iEncType && 
        MOS_STRCMP(Config_GetCoreMng()->aucEncKey,pucEncKey) == 0 &&
        MOS_STRCMP(Config_GetCoreMng()->aucEncLoad,pucEncLoad) == 0)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->iEncType = iEncType;
    MOS_STRNCPY(Config_GetCoreMng()->aucEncKey,pucEncKey,sizeof(Config_GetCoreMng()->aucEncKey));
    MOS_STRNCPY(Config_GetCoreMng()->aucEncLoad,pucEncLoad,sizeof(Config_GetCoreMng()->aucEncLoad));
    Config_GetItemSign()->ucSaveCore = 1;
    // MOS_LOG_INF(CFG_LOGSTR,"cfg_core set cmdPlat EncrypInf encType %d, encKey %s, encLoad %s",iEncType, pucEncKey, pucEncLoad);
    return MOS_OK;
}

_INT Config_SetAbilityUpLoadFlag(_UC ucUploadFlag)
{
    if(ucUploadFlag == Config_GetCoreMng()->ucAbilityUpFlag)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->ucAbilityUpFlag = ucUploadFlag;
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set ability UploadFlag %u",ucUploadFlag);
    return MOS_OK;
}

_INT Config_SetConfigUpLoadFlag(_UC ucUploadFlag)
{
    if(ucUploadFlag == Config_GetCoreMng()->ucBussUpFlag)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->ucBussUpFlag = ucUploadFlag;
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set business UploadFlag %u",ucUploadFlag);
    return MOS_OK;
}

_INT Config_SetAblPlatDevToken(_UC *pucDevToken)
{
    MOS_PARAM_NULL_RETERR(pucDevToken);

    if(MOS_STRCMP(Config_GetCoreMng()->aucDevToken,pucDevToken) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCoreMng()->aucDevToken,pucDevToken,sizeof(Config_GetCoreMng()->aucDevToken));
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set DevToken %s",pucDevToken);
    return MOS_OK;
}

_INT Config_SetConfigAnchorFlag(_UI uiAnchorFlag)
{
    if(uiAnchorFlag == Config_GetCoreMng()->uiAnchorFlag)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->uiAnchorFlag = uiAnchorFlag;
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set business UploadFlag %u",uiAnchorFlag);
    return MOS_OK;
}

// 用于3244登录信令服务器initflag字段
_INT Config_SetCmdLoginStatus(_UI uiCmdLoginStatus)
{
    if(uiCmdLoginStatus == Config_GetCoreMng()->uiCmdLoginStatus)
    {
        return MOS_OK;
    }
    Config_GetCoreMng()->uiCmdLoginStatus = uiCmdLoginStatus;
    Config_GetItemSign()->ucSaveCore = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_core set business CmdLoginStatus %u",uiCmdLoginStatus);
    return MOS_OK;
}

/****************************************************************************
******************************************************************************/
_UC *Config_BuildCoreInfJson()
{
    _UC *pstrTmp      = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();  
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiCoreSign));

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AbilityUpFlag",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->ucAbilityUpFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BussUpFlag",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->ucBussUpFlag));

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"DevUpFlag",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->ucCfgDevUpdate));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CamUpFlag",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->ucCfgCamUpdate));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"TimerUpFlag",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->ucCfgTimePolicyUpdate));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AlarmUpFlag",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->ucAlarmPolicyUpdate));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"linkPort",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->usLinkPort));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"region",Adpt_Json_CreateString(Config_GetCoreMng()->aucRegionId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"linkIpv4",Adpt_Json_CreateString(Config_GetCoreMng()->aucLinkIpv4));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"linkIpv6",Adpt_Json_CreateString(Config_GetCoreMng()->aucLinkIpv6));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"linkSrvid",Adpt_Json_CreateString(Config_GetCoreMng()->aucLinkSrvId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"LinkEncType",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->iLinkEncType));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"LinkEncKey",Adpt_Json_CreateString(Config_GetCoreMng()->aucLinkEncKey));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"LinkEncLoad",Adpt_Json_CreateString(Config_GetCoreMng()->aucLinkEncLoad));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"netip",Adpt_Json_CreateString(Config_GetCoreMng()->aucNetIp));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"cachePath",Adpt_Json_CreateString(Config_GetCoreMng()->aucCachePath));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"soundFilePath",Adpt_Json_CreateString(Config_GetCoreMng()->aucSoudFilePath));

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"HxlinkAddr",Adpt_Json_CreateString(Config_GetCoreMng()->aucHxLinkAddr));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"HxLinkPort",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->usHxLinkPort));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->iEncType));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"EncKey",Adpt_Json_CreateString(Config_GetCoreMng()->aucEncKey));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"EncLoad",Adpt_Json_CreateString(Config_GetCoreMng()->aucEncLoad));
 
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"countryid",Adpt_Json_CreateString(Config_GetCoreMng()->stIspInf.aucCountryId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"areaid",Adpt_Json_CreateString(Config_GetCoreMng()->stIspInf.aucAreaId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"cityid",Adpt_Json_CreateString(Config_GetCoreMng()->stIspInf.aucCityId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"countyid",Adpt_Json_CreateString(Config_GetCoreMng()->stIspInf.aucCountyId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"ispid",Adpt_Json_CreateString(Config_GetCoreMng()->stIspInf.aucISPId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"DevToken",Adpt_Json_CreateString(Config_GetCoreMng()->aucDevToken));
#ifdef DX_SECOND_LINK
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBlinkPort",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->usGBLinkPort));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBregion",Adpt_Json_CreateString(Config_GetCoreMng()->aucGBRegionId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBlinkIpv4",Adpt_Json_CreateString(Config_GetCoreMng()->aucGBLinkIpv4));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBlinkIpv6",Adpt_Json_CreateString(Config_GetCoreMng()->aucGBLinkIpv6));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBlinkSrvid",Adpt_Json_CreateString(Config_GetCoreMng()->aucGBLinkSrvId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBLinkEncType",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->iGBLinkEncType));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBLinkEncKey",Adpt_Json_CreateString(Config_GetCoreMng()->aucGBLinkEncKey));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"GBLinkEncLoad",Adpt_Json_CreateString(Config_GetCoreMng()->aucGBLinkEncLoad));
#endif
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AnchorFlag",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->uiAnchorFlag));

    // 第一次登录信令服务状态 用于3244登录信令服务器initflag字段 
    // 没有 CmdLoginStatus 字段默认为 固件升级后第一次登录上线，出厂第一次登录上线
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CmdLoginStatus",Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->uiCmdLoginStatus));

    pstrTmp = Adpt_Json_Print(hRoot); 
    Adpt_Json_Delete(hRoot);

    // MOS_LOG_INF(CFG_LOGSTR,"build core config info %s",pstrTmp);
    return pstrTmp;
}

 // 读取core核心配置的字段
_INT Config_ParseCoreInfJson(_UC *pStrJson)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _INT iValue       = 0;
    _UC *pstrTmp      = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);

    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiCoreSign);

    // 能力集上报标志
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AbilityUpFlag"),&iValue);
    Config_GetCoreMng()->ucAbilityUpFlag = (_UC)iValue;
    if(Config_GetCoreMng()->ucAbilityUpFlag != 2)
    {
        Config_GetCoreMng()->ucAbilityUpFlag = 0;
    }

    // 业务配置上报标志
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"BussUpFlag"),&iValue);
    Config_GetCoreMng()->ucBussUpFlag = (_UC)iValue;
    if(Config_GetCoreMng()->ucBussUpFlag != 2)
    {
        Config_GetCoreMng()->ucBussUpFlag = 0;
    }

    // 设备配置上报标志
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevUpFlag"),&iValue);
    if(iValue != 0)
    {
        Config_GetItemSign()->ucCfgDevUpdate = 1;
    }

    // 摄像机配置上报标志
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CamUpFlag"),&iValue);
    if(iValue != 0)
    {
        Config_GetItemSign()->ucCfgCamUpdate = 1;
    }

    // 时间策略上报标志
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"TimerUpFlag"),&iValue);
    if(iValue != 0)
    {
        Config_GetItemSign()->ucCfgTimePolicyUpdate = 1;
    }

    // 告警上报标志
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AlarmUpFlag"),&iValue);
    if(iValue != 0)
    {
        Config_GetItemSign()->ucAlarmPolicyUpdate = 1;;
    }

    // 区域 弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"region"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucRegionId, pstrTmp, sizeof(Config_GetCoreMng()->aucRegionId));

    // 弃用
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"linkPort"),&iValue);
    Config_GetCoreMng()->usLinkPort = (_US)iValue;

    // 弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"linkIpv4"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkIpv4, pstrTmp, sizeof(Config_GetCoreMng()->aucLinkIpv4));

    // 弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"linkIpv6"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkIpv6, pstrTmp, sizeof(Config_GetCoreMng()->aucLinkIpv6));
    
    // 弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"linkSrvid"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkSrvId, pstrTmp, sizeof(Config_GetCoreMng()->aucLinkSrvId));

    // 弃用
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"LinkEncType"),&Config_GetCoreMng()->iLinkEncType);
 
    // 弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"LinkEncKey"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkEncKey, pstrTmp, sizeof(Config_GetCoreMng()->aucLinkEncKey));

    // 弃用
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"LinkEncLoad"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucLinkEncLoad, pstrTmp, sizeof(Config_GetCoreMng()->aucLinkEncLoad));

    // 缓存路径
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"cachePath"),&pstrTmp);
    if(MOS_STRLEN(pstrTmp))
        MOS_STRNCPY(Config_GetCoreMng()->aucCachePath, pstrTmp, sizeof(Config_GetCoreMng()->aucCachePath));

    // 声音文件路径
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"soundFilePath"),&pstrTmp);
    if(MOS_STRLEN(pstrTmp))
        MOS_STRNCPY(Config_GetCoreMng()->aucSoudFilePath, pstrTmp, sizeof(Config_GetCoreMng()->aucSoudFilePath));

    // 信令服务器IP
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"HxlinkAddr"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucHxLinkAddr, pstrTmp, sizeof(Config_GetCoreMng()->aucHxLinkAddr));
    
    // 信令服务端口
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"HxLinkPort"),&iValue);
    Config_GetCoreMng()->usHxLinkPort = (_US)iValue;

    // 信令服务加密类型
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EncType"),&Config_GetCoreMng()->iEncType);
    
    // 信令服务加密密钥
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EncKey"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucEncKey, pstrTmp, sizeof(Config_GetCoreMng()->aucEncKey));

    // 信令服务加密向量
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EncLoad"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucEncLoad, pstrTmp, sizeof(Config_GetCoreMng()->aucEncLoad));

#ifdef DX_SECOND_LINK
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBlinkPort"),&iValue);
    Config_GetCoreMng()->usGBLinkPort = (_US)iValue;

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBlinkIpv4"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkIpv4, pstrTmp, sizeof(Config_GetCoreMng()->aucGBLinkIpv4));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBlinkIpv6"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkIpv6, pstrTmp, sizeof(Config_GetCoreMng()->aucGBLinkIpv6));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBregion"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucGBRegionId, pstrTmp, sizeof(Config_GetCoreMng()->aucGBRegionId));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBlinkSrvid"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkSrvId, pstrTmp, sizeof(Config_GetCoreMng()->aucGBLinkSrvId));

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBLinkEncType"),&Config_GetCoreMng()->iGBLinkEncType);
 
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBLinkEncKey"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkEncKey, pstrTmp, sizeof(Config_GetCoreMng()->aucGBLinkEncKey));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GBLinkEncLoad"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucGBLinkEncLoad, pstrTmp, sizeof(Config_GetCoreMng()->aucGBLinkEncLoad));
#endif

    // 国家ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"countryid"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->stIspInf.aucCountryId, pstrTmp, sizeof(Config_GetCoreMng()->stIspInf.aucCountryId));

    // 区域ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"areaid"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->stIspInf.aucAreaId, pstrTmp, sizeof(Config_GetCoreMng()->stIspInf.aucAreaId));

    // 城市ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"cityid"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->stIspInf.aucCityId, pstrTmp, sizeof(Config_GetCoreMng()->stIspInf.aucCityId));
    
    // 县ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"countyid"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->stIspInf.aucCountyId, pstrTmp, sizeof(Config_GetCoreMng()->stIspInf.aucCountyId));

    // ISPID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ispid"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->stIspInf.aucISPId, pstrTmp, sizeof(Config_GetCoreMng()->stIspInf.aucISPId));

    // 网络IP
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"netip"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucNetIp, pstrTmp, sizeof(Config_GetCoreMng()->aucNetIp));

    // 设备TOKEN信息
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevToken"),&pstrTmp);
    MOS_STRNCPY(Config_GetCoreMng()->aucDevToken, pstrTmp, sizeof(Config_GetCoreMng()->aucDevToken));

    // 锚旗
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AnchorFlag"), &iValue);
    Config_GetCoreMng()->uiAnchorFlag = iValue;

    // 第一次登录信令服务状态 用于3244登录信令服务器initflag字段
    // 没有 CmdLoginStatus 字段默认为 固件升级后第一次登录上线，出厂第一次登录上线
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CmdLoginStatus"), &iValue, EN_CMDLOGIN_STATUS_UPGRADE_OR_FACTORY);
    Config_GetCoreMng()->uiCmdLoginStatus = iValue;
    MOS_LOG_INF(CFG_LOGSTR, "Load CmdLoginStatus:%u", Config_GetCoreMng()->uiCmdLoginStatus);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}


