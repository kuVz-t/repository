#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "config_sync.h"
#include "msgmng_type.h"
#include "http_api.h"

// 云化额外能力值json解析组装到hLocalRootJson
_VOID Config_AddExtAbilityJson(_VPTR hExtRootArry,_VPTR hLocalRootJson)
{
    _INT iExtRootSize = 0;
    _INT i = 0;
    JSON_HANDLE hExtObj = MOS_NULL;
    JSON_HANDLE hLocalObj = MOS_NULL;
    _UC *pucExtObjName = MOS_NULL;
    _UC *pucTmpStr = MOS_NULL;
    JSON_HANDLE hTmpObj = MOS_NULL;
    
    iExtRootSize = Adpt_Json_GetArraySize(hExtRootArry);
    for(i = 0; i < iExtRootSize; i++)
    {
        hExtObj = Adpt_Json_GetArrayItem(hExtRootArry,i);
        Adpt_Json_GetName(hExtObj,&pucExtObjName);

        if(Adpt_Json_GetType(hExtObj) == EN_ITRD_JSON_NODE_TYPE_OBJECT || 
            Adpt_Json_GetType(hExtObj) == EN_ITRD_JSON_NODE_TYPE_ARRAY)
        {
            if(pucExtObjName == MOS_NULL)
            {
                MOS_LOG_INF(CFG_LOGSTR,"obj type[%d] ,name is null,can not parse",Adpt_Json_GetType(hExtObj));
                continue;
            }
            hLocalObj = Adpt_Json_GetObjectItem(hLocalRootJson,pucExtObjName);
            if(hLocalObj)
            {
                Config_AddExtAbilityJson(hExtObj,hLocalObj);
            }
            else
            {
                pucTmpStr = Adpt_Json_Print(hExtObj);
                hTmpObj = Adpt_Json_Parse(pucTmpStr);
                Adpt_Json_AddItemToObject(hLocalRootJson,pucExtObjName,hTmpObj);
                Adpt_Json_DePrint(pucTmpStr);
            }
        }
        else if(Adpt_Json_GetType(hExtObj) == EN_ITRD_JSON_NODE_TYPE_STRING)
        {
            Adpt_Json_DeleteItemFromObject(hLocalRootJson,pucExtObjName);
            pucTmpStr = Adpt_Json_Print(hExtObj);
            hTmpObj = Adpt_Json_Parse(pucTmpStr);
            Adpt_Json_AddItemToObject(hLocalRootJson,pucExtObjName,hTmpObj);
            Adpt_Json_DePrint(pucTmpStr);
        }   
    }
    return;
}
// 云化的额外能力值上报功能函数，云化启动的时候获取平台的能力值上报更新一次
_VOID Config_Proc_UploadCloudCamExtCfg()
{
    if(Config_GetCoreMng()->uiExtCfgUpFlag == 1 && Config_GetCoreMng()->ucAbilityUpFlag == 2)
    {
        JSON_HANDLE hRoot = Config_BuildLocalAbilityJson(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD);
        Config_AddSyncServerCfgTask(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD,0,hRoot);
        Config_GetCoreMng()->uiExtCfgUpFlag = 0;
    }
    return;
}
_VPTR Config_BuildLocalAbilityJson(_UC ucMsgType,_UC ucMsgId)
{
    _UC aucMethod[8];
    JSON_HANDLE hObject = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = Adpt_Json_CreateObject();
    ST_CFG_EXTINFO *pstExtInfo = &Config_Task_GetMng()->stExtCfg;

    MOS_LOG_INF(CFG_LOGSTR,"cfg_json build localAblity SJson");
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",ucMsgType,ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    hObject =  Config_BuildDeviceObject(EN_CFG_TYPE_ABILITY);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Device",hObject);

    hObject = Config_BuildCameraObject(EN_CFG_TYPE_ABILITY);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Camera",hObject);

    hObject = Config_BuildPtzObject(EN_CFG_TYPE_ABILITY);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"PresetSetting",hObject);

    hObject = Config_BuildInnerIotObject(EN_CFG_TYPE_ABILITY);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"InAIIoT",hObject);

    hObject = Config_BuildIotHubObject(EN_CFG_TYPE_ABILITY);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"AIIoTHub",hObject);

    hObject =  Config_BuildAIObject(EN_CFG_TYPE_ABILITY, EN_AI_BUILD_DOWNTASK_OFF);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"AI",hObject);

    // 云化的额外能力值组装添加到hBody
    if(MOS_STRLEN(pstExtInfo->pucExtAbilityJson) > 0)
    {
        JSON_HANDLE hExtRoot = Adpt_Json_Parse(pstExtInfo->pucExtAbilityJson);
        Config_AddExtAbilityJson(hExtRoot,hBody);
        Adpt_Json_Delete(hExtRoot);
    }
    return hRoot;
}

_VPTR Config_BuildLocalBussJson(_UC ucMsgType,_UC ucMsgId,_UI uiBussItem)
{
    _UC aucBuff[8];
    JSON_HANDLE hObject = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    if(uiBussItem == EN_ZJ_CFG_ITEM_ALL)
    {
        uiBussItem = 0XFFFFFF;
    }
    MOS_VSNPRINTF(aucBuff, 8, "%02X%02X",ucMsgType,ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucBuff));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"SetCmd",Adpt_Json_CreateStrWithNum(1));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ConfType",Adpt_Json_CreateStrWithNum(uiBussItem));
    if((uiBussItem&EN_ZJ_CFG_ITEM_DEVICE) > 0)
    {
        hObject = Config_BuildDeviceObject(EN_CFG_TYPE_BUSSNESS);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Device",hObject);
    }

    if((uiBussItem&EN_ZJ_CFG_ITEM_CAMERA) > 0)
    {    
        hObject = Config_BuildCameraObject(EN_CFG_TYPE_BUSSNESS);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Camera",hObject);
    }

    if((uiBussItem&EN_ZJ_CFG_ITEM_PTZ) > 0)
    {
        hObject = Config_BuildPtzObject(EN_CFG_TYPE_BUSSNESS);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"PresetSetting",hObject);
    }

    if((uiBussItem&EN_ZJ_CFG_ITEM_INIOT) > 0)
    {
        hObject = Config_BuildInnerIotObject(EN_CFG_TYPE_BUSSNESS);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"InAIIoT",hObject);
    }

    if((uiBussItem&EN_ZJ_CFG_ITEM_IOTHUB) > 0)
    {
        hObject = Config_BuildIotHubObject(EN_CFG_TYPE_BUSSNESS);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"AIIoTHub",hObject);
    }

    if((uiBussItem&EN_ZJ_CFG_ITEM_TIMEPOLICY) > 0)
    {
        hObject = Config_BuildTimerPolicyObject(EN_CFG_TYPE_BUSSNESS);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"TimePolicy",hObject);
    }

    if((uiBussItem&EN_ZJ_CFG_ITEM_ALARMPOLICY) > 0)
    {
        hObject = Config_BuildAlarmPolicyObject(EN_CFG_TYPE_BUSSNESS);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"IoTPolicy",hObject);
    }

    if((uiBussItem&EN_ZJ_CFG_ITEM_SCENEPOLICY) > 0)
    {
        hObject = Config_BuildScenePolicyObject(EN_CFG_TYPE_BUSSNESS);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"ScenePolicy",hObject);
    }

    if((uiBussItem&EN_ZJ_CFG_ITEM_AI) > 0)
    {
        hObject = Config_BuildAIObject(EN_CFG_TYPE_BUSSNESS, EN_AI_BUILD_DOWNTASK_OFF);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"AI",hObject);
    }

    return hRoot;
}

_VPTR Config_BuildAllLocalBussJson()
{
    JSON_HANDLE hObject = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_CreateObject();

    hObject = Config_BuildDeviceObject(EN_CFG_TYPE_BUSSNESS);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Device",hObject);

    hObject = Config_BuildCameraObject(EN_CFG_TYPE_BUSSNESS);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Camera",hObject);

    hObject = Config_BuildPtzObject(EN_CFG_TYPE_BUSSNESS);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"PresetSetting",hObject);

    hObject = Config_BuildInnerIotObject(EN_CFG_TYPE_BUSSNESS);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"InAIIoT",hObject);

    hObject = Config_BuildIotHubObject(EN_CFG_TYPE_BUSSNESS);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"AIIoTHub",hObject);

    hObject = Config_BuildTimerPolicyObject(EN_CFG_TYPE_BUSSNESS);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimePolicy",hObject);

    hObject = Config_BuildAlarmPolicyObject(EN_CFG_TYPE_BUSSNESS);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"IoTPolicy",hObject);

    hObject = Config_BuildScenePolicyObject(EN_CFG_TYPE_BUSSNESS);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ScenePolicy",hObject);

    hObject = Config_BuildAIObject(EN_CFG_TYPE_BUSSNESS, EN_AI_BUILD_DOWNTASK_OFF);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"AI",hObject);

    hObject = Config_BuildCloudSetObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CloudInf",hObject);

    hObject = Config_BuildImsSetObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"IMSInf",hObject);

    return hBody;
}

_VPTR Config_BuildUpLoadStatusJson(_UC ucMsgType,_UC ucMsgId)
{
    _UC aucMethod[8];
    JSON_HANDLE hBody = MOS_NULL;
    ST_CFG_INIOT_NODE* pstInIotNode = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

   
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",ucMsgType,ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Presence",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iPresence));

    pstInIotNode =  Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_RECORD,0);
    if(pstInIotNode)
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"SDRecordStatus",Adpt_Json_CreateStrWithNum(pstInIotNode->uiWorkStatus));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"SDRecordStatus",Adpt_Json_CreateStrWithNum(0));
    }
    pstInIotNode =  Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);

    if(pstInIotNode)
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"CloudRecordStatus",Adpt_Json_CreateStrWithNum(pstInIotNode->uiWorkStatus));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"CloudRecordStatus",Adpt_Json_CreateStrWithNum(0));
    }
    Adpt_Json_AddItemToObject(hBody,(_UC*)"OTAStatus",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iOtaStatus));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CamStatus",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiCamOpenFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    return hRoot;
}

