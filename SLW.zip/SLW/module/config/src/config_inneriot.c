#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"

ST_CFG_INNERIOT_MNG *Config_GetInIotMng()
{
    return &Config_GetlocalCfgInf()->stInnerIotMng;
}

/****************************************************************************
局部函数区间
*****************************************************************************/
static _INT Config_SetIotAbilityFlag(_UI uiKjIoTType,_UI uiAblityFlag)
{
    if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        Config_GetInIotMng()->uiMotionAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_DOORBELL)
    {
        Config_GetInIotMng()->uiDoorBellAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_RECORD)
    {
        Config_GetInIotMng()->uiRecordAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_PIR)
    {
        Config_GetInIotMng()->uiPirAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT)
    {
        Config_GetInIotMng()->uiVoiceAlarmAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_SNAPSHORT)
    {
        Config_GetInIotMng()->uiSnapJpgAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_LAMP)
    {
        Config_GetInIotMng()->uiLampAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_STATELAMP)
    {
        Config_GetInIotMng()->uiStatusLampAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_BUZZER)
    {
        Config_GetInIotMng()->uiBuzzerAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_CLOUDRECORD)
    {
        Config_GetInIotMng()->uiCloudAbility = uiAblityFlag; 
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_CLOUDSNAP)
    {
        Config_GetInIotMng()->uiCloudSnapAbility = uiAblityFlag; 
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_CAMERA)
    {
        Config_GetInIotMng()->uiCameraAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_EVENT)
    {
        Config_GetInIotMng()->uiEventAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_DNSET)
    {
        Config_GetInIotMng()->uiDnAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_FORCEREMOVE)
    {
        Config_GetInIotMng()->uiBreakAlarmAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_STAY)
    {
        Config_GetInIotMng()->uiStayAlarmAbility = uiAblityFlag;
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_CLOUDFACE)
    {
        Config_GetInIotMng()->uiCloudFaceAbility = uiAblityFlag;
    }

    return MOS_OK;
}

_INT Config_AddDefaultInIots(_UI uiKjIoTType)
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_CFG_INIOT_NODE *pstInIotNode = MOS_NULL;

    pstInIotNode = Config_FindInnerIotDevice(uiKjIoTType,0);
    if(pstInIotNode)
    {
        return MOS_OK;
    }
    Config_AddInIotDevice(uiKjIoTType,0);
    hRoot = Adpt_Json_CreateObject();
    switch (uiKjIoTType)
    {
        case EN_ZJ_AIIOT_TYPE_EVENT:
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"PushFlag",Adpt_Json_CreateStrWithNum(0x01));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"SMSFlag",Adpt_Json_CreateStrWithNum(1));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"EmailFlag",Adpt_Json_CreateStrWithNum(1));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"Interval",Adpt_Json_CreateStrWithNum(300));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"EmailAddr",Adpt_Json_CreateString((_UC*)""));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"StartTime",Adpt_Json_CreateStrWithNum(0));
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"EndTime",Adpt_Json_CreateStrWithNum(86400));
            break;
    }
    pStrTmp = Adpt_Json_Print(hRoot);
    Config_SetInIotProp(uiKjIoTType,0,pStrTmp);
    MOS_FREE(pStrTmp);
    Adpt_Json_Delete(hRoot);

#if 0
    {
        JSON_HANDLE hBody;
        ZJ_SetIRLedAbility(1);
        Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_INNER_LAMP,0);
        Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_PTZ,0);
        Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_MOTION,0);
        Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_DNSET,0);
        hRoot = Adpt_Json_CreateObject();
        hBody = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Motion",hBody);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Status",Adpt_Json_CreateStrWithNum(0));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Sensitive",Adpt_Json_CreateStrWithNum(30));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Interval",Adpt_Json_CreateStrWithNum(30));

        hBody = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Human",hBody);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Status",Adpt_Json_CreateStrWithNum(0));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Sensitive",Adpt_Json_CreateStrWithNum(30));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Interval",Adpt_Json_CreateStrWithNum(30));

        hBody = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Face",hBody);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Status",Adpt_Json_CreateStrWithNum(0));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Sensitive",Adpt_Json_CreateStrWithNum(30));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Interval",Adpt_Json_CreateStrWithNum(30));



        pStrTmp = Adpt_Json_Print(hRoot);
        Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_MOTION,0, pStrTmp);
        MOS_FREE(pStrTmp);
        Adpt_Json_Delete(hRoot);

        Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);
        hRoot = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"LoopDays",Adpt_Json_CreateStrWithNum(30));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"RecordFull",Adpt_Json_CreateStrWithNum(1));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"StreamID",Adpt_Json_CreateStrWithNum(0));
        pStrTmp = Adpt_Json_Print(hRoot);
        Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0, pStrTmp);
        MOS_FREE(pStrTmp);
        Adpt_Json_Delete(hRoot);
        
        Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDSNAP,0);
        hRoot = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"LoopDays",Adpt_Json_CreateStrWithNum(30));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Interval",Adpt_Json_CreateStrWithNum(30));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"PicType",Adpt_Json_CreateStrWithNum(2));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"FullFlag",Adpt_Json_CreateStrWithNum(0));
        pStrTmp = Adpt_Json_Print(hRoot);
        Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_CLOUDSNAP,0, pStrTmp);
        MOS_FREE(pStrTmp);
        Adpt_Json_Delete(hRoot); 
    }
#endif
    
    return MOS_OK;
}

_INT Config_InnerIot_Init()
{
    Mos_MutexCreate(&Config_GetInIotMng()->hMutex);
    MOS_LIST_INIT(&Config_GetInIotMng()->stInIotList);
    Config_GetInIotMng()->uiCloudLogAbility = 1;
    return MOS_OK;
}

_INT Config_InnerIot_Destroy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_INIOT_NODE *pstInTotNode = MOS_NULL;

    Mos_MutexLock(&Config_GetInIotMng()->hMutex);
    FOR_EACHDATA_INLIST(&Config_GetInIotMng()->stInIotList, pstInTotNode, stIterator)
    {
        MOS_FREE(pstInTotNode->pucProp);
        MOS_LIST_RMVNODE(&Config_GetInIotMng()->stInIotList, pstInTotNode);
        MOS_FREE(pstInTotNode);
    }
    Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
    
    Mos_MutexDelete(&Config_GetInIotMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR,"InIot destory Ok");
    return MOS_OK;
}

// 查找对应的KjIot设备属性的链表中的节点
ST_CFG_INIOT_NODE* Config_FindInnerIotDevice(_UI uiAotType,_LLID lluAotId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_INIOT_NODE *pstInIotNode = MOS_NULL;
    
    // 遍历KjIot设备的属性的链表
    FOR_EACHDATA_INLIST(&Config_GetInIotMng()->stInIotList, pstInIotNode, stIterator)
    {
        if(pstInIotNode->uiUseFlag && pstInIotNode->uiKjIoTType == uiAotType && pstInIotNode->lluKjIotId == lluAotId)
        {
            // 符合条件的节点
            break;
        }
    }

    // 返回符合条件的KjIot设备属性的节点
    return pstInIotNode;
}

// 添加或查找内部IOT设备
ST_CFG_INIOT_NODE* Config_FindAndCreatInnerIotDevice(_UI uiAotType,_LLID lluAotId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_INIOT_NODE *pstInIotNode = MOS_NULL;
    ST_CFG_INIOT_NODE *pstInIotTmpNode = MOS_NULL;
    
    // 遍历内部KjIot设备的链表
    FOR_EACHDATA_INLIST(&Config_GetInIotMng()->stInIotList, pstInIotNode, stIterator)
    {
        // 查找KjIot设备节点
        if( pstInIotNode->uiUseFlag && pstInIotNode->uiKjIoTType == uiAotType && pstInIotNode->lluKjIotId == lluAotId)
        {
            // 返回存在的KjIot设备节点
            return pstInIotNode;
        }
        // 创建KjIot设备节点
        else if(pstInIotNode->uiUseFlag == 0)
        {
            // 备份KjIot设备节点
            pstInIotTmpNode = pstInIotNode;
        }
    }

    if(pstInIotTmpNode == MOS_NULL)
    {
        // 申请新增的KjIot设备的内存空间
        pstInIotTmpNode = (ST_CFG_INIOT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_INIOT_NODE));
        MOS_LIST_ADDTAIL(&Config_GetInIotMng()->stInIotList, pstInIotTmpNode);
    }

    // 初始化新增的KjIot设备节点
    pstInIotTmpNode->uiKjIoTType = uiAotType;
    pstInIotTmpNode->lluKjIotId  = lluAotId;
    pstInIotTmpNode->uiOpenFlag  = 1;
    pstInIotTmpNode->uiDefaultSetFlag = 0;
    if(pstInIotTmpNode->uiPropLen > 0)
    {
        MOS_MEMSET(pstInIotTmpNode->pucProp, 0, pstInIotTmpNode->uiPropLen);
    }
    pstInIotTmpNode->uiUseFlag = 1;

    // 设置新增KjIot设备的能力集
    Config_SetIotAbilityFlag(uiAotType,1);
    Config_GetItemSign()->ucSaveInIot = 1;
    MOS_LOG_INF(CFG_LOGSTR,"InIot add new Iot[%u %llu]",uiAotType,lluAotId);

    // 返回新增的KjIot设备节点
    return pstInIotTmpNode;
}

// 新增内部IOT设备CFG
_INT Config_AddInIotDevice(_UI uiAotType,_LLID lluAotId)
{
    ST_CFG_INIOT_NODE *pstInKjIoTNode = Config_FindAndCreatInnerIotDevice(uiAotType,lluAotId);
    if(pstInKjIoTNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"pstInKjIoTNode == MOS_NULL");
        return MOS_ERR;
    }
    return MOS_OK;
}

_INT Config_RemoveInIotDevice(_UI uiAotType,_LLID lluAotId)
{
    ST_CFG_INIOT_NODE *pstInIotNode = Config_FindInnerIotDevice(uiAotType,lluAotId);
    if(pstInIotNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"pstInIotNode == MOS_NULL");
        return MOS_OK;
    }
    pstInIotNode->uiUseFlag = 0;
    Config_SetIotAbilityFlag(uiAotType,0);
    MOS_LOG_INF(CFG_LOGSTR,"InIot Remove Iot[%u %llu]",uiAotType,lluAotId);
    Config_GetItemSign()->ucSaveInIot = 1;
    return MOS_OK;
}

_INT Config_SetInIotProp(_UI uiAotType,_LLID lluAotId,_UC *pucProp)
{
    MOS_PARAM_NULL_RETERR(pucProp);

    _UI uiPropLen = MOS_STRLEN(pucProp);
    ST_CFG_INIOT_NODE *pstIniotNode = Config_FindInnerIotDevice(uiAotType,lluAotId);
    if(pstIniotNode == MOS_NULL || uiPropLen == 0)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"pstIniotNode == MOS_NULL || uiPropLen == 0");
        return MOS_ERR;
    }

    Mos_MutexLock(&Config_GetInIotMng()->hMutex); 
    if(MOS_STRCMP(pstIniotNode->pucProp,pucProp) == 0)
    {
        MOS_LOG_INF(CFG_LOGSTR,"pstIniotNode->pucProp == pucProp  So no change");
        Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
        return MOS_OK;
    }
    if(pstIniotNode->uiPropLen < uiPropLen)
    {
        MOS_FREE(pstIniotNode->pucProp);
        pstIniotNode->uiPropLen = uiPropLen + 128;  
        pstIniotNode->pucProp = (_UC*)MOS_MALLOCCLR(pstIniotNode->uiPropLen);
    }
    MOS_STRNCPY(pstIniotNode->pucProp,pucProp,pstIniotNode->uiPropLen);
    Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
    
    pstIniotNode->uiDefaultSetFlag = 1;
	Config_GetItemSign()->ucSaveInIot = 1;
    Config_GetItemSign()->ucCfgInIotUpdate = 1; 
    MOS_LOG_INF(CFG_LOGSTR,"InIot Set Iot[%u %llu] prop %s",uiAotType,lluAotId,pucProp);
    return MOS_OK;
}

_UC* Config_GetInIotProp(_UI uiAotType,_LLID lluAotId)
{
    ST_CFG_INIOT_NODE *pstIniotNode = Config_FindInnerIotDevice(uiAotType,lluAotId);
    if(pstIniotNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"pstIniotNode == MOS_NULL");
        return MOS_NULL;
    }
    else if(pstIniotNode->pucProp == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"pstIniotNode->pucProp == MOS_NULL");
        return MOS_NULL;
    }
    return pstIniotNode->pucProp;

}

// 增加IOT设备属性 (字段)
_INT Config_AddIoTProp(_UI uiAIIoTType, _LLID lluAIIoTID, _UI uiAIIoTEventId, _UC* pucAddProp, _UI uiValue)
{
    MOS_PARAM_NULL_RETERR(pucAddProp);

    _UI uiAddPropLen = MOS_STRLEN(pucAddProp);
    // 获取IOT的当前属性
    ST_CFG_INIOT_NODE *pstIniotNode = Config_FindInnerIotDevice(uiAIIoTType, lluAIIoTID);
    if(pstIniotNode == MOS_NULL || uiAddPropLen == 0)
    {
        MOS_LOG_ERR(CFG_LOGSTR, "IniotNode is Null || AddPropLen = %u", uiAddPropLen);
        return MOS_ERR;
    }

    Mos_MutexLock(&Config_GetInIotMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR, "Before AddIoTProp:%s", pstIniotNode->pucProp);
    JSON_HANDLE hBodyJson = Adpt_Json_Parse(pstIniotNode->pucProp);
    if (hBodyJson)
    {
        // 判断当前属性是否具有添加的字段
        JSON_HANDLE hAddPorpJson = Adpt_Json_GetObjectItem(hBodyJson, pucAddProp);
        if (hAddPorpJson == MOS_NULL)
        {
            // 属性添加pucAddProp字段和uiValue值
            Adpt_Json_AddItemToObject(hBodyJson, pucAddProp, Adpt_Json_CreateStrWithNum(uiValue));

            _UC *pucNewIoTProp = MOS_NULL;
            pucNewIoTProp = Adpt_Json_Print(hBodyJson);
            if (pucNewIoTProp)
            {
                // 把添加字段后的属性添加到IOT的属性
                _UI uiNewIoTPropLen = MOS_STRLEN(pucAddProp);
                if(pstIniotNode->uiPropLen < uiNewIoTPropLen)
                {
                    MOS_FREE(pstIniotNode->pucProp);
                    pstIniotNode->uiPropLen = uiNewIoTPropLen + 128;  
                    pstIniotNode->pucProp = (_UC*)MOS_MALLOCCLR(pstIniotNode->uiPropLen);
                }
                MOS_STRNCPY(pstIniotNode->pucProp, pucNewIoTProp, pstIniotNode->uiPropLen);
                // 查找告警IoT策略节点
                ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
                pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiAIIoTType, lluAIIoTID, uiAIIoTType);
                if (pstAPolicyNode)
                {
                    // 设置IoT告警策略属性
                    Config_SetAlarmPolicyProp(pstAPolicyNode, pstIniotNode->pucProp);
                }
                MOS_LOG_INF(CFG_LOGSTR, "After AddIoTProp:%s", pstIniotNode->pucProp);
                Adpt_Json_Delete(hBodyJson);
                Adpt_Json_DePrint(pucNewIoTProp);

                Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
                Config_GetItemSign()->ucSaveInIot = 1;
                Config_GetItemSign()->ucCfgInIotUpdate = 1; 
                MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu] Add Prop:%s Value:%u OK", uiAIIoTType, lluAIIoTID, pucAddProp, uiValue);
                return MOS_OK;
            }
            else
            {
                MOS_LOG_ERR(CFG_LOGSTR, "pucNewIoTProp is Null");
                Adpt_Json_Delete(hBodyJson);
                Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
                return MOS_ERR;
            }
        }
        else
        {
            MOS_LOG_ERR(CFG_LOGSTR, "InIot[%u %llu] Add Prop:%s Already Exist", uiAIIoTType, lluAIIoTID, pucAddProp);
            Adpt_Json_Delete(hBodyJson);
            Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
            return MOS_ERR;
        }
    }
    else
    {
        MOS_LOG_ERR(CFG_LOGSTR, "hBodyJson is Null");
        Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
        return MOS_ERR;
    }
}
/*
1000:
	1)pucDelProp==null && pucObjName != null 删除Motion、Human、Face、Car、Fence字段(删除1000的第一层字段)
	2)pucDelProp!=null && pucObjName != null 删除Motion、Human、Face、Car、Fence里的属性字段(删除1000的第二层字段)

非1000：
	1)pucDelProp!=null && pucObjName == null 删除非1000的IoT的第一层的属性字段
*/
// 删除IOT设备属性 (字段)
_INT Config_DelIoTProp(_UI uiAIIoTType, _LLID lluAIIoTID, _UI uiAIIoTEventId, _UC* pucDelProp, _UC* pucObjName)
{
    _UI uiDelPorpFlag        = 0;
    _UC *pucNewIoTProp       = MOS_NULL;
    JSON_HANDLE hDelPorpJson = MOS_NULL;

    // 获取IOT的当前属性
    ST_CFG_INIOT_NODE *pstIniotNode = Config_FindInnerIotDevice(uiAIIoTType, lluAIIoTID);
    if(pstIniotNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR, "IniotNode is Null");
        return MOS_ERR;
    }

    Mos_MutexLock(&Config_GetInIotMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR, "Before DelIotProp:%s", pstIniotNode->pucProp);
    JSON_HANDLE hBodyJson = Adpt_Json_Parse(pstIniotNode->pucProp);
    if (hBodyJson)
    {
        // 1000 MOTION  Motion Human Face Car CarNum Fence
        if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
        {
            if (pucObjName == MOS_NULL)
            {
                MOS_LOG_ERR(CFG_LOGSTR, "pucObjName is Null");
                Adpt_Json_Delete(hBodyJson);
                Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
                return MOS_ERR;   
            }

            JSON_HANDLE hDelObjNameJson = Adpt_Json_GetObjectItem(hBodyJson, pucObjName);
            if (hDelObjNameJson)
            {
                // 删除1000的Motion Face Human Car的属性字段
                if (pucDelProp != MOS_NULL)
                {
                    // 判断当前属性是否具有删除的字段
                    hDelPorpJson = Adpt_Json_GetObjectItem(hDelObjNameJson, pucDelProp);
                    if (hDelPorpJson)
                    {
                        uiDelPorpFlag = 1;
                        Adpt_Json_DeleteItemFromObject(hDelObjNameJson, pucDelProp);
                        MOS_LOG_INF(CFG_LOGSTR, "%s DelObjName:%s", pucObjName, pucDelProp);
                    }
                }
                else // 删除1000的Motion Face Human Car字段
                {
                    uiDelPorpFlag = 1;
                    Adpt_Json_DeleteItemFromObject(hBodyJson, pucObjName);
                }
            }
        }
        else
        {
            // 判断当前属性是否具有删除的字段
            hDelPorpJson = Adpt_Json_GetObjectItem(hBodyJson, pucDelProp);
            if (hDelPorpJson)
            {
                uiDelPorpFlag = 1;
                Adpt_Json_DeleteItemFromObject(hBodyJson, pucDelProp);
            }
        }

        if (1 == uiDelPorpFlag)
        {
            pucNewIoTProp = Adpt_Json_Print(hBodyJson);
            if (pucNewIoTProp)
            {
                // 把删除字段后的属性添加到IOT的属性
                MOS_MEMSET(pstIniotNode->pucProp, 0x0, pstIniotNode->uiPropLen);
                MOS_STRNCPY(pstIniotNode->pucProp, pucNewIoTProp, pstIniotNode->uiPropLen);

                MOS_LOG_INF(CFG_LOGSTR, "After DelIoTProp:%s", pstIniotNode->pucProp);
                Adpt_Json_Delete(hBodyJson);
                Adpt_Json_DePrint(pucNewIoTProp);

                Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
                Config_GetItemSign()->ucSaveInIot = 1;
                Config_GetItemSign()->ucCfgInIotUpdate = 1; 

                if(MOS_NULL != pucDelProp)
                {
                    MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu] Del Prop:%s OK", uiAIIoTType, lluAIIoTID, pucDelProp);
                }
                else
                {
                    MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu] Del Prop:%s OK", uiAIIoTType, lluAIIoTID, pucObjName);
                }

                return MOS_OK;
            }
            else
            {
                MOS_LOG_ERR(CFG_LOGSTR, "pucNewIoTProp is Null");
                Adpt_Json_Delete(hBodyJson);
                Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
                return MOS_ERR;
            }
        }
        else
        {
            if(MOS_NULL != pucDelProp)
            {
                MOS_LOG_ERR(CFG_LOGSTR, "InIot[%u %llu] Del Prop:%s No Exist", uiAIIoTType, lluAIIoTID, pucDelProp);
            }
            else
            {
                MOS_LOG_ERR(CFG_LOGSTR, "InIot[%u %llu] Del Prop:%s No Exist", uiAIIoTType, lluAIIoTID, pucObjName);
            }

            Adpt_Json_Delete(hBodyJson);
            Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
            return MOS_ERR;
        }
    }
    else
    {
        MOS_LOG_ERR(CFG_LOGSTR, "hBodyJson is Null");
        Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
        return MOS_ERR;
    }
}

_INT Config_SetInIotOpenFlag(_UI uiAotType,_LLID lluAotId,_INT iOpenFlag)
{
    MOS_LOG_INF(CFG_LOGSTR,"inIot set Iot [%u %llu] openFlag %d",uiAotType, lluAotId, iOpenFlag);

    ST_CFG_INIOT_NODE *pstInIotNode = Config_FindInnerIotDevice(uiAotType,lluAotId);
    if(pstInIotNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"pstInIotNode == MOS_NULL");
        return MOS_ERR;
    }
    if(pstInIotNode->uiOpenFlag == iOpenFlag)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"pstInIotNode->uiOpenFlag(%d) = iOpenFlag(%d) So no change", pstInIotNode->uiOpenFlag, iOpenFlag);
        return MOS_OK;
    }
    pstInIotNode->uiOpenFlag = iOpenFlag;
    Config_GetItemSign()->ucSaveInIot = 1; 
    Config_GetItemSign()->ucCfgInIotUpdate = 1;
    return MOS_OK;
}

_INT Config_SetAttachPtzAbility(_INT iAttachPtzAbility)
{
    if(Config_GetInIotMng()->uiAttachPtzAbility == iAttachPtzAbility)
    {
        return MOS_OK;
    }
    Config_GetInIotMng()->uiAttachPtzAbility = iAttachPtzAbility;
    Config_GetItemSign()->ucSaveInIot = 1;
    MOS_LOG_INF(CFG_LOGSTR,"inIot set AttachPtzAbility %d",iAttachPtzAbility);
    return MOS_OK;   
}

_INT Config_SetPtzSpeedAbility(_INT iPtzSpeedAbility)
{
    if(Config_GetInIotMng()->uiPtzSpeedAbility == iPtzSpeedAbility)
    {
        return MOS_OK;
    }
    Config_GetInIotMng()->uiPtzSpeedAbility = iPtzSpeedAbility;
    Config_GetItemSign()->ucSaveInIot = 1;
    MOS_LOG_INF(CFG_LOGSTR,"inIot set PtzSpeedAbility %d",iPtzSpeedAbility);
    return MOS_OK;   
}

_INT Config_SetPtzAbility(_UI uiPtzAbility)
{
    if(Config_GetInIotMng()->uiPtzAbility == uiPtzAbility)
    {
        return MOS_OK;
    }
    Config_GetInIotMng()->uiPtzAbility = uiPtzAbility;
    Config_GetItemSign()->ucSaveInIot = 1;
    MOS_LOG_INF(CFG_LOGSTR,"inIot set uiPtzAbility %d",uiPtzAbility);
    return MOS_OK;
}

_INT Config_SetRecordProp(_UI uiLoopRecordFlag,_UI uiRecordFullFlag,_UI uiStreamId,_UI uiDuration)
{
    MOS_LOG_INF(CFG_LOGSTR,">>>>>> uiLoopRecordFlag:%d uiRecordFullFlag:%d uiStreamId:%d uiDuration:%d", 
                                   uiLoopRecordFlag,   uiRecordFullFlag,   uiStreamId,   uiDuration);
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_CFG_INIOT_NODE *pstInKjIoTNode = Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_RECORD,0);

    if(pstInKjIoTNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetInIotMng()->stRecordInf.uiloopFlag == uiLoopRecordFlag
        && Config_GetInIotMng()->stRecordInf.uiFullFlag == uiRecordFullFlag
        && Config_GetInIotMng()->stRecordInf.uiStreamerId == uiStreamId
        && Config_GetInIotMng()->stRecordInf.uiDuration == uiDuration)
    {
        return MOS_OK;
    }
    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"RecordLoop",Adpt_Json_CreateStrWithNum(uiLoopRecordFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"RecordFull",Adpt_Json_CreateStrWithNum(uiRecordFullFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"StreamID",Adpt_Json_CreateStrWithNum(uiStreamId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDuration));

    pStrTmp = Adpt_Json_Print(hRoot);
    Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_RECORD,0,pStrTmp); 
    Config_GetInIotMng()->stRecordInf.uiloopFlag   = uiLoopRecordFlag;
    Config_GetInIotMng()->stRecordInf.uiFullFlag   = uiRecordFullFlag;
    Config_GetInIotMng()->stRecordInf.uiStreamerId = uiStreamId;
    Config_GetInIotMng()->stRecordInf.uiDuration   = uiDuration;
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);

    return MOS_OK;
}

_INT Config_GetLocalRecordProp(_UI *puiRecordLoop,_UI *puiRecordFull,_UI *puiStreamId,_UI *puiOpenFlag,_UI *puiDuration)
{
    ST_CFG_INIOT_NODE* pstIotNode =  Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_RECORD,0);
    if(pstIotNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(puiOpenFlag)
    {
        *puiOpenFlag = pstIotNode->uiOpenFlag;
    }
    if(puiRecordLoop)
    {
        *puiRecordLoop = Config_GetInIotMng()->stRecordInf.uiloopFlag;
    }
    if(puiRecordFull)
    {
        *puiRecordFull = Config_GetInIotMng()->stRecordInf.uiFullFlag;
    }
    if(puiStreamId)
    {
        *puiStreamId   = Config_GetInIotMng()->stRecordInf.uiStreamerId;
    }
    if(puiDuration)
    {
        *puiDuration = Config_GetInIotMng()->stRecordInf.uiDuration;
    }
    return MOS_OK;
}

_INT Config_SetDefaultRecordProp(_UI uiLoopRecordFlag,_UI uiRecordFullFlag,_UI uiStreamId,_UI uiDuration)
{
    ST_CFG_INIOT_NODE *pstInKjIoTNode = Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_RECORD,0);
    if(pstInKjIoTNode == MOS_NULL || pstInKjIoTNode->uiDefaultSetFlag == 1)
    {
        MOS_LOG_INF(CFG_LOGSTR,"already set default record prop");
        return MOS_OK;
    }
    MOS_LOG_INF(CFG_LOGSTR,"start set default record prop");
    return Config_SetRecordProp(uiLoopRecordFlag,uiRecordFullFlag,uiStreamId,uiDuration);
}

/****************************************************************
"SnapLoopFlag":""
"SnapInterval"
"SnapFullFlag"
"SnapPicType"
***************************************************************/
_INT Config_SetSnapProp(_UI uiLoopFlag,_UI uiFullFlag,_UI uiInterval,_UI uiPicType)
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    if( Config_GetInIotMng()->stSnapInf.uiLoopFlag == uiLoopFlag
        && Config_GetInIotMng()->stSnapInf.uiFullFlag == uiFullFlag
        && Config_GetInIotMng()->stSnapInf.uiInterval == uiInterval
        && Config_GetInIotMng()->stSnapInf.uiPicType  == uiPicType)
    {
        return MOS_OK;
    }
    hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SnapLoopFlag",Adpt_Json_CreateStrWithNum(uiLoopFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SnapInterval",Adpt_Json_CreateStrWithNum(uiInterval));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SnapFullFlag",Adpt_Json_CreateStrWithNum(uiFullFlag));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SnapPicType",Adpt_Json_CreateStrWithNum(uiPicType));
    pStrTmp = Adpt_Json_Print(hRoot);

    Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_SNAPSHORT,0,pStrTmp);
    Config_GetInIotMng()->stSnapInf.uiLoopFlag = uiLoopFlag;
    Config_GetInIotMng()->stSnapInf.uiFullFlag = uiFullFlag;
    Config_GetInIotMng()->stSnapInf.uiInterval = uiInterval;
    Config_GetInIotMng()->stSnapInf.uiPicType  = uiPicType;
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT Config_SetDefaultSnapProp(_UI uiLoopFlag,_UI uiFullFlag,_UI uiInterval,_UI uiPicType)
{
    ST_CFG_INIOT_NODE *pstInKjIoTNode = Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_SNAPSHORT,0);

    if(pstInKjIoTNode == MOS_NULL || pstInKjIoTNode->uiDefaultSetFlag == 1)
    {
        return MOS_OK;
    }
    return Config_SetSnapProp(uiLoopFlag,uiFullFlag,uiInterval,uiPicType);
}

_INT Config_GetCloudRecordProp(_UI *puiLoopDays,_UI *puiRecordType,_UI *puiStreamId,_UI *puiOpenFlag,_UI *puiDuration)
{
    JSON_HANDLE hRoot = MOS_NULL;
    ST_CFG_INIOT_NODE* pstIotNode =  Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0);
    if(pstIotNode == MOS_NULL)
    {
        // MOS_LOG_ERR(CFG_LOGSTR,"pstIotNode == MOS_NULL");
        return MOS_ERR;
    }
    Mos_MutexLock(&Config_GetInIotMng()->hMutex); 
    hRoot = Adpt_Json_Parse(pstIotNode->pucProp);
    Mos_MutexUnLock(&Config_GetInIotMng()->hMutex); 
    if(hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"hRoot == MOS_NULL");
        return MOS_ERR;
    }
    if(puiOpenFlag)
    {
        *puiOpenFlag = pstIotNode->uiOpenFlag;
    }
    if(puiLoopDays)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"LoopDays"),(_INT*)puiLoopDays);
    }
    if(puiRecordType)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"RecordType"),(_INT*)puiRecordType);
    }
    if(puiStreamId)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StreamID"),(_INT*)puiStreamId);
    }
    if(puiDuration)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Duration"),(_INT*)puiDuration);
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_INT Config_GetCloudSnapProp(_UI *puiLoopDays,_UI *puiRecordType,_UI *puiPicType,_UI *puiInteraval,_UI *puiOpenFlag)
{
    JSON_HANDLE hRoot = MOS_NULL;
    ST_CFG_INIOT_NODE* pstIotNode = Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_CLOUDSNAP,0);
    if(pstIotNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    Mos_MutexLock(&Config_GetInIotMng()->hMutex); 
    hRoot = Adpt_Json_Parse(pstIotNode->pucProp);
    Mos_MutexUnLock(&Config_GetInIotMng()->hMutex); 
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(puiOpenFlag)
    {
        *puiOpenFlag = pstIotNode->uiOpenFlag;
    }
    if(puiLoopDays)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"LoopDays"),(_INT*)puiLoopDays);
    }
    if(puiRecordType)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"RecordType"),(_INT*)puiRecordType);
    }
    if(puiInteraval)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Interval"),(_INT*)puiInteraval);
    }
    if(puiPicType)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PicType"),(_INT*)puiInteraval);
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_INT Config_GetMotionProp(_UI *puiHumanAbility,_UI *puiFaceAbility)
{
    JSON_HANDLE hObject = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    ST_CFG_INIOT_NODE* pstIotNode = Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_MOTION,0);

    if(pstIotNode == MOS_NULL || pstIotNode->pucProp == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    Mos_MutexLock(&Config_GetInIotMng()->hMutex); 
    hRoot = Adpt_Json_Parse(pstIotNode->pucProp);
    Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
    
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    hObject = Adpt_Json_GetObjectItem(hRoot, (_UC*)"Human");
    if(hObject != MOS_NULL && puiHumanAbility){
        *puiHumanAbility = 1;
    }

    hObject = Adpt_Json_GetObjectItem(hRoot, (_UC*)"Face");
    if(hObject != MOS_NULL && puiFaceAbility){
        *puiFaceAbility = 1;
    }
    
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}   

_INT Config_GetEventProp(_UI *puiPushFlag,_UI *puiSmsFlag,_UI *puiEamilFlag,_UI *puiInterval,
    _UC aucEmalAddr[256],_UI *puiCustomType,_UI *puiStartTime, _UI *puiEndTime, _UI *uiSpanFlag)
{
    _UC *pucStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_CFG_INIOT_NODE* pstIotNode =  Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_EVENT,0);
    if(pstIotNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    Mos_MutexLock(&Config_GetInIotMng()->hMutex);
    MOS_PRINTF("\r\nEvent 1013 JSON pstIotNode->pucProp: %s \r\n", pstIotNode->pucProp);
    hRoot = Adpt_Json_Parse(pstIotNode->pucProp);
    Mos_MutexUnLock(&Config_GetInIotMng()->hMutex); 
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(puiPushFlag)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PushFlag"),(_INT*)puiPushFlag);
    }
    if(puiSmsFlag)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SMSFlag"),(_INT*)puiSmsFlag);
    }
    if(puiEamilFlag)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EmailFlag"),(_INT*)puiEamilFlag);
    }
    if(puiInterval)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Interval"),(_INT*)puiInterval);
    }
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EmailAddr"),&pucStrTmp);
    if(aucEmalAddr)
    {
        MOS_STRNCPY(aucEmalAddr, pucStrTmp, 256);
    }
    if(puiCustomType)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CustomType"),(_INT*)puiCustomType);
    }
    if(puiStartTime)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StartTime"),(_INT*)puiStartTime);
    }
    if(puiEndTime)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EndTime"),(_INT*)puiEndTime);
    }
    if(uiSpanFlag)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SpanFlag"),(_INT*)uiSpanFlag);
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_INT Config_SetInIotWorkStatus(_UI uiAotType,_LLID lluAotId,_INT iWorkStatus)
{
    ST_CFG_INIOT_NODE* pstIotNode =  Config_FindInnerIotDevice(uiAotType,lluAotId);
    if(pstIotNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstIotNode->uiWorkStatus == iWorkStatus)
    {   
        return MOS_OK;
    }
    pstIotNode->uiWorkStatus = iWorkStatus;
    MOS_LOG_INF(CFG_LOGSTR,"inIot set KjIot [%u %llu] workstatus %d",uiAotType, lluAotId, iWorkStatus);
    return MOS_OK;
}

/*********************************************************************************
*********************************************************************************/
_VPTR Config_BuildInnerIotObject(_UI uICfgType)
{
    _UC aucBuff[64] ;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_INIOT_NODE *pstInIotNode = MOS_NULL;
    JSON_HANDLE hProp           = MOS_NULL;
    JSON_HANDLE hArryItem       = MOS_NULL;
    JSON_HANDLE hArry           = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiInIotSign));
    if((uICfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"PTZAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiPtzAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AttachPTZAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiAttachPtzAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"PTZSpeedAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiPtzSpeedAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MotionAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiMotionAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"DoorbellAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiDoorBellAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"RecordAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiRecordAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"PIRAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiPirAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"VoiceAlarmAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiVoiceAlarmAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SnapShotAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiSnapJpgAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"BuzzerAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiBuzzerAbility)); 
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"StatusLampAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiStatusLampAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"LampAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiLampAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudRecordAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiCloudAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudSnapshotAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiCloudSnapAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CameraAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiCameraAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"EventAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiEventAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"BreakAlarmAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiBreakAlarmAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"StayAlarmAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiStayAlarmAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"DNAAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiDnAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ColliSionAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiColliSionAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudLogAbility",Adpt_Json_CreateStrWithNum(Config_GetInIotMng()->uiCloudLogAbility));
    }
    
    if((uICfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        hArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IoTS",hArry);
        FOR_EACHDATA_INLIST(&Config_GetInIotMng()->stInIotList, pstInIotNode, stIterator)
        {
            if(pstInIotNode->uiUseFlag == 0)
            {
                continue;
            }
            hArryItem = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hArry,hArryItem);
            
            Adpt_Json_AddItemToObject(hArryItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstInIotNode->uiKjIoTType));
            MOS_VSNPRINTF(aucBuff, 64,(_UC*)"%llu", pstInIotNode->lluKjIotId);
            Adpt_Json_AddItemToObject(hArryItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));
            
            Adpt_Json_AddItemToObject(hArryItem,(_UC*)"OpenFlag",Adpt_Json_CreateStrWithNum(pstInIotNode->uiOpenFlag));
            Adpt_Json_AddItemToObject(hArryItem,(_UC*)"DefaultSetFlag",Adpt_Json_CreateStrWithNum(pstInIotNode->uiDefaultSetFlag));

            Mos_MutexLock(&Config_GetInIotMng()->hMutex);
            if(MOS_STRLEN(pstInIotNode->pucProp) > 0)
            {
                hProp = Adpt_Json_Parse(pstInIotNode->pucProp);
                Adpt_Json_AddItemToObject(hArryItem,(_UC*)"Prop",hProp);
            }
            Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
        }
    }
    return hRoot;
}

_UC *Config_BuildInnerIotJson(_UI uICfgType)
{
    _UC *pstrTmp      = MOS_NULL;    
    JSON_HANDLE hRoot = Config_BuildInnerIotObject(uICfgType);
    
    pstrTmp = Adpt_Json_Print(hRoot);

    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(CFG_LOGSTR,"build inIot info %s",pstrTmp); 
    // MOS_PRINTF("build Inner Iot info %s \r\n", pstrTmp);
    return pstrTmp;
}

// 读取内部IOT配置的字段
_INT Config_ParseInnerIotJson(_UC *pStrJson,_UI uICfgType)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _INT i, iArrySize;
    _INT iKjIoTType = 0;
    _LLID lluAotId  = 0;
    _UC   *pstrTmp;
    JSON_HANDLE hArry     = MOS_NULL;
    JSON_HANDLE hProp     = MOS_NULL;
    JSON_HANDLE hArryItem = MOS_NULL;
    ST_CFG_INIOT_NODE *pstInIotNode = MOS_NULL;
    JSON_HANDLE hRoot     = Adpt_Json_Parse(pStrJson);
    
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiInIotSign);
    
    if((uICfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        // PTZ能力  0.不支持；0x01:支持P；0x02:支持T；0x04: 支持Z
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PTZAbility"),(_INT*)&Config_GetInIotMng()->uiPtzAbility);
        // 外挂PTZ能力，枪机外接云台模式    0.不支持，0x01:支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AttachPTZAbility"),(_INT*)&Config_GetInIotMng()->uiAttachPtzAbility);
        // PTZ速度设置能力  0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PTZSpeedAbility"),(_INT*)&Config_GetInIotMng()->uiPtzSpeedAbility);
        // 运动检测支持能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"MotionAbility"),(_INT*)&Config_GetInIotMng()->uiMotionAbility);
        // 内置门铃按键支持能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DoorbellAbility"),(_INT*)&Config_GetInIotMng()->uiDoorBellAbility);
        // 录像能力支持 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"RecordAbility"),(_INT*)&Config_GetInIotMng()->uiRecordAbility);
        // 人体红外报警支持能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PIRAbility"),(_INT*)&Config_GetInIotMng()->uiPirAbility);
        // 声音检测支持能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"VoiceAlarmAbility"),(_INT*)&Config_GetInIotMng()->uiVoiceAlarmAbility);
        // 报警抓图支持能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SnapShotAbility"),(_INT*)&Config_GetInIotMng()->uiSnapJpgAbility);
        // 扬声器支持能力   0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"BuzzerAbility"),(_INT*)&Config_GetInIotMng()->uiBuzzerAbility);
        // 指示灯控制支持能力   0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StatusLampAbility"),(_INT*)&Config_GetInIotMng()->uiStatusLampAbility);
        // 白光灯控制支持能力   0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"LampAbility"),(_INT*)&Config_GetInIotMng()->uiLampAbility);
        // 云录制支持能力   0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudRecordAbility"),(_INT*)&Config_GetInIotMng()->uiCloudAbility);
        // 云抓图支持能力   0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudSnapshortAbility"),(_INT*)&Config_GetInIotMng()->uiCloudSnapAbility);
        // 支持摄像机采集打开关闭控制能力   0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CameraAbility"),(_INT*)&Config_GetInIotMng()->uiCameraAbility);
        // 事件记录能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EventAbility"),(_INT*)&Config_GetInIotMng()->uiEventAbility);
        // 强拆报警能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"BreakAlarmAbility"),(_INT*)&Config_GetInIotMng()->uiBreakAlarmAbility);
        // 逗留报警能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StayAlarmAbility"),(_INT*)&Config_GetInIotMng()->uiStayAlarmAbility);
        // DNA能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DNAAbility"),(_INT*)&Config_GetInIotMng()->uiDnAbility);
        // 碰撞报警能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ColliSionAbility"),(_INT*)&Config_GetInIotMng()->uiColliSionAbility);
    }
    if((uICfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        // IOT结构体
        hArry = Adpt_Json_GetObjectItem(hRoot,(_UC*)"IoTS");
        iArrySize = Adpt_Json_GetArraySize(hArry);
        for( i = 0 ; i < iArrySize; i++)
        {
            hArryItem = Adpt_Json_GetArrayItem(hArry,i);
            
            // 告警类型
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem,(_UC*)"AIIoTType"),(_INT*)&iKjIoTType);
            // 设备ID
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryItem,(_UC*)"AIIoTID"),&pstrTmp);
            MOS_SSCANF(pstrTmp, "%llu",&lluAotId);
            pstInIotNode = Config_FindAndCreatInnerIotDevice(iKjIoTType,lluAotId);

            // 是否设置默认值   0.不设置；1.设置
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem,(_UC*)"DefaultSetFlag"),(_INT*)&pstInIotNode->uiDefaultSetFlag);
            // 设备是否开启使用 0.关闭；1.打开
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryItem,(_UC*)"OpenFlag"),(_INT*)&pstInIotNode->uiOpenFlag);
            // IOT属性
            hProp = Adpt_Json_GetObjectItem(hArryItem,(_UC*)"Prop");
            if(hProp)
            {
                pstrTmp = Adpt_Json_Print(hProp);
                Mos_MutexLock(&Config_GetInIotMng()->hMutex); 
                if(pstInIotNode->uiPropLen < MOS_STRLEN(pstrTmp))
                {
                    MOS_FREE(pstInIotNode->pucProp);
                    pstInIotNode->uiPropLen =  MOS_STRLEN(pstrTmp) + 128;
                    pstInIotNode->pucProp   = (_UC*)MOS_MALLOCCLR(pstInIotNode->uiPropLen);
                }
                MOS_STRNCPY(pstInIotNode->pucProp,pstrTmp,pstInIotNode->uiPropLen);
                Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
                Adpt_Json_DePrint(pstrTmp);
                
                // 录像 RECORD 1002
                if(iKjIoTType == EN_ZJ_AIIOT_TYPE_RECORD)
                {
                    // 本地是否循环录像
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"RecordLoop"),(_INT*)&Config_GetInIotMng()->stRecordInf.uiloopFlag);
                    // 本地全天录像标志，1.全天录像；0.按策略进行录像；当设置策略时，由设置者来修改此项取值
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"RecordFull"),(_INT*)&Config_GetInIotMng()->stRecordInf.uiFullFlag);
                    // 录制码流选择。0.主码流；1.次码流
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"StreamID"),(_INT*)&Config_GetInIotMng()->stRecordInf.uiStreamerId);
                    // 本地录像当前状态，0.未录制；1.录制中
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"Status"),(_INT*)&Config_GetInIotMng()->stRecordInf.uiStatus);
                    // 报警录制时长
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"Duration"),(_INT*)&Config_GetInIotMng()->stRecordInf.uiDuration);
                }
                // 抓拍 1005  本地抓图
                else if(iKjIoTType == EN_ZJ_AIIOT_TYPE_SNAPSHORT)
                {
                    // 本地是否循环抓图
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"SnapLoopFlag"),(_INT*)&Config_GetInIotMng()->stSnapInf.uiLoopFlag);
                    // 定时抓图的时间间隔
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"SnapInterval"),(_INT*)&Config_GetInIotMng()->stSnapInf.uiInterval);
                    // 本地全天抓图标志，1.全天抓图；0.按策略进行抓图
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"SnapFullFlag"),(_INT*)&Config_GetInIotMng()->stSnapInf.uiFullFlag);
                    // 全天抓图的图片尺寸类型
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"SnapPicType"),(_INT*)&Config_GetInIotMng()->stSnapInf.uiPicType);
                }
            }
        }
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}



