#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_type.h"
#include "config_sync.h"
#include "http_api.h"
#include "http_type.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "msgmng_api.h"

#if 0
#define HTTP_GETLOGADDR_URL       (_UC*)"/log?v=1.0&t=yyyyMMddHHmmssSSS"

/**********************************************************************************
                            和LOG服务器之间的 同步
**********************************************************************************/
static ST_CFG_LOG_SYNC_NODE *Config_GetSyncLogNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_LOG_SYNC_NODE *pstSyncLogNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stLogServSyncList, pstSyncLogNode, stIterator)
    {
        if(pstSyncLogNode->ucStatus == EN_SERVER_NODE_NONE)
        {
            break;
        }
    }
    if(pstSyncLogNode == MOS_NULL)
    {
        pstSyncLogNode = (ST_CFG_LOG_SYNC_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_LOG_SYNC_NODE));
        MOS_LIST_ADDTAIL(&Config_Task_GetMng()->stLogServSyncList, pstSyncLogNode);
    }
    return pstSyncLogNode;
}

_INT Config_AddSyncLogCfgTask(_UC ucMsgType,_UC ucMsgId,_UI uiOgctId,_UC* pucBody,_UI uiMsgLen)
{
    ST_CFG_LOG_SYNC_NODE *pstSyncLogNode = Config_GetSyncLogNode();
    if(pstSyncLogNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstSyncLogNode->ucMsgType  = ucMsgType;
    pstSyncLogNode->ucMsgId    = ucMsgId;
    pstSyncLogNode->uiOgctId   = uiOgctId;
    pstSyncLogNode->pucMsgBuff = pucBody;
    pstSyncLogNode->uiMsgLen   = uiMsgLen;
    pstSyncLogNode->ucStatus   = EN_SERVER_NODE_START;
    return MOS_OK;
}

ST_CFG_LOG_SYNC_NODE *Config_FindSyncLogNodeById(_UI uiOgctId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_LOG_SYNC_NODE *pstSyncLogNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stLogServSyncList, pstSyncLogNode, stIterator)
    {
        if(pstSyncLogNode->ucStatus && uiOgctId == pstSyncLogNode->uiOgctId)
        {
            break;
        }
    }
    return pstSyncLogNode;
}

_VOID Config_ProcSyncLogStatus(_UI uiNowTime)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_LOG_SYNC_NODE *pstSyncLogNode    = MOS_NULL;
    _UC *pStrTmp                            = MOS_NULL;
    //_UC *pucHttpBody                        = MOS_NULL;
    _INT iOutLen        = 0;
    _INT iEncodeLen     = 0;
    _UI uiRspLen        = 0;
    _US usPort          = 9001;
    _UC ucResult        = 0;
    _INT iRet           = 0;
    _UI uiHttpHandle    = 0;
    ST_MOS_SYS_TIME stSysTime;
    _UC aucSignAddr[256] = {0};
    _UC aucSignIP[MOS_INET_IPV6_STR_SIZE];
    _UC aucUrlPath[CFG_STRING_COMMONLEN];
    _UC aucCryptoKey[ITRD_CRPTO_KEY_LEN];
    _UC aucEncodeBody[CFG_STRING_MAXLEN];
    _UC aucOutPut[CFG_STRING_MAXLEN];

    MOS_MEMSET(aucEncodeBody,0,CFG_STRING_MAXLEN);
    MOS_MEMSET(aucOutPut,0,CFG_STRING_MAXLEN);
    MOS_MEMSET(aucSignIP,0,MOS_INET_IPV6_STR_SIZE);
    MOS_MEMSET(aucUrlPath,0,CFG_STRING_COMMONLEN);
    MOS_MEMSET(aucCryptoKey,0,ITRD_CRPTO_KEY_LEN);

    MOS_STRCPY(aucCryptoKey,"x\%73g407");
    //uiHttpHandle = TrasBase_GetBase()->uiHttpHandle;
    MOS_MEMSET(aucSignAddr, 0, MOS_INET_IPV6_STR_SIZE);
	MOS_MEMSET(aucSignIP, 0, MOS_INET_IPV6_STR_SIZE);
    MOS_STRNCPY(aucSignIP,"180.100.133.131",sizeof(aucSignIP));
    MOS_STRNCPY(aucSignAddr,"180.100.133.131",sizeof(aucSignAddr));
    Mos_GetSysTime(&stSysTime);
    MOS_VSNPRINTF(aucUrlPath,64,"/log?v=1.0&t=%04u%02u%02u%02u%02u%02u407",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stLogServSyncList, pstSyncLogNode, stIterator)
    {
        if(pstSyncLogNode->ucStatus == 0)
        {
            MOS_LOG_ERR(LOG_MODULE, "LogNode Is Null");
            continue;
        }
        else if(pstSyncLogNode->ucStatus == 1)
        {
			uiHttpHandle = Http_HttpCreateSyncHandleID();
            iOutLen = Adpt_Des_Ecb_Encrypt(aucCryptoKey, pstSyncLogNode->pucMsgBuff, pstSyncLogNode->uiMsgLen, aucOutPut);
            Adpt_Base64_Enc(aucEncodeBody,iOutLen,aucOutPut);
            iEncodeLen = MOS_STRLEN(aucOutPut);
            MOS_LOG_INF(LOG_MODULE, "Log Body :%s Has Been Encodeed", aucEncodeBody);
            #if 0
            iRet = Http_Httpsclient_SendSyncPostRequest(uiHttpHandle,aucSignIP,usPort,aucSignAddr,
                 aucSysTime,pucHttpBody,MOS_STRLEN(pucHttpBody),30,&pStrTmp,&uiRspLen,&ucResult,MOS_NULL);
            #else     
            iRet = Http_Httpclient_SendSyncPostRequest(uiHttpHandle,aucSignIP,usPort,MOS_NULL,
                    aucUrlPath,aucEncodeBody,iEncodeLen,30,&pStrTmp,&uiRspLen,&ucResult,MOS_NULL);
            #endif

            MOS_LOG_INF(CFG_LOGSTR,"send log to ipAddr %s ,port %u, ret %d ,RspLen %d, rsp %s",aucSignIP, usPort, iRet, uiRspLen, pStrTmp);
            if(iRet < 0)
            {   
                pstSyncLogNode->ucStatus = 2;
                pstSyncLogNode->uiReqTime = uiNowTime;
                continue;   //发送失败内部循环不做重发处理,只置位；
            }
            else if(uiRspLen)
            {
                Config_ParseLogJson(pStrTmp);
                pstSyncLogNode->ucStatus = 3;
            }
        }
        else if(pstSyncLogNode->ucStatus == 2 && (_UI)(uiNowTime - pstSyncLogNode->uiReqTime) > 10)
        {
            pstSyncLogNode->ucStatus = 1;
        }
        else if(pstSyncLogNode->ucStatus == 3)
        {
            MOS_LOG_INF(LOG_MODULE, "LogBuf Send Success!");
            pstSyncLogNode->ucStatus = 0;
        }
    }
    MOS_FREE(pStrTmp);
    return;    
}
#endif

/**********************************************************************************
                            和服务器之间的 同步
**********************************************************************************/
static ST_CFG_SERVER_NODE *Config_GetSyncServNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_SERVER_NODE *pstSyncServNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stServSyncList, pstSyncServNode, stIterator)
    {
        if(pstSyncServNode->ucStatus == EN_SERVER_NODE_NONE)
        {
            break;
        }
    }
    if(pstSyncServNode == MOS_NULL)
    {
        pstSyncServNode = (ST_CFG_SERVER_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_SERVER_NODE));
        MOS_LIST_ADDTAIL(&Config_Task_GetMng()->stServSyncList, pstSyncServNode);
    }
    pstSyncServNode->uiOgctId = 0;
    return pstSyncServNode;
}

_INT Config_AddSyncServerCfgTask(_UC ucMsgType,_UC ucMsgId,_UI uiCfgItem,_VPTR hRoot)
{
    MOS_PARAM_NULL_RETERR(hRoot);

    ST_CFG_SERVER_NODE *pstSyncServNode = Config_GetSyncServNode();
    if(pstSyncServNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstSyncServNode->uiCfgItem  = uiCfgItem;
    pstSyncServNode->ucMsgType  = ucMsgType;
    pstSyncServNode->ucMsgId    = ucMsgId;
    pstSyncServNode->hJsonRoot  = hRoot;
    pstSyncServNode->ucStatus   = EN_SERVER_NODE_START;

    return MOS_OK;
}

ST_CFG_SERVER_NODE *Config_FindSyncServNodeById(_UI uiOgctId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_SERVER_NODE *pstSyncServNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stServSyncList, pstSyncServNode, stIterator)
    {
        if(pstSyncServNode->ucStatus && uiOgctId == pstSyncServNode->uiOgctId)
        {
            break;
        }
    }
    return pstSyncServNode;
}

static _INT Config_RecvServerRspData(_UI uiOgctId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT iCode = 0;
    ST_CFG_SERVER_NODE *pstSyncServNode = Config_FindSyncServNodeById(uiOgctId);
    JSON_HANDLE hRoot = MOS_NULL;
    if(pstSyncServNode == MOS_NULL)
    {
        return MOS_OK;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"),&iCode);
    if(iCode == 0)
    {
        if(pstSyncServNode->ucMsgId + 1 == EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD_RSP )
        {
            Config_SetAbilityUpLoadFlag(2);
        }
        else if(pstSyncServNode->ucMsgId + 1 == EN_OGCT_CFGBUSS_DEVBUSS_UPLOAD_RSP)
        {
            Config_SetConfigUpLoadFlag(2);
        }
        else if(pstSyncServNode->ucMsgId + 1 == EN_OGCT_CFGBUSS_DEVBUSS_UPDATE_RSP)
        {
            if((pstSyncServNode->uiCfgItem&EN_ZJ_CFG_ITEM_DEVICE ) > 0)
            {
                if(Config_GetItemSign()->ucCfgDevUpdate == 2)
                {
                    Config_GetItemSign()->ucCfgDevUpdate = 0;
                    Config_GetItemSign()->ucSaveCore     = 1;
                }
                
            }
            else if((pstSyncServNode->uiCfgItem&EN_ZJ_CFG_ITEM_CAMERA) > 0)
            {
                if(Config_GetItemSign()->ucCfgCamUpdate == 2)
                {
                    Config_GetItemSign()->ucCfgCamUpdate = 0;
                    Config_GetItemSign()->ucSaveCore     = 1;
                }
                
            }
            else if((pstSyncServNode->uiCfgItem&EN_ZJ_CFG_ITEM_TIMEPOLICY) > 0)
            {
                if(Config_GetItemSign()->ucCfgTimePolicyUpdate == 2)
                {
                    Config_GetItemSign()->ucCfgTimePolicyUpdate = 0;
                    Config_GetItemSign()->ucSaveCore     = 1;
                }
            }
            else if((pstSyncServNode->uiCfgItem&EN_ZJ_CFG_ITEM_ALARMPOLICY) > 0)
            {
                if(Config_GetItemSign()->ucAlarmPolicyUpdate == 2)
                {
                    Config_GetItemSign()->ucAlarmPolicyUpdate = 0;
                    Config_GetItemSign()->ucSaveCore     = 1;
                }
            }
        }
    }
    else
    {
        if (pstSyncServNode->ucMsgId + 1 == EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD_RSP )
        {
            Config_SetAbilityUpLoadFlag(0);
            if (Config_Task_GetMng()->uiDevAbilityUploadRetry < 1) 
            {
                Config_Task_GetMng()->uiDevAbilityUploadRetry++;
				
                hRoot = Config_BuildLocalAbilityJson(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD);
                Config_AddSyncServerCfgTask(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD,0,hRoot);
                Config_GetCoreMng()->ucAbilityUpFlag = 1;
            }
        }
        else if (pstSyncServNode->ucMsgId + 1 == EN_OGCT_CFGBUSS_DEVBUSS_UPLOAD_RSP)
        {
            Config_SetConfigUpLoadFlag(0);
            if (Config_Task_GetMng()->uiDevBussUploadRetry < 1)
            {
                Config_Task_GetMng()->uiDevBussUploadRetry++;
                hRoot = Config_BuildLocalBussJson(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_UPLOAD,EN_ZJ_CFG_ITEM_ALL);  
                Config_AddSyncServerCfgTask(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_UPLOAD,0,hRoot);
                Config_GetCoreMng()->ucBussUpFlag = 1;
            }
        }
    }
    MOS_LOG_INF(CFG_LOGSTR,"ogct %u recv response code %d",uiOgctId,iCode);
    pstSyncServNode->ucStatus = EN_SERVER_NODE_FINISH;
    return MOS_OK;
}

_VOID Config_ProcSyncServStatus(_UI uiNowTime)
{
    _INT iRet = 0;
    _UC *pucStrTmp = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_SERVER_NODE *pstSyncNode = MOS_NULL;

    if(Config_Task_GetMng()->ucOnlineStatus != 1)
    {
        return ;
    }
    
    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stServSyncList, pstSyncNode, stIterator)
    {
        if(pstSyncNode->ucStatus == EN_SERVER_NODE_NONE)
        {
            continue;
        }
        if(pstSyncNode->ucStatus == EN_SERVER_NODE_START)
        {
            pstSyncNode->uiReqTime = uiNowTime;
            pstSyncNode->uiOgctId  = Mos_GetSessionId();
            Adpt_Json_DeleteItemFromObject(pstSyncNode->hJsonRoot,(_UC*)"SEQID");
            Adpt_Json_AddItemToObject(pstSyncNode->hJsonRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(pstSyncNode->uiOgctId));
            pucStrTmp = Adpt_Json_Print(pstSyncNode->hJsonRoot);

            iRet = MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID,pstSyncNode->uiOgctId,pstSyncNode->ucMsgType,pstSyncNode->ucMsgId,
                pucStrTmp,MOS_STRLEN(pucStrTmp),Config_RecvServerRspData);
            if(MOS_OK != iRet)
            {
                // 发送失败时释放该节点Json内存
                Adpt_Json_Delete(pstSyncNode->hJsonRoot);
                pstSyncNode->hJsonRoot = MOS_NULL;
                pstSyncNode->uiOgctId  = 0;
                pstSyncNode->ucStatus  = EN_SERVER_NODE_NONE;
            }
            else
            {
                pstSyncNode->ucStatus  = EN_SERVER_NODE_PROC;
                MOS_LOG_INF(CFG_LOGSTR,"ogctid %u start send %s requst, ret %d",pstSyncNode->uiOgctId,pucStrTmp,iRet);
                // MOS_PRINTF("ogctid %u start send %s requst, ret %d",pstSyncNode->uiOgctId,pucStrTmp,iRet);
            }

            MOS_FREE(pucStrTmp);
        }
        else if(pstSyncNode->ucStatus == EN_SERVER_NODE_PROC && uiNowTime - pstSyncNode->uiReqTime > 60)
        {
            pstSyncNode->ucStatus = EN_SERVER_NODE_START;
        }
        else if(pstSyncNode->ucStatus == EN_SERVER_NODE_FINISH)
        {
            MOS_LOG_INF(CFG_LOGSTR,"ogctid %u proc end",pstSyncNode->uiOgctId);
            Adpt_Json_Delete(pstSyncNode->hJsonRoot);
            pstSyncNode->hJsonRoot = MOS_NULL;
            pstSyncNode->uiOgctId = 0;
            pstSyncNode->ucStatus = EN_SERVER_NODE_NONE;
        }
    }
    return ;
}
/**********************************************************************************
                            和client之间的 同步
**********************************************************************************/
ST_CFG_SYNC_NODE *Config_AllocSyncClientNode()
{
    ST_CFG_SYNC_NODE *pstSyncnode = MOS_NULL;
    if(MOS_LIST_GETCOUNT(&Config_Task_GetMng()->stSyncPoolList) > 0)
    {
        Mos_MutexLock(&Config_Task_GetMng()->hMutex);
        pstSyncnode =  MOS_LIST_RMVHEAD(&Config_Task_GetMng()->stSyncPoolList);
        Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    }
    if(pstSyncnode == MOS_NULL)
    {
        pstSyncnode = (ST_CFG_SYNC_NODE*)MOS_MALLOC(sizeof(ST_CFG_SYNC_NODE));
    }
    if(pstSyncnode)
    {
        MOS_MEMSET(pstSyncnode,0,sizeof(ST_CFG_SYNC_NODE));
    }
    return pstSyncnode;
}

_INT Config_AddSyncClientNode(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_UI uiOgctId,_UC *pucBody,_UI uiMsgLen)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pucBody);

    ST_CFG_SYNC_NODE *pstSyncNode = Config_AllocSyncClientNode();
    if(pstSyncNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstSyncNode->ucStatus   = 1;
    pstSyncNode->ucMsgType  = ucMsgType;
    pstSyncNode->ucMsgId    = ucMsgId;
    pstSyncNode->uiOgctId   = uiOgctId;
    pstSyncNode->uiMsgLen   = uiMsgLen;
    pstSyncNode->pucMsgBuff = pucBody;
    pstSyncNode->ucTryCount = 0;
    MOS_STRNCPY(pstSyncNode->aucPeerId,pucPeerId,sizeof(pstSyncNode->aucPeerId));

    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    MOS_LIST_ADDTAIL(&Config_Task_GetMng()->stSyncList,pstSyncNode);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    return MOS_OK;
} 

_VOID Config_ProcSyncClientList(_UI uiNowTime)
{
    _INT iRet = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_SYNC_NODE *pstSyncNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stSyncList, pstSyncNode, stIterator)
    {
        if(pstSyncNode->ucStatus == 1)
        {
            iRet = MsgMng_SendMsg(pstSyncNode->aucPeerId,pstSyncNode->uiOgctId,pstSyncNode->ucMsgType,pstSyncNode->ucMsgId,
                pstSyncNode->pucMsgBuff,pstSyncNode->uiMsgLen,MOS_NULL);
            MOS_LOG_INF(CFG_LOGSTR,"reqid %u send msg %s to peer %s ret %d try count %u",
                pstSyncNode->uiOgctId,pstSyncNode->pucMsgBuff,pstSyncNode->aucPeerId,iRet,pstSyncNode->ucTryCount);
            if(iRet != MOS_OK)    
            {
                pstSyncNode->ucTryCount++;
                if(pstSyncNode->ucTryCount >= 3)
                {
                    pstSyncNode->ucStatus = 3;
                    continue;
                }
                else
                {
                    pstSyncNode->ucStatus = 2;
                    pstSyncNode->uiReqTime = uiNowTime;   
                    continue;
                }
            }
            pstSyncNode->ucStatus = 3;
        }
        else if(pstSyncNode->ucStatus == 2 && uiNowTime - pstSyncNode->uiReqTime >= 5)
        {
            pstSyncNode->ucStatus = 1;
        }
        else if(pstSyncNode->ucStatus == 3)
        {
            pstSyncNode->ucStatus = 0;
            pstSyncNode->ucTryCount = 0;
            MOS_FREE(pstSyncNode->pucMsgBuff);
            Mos_MutexLock(&Config_Task_GetMng()->hMutex);
            MOS_LIST_RMVNODE(&Config_Task_GetMng()->stSyncList, pstSyncNode);
            MOS_LIST_ADDTAIL(&Config_Task_GetMng()->stSyncPoolList,pstSyncNode);
            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
        }
    }
    return;
}
