#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "cloudstg_api.h"

/************************************************************
***************************************************************/
ST_CFG_CAMERA_MNG *Config_GetCamaraMng()
{
    return &Config_GetlocalCfgInf()->stCameraMng;
}

_INT Config_InitCamerMng()
{
    Config_GetCamaraMng()->uiStreamCnt                  = 2;
    Config_GetCamaraMng()->uiVoicePlayAbility           = 1;
    Config_GetCamaraMng()->uiMicPhoneAbility            = 1;
    Config_GetCamaraMng()->uiInversionAbility           = 1;
    Config_GetCamaraMng()->uiIrLedAbility               = 1;
    Config_GetCamaraMng()->uiStorageAbility             = 1;
    Config_GetCamaraMng()->uiCamOpenFlag                = 1;
    Config_GetCamaraMng()->uiMicOpenFlag                = 1;
    Config_GetCamaraMng()->uiSpkOpenFlag                = 0; 
    Config_GetCamaraMng()->uiCamDataInputMode           = 0;
    Config_GetCamaraMng()->uiCurInversionType           = EN_ZJ_ROTATE_TYPE_VERTICAL_UP;
    Config_GetCamaraMng()->uiCurIRWorkMode              = EN_ZJ_IRMODE_IR;
    Config_GetCamaraMng()->uiCurScanFrequery            = 0;
    Config_GetCamaraMng()->uiStorageStatus              = 0;
    Config_GetCamaraMng()->uiCurMicVolume               = 5;
    Config_GetCamaraMng()->uiOSDCustomSwitch            = 0;
    Config_GetCamaraMng()->uiOSDCommonSwitch            = 1;
    Config_GetCamaraMng()->uiOSDCommonPosition          = 0;
    Config_GetCamaraMng()->uiOSDCommonFormat            = 0;
    Config_GetCamaraMng()->uiOSDPostion                 = 0;
    Config_GetCamaraMng()->uiGAT1400Switch              = 1;
    Config_GetCamaraMng()->uiGAT1400UploadInterval      = 5;
    Config_GetCamaraMng()->uiGAT1400Ability             = 0;
    Config_GetCamaraMng()->uiIPv6Ability                = 0;
    Config_GetCamaraMng()->uiInterGAT1400Ability        = 0;
    Config_GetCamaraMng()->uiP2PAbility                 = 0;
    Config_GetCamaraMng()->uiExternalSpeakerAbility     = 0;
    Config_GetCamaraMng()->uiZoomAbility                = 0;
    Config_GetCamaraMng()->uiFocusAbility               = 0;
    Config_GetCamaraMng()->uiQualityProbeAbility        = 0;
    Config_GetCamaraMng()->uiCloudBroadcastAbility      = 0;
    Config_GetCamaraMng()->uiSliceCloudAbility          = 0;
    Config_GetCamaraMng()->uiStsCloudAbility            = 0;
    Config_GetCamaraMng()->uiAISwitchReturnErrAbility   = 0;
    Config_GetCamaraMng()->uiPolicyDomainAbility        = 0;
    Config_GetCamaraMng()->uiIMSAbility                 = 0;
    Config_GetCamaraMng()->uiSuperCodesAbility          = 0;
    Config_GetCamaraMng()->uiSuperCodesStatus           = 1; // 超级编码默认打开
    Config_GetCamaraMng()->uiIPv6Switch                 = 1;
    Config_GetCamaraMng()->uiMsgConnectNetType          = 0;

	Config_GetCamaraMng()->uiPhysicalMaskAbility        = 0;
	Config_GetCamaraMng()->uiSilenceRestartAbility      = 1; // 静默重启播放能力 SDK默认支持
	Config_GetCamaraMng()->uiAlarmSoundRemoteAbility    = 1; // 支持远程触发播放能力(支持3468-播放指定警报音的信令下发) SDK默认支持

    Config_GetCamaraMng()->uiWithScreenAbility          = 0;
	Config_GetCamaraMng()->uiVideoPlayAbility           = 0;
    Config_GetCamaraMng()->uiCallButtonAbility          = 0;
    Config_GetCamaraMng()->uiHangUpButtonAbility        = 0;

    /*事件云存追加参数初始化，默认打开*/
    Config_GetCamaraMng()->iEventCloudSwitch            = CLOUD_EVENTCLOUD_SWITCH_DEFAULT;
    Config_GetCamaraMng()->iEventCloudMaxTime           = CLOUD_EVENTCLOUD_RANGE_MAXTIME_DEFAUL;
    Config_GetCamaraMng()->iEventCloudMinTime           = CLOUD_EVENTCLOUD_RANGE_MINTIME_DEFAUL;
    Config_GetCamaraMng()->iEventCloudDetectTime        = CLOUD_EVENTCLOUD_RANGE_DETECTTIME_DEFAUL;
    Config_GetCamaraMng()->iEventCloudAppendTime        = CLOUD_EVENTCLOUD_RANGE_APPENDTIME_DEFAUL;

    if (STR_SDK_VERSION >= 0x04030000)
    {
        Config_GetCamaraMng()->uiInterGAT1400Ability        = 1;
        Config_GetCamaraMng()->uiQualityProbeAbility        = 1;
    }

    if (STR_SDK_VERSION >= 0x04030100)
    {
        Config_GetCamaraMng()->uiP2PAbility                 = 1;
        // Config_GetCamaraMng()->uiSliceCloudAbility       = 1;
    }

#ifdef SUPPORT_POLICYDOMAIN
    if (STR_SDK_VERSION >= 0x04030401)
    {
        Config_GetCamaraMng()->uiPolicyDomainAbility        = 1;
    }
#endif

    // TEST: 暂时关闭
    // if (STR_SDK_VERSION >= 0x04050100)
    // {
    //     Config_GetCamaraMng()->uiStsCloudAbility         = 1;
    // }
#ifdef VIDEO_INPUT_FLAG
    Config_GetCamaraMng()->uiCamDataInputMode               = 1;
#endif 

    MOS_MEMSET(Config_GetCamaraMng()->ucOSDName,        0, sizeof(Config_GetCamaraMng()->ucOSDName));
    MOS_MEMSET(Config_GetCamaraMng()->ucGAT1400ID,      0, sizeof(Config_GetCamaraMng()->ucGAT1400ID));
    MOS_MEMSET(Config_GetCamaraMng()->ucGAT1400Domain,  0, sizeof(Config_GetCamaraMng()->ucGAT1400Domain));
    MOS_MEMSET(&Config_GetCamaraMng()->stSensors,       0, sizeof(ST_CFG_SERSORS));

    Mos_MutexCreate(&Config_GetCamaraMng()->hGAT1400Mutex);
    Mos_MutexCreate(&Config_GetCamaraMng()->hUploadDevStatusMutex);

    MOS_LOG_INF(CFG_LOGSTR,"camera Init ok, P2PAbility:%u InterGAT1400Ability:%u", Config_GetCamaraMng()->uiP2PAbility, Config_GetCamaraMng()->uiInterGAT1400Ability);
    return MOS_OK;
}

ST_CFG_STREAMER_NODE *Config_GetStreamerNode(_INT iCamid,_UI uiStreamid)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_STREAMER_NODE *pstStreamerNode = MOS_NULL;
    ST_CFG_LEN_NODE *pstLenNode = MOS_NULL;
    if(iCamid != 0 || uiStreamid >= Config_GetCamaraMng()->uiStreamCnt)
    {
        return MOS_NULL;
    }
    pstLenNode = Config_GetCurLenNode();
    FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stStreamerList, pstStreamerNode, stIterator)
    {
        if( pstStreamerNode->uiStreamId == uiStreamid)
        {
            if(pstLenNode)
                pstStreamerNode->stVideoDes.uiLensType = pstLenNode->iLenType;
            return pstStreamerNode;
        }
    }
    pstStreamerNode = (ST_CFG_STREAMER_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_STREAMER_NODE));
    if(pstStreamerNode)
    {
        pstStreamerNode->uiStreamId = uiStreamid;
        if(pstLenNode)
            pstStreamerNode->stVideoDes.uiLensType = pstLenNode->iLenType;
        MOS_LIST_ADDTAIL(&Config_GetCamaraMng()->stStreamerList, pstStreamerNode);
    }
    return pstStreamerNode;
}

ST_CFG_VIDEODES *Config_GetVideoDes(_INT iCamid, _INT iStreamid)
{
    ST_CFG_STREAMER_NODE *pstStreamerNode = Config_GetStreamerNode(iCamid,iStreamid);
    if(pstStreamerNode == MOS_NULL)
    {
        return MOS_NULL;
    }
    return &pstStreamerNode->stVideoDes;
}
/*********************************************************************************
*********************************************************************************/
int Config_SetLensMaxCount(_INT iLensCount)
{
    if(Config_GetCamaraMng()->stSensors.usLenMaxCount == iLensCount)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->stSensors.usLenMaxCount = iLensCount;
    Config_GetItemSign()->ucSaveCamInf    = 1;
    return MOS_OK;
}

int Config_SetLensInf(_INT iLenId,_UC *pucLenName,EN_ZJ_CAMERA_LENS_TYPE enLensType,_DOUBLE focalLenth)
{
    MOS_PARAM_NULL_RETERR(pucLenName);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_LEN_NODE *pstLenNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stSensors.stLensList, pstLenNode, stIterator)
    {
        if(pstLenNode->iLenId == iLenId)
        {
            break;
        }
    }
    if(pstLenNode == MOS_NULL)
    {
        pstLenNode = (ST_CFG_LEN_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_LEN_NODE));
        pstLenNode->iLenId = iLenId;
        MOS_LIST_ADDTAIL(&Config_GetCamaraMng()->stSensors.stLensList, pstLenNode);
    }
    pstLenNode->iLenType = enLensType;
    pstLenNode->focalLenth = focalLenth;
    MOS_STRNCPY(pstLenNode->aucLenName, pucLenName, sizeof(pstLenNode->aucLenName));
    Config_GetItemSign()->ucSaveCamInf    = 1;
    return MOS_OK;
}

ST_CFG_LEN_NODE *Config_GetCurLenNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_LEN_NODE *pstLenNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stSensors.stLensList, pstLenNode, stIterator)
    {
        if(pstLenNode->iLenId == Config_GetCamaraMng()->stSensors.usCurLenId)
        {
            break;
        }
    }
    return pstLenNode;
}

_INT Config_SetEnableLenId(_INT iEnableLenId)
{
    if( Config_GetCamaraMng()->stSensors.usCurLenId == iEnableLenId || iEnableLenId >= Config_GetCamaraMng()->stSensors.usLenMaxCount)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->stSensors.usCurLenId = iEnableLenId;
    Config_GetItemSign()->ucSaveCamInf    = 1;
    Config_GetItemSign()->ucCfgCamUpdate  = 1;
    return MOS_OK;
}

_INT Config_SetDefaultLenId(_INT iDefaultLenId, _INT iAutoFlag)
{
    if( (Config_GetCamaraMng()->stSensors.usDefaultLenId == iDefaultLenId && Config_GetCamaraMng()->stSensors.usAutoFlag == iAutoFlag) || iDefaultLenId >= Config_GetCamaraMng()->stSensors.usLenMaxCount)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->stSensors.usDefaultLenId = iDefaultLenId;
    Config_GetCamaraMng()->stSensors.usAutoFlag     = iAutoFlag;
    Config_GetItemSign()->ucSaveCamInf    = 1;
    Config_GetItemSign()->ucCfgCamUpdate  = 1;
    return MOS_OK;
}

_INT Config_SetCameraStreamCount(_INT iCamIndex,_UI uiStreamCnt)
{
    if(Config_GetCamaraMng()->uiStreamCnt == uiStreamCnt)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiStreamCnt    = uiStreamCnt;
    Config_GetItemSign()->ucSaveCamInf    = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d streamer count %u",iCamIndex,uiStreamCnt);
    return MOS_OK;
}

_INT Config_SetCameraVoicePlayAbility(_INT iCamId,_UI uiVoicePlayAbility)
{
    if(Config_GetCamaraMng()->uiVoicePlayAbility == uiVoicePlayAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiVoicePlayAbility = uiVoicePlayAbility;
    Config_GetItemSign()->ucSaveCamInf        = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d voiceplayability %u",iCamId,uiVoicePlayAbility);
    return MOS_OK;
}

_INT Config_SetCameraCloudBroadCastAbility(_INT iCamId,_UI uiCloudBroadcastAbility)
{
    if(Config_GetCamaraMng()->uiCloudBroadcastAbility == uiCloudBroadcastAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiCloudBroadcastAbility = uiCloudBroadcastAbility;
    Config_GetItemSign()->ucSaveCamInf        = 1;
    Config_GetCoreMng()->ucAbilityUpFlag      = 0;
    Config_GetItemSign()->ucSaveCore          = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d uiCloudBroadcastAbility %u",iCamId,uiCloudBroadcastAbility);
    return MOS_OK;
}

_INT Config_SetCameraMicPhoneAbility(_INT iCamId,_UI uiMicPhoneAbility)
{
    if(Config_GetCamaraMng()->uiMicPhoneAbility == uiMicPhoneAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiMicPhoneAbility = uiMicPhoneAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d micphone %u",iCamId,uiMicPhoneAbility);
    return MOS_OK;
}

_INT Config_SetCameraOSDAbility(_INT iCamId,_UI uiOSDSetAbility)
{
    if(Config_GetCamaraMng()->uiOSDSetAbility == uiOSDSetAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiOSDSetAbility = uiOSDSetAbility;
    Config_GetItemSign()->ucSaveCamInf     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set osd ability %u",iCamId,uiOSDSetAbility);
    return MOS_OK;
}

_INT Config_SetCameraOSDExpandAbility(_INT iCamId,_UI uiOSDSetExpandAbility)
{
    if(Config_GetCamaraMng()->uiOSDSetExpandAbility == uiOSDSetExpandAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiOSDSetExpandAbility = uiOSDSetExpandAbility;
    Config_GetItemSign()->ucSaveCamInf           = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set text osd expand ability %u",iCamId,uiOSDSetExpandAbility);
    return MOS_OK;
}

_INT Config_SetCameraOSDCommonSetAbility(_INT iCamId,_UI uiOSDCommonSetAbility)
{
    if(Config_GetCamaraMng()->uiOSDCommonSetAbility == uiOSDCommonSetAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiOSDCommonSetAbility = uiOSDCommonSetAbility;
    Config_GetItemSign()->ucSaveCamInf           = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set time osd commom ability %u",iCamId,uiOSDCommonSetAbility);
    return MOS_OK;
}

_INT Config_SetCameraIRLedAbility(_INT iCamId,_UI uiIrLedAbility)
{
    if(Config_GetCamaraMng()->uiIrLedAbility == uiIrLedAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiIrLedAbility = uiIrLedAbility;
    Config_GetItemSign()->ucSaveCamInf    = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set IRLED ability %u",iCamId,uiIrLedAbility);
    return MOS_OK;
}

_INT Config_SetCameraRotateAbility(_INT iCamId,_UI uiImageInversionAbility)
{
    if(Config_GetCamaraMng()->uiInversionAbility == uiImageInversionAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiInversionAbility = uiImageInversionAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set rotate ability %u",iCamId,uiImageInversionAbility);
    return MOS_OK;
}

_INT Config_SetCameraWdrAbility(_INT iCamId,_UI uiWDRAbility)
{
    if(Config_GetCamaraMng()->uiWDRAbility == uiWDRAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiWDRAbility = uiWDRAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set wdr ability %u",iCamId,uiWDRAbility);
    return MOS_OK;
}

_INT Config_SetCamerIPv6Switch(_INT iCamID, _UI uiIPv6Switch)
{
    if(Config_GetCamaraMng()->uiIPv6Switch == uiIPv6Switch)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiIPv6Switch = uiIPv6Switch;
    Config_GetItemSign()->ucSaveCamInf       = 1;
    Config_GetItemSign()->ucCfgCamUpdate     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %u uiIPv6Switch %d", iCamID, uiIPv6Switch);
    return MOS_OK;
}

_INT Config_SetCamerMsgConnectNetType(_INT iCamID, _UI uiMsgConnectNetType)
{
    if(Config_GetCamaraMng()->uiMsgConnectNetType == uiMsgConnectNetType)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiMsgConnectNetType = uiMsgConnectNetType;
    Config_GetItemSign()->ucSaveCamInf       = 1;
    Config_GetItemSign()->ucCfgCamUpdate     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %u uiMsgConnectNetType %d", iCamID, uiMsgConnectNetType);
    return MOS_OK;
}

_INT Config_SetIPv6Ability(_INT iCamId, _UI uiIPv6Ability)
{
    if(Config_GetCamaraMng()->uiIPv6Ability == uiIPv6Ability)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiIPv6Ability = uiIPv6Ability;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %u set ipv6 ability %u",iCamId,uiIPv6Ability);
    return MOS_OK;
}

_INT Config_SetCameraIMSAbility(_INT iCamId,_UI uiIMSAbility)
{
    if(Config_GetCamaraMng()->uiIMSAbility == uiIMSAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiIMSAbility = uiIMSAbility;
    Config_GetItemSign()->ucSaveCamInf  = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %u set IMS ability %u",iCamId,uiIMSAbility);
    return MOS_OK;
}

_INT Config_SetCameraP2pAbility(_INT iCamId,_UI uiP2pAbility)
{
    if(Config_GetCamaraMng()->uiP2PAbility == uiP2pAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiP2PAbility = uiP2pAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set P2P ability %u",iCamId, uiP2pAbility);
    return MOS_OK;
}

_INT Config_SetCameraPolicyDomainAbility(_INT iCamId,_UI uiPolicyDomainAbility)
{
#ifdef SUPPORT_POLICYDOMAIN
    if(Config_GetCamaraMng()->uiPolicyDomainAbility == uiPolicyDomainAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiPolicyDomainAbility = uiPolicyDomainAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
#else
    Config_GetCamaraMng()->uiPolicyDomainAbility = 0;
    Config_GetItemSign()->ucSaveCamInf = 1;
#endif
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set PolicyDomain ability %u",iCamId, uiPolicyDomainAbility);
    return MOS_OK;
}

_INT Config_SetCameraPhysicalMaskAbility(_INT iCamId, _UI uiPhysicalMaskAbility)
{
    if(Config_GetCamaraMng()->uiPhysicalMaskAbility == uiPhysicalMaskAbility)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiPhysicalMaskAbility = uiPhysicalMaskAbility;
    Config_GetItemSign()->ucSaveCamInf           = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set PhysicalMaskAbility %u", iCamId, uiPhysicalMaskAbility);

    return MOS_OK;
}

_INT Config_SetCameraAlarmSoundExecuteTimeAbility(_INT iCamId, _UI uiAlarmSoundExecuteTimeAbility)
{
    if(Config_GetCamaraMng()->uiAlarmSoundExecuteTimeAbility == uiAlarmSoundExecuteTimeAbility)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiAlarmSoundExecuteTimeAbility = uiAlarmSoundExecuteTimeAbility;
    Config_GetItemSign()->ucSaveCamInf           = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set AlarmSoundExecuteTimeAbility %u", iCamId, uiAlarmSoundExecuteTimeAbility);

    return MOS_OK;
}

_INT Config_SetCameraSuperCodesAbility(_INT iCamId, _UI uiSuperCodesAbility)
{
    if(Config_GetCamaraMng()->uiSuperCodesAbility == uiSuperCodesAbility)
    {
        return MOS_OK;
    }
	
    Config_GetCamaraMng()->uiSuperCodesAbility = uiSuperCodesAbility;
    Config_GetItemSign()->ucSaveCamInf         = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set SuperCodes ability %u", iCamId, uiSuperCodesAbility);
	
    return MOS_OK;
}

_INT Config_SetCameraSuperCodesStatus(_INT iCamID, _UI uiSuperCodesStatus)
{
    if(Config_GetCamaraMng()->uiSuperCodesStatus == uiSuperCodesStatus)
    {
        return MOS_OK;
    }
	
    Config_GetCamaraMng()->uiSuperCodesStatus = uiSuperCodesStatus;
    Config_GetItemSign()->ucSaveCamInf        = 1;
    Config_GetItemSign()->ucCfgCamUpdate      = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d SuperCodesStatus %u", iCamID, uiSuperCodesStatus);
	
    return MOS_OK;
}

_INT Config_SetCameraExternalSpeakerAbility(_INT iCamId, _UI uiExternalSpeakerAbility)
{
    if(Config_GetCamaraMng()->uiExternalSpeakerAbility == uiExternalSpeakerAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiExternalSpeakerAbility = uiExternalSpeakerAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set ExternalSpeaker ability %u",iCamId, uiExternalSpeakerAbility);
    return MOS_OK;
}
_INT Config_SetCameraZoomAbility(_INT iCamId,_UI uiZoomAbility)
{
    if(Config_GetCamaraMng()->uiZoomAbility == uiZoomAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiZoomAbility = uiZoomAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %u set zoom ability %u",iCamId, uiZoomAbility);
    return MOS_OK;
}

_INT Config_SetCameraFocusAbility(_INT iCamId,_UI uiFocusAbility)
{
    if(Config_GetCamaraMng()->uiFocusAbility == uiFocusAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiFocusAbility = uiFocusAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %u set focus ability %u",iCamId, uiFocusAbility);
    return MOS_OK;
}

_INT Config_SetCameraExternalSpeakerStatus(_INT iCamID, _UI uiConnectStatus, ST_ZJ_EXTERNAL_SPEAKER_INFO *pstInfo)
{
    _UI uiInfoUpdate = 0; 
    ST_ZJ_EXTERNAL_SPEAKER_INFO stInfo;
    MOS_MEMSET(&stInfo, 0, sizeof(ST_ZJ_EXTERNAL_SPEAKER_INFO));

    if(Config_GetCamaraMng()->uiExternalSpeakerStatus != uiConnectStatus)
    {
        Config_GetCamaraMng()->uiExternalSpeakerStatus = uiConnectStatus;
        Config_GetItemSign()->ucSaveCamInf             = 1;
        Config_GetItemSign()->ucCfgCamUpdate           = 1;

        MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d ExternalSpeakerStatus %u", iCamID, uiConnectStatus);
    }

    //pstInfo不为NULL表示有音柱信息,使用pstInfo处理音柱信息;否则表示无音柱信息,使用stInfo处理音柱信息。
    if(NULL != pstInfo)
    {
        MOS_MEMCPY(&stInfo, pstInfo, sizeof(ST_ZJ_EXTERNAL_SPEAKER_INFO));
    }

    if(0 != MOS_STRCMP(Config_GetCamaraMng()->stExternalSpeakerInfo.aucCTEI, stInfo.aucCTEI))
    {
        uiInfoUpdate = 1;
        MOS_STRLCPY(Config_GetCamaraMng()->stExternalSpeakerInfo.aucCTEI, stInfo.aucCTEI, sizeof(Config_GetCamaraMng()->stExternalSpeakerInfo.aucCTEI));
    }

    if(0 != MOS_STRCMP(Config_GetCamaraMng()->stExternalSpeakerInfo.aucFwVer, stInfo.aucFwVer))
    {
        uiInfoUpdate = 1;
        MOS_STRLCPY(Config_GetCamaraMng()->stExternalSpeakerInfo.aucFwVer, stInfo.aucFwVer, sizeof(Config_GetCamaraMng()->stExternalSpeakerInfo.aucFwVer));
    }

    if(0 != MOS_STRCMP(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevUID, stInfo.aucDevUID))
    {
        uiInfoUpdate = 1;
        MOS_STRLCPY(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevUID, stInfo.aucDevUID, sizeof(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevUID));
    }

    if(0 != MOS_STRCMP(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevSN, stInfo.aucDevSN))
    {
        uiInfoUpdate = 1;
        MOS_STRLCPY(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevSN, stInfo.aucDevSN, sizeof(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevSN));
    }

    if(1 == uiInfoUpdate)
    {
        Config_GetItemSign()->ucSaveCamInf   = 1;
        Config_GetItemSign()->ucCfgCamUpdate = 1;

        MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d external speaker info", iCamID);
    }

    return MOS_OK;
}

_INT Config_SetCameraWithScreenAbility(_INT iCamId, _UI uiWithScreenAbility)
{
    if(Config_GetCamaraMng()->uiWithScreenAbility == uiWithScreenAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiWithScreenAbility = uiWithScreenAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set WithScreenAbility ability %u",iCamId, uiWithScreenAbility);
    return MOS_OK;
}

_INT Config_SetCameraVideoPlayAbility(_INT iCamId, _UI uiVideoPlayAbility)
{
    Config_GetCamaraMng()->uiVideoPlayAbility = EN_ZJ_VIDEOPLAY_ABILITY_NONE;

    if (uiVideoPlayAbility == 1)
    {
        Config_GetCamaraMng()->uiVideoPlayAbility = EN_ZJ_VIDEOPLAY_ABILITY_P2P|EN_ZJ_VIDEOPLAY_ABILITY_IMS;
    }

    Config_GetItemSign()->ucSaveCamInf   = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set VideoPlayAbility ability %u",iCamId, uiVideoPlayAbility);
    return MOS_OK;
}

_INT Config_SetCameraCallButtonAbility(_INT iCamId, _UI uiCallButtonAbility)
{
    if(Config_GetCamaraMng()->uiCallButtonAbility == uiCallButtonAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiCallButtonAbility = uiCallButtonAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set CallButtonAbility ability %u",iCamId, uiCallButtonAbility);
    return MOS_OK;
}

_INT Config_SetCameraHangUpButtonAbility(_INT iCamId, _UI uiHangUpButtonAbility)
{
    if(Config_GetCamaraMng()->uiHangUpButtonAbility == uiHangUpButtonAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiHangUpButtonAbility = uiHangUpButtonAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set HangUpButtonAbility ability %u",iCamId, uiHangUpButtonAbility);
    return MOS_OK;
}

_INT Config_SetCameraVideoPlaySupportAbility(_INT iCamID, ST_ZJ_VIDEOPLAY_SUPPORT_INFO *pstVideoPlaySupportAbility)
{
    _UI uiAbilityUpdate = 0; 

    if(pstVideoPlaySupportAbility != MOS_NULL)
    {
        if (Config_GetCamaraMng()->stVideoPlaySupport.uiResolutionAbility != pstVideoPlaySupportAbility->uiResolutionAbility)
        {
            Config_GetCamaraMng()->stVideoPlaySupport.uiResolutionAbility = pstVideoPlaySupportAbility->uiResolutionAbility;
            uiAbilityUpdate = 1;
        }

        if (Config_GetCamaraMng()->stVideoPlaySupport.uiVideoEncAbility != pstVideoPlaySupportAbility->uiVideoEncAbility)
        {
            Config_GetCamaraMng()->stVideoPlaySupport.uiVideoEncAbility = pstVideoPlaySupportAbility->uiVideoEncAbility;
            uiAbilityUpdate = 1;
        } 

        if (Config_GetCamaraMng()->stVideoPlaySupport.uiMaxBitRate != pstVideoPlaySupportAbility->uiMaxBitRate)
        {
            Config_GetCamaraMng()->stVideoPlaySupport.uiMaxBitRate = pstVideoPlaySupportAbility->uiMaxBitRate;
            uiAbilityUpdate = 1;
        }
            
    }

    if(1 == uiAbilityUpdate)
    {
        Config_GetItemSign()->ucSaveCamInf   = 1;
        MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d VideoPlay Support Ability", iCamID);
    }

    return MOS_OK;
}

_INT Config_SetCameraScreenHardwareInfo(_INT iCamID, ST_ZJ_SCREEN_HARDWARE_INFO *pstScreenHardwareInf)
{
    _UI uiInfoUpdate = 0; 

    if(pstScreenHardwareInf != MOS_NULL)
    {
        if (Config_GetCamaraMng()->stScreenHardwareInf.dScreenSize != pstScreenHardwareInf->dScreenSize)
        {
            Config_GetCamaraMng()->stScreenHardwareInf.dScreenSize = pstScreenHardwareInf->dScreenSize;
            uiInfoUpdate = 1;
        }

        if (Config_GetCamaraMng()->stScreenHardwareInf.uiResolution != pstScreenHardwareInf->uiResolution)
        {
            Config_GetCamaraMng()->stScreenHardwareInf.uiResolution = pstScreenHardwareInf->uiResolution;
            uiInfoUpdate = 1;
        } 

        if (Config_GetCamaraMng()->stScreenHardwareInf.uiWidth != pstScreenHardwareInf->uiWidth)
        {
            Config_GetCamaraMng()->stScreenHardwareInf.uiWidth = pstScreenHardwareInf->uiWidth;
            uiInfoUpdate = 1;
        }

        if (Config_GetCamaraMng()->stScreenHardwareInf.uiHeight != pstScreenHardwareInf->uiHeight)
        {
            Config_GetCamaraMng()->stScreenHardwareInf.uiHeight = pstScreenHardwareInf->uiHeight;
            uiInfoUpdate = 1;
        }

        if (Config_GetCamaraMng()->stScreenHardwareInf.uiDpi != pstScreenHardwareInf->uiDpi)
        {
            Config_GetCamaraMng()->stScreenHardwareInf.uiDpi = pstScreenHardwareInf->uiDpi;
            uiInfoUpdate = 1;
        }

        if (Config_GetCamaraMng()->stScreenHardwareInf.uiSupportTouchFlag != pstScreenHardwareInf->uiSupportTouchFlag)
        {
            Config_GetCamaraMng()->stScreenHardwareInf.uiSupportTouchFlag = pstScreenHardwareInf->uiSupportTouchFlag;
            uiInfoUpdate = 1;
        }                
    }

    if(1 == uiInfoUpdate)
    {
        Config_GetItemSign()->ucSaveCamInf   = 1;
        Config_GetItemSign()->ucCfgCamUpdate = 1;

        MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d screen hardware info", iCamID);
    }

    return MOS_OK;
}

_INT Config_SetCameraVideoPlayInfo(_INT iCamID, ST_ZJ_VIDEO_PARAM *pstVideoPlayInf)
{
    if(pstVideoPlayInf != MOS_NULL)
    {
        if(MOS_MEMCMP(&Config_GetCamaraMng()->stVideoPlayInf, pstVideoPlayInf, sizeof(ST_ZJ_VIDEO_PARAM)) == 0)
        {
            return MOS_OK;
        }
        MOS_MEMCPY(&Config_GetCamaraMng()->stVideoPlayInf, pstVideoPlayInf, sizeof(ST_ZJ_VIDEO_PARAM));
        MOS_LOG_INF(CFG_LOGSTR,"set iCamID %d, biteRate %u, FrameRate %u resolution %u, gop:%u, enc:%u",iCamID,  pstVideoPlayInf->uiBitrate,
                    pstVideoPlayInf->uiFramerate, pstVideoPlayInf->uiResolution, pstVideoPlayInf->uiFrameInterval, pstVideoPlayInf->uiEncodeType);
        Config_GetItemSign()->ucSaveCamInf   = 1;
        Config_GetItemSign()->ucCfgCamUpdate = 1;
        return MOS_OK;              
    }

    return MOS_OK;
}

_INT Config_SetCameraQualityProbeAbility(_INT iCamId,_UI uiQualityProbeAbility)
{
    if(Config_GetCamaraMng()->uiQualityProbeAbility == uiQualityProbeAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiQualityProbeAbility = uiQualityProbeAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set uiQualityProbe ability %u",iCamId, uiQualityProbeAbility);
    return MOS_OK;
}

_INT Config_SetCameraCustomizeAlarmSoundAbility(_INT iCamId,_UI uiCustimizeAbility)
{
    if(Config_GetCamaraMng()->uiAlarmSoundSetAbility == uiCustimizeAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiAlarmSoundSetAbility = uiCustimizeAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set AlarmSoundSet ability %u",iCamId, uiCustimizeAbility);
    return MOS_OK;
}

_INT Config_SetCameraAISwitchReturnErrAbility(_INT iCamId,_UI uiReturnErrAbility)
{
    if(Config_GetCamaraMng()->uiAISwitchReturnErrAbility == uiReturnErrAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiAISwitchReturnErrAbility = uiReturnErrAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set AISwitchReturnErr ability %u",iCamId, uiReturnErrAbility);
    return MOS_OK;
}

_INT Config_SetCamerStorageAbility(_INT iCamID, _UI uiStorageAbility)
{
    if(Config_GetCamaraMng()->uiStorageAbility == uiStorageAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiStorageAbility   = uiStorageAbility;
    Config_GetItemSign()->ucSaveCamInf        = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d storageability %u ",iCamID,uiStorageAbility);
    return MOS_OK;
}

_INT Config_SetStreamCaptureAbility(_INT iCamId,_INT iStreamId,_UI uiCaptureAbility)
{
    ST_CFG_STREAMER_NODE *pstStreamerNode = Config_GetStreamerNode(iCamId,iStreamId) ;
    if(pstStreamerNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstStreamerNode->uiCapAbility == uiCaptureAbility)
    {
        return MOS_OK;
    }

    pstStreamerNode->uiCapAbility     = uiCaptureAbility;
    Config_GetItemSign()->ucSaveCamInf   = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d stream %d capture ability %u",iCamId,iStreamId,uiCaptureAbility);
    return MOS_OK;
}

_INT Config_SetStreamResolutionAbility(_INT iCamId,_INT iStreamId,_UI uiResolutionAbility)
{
    ST_CFG_STREAMER_NODE *pstStreamerNode = Config_GetStreamerNode(iCamId,iStreamId) ;
    if(pstStreamerNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstStreamerNode->uiResolutionAbility == uiResolutionAbility)
    {
        return MOS_OK;
    }
    pstStreamerNode->uiResolutionAbility = uiResolutionAbility;
    Config_GetItemSign()->ucSaveCamInf      = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d stream %d resolution ability %u",iCamId,iStreamId,uiResolutionAbility);
    return MOS_OK;
}

_INT Config_SetCameraMultiFocalLenthAbility(_UI uiMultiFocalLenthAbility)
{
    if(Config_GetCamaraMng()->uiMultiFocalLenthAbility == uiMultiFocalLenthAbility)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiMultiFocalLenthAbility = uiMultiFocalLenthAbility;
    Config_GetItemSign()->ucSaveCamInf        = 1;

    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set MultiFocalLenthAbility %u",uiMultiFocalLenthAbility);
    return MOS_OK;
}

_INT Config_SetCameraSilenceRestartAbility(_INT iCamId, _UI uiSilenceRestartAbility)
{
    if(Config_GetCamaraMng()->uiSilenceRestartAbility == uiSilenceRestartAbility)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiSilenceRestartAbility = uiSilenceRestartAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set SilenceRestartAbility %u", iCamId, uiSilenceRestartAbility);

    return MOS_OK;
}

_INT Config_SetCameraAlarmSoundRemoteAbility(_INT iCamId, _UI uiAlarmSoundRemoteAbility)
{
    if(Config_GetCamaraMng()->uiAlarmSoundRemoteAbility == uiAlarmSoundRemoteAbility)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiAlarmSoundRemoteAbility = uiAlarmSoundRemoteAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set AlarmSoundRemoteAbility %u", iCamId, uiAlarmSoundRemoteAbility);

    return MOS_OK;
}

_INT Config_SetEventCloudAppendAbility(_INT iCamId, _UI uiEventCloudAppendAbility)
{
    if(Config_GetCamaraMng()->uiEventCloudAppendAbility == uiEventCloudAppendAbility)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiEventCloudAppendAbility = uiEventCloudAppendAbility;
    Config_GetItemSign()->ucSaveCamInf = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d set EventCloudAppendAbility %u", iCamId, uiEventCloudAppendAbility);
    return MOS_OK;
}
/************************************************************************
设置配置
*************************************************************************/
_INT Config_SetCamerOpenFlag(_INT iCamID, _UI uiCamOpenFlag)
{
    if(Config_GetCamaraMng()->uiCamOpenFlag == uiCamOpenFlag)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiCamOpenFlag   = uiCamOpenFlag;
    if (uiCamOpenFlag != 0)
    {
        CloudstgSetCameraStatusChangeFlag(uiCamOpenFlag);
    }
    Config_GetItemSign()->ucSaveCamInf     = 1;
    Config_GetItemSign()->ucCfgCamUpdate   = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d openflag %u ",iCamID,uiCamOpenFlag);
    return MOS_OK;
}

_INT Config_SetCamerWDR(_INT iCamID, _UI uiOpenFlag)
{
    if(Config_GetCamaraMng()->uiWDRFlag == uiOpenFlag)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiWDRFlag     = uiOpenFlag;
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d wdr %u ",iCamID,uiOpenFlag);
    return MOS_OK;
}

_INT Config_SetCamerMicOpenFlag(_INT iCamID, _UI uiMicOpenFlag)
{
    if(Config_GetCamaraMng()->uiMicOpenFlag == uiMicOpenFlag)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiMicOpenFlag   = uiMicOpenFlag;
    Config_GetItemSign()->ucSaveCamInf     = 1;
    Config_GetItemSign()->ucCfgCamUpdate   = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d mic openfalg %u ",iCamID,uiMicOpenFlag);
    return MOS_OK;
}

_INT Config_SetCamerSpkOpenFlag(_INT iCamID, _UI uiSpkOpenFlag)
{
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    if(Config_GetCamaraMng()->uiSpkOpenFlag == uiSpkOpenFlag)
    {
        Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiSpkOpenFlag   = uiSpkOpenFlag;
    // Config_GetItemSign()->ucSaveCamInf     = 1;
    // Config_GetItemSign()->ucCfgCamUpdate   = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d mic openfalg %u ",iCamID,uiSpkOpenFlag);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    return MOS_OK;
}

_INT Config_SetCamerDisplayOpenFlag(_INT iCamID, _UI uiDisPlayOpenFlag)
{
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    if(Config_GetCamaraMng()->uiDisPlayOpenFlag == uiDisPlayOpenFlag)
    {
        Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiDisPlayOpenFlag   = uiDisPlayOpenFlag;
    // Config_GetItemSign()->ucSaveCamInf     = 1;
    // Config_GetItemSign()->ucCfgCamUpdate   = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d display openfalg %u ",iCamID,uiDisPlayOpenFlag);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    return MOS_OK;
}

_INT Config_SetCameraDataInputMode(_INT iCamID, _UI uiCamDataInputMode)
{
    if(Config_GetCamaraMng()->uiCamDataInputMode == uiCamDataInputMode)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiCamDataInputMode   = uiCamDataInputMode;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d dDataInputMode %u ",iCamID,uiCamDataInputMode);
    return MOS_OK;
}

_INT Config_SetCamerCurInversionType(_INT iCamID, _UI uiCurInversionType)
{
    if(Config_GetCamaraMng()->uiCurInversionType == uiCurInversionType)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiCurInversionType   = uiCurInversionType;
    Config_GetItemSign()->ucSaveCamInf          = 1;
    Config_GetItemSign()->ucCfgCamUpdate        = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d cur inversiontype %u ",iCamID,uiCurInversionType);
    return MOS_OK;
}

_INT Config_SetCamerCurOSDInfo(_INT iCamID, _UI uiDisplayFlag, _UI uicurOSDPos, _UC* ucCurOSDName)
{
    if(MOS_STRCMP(Config_GetCamaraMng()->ucOSDName, ucCurOSDName) == 0 && Config_GetCamaraMng()->uiOSDPostion == uicurOSDPos\
     && Config_GetCamaraMng()->uiOSDCustomSwitch == uiDisplayFlag)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiOSDCustomMode   = 0;
    Config_GetCamaraMng()->uiOSDPostion      = uicurOSDPos;
    Config_GetCamaraMng()->uiOSDCustomSwitch = uiDisplayFlag;
    MOS_MEMSET(Config_GetCamaraMng()->ucOSDName, 0, sizeof(Config_GetCamaraMng()->ucOSDName));
    MOS_STRLCPY(Config_GetCamaraMng()->ucOSDName, ucCurOSDName, sizeof(Config_GetCamaraMng()->ucOSDName));

    // 同步旧OSD数据到新OSD数据
    if (uicurOSDPos == 0)
    {
        uicurOSDPos = 4;// 0默认为右下
    }
    if (uicurOSDPos == 1)
    {
        MOS_MEMSET(Config_GetCamaraMng()->aucOSDTopLeftName, 0, sizeof(Config_GetCamaraMng()->aucOSDTopLeftName));
        MOS_STRLCPY(Config_GetCamaraMng()->aucOSDTopLeftName, ucCurOSDName, sizeof(Config_GetCamaraMng()->aucOSDTopLeftName));
    }
    else if (uicurOSDPos == 2)
    {
        MOS_MEMSET(Config_GetCamaraMng()->aucOSDLowerLeftName, 0, sizeof(Config_GetCamaraMng()->aucOSDLowerLeftName));
        MOS_STRLCPY(Config_GetCamaraMng()->aucOSDLowerLeftName, ucCurOSDName, sizeof(Config_GetCamaraMng()->aucOSDLowerLeftName));
    }
    else if (uicurOSDPos == 3)
    {
        MOS_MEMSET(Config_GetCamaraMng()->aucOSDTopRightName, 0, sizeof(Config_GetCamaraMng()->aucOSDTopRightName));
        MOS_STRLCPY(Config_GetCamaraMng()->aucOSDTopRightName, ucCurOSDName, sizeof(Config_GetCamaraMng()->aucOSDTopRightName));
    }
    else if (uicurOSDPos == 4)
    {
        MOS_MEMSET(Config_GetCamaraMng()->aucOSDLowerRightName, 0, sizeof(Config_GetCamaraMng()->aucOSDLowerRightName));
        MOS_STRLCPY(Config_GetCamaraMng()->aucOSDLowerRightName, ucCurOSDName, sizeof(Config_GetCamaraMng()->aucOSDLowerRightName));
    }        
    Config_GetItemSign()->ucSaveCamInf    = 1;
    Config_GetItemSign()->ucCfgCamUpdate  = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d cur osdPos %u osdName %s ", iCamID, uicurOSDPos, ucCurOSDName);
    return MOS_OK;
}

_INT Config_SetCamerCurOSDInfoEx(_INT iCamID, _UI uiDisplayFlag, _UC *pucTopLeftName, _UC *pucLowerLeftName, _UC *pucTopRightName,_UC *pucLowerRightName)
{
    _UI uiOSDPostion = 0;
    _UC *pucOSDName  = MOS_NULL;

    if (!pucTopLeftName && !pucLowerLeftName && !pucTopRightName && !pucLowerRightName)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiOSDCustomMode   = 1;
    Config_GetCamaraMng()->uiOSDCustomSwitch = uiDisplayFlag;
    if (pucTopLeftName)
    {
        uiOSDPostion = EN_ZJ_OSD_POSITION_LT;
        pucOSDName   = pucTopLeftName;
        MOS_MEMSET(Config_GetCamaraMng()->aucOSDTopLeftName, 0, sizeof(Config_GetCamaraMng()->aucOSDTopLeftName));
        MOS_STRLCPY(Config_GetCamaraMng()->aucOSDTopLeftName, pucTopLeftName, sizeof(Config_GetCamaraMng()->aucOSDTopLeftName));
    }
    if (pucLowerLeftName)
    {
        uiOSDPostion = EN_ZJ_OSD_POSITION_LD;
        pucOSDName   = pucLowerLeftName;        
        MOS_MEMSET(Config_GetCamaraMng()->aucOSDLowerLeftName, 0, sizeof(Config_GetCamaraMng()->aucOSDLowerLeftName));
        MOS_STRLCPY(Config_GetCamaraMng()->aucOSDLowerLeftName, pucLowerLeftName, sizeof(Config_GetCamaraMng()->aucOSDLowerLeftName));
    }    
    if (pucTopRightName)
    {
        uiOSDPostion = EN_ZJ_OSD_POSITION_RT;
        pucOSDName   = pucTopRightName;        
        MOS_MEMSET(Config_GetCamaraMng()->aucOSDTopRightName, 0, sizeof(Config_GetCamaraMng()->aucOSDTopRightName));
        MOS_STRLCPY(Config_GetCamaraMng()->aucOSDTopRightName, pucTopRightName, sizeof(Config_GetCamaraMng()->aucOSDTopRightName));
    }
    if (pucLowerRightName)
    {
        uiOSDPostion = EN_ZJ_OSD_POSITION_RD;
        pucOSDName   = pucLowerRightName;        
        MOS_MEMSET(Config_GetCamaraMng()->aucOSDLowerRightName, 0, sizeof(Config_GetCamaraMng()->aucOSDLowerRightName));
        MOS_STRLCPY(Config_GetCamaraMng()->aucOSDLowerRightName, pucLowerRightName, sizeof(Config_GetCamaraMng()->aucOSDLowerRightName));
    }
    // 同步新OSD数据到旧OSD数据
    if (pucOSDName)
    {
        Config_GetCamaraMng()->uiOSDPostion = uiOSDPostion;
        MOS_MEMSET(Config_GetCamaraMng()->ucOSDName, 0, sizeof(Config_GetCamaraMng()->ucOSDName));
        MOS_STRLCPY(Config_GetCamaraMng()->ucOSDName, pucOSDName, sizeof(Config_GetCamaraMng()->ucOSDName));
    }
    Config_GetItemSign()->ucSaveCamInf    = 1;
    Config_GetItemSign()->ucCfgCamUpdate  = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d TL %s LL %s TR %s LR %s", iCamID, pucTopLeftName, pucLowerLeftName, pucTopRightName, pucLowerRightName);
    return MOS_OK;
}

_INT Config_SetCamerCurTimeOSDDisplay(_INT iCamID, _UI uiDisplayFlag)
{
    if(Config_GetCamaraMng()->uiOSDCommonSwitch == uiDisplayFlag)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiOSDCommonSwitch = uiDisplayFlag;
    Config_GetItemSign()->ucSaveCamInf       = 1;
    Config_GetItemSign()->ucCfgCamUpdate     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d OSDCommonSwitch %u", iCamID, uiDisplayFlag);
    return MOS_OK;
}

_INT Config_SetCamerCurCustomOSDDisplay(_INT iCamID, _UI uiDisplayFlag)
{
    if(Config_GetCamaraMng()->uiOSDCustomSwitch == uiDisplayFlag)
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiOSDCustomSwitch = uiDisplayFlag;
    Config_GetItemSign()->ucSaveCamInf       = 1;
    Config_GetItemSign()->ucCfgCamUpdate     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d OSDCustomSwitch %u", iCamID, uiDisplayFlag);
    return MOS_OK;
}

_INT Config_SetCamerCurOSDCommonInfo(_INT iCamID, _UI uiOSDCommonPosition, _UI uiOSDCommonFormat)
{
    if((Config_GetCamaraMng()->uiOSDCommonPosition == uiOSDCommonPosition) && 
       (Config_GetCamaraMng()->uiOSDCommonFormat   == uiOSDCommonFormat))
    {
        return MOS_OK;
    }

    Config_GetCamaraMng()->uiOSDCommonPosition = uiOSDCommonPosition;
    Config_GetCamaraMng()->uiOSDCommonFormat   = uiOSDCommonFormat;
    Config_GetItemSign()->ucSaveCamInf         = 1;
    Config_GetItemSign()->ucCfgCamUpdate       = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d OSDCommonPosition %u OSDCommonFormat %u",
                                            iCamID, uiOSDCommonPosition, uiOSDCommonFormat);
    return MOS_OK;
}

_INT Config_SetCamerGat1400Switch(_INT iCamID, _UI uiGat1400Switch)
{
    Mos_MutexLock(&Config_GetCamaraMng()->hGAT1400Mutex);
    if(Config_GetCamaraMng()->uiGAT1400Switch == uiGat1400Switch)
    {
        Mos_MutexUnLock(&Config_GetCamaraMng()->hGAT1400Mutex);
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiGAT1400Switch = uiGat1400Switch;
    Config_GetItemSign()->ucSaveCamInf     = 1;
    Config_GetItemSign()->ucCfgCamUpdate   = 1;
    Mos_MutexUnLock(&Config_GetCamaraMng()->hGAT1400Mutex);
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d gat1400 switch %u ",iCamID, uiGat1400Switch);
    return MOS_OK;
}

_INT Config_GetCamerGat1400Switch(_INT iCamID)
{
    _INT uiGat1400Switch = 0;

    Mos_MutexLock(&Config_GetCamaraMng()->hGAT1400Mutex);
    uiGat1400Switch = Config_GetCamaraMng()->uiGAT1400Switch;
    Mos_MutexUnLock(&Config_GetCamaraMng()->hGAT1400Mutex);

    return uiGat1400Switch;
}

_INT Config_SetCamerGat1400UploadInterval(_INT iCamID, _UI uiGAT1400UploadInterval)
{
    Mos_MutexLock(&Config_GetCamaraMng()->hGAT1400Mutex);
    if(Config_GetCamaraMng()->uiGAT1400UploadInterval == uiGAT1400UploadInterval)
    {
        Mos_MutexUnLock(&Config_GetCamaraMng()->hGAT1400Mutex);
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiGAT1400UploadInterval = uiGAT1400UploadInterval;
    Config_GetItemSign()->ucSaveCamInf     = 1;
    Config_GetItemSign()->ucCfgCamUpdate   = 1;
    Mos_MutexUnLock(&Config_GetCamaraMng()->hGAT1400Mutex);
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d gat1400 UploadInterval %u ",iCamID, uiGAT1400UploadInterval);
    return MOS_OK;
}

_INT Config_GetCamerGat1400UploadInterval(_INT iCamID)
{
    _INT uiGAT1400UploadInterval = 0;

    Mos_MutexLock(&Config_GetCamaraMng()->hGAT1400Mutex);
    uiGAT1400UploadInterval = Config_GetCamaraMng()->uiGAT1400UploadInterval;
    Mos_MutexUnLock(&Config_GetCamaraMng()->hGAT1400Mutex);

    return uiGAT1400UploadInterval;
}

_INT Config_SetCamerGat1400Info(_INT iCamID, _UC *pucGAT1400ID, _UC *pucGAT1400Domain)
{
    MOS_PARAM_NULL_RETERR(pucGAT1400ID);
    MOS_PARAM_NULL_RETERR(pucGAT1400Domain);

    _UC *pucStrStart = MOS_NULL;
    _UC *pucStrEnd   = MOS_NULL;
    _UC *pucStrHttp  = MOS_NULL;
    _UC *pucStrHttps = MOS_NULL;
    _UC ucGAT1400DomainBak[64] = {0};

    if(MOS_STRCMP(Config_GetCamaraMng()->ucGAT1400ID, pucGAT1400ID)         == 0 &&
       MOS_STRCMP(Config_GetCamaraMng()->ucGAT1400Domain, pucGAT1400Domain) == 0)
    {
        return MOS_OK;
    }

    // 兼容1400平台返回的域名偶尔是http接口的问题
    MOS_STRNCPY(ucGAT1400DomainBak, pucGAT1400Domain, sizeof(ucGAT1400DomainBak));
    pucStrHttps = MOS_STRSTR(pucGAT1400Domain, (_UC*)"https");
    if (pucStrHttps == MOS_NULL)
    {
        pucStrHttp = MOS_STRSTR(pucGAT1400Domain, (_UC*)"http");
        if (pucStrHttp)
        {
            pucStrHttp += 4;
            MOS_VSNPRINTF(ucGAT1400DomainBak, sizeof(ucGAT1400DomainBak), "https%s", pucStrHttp);
        }
    }
    // 兼容1400平台返回的域名偶尔不带/的问题
    MOS_STRNCPY(Config_GetCamaraMng()->ucGAT1400Domain, ucGAT1400DomainBak, sizeof(Config_GetCamaraMng()->ucGAT1400Domain));
    pucStrStart = MOS_STRSTR(ucGAT1400DomainBak, (_UC*)"//");
    if (pucStrStart)
    {
        pucStrStart += 2;
        pucStrEnd = MOS_STRSTR(pucStrStart, (_UC*)"/");
        if (pucStrEnd == MOS_NULL)
        {
            MOS_VSNPRINTF(Config_GetCamaraMng()->ucGAT1400Domain, sizeof(Config_GetCamaraMng()->ucGAT1400Domain), "%s/", ucGAT1400DomainBak);
        }
    }
    MOS_STRNCPY(Config_GetCamaraMng()->ucGAT1400ID, pucGAT1400ID, sizeof(Config_GetCamaraMng()->ucGAT1400ID));

    Config_GetItemSign()->ucSaveCamInf     = 1;
    Config_GetItemSign()->ucCfgCamUpdate   = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d  gat1400 id %s  domain %s",
            iCamID, Config_GetCamaraMng()->ucGAT1400ID, Config_GetCamaraMng()->ucGAT1400Domain);
    return MOS_OK;
}

_INT Config_SetCamerLocalIPv6Addr(_INT iCamID, _UC *pucLocalIPv6Addr)
{
    if ((pucLocalIPv6Addr == MOS_NULL))
    {
        MOS_LOG_ERR(CFG_LOGSTR, "pucLocalIPv6Addr is null");
        return MOS_ERR;
    }
    if(MOS_STRCMP(Config_GetCamaraMng()->aucLocalIPv6Addr, pucLocalIPv6Addr) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetCamaraMng()->aucLocalIPv6Addr, pucLocalIPv6Addr, sizeof(Config_GetCamaraMng()->aucLocalIPv6Addr));
    Config_GetItemSign()->ucSaveCamInf     = 1;
    Config_GetItemSign()->ucCfgCamUpdate   = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d LocalIPv6Addr %s",
            iCamID, Config_GetCamaraMng()->aucLocalIPv6Addr);
    return MOS_OK;
}

_INT Config_SetCamerCurIRWorkMode(_INT iCamID, _UI uiCurIRWorkMode)
{
    if(Config_GetCamaraMng()->uiCurIRWorkMode == uiCurIRWorkMode)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiCurIRWorkMode   = uiCurIRWorkMode;
    Config_GetItemSign()->ucSaveCamInf       = 1;
    Config_GetItemSign()->ucCfgCamUpdate     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d cur ir mode %u ",iCamID,uiCurIRWorkMode);
    return MOS_OK;
}

_INT Config_SetCamerCurScanFrequery(_INT iCamID, _UI uiCurScanFrequery)
{
    if(Config_GetCamaraMng()->uiCurScanFrequery == uiCurScanFrequery)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiCurScanFrequery   = uiCurScanFrequery;
    Config_GetItemSign()->ucSaveCamInf         = 1;
    Config_GetItemSign()->ucCfgCamUpdate       = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d cur scanfrequery %u ",iCamID,uiCurScanFrequery);
    return MOS_OK;
}

_INT Config_SetCamerStorageStatus(_INT iCamID, _UI uiStorageStatus)
{
    if(Config_GetCamaraMng()->uiStorageStatus == uiStorageStatus)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiStorageStatus   = uiStorageStatus;
    Config_GetItemSign()->ucSaveCamInf       = 1;
    Config_GetItemSign()->ucCfgCamUpdate     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d cur storage status %u ",iCamID,uiStorageStatus);
    return MOS_OK;
}

_INT Config_SetCamVolume(_INT iCamId,_INT iVolume)
{
    if(Config_GetCamaraMng()->uiCurMicVolume == iVolume)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiCurMicVolume = iVolume;
    Config_GetItemSign()->ucSaveCamInf    = 1;
    Config_GetItemSign()->ucCfgCamUpdate  = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set camera %d cur Volume %d",iCamId,iVolume);
    return MOS_OK;
}

_INT Config_SetCameraStreamParam(_INT iCamID,_INT iStreamID, ST_ZJ_VIDEO_PARAM* pstVideoParam)
{
    MOS_PARAM_NULL_RETERR(pstVideoParam);

    ST_CFG_VIDEODES *pstVideoDes = Config_GetVideoDes(iCamID,iStreamID);
    if(pstVideoDes == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(MOS_MEMCMP(&pstVideoDes->stVideoPara, pstVideoParam, sizeof(ST_ZJ_VIDEO_PARAM)) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMCPY(&pstVideoDes->stVideoPara, pstVideoParam, sizeof(ST_ZJ_VIDEO_PARAM));
    MOS_LOG_INF(CFG_LOGSTR,"set streamId %d, biteRate %u, FrameRate %u resolution %u, gop:%u, enc:%u",iStreamID,  pstVideoParam->uiBitrate,
                pstVideoParam->uiFramerate, pstVideoParam->uiResolution, pstVideoParam->uiFrameInterval, pstVideoParam->uiEncodeType);
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    return MOS_OK;
}

_INT Config_SetStreamerFisheyeInf(_INT iCamID,_INT iStreamerId,ST_ZJ_VIDEO_CIRCLE *pstCircle)
{
    MOS_PARAM_NULL_RETERR(pstCircle);

    ST_CFG_VIDEODES *pstVideoDes = Config_GetVideoDes(iCamID,iStreamerId);
    if(pstVideoDes == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(MOS_MEMCMP(&pstVideoDes->stCircle,pstCircle,sizeof(ST_ZJ_VIDEO_CIRCLE)) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMCPY(&pstVideoDes->stCircle,pstCircle,sizeof(ST_ZJ_VIDEO_CIRCLE));
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    return MOS_OK;
}

_INT Config_SetStreamerDistortion(_INT iCamID,_INT iStreamerId,ST_ZJ_VIDEO_DISTORTION *pstDistortion)
{
    MOS_PARAM_NULL_RETERR(pstDistortion);

    ST_CFG_VIDEODES *pstVideoDes = Config_GetVideoDes(iCamID,iStreamerId);
    if(pstVideoDes == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(MOS_MEMCMP(&pstVideoDes->stDistortion,pstDistortion,sizeof(ST_ZJ_VIDEO_DISTORTION)) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMCPY(&pstVideoDes->stDistortion,pstDistortion,sizeof(ST_ZJ_VIDEO_DISTORTION));
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    return MOS_OK;
}

_INT Config_SetCamAudioParam(_UI uiCamId,ST_ZJ_AUDIO_PARAM *pstAudioParm)
{
    MOS_PARAM_NULL_RETERR(pstAudioParm);

    if(MOS_MEMCMP(&Config_GetCamaraMng()->stAudioParm, pstAudioParm, sizeof(ST_ZJ_AUDIO_PARAM)) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMCPY(&Config_GetCamaraMng()->stAudioParm, pstAudioParm,sizeof(ST_ZJ_AUDIO_PARAM));
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    return MOS_OK;
}

ST_ZJ_AUDIO_PARAM* Config_GetCamAudioParm(_UI uiCamId)
{
    return &Config_GetCamaraMng()->stAudioParm;
}

_INT Config_SetRingToneAbilty(_UI uiBSupport,_UI uiDecAblity)
{
    if(Config_GetCamaraMng()->uiRingToneDecAbilty == uiDecAblity
        && Config_GetCamaraMng()->uiRingToneSetAbility == uiBSupport)
    {
        return MOS_OK;
    }
    Config_GetCamaraMng()->uiRingToneDecAbilty  = uiDecAblity;
    Config_GetCamaraMng()->uiRingToneSetAbility = uiBSupport;
    Config_GetItemSign()->ucSaveCamInf = 1;
    return MOS_OK;
}

_INT Config_SetEventCloudSwitch(_INT iEventCloudSwitch)
{
    if(iEventCloudSwitch == Config_GetCamaraMng()->iEventCloudSwitch)
    {
        return MOS_OK;
    }   
    Config_GetCamaraMng()->iEventCloudSwitch = iEventCloudSwitch;
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set EventCloudSwitch %d", iEventCloudSwitch);
    return MOS_OK;
}

// 设置事件云存最大秒数
_INT Config_SetEventCloudMaxTime(_INT iEventCloudMaxTime)
{
    if(iEventCloudMaxTime == Config_GetCamaraMng()->iEventCloudMaxTime)
    {
        return MOS_OK;
    }   
    Config_GetCamaraMng()->iEventCloudMaxTime = iEventCloudMaxTime;
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set EventCloudMaxTime %d", iEventCloudMaxTime);
    return MOS_OK;
}

// 设置事件云存最小秒数
_INT Config_SetEventCloudMinTime(_INT iEventCloudMinTime)
{
    if(iEventCloudMinTime == Config_GetCamaraMng()->iEventCloudMinTime)
    {
        return MOS_OK;
    }   
    Config_GetCamaraMng()->iEventCloudMinTime = iEventCloudMinTime;
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set EventCloudMinTime %d", iEventCloudMinTime);
    return MOS_OK;
}

// 设置事件云存检测秒数
_INT Config_SetEventCloudDetectTime(_INT iEventCloudDetectTime)
{
    if(iEventCloudDetectTime == Config_GetCamaraMng()->iEventCloudDetectTime)
    {
        return MOS_OK;
    }   
    Config_GetCamaraMng()->iEventCloudDetectTime = iEventCloudDetectTime;
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set EventCloudDetectTime %d", iEventCloudDetectTime);
    return MOS_OK;
}

// 设置事件云存追加录制秒数
_INT Config_SetEventCloudAppendTime(_INT iEventCloudAppendTime)
{
    if(iEventCloudAppendTime == Config_GetCamaraMng()->iEventCloudAppendTime)
    {
        return MOS_OK;
    }   
    Config_GetCamaraMng()->iEventCloudAppendTime = iEventCloudAppendTime;
    Config_GetItemSign()->ucSaveCamInf   = 1;
    Config_GetItemSign()->ucCfgCamUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_camera set EventCloudAppendTime %d", iEventCloudAppendTime);
    return MOS_OK;
}

_INT Config_FreeCameraMng()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_STREAMER_NODE *pstStreamerNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stStreamerList, pstStreamerNode, stIterator)
    {
        MOS_LIST_RMVNODE(&Config_GetCamaraMng()->stStreamerList, pstStreamerNode);
        MOS_FREE(pstStreamerNode);
    }

    // 释放通用外接设备插入状态列表内存
    ST_CFG_COMMON_EXDEV_INSERTSTATUS_NODE *pstExDevInsertStatusNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stCommonExDevInsertStatusList, pstExDevInsertStatusNode, stIterator)
    {
        MOS_FREE(pstExDevInsertStatusNode);
    }
    MOS_LIST_RMVALL(&Config_GetCamaraMng()->stCommonExDevInsertStatusList, MOS_TRUE);

    Mos_MutexDelete(&Config_GetCamaraMng()->hGAT1400Mutex);
    Mos_MutexDelete(&Config_GetCamaraMng()->hUploadDevStatusMutex);

    MOS_LOG_INF(CFG_LOGSTR,"camera destroy ok");
    return MOS_OK;
}

/********************************************************************************
*********************************************************************************/
// 通用外接设备插入状态 返回值：MOS_TRUE-更新数据，MOS_FALSE-不更新数据
static _INT Config_UpdateCommonExDevInsertStatus(_UC *pucExDevName, _INT iInsertStatus)
{
    if ((pucExDevName == MOS_NULL) || (MOS_STRLEN(pucExDevName) == 0))
    {
        MOS_LOG_ERR(CFG_LOGSTR, "ExDevName is invalid");
        return MOS_FALSE;
    }

    _INT iFirstFlag  = MOS_TRUE;
    _INT iUpdateFlag = MOS_FALSE;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_COMMON_EXDEV_INSERTSTATUS_NODE *pstExDevInsertStatusNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stCommonExDevInsertStatusList, pstExDevInsertStatusNode, stIterator)
    {
        if (MOS_STRNCMP(pstExDevInsertStatusNode->aucExDevName, pucExDevName, sizeof(pstExDevInsertStatusNode->aucExDevName)) == 0)
        {
            if (pstExDevInsertStatusNode->iInsertStatus != iInsertStatus)
            {
                iUpdateFlag = MOS_TRUE;
                pstExDevInsertStatusNode->iInsertStatus = iInsertStatus;
            }
            iFirstFlag = MOS_FALSE;
            MOS_LOG_INF(CFG_LOGSTR, "update ExDevName InsertStatus [%s %d]", pucExDevName, iInsertStatus);
            break;
        }
    }
    
    if (iFirstFlag == MOS_TRUE)
    {
        pstExDevInsertStatusNode = (ST_CFG_COMMON_EXDEV_INSERTSTATUS_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_COMMON_EXDEV_INSERTSTATUS_NODE));
        if (pstExDevInsertStatusNode == MOS_NULL)
        {
            MOS_LOG_ERR(CFG_LOGSTR, "node malloc err  %s %u", pucExDevName, iInsertStatus);
            return MOS_ERR;
        }
        iUpdateFlag = MOS_TRUE;

        MOS_STRLCPY(pstExDevInsertStatusNode->aucExDevName, pucExDevName, sizeof(pstExDevInsertStatusNode->aucExDevName));
        pstExDevInsertStatusNode->aucExDevName[sizeof(pstExDevInsertStatusNode->aucExDevName)-1] = 0;
        pstExDevInsertStatusNode->iInsertStatus = iInsertStatus;
        MOS_LIST_ADDTAIL(&Config_GetCamaraMng()->stCommonExDevInsertStatusList, pstExDevInsertStatusNode);

        MOS_LOG_INF(CFG_LOGSTR, "first add ExDev InsertStatus [%s %d] cnt:%d", pstExDevInsertStatusNode->aucExDevName, 
                                pstExDevInsertStatusNode->iInsertStatus, MOS_LIST_GETCOUNT(&Config_GetCamaraMng()->stCommonExDevInsertStatusList));
    }

    return iUpdateFlag;
}

// 创建外接设备插入状态对象
static _VPTR Config_BuildExDevInsertStatusObject(JSON_HANDLE hRoot)
{
    if (hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR, "hRoot is invalid");
        return;
    }
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_COMMON_EXDEV_INSERTSTATUS_NODE *pstExDevInsertStatusNode = MOS_NULL;

    JSON_HANDLE hExDevInsertStatusInf = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"ExDevInsertStatusInf", hExDevInsertStatusInf);

    FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stCommonExDevInsertStatusList, pstExDevInsertStatusNode, stIterator)
    {
        Adpt_Json_AddItemToObject(hExDevInsertStatusInf, pstExDevInsertStatusNode->aucExDevName, Adpt_Json_CreateStrWithNum(pstExDevInsertStatusNode->iInsertStatus));
    }

    return;
}

_VPTR Config_BuildCameraObject(_UI uiCfgType)
{
    JSON_HANDLE hSensorObject       = MOS_NULL;
    JSON_HANDLE hPlaySupportObject  = MOS_NULL;
    JSON_HANDLE hObject             = MOS_NULL;
    JSON_HANDLE hArry               = MOS_NULL;
    JSON_HANDLE hArryObject         = MOS_NULL;
    JSON_HANDLE hCloudObject        = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_VIDEODES *pstVideoDes = MOS_NULL;
    ST_CFG_STREAMER_NODE *pstStreamerNode = MOS_NULL;
    ST_CFG_LEN_NODE      *pstLenNode      = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiCamSign));
    if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"StreamCount",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiStreamCnt));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"VoicePlayAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiVoicePlayAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MicroPhoneAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiMicPhoneAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDSetAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDSetAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDSetExpandAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDSetExpandAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDCommonSetAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDCommonSetAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IRRedAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiIrLedAbility));// added
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"InversionAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiInversionAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"StorageAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiStorageAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"WDRAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiWDRAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"RingToneSetAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiRingToneSetAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"RingToneDecAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiRingToneDecAbilty));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"GAT1400Ability",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiGAT1400Ability));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IPv6Ability",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiIPv6Ability));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"P2PAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiP2PAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ZoomAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiZoomAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"FocalAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiFocusAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"QualityProbeAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiQualityProbeAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudBroadcastAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiCloudBroadcastAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AlarmSoundSetAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiAlarmSoundSetAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AISwitchReturnErrAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiAISwitchReturnErrAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"PolicyDomainAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiPolicyDomainAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MultiFocalLenthAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiMultiFocalLenthAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IMSAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiIMSAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SuperCodesAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiSuperCodesAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"PhysicalMaskAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiPhysicalMaskAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AlarmSoundExecuteTimeAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiAlarmSoundExecuteTimeAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AlarmSoundRemoteAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiAlarmSoundRemoteAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SilenceRestartAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiSilenceRestartAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ExternalSpeakerAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiExternalSpeakerAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"EventCloudAppendAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiEventCloudAppendAbility));

        Adpt_Json_AddItemToObject(hRoot,(_UC*)"WithScreenAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiWithScreenAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"VideoPlayAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiVideoPlayAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CallButtonAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiCallButtonAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"HangUpButtonAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiHangUpButtonAbility));
 
        hSensorObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sensor",hSensorObject);

        Adpt_Json_AddItemToObject(hSensorObject,(_UC*)"MaxLenCount",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stSensors.usLenMaxCount));
        Adpt_Json_AddItemToObject(hSensorObject,(_UC*)"CurrentLenID",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stSensors.usCurLenId));
        Adpt_Json_AddItemToObject(hSensorObject,(_UC*)"AutoFlag",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stSensors.usAutoFlag));
        Adpt_Json_AddItemToObject(hSensorObject,(_UC*)"DefaultLenId",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stSensors.usDefaultLenId));
        hArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hSensorObject,(_UC*)"Lens",hArry);
        FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stSensors.stLensList, pstLenNode, stIterator)
        {
            hArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hArry,hArryObject);
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"LenID",Adpt_Json_CreateStrWithNum(pstLenNode->iLenId));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"LenName",Adpt_Json_CreateString(pstLenNode->aucLenName));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"LensType",Adpt_Json_CreateStrWithNum(pstLenNode->iLenType));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"LenFocalLenth",Adpt_Json_CreateStrWithNum(pstLenNode->focalLenth));
        }

        hPlaySupportObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"VideoPlaySupport",hPlaySupportObject);
        Adpt_Json_AddItemToObject(hPlaySupportObject,(_UC*)"ResolutionAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlaySupport.uiResolutionAbility));
        Adpt_Json_AddItemToObject(hPlaySupportObject,(_UC*)"VideoEncAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlaySupport.uiVideoEncAbility));
        Adpt_Json_AddItemToObject(hPlaySupportObject,(_UC*)"MaxBitRate",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlaySupport.uiMaxBitRate));
    }
	
    if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MicroPhoneStatus",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiMicOpenFlag));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CamStatus",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiCamOpenFlag));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"InversionType",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiCurInversionType));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IRRedMode",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiCurIRWorkMode));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ScanFrequery",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiCurScanFrequery));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"StorageStatus",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiStorageStatus));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Volumn",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiCurMicVolume));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"WDRMode",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiWDRFlag));

        // OSD默认(时间)水印显示开关    0.关闭，1.开启
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDCommonSwitch",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDCommonSwitch));

        // OSD默认(时间)水印位置        0.默认; 1.左上; 2.左下; 3.右上; 4.右下
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDCommonPosition",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDCommonPosition));
        // OSD默认(时间)水印格式        参考: 
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDCommonFormat",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDCommonFormat));
        
        // OSD自定义(文本)水印显示开关  0.关闭，1.开启
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDCustomSwitch",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDCustomSwitch));
        // OSD自定义(文本)水印位置      0.默认; 1.左上; 2.左下; 3.右上; 4.右下
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDPosition",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDPostion));   // 以平台协议文档为准
        // OSD自定义(文本)水印内容      格式:UTF-8，最大支持512字节
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDName",Adpt_Json_CreateString(Config_GetCamaraMng()->ucOSDName));
        // OSD自定义(文本)水印模式      0.默认，只能显示一个位置水印;1.支持同时显示四个位置水印
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDCustomMode",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiOSDCustomMode));
        // OSD自定义(文本)水印拓展内容
        hObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSDExpand",hObject);
        // OSD左上自定义(文本),四角水印
        Adpt_Json_AddItemToObject(hObject,(_UC*)"TopLeftName",Adpt_Json_CreateString(Config_GetCamaraMng()->aucOSDTopLeftName));
        // OSD右上自定义(文本),四角水印
        Adpt_Json_AddItemToObject(hObject,(_UC*)"TopRightName",Adpt_Json_CreateString(Config_GetCamaraMng()->aucOSDTopRightName));
        // OSD左下自定义(文本),四角水印
        Adpt_Json_AddItemToObject(hObject,(_UC*)"LowerLeftName",Adpt_Json_CreateString(Config_GetCamaraMng()->aucOSDLowerLeftName));
        // OSD右下自定义(文本),四角水印
        Adpt_Json_AddItemToObject(hObject,(_UC*)"LowerRightName",Adpt_Json_CreateString(Config_GetCamaraMng()->aucOSDLowerRightName));

        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IPv6Switch",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiIPv6Switch));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MsgConnectNetType",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiMsgConnectNetType));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"LocalIPv6Addr",Adpt_Json_CreateString(Config_GetCamaraMng()->aucLocalIPv6Addr));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"GAT1400Switch",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiGAT1400Switch));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"GAT1400UploadInterval",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiGAT1400UploadInterval));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"GAT1400ID",Adpt_Json_CreateString(Config_GetCamaraMng()->ucGAT1400ID));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"GAT1400Domain",Adpt_Json_CreateString(Config_GetCamaraMng()->ucGAT1400Domain));

        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ExternalSpeakerStatus",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiExternalSpeakerStatus));

        hArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ExternalSpeakers", hArry);
        {
            hArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hArry,hArryObject);
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"CTEI",Adpt_Json_CreateString(Config_GetCamaraMng()->stExternalSpeakerInfo.aucCTEI));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"FWVER",Adpt_Json_CreateString(Config_GetCamaraMng()->stExternalSpeakerInfo.aucFwVer));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"UID",Adpt_Json_CreateString(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevUID));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"SN",Adpt_Json_CreateString(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevSN));
        }

        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SuperCodesStatus",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiSuperCodesStatus));

        hObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AudioParam",hObject);
        Adpt_Json_AddItemToObject(hObject,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stAudioParm.uiEncodeType));
        Adpt_Json_AddItemToObject(hObject,(_UC*)"SampleRate",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stAudioParm.uiSampleRate));
        Adpt_Json_AddItemToObject(hObject,(_UC*)"Channel",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stAudioParm.uiChannel));
        Adpt_Json_AddItemToObject(hObject,(_UC*)"Depth",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stAudioParm.uiDepth));
        hCloudObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudInf",hCloudObject);
        Adpt_Json_AddItemToObject(hCloudObject,(_UC*)"EventCloudSwitch",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->iEventCloudSwitch));
        Adpt_Json_AddItemToObject(hCloudObject,(_UC*)"EventCloudMaxTime",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->iEventCloudMaxTime));
        Adpt_Json_AddItemToObject(hCloudObject,(_UC*)"EventCloudMinTime",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->iEventCloudMinTime));
        Adpt_Json_AddItemToObject(hCloudObject,(_UC*)"EventCloudDetectTime",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->iEventCloudDetectTime));
        Adpt_Json_AddItemToObject(hCloudObject,(_UC*)"EventCloudAppendTime",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->iEventCloudAppendTime));

        // 带屏设备屏幕硬件属性
        JSON_HANDLE hScreenHardwareObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ScreenHardwareInf",hScreenHardwareObject);
        Adpt_Json_AddItemToObject(hScreenHardwareObject,(_UC*)"ScreenSize",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stScreenHardwareInf.dScreenSize));
        Adpt_Json_AddItemToObject(hScreenHardwareObject,(_UC*)"Resolution",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stScreenHardwareInf.uiResolution));
        Adpt_Json_AddItemToObject(hScreenHardwareObject,(_UC*)"Width",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stScreenHardwareInf.uiWidth));
        Adpt_Json_AddItemToObject(hScreenHardwareObject,(_UC*)"Height",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stScreenHardwareInf.uiHeight));
        Adpt_Json_AddItemToObject(hScreenHardwareObject,(_UC*)"Dpi",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stScreenHardwareInf.uiDpi));
        Adpt_Json_AddItemToObject(hScreenHardwareObject,(_UC*)"SupportTouchFlag",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stScreenHardwareInf.uiSupportTouchFlag));

        // 双向视频通话对端出流信息
        JSON_HANDLE hVideoPlayInfObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"VideoPlayInf",hVideoPlayInfObject);
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"Resolution",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiResolution));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"Width",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiWidth));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"Height",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiHeight));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiEncodeType));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"SmartEncFlag",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiSmartEncFlag));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"Quality",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiQuality));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiFramerate));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"BitRate",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiBitrate));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"RateType",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiRateType));
        Adpt_Json_AddItemToObject(hVideoPlayInfObject,(_UC*)"FrameInterval",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->stVideoPlayInf.uiFrameInterval));
    }

    hArry = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Streamers",hArry);

    FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stStreamerList, pstStreamerNode, stIterator)
    {
        hArryObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArry,hArryObject);

        pstVideoDes   = &pstStreamerNode->stVideoDes;
        Adpt_Json_AddItemToObject(hArryObject,(_UC*)"StreamID",Adpt_Json_CreateStrWithNum(pstStreamerNode->uiStreamId));
        if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
        {
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"ResolutionAbility",Adpt_Json_CreateStrWithNum(pstStreamerNode->uiResolutionAbility));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"VideoEncAbility",Adpt_Json_CreateStrWithNum(pstStreamerNode->uiCapAbility));
        }
        if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
        {
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Resolution",Adpt_Json_CreateStrWithNum(pstStreamerNode->stVideoDes.stVideoPara.uiResolution));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Width",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiWidth));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Height",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiHeight));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiEncodeType));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"SmartEncFlag",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiSmartEncFlag));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Quality",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiQuality));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiFramerate));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"BiteRate",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiBitrate));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"RateType",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiRateType));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"FrameInterval",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiFrameInterval));


            hObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Circle",hObject);
            Adpt_Json_AddItemToObject(hObject,(_UC*)"Radius",Adpt_Json_CreateStrWithNum(pstVideoDes->stCircle.uiRadius));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"Angle",Adpt_Json_CreateStrWithNum(pstVideoDes->stCircle.doubleAngle));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"C1X",Adpt_Json_CreateStrWithNum(pstVideoDes->stCircle.uiCc1x));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"C1Y",Adpt_Json_CreateStrWithNum(pstVideoDes->stCircle.uiCc1Y));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"C2X",Adpt_Json_CreateStrWithNum(pstVideoDes->stCircle.uiCc2x));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"C2Y",Adpt_Json_CreateStrWithNum(pstVideoDes->stCircle.uiCc2Y));

            hObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Distortion",hObject);
            Adpt_Json_AddItemToObject(hObject,(_UC*)"Fx",Adpt_Json_CreateStrWithNum(pstVideoDes->stDistortion.fx));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"Fy",Adpt_Json_CreateStrWithNum(pstVideoDes->stDistortion.fy));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"Fa",Adpt_Json_CreateStrWithNum(pstVideoDes->stDistortion.a));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"Fb",Adpt_Json_CreateStrWithNum(pstVideoDes->stDistortion.b));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"Scale",Adpt_Json_CreateStrWithNum(pstVideoDes->stDistortion.scale));
        }
    }

    // 创建外接设备插入状态对象
    Config_BuildExDevInsertStatusObject(hRoot);
    return hRoot;
}

_UC *Config_BuildCameraJson(_UI uiCfgType)
{
    _UC *pucStrTmp    = MOS_NULL;

    // 云存相关配置保存在cloud.db，不在此二次保存
    JSON_HANDLE hRoot = Config_BuildCameraObject(uiCfgType);
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_LOG_INF(CFG_LOGSTR,"build camera info %s",pucStrTmp);
	
    // MOS_PRINTF("build camera info %s \r\n", pucStrTmp);
    return pucStrTmp;
}

// 读取摄像机配置的字段
_INT Config_ParseCameraJson(_UC *pStrJson,_UI uiCfgType)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _UC *pucStrTmp = MOS_NULL;
    _INT i,iArrySize,iValue;
    _INT uiValueData = 0;
    JSON_HANDLE hObjetItem          = MOS_NULL;
    JSON_HANDLE hArryObject         = MOS_NULL;
    JSON_HANDLE hArry               = MOS_NULL;
    JSON_HANDLE hSensorObject       = MOS_NULL;
    JSON_HANDLE hPlaySupportObject  = MOS_NULL;
    ST_CFG_VIDEODES *pstVideoDes = MOS_NULL;
    ST_CFG_STREAMER_NODE *pstStreamerNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_LEN_NODE *pstLenNode = MOS_NULL;
    JSON_HANDLE hEventCloudObject = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);

    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiCamSign);
    if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        // 同时编码流数目
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StreamCount"),(_INT*)&Config_GetCamaraMng()->uiStreamCnt);
        // 双向语音对讲能力     设置语音对讲能力 0.不支持;1.支持单工;2.支持双工
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"VoicePlayAbility"),(_INT*)&Config_GetCamaraMng()->uiVoicePlayAbility);
        // 麦克风能力       0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"MicroPhoneAbility"),(_INT*)&Config_GetCamaraMng()->uiMicPhoneAbility);
        // OSD水印设置能力  0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDSetAbility"),(_INT*)&Config_GetCamaraMng()->uiOSDSetAbility);
        // OSD水印设置拓展能力  0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDSetExpandAbility"),(_INT*)&Config_GetCamaraMng()->uiOSDSetExpandAbility);
        // OSD默认/时间水印设置能力 0.不支持，1.支持（支持0-10十一种水印格式）,预留2、3支持更多时间水印格式
        JSON_HANDLE hOSDCommonSetAbility = MOS_NULL;
        hOSDCommonSetAbility = Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDCommonSetAbility");
        if (hOSDCommonSetAbility)
        {
            // 优化读取不存在字段是默认为0情况
            Adpt_Json_GetIntegerEx(hOSDCommonSetAbility,(_INT*)&Config_GetCamaraMng()->uiOSDCommonSetAbility);
        }   
        // 图像翻转能力     0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"InversionAbility"),(_INT*)&Config_GetCamaraMng()->uiInversionAbility);
        // 存储卡支持能力   0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StorageAbility"),(_INT*)&Config_GetCamaraMng()->uiStorageAbility);
        // 铃声设置能力     0.不支持;1.支持选择;2.支持自定义
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"RingToneSetAbility"),(_INT*)&Config_GetCamaraMng()->uiRingToneSetAbility);
        // 门铃声音解码能力 G711A、G711U
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"RingToneDecAbility"),(_INT*)&Config_GetCamaraMng()->uiRingToneDecAbilty);
        // 红外灯支持能力   0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IRRedAbility"),(_INT*)&Config_GetCamaraMng()->uiIrLedAbility);
        // 设备宽动态能力   0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"WDRAbility"),(_INT*)&Config_GetCamaraMng()->uiWDRAbility);
        // 设备GAT1400能力 0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GAT1400Ability"),(_INT*)&Config_GetCamaraMng()->uiGAT1400Ability);
        // 多目摄像头能力   0.不支持, 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"MultiFocalLenthAbility"),(_INT*)&Config_GetCamaraMng()->uiMultiFocalLenthAbility);
        // IMS通话能力     0.不支持  1.支持IMS音频通话  2.支持IMS视频通话能力(VoLTE通话)
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IMSAbility"),&Config_GetCamaraMng()->uiIMSAbility);
        // 超级编码能力     0.不支持，1.支持
        //Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SuperCodesAbility"),(_INT*)&Config_GetCamaraMng()->uiSuperCodesAbility);
        // 物理遮蔽能力     0.不支持，1.支持(不从配置文件读取,由设备厂家设置。当配置文件为1,然后升级为不支持此能力值的版本,能力值会与实际情况不符)
        //Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PhysicalMaskAbility"),(_INT*)&Config_GetCamaraMng()->uiPhysicalMaskAbility);
        // 外接扬声器能力(音柱) 0.不支持，1.支持
        //Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ExternalSpeakerAbility"),(_INT*)&Config_GetCamaraMng()->uiExternalSpeakerAbility);
        // 支持远程触发播放能力(支持3468-播放指定警报音的信令下发), 0.不支持，1.支持  SDK默认支持
        JSON_HANDLE hAlarmSoundRemoteAbility = MOS_NULL;
        hAlarmSoundRemoteAbility = Adpt_Json_GetObjectItem(hRoot,(_UC*)"AlarmSoundRemoteAbility");
        if (hAlarmSoundRemoteAbility)
        {
            // 优化读取不存在字段是默认为0情况
            Adpt_Json_GetIntegerEx(hAlarmSoundRemoteAbility,(_INT*)&Config_GetCamaraMng()->uiAlarmSoundRemoteAbility);
        }
        // 静默重启播放能力 0.不支持，1.支持 SDK默认支持
        JSON_HANDLE hSilenceRestartAbility = MOS_NULL;
        hSilenceRestartAbility = Adpt_Json_GetObjectItem(hRoot,(_UC*)"SilenceRestartAbility");
        if (hSilenceRestartAbility)
        {
            // 优化读取不存在字段是默认为0情况
            Adpt_Json_GetIntegerEx(hSilenceRestartAbility,(_INT*)&Config_GetCamaraMng()->uiSilenceRestartAbility);
        }
        // 设备变倍能力 0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ZoomAbility"),(_INT*)&Config_GetCamaraMng()->uiZoomAbility);
        // 设备变焦能力 0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"FocalAbility"),(_INT*)&Config_GetCamaraMng()->uiFocusAbility);
        // 设备IPv6能力 0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IPv6Ability"),&Config_GetCamaraMng()->uiIPv6Ability);

        // 具备屏幕能力, 0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"WithScreenAbility"),(_INT*)&Config_GetCamaraMng()->uiWithScreenAbility);
        // 双向视频通话能力
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"VideoPlayAbility"),(_INT*)&Config_GetCamaraMng()->uiVideoPlayAbility);
        // 呼出物理按键能力值, 0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CallButtonAbility"),&Config_GetCamaraMng()->uiCallButtonAbility);
        // 挂断物理按键能力值, 0.不支持，1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"HangUpButtonAbility"),&Config_GetCamaraMng()->uiHangUpButtonAbility);

        // sensor镜头
        hSensorObject = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sensor");
        if(hSensorObject != MOS_NULL)
        {
            // 当前镜片ID
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSensorObject,(_UC*)"CurrentLenID"),&iValue);
            Config_GetCamaraMng()->stSensors.usCurLenId = iValue;

            // 自动聚焦标志
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSensorObject,(_UC*)"AutoFlag"),&iValue);
            Config_GetCamaraMng()->stSensors.usAutoFlag = iValue;

            // 默认镜片ID
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSensorObject,(_UC*)"DefaultLenId"),&iValue);
            Config_GetCamaraMng()->stSensors.usDefaultLenId = iValue;

            // 最大镜片数
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSensorObject,(_UC*)"MaxLenCount"),&iValue);
            Config_GetCamaraMng()->stSensors.usLenMaxCount = iValue;

            // 镜片
            hArry = Adpt_Json_GetObjectItem(hSensorObject,(_UC*)"Lens");
            iArrySize = Adpt_Json_GetArraySize(hArry);
            for(i = 0; i < iArrySize; i++)
            {
                hObjetItem = Adpt_Json_GetArrayItem(hArry,i);
                // 镜片ID
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"LenID"),(_INT*)&iValue);

                FOR_EACHDATA_INLIST(&Config_GetCamaraMng()->stSensors.stLensList, pstLenNode, stIterator)
                {
                    if(pstLenNode->iLenId == iValue)
                    {
                        break;
                    }
                }
                if(pstLenNode == MOS_NULL)
                {
                    pstLenNode = (ST_CFG_LEN_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_LEN_NODE));
                    pstLenNode->iLenId = iValue;
                    MOS_LIST_ADDTAIL(&Config_GetCamaraMng()->stSensors.stLensList, pstLenNode);
                }
                // 镜片类型
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"LensType"),&pstLenNode->iLenType);
                // 镜片焦点长度
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"LenFocalLenth"),&pucStrTmp);
                if(pucStrTmp)
                {
                    pstLenNode->focalLenth = atof(pucStrTmp);
                }
                // 镜片名称
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"LenName"),&pucStrTmp);
                MOS_STRNCPY(pstLenNode->aucLenName, pucStrTmp, sizeof(pstLenNode->aucLenName));
            }
        }

        // 双向视频通话对端出流支持能力信息
        hPlaySupportObject = Adpt_Json_GetObjectItem(hRoot,(_UC*)"VideoPlaySupport");
        if(hPlaySupportObject != MOS_NULL)
        {
            // 支持持分辨率类型，见分辨率定义EN_ZJ_CARERA_RESOLUTION_ABILITY，若支持1080P和360P，则uiResolutionAbility=EN_ZJ_CARERA_RESOLUTION_ABILITY_1080P|EN_ZJ_CARERA_RESOLUTION_ABILITY_360P
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPlaySupportObject,(_UC*)"ResolutionAbility"),&iValue);
            Config_GetCamaraMng()->stVideoPlaySupport.uiResolutionAbility = iValue;

            // 0x01.JPEG图片编码模式, 0x02.H264编码，0x04.H265编码,若支持H264、H265编码，则uiVideoEncAbility=0x02|0x04
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPlaySupportObject,(_UC*)"VideoEncAbility"),&iValue);
            Config_GetCamaraMng()->stVideoPlaySupport.uiVideoEncAbility = iValue;

            // 最大支持视频码率
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPlaySupportObject,(_UC*)"MaxBitRate"),&iValue);
            Config_GetCamaraMng()->stVideoPlaySupport.uiMaxBitRate = iValue;
        }
    }

    if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        // 麦克风开关状态   0.关闭，1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"MicroPhoneStatus"),(_INT*)&Config_GetCamaraMng()->uiMicOpenFlag);
        // 摄像头开关状态   0.关闭，1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CamStatus"),(_INT*)&Config_GetCamaraMng()->uiCamOpenFlag);
        // 图像翻转状态     1.垂直翻转,2.水平翻转,3.垂直水平翻转
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"InversionType"),(_INT*)&Config_GetCamaraMng()->uiCurInversionType);
        // 红外灯模式       0.自动模式，1.红外模式，2.全彩模式
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IRRedMode"),(_INT*)&Config_GetCamaraMng()->uiCurIRWorkMode);
        // 摄像头扫描频率   50Hz，60Hz
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ScanFrequery"),(_INT*)&Config_GetCamaraMng()->uiCurScanFrequery);
        // SD卡是否插入,工作正常   0.未插入,1.插入
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StorageStatus"),(_INT*)&Config_GetCamaraMng()->uiStorageStatus);
        // 设备的音量大小   0-100
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Volumn"),(_INT*)&Config_GetCamaraMng()->uiCurMicVolume);
        // 设备宽动态状态   0.关闭，1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"WDRMode"),(_INT*)&Config_GetCamaraMng()->uiWDRFlag);

        // OSD默认(时间)水印显示开关    0.关闭，1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDCommonSwitch"),(_INT*)&Config_GetCamaraMng()->uiOSDCommonSwitch);
        // OSD默认(时间)水印位置        0.默认; 1.左上; 2.左下; 3.右上; 4.右下
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDCommonPosition"),(_INT*)&Config_GetCamaraMng()->uiOSDCommonPosition);
        // OSD默认(时间)水印开关        时间水印显示开关 0.关闭，1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDCommonFormat"),(_INT*)&Config_GetCamaraMng()->uiOSDCommonFormat);

        // OSD自定义(文本)水印显示开关  0.关闭，1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDCustomSwitch"),(_INT*)&Config_GetCamaraMng()->uiOSDCustomSwitch);
        // OSD自定义(文本)水印位置      0.默认; 1.左上; 2.左下; 3.右上; 4.右下
        // 兼容OSDPosition、OSDPostion、OSDPos字段
        JSON_HANDLE hOSDPositionJson = Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDPosition");
        JSON_HANDLE hOSDPostionJson = Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDPostion");
        JSON_HANDLE hOSDPosJson = Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDPos");
        if (hOSDPositionJson)
        {
            Adpt_Json_GetIntegerEx(hOSDPositionJson,(_INT*)&Config_GetCamaraMng()->uiOSDPostion);
        }
        else if (hOSDPostionJson)
        {
            Adpt_Json_GetIntegerEx(hOSDPostionJson,(_INT*)&Config_GetCamaraMng()->uiOSDPostion);
        }
        else if(hOSDPosJson)
        {
            Adpt_Json_GetIntegerEx(hOSDPosJson,(_INT*)&Config_GetCamaraMng()->uiOSDPostion);
        }
        // OSD自定义(文本)水印内容  格式:UTF-8，最大支持512字节
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDName"),&pucStrTmp);
        MOS_STRNCPY(Config_GetCamaraMng()->ucOSDName, pucStrTmp, sizeof(Config_GetCamaraMng()->ucOSDName));
        // OSD自定义(文本)水印模式  0.默认,只能显示一个位置水印; 1.支持同时显示四个位置水印
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDCustomMode"),(_INT*)&Config_GetCamaraMng()->uiOSDCustomMode);
        // OSD自定义(文本)水印拓展内容
        hObjetItem = Adpt_Json_GetObjectItem(hRoot,(_UC*)"OSDExpand");
        if (hObjetItem)
        {
            // OSD左上自定义(文本),四角水印
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"TopLeftName"),&pucStrTmp);
            MOS_STRNCPY(Config_GetCamaraMng()->aucOSDTopLeftName, pucStrTmp, sizeof(Config_GetCamaraMng()->aucOSDTopLeftName));
            // OSD右上自定义(文本),四角水印
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"TopRightName"),&pucStrTmp);
            MOS_STRNCPY(Config_GetCamaraMng()->aucOSDTopRightName, pucStrTmp, sizeof(Config_GetCamaraMng()->aucOSDTopRightName));
            // OSD左下自定义(文本),四角水印
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"LowerLeftName"),&pucStrTmp);
            MOS_STRNCPY(Config_GetCamaraMng()->aucOSDLowerLeftName, pucStrTmp, sizeof(Config_GetCamaraMng()->aucOSDLowerLeftName));
            // OSD右下自定义(文本),四角水印
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"LowerRightName"),&pucStrTmp);
            MOS_STRNCPY(Config_GetCamaraMng()->aucOSDLowerRightName, pucStrTmp, sizeof(Config_GetCamaraMng()->aucOSDLowerRightName));
        }
        // IPv6开关标志，0.关，1.开
        Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IPv6Switch"),(_INT*)&Config_GetCamaraMng()->uiIPv6Switch, 1);
        // 信令连接网络类型，0.IPv4，1.IPv6
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"MsgConnectNetType"),(_INT*)&Config_GetCamaraMng()->uiMsgConnectNetType);

        // 不需要读取  因为上电后重新获取的IPv6地址跟配置文件里面的不一样
        // Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"LocalIPv6Addr"),&pucStrTmp);
        // MOS_STRNCPY(Config_GetCamaraMng()->aucLocalIPv6Addr, pucStrTmp, sizeof(Config_GetCamaraMng()->aucLocalIPv6Addr));
    
        // Ga1400功能开关 0.关闭，1.开启
        JSON_HANDLE hGAT1400Switch = MOS_NULL;
        hGAT1400Switch = Adpt_Json_GetObjectItem(hRoot,(_UC*)"GAT1400Switch");
        if (hGAT1400Switch)
        {
            // 优化读取不存在字段是默认为0情况，主要场景3.0升级4.0后的配置同步
            Adpt_Json_GetIntegerEx(hGAT1400Switch,(_INT*)&Config_GetCamaraMng()->uiGAT1400Switch);
        }
        // MOS_PRINTF("%s:%d: GAT1400Switch:%u \r\n", __FUNCTION__, __LINE__, Config_GetCamaraMng()->uiGAT1400Switch);

        // Ga1400上传图片间隔
        JSON_HANDLE hGAT1400UploadInterval = MOS_NULL;
        hGAT1400UploadInterval = Adpt_Json_GetObjectItem(hRoot,(_UC*)"GAT1400UploadInterval");
        if (hGAT1400UploadInterval)
        {
            // 优化读取不存在字段是默认为0情况，主要场景3.0升级4.0后的配置同步
            Adpt_Json_GetIntegerEx(hGAT1400UploadInterval,(_INT*)&Config_GetCamaraMng()->uiGAT1400UploadInterval);
        }
        // MOS_PRINTF("%s:%d: GAT1400UploadInterval:%u \r\n", __FUNCTION__, __LINE__, Config_GetCamaraMng()->uiGAT1400UploadInterval);

        // Ga1400 ID 20位
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GAT1400ID"),&pucStrTmp);
        MOS_STRNCPY(Config_GetCamaraMng()->ucGAT1400ID, pucStrTmp, sizeof(Config_GetCamaraMng()->ucGAT1400ID));
        // MOS_PRINTF("%s:%d: GAT1400ID:%s \r\n", __FUNCTION__, __LINE__, Config_GetCamaraMng()->ucGAT1400ID);
        // Ga1400 配置接口域名
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GAT1400Domain"),&pucStrTmp);
        MOS_STRNCPY(Config_GetCamaraMng()->ucGAT1400Domain, pucStrTmp, sizeof(Config_GetCamaraMng()->ucGAT1400Domain));
        // MOS_PRINTF("%s:%d: GAT1400Domain:%s \r\n", __FUNCTION__, __LINE__, Config_GetCamaraMng()->ucGAT1400Domain);

        // 外接扬声器连接状态(音柱), 0.不在线，1.在线
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"ExternalSpeakerStatus"),(_INT*)&Config_GetCamaraMng()->uiExternalSpeakerStatus);
        // 音柱信息 数组
        hArry = Adpt_Json_GetObjectItem(hRoot,(_UC*)"ExternalSpeakers");
        {
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"CTEI"),&pucStrTmp);
            MOS_STRLCPY(Config_GetCamaraMng()->stExternalSpeakerInfo.aucCTEI, pucStrTmp, sizeof(Config_GetCamaraMng()->stExternalSpeakerInfo.aucCTEI));
            //MOS_PRINTF("%s:%d: CTEI:%s \r\n", __FUNCTION__, __LINE__, Config_GetCamaraMng()->stExternalSpeakerInfo.aucCTEI);

            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"FWVER"),&pucStrTmp);
            MOS_STRLCPY(Config_GetCamaraMng()->stExternalSpeakerInfo.aucFwVer, pucStrTmp, sizeof(Config_GetCamaraMng()->stExternalSpeakerInfo.aucFwVer));
            //MOS_PRINTF("%s:%d: FWVER:%s \r\n", __FUNCTION__, __LINE__, Config_GetCamaraMng()->stExternalSpeakerInfo.aucFwVer);

            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"UID"),&pucStrTmp);
            MOS_STRLCPY(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevUID, pucStrTmp, sizeof(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevUID));
            //MOS_PRINTF("%s:%d: UID:%s \r\n", __FUNCTION__, __LINE__, Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevUID);

            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"SN"),&pucStrTmp);
            MOS_STRLCPY(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevSN, pucStrTmp, sizeof(Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevSN));
            //MOS_PRINTF("%s:%d: SN:%s \r\n", __FUNCTION__, __LINE__, Config_GetCamaraMng()->stExternalSpeakerInfo.aucDevSN);
        }

        // 超级编码开关状态 0关闭，1打开
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SuperCodesStatus"),(_INT*)&Config_GetCamaraMng()->uiSuperCodesStatus);

        // 音频流参数
        hObjetItem = Adpt_Json_GetObjectItem(hRoot,(_UC*)"AudioParam");
        if(hObjetItem)
        {
            // 编码模式  PCM16 0x01、G711A 0x02、G711U 0x04
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"EncType"),(_INT*)&Config_GetCamaraMng()->stAudioParm.uiEncodeType);
            // 采样率 例如8000
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"SampleRate"),(_INT*)&Config_GetCamaraMng()->stAudioParm.uiSampleRate);
            // 声道数
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Channel"),(_INT*)&Config_GetCamaraMng()->stAudioParm.uiChannel);
            // 深度
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Depth"),(_INT*)&Config_GetCamaraMng()->stAudioParm.uiDepth);
        }

        // 事件云存追加参数
        hObjetItem = Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudInf");
        if(hObjetItem)
        {
            hEventCloudObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"EventCloudSwitch");
            if (hEventCloudObject)
            {
                Adpt_Json_GetIntegerEx(hEventCloudObject,(_INT*)&Config_GetCamaraMng()->iEventCloudSwitch);
            }
            hEventCloudObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"EventCloudMaxTime");
            if (hEventCloudObject)
            {
                Adpt_Json_GetIntegerEx(hEventCloudObject,(_INT*)&Config_GetCamaraMng()->iEventCloudMaxTime);
            }
            hEventCloudObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"EventCloudMinTime");
            if (hEventCloudObject)
            {
                Adpt_Json_GetIntegerEx(hEventCloudObject,(_INT*)&Config_GetCamaraMng()->iEventCloudMinTime);
            }
            hEventCloudObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"EventCloudDetectTime");
            if (hEventCloudObject)
            {
                Adpt_Json_GetIntegerEx(hEventCloudObject,(_INT*)&Config_GetCamaraMng()->iEventCloudDetectTime);
            }
            hEventCloudObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"EventCloudAppendTime");
            if (hEventCloudObject)
            {
                Adpt_Json_GetIntegerEx(hEventCloudObject,(_INT*)&Config_GetCamaraMng()->iEventCloudAppendTime);
            }
        }

        // 带屏设备屏幕硬件属性
        hObjetItem = Adpt_Json_GetObjectItem(hRoot,(_UC*)"ScreenHardwareInf");
        if(hObjetItem)
        {
            JSON_HANDLE hScreenSizeObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"ScreenSize");
            if (hScreenSizeObject)
            {
                Adpt_Json_GetDouble_Ex(hScreenSizeObject, &Config_GetCamaraMng()->stScreenHardwareInf.dScreenSize);
            }

            JSON_HANDLE hResolutionObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Resolution");
            if (hResolutionObject)
            {
                Adpt_Json_GetIntegerEx(hResolutionObject, (_INT*)&Config_GetCamaraMng()->stScreenHardwareInf.uiResolution);
            }

            JSON_HANDLE hWidthObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Width");
            if (hWidthObject)
            {
                Adpt_Json_GetIntegerEx(hWidthObject, (_INT*)&Config_GetCamaraMng()->stScreenHardwareInf.uiWidth);
            }

            JSON_HANDLE hHeightObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Height");
            if (hHeightObject)
            {
                Adpt_Json_GetIntegerEx(hHeightObject, (_INT*)&Config_GetCamaraMng()->stScreenHardwareInf.uiHeight);
            }

            JSON_HANDLE hDpiObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Dpi");
            if (hDpiObject)
            {
                Adpt_Json_GetIntegerEx(hDpiObject, (_INT*)&Config_GetCamaraMng()->stScreenHardwareInf.uiDpi);
            }

            JSON_HANDLE hSupportTouchFlagObject = Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"SupportTouchFlag");
            if (hSupportTouchFlagObject)
            {
                Adpt_Json_GetIntegerEx(hSupportTouchFlagObject, (_INT*)&Config_GetCamaraMng()->stScreenHardwareInf.uiSupportTouchFlag);
            }
        }

        // 双向视频通话对端出流信息
        hObjetItem = Adpt_Json_GetObjectItem(hRoot,(_UC*)"VideoPlayInf");
        if(hObjetItem)
        {
            // 分辨率，见分辨率定义 EN_ZJ_CARERA_RESOLUTION_ABILITY
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Resolution"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiResolution);
            // 宽
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Width"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiWidth);
            // 高
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Height"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiHeight);
            // 编码类型
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"EncType"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiEncodeType);
            // Smart编码标记 0.不支持Smart编码;1.支持Smart编码
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"SmartEncFlag"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiSmartEncFlag);
            // 编码质量，VBR编码方式时 1.标准质量;2.质量
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Quality"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiQuality);
            // 帧率
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"FrameRate"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiFramerate);
            // 码率，见码率定义; CBR编码方式 EN_ZJ_CAMERA_BITRATE_TYPE
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"BitRate"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiBitrate);
            // 编码方式 0.CBR 1.VBR
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"RateType"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiRateType);
            // I帧间隔  50帧、100帧、200帧
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"FrameInterval"),(_INT*)&Config_GetCamaraMng()->stVideoPlayInf.uiFrameInterval);
        }
    }

    // 视频流参数 数组
    hArry = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Streamers");
    iArrySize = Adpt_Json_GetArraySize(hArry);
    for(i = 0; i < iArrySize; i++)
    {
        hArryObject = Adpt_Json_GetArrayItem(hArry,i);
        pstStreamerNode = (ST_CFG_STREAMER_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_STREAMER_NODE));
        if(pstStreamerNode == MOS_NULL)
        {
            continue;
        }
        pstVideoDes = &pstStreamerNode->stVideoDes;
        // 码流序列号，从0开始计数
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"StreamID"),(_INT*)&pstStreamerNode->uiStreamId);
        if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
        {
            // 支持分辨率类型,枚举类型 EN_ZJ_CARERA_RESOLUTION_ABILITY
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"ResolutionAbility"),(_INT*)&pstStreamerNode->uiResolutionAbility);
            // 支持视频编码类型  0x01.JPEG图片编码模式, 0x02.H264编码，0x04.H265编码
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"VideoEncAbility"),(_INT*)&pstStreamerNode->uiCapAbility);
        }
        if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
        {
            // 分辨率，见分辨率定义 EN_ZJ_CARERA_RESOLUTION_ABILITY
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Resolution"),(_INT*)&pstVideoDes->stVideoPara.uiResolution);
            // 宽
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Width"),(_INT*)&pstVideoDes->stVideoPara.uiWidth);
            // 高
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Height"),(_INT*)&pstVideoDes->stVideoPara.uiHeight);
            // 编码类型
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"EncType"),(_INT*)&pstVideoDes->stVideoPara.uiEncodeType);
            // Smart编码标记 0.不支持Smart编码;1.支持Smart编码
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"SmartEncFlag"),(_INT*)&pstVideoDes->stVideoPara.uiSmartEncFlag);
            // 编码质量，VBR编码方式时 1.标准质量;2.质量
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Quality"),(_INT*)&pstVideoDes->stVideoPara.uiQuality);
            // 帧率
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"FrameRate"),(_INT*)&pstVideoDes->stVideoPara.uiFramerate);
            // 码率，见码率定义; CBR编码方式 EN_ZJ_CAMERA_BITRATE_TYPE
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"BiteRate"),(_INT*)&pstVideoDes->stVideoPara.uiBitrate);
            // 编码方式 0.CBR 1.VBR
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"RateType"),(_INT*)&pstVideoDes->stVideoPara.uiRateType);
            // I帧间隔  50帧、100帧、200帧
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"FrameInterval"),(_INT*)&pstVideoDes->stVideoPara.uiFrameInterval);

            // 当为鱼眼镜头，且参数为圆心半径矫正时
            hObjetItem = Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Circle");
            if(hObjetItem)
            {
                // 角度
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Angle"),&pstVideoDes->stCircle.doubleAngle);
                // 半径
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Radius"),(_INT*)&pstVideoDes->stCircle.uiRadius);
                // 圆心坐标X，若为720度，标识第一个圆
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"C1X"),(_INT*)&pstVideoDes->stCircle.uiCc1x);
                // 圆心坐标Y，若为720度，标识第一个圆
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"C1Y"),(_INT*)&pstVideoDes->stCircle.uiCc1Y);
                // 圆心坐标X，若为720度，标识第一个圆
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"C2X"),(_INT*)&pstVideoDes->stCircle.uiCc2x);
                // 圆心坐标Y，若为720度，标识第二个圆
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"C2Y"),(_INT*)&pstVideoDes->stCircle.uiCc2Y);
            }

            // 当为鱼眼镜头，且参数为扭曲度矫正时
            hObjetItem = Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Distortion");
            if(hObjetItem)
            {
                // 镜头光轴与图像圆心的水平偏移
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Fx"),&pstVideoDes->stDistortion.fx);
                // 镜头光轴与图像圆心的垂直偏移
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Fy"),&pstVideoDes->stDistortion.fy);
                // 桶形畸变矫正参数
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Fa"),&pstVideoDes->stDistortion.a);
                // 枕形畸变矫正参数
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Fb"),&pstVideoDes->stDistortion.b);
                // 图像缩放因子
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Scale"),&pstVideoDes->stDistortion.scale);
            }
        }
        MOS_LIST_ADDTAIL(&Config_GetCamaraMng()->stStreamerList, pstStreamerNode);
    }

    JSON_HANDLE hExDevInsertStatusInf = Adpt_Json_GetObjectItem(hRoot, (_UC*)"ExDevInsertStatusInf");
    if (hExDevInsertStatusInf)
    {
        // 轮训json的外接设备插入状态值，更新到List
        JSON_HANDLE hChild = Adpt_Json_GetChild(hExDevInsertStatusInf);
        while (hChild != MOS_NULL)
        {
            _INT iInsertStatus = 0;
            _UC *pucExDevName  = MOS_NULL;            
            Adpt_Json_GetName(hChild, &pucExDevName);
            if ((pucExDevName) && (MOS_STRSTRTAIL(pucExDevName, "Status") != 0))
            {
                Adpt_Json_GetIntegerEx(hChild, &iInsertStatus);
                Config_UpdateCommonExDevInsertStatus(pucExDevName, iInsertStatus);
            }
            hChild = Adpt_Json_GetNext(hChild);
        }
    }

    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

// 通用外接设备插入状态   0.未插入 1.已插入
_INT Config_SeCommonExDevInsertStatus(_UC *pucExDevName, _INT iInsertStatus)
{
    if ((pucExDevName == MOS_NULL) || (MOS_STRLEN(pucExDevName) == 0))
    {
        MOS_LOG_ERR(CFG_LOGSTR, "ExDevName is null");
        return MOS_ERR;
    }

    if(Config_UpdateCommonExDevInsertStatus(pucExDevName, iInsertStatus) == MOS_TRUE)
    {
        Config_GetItemSign()->ucSaveCamInf   = 1;
        Config_GetItemSign()->ucCfgCamUpdate = 1;
    }
    return MOS_OK;
}