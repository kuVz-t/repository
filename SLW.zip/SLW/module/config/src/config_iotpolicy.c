#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "cloudstg_type.h"
#include "kjiot_device_type.h"

ST_MOS_LIST *Config_GetAlarmPolicyList()
{
    return &Config_GetlocalCfgInf()->stIotPolicyList;
}

// 查找告警IoT策略节点 alarm Node
ST_CFG_ALARMPOLICY_NODE *Config_FindAlarmPolicyNode(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPolicyId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_ALARMPOLICY_NODE *pstIotPolicyNode = MOS_NULL;

    FOR_EACHDATA_INLIST(Config_GetAlarmPolicyList(), pstIotPolicyNode, stIterator)
    {
        if(pstIotPolicyNode->uiKjIoTType == uiKjIoTType && pstIotPolicyNode->lluKjIotId == lluKjIoTId
            && pstIotPolicyNode->uiPolicyId == uiPolicyId && pstIotPolicyNode->uiUseFlag)
        {
            pstIotPolicyNode->uiUseFlag = 1;
            break;
        }
    }
    return pstIotPolicyNode;
}

// 创建/查找告警IoT策略节点
ST_CFG_ALARMPOLICY_NODE *Config_FindAndCreatAlarmPolicyNode(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPolicyId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmTmpNode = MOS_NULL;

    FOR_EACHDATA_INLIST(Config_GetAlarmPolicyList(), pstAlarmNode, stIterator)
    {
        if(pstAlarmNode->uiKjIoTType == uiKjIoTType && pstAlarmNode->lluKjIotId == lluKjIoTId
            && pstAlarmNode->uiPolicyId == uiPolicyId && pstAlarmNode->uiUseFlag)
        {
            pstAlarmNode->uiUseFlag = 1;
            return pstAlarmNode;
        }
        else if(pstAlarmNode->uiUseFlag == 0)
        {
            pstAlarmTmpNode = pstAlarmNode;
        }
    }
    if(pstAlarmTmpNode == MOS_NULL)
    {
        pstAlarmTmpNode = (ST_CFG_ALARMPOLICY_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_ALARMPOLICY_NODE));
        MOS_LIST_ADDTAIL(Config_GetAlarmPolicyList(), pstAlarmTmpNode);
    }
    pstAlarmTmpNode->uiOpenFlag  = 1;
    pstAlarmTmpNode->uiKjIoTType = uiKjIoTType;
    pstAlarmTmpNode->lluKjIotId  = lluKjIoTId;
    pstAlarmTmpNode->uiPolicyId  = uiPolicyId;
    pstAlarmTmpNode->uiUseFlag   = 1;
    MOS_LOG_INF(CFG_LOGSTR, "alarm policy add new policyid %u IoTType:%u", uiPolicyId, uiKjIoTType);
    return pstAlarmTmpNode;
}

// 删除IOT设备策略类型
_INT Config_DeleteAlarmPolicyNode(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPolicyId)
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_OUTPUT_NODE    *pstOutputNode     = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode    = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode    = MOS_NULL;
    
    pstAlarmNode = Config_FindAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiPolicyId);
    if(pstAlarmNode == MOS_NULL)
    {
        return MOS_OK;
    }
    // FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode,stIterator)
    // {
    //     FOR_EACHDATA_INLIST(&pstEventNode->stOutputList, pstOutputNode,stIterator1)
    //     {
    //         pstOutputNode->uiUseFlag = 0;
    //     }
    //     pstEventNode->uiUseFlag = 0;
    // } 
    pstAlarmNode->uiUseFlag = 0;
    pstAlarmNode->uiKjIoTType = 0;
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
    return MOS_OK;
}

// 查找 告警IoT策略的事件 的 节点
ST_CFG_POLICYEVENT_NODE *Config_FindAlarmEventNode(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId)
{
    MOS_PARAM_NULL_RETNULL(pstAlarmNode);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_POLICYEVENT_NODE *pstEventNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator)
    {
        if(pstEventNode->uiUseFlag && pstEventNode->uiKjIoTEventId == uiKjIoTEventId)
        {
            pstEventNode->uiUseFlag = 1;
            break;
        }
    }
    return pstEventNode;
}
// 添加/查找 告警IoT策略的事件 的 节点
ST_CFG_POLICYEVENT_NODE *Config_FindAndCreatAlarmEventNode(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId)
{
    MOS_PARAM_NULL_RETNULL(pstAlarmNode);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_POLICYEVENT_NODE *pstEventNode = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventTmpNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator)
    {
        if(pstEventNode->uiUseFlag && pstEventNode->uiKjIoTEventId == uiKjIoTEventId)
        {
            pstEventNode->uiUseFlag = 1;
            return pstEventNode;
        }
        else if(pstEventNode->uiUseFlag == 0)
        {
            pstEventTmpNode = pstEventNode;
        }
    }
    if(pstEventTmpNode == MOS_NULL)
    {
        pstEventTmpNode = (ST_CFG_POLICYEVENT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_POLICYEVENT_NODE));
        MOS_LIST_ADDTAIL(&pstAlarmNode->stEventList, pstEventTmpNode);
    }
    pstEventTmpNode->uiKjIoTEventId = uiKjIoTEventId;
    pstEventTmpNode->uiUseFlag = 1;
    MOS_LOG_INF(CFG_LOGSTR,"alarm policyid %u add new IoTType:%u event %u", pstAlarmNode->uiPolicyId, pstAlarmNode->uiKjIoTType, uiKjIoTEventId);
    return pstEventTmpNode;
}
// 删除 告警IoT策略的事件 的 节点
_INT Config_DelAlarmEventNode(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId)
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_OUTPUT_NODE    *pstOutputNode     = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode    = MOS_NULL;
    // ST_CFG_ALARMPOLICY_NODE *pstAlarmNode    = MOS_NULL;
    
    // pstAlarmNode = Config_FindAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiPolicyId);
    // if(pstAlarmNode == MOS_NULL)
    // {
    //     return MOS_OK;
    // }
    FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode,stIterator)
    {
        if (pstEventNode->uiKjIoTEventId == uiKjIoTEventId)
        {
            FOR_EACHDATA_INLIST(&pstEventNode->stOutputList, pstOutputNode,stIterator1)
            {
                pstOutputNode->uiUseFlag = 0;
            }
            pstEventNode->uiUseFlag = 0;
        }
    }
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
    return MOS_OK;
}

_INT Config_SetAlarmPolicyOpenFlag(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiOpenFlag)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);

    if(pstAlarmNode->uiOpenFlag == uiOpenFlag)
    {
        return MOS_OK;
    }
    pstAlarmNode->uiOpenFlag = uiOpenFlag;
    Config_GetItemSign()->ucSaveAlarmPolicy   = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"alarm policy set policyid %u open flag %u",pstAlarmNode->uiPolicyId,uiOpenFlag);
    return MOS_OK;
}

_INT Config_SetAlarmPolicyProp(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UC *pucProp)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);
    MOS_PARAM_NULL_RETERR(pucProp);

    _UI uiPropLen = 0;
    
    if(pucProp == MOS_NULL)
    {
        pucProp = (_UC*)"";
    }  
    uiPropLen = MOS_STRLEN(pucProp);
    if(MOS_STRCMP(pstAlarmNode->pucProp,pucProp) == 0)
    {
        return MOS_OK;
    }     
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    if(pstAlarmNode->uiPropLen < uiPropLen)
    {
        MOS_FREE(pstAlarmNode->pucProp);
        pstAlarmNode->uiPropLen = uiPropLen + 128;
        pstAlarmNode->pucProp  = (_UC*)MOS_MALLOCCLR(pstAlarmNode->uiPropLen);
    }
    MOS_STRNCPY(pstAlarmNode->pucProp, pucProp, pstAlarmNode->uiPropLen);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR,"alarm policy set KjIoTType:%u policyid %u prop %s", pstAlarmNode->uiKjIoTType,pstAlarmNode->uiPolicyId,pucProp);
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
    return MOS_OK;
}

_UC* Config_GetAlarmPolicyProp(_UI uiKjIoTType, _LLID lluKjIoTId, _UI uiPolicyId)
{
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = Config_FindAlarmPolicyNode(uiKjIoTType, lluKjIoTId, uiPolicyId);
    if(pstAlarmNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR, "pstAlarmNode == MOS_NULL");
        return MOS_NULL;
    }
    else if(pstAlarmNode->pucProp == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR, "pstAlarmNode->pucProp == MOS_NULL");
        return MOS_NULL;
    }

    return pstAlarmNode->pucProp;
}

/*
1000:
	1)pucDelProp==null && pucObjName != null 删除Motion、Human、Face、Car、Fence字段(删除1000的第一层字段)
	2)pucDelProp!=null && pucObjName != null 删除Motion、Human、Face、Car、Fence里的属性字段(删除1000的第二层字段)

非1000：
	1)pucDelProp!=null && pucObjName == null 删除非1000的IoT的第一层的属性字段
*/
// 删除报警策略属性 (字段)
_INT Config_DelAlarmPolicyProp(_UI uiAIIoTType, _LLID lluAIIoTID, _UI uiAIIoTEventId, _UC* pucDelProp, _UC* pucObjName)
{
    _UI uiDelPorpFlag                     = 0;
    _UC *pucNewIoTProp                    = MOS_NULL;
    JSON_HANDLE hDelPorpJson              = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = MOS_NULL;

    // 获取报警策略属性
    if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        pstAlarmNode = Config_FindAlarmPolicyNode(uiAIIoTType, lluAIIoTID, IOT_DEFAULT_POLICYID_MOTION);
    }
    else
    {
        pstAlarmNode = Config_FindAlarmPolicyNode(uiAIIoTType, lluAIIoTID, uiAIIoTType);
    }
    if (pstAlarmNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR, "pstAlarmNode is Null! uiAIIoTType = %u", uiAIIoTType);
        return MOS_ERR;
    }

    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR, "Before DelPolicyProp:%s", pstAlarmNode->pucProp);
    JSON_HANDLE hBodyJson = Adpt_Json_Parse(pstAlarmNode->pucProp);
    if (hBodyJson)
    {
        // 1000 MOTION  Motion Human Face Car CarNum Fence
        if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
        {
            if (pucObjName == MOS_NULL)
            {
                MOS_LOG_ERR(CFG_LOGSTR, "pucObjName is Null");
                Adpt_Json_Delete(hBodyJson);
                Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                return MOS_ERR;   
            }

            JSON_HANDLE hDelObjNameJson = Adpt_Json_GetObjectItem(hBodyJson, pucObjName);
            if (hDelObjNameJson)
            {
                // 删除1000的Motion Face Human Car的属性字段
                if (pucDelProp != MOS_NULL)
                {
                    // 判断当前属性是否具有删除的字段
                    hDelPorpJson = Adpt_Json_GetObjectItem(hDelObjNameJson, pucDelProp);
                    if (hDelPorpJson)
                    {
                        uiDelPorpFlag = 1;
                        Adpt_Json_DeleteItemFromObject(hDelObjNameJson, pucDelProp);
                        MOS_LOG_INF(CFG_LOGSTR, "%s DelObjName:%s", pucObjName, pucDelProp);
                    }
                }
                else // 删除1000的Motion Face Human Car字段
                {
                    uiDelPorpFlag = 1;
                    Adpt_Json_DeleteItemFromObject(hBodyJson, pucObjName);
                }
            }
        }
        else
        {
            // 判断当前属性是否具有删除的字段
            hDelPorpJson = Adpt_Json_GetObjectItem(hBodyJson, pucDelProp);
            if (hDelPorpJson)
            {
                uiDelPorpFlag = 1;
                Adpt_Json_DeleteItemFromObject(hBodyJson, pucDelProp);
            }
        }

        if (1 == uiDelPorpFlag)
        {
            pucNewIoTProp = Adpt_Json_Print(hBodyJson);
            if (pucNewIoTProp)
            {
                // 把删除字段后的属性添加到策略属性
                MOS_MEMSET(pstAlarmNode->pucProp, 0x0, pstAlarmNode->uiPropLen);
                MOS_STRNCPY(pstAlarmNode->pucProp, pucNewIoTProp, pstAlarmNode->uiPropLen);

                MOS_LOG_INF(CFG_LOGSTR, "After DelPolicyProp:%s", pstAlarmNode->pucProp);
                Adpt_Json_Delete(hBodyJson);
                Adpt_Json_DePrint(pucNewIoTProp);

                Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);

                Config_GetItemSign()->ucSaveAlarmPolicy   = 1;
                Config_GetItemSign()->ucAlarmPolicyUpdate = 1;

                if(MOS_NULL != pucDelProp)
                {
                    MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu] Del Prop:%s OK", uiAIIoTType, lluAIIoTID, pucDelProp);
                }
                else
                {
                    MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu] Del Prop:%s OK", uiAIIoTType, lluAIIoTID, pucObjName);
                }

                return MOS_OK;
            }
            else
            {
                MOS_LOG_ERR(CFG_LOGSTR, "pucNewPolicyProp is Null");
                Adpt_Json_Delete(hBodyJson);
                Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                return MOS_ERR;
            }
        }
        else
        {
            if(MOS_NULL != pucDelProp)
            {
                MOS_LOG_ERR(CFG_LOGSTR, "InIot[%u %llu] Del Prop:%s No Exist", uiAIIoTType, lluAIIoTID, pucDelProp);
            }
            else
            {
                MOS_LOG_ERR(CFG_LOGSTR, "InIot[%u %llu] Del Prop:%s No Exist", uiAIIoTType, lluAIIoTID, pucObjName);
            }

            Adpt_Json_Delete(hBodyJson);
            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
            return MOS_ERR;
        }
    }
    else
    {
        MOS_LOG_ERR(CFG_LOGSTR, "hBodyJson is Null");
        Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
        return MOS_ERR;
    }
}

_INT Config_SetAlarmPolicyName(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UC *pucPolicyName)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);
    MOS_PARAM_NULL_RETERR(pucPolicyName);

    if(MOS_STRCMP(pstAlarmNode->aucPolicyName,pucPolicyName) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(pstAlarmNode->aucPolicyName,pucPolicyName,sizeof(pstAlarmNode->aucPolicyName));
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
    return MOS_OK;
}

_INT Config_SetAlarmPolicyTime(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiSnapFlag,_UI uiWeekFlag,_UI StartTime,_UI uiEndTime)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);

    if(pstAlarmNode->uiEndTime == uiEndTime && pstAlarmNode->uiStartTime == StartTime
        && pstAlarmNode->uiWeekFlag  == uiWeekFlag && pstAlarmNode->uiSpanFlag  == uiSnapFlag)
    {
        return MOS_OK;
    }
    pstAlarmNode->uiSpanFlag  = uiSnapFlag;
    pstAlarmNode->uiEndTime   = uiEndTime;
    pstAlarmNode->uiStartTime = StartTime;
    pstAlarmNode->uiWeekFlag  = uiWeekFlag;
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
    return MOS_OK;
}

// 事件的输出节点
ST_CFG_OUTPUT_NODE *Config_FindEventOutNode(ST_CFG_POLICYEVENT_NODE *pstEevntNode,_UI uiDevType,_LLID lluDevId)
{
    MOS_PARAM_NULL_RETNULL(pstEevntNode);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstEevntNode->stOutputList, pstOutputNode, stIterator)
    {
        if(pstOutputNode->uiUseFlag && pstOutputNode->uiKjIoTType == uiDevType && pstOutputNode->lluKjIotId == lluDevId)
        {
            break;
        }
    }
    return pstOutputNode;
}

// 设置响应IoT的OutPut属性
_INT Config_SetOutputDevParam(ST_CFG_OUTPUT_NODE *pstOutputNode, _UC *pucParam)
{
    _INT ret = MOS_ERR;
    MOS_PARAM_NULL_RETERR(pstOutputNode);

    if(pucParam == MOS_NULL)
    {
        pucParam = (_UC*)"";
    }
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    if(pstOutputNode->uiParamLen < MOS_STRLEN(pucParam))
    {
        pstOutputNode->uiParamLen =  MOS_STRLEN(pucParam) + 128;
        MOS_FREE(pstOutputNode->pucParam);
        pstOutputNode->pucParam = (_UC*)MOS_MALLOCCLR(pstOutputNode->uiParamLen );
    }
    if(MOS_STRCMP(pstOutputNode->pucParam, pucParam) != 0)
    {
        ret = MOS_OK;
        MOS_STRNCPY(pstOutputNode->pucParam, pucParam, pstOutputNode->uiParamLen);
    }
    else
    {
        ret = MOS_ERR;
    }
    pstOutputNode->uiSetDefaultFalg = 1;
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    return ret;
}

// 添加告警IoT策略的事件
_INT Config_AddAlarmPolicyEvent(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode, _UI uiKjIoTEventId)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);
    
    // 添加/查找 告警IoT策略的事件 的 节点
    Config_FindAndCreatAlarmEventNode(pstAlarmNode,uiKjIoTEventId);
    return MOS_OK;
}

// 删除告警IoT策略的事件
_INT Config_DelAlarmPolicyEvent(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode, _UI uiKjIoTEventId)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);
    
    // 删除 告警IoT策略的事件 的 节点
    Config_DelAlarmEventNode(pstAlarmNode, uiKjIoTEventId);
    return MOS_OK;
}

// 告警IOT设备 策略增加 联动响应的IOT设备
_INT Config_AddAlarmPolicyOutput(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiKjIoTEventId, _UI uiOutIotType,_LLID lluOutIotId,_UC *pucParam)
{
    _INT ret = MOS_ERR;
    ST_CFG_OUTPUT_NODE  *pstOutputNode      = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;

    MOS_PARAM_NULL_RETERR(pstAlarmNode);

    if(pucParam == MOS_NULL)
    {
        pucParam = (_UC*)"";
    }
    // 查找 告警IoT策略的事件 的 节点
    pstEventNode = Config_FindAlarmEventNode(pstAlarmNode,uiKjIoTEventId);
    if(pstEventNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    // 添加/查找 告警IoT策略的事件 的 响应IoT的OutPut节点
    pstOutputNode = Config_FindAndCreatOutNode(&pstEventNode->stOutputList,uiOutIotType,lluOutIotId);
    if (pstOutputNode)
    {
        // 设置响应IoT的OutPut属性
        ret = Config_SetOutputDevParam(pstOutputNode,pucParam);
        if (MOS_OK == ret)
        {
            Config_GetItemSign()->ucSaveAlarmPolicy   = 1;
            Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
        }
    }
    return MOS_OK;
}

// 告警IOT设备 策略删除 联动响应的IOT设备
_INT Config_DeleteAlarmPolicyOutPut(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode, _UI uiKjIoTEventId, _UI uiOutIotType,_LLID lluOutIotId)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_OUTPUT_NODE  *pstOutputNode      = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    // 查找 告警IoT策略的事件 的 节点
    pstEventNode = Config_FindAlarmEventNode(pstAlarmNode,uiKjIoTEventId);
    if(MOS_NULL == pstEventNode)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"MOS_NULL == pstEventNode");
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstEventNode->stOutputList, pstOutputNode, stIterator)
    {
        if(pstOutputNode->uiUseFlag && pstOutputNode->uiKjIoTType == uiOutIotType  && pstOutputNode->lluKjIotId == lluOutIotId)
        {
            pstOutputNode->uiUseFlag   = 0;
            pstOutputNode->uiKjIoTType = 0;
            pstOutputNode->lluKjIotId  = 0;
            pstOutputNode->uiParamLen  = 0;
            pstOutputNode->uiSetDefaultFalg = 0;
            MOS_FREE(pstOutputNode->pucParam);
            pstOutputNode->pucParam = MOS_NULL;
            break;
        }
    }
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
    return MOS_OK;
}

_INT Config_AddAlarmPolicyOutputScene(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode, _UI uiKjIoTEventId, _UI uiSceneId)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);

    // 查找 告警IoT策略的事件 的 节点
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    pstEventNode = Config_FindAlarmEventNode(pstAlarmNode,uiKjIoTEventId);
    if(pstEventNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"MOS_NULL == pstAlarmNode");
        return MOS_ERR;
    }
    if(pstEventNode->uiScenceId == uiSceneId)
    {
        return MOS_OK;
    }
    pstEventNode->uiScenceId = uiSceneId;
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
    return MOS_OK;
}

// 增加 联动响应的IOT设备的动作属性(字段)
_INT Config_AddAlarmPolicyOutputProp(_UI uiInIoTType,  _LLID lluInIoTId, _UI uiInIoTEventId,
                                     _UI uiOutIoTType, _LLID lluOutIoTId,
                                     _UC* pucAddOutputProp, _UI uiValue)
{
    MOS_PARAM_NULL_RETERR(pucAddOutputProp);
    ST_CFG_OUTPUT_NODE  *pstOutputNode      = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    // 查找告警IoT策略节点
    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiInIoTType, lluInIoTId, uiInIoTType);    
    if(pstAPolicyNode)
    {
        // 查找 告警IoT策略的事件 的 节点
        pstEventNode = Config_FindAlarmEventNode(pstAPolicyNode, uiInIoTEventId);
        if(pstEventNode)
        {
            // 添加/查找 告警IoT策略的事件 的 响应IoT的OutPut节点
            pstOutputNode = Config_FindAndCreatOutNode(&pstEventNode->stOutputList, uiOutIoTType, lluOutIoTId);
            if (pstOutputNode)
            {
                // 设置响应IoT的OutPut属性
                Mos_MutexLock(&Config_Task_GetMng()->hMutex);
                MOS_LOG_INF(CFG_LOGSTR, "Before AddOutputProp:%s", pstOutputNode->pucParam);
                JSON_HANDLE hBodyJson = Adpt_Json_Parse(pstOutputNode->pucParam);
                if (hBodyJson)
                {
                    // 判断当前属性是否具有添加的字段
                    JSON_HANDLE hAddOutputPorpJson = Adpt_Json_GetObjectItem(hBodyJson, pucAddOutputProp);
                    if (hAddOutputPorpJson == MOS_NULL)
                    {
                        // 属性添加pucAddProp字段和uiValue值
                        Adpt_Json_AddItemToObject(hBodyJson, pucAddOutputProp, Adpt_Json_CreateStrWithNum(uiValue));

                        _UC *pucNewOutputProp = MOS_NULL;
                        pucNewOutputProp = Adpt_Json_Print(hBodyJson);
                        if (pucNewOutputProp)
                        {
                            // 把添加字段后的属性添加到IOT的属性
                            _UI uiNewIoTPropLen = MOS_STRLEN(pucNewOutputProp);
                            if(pstOutputNode->uiParamLen < uiNewIoTPropLen)
                            {
                                MOS_FREE(pstOutputNode->pucParam);
                                pstOutputNode->uiParamLen = uiNewIoTPropLen + 128;  
                                pstOutputNode->pucParam = (_UC*)MOS_MALLOCCLR(pstOutputNode->uiParamLen);
                            }
                            MOS_STRNCPY(pstOutputNode->pucParam, pucNewOutputProp, pstOutputNode->uiParamLen);
                            MOS_LOG_INF(CFG_LOGSTR, "After AddOutputProp:%s", pstOutputNode->pucParam);
                            Adpt_Json_Delete(hBodyJson);
                            Adpt_Json_DePrint(pucNewOutputProp);

                            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                            Config_GetItemSign()->ucSaveAlarmPolicy = 1;
                            Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
                            MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu %u] Add OutIot[%u %llu] OutPutProp:%s Value:%u OK",
                                        uiInIoTType, lluInIoTId, uiInIoTEventId, uiOutIoTType, lluOutIoTId, pucAddOutputProp, uiValue);
                            return MOS_OK;
                        }
                        else
                        {
                            MOS_LOG_ERR(CFG_LOGSTR, "pucNewOutputProp is Null");
                            Adpt_Json_Delete(hBodyJson);
                            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                            return MOS_ERR;
                        }
                    }
                    else
                    {
                        MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu %u] Add OutIot[%u %llu] OutPutProp:%s Already Exist",
                            uiInIoTType, lluInIoTId, uiInIoTEventId, uiOutIoTType, lluOutIoTId, pucAddOutputProp);
                        Adpt_Json_Delete(hBodyJson);
                        Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                        return MOS_ERR;
                    }
                }
                else
                {
                    MOS_LOG_ERR(CFG_LOGSTR, "hBodyJson is Null");
                    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                    return MOS_ERR;
                }
            }
            else
            {
                MOS_LOG_ERR(CFG_LOGSTR, "pstOutputNode is Null");
                return MOS_ERR;               
            }
        }
        else
        {
            MOS_LOG_ERR(CFG_LOGSTR, "pstEventNode is Null");
            return MOS_ERR;           
        }
    }
    else
    {
        MOS_LOG_ERR(CFG_LOGSTR, "pstAPolicyNode is Null");
        return MOS_ERR;
    }
}

 // 删除 联动响应的IOT设备的动作属性(字段)
_INT Config_DelAlarmPolicyOutputProp(_UI uiInIoTType,  _LLID lluInIoTId,  _UI uiInIoTEventId,
                                     _UI uiOutIoTType, _LLID lluOutIoTId, _UC* pucDelOutputProp)
{
    MOS_PARAM_NULL_RETERR(pucDelOutputProp);
    ST_CFG_OUTPUT_NODE  *pstOutputNode      = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;

    // 查找告警IoT策略节点
    if (uiInIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION, lluInIoTId, IOT_DEFAULT_POLICYID_MOTION);
    }
    else
    {
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiInIoTType, lluInIoTId, uiInIoTType);
    }  
    if(pstAPolicyNode)
    {
        // 查找 告警IoT策略的事件 的 节点
        pstEventNode = Config_FindAlarmEventNode(pstAPolicyNode, uiInIoTEventId);
        if(pstEventNode)
        {
            // 添加/查找 告警IoT策略的事件 的 响应IoT的OutPut节点
            pstOutputNode = Config_FindAndCreatOutNode(&pstEventNode->stOutputList, uiOutIoTType, lluOutIoTId);
            if (pstOutputNode)
            {
                // 设置响应IoT的OutPut属性
                Mos_MutexLock(&Config_Task_GetMng()->hMutex);
                MOS_LOG_INF(CFG_LOGSTR, "Before DelOutputProp:%s", pstOutputNode->pucParam);
                JSON_HANDLE hBodyJson = Adpt_Json_Parse(pstOutputNode->pucParam);
                if (hBodyJson)
                {
                    // 判断当前属性是否具有添加的字段
                    JSON_HANDLE hDelOutputPorpJson = Adpt_Json_GetObjectItem(hBodyJson, pucDelOutputProp);
                    if (hDelOutputPorpJson)
                    {
                        Adpt_Json_DeleteItemFromObject(hBodyJson, pucDelOutputProp);

                        _UC *pucNewIoTProp = MOS_NULL;
                        pucNewIoTProp = Adpt_Json_Print(hBodyJson);
                        if (pucNewIoTProp)
                        {
                            // 把删除字段后的属性添加到IOT的属性
                            MOS_MEMSET(pstOutputNode->pucParam, 0x0, pstOutputNode->uiParamLen);
                            MOS_STRNCPY(pstOutputNode->pucParam, pucNewIoTProp, pstOutputNode->uiParamLen);
                            MOS_LOG_INF(CFG_LOGSTR, "After DelIoTProp:%s", pstOutputNode->pucParam);
                            Adpt_Json_Delete(hBodyJson);
                            Adpt_Json_DePrint(pucNewIoTProp);

                            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                            Config_GetItemSign()->ucSaveAlarmPolicy = 1;
                            Config_GetItemSign()->ucAlarmPolicyUpdate = 1;
                            MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu %u] Del OutIot[%u %llu] OutPutProp:%s OK",
                                        uiInIoTType, lluInIoTId, uiInIoTEventId, uiOutIoTType, lluOutIoTId, pucDelOutputProp);
                            return MOS_OK;
                        }
                        else
                        {
                            MOS_LOG_ERR(CFG_LOGSTR, "pucNewIoTProp is Null");
                            Adpt_Json_Delete(hBodyJson);
                            Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                            return MOS_ERR;
                        }
                    }
                    else
                    {
                        MOS_LOG_INF(CFG_LOGSTR, "InIot[%u %llu %u] Add OutIot[%u %llu] OutPutProp:%s No Exist",
                            uiInIoTType, lluInIoTId, uiInIoTEventId, uiOutIoTType, lluOutIoTId, pucDelOutputProp);
                        Adpt_Json_Delete(hBodyJson);
                        Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                        return MOS_ERR;
                    }
                }
                else
                {
                    MOS_LOG_ERR(CFG_LOGSTR, "hBodyJson is Null");
                    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
                    return MOS_ERR;
                }
            }
            else
            {
                MOS_LOG_ERR(CFG_LOGSTR, "pstOutputNode is Null");
                return MOS_ERR;               
            }
        }
        else
        {
            MOS_LOG_ERR(CFG_LOGSTR, "pstEventNode is Null");
            return MOS_ERR;           
        }
    }
    else
    {
        MOS_LOG_ERR(CFG_LOGSTR, "pstAPolicyNode is Null");
        return MOS_ERR;
    }
}

_INT Config_AlarmPolicyBegainSync()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1,stIterator2;
    ST_CFG_OUTPUT_NODE    *pstOutputNode    = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode   = MOS_NULL;

    FOR_EACHDATA_INLIST(Config_GetAlarmPolicyList(), pstAlarmNode,stIterator)
    {
        if(pstAlarmNode->uiUseFlag == 1)
        {
            pstAlarmNode->uiUseFlag = 2;
        }
        FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator1)
        {
            if(pstEventNode->uiUseFlag == 1)
            {
                pstEventNode->uiUseFlag = 2;
            }
            FOR_EACHDATA_INLIST(&pstEventNode->stOutputList, pstOutputNode,stIterator2)
            {
                if(pstOutputNode->uiUseFlag == 1)
                {   
                    pstOutputNode->uiUseFlag = 2;
                }
            } 
        }
    }
    return MOS_OK;
}

_INT Config_AlarmPolicyEndSync()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1,stIterator2;
    ST_CFG_OUTPUT_NODE    *pstOutputNode    = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode   = MOS_NULL;

    FOR_EACHDATA_INLIST(Config_GetAlarmPolicyList(), pstAlarmNode,stIterator)
    {
        if(pstAlarmNode->uiUseFlag == 2)
        {
            pstAlarmNode->uiUseFlag = 0;
        }
        FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator1)
        {
            if(pstEventNode->uiUseFlag == 2)
            {
                pstEventNode->uiUseFlag = 0;
            }
            FOR_EACHDATA_INLIST(&pstEventNode->stOutputList, pstOutputNode,stIterator2)
            {
                if(pstOutputNode->uiUseFlag == 2)
                {   
                    pstOutputNode->uiUseFlag = 0;
                }
            } 
        }
    }
    return MOS_OK;
}

_INT Config_AlarmPolicyDestroy()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1,stIterator2;
    ST_CFG_OUTPUT_NODE    *pstOutputNode    = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode   = MOS_NULL;

    Mos_MutexLock(&Config_Task_GetMng()->hMutex);  
    FOR_EACHDATA_INLIST(Config_GetAlarmPolicyList(), pstAlarmNode,stIterator)
    {
        MOS_LIST_RMVNODE(Config_GetAlarmPolicyList(), pstAlarmNode);
        FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator1)
        {
            MOS_LIST_RMVNODE(&pstAlarmNode->stEventList, pstEventNode);
            FOR_EACHDATA_INLIST(&pstEventNode->stOutputList, pstOutputNode,stIterator2)
            {
                MOS_LIST_RMVNODE(&pstEventNode->stOutputList, pstOutputNode);
                MOS_FREE(pstOutputNode->pucParam);
                MOS_FREE(pstOutputNode);
            } 
            MOS_FREE(pstEventNode);
        }
        MOS_FREE(pstAlarmNode->pucProp);
        MOS_FREE(pstAlarmNode);
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);  
    MOS_LOG_INF(CFG_LOGSTR,"alarm policy destroy ok");
    return MOS_OK;
}

/************************************************
****************************************************/
_INT Config_AlarmPolicyEventBegainSync(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);

    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode = MOS_NULL;
    
    if(pstAlarmNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator)
    {
        if( pstEventNode->uiUseFlag == 1)//Todo
        {
            pstEventNode->uiUseFlag = 2;
        }
        FOR_EACHDATA_INLIST(&pstEventNode->stOutputList,pstOutputNode,stIterator1)
        {
            if(pstOutputNode->uiUseFlag == 1)
            {
                pstOutputNode->uiUseFlag = 2;
            }
        }
    }
    return MOS_OK;
}   

_INT Config_AlarmPolicyEventEndSync(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);

    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode = MOS_NULL;
    if (MOS_NULL == pstAlarmNode)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"MOS_NULL == pstAlarmNode");
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator)
    {
        if( pstEventNode->uiUseFlag == 2)
        {
            pstEventNode->uiUseFlag = 0;
        }
        FOR_EACHDATA_INLIST(&pstEventNode->stOutputList,pstOutputNode,stIterator1)
        {
            if(pstOutputNode->uiUseFlag == 2)
            {
                pstOutputNode->uiUseFlag = 0;
            }
        }
    }
    return MOS_OK;

}

//获取告警策略的prop
_INT Config_GetMotionSensitive()
{
    _INT iSensitive     = 0;
    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hMotion = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = Config_FindAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID,IOT_DEFAULT_POLICYID_MOTION);
    if(pstAlarmNode != MOS_NULL)
    {
        hRoot   = Adpt_Json_Parse(pstAlarmNode->pucProp);
        hMotion = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Motion");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hMotion,(_UC*)"Sensitive"),(_INT*)&iSensitive);
        Adpt_Json_Delete( hRoot);
    }

    MOS_LOG_INF(CFG_LOGSTR,"motionSensitive of alarm policy is %d",iSensitive);
    return iSensitive;
}

_INT Config_SetMotionSensitive(_INT iSensitive)
{
    _UC *pStrTmp        = MOS_NULL; 
    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hMotion = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = Config_FindAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID,IOT_DEFAULT_POLICYID_MOTION);
    if(pstAlarmNode != MOS_NULL)
    {
        hRoot = Adpt_Json_Parse(pstAlarmNode->pucProp);
        hMotion = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Motion");
        if(hMotion == MOS_NULL)
        {
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;
        }
        else
        {
            Adpt_Json_DeleteItemFromObject(hMotion,(_UC*)"Sensitive");
            Adpt_Json_AddItemToObject(hMotion,(_UC*)"Sensitive",Adpt_Json_CreateStrWithNum(iSensitive));
            pStrTmp = Adpt_Json_Print(hRoot);
            Config_SetAlarmPolicyProp(pstAlarmNode,pStrTmp);
            MOS_FREE(pStrTmp); 
            Adpt_Json_Delete(hRoot);
            MOS_LOG_INF(CFG_LOGSTR,"set motionSensitive %d",iSensitive);
            return MOS_OK;
        }  
    }
    return MOS_ERR;
}

_INT Config_GetHumanTraceSwitch()
{
    _INT iOpenFlag     = 0;
    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hHuman = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = Config_FindAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID,IOT_DEFAULT_POLICYID_MOTION);
    if(pstAlarmNode != MOS_NULL)
    {
        hRoot   = Adpt_Json_Parse(pstAlarmNode->pucProp);
        hHuman = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Human");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hHuman,(_UC*)"Trace"),(_INT*)&iOpenFlag);
        Adpt_Json_Delete( hRoot);
    }

    MOS_LOG_INF(CFG_LOGSTR,"Human Trace is %d",iOpenFlag);
    return iOpenFlag;
}

_INT Config_SetHumanTraceSwitch(_INT iOpenFlag)
{
    _UC *pStrTmp        = MOS_NULL; 
    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hHuman  = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = Config_FindAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID,IOT_DEFAULT_POLICYID_MOTION);
    if(pstAlarmNode != MOS_NULL)
    {
        hRoot = Adpt_Json_Parse(pstAlarmNode->pucProp);
        hHuman = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Human");
        if(hHuman == MOS_NULL)
        {
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;
        }
        else
        {
            Adpt_Json_DeleteItemFromObject(hHuman,(_UC*)"Trace");
            Adpt_Json_AddItemToObject(hHuman,(_UC*)"Trace",Adpt_Json_CreateStrWithNum(iOpenFlag));
            pStrTmp = Adpt_Json_Print(hRoot);
            Config_SetAlarmPolicyProp(pstAlarmNode,pStrTmp);

            MOS_FREE(pStrTmp);            
            MOS_LOG_INF(CFG_LOGSTR,"set Human Trace openFlag %d",iOpenFlag);
        }
        Adpt_Json_Delete(hRoot);
        return MOS_OK;
    }
    return MOS_ERR;
}
_VOID Config_AddCommonDefaultPolicy(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucPolicyName)
{
    _UC aucOutPut[256] = {0};
    ST_CFG_INIOT_NODE *pstIotNode = Config_FindInnerIotDevice(uiKjIoTType,lluKjIoTId);

    if(pstIotNode != MOS_NULL)
    {
        ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiKjIoTType);    
        if(pstAPolicyNode && pstAPolicyNode->pucProp == MOS_NULL)
        {
            Config_SetAlarmPolicyOpenFlag(pstAPolicyNode,1);
            Config_SetAlarmPolicyProp(pstAPolicyNode,"{\"Sensitive\":\"80\",\"Interval\":\"30\"}");
            Config_SetAlarmPolicyName(pstAPolicyNode,pucPolicyName);
            Config_SetAlarmPolicyTime(pstAPolicyNode,0,127,0,86400);

            Config_AddAlarmPolicyEvent(pstAPolicyNode,0);
            MOS_VSNPRINTF(aucOutPut,256,"{\"EmailFlag\":\"0\",\"PushFlag\":\"0\",\"SMSFlag\":\"0\",\"Interval\":\"300\"}");
            Config_AddAlarmPolicyOutput(pstAPolicyNode,0,EN_ZJ_AIIOT_TYPE_EVENT,0,aucOutPut);
            MOS_VSNPRINTF(aucOutPut,256,"{\"CtrlType\":\"1\",\"StreamID\":\"0\",\"Duration\":\"60\"}");
            Config_AddAlarmPolicyOutput(pstAPolicyNode,0,EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0,aucOutPut);
            Config_AddAlarmPolicyOutput(pstAPolicyNode,0,EN_ZJ_AIIOT_TYPE_RECORD,0,aucOutPut);
        }
    }
    return ;
}
static _INT Config_GetVoiceDetectProp(_UI *puiTraceAbility)
{
    JSON_HANDLE hObject = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    ST_CFG_INIOT_NODE* pstIotNode = Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT,0);

    if(pstIotNode == MOS_NULL || pstIotNode->pucProp == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    Mos_MutexLock(&Config_GetInIotMng()->hMutex); 
    hRoot = Adpt_Json_Parse(pstIotNode->pucProp);
    Mos_MutexUnLock(&Config_GetInIotMng()->hMutex);
    
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    hObject = Adpt_Json_GetObjectItem(hRoot, (_UC*)"Trace");
    if(hObject != MOS_NULL && puiTraceAbility){
        *puiTraceAbility = 1;
    }

    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}
_VOID Config_AddDefaultVoicePolicy(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucPolicyName)
{
    ST_CFG_INIOT_NODE *pstInIotNode   = Config_FindInnerIotDevice(uiKjIoTType,lluKjIoTId);
    if(pstInIotNode != MOS_NULL)
    {
        _UI uiTraceFlag = 0;
        ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiKjIoTType);
		Config_GetVoiceDetectProp(&uiTraceFlag);
        if(pstAPolicyNode && pstAPolicyNode->pucProp == MOS_NULL)
        {
            _UC aucBuff[256];
            Config_SetAlarmPolicyOpenFlag(pstAPolicyNode,1);
            
            Config_SetAlarmPolicyName(pstAPolicyNode,pucPolicyName);
            Config_SetAlarmPolicyTime(pstAPolicyNode,0,127,0,86400);
            if(Config_GetInIotMng()->uiPtzAbility > 0 && uiTraceFlag == 1)
            {
                MOS_VSNPRINTF(aucBuff,256,"{\"Status\":\"1\",\"Interval\":\"30\",\"Trace\":\"0\"}");
            }
            else
            {
                MOS_VSNPRINTF(aucBuff,256,"{\"Status\":\"1\",\"Interval\":\"30\"}");
            }
            Config_SetAlarmPolicyProp(pstAPolicyNode,aucBuff);

            Config_AddAlarmPolicyEvent(pstAPolicyNode,0);
            MOS_VSNPRINTF(aucBuff,256,"{\"CtrlType\":\"1\",\"Duration\":\"60\",\"StreamID\":\"0\"}");
            Config_AddAlarmPolicyOutput(pstAPolicyNode,0,EN_ZJ_AIIOT_TYPE_RECORD,0,aucBuff);
            Config_AddAlarmPolicyOutput(pstAPolicyNode,0,EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0,aucBuff);
            MOS_VSNPRINTF(aucBuff,256,"{\"EmailFlag\":\"0\",\"PushFlag\":\"0\",\"SMSFlag\":\"0\",\"Interval\":\"300\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\"}");
            Config_AddAlarmPolicyOutput(pstAPolicyNode,0,EN_ZJ_AIIOT_TYPE_EVENT,0,aucBuff);
        }
    }
    return ;
}

// 设置KjIot设备的策略
_INT Config_SetDefaultIotPolicy(_UI uiKjIoTType, _UI uiOpenFlag, _UI uiKjIoTEventId, _UI uiTraceFlag,_UI uiBuzzerFlag,_UI uiSenstive,
    _UI uiRecordFlag, _UI uiSnapFlag, _UI uiEventFlag, _UI uiEventInterval,_UI uiDuration, _UI uiActiveTime,_UI uiSoundType,_UC *pucSoundFile)
{
    MOS_PARAM_NULL_RETERR(pucSoundFile);

    _UC aucBuff[256];
    _UC* pucProp = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstIotPolicyNode;
    // 判断该KjIot设备是否已经添加
    ST_CFG_INIOT_NODE* pstInIotNode = Config_FindInnerIotDevice(uiKjIoTType,0);
    if(pstInIotNode == MOS_NULL)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"can not find iniot %u",uiKjIoTType);
        return MOS_OK;
    }

    // 在KjIot设备策略链表中 查找对应KjIot设备的策略节点
    if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_MOTION)  // MOTION KjIot设备
        pstIotPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType, 0, IOT_DEFAULT_POLICYID_MOTION);
    else    // 非MOTION KjIot设备
        pstIotPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType, 0, uiKjIoTType);
    
    // 已设置KjIot设备策略
    if(MOS_LIST_GETCOUNT(&pstIotPolicyNode->stEventList) > 0)
    {
        MOS_LOG_WARN(CFG_LOGSTR,"IoTType:%u also have KjIotPolicy!", uiKjIoTType);
        return MOS_OK;
    }

    // KjIot设备的策略节点初始化
    pstIotPolicyNode->uiSpanFlag  = 0;
    pstIotPolicyNode->uiOpenFlag = uiOpenFlag;
    pstIotPolicyNode->uiEndTime   = 86400;
    pstIotPolicyNode->uiStartTime = 0;
    pstIotPolicyNode->uiWeekFlag  = 0X7F;

    // 添加EventId事件的策略
    Config_AddAlarmPolicyEvent(pstIotPolicyNode,uiKjIoTEventId);

    // 根据flag 设置不同二级KjIot设备的output属性
    if(uiRecordFlag == 1)
    {
        MOS_VSNPRINTF(aucBuff,256,"{\"CtrlType\":\"1\",\"Duration\":\"%d\",\"StreamID\":\"0\"}",uiDuration);
        Config_AddAlarmPolicyOutput(pstIotPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_RECORD,0,aucBuff);
        Config_AddAlarmPolicyOutput(pstIotPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0,aucBuff);
    }
    if(uiSnapFlag == 1)
    {
        Config_AddAlarmPolicyOutput(pstIotPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_SNAPSHORT,0,(_UC*)"{\"PicType\":\"2\",\"GifFlag\":\"0\"}");
        Config_AddAlarmPolicyOutput(pstIotPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_CLOUDSNAP,0,(_UC*)"{\"PicType\":\"2\",\"GifFlag\":\"1\"}");
    }
    if(uiEventFlag == 1)
    {
        MOS_VSNPRINTF(aucBuff,256,"{\"EmailFlag\":\"0\",\"PushFlag\":\"1\",\"SMSFlag\":\"0\",\"Interval\":\"%d\",\"StartTime\":\"0\",\"EndTime\":\"86400\"}",uiEventInterval);
        Config_AddAlarmPolicyOutput(pstIotPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_EVENT,0,aucBuff);
    }
    if(uiBuzzerFlag == 1)
    {
        if(Config_FindInnerIotDevice(EN_ZJ_AIIOT_TYPE_BUZZER,0) != MOS_NULL)
        {
            MOS_VSNPRINTF(aucBuff,256,"{\"CtrlType\":\"1\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"SoundName\":\"%s\",\"SpeakerId\":\"0\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\"}",uiKjIoTType,uiSoundType,pucSoundFile);
            Config_AddAlarmPolicyOutput(pstIotPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_BUZZER,0,aucBuff);
        }
    }
    
    if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_DOORBELL)
    {
        Config_SetAlarmPolicyName(pstIotPolicyNode,(_UC*)"DOORBELL");
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_FORCEREMOVE)
    {
        Config_SetAlarmPolicyName(pstIotPolicyNode,(_UC*)"ForceMove");
    }
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_STAY)
    {
        Config_SetAlarmPolicyName(pstIotPolicyNode,(_UC*)"StayAlarm");

        pucProp = (_UC *)MOS_MALLOCCLR(256);
        MOS_VSNPRINTF(pucProp,256,"{\"ActiveTime\":\"%d\"}",uiActiveTime);
        Config_SetAlarmPolicyProp(pstIotPolicyNode,pucProp);

        MOS_FREE(pucProp);
    } 
    else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        Config_SetAlarmPolicyName(pstIotPolicyNode,(_UC*)"Motion");

        pucProp = (_UC *)MOS_MALLOCCLR(512);
        MOS_VSNPRINTF(pucProp,512,"{\"Motion\":{\"Sensitive\":\"%d\",\"Status\":\"1\",\"Trace\":\"%d\",\"Interval\":\"60\",\"ActiveTime\":\"%d\"},"
        "\"Human\":{\"Sensitive\":\"%d\",\"Status\":\"1\",\"Trace\":\"%d\",\"Interval\":\"60\",\"ActiveTime\":\"%d\"}}",uiSenstive,uiTraceFlag,uiActiveTime,uiSenstive,uiTraceFlag,uiActiveTime);
        Config_SetAlarmPolicyProp(pstIotPolicyNode,pucProp);

        MOS_FREE(pucProp);
    }
    MOS_LOG_INF(CFG_LOGSTR,"set default KjIotPolicy ok,KjIotType %u,eventId %u",uiKjIoTType,uiKjIoTEventId);
    return MOS_OK;
}

// 增加告警IOT设备策略类型
_INT Config_AddIoTDefaultPolicy(ST_ZJ_IOT_POLICY_INFO *pstIoTPolicyInfo)
{
    MOS_PARAM_NULL_RETERR(pstIoTPolicyInfo);

    _UI uiPushFlag                  = 0;
    _UI uiDuration                  = 0;
    _UI uiHumanFlag                 = 0;
    _UI uiEventInterval             = 0;
    _UI uiDetectInterval            = 0;
    // _UC aucSnapBuff[256]         = {0};
    _UC aucRecordBuff[256]          = {0};
    _UC aucAIEventBuff[256]         = {0};
    _UC aucMotionEventBuff[256]     = {0};
    _UC aucDeviceLinkEventBuff[256] = {0};

    // ebo机器人事件推送开关默认打开，其它默认关闭
    if (EN_ZJ_AIIOT_TYPE_EBO_ROBOT == pstIoTPolicyInfo->uiInIoTType)
    {
        uiPushFlag = 1;
    }
    else if(EN_ZJ_AIIOT_TYPE_VIDEOPLAY == pstIoTPolicyInfo->uiInIoTType)
    {
        uiPushFlag = 1;
    }
    else
    {
        uiPushFlag = 0;
    }

#ifdef DX_DOORBELL
    uiDuration       = 0;
    uiHumanFlag      = 0;
    uiEventInterval  = 0;
    uiDetectInterval = 30;
#else
    uiDuration       = CLOUDSTG_EVENT_UPLOAD_TIME; // 需要删除TestPath配置
    uiHumanFlag      = 1;
    uiEventInterval  = CLOUDSTG_UPLOAD_TIME;
    uiDetectInterval = 60;
#endif
    // MOS_VSNPRINTF(aucSnapBuff,    256, "{\"PicType\":\"2\",\"GifFlag\":\"0\"}");
    #if 0
    MOS_VSNPRINTF(aucRecordBuff,     256, "{\"CtrlType\":\"1\",\"Duration\":\"%d\"}", uiDuration);
    #else
    MOS_VSNPRINTF(aucRecordBuff,     256, "{\"CtrlType\":\"1\",\"Duration\":\"%d\",\"StreamID\":\"0\"}", uiDuration);
    #endif
    MOS_VSNPRINTF(aucAIEventBuff,    256, "{\"EmailFlag\":\"0\",\"PushFlag\":\"%u\",\"SMSFlag\":\"0\",\"Interval\":\"%d\",\"StartTime\":\"0\",\"EndTime\":\"86400\"}", uiPushFlag, uiEventInterval);
    MOS_VSNPRINTF(aucMotionEventBuff,256, "{\"EmailFlag\":\"0\",\"PushFlag\":\"1\",\"SMSFlag\":\"0\",\"Interval\":\"%d\",\"StartTime\":\"0\",\"EndTime\":\"86400\"}",uiEventInterval);
    MOS_VSNPRINTF(aucDeviceLinkEventBuff,256, "{\"EmailFlag\":\"0\",\"PushFlag\":\"1\",\"SMSFlag\":\"0\",\"Interval\":\"%d\",\"StartTime\":\"0\",\"EndTime\":\"86400\"}",uiEventInterval);

    // AI功能的 IOT的告警消息推送间隔 根据其属性prop的Interval间隔为0s或1s，则事件推送间隔Interval默认为1s
    ST_CFG_INIOT_NODE *pstIniotNode = Config_FindInnerIotDevice(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId);
    if ((pstIniotNode != MOS_NULL) && (pstIniotNode->pucProp != MOS_NULL))
    {
        JSON_HANDLE hPropJson = Adpt_Json_Parse(pstIniotNode->pucProp);
        if (hPropJson != MOS_NULL)
        {
            JSON_HANDLE hIntervalJson = Adpt_Json_GetObjectItem(hPropJson,(_UC*)"Interval");
            if (hIntervalJson)
            {
                _INT iInterval = 30;
                Adpt_Json_GetIntegerEx(hIntervalJson, &iInterval);
                if (iInterval == 0 || iInterval == 1)   
                {
                    MOS_VSNPRINTF(aucAIEventBuff, 256, "{\"EmailFlag\":\"0\",\"PushFlag\":\"%u\",\"SMSFlag\":\"0\",\"Interval\":\"1\",\"StartTime\":\"0\",\"EndTime\":\"86400\"}", uiPushFlag);
                }
            }

            Adpt_Json_Delete(hPropJson);
        }
    }

    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
    // 创建告警IoT策略节点
    pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTType);
    if ((pstAPolicyNode != MOS_NULL) && (MOS_LIST_GETCOUNT(&pstAPolicyNode->stEventList) <= 0))
    {
        MOS_LOG_INF(CFG_LOGSTR,"IoT(%u %llu %u) %s default AlarmPolicy", 
                                pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, 
                                pstIoTPolicyInfo->uiInIoTEventId, pstIoTPolicyInfo->aucPolicyName);
        // 设置策略启动标志
        Config_SetAlarmPolicyOpenFlag(pstAPolicyNode, pstIoTPolicyInfo->uiOpenFlag);
        // 设置策略名称
        Config_SetAlarmPolicyName(pstAPolicyNode, pstIoTPolicyInfo->aucPolicyName);
        // 设置策略布控时间
        Config_SetAlarmPolicyTime(pstAPolicyNode, pstIoTPolicyInfo->uiSpanFlag,  pstIoTPolicyInfo->uiWeekFlag, 
                                                  pstIoTPolicyInfo->uiStartTime, pstIoTPolicyInfo->uiEndTime);
        // 设置策略的属性
        Config_SetAlarmPolicyProp(pstAPolicyNode,(_UC*)pstIniotNode->pucProp);

        Config_AlarmPolicyEventBegainSync(pstAPolicyNode);
        // 添加IoT类型的事件策略
        Config_AddAlarmPolicyEvent(pstAPolicyNode, pstIoTPolicyInfo->uiInIoTEventId); 
        // 添加事件的响应IoT类型和默认动作
        if (pstIoTPolicyInfo->uiInIoTType    == EN_ZJ_AIIOT_TYPE_MOTION && 
            pstIoTPolicyInfo->lluInIoTId     == EN_ZJ_DEFAULT_IOTID     && 
            pstIoTPolicyInfo->uiInIoTEventId == EN_ZJ_MOTION_EVENT_MOTION)
        {
            // 消息推送
            // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_EVENT,EN_ZJ_DEFAULT_IOTID,aucMotionEventBuff);
            ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_EVENT, EN_ZJ_DEFAULT_IOTID, aucMotionEventBuff);
        }
        else if (pstIoTPolicyInfo->uiInIoTType == EN_ZJ_AIIOT_TYPE_LINKAGEALARM)
        {
            /**
             * 1022事件 默认打开pushflag
            */
            ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_EVENT, EN_ZJ_DEFAULT_IOTID, aucDeviceLinkEventBuff);
        }
        else
        {
            // 消息推送
            // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_EVENT,EN_ZJ_DEFAULT_IOTID,aucAIEventBuff);
            ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_EVENT, EN_ZJ_DEFAULT_IOTID, aucAIEventBuff);
        }
        // 事件录像
        // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_RECORD,EN_ZJ_DEFAULT_IOTID,aucRecordBuff);
        ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_RECORD, EN_ZJ_DEFAULT_IOTID, aucRecordBuff);
        // 云存
        // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_CLOUDRECORD,EN_ZJ_DEFAULT_IOTID,aucRecordBuff);
        ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, EN_ZJ_DEFAULT_IOTID, aucRecordBuff);
        // 本地抓拍
        // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_SNAPSHORT,EN_ZJ_DEFAULT_IOTID,aucSnapBuff);
        // ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_SNAPSHORT, EN_ZJ_DEFAULT_IOTID, aucSnapBuff);
        // 云端抓拍
        // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_CLOUDSNAP,EN_ZJ_DEFAULT_IOTID,aucSnapBuff);
        // ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_CLOUDSNAP, EN_ZJ_DEFAULT_IOTID, aucSnapBuff);

        Config_AlarmPolicyEventEndSync(pstAPolicyNode);

        MOS_LOG_INF(CFG_LOGSTR,"IoT(%u %llu %u) %s Add AlarmPolicy", 
                        pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, 
                        pstIoTPolicyInfo->uiInIoTEventId, pstIoTPolicyInfo->aucPolicyName);
    }
    else
    {
        // 已有策略节点，增加EVENTID的响应策略 or 策略输出字段增加
        MOS_LOG_INF(CFG_LOGSTR,"IoT(%u %llu) %s ADD %u AlarmPolicy",
                pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId,
                    pstIoTPolicyInfo->aucPolicyName, pstIoTPolicyInfo->uiInIoTEventId);

        // 添加IoT类型的事件策略
        Config_AddAlarmPolicyEvent(pstAPolicyNode, pstIoTPolicyInfo->uiInIoTEventId);
        // 添加事件的响应IoT类型和默认动作
        if (pstIoTPolicyInfo->uiInIoTType    == EN_ZJ_AIIOT_TYPE_MOTION &&
            pstIoTPolicyInfo->lluInIoTId     == EN_ZJ_DEFAULT_IOTID     && 
            pstIoTPolicyInfo->uiInIoTEventId == EN_ZJ_MOTION_EVENT_MOTION)
        {
            // 消息推送
            Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_EVENT,EN_ZJ_DEFAULT_IOTID,aucMotionEventBuff);
            ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_EVENT, EN_ZJ_DEFAULT_IOTID, aucMotionEventBuff);
            
        }
        else if (pstIoTPolicyInfo->uiInIoTType == EN_ZJ_AIIOT_TYPE_LINKAGEALARM)
        {
            /**
             * 1022事件 默认打开pushflag
            */
            ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_EVENT, EN_ZJ_DEFAULT_IOTID, aucDeviceLinkEventBuff);
        }
        else
        {         
            // 消息推送
            // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_EVENT,EN_ZJ_DEFAULT_IOTID,aucAIEventBuff);
            ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_EVENT, EN_ZJ_DEFAULT_IOTID, aucAIEventBuff);
        }
        // 事件录像
        // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_RECORD,EN_ZJ_DEFAULT_IOTID,aucRecordBuff);
        ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_RECORD, EN_ZJ_DEFAULT_IOTID, aucRecordBuff);
        // 云存
        // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_CLOUDRECORD,EN_ZJ_DEFAULT_IOTID,aucRecordBuff);
        ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, EN_ZJ_DEFAULT_IOTID, aucRecordBuff);
        // 本地抓拍
        // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_SNAPSHORT,EN_ZJ_DEFAULT_IOTID,aucSnapBuff);
        // ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_SNAPSHORT, EN_ZJ_DEFAULT_IOTID, aucSnapBuff);
        // 云端抓拍
        // Config_AddAlarmPolicyOutput(pstAPolicyNode,pstIoTPolicyInfo->uiInIoTEventId,EN_ZJ_AIIOT_TYPE_CLOUDSNAP,EN_ZJ_DEFAULT_IOTID,aucSnapBuff);
        // ZJ_AddAlarmPolicyOutput(pstIoTPolicyInfo->uiInIoTType, pstIoTPolicyInfo->lluInIoTId, pstIoTPolicyInfo->uiInIoTEventId, EN_ZJ_AIIOT_TYPE_CLOUDSNAP, EN_ZJ_DEFAULT_IOTID, aucSnapBuff);
    }
    return MOS_OK;
}

// 删除告警IOT设备策略类型
_INT Config_DelIoTDefaultPolicy(_UI uiInIoTType, _LLID lluInIoTId)
{
    _INT iRet = MOS_ERR;
    // 删除告警IoT策略节点
    if (uiInIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        iRet = Config_DeleteAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION, lluInIoTId, IOT_DEFAULT_POLICYID_MOTION);
    }
    else
    {
        iRet = Config_DeleteAlarmPolicyNode(uiInIoTType, lluInIoTId, uiInIoTType);
    }

    return iRet;
}

/**********************************************************************************
***********************************************************************************/
_VPTR Config_BuildAlarmPolicyObject(_UI uiCfgType)
{
    _UC aucBuff[64] = {0};
    ST_MOS_LIST_ITERATOR stIterator,stIterator1,stIterator2;
    ST_CFG_OUTPUT_NODE      *pstOutputNode    = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode     = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode     = MOS_NULL;
    
    JSON_HANDLE hOutPut     = MOS_NULL;
    JSON_HANDLE hActionArry = MOS_NULL;
    JSON_HANDLE hActionItem = MOS_NULL;

    JSON_HANDLE hEventArry = MOS_NULL;
    JSON_HANDLE hEventItem = MOS_NULL;

    JSON_HANDLE hProp       = MOS_NULL;
    JSON_HANDLE hIotArray   = MOS_NULL;
    JSON_HANDLE hIotItem    = MOS_NULL;
    JSON_HANDLE hRoot       = Adpt_Json_CreateObject();
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiAlarmPolicySign));
   
    hIotArray = Adpt_Json_CreateArray();
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Policys",hIotArray);
    FOR_EACHDATA_INLIST(Config_GetAlarmPolicyList(), pstAlarmNode, stIterator)
    {
        if(pstAlarmNode->uiUseFlag == 0)
        {
            continue;
        }
        hIotItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hIotArray,hIotItem);
        
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstAlarmNode->uiKjIoTType));
        
        MOS_VSNPRINTF(aucBuff, sizeof(aucBuff), "%llu",pstAlarmNode->lluKjIotId);
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));

        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"OpenFlag",Adpt_Json_CreateStrWithNum(pstAlarmNode->uiOpenFlag));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"PolicyName",Adpt_Json_CreateString(pstAlarmNode->aucPolicyName));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"PolicyID",Adpt_Json_CreateStrWithNum(pstAlarmNode->uiPolicyId));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"Week",Adpt_Json_CreateStrWithNum(pstAlarmNode->uiWeekFlag));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"StartTime",Adpt_Json_CreateStrWithNum(pstAlarmNode->uiStartTime));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"EndTime",Adpt_Json_CreateStrWithNum(pstAlarmNode->uiEndTime));
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"SpanFlag",Adpt_Json_CreateStrWithNum(pstAlarmNode->uiSpanFlag)); 
        if(MOS_STRLEN(pstAlarmNode->pucProp) > 0)
        {
            hProp = Adpt_Json_Parse(pstAlarmNode->pucProp);
            Adpt_Json_AddItemToObject(hIotItem,(_UC*)"Prop",hProp);
        }
        hEventArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hIotItem,(_UC*)"Events",hEventArry);
        FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList,pstEventNode,stIterator1)
        {
            if(pstEventNode->uiUseFlag == 0)
            {
                continue;
            }
            hEventItem = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hEventArry,hEventItem);
            Adpt_Json_AddItemToObject(hEventItem,(_UC*)"EventID",Adpt_Json_CreateStrWithNum(pstEventNode->uiKjIoTEventId));
            
            hActionArry = Adpt_Json_CreateArray();
            Adpt_Json_AddItemToObject(hEventItem,(_UC*)"Action",hActionArry);
            FOR_EACHDATA_INLIST(&pstEventNode->stOutputList,pstOutputNode,stIterator2)
            {
                if(pstOutputNode->uiUseFlag == 0)
                {
                    continue;
                }
                hActionItem = Adpt_Json_CreateObject();
                Adpt_Json_AddItemToArray(hActionArry,hActionItem);

                Adpt_Json_AddItemToObject(hActionItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstOutputNode->uiKjIoTType));
                MOS_VSNPRINTF(aucBuff, sizeof(aucBuff), "%llu",pstOutputNode->lluKjIotId);
                Adpt_Json_AddItemToObject(hActionItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));
                Mos_MutexLock(&Config_Task_GetMng()->hMutex);
                if(MOS_STRLEN(pstOutputNode->pucParam) > 0)
                {
                    if(pstAlarmNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_DOORBELL && pstOutputNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_BUZZER)
                    {
                        MOS_LOG_INF(CFG_LOGSTR,"=== doorbell output %s",pstOutputNode->pucParam);
                    }
                    hOutPut = Adpt_Json_Parse(pstOutputNode->pucParam);
                    Adpt_Json_AddItemToObject(hActionItem,(_UC*)"OutPut",hOutPut);
                }
                Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
            }
        }
    }
    return hRoot;
}

_UC *Config_BuildIotPolicyJson(_UI uiCfgType)
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = Config_BuildAlarmPolicyObject(uiCfgType);
    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_LOG_INF(CFG_LOGSTR,"build alarm policy info %s",pStrTmp);
    MOS_PRINTF("build alarm policy info %s \r\n",pStrTmp);
    return pStrTmp;
}

// 读取报警策略配置的字段
_INT Config_ParseAlarmPolicyJson(_UC *pucJson,_UI uiCfgType)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT i, iArraySize;
    _INT j, jArraySize;
    _INT z, zArrySize;
    _UI uiKjIoTEventId;
    _UI uiPolicyId   = 0;
    _UI uiKjIoTType  = 0;
    _LLID lluKjIoTId = 0;
    _UI uiOutKjIoTType  = 0;
    _LLID lluOutKjIoTId = 0;
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hProp       = MOS_NULL;
    
    JSON_HANDLE hActionArry = MOS_NULL;
    JSON_HANDLE hActionItem = MOS_NULL;

    JSON_HANDLE hEventArry = MOS_NULL;
    JSON_HANDLE hEventItem = MOS_NULL;
    
    JSON_HANDLE hIotItem    = MOS_NULL;
    JSON_HANDLE hIotArray   = MOS_NULL;
    
    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = MOS_NULL;
    
    JSON_HANDLE hRoot       = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 每个配置项的版本ID  设备端生成
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiAlarmPolicySign);
    
    // 联动策略
    hIotArray = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Policys");
    iArraySize = Adpt_Json_GetArraySize(hIotArray);
    for(i = 0; i < iArraySize; i++)
    {
        hIotItem = Adpt_Json_GetArrayItem(hIotArray,i);
        // AIIoT类型
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);  
        // 设备ID
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"AIIoTID"),&pStrTmp);
        MOS_SSCANF(pStrTmp, "%llu",&lluKjIoTId);
        // 策略ID，由客户端生成
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"PolicyID"),(_INT*)&uiPolicyId);
        pstAlarmNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiPolicyId);

        // 开关 0.关闭；1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"OpenFlag"),(_INT*)&pstAlarmNode->uiOpenFlag);
        // 周几，为掩码代表一周中的一天或多天 0x01，为周一；0x02,为周二；0x04,为周三；0x08为周四；0x10为周五；0x20为周六；0x40为周日
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"Week"),    (_INT*)&pstAlarmNode->uiWeekFlag);
        // 开始时间 (距离0点的秒数Hour*3600+Minute*60+usSecond)
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"StartTime"),(_INT*)&pstAlarmNode->uiStartTime);
        // 结束时间 (距离0点的秒数Hour*3600+Minute*60+usSecond)
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"EndTime"),(_INT*)&pstAlarmNode->uiEndTime);
        // 是否跨天  0.关闭；1.开启
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"SpanFlag"),(_INT*)&pstAlarmNode->uiSpanFlag);
        // 策略名
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"PolicyName"),&pStrTmp);
        MOS_STRNCPY(pstAlarmNode->aucPolicyName, pStrTmp, sizeof(pstAlarmNode->aucPolicyName));

        // 根据AIIoT类型定义当前AIIoTID的属性设置
        hProp = Adpt_Json_GetObjectItem(hIotItem,(_UC*)"Prop");
        pStrTmp = Adpt_Json_Print(hProp);
        Config_SetAlarmPolicyProp(pstAlarmNode,pStrTmp);
        MOS_FREE(pStrTmp);

        // 事件
        hEventArry = Adpt_Json_GetObjectItem(hIotItem,(_UC*)"Events");
        jArraySize = Adpt_Json_GetArraySize(hEventArry);
        for(j = 0; j < jArraySize; j++)
        {
            hEventItem = Adpt_Json_GetArrayItem(hEventArry,j);
            // 事件ID，IoT设备根据输入信号值定义事件条件，当输入条件达到时，输出对应的事件ID,设备事件ID与策略中事件ID一致则触发Action
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hEventItem,(_UC*)"EventID"),(_INT*)&uiKjIoTEventId);
            pstEventNode = Config_FindAndCreatAlarmEventNode(pstAlarmNode,uiKjIoTEventId);

            // 告警联动策略动作
            hActionArry = Adpt_Json_GetObjectItem(hEventItem,(_UC*)"Action");
            zArrySize  = Adpt_Json_GetArraySize(hActionArry);
            for(z = 0; z < zArrySize; z++)
            {
                hActionItem = Adpt_Json_GetArrayItem(hActionArry,z);
                // output的IoT类型
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hActionItem,(_UC*)"AIIoTType"),(_INT*)&uiOutKjIoTType);
                // 设备ID
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hActionItem,(_UC*)"AIIoTID"),&pStrTmp);
                MOS_SSCANF(pStrTmp, "%llu",&lluOutKjIoTId);
                pstOutputNode = Config_FindAndCreatOutNode(&pstEventNode->stOutputList,uiOutKjIoTType,lluOutKjIoTId);
                // 根据不同的类型输出不同的参数
                hProp = Adpt_Json_GetObjectItem(hActionItem,(_UC*)"OutPut");

                // 兼容3.0电子围栏告警联动消息推送1013设置不为0，强制修改为0 业务要求电子围栏实时告警
                if (KJIOT_EVENT_IS_FENCE(uiKjIoTType, uiKjIoTEventId) && (uiOutKjIoTType  == EN_ZJ_AIIOT_TYPE_EVENT))
                {
                    _INT iInterval = 30;
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hProp,(_UC*)"Interval"), &iInterval);
                    if (iInterval != 0)
                    {
                        Adpt_Json_DeleteItemFromObject(hProp, (_UC*)"Interval");
                        Adpt_Json_AddItemToObject(hProp, (_UC*)"Interval", Adpt_Json_CreateStrWithNum(0));
                    }
                }
                
                pStrTmp = Adpt_Json_Print(hProp);
                Config_SetOutputDevParam(pstOutputNode,pStrTmp);
                MOS_FREE(pStrTmp);  
            }  
        }
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}
static _INT Config_AddMotionCommonDefaultPolicyEx(ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode,_UI uiKjIoTEventId,_UI uiEventFlag,_UI uiRecordFlag,_UI uiBuzzerFlag,_UI uiLampFlag,_UI uiCtrlType)
{
    _UI uiRecordDuration,uiHumanFlag,uiEventInterval,uiDetectInterval = 0;
    _UC aucLampBuff[128]         = {0};
    _UC aucRecordBuff[128]       = {0};
    _UC aucBuzzerBuff[256]       = {0};
    _UC aucEventBuff[256]        = {0};

#ifdef DX_DOORBELL
    uiRecordDuration = 0;
    uiHumanFlag      = 0;
    uiEventInterval  = 0;
    uiDetectInterval = 30;
#else
    uiRecordDuration = CLOUDSTG_EVENT_UPLOAD_TIME; // 需要删除TestPath配置
    uiHumanFlag      = 1;
    uiEventInterval  = CLOUDSTG_UPLOAD_TIME;
    uiDetectInterval = 60;
#endif

    Config_AddAlarmPolicyEvent(pstAPolicyNode, uiKjIoTEventId);
    Config_AddAlarmPolicyOutputScene(pstAPolicyNode,uiKjIoTEventId,0);
    if (uiEventFlag)
    {
        // 移动侦测推送默认开启     其他AI侦测推送默认关闭
        if (uiKjIoTEventId == EN_ZJ_MOTION_EVENT_MOTION) // 客户端移动侦测的默认推送间隔为CLOUDSTG_UPLOAD_TIME
        {
            MOS_VSNPRINTF(aucEventBuff, sizeof(aucEventBuff),"{\"EmailFlag\":\"0\",\"PushFlag\":\"1\",\"SMSFlag\":\"0\",\"Interval\":\"%d\",\"StartTime\":\"0\",\"EndTime\":\"86400\"}",uiEventInterval);
        }
        else if (uiKjIoTEventId == EN_ZJ_MOTION_EVENT_HUMAN) // 客户端移动侦测的默认推送间隔为CLOUDSTG_UPLOAD_TIME
        {
            MOS_VSNPRINTF(aucEventBuff, sizeof(aucEventBuff),"{\"EmailFlag\":\"0\",\"PushFlag\":\"0\",\"SMSFlag\":\"0\",\"Interval\":\"%d\",\"StartTime\":\"0\",\"EndTime\":\"86400\"}",uiEventInterval);
        }
        else
        {
            MOS_VSNPRINTF(aucEventBuff,sizeof(aucEventBuff), "{\"EmailFlag\":\"0\",\"PushFlag\":\"0\",\"SMSFlag\":\"0\",\"Interval\":\"0\",\"StartTime\":\"0\",\"EndTime\":\"86400\"}");
        }
        Config_AddAlarmPolicyOutput(pstAPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_EVENT,0,aucEventBuff);
    }
    if (uiRecordFlag)
    {
        MOS_VSNPRINTF(aucRecordBuff, sizeof(aucRecordBuff), "{\"CtrlType\":\"1\",\"Duration\":\"%d\",\"StreamID\":\"0\"}", uiRecordDuration);
        Config_AddAlarmPolicyOutput(pstAPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_RECORD,0,aucRecordBuff);
        Config_AddAlarmPolicyOutput(pstAPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0,aucRecordBuff);
    }
    if (uiBuzzerFlag)
    {
        MOS_VSNPRINTF(aucBuzzerBuff, sizeof(aucBuzzerBuff), "{\"CtrlType\":\"%u\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"2\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\",\"RemindRule\":\"0\",\"ExecuteTime\":[]}", uiCtrlType, EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_RING_ALARM);
        Config_AddAlarmPolicyOutput(pstAPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_BUZZER,0,aucBuzzerBuff);
    }
    if (uiLampFlag)
    {
        MOS_VSNPRINTF(aucLampBuff,   sizeof(aucLampBuff), "{\"CtrlType\":\"%u\",\"Duration\":\"30\",\"Flicker\":\"0\"}", uiCtrlType);
        Config_AddAlarmPolicyOutput(pstAPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_INNER_LAMP,0,aucLampBuff);
    }
    // Config_AddAlarmPolicyOutput(pstAPolicyNode,EN_ZJ_MOTION_EVENT_FENCE_FACE_STAY,EN_ZJ_AIIOT_TYPE_SNAPSHORT,  0,aucSnapBuff);
    // Config_AddAlarmPolicyOutput(pstAPolicyNode,EN_ZJ_MOTION_EVENT_FENCE_FACE_STAY,EN_ZJ_AIIOT_TYPE_CLOUDSNAP,  0,aucSnapBuff);    
    return MOS_OK;
}

static _INT Config_AddMotionCommonDefaultPolicy(ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode,_UI uiKjIoTEventId,_UI uiEventFlag,_UI uiRecordFlag,_UI uiBuzzerFlag,_UI uiLampFlag)
{
    // 扬声器/白光灯默认为开
    return Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, uiKjIoTEventId, uiEventFlag, uiRecordFlag, uiBuzzerFlag, uiLampFlag, 1);
}

_INT Config_MotionAlarmPolicyUpdate()
{
    // _UI uiHaveMotionFlag     = 0;
    // _UI uiHaveHumanFlag      = 0;
    _UI uiHaveFenceBaseFlag  = 0;
    _UI uiHaveFenceStayFlag  = 0;
    _UI uiHaveFenceEx1Flag   = 0;
    _UI uiHaveFenceEx2Flag   = 0;

    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;

    pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION, 0, IOT_DEFAULT_POLICYID_MOTION);
    if (pstAPolicyNode->pucProp != MOS_NULL)
    {
        _INT iValue  = 0;
        JSON_HANDLE hFenceJson   = MOS_NULL;
        JSON_HANDLE hIoTPropJson = Adpt_Json_Parse(pstAPolicyNode->pucProp);
        if (hIoTPropJson)
        {
            hFenceJson = Adpt_Json_GetObjectItem(hIoTPropJson, (_UC*)"Fence");
            if (hFenceJson)
            {
                uiHaveFenceBaseFlag = 1;// 具备电子围栏基础功能
                if (Adpt_Json_GetObjectItem(hFenceJson, (_UC*)"StayTime"))
                {
                    uiHaveFenceStayFlag = 1;// 具备电子围栏滞留功能
                }
                
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hFenceJson, (_UC*)"ExpandEventAbility"),&iValue);
                if (iValue & 0x01)  
                {
                    uiHaveFenceEx1Flag = 1;// 具备电子围栏机动车识别功能
                }
                if (iValue & 0x02)
                {
                    uiHaveFenceEx2Flag = 1;// 具备电子围栏机动车识别功能
                }
            }
            Adpt_Json_Delete(hIoTPropJson);
        }
    }
    MOS_LOG_INF(CFG_LOGSTR,"IoT MOTION HaveFence=%d HaveFenceStay=%d HaveFenceEx1=%d HaveFenceEx2=%d\n",
                uiHaveFenceBaseFlag, uiHaveFenceStayFlag, uiHaveFenceEx1Flag, uiHaveFenceEx2Flag);

    if (MOS_LIST_GETCOUNT(&pstAPolicyNode->stEventList) <= 0)
    {
        MOS_LOG_INF(CFG_LOGSTR,"IoT MOTION default alarmPolicy!");
        Config_SetAlarmPolicyOpenFlag(pstAPolicyNode, 1);
        Config_SetAlarmPolicyName(pstAPolicyNode, IOT_POLICYNAME_MOTION);
        Config_SetAlarmPolicyTime(pstAPolicyNode, 0, 127, 0, 86400);

        Config_AlarmPolicyEventBegainSync(pstAPolicyNode);

        // 移动侦测策略
        Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_MOTION, 1, 1, 0, 0);
        // 人形侦测策略
        Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_HUMAN, 1, 1, 0, 1);

        // 电子围栏基础策略
        if (uiHaveFenceBaseFlag)
        {
            Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTION_IN, 1, 1, 1, 1);
            Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTION_OUT, 1, 1, 1, 1);
            Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_IN, 1, 1, 1, 1);
            Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_OUT, 1, 1, 1, 1);
            Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_FACE_IN, 1, 1, 1, 1);
            Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_FACE_OUT, 1, 1, 1, 1);
        }

        // 电子围栏滞留策略 - 扬声器/白光灯默认为关
        if (uiHaveFenceStayFlag)
        {
            Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTION_STAY, 1, 1, 1, 1, 0);
            Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_STAY, 1, 1, 1, 1, 0);
            Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_FACE_STAY, 1, 1, 1, 1, 0);
        }

        // 电子围栏人机非策略 - 为了平台兼容,扬声器/白光灯默认为关
        if (uiHaveFenceEx1Flag)
        {
            Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTOR_IN, 1, 1, 1, 1, 0);
            Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTOR_OUT, 1, 1, 1, 1, 0);
            if (uiHaveFenceStayFlag)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTOR_STAY, 1, 1, 1, 1, 0);
            }
        }
        if (uiHaveFenceEx2Flag)
        {
            Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_IN, 1, 1, 1, 1, 0);
            Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_OUT, 1, 1, 1, 1, 0);
            if (uiHaveFenceStayFlag)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_STAY, 1, 1, 1, 1, 0);
            }
        }

        Config_AlarmPolicyEventEndSync(pstAPolicyNode);
    }
    else
    {
        MOS_LOG_INF(CFG_LOGSTR,"IoT MOTION Add alarmPolicy!");

        ST_MOS_LIST_ITERATOR        stIterator;
        ST_CFG_POLICYEVENT_NODE     *pstEventNode = MOS_NULL;
        _UI uiAddMotionFlag         = 1;
        _UI uiAddHumanFlag          = 1;
        _UI uiAddFenceMotionInFlag  = 1;
        _UI uiAddFenceMotionOutFlag = 1;
        _UI uiAddFenceHumanInFlag   = 1;
        _UI uiAddFenceHumanOutFlag  = 1;
        _UI uiAddFenceFaceInFlag    = 1;
        _UI uiAddFenceFaceOutFlag   = 1;
        _UI uiAddCarNumFlag         = 1;
        _UI uiAddFenceMotionStayFlag= 1;
        _UI uiAddFenceHumanStayFlag = 1;
        _UI uiAddFenceFaceStayFlag  = 1;
        _UI uiAddFenceMotorInFlag      = 1;
        _UI uiAddFenceMotorOutFlag     = 1;
        _UI uiAddFenceMotorStayFlag    = 1;
        _UI uiAddFenceNonMotorInFlag   = 1;
        _UI uiAddFenceNonMotorOutFlag  = 1;
        _UI uiAddFenceNonMotorStayFlag = 1;

        FOR_EACHDATA_INLIST(&pstAPolicyNode->stEventList,pstEventNode,stIterator)
        {
            if(pstEventNode->uiUseFlag == 0)
            {
                continue;
            }
            switch(pstEventNode->uiKjIoTEventId)
            {
                case EN_ZJ_MOTION_EVENT_MOTION:
                {
                    uiAddMotionFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_HUMAN:
                {
                    uiAddHumanFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_MOTION_IN:
                {
                    uiAddFenceMotionInFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_MOTION_OUT:
                {
                    uiAddFenceMotionOutFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_HUMAN_IN:
                {
                    uiAddFenceHumanInFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_HUMAN_OUT:
                {
                    uiAddFenceHumanOutFlag = 0;
                    break;
                }                
                case EN_ZJ_MOTION_EVENT_FENCE_FACE_IN:
                {
                    uiAddFenceFaceInFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_FACE_OUT:
                {
                    uiAddFenceFaceOutFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_MOTION_STAY:
                {
                    uiAddFenceMotionStayFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_HUMAN_STAY:
                {
                    uiAddFenceHumanStayFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_FACE_STAY:
                {
                    uiAddFenceFaceStayFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_MOTOR_IN:
                {
                    uiAddFenceMotorInFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_MOTOR_OUT:
                {
                    uiAddFenceMotorOutFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_MOTOR_STAY:
                {
                    uiAddFenceMotorStayFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_IN:
                {
                    uiAddFenceNonMotorInFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_OUT:
                {
                    uiAddFenceNonMotorOutFlag = 0;
                    break;
                }
                case EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_STAY:
                {
                    uiAddFenceNonMotorStayFlag = 0;
                    break;
                }
            }                                
        }

        // Config_AlarmPolicyEventBegainSync(pstAPolicyNode);
        if (uiAddMotionFlag == 1)
        {
            Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_MOTION, 1, 1, 0, 0);
        }

        if (uiAddHumanFlag == 1)
        {
            Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_HUMAN, 1, 1, 0, 1);
        }
        // 电子围栏基础策略
        if (uiHaveFenceBaseFlag)
        {
            if (uiAddFenceMotionInFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTION_IN, 1, 1, 1, 1);
            }
            if (uiAddFenceMotionOutFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTION_OUT, 1, 1, 1, 1);
            }
            if (uiAddFenceHumanInFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_IN, 1, 1, 1, 1);
            } 
            if (uiAddFenceHumanOutFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_OUT, 1, 1, 1, 1);
            }
            if (uiAddFenceFaceInFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_FACE_IN, 1, 1, 1, 1);
            }
            if (uiAddFenceFaceOutFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicy(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_FACE_OUT, 1, 1, 1, 1);
            }
        }

        // 电子围栏滞留策略 - 扬声器/白光灯默认为关
        if (uiHaveFenceStayFlag)
        {
            if (uiAddFenceMotionStayFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTION_STAY, 1, 1, 1, 1, 0);
            }
            if (uiAddFenceHumanStayFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_HUMAN_STAY, 1, 1, 1, 1, 0);
            }
            if (uiAddFenceFaceStayFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_FACE_STAY, 1, 1, 1, 1, 0);
            }
        }

        // 电子围栏人机非策略 - 为了平台兼容,扬声器/白光灯默认为关
        if (uiHaveFenceEx1Flag)
        {
            if (uiAddFenceMotorInFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTOR_IN, 1, 1, 1, 1, 0);
            }
            if (uiAddFenceMotorOutFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTOR_OUT, 1, 1, 1, 1, 0);
            }
            if (uiAddFenceMotorStayFlag == 1 && uiHaveFenceStayFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_MOTOR_STAY, 1, 1, 1, 1, 0);
            }
        }
        if (uiHaveFenceEx2Flag)
        {
            if (uiAddFenceNonMotorInFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_IN, 1, 1, 1, 1, 0);
            }
            if (uiAddFenceNonMotorOutFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_OUT, 1, 1, 1, 1, 0);
            }
            if (uiAddFenceNonMotorStayFlag == 1 && uiHaveFenceStayFlag == 1)
            {
                Config_AddMotionCommonDefaultPolicyEx(pstAPolicyNode, EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_STAY, 1, 1, 1, 1, 0);
            }
        }

        // Config_AlarmPolicyEventEndSync(pstAPolicyNode);
    }

    MOS_LOG_INF(CFG_LOGSTR,"Iot MOTION AlarmPolicy Init OK");
    return MOS_OK;
}
