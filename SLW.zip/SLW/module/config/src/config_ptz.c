#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"

static  ST_CFG_PTZ_MNG g_CfgPtzMng;

ST_CFG_PTZ_MNG *Config_GetPtzMng()
{
    return &g_CfgPtzMng;
}

// PTZ 模块销毁
_INT Ptz_Task_Destroy()
{

    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST_ITERATOR stIterator1;
    ST_CFG_CRUISE_NODE  *pstCruiseNode     = MOS_NULL;
    ST_CFG_CRUISE_POINT_NODE *pstPointNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stCruiseList, pstCruiseNode, stIterator)
    {
        FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList, pstPointNode, stIterator1)
        {
            MOS_FREE(pstPointNode);
        }
    }

    MOS_LIST_RMVALL(&Config_GetPtzMng()->stPresetList, MOS_TRUE);
    MOS_LIST_RMVALL(&Config_GetPtzMng()->stCruiseList, MOS_TRUE);

    MOS_LOG_INF(PTZ_LOGSTR,"ptz task Destroy ok");

    return MOS_OK;
}

/*****************************************************************
******************************************************************/
_INT Config_AddPresetPoint(_INT iCamId, _UI uiPresetId,_UC *pucName, ST_CFG_PRESET_POINT *pstPoint)
{
    MOS_PARAM_NULL_RETERR(pucName);
    MOS_PARAM_NULL_RETERR(pstPoint);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PRESET_NODE  *pstPresetNode = MOS_NULL;
    ST_CFG_PRESET_NODE  *pstFreeNode   = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stPresetList, pstPresetNode, stIterator)
    {
        if(pstPresetNode->uiPresetId == uiPresetId)
        {
            break;
        }
        else if(pstPresetNode->uiUseFlag == 0)
        {
            pstFreeNode = pstPresetNode;
        }
    }
    
    if(pstPresetNode == MOS_NULL)
    {
        if(pstFreeNode == MOS_NULL)
        {
            pstPresetNode = (ST_CFG_PRESET_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_PRESET_NODE));
            MOS_LIST_ADDTAIL(&Config_GetPtzMng()->stPresetList, pstPresetNode);
        }
        else
        {
            pstPresetNode = pstFreeNode;
        }
        pstPresetNode->uiPresetId = uiPresetId;
    }
    MOS_MEMCPY(&pstPresetNode->stPtzPreset, pstPoint, sizeof(ST_CFG_PRESET_POINT));
    MOS_STRNCPY(pstPresetNode->aucName, pucName,sizeof(pstPresetNode->aucName));
    pstPresetNode->uiUseFlag = 1;
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    return MOS_OK;;
}

_INT Config_DelPresetPointById(_INT iCamid,_UI uiPresetId)
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_PRESET_NODE  *pstPresetNode = MOS_NULL;
    ST_CFG_CRUISE_NODE  *pstCruiseNode = MOS_NULL;
    ST_CFG_CRUISE_POINT_NODE *pstPointNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stPresetList, pstPresetNode, stIterator)
    {
        if( pstPresetNode->uiUseFlag == 1 && pstPresetNode->uiPresetId == uiPresetId)
        {
            pstPresetNode->uiUseFlag = 0;
            break;
        }
    }
    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stCruiseList, pstCruiseNode, stIterator)
    {
        if(pstCruiseNode->uiUseFlag == 0)
        {
            continue;
        }
        FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList, pstPointNode, stIterator1)
        {
            if(pstPointNode->uiUseFlag && pstPointNode->uiPresetId == uiPresetId)
            {
                pstPointNode->uiUseFlag = 0;
            }
        }
    }
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    return MOS_OK;
}

_INT Config_DelAllPresetPoints()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PRESET_NODE  *pstPresetNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stPresetList, pstPresetNode, stIterator)
    {
        if( pstPresetNode->uiUseFlag == 1)
        {
            pstPresetNode->uiUseFlag = 0;
        }
    }
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    MOS_LOG_INF(PTZ_LOGSTR,"delete all presets");
    return MOS_OK;
}

_INT Config_FindAllPresetId(_INT iCamId,_UI uiPresetId,_INT *pstPresetIdArry,_INT iSize)
{
    MOS_PARAM_NULL_RETERR(pstPresetIdArry);

    _INT i = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PRESET_NODE  *pstPresetNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stPresetList, pstPresetNode, stIterator)
    {
        if(pstPresetNode->uiUseFlag == 1 && i < iSize)
        {
            pstPresetIdArry[i] = pstPresetNode->uiPresetId;
            i++;
        }
    }
    return i;
}

_INT Config_FindPresetPointById(_INT iCamId,_UI uiPresetId,ST_CFG_PRESET_POINT *pstPtzPreset)
{
    MOS_PARAM_NULL_RETERR(pstPtzPreset);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PRESET_NODE  *pstPresetNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stPresetList, pstPresetNode, stIterator)
    {
        if(pstPresetNode->uiUseFlag == 1 && pstPresetNode->uiPresetId == uiPresetId)
        {
            MOS_MEMCPY(pstPtzPreset, &pstPresetNode->stPtzPreset,sizeof(ST_CFG_PRESET_POINT));
            return MOS_OK;
        }
    }
    return MOS_ERR;
}

_INT Config_SetPresetPictureId(_INT iCamId,_UI uiPresetId, _UC *pucPicId)
{
    MOS_PARAM_NULL_RETERR(pucPicId);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PRESET_NODE  *pstPresetNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stPresetList, pstPresetNode, stIterator)
    {
        if(pstPresetNode->uiUseFlag == 1 && pstPresetNode->uiPresetId == uiPresetId)
        {
            break;
        }
    }
    if(pstPresetNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(MOS_STRCMP(pstPresetNode->aucPicID, pucPicId) != 0)
    {
        MOS_STRNCPY(pstPresetNode->aucPicID, pucPicId, sizeof(pstPresetNode->aucPicID));
        Config_GetItemSign()->ucSavePtz = 1;
    }
    MOS_LOG_INF(PTZ_LOGSTR,"cfg_ptz set PicId %s for PresetId %d,",pucPicId, uiPresetId);
    return MOS_OK;
}

//
_INT Config_AddCurise(_INT iCamId,_UI uiCruiseID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CRUISE_NODE *pstCruiseNode = MOS_NULL;
    ST_CFG_CRUISE_NODE *pstCruiseTmpNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stCruiseList, pstCruiseNode, stIterator)
    {
        if(pstCruiseNode->uiUseFlag == 1 && pstCruiseNode->uiCruiseId == uiCruiseID)
        {
            break;
        }
        else if(pstCruiseNode->uiUseFlag == 0)
        {
            pstCruiseTmpNode = pstCruiseNode;
        }
    }
    if(pstCruiseNode == MOS_NULL)
    {
        if(pstCruiseTmpNode == MOS_NULL){
            pstCruiseNode = (ST_CFG_CRUISE_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_CRUISE_NODE));
            MOS_LIST_ADDTAIL(&Config_GetPtzMng()->stCruiseList, pstCruiseNode);
        }
        else{
            pstCruiseNode = pstCruiseTmpNode;
        }
    }
    pstCruiseNode->uiCruiseId = uiCruiseID;
    pstCruiseNode->uiUseFlag  = 1;
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    return MOS_OK;
}

_INT Config_DeleteCurise(_INT iCamId,_UI uiCruiseID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CRUISE_POINT_NODE *pstPointNode = MOS_NULL;
    ST_CFG_CRUISE_NODE *pstCruiseNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stCruiseList, pstCruiseNode, stIterator)
    {
        if(pstCruiseNode->uiUseFlag == 1 && pstCruiseNode->uiCruiseId == uiCruiseID)
        {
            break;
        }
    }
    if(pstCruiseNode == MOS_NULL)
    {
        return MOS_OK;
    }
    FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList, pstPointNode, stIterator)
    {
        pstPointNode->uiUseFlag = 0;
    }
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    return MOS_OK;
}

ST_CFG_CRUISE_NODE *Config_FindCuriseNode(_INT iCamId,_UI uiCruiseID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CRUISE_NODE *pstCruiseNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stCruiseList, pstCruiseNode, stIterator)
    {
        if(pstCruiseNode->uiUseFlag == 1 && pstCruiseNode->uiCruiseId == uiCruiseID)
        {
            break;
        }
    }
    return pstCruiseNode;
}

_INT Config_SetCuriseName(_INT iCamId,_UI uiCruiseID,_UC *pucName)
{
    MOS_PARAM_NULL_RETERR(pucName);

    ST_CFG_CRUISE_NODE *pstCruiseNode = Config_FindCuriseNode(iCamId,uiCruiseID);
    if(pstCruiseNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(MOS_STRCMP(pstCruiseNode->aucName,pucName) != 0)
    {
        MOS_STRNCPY(pstCruiseNode->aucName,pucName,sizeof(pstCruiseNode->aucName));
        Config_GetItemSign()->ucSavePtz = 1;
        Config_GetItemSign()->ucCfgPtzUpdate = 1;
    }
    MOS_LOG_INF(PTZ_LOGSTR,"cfg_ptz set CuriseName %s for curiseId %d ",pucName, uiCruiseID);
    return MOS_OK;
}

_INT Config_AddPresetIdToCuriseEx(_INT iCamId,_UI uiCruiseID,_UI uiPresetId,_UI uiDwellTime,_UI uiSpeed)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CRUISE_POINT_NODE *pstCruisePointTmpNode  = MOS_NULL;
    ST_CFG_CRUISE_POINT_NODE *pstCruisePointNode  = MOS_NULL;
    ST_CFG_CRUISE_NODE       *pstCruiseNode = Config_FindCuriseNode(iCamId,uiCruiseID);
    
    if(pstCruiseNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList, pstCruisePointNode, stIterator)
    {
        if(pstCruisePointNode->uiUseFlag && pstCruisePointNode->uiPresetId == uiPresetId)
        {
            break;
        }
        else if(pstCruisePointNode->uiUseFlag == 0)
        {
            pstCruisePointTmpNode = pstCruisePointNode;
        }
    }
    if(pstCruisePointNode == MOS_NULL)
    {
        if(pstCruisePointTmpNode == MOS_NULL)
        {
            pstCruisePointNode = (ST_CFG_CRUISE_POINT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_CRUISE_POINT_NODE));
            MOS_LIST_ADDTAIL(&pstCruiseNode->stPointList, pstCruisePointNode);
        }
        else{
            pstCruisePointNode = pstCruisePointTmpNode;
        }
    }
    pstCruisePointNode->uiDwellTime = uiDwellTime;
    pstCruisePointNode->uiPresetId  = uiPresetId;
    pstCruisePointNode->uiSpeed     = uiSpeed;
    pstCruisePointNode->uiUseFlag   = 1;
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    return MOS_OK;
}

_INT Config_AddPresetIdToCurise(_INT iCamId,_UI uiCruiseID,_UI uiIndex,_UI uiPresetId,_UI uiDwellTime,_UI uiSpeed)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CRUISE_POINT_NODE *pstCruisePointTmpNode  = MOS_NULL;
    ST_CFG_CRUISE_POINT_NODE *pstCruisePointNode  = MOS_NULL;
    ST_CFG_CRUISE_NODE       *pstCruiseNode = Config_FindCuriseNode(iCamId,uiCruiseID);
    
    if(pstCruiseNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList, pstCruisePointNode, stIterator)
    {
        if(pstCruisePointNode->uiUseFlag && pstCruisePointNode->uiPresetId == uiPresetId)
        {
            break;
        }
        else if(pstCruisePointNode->uiUseFlag == 0)
        {
            pstCruisePointTmpNode = pstCruisePointNode;
        }
    }

    if(pstCruisePointTmpNode == MOS_NULL)
    {
        pstCruisePointTmpNode = (ST_CFG_CRUISE_POINT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_CRUISE_POINT_NODE));
        MOS_LIST_ADDTAIL(&pstCruiseNode->stPointList, pstCruisePointTmpNode);
    }
    else{
        pstCruisePointTmpNode = pstCruisePointNode;
    }
    pstCruisePointTmpNode->uiIndex     = uiIndex;
    pstCruisePointTmpNode->uiDwellTime = uiDwellTime;
    pstCruisePointTmpNode->uiPresetId  = uiPresetId;
    pstCruisePointTmpNode->uiSpeed     = uiSpeed;
    Config_GetItemSign()->ucSavePtz = 1;
    return MOS_OK;
}

_INT Config_BegainSyncCruise(_INT iCamId)
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_CRUISE_POINT_NODE *pstCruisePointNode = MOS_NULL;
    ST_CFG_CRUISE_NODE *pstCruiseNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stCruiseList, pstCruiseNode, stIterator)
    {
        if(pstCruiseNode->uiUseFlag == 1)
        {
            pstCruiseNode->uiUseFlag = 2;
        }
        FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList,pstCruisePointNode,stIterator1)
        {
            if(pstCruisePointNode->uiUseFlag == 1)
            {
                pstCruisePointNode->uiUseFlag = 2;
            }
        }
    }
    return MOS_OK;
}

_INT Config_EndSyncCruise(_INT iCamId)
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_CRUISE_POINT_NODE *pstCruisePointNode = MOS_NULL;
    ST_CFG_CRUISE_NODE *pstCruiseNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stCruiseList, pstCruiseNode, stIterator)
    {
        if(pstCruiseNode->uiUseFlag == 2)
        {
            pstCruiseNode->uiUseFlag = 0;
        }
        FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList,pstCruisePointNode,stIterator1)
        {
            if(pstCruisePointNode->uiUseFlag == 2)
            {
                pstCruisePointNode->uiUseFlag = 0;
            }
        }
    }
    Config_GetItemSign()->ucSavePtz = 1;
    return MOS_OK;
}

//看守位设置  
_INT Config_AddWatchPoint(_INT iCamId,_UI uiPresetID,_UI uiWatchTime)
{
    Config_GetPtzMng()->uiWatchPresetId = uiPresetID;
    Config_GetPtzMng()->uiWatchTime     = uiWatchTime;
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    return MOS_OK;
}

_INT Config_DeleteWatchPoint(_INT iCamId)
{
    Config_GetPtzMng()->uiWatchPresetId = 0;
    Config_GetPtzMng()->uiWatchTime     = 0;
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    return MOS_OK;
}

_INT Config_SetPreSetAbility(_INT iCamID, _UI uiSetPresetAbility)
{
    if(Config_GetPtzMng()->uiSetPreSetAbility == uiSetPresetAbility)
    {
        return MOS_OK;
    }
    Config_GetPtzMng()->uiSetPreSetAbility   = uiSetPresetAbility;
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    MOS_LOG_INF(PTZ_LOGSTR,"cfg_ptz set camera %u SetPresetAbility %u ",iCamID,uiSetPresetAbility);
    return MOS_OK;
}

_INT Config_SetCuriseAbility(_INT iCamID, _UI uiSetCuriseAbility)
{
    if(Config_GetPtzMng()->uiSetCuriseAbility == uiSetCuriseAbility)
    {
        return MOS_OK;
    }
    Config_GetPtzMng()->uiSetCuriseAbility   = uiSetCuriseAbility;
    Config_GetItemSign()->ucSavePtz = 1;
    Config_GetItemSign()->ucCfgPtzUpdate = 1;
    MOS_LOG_INF(PTZ_LOGSTR,"cfg_ptz set camera %u SetCuriseAbility %u ",iCamID,uiSetCuriseAbility);
    return MOS_OK;
}

/*************************************************************************************
**************************************************************************************/
_VPTR Config_BuildPtzObject(_UI uiCfgType)
{
    JSON_HANDLE hObject     = MOS_NULL;
    JSON_HANDLE hArryObject = MOS_NULL;
    JSON_HANDLE hArry       = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CRUISE_NODE *pstCruiseNode = MOS_NULL;
    ST_CFG_PRESET_NODE *pstPresetNode = MOS_NULL;  
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiPtzSign));

    if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SetPresetAbility",Adpt_Json_CreateStrWithNum(Config_GetPtzMng()->uiSetPreSetAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SetCuriseAbility",Adpt_Json_CreateStrWithNum(Config_GetPtzMng()->uiSetCuriseAbility));
    }
    if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        hArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"PreSets",hArry);
        
        FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stPresetList, pstPresetNode, stIterator)
        {
            if(pstPresetNode->uiUseFlag == 0)
            {
                continue;
            }
            hArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hArry,hArryObject); 
            
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"PresetId",Adpt_Json_CreateStrWithNum(pstPresetNode->uiPresetId));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Name",Adpt_Json_CreateString(pstPresetNode->aucName));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"PicID",Adpt_Json_CreateString(pstPresetNode->aucPicID));
            hObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Point",hObject);
            Adpt_Json_AddItemToObject(hObject,(_UC*)"X",Adpt_Json_CreateStrWithNum(pstPresetNode->stPtzPreset.iX));
            Adpt_Json_AddItemToObject(hObject,(_UC*)"Y",Adpt_Json_CreateStrWithNum(pstPresetNode->stPtzPreset.iY));  
        }

        hArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Cruises",hArry);
        
        FOR_EACHDATA_INLIST(&Config_GetPtzMng()->stCruiseList,pstCruiseNode,stIterator)
        {
            JSON_HANDLE hPointArry       = MOS_NULL;
            JSON_HANDLE hPointObject     = MOS_NULL;
            ST_MOS_LIST_ITERATOR stIterator1;
            ST_CFG_CRUISE_POINT_NODE *pstPointNode = MOS_NULL;
            
            if(pstCruiseNode->uiUseFlag == 0)
            {
                continue;
            }
            hArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hArry,hArryObject);

            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"CruiseID",Adpt_Json_CreateStrWithNum(pstCruiseNode->uiCruiseId));
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"Name",Adpt_Json_CreateString(pstCruiseNode->aucName));

            hPointArry = Adpt_Json_CreateArray();
            Adpt_Json_AddItemToObject(hArryObject,(_UC*)"PresetPoints",hPointArry);
            FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList,pstPointNode,stIterator1)
            {
                if(pstPointNode->uiUseFlag == 0)
                {
                    continue;
                }
                hPointObject = Adpt_Json_CreateObject();
                Adpt_Json_AddItemToArray(hPointArry,hPointObject);
                Adpt_Json_AddItemToObject(hPointObject,(_UC*)"PresetID",Adpt_Json_CreateStrWithNum(pstPointNode->uiPresetId));
                Adpt_Json_AddItemToObject(hPointObject,(_UC*)"DwellTime",Adpt_Json_CreateStrWithNum(pstPointNode->uiDwellTime));
                Adpt_Json_AddItemToObject(hPointObject,(_UC*)"Speed",Adpt_Json_CreateStrWithNum(pstPointNode->uiSpeed));
            }
        }

        hObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hObject,(_UC*)"PresetID",Adpt_Json_CreateStrWithNum(Config_GetPtzMng()->uiWatchPresetId));
        Adpt_Json_AddItemToObject(hObject,(_UC*)"WatchTime",Adpt_Json_CreateStrWithNum(Config_GetPtzMng()->uiWatchTime));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"WatchPoint",hObject);  
    }
    return hRoot;
}

_UC *Config_BuildPtzJson(_UI uiCfgType)
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = Config_BuildPtzObject(uiCfgType);
    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_LOG_INF(PTZ_LOGSTR,"build ptz info %s",pStrTmp);
    return pStrTmp;
}

// 读取PTZ云台配置的字段
_INT Config_ParsePtzJson(_UC *pStrJson,_UI uiCfgType)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _INT iArrySize,i;
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hArry,hArryObject,hObjetItem;
    ST_CFG_PRESET_NODE *pstPresetNode = MOS_NULL;
    ST_CFG_CRUISE_NODE *pstCruiseNode = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);

    // 每个配置项的版本ID  设备端生成
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiPtzSign);
    // 是否支持预置位能力   预置点设置能力支持  0.不支持； 1.支持 
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SetPresetAbility"),(_INT*)&Config_GetPtzMng()->uiSetPreSetAbility);
    // 是否支持智能巡航能力   智能巡航设置能力支持  0.不支持； 1.支持 
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SetCuriseAbility"),(_INT*)&Config_GetPtzMng()->uiSetCuriseAbility);
    
    // 预置点
    hArry = Adpt_Json_GetObjectItem(hRoot,(_UC*)"PreSets");
    iArrySize = Adpt_Json_GetArraySize(hArry);
    for(i = 0; i < iArrySize; i++)
    {
        pstPresetNode = (ST_CFG_PRESET_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_PRESET_NODE));
        if(pstPresetNode == MOS_NULL)
        {   
            continue;
        }
        hArryObject = Adpt_Json_GetArrayItem(hArry,i);
        // 预置点序号（1-256）
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"PresetId"),(_INT*)&pstPresetNode->uiPresetId);
        // 预置点名称
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Name"),&pStrTmp);
        MOS_STRNCPY(pstPresetNode->aucName, pStrTmp, sizeof(pstPresetNode->aucName));
        // 预置点图片ID，URL
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"PicID"),&pStrTmp);
        MOS_STRNCPY(pstPresetNode->aucPicID, pStrTmp, sizeof(pstPresetNode->aucPicID));
        // 预置点坐标
        hObjetItem = Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Point");
        // 预置点坐标 X轴
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"X"),(_INT*)&pstPresetNode->stPtzPreset.iX);
        // 预置点坐标 Y轴
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"Y"),(_INT*)&pstPresetNode->stPtzPreset.iY);
        pstPresetNode->uiUseFlag = 1;
        MOS_LIST_ADDTAIL(&Config_GetPtzMng()->stPresetList, pstPresetNode); 
    }

    // 轨迹
    hArry     = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Cruises");
    iArrySize = Adpt_Json_GetArraySize(hArry);
    for(i = 0; i < iArrySize; i++)
    {
        _INT j,iPointArrySize        = 0;
        JSON_HANDLE hPointArry       = MOS_NULL;
        JSON_HANDLE hPointObject     = MOS_NULL;
        ST_CFG_CRUISE_POINT_NODE *pstPointNode = MOS_NULL;
         
        hArryObject = Adpt_Json_GetArrayItem(hArry,i);
        
        pstCruiseNode = (ST_CFG_CRUISE_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_CRUISE_NODE));
        if(pstCruiseNode == MOS_NULL)
        {
            continue;
        }
        // 轨迹序号（1-8）
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"CruiseID"),(_INT*)&pstCruiseNode->uiCruiseId);
        // 轨迹名称
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Name"),&pStrTmp);
        MOS_STRNCPY(pstCruiseNode->aucName, pStrTmp, sizeof(pstCruiseNode->aucName));

        // 预置点
        hPointArry = Adpt_Json_GetObjectItem(hArryObject,(_UC*)"PresetPoints");
        iPointArrySize = Adpt_Json_GetArraySize(hPointArry);
        for(j = 0; j < iPointArrySize; j++)
        {
            hPointObject = Adpt_Json_GetArrayItem(hPointArry,j);
            pstPointNode = (ST_CFG_CRUISE_POINT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_CRUISE_POINT_NODE));
            if(pstPointNode == MOS_NULL)
            {
                continue;
            }
            pstPointNode->uiUseFlag = 1; 
            // 预置点序号（1-256）
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointObject,(_UC*)"PresetID"),(_INT*)&pstPointNode->uiPresetId);
            // 停留时间(5-60s)
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointObject,(_UC*)"DwellTime"),(_INT*)&pstPointNode->uiDwellTime);
            // 云台速度（1-7）
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointObject,(_UC*)"Speed"),(_INT*)&pstPointNode->uiSpeed);   
            MOS_LIST_ADDTAIL(&pstCruiseNode->stPointList, pstPointNode);
        }
        pstCruiseNode->uiUseFlag = 1;
        MOS_LIST_ADDTAIL(&Config_GetPtzMng()->stCruiseList,pstCruiseNode);
    }
    // 看守位
    hObjetItem = Adpt_Json_GetObjectItem(hRoot,(_UC*)"WatchPoint");
    if(hObjetItem)
    {
        // 预置点序号（1-256）
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"PresetID"),(_INT*)&Config_GetPtzMng()->uiWatchPresetId);
        // 看守位回归时间（5-360s）
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObjetItem,(_UC*)"WatchTime"),(_INT*)&Config_GetPtzMng()->uiWatchTime);
    }  
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}
