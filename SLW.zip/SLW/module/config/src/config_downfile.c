#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_api.h"
#include "qualityprobe_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"


// 接收文件数据间隔的最大时间 - 秒
#define DOWNFILE_RECV_MAXTIME           10
// 下载完整文件最大时间RECV - 秒
#define DOWNFILE_FINISH_MAXTIME         30
// 下载完整文件判断超时后，下载线程未及时处理状态 - 秒
#define DOWNFILE_TIMEOUT_MAXTIME        40
// 下载完整文件通知服务器结果最大时间 - 从结束下载开始  - 秒
#define DOWNFILE_FINISH_NOTIFY_MAXTIME  10
// 下载文件数量
#define DOWNFILE_MAX_NUM                3

#define DOWNFILE_HTTP_GET "GET %s HTTP/1.1\r\nHOST: %s:%d\r\nAccept: */*\r\nConnection: Close\r\n"

typedef enum enum_CFG_DOWNFILE_STATUS // 设备下载状态
{
    EN_CFG_DOWNFILE_NOT     = 0,    // 0:不需要下载
    EN_CFG_DOWNFILE_BEGIN   = 1,    // 1:开始下载
    EN_CFG_DOWNFILE_NOW     = 2,    // 2:下载中
    EN_CFG_DOWNFILE_SUCCESS = 3,    // 3:下载成功
    EN_CFG_DOWNFILE_TIMEOUT = 4,    // 4:下载超时 - 外部线程检测超时,下载线程释放资源,再设置为fail
    EN_CFG_DOWNFILE_FAIL    = 5     // 5:下载失败
} EN_CFG_DOWNFILE_STATUS;

typedef enum enum_CFG_DOWNFILE_NOTIFY_STATUS // 设备下载通知状态
{
    EN_CFG_DOWNFILE_NOTIFY_NOT     = 0,    // 0:不需要通知
    EN_CFG_DOWNFILE_NOTIFY_DOING   = 1,    // 1:正在通知
    EN_CFG_DOWNFILE_NOTIFY_TIMEOUT = 2,    // 2:通知超时
    EN_CFG_DOWNFILE_NOTIFY_COMPLETE= 3,    // 3:完成通知
} EN_CFG_DOWNFILE_NOTIFY_STATUS;

typedef struct stru_DOWNFILE_DATA
{
    _UC ucStatus;           // 下载状态 EN_CFG_DOWNFILE_STATUS
    _UC ucNotifyStatus;     // 通知状态 EN_CFG_DOWNFILE_NOTIFY_STATUS
    _UI uiHttpId;
    _UI uiOgctId;

    _UI uiHttpsFlag;            // https标志
    _UI uiTimeoutStatusCnt;     // 超时状态计数 - ucStatus == EN_CFG_DOWNFILE_TIMEOUT时，下载线程未(及时)处理与关闭该下载任务
    _CTIME_T cCheckRecvTime;    // 检测下载时间 - 定时
    _CTIME_T cLastRecvTime;     // 最新下载时间
    _CTIME_T cBegainTime;       // 下载开始时间
    _CTIME_T cNotifyTime;       // 通知开始时间

    _UI uiFileType;       // 下载文件格式 - EN_ZJ_FILE_FORMAT
    _UC aucFileName[CFG_STRING_MIDLEN];    // 下载文件名
    _UC aucFileUrl[CFG_STRING_BIGMAXLEN]; // 下载url路径
    _UI uiLastDownSize;   // 上次下载大小
    _UI uiDownSize;       // 下载大小
    _UC ucDownDataNtcFlag;// 下载数据通知标志/pfunDownDataNtc调用标志 0-未调用 1-已调用
    _UC ucDownDataTransErrFlag;// 下载数据传输错误标志

    ST_MOS_LIST_NODE stNode;
} ST_DOWNFILE_DATA;

typedef struct stru_OTATASK_MNG
{
    _UC ucInitFlag;
    _UC ucRunFlag;
    _UC ucDownloadingFlag;       // 下载任务正在下载中
    _UI uiOgctId;
    _HTHREAD hThread;
    _HMUTEX hMutex;
    // ST_DOWNFILE_DATA stDownFile;
    ST_MOS_LIST stDownFileList;
} ST_DOWNFILE_TASK_MNG;

/********************************************************************
*********************************************************************/
static ST_DOWNFILE_TASK_MNG g_stDownFileTaskMng;


/**********************************************************************
***********************************************************************/
static ST_DOWNFILE_TASK_MNG *DownFile_GetTaskMng()
{
    return &g_stDownFileTaskMng;
}

// DownFile 模块初始化
_INT DownFile_Task_Init()
{
    if (DownFile_GetTaskMng()->ucInitFlag == 1)
    {
        return MOS_OK;
    }
    MOS_MEMSET(&g_stDownFileTaskMng, 0, sizeof(g_stDownFileTaskMng));
    Mos_MutexCreate(&(DownFile_GetTaskMng()->hMutex));
    DownFile_GetTaskMng()->ucInitFlag = 1;
    return MOS_OK;
}

// DownFile 模块销毁
_INT DownFile_Task_Destroy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_DOWNFILE_DATA *pstDownFile = MOS_NULL;

    if (DownFile_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_OK;
    }

    FOR_EACHDATA_INLIST(&DownFile_GetTaskMng()->stDownFileList, pstDownFile, stIterator)
    {
        MOS_FREE(pstDownFile);
    }    
    MOS_LIST_RMVALL(&DownFile_GetTaskMng()->stDownFileList, MOS_TRUE);

    Mos_MutexDelete(&DownFile_GetTaskMng()->hMutex);

    if (DownFile_GetTaskMng()->hThread)
    {
        Mos_ThreadDelete(DownFile_GetTaskMng()->hThread);
        DownFile_GetTaskMng()->hThread = MOS_NULL;
    }
    DownFile_GetTaskMng()->ucInitFlag = 0;
    DownFile_GetTaskMng()->ucRunFlag  = 0;
    MOS_LOG_INF(DOWNFILE_LOGSTR, "down file task Destroy ok");

    return MOS_OK;
}

static ST_DOWNFILE_DATA *DownFile_AddDownloadTaskNode(_UI uiFileType, _UC *pucFileName, _UC *pucSoundUrl)
{
    ST_DOWNFILE_DATA *pstDownFile = MOS_NULL;

    Mos_MutexLock(&(DownFile_GetTaskMng()->hMutex));
    if (MOS_LIST_GETCOUNT(&DownFile_GetTaskMng()->stDownFileList) <= DOWNFILE_MAX_NUM)
    {
        pstDownFile = (ST_DOWNFILE_DATA*)MOS_MALLOCCLR(sizeof(ST_DOWNFILE_DATA));
        pstDownFile->uiHttpsFlag    = 0;
        pstDownFile->ucStatus       = EN_CFG_DOWNFILE_BEGIN;
        pstDownFile->cBegainTime    = Mos_Time();
        pstDownFile->ucNotifyStatus = EN_CFG_DOWNFILE_NOTIFY_NOT;
        pstDownFile->ucDownDataNtcFlag      = MOS_FALSE;
        pstDownFile->ucDownDataTransErrFlag = MOS_FALSE;

        pstDownFile->uiFileType = uiFileType;
        MOS_STRNCPY(pstDownFile->aucFileName, pucFileName, sizeof(pstDownFile->aucFileName));
        MOS_STRNCPY(pstDownFile->aucFileUrl, pucSoundUrl, sizeof(pstDownFile->aucFileUrl));
        
        MOS_LIST_ADDTAIL(&(DownFile_GetTaskMng()->stDownFileList), pstDownFile);
    }
    Mos_MutexUnLock(&(DownFile_GetTaskMng()->hMutex));
    
    if (pstDownFile)
    {
        MOS_LOG_INF(DOWNFILE_LOGSTR, "Start download file node %p filename %s", pstDownFile, pucFileName);
    }

    return pstDownFile;
}

// DownFile 开始下载文件
_INT DownFile_StartDownload(_UI uiFileType, _UC *pucFileName, _UC *pucSoundUrl)
{
    MOS_PARAM_NULL_RETERR(pucFileName);
    MOS_PARAM_NULL_RETERR(pucSoundUrl);

    _UC aucLogString[256] = {0};

    MOS_LOG_INF(DOWNFILE_LOGSTR, "FileName:%s SoundUrl:%s\n", pucFileName, pucSoundUrl);
    
    if (DownFile_AddDownloadTaskNode(uiFileType, pucFileName, pucSoundUrl) != MOS_NULL)
    {
        MOS_VSNPRINTF(aucLogString, sizeof(aucLogString), "start down file [type:%d name:%s] success", uiFileType, pucFileName);
        CloudStg_UploadLogEx2(DOWNFILE_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, EN_DOWNFILE_RT_START_TASK_SUCCEESS, aucLogString, MOS_NULL, 1);
        return MOS_OK;
    }
    else
    {
        MOS_VSNPRINTF(aucLogString, sizeof(aucLogString), "start down file [type:%d name:%s] fail", uiFileType, pucFileName);
        CloudStg_UploadLogEx2(DOWNFILE_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, EN_DOWNFILE_RT_START_TASK_FAIL, aucLogString, MOS_NULL, 1);        
        return MOS_ERR;
    }
}

//上报自定义文件入库结果应答 0x34E3
static _INT DownFile_RecvPubUpdateSoundFileStatusRsp(_UI uiReqId,_VPTR hJsonRoot)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_DOWNFILE_DATA *pstDownFile = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&DownFile_GetTaskMng()->stDownFileList, pstDownFile, stIterator)
    {
        if (pstDownFile->uiOgctId == uiReqId)
        {
            pstDownFile->uiOgctId = 0;
            pstDownFile->ucNotifyStatus = EN_CFG_DOWNFILE_NOTIFY_COMPLETE;
            break;
        }
    }
    if (pstDownFile == MOS_NULL)
    {
        MOS_LOG_ERR(DOWNFILE_LOGSTR,"ogct %u recv Publish downfile soundfile rsp, no found downfile node",uiReqId);
    }
    else
    {
        MOS_LOG_INF(DOWNFILE_LOGSTR,"ogct %u recv Publish downfile soundfile rsp node %p",uiReqId,pstDownFile);
    }
    
    //Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    return MOS_OK;
}
// 上报自定义文件入库结果 0x34E2
static _INT DownFile_PubUpdateSoundFileStatus(ST_DOWNFILE_DATA *pstDownFile, _INT iStatus)
{
    MOS_PARAM_NULL_RETERR(pstDownFile);

    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[16];
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;

    pstDownFile->uiOgctId = Mos_GetSessionId();
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%0X%0X", EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPDATESOUNDFILESTATTUS);
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"SEQID", Adpt_Json_CreateStrWithNum(pstDownFile->uiOgctId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"BODY", hBody);
    Adpt_Json_AddItemToObject(hBody, (_UC *)"FileName", Adpt_Json_CreateString(pstDownFile->aucFileName));
    Adpt_Json_AddItemToObject(hBody, (_UC *)"Status", Adpt_Json_CreateStrWithNum(iStatus));

    pStrTmp = Adpt_Json_Print(hRoot);

    MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID, pstDownFile->uiOgctId,
                   EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPDATESOUNDFILESTATTUS, pStrTmp, MOS_STRLEN(pStrTmp), DownFile_RecvPubUpdateSoundFileStatusRsp);

    MOS_FREE(pStrTmp);
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(DOWNFILE_LOGSTR, "ogct %u Publish downfile soundfile status %d node %p", pstDownFile->uiOgctId, iStatus, pstDownFile);
    return MOS_OK;
}

// 接收文件数据
static _VOID DownFile_HttpRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);
    MOS_PARAM_NULL_NORET(vpUserPtr);

    ST_DOWNFILE_DATA *pstDownFile = (ST_DOWNFILE_DATA *)vpUserPtr;

    pstDownFile->uiDownSize += uiLen;

    if (pstDownFile->ucDownDataNtcFlag == MOS_TRUE)
    {
        if (ZJ_GetFuncTable()->pfunDownDataTrans)
        {
            // 将文件数据回调给设备厂商
            if (MOS_OK != ZJ_GetFuncTable()->pfunDownDataTrans(pucData, uiLen, 0))
            {
                pstDownFile->ucDownDataTransErrFlag = MOS_TRUE;
            }
        }
        else
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "ZJ_GetFuncTable()->pfunDownDataTrans == NULL");
        }
    } 

    return;
}

// http 下载成功
static _VOID DownFile_HttpFinished(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    MOS_PARAM_NULL_NORET(vpUserPtr);

    ST_DOWNFILE_DATA *pstDownFile = (ST_DOWNFILE_DATA *)vpUserPtr;
    
    if (pstDownFile->ucDownDataNtcFlag == MOS_TRUE)
    {
        if (ZJ_GetFuncTable()->pfunDownDataTrans)
        {
            if (MOS_OK != ZJ_GetFuncTable()->pfunDownDataTrans(MOS_NULL, 0, 1))
            {
                pstDownFile->ucDownDataTransErrFlag = MOS_TRUE;
            }
        }
        else
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "ZJ_GetFuncTable()->pfunDownDataTrans == NULL");
        }
    }

    MOS_LOG_INF(DOWNFILE_LOGSTR, "%p Down file finish down size %u errflag %d", 
    pstDownFile, pstDownFile->uiDownSize, pstDownFile->ucDownDataTransErrFlag);
    // Qp_CountIF_Post(COUNT_TYPE_OTA, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    DownFile_GetTaskMng()->ucDownloadingFlag = 0;

    // pstDownFile对象操作后，才变更状态
    pstDownFile->uiHttpId = 0;
    pstDownFile->ucStatus = EN_CFG_DOWNFILE_SUCCESS;

    return;
}

// http 下载失败
static _VOID DownFile_HttpFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    MOS_PARAM_NULL_NORET(vpUserPtr);

    _UC aucLogString[256] = {0};
    ST_DOWNFILE_DATA *pstDownFile = (ST_DOWNFILE_DATA *)vpUserPtr;

    if (pstDownFile->ucDownDataNtcFlag == MOS_TRUE)
    {
        if (ZJ_GetFuncTable()->pfunDownDataStop)
        {
            ZJ_GetFuncTable()->pfunDownDataStop();
        }
        else
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "ZJ_GetFuncTable()->pfunDownDataStop == NULL");
        }
    }

    MOS_LOG_ERR(DOWNFILE_LOGSTR, "%p Down file http errcode:%u DownDataNtcFlag:%d", pstDownFile, uiErrCode, pstDownFile->ucDownDataNtcFlag);
    MOS_VSNPRINTF(aucLogString, sizeof(aucLogString), "%s parse url fail filename:%s", pstDownFile->uiHttpsFlag?"https":"http", pstDownFile->aucFileName);
    
    if (MOS_STRLEN(aucLogString))
    {
        CloudStg_UploadLogEx2(DOWNFILE_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, EN_DOWNFILE_RT_HTTP_REQUEST_FAIL, aucLogString, MOS_NULL, 1); 
    }
    DownFile_GetTaskMng()->ucDownloadingFlag = 0;

    // pstDownFile对象操作后，才变更状态
    pstDownFile->uiHttpId = 0;
    pstDownFile->ucStatus = EN_CFG_DOWNFILE_FAIL;
    return;
}

static _VOID DownFile_HttpRecvHeader(_VPTR vpUserPtr, _UI uiReqId, ST_HTTP_PRASE_HEAD stHttpParseHead)
{
    ST_DOWNFILE_DATA *pstDownFile = (ST_DOWNFILE_DATA *)vpUserPtr;
    if (stHttpParseHead.iResultCode == 200)
    {
        if (ZJ_GetFuncTable()->pfunDownDataNtc)
        {
            _INT iRet = ZJ_GetFuncTable()->pfunDownDataNtc(pstDownFile->uiFileType, stHttpParseHead.iContentLength, pstDownFile->aucFileName);
            if (iRet != MOS_OK)
            {
                MOS_LOG_ERR(DOWNFILE_LOGSTR, "pfunDownDataNtc return err=%d", iRet);        
            }
        }
        else
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "pfunDownDataNtc is NULL");
        }
        pstDownFile->ucDownDataNtcFlag = MOS_TRUE;
    }
    MOS_LOG_INF(DOWNFILE_LOGSTR, "down file %p ResultCode:%d", pstDownFile, stHttpParseHead.iResultCode);
}

// 开始下载声音文件
static _INT DownFile_StartDownFile(ST_DOWNFILE_DATA *pstDownFile)
{
    _INT iRet        = 0;
    _UI uiHttpsFlag  = 0;
    _UC *pucSubUrl   = MOS_NULL;
    _UC *pStrTmp     = MOS_NULL;
    _UC aucHost[256] = {0};

    if (MOS_STRLEN(pstDownFile->aucFileUrl) == 0)
    {
        MOS_LOG_ERR(DOWNFILE_LOGSTR, "DownloadUrl is Null");
        return MOS_ERR;
    }
    pStrTmp = MOS_STRSTR(pstDownFile->aucFileUrl, "https");
    if (pStrTmp == MOS_NULL)
    {
        pStrTmp = MOS_STRSTR(pstDownFile->aucFileUrl, "http");
        if (pStrTmp == MOS_NULL)
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "Download Url is Unrecognized %s", pstDownFile->aucFileUrl);
            return MOS_ERR;
        }
        pStrTmp += MOS_STRLEN("http://");
    }
    else
    {
        uiHttpsFlag = 1;
        pStrTmp += MOS_STRLEN("https://");
    }
    pucSubUrl = MOS_STRSTR(pStrTmp, "/");
    if (pucSubUrl == MOS_NULL)
    {
        MOS_LOG_ERR(DOWNFILE_LOGSTR, "Download Url is Incorrect format %s", pstDownFile->aucFileUrl);
        return MOS_ERR;
    }
    MOS_STRNCPY(aucHost, pStrTmp, pucSubUrl - pStrTmp);
    pstDownFile->uiHttpsFlag = uiHttpsFlag;
    MOS_LOG_INF(DOWNFILE_LOGSTR, "down file %p START REQUEST CONNECT DOWN URL(%s)", pstDownFile, pstDownFile->aucFileUrl);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = DownFile_HttpRecvFunc;
    stHttpInfoNode.pfuncFinished   = DownFile_HttpFinished;
    stHttpInfoNode.pfuncFailed     = DownFile_HttpFailed;
    stHttpInfoNode.pfuncRecvHeader = DownFile_HttpRecvHeader;
    stHttpInfoNode.vpUserPtr       = pstDownFile;
    stHttpInfoNode.iTimeOut        = 30;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, aucHost, pucSubUrl, EN_HTTP_METHOD_GET, pstDownFile->uiHttpId);

    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

// 下载文件状态
_VOID DownFile_ProcStatus()
{
    _INT iRet = MOS_OK;
    _CTIME_T cNowTime = 0;
    _CTIME_T cSubTime = 0;
    _UC aucLogString[256] = {0};
    ST_MOS_LIST_ITERATOR stIterator;
    ST_DOWNFILE_DATA *pstDownFile = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&DownFile_GetTaskMng()->stDownFileList, pstDownFile, stIterator)
    {
        cNowTime = Mos_Time();
        // 下载文件超时
        if (pstDownFile->ucStatus == EN_CFG_DOWNFILE_NOW && 
            ((_UI)cNowTime - pstDownFile->cBegainTime > DOWNFILE_FINISH_MAXTIME))
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "down file %p time out in download", pstDownFile);
            pstDownFile->ucStatus = EN_CFG_DOWNFILE_TIMEOUT;            
        }
        // 设置状态timeout后下载线程未及时处理
        else if(pstDownFile->ucStatus == EN_CFG_DOWNFILE_TIMEOUT && 
                (_UI)cNowTime - pstDownFile->cBegainTime > DOWNFILE_TIMEOUT_MAXTIME)
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "down file %p timeout logic error %s", pstDownFile, pstDownFile->aucFileName);
            pstDownFile->ucStatus = EN_CFG_DOWNFILE_FAIL;
        }

        // 判断传输数据错误标志
        if (pstDownFile->ucDownDataTransErrFlag == MOS_TRUE)
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "DownDataTransErrFlag is true");
            pstDownFile->ucDownDataTransErrFlag = MOS_FALSE;
            pstDownFile->ucStatus = EN_CFG_DOWNFILE_FAIL;
        }

        // 开始下载文件
        if (pstDownFile->ucStatus == EN_CFG_DOWNFILE_BEGIN)
        {
            // 有文件正在下载，同一时间只支持下载单个文件
            if (DownFile_GetTaskMng()->ucDownloadingFlag == 1)
            {
                break;
            }
            pstDownFile->cCheckRecvTime = cNowTime;
            pstDownFile->cLastRecvTime  = cNowTime;
            pstDownFile->uiDownSize     = 0;
            pstDownFile->uiLastDownSize = 0;
            pstDownFile->uiHttpId       = Mos_GetSessionId();
            // 开始下载文件
            iRet = DownFile_StartDownFile(pstDownFile);
            if (iRet == MOS_OK)
            {
                // Mos_MutexLock(&(DownFile_GetTaskMng()->hMutex));
                DownFile_GetTaskMng()->ucDownloadingFlag = 1;
                // Mos_MutexUnLock(&(DownFile_GetTaskMng()->hMutex));
                pstDownFile->ucStatus = EN_CFG_DOWNFILE_NOW;
            }
            else
            {
                pstDownFile->ucStatus = EN_CFG_DOWNFILE_FAIL;
                DownFile_GetTaskMng()->ucDownloadingFlag = 0;
                MOS_VSNPRINTF(aucLogString, sizeof(aucLogString), "start thread fail filename:%s", pstDownFile->aucFileName);
                CloudStg_UploadLogEx2(DOWNFILE_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, EN_DOWNFILE_RT_START_THREAD_FAIL, aucLogString, MOS_NULL, 1);                
            }

            MOS_LOG_INF(DOWNFILE_LOGSTR, "down file %p start status %u iret %d", pstDownFile, pstDownFile->ucStatus, iRet);
        }
        // 正在下载文件 - 检测正在下载文件
        else if (pstDownFile->ucStatus == EN_CFG_DOWNFILE_NOW && (_UI)(cNowTime - pstDownFile->cCheckRecvTime) >= 1)
        {
            pstDownFile->cCheckRecvTime = cNowTime;
            // 接收文件包数据超时
            if (pstDownFile->uiLastDownSize == pstDownFile->uiDownSize)
            {
                if (cNowTime - pstDownFile->cLastRecvTime > DOWNFILE_RECV_MAXTIME)
                {
                    MOS_LOG_ERR(DOWNFILE_LOGSTR, "down file %p too long time have no data", pstDownFile);
                    pstDownFile->ucStatus = EN_CFG_DOWNFILE_TIMEOUT;
                }
                break;
            }

            pstDownFile->cLastRecvTime = cNowTime;
        }
        // 下载文件成功
        else if (pstDownFile->ucStatus == EN_CFG_DOWNFILE_SUCCESS)
        {
            pstDownFile->uiHttpId       = 0;
            pstDownFile->ucStatus       = EN_CFG_DOWNFILE_NOT;
            pstDownFile->ucNotifyStatus = EN_CFG_DOWNFILE_NOTIFY_DOING;
            pstDownFile->cNotifyTime    = cNowTime;

            MOS_LOG_INF(DOWNFILE_LOGSTR, "down file %p success %s", pstDownFile, pstDownFile->aucFileName);
            DownFile_PubUpdateSoundFileStatus(pstDownFile, 1);
        }
        // 下载文件失败
        else if (pstDownFile->ucStatus == EN_CFG_DOWNFILE_FAIL)
        {
            if (pstDownFile->uiHttpId)
            {
                // Http异步取消请求
                Http_Httpclient_CancelAsyncRequestEx(pstDownFile->uiHttpId);
            }

            pstDownFile->uiHttpId       = 0;
            pstDownFile->ucStatus       = EN_CFG_DOWNFILE_NOT;
            pstDownFile->ucNotifyStatus = EN_CFG_DOWNFILE_NOTIFY_DOING;
            pstDownFile->cNotifyTime    = cNowTime;
            
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "down file %p failed %s", pstDownFile, pstDownFile->aucFileName);
            DownFile_PubUpdateSoundFileStatus(pstDownFile, 0);
        }
        
        // 下载结果，通知服务器超时
        if (pstDownFile->ucNotifyStatus == EN_CFG_DOWNFILE_NOTIFY_DOING &&
            ((_UI)cNowTime - pstDownFile->cNotifyTime > DOWNFILE_FINISH_NOTIFY_MAXTIME))
        {
            MOS_LOG_ERR(DOWNFILE_LOGSTR, "down file %p time out in notify server", pstDownFile);
            pstDownFile->ucNotifyStatus = EN_CFG_DOWNFILE_NOTIFY_TIMEOUT;

            MOS_VSNPRINTF(aucLogString, sizeof(aucLogString), "time out in notify server filename:%s", pstDownFile->aucFileName);
            CloudStg_UploadLogEx2(DOWNFILE_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, EN_DOWNFILE_RT_NOTIFY_STATUS_FAIL, aucLogString, MOS_NULL, 1);            
        }

        if (pstDownFile->ucNotifyStatus == EN_CFG_DOWNFILE_NOTIFY_TIMEOUT)
        {
            if (pstDownFile->uiOgctId != 0)
            {
                MsgMng_CancleReqMsg(pstDownFile->uiOgctId);
                pstDownFile->uiOgctId = 0;
            }
            pstDownFile->ucNotifyStatus = EN_CFG_DOWNFILE_NOTIFY_COMPLETE;
        }
        else if (pstDownFile->ucNotifyStatus == EN_CFG_DOWNFILE_NOTIFY_COMPLETE)
        {
            MOS_VSNPRINTF(aucLogString, sizeof(aucLogString), "notify server success filename:%s", pstDownFile->aucFileName);
            CloudStg_UploadLogEx2(DOWNFILE_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, EN_DOWNFILE_RT_NOTIFY_STATUS_SUCCESS, aucLogString, MOS_NULL, 1); 

            MOS_LOG_INF(DOWNFILE_LOGSTR, "down file %p notify server success", pstDownFile);
            Mos_MutexLock(&(DownFile_GetTaskMng()->hMutex));
            MOS_LIST_RMVNODE(&DownFile_GetTaskMng()->stDownFileList, pstDownFile);
            MOS_FREE(pstDownFile);
            Mos_MutexUnLock(&(DownFile_GetTaskMng()->hMutex));
            break;
        }
    }
    return;
}

