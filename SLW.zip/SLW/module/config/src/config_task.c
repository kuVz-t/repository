#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "config_json.h"
#include "config_sync.h"
#include "adpt_json_adapt.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "adpt_crypto_adapt.h"
#include "msgmng_api.h"
#include "kj_timer.h"
#include "watchdog_api.h"
#include "config_ap.h"
#include "ga1400_api.h"
#include "kjiot_device_prv.h"
#include "kjiot_device_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "msgmng_cmdserver.h"
#ifdef BUILD_IMSSDK_FALG
#include "ims_render.h"
#endif

#define DNS_GET_MAX_CNT 10                 // DNS获取最大个数
#define DNS_CONFIG_FILE "/etc/resolv.conf" // DNS配置文件

static ST_CONFIG_MNG g_CfgTask_Mng = {0};
/****************************************************************************************************
                                        局部函数声明
*****************************************************************************************************/
static _INT  Config_Task_Loop(_VPTR pParam);
static _VOID Config_LoadFile();
static _VOID Config_UpgradeSetSuperCodesStatus(_UI uiCurSdkVersion);
/****************************************************************************************************
*****************************************************************************************************/
ST_CONFIG_MNG *Config_Task_GetMng()
{
    return &g_CfgTask_Mng;
}
ST_CFG_ITEMSIGN *Config_GetItemSign()
{
    return &Config_Task_GetMng()->stOwner.stItemSign;
}
/****************************************************************************************************
                                        全局函数定义
*****************************************************************************************************/
_INT Config_Task_Init(_UC *pucSystemPath,_UC *pucWorkPath)
{
    MOS_PARAM_NULL_RETERR(pucSystemPath);
    MOS_PARAM_NULL_RETERR(pucWorkPath);

    if(Config_Task_GetMng()->ucInitFlag == 1)
    {
        return MOS_OK;
    }
    MOS_MEMSET(&g_CfgTask_Mng,0,sizeof(ST_CONFIG_MNG));
    Mos_SysInit(pucWorkPath);
    // 设置为调试模式
    Mos_SysSetDMode(MOS_TRUE);
    Mos_MutexCreate(&Config_Task_GetMng()->hMutex);
    Config_Task_GetMng()->hMsgQueque = Mos_MsgQueueCreate(MOS_FALSE,100, __FUNCTION__);
    Config_InitCamerMng();
    Config_InitDeviceMng();
    Config_IotHub_Init();
    Config_Cloud_Init();
    Config_InnerIot_Init();
    Config_InitAIMng();
    Config_Ims_Init();
    // OTA升级初始化
    Ota_Task_Init();
    DownFile_Task_Init();
    MOS_VSNPRINTF(Config_Task_GetMng()->aucCfgPath, MOS_DIR_NAME_LEN, "%s/config",Mos_GetWorkPath());
    Mos_DirMake(Config_Task_GetMng()->aucCfgPath,MOS_DIR_MAKE_FLAG);
    MOS_STRNCPY(Config_Task_GetMng()->aucSystemPath, pucSystemPath, sizeof(Config_Task_GetMng()->aucSystemPath));
    Mos_DirMake(Config_Task_GetMng()->aucSystemPath,MOS_DIR_MAKE_FLAG);
    
    Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_RECORD,0);
    // 读取配置文件的字段
    Config_LoadFile();
    Config_AddDefaultInIots(EN_ZJ_AIIOT_TYPE_EVENT);
#ifdef IOV_SERVER
    Config_AddDefaultInIots(EN_ZJ_AIIOT_TYPE_COLLISION);
#endif
    // 升级后检测是否需要打开超级编码开关
    Config_UpgradeSetSuperCodesStatus(STR_SDK_VERSION);

    Config_SetSdkVersion(STR_SDK_VERSION);//0x04040404);
    
    if(Config_GetSystemMng()->iCtrlType == EN_ZJ_CTRLDID_EXITGROUP)
    {
        Config_Task_GetMng()->stBevBindInf.ucNeedExitGroup = 1;
    }
    Config_Task_GetMng()->stBevBindInf.ucGetDstFlag = 1;
    Config_Task_GetMng()->stBevBindInf.cGetDstTime = Mos_Time() - 630 +  Mos_Time()%600;
    Config_Task_GetMng()->uiLoginCount = 0;
    Config_Task_GetMng()->uiDevAbilityUploadRetry = 0;
    Config_Task_GetMng()->uiDevBussUploadRetry = 0;
    Config_Task_GetMng()->ucInitFlag     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg task init ok msg queue %p ",Config_Task_GetMng()->hMsgQueque);
    return MOS_OK;
}

_INT Config_Task_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    if(Config_Task_GetMng()->ucRunFlag == 1)
    {
        return MOS_OK;
    }
    Config_Task_GetMng()->ucRunFlag = 1;
    Config_Task_GetMng()->cLastLoginTime = Mos_Time();
#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    if(Mos_ThreadCreate((_UC*)"cfg_task",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                      Config_Task_Loop,MOS_NULL,MOS_NULL,&Config_Task_GetMng()->hThread) == MOS_ERR)
    {
        Config_Task_GetMng()->ucRunFlag = 0;
        return MOS_ERR;
    }
    return MOS_OK;
}

_INT Config_Task_Stop()
{
    if(Config_Task_GetMng()->ucRunFlag == 0)
    {
        return MOS_OK;
    }
    Config_Task_GetMng()->ucRunFlag = 0;
    Mos_ThreadDelete(Config_Task_GetMng()->hThread);
    MOS_LOG_INF(CFG_LOGSTR,"cfg task stop ok");
    return MOS_OK;
}

_INT Config_Task_Destroy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_SYNC_NODE *pstSyncNode = MOS_NULL;
    ST_CFG_SERVER_NODE *pstServerNode = MOS_NULL;
    if(Config_Task_GetMng()->ucInitFlag == 0)
    {
        return MOS_OK;
    }
    Config_Task_GetMng()->ucInitFlag = 0;
    _VPTR pstMsg = MOS_NULL;
    while((pstMsg = Mos_MsgQueuePop(Config_Task_GetMng()->hMsgQueque)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    Mos_MsgQueueDelete(Config_Task_GetMng()->hMsgQueque);
    Config_Task_GetMng()->hMsgQueque = MOS_NULL;
    Config_FreeCameraMng();
    Config_InnerIot_Destroy();
    Config_IotHub_Destroy();
    Config_Cloud_Destroy();
    Config_AlarmPolicyDestroy();
    Config_TimePolicyDestroy();
    Ota_Task_Destroy();
    DownFile_Task_Destroy();
    Ptz_Task_Destroy();
    ServerSet_Task_Destroy();
    AI_Task_Destroy();
    Config_Ims_Destroy();
    
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);

    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stSyncList, pstSyncNode, stIterator)
    {
        MOS_LIST_RMVNODE(&Config_Task_GetMng()->stSyncList, pstSyncNode);
        MOS_LIST_ADDTAIL(&Config_Task_GetMng()->stSyncPoolList,pstSyncNode);
    }
    
    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stSyncPoolList, pstSyncNode, stIterator)
    {
        MOS_LIST_RMVNODE(&Config_Task_GetMng()->stSyncPoolList, pstSyncNode);
        MOS_FREE(pstSyncNode->pucMsgBuff);
        MOS_FREE(pstSyncNode);
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);

    FOR_EACHDATA_INLIST(&Config_Task_GetMng()->stServSyncList, pstServerNode, stIterator)
    {
        MOS_LIST_RMVNODE(&Config_Task_GetMng()->stServSyncList, pstServerNode);
        if(pstServerNode->hJsonRoot)
        {
            Adpt_Json_Delete(pstServerNode->hJsonRoot);
        }
        MOS_FREE(pstServerNode);
    }
    Mos_MutexDelete(&Config_Task_GetMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR,"cfg task Destroy ok");
    return MOS_OK;
}

/**
 * 说明：升级后检测是否需要打开超级编码开关
 * 需求：SDK4.8.1.1之前和SDK4.8.2.0的超级编码功能开关为关闭，升级SDK4.8.1.1及之后的版本(不包括SDK4.8.2.0)需要将开关置为开启状态
 * 注意：1. SDK4.8.1.1及之后的版本(不包括SDK4.8.2.0)升级更高版本时，升级后超级编码开关不需要置为开启状态
 *       2. 此接口需要在加载配置参数后(Config_LoadFile)及设置SDK版本(Config_SetSdkVersion)前调用
*/
static _VOID Config_UpgradeSetSuperCodesStatus(_UI uiCurSdkVersion)
{
    _UI uiOldSdkVersion = Config_GetDeviceMng()->uiSdkVersion;

    // 设备不为出厂和重置状态
    if (0 != uiOldSdkVersion)
    {
        // SDK4.8.1.1 、SDK4.8.2.1 版本都会支持 升级后检测是否需要打开超级编码开关
        // SDK4.8.4.0版本不会继续发放
        // SDK4.8.2.0、SDK4.8.3.0、SDK4.8.5.0不会支持该功能，不会出现Config_UpgradeSetSuperCodesStatus代码，表示uiCurSdkVersion不会等于0x04080200、0x04080300、0x04080500

        // 当前版本大于等于SDK4.8.1.1
        if (uiCurSdkVersion >= 0x04080101)
        {
            // 旧版本号小于SDK4.8.1.1 或者 等于SDK4.8.2.0  
            if (uiOldSdkVersion < 0x04080101 || uiOldSdkVersion == 0x04080200)
            {
                // 默认打开超级编码开关
                Config_SetCameraSuperCodesStatus(0, 1);
            }
        }
    }

    return;
}

_INT Config_SetLoginServerAddr(_INT offical_flag)
{
    MOS_MEMSET(&Config_Task_GetMng()->stCfgLoginServer, 0, sizeof(ST_CFG_LOGIN_SERVER_INFO));
    Config_Task_GetMng()->stCfgLoginServer.uiOfficialFlag = offical_flag;
    return MOS_OK;
}

_INT Config_GetLoginServerFlag()
{
    return Config_Task_GetMng()->stCfgLoginServer.uiOfficialFlag;
}

/**
 * brief 获取设备的DNS配置
 * param[out] pcData DNS配置
 * param[int] uiDataSize pcData空间大小  
 * return 0成功 其它失败
*/
static _INT Config_GetResolvConf(_C *pcData, _UI uiDataSize)
{
    MOS_PARAM_INVALID_RET(pcData, MOS_NULL, MOS_ERR);

    _INT iRet      = MOS_ERR;
    _UI uiCount    = 0;
    _UI uiDataLen  = 0;
    _UI uiStrLen   = 0;
    _C acLine[256] = {0};
    _C *pToken     = MOS_NULL;
    _HFILE hFile   = MOS_NULL;

    // 打开 resolv.conf 文件
    hFile = Mos_FileOpen(DNS_CONFIG_FILE, MOS_FILE_O_RDONLY);
    if (MOS_NULL == hFile) 
    {
        MOS_LOG_ERR(CFG_LOGSTR, "open %s fail!", DNS_CONFIG_FILE);
        return MOS_ERR;
    }

    // 逐行读取文件内容
    while (fgets(acLine, sizeof(acLine), hFile)) 
    {
        if ('#' == acLine[0]) 
        {
            // 跳过注释行
            continue;
        } 
        else if (MOS_NULL != MOS_STRSTR(acLine, "nameserver")) 
        {
            iRet = MOS_OK;

            // 去除换行符
            acLine[MOS_STRLEN(acLine) - 1] = '\0';

            // 解析DNS服务器IP地址
            pToken = strtok(acLine, " ");
            pToken = strtok(MOS_NULL, " ");
            uiStrLen = MOS_STRLEN(pToken);
            
            // 数据长度不能大于数据buffer空间大小
            if ((uiDataLen + uiStrLen + 2) < uiDataSize)
            {
                // 每个DNS之间用分号分隔
                if (uiDataLen > 0)
                {
                    MOS_STRCAT(pcData, ";");
                    uiDataLen += 1;
                }

                MOS_STRCAT(pcData, pToken);
                uiDataLen += uiStrLen;
            }
            else
            {
                break;
            }

            uiCount++;

            // 获取的DNS限制最大10个
            if (uiCount > DNS_GET_MAX_CNT)
            {
                break;
            }
        }
    }

    // 关闭文件
    Mos_FileClose(hFile);

    return iRet;
}

static _INT Config_PushOnlineStatus(_UI uiStatus, _INT msgType)
{
    _INT iRet = MOS_OK;

    if (msgType & CFG_AP_MSG)
    {
        do{
            ST_CFG_ONLINESTATUS_MSG *pstMsg = (ST_CFG_ONLINESTATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_CFG_ONLINESTATUS_MSG));
            if (pstMsg == NULL)
            {
                iRet = MOS_ERR;
                break;
            }
            pstMsg->stMsgHead.usMsgType = EN_CFG_MSG_ONLINESTATUS;
            pstMsg->uiOnlineStatus      = uiStatus;
            if (Mos_MsgQueuePush(Cfgap_GetTaskMng()->hMsgQueue, pstMsg) == MOS_ERR)
            {
                MOS_FREE(pstMsg);
                iRet = MOS_ERR;
                break;
            }
        }while(0);
    }

#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
    if (msgType & CFG_1400_MSG)
    {
        do{
            
            ST_CFG_ONLINESTATUS_MSG *pstMsg = (ST_CFG_ONLINESTATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_CFG_ONLINESTATUS_MSG));
            if (pstMsg == NULL)
            {
                iRet = MOS_ERR;
                break;
            }
            pstMsg->stMsgHead.usMsgType = EN_CFG_MSG_ONLINESTATUS;
            pstMsg->uiOnlineStatus      = uiStatus;
            if (Mos_MsgQueuePush(Ga1400_GetTaskMng()->hMsgQueue, pstMsg) == MOS_ERR)
            {
                MOS_FREE(pstMsg);
                iRet = MOS_ERR;
                break;
            }
        }while(0);
    }
#endif

    if (msgType & CFG_IOT_MSG)
    {
        do{
            ST_CFG_ONLINESTATUS_MSG *pstMsg = (ST_CFG_ONLINESTATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_CFG_ONLINESTATUS_MSG));
            if (pstMsg == NULL)
            {
                iRet = MOS_ERR;
                break;
            }
            pstMsg->stMsgHead.usMsgType = EN_KJIOT_MSG_ONLINESTATUS;
            pstMsg->uiOnlineStatus      = uiStatus;
            if (Mos_MsgQueuePush(KjIoT_GetMng()->hMsgQueue, pstMsg) == MOS_ERR)
            {
                MOS_FREE(pstMsg);
                iRet = MOS_ERR;
                break;
            }
        }while(0);
    }

#ifdef BUILD_IMSSDK_FALG
    if (msgType & CFG_IMS_MSG)
    {
        do{
            
            ST_CFG_ONLINESTATUS_MSG *pstMsg = (ST_CFG_ONLINESTATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_CFG_ONLINESTATUS_MSG));
            if (pstMsg == NULL)
            {
                iRet = MOS_ERR;
                break;
            }
            pstMsg->stMsgHead.usMsgType = EN_CFG_MSG_ONLINESTATUS;
            pstMsg->uiOnlineStatus      = uiStatus;
            if (Mos_MsgQueuePush(ImsMedia_GetTaskMng()->hImsMsgQueue, pstMsg) == MOS_ERR)
            {
                MOS_FREE(pstMsg);
                iRet = MOS_ERR;
                break;
            }
        }while(0);
    }
#endif

    return iRet;
}

_INT Config_SetDeviOnlineStatus(_UI uiStatus)
{
    _INT iRet = MOS_ERR;
    _UC CFG_COMMON_MSG = 0;
    ST_CFG_ONLINESTATUS_MSG *pstCfgMsg = (ST_CFG_ONLINESTATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_CFG_ONLINESTATUS_MSG));
    _UC aucBuf[512] = {0};
    _C  acResolvConf[256] = {0};

    if(pstCfgMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    if (uiStatus == EN_ZJ_DEVICE_STATUS_OFFLINE)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"-------------------- DEVICE OFFLINE --------------------");
        if(ZJ_GetFuncTable()->pFunSelfStatusCb)
        {
            ZJ_GetFuncTable()->pFunSelfStatusCb(EN_ZJ_SERVER_STATUS_INIT,0);
        }
        else
        {
             MOS_LOG_INF(CFG_LOGSTR,"Device pFunSelfStatusCb is NULL");
        }
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_REGISTINFO_RT_CMDSERVER_OFFLINE, "Device Offline", 1);
    }
    else // EN_ZJ_DEVICE_STATUS_ONLINE
    {
        MOS_LOG_INF(CFG_LOGSTR,"--------------------  DEVICE ONLINE --------------------");
        if(ZJ_GetFuncTable()->pFunSelfStatusCb)
        {
            ZJ_GetFuncTable()->pFunSelfStatusCb(EN_ZJ_SERVER_STATUS_PROCESS,0);
        }
        else
        {
             MOS_LOG_INF(CFG_LOGSTR,"Device pFunSelfStatusCb is NULL");
        }  

        // 设备上线上报当前休眠状态 0x3410
        MsgMng_UploadDevStatus(Config_GetCamaraMng()->uiCamOpenFlag, EN_DEV_STATUS_CHANGE_WAY_ONLINE);

        //上报设备运行时长、上次登录时间（单位为秒）、累计登陆次数
        Config_Task_GetMng()->uiLoginCount++;
        _UC *pucLastLoginTime = Mos_PrintTime(Config_Task_GetMng()->cLastLoginTime);
        MOS_SPRINTF(aucBuf, "Device Online! RunTime: %llu,  Last login time: %s, Login Count: %d, LinkV%d: %s", 
                            Mos_GetLLTickCount()/1000, pucLastLoginTime, Config_Task_GetMng()->uiLoginCount, 
                            (Config_GetCamaraMng()->uiMsgConnectNetType == 1) ? 6 : 4, 
                            (Config_GetCamaraMng()->uiMsgConnectNetType == 1) ? MsgMng_GetCmdServer()->aucLinkAddrIPv6 : MsgMng_GetCmdServer()->aucLinkAddrIPv4
                            );
        _INT iBufLen = MOS_STRLEN(aucBuf);
        // 信令IPv6方式连接 说明本地IPv6和返回的信令服务IPv6地址都存在 需上报云涛
        if (Config_GetCamaraMng()->uiMsgConnectNetType == 1)
        {
            _UC aucStrcatBuf[128] = {0};
            MOS_SPRINTF(aucStrcatBuf, ", ServAssignV6: %s, LocalV6: %s", Config_GetCoreMng()->aucHxLinkIPv6Addr, Config_GetCamaraMng()->aucLocalIPv6Addr);
            _INT iStrcatBufLen = MOS_STRLEN(aucStrcatBuf);
            if ((iBufLen + iStrcatBufLen) < sizeof(aucBuf))
            {
                MOS_STRCAT(aucBuf, aucStrcatBuf);
            }
        }
        else
        {
            // 信令IPv4方式连接 本地IPv6或返回的信令服务IPv6地址如果存在 则上报对应的字段到云涛
            if (MOS_STRLEN(Config_GetCoreMng()->aucHxLinkIPv6Addr) > 0)
            {
                _UC aucStrcatLinkBuf[128] = {0};
                MOS_SPRINTF(aucStrcatLinkBuf, ", ServAssignV6: %s", Config_GetCoreMng()->aucHxLinkIPv6Addr);
                MOS_STRCAT(aucBuf, aucStrcatLinkBuf);
            }
            if (MOS_STRLEN(Config_GetCamaraMng()->aucLocalIPv6Addr) > 0)
            {
                _UC aucStrcatLocalBuf[128] = {0};
                MOS_SPRINTF(aucStrcatLocalBuf, ", LocalV6: %s", Config_GetCamaraMng()->aucLocalIPv6Addr);
                MOS_STRCAT(aucBuf, aucStrcatLocalBuf);
            }
        }

        // 云涛上报DNS配置
        MOS_STRCAT(aucBuf, " DNS:");
        iRet = Config_GetResolvConf(acResolvConf, sizeof(acResolvConf));
        if (MOS_OK == iRet)
        {
             MOS_STRCAT(aucBuf, acResolvConf);
        }
        else
        {
            MOS_STRCAT(aucBuf, "get error");
        }
    
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_REGISTINFO_RT_CMDSERVER_ONLINE, aucBuf, 1);
        MOS_LOG_INF(CFG_LOGSTR, "%s", aucBuf);
        MOS_FREE(pucLastLoginTime);
        Config_Task_GetMng()->cLastLoginTime = Mos_Time();
    }

    Config_Task_GetMng()->uiDevAbilityUploadRetry = 0;
    Config_Task_GetMng()->uiDevBussUploadRetry    = 0;
    pstCfgMsg->stMsgHead.usMsgType = EN_CFG_MSG_ONLINESTATUS;
    pstCfgMsg->uiOnlineStatus      = uiStatus;

    iRet = Mos_MsgQueuePush(Config_Task_GetMng()->hMsgQueque,pstCfgMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCfgMsg);
        return MOS_ERR;
    }

    if (Cfgap_GetTaskMng()->ucRunFlag >= 1)
    {
        CFG_COMMON_MSG |= CFG_AP_MSG;
    }

#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
    if (Ga1400_GetTaskMng()->ucRunFlag >= 1)
    {
        CFG_COMMON_MSG |= CFG_1400_MSG;
    }
#endif

    if (KjIoT_GetMng()->ucBRun >= 1)
    {
        CFG_COMMON_MSG |= CFG_IOT_MSG;
    }

#ifdef BUILD_IMSSDK_FALG
    if (ImsMedia_GetTaskMng()->ucRunFlag >= 1)
    {
        CFG_COMMON_MSG |= CFG_IMS_MSG;
    }
#endif

    //发送上线状态给各模块
    if (Config_PushOnlineStatus(uiStatus, CFG_COMMON_MSG) == MOS_ERR)
    {
        printf("Push Online Status fail\r\n");
        return MOS_ERR;
    }

    return MOS_OK;
}

_INT Config_SetSyncCfgByp2pFlag(_UC *pucPeerId,_UI uiOgctId,_UI uiCfgItem,_UI uiSign,ST_CFG_MSGSRCINF *pstSrcInf)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstSrcInf);

    _UI uiCode    = 0;
    _UI uiCfgType = EN_CFG_TYPE_ALL;
    _UC aucMethod[8];
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hObject  = MOS_NULL;
    JSON_HANDLE hFromObj = MOS_NULL;
    JSON_HANDLE hToObj   = MOS_NULL;
    JSON_HANDLE hRoot    = Adpt_Json_CreateObject();
    JSON_HANDLE hBodyObj = Adpt_Json_CreateObject();
    
    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_P2P_CFGSYNC_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiOgctId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(uiCode));

    hFromObj = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"FROM",hFromObj);
    Adpt_Json_AddItemToObject(hFromObj,(_UC*)"DID",Adpt_Json_CreateString(Config_GetSystemMng()->aucDid));

    if(MOS_STRLEN(pstSrcInf->aucServId) > 0 || MOS_STRLEN(pstSrcInf->aucUsrToken) > 0)
    {
        hToObj = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"TO",hToObj);
        if(MOS_STRLEN(pstSrcInf->aucServId) > 0){
            Adpt_Json_AddItemToObject(hToObj,(_UC*)"SvrID",Adpt_Json_CreateString(pstSrcInf->aucServId));
            uiCfgType = EN_CFG_TYPE_BUSSNESS;
        }
        if(MOS_STRLEN(pstSrcInf->aucUsrToken) > 0){
            Adpt_Json_AddItemToObject(hToObj,(_UC*)"UserToken",Adpt_Json_CreateString(pstSrcInf->aucUsrToken));
        }
    }
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBodyObj);
    
    if((uiCfgItem & EN_ZJ_CFG_ITEM_DEVICE) > 0 && uiSign != Config_GetItemSign()->uiDevSign)
    {
        hObject = Config_BuildDeviceObject(EN_CFG_TYPE_ALL);
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"Device",hObject);
    }
    if((uiCfgItem & EN_ZJ_CFG_ITEM_CAMERA) > 0 && uiSign != Config_GetItemSign()->uiCamSign)
    {
        hObject = Config_BuildCameraObject(EN_CFG_TYPE_ALL);
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"Camera",hObject);
    }
    if((uiCfgItem & EN_ZJ_CFG_ITEM_PTZ) > 0 && uiSign != Config_GetItemSign()->uiPtzSign)
    {
        hObject = Config_BuildPtzObject(EN_CFG_TYPE_ALL);
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"PresetSetting",hObject);
    }
    if((uiCfgItem & EN_ZJ_CFG_ITEM_INIOT) > 0 && uiSign != Config_GetItemSign()->uiInIotSign)
    {
        hObject = Config_BuildInnerIotObject(EN_CFG_TYPE_ALL);
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"InAIIoT",hObject);
    }
    if((uiCfgItem & EN_ZJ_CFG_ITEM_IOTHUB) > 0 && uiSign != Config_GetItemSign()->uiIotHubSign)
    {
        hObject = Config_BuildIotHubObject(EN_CFG_TYPE_ALL);
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"AIIoTHub",hObject);
    }
    if((uiCfgItem & EN_ZJ_CFG_ITEM_TIMEPOLICY) > 0 && uiSign != Config_GetItemSign()->uiTimePolicySign)
    {
        hObject = Config_BuildTimerPolicyObject(EN_CFG_TYPE_ALL);
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"TimePolicy",hObject);
    }
    if((uiCfgItem & EN_ZJ_CFG_ITEM_ALARMPOLICY) > 0 && uiSign != Config_GetItemSign()->uiAlarmPolicySign)
    {
        hObject = Config_BuildAlarmPolicyObject(EN_CFG_TYPE_ALL);
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"IoTPolicy",hObject);
    }
    if((uiCfgItem & EN_ZJ_CFG_ITEM_SYSTEM ) > 0 && uiSign != Config_GetItemSign()->uiSystemSign)
    {
        hObject = Config_BuildSystemObject();
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"System",hObject);
    }
    if((uiCfgItem & EN_ZJ_CFG_ITEM_SERVERSET ) > 0 && uiSign != Config_GetItemSign()->uiServSetSign)
    {
        hObject = Config_BuildServerSetObject();
        Adpt_Json_AddItemToObject(hBodyObj,(_UC*)"ServerSet",hObject);
    }
    pStrTmp = Adpt_Json_Print(hRoot);
    Config_AddSyncClientNode(pucPeerId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_P2P_CFGSYNC_RSP,uiOgctId,pStrTmp,MOS_STRLEN(pStrTmp));
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_INT Config_SetDevNeedBindFlag(_UC *pucBindCode,_UC *pucGroupId)
{
    MOS_PARAM_NULL_RETERR(pucBindCode);
    MOS_PARAM_NULL_RETERR(pucGroupId);
    
    MOS_STRNCPY(Config_Task_GetMng()->stBevBindInf.aucBindCode, pucBindCode, sizeof(Config_Task_GetMng()->stBevBindInf.aucBindCode));
    MOS_STRNCPY(Config_Task_GetMng()->stBevBindInf.aucBindGroupId,pucGroupId,sizeof(Config_Task_GetMng()->stBevBindInf.aucBindGroupId));
    Config_Task_GetMng()->stBevBindInf.ucBindFlag = 1;
    return MOS_OK;
}

_INT Config_GetExitGroupFlag()
{
    return Config_Task_GetMng()->stBevBindInf.ucNeedExitGroup;
}

/****************************************************************************************************
                                        局部函数定义
*****************************************************************************************************/
ST_CFG_INF *Config_GetlocalCfgInf()
{
    return &g_CfgTask_Mng.stOwner;
}

static _INT  Config_Task_ProcOnlineMsg(_VPTR pstMsg) 
{
    MOS_PARAM_NULL_RETERR(pstMsg);

    JSON_HANDLE hRoot = MOS_NULL;
    ST_CFG_ONLINESTATUS_MSG *pstCfgMsg = (ST_CFG_ONLINESTATUS_MSG *)pstMsg;

    Config_Task_GetMng()->ucOnlineStatus = (_UC)pstCfgMsg->uiOnlineStatus;
    
    if(pstCfgMsg->uiOnlineStatus == 1)
    {		
        if(Config_GetCoreMng()->ucAbilityUpFlag == 0)
        {			
            hRoot = Config_BuildLocalAbilityJson(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD);
            Config_AddSyncServerCfgTask(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD,0,hRoot);
            Config_GetCoreMng()->ucAbilityUpFlag = 1;
        }
        if(Config_GetCoreMng()->ucBussUpFlag == 0)
        {			
            hRoot = Config_BuildLocalBussJson(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_UPLOAD,EN_ZJ_CFG_ITEM_ALL);  
            Config_AddSyncServerCfgTask(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_UPLOAD,0,hRoot);
            Config_GetCoreMng()->ucBussUpFlag = 1;
        }
        if(MOS_STRLEN(Config_GetGroupInf()->aucOwnerId) == 0 && MOS_STRLEN(Config_GetGroupInf()->aucGrpid) > 0)
        {
            Config_Task_GetMng()->stBevBindInf.ucGetGroupInfFlag = 1;
        }
    }
    MOS_LOG_INF(CFG_LOGSTR,"recv online msg status %u,upability %u, upconfig %u",
        Config_Task_GetMng()->ucOnlineStatus,Config_GetCoreMng()->ucAbilityUpFlag,Config_GetCoreMng()->ucBussUpFlag);
    return  MOS_OK;
}

static _INT Config_Task_ProcMsg(_VPTR pstMsg)
{
    MOS_PARAM_NULL_RETERR(pstMsg);

    ST_MOS_MSGHEAD *pstMsgHead = (ST_MOS_MSGHEAD *)pstMsg;
    
    switch (pstMsgHead->usMsgType) 
    {
        case EN_CFG_MSG_ONLINESTATUS:
        {
            Config_Task_ProcOnlineMsg(pstMsg);
        }
        break;
        default:
        {
            break;
        }
    }
    return MOS_OK;
}

//update cfgItem TO SERVER 上报配置属性到信令服务器
static _VOID Config_UpdateItemFile()
{
    _UI uiCfgUpItem = 0;
    JSON_HANDLE hRoot = MOS_NULL;

    if(Config_GetCoreMng()->ucAbilityUpFlag != 2 && Config_GetCoreMng()->ucBussUpFlag != 2)
    {
        return;
    } 
	if( Config_Task_GetMng()->ucOnlineStatus == 0)
	{
		return;
	}
    if(Config_GetItemSign()->ucCfgDevUpdate == 1)
    {
        Config_GetItemSign()->ucSaveCore = 1;
        Config_GetItemSign()->ucCfgDevUpdate = 2;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_DEVICE;
    }
    if(Config_GetItemSign()->ucCfgCamUpdate == 1)
    {
        Config_GetItemSign()->ucSaveCore = 1;
        Config_GetItemSign()->ucCfgCamUpdate = 2;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_CAMERA;
    }
    if(Config_GetItemSign()->ucCfgInIotUpdate)
    {
        Config_GetItemSign()->ucCfgInIotUpdate = 0;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_INIOT;
    }
    if(Config_GetItemSign()->ucCfgIotHubUpdate)
    {
        Config_GetItemSign()->ucCfgIotHubUpdate = 0;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_IOTHUB;
    }

    if(Config_GetItemSign()->ucCfgTimePolicyUpdate == 1)
    {
        Config_GetItemSign()->ucSaveCore = 1;
        Config_GetItemSign()->ucCfgTimePolicyUpdate = 2;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_TIMEPOLICY;
    }

    if(Config_GetItemSign()->ucAlarmPolicyUpdate == 1)
    {
        Config_GetItemSign()->ucSaveCore = 1;
        Config_GetItemSign()->ucAlarmPolicyUpdate = 2;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_ALARMPOLICY;
    } 
    
    if(Config_GetItemSign()->ucCfgScenePolicyUpdate)
    {
        Config_GetItemSign()->ucCfgScenePolicyUpdate = 0;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_SCENEPOLICY;
    }
    
    if(Config_GetItemSign()->ucCfgPtzUpdate)
    {
        Config_GetItemSign()->ucCfgPtzUpdate = 0;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_PTZ;
    }

    if(Config_GetItemSign()->ucCfgAiUpdate)
    {
        Config_GetItemSign()->ucCfgAiUpdate = 0;
        uiCfgUpItem += EN_ZJ_CFG_ITEM_AI;
    }

    if(uiCfgUpItem > 0)
    {
        MOS_LOG_INF(CFG_LOGSTR,"cfg update cfgitem %u to server",uiCfgUpItem);
        hRoot = Config_BuildLocalBussJson(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_UPDATE,uiCfgUpItem);
        Config_AddSyncServerCfgTask(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_UPDATE,uiCfgUpItem,hRoot);
    }
    return;
}

static _INT Config_EncConfigParam(_UC *pucInBuff,_UC *pucOutBuff,_INT iSystemFlag)
{
    MOS_PARAM_NULL_RETERR(pucInBuff);
    MOS_PARAM_NULL_RETERR(pucOutBuff);

    _INT iStrLen    = 0;
    _INT iTotalLen  = 0;
    _UC *pucEncode  = MOS_NULL;
    _UC aucAesKey[32] = {'\0'};
    _UC aucAESVI[17] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',0};

    iStrLen = MOS_STRLEN(pucInBuff);
    pucEncode = (_UC*)MOS_MALLOCCLR(iStrLen + 32);
    MOS_STRNCPY(pucEncode, pucInBuff, iStrLen);
    
    iTotalLen = MOS_HEX_NUM(iStrLen);
    if(iTotalLen - iStrLen > 0)
    {
        MOS_MEMSET(pucEncode + iStrLen, iTotalLen - iStrLen, iTotalLen - iStrLen);
    }
    
    if(iSystemFlag == 1)
    {
        MOS_STRNCPY(aucAesKey,"qweasdzxc1234567",16);
    }
    else if(MOS_STRLEN(Config_GetSystemMng()->aucDevCTEI) > 0)
    {
        MOS_STRNCPY(aucAesKey, Config_GetSystemMng()->aucDevCTEI, 16);
    }
    else
    {
        MOS_MEMSET(aucAesKey, 0x31, 16);
    }
    Adpt_Aec_Encrypt(aucAesKey,aucAESVI,pucEncode,pucOutBuff,iTotalLen);
    MOS_FREE(pucEncode);
    return iTotalLen;
}

static _INT Config_DecConfigParam(_UC *pucInBuff,_UC *pucOutBuff,_INT iLen,_INT iSystemFlag)
{
    MOS_PARAM_NULL_RETERR(pucInBuff);
    MOS_PARAM_NULL_RETERR(pucOutBuff);

    _UC aucAesKey[32] = {'\0'};
    _UC aucAESVI[17] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',0};
    if(iSystemFlag == 1)
    {
        MOS_STRNCPY(aucAesKey,"qweasdzxc1234567",16);
    }
    else if(MOS_STRLEN(Config_GetSystemMng()->aucDevCTEI) > 0)
    {
        MOS_STRNCPY(aucAesKey, Config_GetSystemMng()->aucDevCTEI, 16);
    }
    else
    {
        MOS_MEMSET(aucAesKey, 0x31, 16);
    }
    Adpt_Aec_Decrypt(aucAesKey,aucAESVI,pucInBuff,pucOutBuff,iLen); 
    return MOS_OK;
}

// 储存配置属性到配置文件
static _VOID Config_Task_SaveItemFile()
{
    _UC *pStrTmp;
    _INT iRet         = MOS_ERR;
    _INT iTolLen      = 0;
    _UC *pucOutBuff   = MOS_NULL;
    _UC  aucBuff[256] = {0};
    
    if(Config_GetItemSign()->ucSaveSystem)
    {
        Config_GetItemSign()->ucSaveSystem = 0;
        Config_GetItemSign()->uiSystemSign += Mos_Time()%1000;
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucSystemPath,CFG_NEWSYSTEM_FILE);
        pStrTmp = Config_BuildSystemJson();

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,1);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }
    if(Config_GetItemSign()->ucSaveCore)
    {
        Config_GetItemSign()->uiCoreSign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveCore = 0;
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_CORE_FILE);
        pStrTmp = Config_BuildCoreInfJson();

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }
    if(Config_GetItemSign()->ucSaveDev)
    {
        Config_GetItemSign()->uiDevSign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveDev = 0;
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_DEVICE_FILE);
        pStrTmp = Config_BuildDeviceJson(EN_CFG_TYPE_ALL);

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
        if(ZJ_GetFuncTable()->pfunCfgItemChangeCb)
        {
            iRet = ZJ_GetFuncTable()->pfunCfgItemChangeCb(EN_ZJ_CFG_ITEM_DEVICE);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(CFG_LOGSTR,"Device pfunCfgItemChangeCb(iValue:%d) err", EN_ZJ_CFG_ITEM_DEVICE);
            }
        }
        else
        {
            MOS_LOG_ERR(CFG_LOGSTR,"pfunCfgItemChangeCb is NULL!");
        }
    }
    if(Config_GetItemSign()->ucSaveCamInf)
    {
        Config_GetItemSign()->uiCamSign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveCamInf = 0;
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_CAMERA_FILE);

        pStrTmp = Config_BuildCameraJson(EN_CFG_TYPE_ALL);    

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }
        
    if(Config_GetItemSign()->ucSaveInIot)
    {
        Config_GetItemSign()->uiInIotSign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveInIot = 0;

        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_INIOT_FILE);
        pStrTmp = Config_BuildInnerIotJson(EN_CFG_TYPE_ALL);

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    if(Config_GetItemSign()->ucSaveIotHub)
    {
        Config_GetItemSign()->uiIotHubSign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveIotHub = 0;

        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_IOTHUB_FILE);
        pStrTmp = Config_BuildIotHubJson(EN_CFG_TYPE_ALL);

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    if(Config_GetItemSign()->ucSaveTimePolicy)
    {
        Config_GetItemSign()->uiTimePolicySign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveTimePolicy = 0;

        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_TIMEPOLICY_FILE);
        pStrTmp = Config_BuildTimePolicyJson(EN_CFG_TYPE_ALL);

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    if(Config_GetItemSign()->ucSaveAlarmPolicy)
    {
        Config_GetItemSign()->uiAlarmPolicySign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveAlarmPolicy = 0;
        
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_ALARMPOLICY_FILE);
        pStrTmp = Config_BuildIotPolicyJson(EN_CFG_TYPE_ALL);

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    if(Config_GetItemSign()->ucSaveScenePolicy)
    {
        Config_GetItemSign()->uiScenePolicySign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveScenePolicy = 0;
        
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_SCENEPOLICY_FILE);
        pStrTmp = Config_BuildScenePolicyJson(EN_CFG_TYPE_ALL);

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    if(Config_GetItemSign()->ucSaveGroup)
    {
        Config_GetItemSign()->uiGroupSign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveGroup = 0;

        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_GROUP_FILE);
        pStrTmp = Config_BuildGroupInfItem();

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
        if(ZJ_GetFuncTable()->pfunCfgItemChangeCb)
        {
            iRet = ZJ_GetFuncTable()->pfunCfgItemChangeCb(EN_ZJ_CFG_ITEM_GROUPINF);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(CFG_LOGSTR,"Device pfunCfgItemChangeCb(iValue:%d) err", EN_ZJ_CFG_ITEM_DEVICE);
            }
        }
        else
        {
            MOS_LOG_ERR(CFG_LOGSTR,"pfunCfgItemChangeCb is NULL!");
        }
    }

    if(Config_GetItemSign()->ucSavePtz)
    {
        Config_GetItemSign()->uiPtzSign += Mos_Time()%1000;
        Config_GetItemSign()->ucSavePtz = 0;
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_PTZ_FILE);
        pStrTmp = Config_BuildPtzJson(EN_CFG_TYPE_ALL);

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pStrTmp);
        MOS_FREE(pucOutBuff);
    }

    if(Config_GetItemSign()->ucSaveServSetFlag)
    {
        Config_GetItemSign()->uiServSetSign += Mos_Time()%1000;
        Config_GetItemSign()->ucSaveServSetFlag = 0;
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_SERVERSET_FILE);
        pStrTmp = Config_BuildServerSetJson();

        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    } 

    if(Config_GetItemSign()->ucSaveCloudFlag)
    {
        Config_GetItemSign()->ucSaveCloudFlag = 0;
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_CLOUDSTG_FILE);
        pStrTmp = Config_BuildCloudSetJson();
        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    if(Config_GetItemSign()->ucSaveCloudPatchFlag)
    {
        Config_GetItemSign()->ucSaveCloudPatchFlag = 0;
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_GetCoreMng()->aucCachePath,CFG_CLOUDSTG_PATCH_FILE);
        pStrTmp = Config_BuildCloudPatchSetJson();
        MOS_LOG_WARN(CFG_LOGSTR, "Ready to malloc %d", MOS_STRLEN(pStrTmp) + 16);
        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff,0);
        if (MOS_FALSE == Mos_FileSave(aucBuff, pucOutBuff, iTolLen))
        {
            MOS_LOG_ERR(CFG_LOGSTR,"can't save file %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    if(Config_GetItemSign()->ucSaveAiFlag)
    {
        Config_GetItemSign()->ucSaveAiFlag = 0;
        MOS_VSNPRINTF(aucBuff, 256, "%s/%s", Config_Task_GetMng()->aucCfgPath, CFG_AI_FILE);
        pStrTmp = Config_BuildAIJson(EN_CFG_TYPE_ALL);
        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff, 0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);
        MOS_FREE(pStrTmp);
        MOS_FREE(pucOutBuff);
    }

    if(Config_GetItemSign()->ucSaveImsFlag)
    {
        Config_GetItemSign()->ucSaveImsFlag = 0;
        MOS_VSNPRINTF(aucBuff, 256, "%s/%s", Config_Task_GetMng()->aucCfgPath, CFG_IMS_FILE);
        pStrTmp = Config_BuildImsSetJson();
        pucOutBuff = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrTmp) + 16);
        iTolLen = Config_EncConfigParam(pStrTmp,pucOutBuff, 0);
        Mos_FileSave(aucBuff, pucOutBuff, iTolLen);
        MOS_FREE(pStrTmp);
        MOS_FREE(pucOutBuff);
    }

    return ;
}

_VOID Config_LoadCloudPatchFile()
{
    _UC aucBuff[256]  = {0};
    _UC *pStrTmp      = MOS_NULL;
    _INT iLen         = 0;
    _UC *pucOutBuff   = MOS_NULL;

    // cloudpatchcfg.db 加载云存设置配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_GetCoreMng()->aucCachePath,CFG_CLOUDSTG_PATCH_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
        Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
        // 读取云存配置的字段
        // MOS_LOG_INF(CFG_LOGSTR,"load patch cloud set inf %s",pucOutBuff);
        Config_ParseCloudPatchSetJson(pucOutBuff);
        // MOS_PRINTF("load patch cloud set inf file %s, %s\r\n", Config_GetCoreMng()->aucCachePath, pucOutBuff);
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }
    else
    {
        MOS_LOG_ERR(CFG_LOGSTR,"can't load file %s",aucBuff);
    }
}

// 读取配置文件的字段
static _VOID Config_LoadFile()
{
    _UC aucBuff[256]  = {0};
    _UC *pStrTmp      = MOS_NULL;
    _UC *pucOutBuff   = MOS_NULL;
    _INT iLen         = 0;
    _UI uiAllSaveFlag = 0;
    _UI uiCfgEnfFlag  = 0;
    
    // systemcfg.db 加载系统配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucSystemPath,CFG_SYSTEM_FILE);
    if(Mos_FileLoad(aucBuff,&pStrTmp) > 0)
    {
        MOS_LOG_INF(CFG_LOGSTR, "load systerm file %s",aucBuff);
        // 读取系统配置的字段
        Config_ParseSystemJson(pStrTmp);
        MOS_FREE(pStrTmp);
        Mos_FileRmv(aucBuff);
        uiAllSaveFlag = 1;
        Config_GetItemSign()->ucSaveSystem   = uiAllSaveFlag;
    }
    else
    {
        // systemencrycfg.db 加载系统配置字段
        MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucSystemPath,CFG_NEWSYSTEM_FILE);
        iLen = Mos_FileLoad(aucBuff,&pStrTmp);
        if(iLen > 0)
        {
            MOS_LOG_INF(CFG_LOGSTR, "load new systerm file %s",aucBuff);
            uiCfgEnfFlag = 1;
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,1);
            // 读取系统配置的字段
            Config_ParseSystemJson(pucOutBuff);
            MOS_FREE(pStrTmp);
            MOS_FREE(pucOutBuff);
        }
    }
    
    // corecfg.db 加载核心配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_CORE_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取core核心配置的字段
            Config_ParseCoreInfJson(pucOutBuff);
            MOS_LOG_INF(CFG_LOGSTR, "load core file %s",aucBuff);
        }
        else
        {
            // 读取core核心配置的字段
            Config_ParseCoreInfJson(pStrTmp);
            Config_GetItemSign()->ucSaveCore = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR, "load core file %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }
    
    // devcfg.db 加载设备配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_DEVICE_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取设备配置的字段
            Config_ParseDeviceJson(pucOutBuff,EN_CFG_TYPE_ALL);
            MOS_LOG_INF(CFG_LOGSTR, "load device file %s",aucBuff);
        }
        else
        {
            // 读取设备配置的字段
            Config_ParseDeviceJson(pStrTmp,EN_CFG_TYPE_ALL);
            Config_GetItemSign()->ucSaveDev = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR, "load device file %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }
    else
    {
        Config_GetDeviceMng()->uiAwakeInterval = DEVICE_AWAKE_INTERVAL_DEFAULT;
    }

    // camcfg.db 加载摄像机配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_CAMERA_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取摄像机配置的字段
            Config_ParseCameraJson(pucOutBuff,EN_CFG_TYPE_ALL);
            MOS_LOG_INF(CFG_LOGSTR, "load camera file %s",aucBuff);
        }
        else
        {
            // 读取摄像机配置的字段
            Config_ParseCameraJson(pStrTmp,EN_CFG_TYPE_ALL);
            Config_GetItemSign()->ucSaveCamInf = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR, "load camera file %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // iniotcfg.db 加载内部IOT配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_INIOT_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取内部IOT配置的字段
            Config_ParseInnerIotJson(pucOutBuff,EN_CFG_TYPE_ALL);
            MOS_LOG_INF(CFG_LOGSTR, "load InIot file %s",aucBuff);
        }
        else
        {
            // 读取内部IOT配置的字段
            Config_ParseInnerIotJson(pStrTmp,EN_CFG_TYPE_ALL);
            Config_GetItemSign()->ucSaveInIot = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR, "load InIot file %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // iothubcfg.db 加载拓展IOT配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_IOTHUB_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取拓展IOT配置的字段
            Config_ParseIotHubJson(pucOutBuff,EN_CFG_TYPE_ALL);
            MOS_LOG_INF(CFG_LOGSTR, "load iothub file %s",aucBuff);
        }
        else
        {
            // 读取拓展IOT配置的字段
            Config_ParseIotHubJson(pStrTmp,EN_CFG_TYPE_ALL);
            Config_GetItemSign()->ucSaveIotHub = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR, "load iothub file %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // timepolicy.db  加载定时策略配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_TIMEPOLICY_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取定时策略配置的字段
            Config_ParseTimePolicyJson(pucOutBuff,EN_CFG_TYPE_ALL);
            MOS_LOG_INF(CFG_LOGSTR, "load timePolicy file %s",aucBuff);
        }
        else
        {
            // 读取定时策略配置的字段
            Config_ParseTimePolicyJson(pStrTmp,EN_CFG_TYPE_ALL);
            Config_GetItemSign()->ucSaveTimePolicy = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR, "load timePolicy file %s",aucBuff);
        }

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // alarmpolicy.db  加载报警策略配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_ALARMPOLICY_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取报警策略配置的字段
            Config_ParseAlarmPolicyJson(pucOutBuff,EN_CFG_TYPE_ALL);
            MOS_LOG_INF(CFG_LOGSTR,"load alarm policy %s",aucBuff);
        }
        else
        {
            Config_ParseAlarmPolicyJson(pStrTmp,EN_CFG_TYPE_ALL);
            // 读取报警策略配置的字段
            Config_GetItemSign()->ucSaveAlarmPolicy = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR,"load alarm policy %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // groupcfg.db  加载Group组配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_GROUP_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取Group组配置的字段
            Config_ParseGroupInfItem(pucOutBuff);
            MOS_LOG_INF(CFG_LOGSTR,"load Group inf %s",aucBuff);
        }
        else
        {
            // 读取Group组配置的字段
            Config_ParseGroupInfItem(pStrTmp);
            Config_GetItemSign()->ucSaveGroup = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR,"load Group inf %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // ptzcfg.db 加载PTZ云台配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_PTZ_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取PTZ云台配置的字段
            Config_ParsePtzJson(pucOutBuff,EN_CFG_TYPE_ALL);
            MOS_LOG_INF(CFG_LOGSTR,"load ptz inf %s",aucBuff);
        }
        else
        {
            // 读取PTZ云台配置的字段
            Config_ParsePtzJson(pStrTmp,EN_CFG_TYPE_ALL);
            Config_GetItemSign()->ucSavePtz = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR,"load ptz inf %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // servsetcfg.db  加载服务器设置配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_SERVERSET_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取服务器设置配置的字段
            Config_ParseServerSetJson(pucOutBuff);
            MOS_LOG_INF(CFG_LOGSTR,"load Server Set inf %s",aucBuff);
        }
        else
        {
            // 读取服务器设置配置的字段
            Config_ParseServerSetJson(pStrTmp);
            Config_GetItemSign()->ucSaveServSetFlag = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR,"load Server Set inf %s",aucBuff);
        }
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }
    
    // cloudcfg.db 加载云存设置配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_CLOUDSTG_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
        Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
        // 读取云存配置的字段
        Config_ParseCloudSetJson(pucOutBuff);
        MOS_LOG_INF(CFG_LOGSTR,"load cloud set inf %s",aucBuff);
        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // aicfg.db 加载设备配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_AI_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取设备配置的字段
            Config_ParseAIJson(pucOutBuff,EN_CFG_TYPE_ALL);
            MOS_LOG_INF(CFG_LOGSTR, "load AI file %s",aucBuff);
        }
        else
        {
            // 读取设备配置的字段
            Config_ParseAIJson(pStrTmp,EN_CFG_TYPE_ALL);
            Config_GetItemSign()->ucSaveAiFlag = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR, "load AI file %s",aucBuff);
        }

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    // imscfg.db 加载设备配置字段
    MOS_MEMSET(aucBuff, 0, sizeof(aucBuff));
    MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_Task_GetMng()->aucCfgPath,CFG_IMS_FILE);
    iLen = Mos_FileLoad(aucBuff,&pStrTmp);
    if(iLen > 0)
    {
        if(uiCfgEnfFlag == 1)
        {
            pucOutBuff = (_UC*)MOS_MALLOCCLR(iLen + 16);
            Config_DecConfigParam(pStrTmp,pucOutBuff,iLen,0);
            // 读取设备配置的字段
            Config_ParseImsSetJson(pucOutBuff);
            MOS_LOG_INF(CFG_LOGSTR, "load IMS file %s",aucBuff);
        }
        else
        {
            // 读取设备配置的字段
            Config_ParseImsSetJson(pStrTmp);
            Config_GetItemSign()->ucSaveAiFlag = uiAllSaveFlag;
            MOS_LOG_INF(CFG_LOGSTR, "load IMS file %s",aucBuff);
        }

        MOS_FREE(pucOutBuff);
        MOS_FREE(pStrTmp);
    }

    return ;
}

static _INT Config_ProcStatusChangeFlag()
{
    JSON_HANDLE hRoot = MOS_NULL;
    if(Config_GetCoreMng()->ucStatusUpFlag == 0)
    {
        return MOS_OK;
    }
   
    Config_GetCoreMng()->ucStatusUpFlag = 0;
    
    hRoot = Config_BuildUpLoadStatusJson(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVSTATUS_UPDATE);
    
    Config_AddSyncServerCfgTask(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVSTATUS_UPDATE,0,hRoot);

    MOS_LOG_INF(CFG_LOGSTR,"update device status to server");
    return MOS_OK;
}

static _INT Config_ProcUpload4GFlow(_UI  uiNowTime)
{
    _UC aucMethod[8];
	_UI uiUseFlow   = 0;
    _UI uiUsedFlow  = 0;
    _UI uiSendFlow  = 0;
    _UI uiRecvFlow  = 0;
    _HANDLE hBody   = MOS_NULL;
    _HANDLE hRoot   = MOS_NULL;
    _US uiSeqID     = Mos_GetSessionId();
    _UC *pucStrTmp  = MOS_NULL;
    _INT iRet       = MOS_ERR;

    if(Config_Task_GetMng()->uiLastTime == 0)
    {
        Config_Task_GetMng()->uiLastTime = uiNowTime;
    }

    Mos_SocketGetTotalTraffic(&uiSendFlow, &uiRecvFlow);
    uiUseFlow = uiSendFlow + uiRecvFlow;
    uiUsedFlow = (uiUseFlow - Config_GetDeviceMng()->uiLastUseFlow)/1024; //单位M

	if((_UI)(uiNowTime -  Config_Task_GetMng()->uiLastTime) > 600 || uiUsedFlow >=10)  //十分钟轮询或者使用流量>十
	{
        Config_Task_GetMng()->uiLastTime     = uiNowTime;
        Config_GetDeviceMng()->uiLastUseFlow = uiUseFlow;

        hRoot   = Adpt_Json_CreateObject();
        MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEV4GFLOWUPLOAD_REQ);
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqID));
        hBody   = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"BitFlow",Adpt_Json_CreateStrWithNum(uiUsedFlow));

        // 因为天翼视联统一SDK与能力平台对接规范没有该信令, 并且中台不支持该信令应答, 采用Config_AddSyncServerCfgTask请求时会导致任务队列累加
        // 所以这里发送时不需要注册应答接口
        // Config_AddSyncServerCfgTask(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEV4GFLOWUPLOAD_REQ,0,hRoot);
        pucStrTmp = Adpt_Json_Print(hRoot);
    
        iRet = MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID, uiSeqID, EN_OGCT_METHOD_CFGBUSS, EN_OGCT_CFGBUSS_DEV4GFLOWUPLOAD_REQ,
        pucStrTmp, MOS_STRLEN(pucStrTmp), MOS_NULL);

        Adpt_Json_DePrint(pucStrTmp);
        Adpt_Json_Delete(hRoot);

        MOS_LOG_INF(CFG_LOGSTR,"ogct %u upload used flow :%d ret %d", uiSeqID, uiUsedFlow, iRet);
	}

    return MOS_OK;
}

/******************************************************************************
21cn 平台 设备BIND 功能
******************************************************************************/
static _UC *Config_BuildDxBindDeviceJson(_UI uiSeqId)
{
    _UC aucBuff[256];
    _UC *pucOutBuff;
    _UC *pStrTmp   = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    ST_ZJ_NETWORK_INFO stNetWorkInf;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;

    MOS_MEMSET(&stNetWorkInf, 0, sizeof(stNetWorkInf));
    if(ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetWorkInf);
        if (iRet == MOS_ERR)
        {
             MOS_LOG_ERR(CFG_LOGSTR,"Device pfunGetCurNetInfo err");  
        }
    }
    else
    {
        MOS_LOG_ERR(CFG_LOGSTR,"pfunGetCurNetInfo is NULL!");
    }
     
    MOS_VSNPRINTF(aucBuff, 8,(_UC*)"%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJCMD_BINDDEV);  
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucBuff));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiSeqId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"BindCode", Adpt_Json_CreateString(pstBindInf->aucBindCode));
    
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Mac", Adpt_Json_CreateString(stNetWorkInf.aucMacAddr));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CTEI", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"FirmwareVersion", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));

    uiSeqId = Mos_GetTickCount();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp", Adpt_Json_CreateStrWithNum(uiSeqId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DevType", Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iDevOsType));

    MOS_VSNPRINTF(aucBuff, 256,"BindCode=%s&CTEI=%s&DevType=%u&DID=%s&FirmwareVersion=%s&Mac=%s&TimeStamp=%u",
        pstBindInf->aucBindCode,Config_GetSystemMng()->aucDevCTEI,Config_GetDeviceMng()->iDevOsType,
        Config_GetSystemMng()->aucDevUID,Config_GetDeviceMng()->aucDevVerSion,stNetWorkInf.aucMacAddr,uiSeqId);

    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);
    Adpt_HmacSha256_Encrypt(aucBuff,pucOutBuff,128,Config_GetSystemMng()->aucDevkey);

    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}


_VOID Config_RecvDxDevBindRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;

    if(pstBindInf->usBuffLen == 0)
    {
        pstBindInf->usBuffLen   = 1024;
        pstBindInf->pucHttpBuff = (_UC*)MOS_MALLOC(pstBindInf->usBuffLen);
    }
    if(pstBindInf->usRecvLen + uiLen < pstBindInf->usBuffLen)
    {
        MOS_MEMCPY(pstBindInf->pucHttpBuff + pstBindInf->usRecvLen, pucData, uiLen);
        pstBindInf->usRecvLen += uiLen;
    }
    return;
}

_VOID Config_RecvDxDevBindFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;
    
    if(pstBindInf->pucHttpBuff)
    {
        pstBindInf->pucHttpBuff[pstBindInf->usRecvLen] = 0;
    }
    MOS_LOG_INF(CFG_LOGSTR,"rev bind rsp %s",pstBindInf->pucHttpBuff);
    MOS_FREE(pstBindInf->pucHttpBuff);
    pstBindInf->pucHttpBuff = MOS_NULL;
    pstBindInf->usBuffLen   = 0;
    pstBindInf->usRecvLen   = 0;
    pstBindInf->uiReqID     = 0;
    pstBindInf->ucBindFlag  = 3;
    return ;
}

_VOID Config_RecvDxDevBindFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;
    
    _UC pucUrl[256] = {0};

    MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucOtherAddr, CFG_ABILITYBINDDEV_URL);
    CloudStg_UploadLogEx(Mos_GetSessionId(), pucUrl, uiErrCode, EN_CFGNET_RT_BIND_DEVICE, "bind device error", pstBindInf->pucHttpBuff, 1); 

    MOS_FREE(pstBindInf->pucHttpBuff);
    pstBindInf->pucHttpBuff = MOS_NULL;
    pstBindInf->usBuffLen   = 0;
    pstBindInf->usRecvLen   = 0;
    pstBindInf->uiReqID     = 0;
    pstBindInf->ucBindFlag  = 4;
    MOS_LOG_ERR(CFG_LOGSTR,"rev bind rsp fail");
    return;
}

_INT Config_BindDxDeviceToAblityPlat()
{
	_INT i,iRet = 0;
    _US usPort = 80;
    _UI uiHttpsFlag = 0;
    _UC *pucHttpBody = MOS_NULL;
    _UC *pStrTmp  = MOS_NULL;
    _UC *pStrStart = MOS_NULL;
    _UC auAdmonAddr[MOS_INET_IPV6_STR_SIZE];
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;
    
    MOS_MEMSET(auAdmonAddr, 0, MOS_INET_IPV6_STR_SIZE);
    
    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucOtherAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 
    
    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucOtherAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucOtherAddr;
    }
	else
	{
		pStrStart += 2;
	}
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRNCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    MOS_LOG_INF(CFG_LOGSTR,"get Bind device pu addr %s",Config_GetSystemMng()->aucOtherAddr);
    _UI uiSeqId = Mos_GetSessionId();
    pucHttpBody = Config_BuildDxBindDeviceJson(uiSeqId);  
    pstBindInf->uiReqID = uiSeqId;
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = Config_RecvDxDevBindRsp;
    stHttpInfoNode.pfuncFinished   = Config_RecvDxDevBindFinish;
    stHttpInfoNode.pfuncFailed     = Config_RecvDxDevBindFail;
    stHttpInfoNode.pucContent      = pucHttpBody;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pucHttpBody);
    stHttpInfoNode.iTimeOut        = 15;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, CFG_ABILITYBINDDEV_URL, EN_HTTP_METHOD_POST, uiSeqId);
    MOS_LOG_INF(CFG_LOGSTR,"dev %s ,send BindMsg %s to abilityPlat %s ,url %s, ret %d",
        Config_GetSystemMng()->aucDevUID, pucHttpBody, auAdmonAddr, CFG_ABILITYBINDDEV_URL, iRet);   
    MOS_FREE(pucHttpBody);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;  /*FIXME 上层未使用此返回值*/
}

static _VOID Config_ProcDevBindFlag(ST_CFG_BINDDEVINF *pstBindInf,_UI uiNowTime)
{
    MOS_PARAM_NULL_NORET(pstBindInf);

    if(pstBindInf->ucBindFlag == 1)
    {
        pstBindInf->uiReqTime = uiNowTime;
        pstBindInf->ucBindFlag = 2;
        Config_BindDxDeviceToAblityPlat();
    }
    else if(pstBindInf->ucBindFlag == 2 && uiNowTime - pstBindInf->uiReqTime > 60)
    {
        // handleID被赋值为seqID
        if(pstBindInf->uiReqID)
        {
            Http_Httpclient_CancelAsyncRequestEx(pstBindInf->uiReqID);
            pstBindInf->uiReqID = 0;
        }
        pstBindInf->ucBindFlag = 1;
    }
    else if(pstBindInf->ucBindFlag == 3)
    {
        MOS_MEMSET(pstBindInf->aucBindCode,0,CFG_STRING_COMMONLEN);
        MOS_MEMSET(pstBindInf->aucBindGroupId,0,CFG_STRING_COMMONLEN);
        pstBindInf->ucBindFlag = 0;
    }
    else if(pstBindInf->ucBindFlag == 4)
    {
        MOS_MEMSET(pstBindInf->aucBindCode,0,CFG_STRING_COMMONLEN);
        MOS_MEMSET(pstBindInf->aucBindGroupId,0,CFG_STRING_COMMONLEN);
        pstBindInf->ucBindFlag = 0;
    }
    return;
}
/************************************************************************
设备获取组的 公共信息
**************************************************************************/
_INT Config_ProcGetGroupInfRsp(_UI uiSeqID, JSON_HANDLE hRoot)
{
    MOS_PARAM_NULL_RETERR(hRoot);

    _INT iCode        = 0;
    _UC *pucStrTmp    = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hGroupInf = MOS_NULL;
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;
    
    do
    {
        if(pstBindInf->uiReqID != uiSeqID)
        {
            break;
        }
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iCode);
        if(iCode != 0)
        {
            pstBindInf->ucGetGroupInfFlag = 4;
            break;
        }
        hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
        if(hBody == MOS_NULL)
        {
            pstBindInf->ucGetGroupInfFlag = 4;
            break;
        }
        hGroupInf = Adpt_Json_GetObjectItem(hBody,(_UC*)"GIDInfo");
        if(hGroupInf == MOS_NULL)
        {
            pstBindInf->ucGetGroupInfFlag = 4;
            break;
        }
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hGroupInf,(_UC*)"Owner"),&pucStrTmp);
        Config_SetDevGroupOwnerId(pucStrTmp);
        pstBindInf->ucGetGroupInfFlag = 3;
        pstBindInf->ucGetUsrInfFlag   = 1;
        
    }while(0);

    MOS_LOG_INF(CFG_LOGSTR,"ogct %u recv group pubinf rspcode %d onwerid %s",uiSeqID,iCode,Config_GetGroupInf()->aucOwnerId);
    return MOS_OK;
}

_INT Config_SendGetGroupInfToServer(ST_CFG_BINDDEVINF *pstBindInf)
{
    MOS_PARAM_NULL_RETERR(pstBindInf);

    _INT iRet;
    _UC aucMethod[8];
    _UC *pStrTmp   = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    
    pstBindInf->uiReqID = Mos_GetSessionId();

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, (_UC*)"%02X%02X",EN_OGCT_METHOD_GROUP, EN_OGCT_GROUP_GETINF);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstBindInf->uiReqID));
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"GID", Adpt_Json_CreateString(Config_GetGroupInf()->aucGrpid));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Item", Adpt_Json_CreateStrWithNum(0X10));

    pStrTmp = Adpt_Json_Print(hRoot);
    iRet = MsgMng_SendMsg(MSGMNG_P2P_SERVER_ID,pstBindInf->uiReqID,EN_OGCT_METHOD_GROUP, EN_OGCT_GROUP_GETINF,
        pStrTmp,MOS_STRLEN(pStrTmp),Config_ProcGetGroupInfRsp);

    MOS_LOG_INF(CFG_LOGSTR,"ogct %u get group pubinf body %s iRet %d",pstBindInf->uiReqID,pStrTmp,iRet);
    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pStrTmp);
    return iRet;
}

_INT Config_ProcGetGroupInfStatus(ST_CFG_BINDDEVINF *pstBindInf,_UI uiTimeNow)
{
    MOS_PARAM_NULL_RETERR(pstBindInf);

    if(pstBindInf->ucGetGroupInfFlag == 1)
    {
        Config_SendGetGroupInfToServer(pstBindInf);
        pstBindInf->ucGetGroupInfFlag = 2;
        pstBindInf->uiReqTime = uiTimeNow;
    }
    else if(pstBindInf->ucGetGroupInfFlag == 2 && (_UI)(uiTimeNow - pstBindInf->uiReqTime) > 20)
    {
        MsgMng_CancleReqMsg(pstBindInf->uiReqID);
        pstBindInf->uiReqID = 0;
        pstBindInf->ucGetGroupInfFlag = 1;
    }
    else if(pstBindInf->ucGetGroupInfFlag == 3 || pstBindInf->ucGetGroupInfFlag == 4)
    {
        pstBindInf->ucGetGroupInfFlag = 0;
    }
    return MOS_OK;
}


/************************************************************************************
获取用户的公开信息
*************************************************************************************/
_INT Config_ProcGetUsrPubInfRsp(_UI uiSeqID, JSON_HANDLE hRoot)
{
    MOS_PARAM_NULL_RETERR(hRoot);
    
    _INT iCode        = 0;
    _UC *pucStrTmp    = MOS_NULL;
    _UC *pucMobile    = MOS_NULL;
    _UC *pucAccout    = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;
    
    do
    {
        if(pstBindInf->uiReqID != uiSeqID)
        {
            break;
        }
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iCode);
        if(iCode != 0)
        {
            pstBindInf->ucGetUsrInfFlag = 4;
            break;
        }
        hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
        if(hBody == MOS_NULL)
        {
            pstBindInf->ucGetUsrInfFlag = 4;
            break;
        }
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Name"),&pucStrTmp);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Account"),&pucAccout);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Phone"),&pucMobile);

        Config_SetDevOwnerPubInf(pucStrTmp,pucAccout,pucMobile);
        pstBindInf->ucGetUsrInfFlag = 3;
        
    }while(0);

    MOS_LOG_INF(CFG_LOGSTR,"ogct %u recv group pubinf rsp code %d onwerid %s",uiSeqID,iCode,Config_GetGroupInf()->aucOwnerId);
    return MOS_OK;
}

_INT Config_SendGetUsrPubInfToServer(ST_CFG_BINDDEVINF *pstBindInf)
{
    MOS_PARAM_NULL_RETERR(pstBindInf);

    _INT iRet;
    _UC *pStrTmp   = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    _UC aucMethod[8];
    
    pstBindInf->uiReqID = Mos_GetSessionId();
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, (_UC*)"%02X%02X",EN_OGCT_METHOD_GROUP, EN_OGCT_GROUP_GETUSRPUBINF);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstBindInf->uiReqID));
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Userid", Adpt_Json_CreateString(Config_GetGroupInf()->aucOwnerId));

    pStrTmp = Adpt_Json_Print(hRoot);
    
    iRet = MsgMng_SendMsg(MSGMNG_P2P_SERVER_ID,pstBindInf->uiReqID,EN_OGCT_METHOD_GROUP, EN_OGCT_GROUP_GETUSRPUBINF,
        pStrTmp,MOS_STRLEN(pStrTmp),Config_ProcGetUsrPubInfRsp);

    MOS_LOG_INF(CFG_LOGSTR,"ogct %u req user pubinf body %s iRet %d",pstBindInf->uiReqID,pStrTmp,iRet);
    
    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pStrTmp);
    return iRet;
}

_INT Config_ProcGetUsrPubInfStatus(ST_CFG_BINDDEVINF *pstBindInf, _UI uiTimeNow)
{
    MOS_PARAM_NULL_RETERR(pstBindInf);

    if(pstBindInf->ucGetUsrInfFlag == 1)
    {
        Config_SendGetUsrPubInfToServer(pstBindInf);
        pstBindInf->ucGetUsrInfFlag = 2;
        pstBindInf->uiReqTime = uiTimeNow;
    }
    else if(pstBindInf->ucGetUsrInfFlag == 2 && (_UI)(uiTimeNow - pstBindInf->uiReqTime) > 20)
    {
        MsgMng_CancleReqMsg(pstBindInf->uiReqID);
        pstBindInf->uiReqID = 0;
        pstBindInf->ucGetUsrInfFlag = 1;
    }
    else if(pstBindInf->ucGetUsrInfFlag == 3 || pstBindInf->ucGetUsrInfFlag == 4)
    {
        pstBindInf->ucGetUsrInfFlag = 0;
    }
    return MOS_OK;
}

/*******************************************************************************
退组操作
********************************************************************************/
_INT Config_ProcResetDevRsp(_UI uiSeqID, JSON_HANDLE hRoot)
{
    MOS_PARAM_NULL_RETERR(hRoot);

    _INT iCode;
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;
    
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    do{
        if(pstBindInf->uiReqID != uiSeqID)
        {
            break;
        }
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iCode);
        if(iCode != 0)
        { 
            break;
        }
        pstBindInf->ucNeedExitGroup = 3;
    }while(0);

    MOS_LOG_INF(CFG_LOGSTR,"ogct %u recv reset device rsp code %u ",uiSeqID,iCode);
    return MOS_OK; 
}

_INT Config_SendResetDeviceToServer(ST_CFG_BINDDEVINF *pstBindInf)
{
     MOS_PARAM_NULL_RETERR(pstBindInf);

    _INT iRet = MOS_OK;
    _UC aucMethod[8] = {0};
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;

    pstBindInf->uiReqID = Mos_GetSessionId();

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, (_UC*)"%02X%02X",EN_OGCT_METHOD_GROUP, EN_OGCT_GROUP_DEVRESET);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstBindInf->uiReqID));

    pStrTmp = Adpt_Json_Print(hRoot);
    iRet = MsgMng_SendMsg(MSGMNG_P2P_SERVER_ID,pstBindInf->uiReqID,EN_OGCT_METHOD_GROUP,EN_OGCT_GROUP_DEVRESET,
        pStrTmp,MOS_STRLEN(pStrTmp),Config_ProcResetDevRsp);

    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pStrTmp);
    MOS_LOG_INF(CFG_LOGSTR,"ogct %u reset device iRet %d",pstBindInf->uiReqID,iRet);
    return iRet;
}

static _INT Config_ProcExitGroupFlag(ST_CFG_BINDDEVINF *pstBindInf,_UI uiTimeNow)
{
    MOS_PARAM_NULL_RETERR(pstBindInf);

    if(pstBindInf->ucNeedExitGroup == 1)
    {
        if(MOS_STRLEN(Config_GetGroupInf()->aucGrpid) == 0)
        {
            Config_SetDevCtrlType(0);
            pstBindInf->ucNeedExitGroup = 0;
            return MOS_OK;
        }
        Config_SendResetDeviceToServer(pstBindInf);
        pstBindInf->ucNeedExitGroup = 2;
        pstBindInf->uiReqTime = uiTimeNow;  
    }
    else if(pstBindInf->ucNeedExitGroup == 2 && uiTimeNow - pstBindInf->uiReqTime > 20)
    {
        pstBindInf->ucNeedExitGroup = 1;
        MsgMng_CancleReqMsg(pstBindInf->uiReqID);
    }
    else if(pstBindInf->ucNeedExitGroup == 3)
    {
        Config_SetDevCtrlType(0);
        Config_SetDevGrpId((_UC*)"");
        Config_SetDevGroupOwnerId((_UC*)"");
        pstBindInf->ucNeedExitGroup = 0;
        Http_SetDevicGroupId("");
        if(ZJ_GetFuncTable()->pFunSelfStatusCb)
        {
            ZJ_GetFuncTable()->pFunSelfStatusCb(EN_ZJ_SERVER_STATUS_WAITBIND,0);
        }
    }
    return MOS_OK;
}

/**********************************************************
*get dst from Link
**********************************************************/
_INT Config_ProcGetDstFromLinkRsp(_UI uiSeqID, JSON_HANDLE hRoot)
{   
    MOS_PARAM_NULL_RETERR(hRoot);

    _INT iCode          = 0;
    JSON_HANDLE hBody   = MOS_NULL;
    _UC *pucDst         = MOS_NULL; 
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;
    
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(pstBindInf->uiReqID != uiSeqID)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"ogct %u is different from %u",uiSeqID,pstBindInf->uiReqID);
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iCode);
    if(iCode != 0)
    {
        pstBindInf->ucGetDstFlag = 4;
        return MOS_ERR;
    }
    hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"DST"),&pucDst);
    Config_SetLocalAreaDst(pucDst);
    pstBindInf->cGetDstTime  = Mos_Time();
    if(ZJ_GetFuncTable()->pfunSetTimeZone)
    {
        ZJ_GetFuncTable()->pfunSetTimeZone(1,Config_GetSystemMng()->iTimeZone,MOS_NULL,(char*)Config_GetDeviceMng()->aucDst);
    }
    pstBindInf->ucGetDstFlag = 3;
    MOS_LOG_INF(CFG_LOGSTR,"ogct %u recv dst %s, rsp code %d",uiSeqID,pucDst,iCode);
    return MOS_OK;
}

_INT Config_GetDstFromLinkServer(ST_CFG_BINDDEVINF *pstBindInf)
{
    MOS_PARAM_NULL_RETERR(pstBindInf);

    _INT iRet;
    _UC aucMethod[8];
    _UC *pStrTmp   = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;

    pstBindInf->uiReqID = Mos_GetSessionId();

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, (_UC*)"%02X%02X",EN_OGCT_METHOD_CFGBUSS, EN_OGCT_CFGBUSS_GTEDTS);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstBindInf->uiReqID));
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Area", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDstArea));

    pStrTmp = Adpt_Json_Print(hRoot);

    iRet = MsgMng_SendMsg(MSGMNG_P2P_SERVER_ID,pstBindInf->uiReqID,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_GTEDTS,
        pStrTmp,MOS_STRLEN(pStrTmp),Config_ProcGetDstFromLinkRsp);

    MOS_LOG_INF(CFG_LOGSTR, "ogct %u get dst from link requst body %s iRet %d",pstBindInf->uiReqID, pStrTmp,iRet);
    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pStrTmp);
    return iRet;
}

_INT Config_ProcGetDstStatus(ST_CFG_BINDDEVINF *pstBindInf, _UI uitimeNow)
{
    MOS_PARAM_NULL_RETERR(pstBindInf);

    _INT iRandom =(_INT) &uitimeNow;
    
    if(MOS_STRLEN(Config_GetDeviceMng()->aucDstArea) == 0 || Config_GetDeviceMng()->iDstUseFlag == 0 
        || (_UI)(Mos_Time() - pstBindInf->cGetDstTime) < 86400)
    {
        return MOS_OK;
    }
    if(pstBindInf->ucGetDstFlag == 1 && MOS_STRLEN(Config_GetDeviceMng()->aucDst) == 0)
    {
        Config_GetDstFromLinkServer(pstBindInf);
        pstBindInf->uiReqTime = uitimeNow;
        pstBindInf->ucGetDstFlag = 2;
    }
    else if((_UI)(uitimeNow - pstBindInf->uiReqTime) > 60)
    {
        if(pstBindInf->ucGetDstFlag == 2)
        {
            MsgMng_CancleReqMsg(pstBindInf->uiReqID);
        }
        pstBindInf->ucGetDstFlag = 1;
    }
    return 0;
}

/*******************************************************************************
处理需要请求的状态
TODO 出组 进组的 NTC
********************************************************************************/
static _VOID Config_ProcDevBussStatus(_UI uiTimeNow)
{
    ST_CFG_BINDDEVINF *pstBindInf = &Config_Task_GetMng()->stBevBindInf;

    if(Config_Task_GetMng()->ucOnlineStatus != 1)
    {
        return;
    } 
    if(pstBindInf->ucNeedExitGroup != 0)
    {
        Config_ProcExitGroupFlag(pstBindInf,uiTimeNow);
    }
    else if(pstBindInf->ucBindFlag != 0)
    {
        Config_ProcDevBindFlag(pstBindInf,uiTimeNow);
    }
    else if(pstBindInf->ucGetGroupInfFlag != 0)
    {
        Config_ProcGetGroupInfStatus(pstBindInf,uiTimeNow);
    }
    else if(pstBindInf->ucGetUsrInfFlag != 0)
    {
        Config_ProcGetUsrPubInfStatus(pstBindInf,uiTimeNow);
    }
    else 
    {
        Config_ProcGetDstStatus(pstBindInf,uiTimeNow);
    }
    return;
}


_VOID Config_SleepMonitor()
{
    static _INT iConfigLastBusyStatus = 0;
    _INT iBusyStatus                  = 0;
    _INT iForceNotify                 = 0;

    Config_GetSLeepMonotorStatus(&iBusyStatus, &iForceNotify);
    // 状态更新，重新通知厂商休眠等待时间
    // 在检测间隔内更新了繁忙状态，也需要通知
    if (iBusyStatus != iConfigLastBusyStatus || iForceNotify)
    {
        //通知休眠时间
        if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT && ZJ_GetFuncTable()->pfuncStartSleep)
        {
            if (iBusyStatus)
            {
                ZJ_GetFuncTable()->pfuncStartSleep(-1);//通知不休眠
            }
            else
            {
                ZJ_GetFuncTable()->pfuncStartSleep(Config_GetDevAwakeInterval());//通知休眠等待时间
            }
        }
        iConfigLastBusyStatus = iBusyStatus;
    }
}

static _INT Config_Task_Loop(_VPTR pParam)
{
    _VPTR pstMsg;
    _UI   uiLoopCnt  = 0;
    _UI   uiNowTime = 0;
    _HSWDWRITE    hSwdConfigFeedDog;
    kj_timer_t    tConfigFeedDogTimeOut;
    kj_timer_t    tConfigCheckBusyTimeOut;
    hSwdConfigFeedDog = Swd_AppThreadRegist(CONFIG_APP, FEED_DOG_SUPER_MAX_TIMESEC);
    kj_timer_init(&tConfigFeedDogTimeOut);
    getDiffTimems(&tConfigFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);

    kj_timer_init(&tConfigCheckBusyTimeOut);
    getDiffTimems(&tConfigCheckBusyTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);

    Config_SetSLeepMonotorForceNotify();
    
    while(Config_Task_GetMng()->ucRunFlag == 1)
    {
        // 软看门狗检测喂狗
        if (getDiffTimems(&tConfigFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_MIDDLE_TIMEOUT_SEC)
        {
#ifdef ENABLE_TEST_NOT_FEEDDOG
            if ((Mos_FileIsExist("/tmp/sdk_test_no_config_swd") == MOS_FALSE))
                Swd_AppThreadFeedDog(hSwdConfigFeedDog);
#else
            Swd_AppThreadFeedDog(hSwdConfigFeedDog);
#endif


            getDiffTimems(&tConfigFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }
        // 检测睡眠检测-用于低功耗门铃
        if (getDiffTimems(&tConfigCheckBusyTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
        {
#if SDK_AWAKE_SLEEP_ENABLE
            Config_SleepMonitor();
#endif
            getDiffTimems(&tConfigCheckBusyTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }

        if(Mos_MsgQueueGetCount(Config_Task_GetMng()->hMsgQueque) > 0)
        {
            pstMsg = Mos_MsgQueuePop(Config_Task_GetMng()->hMsgQueque);
            Config_Task_ProcMsg(pstMsg);
            MOS_FREE(pstMsg);
        }  
        #ifdef BUILD_IMSSDK_FALG
        // IMS 查询业务配置
        ImsMedia_PollBusiCfg();
        #endif       
        if(uiLoopCnt%30 == 0)
        {
            uiNowTime++;
            
            // 储存配置属性到配置文件
            Config_Task_SaveItemFile();

            Config_ProcStatusChangeFlag();

            Config_Proc_UploadCloudCamExtCfg();

            if(MOS_STRLEN(Config_GetDeviceMng()->aucDev4GCardNum) > 0)
            {
                Config_ProcUpload4GFlow(uiNowTime);
            }

            Config_ProcSyncServStatus(uiNowTime);

            //update cfgItem TO SERVER 上报配置属性到信令服务器
            Config_UpdateItemFile();

            Config_ProcDevBussStatus(uiNowTime);

            // OTA升级检查固件版本号
            Ota_ProcCheckVersion();

            // OTA升级下载新固件
            Ota_ProcDownVersion();

            // 下载文件
            DownFile_ProcStatus();

            // AI布控底库图片下载
            AI_ProcDownAIPicture();

            // AI 背景图和人脸图撒上传
            AI_ProcUploadBgAndFacePic();

            // AI 识别打包上传zip
            AI_ProcUploadAIRecZip();

            // AI 告警图片、视频上传
            AI_ProcUplaodAIAlarmPV();
        }
        
        if(MOS_LIST_GETCOUNT(&Config_Task_GetMng()->stSyncList) > 0)
        {
            Config_ProcSyncClientList(uiNowTime);
        }

        // 识别类(AI_PIC)消息上报超时检测
        if(MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUploadCmdPlatTaskInfList) > 0)
        {
            AI_ProcAiPicTimeOutList();
        }

        // 抓拍类(AI_ZIP)消息上报超时检测
        if(MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUploadZipTaskInfList) > 0)
        {
            AI_ProcAiZipTimeOutList();
        }

        // AI 告警图片、视频上传超时检测
        if(MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList) > 0)
        {
            // AI_ProcAiAlarmUploadPVTimeOutList();
        }

        ++uiLoopCnt;
        Mos_Sleep(20);
    }
    Swd_AppThreadUnRegist(hSwdConfigFeedDog);
    MOS_LOG_INF(CFG_LOGSTR,"Cfg task out");
    return MOS_OK;
}

_INT Config_MutexLock()
{
    return  Mos_MutexLock(&Config_Task_GetMng()->hMutex);
}

_INT Config_MutexUnLock()
{
    return Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
}

_INT Config_BegainSyncBussList(ST_MOS_LIST *pstBussList)
{
    MOS_PARAM_NULL_RETERR(pstBussList);
    
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CONIFG_COMMON_BUSS_NODE *pstComBussNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(pstBussList, pstComBussNode, stIterator)
    {
        if(pstComBussNode->uiUseFlag == 1)
        {
            pstComBussNode->uiUseFlag = 2;
        }
    }
    return MOS_OK;
}

_INT Config_EndSyncBussList(ST_MOS_LIST *pstBussList)
{
    MOS_PARAM_NULL_RETERR(pstBussList);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CONIFG_COMMON_BUSS_NODE *pstComBussNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(pstBussList, pstComBussNode, stIterator)
    {
        if(pstComBussNode->uiUseFlag == 2)
        {
            pstComBussNode->uiUseFlag = 0;
        }
    }
    return MOS_OK;
}

// 添加/查找 告警IoT策略的事件 的 响应IoT的OutPut节点
ST_CFG_OUTPUT_NODE *Config_FindAndCreatOutNode(ST_MOS_LIST *pstOutputList,_UI uiKjIoTType,_LLID lluKjIotId)
{
    MOS_PARAM_NULL_RETNULL(pstOutputList);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;
    ST_CFG_OUTPUT_NODE *pstOutputTmpNode = MOS_NULL;

    FOR_EACHDATA_INLIST(pstOutputList, pstOutputNode, stIterator)
    {
        if(pstOutputNode->uiUseFlag && pstOutputNode->uiKjIoTType == uiKjIoTType && pstOutputNode->lluKjIotId == lluKjIotId)
        {
            pstOutputNode->uiUseFlag = 1;
            return pstOutputNode;
        }
        else if(pstOutputNode->uiUseFlag == 0)
        {
            pstOutputTmpNode = pstOutputNode;
        }
    }
    if(pstOutputTmpNode == MOS_NULL)
    {
        pstOutputTmpNode = (ST_CFG_OUTPUT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_OUTPUT_NODE));
        MOS_LIST_ADDTAIL(pstOutputList, pstOutputTmpNode);
    }
    if(pstOutputTmpNode->pucParam)
    {
        pstOutputTmpNode->pucParam[0] = 0;
    }
    pstOutputTmpNode->uiKjIoTType = uiKjIoTType;
    pstOutputTmpNode->lluKjIotId  = lluKjIotId;
    pstOutputTmpNode->uiUseFlag = 1;
    return pstOutputTmpNode;
}
// 查找 告警IoT策略的事件 的 响应IoT的OutPut节点
ST_CFG_OUTPUT_NODE *Config_FindOutNode(ST_MOS_LIST *pstOutputList,_UI uiKjIoTType,_LLID lluKjIotId)
{
    MOS_PARAM_NULL_RETNULL(pstOutputList);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;

    FOR_EACHDATA_INLIST(pstOutputList, pstOutputNode, stIterator)
    {
        if(pstOutputNode->uiUseFlag && pstOutputNode->uiKjIoTType == uiKjIoTType && pstOutputNode->lluKjIotId == lluKjIotId)
        {
            pstOutputNode->uiUseFlag = 1;
            return pstOutputNode;
        }
    }

    return MOS_NULL;
}
