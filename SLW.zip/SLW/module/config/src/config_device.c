#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "http_type.h"
#include "msgmng_cmdserver.h"
/*******************************************************************************/
ST_CFG_DEVICE_MNG *Config_GetDeviceMng()
{
    return &Config_GetlocalCfgInf()->stDeviceMng;
}

_INT Config_InitDeviceMng()
{
    Config_GetDeviceMng()->iEncryAbility         = 0X03;
    Config_GetDeviceMng()->iOtaAbility           = EN_ZJ_OTA_ABILITY_SDCARD|EN_ZJ_OTA_ABILITY_REMOTEUPDATE;
    Config_GetDeviceMng()->iWifiSetAbility       = EN_ZJ_SETWIFI_ABILITY_AP|EN_ZJ_SETWIFI_ABILITY_QRCODE|EN_ZJ_SETWIFI_ABILITY_WIRED;
    Config_GetDeviceMng()->iEnergyType           = 0;
    Config_GetDeviceMng()->iAwakeAbility         = EN_ZJ_AWAKE_ABILITY_NOTSUPPORT;
    Config_GetDeviceMng()->iPowerSupplyFlag      = 1;
    Config_GetDeviceMng()->iPowerLevel           = 100;
    Config_GetDeviceMng()->i4GAbility            = 0;
    Config_GetDeviceMng()->iPilotLightStatus     = 1;
    Config_GetDeviceMng()->uiMaxSessionCnt       = 4;
    Config_GetDeviceMng()->iMaxChnNum            = 1;
    Config_GetDeviceMng()->iTimingTaskAbility    = 1;
    Config_GetDeviceMng()->iTimingAwakeAbility   = 1;
    Config_GetDeviceMng()->iGetDevOuterIPAbility = 1;

    Config_GetDeviceMng()->stSleepMonitorMng.ucInitFlag     = 1;
    Config_GetDeviceMng()->stSleepMonitorMng.uiMonitorId    = 1;
    Config_GetDeviceMng()->stSleepMonitorMng.iForceNotify   = 0;

    // 应用与获取设备外网IP处理方案
    // 获取设备外网IP开关状态，0.关闭， 1:开启 默认：关闭
    Config_GetDeviceMng()->uiGetDevOuterIPStatus = EN_GETOUTERIP_STATUS_CLOSE;
    // 设备上线后在该值的随机时间点内获取外网IP 单位：分钟(min), 范围：[1-10] 默认：3分钟
    Config_GetDeviceMng()->uiOnlineRandomTime    = EN_GETOUTERIP_ONLINERANDOMTIME_DEFAULT;
    // 将获取外网IP统计数据上报云涛间隔(也可理解成数据统计周期) 单位：小时(h), 范围：[1-24] 默认：6小时
    Config_GetDeviceMng()->uiUploadInterval      = EN_GETOUTERIP_UPLOADINTERVAL_DEFAULT;
    // 统计周期内外网IP变更次数最大值   范围：[3-10] 默认：5次
    Config_GetDeviceMng()->uiMaxChangeCount      = EN_GETOUTERIP_MAXCHANGECOUNT_DEFAULT;
    // 统计周期内外网IP变更次数达到上限后,停止检查设备外网IP的时长  单位：小时(h), 范围：[1-24] 默认：12小时
    Config_GetDeviceMng()->uiStopCheckDuration   = EN_GETOUTERIP_STOPCHECKDURATION_DEFAULT;

    // Mos_MutexCreate(&Config_GetDeviceMng()->stSleepMonitorMng.hMutex);

    MOS_LOG_INF(CFG_LOGSTR,"cfg_device Init Ok");
    return MOS_OK;
}

_INT Config_SetSdkVersion(_UI uiSdkVersion)
{
    if(Config_GetDeviceMng()->uiSdkVersion == uiSdkVersion)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->uiSdkVersion = uiSdkVersion;
    
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set sdkVersion 0x%x",uiSdkVersion);
    return MOS_OK;
}

_UC* Config_GetSdkVersion(_UC *aucSdkVersion)
{
    _UC sdkVersion[4] = {0};
    MOS_MEMCPY(sdkVersion, &Config_GetDeviceMng()->uiSdkVersion, sizeof(sdkVersion));
    MOS_SPRINTF(aucSdkVersion,"SdkV%02x.%02x.%02x.%02x", sdkVersion[3], sdkVersion[2], sdkVersion[1], sdkVersion[0]);
    return aucSdkVersion;
}

_INT Config_SetAppVersion(_UC* pcVersion)
{
    MOS_PARAM_NULL_RETERR(pcVersion);

    // 用于3244登录信令服务器initflag字段 
    // 前后设备版本号相同，则上报core.db中uiCmdLoginStatus值 
    //     特殊情况一：core.db缺失则uiCmdLoginStatus默认为EN_CMDLOGIN_STATUS_REBOOT（不会存在新旧版本号相同情况）； 
    //     特殊情况二：core.db存在CmdLoginStatus字段缺失，则uiCmdLoginStatus默认为EN_CMDLOGIN_STATUS_UPGRADE_OR_FACTORY； 
    // 设备登录成功后正常重启情况，需上报 EN_CMDLOGIN_STATUS_REBOOT ,此值会在登录信令服务成功后设置，并保存在core.db中，重启后再加载出来
    if (MOS_STRCMP(Config_GetDeviceMng()->aucDevVerSion, pcVersion) == 0)
    {
        MOS_LOG_INF(CFG_LOGSTR, "Device Set AppVersion %s, InitFlag:%u", pcVersion, Config_GetCoreMng()->uiCmdLoginStatus);
        // 上报升级状态和进度
        // Ota_PubUpgradePrecentage(0, EN_CFG_OTA_UPGRADE_NONEED);
        return MOS_OK;
    }

    MOS_LOG_INF(CFG_LOGSTR, "DevVerSion %s, Len:%d", Config_GetDeviceMng()->aucDevVerSion, MOS_STRLEN(Config_GetDeviceMng()->aucDevVerSion));

    // 版本号长度为空，存在 设备第一次出厂 和 设备重置 的情况
    if (MOS_STRLEN(Config_GetDeviceMng()->aucDevVerSion) == 0)
    {
        _UC  aucSysPath[256] = {0};
        MOS_VSNPRINTF(aucSysPath, sizeof(aucSysPath), "%s/%s", Config_Task_GetMng()->aucSystemPath, CFG_NEWSYSTEM_FILE);
        // 不存在 systemencrycfg.db 文件 ，则是 设备第一次出厂
        if (Mos_FileIsExist(aucSysPath) == MOS_FALSE)
        {
            MOS_LOG_INF(CFG_LOGSTR, "Dev Start CmdLoginStatus %d First FACTORY", EN_CMDLOGIN_STATUS_UPGRADE_OR_FACTORY);
            Config_SetCmdLoginStatus(EN_CMDLOGIN_STATUS_UPGRADE_OR_FACTORY);
        }
        // 存在 systemencrycfg.db 文件 ，则是设备重置 重置要求厂商不删除 systemencrycfg.db 文件
        else
        {
            MOS_LOG_INF(CFG_LOGSTR, "Dev Start CmdLoginStatus %d RESET", EN_CMDLOGIN_STATUS_RESET);
            Config_SetCmdLoginStatus(EN_CMDLOGIN_STATUS_RESET);
        }
    }
    // 前后设备版本号不相同，且版本长度大于0 则是设备升级情况  
    else
    {
        MOS_LOG_INF(CFG_LOGSTR, "Dev Start CmdLoginStatus %d UPGRADE", EN_CMDLOGIN_STATUS_UPGRADE_OR_FACTORY);
        Config_SetCmdLoginStatus(EN_CMDLOGIN_STATUS_UPGRADE_OR_FACTORY);
    }

    MOS_STRNCPY(Config_GetDeviceMng()->aucDevVerSion, pcVersion, sizeof(Config_GetDeviceMng()->aucDevVerSion));
    Config_GetDeviceMng()->uiUpgradedEndFlag   = 1;
    Config_GetDeviceMng()->uiXwUpgradedFlag    = 1;
	
    Config_GetCoreMng()->ucAbilityUpFlag       = 0;
    Config_GetCoreMng()->ucBussUpFlag          = 0;

    Config_GetItemSign()->ucSaveCore           = 1;
    Config_GetItemSign()->ucSaveDev            = 1;
    Config_GetItemSign()->ucCfgDevUpdate       = 1;

    Config_SetAblPlatDevToken("");
    MOS_LOG_INF(CFG_LOGSTR, "Device Set AppVersion %s, UpgradeFlag %u, InitFlag:%u", pcVersion, Config_GetDeviceMng()->uiUpgradedEndFlag, Config_GetCoreMng()->uiCmdLoginStatus);
	
    return MOS_OK;
}

_INT Config_SetEncryptAbility(_INT iEncAbility)
{
    if(Config_GetDeviceMng()->iEncryAbility == iEncAbility)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iEncryAbility = iEncAbility;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set encryptAbility %d",iEncAbility);
    return MOS_OK;
}

_INT Config_SetOtaAbility(_INT iOtaAbility)
{
    if(Config_GetDeviceMng()->iOtaAbility == iOtaAbility)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iOtaAbility = iOtaAbility;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set otaAbility %d",iOtaAbility);
    return MOS_OK; 
}

_INT Config_SetWifiSetAbility(_INT iWifiSetAbility)
{
    if(Config_GetDeviceMng()->iWifiSetAbility == iWifiSetAbility)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iWifiSetAbility = iWifiSetAbility;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set wifisetAbility %d",iWifiSetAbility);
    return MOS_OK;
}

_INT Config_SetEngeryType(_INT iEngeryType)
{
    if(Config_GetDeviceMng()->iEnergyType == iEngeryType)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iEnergyType = iEngeryType;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set engeryType %d",iEngeryType);
    return MOS_OK;
}

_INT Config_SetAwakeAbility(_INT iAwakeAbility)
{
    if(Config_GetDeviceMng()->iAwakeAbility == iAwakeAbility)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iAwakeAbility = iAwakeAbility;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set AwakeAbility %d",iAwakeAbility);
    return MOS_OK;
}

_INT Config_SetDeviceName(_UC *pucDevName)
{
    MOS_PARAM_NULL_RETERR(pucDevName);

    if(MOS_STRCMP(Config_GetDeviceMng()->aucDevName,pucDevName) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetDeviceMng()->aucDevName,pucDevName,sizeof(Config_GetDeviceMng()->aucDevName));
    Config_GetItemSign()->ucSaveDev      = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set DeviceName %s",Config_GetDeviceMng()->aucDevName);
    return MOS_OK;
}

_INT Config_SetMaxSessionCnt(_UI uiMaxSessionCnt)
{
    Config_GetDeviceMng()->uiMaxSessionCnt = uiMaxSessionCnt;
    Config_GetItemSign()->ucSaveDev        = 1;
    Config_GetItemSign()->ucCfgDevUpdate   = 1;
    return MOS_OK;
}   

_INT Config_SetPowerSupply(_INT iSupplyFlag)
{
    if(Config_GetDeviceMng()->iPowerSupplyFlag == iSupplyFlag)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iPowerSupplyFlag = iSupplyFlag;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set PowerSupply %d",iSupplyFlag);
    return MOS_OK;
}

_INT Config_Set4GAbility(_INT i4GAbility)
{
    if(Config_GetDeviceMng()->i4GAbility == i4GAbility)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->i4GAbility = i4GAbility;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set 4GAbility %d",i4GAbility);
    return MOS_OK;
}

_INT Config_SetPowerLevel(_INT iPowerLevel)
{
    if(Config_GetDeviceMng()->iPowerLevel == iPowerLevel)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iPowerLevel = iPowerLevel;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set PowerLevel %d",iPowerLevel);
    return MOS_OK;
}

_INT Config_SetDevicePresenceFlag(_INT iPresence)
{
    if(Config_GetDeviceMng()->iPresence == iPresence)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iPresence = iPresence;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set DevicePresenceFlag %d",iPresence);
    return MOS_OK;
}

_INT Config_SetDevOtaStatus(_INT iOtaStatus)
{
    Config_GetDeviceMng()->iOtaStatus = iOtaStatus;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set DevOtaStatus %d",iOtaStatus);
    return MOS_OK;
}

_INT Config_SetDevOsType(_INT iDevOsType)
{
    if(Config_GetDeviceMng()->iDevOsType == iDevOsType)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iDevOsType = iDevOsType;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set DevOsType %d",iDevOsType);
    return MOS_OK;
}

_INT Config_SetDevType(_INT iDevType)
{
    if(Config_GetDeviceMng()->iDevType == iDevType)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iDevType = iDevType;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set DevType %d",iDevType);
    return MOS_OK;
}

_INT Config_SetUpLogFlag(_INT iUpLogFlag,_INT iLogErrType)
{
    if(Config_GetDeviceMng()->iLogUpLoadFlag == iUpLogFlag && 
        Config_GetDeviceMng()->iLogErrType == iLogErrType)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iLogErrType    = iLogErrType;
    Config_GetDeviceMng()->iLogUpLoadFlag = iUpLogFlag;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set Log upload flag %d type %u",iUpLogFlag,iLogErrType);
    return MOS_OK;
}

_INT Config_SetPilotLightStatus(_INT iPilotLightStatus)
{
    if (Config_GetDeviceMng()->iPilotLightStatus == iPilotLightStatus)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iPilotLightStatus = iPilotLightStatus;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set Pilot Light Status flag %d",iPilotLightStatus);
    return MOS_OK;
}

_INT Config_SetSIMCardAccount(_UC *pucSIMCardAccount)
{
    MOS_PARAM_NULL_RETERR(pucSIMCardAccount);

    if(MOS_STRCMP(Config_GetDeviceMng()->aucDev4GCardNum,pucSIMCardAccount) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetDeviceMng()->aucDev4GCardNum,pucSIMCardAccount,sizeof(Config_GetDeviceMng()->aucDev4GCardNum));
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set SIMCardAccount %s",pucSIMCardAccount);
    return MOS_OK;
}

_INT Config_SetDevAutoUpgradeParam(_UI uiAutoUpgradeFlag, _UI uiWeekDay, _UI uiTime)
{
    if(Config_GetDeviceMng()->uiAutoUpgradeFlag == uiAutoUpgradeFlag && Config_GetDeviceMng()->uiUpgradeWeekDay == uiWeekDay 
        && Config_GetDeviceMng()->uiUpgradeTime == uiTime)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->uiAutoUpgradeFlag = uiAutoUpgradeFlag;
    Config_GetDeviceMng()->uiUpgradeTime     = uiTime;
    Config_GetDeviceMng()->uiUpgradeWeekDay  = uiWeekDay;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set Auto Upgradeflag %d",uiAutoUpgradeFlag);
    return MOS_OK;
}

_INT Config_SetDevLimitStreamFlag(_UI uiFlag)
{
    if(Config_GetDeviceMng()->uiLimitStreamFlag == uiFlag)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->uiLimitStreamFlag = uiFlag;
    Config_GetItemSign()->ucSaveDev = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set Stream limit flag %d",uiFlag);
    return MOS_OK;
}

_INT Config_SetDevModel(_UC *pucDevModel)
{
    MOS_PARAM_NULL_RETERR(pucDevModel);

    if( MOS_STRCMP(Config_GetDeviceMng()->aucDevModel,pucDevModel) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetDeviceMng()->aucDevModel,pucDevModel,sizeof(Config_GetDeviceMng()->aucDevModel));
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
	MOS_LOG_INF(CFG_LOGSTR,"cfg_device set DevModel  %s",pucDevModel);
    return MOS_OK;
}

//about dst 
_INT Config_SetAreaInfo(_INT iDstUseFlag,_UC *pucDstArea)
{
    MOS_PARAM_NULL_RETERR(pucDstArea);

    if(Config_GetDeviceMng()->iDstUseFlag == iDstUseFlag && MOS_STRCMP(Config_GetDeviceMng()->aucDstArea,pucDstArea) == 0)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iDstUseFlag = iDstUseFlag;
    MOS_STRNCPY(Config_GetDeviceMng()->aucDstArea,pucDstArea,sizeof(Config_GetDeviceMng()->aucDstArea));
    Config_GetItemSign()->ucSaveDev      = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
	MOS_LOG_INF(CFG_LOGSTR,"cfg_device set dstUseFlag %d, dstArea %s",iDstUseFlag, pucDstArea);
    return MOS_OK;
}

_INT Config_SetLocalAreaDst(_UC *pucDst)
{
    MOS_PARAM_NULL_RETERR(pucDst);

    if(MOS_STRCMP(Config_GetDeviceMng()->aucDst,pucDst) == 0)
    {
        return MOS_OK;
    }
    MOS_STRNCPY(Config_GetDeviceMng()->aucDst,pucDst,sizeof(Config_GetDeviceMng()->aucDst));
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
	MOS_LOG_INF(CFG_LOGSTR,"cfg_device set dst %s", pucDst);
    return MOS_OK;
}

_INT Config_SetFirstLaunchTime()
{
    Config_GetDeviceMng()->cFirstLaunchTime = Mos_Time();
    return MOS_OK;
}

_INT Config_SetDevAwakeInterval(_UI uiAwakeInterval)
{
    // 限制唤醒间隔的时长
    if (uiAwakeInterval > DEVICE_AWAKE_INTERVAL_MAX)
    {
        uiAwakeInterval = DEVICE_AWAKE_INTERVAL_MAX;
    }
    else if (uiAwakeInterval < DEVICE_AWAKE_INTERVAL_MIN)
    {
        uiAwakeInterval = DEVICE_AWAKE_INTERVAL_MIN;
    }

    if(Config_GetDeviceMng()->uiAwakeInterval == uiAwakeInterval)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->uiAwakeInterval = uiAwakeInterval;
    Config_GetItemSign()->ucSaveDev        = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set awake interval %d",uiAwakeInterval);
    return MOS_OK;
}

_INT Config_SetMaxChnNum(_INT iMaxChnNum)
{
    if (Config_GetDeviceMng()->iMaxChnNum == iMaxChnNum)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iMaxChnNum = iMaxChnNum;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set MaxChnNum %d",iMaxChnNum);
    return MOS_OK;
}

// 定时任务的能力字段包括任务ID可字符串及按照协议可嵌套当前已具备的所有定时任务能力，包括且不局限于语音、白光灯、休眠、预置位操作
_INT Config_SetTimingTaskAbility(_INT iTimingTaskAbility)
{
    if (Config_GetDeviceMng()->iTimingTaskAbility == iTimingTaskAbility)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iTimingTaskAbility = iTimingTaskAbility;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set TimingTaskAbility %d",iTimingTaskAbility);
    return MOS_OK;
}

// 业务使用定时休眠去判断能不能使用定时休眠的下发
_INT Config_SetTimingAwakeAbility(_INT iTimingAwakeAbility)
{
    if (Config_GetDeviceMng()->iTimingAwakeAbility == iTimingAwakeAbility)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iTimingAwakeAbility = iTimingAwakeAbility;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set TimingAwakeAbility %d",iTimingAwakeAbility);
    return MOS_OK;
}

_INT Config_SetGetDevOuterIPAbility(_INT iGetDevOuterIPAbility)
{
    if (Config_GetDeviceMng()->iGetDevOuterIPAbility == iGetDevOuterIPAbility)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->iGetDevOuterIPAbility = iGetDevOuterIPAbility;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_device set GetDevOuterIPAbility %d",iGetDevOuterIPAbility);
    return MOS_OK;
}

_UI Config_GetDevAwakeInterval()
{
    if (MsgMng_GetCmdServer()->ucStatus != EN_MSGMNG_CMDSERVER_STATUS_PROCESS)
    {
        return DEVICE_AWAKE_INTERVAL_OFFLINE;//未配网，固定休眠时间
    }
    else
    {
        return Config_GetDeviceMng()->uiAwakeInterval;
    }
}

_INT Config_SetCloudLogStatus(_UI uiCloudLogStatus)
{
    if (Config_GetDeviceMng()->uiCloudLogStatus == uiCloudLogStatus)
    {
        return MOS_OK;
    }
    // 事件云存监控上报关闭
    if (uiCloudLogStatus == 0)
    {
        CloudstgSetCloudEventUploadInitFlag(0);
    }
    Config_GetDeviceMng()->uiCloudLogStatus = uiCloudLogStatus;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
	MOS_LOG_INF(CFG_LOGSTR,"cfg_device set CloudLogStatus %d", uiCloudLogStatus);
    return MOS_OK;
}

_INT Config_SetCloudLogInterval(_UI uiCloudLogInterval)
{
    if (Config_GetDeviceMng()->uiCloudLogInterval == uiCloudLogInterval)
    {
        return MOS_OK;
    }
    // 设备仅支持10~180分钟的上报周期（暂时）
    if (uiCloudLogInterval < 10 || uiCloudLogInterval > 180)
    {
	    MOS_LOG_INF(CFG_LOGSTR,"CloudLogInterval can't set to %d", uiCloudLogInterval);
        return MOS_ERR;
    }
    Config_GetDeviceMng()->uiCloudLogInterval = uiCloudLogInterval;
    Config_GetItemSign()->ucSaveDev = 1;
    Config_GetItemSign()->ucCfgDevUpdate = 1;
	MOS_LOG_INF(CFG_LOGSTR,"cfg_device set CloudLogInterval %d", uiCloudLogInterval);
    return MOS_OK;
}

// 应用与获取设备外网IP处理方案
// 对设备获取外网IP操作涉及的参数配置
_INT Config_SetGetOuterIPInf(_UI uiGetDevOuterIPStatus, _UI uiOnlineRandomTime, _UI uiUploadInterval, _UI uiMaxChangeCount, _UI uiStopCheckDuration)
{
    _INT iChangeFlag = 0;

    // 获取设备外网IP开关状态，0.关闭， 1:开启 默认：关闭
    if (Config_GetDeviceMng()->uiGetDevOuterIPStatus != uiGetDevOuterIPStatus)
    {
        Config_GetDeviceMng()->uiGetDevOuterIPStatus = uiGetDevOuterIPStatus;
        // MOS_LOG_INF(CFG_LOGSTR,"cfg_device set GetDevOuterIPStatus %u", uiGetDevOuterIPStatus);
        iChangeFlag = 1;
    }

    // 设备上线后在该值的随机时间点内获取外网IP 单位：分钟(min), 范围：[1-10] 默认：3分钟
    if ((uiOnlineRandomTime < EN_GETOUTERIP_ONLINERANDOMTIME_MIN) || (uiOnlineRandomTime > EN_GETOUTERIP_ONLINERANDOMTIME_MAX))
    {
	    MOS_LOG_INF(CFG_LOGSTR, "OnlineRandomTime can't set to %u range[%d-%d]", 
                        uiOnlineRandomTime, EN_GETOUTERIP_ONLINERANDOMTIME_MIN, EN_GETOUTERIP_ONLINERANDOMTIME_MAX);
    }
    else
    {
        if (Config_GetDeviceMng()->uiOnlineRandomTime != uiOnlineRandomTime)
        {
            Config_GetDeviceMng()->uiOnlineRandomTime = uiOnlineRandomTime;
            // MOS_LOG_INF(CFG_LOGSTR,"cfg_device set OnlineRandomTime %u", uiOnlineRandomTime);
            iChangeFlag = 1;
        }
    }

    // 将获取外网IP统计数据上报云涛间隔(也可理解成数据统计周期) 单位：小时(h), 范围：[1-24] 默认：6小时
    if ((uiUploadInterval < EN_GETOUTERIP_UPLOADINTERVAL_MIN) || (uiUploadInterval > EN_GETOUTERIP_UPLOADINTERVAL_MAX))
    {
	    MOS_LOG_INF(CFG_LOGSTR, "UploadInterval can't set to %u range[%d-%d]", 
                        uiUploadInterval, EN_GETOUTERIP_UPLOADINTERVAL_MIN, EN_GETOUTERIP_UPLOADINTERVAL_MAX);
    }
    else
    {
        if (Config_GetDeviceMng()->uiUploadInterval != uiUploadInterval)
        {
            Config_GetDeviceMng()->uiUploadInterval = uiUploadInterval;
            // MOS_LOG_INF(CFG_LOGSTR,"cfg_device set UploadInterval %u", uiUploadInterval);
            iChangeFlag = 1;
        }
    }

    // 统计周期内外网IP变更次数最大值   范围：[3-10] 默认：5次
    if ((uiMaxChangeCount < EN_GETOUTERIP_MAXCHANGECOUNT_MIN) || (uiMaxChangeCount > EN_GETOUTERIP_MAXCHANGECOUNT_MAX))
    {
	    MOS_LOG_INF(CFG_LOGSTR, "MaxChangeCount can't set to %u range[%d-%d]", 
                        uiMaxChangeCount, EN_GETOUTERIP_MAXCHANGECOUNT_MIN, EN_GETOUTERIP_MAXCHANGECOUNT_MAX);
    }
    else
    {
        if (Config_GetDeviceMng()->uiMaxChangeCount != uiMaxChangeCount)
        {
            Config_GetDeviceMng()->uiMaxChangeCount = uiMaxChangeCount;
            // MOS_LOG_INF(CFG_LOGSTR,"cfg_device set MaxChangeCount %u", uiMaxChangeCount);
            iChangeFlag = 1;
        }
    }

    // 统计周期内外网IP变更次数达到上限后,停止检查设备外网IP的时长  单位：小时(h), 范围：[1-24] 默认：12小时
    if ((uiStopCheckDuration < EN_GETOUTERIP_STOPCHECKDURATION_MIN) || (uiStopCheckDuration > EN_GETOUTERIP_STOPCHECKDURATION_MAX))
    {
	    MOS_LOG_INF(CFG_LOGSTR, "StopCheckDuration can't set to %u range[%d-%d]", 
                        uiStopCheckDuration, EN_GETOUTERIP_STOPCHECKDURATION_MIN, EN_GETOUTERIP_STOPCHECKDURATION_MAX);
    }
    else
    {
        if (Config_GetDeviceMng()->uiStopCheckDuration != uiStopCheckDuration)
        {
            Config_GetDeviceMng()->uiStopCheckDuration = uiStopCheckDuration;
            // MOS_LOG_INF(CFG_LOGSTR,"cfg_device set StopCheckDuration %u", uiStopCheckDuration);
            iChangeFlag = 1;
        }
    }

    if (iChangeFlag == 1)
    {
        Config_GetItemSign()->ucSaveDev = 1;
        Config_GetItemSign()->ucCfgDevUpdate = 1;
    }

    return MOS_OK;
}

/*************************************************************************
配置 修改 区间
*************************************************************************/
_VPTR Config_BuildDeviceObject(_UI uiCfgType)
{
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiDevSign));
    
    if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"EncAbility",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iEncryAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OTAAbility",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iOtaAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"WifiSetAbility",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iWifiSetAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"EnergyType",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iEnergyType));  
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AwakeAbility",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iAwakeAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Powersupply",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iPowerSupplyFlag)); 
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SIMAbility",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->i4GAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SdkVersion",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiSdkVersion));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MaxChnNum",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iMaxChnNum));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"TimingAwakeAbility",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iTimingAwakeAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"TimingTaskAbility",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iTimingTaskAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"GetDevOuterIPAbility",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iGetDevOuterIPAbility));
    }
    
    if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OSType",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iDevOsType));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"PowerLevel",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iPowerLevel));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AwakeInterval",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiAwakeInterval));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"DevVersion",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"DevName",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevName));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SIMCard",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDev4GCardNum));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"DevType",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iDevType));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"DevModel",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevModel));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"UpLogFlag",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iLogUpLoadFlag));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"UpLogErrType",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iLogErrType));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AutoUpgradeFlag",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiAutoUpgradeFlag));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AutoUpgradeWeekDay",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiUpgradeWeekDay));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AutoUpgradeTime",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiUpgradeTime));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MaxSessionCnt",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiMaxSessionCnt));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"DstUseFlag",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iDstUseFlag));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"DstArea",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDstArea));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Dst",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDst));

        // 内置指示灯能力值置1 才上报状态字段
        if (Config_GetInIotMng()->uiStatusLampAbility == 1)
        {
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"PilotLightStatus",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->iPilotLightStatus));
        }
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudLogStatus",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiCloudLogStatus));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CloudLogInterval",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiCloudLogInterval));
        
        // 应用于获取设备外网IP处理方案
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"GetDevOuterIPStatus",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiGetDevOuterIPStatus));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"OnlineRandomTime",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiOnlineRandomTime));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"UploadInterval",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiUploadInterval));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MaxChangeCount",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiMaxChangeCount));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"StopCheckDuration",Adpt_Json_CreateStrWithNum(Config_GetDeviceMng()->uiStopCheckDuration));
    }
    return hRoot;
}

_UC *Config_BuildDeviceJson(_UI uiCfgType)
{
    _UC *pstrTmp      = MOS_NULL;
    
    JSON_HANDLE hRoot = Config_BuildDeviceObject(uiCfgType);  
    
    pstrTmp = Adpt_Json_Print(hRoot);
    
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(CFG_LOGSTR,"build device info %s",pstrTmp);
    return pstrTmp;
}

// 读取设备配置的字段
_INT Config_ParseDeviceJson(_UC *pStrJson,_UI uiCfgType)
{
    MOS_PARAM_NULL_RETERR(pStrJson);

    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        // 加密能力类型
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EncAbility"),&Config_GetDeviceMng()->iEncryAbility);
        // 升级能力
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OTAAbility"),&Config_GetDeviceMng()->iOtaAbility);
        // WiFi配网支持类型能力
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"WifiSetAbility"),&Config_GetDeviceMng()->iWifiSetAbility);
        // 电源供电节能模式  0.不带电池；1.带电池
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"EnergyType"),&Config_GetDeviceMng()->iEnergyType);
        // 休眠唤醒能力  0x00不支持休眠,0x01支持本地唤醒,0x02 支持远程唤醒
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AwakeAbility"),&Config_GetDeviceMng()->iAwakeAbility);
        // 是否插电源    0.不插电；1 插电
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Powersupply"),&Config_GetDeviceMng()->iPowerSupplyFlag);
        // 是否支持4G
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SIMAbility"),&Config_GetDeviceMng()->i4GAbility);
        // sdk版本
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SdkVersion"),&Config_GetDeviceMng()->uiSdkVersion);

        // 定时休眠能力值 业务使用定时休眠去判断能不能使用定时休眠的下发
        JSON_HANDLE hTimingAwakeAbility = MOS_NULL;
        hTimingAwakeAbility = Adpt_Json_GetObjectItem(hRoot,(_UC*)"TimingAwakeAbility");
        if (hTimingAwakeAbility)
        {
            // 优化读取不存在字段是默认为0情况，主要场景3.0升级4.0后的配置同步
            Adpt_Json_GetIntegerEx(hTimingAwakeAbility,(_INT*)&Config_GetDeviceMng()->iTimingAwakeAbility);
        }

        // 定时任务能力值 定时任务的能力字段包括任务ID可字符串及按照协议可嵌套当前已具备的所有定时任务能力，包括且不局限于语音、白光灯、休眠、预置位操作
        JSON_HANDLE hTimingTaskAbility = MOS_NULL;
        hTimingTaskAbility = Adpt_Json_GetObjectItem(hRoot,(_UC*)"TimingTaskAbility");
        if (hTimingTaskAbility)
        {
            // 优化读取不存在字段是默认为0情况，主要场景3.0升级4.0后的配置同步
            Adpt_Json_GetIntegerEx(hTimingTaskAbility,(_INT*)&Config_GetDeviceMng()->iTimingTaskAbility);
        }

        JSON_HANDLE hGetDevOuterIPAbility = MOS_NULL;
        hGetDevOuterIPAbility = Adpt_Json_GetObjectItem(hRoot,(_UC*)"GetDevOuterIPAbility");
        if (hGetDevOuterIPAbility)
        {
            // 优化读取不存在字段是默认为0情况，主要场景3.0升级4.0后的配置同步
            Adpt_Json_GetIntegerEx(hGetDevOuterIPAbility,(_INT*)&Config_GetDeviceMng()->iGetDevOuterIPAbility);
        }
    }
    if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        // 电源电量  此项不由服务器反向设置
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PowerLevel"),&Config_GetDeviceMng()->iPowerLevel);
        // 日志上传开关
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"UpLogFlag"),&Config_GetDeviceMng()->iLogUpLoadFlag);
        // 错误日志上报类型
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"UpLogErrType"),&Config_GetDeviceMng()->iLogErrType);
        
        // 设备的操作系统类型
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OsType"),&Config_GetDeviceMng()->iDevOsType);
        // 设备类型：0x01.摄像机；0x02.分体门铃；0x03.单体门铃；0x04.NVR
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevType"),&Config_GetDeviceMng()->iDevType);
        // 设备定时升级开关: 0.关、1.开
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AutoUpgradeFlag"),(_INT*)&Config_GetDeviceMng()->uiAutoUpgradeFlag);
        // 周几自动升级
        // 0x01 表示周一； 0x02 表示周二； 0x04 表示周三； 0x08表示周四； 0x10 表示周五； 0x20表示周六； 0x40表示周日；或的方式
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AutoUpgradeWeekDay"),(_INT*)&Config_GetDeviceMng()->uiUpgradeWeekDay);
        // 自动升级时间 HH*3600 + MM*60 + SS
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AutoUpgradeTime"),(_INT*)&Config_GetDeviceMng()->uiUpgradeTime);
        // 最大媒体点播数（包括实时流、TF卡回看）
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"MaxSessionCnt"),(_INT*)&Config_GetDeviceMng()->uiMaxSessionCnt);
        if(Config_GetDeviceMng()->uiMaxSessionCnt == 0)
        {
            Config_GetDeviceMng()->uiMaxSessionCnt = 4;
        }
        // 休眠设备唤醒后，等待此时长后，继续休眠。即唤醒后工作时长。
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AwakeInterval"),(_INT*)&Config_GetDeviceMng()->uiAwakeInterval);
        // 设备版本    此项不由服务器反向设置
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevVersion"),&pStrTmp);
        MOS_STRNCPY(Config_GetDeviceMng()->aucDevVerSion, pStrTmp, sizeof(Config_GetDeviceMng()->aucDevVerSion));

        // 设备型号：EF-FH8632-0530-00  第一位 sdk 开发者 , 第二位厂商芯片信号 第三 产品型号 第四 省份
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevModel"),&pStrTmp);
        MOS_STRNCPY(Config_GetDeviceMng()->aucDevModel, pStrTmp, sizeof(Config_GetDeviceMng()->aucDevModel));

        // 设备名称
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DevName"),&pStrTmp);
        MOS_STRNCPY(Config_GetDeviceMng()->aucDevName, pStrTmp, sizeof(Config_GetDeviceMng()->aucDevName));

        // 4G卡号
        // Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SIMCard"),&pStrTmp);
        // MOS_STRNCPY(Config_GetDeviceMng()->aucDev4GCardNum, pStrTmp, sizeof(Config_GetDeviceMng()->aucDev4GCardNum));

        // 夏令时使用标志
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DstUseFlag"),(_INT*)&Config_GetDeviceMng()->iDstUseFlag);
        // 夏令时区域
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DstArea"),&pStrTmp);
        MOS_STRNCPY(Config_GetDeviceMng()->aucDstArea, pStrTmp, sizeof(Config_GetDeviceMng()->aucDstArea));
        // 夏令时
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Dst"),&pStrTmp);
        MOS_STRNCPY(Config_GetDeviceMng()->aucDst, pStrTmp, sizeof(Config_GetDeviceMng()->aucDst));

        // 设备指示灯开关状态: 0.关、1.开
        Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PilotLightStatus"),(_INT*)&Config_GetDeviceMng()->iPilotLightStatus, 1);

        /* MaxChnNum字段不需要读取赋值到Config_GetDeviceMng()->iMaxChnNum全局变量 */
        // 最大通道数，默认为1
        // Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hRoot,(_UC*)"MaxChnNum"),(_INT*)&Config_GetDeviceMng()->iMaxChnNum, 1);
        // // 当配置的通道数为0，则设置为默认值1
        // if (Config_GetDeviceMng()->iMaxChnNum == 0)
        // {
        //     Config_GetDeviceMng()->iMaxChnNum = 1;
        // }

        // 事件云存上报开关：0关，1开
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudLogStatus"),(_INT*)&Config_GetDeviceMng()->uiCloudLogStatus);

        // 10-180分钟，默认30分钟
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CloudLogInterval"),(_INT*)&Config_GetDeviceMng()->uiCloudLogInterval);

        // 应用于获取设备外网IP处理方案
        // 获取设备外网IP开关状态，0.关闭， 1:开启 默认：关闭
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"GetDevOuterIPStatus"),(_INT*)&Config_GetDeviceMng()->uiGetDevOuterIPStatus);      
        // 设备上线后在该值的随机时间点内获取外网IP 单位：分钟(min), 范围：[1-10] 默认：3分钟
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"OnlineRandomTime"),(_INT*)&Config_GetDeviceMng()->uiOnlineRandomTime);
        // 将获取外网IP统计数据上报云涛间隔(也可理解成数据统计周期) 单位：小时(h), 范围：[1-24] 默认：6小时
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"UploadInterval"),(_INT*)&Config_GetDeviceMng()->uiUploadInterval);
        // 统计周期内外网IP变更次数最大值   范围：[3-10] 默认：5次
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"MaxChangeCount"),(_INT*)&Config_GetDeviceMng()->uiMaxChangeCount);
        // 统计周期内外网IP变更次数达到上限后,停止检查设备外网IP的时长  单位：小时(h), 范围：[1-24] 默认：12小时
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"StopCheckDuration"),(_INT*)&Config_GetDeviceMng()->uiStopCheckDuration);
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiDevSign);  
    Adpt_Json_Delete(hRoot);

    // 如果休眠间隔时长为0，则为默认值
    if (Config_GetDeviceMng()->uiAwakeInterval == 0)
    {
        Config_GetDeviceMng()->uiAwakeInterval = DEVICE_AWAKE_INTERVAL_DEFAULT;
    }

    // 限制唤醒间隔的时长 最大值和最小值
    if (Config_GetDeviceMng()->uiAwakeInterval > DEVICE_AWAKE_INTERVAL_MAX)
    {
        Config_GetDeviceMng()->uiAwakeInterval = DEVICE_AWAKE_INTERVAL_MAX;
    }
    else if (Config_GetDeviceMng()->uiAwakeInterval < DEVICE_AWAKE_INTERVAL_MIN)
    {
        Config_GetDeviceMng()->uiAwakeInterval = DEVICE_AWAKE_INTERVAL_MIN;
    }
    return MOS_OK;
}

_VOID Config_GetSLeepMonotorStatus(_INT *piBusyStatus, _INT *piForceNotify)
{
    MOS_PARAM_NULL_NORET(piBusyStatus);
    MOS_PARAM_NULL_NORET(piForceNotify);
#if SDK_AWAKE_SLEEP_ENABLE    
    ST_MOS_LIST_ITERATOR stIterator;
    ST_SLeepMonotorNode *pstBussNode = MOS_NULL;
    ST_SLEEP_MONITOR_MNG *pstSleepMonitorMng = &Config_GetDeviceMng()->stSleepMonitorMng;
    
    *piBusyStatus  = 0;
    *piForceNotify = 0;
    if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //低功耗设备
    {
        Mos_MutexLock(&pstSleepMonitorMng->hMutex);
        
        FOR_EACHDATA_INLIST(&pstSleepMonitorMng->stAppInfoList, pstBussNode, stIterator)
        {
            if (pstBussNode->iBusyStatus)
            {
                *piBusyStatus = 1;
                break;
            }
        }
        *piForceNotify = pstSleepMonitorMng->iForceNotify;
        pstSleepMonitorMng->iForceNotify = 0;
        Mos_MutexUnLock(&pstSleepMonitorMng->hMutex);
    }

    // MOS_PRINTF("%s busy:%d notify:%d\n", __FUNCTION__, *piBusyStatus, *piForceNotify);
#else
    *piBusyStatus  = 0;
    *piForceNotify = 0;
#endif
}

_UI Config_AppSLeepMonotorRegist(_UC *pucAppName)
{
    _UI uiMonitorId = 0;
#if SDK_AWAKE_SLEEP_ENABLE
    if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //低功耗设备
    {
        ST_SLEEP_MONITOR_MNG *pstSleepMonitorMng = &Config_GetDeviceMng()->stSleepMonitorMng;
        Mos_MutexLock(&pstSleepMonitorMng->hMutex);
        ST_SLeepMonotorNode *pstAppNode = (ST_SLeepMonotorNode*)MOS_MALLOC(sizeof(ST_SLeepMonotorNode));
        MOS_MEMSET(pstAppNode, 0, sizeof(ST_SLeepMonotorNode));
        MOS_STRCPY(pstAppNode->ucAppName, pucAppName);
        pstAppNode->uiMonitorId   = pstSleepMonitorMng->uiMonitorId++;
        pstAppNode->iBusyStatus   = 0;
        uiMonitorId               = pstAppNode->uiMonitorId;
        MOS_LIST_ADDTAIL(&(pstSleepMonitorMng->stAppInfoList), pstAppNode);
        MOS_PRINTF("%s %s watchId:%u register\n", __FUNCTION__, pstAppNode->ucAppName, pstAppNode->uiMonitorId);
        Mos_MutexUnLock(&pstSleepMonitorMng->hMutex);
    }
    else
    {
        uiMonitorId = 1;
    }
#endif
    return uiMonitorId;
}

_VOID Config_AppSLeepMonotorUnRegist(_UI uiMonitorId)
{
#if SDK_AWAKE_SLEEP_ENABLE
    ST_MOS_LIST_ITERATOR stIterator;
    ST_SLeepMonotorNode *pstBussNode = MOS_NULL;
    ST_SLEEP_MONITOR_MNG *pstSleepMonitorMng = &Config_GetDeviceMng()->stSleepMonitorMng;
    
    if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //低功耗设备
    {
        Mos_MutexLock(&pstSleepMonitorMng->hMutex);

        FOR_EACHDATA_INLIST(&pstSleepMonitorMng->stAppInfoList, pstBussNode, stIterator)
        {
            if (pstBussNode->uiMonitorId == uiMonitorId)
            {
                MOS_PRINTF("%s %s watchId:%u unregister\n", __FUNCTION__, pstBussNode->ucAppName, pstBussNode->uiMonitorId);
                MOS_LIST_RMVNODE(&pstSleepMonitorMng->stAppInfoList, pstBussNode);
                MOS_FREE(pstBussNode);
                break;
            }
        }
        
        Mos_MutexUnLock(&pstSleepMonitorMng->hMutex);
    }
#endif
}

_VOID Config_AppSLeepMonotorUpdateStatus(_UI uiMonitorId, _INT iBusyStatus)
{
#if SDK_AWAKE_SLEEP_ENABLE
    ST_MOS_LIST_ITERATOR stIterator;
    ST_SLeepMonotorNode *pstBussNode = MOS_NULL;
    
    if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //低功耗设备
    {
        ST_SLEEP_MONITOR_MNG *pstSleepMonitorMng = &Config_GetDeviceMng()->stSleepMonitorMng;
        Mos_MutexLock(&pstSleepMonitorMng->hMutex);

        FOR_EACHDATA_INLIST(&pstSleepMonitorMng->stAppInfoList, pstBussNode, stIterator)
        {
            if (pstBussNode->uiMonitorId == uiMonitorId)
            {
                if (pstBussNode->iBusyStatus != iBusyStatus)
                {
                    pstSleepMonitorMng->iForceNotify = 1;
                }
                pstBussNode->iBusyStatus = iBusyStatus;
                MOS_PRINTF("%s %s busy:%d force:%d\n", __FUNCTION__, pstBussNode->ucAppName, pstBussNode->iBusyStatus, pstSleepMonitorMng->iForceNotify);
                break;
            }
        }
        
        Mos_MutexUnLock(&pstSleepMonitorMng->hMutex);
    }
#endif
}

_VOID Config_SetSLeepMonotorForceNotify()
{
#if SDK_AWAKE_SLEEP_ENABLE
    ST_SLEEP_MONITOR_MNG *pstSleepMonitorMng = &Config_GetDeviceMng()->stSleepMonitorMng;
    
    if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //低功耗设备
    {
        Mos_MutexLock(&pstSleepMonitorMng->hMutex);
        pstSleepMonitorMng->iForceNotify = 1;
        Mos_MutexUnLock(&pstSleepMonitorMng->hMutex);
    }
#endif
}
