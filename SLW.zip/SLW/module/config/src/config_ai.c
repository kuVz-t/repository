#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_api.h"
#include "ga1400_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

_VOID AI_CloseSocket(ST_URL_CONN_SOCKET *pstConnSocket);

/*******************************************************************************/

static _HFILE *g_phAIPic_fd                          = MOS_NULL;
static _UC g_ucAIPicFile[MOS_DIR_NAME_LEN]           = {0};

static ST_AICFG_LABEL g_stAICfgLabel[] = {
    {EN_AICFG_LABEL_FACE_BLACKLIST, "AICAM_LABELID", "AICAM_LABELNAME", "AICAM_USERID"},// 人脸黑名单label标识和原来的保持一致, 做好已下发人脸库同步
    {EN_AICFG_LABEL_FACE_WHITELIST, "FACE_WHITELIST_LABELID", "FACE_WHITELIST_LABELNAME", "FACE_WHITELIST_USERID"},
};

ST_AICFG_LABEL *Get_AICfgLabel()
{
    return g_stAICfgLabel;
}

ST_CFG_AI_MNG *Config_GetAIMng()
{
    return &Config_GetlocalCfgInf()->stAiMng;
}

// 获取新人脸能力值
_UI Config_GetNewFaceAbility()
{
    _UI uiAiAbility       = 0;
    _UI uiHaveFaceCapture = 0;
    _UI uiHaveFaceDiscern = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_COMMON_AI_ABILITY_INF_NODE *pstAiAbilityInfNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stCommonAiAblitityList, pstAiAbilityInfNode, stIterator)
    {
        if (0 == MOS_STRNCMP(pstAiAbilityInfNode->aucName, "NewFaceCaptureAbility", sizeof(pstAiAbilityInfNode->aucName)))
        {
            uiHaveFaceCapture = 1;

            if (0 != pstAiAbilityInfNode->uiAbility)
            {
                uiAiAbility = 1;
                break;
            }
        }
        else if (0 == MOS_STRNCMP(pstAiAbilityInfNode->aucName, "NewFaceDiscernAbility", sizeof(pstAiAbilityInfNode->aucName)))
        {
            uiHaveFaceDiscern = 1;

            // 0 不支持 1只支持黑名单布控 2只支持白名单布控 3.支持黑/白名单(不支持同时打开)；4.支持黑/白名单(支持同时打开)
            if (0 != pstAiAbilityInfNode->uiAbility)
            {
                uiAiAbility = 1;
                break;
            }
        }

        // 当人脸抓拍和人脸布控都查找过，退出查找
        if ((1 == uiHaveFaceCapture) && (1 == uiHaveFaceDiscern))
        {
            break;
        }
    }

    return uiAiAbility;
}

// AI 模块初始化
_INT Config_InitAIMng()
{
    if(Config_GetAIMng()->ucInitFlag == 1)
    {
        return MOS_OK;
    }
    
    Config_GetAIMng()->iAiPicMaxNum             = 0;
    Config_GetAIMng()->iAiPicCnt                = 0;

    Config_GetAIMng()->iHumanCountFlag          = 0;
    Config_GetAIMng()->iHumanCountInterval      = 1;
    MOS_MEMSET(Config_GetAIMng()->stHumanCountRegion, 0x0, sizeof(ST_CFG_HUMAN_COUNT_REGION));

    Mos_MutexCreate(&Config_GetAIMng()->hUpLoadMutex);
    Mos_MutexCreate(&Config_GetAIMng()->hUpLoad1400Mutex);
    Mos_MutexCreate(&Config_GetAIMng()->hUpLoadZipMutex);
    Mos_MutexCreate(&Config_GetAIMng()->hDownLoadMutex);
    Mos_MutexCreate(&Config_GetAIMng()->hUplaodAIAlarmPVMutex);

    Config_GetAIMng()->ucInitFlag = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_device AI Init Ok");
    return MOS_OK;
}

// AI 模块销毁
_INT AI_Task_Destroy()
{
    if(Config_GetAIMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(AICFG_LOGSTR, "Already Init");
        return MOS_OK;
    }

    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST_ITERATOR stIterator1;

    ST_CFG_LABELS_INF_NODE  *pstLabelInfNode  = MOS_NULL;
    ST_CFG_PICTURE_INF_NODE *pstPictureNode   = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stLabelsInfList, pstLabelInfNode, stIterator)
    {
        FOR_EACHDATA_INLIST(&pstLabelInfNode->stPictureInfList, pstPictureNode, stIterator1)
        {
            MOS_FREE(pstPictureNode);
        }
    }

    ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskNode     = MOS_NULL;
    ST_CFG_DOWNLOAD_PIC_INF_NODE  *pstDownLoadPictureNode  = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stDownloadTaskInfList, pstDownloadTaskNode, stIterator)
    {
        FOR_EACHDATA_INLIST(&pstDownloadTaskNode->stDownloadPicInfList, pstDownLoadPictureNode, stIterator1)
        {
            MOS_FREE(pstDownLoadPictureNode);
        }
    }

    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode  = MOS_NULL;
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfNode, stIterator)
    {
        if (pstUploadAIPic1400InfNode->pucBgPicBaseData)
        {
            MOS_FREE(pstUploadAIPic1400InfNode->pucBgPicBaseData);
        }
        if (pstUploadAIPic1400InfNode->pucFaceOrCarPicBaseData)
        {
            MOS_FREE(pstUploadAIPic1400InfNode->pucFaceOrCarPicBaseData);
        }
        if (pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead)
        {
            MOS_FREE(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead);
        }
    }

    MOS_LIST_RMVALL(&Config_GetAIMng()->stCommonAiAblitityList,      MOS_TRUE);
    MOS_LIST_RMVALL(&Config_GetAIMng()->stLabelsInfList,             MOS_TRUE);
    MOS_LIST_RMVALL(&Config_GetAIMng()->stDownloadTaskInfList,       MOS_TRUE);
    MOS_LIST_RMVALL(&Config_GetAIMng()->stUploadZipTaskInfList,      MOS_TRUE);
    MOS_LIST_RMVALL(&Config_GetAIMng()->stUploadCmdPlatTaskInfList,  MOS_TRUE);
    MOS_LIST_RMVALL(&Config_GetAIMng()->stUpload1400PlatTaskInfList, MOS_TRUE);
    MOS_LIST_RMVALL(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList,MOS_TRUE);

    Mos_MutexDelete(&Config_GetAIMng()->hUpLoadMutex);
    Mos_MutexDelete(&Config_GetAIMng()->hUpLoad1400Mutex);
    Mos_MutexDelete(&Config_GetAIMng()->hUpLoadZipMutex);
    Mos_MutexDelete(&Config_GetAIMng()->hDownLoadMutex);
    Mos_MutexDelete(&Config_GetAIMng()->hUplaodAIAlarmPVMutex);

    _INT iRet = ((Config_GetAIMng()->hUpLoadThread && Mos_ThreadDelete(Config_GetAIMng()->hUpLoadThread))||
        (Config_GetAIMng()->hUpLoadZipThread && Mos_ThreadDelete(Config_GetAIMng()->hUpLoadZipThread)) ||
        (Config_GetAIMng()->hDownLoadThread && Mos_ThreadDelete(Config_GetAIMng()->hDownLoadThread)) ||
        (Config_GetAIMng()->hUplaodAIAlarmPVThread && Mos_ThreadDelete(Config_GetAIMng()->hUplaodAIAlarmPVThread)));

    Config_GetAIMng()->ucInitFlag = 0;

    MOS_LOG_INF(AICFG_LOGSTR,"cfg_device AI task Destroy ok");
    return MOS_OK;
}

// 更新/添加通用AI能力值 返回值：MOS_TRUE-更新数据，MOS_FALSE-不更新数据
static _INT AI_UpdateCommonAiAbility(_UC *pucAiName, _UI uiAiAbility)
{
    if ((pucAiName == MOS_NULL) || (MOS_STRLEN(pucAiName) == 0))
    {
        MOS_LOG_ERR(AICFG_LOGSTR, "AiName is invalid");
        return MOS_FALSE;
    }

    _INT iUpdateFlag = MOS_FALSE;
    _INT iFirstFlag = MOS_TRUE;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_COMMON_AI_ABILITY_INF_NODE *pstAiAbilityInfNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stCommonAiAblitityList, pstAiAbilityInfNode, stIterator)
    {
        if (MOS_STRNCMP(pstAiAbilityInfNode->aucName, pucAiName, sizeof(pstAiAbilityInfNode->aucName)) == 0)
        {
            if (pstAiAbilityInfNode->uiAbility != uiAiAbility)
            {
                iUpdateFlag = MOS_TRUE;
                pstAiAbilityInfNode->uiAbility = uiAiAbility;
            }
            iFirstFlag = MOS_FALSE;
            MOS_LOG_INF(AICFG_LOGSTR,"update ai ability [%s %d]", pucAiName, uiAiAbility);
            break;
        }
    }
    
    if (iFirstFlag == MOS_TRUE)
    {
        pstAiAbilityInfNode = (ST_CFG_COMMON_AI_ABILITY_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_COMMON_AI_ABILITY_INF_NODE));
        if (pstAiAbilityInfNode == MOS_NULL)
        {
            MOS_LOG_ERR(AICFG_LOGSTR, "node malloc err  %s %u", pucAiName, uiAiAbility);
            return MOS_ERR;
        }
        iUpdateFlag = MOS_TRUE;

        MOS_STRLCPY(pstAiAbilityInfNode->aucName, pucAiName, sizeof(pstAiAbilityInfNode->aucName));
        pstAiAbilityInfNode->aucName[sizeof(pstAiAbilityInfNode->aucName)-1] = 0;
        pstAiAbilityInfNode->uiAbility = uiAiAbility;
        MOS_LIST_ADDTAIL(&Config_GetAIMng()->stCommonAiAblitityList, pstAiAbilityInfNode);

        MOS_LOG_INF(AICFG_LOGSTR,"first add ai ability [%s %d] cnt:%d", pstAiAbilityInfNode->aucName, 
                                                                        pstAiAbilityInfNode->uiAbility,
                                                                        MOS_LIST_GETCOUNT(&Config_GetAIMng()->stCommonAiAblitityList));
    }

    return iUpdateFlag;
}

// 人脸布控图片消息上报的https请求超时检测
_INT AI_ProcAiPicTimeOutList()
{
    _INT iRet = MOS_ERR;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = MOS_NULL;
    _CTIME_T cNowtime    = 0;
    _ULLID   lluDuration = 0;
    cNowtime = Mos_Time();

    _ULLID lluNowTime = (_LLID)cNowtime * 1000;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadCmdPlatTaskInfList, pstUploadAIFacePicInfNode, stIterator)
    {
        lluDuration = MOS_ABS_NUM(lluNowTime - pstUploadAIFacePicInfNode->lluReqTime);
        if ((pstUploadAIFacePicInfNode->uiUseFlag    == 1)                          &&
            (pstUploadAIFacePicInfNode->uiReportFlag == 0)                          &&
            (pstUploadAIFacePicInfNode->stDxUpAIPicAlarmData.uiHttpCancelFlag == 0) &&
            (lluDuration >= AI_FACEREC_ALARM_REPORT_TIMEOUT_MSEC)) // 30S
        {
            MOS_LOG_ERR(AICFG_LOGSTR, "UploadAIBgAndFace MSG ReqId:%u DispositionID:%s is Timeout (%llu - %llu) = %llu > %u(ms)",
                                                pstUploadAIFacePicInfNode->uiReqId, pstUploadAIFacePicInfNode->ucDispositionID,
                                                lluNowTime, pstUploadAIFacePicInfNode->lluReqTime, lluDuration, (_UI)AI_FACEREC_ALARM_REPORT_TIMEOUT_MSEC);    

            // 取消人脸布控图片消息上报的https请求
            // http fail 回调函数处理 删除AIFace任务节点、通知厂商清除AI图片数据缓存
            Http_Httpclient_CancelAsyncRequestEx(pstUploadAIFacePicInfNode->uiReqId);
            pstUploadAIFacePicInfNode->stDxUpAIPicAlarmData.uiHttpCancelFlag = 1;
#if 0
            // 通知厂商清除AI图片数据缓存 ADD by LWJ
            if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
            {
                iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucFaceDataBuf, pstUploadAIFacePicInfNode->pucBgDataBuf);
                if (MOS_OK == iRet)
                {
                    // MOS_LOG_INF(AICFG_LOGSTR,"Device pFunFreeAiPicCache DispositionID:%s OK ", pstUploadAIFacePicInfNode->ucDispositionID);
                }
                else
                {
                    _UC aucStrErrLog[128] = {0};
                    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunFreeAiPicCache DispositionID:%s Bgbuf:%p Picbuf:%p return failed", pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucBgDataBuf, pstUploadAIFacePicInfNode->pucFaceDataBuf);        
                    CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                            EN_AI_RT_UPLOAD_FACEREC_FUNCFREECACHE_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);   
                }
            }
            else
            {
                MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeAiPicCache is NULL!");
            }

            // 从上传AIFace任务节点删除人脸
            Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
            Config_DelUploadAIFacePicTaskNode(0, pstUploadAIFacePicInfNode->uiReqId);
            Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));
#endif
            lluDuration = 0;
        }
    }

    return MOS_OK;
}

_INT AI_ProcAiZipTimeOutList()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = MOS_NULL;
    _UC ucZipFilePath[128] = {0};
    _CTIME_T cNowtime      = 0;
    _ULLID   lluDuration   = 0;
    cNowtime = Mos_Time();

    _ULLID lluNowTime = (_LLID)cNowtime * 1000;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadZipTaskInfList, pstUploadAIZipInfNode, stIterator)
    {
        lluDuration = MOS_ABS_NUM(lluNowTime - pstUploadAIZipInfNode->lluReqTime);
        if ((pstUploadAIZipInfNode->uiUseFlag                             == 1)  &&
            (pstUploadAIZipInfNode->uiReportFlag                          == 0)  &&
            (pstUploadAIZipInfNode->stDxUpAIZipEventData.uiHttpCancelFlag == 0)  &&
            (lluDuration >= AI_ZIP_ALARM_REPORT_TIMEOUT_MSEC)) // 30S
        {
            MOS_LOG_ERR(AICFG_LOGSTR, "UploadAIZIP MSG ReqId:%u ZipFilePath:%s is Timeout (%llu - %llu) = %llu > %u(ms)",
                                                pstUploadAIZipInfNode->uiReqId, pstUploadAIZipInfNode->ucZipFilePath,
                                                lluNowTime, pstUploadAIZipInfNode->lluReqTime, lluDuration, (_UI)AI_ZIP_ALARM_REPORT_TIMEOUT_MSEC);    
            // http fail 回调函数处理 删除ZIP文件/从上传AI_ZIP任务节点删除人脸
            Http_Httpclient_CancelAsyncRequestEx(pstUploadAIZipInfNode->uiReqId);
            pstUploadAIZipInfNode->stDxUpAIZipEventData.uiHttpCancelFlag = 1;
#if 0
            // 删除ZIP文件
            MOS_STRLCPY(ucZipFilePath, pstUploadAIZipInfNode->ucZipFilePath, sizeof(ucZipFilePath));
            Mos_FileRmv(ucZipFilePath);

            // 从上传AI_ZIP任务节点删除人脸
            Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
            Config_DelUploadAIZipTaskNode(0, pstUploadAIZipInfNode->uiReqId);
            Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));
#endif
            lluDuration = 0;
        }
    }

    return MOS_OK;
}

_INT AI_ProcAiAlarmUploadPVTimeOutList()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;
    _CTIME_T cNowtime = 0;
    cNowtime = Mos_Time();

    _LLID lluNowTime = (_LLID)cNowtime;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfNode, stIterator)
    {
        if (pstUplaodAIAlarmPVInfNode->uiUseFlag && pstUplaodAIAlarmPVInfNode->uiReportFlag == 1 &&
            (lluNowTime - pstUplaodAIAlarmPVInfNode->lluReportTimeStamp >= AI_IOTPV_ALARM_REPORT_TIMEOUT_SEC))
        {
            // if (((lluNowTime - pstUplaodAIAlarmPVInfNode->lluReportTimeStamp)%10) == 0)
            // {
            //     MOS_PRINTF("%s Timeout=%llu ReqId=%u PicPath=%s VideoPath=%s\n", __FUNCTION__, (lluNowTime - pstUplaodAIAlarmPVInfNode->lluReportTimeStamp),
            //     pstUplaodAIAlarmPVInfNode->uiReqId,pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
            // }
            // _UI uiReqId = pstUplaodAIAlarmPVInfNode->uiReqId;
            // // 通知厂商清除图片数据缓存 
            // if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
            // {
            //     _INT iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
            //                                                     pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
            //     if (MOS_OK != iRet)
            //     {
            //         MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed",
            //                                     pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
            //                                     pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
            //     }
            // }
            // else
            // {
            //     MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
            // }
            // MOS_LOG_WARN(AICFG_LOGSTR,"DelUploadAIAlarmPVTaskNode ReqId=%d", uiReqId);
            // 删除上传AI告警图片和视频的节点
            // Config_DelUploadAIAlarmPVTaskNode(0, uiReqId); 
            // break;
        }
    }

    return MOS_OK;
}

/********************AI_LABEL START********************/
// 添加Labels链表节点
_INT Config_AddAILabelNode(_INT iCamId, _UC *pucLabelID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_LABELS_INF_NODE *pstLabelInfNode     = MOS_NULL;
    ST_CFG_LABELS_INF_NODE *pstLabelInfTmpNode  = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stLabelsInfList, pstLabelInfNode, stIterator)
    {
        if(pstLabelInfNode->uiUseFlag == 1 && (MOS_STRCMP(pstLabelInfNode->ucLabelID, pucLabelID) == 0))
        {
            break;
        }
        else if(pstLabelInfNode->uiUseFlag == 0)
        {
            pstLabelInfTmpNode = pstLabelInfNode;
        }
    }
    if(pstLabelInfNode == MOS_NULL)
    {
        if(pstLabelInfTmpNode == MOS_NULL)
        {
            pstLabelInfNode = (ST_CFG_LABELS_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_LABELS_INF_NODE));
            MOS_LIST_ADDTAIL(&Config_GetAIMng()->stLabelsInfList, pstLabelInfNode);
        }
        else
        {
            pstLabelInfNode = pstLabelInfTmpNode;
        }
    }

    MOS_STRLCPY(pstLabelInfNode->ucLabelID, pucLabelID, sizeof(pstLabelInfNode->ucLabelID));
    pstLabelInfNode->uiUseFlag  = 1;

    Config_GetItemSign()->ucSaveAiFlag  = 1;
    Config_GetItemSign()->ucCfgAiUpdate = 1;
    return MOS_OK;
}

// 删除Labels链表节点
_INT Config_DeleteAILabelNode(_INT iCamId, _UC *pucLabelID)
{
    ST_MOS_LIST_ITERATOR    stIterator;
    ST_CFG_PICTURE_INF_NODE *pstPictureNode  = MOS_NULL;
    ST_CFG_LABELS_INF_NODE  *pstLabelInfNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stLabelsInfList, pstLabelInfNode, stIterator)
    {
        if(pstLabelInfNode->uiUseFlag == 1 && (MOS_STRCMP(pstLabelInfNode->ucLabelID, pucLabelID) == 0))
        {
            pstLabelInfNode->uiUseFlag = 0;
            pstLabelInfNode->uiPicType = 0;
            pstLabelInfNode->uiWBList  = 0;
            MOS_MEMSET(pstLabelInfNode->ucUserID,    0, sizeof(pstLabelInfNode->ucUserID));
            MOS_MEMSET(pstLabelInfNode->ucLabelID,   0, sizeof(pstLabelInfNode->ucLabelID));
            MOS_MEMSET(pstLabelInfNode->ucLabelName, 0, sizeof(pstLabelInfNode->ucLabelName));
            break;
        }
    }
    if(pstLabelInfNode == MOS_NULL)
    {
        return MOS_OK;
    }
    FOR_EACHDATA_INLIST(&pstLabelInfNode->stPictureInfList, pstPictureNode, stIterator)
    {
        pstPictureNode->uiUseFlag = 0;
    }

    Config_GetItemSign()->ucSaveAiFlag  = 1;
    Config_GetItemSign()->ucCfgAiUpdate = 1;
    return MOS_OK;
}

// 查找Label节点
ST_CFG_LABELS_INF_NODE *Config_FindLabelNode(_INT iCamId, _UC *pucLabelID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_LABELS_INF_NODE *pstLabelInfNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stLabelsInfList, pstLabelInfNode, stIterator)
    {
        if(pstLabelInfNode->uiUseFlag == 1 && (MOS_STRCMP(pstLabelInfNode->ucLabelID, pucLabelID) == 0))
        {
            break;
        }
    }
    return pstLabelInfNode;
}

// Label设置LabelName 人脸图片父集名称
_INT Config_SetLabelNodeName(_INT iCamId, _UC *pucLabelID, _UC *pucLabelName)
{
    MOS_PARAM_NULL_RETERR(pucLabelName);

    ST_CFG_LABELS_INF_NODE *pstLabelInfNode = Config_FindLabelNode(iCamId, pucLabelID);
    if(pstLabelInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(MOS_STRCMP(pstLabelInfNode->ucLabelName, pucLabelName) != 0)
    {
        MOS_STRLCPY(pstLabelInfNode->ucLabelName, pucLabelName, sizeof(pstLabelInfNode->ucLabelName));
        Config_GetItemSign()->ucSaveAiFlag  = 1;
        Config_GetItemSign()->ucCfgAiUpdate = 1;
    }
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set pucLabelName %s for pucLabelID %s", pucLabelName, pucLabelID);
    return MOS_OK;
}

// Label设置UserID 这组图片所属用户
_INT Config_SetLabelNodeUserID(_INT iCamId, _UC *pucLabelID, _UC *pucUserID)
{
    MOS_PARAM_NULL_RETERR(pucUserID);

    ST_CFG_LABELS_INF_NODE *pstLabelInfNode = Config_FindLabelNode(iCamId, pucLabelID);
    if(pstLabelInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(MOS_STRCMP(pstLabelInfNode->ucUserID, pucUserID) != 0)
    {
        MOS_STRLCPY(pstLabelInfNode->ucUserID, pucUserID, sizeof(pstLabelInfNode->ucUserID));
        Config_GetItemSign()->ucSaveAiFlag  = 1;
        Config_GetItemSign()->ucCfgAiUpdate = 1;
    }
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set pucUserID %s for pucLabelID %s", pucUserID, pucLabelID);
    return MOS_OK;
}

// Label设置PicType 人脸图片父集类型
_INT Config_SetLabelNodePicType(_INT iCamId, _UC *pucLabelID, _UI uiPicType)
{
    ST_CFG_LABELS_INF_NODE *pstLabelInfNode = Config_FindLabelNode(iCamId, pucLabelID);
    if(pstLabelInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstLabelInfNode->uiPicType != uiPicType)
    {
        pstLabelInfNode->uiPicType = uiPicType;
        Config_GetItemSign()->ucSaveAiFlag  = 1;
        Config_GetItemSign()->ucCfgAiUpdate = 1;
    }
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set uiPicType %d for pucLabelID %s", uiPicType, pucLabelID);
    return MOS_OK;
}

// Label设置WBList 人脸图片父集所属名单
_INT Config_SetLabelNodeWBList(_INT iCamId, _UC *pucLabelID, _UI uiWBList)
{
    ST_CFG_LABELS_INF_NODE *pstLabelInfNode = Config_FindLabelNode(iCamId, pucLabelID);
    if(pstLabelInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstLabelInfNode->uiWBList != uiWBList)
    {
        pstLabelInfNode->uiWBList = uiWBList;
        Config_GetItemSign()->ucSaveAiFlag  = 1;
        Config_GetItemSign()->ucCfgAiUpdate = 1;
    }
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set uiWBList %d for pucLabelID %s", uiWBList, pucLabelID);
    return MOS_OK;
}

// 往Label添加 Pic
_INT Config_AddPictureToLabel(_INT iCamId,  _UC *pucLabelID, _UC *pucDesc, _UC *pucDispositionID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PICTURE_INF_NODE *pstPictureInfNode    = MOS_NULL;
    ST_CFG_PICTURE_INF_NODE *pstPictureInfTmpNode = MOS_NULL;
    ST_CFG_LABELS_INF_NODE  *pstLabelInfNode      = Config_FindLabelNode(iCamId, pucLabelID);
    
    if(pstLabelInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstLabelInfNode->stPictureInfList, pstPictureInfNode, stIterator)
    {
        if(pstPictureInfNode->uiUseFlag && (MOS_STRCMP(pstPictureInfNode->ucDispositionID, pucDispositionID) == 0))
        {
            break;
        }
        else if(pstPictureInfNode->uiUseFlag == 0)
        {
            pstPictureInfTmpNode = pstPictureInfNode;
        }
    }
    if(pstPictureInfNode == MOS_NULL)
    {
        if(pstPictureInfTmpNode == MOS_NULL)
        {
            MOS_PRINTF("%s:%d  malloc ST_CFG_PICTURE_INF_NODE \r\n", __FUNCTION__, __LINE__);
            pstPictureInfNode = (ST_CFG_PICTURE_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_PICTURE_INF_NODE));
            MOS_LIST_ADDTAIL(&pstLabelInfNode->stPictureInfList, pstPictureInfNode);
        }
        else
        {
            MOS_PRINTF("%s:%d  no malloc ST_CFG_PICTURE_INF_NODE \r\n", __FUNCTION__, __LINE__);
            pstPictureInfNode = pstPictureInfTmpNode;
        }
    }

    if (pucDesc != MOS_NULL)
    {
        // MOS_PRINTF("%s:%d ucDesc:%s \r\n", __FUNCTION__, __LINE__, pucDesc);
        MOS_STRLCPY(pstPictureInfNode->ucDesc, pucDesc, sizeof(pstPictureInfNode->ucDesc));
        // MOS_PRINTF("%s:%d Node ucDesc:%s \r\n", __FUNCTION__, __LINE__, pstPictureInfNode->ucDesc);
    }
    if (pucDispositionID != MOS_NULL)
    {
        // MOS_PRINTF("%s:%d ucDispositionID:%s \r\n", __FUNCTION__, __LINE__, pucDispositionID);
        MOS_STRLCPY(pstPictureInfNode->ucDispositionID, pucDispositionID, sizeof(pstPictureInfNode->ucDispositionID));
        // MOS_PRINTF("%s:%d Node ucDispositionID:%s \r\n", __FUNCTION__, __LINE__, pstPictureInfNode->ucDispositionID);
    }
    pstPictureInfNode->uiUseFlag        = 1;

    Config_GetItemSign()->ucSaveAiFlag  = 1;
    Config_GetItemSign()->ucCfgAiUpdate = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"add ucDispositionID:%s", pucDispositionID);
    return MOS_OK;
}

// 删除LAbel中指定的Pic
_INT Config_DelPictureToLabel(_INT iCamId,  _UC *pucLabelID, _UC *pucDispositionID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_PICTURE_INF_NODE *pstPictureInfNode = MOS_NULL;
    ST_CFG_LABELS_INF_NODE  *pstLabelInfNode   = Config_FindLabelNode(iCamId, pucLabelID);
    
    if(pstLabelInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstLabelInfNode->stPictureInfList, pstPictureInfNode, stIterator)
    {
        if(pstPictureInfNode->uiUseFlag && (MOS_STRCMP(pstPictureInfNode->ucDispositionID, pucDispositionID) == 0))
        {
            MOS_LOG_INF(AICFG_LOGSTR,"del ucDispositionID:%s", pucDispositionID);
            
            pstPictureInfNode->uiUseFlag        = 0;
            MOS_MEMSET(pstPictureInfNode->ucDesc, 0, sizeof(pstPictureInfNode->ucDesc));
            MOS_MEMSET(pstPictureInfNode->ucDispositionID, 0, sizeof(pstPictureInfNode->ucDispositionID));

            Config_GetItemSign()->ucSaveAiFlag  = 1;
            Config_GetItemSign()->ucCfgAiUpdate = 1;
            break;
        }
    }

    return MOS_OK;
}

// 开始同步Label和Pic
_INT Config_BeginSyncLabelAndPicture(_INT iCamId)
{
    ST_MOS_LIST_ITERATOR    stIterator,stIterator1;
    ST_CFG_LABELS_INF_NODE  *pstLabelInfNode   = MOS_NULL;
    ST_CFG_PICTURE_INF_NODE *pstPictureInfNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stLabelsInfList, pstLabelInfNode, stIterator)
    {
        if(pstLabelInfNode->uiUseFlag == 1)
        {
            pstLabelInfNode->uiUseFlag = 2;
        }
        FOR_EACHDATA_INLIST(&pstLabelInfNode->stPictureInfList,pstPictureInfNode,stIterator1)
        {
            if(pstPictureInfNode->uiUseFlag == 1)
            {
                pstPictureInfNode->uiUseFlag = 2;
            }
        }
    }
    return MOS_OK;
}

// 结束同步Label和Pic
_INT Config_EndSyncLabelAndPicture(_INT iCamId)
{
    ST_MOS_LIST_ITERATOR    stIterator,stIterator1;
    ST_CFG_LABELS_INF_NODE  *pstLabelInfNode   = MOS_NULL;
    ST_CFG_PICTURE_INF_NODE *pstPictureInfNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stLabelsInfList, pstLabelInfNode, stIterator)
    {
        if(pstLabelInfNode->uiUseFlag == 2)
        {
            pstLabelInfNode->uiUseFlag = 0;
        }
        FOR_EACHDATA_INLIST(&pstLabelInfNode->stPictureInfList, pstPictureInfNode, stIterator1)
        {
            if(pstPictureInfNode->uiUseFlag == 2)
            {
                pstPictureInfNode->uiUseFlag = 0;
            }
        }
    }
    Config_GetItemSign()->ucSaveAiFlag = 1;
    return MOS_OK;
}
/********************AI_LABEL END**********************/

/********************AI_DOWN START*********************/
// 添加DownloadTask链表节点
_INT Config_AddAIDownloadTaskNode(_INT iCamId, _UC *pucTaskID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskNode     = MOS_NULL;
    ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskTmpNode  = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stDownloadTaskInfList, pstDownloadTaskNode, stIterator)
    {
        if(pstDownloadTaskNode->uiUseFlag == 1 && (MOS_STRCMP(pstDownloadTaskNode->ucTaskID, pucTaskID) == 0))
        {
            break;
        }
        else if(pstDownloadTaskNode->uiUseFlag == 0)
        {
            pstDownloadTaskTmpNode = pstDownloadTaskNode;
        }
    }
    if(pstDownloadTaskNode == MOS_NULL)
    {
        if(pstDownloadTaskTmpNode == MOS_NULL)
        {
            pstDownloadTaskNode = (ST_CFG_DOWNLOAD_TASK_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_DOWNLOAD_TASK_INF_NODE));
            MOS_LIST_ADDTAIL(&Config_GetAIMng()->stDownloadTaskInfList, pstDownloadTaskNode);
        }
        else
        {
            pstDownloadTaskNode = pstDownloadTaskTmpNode;
        }
    }

    MOS_STRLCPY(pstDownloadTaskNode->ucTaskID, pucTaskID, sizeof(pstDownloadTaskNode->ucTaskID));
    pstDownloadTaskNode->uiUseFlag  = 1;

    Config_GetItemSign()->ucSaveAiFlag  = 1;
    // Config_GetItemSign()->ucCfgAiUpdate = 1;
    return MOS_OK;
}

// 删除DownloadTask链表节点
_INT Config_DeleteAIDownloadTaskNode(_INT iCamId, _UC *pucTaskID)
{
    ST_MOS_LIST_ITERATOR    stIterator;
    ST_CFG_DOWNLOAD_PIC_INF_NODE  *pstDownLoadPictureNode  = MOS_NULL;
    ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskNode     = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stDownloadTaskInfList, pstDownloadTaskNode, stIterator)
    {
        if(pstDownloadTaskNode->uiUseFlag == 1 && (MOS_STRCMP(pstDownloadTaskNode->ucTaskID, pucTaskID) == 0))
        {
            MOS_LOG_INF(AICFG_LOGSTR,"del download TaskId:%s", pucTaskID);
            pstDownloadTaskNode->uiUseFlag = 0;
            pstDownloadTaskNode->uiPicType = 0;
            MOS_MEMSET(pstDownloadTaskNode->ucTaskID, 0, sizeof(pstDownloadTaskNode->ucTaskID));
            MOS_MEMSET(pstDownloadTaskNode->ucUserID, 0, sizeof(pstDownloadTaskNode->ucUserID));
            break;
        }
    }
    if(pstDownloadTaskNode == MOS_NULL)
    {
        return MOS_OK;
    }
    FOR_EACHDATA_INLIST(&pstDownloadTaskNode->stDownloadPicInfList, pstDownLoadPictureNode, stIterator)
    {
        pstDownLoadPictureNode->uiUseFlag = 0;
        pstDownLoadPictureNode->uiWBList  = 0;
        MOS_MEMSET(pstDownLoadPictureNode->ucDesc,          0, sizeof(pstDownLoadPictureNode->ucDesc));
        MOS_MEMSET(pstDownLoadPictureNode->ucPicUrl,        0, sizeof(pstDownLoadPictureNode->ucPicUrl));
        MOS_MEMSET(pstDownLoadPictureNode->ucDispositionID, 0, sizeof(pstDownLoadPictureNode->ucDispositionID));
    }

    Config_GetItemSign()->ucSaveAiFlag  = 1;
    // Config_GetItemSign()->ucCfgAiUpdate = 1;
    return MOS_OK;
}

// 查找DownloadTask链表节点
ST_CFG_DOWNLOAD_TASK_INF_NODE *Config_FindDownloadTaskNode(_INT iCamId, _UC *pucTaskID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stDownloadTaskInfList, pstDownloadTaskNode, stIterator)
    {
        if(pstDownloadTaskNode->uiUseFlag == 1 && (MOS_STRCMP(pstDownloadTaskNode->ucTaskID, pucTaskID) == 0))
        {
            break;
        }
    }
    return pstDownloadTaskNode;
}

// 设置DownloadTask节点 的UserID 用户标识
_INT Config_SetDownloadTaskNodeUserID(_INT iCamId, _UC *pucTaskID, _UC *pucUserID)
{
    MOS_PARAM_NULL_RETERR(pucUserID);

    ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskNode = Config_FindDownloadTaskNode(iCamId, pucTaskID);
    if(pstDownloadTaskNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(MOS_STRCMP(pstDownloadTaskNode->ucUserID, pucUserID) != 0)
    {
        MOS_STRLCPY(pstDownloadTaskNode->ucUserID, pucUserID, sizeof(pstDownloadTaskNode->ucUserID));
        Config_GetItemSign()->ucSaveAiFlag  = 1;
        // Config_GetItemSign()->ucCfgAiUpdate = 1;
    }
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set pucUserID %s for pucTaskID %s", pucUserID, pucTaskID);
    return MOS_OK;
}

// 设置DownloadTask节点 的PicType 图片类型
_INT Config_SetDownloadTaskNodePicType(_INT iCamId, _UC *pucTaskID, _UI uiPicType)
{
    ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskNode = Config_FindDownloadTaskNode(iCamId, pucTaskID);
    if(pstDownloadTaskNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstDownloadTaskNode->uiPicType != uiPicType)
    {
        pstDownloadTaskNode->uiPicType = uiPicType;
        Config_GetItemSign()->ucSaveAiFlag  = 1;
        // Config_GetItemSign()->ucCfgAiUpdate = 1;
    }
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set uiPicType %d for pucTaskID %s", uiPicType, pucTaskID);
    return MOS_OK;
}

// 添加Pic到下载任务链表
_INT Config_AddPictureToDownloadTask(_INT iCamId,  _UC *pucTaskID, _UI uiWBList, _UC *pucDesc, _UC *pucDispositionID, _UC *pucPicUrl)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_DOWNLOAD_PIC_INF_NODE   *pstDownloadPictureInfNode    = MOS_NULL;
    ST_CFG_DOWNLOAD_PIC_INF_NODE   *pstDownloadPictureInfTmpNode = MOS_NULL;
    ST_CFG_DOWNLOAD_TASK_INF_NODE  *pstDownloadTaskNode = Config_FindDownloadTaskNode(iCamId, pucTaskID);
    
    if(pstDownloadTaskNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstDownloadTaskNode->stDownloadPicInfList, pstDownloadPictureInfNode, stIterator)
    {
        if(pstDownloadPictureInfNode->uiUseFlag && (MOS_STRCMP(pstDownloadPictureInfNode->ucDispositionID, pucDispositionID) == 0))
        {
            break;
        }
        else if(pstDownloadPictureInfNode->uiUseFlag == 0)
        {
            pstDownloadPictureInfTmpNode = pstDownloadPictureInfNode;
        }
    }
    if(pstDownloadPictureInfNode == MOS_NULL)
    {
        if(pstDownloadPictureInfTmpNode == MOS_NULL)
        {
            MOS_PRINTF("%s:%d  malloc ST_CFG_DOWNLOAD_PIC_INF_NODE \r\n", __FUNCTION__, __LINE__);
            pstDownloadPictureInfNode = (ST_CFG_DOWNLOAD_PIC_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_DOWNLOAD_PIC_INF_NODE));
            MOS_LIST_ADDTAIL(&pstDownloadTaskNode->stDownloadPicInfList, pstDownloadPictureInfNode);
        }
        else
        {
            MOS_PRINTF("%s:%d  no malloc ST_CFG_DOWNLOAD_PIC_INF_NODE \r\n", __FUNCTION__, __LINE__);
            pstDownloadPictureInfNode = pstDownloadPictureInfTmpNode;
        }
    }

    if (pucDesc != MOS_NULL)
    {
        // MOS_PRINTF("%s:%d ucDesc:%s \r\n", __FUNCTION__, __LINE__, pucDesc);
        MOS_STRLCPY(pstDownloadPictureInfNode->ucDesc, pucDesc, sizeof(pstDownloadPictureInfNode->ucDesc));
        // MOS_PRINTF("%s:%d Node ucDesc:%s \r\n", __FUNCTION__, __LINE__, pstDownloadPictureInfNode->ucDesc);
    }
    if (pucDispositionID != MOS_NULL)
    {
        // MOS_PRINTF("%s:%d ucDispositionID:%s \r\n", __FUNCTION__, __LINE__, pucDispositionID);
        MOS_STRLCPY(pstDownloadPictureInfNode->ucDispositionID, pucDispositionID, sizeof(pstDownloadPictureInfNode->ucDispositionID));
        // MOS_PRINTF("%s:%d Node ucDispositionID:%s \r\n", __FUNCTION__, __LINE__, pstDownloadPictureInfNode->ucDispositionID);
    }
    if (pucPicUrl != MOS_NULL)
    {
        // MOS_PRINTF("%s:%d pucPicUrl:%s \r\n", __FUNCTION__, __LINE__, pucPicUrl);
        MOS_STRLCPY(pstDownloadPictureInfNode->ucPicUrl, pucPicUrl, sizeof(pstDownloadPictureInfNode->ucPicUrl));
        // MOS_PRINTF("%s:%d Node ucPicUrl:%s \r\n", __FUNCTION__, __LINE__, pstDownloadPictureInfNode->ucPicUrl);
    }

    pstDownloadPictureInfNode->uiReqId   = Mos_GetSessionId();
    pstDownloadPictureInfNode->uiWBList  = uiWBList;
    pstDownloadPictureInfNode->uiUseFlag = 1;

    MOS_LOG_INF(AICFG_LOGSTR,"add download pic WBList:%u, ReqId:%u", pstDownloadPictureInfNode->uiWBList, pstDownloadPictureInfNode->uiReqId);

    Config_GetItemSign()->ucSaveAiFlag  = 1;
    // Config_GetItemSign()->ucCfgAiUpdate = 1;
    return MOS_OK;
}

// 获取 DOWNLOAD_PIC 链表节点 使用数
_INT Config_GetPictureToDownloadTaskNodeCount(_INT iCamId, _UC *pucTaskID, _UI *puiPictureToDownloadNodeCount)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_DOWNLOAD_PIC_INF_NODE   *pstDownloadPictureInfNode = MOS_NULL;
    ST_CFG_DOWNLOAD_TASK_INF_NODE  *pstDownloadTaskNode = Config_FindDownloadTaskNode(iCamId, pucTaskID);
    
    if(pstDownloadTaskNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstDownloadTaskNode->stDownloadPicInfList, pstDownloadPictureInfNode, stIterator)
    {
        if(pstDownloadPictureInfNode->uiUseFlag == 1)
        {
            (*puiPictureToDownloadNodeCount)++;
            break;
        }
    }
    return MOS_OK;
}

// 从下载任务链表删除Pic
_INT Config_DelPictureToDownloadTask(_INT iCamId, _UC *pucTaskID, _UC *pucDispositionID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_DOWNLOAD_PIC_INF_NODE   *pstDownloadPictureInfNode = MOS_NULL;
    ST_CFG_DOWNLOAD_TASK_INF_NODE  *pstDownloadTaskNode = Config_FindDownloadTaskNode(iCamId, pucTaskID);
    
    if(pstDownloadTaskNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&pstDownloadTaskNode->stDownloadPicInfList, pstDownloadPictureInfNode, stIterator)
    {
        if(pstDownloadPictureInfNode->uiUseFlag && (MOS_STRCMP(pstDownloadPictureInfNode->ucDispositionID, pucDispositionID) == 0))
        {
            MOS_LOG_INF(AICFG_LOGSTR,"del download pic ucDispositionID:%s, ReqId:%u", pucDispositionID, pstDownloadPictureInfNode->uiReqId);
            
            pstDownloadPictureInfNode->uiUseFlag    = 0;
            pstDownloadPictureInfNode->uiWBList     = 0;
            pstDownloadPictureInfNode->uiReqId      = 0;
            MOS_MEMSET(pstDownloadPictureInfNode->ucDesc, 0, sizeof(pstDownloadPictureInfNode->ucDesc));
            MOS_MEMSET(pstDownloadPictureInfNode->ucPicUrl, 0, sizeof(pstDownloadPictureInfNode->ucPicUrl));
            MOS_MEMSET(pstDownloadPictureInfNode->ucDispositionID, 0, sizeof(pstDownloadPictureInfNode->ucDispositionID));

            Config_GetItemSign()->ucSaveAiFlag      = 1;
            // Config_GetItemSign()->ucCfgAiUpdate     = 1;
            break;
        }
    }

    return MOS_OK;
}
/********************AI_DOWN END**********************/

/*******************AI_FACE_PIC START*******************/
// 获取上传AIFace任务已用节点数 UPLOAD_AIFACE_PIC
_INT Config_GetUploadAIFacePicTaskNodeCount(_INT iCamId, _UI *puiAIFaceUploadPicNodeCount)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = MOS_NULL;

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadCmdPlatTaskInfList, pstUploadAIFacePicInfNode, stIterator)
    {
        if(pstUploadAIFacePicInfNode->uiUseFlag == 1)
        {
            (*puiAIFaceUploadPicNodeCount)++;
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));

    return MOS_OK;
}

// 添加 UPLOAD_AIFACE_PIC 链表节点
_INT Config_AddUploadAIFacePicTaskNode(_INT iCamId, _UI uiReqId, _LLID lluHappenTime, _UC *pucNotificationID, ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInf)
{
    _UI uiAIFaceUploadPicNodeCount = 0;
    MOS_PARAM_NULL_RETERR(pstAiPicEventInf);
    MOS_PARAM_NULL_RETERR(pucNotificationID);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode     = MOS_NULL;
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfTmpNode  = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadCmdPlatTaskInfList, pstUploadAIFacePicInfNode, stIterator)
    {
        if(pstUploadAIFacePicInfNode->uiUseFlag == 1 && pstUploadAIFacePicInfNode->uiReqId == uiReqId)
        {
            break;
        }
        else if(pstUploadAIFacePicInfNode->uiUseFlag == 0)
        {
            pstUploadAIFacePicInfTmpNode = pstUploadAIFacePicInfNode;
        }
    }
    if(pstUploadAIFacePicInfNode == MOS_NULL)
    {
        if(pstUploadAIFacePicInfTmpNode == MOS_NULL)
        {
            pstUploadAIFacePicInfNode = (ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE));
            MOS_LIST_ADDTAIL(&Config_GetAIMng()->stUploadCmdPlatTaskInfList, pstUploadAIFacePicInfNode);
        }
        else
        {
            pstUploadAIFacePicInfNode = pstUploadAIFacePicInfTmpNode;
        }
    }

    pstUploadAIFacePicInfNode->uiReqId          = uiReqId;
    pstUploadAIFacePicInfNode->lluReqTime       = (_LLID)Mos_Time() * 1000;// 请求时间使用当前系统时间, 用于超时判断
    pstUploadAIFacePicInfNode->uiReportFlag     = 0;
    pstUploadAIFacePicInfNode->lluReportTimeStamp = lluHappenTime;
    MOS_STRLCPY(pstUploadAIFacePicInfNode->ucNotificationID, pucNotificationID, sizeof(pstUploadAIFacePicInfNode->ucNotificationID));
    MOS_STRLCPY(pstUploadAIFacePicInfNode->ucDispositionID,  pstAiPicEventInf->pstAiPicHead->aucLabelID, sizeof(pstUploadAIFacePicInfNode->ucDispositionID));
    pstUploadAIFacePicInfNode->pucFaceDataBuf     = pstAiPicEventInf->pstAiPicHead->pucPicBuf;
    pstUploadAIFacePicInfNode->uiFaceDataBufLen   = pstAiPicEventInf->pstAiPicHead->uiPicLen;
    pstUploadAIFacePicInfNode->pucBgDataBuf       = pstAiPicEventInf->pucBgJpgBuff;
    pstUploadAIFacePicInfNode->uiBgDataBufLen     = pstAiPicEventInf->uiBgJpgLen;
    pstUploadAIFacePicInfNode->stDxUpAIPicAlarmData.uiHttpCancelFlag = 0;

    pstUploadAIFacePicInfNode->uiUseFlag = 1;

    Config_GetUploadAIFacePicTaskNodeCount(0, &uiAIFaceUploadPicNodeCount);

    MOS_LOG_INF(AICFG_LOGSTR,"ADD AIface Pic NotificationID:%s, AIFaceUploadPicNodeCount:%u, ReqId:%u", 
        pucNotificationID, uiAIFaceUploadPicNodeCount, pstUploadAIFacePicInfNode->uiReqId);

#if AIFACE_WRITEFILE
    FILE *hFileBg        = NULL;
    _UC   aucFileNameBg[256] = {0};

    MOS_VSNPRINTF(aucFileNameBg,256,"%s/%s.jpeg",Config_GetCoreMng()->aucCachePath, pstUploadAIFacePicInfNode->ucNotificationID);
    if (NULL == hFileBg)
    {
        hFileBg = fopen(aucFileNameBg, "wb+");
        if (NULL == hFileBg)
        {
            MOS_PRINTF("fopen: %s failed", aucFileNameBg);
            return -1;
        }
    }

    if (hFileBg)
    {
        fseek(hFileBg, SEEK_SET, 0);
        fwrite(pstUploadAIFacePicInfNode->pucBgDataBuf, pstUploadAIFacePicInfNode->uiBgDataBufLen, 1, hFileBg);
        fclose(hFileBg);
        hFileBg = NULL;
    }
#endif
    return MOS_OK;
}

// 查找上传AIFace任务链表节点
ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *Config_FindUploadAIFacePicTaskNode(_INT iCamId, _UI uiReqId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadCmdPlatTaskInfList, pstUploadAIFacePicInfNode, stIterator)
    {
        if(pstUploadAIFacePicInfNode->uiUseFlag == 1 && pstUploadAIFacePicInfNode->uiReqId == uiReqId)
        {
            break;
        }
    }
    return pstUploadAIFacePicInfNode;
}

// 设置上传AIFace任务节点的信息
_INT Config_SetUploadAIFacePicTaskNodeInfo(_INT iCamId, ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNodeBak)
{
    MOS_PARAM_NULL_RETERR(pstUploadAIFacePicInfNodeBak);

    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = Config_FindUploadAIFacePicTaskNode(iCamId, pstUploadAIFacePicInfNodeBak->uiReqId);
    if(pstUploadAIFacePicInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 消息类型: 1、人脸；2、车牌
    if(pstUploadAIFacePicInfNode->uiNotifyType != pstUploadAIFacePicInfNodeBak->uiNotifyType)
    {
        pstUploadAIFacePicInfNode->uiNotifyType = pstUploadAIFacePicInfNodeBak->uiNotifyType;
    }

    // 人脸/车牌图直连分流的资源池访问地址
    if (pstUploadAIFacePicInfNodeBak->ucFaceRequestURL)
    {
        if(MOS_STRCMP(pstUploadAIFacePicInfNode->ucFaceRequestURL, pstUploadAIFacePicInfNodeBak->ucFaceRequestURL) != 0)
        {
            MOS_STRLCPY(pstUploadAIFacePicInfNode->ucFaceRequestURL,    pstUploadAIFacePicInfNodeBak->ucFaceRequestURL,    sizeof(pstUploadAIFacePicInfNode->ucFaceRequestURL));
            
            if (pstUploadAIFacePicInfNodeBak->ucFaceRequestDate)
            {
                MOS_STRLCPY(pstUploadAIFacePicInfNode->ucFaceRequestDate,   pstUploadAIFacePicInfNodeBak->ucFaceRequestDate,   sizeof(pstUploadAIFacePicInfNode->ucFaceRequestDate));
            }

            if (pstUploadAIFacePicInfNodeBak->ucFaceAuthorization)
            {
                MOS_STRLCPY(pstUploadAIFacePicInfNode->ucFaceAuthorization, pstUploadAIFacePicInfNodeBak->ucFaceAuthorization, sizeof(pstUploadAIFacePicInfNode->ucFaceAuthorization));
            }
        }
    }

    // 原始图像(背景图)直连分流的资源池访问地址
    if (pstUploadAIFacePicInfNodeBak->ucBgRequestURL)
    {
        if(MOS_STRCMP(pstUploadAIFacePicInfNode->ucBgRequestURL, pstUploadAIFacePicInfNodeBak->ucBgRequestURL) != 0)
        {
            MOS_STRLCPY(pstUploadAIFacePicInfNode->ucBgRequestURL,    pstUploadAIFacePicInfNodeBak->ucBgRequestURL,    sizeof(pstUploadAIFacePicInfNode->ucBgRequestURL));

            if (pstUploadAIFacePicInfNodeBak->ucBgRequestDate)
            {
                MOS_STRLCPY(pstUploadAIFacePicInfNode->ucBgRequestDate,   pstUploadAIFacePicInfNodeBak->ucBgRequestDate,   sizeof(pstUploadAIFacePicInfNode->ucBgRequestDate));
            }

            if (pstUploadAIFacePicInfNodeBak->ucBgAuthorization)
            {
                MOS_STRLCPY(pstUploadAIFacePicInfNode->ucBgAuthorization, pstUploadAIFacePicInfNodeBak->ucBgAuthorization, sizeof(pstUploadAIFacePicInfNode->ucBgAuthorization));
            }
        }
    }

    pstUploadAIFacePicInfNode->uiUploadFlag = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"SetAIFaceInfo NotifyType:%d BgRequestURL:%s FaceRequestURL:%s for NotificationID:%s", 
                                    pstUploadAIFacePicInfNode->uiNotifyType,   pstUploadAIFacePicInfNode->ucBgRequestURL, 
                                    pstUploadAIFacePicInfNode->ucBgRequestURL, pstUploadAIFacePicInfNode->ucNotificationID);
    return MOS_OK;
}

// 设置上传AIFace任务节点的上报信息
_INT Config_SetUploadAIFacePicTaskNodeReportInf(_INT iCamId, _UI uiReqId, _UI uiReportFlag, _ULLID lluReportTimeStamp)
{
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = Config_FindUploadAIFacePicTaskNode(iCamId, uiReqId);
    if(pstUploadAIFacePicInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
    pstUploadAIFacePicInfNode->uiReportFlag       = uiReportFlag;
    pstUploadAIFacePicInfNode->lluReportTimeStamp = lluReportTimeStamp;
    MOS_LOG_INF(AICFG_LOGSTR,"AIface Set ReqId:%u ReportFlag:%u TimeStamp:%llu",
                                pstUploadAIFacePicInfNode->uiReqId,
                                pstUploadAIFacePicInfNode->uiReportFlag,
                                pstUploadAIFacePicInfNode->lluReportTimeStamp);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));

    return MOS_OK;
}

// 从上传AIFace任务节点删除人脸 UPLOAD_AIFACE_PIC
_INT Config_DelUploadAIFacePicTaskNode(_INT iCamId, _UI uiReqId)
{
    _UI uiAIFaceUploadPicNodeCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadCmdPlatTaskInfList, pstUploadAIFacePicInfNode, stIterator)
    {
        if(pstUploadAIFacePicInfNode->uiUseFlag && pstUploadAIFacePicInfNode->uiReqId == uiReqId)
        {
            pstUploadAIFacePicInfNode->uiUseFlag        = 0;

            Config_GetUploadAIFacePicTaskNodeCount(0, &uiAIFaceUploadPicNodeCount);

            MOS_LOG_INF(AICFG_LOGSTR,"DEL AIface Pic NotificationID:%s, AIFaceUploadPicNodeCount:%u, ReqId:%u", 
                pstUploadAIFacePicInfNode->ucNotificationID, uiAIFaceUploadPicNodeCount, pstUploadAIFacePicInfNode->uiReqId);

            pstUploadAIFacePicInfNode->uiUploadFlag     = 0;
            pstUploadAIFacePicInfNode->lluReqTime       = 0;
            pstUploadAIFacePicInfNode->uiReqId          = 0;
            pstUploadAIFacePicInfNode->uiNotifyType     = 0;
            pstUploadAIFacePicInfNode->uiBgDataBufLen   = 0;
            pstUploadAIFacePicInfNode->uiFaceDataBufLen = 0;
            pstUploadAIFacePicInfNode->pucBgDataBuf     = MOS_NULL;
            pstUploadAIFacePicInfNode->pucFaceDataBuf   = MOS_NULL;
            pstUploadAIFacePicInfNode->stDxUpAIPicAlarmData.uiHttpCancelFlag = 0;
            MOS_MEMSET(pstUploadAIFacePicInfNode->ucDispositionID,     0x0, sizeof(pstUploadAIFacePicInfNode->ucDispositionID));
            MOS_MEMSET(pstUploadAIFacePicInfNode->ucNotificationID,    0x0, sizeof(pstUploadAIFacePicInfNode->ucNotificationID));
            MOS_MEMSET(pstUploadAIFacePicInfNode->ucBgRequestURL,      0x0, sizeof(pstUploadAIFacePicInfNode->ucBgRequestURL));
            MOS_MEMSET(pstUploadAIFacePicInfNode->ucBgRequestDate,     0x0, sizeof(pstUploadAIFacePicInfNode->ucBgRequestDate));
            MOS_MEMSET(pstUploadAIFacePicInfNode->ucBgAuthorization,   0x0, sizeof(pstUploadAIFacePicInfNode->ucBgAuthorization));
            MOS_MEMSET(pstUploadAIFacePicInfNode->ucFaceRequestURL,    0x0, sizeof(pstUploadAIFacePicInfNode->ucFaceRequestURL));
            MOS_MEMSET(pstUploadAIFacePicInfNode->ucFaceRequestDate,   0x0, sizeof(pstUploadAIFacePicInfNode->ucFaceRequestDate));
            MOS_MEMSET(pstUploadAIFacePicInfNode->ucFaceAuthorization, 0x0, sizeof(pstUploadAIFacePicInfNode->ucFaceAuthorization));
            break;
        }
    }

    return MOS_OK;
}

/*******************AI_FACE_PIC END***********************/

/*********************AI_ZIP START************************/
// 添加 UPLOAD_AI_ZIP_INF 链表节点
_INT Config_AddUploadAIZipTaskNode(_INT iCamId, _UI  uiReqId, _LLID lluHappenTime, _UC *pucZipFilePath)
{
    MOS_PARAM_NULL_RETERR(pucZipFilePath);

    _UI uiAIZipUploadPicNodeCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode     = MOS_NULL;
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfTmpNode  = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadZipTaskInfList, pstUploadAIZipInfNode, stIterator)
    {
        if(pstUploadAIZipInfNode->uiUseFlag == 1 && pstUploadAIZipInfNode->uiReqId == uiReqId)
        {
            break;
        }
        else if(pstUploadAIZipInfNode->uiUseFlag == 0)
        {
            pstUploadAIZipInfTmpNode = pstUploadAIZipInfNode;
        }
    }
    if(pstUploadAIZipInfNode == MOS_NULL)
    {
        if(pstUploadAIZipInfTmpNode == MOS_NULL)
        {
            pstUploadAIZipInfNode = (ST_CFG_UPLOAD_AI_ZIP_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_UPLOAD_AI_ZIP_INF_NODE));
            MOS_LIST_ADDTAIL(&Config_GetAIMng()->stUploadZipTaskInfList, pstUploadAIZipInfNode);
        }
        else
        {
            pstUploadAIZipInfNode = pstUploadAIZipInfTmpNode;
        }
    }

    pstUploadAIZipInfNode->uiReqId            = uiReqId;
    pstUploadAIZipInfNode->lluReqTime         = (_LLID)Mos_Time() * 1000;// 请求时间使用当前系统时间, 用于超时判断
    pstUploadAIZipInfNode->uiReportFlag       = 0;
    pstUploadAIZipInfNode->lluReportTimeStamp = pstUploadAIZipInfNode->lluReqTime;
    pstUploadAIZipInfNode->stDxUpAIZipEventData.uiHttpCancelFlag = 0;
    MOS_STRLCPY(pstUploadAIZipInfNode->ucZipFilePath, pucZipFilePath, sizeof(pstUploadAIZipInfNode->ucZipFilePath));

    pstUploadAIZipInfNode->uiUseFlag = 1;

    Config_GetUploadAIZipTaskNodeCount(0, &uiAIZipUploadPicNodeCount);

    MOS_LOG_INF(AICFG_LOGSTR,"ADD ZI_ZIP ReqId:%u ZipFilePath:%s ReqTime:%llu AIZipUploadPicNodeCount:%u", 
        uiReqId, pucZipFilePath, pstUploadAIZipInfNode->lluReqTime, uiAIZipUploadPicNodeCount);

    return MOS_OK;
}

// 查找上传AI_ZIP任务链表节点
ST_CFG_UPLOAD_AI_ZIP_INF_NODE *Config_FindUploadAIZipTaskNode(_INT iCamId, _UI uiReqId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadZipTaskInfList, pstUploadAIZipInfNode, stIterator)
    {
        if(pstUploadAIZipInfNode->uiUseFlag == 1 && pstUploadAIZipInfNode->uiReqId == uiReqId)
        {
            break;
        }
    }
    return pstUploadAIZipInfNode;
}

// 设置上传AI_ZIP任务节点的信息
_INT Config_SetUploadAIZipTaskNodeInfo(_INT iCamId, ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNodeBak)
{
    MOS_PARAM_NULL_RETERR(pstUploadAIZipInfNodeBak);

    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = Config_FindUploadAIZipTaskNode(iCamId, pstUploadAIZipInfNodeBak->uiReqId);
    if(pstUploadAIZipInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    // AI_ZIP直连分流的资源池访问地址
    if (pstUploadAIZipInfNodeBak->ucZipRequestURL)
    {
        if(MOS_STRCMP(pstUploadAIZipInfNode->ucZipRequestURL, pstUploadAIZipInfNodeBak->ucZipRequestURL) != 0)
        {
            MOS_STRLCPY(pstUploadAIZipInfNode->ucZipRequestURL,    pstUploadAIZipInfNodeBak->ucZipRequestURL,    sizeof(pstUploadAIZipInfNode->ucZipRequestURL));

            if (pstUploadAIZipInfNodeBak->ucZipRequestDate)
            {
                MOS_STRLCPY(pstUploadAIZipInfNode->ucZipRequestDate,   pstUploadAIZipInfNodeBak->ucZipRequestDate,   sizeof(pstUploadAIZipInfNode->ucZipRequestDate));
            }

            if (pstUploadAIZipInfNodeBak->ucZipAuthorization)
            {
                MOS_STRLCPY(pstUploadAIZipInfNode->ucZipAuthorization, pstUploadAIZipInfNodeBak->ucZipAuthorization, sizeof(pstUploadAIZipInfNode->ucZipAuthorization));    
            }
        }
    }

    pstUploadAIZipInfNode->uiUploadFlag = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"Set AI_ZIP Info ZipRequestURL:%s for ReqId:%u", pstUploadAIZipInfNode->ucZipRequestURL, pstUploadAIZipInfNode->uiReqId);
    return MOS_OK;
}

// 设置上传AI-ZIP任务节点的上报信息
_INT Config_SetUploadAIZipTaskNodeReportInf(_INT iCamId, _UI uiReqId, _UI uiReportFlag, _ULLID lluReportTimeStamp)
{
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = Config_FindUploadAIZipTaskNode(iCamId, uiReqId);
    if(pstUploadAIZipInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
    pstUploadAIZipInfNode->uiReportFlag       = uiReportFlag;
    pstUploadAIZipInfNode->lluReportTimeStamp = lluReportTimeStamp;
    MOS_LOG_INF(AICFG_LOGSTR,"AIZIP Set ReqId:%u ReportFlag:%u TimeStamp:%llu",
                                pstUploadAIZipInfNode->uiReqId,
                                pstUploadAIZipInfNode->uiReportFlag,
                                pstUploadAIZipInfNode->lluReportTimeStamp);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));

    return MOS_OK;
}

// 从上传AI_ZIP任务节点删除人脸 UPLOAD_AI_ZIP_INF
_INT Config_DelUploadAIZipTaskNode(_INT iCamId, _UI uiReqId)
{
    _UI uiAIZipUploadPicNodeCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadZipTaskInfList, pstUploadAIZipInfNode, stIterator)
    {
        if(pstUploadAIZipInfNode->uiUseFlag && pstUploadAIZipInfNode->uiReqId == uiReqId)
        {
            pstUploadAIZipInfNode->uiUseFlag    = 0;

            Config_GetUploadAIZipTaskNodeCount(0, &uiAIZipUploadPicNodeCount);

            MOS_LOG_INF(AICFG_LOGSTR,"DEL ZI_ZIP ReqId:%u AIZipUploadPicNodeCount:%u", uiReqId, uiAIZipUploadPicNodeCount);
            
            pstUploadAIZipInfNode->uiUploadFlag = 0;
            pstUploadAIZipInfNode->uiReqId      = 0;
            pstUploadAIZipInfNode->lluReqTime   = 0;
            pstUploadAIZipInfNode->stDxUpAIZipEventData.uiHttpCancelFlag = 0;
            MOS_MEMSET(pstUploadAIZipInfNode->ucZipFilePath,      0x0, sizeof(pstUploadAIZipInfNode->ucZipFilePath));
            MOS_MEMSET(pstUploadAIZipInfNode->ucZipRequestURL,    0x0, sizeof(pstUploadAIZipInfNode->ucZipRequestURL));
            MOS_MEMSET(pstUploadAIZipInfNode->ucZipRequestDate,   0x0, sizeof(pstUploadAIZipInfNode->ucZipRequestDate));
            MOS_MEMSET(pstUploadAIZipInfNode->ucZipAuthorization, 0x0, sizeof(pstUploadAIZipInfNode->ucZipAuthorization));

            break;
        }
    }
    return MOS_OK;
}

// 获取上传AI_ZIP任务已用节点数 UPLOAD_AI_ZIP_INF
_INT Config_GetUploadAIZipTaskNodeCount(_INT iCamId, _UI *puiAIZipUploadPicNodeCount)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = MOS_NULL;

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadZipTaskInfList, pstUploadAIZipInfNode, stIterator)
    {
        if(pstUploadAIZipInfNode->uiUseFlag == 1)
        {
            (*puiAIZipUploadPicNodeCount)++;
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));

    return MOS_OK;
}
/*********************AI_ZIP END************************/

/****************AIAlARM_UPLOAD_PV START****************/
// 添加 UPLOAD_AIALARM_PV_INF 链表节点
_INT Config_AddUploadAIAlarmPVTaskNode(_INT iCamId, _UI uiReqId, ST_ZJ_IOT_INF* pstIoTInf, ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf)
{
    MOS_PARAM_NULL_RETERR(pstAIAlarmUploadInf);

    _UI uiUploadAIAlarmPVNodeCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode    = MOS_NULL;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfTmpNode = MOS_NULL;
    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfNode, stIterator)
    {
        if(pstUplaodAIAlarmPVInfNode->uiUseFlag == 1 && pstUplaodAIAlarmPVInfNode->uiReqId == uiReqId)
        {
            break;
        }
        else if(pstUplaodAIAlarmPVInfNode->uiUseFlag == 0)
        {
            pstUplaodAIAlarmPVInfTmpNode = pstUplaodAIAlarmPVInfNode;
        }
    }
    if(pstUplaodAIAlarmPVInfNode == MOS_NULL)
    {
        if(pstUplaodAIAlarmPVInfTmpNode == MOS_NULL)
        {
            pstUplaodAIAlarmPVInfNode = (ST_CFG_UPLOAD_AIALARM_PV_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_UPLOAD_AIALARM_PV_INF_NODE));
            MOS_LIST_ADDTAIL(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfNode);
        }
        else
        {
            pstUplaodAIAlarmPVInfNode = pstUplaodAIAlarmPVInfTmpNode;
        }
    }

    pstUplaodAIAlarmPVInfNode->uiReqId = uiReqId;
    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType    = pstIoTInf->uiIoTType;
    pstUplaodAIAlarmPVInfNode->stAIIoTInf.lluIoTId     = pstIoTInf->lluIoTId;
    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId = pstIoTInf->uiIoTEventId;
    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.lluTimeStamp = pstAIAlarmUploadInf->lluTimeStamp;
    MOS_STRLCPY(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, pstAIAlarmUploadInf->ucPicPath, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath));
    MOS_STRLCPY(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath, pstAIAlarmUploadInf->ucVideoPath, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath));

    // ReportMsgTimeStamp赋值厂商告警事件时间, 避免出现上传图片/视频超时误判
    pstUplaodAIAlarmPVInfNode->lluReportTimeStamp = pstAIAlarmUploadInf->lluTimeStamp;
    pstUplaodAIAlarmPVInfNode->uiReportFlag = 0;
    pstUplaodAIAlarmPVInfNode->uiUseFlag = 1;

    Config_GetUploadAIAlarmPVTaskNodeCount(0, &uiUploadAIAlarmPVNodeCount);

    MOS_LOG_INF(AICFG_LOGSTR,"ADD AIAlARM_UPLOAD_PV[%u %llu %u] ReqId:%u lluTimeStamp:%llu PicPath:%s VideoPath:%s UploadAIAlarmPVNodeCount:%u",
                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType, pstUplaodAIAlarmPVInfNode->stAIIoTInf.lluIoTId,
                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId, uiReqId, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.lluTimeStamp,
                pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath,
                uiUploadAIAlarmPVNodeCount);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    return MOS_OK;
}

// 查找上传AI告警图片和视频任务链表节点
ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *Config_FindUploadAIAlarmPVTaskNode(_INT iCamId, _UI uiReqId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfNode, stIterator)
    {
        if(pstUplaodAIAlarmPVInfNode->uiUseFlag == 1 && pstUplaodAIAlarmPVInfNode->uiReqId == uiReqId)
        {
            break;
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));

    return pstUplaodAIAlarmPVInfNode;
}

// 查找上传AI告警图片和视频任务链表节点 (文件路径)
ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *Config_FindUploadAIAlarmPVTaskNodeByPath(_INT iCamId, _UC *pucPath)
{
    MOS_PARAM_NULL_RETNULL(pucPath);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfNode, stIterator)
    {
        if(pstUplaodAIAlarmPVInfNode->uiUseFlag == 1 && 
           ((MOS_STRNCMP(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,   pucPath, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath  )) == 0) ||
            (MOS_STRNCMP(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath, pucPath, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath)) == 0) ))
        {
            break;
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));

    return pstUplaodAIAlarmPVInfNode;
}

// 设置 UPLOAD_AIALARM_PV_INF 链表节点的网络信息
_INT Config_SetUploadAIAlarmPVTaskNodeNetInfo(_INT iCamId, _UI uiReqId, ST_CFG_AIALARM_PV_NETINF* pstAIAlarmPVNetInf)
{
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNode(iCamId, uiReqId);
    if(pstUplaodAIAlarmPVInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    if (pstAIAlarmPVNetInf->ucPicRequestUrl)
    {
        MOS_STRLCPY(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicRequestUrl, pstAIAlarmPVNetInf->ucPicRequestUrl, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicRequestUrl));
        if (pstAIAlarmPVNetInf->ucPicRequestDate)
        {
            MOS_STRLCPY(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicRequestDate, pstAIAlarmPVNetInf->ucPicRequestDate, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicRequestDate));
        }
        if (pstAIAlarmPVNetInf->ucPicAuthorization)
        {
            MOS_STRLCPY(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicAuthorization, pstAIAlarmPVNetInf->ucPicAuthorization, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicAuthorization));
        }
    }

    if (pstAIAlarmPVNetInf->ucVideoRequestUrl)
    {
        MOS_STRLCPY(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoRequestUrl, pstAIAlarmPVNetInf->ucVideoRequestUrl, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoRequestUrl));
        if (pstAIAlarmPVNetInf->ucPicRequestDate)
        {
            MOS_STRLCPY(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoRequestDate, pstAIAlarmPVNetInf->ucVideoRequestDate, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoRequestDate));
        }
        if (pstAIAlarmPVNetInf->ucPicAuthorization)
        {
            MOS_STRLCPY(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoAuthorization, pstAIAlarmPVNetInf->ucVideoAuthorization, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoAuthorization));
        }
    }
    MOS_LOG_INF(AICFG_LOGSTR,"AIAlarmPV[%u %u] Set NetInfo ReqId:%u PicUrl:%s VideoUrl:%s",
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType,
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId,
                                uiReqId, pstAIAlarmPVNetInf->ucPicRequestUrl, 
                                pstAIAlarmPVNetInf->ucVideoRequestUrl);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    return MOS_OK;
}

// 设置 UploadAIAlarmPVTask 节点 ReportMsg上报信息
_INT Config_SetUploadAIAlarmPVTaskNodeReportInf(_INT iCamId, _UI uiReqId, _UI uiReportFlag, _ULLID lluReportTimeStamp)
{
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNode(iCamId, uiReqId);
    if(pstUplaodAIAlarmPVInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    pstUplaodAIAlarmPVInfNode->uiReportFlag       = uiReportFlag;
    pstUplaodAIAlarmPVInfNode->lluReportTimeStamp = lluReportTimeStamp;
    MOS_LOG_INF(AICFG_LOGSTR,"AIAlarmPV[%u %u] Set ReqId:%u ReportFlag:%u TimeStamp:%llu",
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType,
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId, 
                                pstUplaodAIAlarmPVInfNode->uiReqId,
                                pstUplaodAIAlarmPVInfNode->uiReportFlag,
                                pstUplaodAIAlarmPVInfNode->lluReportTimeStamp);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    return MOS_OK;
}

// 设置 UploadAIAlarmPVTask 节点 PicUploadFlag 上报AI告警图片的状态
_INT Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(_INT iCamId, _UI uiReqId, _UI uiPicUploadFlag)
{
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNode(iCamId, uiReqId);
    if(pstUplaodAIAlarmPVInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    pstUplaodAIAlarmPVInfNode->uiPicUploadFlag = uiPicUploadFlag;
    MOS_LOG_INF(AICFG_LOGSTR,"AIAlarmPV[%u %u] Set ReqId:%u PicUploadFlag:%u",
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType,
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId, 
                                pstUplaodAIAlarmPVInfNode->uiReqId,
                                pstUplaodAIAlarmPVInfNode->uiPicUploadFlag);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    return MOS_OK;
}

// 设置UploadAIAlarmPV节点 VideoUploadFlag 上报AI告警视频的状态
_INT Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(_INT iCamId, _UI uiReqId, _UI uiVideoUploadFlag)
{
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNode(iCamId, uiReqId);
    if(pstUplaodAIAlarmPVInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    pstUplaodAIAlarmPVInfNode->uiVideoUploadFlag = uiVideoUploadFlag;
    MOS_LOG_INF(AICFG_LOGSTR,"AIAlarmPV[%u %u] Set ReqId:%u VideoUploadFlag:%u",
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType,
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId, 
                                pstUplaodAIAlarmPVInfNode->uiReqId, 
                                pstUplaodAIAlarmPVInfNode->uiVideoUploadFlag);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));

    return MOS_OK;
}

// 设置 UploadAIAlarmPVTask 节点 PicUploadFlag 上报AI告警图片的状态 (路径方式)
_INT Config_SetUploadAIAlarmPVTaskNodePicUploadFlagByPath(_INT iCamId, _UC* pucPath, _UI uiPicUploadFlag)
{
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNodeByPath(iCamId, pucPath);
    if(pstUplaodAIAlarmPVInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    pstUplaodAIAlarmPVInfNode->uiPicUploadFlag = uiPicUploadFlag;
    MOS_LOG_INF(AICFG_LOGSTR,"AIAlarmPV[%u %u] Set ReqId:%u ByPath:%s PicUploadFlag:%u",
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType,
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId, 
                                pstUplaodAIAlarmPVInfNode->uiReqId, 
                                pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, 
                                pstUplaodAIAlarmPVInfNode->uiPicUploadFlag);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    return MOS_OK;
}

// 设置UploadAIAlarmPV节点 VideoUploadFlag 上报AI告警视频的状态 (路径方式)
_INT Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlagByPath(_INT iCamId, _UC* pucPath, _UI uiVideoUploadFlag)
{
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNodeByPath(iCamId, pucPath);
    if(pstUplaodAIAlarmPVInfNode == MOS_NULL)
    {
        return MOS_ERR;
    }

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    pstUplaodAIAlarmPVInfNode->uiVideoUploadFlag = uiVideoUploadFlag;
    MOS_LOG_INF(AICFG_LOGSTR,"AIAlarmPV[%u %u] Set ReqId:%u ByPath:%s VideoUploadFlag:%u",
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType,
                                pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId, 
                                pstUplaodAIAlarmPVInfNode->uiReqId, 
                                pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath, 
                                pstUplaodAIAlarmPVInfNode->uiVideoUploadFlag);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));

    return MOS_OK;
}

// 删除 UPLOAD_AIALARM_PV_INF 链表节点
_INT Config_DelUploadAIAlarmPVTaskNode(_INT iCamId, _UI uiReqId)
{
    _UI uiUploadAIAlarmPVNodeCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;
    
    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfNode, stIterator)
    {
        if(pstUplaodAIAlarmPVInfNode->uiUseFlag && pstUplaodAIAlarmPVInfNode->uiReqId == uiReqId)
        {
            pstUplaodAIAlarmPVInfNode->uiUseFlag         = 0;

            Config_GetUploadAIAlarmPVTaskNodeCount(0, &uiUploadAIAlarmPVNodeCount);

            MOS_LOG_INF(AICFG_LOGSTR,"DEL AIAlarmPV[%u %u] ReqId:%u, UploadAIAlarmPVNodeCount:%u", 
                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType,
                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId, uiReqId, uiUploadAIAlarmPVNodeCount);
            
            pstUplaodAIAlarmPVInfNode->uiReqId           = 0;
            pstUplaodAIAlarmPVInfNode->uiReportFlag      = 0;
            pstUplaodAIAlarmPVInfNode->uiPicUploadFlag   = 0;
            pstUplaodAIAlarmPVInfNode->uiVideoUploadFlag = 0;
            pstUplaodAIAlarmPVInfNode->lluReportTimeStamp = 0;
            MOS_MEMSET(&pstUplaodAIAlarmPVInfNode->stAIIoTInf,         0x0, sizeof(pstUplaodAIAlarmPVInfNode->stAIIoTInf));
            MOS_MEMSET(&pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf,  0x0, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf));
            MOS_MEMSET(&pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf, 0x0, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf));
            break;
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    return MOS_OK;   
}

// 获取 UPLOAD_AIALARM_PV_INF 链表节点 使用数
_INT Config_GetUploadAIAlarmPVTaskNodeCount(_INT iCamId, _UI *puiUploadAIAlarmPVNodeCount)
{
    MOS_PARAM_INVALID_RET(puiUploadAIAlarmPVNodeCount, MOS_NULL, MOS_ERR);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;

    *puiUploadAIAlarmPVNodeCount = 0;

    Mos_MutexLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfNode, stIterator)
    {
        if(pstUplaodAIAlarmPVInfNode->uiUseFlag == 1)
        {
            (*puiUploadAIAlarmPVNodeCount)++;
            // MOS_LOG_INF(AICFG_LOGSTR,"AIAlarmPV Count:%u", *puiUploadAIAlarmPVNodeCount);
        }
    }
    Mos_MutexUnLock(&(Config_GetAIMng()->hUplaodAIAlarmPVMutex));
    return MOS_OK;
}
/****************AIAlARM_UPLOAD_PV END******************/

// 通用AI能力   0.不支持；1.支持
_INT Config_SetCommonAiAbility(_UC *pucName, _INT iAbility)
{
    if(AI_UpdateCommonAiAbility(pucName, iAbility) == MOS_TRUE)
    {
        Config_GetItemSign()->ucSaveAiFlag = 1;
    }
    return MOS_OK;
}

// AI 设备支持的最大布控底图数目
_INT Config_SetAiMaxPicNum(_INT iAiMaxPicNum)
{
    // MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai Config_GetAIMng()->iAiPicMaxNum %d iAiMaxPicNum %d", Config_GetAIMng()->iAiPicMaxNum, iAiMaxPicNum);

    if(Config_GetAIMng()->iAiPicMaxNum == iAiMaxPicNum)
    {
        return MOS_OK;
    }
    Config_GetAIMng()->iAiPicMaxNum = iAiMaxPicNum;
    Config_GetItemSign()->ucSaveAiFlag = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set iAiMaxPicNum %d", iAiMaxPicNum);
    return MOS_OK;
}

// AI 设备当前布控地图数目
_INT Config_SetAiCurPicNum(_INT iAiCurPicNum)
{
    // MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai Config_GetAIMng()->iAiPicCnt %d iAiCurPicNum %d", Config_GetAIMng()->iAiPicCnt, iAiCurPicNum);

    if(Config_GetAIMng()->iAiPicCnt == iAiCurPicNum)
    {
        return MOS_OK;
    }
    Config_GetAIMng()->iAiPicCnt = iAiCurPicNum;
    Config_GetItemSign()->ucSaveAiFlag  = 1;
    Config_GetItemSign()->ucCfgAiUpdate = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set iAiCurPicNum %d", iAiCurPicNum);
    return MOS_OK;
}

// 客流统计开关
_INT Config_SetHumanCountOpenFlag(_INT iHumanCountFlag)
{
    if(Config_GetAIMng()->iHumanCountFlag == iHumanCountFlag)
    {
        return MOS_OK;
    }
    Config_GetAIMng()->iHumanCountFlag = iHumanCountFlag;
    Config_GetItemSign()->ucSaveAiFlag  = 1;
    Config_GetItemSign()->ucCfgAiUpdate = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set iHumanCountFlag %d", iHumanCountFlag);
    return MOS_OK;
}

// 客流统计检测间隔 iHumanCountInterval:单位分钟
_INT Config_SetHumanCountInterval(_INT iHumanCountInterval)
{
    if(Config_GetAIMng()->iHumanCountInterval == iHumanCountInterval)
    {
        return MOS_OK;
    }
    Config_GetAIMng()->iHumanCountInterval = iHumanCountInterval;
    Config_GetItemSign()->ucSaveAiFlag  = 1;
    Config_GetItemSign()->ucCfgAiUpdate = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set iHumanCountInterval %d", iHumanCountInterval);
    return MOS_OK;
}

// 客流统计区域
_INT Config_SetHumanCountRegions(ST_CFG_HUMAN_COUNT_REGION *pstHumanCountRegion)
{
    if(!pstHumanCountRegion)
    {
        return MOS_OK;
    }

    _INT i = 0;
    for(i=0; i<4; i++)
    {
        Config_GetAIMng()->stHumanCountRegion[0].iX[i] = pstHumanCountRegion->iX[i];
        Config_GetAIMng()->stHumanCountRegion[0].iY[i] = pstHumanCountRegion->iY[i];
    }
    Config_GetItemSign()->ucSaveAiFlag  = 1;
    Config_GetItemSign()->ucCfgAiUpdate = 1;
    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set stHumanCountRegion");
    return MOS_OK;
}

// 设置人脸图片缓存路径
_INT Config_SetFaceFileCachePath(unsigned char *pucFaceCachePath)
{
    Mos_DirMake(pucFaceCachePath, MOS_DIR_MAKE_FLAG);
    MOS_STRLCPY(Config_Task_GetMng()->aucFaceCachePath, pucFaceCachePath, sizeof(Config_Task_GetMng()->aucFaceCachePath));
	

    MOS_LOG_INF(AICFG_LOGSTR,"cfg_ai set pucFaceCachePath %s", pucFaceCachePath);
    return MOS_OK;
}

// 创建AI能力对象
static _VPTR Config_BuildAIAbilityObject(JSON_HANDLE hRoot)
{
    if (hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(AICFG_LOGSTR, "hRoot is invalid");
        return MOS_NULL;
    }
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_COMMON_AI_ABILITY_INF_NODE *pstAiAbilityInfNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stCommonAiAblitityList, pstAiAbilityInfNode, stIterator)
    {
        Adpt_Json_AddItemToObject(hRoot,pstAiAbilityInfNode->aucName, Adpt_Json_CreateStrWithNum(pstAiAbilityInfNode->uiAbility));
    }

    return MOS_NULL;
}

/*************************************************************************
创建 AI配置Json
*************************************************************************/
_VPTR Config_BuildAIObject(_UI uiCfgType, EN_BUILD_DOWNTASK_FLAG enBuildDownTaskFlag)
{
    _INT i = 0;
    JSON_HANDLE hLabelArry              = MOS_NULL;
    JSON_HANDLE hLabelArryObject        = MOS_NULL;
    JSON_HANDLE hDownloadTaskArry       = MOS_NULL;
    JSON_HANDLE hDownloadTaskArryObject = MOS_NULL;

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AiPicMaxNum",Adpt_Json_CreateStrWithNum(Config_GetAIMng()->iAiPicMaxNum));
        Config_BuildAIAbilityObject(hRoot);
    }

    if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"AiPicCnt",Adpt_Json_CreateStrWithNum(Config_GetAIMng()->iAiPicCnt));

        hLabelArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"Labels",hLabelArry);
        
        ST_MOS_LIST_ITERATOR    stIterator;
        ST_CFG_LABELS_INF_NODE  *pstLabelInfNode   = MOS_NULL;
        
        FOR_EACHDATA_INLIST(&Config_GetAIMng()->stLabelsInfList,pstLabelInfNode,stIterator)
        {
            JSON_HANDLE hPictureArry       = MOS_NULL;
            JSON_HANDLE hPictureObject     = MOS_NULL;
            ST_MOS_LIST_ITERATOR stIterator1;
            ST_CFG_PICTURE_INF_NODE *pstPictureInfNode = MOS_NULL;

            if(pstLabelInfNode->uiUseFlag == 0)
            {
                continue;
            }
            hLabelArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hLabelArry,hLabelArryObject);

            Adpt_Json_AddItemToObject(hLabelArryObject,(_UC*)"LabelID",Adpt_Json_CreateString(pstLabelInfNode->ucLabelID));
            Adpt_Json_AddItemToObject(hLabelArryObject,(_UC*)"LabelName",Adpt_Json_CreateString(pstLabelInfNode->ucLabelName));
            Adpt_Json_AddItemToObject(hLabelArryObject,(_UC*)"PicType",Adpt_Json_CreateStrWithNum(pstLabelInfNode->uiPicType));
            Adpt_Json_AddItemToObject(hLabelArryObject,(_UC*)"WBList",Adpt_Json_CreateStrWithNum(pstLabelInfNode->uiWBList));
            Adpt_Json_AddItemToObject(hLabelArryObject,(_UC*)"UserId",Adpt_Json_CreateString(pstLabelInfNode->ucUserID));

            hPictureArry = Adpt_Json_CreateArray();
            Adpt_Json_AddItemToObject(hLabelArryObject,(_UC*)"Pictures",hPictureArry);
            FOR_EACHDATA_INLIST(&pstLabelInfNode->stPictureInfList, pstPictureInfNode, stIterator1)
            {
                if(pstPictureInfNode->uiUseFlag == 0)
                {
                    // MOS_PRINTF("build ai Labels Pictures json continue \r\n");
                    continue;
                }
                hPictureObject = Adpt_Json_CreateObject();
                Adpt_Json_AddItemToArray(hPictureArry,hPictureObject);
                Adpt_Json_AddItemToObject(hPictureObject,(_UC*)"DispositionID",Adpt_Json_CreateString(pstPictureInfNode->ucDispositionID));
                Adpt_Json_AddItemToObject(hPictureObject,(_UC*)"Desc",Adpt_Json_CreateString(pstPictureInfNode->ucDesc));  
            }
        }

        Adpt_Json_AddItemToObject(hRoot,(_UC*)"HumanCountFlag",Adpt_Json_CreateStrWithNum(Config_GetAIMng()->iHumanCountFlag));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"HumanCountInterval",Adpt_Json_CreateStrWithNum(Config_GetAIMng()->iHumanCountInterval));
        JSON_HANDLE hHumanCountRegionArry       = MOS_NULL;
        JSON_HANDLE hHumanCountRegionArryObject = MOS_NULL;
        hHumanCountRegionArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"HumanCountRegions",hHumanCountRegionArry);
        for (i = 0; i < 4; i++)
        {
            hHumanCountRegionArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hHumanCountRegionArry,hHumanCountRegionArryObject);
            Adpt_Json_AddItemToObject(hHumanCountRegionArryObject,(_UC*)"x",Adpt_Json_CreateNumber(Config_GetAIMng()->stHumanCountRegion[0].iX[i]));
            Adpt_Json_AddItemToObject(hHumanCountRegionArryObject,(_UC*)"y",Adpt_Json_CreateNumber(Config_GetAIMng()->stHumanCountRegion[0].iY[i]));
        }

        // 待下载图片列表（待下载图片列表不需要上传平台，人脸批量下发时此列表较大）
        if (EN_AI_BUILD_DOWNTASK_ON == enBuildDownTaskFlag)
        {
            hDownloadTaskArry = Adpt_Json_CreateArray();
            Adpt_Json_AddItemToObject(hRoot,(_UC*)"DownLoadTask",hDownloadTaskArry);

            ST_MOS_LIST_ITERATOR    stIterator2;
            ST_CFG_DOWNLOAD_TASK_INF_NODE  *pstDownloadTaskInfNode   = MOS_NULL;

            FOR_EACHDATA_INLIST(&Config_GetAIMng()->stDownloadTaskInfList, pstDownloadTaskInfNode, stIterator2)
            {
                JSON_HANDLE hDownloadPictureArry       = MOS_NULL;
                JSON_HANDLE hDownloadPictureObject     = MOS_NULL;
                ST_MOS_LIST_ITERATOR stIterator3;
                ST_CFG_DOWNLOAD_PIC_INF_NODE *pstDownloadPicInfNode = MOS_NULL;

                if(pstDownloadTaskInfNode->uiUseFlag == 0)
                {
                    continue;
                }
                hDownloadTaskArryObject = Adpt_Json_CreateObject();
                Adpt_Json_AddItemToArray(hDownloadTaskArry, hDownloadTaskArryObject);

                Adpt_Json_AddItemToObject(hDownloadTaskArryObject,(_UC*)"TaskID",Adpt_Json_CreateString(pstDownloadTaskInfNode->ucTaskID));
                Adpt_Json_AddItemToObject(hDownloadTaskArryObject,(_UC*)"UserID",Adpt_Json_CreateString(pstDownloadTaskInfNode->ucUserID));
                Adpt_Json_AddItemToObject(hDownloadTaskArryObject,(_UC*)"PicType",Adpt_Json_CreateStrWithNum(pstDownloadTaskInfNode->uiPicType));

                hDownloadPictureArry = Adpt_Json_CreateArray();
                Adpt_Json_AddItemToObject(hDownloadTaskArryObject,(_UC*)"Pictures",hDownloadPictureArry);
                FOR_EACHDATA_INLIST(&pstDownloadTaskInfNode->stDownloadPicInfList, pstDownloadPicInfNode, stIterator3)
                {
                    if(pstDownloadPicInfNode->uiUseFlag == 0)
                    {
                        // MOS_PRINTF("build ai DownLoadTask Pictures json continue \r\n");
                        continue;
                    }
                    hDownloadPictureObject = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToArray(hDownloadPictureArry,hDownloadPictureObject);
                    Adpt_Json_AddItemToObject(hDownloadPictureObject,(_UC*)"WBList",Adpt_Json_CreateStrWithNum(pstDownloadPicInfNode->uiWBList));
                    Adpt_Json_AddItemToObject(hDownloadPictureObject,(_UC*)"DispositionID",Adpt_Json_CreateString(pstDownloadPicInfNode->ucDispositionID));
                    Adpt_Json_AddItemToObject(hDownloadPictureObject,(_UC*)"Desc",Adpt_Json_CreateString(pstDownloadPicInfNode->ucDesc));
                    Adpt_Json_AddItemToObject(hDownloadPictureObject,(_UC*)"PicUrl",Adpt_Json_CreateString(pstDownloadPicInfNode->ucPicUrl));
                }
            }
        }
    }
    return hRoot;
}

_UC *Config_BuildAIJson(_UI uiCfgType)
{
    _UC *pstrTmp      = MOS_NULL;
    JSON_HANDLE hRoot = Config_BuildAIObject(uiCfgType, EN_AI_BUILD_DOWNTASK_ON);

    pstrTmp = Adpt_Json_Print(hRoot);
    
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(AICFG_LOGSTR,"build AI info %s", pstrTmp);

    // 批量下发人脸时打印过于频繁
    // MOS_PRINTF("build AI info %s \r\n", pstrTmp);
    return pstrTmp;
}

// 读取AI配置的字段
_INT Config_ParseAIJson(_UC *pStrJson,_UI uiCfgType)
{
    MOS_PARAM_NULL_RETERR(pStrJson);
    // MOS_LOG_INF(AICFG_LOGSTR,"AIJson pStrJson: %s", pStrJson);

    _INT i = 0;
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if((uiCfgType & EN_CFG_TYPE_ABILITY) > 0)
    {
        // AI端侧识最大存储底图数目
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AiPicMaxNum"),&Config_GetAIMng()->iAiPicMaxNum);
        // MOS_PRINTF("%s:%d: AiPicMaxNum:%d \r\n", __FUNCTION__, __LINE__, Config_GetAIMng()->iAiPicMaxNum);
        
        // 轮训json的AI能力值，更新到List
        JSON_HANDLE hChild = Adpt_Json_GetChild(hRoot);
        while (hChild != NULL)
        {
            _INT iAiAbility = 0;
            _UC *pucAidName = MOS_NULL;            
            Adpt_Json_GetName(hChild, &pucAidName);
            if (pucAidName && MOS_STRSTRTAIL(pucAidName, "Ability") != 0)
            {
                Adpt_Json_GetIntegerEx(hChild, &iAiAbility);
                AI_UpdateCommonAiAbility(pucAidName, iAiAbility);
            }
            hChild = Adpt_Json_GetNext(hChild);
        }
    }
    if((uiCfgType & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        // 当前已经存储的AI端侧识别底库图片数目
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"AiPicCnt"),&Config_GetAIMng()->iAiPicCnt);
        // MOS_PRINTF("%s:%d: AiPicCnt:%d \r\n", __FUNCTION__, __LINE__, Config_GetAIMng()->iAiPicCnt);

        // Labels
        _INT iLabelArrySize          = 0;
        JSON_HANDLE hLabelArry       = MOS_NULL;
        JSON_HANDLE hLabelObject     = MOS_NULL;
        ST_CFG_LABELS_INF_NODE  *pstLabelInfNode   = MOS_NULL;
        
        hLabelArry     = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Labels");
        iLabelArrySize = Adpt_Json_GetArraySize(hLabelArry);
        for(i = 0; i < iLabelArrySize; i++)
        {
            _INT j,iPictureArrySize        = 0;
            JSON_HANDLE hPictureArry       = MOS_NULL;
            JSON_HANDLE hPictureObject     = MOS_NULL;
            ST_CFG_PICTURE_INF_NODE *pstPictureInfNode = MOS_NULL;
            
            hLabelObject = Adpt_Json_GetArrayItem(hLabelArry,i);
            
            pstLabelInfNode = (ST_CFG_LABELS_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_LABELS_INF_NODE));
            if(pstLabelInfNode == MOS_NULL)
            {
                continue;
            }

            // 人脸图片父集ID
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hLabelObject, (_UC*)"LabelID"),&pStrTmp);
            MOS_STRLCPY(pstLabelInfNode->ucLabelID, pStrTmp, sizeof(pstLabelInfNode->ucLabelID));
            // MOS_PRINTF("%s:%d: Labels LabelID:%s \r\n", __FUNCTION__, __LINE__, pstLabelInfNode->ucLabelID);

            // 人脸图片父集名称
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hLabelObject, (_UC*)"LabelName"), &pStrTmp);
            MOS_STRLCPY(pstLabelInfNode->ucLabelName, pStrTmp, sizeof(pstLabelInfNode->ucLabelName));
            // MOS_PRINTF("%s:%d: Labels LabelName:%s \r\n", __FUNCTION__, __LINE__, pstLabelInfNode->ucLabelName);

            // 人脸图片父集类型
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hLabelObject, (_UC*)"PicType"), &pstLabelInfNode->uiPicType);
            // MOS_PRINTF("%s:%d: Labels PicType:%d \r\n", __FUNCTION__, __LINE__, pstLabelInfNode->uiPicType);

            // 人脸图片父集所属名单 0.都不属于；1.黑名单；2.白名单
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hLabelObject, (_UC*)"WBList"), &pstLabelInfNode->uiWBList);
            // MOS_PRINTF("%s:%d: Labels WBList:%d \r\n", __FUNCTION__, __LINE__, pstLabelInfNode->uiWBList);

            // 这组图片所属用户
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hLabelObject, (_UC*)"UserId"), &pStrTmp);
            MOS_STRLCPY(pstLabelInfNode->ucUserID, pStrTmp, sizeof(pstLabelInfNode->ucUserID));
            // MOS_PRINTF("%s:%d: Labels UserId:%s \r\n", __FUNCTION__, __LINE__, pstLabelInfNode->ucUserID);

            // Pictures
            hPictureArry = Adpt_Json_GetObjectItem(hLabelObject,(_UC*)"Pictures");
            iPictureArrySize = Adpt_Json_GetArraySize(hPictureArry);
            for(j = 0; j < iPictureArrySize; j++)
            {
                hPictureObject = Adpt_Json_GetArrayItem(hPictureArry,j);
                pstPictureInfNode = (ST_CFG_PICTURE_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_PICTURE_INF_NODE));
                if(pstPictureInfNode == MOS_NULL)
                {
                    continue;
                }
                pstPictureInfNode->uiUseFlag = 1; 
                // 人脸图片父集ID
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPictureObject, (_UC*)"DispositionID"),&pStrTmp);
                MOS_STRLCPY(pstPictureInfNode->ucDispositionID, pStrTmp, sizeof(pstPictureInfNode->ucDispositionID));
                // MOS_PRINTF("%s:%d: Labels DispositionID:%s \r\n", __FUNCTION__, __LINE__, pstPictureInfNode->ucDispositionID);

                // 人脸图片父集名称
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPictureObject, (_UC*)"Desc"), &pStrTmp);
                MOS_STRLCPY(pstPictureInfNode->ucDesc, pStrTmp, sizeof(pstPictureInfNode->ucDesc));
                // MOS_PRINTF("%s:%d: Labels Desc:%s \r\n", __FUNCTION__, __LINE__, pstPictureInfNode->ucDesc);

                MOS_LIST_ADDTAIL(&pstLabelInfNode->stPictureInfList, pstPictureInfNode);
            }

            pstLabelInfNode->uiUseFlag = 1;
            MOS_LIST_ADDTAIL(&Config_GetAIMng()->stLabelsInfList,pstLabelInfNode);
        }

        // 客流统计开关 0.关，1.开
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"HumanCountFlag"),&Config_GetAIMng()->iHumanCountFlag);
        // MOS_PRINTF("%s:%d: HumanCountFlag:%d \r\n", __FUNCTION__, __LINE__, Config_GetAIMng()->iHumanCountFlag);

        // 客流统计事件检测间隔 分钟，默认为1分钟
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"HumanCountInterval"),&Config_GetAIMng()->iHumanCountInterval);
        // MOS_PRINTF("%s:%d: HumanCountInterval:%d \r\n", __FUNCTION__, __LINE__, Config_GetAIMng()->iHumanCountInterval);

        _INT iHumanCountRegionArrySize;
        JSON_HANDLE hHumanCountRegionArry,hHumanCountRegionArryObject;
        // 客流统计区域坐标，只支持1个区域和4个点
        hHumanCountRegionArry = Adpt_Json_GetObjectItem(hRoot,(_UC*)"HumanCountRegions");
        iHumanCountRegionArrySize = Adpt_Json_GetArraySize(hHumanCountRegionArry);

        for(i = 0; i < iHumanCountRegionArrySize; i++)
        {
            if (i > 3)
            {
                break;
            }
            hHumanCountRegionArryObject = Adpt_Json_GetArrayItem(hHumanCountRegionArry,i);
            // 坐标X
            Adpt_Json_GetDouble_Ex(Adpt_Json_GetObjectItem(hHumanCountRegionArryObject, (_UC*)"x"),&Config_GetAIMng()->stHumanCountRegion->iX[i]);
            // MOS_PRINTF("%s:%d: x:%d \r\n", __FUNCTION__, __LINE__, Config_GetAIMng()->stHumanCountRegion->iX[i]);
            
            // 坐标Y
            Adpt_Json_GetDouble_Ex(Adpt_Json_GetObjectItem(hHumanCountRegionArryObject, (_UC*)"y"),&Config_GetAIMng()->stHumanCountRegion->iY[i]);
            // MOS_PRINTF("%s:%d: y:%d \r\n", __FUNCTION__, __LINE__, Config_GetAIMng()->stHumanCountRegion->iY[i]);
        }
#if 0
        // DownloadTask
        _INT iDownloadTaskArrySize          = 0;
        JSON_HANDLE hDownloadTaskArry       = MOS_NULL;
        JSON_HANDLE hDownloadTaskObject     = MOS_NULL;
        ST_CFG_DOWNLOAD_TASK_INF_NODE  *pstDownloadTaskInfNode = MOS_NULL;
        
        hDownloadTaskArry     = Adpt_Json_GetObjectItem(hRoot,(_UC*)"DownLoadTask");
        iDownloadTaskArrySize = Adpt_Json_GetArraySize(hDownloadTaskArry);
        for(i = 0; i < iDownloadTaskArrySize; i++)
        {
            _INT iDownloadPictureArrySize          = 0;
            JSON_HANDLE hDownloadPictureArry       = MOS_NULL;
            JSON_HANDLE hDownloadPictureObject     = MOS_NULL;
            ST_CFG_DOWNLOAD_PIC_INF_NODE *pstDownloadPicInfNode = MOS_NULL;
            
            hDownloadTaskObject = Adpt_Json_GetArrayItem(hDownloadTaskArry,i);
            
            pstDownloadTaskInfNode = (ST_CFG_DOWNLOAD_TASK_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_DOWNLOAD_TASK_INF_NODE));
            if(pstDownloadTaskInfNode == MOS_NULL)
            {
                continue;
            }

            // 人脸图片父集ID
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDownloadTaskObject, (_UC*)"TaskID"),&pStrTmp);
            MOS_STRLCPY(pstDownloadTaskInfNode->ucTaskID, pStrTmp, sizeof(pstDownloadTaskInfNode->ucTaskID));
            // MOS_PRINTF("%s:%d: DownLoadTask TaskID:%s \r\n", __FUNCTION__, __LINE__, pstDownloadTaskInfNode->ucTaskID);

            // 人脸图片父集名称
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDownloadTaskObject, (_UC*)"UserID"), &pStrTmp);
            MOS_STRLCPY(pstDownloadTaskInfNode->ucUserID, pStrTmp, sizeof(pstDownloadTaskInfNode->ucUserID));
            // MOS_PRINTF("%s:%d: DownLoadTask UserID:%s \r\n", __FUNCTION__, __LINE__, pstDownloadTaskInfNode->ucUserID);

            // 人脸图片父集类型
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDownloadTaskObject, (_UC*)"PicType"), &pstDownloadTaskInfNode->uiPicType);
            // MOS_PRINTF("%s:%d: DownLoadTask PicType:%d \r\n", __FUNCTION__, __LINE__, pstDownloadTaskInfNode->uiPicType);

            // Pictures
            hDownloadPictureArry = Adpt_Json_GetObjectItem(hDownloadTaskObject,(_UC*)"Pictures");
            iDownloadPictureArrySize = Adpt_Json_GetArraySize(hDownloadPictureArry);
            for(j = 0; j < iDownloadPictureArrySize; j++)
            {
                hDownloadPictureObject = Adpt_Json_GetArrayItem(hDownloadPictureArry,j);
                pstDownloadPicInfNode = (ST_CFG_DOWNLOAD_PIC_INF_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_DOWNLOAD_PIC_INF_NODE));
                if(pstDownloadPicInfNode == MOS_NULL)
                {
                    continue;
                }
                pstDownloadPicInfNode->uiUseFlag = 1; 

                // 所属名单 0.都不属于；1.黑名单；2.白名单
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDownloadPictureObject, (_UC*)"WBList"), &pstDownloadPicInfNode->uiWBList);
                // MOS_PRINTF("%s:%d: DownLoadTask WBList:%d \r\n", __FUNCTION__, __LINE__, pstDownloadPicInfNode->uiWBList);

                // 人脸图片父集ID
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDownloadPictureObject, (_UC*)"DispositionID"),&pStrTmp);
                MOS_STRLCPY(pstDownloadPicInfNode->ucDispositionID, pStrTmp, sizeof(pstDownloadPicInfNode->ucDispositionID));
                // MOS_PRINTF("%s:%d: DownLoadTask DispositionID:%s \r\n", __FUNCTION__, __LINE__, pstDownloadPicInfNode->ucDispositionID);

                // 人脸图片父集名称
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDownloadPictureObject, (_UC*)"Desc"), &pStrTmp);
                MOS_STRLCPY(pstDownloadPicInfNode->ucDesc, pStrTmp, sizeof(pstDownloadPicInfNode->ucDesc));
                // MOS_PRINTF("%s:%d: DownLoadTask Desc:%s \r\n", __FUNCTION__, __LINE__, pstDownloadPicInfNode->ucDesc);

                // 人脸图片下载地址
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDownloadPictureObject, (_UC*)"PicUrl"), &pStrTmp);
                MOS_STRLCPY(pstDownloadPicInfNode->ucPicUrl, pStrTmp, sizeof(pstDownloadPicInfNode->ucPicUrl));
                // MOS_PRINTF("%s:%d: DownLoadTask PicUrl:%s \r\n", __FUNCTION__, __LINE__, pstDownloadPicInfNode->ucPicUrl);

                MOS_LIST_ADDTAIL(&pstDownloadTaskInfNode->stDownloadPicInfList, pstDownloadPicInfNode);
            }
            pstDownloadTaskInfNode->uiUseFlag = 1;
            MOS_LIST_ADDTAIL(&Config_GetAIMng()->stDownloadTaskInfList,pstDownloadTaskInfNode);
        }
#endif
    }

    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

/****************************************************************
向平台汇报库下载状态回复 0x4423
*****************************************************************/
static _INT AI_RecvPubUpGradeDownPicStatusRsp(_UI uiReqId,_VPTR hJsonRoot)
{
    if(Config_GetAIMng()->uiOgctId == uiReqId)
    {
        Config_GetAIMng()->uiOgctId = 0;
    }

    MOS_LOG_INF(AICFG_LOGSTR,"ogct %u recv Publish down AIPIC Status rsp",uiReqId);
    return MOS_OK;
}

// 向平台汇报库下载状态 0x4422
_INT AI_PubUpgradeDownPicStatus(ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskInfNode, ST_CFG_DOWNLOAD_PIC_INF_NODE  *pstDownloadPicInfNode,_INT istatus)
{
    _UC *pStrTmp                = MOS_NULL;
    _UC aucMethod[16]           = {0};
    JSON_HANDLE hBody           = MOS_NULL;
    JSON_HANDLE hRoot           = MOS_NULL;
    JSON_HANDLE hPictureArry    = MOS_NULL;
    JSON_HANDLE hPictureObject  = MOS_NULL;

    if(Config_GetAIMng()->uiOgctId != 0)
    {
        MsgMng_CancleReqMsg(Config_GetAIMng()->uiOgctId);
    }
    Config_GetAIMng()->uiOgctId = Mos_GetSessionId();

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%0X%0X",EN_OGCT_METHOD_DEVAI,EN_OGCT_DEVAI_UPLOADFACEORLICENSELIB_REQ);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(Config_GetAIMng()->uiOgctId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY", hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TaskID", Adpt_Json_CreateString(pstDownloadTaskInfNode->ucTaskID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"PicType", Adpt_Json_CreateStrWithNum(pstDownloadTaskInfNode->uiPicType));

    hPictureArry = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Pictures",hPictureArry);
    hPictureObject = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToArray(hPictureArry,hPictureObject);
    Adpt_Json_AddItemToObject(hPictureObject,(_UC*)"DispositionID",Adpt_Json_CreateString(pstDownloadPicInfNode->ucDispositionID));
    Adpt_Json_AddItemToObject(hPictureObject,(_UC*)"Status",Adpt_Json_CreateStrWithNum(istatus));  

    pStrTmp = Adpt_Json_Print(hRoot);

    MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID,Config_GetAIMng()->uiOgctId,
        EN_OGCT_METHOD_DEVAI,EN_OGCT_DEVAI_UPLOADFACEORLICENSELIB_REQ,
        pStrTmp,MOS_STRLEN(pStrTmp),AI_RecvPubUpGradeDownPicStatusRsp);

    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pStrTmp);

    MOS_LOG_INF(AICFG_LOGSTR,"ogct %u Publish downAIPIC status %d", Config_GetAIMng()->uiOgctId, istatus);
    return MOS_OK;
}

// 存储下载的AIPic数据为jpg图片
_INT AI_SaveAIPicData(_UC *pucPicID, _UC *pucPicData, _UI uiPicDataLen)
{
    _INT iRet = 0;
    if (MOS_NULL == g_phAIPic_fd)
    {
        MOS_VSNPRINTF(g_ucAIPicFile, MOS_DIR_NAME_LEN, "%s/%s.jpg", Config_Task_GetMng()->aucFaceCachePath, pucPicID);
        MOS_PRINTF("%s:%d g_ucAIPicFile:%s \r\n", __FUNCTION__, __LINE__, g_ucAIPicFile);
        g_phAIPic_fd = Mos_FileOpen(g_ucAIPicFile, MOS_FILE_O_RDWR|MOS_FILE_O_CREAT|MOS_FILE_O_BIN);
        if (MOS_NULL == g_phAIPic_fd)
        {
            MOS_LOG_ERR(AICFG_LOGSTR,"Mos_FileOpen failed g_phAIPic_fd is null, errno = %u", errno);
            return MOS_ERR;
        } 
    }

    iRet = Mos_FileWrite(g_phAIPic_fd, pucPicData, uiPicDataLen);
    if (iRet < 0)
    {
        MOS_LOG_ERR(AICFG_LOGSTR,"Mos_FileWrite error");
        return MOS_ERR;
    }

    return MOS_OK;
} 

// 关闭下载的AIpic图片
_INT AI_CloseAIPicFile()
{
    if (g_phAIPic_fd)
    {
        Mos_FileClose(g_phAIPic_fd);
        g_phAIPic_fd = MOS_NULL;
    }
    return MOS_OK;
}

static _VOID AI_DownloadHttpRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    /*无作用，但必须注册 http模块要求*/
}


static _VOID AI_DownloadHttpFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId)
{
    if (uiErrCode != 302)
    {
        _UC aucStrErrLog[128] = {0};
        ST_CFG_DOWNLOAD_PIC_INF_NODE *pstDownloadPicInfNode = (ST_CFG_DOWNLOAD_PIC_INF_NODE *)vpUserPtr;
        if (pstDownloadPicInfNode)
        {
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "https ResultCode is %d not 302, Redirect error! DispositionID:%s", uiErrCode, pstDownloadPicInfNode->ucDispositionID);
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->ucPicUrl, -1, 
                                    EN_AI_RT_DOWNPIC_URL_RT_NOT_302_REDIRECT_ERR, aucStrErrLog, MOS_NULL, 1);
        }
        AI_CloseAIPicFile();
    }
}

static _VOID AI_DownloadHttpRecvHeader(_VPTR vpUserPtr, _UI uiReqId, ST_HTTP_PRASE_HEAD stHttpParseHead)
{
    ST_CFG_DOWNLOAD_PIC_INF_NODE *pstDownloadPicInfNode = (ST_CFG_DOWNLOAD_PIC_INF_NODE *)vpUserPtr;
    if (pstDownloadPicInfNode)
    {
        pstDownloadPicInfNode->uiHttpCode = stHttpParseHead.iResultCode;
        if (stHttpParseHead.iResultCode == 302)
        {
            MOS_LOG_INF(AICFG_LOGSTR, "aucRedirectUrl:%s \r\n", stHttpParseHead.ucRedirectUrl);
            MOS_MEMSET(pstDownloadPicInfNode->aucRedirectUrl, 0, sizeof(pstDownloadPicInfNode->aucRedirectUrl));
            MOS_MEMCPY(pstDownloadPicInfNode->aucRedirectUrl, stHttpParseHead.ucRedirectUrl, sizeof(pstDownloadPicInfNode->aucRedirectUrl));
        }
        else
        {
            _UC aucStrErrLog[256] = {0};
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "https ResultCode is %d not 302, Redirect error! DispositionID:%s", stHttpParseHead.iResultCode, pstDownloadPicInfNode->ucDispositionID);
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->ucPicUrl, -1,
                                EN_AI_RT_DOWNPIC_URL_RT_NOT_302_REDIRECT_ERR, aucStrErrLog, MOS_NULL, 1);
        }
    }
    else
    {
        _UC aucStrErrLog[256] = {0};
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "AIPIC https recv Header error");
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->ucPicUrl, -1, 
                            EN_AI_RT_DOWNPIC_URL_READ_HEAD_ERR, aucStrErrLog, MOS_NULL, 1);
    }
}

static _VOID AI_DownloadRedirectHttpRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    ST_CFG_DOWNLOAD_PIC_INF_NODE *pstDownloadPicInfNode = (ST_CFG_DOWNLOAD_PIC_INF_NODE *)vpUserPtr;
    if (pstDownloadPicInfNode && pstDownloadPicInfNode->uiHttpCode == 200)
    {
        _INT iRet = MOS_ERR;
        _UC aucStrErrLog[128] = {0};
        iRet = AI_SaveAIPicData(pstDownloadPicInfNode->ucDispositionID, pucData, uiLen);
        if (iRet == MOS_ERR)
        {
            Http_Httpclient_CancelAsyncRequestEx(uiReqId);
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "SaveAIPicData error  DispositionID:%s", pstDownloadPicInfNode->ucDispositionID);   
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->ucPicUrl, -1, 
                                    EN_AI_RT_DOWNPIC_SAVE_PIC_DATA_ERR, aucStrErrLog, MOS_NULL, 1);
        }
    }
}

static _VOID AI_DownloadRedirectHttpFinished(_VPTR vpUserPtr, _UI uiReqId)
{
    MOS_LOG_INF(AICFG_LOGSTR,"Down AIPIC %d OK: ", uiReqId);
    AI_CloseAIPicFile();
}

static _VOID AI_DownloadRedirectHttpFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId)
{
   MOS_LOG_INF(AICFG_LOGSTR,"Down AIPIC %d FAIL: ", uiReqId);
    AI_CloseAIPicFile();
}

static _VOID AI_DownloadRedirectHttpRecvHeader(_VPTR vpUserPtr, _UI uiReqId, ST_HTTP_PRASE_HEAD stHttpParseHead)
{
    ST_CFG_DOWNLOAD_PIC_INF_NODE *pstDownloadPicInfNode = (ST_CFG_DOWNLOAD_PIC_INF_NODE *)vpUserPtr;
    if (pstDownloadPicInfNode)
    {
        pstDownloadPicInfNode->uiHttpCode = stHttpParseHead.iResultCode;
    }
    if (stHttpParseHead.iResultCode != 200)
    {
        _UC aucStrErrLog[256] = {0};
        ST_CFG_DOWNLOAD_PIC_INF_NODE *pstDownloadPicInfNode = (ST_CFG_DOWNLOAD_PIC_INF_NODE *)vpUserPtr;
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "https ResultCode is %d not 200, error! ucDispositionID:%s",stHttpParseHead.iResultCode, pstDownloadPicInfNode->ucDispositionID);
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_AI_RT_DOWNPIC_REDIRECT_URL_RT_NOT_200_ERR, aucStrErrLog, MOS_NULL, 1);
    }
}

// 下载AI图片
_INT AI_DownLoadAiPictureProc(ST_CFG_DOWNLOAD_PIC_INF_NODE  *pstDownloadPicInfNode)
{   
    if (pstDownloadPicInfNode == MOS_NULL)
    {
        MOS_LOG_ERR(AICFG_LOGSTR, "pstDownloadPicInfNode is NULL \r\n");
        return MOS_ERR;
    }

    if(MOS_STRLEN(pstDownloadPicInfNode->ucPicUrl) == 0)
    {
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->ucPicUrl, -1, 
                                EN_AI_RT_DOWNPIC_URL_NULL_ERR, (_UC*)"Download AIPic Url is Null", MOS_NULL, 1);
        return MOS_ERR; 
    }

    if (MOS_STRSTR(pstDownloadPicInfNode->ucPicUrl, "https") == MOS_NULL && MOS_STRSTR(pstDownloadPicInfNode->ucPicUrl, "http") == MOS_NULL)
    {
        _UC aucStrErrLog[256] = {0};
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Download AIPic Url is Unrecognized %s", pstDownloadPicInfNode->ucPicUrl);
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->ucPicUrl, -1, 
                                    EN_AI_RT_DOWNPIC_URL_RECOGNIZE_ERR, aucStrErrLog, MOS_NULL, 1);
        return MOS_ERR;
    }

    _INT iRet               = 0;
    _INT iSslFlag           = 1;
    _UC aucHostAddr[128]    = {0};
    _UC aucStrErrLog[128]   = {0};
    _UC aucDownloadUrl[512] = {0};
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    
    if (Http_Parse_Url(pstDownloadPicInfNode->ucPicUrl, aucHostAddr, aucDownloadUrl, &iSslFlag) == MOS_ERR)
    {
        MOS_LOG_ERR(AICFG_LOGSTR, "Https_Parse_Url failed! \r\n");
        return MOS_ERR;
    }

    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag        = iSslFlag;
    stHttpInfoNode.pfuncRecv        = AI_DownloadHttpRecvFunc;
    stHttpInfoNode.pfuncRecvHeader  = AI_DownloadHttpRecvHeader;
    stHttpInfoNode.pfuncFailed      = AI_DownloadHttpFailed;
    stHttpInfoNode.vpUserPtr        = pstDownloadPicInfNode;
    stHttpInfoNode.iTimeOut         = 20;
    iRet = Http_SendSyncRequest(&stHttpInfoNode, aucHostAddr, aucDownloadUrl, EN_HTTP_METHOD_GET, pstDownloadPicInfNode->uiReqId);
    if (iRet == EN_HTTP_RET_CONNECT_ERR)
    {
        MOS_MEMSET(aucStrErrLog, 0, sizeof(aucStrErrLog));
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Connect URL Failed, Stop DownLoad AIPIC");
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->ucPicUrl, -1, 
                                EN_AI_RT_DOWNPIC_URL_CONNET_ERR, aucStrErrLog, MOS_NULL, 1);
        return MOS_ERR;
    }
    else if(iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        MOS_MEMSET(aucStrErrLog, 0, sizeof(aucStrErrLog));
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Download AIPic get Host(%s) AddrInfo error ", aucHostAddr);
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->ucPicUrl, -1, 
                                EN_AI_RT_DOWNPIC_URL_GET_HOST_ADDRINFO_ERR, aucStrErrLog, MOS_NULL, 1);
        return MOS_ERR;
    }

    /*重定向地址*/
    if (iRet == MOS_OK && pstDownloadPicInfNode->uiHttpCode == 302)
    {
        pstDownloadPicInfNode->uiHttpCode = 0;
        Mos_Sleep(50); /**/
        MOS_MEMSET(aucHostAddr, 0, sizeof(aucHostAddr));
        MOS_MEMSET(aucDownloadUrl, 0, sizeof(aucDownloadUrl));
        if (Http_Parse_Url(pstDownloadPicInfNode->aucRedirectUrl, aucHostAddr, aucDownloadUrl, &iSslFlag) == MOS_ERR)
        {
            MOS_PRINTF("%s:%d: Https_Parse_Url failed! \r\n", __FUNCTION__, __LINE__);
            return MOS_ERR;
        }
        stHttpInfoNode.uiSSLFlag        = iSslFlag;
        stHttpInfoNode.pfuncRecv        = AI_DownloadRedirectHttpRecvFunc;
        stHttpInfoNode.pfuncFinished    = AI_DownloadRedirectHttpFinished;
        stHttpInfoNode.pfuncFailed      = AI_DownloadRedirectHttpFailed;
        stHttpInfoNode.pfuncRecvHeader  = AI_DownloadRedirectHttpRecvHeader;
        stHttpInfoNode.vpUserPtr        = pstDownloadPicInfNode;
        stHttpInfoNode.iTimeOut         = 40;
        iRet = Http_SendSyncRequest(&stHttpInfoNode, aucHostAddr, aucDownloadUrl, EN_HTTP_METHOD_GET, pstDownloadPicInfNode->uiReqId); 
        if (iRet == EN_HTTP_RET_CONNECT_ERR)
        {
            pstDownloadPicInfNode->uiHttpCode = 0;
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "AIPIC Connect Redirect URL Failed, Stop DownLoad AIPIC");
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfNode->aucRedirectUrl, -1, 
                                    EN_AI_RT_DOWNPIC_REDIRECT_URL_CONNET_ERR, aucStrErrLog, MOS_NULL, 1);
            return MOS_ERR;
        }

        pstDownloadPicInfNode->uiHttpCode = 0;
        Mos_Sleep(10); /**/
    }
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

// 下载AI图片线程
static _INT AI_DownAIPic_Loop(_VPTR pParam)
{
    _INT iRet                                 = 0;
    _INT iErrTime                             = 0;
    _UC  aucStrErrLog[128]                    = {0};
    EN_AICFG_LABEL enLabelType                = EN_BLACK_LIST;
    static _INT iIsFindDownLoadPicInfNodeFlag = 0;

    MOS_PRINTF("%s:%d  start\r\n", __FUNCTION__, __LINE__);
    while(Config_GetAIMng()->ucInitFlag)
    {
        ST_MOS_LIST_ITERATOR stIterator;
        ST_CFG_DOWNLOAD_PIC_INF_NODE  *pstDownloadPicInfNode     = MOS_NULL;
        ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskInfNode    = MOS_NULL;
        ST_CFG_DOWNLOAD_PIC_INF_NODE  *pstDownloadPicInfTmpNode  = MOS_NULL;
        ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskInfTmpNode = MOS_NULL;

        // 查询下载列表
        Mos_MutexLock(&(Config_GetAIMng()->hDownLoadMutex));
        FOR_EACHDATA_INLIST(&Config_GetAIMng()->stDownloadTaskInfList, pstDownloadTaskInfNode, stIterator)
        {
            if(pstDownloadTaskInfNode->uiUseFlag == 1)
            {
                pstDownloadTaskInfTmpNode = pstDownloadTaskInfNode;
                FOR_EACHDATA_INLIST(&pstDownloadTaskInfNode->stDownloadPicInfList, pstDownloadPicInfNode, stIterator)
                {
                    if(pstDownloadPicInfNode->uiUseFlag == 1)
                    {
                        iIsFindDownLoadPicInfNodeFlag = 1;
                        pstDownloadPicInfTmpNode = pstDownloadPicInfNode;
                        MOS_PRINTF("%s:%d find DownLoadPicInfNode DispositionID:%s \r\n", __FUNCTION__, __LINE__, pstDownloadPicInfTmpNode->ucDispositionID);
                        break;
                    }
                }

                if (iIsFindDownLoadPicInfNodeFlag == 1)
                {
                    break;
                }
                else
                {
                    _UI uiPictureToDownloadNodeCount = 0;
                    Config_GetPictureToDownloadTaskNodeCount(0, pstDownloadTaskInfTmpNode->ucTaskID, &uiPictureToDownloadNodeCount);
                    // 当前链表下载任务完成 删除任务节点
                    if (uiPictureToDownloadNodeCount == 0)
                    {
                        MOS_PRINTF("%s:%d Go to Del Down Task %s \r\n", __FUNCTION__, __LINE__, pstDownloadTaskInfTmpNode->ucTaskID);
                        // 删除DownloadTask链表节点
                        Config_DeleteAIDownloadTaskNode(0, pstDownloadTaskInfTmpNode->ucTaskID);
                    }
                }
            }
        }
        Mos_MutexUnLock(&(Config_GetAIMng()->hDownLoadMutex));

        if (iIsFindDownLoadPicInfNodeFlag == 1)
        {
            // 白名单
            if (EN_WHITE_LIST == pstDownloadPicInfTmpNode->uiWBList)
            {
                enLabelType = EN_AICFG_LABEL_FACE_WHITELIST;
            }
            else
            {
                // 历史原因平台0和1都是黑名单，现在厂家只有1是黑名单，所以这里强置为1黑名单
                pstDownloadPicInfTmpNode->uiWBList = EN_BLACK_LIST;
                enLabelType = EN_AICFG_LABEL_FACE_BLACKLIST;
            }

            while(Config_GetAIMng()->ucInitFlag)
            {
                // AI 开始下载AI图片
                iRet = AI_DownLoadAiPictureProc(pstDownloadPicInfTmpNode);
                if (MOS_OK == iRet)
                {
                    MOS_PRINTF("%s:%d  AI_DownLoadAiPictureProc ucDispositionID:%s AIPicFile:%s TaskId:%s OK \r\n", __FUNCTION__, __LINE__,
                                    pstDownloadPicInfTmpNode->ucDispositionID, g_ucAIPicFile, pstDownloadTaskInfTmpNode->ucTaskID);

                    // 通知厂商读取AI图片数据并提取特征值 ADD by LWJ  
                    if (ZJ_GetFuncTable()->pFunAddSingleAiPic)
                    {
                        iRet = ZJ_GetFuncTable()->pFunAddSingleAiPic(g_stAICfgLabel[enLabelType].pucLabelID, pstDownloadPicInfTmpNode->ucDispositionID, g_ucAIPicFile);

                        // 向平台汇报库下载状态
                        if (MOS_OK == iRet)
                        {
                            // 往Label添加 布控Pic
                            Config_AddPictureToLabel(0, g_stAICfgLabel[enLabelType].pucLabelID, pstDownloadPicInfTmpNode->ucDesc, pstDownloadPicInfTmpNode->ucDispositionID);

                            // 向平台汇报库下载状态 0x4422
                            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunAddSingleAiPic ID:%s OK", pstDownloadPicInfTmpNode->ucDispositionID);
                            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfTmpNode->ucPicUrl, -1, 
                                                    EN_AI_RT_DOWNPIC_FUNCADDSINGLEAIPIC_DEV_RT_OK, aucStrErrLog, MOS_NULL, 1);

                            AI_PubUpgradeDownPicStatus(pstDownloadTaskInfTmpNode, pstDownloadPicInfTmpNode, 1);
                        }
                        else
                        {
                            // 向平台汇报库下载状态 0x4422
                            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunAddSingleAiPic ID:%s return err", pstDownloadPicInfTmpNode->ucDispositionID);
                            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pstDownloadPicInfTmpNode->ucPicUrl, -1, 
                                                    EN_AI_RT_DOWNPIC_FUNCADDSINGLEAIPIC_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);

                            AI_PubUpgradeDownPicStatus(pstDownloadTaskInfTmpNode, pstDownloadPicInfTmpNode, 0);
                            // 删除LAbel中指定的Pic
                            Config_DelPictureToLabel(0, g_stAICfgLabel[enLabelType].pucLabelID, pstDownloadPicInfTmpNode->ucDispositionID);
                        }
                    }
                    else
                    {
                        MOS_LOG_ERR(AICFG_LOGSTR,"pFunAddSingleAiPic is NULL!");
                        // 向平台汇报库下载状态 0x4422
                        AI_PubUpgradeDownPicStatus(pstDownloadTaskInfTmpNode, pstDownloadPicInfTmpNode, 0);
                        // 删除LAbel中指定的Pic
                        Config_DelPictureToLabel(0, g_stAICfgLabel[enLabelType].pucLabelID, pstDownloadPicInfTmpNode->ucDispositionID);
                    }

                    if (Mos_FileIsExist(g_ucAIPicFile))
                    {
                        // 删除图片
                        MOS_PRINTF("%s:%d  Mos_FileRmv g_ucAIPicFile:%s \r\n", __FUNCTION__, __LINE__, g_ucAIPicFile);
                        Mos_FileRmv(g_ucAIPicFile);
                    }
                    else
                    {
                        MOS_PRINTF("%s:%d  g_ucAIPicFile:%s no Exist \r\n", __FUNCTION__, __LINE__, g_ucAIPicFile);
                    }
                    iErrTime = 0;
                    break;
                }
                else
                {
                    iErrTime++;
                    if (3 == iErrTime)
                    {
                        MOS_LOG_ERR(AICFG_LOGSTR,"3 == iErrTime  AI_DownLoadAiPictureProc failed");
                        // 向平台汇报库下载状态 0x4422
                        AI_PubUpgradeDownPicStatus(pstDownloadTaskInfTmpNode, pstDownloadPicInfTmpNode, 0);
                        // 删除LAbel中指定的Pic
                        Config_DelPictureToLabel(0, g_stAICfgLabel[enLabelType].pucLabelID, pstDownloadPicInfTmpNode->ucDispositionID);
                        if (Mos_FileIsExist(g_ucAIPicFile))
                        {
                            // 删除图片
                            Mos_FileRmv(g_ucAIPicFile);
                        }
                        iErrTime = 0;
                        break;
                    }
                }
                Mos_Sleep(1000); // 1s
            }

            // 从下载任务链表删除Pic
            Mos_MutexLock(&(Config_GetAIMng()->hDownLoadMutex));
            Config_DelPictureToDownloadTask(0, pstDownloadTaskInfTmpNode->ucTaskID, pstDownloadPicInfTmpNode->ucDispositionID);
            Mos_MutexUnLock(&(Config_GetAIMng()->hDownLoadMutex));
            iIsFindDownLoadPicInfNodeFlag = 0;
        }
        Mos_Sleep(20);
    }

    // 删除线程
    /*
    if(MOS_OK != Mos_ThreadDelete(Config_GetAIMng()->hDownLoadThread))
    {
        MOS_LOG_ERR(AICFG_LOGSTR,"Mos_ThreadDelete failed !!");
        return MOS_ERR;
    }

    Config_GetAIMng()->hDownLoadThread = MOS_NULL;
    */
    MOS_LOG_INF(AICFG_LOGSTR,"AI_DownAIPic_Loop Exit");

    return MOS_OK;
}

// AI布控底库图片下载
_VOID AI_ProcDownAIPicture()
{
    // 未有下载AI底库图片任务
    if(MOS_LIST_GETCOUNT(&Config_GetAIMng()->stDownloadTaskInfList) == 0)
    {
        return;
    }

    _INT iDownloadTaskUsedCount  = 0;
    _INT iDownloadTaskTotalCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_DOWNLOAD_TASK_INF_NODE *pstDownloadTaskInfNode    = MOS_NULL;

    iDownloadTaskTotalCount = MOS_LIST_GETCOUNT(&Config_GetAIMng()->stDownloadTaskInfList);
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stDownloadTaskInfList, pstDownloadTaskInfNode, stIterator)
    {
        if (pstDownloadTaskInfNode->uiUseFlag == 0)
        {
            iDownloadTaskUsedCount++;
        }
    }
    if (iDownloadTaskTotalCount == iDownloadTaskUsedCount)
    {
        return;
    }
    
    if (Config_GetAIMng()->hDownLoadThread == MOS_NULL)
    {
        // 开始下载AI图片
        #ifdef MOS_LINUX_RTOS
            _UI uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
        #else
            _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
        #endif
            if(Mos_ThreadCreate((_UC*)"cfg_ai_downAIpic",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                            AI_DownAIPic_Loop,MOS_NULL,MOS_NULL, &Config_GetAIMng()->hDownLoadThread) == MOS_ERR)
            {
                Config_GetAIMng()->hDownLoadThread = MOS_NULL;
                CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_AI_RT_DOWNPIC_CREATE_THREAD_ERR, (_UC*)"Create AI_DownAIPic_Loop failed", MOS_NULL, 1);
                return;
            }
    }
    return;
}


static _VOID AI_UploadHttpRecv(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    /*因服务器不会下发,conten_len为0，此回调不会触发*/
    ST_URL_CONN_SOCKET *pstConnSocket = (ST_URL_CONN_SOCKET *)vpUserPtr;
    if (pstConnSocket){
        if (pstConnSocket->pucHttpResponse == MOS_NULL)
        {
            pstConnSocket->pucHttpResponse = (_UC*)MOS_MALLOC(1024);
            MOS_MEMSET(pstConnSocket->pucHttpResponse, 0, 1024);
        }
        if (pstConnSocket->uiHttpResponseIndex + uiLen < 1024 && pstConnSocket->pucHttpResponse)
        {
            MOS_MEMCPY(pstConnSocket->pucHttpResponse + pstConnSocket->uiHttpResponseIndex, pucData, uiLen);
            pstConnSocket->uiHttpResponseIndex += uiLen;
        }
    }
}

static _VOID AI_UploadHttpFinished(_VPTR vpUserPtr, _UI uiReqId)
{
    ST_URL_CONN_SOCKET *pstConnSocket = (ST_URL_CONN_SOCKET *)vpUserPtr;
    if (pstConnSocket){
        MOS_LOG_INF(AICFG_LOGSTR, "UploadAIPic reqid = %d Success", uiReqId);
        if (pstConnSocket->pucHttpResponse)
        {
            pstConnSocket->pucHttpResponse[pstConnSocket->uiHttpResponseIndex] = 0;
            MOS_LOG_INF(AICFG_LOGSTR,"recv %s",pstConnSocket->pucHttpResponse);
            /*释放http接收缓存*/
            MOS_FREE(pstConnSocket->pucHttpResponse);
            pstConnSocket->uiHttpResponseIndex = 0;
        }
    }
    else{
        MOS_LOG_ERR(AICFG_LOGSTR, "reqid = %d pstConnSocket is NULL", uiReqId);
    }
}

static _VOID AI_UploadHttpFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId)
{
    ST_URL_CONN_SOCKET *pstConnSocket = (ST_URL_CONN_SOCKET *)vpUserPtr;
    if (pstConnSocket){
        MOS_LOG_ERR(AICFG_LOGSTR, "UploadAIPic reqid = %d Fail", uiReqId);
        if (pstConnSocket->pucHttpResponse)
        {
            pstConnSocket->pucHttpResponse[pstConnSocket->uiHttpResponseIndex] = 0;
            MOS_LOG_INF(AICFG_LOGSTR,"recv %s",pstConnSocket->pucHttpResponse);
            /*释放http接收缓存*/
            MOS_FREE(pstConnSocket->pucHttpResponse);
            pstConnSocket->uiHttpResponseIndex = 0;
        }
    }
    else{
        MOS_LOG_ERR(AICFG_LOGSTR, "reqid = %d pstConnSocket is NULL", uiReqId);
    }
}

static _INT AI_UploadHttpGetData(_VPTR vpUserPtr, _UC* pucData, _UI uiMaxDataLen, _UI uiReqId)
{
    ST_URL_CONN_SOCKET *pstConnSocket = (ST_URL_CONN_SOCKET *)vpUserPtr;
    
    if (pstConnSocket)
    {
        _INT iUploadLen = ((pstConnSocket->uiAiPicDataLength - pstConnSocket->uiAiPicUploadIndex) > uiMaxDataLen) ? uiMaxDataLen\
                            : (pstConnSocket->uiAiPicDataLength - pstConnSocket->uiAiPicUploadIndex);
        if (iUploadLen > 0)
        {
            MOS_MEMCPY(pucData, pstConnSocket->pucAIPicData + pstConnSocket->uiAiPicUploadIndex, iUploadLen);
            pstConnSocket->uiAiPicUploadIndex += iUploadLen;
            return iUploadLen;
        }
        pstConnSocket->uiAiPicUploadIndex = 0;
        return 0;
    }
    else
    {
        MOS_LOG_ERR(AICFG_LOGSTR, "reqid = %d pstConnSocket is NULL", uiReqId);
        return MOS_ERR;
    }
}

/*线程安全*/
_INT AI_StartUploadRequest(ST_URL_CONN_SOCKET *pstConnSocket, _UC *pucAIPicDate, _INT uiAIPicDateLen, _INT *piIsEndFlag, _UI uiReqId)
{
    MOS_PARAM_NULL_RETERR(pucAIPicDate);
    MOS_PARAM_NULL_RETERR(pstConnSocket);
    _INT iRet     = MOS_ERR;
    _INT iSslFlag = 1;
    _UC aucHostAddr[128]     = {0};
    _UC aucUploadUrl[512]    = {0};
    _UC aucExpandHeader[256] = {0};

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    if (Http_Parse_Url(pstConnSocket->aucRequestURL, aucHostAddr, aucUploadUrl, &iSslFlag) == MOS_ERR)
    {
        *piIsEndFlag = MOS_TRUE;
        MOS_LOG_ERR(AICFG_LOGSTR, "Https_Parse_Url failed! \r\n");
        return MOS_ERR;
    }
    pstConnSocket->pucAIPicData = pucAIPicDate;
    pstConnSocket->uiAiPicDataLength = uiAIPicDateLen;
    MOS_VSNPRINTF(aucExpandHeader, sizeof(aucExpandHeader), "Date: %s\r\nAuthorization: %s\r\nExpect: 100-continue\r\n", pstConnSocket->aucRequestDate, pstConnSocket->aucAuthorization);
    
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag        = pstConnSocket->uiHttpType; /*iSslFlag*/
    stHttpInfoNode.pfuncRecv        = AI_UploadHttpRecv;
    stHttpInfoNode.pfuncFinished    = AI_UploadHttpFinished;
    stHttpInfoNode.pfuncFailed      = AI_UploadHttpFailed;
    stHttpInfoNode.pfuncGetData     = AI_UploadHttpGetData;
    stHttpInfoNode.pucExpandHeader  = aucExpandHeader;
    stHttpInfoNode.vpUserPtr        = pstConnSocket;
    stHttpInfoNode.uiContentLen     = uiAIPicDateLen;
    stHttpInfoNode.iTimeOut         = 60;
    iRet = Http_SendSyncRequest(&stHttpInfoNode, aucHostAddr, aucUploadUrl, EN_HTTP_METHOD_PUT, uiReqId);
    // Mos_Sleep(10); /**/
    *piIsEndFlag = MOS_TRUE;
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

// AI 开始上传背景图和人脸图 - 不可重入函数
_INT AI_StartUploadBgAndFacePic(ST_URL_CONN_SOCKET *pstConnSocket, _UC *pucAIPicDate, _INT uiAIPicDateLen, _INT *piIsEndFlag, _UI uiReqId)
{
    return AI_StartUploadRequest(pstConnSocket, pucAIPicDate, uiAIPicDateLen, piIsEndFlag, uiReqId);
}

// 通知厂商清除AI图片数据缓
static _INT AI_NotifyDevFreeAiPicCache(ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode)
{
    MOS_PARAM_INVALID_RET(pstUploadAIFacePicInfNode, MOS_NULL, MOS_ERR);

    _INT iRet = 0;

    // 通知厂商清除AI图片数据缓存 ADD by LWJ
    if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
    {        
        iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucFaceDataBuf, pstUploadAIFacePicInfNode->pucBgDataBuf);
        if (MOS_OK == iRet)
        {
            // MOS_LOG_INF(AICFG_LOGSTR,"Device pFunFreeAiPicCache DispositionID:%s OK ", pstUploadAIFacePicInfNode->ucDispositionID);
        }
        else
        {
            _UC aucStrErrLog[128] = {0};
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunFreeAiPicCache DispositionID:%s Bgbuf:%p Picbuf:%p return failed", pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucBgDataBuf, pstUploadAIFacePicInfNode->pucFaceDataBuf);        
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                    EN_AI_RT_UPLOAD_FACEREC_FUNCFREECACHE_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);   
        }
    }
    else
    {
        MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeAiPicCache is NULL!");
    }

    return iRet;
}

// 上传布控告警背景图和人脸图的线程
static _INT AI_UploadAIBgAndFacePic_Loop(_VPTR pParam)
{
    _INT iRet            = 0;
    _INT iIsEndFlag      = 0;
    _UC  *pucPicDate     = MOS_NULL;
    _UI  uiPicDateLen    = 0;
    _ULLID lluNowTime    = 0;
    _ULLID lluDuration   = 0;
    _INT isUploadNowFlag = 0;  // 是否正在upload图片
    ST_URL_CONN_SOCKET stConnSocket         = {0};
    static _INT iIsFindUpLoadPicInfNodeFlag = 0; // 1.upload人脸图 2.upload背景图
    _UI uiAIFaceUploadPicNodeCount          = 0;

#if AIFACE_WRITEFILE
    _UI   uiTargetSizeBg = 0;
    FILE *hFileBg        = NULL;
    _UC  *pucPacDateBg   = NULL;
    _UC   aucFileNameBg[256] = {0};
#endif

    MOS_PRINTF("%s:%d  start \r\n", __FUNCTION__, __LINE__);
    while(Config_GetAIMng()->ucInitFlag)
    {
        ST_MOS_LIST_ITERATOR stIterator;
        ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode    = MOS_NULL;
        ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfTmpNode = MOS_NULL;
        
        lluNowTime = (_ULLID)Mos_Time();

        // 查找最早的节点上传
        FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadCmdPlatTaskInfList, pstUploadAIFacePicInfNode, stIterator)
        {
            if (pstUploadAIFacePicInfNode->uiUseFlag == 1 && pstUploadAIFacePicInfNode->uiUploadFlag == 1)
            {
                lluDuration = MOS_ABS_NUM(lluNowTime - pstUploadAIFacePicInfNode->lluReportTimeStamp);
                
                // 节点上传超时
                if (lluDuration >= AI_FACEREC_ALARM_UPLOAD_TIMEOUT_SEC)
                {
                    MOS_LOG_ERR(AICFG_LOGSTR, "UploadAIBgAndFace PIC ReqId:%u DispositionID:%s is Timeout (%llu - %llu) = %llu > %d",
                        pstUploadAIFacePicInfNode->uiReqId, pstUploadAIFacePicInfNode->ucDispositionID,
                        lluNowTime, pstUploadAIFacePicInfNode->lluReportTimeStamp, lluDuration, (_INT)AI_FACEREC_ALARM_UPLOAD_TIMEOUT_SEC);    

                    // 通知厂商清除AI图片数据缓存 ADD by LWJ
                    AI_NotifyDevFreeAiPicCache(pstUploadAIFacePicInfNode);

                    // 从上传AIFace任务节点删除人脸
                    Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
                    Config_DelUploadAIFacePicTaskNode(0, pstUploadAIFacePicInfNode->uiReqId);
                    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));

                    lluDuration = 0;
                }
                else
                {
                    if (MOS_NULL == pstUploadAIFacePicInfTmpNode)
                    {
                        pstUploadAIFacePicInfTmpNode = pstUploadAIFacePicInfNode;
                    }
                    else
                    {
                        if (pstUploadAIFacePicInfTmpNode->lluReportTimeStamp > pstUploadAIFacePicInfNode->lluReportTimeStamp)
                        {
                            pstUploadAIFacePicInfTmpNode = pstUploadAIFacePicInfNode;
                        }
                    }
                }
            }
        }

        // 未找到上传节点
        if (MOS_NULL == pstUploadAIFacePicInfTmpNode)
        {
            Mos_Sleep(20);
            continue;
        }
        else
        {
            // 先发人脸图
            iIsFindUpLoadPicInfNodeFlag = 1;

            Config_GetUploadAIFacePicTaskNodeCount(0, &uiAIFaceUploadPicNodeCount);

            MOS_LOG_INF(AICFG_LOGSTR, "find UploadAIFacePicInfNode ucNotificationID: %s, AIFaceUploadPicNodeCount:%u, ReqId:%u", 
                pstUploadAIFacePicInfTmpNode->ucNotificationID, uiAIFaceUploadPicNodeCount, pstUploadAIFacePicInfTmpNode->uiReqId);

            while(Config_GetAIMng()->ucInitFlag)
            {
                if (iIsFindUpLoadPicInfNodeFlag == 1 && isUploadNowFlag == 0)    // upload 人脸图
                {
                    if (pstUploadAIFacePicInfTmpNode->ucFaceRequestURL)
                    {
                        MOS_LOG_INF(AICFG_LOGSTR, "Start Upload Face Url: %s, ReqId:%u", pstUploadAIFacePicInfTmpNode->ucFaceRequestURL, pstUploadAIFacePicInfTmpNode->uiReqId);
                        pucPicDate   = MOS_NULL;
                        uiPicDateLen = 0;
                        MOS_MEMSET(&stConnSocket, 0x0, sizeof(ST_URL_CONN_SOCKET));
                        MOS_STRLCPY(stConnSocket.aucRequestURL,        pstUploadAIFacePicInfTmpNode->ucFaceRequestURL,    sizeof(stConnSocket.aucRequestURL));
                        if (pstUploadAIFacePicInfTmpNode->ucFaceRequestDate)
                        {
                            MOS_STRLCPY(stConnSocket.aucRequestDate,   pstUploadAIFacePicInfTmpNode->ucFaceRequestDate,   sizeof(stConnSocket.aucRequestDate));
                        }
                        if (pstUploadAIFacePicInfTmpNode->ucFaceAuthorization)
                        {
                            MOS_STRLCPY(stConnSocket.aucAuthorization, pstUploadAIFacePicInfTmpNode->ucFaceAuthorization, sizeof(stConnSocket.aucAuthorization));
                        }

                        pucPicDate   = pstUploadAIFacePicInfTmpNode->pucFaceDataBuf;
                        uiPicDateLen = pstUploadAIFacePicInfTmpNode->uiFaceDataBufLen;
                        isUploadNowFlag = 1;
                    }
                    else
                    {   // 跳去upload背景图
                        iIsFindUpLoadPicInfNodeFlag = 2;
                        // Mos_Sleep(200);
                        continue;               
                    }
                }
                else if (iIsFindUpLoadPicInfNodeFlag == 2 && isUploadNowFlag == 0) // upload 背景图
                {
                    if (pstUploadAIFacePicInfTmpNode->ucBgRequestURL)
                    {
                        MOS_LOG_INF(AICFG_LOGSTR, "Start Upload BG Url: %s, ReqId:%u", pstUploadAIFacePicInfTmpNode->ucBgRequestURL, pstUploadAIFacePicInfTmpNode->uiReqId);
                        pucPicDate   = MOS_NULL;
                        uiPicDateLen = 0;
                        MOS_MEMSET(&stConnSocket, 0x0, sizeof(ST_URL_CONN_SOCKET));
                        MOS_STRLCPY(stConnSocket.aucRequestURL,        pstUploadAIFacePicInfTmpNode->ucBgRequestURL,    sizeof(stConnSocket.aucRequestURL));

                        if (pstUploadAIFacePicInfTmpNode->ucBgRequestDate)
                        {
                            MOS_STRLCPY(stConnSocket.aucRequestDate,   pstUploadAIFacePicInfTmpNode->ucBgRequestDate,   sizeof(stConnSocket.aucRequestDate));
                        }
                        if (pstUploadAIFacePicInfTmpNode->ucBgAuthorization)
                        {
                            MOS_STRLCPY(stConnSocket.aucAuthorization, pstUploadAIFacePicInfTmpNode->ucBgAuthorization, sizeof(stConnSocket.aucAuthorization));
                        }
#if AIFACE_WRITEFILE
                        MOS_VSNPRINTF(aucFileNameBg,256,"%s/%s.jpeg",Config_GetCoreMng()->aucCachePath, pstUploadAIFacePicInfTmpNode->ucNotificationID);
                        if (NULL == hFileBg)
                        {
                            hFileBg = fopen(aucFileNameBg, "r+");
                            if (NULL == hFileBg)
                            {
                                MOS_PRINTF("fopen: %s failed", aucFileNameBg);
                                return -1;
                            }
                            else
                            {
                                struct   stat   buf = {0}; 
                                stat(aucFileNameBg, &buf);
                                uiTargetSizeBg = buf.st_size;
                                MOS_PRINTF("Bg Fiile:%s uiTargetSizeBg:%u \r\n", aucFileNameBg, uiTargetSizeBg);
                                pucPacDateBg  = (_UC *)malloc(uiTargetSizeBg);
                            }
                        }

                        if (hFileBg)
                        {
                            fseek(hFileBg, SEEK_SET, 0);
                            fread(pucPacDateBg, uiTargetSizeBg, 1, hFileBg);
                            fclose(hFileBg);
                            hFileBg = NULL;
                        }
                        pucPicDate   = pucPacDateBg;
                        uiPicDateLen = uiTargetSizeBg;
#else
                        pucPicDate   = pstUploadAIFacePicInfTmpNode->pucBgDataBuf;
                        uiPicDateLen = pstUploadAIFacePicInfTmpNode->uiBgDataBufLen;
#endif
                        isUploadNowFlag = 1;                 
                    }
                    else
                    {   // 退出upload图片
                        // Mos_Sleep(200);
                        break;               
                    }
                }

                // AI 开始上传背景图和人脸图
                iRet = AI_StartUploadBgAndFacePic(&stConnSocket, pucPicDate, uiPicDateLen, &iIsEndFlag, pstUploadAIFacePicInfTmpNode->uiReqId);
                if (MOS_OK == iRet)
                {
                    // 图片upload完成
                    if (iIsEndFlag)
                    {
                        // Mos_Sleep(200);
                        MOS_LOG_INF(AICFG_LOGSTR,"Upload AIFace OK UpLoadPicInfNodeFlag: %d, ReqId = %u", iIsFindUpLoadPicInfNodeFlag, pstUploadAIFacePicInfTmpNode->uiReqId);
                        if (iIsFindUpLoadPicInfNodeFlag ==1)
                        {
                            // 发完人脸图，再发背景图
                            isUploadNowFlag = 0;
                            iIsFindUpLoadPicInfNodeFlag = 2;
                            continue;
                        }
                        else if (iIsFindUpLoadPicInfNodeFlag == 2)
                        {
                            // 发完背景图,退出upload
                            break;
                        }
                    }
                    else
                    {
                        // Mos_Sleep(20);
                        continue;
                    }
                }
                else
                {
                    MOS_LOG_ERR(AICFG_LOGSTR,"Upload AIFace failed UpLoadPicInfNodeFlag:%d, ReqId = %u", iIsFindUpLoadPicInfNodeFlag, pstUploadAIFacePicInfTmpNode->uiReqId);
                    if (iIsFindUpLoadPicInfNodeFlag ==1)
                    {
                        // Mos_Sleep(1000); // 1s
                        Mos_Sleep(100);
                        // 发人脸图失败，继续发背景图
                        isUploadNowFlag = 0;
                        iIsFindUpLoadPicInfNodeFlag = 2;
                        continue;
                    }
                    else if (iIsFindUpLoadPicInfNodeFlag == 2)
                    {
                        // 发背景图失败,退出upload
                        break;
                    }
                }
                Mos_Sleep(20);
            }

#if AIFACE_WRITEFILE
            if (pucPacDateBg)
            {
                MOS_FREE(pucPacDateBg); 
            }
            Mos_FileRmv(aucFileNameBg);
#endif
            // 通知厂商清除AI图片数据缓存 ADD by LWJ
            AI_NotifyDevFreeAiPicCache(pstUploadAIFacePicInfTmpNode);

            // 从上传AIFace任务节点删除人脸
            Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
            Config_DelUploadAIFacePicTaskNode(0, pstUploadAIFacePicInfTmpNode->uiReqId);
            Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));

            isUploadNowFlag = 0;
            iIsFindUpLoadPicInfNodeFlag = 0;
        }
        Mos_Sleep(20);
    }

    // 删除线程
    /*
    if(MOS_OK != Mos_ThreadDelete(Config_GetAIMng()->hUpLoadThread))
    {
        MOS_LOG_ERR(AICFG_LOGSTR,"Mos_ThreadDelete failed !!");
        return MOS_ERR;
    }

    Config_GetAIMng()->hUpLoadThread = MOS_NULL;
    */
    MOS_LOG_INF(AICFG_LOGSTR,"AI_UploadAIBgAndFacePic_Loop Exit");

    return MOS_OK;
}

// AI 背景图和人脸图上传
_VOID AI_ProcUploadBgAndFacePic()
{
    // 未有上传AIFace图片任务
    if(MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUploadCmdPlatTaskInfList) == 0)
    {
        return;
    }

    _INT iUploadAIFacePicTaskUsedCount  = 0;
    _INT iUploadAIFacePicTaskTotalCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = MOS_NULL;

    iUploadAIFacePicTaskTotalCount = MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUploadCmdPlatTaskInfList);
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadCmdPlatTaskInfList, pstUploadAIFacePicInfNode, stIterator)
    {
        if (pstUploadAIFacePicInfNode->uiUseFlag == 0)
        {
            iUploadAIFacePicTaskUsedCount++;
        }
    }
    if (iUploadAIFacePicTaskTotalCount == iUploadAIFacePicTaskUsedCount)
    {
        return;
    }
    
    if (Config_GetAIMng()->hUpLoadThread == MOS_NULL)
    {

        #ifdef MOS_LINUX_RTOS
            _UI uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
        #else
            _UI uiStackSize = MOS_THREAD_STACK_HIGH_SIZE;
        #endif
        if(Mos_ThreadCreate((_UC*)"UploadAIBgAngFacePic",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        AI_UploadAIBgAndFacePic_Loop,MOS_NULL,MOS_NULL, &Config_GetAIMng()->hUpLoadThread) == MOS_ERR)
        {
            Config_GetAIMng()->hUpLoadThread = MOS_NULL;
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_AI_RT_UPLOAD_FACEREC_CREATE_THREAD_ERR, (_UC*)"Create AI_UploadAIBgAndFacePic_Loop failed", MOS_NULL, 1);
                
            return;
        }
    }
    return;
}

// 上传AI_Zip的线程
static _INT AI_UploadAIZip_Loop(_VPTR pParam)
{
    _INT iRet               = 0;
    _INT iIsEndFlag         = 0;
    _ULLID lluNowTime       = 0;
    _ULLID lluDuration      = 0;
    _INT iAiPicZipDateLen   = 0;
    _UC  ucZipFilePath[128] = {0};
    _UC  *pucAiPicZipDate   = MOS_NULL;
    _HFILE *phAIPicZip_fd   = MOS_NULL;
    _INT isUploadNowFlag    = 0;  // 是否正在upload AI_ZIP
    ST_URL_CONN_SOCKET stConnSocket = {0};
    _UI uiAIZipUploadPicNodeCount   = 0;

    MOS_PRINTF("%s:%d  start\r\n", __FUNCTION__, __LINE__);

    while(Config_GetAIMng()->ucInitFlag)
    {
        ST_MOS_LIST_ITERATOR stIterator;
        ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode    = MOS_NULL;
        ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfTmpNode = MOS_NULL;
        
        lluNowTime = (_ULLID)Mos_Time();

        // 查找最旧的节点上传
        FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadZipTaskInfList, pstUploadAIZipInfNode, stIterator)
        {
            if(pstUploadAIZipInfNode->uiUseFlag == 1 && pstUploadAIZipInfNode->uiUploadFlag == 1)
            {
                lluDuration = MOS_ABS_NUM(lluNowTime - pstUploadAIZipInfNode->lluReportTimeStamp);

                // 查找上传AIZIP抓拍图片的超时节点 2分钟超时
                if (lluDuration >= AI_ZIP_ALARM_UPLOAD_TIMEOUT_SEC)
                {
                    MOS_LOG_ERR(AICFG_LOGSTR, "UploadAIZIP PIC ReqId:%u ZipFilePath:%s is Timeout (%llu - %llu) = %llu > %d",
                                                pstUploadAIZipInfNode->uiReqId, pstUploadAIZipInfNode->ucZipFilePath,
                                                lluNowTime, pstUploadAIZipInfNode->lluReportTimeStamp, lluDuration, (_INT)AI_ZIP_ALARM_UPLOAD_TIMEOUT_SEC);    
                    // 删除ZIP文件
                    MOS_STRLCPY(ucZipFilePath, pstUploadAIZipInfNode->ucZipFilePath, sizeof(ucZipFilePath));
                    Mos_FileRmv(ucZipFilePath);

                    // 从上传AI_ZIP任务节点删除人脸
                    Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
                    Config_DelUploadAIZipTaskNode(0, pstUploadAIZipInfNode->uiReqId);
                    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));

                    lluDuration = 0;
                }
                else
                {
                    // 找最旧的节点
                    if (MOS_NULL == pstUploadAIZipInfTmpNode)
                    {
                        pstUploadAIZipInfTmpNode = pstUploadAIZipInfNode;
                    }
                    else
                    {
                        if (pstUploadAIZipInfTmpNode->lluReportTimeStamp > pstUploadAIZipInfNode->lluReportTimeStamp)
                        {
                            pstUploadAIZipInfTmpNode = pstUploadAIZipInfNode;
                        }
                    }
                }
            }
        }   

        if (MOS_NULL == pstUploadAIZipInfTmpNode)
        {
            Mos_Sleep(200);
            continue;
        }
        else
        {
            Config_GetUploadAIZipTaskNodeCount(0, &uiAIZipUploadPicNodeCount);

            MOS_LOG_INF(AICFG_LOGSTR, "find pstUploadAIZipInfNode ReqId:%u ZipFilePath:%s AIZipUploadPicNodeCount:%u", 
                pstUploadAIZipInfTmpNode->uiReqId, pstUploadAIZipInfTmpNode->ucZipFilePath, uiAIZipUploadPicNodeCount);

            while(Config_GetAIMng()->ucInitFlag)
            {
                if (isUploadNowFlag == 0)    // upload AI_ZIP
                {
                    if (pstUploadAIZipInfTmpNode->ucZipRequestURL)
                    {
                        MOS_LOG_INF(AICFG_LOGSTR, "Start Upload AI_ZIP Url: %s", pstUploadAIZipInfTmpNode->ucZipRequestURL);
                        pucAiPicZipDate  = MOS_NULL;
                        iAiPicZipDateLen = 0;
                        MOS_MEMSET(&stConnSocket, 0x0, sizeof(ST_URL_CONN_SOCKET));
                        MOS_STRLCPY(stConnSocket.aucRequestURL,        pstUploadAIZipInfTmpNode->ucZipRequestURL,    sizeof(stConnSocket.aucRequestURL));
                        if (pstUploadAIZipInfTmpNode->ucZipRequestDate)
                        {
                            MOS_STRLCPY(stConnSocket.aucRequestDate,   pstUploadAIZipInfTmpNode->ucZipRequestDate,   sizeof(stConnSocket.aucRequestDate));
                        }
                        if (pstUploadAIZipInfTmpNode->ucZipAuthorization)
                        {
                            MOS_STRLCPY(stConnSocket.aucAuthorization, pstUploadAIZipInfTmpNode->ucZipAuthorization, sizeof(stConnSocket.aucAuthorization));
                        }

                        // 读取zip文件的内容
                        if (phAIPicZip_fd == MOS_NULL)
                        {
                            phAIPicZip_fd = Mos_FileOpen(pstUploadAIZipInfTmpNode->ucZipFilePath, MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
                            if (MOS_NULL == phAIPicZip_fd)
                            {
                                MOS_LOG_ERR(AICFG_LOGSTR,"Mos_FileOpen %s failed AIPicZip_fd is null, errno(%u)", pstUploadAIZipInfTmpNode->ucZipFilePath, errno);
                                break;
                            }

                            iAiPicZipDateLen = Mos_FileSize(phAIPicZip_fd);
                            pucAiPicZipDate  = (_UC *)Mos_MallocClr(iAiPicZipDateLen);
                            MOS_LOG_INF(AICFG_LOGSTR, "ZIP FILE(%s) SIZE: %d", pstUploadAIZipInfTmpNode->ucZipFilePath, iAiPicZipDateLen);
                        }
                        if (phAIPicZip_fd)
                        {
                            Mos_FileSeek(phAIPicZip_fd, MOS_FILE_SEEK_BEGIN, 0);  

                            iRet = Mos_FileRead(phAIPicZip_fd, pucAiPicZipDate, iAiPicZipDateLen);
                            if (iRet < 0)
                            {
                                MOS_LOG_ERR(AICFG_LOGSTR,"Mos_FileRead %s error(%u)", pstUploadAIZipInfTmpNode->ucZipFilePath, errno);
                            }
                            Mos_FileClose(phAIPicZip_fd);
                            phAIPicZip_fd = MOS_NULL;
                        }

                        isUploadNowFlag = 1;
                    }
                    else
                    {   // URL为空。跳出Upload，等待下一次Upload
                        Mos_Sleep(200);
                        isUploadNowFlag = 0;
                        break;               
                    }
                }

                // AI 开始上传AI识别Zip
                iRet = AI_StartUploadBgAndFacePic(&stConnSocket, pucAiPicZipDate, iAiPicZipDateLen, &iIsEndFlag, pstUploadAIZipInfTmpNode->uiReqId);
                if (MOS_OK == iRet)
                {
                    if (iIsEndFlag)
                    {
                        MOS_LOG_INF(AICFG_LOGSTR, "Upload AI ZIP (%s) OK", pstUploadAIZipInfTmpNode->ucZipFilePath);
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    MOS_LOG_ERR(AICFG_LOGSTR, "Upload AI ZIP (%s) Failed", pstUploadAIZipInfTmpNode->ucZipFilePath);
                    break;
                }
                Mos_Sleep(200);
            }

            // 释放ZIP数据缓存
            if (pucAiPicZipDate)
            {
                MOS_FREE(pucAiPicZipDate); 
            }

            // 删除ZIP文件
            MOS_STRLCPY(ucZipFilePath, pstUploadAIZipInfTmpNode->ucZipFilePath, sizeof(ucZipFilePath));
            Mos_FileRmv(ucZipFilePath);

            // 从上传AI_ZIP任务节点删除人脸
            Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
            Config_DelUploadAIZipTaskNode(0, pstUploadAIZipInfTmpNode->uiReqId);
            Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));

            isUploadNowFlag = 0;
        }
        Mos_Sleep(200);
    }

    // 删除线程
    /*
    if(MOS_OK != Mos_ThreadDelete(Config_GetAIMng()->hUpLoadZipThread))
    {
        MOS_LOG_ERR(AICFG_LOGSTR,"Mos_ThreadDelete failed !!");
        return MOS_ERR;
    }

    Config_GetAIMng()->hUpLoadZipThread = MOS_NULL;
    */
    MOS_LOG_INF(AICFG_LOGSTR,"AI_UploadAIRecZip_Loop Exit");

    return MOS_OK;
}

// AI 识别打包上传zip
_VOID AI_ProcUploadAIRecZip()
{
    // 未有上传AI_ZIP图片任务
    if(MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUploadZipTaskInfList) == 0)
    {
        return;
    }

    _INT iUploadAIZipTaskUsedCount  = 0;
    _INT iUploadAIZipTaskTotalCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = MOS_NULL;

    iUploadAIZipTaskTotalCount = MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUploadZipTaskInfList);
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUploadZipTaskInfList, pstUploadAIZipInfNode, stIterator)
    {
        if (pstUploadAIZipInfNode->uiUseFlag == 0)
        {
            iUploadAIZipTaskUsedCount++;
        }
    }
    if (iUploadAIZipTaskTotalCount == iUploadAIZipTaskUsedCount)
    {
        return;
    }

    if (Config_GetAIMng()->hUpLoadZipThread == MOS_NULL)
    {

        #ifdef MOS_LINUX_RTOS
            _UI uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
        #else
            _UI uiStackSize = MOS_THREAD_STACK_HIGH_SIZE;
        #endif
        if(Mos_ThreadCreate((_UC*)"UploadAIZip",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        AI_UploadAIZip_Loop,MOS_NULL,MOS_NULL, &Config_GetAIMng()->hUpLoadZipThread) == MOS_ERR)
        {
            Config_GetAIMng()->hUpLoadZipThread = MOS_NULL;
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_AI_RT_UPLOAD_ZIP_CREATE_THREAD_ERR, (_UC*)"Create AI_UploadAIZip_Loop failed", MOS_NULL, 1);
                
            return;
        }
    }
    return;
}

// 上传AI告警图片或视频的数据 - 不可重入函数
_INT AI_StartUplaodAIAlarmPVData(ST_URL_CONN_SOCKET *pstConnSocket, _UC *pucAIPicDate, _INT uiAIPicDateLen, _INT *piIsEndFlag, _UI uiReqId)
{
    return AI_StartUploadRequest(pstConnSocket, pucAIPicDate, uiAIPicDateLen, piIsEndFlag, uiReqId);
}

static _INT AI_UplaodAIAlarmPV_Loop(_VPTR pParam)
{
    _INT iRet            = MOS_ERR;
    _UI  uiDataId        = 0;
    _UI  uiDataLen       = 0;
    _UI  uiRetryCount    = 0;   //重试次数
    _INT iIsEndFlag      = 0;
    _ULLID lluNowTime    = 0;
    _ULLID lluDuration   = 0;
    _UC *pucPicBuf       = MOS_NULL;
    _UC *pucVideoBuf     = MOS_NULL;
    _HFILE *phAIPic_fd   = MOS_NULL;
    _HFILE *phAIVideo_fd = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_URL_CONN_SOCKET   stConnSocket = {0};
    _UI uiUploadAIAlarmPVNodeCount    = 0;
  
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode    = MOS_NULL;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfTmpNode = MOS_NULL;

    MOS_LOG_INF(AICFG_LOGSTR, "\r\n=================\r\nStart Upload IOT AI Node");

    while (Config_GetAIMng()->ucInitFlag)
    {
        lluNowTime = (_LLID)Mos_Time();
        pstUplaodAIAlarmPVInfNode = MOS_NULL;
        pstUplaodAIAlarmPVInfTmpNode = MOS_NULL;

        FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfTmpNode, stIterator)
        {
            if(pstUplaodAIAlarmPVInfTmpNode->uiUseFlag == 1)
            {
                // 若是AI告警图片和视频都需要释放缓存，则通知厂商释放缓存后删除该节点
                if (pstUplaodAIAlarmPVInfTmpNode->uiPicUploadFlag   == 2 && 
                    pstUplaodAIAlarmPVInfTmpNode->uiVideoUploadFlag == 2 )
                {
                    MOS_LOG_INF(AICFG_LOGSTR, "AIAlram[%u %u] ReqId:%u Need to Free Cache PicPath:%s VideoPath:%s",
                                                pstUplaodAIAlarmPVInfTmpNode->stAIIoTInf.uiIoTType,
                                                pstUplaodAIAlarmPVInfTmpNode->stAIIoTInf.uiIoTEventId,
                                                pstUplaodAIAlarmPVInfTmpNode->uiReqId,
                                                pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucPicPath,
                                                pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucVideoPath);
                    // 通知厂商清除图片数据缓存 
                    if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
                    { 
                        iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucPicPath,
                                                                           pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucVideoPath);
                        if (MOS_OK != iRet)
                        {
                            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed",
                                                            pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucPicPath,
                                                            pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucVideoPath);
                        }
                    }
                    else
                    {
                        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
                    }

                    // 删除上传AI告警图片和视频的节点
                    Config_DelUploadAIAlarmPVTaskNode(0, pstUplaodAIAlarmPVInfTmpNode->uiReqId); 
                }
                else if (pstUplaodAIAlarmPVInfTmpNode->uiPicUploadFlag   == 1 || 
                         pstUplaodAIAlarmPVInfTmpNode->uiVideoUploadFlag == 1 )
                {
                    lluDuration = MOS_ABS_NUM(lluNowTime - pstUplaodAIAlarmPVInfTmpNode->lluReportTimeStamp);
                    // 查找上传AI告警图片或视频的超时节点, 并设置标志位
                    if (lluDuration >= AI_IOTPV_ALARM_UPLOAD_TIMEOUT_SEC)
                    {
                        MOS_LOG_ERR(AICFG_LOGSTR, "AIAlram[%u %u] ReqId:%u is Timeout PicPath:%s VideoPath:%s (%llu - %llu)=%llu > %d",
                                                    pstUplaodAIAlarmPVInfTmpNode->stAIIoTInf.uiIoTType,
                                                    pstUplaodAIAlarmPVInfTmpNode->stAIIoTInf.uiIoTEventId,
                                                    pstUplaodAIAlarmPVInfTmpNode->uiReqId,
                                                    pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucPicPath,
                                                    pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucVideoPath,
                                                    lluNowTime,  pstUplaodAIAlarmPVInfTmpNode->lluReportTimeStamp,
                                                    lluDuration, (_INT)AI_IOTPV_ALARM_UPLOAD_TIMEOUT_SEC);    
                        // 通知厂商清除图片数据缓存 
                        if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
                        { 
                            iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucPicPath,
                                                                            pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucVideoPath);
                            if (MOS_OK != iRet)
                            {
                                MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed",
                                                                pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucPicPath,
                                                                pstUplaodAIAlarmPVInfTmpNode->stAIAlarmUploadInf.ucVideoPath);
                            }
                        }
                        else
                        {
                            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
                        }

                        // 删除上传AI告警图片和视频的节点
                        Config_DelUploadAIAlarmPVTaskNode(0, pstUplaodAIAlarmPVInfTmpNode->uiReqId);
                        lluDuration = 0;                    
                    }
                    else 
                    {
                        // 找最旧的节点
                        if (MOS_NULL == pstUplaodAIAlarmPVInfNode)
                        {
                            pstUplaodAIAlarmPVInfNode = pstUplaodAIAlarmPVInfTmpNode;
                        }
                        else
                        {
                            if (pstUplaodAIAlarmPVInfNode->lluReportTimeStamp > pstUplaodAIAlarmPVInfTmpNode->lluReportTimeStamp)
                            {
                                pstUplaodAIAlarmPVInfNode = pstUplaodAIAlarmPVInfTmpNode;
                            }
                        }
                    }
                }
            }
        }

        if (MOS_NULL == pstUplaodAIAlarmPVInfNode)
        {
            Mos_Sleep(200);
            continue;
        }
        else
        {
            Config_GetUploadAIAlarmPVTaskNodeCount(0, &uiUploadAIAlarmPVNodeCount);
            MOS_LOG_INF(AICFG_LOGSTR, "AIAlram[%u %u] Find Upload Node ReqId:%u PicFlag:%u VideoFlag:%u Time:%llu Count:%u",
                                        pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType, 
                                        pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId,
                                        pstUplaodAIAlarmPVInfNode->uiReqId, 
                                        pstUplaodAIAlarmPVInfNode->uiPicUploadFlag, 
                                        pstUplaodAIAlarmPVInfNode->uiVideoUploadFlag,
                                        pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.lluTimeStamp,
                                        uiUploadAIAlarmPVNodeCount);

            //上传图片
            if (pstUplaodAIAlarmPVInfNode->uiPicUploadFlag == 1)
            {
                iIsEndFlag   = 0;
                uiRetryCount = 0;
                MOS_LOG_INF(AICFG_LOGSTR,"GO TO SEND [%u %u] PIC(%s) File ReqId:%u ", 
                                            pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType, 
                                            pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId,
                                            pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                            pstUplaodAIAlarmPVInfNode->uiReqId);
                phAIPic_fd = Mos_FileOpen(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
                if (phAIPic_fd)
                {
                    MOS_MEMSET(&stConnSocket, 0x0, sizeof(ST_URL_CONN_SOCKET));
                    uiDataLen = Mos_FileSize(phAIPic_fd);
                    pucPicBuf = (_UC*)MOS_MALLOCCLR(uiDataLen);
                    if (pucPicBuf)
                    {
                        iRet = Mos_FileRead(phAIPic_fd, pucPicBuf, uiDataLen);
                        if (iRet > 0)
                        {
                            MOS_STRLCPY(stConnSocket.aucRequestURL, pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicRequestUrl, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicRequestUrl));
                            if (pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicRequestDate)
                            {
                                MOS_STRLCPY(stConnSocket.aucRequestDate, pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicRequestDate, sizeof(stConnSocket.aucRequestDate));
                            }
                            if (pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicAuthorization)
                            {
                                MOS_STRLCPY(stConnSocket.aucAuthorization, pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucPicAuthorization, sizeof(stConnSocket.aucAuthorization));
                            }
                            while(!iIsEndFlag)
                            {
                                // 上传AI告警图片的数据
                                iRet = AI_StartUplaodAIAlarmPVData(&stConnSocket, pucPicBuf, uiDataLen, &iIsEndFlag, pstUplaodAIAlarmPVInfNode->uiReqId);
                                if (MOS_OK == iRet)
                                {
                                    // 图片upload完成
                                    if (iIsEndFlag)
                                    {
                                        // 设置AI告警图片缓存可释放
                                        Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);
                                        MOS_LOG_INF(AICFG_LOGSTR,"SEND IoT[%u %u] ReqId:%u AI Pic(%s) File Success",
                                                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType, 
                                                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId,
                                                                    pstUplaodAIAlarmPVInfNode->uiReqId,
                                                                    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath);
                                    }
                                }
                                else
                                {
                                    Mos_Sleep(50);
                                    uiRetryCount++;
                                    if ((uiRetryCount >= 3) || (iIsEndFlag == 1))
                                    {
                                        // 设置AI告警图片缓存可释放
                                        Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);
                                        MOS_LOG_ERR(AICFG_LOGSTR,"SEND IoT[%u %u] ReqId:%u AI Pic(%s) File Error, RetryCount:%u IsEndFlag:%d", 
                                                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType, 
                                                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId,
                                                                    pstUplaodAIAlarmPVInfNode->uiReqId,
                                                                    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                                                    uiRetryCount, iIsEndFlag);
                                        iIsEndFlag   = 0;
                                        uiRetryCount = 0;
                                        break;// while(!iIsEndFlag)
                                    }
                                }
                            }
                        }
                        else
                        {
                            // 设置AI告警图片缓存可释放
                            Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);
                            MOS_LOG_ERR(AICFG_LOGSTR, "IOT ReqId:%u AI Read Pic(%s) File Fail",
                                                        pstUplaodAIAlarmPVInfNode->uiReqId,
                                                        pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath);
                        }
                        MOS_FREE(pucPicBuf);
                        Mos_FileClose(phAIPic_fd);
                    }
                    else
                    {
                        MOS_LOG_ERR(AICFG_LOGSTR, "IOT ReqId:%u AI MALLOCCLR Pic(%s) File Fail",
                                                    pstUplaodAIAlarmPVInfNode->uiReqId,
                                                    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath);
                        Mos_FileClose(phAIPic_fd);
                        // 设置AI告警图片缓存可释放
                        Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);
                    }
                }
                else
                {
                    // 设置AI告警图片缓存可释放
                    Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);
                    MOS_LOG_ERR(AICFG_LOGSTR, "IOT ReqId:%u AI Open Pic(%s) File Fail",
                                                pstUplaodAIAlarmPVInfNode->uiReqId,
                                                pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath);
                }
            }
            //上传视频
            if (pstUplaodAIAlarmPVInfNode->uiVideoUploadFlag == 1)
            {
                MOS_LOG_INF(AICFG_LOGSTR,"GO TO SEND [%u %u] Video(%s) File ReqId:%u",
                                            pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType, 
                                            pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId,
                                            pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath,
                                            pstUplaodAIAlarmPVInfNode->uiReqId);
                phAIVideo_fd = Mos_FileOpen(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath, MOS_FILE_O_RDONLY|MOS_FILE_O_BIN);
                if (phAIVideo_fd)
                {
                    iIsEndFlag = 0;
                    uiRetryCount = 0;
                    MOS_MEMSET(&stConnSocket, 0x0, sizeof(ST_URL_CONN_SOCKET));
                    uiDataLen = Mos_FileSize(phAIVideo_fd);
                    pucVideoBuf = (_UC*)MOS_MALLOCCLR(uiDataLen);
                    if (pucVideoBuf)
                    {
                        iRet = Mos_FileRead(phAIVideo_fd, pucVideoBuf, uiDataLen);
                        if (iRet > 0)
                        {
                            MOS_STRLCPY(stConnSocket.aucRequestURL, pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoRequestUrl, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoRequestUrl));
                            if (pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoRequestDate)
                            {
                                MOS_STRLCPY(stConnSocket.aucRequestDate, pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoRequestDate, sizeof(stConnSocket.aucRequestDate));
                            }
                            if (pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoAuthorization)
                            {
                                MOS_STRLCPY(stConnSocket.aucAuthorization, pstUplaodAIAlarmPVInfNode->stAIAlarmPVNetInf.ucVideoAuthorization, sizeof(stConnSocket.aucAuthorization));
                            }
                            while(!iIsEndFlag)
                            {
                                // 上传AI告警视频的数据
                                iRet = AI_StartUplaodAIAlarmPVData(&stConnSocket, pucVideoBuf, uiDataLen, &iIsEndFlag, pstUplaodAIAlarmPVInfNode->uiReqId);
                                if (MOS_OK == iRet)
                                {
                                    if (iIsEndFlag)
                                    {
                                        // 设置AI告警视频缓存可释放
                                        Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);                
                                        MOS_LOG_INF(AICFG_LOGSTR,"SEND IOT[%u %u] ReqId:%u AI Video(%s) File Success",
                                                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType, 
                                                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId,
                                                                    pstUplaodAIAlarmPVInfNode->uiReqId,
                                                                    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                                    }
                                }
                                else
                                {
                                    Mos_Sleep(50);
                                    uiRetryCount++;
                                    if ((uiRetryCount >= 3) || (iIsEndFlag == 1))
                                    {
                                        // 设置AI告警视频缓存可释放
                                        Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);                
                                        MOS_LOG_ERR(AICFG_LOGSTR,"SEND IOT[%u %u] ReqId:%u AI Video(%s) File Error, RetryCount:%u IsEndFlag:%d",
                                                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTType, 
                                                                    pstUplaodAIAlarmPVInfNode->stAIIoTInf.uiIoTEventId,
                                                                    pstUplaodAIAlarmPVInfNode->uiReqId,
                                                                    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath,
                                                                    uiRetryCount, iIsEndFlag);
                                        iIsEndFlag   = 0;
                                        uiRetryCount = 0;
                                        break;// while(!iIsEndFlag)
                                    }
                                }
                            }
                        }
                        else
                        {
                            // 设置AI告警视频缓存可释放
                            Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);
                            MOS_LOG_ERR(AICFG_LOGSTR, "IOT ReqId:%u AI Read Video(%s) File Fail",
                                                        pstUplaodAIAlarmPVInfNode->uiReqId,
                                                        pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                        }
                        MOS_FREE(pucVideoBuf);
                        Mos_FileClose(phAIVideo_fd);
                    }
                    else
                    {
                        // 设置AI告警视频缓存可释放
                        Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);                
                        MOS_LOG_ERR(AICFG_LOGSTR, "IOT ReqId:%u AI MALLOCCLR Video(%s) File Fail",
                                                    pstUplaodAIAlarmPVInfNode->uiReqId,
                                                    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                        Mos_FileClose(phAIVideo_fd);
                    }        
                }
                else
                {
                    // 设置AI告警视频缓存可释放
                    Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(0, pstUplaodAIAlarmPVInfNode->uiReqId, 2);                
                    MOS_LOG_ERR(AICFG_LOGSTR, "IOT ReqId:%u AI Open Video(%s) File Fail",
                                                pstUplaodAIAlarmPVInfNode->uiReqId,
                                                pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                }
            }

            // 若是AI告警图片和视频都需要释放缓存，则通知厂商释放缓存后删除该节点
            if (pstUplaodAIAlarmPVInfNode->uiPicUploadFlag   == 2 && 
                pstUplaodAIAlarmPVInfNode->uiVideoUploadFlag == 2 )
            {
                // 通知厂商清除图片数据缓存 
                if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
                {
                    // MOS_LOG_INF(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s GO TO DO",
                    //                 pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);

                    iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                                                       pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                    if (MOS_OK != iRet)
                    {
                        MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed",
                                                    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                                    pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                    }
                }
                else
                {
                    MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
                }

                // 删除上传AI告警图片和视频的节点
                Config_DelUploadAIAlarmPVTaskNode(0, pstUplaodAIAlarmPVInfNode->uiReqId); 
            }
        }
        Mos_Sleep(200);
    }

    // 删除线程
    /*
    if(MOS_OK != Mos_ThreadDelete(Config_GetAIMng()->hUplaodAIAlarmPVThread))
    {
        MOS_LOG_ERR(AICFG_LOGSTR,"Mos_ThreadDelete failed !!");
        return MOS_ERR;
    }

    Config_GetAIMng()->hUplaodAIAlarmPVThread = MOS_NULL;
    */
    MOS_LOG_INF(AICFG_LOGSTR,"AI_UplaodAIAlarmPV_Loop Exit");
    return MOS_OK;
}

// AI 告警图片、视频上传
_VOID AI_ProcUplaodAIAlarmPV()
{
    // 未有上传AIAlarmPV图片和视频任务
    if(MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList) == 0)
    {
        return;
    }

    _INT iUploadAIAlarmPVTaskUsedCount  = 0;
    _INT iUploadAIAlarmPVTaskTotalCount = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;

    iUploadAIAlarmPVTaskTotalCount = MOS_LIST_GETCOUNT(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList);
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUplaodAIAlarmPVTaskInfList, pstUplaodAIAlarmPVInfNode, stIterator)
    {
        if (pstUplaodAIAlarmPVInfNode->uiUseFlag == 0)
        {
            iUploadAIAlarmPVTaskUsedCount++;
        }
    }
    if (iUploadAIAlarmPVTaskTotalCount == iUploadAIAlarmPVTaskUsedCount)
    {
        return;
    }

    if (Config_GetAIMng()->hUplaodAIAlarmPVThread == MOS_NULL)
    {
        #ifdef MOS_LINUX_RTOS
            _UI uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
        #else
            _UI uiStackSize = MOS_THREAD_STACK_HIGH_SIZE;
        #endif
            if(Mos_ThreadCreate((_UC*)"UplaodAIAlarmPV",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                            AI_UplaodAIAlarmPV_Loop,MOS_NULL,MOS_NULL, &Config_GetAIMng()->hUplaodAIAlarmPVThread) == MOS_ERR)
            {
                Config_GetAIMng()->hUplaodAIAlarmPVThread = MOS_NULL;
                MOS_LOG_ERR(AICFG_LOGSTR,"Create AI_UplaodAIAlarmPV_Loop failed");
                return;
            }
    }
    return;
}
