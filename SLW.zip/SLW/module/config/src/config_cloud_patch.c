#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "cloudstg_api.h"

_INT Config_AddOneCloudPatchInfoToCfgTaskList(_UC *pucUuid, _INT iCamId, _INT iEventType, _INT iTaskType, _INT iStorageType, _INT iCloudUpLoadMode, _UI uiDuration, _CTIME_T tCreateTime, _CTIME_T tFailTime)
{
    _BOOL bNeedInsertHeadFlag = MOS_TRUE;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskTmp  = MOS_NULL;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskNode = MOS_NULL;

    pstPatchTaskNode = Mos_MemAlloc(MOS_NULL,sizeof(ST_CFG_CLOUDSTG_PATCH_MNG));
    MOS_MEMSET(pstPatchTaskNode, 0x00, sizeof(ST_CFG_CLOUDSTG_PATCH_MNG));
    MOS_MEMSET(pstPatchTaskNode->pucUuid, 0x00, sizeof(pstPatchTaskNode->pucUuid));
    MOS_STRCPY(pstPatchTaskNode->pucUuid, pucUuid);
    pstPatchTaskNode->iCamId = iCamId;
    pstPatchTaskNode->iEventType = iEventType;
    pstPatchTaskNode->iTaskType = iTaskType;
    pstPatchTaskNode->iStorageType = iStorageType;
    pstPatchTaskNode->iCloudUpLoadMode = iCloudUpLoadMode;
    pstPatchTaskNode->uiDuration = uiDuration;
    pstPatchTaskNode->tCreateTime = tCreateTime;
    pstPatchTaskNode->tFailTime = tFailTime;

    // 首次加入链表无需检查
    Mos_MutexLock(&Config_GetCloudMng()->hCloudPatchMutex);
    if (Config_GetCloudMng()->stPatchTaskCfgList.uiTotalCount == 0)
    {
        MOS_LIST_ADDTAIL(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode);
    }
    // 按create/fail时间顺序插入
    else
    {
        FOR_EACHDATA_INLIST_CONVERSE(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskTmp, stIterator)
        {
            if(pstPatchTaskTmp->tCreateTime == pstPatchTaskNode->tCreateTime)
            {
                // create时间一样，对比fail时间
                if (pstPatchTaskTmp->tFailTime <= pstPatchTaskNode->tFailTime)
                {
                    // printf("pstPatchTaskTmp->tFailTime:%u <= pstPatchTaskNode->tFailTime:%u\r\n", pstPatchTaskTmp->tFailTime, pstPatchTaskNode->tFailTime);
                    MOS_LIST_INSERTNEXT(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskTmp, pstPatchTaskNode);
                    bNeedInsertHeadFlag = MOS_FALSE;
                    break;
                }
            }
            else if (pstPatchTaskTmp->tCreateTime < pstPatchTaskNode->tCreateTime)
            {
                // printf("pstPatchTaskTmp->tCreateTime:%u < pstPatchTaskNode->tCreateTime:%u\r\n", pstPatchTaskTmp->tCreateTime, pstPatchTaskNode->tCreateTime);
                MOS_LIST_INSERTNEXT(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskTmp, pstPatchTaskNode);
                bNeedInsertHeadFlag = MOS_FALSE;
                break;
            }
        }
        // 新增的补录时间create time小于所有补录时间段，插入到链表头部
        if (bNeedInsertHeadFlag == MOS_TRUE)
        {
            MOS_LIST_ADDHEAD(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode);
        }
    }
    Mos_MutexUnLock(&Config_GetCloudMng()->hCloudPatchMutex);

    Config_GetItemSign()->ucSaveCloudPatchFlag = 1;
    return MOS_OK;
}

_INT Config_ModifyOneCloudPatchInfoFromCfgTaskList(_UC *pucUuid, _INT iCamId, _INT iEventType, _INT iTaskType, _INT iStorageType, _INT iCloudUpLoadMode, _UI uiDuration, _CTIME_T tCreateTime, _CTIME_T tFailTime)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskNode = MOS_NULL;

    Mos_MutexLock(&Config_GetCloudMng()->hCloudPatchMutex);
    FOR_EACHDATA_INLIST(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode, stIterator)
    {
        if (MOS_STRCMP(pstPatchTaskNode->pucUuid, pucUuid) == 0 && pstPatchTaskNode->iCamId == iCamId)
        {
            pstPatchTaskNode->iEventType = iEventType;
            pstPatchTaskNode->iTaskType = iTaskType;
            pstPatchTaskNode->iStorageType = iStorageType;
            pstPatchTaskNode->iCloudUpLoadMode = iCloudUpLoadMode;
            pstPatchTaskNode->uiDuration = uiDuration;
            pstPatchTaskNode->tCreateTime = tCreateTime;
            pstPatchTaskNode->tFailTime = tFailTime;
            break;
        }
    }
    Mos_MutexUnLock(&Config_GetCloudMng()->hCloudPatchMutex);

    Config_GetItemSign()->ucSaveCloudPatchFlag = 1;

    return MOS_OK;
}

_INT Config_RemoveOneCloudPatchInfoFromCfgTaskList(_UC *pucUuid, _INT iCamId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskNode = MOS_NULL;

    Mos_MutexLock(&Config_GetCloudMng()->hCloudPatchMutex);
    FOR_EACHDATA_INLIST(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode, stIterator)
    {
        if (MOS_STRCMP(pstPatchTaskNode->pucUuid, pucUuid) == 0 && pstPatchTaskNode->iCamId == iCamId)
        {
            MOS_LIST_RMVNODE(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode);
            Mos_MemFree(pstPatchTaskNode);
            break;
        }
    }
    Mos_MutexUnLock(&Config_GetCloudMng()->hCloudPatchMutex);

    Config_GetItemSign()->ucSaveCloudPatchFlag = 1;

    return MOS_OK;
}

_VPTR Config_BuildCloudPatchSetObject()
{
    JSON_HANDLE hRoot      = Adpt_Json_CreateObject();
    JSON_HANDLE hArray     = Adpt_Json_CreateArray();
    JSON_HANDLE hArrayItem = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskNode = MOS_NULL;
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"DeviceId", Adpt_Json_CreateString(Config_GetSystemMng()->aucDid));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"PatchList", hArray);

    Mos_MutexLock(&Config_GetCloudMng()->hCloudPatchMutex);
    FOR_EACHDATA_INLIST(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode, stIterator)
    {
        hArrayItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArray,hArrayItem);
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Uuid",Adpt_Json_CreateString(pstPatchTaskNode->pucUuid));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"CamId",Adpt_Json_CreateStrWithNum(pstPatchTaskNode->iCamId));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"EventType",Adpt_Json_CreateStrWithNum(pstPatchTaskNode->iEventType));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"TaskType",Adpt_Json_CreateStrWithNum(pstPatchTaskNode->iTaskType));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"StorageType",Adpt_Json_CreateStrWithNum(pstPatchTaskNode->iStorageType));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"CloudUpLoadMode",Adpt_Json_CreateStrWithNum(pstPatchTaskNode->iCloudUpLoadMode));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(pstPatchTaskNode->uiDuration));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"CreateTime",Adpt_Json_CreateStrWithNum(pstPatchTaskNode->tCreateTime));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"FailTime",Adpt_Json_CreateStrWithNum(pstPatchTaskNode->tFailTime));
    }
    Mos_MutexUnLock(&Config_GetCloudMng()->hCloudPatchMutex);
    
    return hRoot;
}

_UC *Config_BuildCloudPatchSetJson()
{
    _UC *pStrTmp = MOS_NULL;    
    JSON_HANDLE hRoot     = Config_BuildCloudPatchSetObject();
    
    pStrTmp = Adpt_Json_Print(hRoot);
    // MOS_LOG_INF(CFG_LOGSTR,"build patch cloud info %s",pStrTmp);
    // printf("build patch cloud info %s\r\n",pStrTmp);
    
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}

// 读取云存配置的字段
_INT Config_ParseCloudPatchSetJson(_UC *pStrJson)
{
    MOS_PARAM_NULL_RETERR(pStrJson);
    _UC *pStrTmp     = MOS_NULL;
    _UC aucBuff[256] = {0};
    _INT iArrySize = 0, i = 0;
    JSON_HANDLE hRoot       = Adpt_Json_Parse(pStrJson);
    JSON_HANDLE hArray      = MOS_NULL;
    JSON_HANDLE hArryObject = MOS_NULL;
    ST_CFG_CLOUDSTG_PATCH_MNG *pstPatchTaskNode = MOS_NULL;

    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DeviceId"),&pStrTmp);
    if (MOS_STRLEN(pStrTmp) == 0)
    {
        MOS_LOG_ERR(CFG_LOGSTR,"Can't find uuid");
        printf("Can't find uuid\r\n");
        return MOS_ERR;
    }

    if (MOS_STRCMP(pStrTmp, Config_GetSystemMng()->aucDid) != 0)
    {
        MOS_VSNPRINTF(aucBuff,256,"%s/%s",Config_GetCoreMng()->aucCachePath,CFG_CLOUDSTG_PATCH_FILE);
        Mos_FileRmv(aucBuff);
        MOS_LOG_ERR(CFG_LOGSTR,"Detected different sd crad plug in! Can't config patch info normally");
        printf("Detected different sd crad plug in! Can't config patch info normally\r\n");
        return MOS_ERR;
    }
    
    hArray = Adpt_Json_GetObjectItem(hRoot,(_UC*)"PatchList");
    iArrySize = Adpt_Json_GetArraySize(hArray);

    for(i = 0; i < iArrySize; i++)
    {
        pstPatchTaskNode = Mos_MemAlloc(MOS_NULL,sizeof(ST_CFG_CLOUDSTG_PATCH_MNG));
        MOS_MEMSET(pstPatchTaskNode, 0x00, sizeof(ST_CFG_CLOUDSTG_PATCH_MNG));
        hArryObject = Adpt_Json_GetArrayItem(hArray,i);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Uuid"),&pStrTmp);
        MOS_STRNCPY(pstPatchTaskNode->pucUuid, pStrTmp, sizeof(pstPatchTaskNode->pucUuid));
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"CamId"),&pstPatchTaskNode->iCamId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"EventType"),&pstPatchTaskNode->iEventType);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"TaskType"),&pstPatchTaskNode->iTaskType);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"StorageType"),&pstPatchTaskNode->iStorageType);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"CloudUpLoadMode"),&pstPatchTaskNode->iCloudUpLoadMode);
        if (pstPatchTaskNode->iCloudUpLoadMode == 0) 
        {
            pstPatchTaskNode->iCloudUpLoadMode = 2;
        }
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"Duration"),&pstPatchTaskNode->uiDuration);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"CreateTime"),&pstPatchTaskNode->tCreateTime);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject,(_UC*)"FailTime"),&pstPatchTaskNode->tFailTime);

        Mos_MutexLock(&Config_GetCloudMng()->hCloudPatchMutex);
        MOS_LIST_ADDTAIL(&Config_GetCloudMng()->stPatchTaskCfgList, pstPatchTaskNode);
        Mos_MutexUnLock(&Config_GetCloudMng()->hCloudPatchMutex);
    }

    Adpt_Json_Delete(hRoot);

    return MOS_OK;
}
