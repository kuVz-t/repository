#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"
#include "adpt_crypto_adapt.h"
#include "http_api.h"
#include "msgmng_api.h"
#include "config_ims.h"

ST_CFG_IMS_MNG *Config_GetImsMng()
{
    return &Config_GetlocalCfgInf()->stImsMng;
}

_INT Config_Ims_Init()
{
    MOS_LOG_INF(IMSCFG_LOGSTR,"Config IMS Init Ok");
    return MOS_OK;
}

_INT Config_Ims_Destroy()
{
    MOS_LOG_INF(IMSCFG_LOGSTR,"Config IMS Destroy Ok");
    return MOS_OK;
}

/*************************************************************************
创建 IMS配置Json
*************************************************************************/
_VPTR Config_BuildImsSetObject()
{
    MOS_LOG_INF(CFG_LOGSTR,"build ims info %s",Config_GetImsMng()->ucImsBusiParamJson);
    JSON_HANDLE hRoot = Adpt_Json_Parse(Config_GetImsMng()->ucImsBusiParamJson);

    return hRoot;
}

_UC *Config_BuildImsSetJson()
{
    _UC *pStrTmp = MOS_NULL;    
    JSON_HANDLE hRoot = Config_BuildImsSetObject();
    
    pStrTmp = Adpt_Json_Print(hRoot);
    // MOS_LOG_INF(CFG_LOGSTR,"build ims info %s",pStrTmp);
    
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}

// 读取IMS配置的字段
_INT Config_ParseImsSetJson(_UC *pStrJson)
{
    MOS_PARAM_NULL_RETERR(pStrJson);
    // MOS_LOG_INF(IMSCFG_LOGSTR,"IMS Json pStrJson: %s", pStrJson);

    _UC  *pStrTmp = MOS_NULL;
    MOS_STRNCPY(Config_GetImsMng()->ucImsBusiParamJson, pStrJson, sizeof(Config_GetImsMng()->ucImsBusiParamJson));

    JSON_HANDLE hRoot = Adpt_Json_Parse(pStrJson);
    if(hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(IMSCFG_LOGSTR, "hRoot == MOS_NULL");
        return MOS_ERR;
    }

    // 版本号，可依据该字段判断IMS业务参数是否是否有变化
    //Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),&pStrTmp);
    //MOS_STRNCPY(Config_GetImsMng()->ucSign, pStrTmp, sizeof(Config_GetImsMng()->ucSign));
    // 轮询间隔
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PollingInterval"),(_INT*)&Config_GetImsMng()->uiPollingInterval);
    // 轮询开关 0.关闭，1.开启，默认关，轮询依赖套餐开通
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PollingStatus"),(_INT*)&Config_GetImsMng()->uiPollingStatus);
    // 是否开通 0.关闭 1.开通
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"HaveIMS"),(_INT*)&Config_GetImsMng()->uiHaveIMS);
    // 绑定码
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Bindkey"),&pStrTmp);
    MOS_STRNCPY(Config_GetImsMng()->ucBindKey, pStrTmp, sizeof(Config_GetImsMng()->ucBindKey));
    Adpt_Json_Delete(hRoot);

    return MOS_OK;
}

_INT Config_SetImsBindKey(_UC *pucBindKey)
{
    MOS_PARAM_NULL_RETERR(pucBindKey);

    if(MOS_STRCMP(Config_GetImsMng()->ucBindKey,pucBindKey) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetImsMng()->ucBindKey,pucBindKey,sizeof(Config_GetImsMng()->ucBindKey));
    MOS_LOG_INF(CFG_LOGSTR,"ImsCfg set BindKey %s", pucBindKey);
    Config_GetItemSign()->ucSaveImsFlag = 1;
    return MOS_OK;
}

_INT Config_SetImsSign(_UC *pucSign)
{
    MOS_PARAM_NULL_RETERR(pucSign);

    if(MOS_STRCMP(Config_GetImsMng()->ucSign,pucSign) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetImsMng()->ucSign,pucSign,sizeof(Config_GetImsMng()->ucSign));
    MOS_LOG_INF(CFG_LOGSTR,"ImsCfg set Sign %s", pucSign);
    return MOS_OK;
}

_INT Config_SetImsPollingStatus(_UI uiPollingStatus)
{
    if(uiPollingStatus == Config_GetImsMng()->uiPollingStatus)
    {
        return MOS_OK;
    }
    Config_GetImsMng()->uiPollingStatus = uiPollingStatus;
    MOS_LOG_INF(CFG_LOGSTR,"ImsCfg set PollingStatus %u",uiPollingStatus);
    return MOS_OK;
}

_INT Config_SetImsPollingInterval(_UI uiPollingInterval)
{
    if(uiPollingInterval == Config_GetImsMng()->uiPollingInterval)
    {
        return MOS_OK;
    }
    Config_GetImsMng()->uiPollingInterval = uiPollingInterval;
    MOS_LOG_INF(CFG_LOGSTR,"ImsCfg set PollingInterval %u",uiPollingInterval);
    return MOS_OK;
}

_INT Config_SetImsHaveIMSValue(_UI uiHaveIMS)
{
    if(uiHaveIMS == Config_GetImsMng()->uiHaveIMS)
    {
        return MOS_OK;
    }
    Config_GetImsMng()->uiHaveIMS = uiHaveIMS;
    Config_GetItemSign()->ucSaveImsFlag = 1;
    MOS_LOG_INF(CFG_LOGSTR,"ImsCfg set HaveIMS %u",uiHaveIMS);
    return MOS_OK;
}

_INT Config_SetImsBusiParamJson(_UC *pucImsBusiParamJson)
{
    MOS_PARAM_NULL_RETERR(pucImsBusiParamJson);

    if(MOS_STRCMP(Config_GetImsMng()->ucImsBusiParamJson,pucImsBusiParamJson) == 0)
    {
        return MOS_OK;
    }   
    MOS_STRNCPY(Config_GetImsMng()->ucImsBusiParamJson,pucImsBusiParamJson,sizeof(Config_GetImsMng()->ucImsBusiParamJson));
    Config_GetItemSign()->ucSaveImsFlag = 1;
    MOS_LOG_INF(CFG_LOGSTR,"ImsCfg set ImsBusiParamJson %s", pucImsBusiParamJson);
    return MOS_OK;
}