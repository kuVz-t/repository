#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "adpt_json_adapt.h"

ST_CFG_KJIOTHUB_MNG *Config_GetIotHubMng()
{
     return &Config_GetlocalCfgInf()->stKjIoTHubMng;
}
/******************************************************************
*******************************************************************/
_INT Config_IotHub_Init()
{
    Mos_MutexCreate(&Config_GetIotHubMng()->hMutex);
    MOS_LIST_INIT(&Config_GetIotHubMng()->stIotList);
    Config_GetIotHubMng()->uiIotMaxCount = 32;
    return MOS_OK;
}

_INT Config_SetIotHubAbility(_UI uiHubAblity)
{
    if(Config_GetIotHubMng()->uiIotHubAbility == uiHubAblity)
    {
        return MOS_OK;
    }
    Config_GetIotHubMng()->uiIotHubAbility = uiHubAblity;
    Config_GetItemSign()->ucSaveIotHub     = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub set Ability %d",uiHubAblity);
    return MOS_OK;
}

_INT Config_SetIotHubStatus(_UI uiHubStatus)
{
    if(Config_GetIotHubMng()->uiIotHubStatus == uiHubStatus)
    {
        return MOS_OK;
    }
    Config_GetIotHubMng()->uiIotHubStatus = uiHubStatus;
    Config_GetItemSign()->ucSaveIotHub      = 1;
    Config_GetItemSign()->ucCfgIotHubUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub set IotHubStatus %d",uiHubStatus);
    return MOS_OK;
}

_INT Config_SetIotHubMaxCount(_UI uiIotMaxCnt)
{
    if(Config_GetIotHubMng()->uiIotMaxCount == uiIotMaxCnt)
    {
        return MOS_OK;
    }
    Config_GetIotHubMng()->uiIotMaxCount = uiIotMaxCnt;
    Config_GetItemSign()->ucSaveIotHub = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub set KjIot MaxCount %d",uiIotMaxCnt);
    return MOS_OK;
}
/******************************************************************

******************************************************************/
ST_CFG_HUBIOT_NODE* Config_FindIotForHub(_UI uiKjIoTType,_LLID lluKjIoTId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_HUBIOT_NODE *pstIotHubNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetIotHubMng()->stIotList, pstIotHubNode, stIterator)
    {
        if(pstIotHubNode->uiKjIoTType == uiKjIoTType && pstIotHubNode->lluKjIoTId == lluKjIoTId
            && pstIotHubNode->uiUseFlag)
        {
            break;
        }
    }
    
    return pstIotHubNode;
}

_INT Config_BegainSyncIotHubDevList()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_HUBIOT_NODE *pstIotHubNode    = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetIotHubMng()->stIotList, pstIotHubNode, stIterator)
    {
        if(pstIotHubNode->uiUseFlag)
        {
            pstIotHubNode->uiUseFlag = 2;
        }
    }
    return MOS_OK;
}

_INT Config_EndSyncIotHubDevList()
{
    _UI uiChgFlag = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_HUBIOT_NODE *pstIotHubNode    = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetIotHubMng()->stIotList, pstIotHubNode, stIterator)
    {
        if(pstIotHubNode->uiUseFlag == 2)
        {
            uiChgFlag = 1;
            pstIotHubNode->uiUseFlag = 0;
        }
    }
    if(uiChgFlag)
        Config_GetItemSign()->ucSaveIotHub = 1;
    return MOS_OK;
}

ST_CFG_HUBIOT_NODE* Config_FindAndCreatIotForHub(_UI uiKjIoTType,_LLID lluKjIoTId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_HUBIOT_NODE *pstIotHubNode    = MOS_NULL;
    ST_CFG_HUBIOT_NODE *pstIotHubTmpNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Config_GetIotHubMng()->stIotList, pstIotHubNode, stIterator)
    {
        if(pstIotHubNode->uiUseFlag && pstIotHubNode->uiKjIoTType == uiKjIoTType && pstIotHubNode->lluKjIoTId == lluKjIoTId)
        {
            pstIotHubNode->uiUseFlag = 1;
            return pstIotHubNode;
        }
        else if(pstIotHubNode->uiUseFlag == 0)
        {   
            pstIotHubTmpNode = pstIotHubNode;
        }
    }
    if(pstIotHubTmpNode == MOS_NULL)
    {
        pstIotHubTmpNode = (ST_CFG_HUBIOT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_HUBIOT_NODE));
        MOS_LIST_ADDTAIL(&Config_GetIotHubMng()->stIotList, pstIotHubTmpNode);
    }
    pstIotHubTmpNode->uiPowerLevel  = 100;
    pstIotHubTmpNode->uiOpenFlag    = 1;
    pstIotHubTmpNode->uiEnableFlag  = 1;
    pstIotHubTmpNode->uiKjIoTType   = uiKjIoTType;
    pstIotHubTmpNode->lluKjIoTId    = lluKjIoTId;
    pstIotHubTmpNode->aucIotName[0] = 0;
    if(pstIotHubTmpNode->pucProp)
    {
        MOS_MEMSET(pstIotHubTmpNode->pucProp,0,pstIotHubTmpNode->uiPropBuffLen);
    }
    pstIotHubTmpNode->uiUseFlag = 1;
    Config_GetItemSign()->ucSaveIotHub = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub add KjIot[%u %llu]",uiKjIoTType,lluKjIoTId);
    return pstIotHubTmpNode;
}

_INT Config_AddIotToHub(_UI uiKjIoTType,_LLID lluKjIoTId)
{
    ST_CFG_HUBIOT_NODE *pstIotHubNode = Config_FindAndCreatIotForHub(uiKjIoTType,lluKjIoTId);
    if(pstIotHubNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    return MOS_OK;
}

//
_INT Config_AddIotToHubEx(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucIotName,_UI uiOpenFlag,_UC *pucProp)
{
    MOS_PARAM_NULL_RETERR(pucIotName);
    MOS_PARAM_NULL_RETERR(pucProp);

    _UI uiPropLen = MOS_STRLEN(pucProp);
    ST_CFG_HUBIOT_NODE *pstIotHubNode = Config_FindAndCreatIotForHub(uiKjIoTType,lluKjIoTId);
    
    pstIotHubNode->uiOpenFlag  = uiOpenFlag;
    MOS_MEMCPY(pstIotHubNode->aucIotName, pucIotName,128);

    Mos_MutexLock(&Config_GetIotHubMng()->hMutex);
    if(uiPropLen > pstIotHubNode->uiPropBuffLen)
    {
        MOS_FREE(pstIotHubNode->pucProp);
        pstIotHubNode->uiPropBuffLen = uiPropLen + 128;
        pstIotHubNode->pucProp = (_UC*)MOS_MALLOC(pstIotHubNode->uiPropBuffLen);
    }
    MOS_STRNCPY(pstIotHubNode->pucProp, pucProp, pstIotHubNode->uiPropBuffLen);
    Mos_MutexUnLock(&Config_GetIotHubMng()->hMutex);
    Config_GetItemSign()->ucSaveIotHub      = 1;
    Config_GetItemSign()->ucCfgIotHubUpdate = 1;
    return MOS_OK;
}

_INT Config_DeleteIotFromHub(_UI uiKjIoTType,_LLID lluKjIoTId)
{
    ST_CFG_HUBIOT_NODE *pstIotHubNode = Config_FindIotForHub(uiKjIoTType,lluKjIoTId);
    if(pstIotHubNode == MOS_NULL)
    {
        Config_GetItemSign()->ucSaveIotHub      = 1;
        return MOS_OK;
    }
    pstIotHubNode->uiUseFlag = 0;
    Config_GetItemSign()->ucSaveIotHub      = 1;
    Config_GetItemSign()->ucCfgIotHubUpdate = 1;
    return MOS_OK;
}

_INT Config_SetIotPropInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucProp)
{
    MOS_PARAM_NULL_RETERR(pucProp);

    _UI uiPropLen = MOS_STRLEN(pucProp);
    ST_CFG_HUBIOT_NODE *pstIotHubNode = Config_FindIotForHub(uiKjIoTType,lluKjIoTId);

    if(pstIotHubNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    Mos_MutexLock(&Config_GetIotHubMng()->hMutex);
    if(MOS_STRCMP(pstIotHubNode->pucProp, pucProp) == 0)
    {
        Mos_MutexUnLock(&Config_GetIotHubMng()->hMutex);
        return MOS_OK;
    }
    if(uiPropLen > pstIotHubNode->uiPropBuffLen)
    {
        MOS_FREE(pstIotHubNode->pucProp);
        pstIotHubNode->uiPropBuffLen = uiPropLen + 128;
        pstIotHubNode->pucProp = (_UC*)MOS_MALLOCCLR(pstIotHubNode->uiPropBuffLen);
    }
    MOS_STRNCPY(pstIotHubNode->pucProp, pucProp, pstIotHubNode->uiPropBuffLen);
    Mos_MutexUnLock(&Config_GetIotHubMng()->hMutex);

    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub Set KjIot[%u %llu] prop %s",uiKjIoTType,lluKjIoTId,pucProp);  
    Config_GetItemSign()->ucSaveIotHub = 1;
    Config_GetItemSign()->ucCfgIotHubUpdate = 1;
    return MOS_OK;
}

_INT Config_SetIotEnableFlagInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiEnableFlag)
{
    ST_CFG_HUBIOT_NODE *pstKjIoTNode = Config_FindIotForHub(uiKjIoTType,lluKjIoTId);
    if(pstKjIoTNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstKjIoTNode->uiEnableFlag == uiEnableFlag)
    {
        return MOS_OK;
    }
    pstKjIoTNode->uiEnableFlag = uiEnableFlag;
    Config_GetItemSign()->ucSaveIotHub      = 1;
    Config_GetItemSign()->ucCfgIotHubUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub Set KjIot[%u %llu] enalbeflag %u",uiKjIoTType,lluKjIoTId,uiEnableFlag); 
    return MOS_OK;
}

_INT Config_SetIotOpenFlagInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiOpenFlag)
{
    ST_CFG_HUBIOT_NODE *pstKjIoTNode = Config_FindIotForHub(uiKjIoTType,lluKjIoTId);
    if(pstKjIoTNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstKjIoTNode->uiOpenFlag == uiOpenFlag)
    {
        return MOS_OK;
    }
    pstKjIoTNode->uiOpenFlag = uiOpenFlag;
    Config_GetItemSign()->ucSaveIotHub = 1;
    Config_GetItemSign()->ucCfgIotHubUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub Set KjIot[%u %llu] openflag %u",uiKjIoTType,lluKjIoTId,uiOpenFlag);
    return MOS_OK;
}

_INT Config_SetIotNameInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UC *pucIotName)
{
    MOS_PARAM_NULL_RETERR(pucIotName);

    ST_CFG_HUBIOT_NODE *pstKjIoTNode = Config_FindIotForHub(uiKjIoTType,lluKjIoTId);
    if(pstKjIoTNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(MOS_STRCMP(pstKjIoTNode->aucIotName, pucIotName) == 0)
    {
        return MOS_OK;
    }
    MOS_MEMCPY(pstKjIoTNode->aucIotName, pucIotName,128);
    Config_GetItemSign()->ucSaveIotHub = 1;
    Config_GetItemSign()->ucCfgIotHubUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub Set KjIot[%u %llu] name %s",uiKjIoTType,lluKjIoTId,pucIotName);
    return MOS_OK;
}

_INT Config_SetIotPowerLevelInHub(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPowerLevel)
{
    ST_CFG_HUBIOT_NODE *pstKjIoTNode = Config_FindIotForHub(uiKjIoTType,lluKjIoTId);
    if(pstKjIoTNode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(pstKjIoTNode->uiPowerLevel == uiPowerLevel)
    {
        return MOS_OK;
    }
    pstKjIoTNode->uiPowerLevel = uiPowerLevel;
    Config_GetItemSign()->ucSaveIotHub      = 1;
    Config_GetItemSign()->ucCfgIotHubUpdate = 1;
    MOS_LOG_INF(CFG_LOGSTR,"cfg_iotHub Set KjIot[%u %llu] Power level %u",uiKjIoTType,lluKjIoTId,uiPowerLevel);
    return MOS_OK;
}

_INT Config_IotHub_Destroy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_HUBIOT_NODE *pstHubIotNode = MOS_NULL;
   
    Mos_MutexLock(&Config_GetIotHubMng()->hMutex);
    FOR_EACHDATA_INLIST(&Config_GetIotHubMng()->stIotList, pstHubIotNode, stIterator)
    {
        MOS_LIST_RMVNODE(&Config_GetIotHubMng()->stIotList, pstHubIotNode);
        MOS_FREE(pstHubIotNode->pucProp);
        MOS_FREE(pstHubIotNode);
    }
    Mos_MutexUnLock(&Config_GetIotHubMng()->hMutex);
    
    Mos_MutexDelete(&Config_GetIotHubMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR,"iotHub Destroy Ok");
    return MOS_OK;
}

/*********************************************************************************
**********************************************************************************/
_VPTR Config_BuildIotHubObject(_UI uiCfgItem)
{
    _UC aucBuff[64];
    JSON_HANDLE hProp      = MOS_NULL;
    JSON_HANDLE hArray     = MOS_NULL;
    JSON_HANDLE hArrayItem = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_HUBIOT_NODE* pstKjIoTNode = MOS_NULL;    
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Sign",Adpt_Json_CreateStrWithNum(Config_GetItemSign()->uiIotHubSign));
    
    if((uiCfgItem & EN_CFG_TYPE_ABILITY) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IoTHubAbility",Adpt_Json_CreateStrWithNum(Config_GetIotHubMng()->uiIotHubAbility));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IoTHubMaxCount",Adpt_Json_CreateStrWithNum(Config_GetIotHubMng()->uiIotMaxCount));
    }
    if((uiCfgItem & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IoTHubStatus",Adpt_Json_CreateStrWithNum(Config_GetIotHubMng()->uiIotHubStatus));

        hArray = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IoTs",hArray);    
        FOR_EACHDATA_INLIST(&Config_GetIotHubMng()->stIotList, pstKjIoTNode, stIterator)
        {
            if(pstKjIoTNode->uiUseFlag == 0)
            {
                continue;
            }
            hArrayItem = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hArray,hArrayItem);
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstKjIoTNode->uiKjIoTType));
            MOS_VSNPRINTF(aucBuff, 64,(_UC*)"%llu",pstKjIoTNode->lluKjIoTId);
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"IoTName",Adpt_Json_CreateString(pstKjIoTNode->aucIotName));
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"OpenFlag",Adpt_Json_CreateStrWithNum(pstKjIoTNode->uiOpenFlag));
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Enable",Adpt_Json_CreateStrWithNum(pstKjIoTNode->uiEnableFlag));
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"PowerLevel",Adpt_Json_CreateStrWithNum(pstKjIoTNode->uiPowerLevel));
            
            Mos_MutexLock(&Config_GetIotHubMng()->hMutex);
            if(pstKjIoTNode->pucProp != MOS_NULL)
            {
                hProp = Adpt_Json_Parse(pstKjIoTNode->pucProp);
                Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Prop",hProp);
            }
            Mos_MutexUnLock(&Config_GetIotHubMng()->hMutex); 
        }
    }
    return hRoot;
}

_UC* Config_BuildIotHubJson(_UI uiCfgItem)
{
    _UC *pucStrTmp = MOS_NULL;
    
    JSON_HANDLE hRoot = Config_BuildIotHubObject(uiCfgItem);

    pucStrTmp = Adpt_Json_Print(hRoot);
    
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(CFG_LOGSTR,"build KjIothub info %s",pucStrTmp);
    
    return pucStrTmp;
}

// 读取拓展IOT配置的字段
_INT Config_ParseIotHubJson(_UC *pucHubJson,_UI uiCfgItem)
{
    MOS_PARAM_NULL_RETERR(pucHubJson);

    _UC *pStrTmp = MOS_NULL;
    _INT i, iArraySize = 0;
    _UI uiKjIoTType  = 0,uiPropLen = 0;
    _LLID lluKjIotId = 0;
    JSON_HANDLE hProp      = MOS_NULL;
    JSON_HANDLE hArray     = MOS_NULL;
    JSON_HANDLE hArrayItem = MOS_NULL;
    ST_CFG_HUBIOT_NODE* pstIotHubNode = MOS_NULL;
    JSON_HANDLE hRoot      = Adpt_Json_Parse(pucHubJson);
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Sign"),(_INT*)&Config_GetItemSign()->uiIotHubSign);
    if((uiCfgItem & EN_CFG_TYPE_ABILITY) > 0)
    {
        // 是否扩展IoT能力 0.不支持； 1.支持
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IoTHubAbility"),(_INT*)&Config_GetIotHubMng()->uiIotHubAbility);
        // 拓展IOT hub个数
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IoTHubMaxCount"),(_INT*)&Config_GetIotHubMng()->uiIotMaxCount);
    }
    if((uiCfgItem & EN_CFG_TYPE_BUSSNESS) > 0)
    {
        // 是否插入了Hub状态,若没有扩展IoT能力，无此项
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"IoTHubStatus"),(_INT*)&Config_GetIotHubMng()->uiIotHubStatus); 
        // 拓展IOT属性
        hArray = Adpt_Json_GetObjectItem(hRoot,(_UC*)"IoTs");
        iArraySize = Adpt_Json_GetArraySize(hArray);
        for(i = 0 ; i < iArraySize; i++)
        {   
            hArrayItem = Adpt_Json_GetArrayItem(hArray,i);
            // 拓展IOT设备类型
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
            // 设备ID
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTID"),&pStrTmp);
            MOS_SSCANF(pStrTmp, "%llu",&lluKjIotId);
            pstIotHubNode = Config_FindAndCreatIotForHub(uiKjIoTType,lluKjIotId);

            // IoT设备信号是否正常  0.不正常，1.正常
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"IoTName"),&pStrTmp);
            MOS_STRNCPY(pstIotHubNode->aucIotName, pStrTmp, sizeof(pstIotHubNode->aucIotName));

            // 设备是否开启使用 0.关闭；1.打开
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"OpenFlag"),(_INT*)&pstIotHubNode->uiOpenFlag);
            // IoT设备信号是否正常 0.不正常，1.正常
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Enable"),(_INT*)&pstIotHubNode->uiEnableFlag);
            // 电源电量
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PowerLevel"),(_INT*)&pstIotHubNode->uiPowerLevel);

            // 拓展IOT的属性
            hProp = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Prop");
            if(hProp)
            {
                pStrTmp = Adpt_Json_Print(hProp);
                 
                Mos_MutexLock(&Config_GetIotHubMng()->hMutex);
                if(uiPropLen > pstIotHubNode->uiPropBuffLen)
                {
                    MOS_FREE(pstIotHubNode->pucProp);
                    pstIotHubNode->uiPropBuffLen = uiPropLen + 128;
                    pstIotHubNode->pucProp = (_UC*)MOS_MALLOCCLR(pstIotHubNode->uiPropBuffLen);
                }
                MOS_STRNCPY(pstIotHubNode->pucProp, pStrTmp, pstIotHubNode->uiPropBuffLen);
                Mos_MutexUnLock(&Config_GetIotHubMng()->hMutex);
                
                MOS_FREE(pStrTmp);
            }
        }
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}



