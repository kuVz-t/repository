#ifndef _CONFIG_SYNC_H
#define _CONFIG_SYNC_H

typedef enum
{
    EN_CFG_METHOD_NONE   = 0,
    EN_CFG_METHOD_GET    = 1,
    EN_CFG_METHOD_GETRSP = 2,
    EN_CFG_METHOD_SET    = 3,
    EN_CFG_METHOD_SETRSP = 4
}EN_CFG_METHOD;

typedef enum
{
    EN_CFG_STATUS_OK       = 0,
    EN_CFG_NOUPDATE = 1,

}EN_CFG_RSPSTATUS;


typedef enum enum_SERVER_NODE_STATUS
{
    EN_SERVER_NODE_NONE      = 0,
    EN_SERVER_NODE_START     = 1,
    EN_SERVER_NODE_PROC      = 2,
    EN_SERVER_NODE_FINISH    = 3
}EN_SERVER_NODE_STATUS;

typedef struct stru_CFG_SERVER_NODE
{
    _UC ucStatus;  // EN_SERVER_NODE_STATUS
    _UC ucMsgType;
    _UC ucMsgId;  
    _UC ucRsv;
    _UI uiOgctId;
    _UI uiReqTime;
    _UI uiCfgItem;
    _VPTR hJsonRoot;
    ST_MOS_LIST_NODE stNode;  
}ST_CFG_SERVER_NODE;

typedef struct ST_CFG_SYNC_NODE
{
    _UC ucStatus; // 1 请求 2 请求 ing  3 结束
    _UC ucMsgType;
    _UC ucMsgId;
    _UC ucTryCount;
    _UI uiOgctId;
    _UI uiCfgItem;
    _UI uiMsgLen;
    _UC *pucMsgBuff;
    _UI uiReqTime;
    _UC  aucPeerId[CFG_STRING_COMMONLEN+4];
    ST_MOS_LIST_NODE stNode;  
}ST_CFG_SYNC_NODE;

//lognode
typedef struct stru_CFG_LOG_SYNC_NODE
{
    _UC ucStatus;  // 1.发送2.发送中3.完成 0.节点空
    _UC ucMsgType;
    _UC ucMsgId; 
    _UI uiOgctId;
    _UI uiReqTime;
    _UI uiMsgLen;
    _UC *pucMsgBuff;
    ST_MOS_LIST_NODE stNode;  
}ST_CFG_LOG_SYNC_NODE;

/*******************************************************************
                    和服务器交互的配置 
********************************************************************/ 
_INT Config_AddSyncServerCfgTask(_UC ucMsgType,_UC ucMsgId,_UI uiCfgItem,_VPTR hJsonRoot);

ST_CFG_SERVER_NODE *Config_FindSyncServNodeById(_UI uiOgctId);

_VOID Config_ProcSyncServStatus(_UI uiNowTime);

/*******************************************************************
                    和设备交互的配置 
********************************************************************/

ST_CFG_SYNC_NODE *Config_AllocSyncClientNode();

_INT Config_AddSyncClientNode(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_UI uiOgctId,_UC *pucBody,_UI uiMsgLen);

_VOID Config_ProcSyncClientList(_UI uiNowTime); 

/*******************************************************************
                    和到log服务器的交互 
********************************************************************/
//_INT Config_AddSyncLogCfgTask(_UC ucMsgType,_UC ucMsgId,_UI uiOgctId,_UC* pucBody,_UI uiMsgLen);

//ST_CFG_LOG_SYNC_NODE *Config_FindSyncLogNodeById(_UI uiOgctId);

//_VOID Config_ProcSyncLogStatus(_UI uiNowTime);

#endif

