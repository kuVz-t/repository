/*******************************************************************
 *	Copyright(c) 2022 ChinaTelecom
 *  All rights reserved.
 *	
 *  Date     : 2022/10/14
 *	FileName : http_type.h
 *	Describe : http内部模块文件，定义Http模块相关变量、结构体等
 *	Author   : 
 ******************************************************************/
#ifndef _HTTP_TYPE_H_
#define _HTTP_TYPE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"
#include "adpt_ssl_adapt.h"

#define HTTP_LOGSTR "HTTP"
#define HTTP_HEADER_SIZE        4096
#define HTTP_SEND_BUFFER_SIZE   (16 * 1024)
#define HTTP_RECV_BUFFER_SIZE   (16 * 1024)
#define HTTP_SOCKET_BUFFER_SIZE (32 * 1024)
#define HTTP_LOG_FLAG 0
#define HTTP_LOG_FORMAT_1       "\n****************************-[HTTP]-***************************\n"
#define HTTP_LOG_FORMAT_2       "\n****************************-[END]-****************************\n"
#define HTTP_LOG_INF(_pucFormat, ...)  if (HTTP_LOG_FLAG){_UC aucStrTmp[256] = {0};MOS_SPRINTF(aucStrTmp, "%s%s%s", HTTP_LOG_FORMAT_1,_pucFormat,HTTP_LOG_FORMAT_2); Mos_LogPrintf((_UC *)_MOS_FUNC, _MOS_LINE, (_UC *)HTTP_LOGSTR,\
                                                                EN_LOG_LVL_INFO, (_UC *)aucStrTmp, ##__VA_ARGS__);}
#define HTTP_LOG_ERR(_pucFormat, ...)  if (HTTP_LOG_FLAG){_UC aucStrTmp[256] = {0};MOS_SPRINTF(aucStrTmp, "%s%s%s", HTTP_LOG_FORMAT_1,_pucFormat,HTTP_LOG_FORMAT_2); Mos_LogPrintf((_UC *)_MOS_FUNC, _MOS_LINE, (_UC *)HTTP_LOGSTR,\
                                                                EN_LOG_LVL_ERR, (_UC *)aucStrTmp, ##__VA_ARGS__);}     

typedef enum enum_HTTP_METHOD{
    EN_HTTP_METHOD_GET,
    EN_HTTP_METHOD_POST,
    EN_HTTP_METHOD_PUT
} EN_HTTP_METHOD;

typedef enum enum_HTTP_COMPLETE_STATUS{
    EN_HTTP_COMPLETE_NONE,             /*未完成*/     
    EN_HTTP_COMPLETE_SUCCESS,          /*完成,成功*/
    EN_HTTP_COMPLETE_FAILED,           /*完成,失败*/
} EN_COMPLETE_STATUS;

typedef enum enum_HTTP_ERR_CODE{
    EN_HTTP_TRY_AGAIN   = -100,
} EN_HTTP_ERR_CODE;

typedef struct stru_HTTP_PRASE_HEAD
{
    _INT iChunkFlag;
    _INT iResultCode;
    _INT iContentLength;
    _UC ucRedirectUrl[512];
    _UC ucWWWAuthenticate[512];
}ST_HTTP_PRASE_HEAD;

typedef _VOID (*PFN_RECV)(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId);
typedef _VOID (*PFN_RECV_HEADER)(_VPTR vpUserPtr, _UI uiReqId, ST_HTTP_PRASE_HEAD stHttpParseHead);
typedef _VOID (*PFN_FINISHED)(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime);
typedef _VOID (*PFN_FAILED)(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime);
typedef _INT (*PFN_GET_DATA)(_VPTR vpUserPtr, _UC* pucData, _UI uiMaxDataLen, _UI uiReqId);

typedef struct
{
    _UC* pucHost;                        /*http请求域名*/
    _UC* pucUrl;                         /*http请求地址*/
    _INT iPort;                          /*http请求端口，如果无，默认http:80 https:443*/
    _UI uiConnectType;                   /*http连接类型 EN_MOS_INET_TYPE */
    ST_MOS_INET_IPARRAY stIpArrayInfo;   /*http请求域名对应的ip数组信息*/

    PFN_RECV pfuncRecv;                  /*http回调，数据接收函数*/
    PFN_FINISHED pfuncFinished;          /*http回调，接收完成函数*/
    PFN_FAILED pfuncFailed;              /*http回调，接收失败函数*/
    PFN_GET_DATA pfuncGetData;           /*http回调，获取发送数据函数*/
    PFN_RECV_HEADER pfuncRecvHeader;     /*http回调，http头部接收函数*/

    _VPTR vpUserPtr;                     /*应用层使用*/
    _UI* puiHandler;                     /*模块内部使用uiReqId替代作用*/
    _UC* pucContent;                     /*待发送数据内容*/
    _UI uiContentLen;                    /*待发送数据长度 大数据发送也需要一次性给出数据长度*/
    _UC* pucExpandHeader;                /*扩展头部字段*/
    _UC* pucTmpBuff;                     /*用于缓存pfuncGetData数据*/
    _UI uiTmpBuffLen;                    /*pfuncGetData数据长度*/

    _UI  uiSSLFlag;                      /*是否走https标志*/
    _SOCKET hSocket;                     /*备用网络句柄, 不操作释放*/
    void *  hSSL;                        /*https句柄*/

    _UI  uiStartTime;                    /*http请求开始时间(毫秒)*/
    _INT iTimeOut;                       /*超时时间，包括整个http请求*/
    _INT iSendPos;                       /*已发送数据的索引，用于分段发送*/
    _INT iChunkFlag;                     /*接收的数据是否是chunk类型*/
    _INT iHeaderIndex;                   /*aucHeader数组的索引*/
    _UC  aucHeader[HTTP_HEADER_SIZE];    /*用于存储http头部或chunk头部*/
    _INT iReservLen;                     /*RECV剩余长度*/
    _INT iMethod;                        /*http方法字*/
    _UI  uiReqId;                        /*http请求序号*/
    _INT iResultCode;                    /*http响应状态码*/
    _INT iRetCode;                       /*http发送状态标志*/
} ST_HTTP_NODE;

#ifdef __cplusplus
}
#endif

#endif
