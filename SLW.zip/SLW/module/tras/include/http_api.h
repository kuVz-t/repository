/*******************************************************************
 *	Copyright(c) 2022 ChinaTelecom
 *  All rights reserved.
 *	
 *  Date     : 2022/10/18
 *	FileName : http_api.h
 *	Describe : http对外文件，向业务层提供相关结构体与加密接口等
 *	Author   : 
 ******************************************************************/
#ifndef HTTP_API_H
#define HTTP_API_H

#ifdef __cplusplus
extern "C" {
#endif

#define HTTP_DEBUG 1
#include "mos.h"
#include "adpt_crypto_adapt.h"

#define TRASLOG_STR            "TS"
#define CFG_STRING_LEN         64
#define MAGIC_HEAD             0x2324     /* 包头部 #$ */
#define PACKET_LEN             8          /* 包头长度 */
#define PAKCET_MAX_SIZE        256        /* 定义包的最大值 */

typedef enum enum_HTTP_STREAMER_TYPE{
    EN_HTTP_STREAMER_VIDEO   = 0X01,
    EN_HTTP_STREAMER_AUDIO   = 0X02,
    EN_HTTP_STREAMER_AV      = 0X03
}EN_HTTP_STREAMER_TYPE;

#pragma pack (1)
typedef struct stru_OGCT_PROTOCAL_HEAD{
    _UC aucheck[2]; // 起始字 2字节 摄像头报文交互头为:#$
    _UC ucMsgType;  // 类型字 1字节 用来区分报文的类型
    _UC ucMsgId;    // 方法字 1字节 用来区分报文的方法
    _US usBodyLen;  // 后面body数据长度 2字节 网络字节序,报文长度
    _UC ucEncFlag;  // 加密标记字 1字节 用来表示报文数据的加密模式
    _UC ucRsv;      // 保留字 1字节  =0,保留
}ST_OGCT_PROTOCAL_HEAD;

//media header
typedef struct stru_MEDIA_PROTOCAL_HEAD
{
    _US  usChannel;   //网络字节序，当前流媒体通道号。用来归属一个流的数据。
    _US  usSeqId;     //网络字节序，报文打包序列号。用来判断丢包和乱序。
    _UC  ucFrameType; //类型：高4位标识帧类型：  I帧：1标识I帧/0标识P帧  低4位依次为：帧开始、帧结束、NAL开始、NAL结束；
    _UC  ucAVType;    //用来区分媒体数据类型：1.视频；2.音频；
    _INT iFrameLen;    //Frame帧长度；网络字节序。
    _INT iTimeStamp;   //网络字节序，帧的时间戳，当天的毫秒数。
    _UC aucMsgBody[0];
}ST_MEDIA_PROTOCAL_HEAD;


typedef struct stru_MEDIA_PROTOCAL_HEAD2{
    _US  usChannel;   //网络字节序，当前流媒体通道号。用来归属一个流的数据。
    _US  usSeqId;     //网络字节序，报文打包序列号。用来判断丢包和乱序。
    _UC  ucFrameType; //类型：高4位标识帧类型：  I帧：1标识I帧/0标识P帧  低4位依次为：帧开始、帧结束、NAL开始、NAL结束；
    _UC  ucAVType;    //用来区分媒体数据类型：1.视频；2.音频；
    _UC aucMsgBody[0];
}ST_MEDIA_PROTOCAL_HEAD2;

#pragma pack ()
typedef struct stru_http_ENCRYPTO_INF
{
    _INT iEncType;
    _UC aucEncKey[36];
    _UC aucEncLv[24];
    _HCRYPTOCTX hCryptoCtx; // 低级加密句柄
}ST_HTTP_ENCRYPTO_INF;


/* 打印BUF */
#define BUF_PRINTF(name, buf, len) \
        do {\
        printf("------------------%s[%d]------------------\r\n", (name), (len)); \
        int i = 0; \
        for(i = 0; i < (len); i++){ \
            printf("%02x", (unsigned char)(buf)[i]); \
        } \
        printf("\r\n---------------------------------------\r\n");\
        } while(0);
        
/* 打印内存格式的BUF */
#define BUF_PRINTF_EX(name, buf, len) \
        do {\
        printf("------------------%s[%d]------------------\r\n", (name), (len)); \
        int i = 0; \
        for(i=0;i<len;i++) {\
            printf("%02x",(unsigned char)(buf)[i]); \
        }\
        printf("---------------------------------------\r\n");\
        } while(0);

/* u16转u8 buf */
#define U16_TO_U8S(u16, u8_buf) \
        *(u8_buf) = (unsigned char)(((u16) & 0xff00) >> 8); \
        *(u8_buf + 1) = (unsigned char)(((u16) & 0x00ff));

/* u32转u8 buf */
#define U32_TO_U8S(u32, u8_buf) \
        *(u8_buf) = (unsigned char)(((u32) & 0xff000000) >> 24); \
        *(u8_buf + 1) = (unsigned char)(((u32) & 0x00ff0000) >> 16); \
        *(u8_buf + 2) = (unsigned char)(((u32) & 0x0000ff00) >> 8); \
        *(u8_buf + 3) = (unsigned char)(((u32) & 0x000000ff));

/* u8 buf转u8 */
#define U8S_TO_U8(u8_buf, u8) \
        (u8) |= (unsigned char)(*(u8_buf));

/* u8 buf转u16 */
#define U8S_TO_U16(u8_buf, u16) \
        (u16) |= (unsigned short)(*(u8_buf) << 8); \
        (u16) |= (unsigned short)(*(u8_buf + 1));

/* u8 buf转u32 */
#define U8S_TO_U32(u8_buf, u32) \
        (u32) |= (unsigned int)(*(u8_buf) << 24); \
        (u32) |= (unsigned int)(*(u8_buf + 1) << 16); \
        (u32) |= (unsigned int)(*(u8_buf + 2) << 8); \
        (u32) |= (unsigned int)(*(u8_buf + 3));

/************************************/
_INT Http_EncMsgHead(ST_OGCT_PROTOCAL_HEAD *pstProtoHead,_UC ucMsgType,_UC ucMsgId,_US usBodyLen, _INT iEncType);
_INT Http_EncMsgBody(ST_OGCT_PROTOCAL_HEAD *pstProtoHead,_UC *pucMsgBody,_INT iMsgBodyLen,ST_HTTP_ENCRYPTO_INF *pstEncryInf, _UC *pucOutputBuf, _INT *iOutputBufLen);
_INT Http_EncMsgBody2(ST_OGCT_PROTOCAL_HEAD *pstProtoHead,_UC *pucMsgBody,_INT iMsgBodyLen,ST_HTTP_ENCRYPTO_INF *pstEncryInf, _UC *pucOutputBuf, _INT *iOutputBufLen);
_INT Http_DecMsgBody(_UC ucEncFlag, _UC* pucInOutBody, _INT iLen, ST_HTTP_ENCRYPTO_INF *pstEncryInf);
_INT Http_DecMsgBodyMedia(_UC ucEncFlag, _UC* pucInOutBody, _INT iLen, ST_HTTP_ENCRYPTO_INF *pstEncryInf);

/*****************-保留接口,暂不使用-*******************/
_INT Http_SendDataToPeer(_UC pucPeerId,_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen);
_INT Http_SendPrivateData(_UC pucPeerId, _UC *pucData, _UI uiDatalen);
_INT Http_DirectConnectPeer(_UC *pucPeerIp);
_INT Http_SetDevicGroupId(_UC *pucGroupId);
_INT Http_SetDevJoinGroupFlag(_UC *pucBindId,_UC *pucJoinGroup);
_INT Http_ClearServersAddr();
_INT Http_SetP2PLinkEncryKeyInf(_UC *pucPeerId,_INT iEncType,_UC *pucEncKey,_UC *pucEncLv);

#ifdef __cplusplus
}
#endif

#endif