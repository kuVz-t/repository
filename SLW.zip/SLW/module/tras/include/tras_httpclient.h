/*******************************************************************
 *	Copyright(c) 2022 ChinaTelecom
 *  All rights reserved.
 *	
 *  Date     : 2022/10/18
 *	FileName : tras_httpclient.h
 *	Describe : http对外文件，为业务层提供HTTP请求接口。
 *	Author   : 
 ******************************************************************/
#ifndef _TRAS_HTTPCLIENT_H_
#define _TRAS_HTTPCLIENT_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "http.h"
#include "http_type.h"

typedef struct
{
    _INT iTimeOut;                          /*超时时间*/
    PFN_RECV pfuncRecv;                     /*HTTP内容接收回调*/
    PFN_FINISHED pfuncFinished;             /*HTTP接收结束回调*/
    PFN_FAILED pfuncFailed;                 /*HTTP接收失败回调*/
    PFN_GET_DATA pfuncGetData;              /*HTTP获取发送数据回调  每次返回4096字节 还有数据返回1 无数据返回0，错误返回-1*/
    PFN_RECV_HEADER pfuncRecvHeader;        /*HTTP接收头部回调*/
    _VPTR vpUserPtr;                        
    // _UI* puiHandler;
    _UC* pucContent;                        /*HTTP待发送数据*/
    _UI  uiContentLen;                      /*HTTP待发送数据长度 大数据发送也需要一次性给出数据长度*/
    _UC* pucExpandHeader;                   /*HTTP头部扩展字段 单个Header字段请用\r\n结尾, 多个Header字段组合用\r\n间隔,\r\n结尾*/

    _UI  uiSSLFlag;                         /*0:http 1:https*/
} ST_HTTP_INFO_NODE;

/*******************************
 * Param    : 解析url
 * Return   : 无
 * Describe : 从完整的url解析出主机
 *            域名、文件路径和ssl标志
 *            注意pucHost包含端口信息
*********************************/
_INT Http_Parse_Url(_UC *pucUrl, _UC *pucHost, _UC *pucFile, _INT *piSslFlag);

/*******************************
 * Param    : 默认配置结点
 * Return   : 无
 * Describe : 获取HTTP请求默认配置
 *            部分参数需要重新设定
*********************************/
_INT Http_GetDefaultConfig(ST_HTTP_INFO_NODE *pstNode);

/*******************************
 * Param    : ST_HTTP_INFO_NODE(默认配置结点) pucHost(主机域名) 
 *            pucUrl（资源地址） iMethod（方法字） uiReqId（序号） 
 * Return   : 成功：MOS_OK 失败：MOS_ERR
 * Describe : HTTP异步请求接口
*********************************/
_INT Http_SendAsyncRequest(ST_HTTP_INFO_NODE *pstNode, _UC* pucHost, _UC* pucUrl, _INT iMethod, _UI uiReqId);

/*******************************
 * Param    : ST_HTTP_INFO_NODE(默认配置结点) pucHost(主机域名) 
 *            pucUrl（资源地址） iMethod（方法字） uiReqId（序号） 
 * Return   : 成功：MOS_OK 失败：MOS_ERR
 * Describe : HTTP同步请求接口
*********************************/
_INT Http_SendSyncRequest(ST_HTTP_INFO_NODE *pstNode, _UC* pucHost, _UC* pucUrl, _INT iMethod, _UI uiReqId);

 /*******************************
 * Param    : uiReqId（请求序号） 
 * Return   : 成功：MOS_OK 失败：MOS_ERR
 * Describe : 取消HTTP请求接口
 *            HTTP线程会回调fail回调
*********************************/
 _INT Http_Httpclient_CancelAsyncRequestEx(_UI uiReqId);


#ifdef __cplusplus
}
#endif

#endif
