#ifndef _HTTP_MEDIA_H_
#define _HTTP_MEDIA_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "http_api.h"
#include "zj_func.h"

typedef enum enum_HTTP_STREAM_EVENT_OPTION{
    EN_HTTP_STREAM_EVENT_OPTION_CREATE_REQ       = 0,
    EN_HTTP_STREAM_EVENT_OPTION_CREATE_RSP       = 1,
    EN_HTTP_STREAM_EVENT_OPTION_PARAM_NODATA     = 2,
    EN_HTTP_STREAM_EVENT_OPTION_PARAM_COMPLETE   = 3,
    EN_HTTP_STREAM_EVENT_OPTION_CAMPICS_REQ      = 4,
    EN_HTTP_STREAM_EVENT_OPTION_CAMPICS_RSP      = 5,
    EN_HTTP_STREAM_EVENT_OPTION_TEARDOWN_REQ     = 6,
    EN_HTTP_STREAM_EVENT_OPTION_NEEDIFRAME_REQ   = 7
}EN_HTTP_STREAM_EVENT_OPTION;

// 返回 0 表示正常 -1 表示超过最大连接数
typedef _INT (*PFUN_NTYSTREAMSTATUS)(_UC* pucPeerID, _UI uiSessionID, _UI uiOption, _INT iOptCode);
typedef _INT (*PFUN_DOWNFILESTATUSCB)(_UI uiSessionID, _UC* pucData, _UI uiJpegLen, _INT iErr);

_INT Http_SetPeerRelayMode(_UC *pucPeerID,_UI uiOpenFlag);

_INT Http_SetPlayStreamNoticeCB(PFUN_NTYSTREAMSTATUS pfunStreamNotice);
_INT Http_SetDownFileStatusCB(PFUN_DOWNFILESTATUSCB pFunDownFileStatusCb);

_INT Http_GetPlayStreamType(_UC *pucPeerID,_UI uiSessionID,_UI *puiMediaType, _UI *puiStreamType);
_INT Http_GetPlayStreamAndMicInf(_UC* pucPeerID,_UI uiSessionID,_INT *piCamId,_INT *piStreamId,_INT *piMicId);

_UI Http_CreateLiveStream(_UC* pucPeerID, _INT iCamID, _INT iStreamID, _INT iAudioFlag);
_UI Http_CreatPushStream(_UC* pucPeerId,_INT iCamId,_INT iStreamId,_INT iAudioFlag);
_UI Http_CreateRecordStream(_UC* pucPeerID, _INT iCamID, _UC* pucPlayTime,_INT iDownFlag);
_INT Http_GetRecordJustTime(_UC* pucPeerID, _UI uiSessionID);

_UI Http_ReqAliveJpeg(_UC* pucPeerID, _INT iCamID, _INT iPicType);

_UI Http_ReqOneJpegFile(_UC* pucPeerID, _INT iCamID, _UC* pucEventName);

_UI Http_CollectLogFiles(_UC* pucPeerID,_UC *pucFilePath);

_UI Http_PushSoundFile(_UC* pucPeerID,_UC *pucFullName);
    
_INT Http_PausePlay(_UC* pucPeerID, _UI uiSessionID, _UI uiAvFlag);
_INT Http_ResumePlay(_UC* pucPeerID, _UI uiSessionID, _UI uiAvFlag);
_INT Http_StopPlay(_UC* pucPeerID, _UI uiSessionID);
_INT Http_SetPlayTime(_UC* pucPeerID, _UI uiSessionID, _UI uiTimeSecond);
_INT Http_GetKeyFrame(_UC* pucPeerID, _UI uiSessionID);

// 同意请求，开始发送媒体流数据；
_INT Http_AcceptSession(_UC* pucPeerID, _UI uiSessionID, _UI uiAcceptState);

_INT Http_SetCollectLogFileStatus(_UC* pucPeerID, _UI uiSessionID, _UI uiStatus,_UC *pucFileName);

_INT Http_GetCurSessionsTTLTime(ST_ZJ_SESSION_TTL_INFO astSessionTTLs[8],_INT *piSessionCnt);

#ifdef __cplusplus
}
#endif

#endif
