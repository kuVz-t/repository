//
//  kj_aes.h
//  kj_p2p_data_transceiver
//
//  Created by de on 2020/12/29.
//

#ifndef kj_aes_h
#define kj_aes_h

#include <stdio.h>
#include <stdint.h>

typedef enum KJ_AES_MODE
{
    KJ_AES_128 = 1,
    KJ_AES_192,
    KJ_AES_256,
} KJAESMode;

typedef enum KJ_AES_PADDINGTYPE
{
    KJ_AES_NOPadding = 1,
    KJ_AES_Pkcs7Padding,
    KJ_AES_ZeroPadding,
    KJ_AES_NewPadding
} KJAESPaddingType;

//用完需要free
uint8_t* kj_aes_encrypt_cbc(uint8_t* buf, uint32_t* length, uint8_t* no_padding_output_buf, const uint8_t* key, const uint8_t* iv,KJAESPaddingType padding, uint8_t type);

//用完需要free
uint8_t* kj_aes_decrypt_cbc(char* buf, uint32_t* length, const uint8_t* key, const uint8_t* iv,KJAESPaddingType padding, uint8_t type);


#endif /* kj_aes_h */
