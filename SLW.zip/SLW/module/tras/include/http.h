/*******************************************************************
 *	Copyright(c) 2022 ChinaTelecom
 *  All rights reserved.
 *	
 *  Date     : 2022/10/18
 *	FileName : http.h
 *	Describe : HTTP模块事件处理主程序
 *	Author   : 
 ******************************************************************/
#ifndef __TRAS_HTTP_H_
#define __TRAS_HTTP_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/epoll.h>
#include "http_type.h"
#include "kj_timer.h"

typedef enum
{
    EN_TRAS_PROTOCOL_HTTP = 0               /*HTTP协议*/
} EN_TRAS_PROTOCOL;

typedef enum
{
    EN_HTTP_STATUS_IDLE         = 0,              /*初始状态创建socket*/
    EN_HTTP_STATUS_CONNECT      = 1,              /*等到连接成功状态*/
    EN_HTTP_STATUS_HANDLE       = 2,              /*HTTP连接成功*/
    EN_HTTP_STATUS_FINISH       = 3,              /*HTTP请求完成*/
    EN_HTTP_STATUS_FAIL         = 4,              /*HTTP请求失败*/
    EN_HTTP_STATUS_TIMEOUT      = 5,              /*HTTP请求超时*/
} EN_HTTP_STATUS;

typedef enum
{
    EN_HTTP_RET_ILLEGAL_PARAM_ERR = 100,           /*HTTP请求参数非法*/
    EN_HTTP_RET_NODE_MALLOC_ERR   = 101,           /*HTTP创建结点失败*/
    EN_HTTP_RET_GETHOSTBYNAME_ERR = 102,           /*HTTP域名解析失败*/
    EN_HTTP_RET_GETIPINFO_ERR     = 103,           /*HTTP获取IP地址信息失败*/
    EN_HTTP_RET_SOCKETOPEN_ERR    = 104,           /*HTTP创建socket失败*/
    EN_HTTP_RET_CONNECT_ERR       = 105,           /*HTTP连接服务器失败*/
    EN_HTTP_RET_ADDEPOLL_ERR      = 106,           /*HTTP加入epoll失败*/
    EN_HTTP_RET_UNINITIALIZED_ERR = 107,           /*HTTP模块未初始化*/
    EN_HTTP_RET_COMMON_ERR        = 108,           /*HTTP请求完成（失败）*/
    EN_HTTP_RET_TIMEOUT           = 109,           /*HTTP请求服务器timeout*/
} EN_HTTP_RET_CODE;

// HTTP模块管理结点
typedef struct
{
    _INT            iEpollFd;
    _HTHREAD        hExtThread;
    _HMUTEX         hTaskMutex;
    _INT            iRunFlag;
    _INT            iInitFlag;
    _INT            iNetStatus;
    ST_MOS_LIST     stHttpNodeList;
} ST_HTTP_MGR;

// HTTP结点，EPOLL监听层
typedef struct stru_HTTP_MGR_NODE
{
    _INT iProtocol;
    _INT iStatus;
    _SOCKET hSocket;
    _VOID *pstHandleNode;
    _INT *piCompleteFlag;
    struct epoll_event stEvent;
    kj_timer_t tHttpNodeTimeOut;
    _ULLID ullReqTime;

    ST_MOS_LIST_NODE stNode;
}ST_HTTP_MGR_NODE;

_INT Http_Add_Fd(ST_HTTP_MGR_NODE *pstHttpMgrNode);
ST_HTTP_MGR* Http_GetMgr();

///////////////////////////////////////////////////////////////////////////
// 外部接口
///////////////////////////////////////////////////////////////////////////

_INT Http_GetNetWorkType();
_INT Http_SetNetworkType(_UC ucNetworkType);
_INT Http_Init();
_INT Http_Start();
_INT Http_Stop();
_INT Http_Destroyed();

// host/ip 转为 ip数组ST_MOS_INET_IPARRAY
// 返回值：MOS_OK成功 MOS_ERR失败
// 注意：host转ip过程，最长阻塞1秒
// 注意：pstIpArrayInfo由使用者提供，缓存ip列表
_INT Http_GetAddrArrayInfo(ST_MOS_INET_IPARRAY *pstIpArrayInfo, _UC *pucHost, _INT iDefaultPort, _INT *piOutPort);
// 从IPARRAY查找ipv4或ipv6的ip信息
ST_MOS_INET_IP *Http_GetInetIPByIpArray(ST_MOS_INET_IPARRAY *pstIpArrayInfo, _US usType);

// 创建阻塞socket连接 - 不具备设置connect超时的功能
_SOCKET Http_CreateSocketBlockAndConnect(_UC *pucHost, _INT iPort, _INT iTimeout, _UI *puiConnType, _UI *puiHasIpv6);
// 创建阻塞socket连接 - 具备设置connect超时的功能 bNoDelay默认为MOS_FALSE（注意：该接口没有设置Mos_SocketSetSendBuf的大小，使用者需要获取socket后手动设置）
_SOCKET Http_CreateSocketBlockAndConnect2(_UC *pucHost, _INT iPort, _INT iConnectTimeout, _INT iSTimeout,
                                            _INT iRTimeout, _BOOL bNoDelay, _UI *puiConnType, _UI *puiHasIpv6);

#ifdef __cplusplus
}
#endif

#endif