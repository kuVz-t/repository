/*******************************************************************
 *	Copyright(c) 2022 ChinaTelecom
 *  All rights reserved.
 *	
 *  Date     : 2022/10/18
 *	FileName : http_common.h
 *	Describe : http内部模块文件，提供HTTP发送和接收处理接口
 *	Author   : 
 ******************************************************************/
#ifndef _HTTP_COMMON_H
#define _HTTP_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"
#include "http_type.h"

typedef enum enum_HTTP_RECV_CODE{
    EN_HTTP_RECV_FINISH   = 0,                       /*状态0：接收完成*/
    EN_HTTP_RECV_CONTINUE = 1,                       /*状态1：继续读取数据*/
}EN_HTTP_RECV_CODE;

typedef enum enum_HTTP_STATUS_CODE{
    EN_HTTP_STATUS_CREATE_SSL       = 0,             /*状态0：需要创建SSL*/
    EN_HTTP_STATUS_CONNECTING       = 1,             /*状态1：连接中*/
    EN_HTTP_STATUS_CONNECTED        = 2,             /*状态2：连接成功，可发送状态*/
    EN_HTTP_STATUS_SEND_HEADER_OVER = 3,             /*状态3：发送头部成功*/
    EN_HTTP_STATUS_SEND_BODY_OVER   = 4              /*状态4：发送body数据成功*/
}EN_HTTP_STATUS_CODE;

_INT Http_Process_Send(ST_HTTP_NODE *psthttp);
_INT Http_Process_Recv(ST_HTTP_NODE *psthttp);

#ifdef __cplusplus
}
#endif

#endif