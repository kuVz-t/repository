#include "tras_httpclient.h" 
#include "http.h"
#include "config_system.h"
#include "config_api.h"

#define HTTP_ASYNC_TIMEOUT 10
#define HTTPCLIENT_LOGSTR "HttpClient"

_INT Http_Parse_Url(_UC *pucUrl, _UC *pucHost, _UC *pucFile, _INT *piSslFlag)
{
    _UC *pucPtr1  = MOS_NULL;
    _UC *pucPtr2  = MOS_NULL;
    _INT iLen     = 0;

    if (!pucUrl || !pucHost || !pucFile)
    {
        return MOS_ERR;
    }
 
    pucPtr1 = (_UC *)pucUrl;
    if (MOS_STRNCMP(pucPtr1, "http://", MOS_STRLEN("http://")) == 0)
    {
        pucPtr1 += MOS_STRLEN("http://");
        *piSslFlag = 0;
    }
    else if (MOS_STRNCMP(pucPtr1, "https://", MOS_STRLEN("https://")) == 0)
    {
        pucPtr1 += MOS_STRLEN("https://");
        *piSslFlag = 1;
    }
    else
    {
        // return MOS_ERR;
    }

    pucPtr2 = MOS_STRCHR(pucPtr1,'/');
    if (pucPtr2)
    {
        iLen = MOS_STRLEN(pucPtr1) - MOS_STRLEN(pucPtr2);
        MOS_MEMCPY(pucHost, pucPtr1, iLen);
        pucHost[iLen] = '\0';
        if (*(pucPtr2 + 1))
        {
            MOS_MEMCPY(pucFile, pucPtr2 + 1, MOS_STRLEN(pucPtr2)-1);
            pucFile[MOS_STRLEN(pucPtr2) - 1] = '\0';
        }
    }
    else
    {
        MOS_MEMCPY(pucHost, pucPtr1, MOS_STRLEN(pucPtr1));
        pucHost[MOS_STRLEN(pucPtr1)] = '\0';
    }
    return MOS_OK;
}

/**************- HTTP -***************/
_INT Http_GetDefaultConfig(ST_HTTP_INFO_NODE *pstNode)
{
    if (pstNode == MOS_NULL)
        return MOS_ERR;
    
    pstNode->iTimeOut         = HTTP_ASYNC_TIMEOUT;
    pstNode->pfuncRecv        = MOS_NULL;
    pstNode->pfuncFinished    = MOS_NULL;
    pstNode->pfuncFailed      = MOS_NULL;
    pstNode->pfuncGetData     = MOS_NULL;
    pstNode->pfuncRecvHeader  = MOS_NULL;
    pstNode->vpUserPtr        = MOS_NULL;
    pstNode->pucContent       = MOS_NULL;
    pstNode->uiContentLen     = 0;               // strlen(pucContent)
    pstNode->pucExpandHeader  = MOS_NULL;
    pstNode->uiSSLFlag        = 1;
    return MOS_OK;
}

static _INT Http_freeInfoNode(ST_HTTP_NODE *pstHttpNode)
{
    MOS_FREE(pstHttpNode->pucHost);
    MOS_FREE(pstHttpNode->pucUrl);
    MOS_FREE(pstHttpNode->pucContent);
    MOS_FREE(pstHttpNode->pucTmpBuff);
    MOS_FREE(pstHttpNode->pucExpandHeader);
    MOS_FREE(pstHttpNode);
    return MOS_OK;
}

static ST_HTTP_NODE *Http_CreateInfoNode(ST_HTTP_INFO_NODE *pstNode, _UC* pucHost, _UC* pucUrl, _INT iMethod, _UI uiReqId)
{
    ST_HTTP_NODE *pstHttpNode = (ST_HTTP_NODE *)Mos_MallocClr(sizeof(ST_HTTP_NODE));
    if(pstHttpNode != MOS_NULL)
    {
        if (pstNode->pfuncGetData != MOS_NULL)
        {
            pstHttpNode->pucTmpBuff  = (_UC *)Mos_MallocClr(HTTP_SEND_BUFFER_SIZE);
        }
        else if (pstNode->uiContentLen > 0)
        {
            pstHttpNode->pucContent  = (_UC *)Mos_MallocClr(pstNode->uiContentLen + 1);
        }    
        pstHttpNode->pucExpandHeader = (_UC *)Mos_MallocClr(MOS_STRLEN(pstNode->pucExpandHeader) + 1);
        pstHttpNode->pucHost         = (_UC *)Mos_MallocClr(MOS_STRLEN(pucHost) + 1);
        pstHttpNode->pucUrl          = (_UC *)Mos_MallocClr(MOS_STRLEN(pucUrl) + 2);
        
        if ((pstHttpNode->pucHost == MOS_NULL || pstHttpNode->pucUrl == MOS_NULL || pstHttpNode->pucExpandHeader == MOS_NULL) ||
            (pstHttpNode->pucContent == MOS_NULL && pstHttpNode->pucTmpBuff == MOS_NULL && iMethod != EN_HTTP_METHOD_GET && pstHttpNode->uiContentLen != 0))
        { 
            Http_freeInfoNode(pstHttpNode);
            MOS_LOG_ERR(HTTPCLIENT_LOGSTR, "http info malloc fail");
            return MOS_NULL;
        }
        else
        {
            /*变量赋值*/
            MOS_STRCPY(pstHttpNode->pucHost, pucHost);
            if(pucUrl[0] != '/')
            {
                // 兼容url不带'/' 情况
                pstHttpNode->pucUrl[0] = '/';
                MOS_STRCPY(pstHttpNode->pucUrl+1, pucUrl);  /*strncpy*/
            }
            else
            {
                MOS_STRCPY(pstHttpNode->pucUrl, pucUrl);
            }
            // 扩展頭部
            MOS_STRCPY(pstHttpNode->pucExpandHeader, pstNode->pucExpandHeader);
            // Content数据预处理, uiContentLen必须不为0
            pstHttpNode->uiContentLen = pstNode->uiContentLen;
            if (pstNode->pucContent)
            {
                MOS_STRCPY(pstHttpNode->pucContent, pstNode->pucContent);
            }
            else if (pstNode->pfuncGetData)
            {
                // 不指定Content数据, 通过回调分段传输数据
                pstHttpNode->pfuncGetData = pstNode->pfuncGetData;
            }
            
            if (pstHttpNode->iTimeOut <= 5)
            {
                // 避免出现非法的timeout值
                pstHttpNode->iTimeOut = HTTP_ASYNC_TIMEOUT;
            }
            
            // callback
            pstHttpNode->pfuncRecvHeader = pstNode->pfuncRecvHeader;
            pstHttpNode->pfuncRecv       = pstNode->pfuncRecv;
            pstHttpNode->pfuncFinished   = pstNode->pfuncFinished;
            pstHttpNode->pfuncFailed     = pstNode->pfuncFailed;

            pstHttpNode->iTimeOut        = pstNode->iTimeOut;
            pstHttpNode->vpUserPtr       = pstNode->vpUserPtr;
            pstHttpNode->uiSSLFlag       = pstNode->uiSSLFlag;
            pstHttpNode->uiReqId         = uiReqId;
            pstHttpNode->iMethod         = iMethod;

            // 保存请求开始时间,用于计算请求耗时
            pstHttpNode->uiStartTime     = Mos_GetTickCount();

            return pstHttpNode;
        }
    }
    else
    {
        MOS_LOG_ERR(HTTPCLIENT_LOGSTR, "ST_HTTP_NODE Malloc Fail");
        return MOS_NULL;
    }
}

/*成功返回MOS_OK,失败返回EN_HTTP_RET_CODE*/
_INT Http_SendRequest(ST_HTTP_INFO_NODE *pstNode, _UC* pucHost, _UC* pucUrl, _INT iMethod, _UI uiReqId, _UI uiSyncFlag)
{
    _INT iPort         = 0;
    _INT iCompleteFlag = 0;

    if (pstNode == MOS_NULL || pucHost == MOS_NULL || pucUrl == MOS_NULL)
    {
        MOS_LOG_ERR(HTTPCLIENT_LOGSTR, "Http Request Parms Have Null");
        return EN_HTTP_RET_ILLEGAL_PARAM_ERR;
    }

    if (iMethod != EN_HTTP_METHOD_GET && pstNode->uiContentLen == 0)
    {
        MOS_LOG_ERR(HTTPCLIENT_LOGSTR, "Http Request %s ContentLen Can Not Be Zero", pucHost);
        // return EN_HTTP_RET_ILLEGAL_PARAM_ERR;   /*质态数据使用post方法，但数据存放在url中*/
    }
    
    if (pstNode->pucContent && pstNode->pfuncGetData)
    {
        MOS_LOG_ERR(HTTPCLIENT_LOGSTR, "Http Request pucContent and pfuncGetData Use Only One");
        return EN_HTTP_RET_ILLEGAL_PARAM_ERR;
    }

    if (pstNode->pucContent && pstNode->uiContentLen > HTTP_SEND_BUFFER_SIZE)
    {
        /*目前对最大发送长度不作限制*/
        MOS_LOG_WARN(HTTPCLIENT_LOGSTR, "Http Request pucContent Should Less Than 4KB, Recommended Use pfuncGetData");
        // return EN_HTTP_RET_ILLEGAL_PARAM_ERR;
    }

    /*1、创建內存，结点赋值*/
    ST_HTTP_NODE *pstHttpNode = Http_CreateInfoNode(pstNode, pucHost, pucUrl, iMethod, uiReqId);
    ST_HTTP_MGR_NODE *pstHttpMgrNode = (ST_HTTP_MGR_NODE *)Mos_MallocClr(sizeof(ST_HTTP_MGR_NODE));;
    if (pstHttpMgrNode == MOS_NULL || pstHttpNode == MOS_NULL)
    {
        Http_freeInfoNode(pstHttpNode);
        MOS_FREE(pstHttpMgrNode);
        return EN_HTTP_RET_NODE_MALLOC_ERR;
    }
    pstHttpMgrNode->iProtocol = EN_TRAS_PROTOCOL_HTTP;
    pstHttpMgrNode->pstHandleNode = pstHttpNode;
    
    /*2、host转ip*/
    iPort = (pstNode->uiSSLFlag == 1)?443:80;
    if (Http_GetAddrArrayInfo(&(pstHttpNode->stIpArrayInfo), pstHttpNode->pucHost, iPort, &iPort) != MOS_OK)
    {
        Http_freeInfoNode(pstHttpNode);
        MOS_FREE(pstHttpMgrNode);
        return EN_HTTP_RET_GETHOSTBYNAME_ERR;
    }
    pstHttpNode->iPort = iPort;
    // ipv6能力值&开关 都打开, 才尝试用V6，否则只能用V4
    if (Config_GetCamaraMng()->uiIPv6Ability && Config_GetCamaraMng()->uiIPv6Switch)
    {
        pstHttpNode->uiConnectType = EN_CINET_TYPE_IPV6;
    }
    else
    {
        pstHttpNode->uiConnectType = EN_CINET_TYPE_IPV4;
    }

    /*同步请求才会赋值完成标志的指针，后续等待标志;非同步请求不要赋值指针, 直接标记为该接口完成*/
    iCompleteFlag = EN_HTTP_COMPLETE_NONE;
    if (uiSyncFlag)
    {
        pstHttpMgrNode->piCompleteFlag = &iCompleteFlag;
    }
    else
    {
        iCompleteFlag = EN_HTTP_COMPLETE_SUCCESS;
    }

    /*3、插入链表*/
    if (Http_Add_Fd(pstHttpMgrNode) == EN_HTTP_RET_ADDEPOLL_ERR)
    {
        MOS_LOG_ERR(HTTPCLIENT_LOGSTR, "Http Add Fail url = %s",pstHttpNode->pucUrl);
        Mos_SocketClose(pstHttpMgrNode->hSocket);
        Http_freeInfoNode(pstHttpNode);
        MOS_FREE(pstHttpMgrNode);
        return EN_HTTP_RET_ADDEPOLL_ERR;
    }

    /*同步请求等待*/
    while (iCompleteFlag == EN_HTTP_COMPLETE_NONE)
    {
        Mos_Sleep(100);
    }

    if (iCompleteFlag == EN_HTTP_COMPLETE_SUCCESS)
        return MOS_OK;
    else
        return EN_HTTP_RET_COMMON_ERR;
}

_INT Http_SendAsyncRequest(ST_HTTP_INFO_NODE *pstNode, _UC* pucHost, _UC* pucUrl, _INT iMethod, _UI uiReqId)
{
    if(Http_GetMgr()->iRunFlag == 1)
        return Http_SendRequest(pstNode, pucHost, pucUrl, iMethod, uiReqId, 0);
    else{
        MOS_LOG_WARN(HTTPCLIENT_LOGSTR, "http is not running");
        return MOS_ERR;
    }
}

_INT Http_SendSyncRequest(ST_HTTP_INFO_NODE *pstNode, _UC* pucHost, _UC* pucUrl, _INT iMethod, _UI uiReqId)
{
    // reqid用于排查问题
    if(Http_GetMgr()->iRunFlag == 1)
        return Http_SendRequest(pstNode, pucHost, pucUrl, iMethod, uiReqId, 1);
    else{
        MOS_LOG_WARN(HTTPCLIENT_LOGSTR, "http is not running");
        return MOS_ERR;
    }
}

// Http异步取消请求 ADD By LWJ
 _INT Http_Httpclient_CancelAsyncRequestEx(_UI uiReqId)
{
    if (uiReqId == 0)
    {
        MOS_LOG_WARN(HTTPCLIENT_LOGSTR, "the requestid is zero");
        return MOS_ERR;
    }
    ST_HTTP_MGR_NODE *pstHttpMgrNode =  MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;

    Mos_MutexLock(&(Http_GetMgr()->hTaskMutex));
    // 遍历读链表
    FOR_EACHDATA_INLIST(&(Http_GetMgr()->stHttpNodeList), pstHttpMgrNode, stIterator)
    {
        ST_HTTP_NODE *pstHttpNode = (ST_HTTP_NODE*)pstHttpMgrNode->pstHandleNode;
        // 已完成，则删除
        if (pstHttpNode->uiReqId == uiReqId)
        {
            MOS_LOG_INF(HTTPCLIENT_LOGSTR, "https(ReqId:%u) %s Cancel!", pstHttpNode->uiReqId, pstHttpNode->pucUrl);
            pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FAIL;
        }
    }
    Mos_MutexUnLock(&(Http_GetMgr()->hTaskMutex));
	
    return MOS_OK;
}

