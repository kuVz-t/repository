#include "http_media.h"

_INT Http_SetPeerRelayMode(_UC *pucPeerID,_UI uiOpenFlag)
{
    return MOS_OK;
}

_INT Http_SetPlayStreamNoticeCB(PFUN_NTYSTREAMSTATUS pfunStreamNotice)
{
    return MOS_OK;
}
_INT Http_SetDownFileStatusCB(PFUN_DOWNFILESTATUSCB pFunDownFileStatusCb)
{
    return MOS_OK;
}

_INT Http_GetPlayStreamType(_UC *pucPeerID,_UI uiSessionID,_UI *puiMediaType, _UI *puiStreamType)
{
    return MOS_OK;
}
_INT Http_GetPlayStreamAndMicInf(_UC* pucPeerID,_UI uiSessionID,_INT *piCamId,_INT *piStreamId,_INT *piMicId)
{
    return MOS_OK;
}

_UI Http_CreateLiveStream(_UC* pucPeerID, _INT iCamID, _INT iStreamID, _INT iAudioFlag)
{
    return MOS_OK;
}
_UI Http_CreatPushStream(_UC* pucPeerId,_INT iCamId,_INT iStreamId,_INT iAudioFlag)
{
    return MOS_OK;
}
_UI Http_CreateRecordStream(_UC* pucPeerID, _INT iCamID, _UC* pucPlayTime,_INT iDownFlag)
{
    return MOS_OK;
}
_INT Http_GetRecordJustTime(_UC* pucPeerID, _UI uiSessionID)
{
    return MOS_OK;
}

_UI Http_ReqAliveJpeg(_UC* pucPeerID, _INT iCamID, _INT iPicType)
{
    return MOS_OK;
}

_UI Http_ReqOneJpegFile(_UC* pucPeerID, _INT iCamID, _UC* pucEventName)
{
    return MOS_OK;
}

_UI Http_CollectLogFiles(_UC* pucPeerID,_UC *pucFilePath)
{
    return MOS_OK;
}

_UI Http_PushSoundFile(_UC* pucPeerID,_UC *pucFullName)
{
    return MOS_OK;
}
    
_INT Http_PausePlay(_UC* pucPeerID, _UI uiSessionID, _UI uiAvFlag)
{
    return MOS_OK;
}
_INT Http_ResumePlay(_UC* pucPeerID, _UI uiSessionID, _UI uiAvFlag)
{
    return MOS_OK;
}
_INT Http_StopPlay(_UC* pucPeerID, _UI uiSessionID)
{
    return MOS_OK;
}
_INT Http_SetPlayTime(_UC* pucPeerID, _UI uiSessionID, _UI uiTimeSecond)
{
    return MOS_OK;
}
_INT Http_GetKeyFrame(_UC* pucPeerID, _UI uiSessionID)
{
    return MOS_OK;
}

// 同意请求，开始发送媒体流数据；
_INT Http_AcceptSession(_UC* pucPeerID, _UI uiSessionID, _UI uiAcceptState)
{
    return MOS_OK;
}

_INT Http_SetCollectLogFileStatus(_UC* pucPeerID, _UI uiSessionID, _UI uiStatus,_UC *pucFileName)
{
    return MOS_OK;
}

_INT Http_GetCurSessionsTTLTime(ST_ZJ_SESSION_TTL_INFO astSessionTTLs[8],_INT *piSessionCnt)
{
    return MOS_OK;
}
