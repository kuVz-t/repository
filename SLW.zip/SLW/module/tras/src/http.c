#include "mos.h"
#include "watchdog_api.h"
#include "config_api.h"
#include "http.h"
#include "http_common.h"

#define HTTP_MAX_LISTEN_NUM                     64
#define HTTP_FEED_DOG_TIMEOUT_MSEC              1000
#define HTTP_ROLL2IPV4_SEND_SIGNAL_TIMEOUT_S    3       //未接收到可发送信号前, 判断超时, 规避出现异常网络的情况导致ipv6无法回落ipv4

static _UC g_enNetType = 0;
static ST_HTTP_MGR g_stHttpMgr = {0};
static kj_timer_t g_tHttpFeedDogTimeOut = {0};
static _HSWDWRITE g_hSwdHttpFeedDog = {0};
struct epoll_event events[HTTP_MAX_LISTEN_NUM];       // epoll事件监听列表

static _C *g_acRetCodeStringArray[5] = {"Crate SSL Step!", "Wating for Connecting!", "Had Connected to Server", "Had Send Http Header", "Had Send Http Content"};
static _C *g_acStatusStringArray[6] = {"idle", "connect", "handle", "finish", "fail", "timeout"};

ST_HTTP_MGR *Http_GetMgr()
{
    return &g_stHttpMgr;
}

_INT Http_SetNetworkType(_UC ucNetworkType)
{
    g_enNetType = ucNetworkType;
    return MOS_OK;
}

_INT Http_GetNetWorkType()
{
    return g_enNetType;
}

static _VOID Http_CheckAndFeedDog()
{
    // 软看门狗喂狗
    if (getDiffTimems(&g_tHttpFeedDogTimeOut, 0, ENUM_SECONDS_TYPE_MSECONDS, 60 * 10) >= HTTP_FEED_DOG_TIMEOUT_MSEC)
    {
        Swd_AppThreadFeedDog(g_hSwdHttpFeedDog);
        getDiffTimems(&g_tHttpFeedDogTimeOut, 1, ENUM_SECONDS_TYPE_MSECONDS, 60 * 10);
    }
}

// 从IPARRAY查找ipv4或ipv6的ip信息
ST_MOS_INET_IP *Http_GetInetIPByIpArray(ST_MOS_INET_IPARRAY *pstIpArrayInfo, _US usType)
{
    MOS_PARAM_NULL_RETNULL(pstIpArrayInfo);
    _INT i = 0;
    ST_MOS_INET_IP *pstIpInfo = MOS_NULL;

    for (i = 0; i < pstIpArrayInfo->uiCount; i++)
    {
        if (pstIpArrayInfo->astIps[i].usType != usType)
        {
            continue;
        }
        pstIpInfo = &pstIpArrayInfo->astIps[i];
        break;
    }
    return pstIpInfo;
}

// host/ip 转为 ip数组ST_MOS_INET_IPARRAY
// 返回值：MOS_OK成功 MOS_ERR失败
// 注意：host转ip过程，最长阻塞1秒
// 注意：pstIpArrayInfo由使用者提供，缓存ip列表
_INT Http_GetAddrArrayInfo(ST_MOS_INET_IPARRAY *pstIpArrayInfo, _UC *pucHost, _INT iDefaultPort, _INT *piOutPort)
{
    MOS_PARAM_INVALID_RET(pstIpArrayInfo, MOS_NULL, MOS_ERR);
    MOS_PARAM_INVALID_RET(pucHost, MOS_NULL, MOS_ERR);

    _UC *pucHostTemp = MOS_NULL;
    _INT iPort = iDefaultPort;

    pucHostTemp = MOS_STRCHR(pucHost, ':');
    if (pucHostTemp)
    {
        *pucHostTemp++ = '\0';
        iPort = MOS_ATOI(pucHostTemp);
    }
    else
    {
        iPort = iDefaultPort;
    }

    if (piOutPort)
    {
        *piOutPort = iPort;
    }

    // 获取服务器地址信息
    if (Mos_InetGetAddrInfo(pucHost,iPort,EN_CINET_PRTL_TCP,MOS_TRUE,pstIpArrayInfo) != MOS_OK)
    {
        MOS_PRINTF("%s Mos_InetGetAddrInfo %s failed, try again\n", __FUNCTION__, pucHost);
        if (Mos_InetGetAddrInfo(pucHost,iPort,EN_CINET_PRTL_TCP,MOS_TRUE,pstIpArrayInfo) != MOS_OK)
        {
            return MOS_ERR;
        }
    }

    return MOS_OK;
}
// 计算http请求耗时时间
static _UI Http_GetUseTime(_UI uiStartTime)
{
    _UI uiUseTime      = 0;
    _UI uiCurTickCount = 0;

    uiCurTickCount = Mos_GetTickCount();
    if (uiCurTickCount > uiStartTime)
    {
        uiUseTime = uiCurTickCount - uiStartTime;
    }
    else
    {
        uiUseTime = 0;
    }

    return uiUseTime;
}

#if 0
// 地址为IP返回MOS_TRUE 其他返回MOS_FALSE
static _BOOL Http_HostIsIP(_UC *pucHost)
{
    _INT i, j, z;
    _UC ip[4][4] = {0};
    _INT ip_i = 0;
    _UC *ptr = pucHost;
    _INT ptr_i = 0;
    _INT ptr_len = MOS_STRLEN(ptr);

    if (NULL == pucHost)
        return MOS_FALSE;

    //检查IP范围
    for (i = 0; i < 4; i++)
    {
        ip_i = 0;
        for (j = 0; j < 4; j++)
        {
            // 1.字符为0-9的数字
            if (3 != j && isdigit(ptr[ptr_i]))
            {
                ip[i][ip_i++] = ptr[ptr_i++];
            }
            // 2.字符为'.'分隔符
            else if (3 != i && 0 != j && '.' == ptr[ptr_i])
            {
                ip[i][ip_i++] = '\0';
                ptr_i++;
                break;
            }
            else
            {
                return MOS_FALSE;
            }
            // 3.结束
            if (ptr_len <= ptr_i)
            {
                if (3 == i)
                    break;
                else
                    return MOS_FALSE;
            }
        }
    }
    //检查IP格式
    for (z = 0; z < 4; z++)
        if (MOS_ATOI(ip[z]) > 255)
            return MOS_FALSE;
    return MOS_TRUE;
}
#endif

// 非阻塞socket
static _SOCKET Http_Handle_Create2(ST_MOS_INET_IPARRAY *pstIpArrayInfo, _UI iConnectType)
{
    _BOOL bConnected = MOS_TRUE;
    _SOCKET hSocket = MOS_SOCKET_INVALID;
    ST_MOS_INET_IP *pstIpInfo = MOS_NULL;

    pstIpInfo = Http_GetInetIPByIpArray(pstIpArrayInfo, iConnectType);
    if (pstIpInfo == MOS_NULL)
    {
        return MOS_SOCKET_INVALID;
    }

    do
    {
        hSocket = Mos_SocketOpen(pstIpInfo->usType, EN_CINET_PRTL_TCP, MOS_FALSE, MOS_TRUE);
        if (hSocket == MOS_SOCKET_INVALID)
        {
            MOS_LOG_ERR(HTTP_LOGSTR, "Mos_SocketOpen error %d",errno);
            hSocket = EN_HTTP_RET_SOCKETOPEN_ERR;
            break;
        }

        if (Mos_SocketConnect(hSocket, pstIpInfo, &bConnected) != MOS_OK)
        {
            MOS_LOG_ERR(HTTP_LOGSTR, "Mos_SocketConnect errno %d type %d", errno, iConnectType);
            Mos_SocketClose(hSocket);
            hSocket = MOS_SOCKET_INVALID;
            break;
        }

        Mos_SocketSetSendBuf(hSocket, 32 * 1024);
    } while (0);

    return hSocket;
}

// _INT Http_Create_Fd(_UC *pucHost, _INT *iDefaultPort, _INT *iIpv6Flag)
// {
//     return MOS_OK;
// }

_INT Http_Add_Fd(ST_HTTP_MGR_NODE *pstHttpMgrNode)
{
    if (Http_GetMgr()->iRunFlag != 1 || pstHttpMgrNode == MOS_NULL)
    {
        return EN_HTTP_RET_UNINITIALIZED_ERR;
    }

    Mos_MutexLock(&(Http_GetMgr()->hTaskMutex));
    MOS_LIST_ADDTAIL(&(Http_GetMgr()->stHttpNodeList), pstHttpMgrNode);
    Mos_MutexUnLock(&(Http_GetMgr()->hTaskMutex));

    ST_HTTP_NODE *pstHttpNode = (ST_HTTP_NODE *)pstHttpMgrNode->pstHandleNode;
    // 计时
    kj_timer_init(&pstHttpMgrNode->tHttpNodeTimeOut);
    getDiffTimems(&pstHttpMgrNode->tHttpNodeTimeOut, 1, ENUM_SECONDS_TYPE_SECONDS, 60 * 10);
    MOS_LOG_INF(HTTP_LOGSTR, "Http Add Node success host %s port:%d reqid = %d socket = %d url = %s list count [%d]",
            pstHttpNode->pucHost,pstHttpNode->iPort,pstHttpNode->uiReqId, pstHttpMgrNode->hSocket, pstHttpNode->pucUrl, MOS_LIST_GETCOUNT(&(Http_GetMgr()->stHttpNodeList)));

    return MOS_OK;
}

static _INT Http_Close_Fd(ST_HTTP_MGR_NODE *pstHttpMgrNode)
{
    if (pstHttpMgrNode==MOS_NULL || pstHttpMgrNode->pstHandleNode==MOS_NULL || pstHttpMgrNode->hSocket==MOS_SOCKET_INVALID)
    {
        MOS_LOG_WARN(HTTP_LOGSTR, "Input Param Err ptr=%p node=%p socket=%d", pstHttpMgrNode, pstHttpMgrNode->pstHandleNode, pstHttpMgrNode->hSocket);
        return MOS_ERR;
    }

    _SOCKET hSocket = pstHttpMgrNode->hSocket;
    ST_HTTP_NODE *pstHttpNode = (ST_HTTP_NODE *)pstHttpMgrNode->pstHandleNode;

    epoll_ctl(Http_GetMgr()->iEpollFd, EPOLL_CTL_DEL, hSocket, &pstHttpMgrNode->stEvent);
    if (!pstHttpNode->hSSL)
    {
        if (hSocket > 0)
        {
            Mos_SocketShutDown(hSocket, EN_CINET_SHTDWN_BOTH);
            Mos_SocketClose(hSocket);
        }
        else
        {
            MOS_LOG_WARN(HTTP_LOGSTR, "socket had been delete, seqid[%d]", pstHttpNode->uiReqId);
        }
    }
    else
    {
        Adpt_SSL_Destroy(pstHttpNode->hSSL);
    }
    pstHttpMgrNode->hSocket = MOS_SOCKET_INVALID;
    pstHttpNode->hSocket    = MOS_SOCKET_INVALID;
    pstHttpNode->hSSL       = MOS_NULL;
    return MOS_OK;
}

static _INT Http_Del_Fd(ST_HTTP_MGR_NODE *pstHttpMgrNode)
{
    // _INT iRet = MOS_ERR;
    ST_HTTP_NODE *pstHttpNode = MOS_NULL;
    Mos_MutexLock(&(Http_GetMgr()->hTaskMutex));
    MOS_LIST_RMVNODE(&Http_GetMgr()->stHttpNodeList, pstHttpMgrNode);
    Mos_MutexUnLock(&(Http_GetMgr()->hTaskMutex));
    
    // close句柄
    Http_Close_Fd(pstHttpMgrNode);
    
    pstHttpNode = (ST_HTTP_NODE *)pstHttpMgrNode->pstHandleNode;
    MOS_FREE(pstHttpNode->pucHost);
    MOS_FREE(pstHttpNode->pucUrl);
    MOS_FREE(pstHttpNode->pucContent);
    MOS_FREE(pstHttpNode->pucExpandHeader);
    MOS_FREE(pstHttpNode->pucTmpBuff);
    MOS_FREE(pstHttpNode);

    MOS_FREE(pstHttpMgrNode);
    return MOS_OK;
}

static _INT Http_Process()
{
    _INT i       = 0;
    _INT iRet    = MOS_ERR;
    _INT iNReady = 0;
    ST_HTTP_MGR_NODE *pstHttpMgrNode = MOS_NULL;
    struct epoll_event stEpollEvent  = {0};

    iNReady = epoll_wait(Http_GetMgr()->iEpollFd, events, HTTP_MAX_LISTEN_NUM, 0);
    if (iNReady <= -1)
    {
        MOS_LOG_ERR(HTTP_LOGSTR, "epoll_wait fail errno = %d", errno);
        return MOS_ERR;
    }
    else if (iNReady == 0)
    { 
        return MOS_OK;
    }
    else
    {
        for (i = 0; i < iNReady; i++)
        {
            // 对端异常关闭，会发送RST，触发EPOLLERR
            if (events[i].events & EPOLLERR || events[i].events & EPOLLHUP)
            {
                ST_MOS_LIST_ITERATOR stIterator;
                FOR_EACHDATA_INLIST(&(Http_GetMgr()->stHttpNodeList), pstHttpMgrNode, stIterator)
                {
                    if (pstHttpMgrNode->hSocket == events[i].data.fd)
                    {
                        _INT err;
                        socklen_t len = sizeof(err);
                        ST_HTTP_NODE *pstHttpNode = (ST_HTTP_NODE *)pstHttpMgrNode->pstHandleNode;

                        getsockopt(pstHttpMgrNode->hSocket, SOL_SOCKET, SO_ERROR, &err, &len);
                        MOS_LOG_ERR(HTTP_LOGSTR, "[%u] Socket Err %d", pstHttpNode->uiReqId, err);
                        // 删除
                        pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FAIL;
                        break;
                    }
                }
            }
            else if (events[i].events & EPOLLIN)
            {
                ST_MOS_LIST_ITERATOR stIterator;
                FOR_EACHDATA_INLIST(&(Http_GetMgr()->stHttpNodeList), pstHttpMgrNode, stIterator)
                {
                    if (pstHttpMgrNode->hSocket == events[i].data.fd)
                    {
                        if (pstHttpMgrNode->iProtocol == EN_TRAS_PROTOCOL_HTTP)
                        {
                            ST_HTTP_NODE *pstHttpNode = (ST_HTTP_NODE *)pstHttpMgrNode->pstHandleNode;
                            iRet = Http_Process_Recv(pstHttpNode);

                            if (iRet == EN_HTTP_TRY_AGAIN)
                            {
                                // 重试
                                MOS_MEMCPY(&stEpollEvent, &events[i], sizeof(stEpollEvent));
                                stEpollEvent.events = EPOLLIN | EPOLLERR | EPOLLHUP;
                                epoll_ctl(Http_GetMgr()->iEpollFd, EPOLL_CTL_MOD, pstHttpMgrNode->hSocket, &stEpollEvent);
                            }
                            else if (iRet == MOS_OK)
                            {
                                if (pstHttpNode->iResultCode == 200 || pstHttpNode->iResultCode == 302)
                                {
                                    // 成功
                                    pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FINISH;
                                }
                                else if (pstHttpNode->iResultCode == 100)
                                {
                                    // 收到100，epoll监听发送状态
                                    pstHttpNode->iResultCode = 0;
                                    MOS_MEMCPY(&stEpollEvent, &events[i], sizeof(stEpollEvent));
                                    stEpollEvent.events = EPOLLOUT | EPOLLERR | EPOLLHUP;
                                    epoll_ctl(Http_GetMgr()->iEpollFd, EPOLL_CTL_MOD, pstHttpMgrNode->hSocket, &stEpollEvent);
                                }
                                else
                                {
                                    pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FAIL;
                                    MOS_LOG_ERR(HTTP_LOGSTR, "[%d] Recv Fail resultcode [%d]", pstHttpNode->uiReqId, pstHttpNode->iResultCode);
                                }
                            }
                            else
                            {
                                // 删除
                                pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FAIL;
                                iRet = MOS_OK;
                                MOS_LOG_ERR(HTTP_LOGSTR, "[%d] Recv Fail err [%d]", pstHttpNode->uiReqId, errno);
                            }
                        }
                        break;
                    }
                }
            }
            else if (events[i].events & EPOLLOUT)
            {
                ST_MOS_LIST_ITERATOR stIterator;
                // 与链表删除在同一线程，不加锁
                FOR_EACHDATA_INLIST(&(Http_GetMgr()->stHttpNodeList), pstHttpMgrNode, stIterator)
                {
                    if (pstHttpMgrNode->hSocket == events[i].data.fd)
                    {
                        if (pstHttpMgrNode->iProtocol == EN_TRAS_PROTOCOL_HTTP)
                        {
                            ST_HTTP_NODE *pstHttpNode = (ST_HTTP_NODE *)pstHttpMgrNode->pstHandleNode;

                            iRet = Http_Process_Send(pstHttpNode);
                            if (iRet == EN_HTTP_TRY_AGAIN)
                            {
                                // 重试
                                MOS_MEMCPY(&stEpollEvent, &events[i], sizeof(stEpollEvent));
                                stEpollEvent.events = EPOLLOUT | EPOLLERR | EPOLLHUP;
                                epoll_ctl(Http_GetMgr()->iEpollFd, EPOLL_CTL_MOD, pstHttpMgrNode->hSocket, &stEpollEvent);
                            }
                            else if (iRet == MOS_OK)
                            {
                                // 成功
                                MOS_MEMCPY(&stEpollEvent, &events[i], sizeof(stEpollEvent));
                                stEpollEvent.events = EPOLLIN;
                                epoll_ctl(Http_GetMgr()->iEpollFd, EPOLL_CTL_MOD, pstHttpMgrNode->hSocket, &stEpollEvent);
                                //MOS_LOG_INF(HTTP_LOGSTR, "Send [%s] Success", pstHttpNode->pucUrl);
                            }
                            else
                            {
                                // 删除
                                pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FAIL;
                                MOS_LOG_INF(HTTP_LOGSTR, "[%d] Send Fail err [%d]", pstHttpNode->uiReqId, errno);
                                iRet = MOS_OK;
                            }
                        }
                        break;
                    }
                }
            }
        }
    } 

    return iRet;
}

_INT Http_Loop()
{
    _UI uiUseTime                    = 0;
    _UI uiDiffTime                   = 0;
    ST_HTTP_MGR_NODE *pstHttpMgrNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;

    g_hSwdHttpFeedDog = Swd_AppThreadRegist(EPOLL_APP, FEED_DOG_SUPER_MAX_TIMESEC);
    kj_timer_init(&g_tHttpFeedDogTimeOut);
    getDiffTimems(&g_tHttpFeedDogTimeOut, 1, ENUM_SECONDS_TYPE_MSECONDS, 60 * 10);

    while (Http_GetMgr()->iRunFlag)
    {
        /*软看门狗检测喂狗*/
        Http_CheckAndFeedDog();
        /*遍历读链表 已完成或失败或超时*/
        FOR_EACHDATA_INLIST(&(Http_GetMgr()->stHttpNodeList), pstHttpMgrNode, stIterator)
        {
            ST_HTTP_NODE *pstHttpNode = (ST_HTTP_NODE *)pstHttpMgrNode->pstHandleNode;
            
            uiDiffTime = getDiffTimems(&pstHttpMgrNode->tHttpNodeTimeOut, 0, ENUM_SECONDS_TYPE_SECONDS, 60 * 10);
            /*整个请求判断超时，删除链接*/
            if (uiDiffTime > pstHttpNode->iTimeOut)
            {
                pstHttpMgrNode->iStatus = EN_HTTP_STATUS_TIMEOUT;
            }
            /*未接收到可发送信号前, 判断超时, 规避出现异常网络的情况导致ipv6无法回落ipv4*/
            else if (pstHttpMgrNode->iStatus == EN_HTTP_STATUS_HANDLE && pstHttpNode->iRetCode < EN_HTTP_STATUS_CONNECTED)
            {
                if (pstHttpNode->uiConnectType == EN_CINET_TYPE_IPV6 && uiDiffTime >= HTTP_ROLL2IPV4_SEND_SIGNAL_TIMEOUT_S)
                {
                    // 关闭句柄 - 注意处于EN_HTTP_STATUS_HANDLE状态
                    Http_Close_Fd(pstHttpMgrNode);
                    // 切换为连接ipv4
                    pstHttpMgrNode->iStatus    = EN_HTTP_STATUS_IDLE;  
                    pstHttpNode->iRetCode      = EN_HTTP_STATUS_CREATE_SSL;
                    pstHttpNode->uiConnectType = EN_CINET_TYPE_IPV4;
                    MOS_LOG_WARN(HTTP_LOGSTR, "id %u roll ipv4, recv send signal timeout, time: %llu\n", 
                        pstHttpNode->uiReqId, Mos_GetLLTickCount() - pstHttpMgrNode->ullReqTime);
                }
            }

            if (pstHttpMgrNode->iStatus == EN_HTTP_STATUS_IDLE)
            {
                /*HTTP创建连接*/
                pstHttpMgrNode->ullReqTime = Mos_GetLLTickCount();
                _SOCKET hSocket = Http_Handle_Create2(&(pstHttpNode->stIpArrayInfo), pstHttpNode->uiConnectType);
                if (hSocket > 0)
                {
                    pstHttpNode->hSocket    = hSocket;
                    pstHttpMgrNode->hSocket = hSocket;
                    pstHttpMgrNode->iStatus = EN_HTTP_STATUS_CONNECT;
                }
                else
                {
                    if (pstHttpNode->uiConnectType == EN_CINET_TYPE_IPV6)
                    {
                        // 切换为连接ipv4
                        pstHttpMgrNode->iStatus = EN_HTTP_STATUS_IDLE;  
                        pstHttpNode->uiConnectType = EN_CINET_TYPE_IPV4;
                        MOS_PRINTF("http id %u connect ipv6 failed, try to ipv4\n", pstHttpNode->uiReqId);
                    }
                    else
                    {
                        /*未创建socket成功，释放时要做判断*/
                        pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FAIL;
                    }
                }
            }
            else if (pstHttpMgrNode->iStatus == EN_HTTP_STATUS_CONNECT)
            {
                /*HTTP连接成功，加入Epoll监听*/
                if (Mos_SockCheckBoolConnectLink(pstHttpMgrNode->hSocket) == MOS_TRUE)
                {
                    pstHttpMgrNode->stEvent.events = EPOLLOUT | EPOLLERR | EPOLLIN | EPOLLHUP; //监听EPOLLOUT，EPOLLERR，EPOLLIN事件
                    pstHttpMgrNode->stEvent.data.fd = pstHttpMgrNode->hSocket;
                    if (epoll_ctl(Http_GetMgr()->iEpollFd, EPOLL_CTL_ADD, pstHttpMgrNode->hSocket, &pstHttpMgrNode->stEvent) < 0)
                    {
                        pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FAIL;
                    }
                    else
                    {
                        pstHttpMgrNode->iStatus = EN_HTTP_STATUS_HANDLE;
                    }
                }
                else
                {
                    if (pstHttpNode->uiConnectType == EN_CINET_TYPE_IPV6)
                    {
                        _BOOL bSwitchIPV4 = MOS_FALSE;
                        if (Mos_SockCheckBoolConnect(pstHttpMgrNode->hSocket) == MOS_FALSE) // 检测socket状态，不一定已连接
                        {
                            /* ipv6连接失败，切换连接IPv4 */
                            bSwitchIPV4 = MOS_TRUE;
                            MOS_PRINTF("http %d connect ipv6 failed, try ipv4\n", pstHttpNode->uiReqId);
                        }
                        else if ((Mos_GetLLTickCount()-pstHttpMgrNode->ullReqTime) > MOS_INET_IPV6_TIMEOUT_MS)
                        {
                            /* ipv6连接超过500ms，切换连接IPv4 */
                            bSwitchIPV4 = MOS_TRUE;
                            MOS_PRINTF("http %d connect ipv6 timeout, try ipv4\n", pstHttpNode->uiReqId);
                        }

                        if (bSwitchIPV4)
                        {
                            /*需要关掉socket，后续IPV4连接会重新创建socket*/
                            Mos_SocketClose(pstHttpMgrNode->hSocket);
                            pstHttpMgrNode->hSocket    = MOS_SOCKET_INVALID;
                            pstHttpMgrNode->iStatus    = EN_HTTP_STATUS_IDLE;
                            pstHttpNode->hSocket       = MOS_SOCKET_INVALID;
                            pstHttpNode->uiConnectType = EN_CINET_TYPE_IPV4;
                        }
                    }
                    else if (pstHttpNode->uiConnectType == EN_CINET_TYPE_IPV4)
                    {
                        if (Mos_SockCheckBoolConnect(pstHttpMgrNode->hSocket) == MOS_FALSE) // 检测socket状态，不一定已连接
                        {
                            /* ipv4连接失败 */
                            pstHttpMgrNode->iStatus = EN_HTTP_STATUS_FAIL;
                        }
                    }
                }
            }
            
            // 处理错误、超时、完成状态
            if (pstHttpMgrNode->iStatus == EN_HTTP_STATUS_FAIL || 
                pstHttpMgrNode->iStatus == EN_HTTP_STATUS_TIMEOUT || 
                pstHttpMgrNode->iStatus == EN_HTTP_STATUS_FINISH)
            {
                _UC aucDeleteLog[128] = {0};

                MOS_VSNPRINTF(aucDeleteLog, sizeof(aucDeleteLog), "delete %s id:%u status:[%s] left:%d", 
                            g_acStatusStringArray[pstHttpMgrNode->iStatus], pstHttpNode->uiReqId, 
                            g_acRetCodeStringArray[pstHttpNode->iRetCode], 
                            MOS_LIST_GETCOUNT(&(Http_GetMgr()->stHttpNodeList)));
                // 获取请求耗时
                uiUseTime = Http_GetUseTime(pstHttpNode->uiStartTime);
                
                /*HTTP已完成或失败删除*/
                if (pstHttpMgrNode->iStatus == EN_HTTP_STATUS_FAIL || pstHttpMgrNode->iStatus == EN_HTTP_STATUS_TIMEOUT)
                {
                    if (pstHttpNode->pfuncFailed)
                    {
                        /*超时错误码*/
                        pstHttpNode->pfuncFailed(pstHttpNode->vpUserPtr, EN_HTTP_RET_TIMEOUT, pstHttpNode->uiReqId, uiUseTime);
                    }
                    MOS_LOG_WARN(HTTP_LOGSTR, "%s, http request failed ipv%d time: %llu\n", aucDeleteLog,
                                    (pstHttpNode->uiConnectType==EN_CINET_TYPE_IPV4)?4:6, 
                                    Mos_GetLLTickCount() - pstHttpMgrNode->ullReqTime);
                }
                else if(pstHttpMgrNode->iStatus == EN_HTTP_STATUS_FINISH)
                {
                    if (pstHttpNode->pfuncFinished)
                    {
                        pstHttpNode->pfuncFinished(pstHttpNode->vpUserPtr, pstHttpNode->uiReqId, uiUseTime);
                    }
                    MOS_LOG_INF(HTTP_LOGSTR, "%s, http request succeed ipv%d time: %llu\n", aucDeleteLog,
                                    (pstHttpNode->uiConnectType==EN_CINET_TYPE_IPV4)?4:6, 
                                    Mos_GetLLTickCount() - pstHttpMgrNode->ullReqTime);
                }

                /*如果存在完成标志，则将完成标志赋值*/
                if (pstHttpMgrNode->piCompleteFlag)
                {
                    /*同步返回HTTP请求状态码*/
                    if (pstHttpMgrNode->iStatus == EN_HTTP_STATUS_FAIL || pstHttpMgrNode->iStatus == EN_HTTP_STATUS_TIMEOUT)
                    {
                        *(pstHttpMgrNode->piCompleteFlag) = EN_HTTP_COMPLETE_FAILED;
                    }
                    else
                    {
                        *(pstHttpMgrNode->piCompleteFlag) = EN_HTTP_COMPLETE_SUCCESS;
                    }
                }

                Http_Del_Fd(pstHttpMgrNode);
            }
        }

        Http_Process();
        Mos_Sleep(5); 
    }
    Swd_AppThreadUnRegist(g_hSwdHttpFeedDog);
    return MOS_OK;
}

_INT Http_Init()
{
    if (Http_GetMgr()->iInitFlag == 1)
    {
        MOS_LOG_WARN(HTTP_LOGSTR,"Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stHttpMgr, 0, sizeof(g_stHttpMgr));
    
    Http_GetMgr()->iEpollFd = epoll_create(HTTP_MAX_LISTEN_NUM);
    // 创建链表
    MOS_LIST_INIT(&(Http_GetMgr()->stHttpNodeList));
    // 创建互斥锁
    Mos_MutexCreate(&(Http_GetMgr()->hTaskMutex));
    Http_GetMgr()->iInitFlag = 1;
    MOS_LOG_INF(HTTP_LOGSTR, "Http Init ok");
    return MOS_OK;
}

_INT Http_Start()
{
    if (Http_GetMgr()->iInitFlag != 1)
    {
        MOS_LOG_INF(HTTP_LOGSTR, "Http is Uninitialized");
        return MOS_ERR;
    }
    if (Http_GetMgr()->iRunFlag == 1)
    {
        MOS_LOG_WARN(HTTP_LOGSTR,"Already Start");
        return MOS_OK;
    }
    // 线程栈大小
    _UI uiStackSize = MOS_THREAD_STACK_HIGH_SIZE;
    _INT iRet = MOS_OK;

    Http_GetMgr()->iRunFlag = 1;
    iRet = Mos_ThreadCreate((_UC *)"Http", EN_THREAD_PRIORITY_NORMAL, uiStackSize,
                            Http_Loop, MOS_NULL, MOS_NULL, &Http_GetMgr()->hExtThread);
    if (iRet == MOS_ERR)
    {
        Http_GetMgr()->iRunFlag = 0;
        return MOS_ERR;
    }
    
    MOS_LOG_INF(HTTP_LOGSTR, "Http Start ok");
    return MOS_OK;
}

_INT Http_Stop()
{
    if (Http_GetMgr()->iRunFlag == 0)
    {
        MOS_LOG_INF(HTTP_LOGSTR,"Already Stop !!");
        return MOS_OK;
    }
    Http_GetMgr()->iRunFlag = 0;
    Mos_ThreadDelete(Http_GetMgr()->hExtThread);
    MOS_LOG_INF(HTTP_LOGSTR,"http stop ok");
    return MOS_OK;
}

_INT Http_Destroyed()
{
    if (Http_GetMgr()->iInitFlag == 0)
    {
        MOS_LOG_INF(HTTP_LOGSTR,"Already Destroy !!");
        return MOS_OK;
    }
    ST_MOS_LIST_ITERATOR stIterator;
    ST_HTTP_MGR_NODE *pstHttpMgrNode = MOS_NULL;
    // 遍历读链表
    FOR_EACHDATA_INLIST(&(Http_GetMgr()->stHttpNodeList), pstHttpMgrNode, stIterator)
    {
        Http_Del_Fd(pstHttpMgrNode);
    }
    Mos_MutexDelete(&(Http_GetMgr()->hTaskMutex));
    if (Http_GetMgr()->iEpollFd > 0)
    {
        close(Http_GetMgr()->iEpollFd);
        Http_GetMgr()->iEpollFd = MOS_SOCKET_INVALID;
    }
    Http_GetMgr()->iInitFlag = 0;
    MOS_LOG_INF(HTTP_LOGSTR, "Http Destroy ok");
    return MOS_OK;
}

// 创建阻塞socket并且连接
_SOCKET Http_CreateSocketBlockAndConnect(_UC *pucHost, _INT iPort, _INT iTimeout, _UI *puiConnType, _UI *puiHasIpv6)
{
    MOS_PARAM_INVALID_RET(pucHost, MOS_NULL, MOS_SOCKET_INVALID);

    _BOOL bConnected                    = MOS_TRUE;
    _SOCKET hSocket                     = MOS_SOCKET_INVALID;
    ST_MOS_INET_IP *pstIpInfo           = MOS_NULL;
    ST_MOS_INET_IPARRAY stIpArrayInfo   = {0};
    _ULLID ullBeginTime                 = 0;
    _UI uiIPv6Flag                      = 0;
    _INT i                              = 0;

    // 获取服务器地址信息
    if (Mos_InetGetAddrInfo(pucHost,iPort,EN_CINET_PRTL_TCP,MOS_TRUE,&stIpArrayInfo) != MOS_OK)
    {
        MOS_LOG_WARN(HTTP_LOGSTR, "Mos_InetGetAddrInfo(%s %d) Failed, Again", pucHost, iPort); 
        if (Mos_InetGetAddrInfo(pucHost,iPort,EN_CINET_PRTL_TCP,MOS_TRUE,&stIpArrayInfo) != MOS_OK)
        {
            return MOS_SOCKET_INVALID;
        }
    }
    for (i = 0; i < stIpArrayInfo.uiCount; i++)
    {
        if (stIpArrayInfo.astIps[i].usType == EN_CINET_TYPE_IPV6)
        {
            uiIPv6Flag = 1;
            break;
        }
    }
    if (puiHasIpv6)
    {
        *puiHasIpv6 = uiIPv6Flag;
    }
    ullBeginTime = Mos_GetLLTickCount();
    do
    {
        // 设备支持IPv6 优先使用IPv6进行连接
        if (Config_GetCamaraMng()->uiIPv6Ability && Config_GetCamaraMng()->uiIPv6Switch)
        {
            // 从stIpArrayInfo获取ipv6地址
            pstIpInfo = Http_GetInetIPByIpArray(&stIpArrayInfo, EN_CINET_TYPE_IPV6);
            if (pstIpInfo == MOS_NULL)
            {
                break;
            }
            hSocket = Mos_SocketOpen(pstIpInfo->usType, EN_CINET_PRTL_TCP, MOS_TRUE, MOS_TRUE);
            if (hSocket == MOS_SOCKET_INVALID)
            {
                Mos_SocketClose(hSocket);
                break;
            }
            
            //设置发送/接收超时500ms
            if (Mos_SocketSetSendTimeOutMs(hSocket, MOS_INET_IPV6_TIMEOUT_MS) != MOS_OK)
            {
                Mos_SocketClose(hSocket);
                break;
            }
            if (Mos_SocketSetRecvTimeOutMs(hSocket, MOS_INET_IPV6_TIMEOUT_MS) != MOS_OK)
            {
                Mos_SocketClose(hSocket);
                break;
            }

            if (Mos_SocketConnect(hSocket, pstIpInfo, &bConnected) != MOS_OK)
            {
                Mos_SocketClose(hSocket);
                MOS_LOG_WARN(HTTP_LOGSTR, "http1 request failed ipv6 time: %llu", Mos_GetLLTickCount() - ullBeginTime);
                break;
            }

            //设置发送/接收超时
            if (iTimeout > 0)
            {
                //设置发送/接收超时
                if (Mos_SocketSetSendTimeOut(hSocket, iTimeout) != MOS_OK)
                {
                    Mos_SocketClose(hSocket);
                    break;
                }
                if (Mos_SocketSetRecvTimeOut(hSocket, iTimeout) != MOS_OK)
                {
                    Mos_SocketClose(hSocket);
                    break;
                }                
            }

            MOS_LOG_INF(HTTP_LOGSTR, "http1 request succeed ipv6 time: %llu", Mos_GetLLTickCount() - ullBeginTime);
            if (puiConnType)
            {
                *puiConnType = EN_CINET_TYPE_IPV6;
            }
            Mos_SocketSetSendBuf(hSocket, 32 * 1024);
            return hSocket;
        }
    } while (0);

    // IPv6连接失败或者设备不支持IPv6则使用IPv4进行连接
    // 从stIpArrayInfo获取ipv4地址
    pstIpInfo = Http_GetInetIPByIpArray(&stIpArrayInfo, EN_CINET_TYPE_IPV4);
    if (pstIpInfo == MOS_NULL)
    {
        return MOS_SOCKET_INVALID;
    }

    hSocket = Mos_SocketOpen(pstIpInfo->usType, EN_CINET_PRTL_TCP, MOS_TRUE, MOS_TRUE);
    if (hSocket == MOS_SOCKET_INVALID)
    {
        Mos_SocketClose(hSocket);
        return MOS_SOCKET_INVALID;
    }
    
    //设置发送/接收超时
    if (iTimeout > 0)
    {
        if (Mos_SocketSetSendTimeOut(hSocket, iTimeout) != MOS_OK)
        {
            Mos_SocketClose(hSocket);
            return MOS_SOCKET_INVALID;
        }
        if (Mos_SocketSetRecvTimeOut(hSocket, iTimeout) != MOS_OK)
        {
            Mos_SocketClose(hSocket);
            return MOS_SOCKET_INVALID;
        }
    }

    if (Mos_SocketConnect(hSocket, pstIpInfo, &bConnected) != MOS_OK)
    {
        Mos_SocketClose(hSocket);
        MOS_LOG_WARN(HTTP_LOGSTR, "http1 request failed ipv4 time: %llu", Mos_GetLLTickCount() - ullBeginTime);
        return MOS_SOCKET_INVALID;
    }

    MOS_LOG_INF(HTTP_LOGSTR, "http1 request succeed ipv4 time: %llu", Mos_GetLLTickCount() - ullBeginTime);
    if (puiConnType)
    {
        *puiConnType = EN_CINET_TYPE_IPV4;
    }
    Mos_SocketSetSendBuf(hSocket, 32 * 1024);

    return hSocket;
}

// 创建阻塞socket并且连接 bNoDelay默认为MOS_FALSE（注意：该接口没有设置Mos_SocketSetSendBuf的大小，使用者需要获取socket后手动设置）
_SOCKET Http_CreateSocketBlockAndConnect2(_UC *pucHost, _INT iPort, _INT iConnectTimeout, _INT iSTimeout,
                                        _INT iRTimeout, _BOOL bNoDelay, _UI *puiConnType, _UI *puiHasIpv6)
{
    MOS_PARAM_INVALID_RET(pucHost, MOS_NULL, MOS_SOCKET_INVALID);

    _BOOL bConnected                    = MOS_TRUE;
    _BOOL bTimeout                      = MOS_FALSE;
    _SOCKET hSocket                     = MOS_SOCKET_INVALID;
    ST_MOS_INET_IP *pstIpInfo           = MOS_NULL;
    ST_MOS_INET_IPARRAY stIpArrayInfo   = {0};
    _ULLID ullBeginTime                 = 0;
    _UI uiIndex                         = 0;
    _UI auiConnectType[2]               = {0};
    _ULLID aullConnectTimeoutMs[2]      = {0};
    _UI uiIPv6Flag                      = 0;
    _INT i                              = 0;

    // 获取服务器地址信息
    if (Mos_InetGetAddrInfo(pucHost,iPort,EN_CINET_PRTL_TCP,MOS_TRUE,&stIpArrayInfo) != MOS_OK)
    {
        MOS_PRINTF("Mos_InetGetAddrInfo(%s %d) Failed, Again", pucHost, iPort); 
        if (Mos_InetGetAddrInfo(pucHost,iPort,EN_CINET_PRTL_TCP,MOS_TRUE,&stIpArrayInfo) != MOS_OK)
        {
            MOS_LOG_WARN(HTTP_LOGSTR, "Mos_InetGetAddrInfo(%s %d) Failed x2", pucHost, iPort); 
            return MOS_SOCKET_INVALID;
        }
    }
    for (i = 0; i < stIpArrayInfo.uiCount; i++)
    {
        if (stIpArrayInfo.astIps[i].usType == EN_CINET_TYPE_IPV6)
        {
            uiIPv6Flag = 1;
            break;
        }
    }
    if (puiHasIpv6)
    {
        *puiHasIpv6 = uiIPv6Flag;
    }
    auiConnectType[0] = EN_CINET_TYPE_IPV6;
    auiConnectType[1] = EN_CINET_TYPE_IPV4;
    aullConnectTimeoutMs[0] = MOS_INET_IPV6_TIMEOUT_MS;
    aullConnectTimeoutMs[1] = (iConnectTimeout > 0)?(iConnectTimeout*1000):(10*1000);

    if (Config_GetCamaraMng()->uiIPv6Ability && Config_GetCamaraMng()->uiIPv6Switch)
    {
        uiIndex = 0;// 优先ipv6
    }
    else
    {
        uiIndex = 1;// 直接使用ipv4
    }

    for (; uiIndex<2; uiIndex++)
    {
        bConnected = MOS_TRUE;
        bTimeout   = MOS_FALSE;

        ullBeginTime = Mos_GetLLTickCount();
        do 
        {
            // 从stIpArrayInfo获取地址
            pstIpInfo = Http_GetInetIPByIpArray(&stIpArrayInfo, auiConnectType[uiIndex]);
            if (pstIpInfo == MOS_NULL)
            {
                MOS_PRINTF("%s Http_GetInetIPByIpArray not found ipv%d ip\n", __FUNCTION__, ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4));
                break;
            }

            // 创建socket, 非阻塞
            hSocket = Mos_SocketOpen(pstIpInfo->usType, EN_CINET_PRTL_TCP, MOS_FALSE, MOS_TRUE);
            if (hSocket == MOS_SOCKET_INVALID)
            {
                MOS_PRINTF("%s Mos_SocketOpen failed ipv%d\n", __FUNCTION__, ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4));
                break;
            }
            if (bNoDelay == MOS_TRUE)
            {
                if (Mos_SocketSetOptNodelay(hSocket, MOS_TRUE) != MOS_OK)
                {
                    MOS_LOG_ERR(HTTP_LOGSTR, "Mos_SocketSetOptNodelay failed ipv%d", ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4));
                    break;
                }
            }
            if (Mos_SocketConnect(hSocket, pstIpInfo, &bConnected) != MOS_OK)
            {
                MOS_PRINTF("%s Mos_SocketConnect failed ipv%d\n", __FUNCTION__, ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4));
                break;
            }

            if (bConnected == MOS_FALSE)
            {
                _INT iTimeoutMs    = 0;
                _INT iMaxTimeoutMs = 0;
                _INT iSelectReady  = 0;
                _ULLID ullConnTime = 0;
                MOS_FD_SET fdWSet;
                
                Mos_InetFDCreate(&fdWSet);
                iTimeoutMs    = aullConnectTimeoutMs[uiIndex];
                iMaxTimeoutMs = aullConnectTimeoutMs[uiIndex];
                ullConnTime   = Mos_GetLLTickCount();

                while (iTimeoutMs > 0)
                {
                    MOS_INET_FD_ZERO(fdWSet);
                    MOS_INET_FD_SET(hSocket, fdWSet);
                    // select监听 设置超时
                    iSelectReady = Mos_SocketSelect(hSocket + 1, MOS_NULL, fdWSet, MOS_NULL, iTimeoutMs);
                    if (iSelectReady > 0)
                    {
                        // 正常环境下，接收到可写信号，socket正常，则可判断为socket已连接
                        if (Mos_SockCheckBoolConnect(hSocket) == MOS_TRUE)
                        {
                            // 优化处理：新增判断是否连接, 规避网络异常情况导致未连接socket出现异常
                            if (Mos_SockCheckBoolConnectLink(hSocket) == MOS_TRUE && Mos_InetFDIsSet(hSocket, fdWSet))
                            {
                                bConnected = MOS_TRUE;
                            }
                            else
                            {
                                // 休眠,防止持续触发导致频繁占用CPU
                                Mos_Sleep(50);
                                // 判断socket未连接，但不一定socket出错
                                iTimeoutMs = (_INT)(Mos_GetLLTickCount() - ullConnTime);
                                if (iTimeoutMs >= iMaxTimeoutMs)
                                {
                                    // 超时，退出
                                    bTimeout = MOS_TRUE;
                                }
                                else
                                {
                                    // 未超时，继续监听socket，计算监听超时时间
                                    iTimeoutMs = iMaxTimeoutMs - iTimeoutMs;
                                    continue;
                                }
                            }
                        }
                        else
                        {
                            bConnected = MOS_FALSE;
                        }
                    }
                    else if (iSelectReady == 0)
                    {
                        bTimeout = MOS_TRUE;
                    }
                    else
                    {
                        bConnected = MOS_FALSE;
                    }
                    break;
                }

                Mos_InetFDDelete(fdWSet);
            }

            if (bTimeout == MOS_TRUE || (bConnected != MOS_TRUE))
            {
                break;
            }

            // 设置为阻塞
            if (Mos_SocketSetOptBlk(hSocket, MOS_TRUE) != MOS_OK)
            {
                MOS_LOG_ERR(HTTP_LOGSTR, "Mos_SocketSetOptBlk failed ipv%d", ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4));
                break;
            }

            //设置发送超时
            if (iSTimeout > 0)
            {
                if (Mos_SocketSetSendTimeOut(hSocket, iSTimeout) != MOS_OK)
                {
                    MOS_LOG_ERR(HTTP_LOGSTR, "Mos_SocketSetSendTimeOut failed ipv%d", ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4));
                    break;
                }
            }
            //设置接收超时
            if (iRTimeout > 0)
            {
                if (Mos_SocketSetRecvTimeOut(hSocket, iRTimeout) != MOS_OK)
                {
                    MOS_LOG_ERR(HTTP_LOGSTR, "Mos_SocketSetRecvTimeOut failed ipv%d", ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4));
                    break;
                }
            }
            MOS_LOG_INF(HTTP_LOGSTR, "http2 connect succeed ipv%d time: %llu", 
                ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4), Mos_GetLLTickCount() - ullBeginTime);
            if (puiConnType)
            {
                *puiConnType = auiConnectType[uiIndex];
            }
            return hSocket;
        } while(0);

        if (bTimeout == MOS_TRUE)
        {
            MOS_LOG_WARN(HTTP_LOGSTR, "http2 connect failed timeout ipv%d time: %llu", 
                ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4), Mos_GetLLTickCount() - ullBeginTime);
        }
        else if (hSocket != MOS_SOCKET_INVALID)
        {
            MOS_LOG_WARN(HTTP_LOGSTR, "http2 connect failed ipv%d time: %llu", 
                ((auiConnectType[uiIndex]==EN_CINET_TYPE_IPV6)?6:4), Mos_GetLLTickCount() - ullBeginTime);
        }

        // 关闭socket
        if (hSocket != MOS_SOCKET_INVALID)
        {
            Mos_SocketClose(hSocket);
            hSocket = MOS_SOCKET_INVALID;
        }
    }
    return hSocket;
}
