#include "http_api.h"
#include "msgmng_type.h"
// #include "kj_aes.h"

_INT Http_EncMsgHead(ST_OGCT_PROTOCAL_HEAD *pstProtoHead, _UC ucMsgType, _UC ucMsgId, _US usBodyLen, _INT iEncType)
{
    if (MOS_NULL == pstProtoHead)
    {
        MOS_PRINTF("some param is MOS_NULL !");
        return MOS_ERR;        
    }

    pstProtoHead->aucheck[0]    = 0x23;  // #
    pstProtoHead->aucheck[1]    = 0x24;  // $
    pstProtoHead->ucMsgType     = ucMsgType;
    pstProtoHead->ucMsgId       = ucMsgId;
    pstProtoHead->usBodyLen     = MOS_INET_HTONS(usBodyLen);// (unsigned short)((usBodyLen & 0x00FF) << 8) | (unsigned short)((usBodyLen & 0xFF00) >> 8);
    pstProtoHead->ucEncFlag     = iEncType;
    pstProtoHead->ucRsv         = 0;

    return MOS_OK;
}

_INT Http_EncMsgBody(ST_OGCT_PROTOCAL_HEAD *pstProtoHead, _UC *pucMsgBody, _INT iMsgBodyLen, ST_HTTP_ENCRYPTO_INF *pstEncryInf, _UC *pucOutputBuf, _INT *iOutputBufLen)
{
    if (MOS_NULL == pstProtoHead || MOS_NULL == pucMsgBody || MOS_NULL == pstEncryInf || MOS_NULL == pucOutputBuf)
    {
        MOS_PRINTF("some param is MOS_NULL !");
        return MOS_ERR;       
    }

    _INT iEncryptLen = 0;
    if (pstEncryInf->iEncType == 0)
    {
        MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
        MOS_MEMCPY(pucOutputBuf+(sizeof(ST_OGCT_PROTOCAL_HEAD)), pucMsgBody, iMsgBodyLen);
        *iOutputBufLen = sizeof(ST_OGCT_PROTOCAL_HEAD) + iMsgBodyLen;
    }
    else
    {
        #if 1
        _UC  *ucEncrypttext = MOS_NULL;
       
        // MOS_LOG_INF(MOS_NULL,"Http_EncMsgBody EncKey:%s  EncLv:%s EncType = %d ", pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, pstEncryInf->iEncType);
        ucEncrypttext = Adpt_Aes_Encrypt_Ex(pucMsgBody, iMsgBodyLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, &iEncryptLen, ADPT_AES_PKCS7_PADDING);
        MOS_MEMCPY(pucOutputBuf, ucEncrypttext, iEncryptLen);
        *iOutputBufLen = iEncryptLen;

        MOS_FREE(ucEncrypttext);
        #else
        _UC  *ucEncrypttext = MOS_NULL;
        
        //MOS_PRINTF("ENCMSG EncKey:%s  EncLv:%s EncType = %d ", pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, pstEncryInf->iEncType);
        //MOS_BUFPRINTF("B-pucMsgBody: ", pucMsgBody, iMsgBodyLen);
        ucEncrypttext = kj_aes_encrypt_cbc(pucMsgBody, &iMsgBodyLen, MOS_NULL, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, KJ_AES_Pkcs7Padding, KJ_AES_128);
        //MOS_BUFPRINTF("e-ucEncrypttext: ", ucEncrypttext, iMsgBodyLen);
        iEncryptLen = iMsgBodyLen;
        MOS_MEMCPY(pucOutputBuf, ucEncrypttext, iEncryptLen);
        *iOutputBufLen = iEncryptLen;

        MOS_FREE(ucEncrypttext);
        #endif
    }

    return MOS_OK;
}

_INT Http_EncMsgBody2(ST_OGCT_PROTOCAL_HEAD *pstProtoHead, _UC *pucMsgBody, _INT iMsgBodyLen, ST_HTTP_ENCRYPTO_INF *pstEncryInf, _UC *pucOutputBuf, _INT *iOutputBufLen)
{
    if (MOS_NULL == pstProtoHead || MOS_NULL == pucMsgBody || MOS_NULL == pstEncryInf || MOS_NULL == pucOutputBuf)
    {
        MOS_PRINTF("some param is MOS_NULL !");
        return MOS_ERR;
    }

    if (pstEncryInf->iEncType == 0)
    {
        MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
        MOS_MEMCPY(pucOutputBuf+(sizeof(ST_OGCT_PROTOCAL_HEAD)), pucMsgBody, iMsgBodyLen);
        *iOutputBufLen = sizeof(ST_OGCT_PROTOCAL_HEAD) + iMsgBodyLen;
    }
    else
    {
        #if 1
        _UC  *ucEncrypttext = MOS_NULL;
        if (pstProtoHead->ucMsgType == EN_OGCT_METHOD_DATA)
        {
            // MOS_PRINTF("Http_EncMsgBody2-1 EN_OGCT_METHOD_DATA EncKey:%s  EncLv:%s EncType = %d \r\n", pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, pstEncryInf->iEncType);
            _UI  uiLen          = iMsgBodyLen;
            if (uiLen >= 32)
            {
                MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
                uiLen = 32;
                ucEncrypttext = (_UC *)MOS_MALLOC(uiLen);
                Adpt_Aes_Encrypt(pucMsgBody, uiLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, ucEncrypttext);     
                
                MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD), ucEncrypttext, uiLen);
                MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD)+uiLen, pucMsgBody+uiLen, iMsgBodyLen-uiLen);
            }
            else if (uiLen >= 16 && uiLen < 32)
            {
                MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
                uiLen = 16;
                ucEncrypttext = (_UC *)MOS_MALLOC(uiLen);
                Adpt_Aes_Encrypt(pucMsgBody, uiLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, ucEncrypttext);   
                
                MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD), ucEncrypttext, uiLen);
                MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD)+uiLen, pucMsgBody+uiLen, iMsgBodyLen-uiLen);
            }
            else
            {
                pstProtoHead->ucEncFlag = 0;
                MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
                MOS_MEMCPY(pucOutputBuf+(sizeof(ST_OGCT_PROTOCAL_HEAD)), pucMsgBody, iMsgBodyLen);
            }
            *iOutputBufLen = (iMsgBodyLen +(sizeof(ST_OGCT_PROTOCAL_HEAD)));
        }
        else
        {
            // MOS_PRINTF("Http_EncMsgBody2-2 EncKey:%s  EncLv:%s EncType = %d \r\n", pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, pstEncryInf->iEncType);
            ucEncrypttext = Adpt_Aes_Encrypt_Ex(pucMsgBody, iMsgBodyLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, &iMsgBodyLen, ADPT_AES_PKCS7_PADDING);
            pstProtoHead->usBodyLen = MOS_INET_HTONS(iMsgBodyLen);
            MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
            MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD), ucEncrypttext, iMsgBodyLen);
            *iOutputBufLen = (iMsgBodyLen +(sizeof(ST_OGCT_PROTOCAL_HEAD)));
        }
        MOS_FREE(ucEncrypttext);
        #else
        _UC  *ucEncrypttext = MOS_NULL;
        if (pstProtoHead->ucMsgType == EN_OGCT_METHOD_DATA)
        {
            //MOS_PRINTF("EncKey:%s  EncLv:%s EncType = %d ", pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, pstEncryInf->iEncType);
            _UI  uiLen          = iMsgBodyLen;
            if (uiLen >= 32)
            {
                MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
                uiLen = 32;
                ucEncrypttext = kj_aes_encrypt_cbc(pucMsgBody, &uiLen,  MOS_NULL,pstEncryInf->aucEncKey,
                                                   pstEncryInf->aucEncLv, KJ_AES_NewPadding, KJ_AES_128);
                MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD), ucEncrypttext, uiLen);
                MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD)+uiLen, pucMsgBody+uiLen, iMsgBodyLen-uiLen);
            }
            else if (uiLen >= 16 && uiLen < 32)
            {
                MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
                uiLen = 16;
                ucEncrypttext = kj_aes_encrypt_cbc(pucMsgBody, &uiLen,  MOS_NULL,pstEncryInf->aucEncKey,
                                                   pstEncryInf->aucEncLv, KJ_AES_NewPadding, KJ_AES_128);
                MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD), ucEncrypttext, 16);
                MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD)+uiLen, pucMsgBody+uiLen, iMsgBodyLen-uiLen);
            }
            else
            {
                pstProtoHead->ucEncFlag = 0;
                MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
                MOS_MEMCPY(pucOutputBuf+(sizeof(ST_OGCT_PROTOCAL_HEAD)), pucMsgBody, iMsgBodyLen);
            }
            *iOutputBufLen = (iMsgBodyLen +(sizeof(ST_OGCT_PROTOCAL_HEAD)));
        }
        else
        {
            ucEncrypttext = kj_aes_encrypt_cbc(pucMsgBody, &iMsgBodyLen, MOS_NULL, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, KJ_AES_Pkcs7Padding, KJ_AES_128);
            pstProtoHead->usBodyLen = MOS_INET_HTONS(iMsgBodyLen);
            MOS_MEMCPY(pucOutputBuf, pstProtoHead, sizeof(ST_OGCT_PROTOCAL_HEAD));
            MOS_MEMCPY(pucOutputBuf+sizeof(ST_OGCT_PROTOCAL_HEAD), ucEncrypttext, iMsgBodyLen);
            *iOutputBufLen = (iMsgBodyLen +(sizeof(ST_OGCT_PROTOCAL_HEAD)));
        }
        MOS_FREE(ucEncrypttext);        
        #endif
    }

    return MOS_OK;
}

_INT Http_DecMsgBody(_UC ucEncFlag, _UC* pucInOutBody, _INT iLen, ST_HTTP_ENCRYPTO_INF *pstEncryInf)
{
    // AES解密
    if (ucEncFlag == 0x31)
    {
        // MOS_PRINTF("Http_DecMsgBody iLen:%d pstEncryInf->aucEncKey:%s pstEncryInf->aucEncLv:%s \r\n", iLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv);
        #if 1
        _INT iDecryptLen = 0;
        _UC  *ucDecrypttext = (_UC *)MOS_MALLOC(iLen + 1);
        iDecryptLen = Adpt_Aes_Decrypt(pucInOutBody, iLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, ucDecrypttext);
        if (iDecryptLen == 0)//openssl的接口没有返回解密数据的长度
        {
            iDecryptLen = iLen-ucDecrypttext[iLen-1];//KJ_AES_Pkcs7Padding
        }
        if (iDecryptLen < 0 || iDecryptLen > iLen)//处理异常情况，防止内存越界
        {
            iDecryptLen = 0;
        }
        if (iDecryptLen == iLen)//防止内存越界
        {
            iDecryptLen = iLen - 1;
        }
        MOS_MEMSET(pucInOutBody, 0, iLen);
        MOS_MEMCPY(pucInOutBody, ucDecrypttext, iDecryptLen);
        pucInOutBody[iDecryptLen] = '\0';
        MOS_FREE(ucDecrypttext);
        #else
        _UC  *ucDecrypttext = MOS_NULL;

        ucDecrypttext = kj_aes_decrypt_cbc(pucInOutBody, &iLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, KJ_AES_Pkcs7Padding, KJ_AES_128);

        MOS_MEMSET(pucInOutBody, 0, iLen);
        MOS_MEMCPY(pucInOutBody, ucDecrypttext, iLen);
        pucInOutBody[iLen] = '\0';
        MOS_FREE(ucDecrypttext);
        #endif
    }
    // 无解密
    else if (ucEncFlag == 0x00)
    {
        // MOS_PRINTF("Http_DecMsgBody None encrypt \r\n");
    }

    return MOS_OK;
}

_INT Http_DecMsgBodyMedia(_UC ucEncFlag, _UC* pucInOutBody, _INT iLen, ST_HTTP_ENCRYPTO_INF *pstEncryInf)
{
    // AES解密
    if (ucEncFlag == 0x31)
    {
        // MOS_PRINTF("Http_DecMsgBodyMedia iLen:%d pstEncryInf->aucEncKey:%s pstEncryInf->aucEncLv:%s \r\n", iLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv);
        #if 1
        _INT iDecryptLen = 0;
        _UC  *ucDecrypttext = (_UC *)MOS_MALLOC(iLen + 1);
        Adpt_Aes_Decrypt(pucInOutBody, iLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, ucDecrypttext);
        iDecryptLen = iLen;//KJ_AES_NOPadding
        MOS_MEMSET(pucInOutBody, 0, iLen);
        MOS_MEMCPY(pucInOutBody, ucDecrypttext, iDecryptLen);
        MOS_FREE(ucDecrypttext);        
        #else
        _UC  *ucDecrypttext = MOS_NULL;

        ucDecrypttext = kj_aes_decrypt_cbc(pucInOutBody, &iLen, pstEncryInf->aucEncKey, pstEncryInf->aucEncLv, KJ_AES_NOPadding, KJ_AES_128);

        MOS_MEMSET(pucInOutBody, 0, iLen);
        MOS_MEMCPY(pucInOutBody, ucDecrypttext, iLen);
        MOS_FREE(ucDecrypttext);
        #endif
    }
    // 无解密
    else if (ucEncFlag == 0x00)
    {
        // MOS_PRINTF("Http_DecMsgBody None encrypt \r\n");
    }



    return MOS_OK;
}

/**********************************/
_INT Http_SendDataToPeer(_UC pucPeerId,_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen)
{
    return MOS_OK;
}

_INT Http_SendPrivateData(_UC pucPeerId, _UC *pucData, _UI uiDatalen)
{
    return MOS_OK;
}

_INT Http_DirectConnectPeer(_UC *pucPeerIp)
{
    return MOS_OK;
}

_INT Http_SetDevicGroupId(_UC *pucGroupId)
{
    return MOS_OK;
}

_INT Http_SetDevJoinGroupFlag(_UC *pucBindId,_UC *pucJoinGroup)
{
    return MOS_OK;
}

_INT Http_ClearServersAddr()
{
    return MOS_OK;
}

_INT Http_SetP2PLinkEncryKeyInf(_UC *pucPeerId,_INT iEncType,_UC *pucEncKey,_UC *pucEncLv)
{
    return MOS_OK;
}

