#include "mos.h"
#include "adpt_json_adapt.h"
#include "msgmng_type.h"
#include "config_system.h"
#include "http_common.h"

//http header 需要添加"Connection: Close\r\n"强制关闭keep-alive
#define HTTP_POST "POST %s HTTP/1.1\r\nHOST: %s:%d\r\nAccept: */*\r\n"\
    "Content-Type: application/json\r\nConnection: Close\r\nContent-Length: %d\r\n"

#define HTTP_GET "GET %s HTTP/1.1\r\nHOST: %s:%d\r\nAccept: */*\r\nConnection: Close\r\n"

#define HTTP_PUT "PUT %s HTTP/1.1\r\nHost: %s\r\nContent-Type: application/octet-stream\r\n"\
        "Content-Length: %d\r\n"                                                  

/****************HTTP SEND*************/
static _INT Http_SendData(ST_HTTP_NODE *pstHttpNode, _UC* pucData, _INT iLength)
{
    if (iLength <= 0 || pucData == MOS_NULL)
    {
        return MOS_ERR;
    }

    _INT iRet = 0;
    _INT iLen = 0;
    _BOOL pbOutWait = MOS_ERR;

    if (pstHttpNode->uiSSLFlag)
    {
        iRet = Adpt_SSL_Write_Ex(pstHttpNode->hSSL, (_UC *)pucData, iLength, &iLen);
        if (iRet == ITRD_OK)
        {
            HTTP_LOG_INF("SEND sendLength %d\n%s\n", iLen, pucData);
            return iLen;
        }
        else if (iRet == ITRD_ERR)
        {
            return MOS_ERR;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        iRet = Mos_SocketSend(pstHttpNode->hSocket, (_UC *)pucData, iLength, &pbOutWait);
        if (iRet > 0)
        {
            HTTP_LOG_INF("SEND sendLength %d\n%s\n", iRet, pucData);
            return iRet;
        }
        else if (pbOutWait == MOS_TRUE)
        {
            return 0; /*return iRet;*/
        }
        else
        {
            return MOS_ERR;
        }
    }
}

_INT Http_Process_Send(ST_HTTP_NODE *pstHttpNode)
{
    _INT iRet = MOS_ERR;
    _UC aucRequest[HTTP_SEND_BUFFER_SIZE] = {0};

    // 发送头部
    if (pstHttpNode->iRetCode == EN_HTTP_STATUS_CONNECTED)
    {
        _UI uiLength = 0;
        // 组建Header
        if (pstHttpNode->iMethod == EN_HTTP_METHOD_GET)
        {
            MOS_SPRINTF(aucRequest, HTTP_GET, pstHttpNode->pucUrl, pstHttpNode->pucHost, pstHttpNode->iPort);
        }
        else if(pstHttpNode->iMethod == EN_HTTP_METHOD_POST)
        {
            MOS_SPRINTF(aucRequest, HTTP_POST, pstHttpNode->pucUrl, pstHttpNode->pucHost, pstHttpNode->iPort, pstHttpNode->uiContentLen);
        }
        else if(pstHttpNode->iMethod == EN_HTTP_METHOD_PUT)
        {
            MOS_SPRINTF(aucRequest, HTTP_PUT, pstHttpNode->pucUrl, pstHttpNode->pucHost, pstHttpNode->uiContentLen);
        }
        if(pstHttpNode->pucExpandHeader)
        {
            MOS_STRCAT(aucRequest, pstHttpNode->pucExpandHeader);
        }   
        MOS_STRCAT(aucRequest, "\r\n");
        uiLength = MOS_STRLEN(aucRequest) - pstHttpNode->iSendPos;

        // 发送Header
        iRet = Http_SendData(pstHttpNode, aucRequest + pstHttpNode->iSendPos, uiLength);
        if (iRet == MOS_ERR)                                /*发送错误*/
        {
            MOS_LOG_ERR(HTTP_LOGSTR, "Http_SendData error [%d]", pstHttpNode->uiReqId);
            return MOS_ERR;
        }
        else if (iRet == uiLength)                          /*发送完头部*/
        {
            pstHttpNode->iRetCode = EN_HTTP_STATUS_SEND_HEADER_OVER;
            if (MOS_STRSTR(aucRequest, "Expect: 100-continue"))
            {
                pstHttpNode->iSendPos = 0;
                return MOS_OK;                              /*请求头有100，收到服务器回复后再发送内容*/
            }
            if (pstHttpNode->uiContentLen > 0)              /*具备content数据，继续发送*/
            {
                pstHttpNode->iSendPos = 0;
                return EN_HTTP_TRY_AGAIN;
            }
            return MOS_OK;
        }
        else                                                /*发送了部分数据*/
        {
            pstHttpNode->iSendPos += iRet;
            return EN_HTTP_TRY_AGAIN;
        }
    }
    // 发送数据
    else if (pstHttpNode->iRetCode == EN_HTTP_STATUS_SEND_HEADER_OVER)
    {   
        _UI i = 0;
        _UI uiLength       = 0;
        _INT iRecvMaxTimes = ((128*1024)/HTTP_SEND_BUFFER_SIZE);
        /*HTTP_SOCKET_BUFFER_SIZE/HTTP_SEND_BUFFER_SIZE 必须大于 0*/
        for (;i < iRecvMaxTimes; i++)
        {
            // 大数据发送 pstHttpNode->pfuncGetData与pucContent不能同时传入
            if (pstHttpNode->pfuncGetData)
            {
                if (pstHttpNode->uiTmpBuffLen == 0)             /*判断需不需要重新获取数据*/
                {
                    pstHttpNode->uiTmpBuffLen = pstHttpNode->pfuncGetData(pstHttpNode->vpUserPtr, pstHttpNode->pucTmpBuff, HTTP_SEND_BUFFER_SIZE, pstHttpNode->uiReqId);
                    if (pstHttpNode->uiTmpBuffLen < 0)          /*回调发生错误*/
                    {
                        MOS_LOG_ERR(HTTP_LOGSTR, "pstHttpNode->pfuncGetData [%d]", pstHttpNode->uiReqId);
                        return MOS_ERR;
                    }
                    else if(pstHttpNode->uiTmpBuffLen == 0)     /*无数据可读*/
                    {
                        pstHttpNode->iRetCode = EN_HTTP_STATUS_SEND_BODY_OVER;
                        return MOS_OK;
                    }
                    else{}
                }

                uiLength = pstHttpNode->uiTmpBuffLen - pstHttpNode->iSendPos;
                iRet = Http_SendData(pstHttpNode, pstHttpNode->pucTmpBuff + pstHttpNode->iSendPos, uiLength);         
            }
            else
            {
                uiLength = pstHttpNode->uiContentLen - pstHttpNode->iSendPos;
                iRet = Http_SendData(pstHttpNode, pstHttpNode->pucContent + pstHttpNode->iSendPos, uiLength);        
            }

            if (iRet < 0)                                       /*发送错误*/
            {
                MOS_LOG_ERR(HTTP_LOGSTR, "Http_SendData error [%d]", pstHttpNode->uiReqId);
                return MOS_ERR;
            }
            else if (iRet == uiLength)                          /*发送完成*/
            {
                if (pstHttpNode->pfuncGetData)                  /*应用层还有数据，继续发送*/
                {
                    MOS_MEMSET(pstHttpNode->pucTmpBuff, 0, HTTP_SEND_BUFFER_SIZE);
                    pstHttpNode->uiTmpBuffLen = 0;
                    pstHttpNode->iSendPos     = 0;
                    continue;
                    // return EN_HTTP_TRY_AGAIN;
                }
                else
                {
                    pstHttpNode->iRetCode = EN_HTTP_STATUS_SEND_BODY_OVER;
                    return MOS_OK;
                }
            }
            else                                                /*发送部分数据*/
            {
                pstHttpNode->iSendPos += iRet;
                return EN_HTTP_TRY_AGAIN;
            }
        }
        return EN_HTTP_TRY_AGAIN;
    }
    // 握手连接
    else
    {
        // https 需要多进行一步密钥交互
        if (pstHttpNode->uiSSLFlag == 1)
        {
            if (pstHttpNode->iRetCode == EN_HTTP_STATUS_CREATE_SSL)
            {
                if (Adpt_SSL_Create(pstHttpNode->hSocket, &pstHttpNode->hSSL) == ITRD_ERR)
                {
                    MOS_LOG_ERR(HTTP_LOGSTR, "Adpt_SSL_Create error [%d]", pstHttpNode->uiReqId);
                    return MOS_ERR;
                }

                if (Adpt_SSL_SetClientMode(pstHttpNode->hSSL, ITRD_TRUE) == ITRD_ERR)
                {
                    MOS_LOG_ERR(HTTP_LOGSTR, "Adpt_SSL_SetClientMode error [%d]", pstHttpNode->uiReqId);
                    return MOS_ERR;
                }

                iRet = Adpt_SSL_Connect_Ex(pstHttpNode->hSSL, pstHttpNode->pucHost);
                if (iRet == ITRD_OK)
                {
                    pstHttpNode->iRetCode = EN_HTTP_STATUS_CONNECTED;
                }
                else
                {
                    if (iRet == ITRD_ERR)
                    {
                        MOS_LOG_ERR(HTTP_LOGSTR, "CONNECT [%d] fail", pstHttpNode->uiReqId);
                        return MOS_ERR;
                    }
                    pstHttpNode->iRetCode = EN_HTTP_STATUS_CONNECTING;
                }
                return EN_HTTP_TRY_AGAIN; 
            }
            else if (pstHttpNode->iRetCode == EN_HTTP_STATUS_CONNECTING)
            {
                // 判断是否已连接 
                iRet = Adpt_SSL_Connect_Ex(pstHttpNode->hSSL, pstHttpNode->pucHost);
                if (iRet == ITRD_OK)
                {
                    pstHttpNode->iRetCode = EN_HTTP_STATUS_CONNECTED;
                }
                else
                {
                    if (iRet == ITRD_ERR)
                    {
                        MOS_LOG_ERR(HTTP_LOGSTR, "CONNECT [%d] fail", pstHttpNode->uiReqId);
                        return MOS_ERR;          
                    }
                    pstHttpNode->iRetCode = EN_HTTP_STATUS_CONNECTING;
                }

                return EN_HTTP_TRY_AGAIN;  
            }
        }
        else
        {
            pstHttpNode->iRetCode = EN_HTTP_STATUS_CONNECTED;
            return EN_HTTP_TRY_AGAIN;
        }
    }

    return MOS_OK;
}

/****************HTTP RECV*************/
static _INT Http_Parser_Header(_UC *pucData, _UI uiLength, ST_HTTP_PRASE_HEAD *stHttpParseHead)
{
    _UI uiPos = 0;
    _INT iLen = 0;
    _UC *pucBody = pucData;
    _UC *pucPtr   = MOS_NULL;
    _UC *pucPtrTmp = MOS_NULL;
    _UC aucHeader[HTTP_HEADER_SIZE] = {0};

    while (uiPos <= uiLength)
    {
        aucHeader[uiPos] = *pucBody++;
        if (aucHeader[uiPos] == '\n')
        {
            pucPtr = MOS_STRSTR(aucHeader,"HTTP/1.1");
            if(pucPtr == MOS_NULL)
            {
                pucPtr = MOS_STRSTR(aucHeader,"HTTP/1.0");
            }
            if (pucPtr != MOS_NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,' ');
                pucPtr++;
                stHttpParseHead->iResultCode = MOS_ATOI(pucPtr);
            }
            pucPtr = MOS_STRSTR(aucHeader,"Content-Length:");
            if (pucPtr != MOS_NULL)
            {
                // 如果是keep alive，则content-length和chunk必然是二选一
                // 若是非keep alive，则和http1.0一样。content-length可有可无
                // Transfer-Encoding: chunked
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                stHttpParseHead->iContentLength = MOS_STRTOL(pucPtr, 10);
            }
            pucPtr = MOS_STRSTR(aucHeader,"Transfer-Encoding: chunked");
            if (pucPtr != MOS_NULL)
            {
                stHttpParseHead->iChunkFlag = 1;
            }
            pucPtr = MOS_STRSTR(aucHeader,"Location:");
            if (pucPtr != MOS_NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                pucPtrTmp = MOS_STRCHR(pucPtr,'\r');
                iLen = pucPtrTmp - pucPtr;
                if (stHttpParseHead->ucRedirectUrl)
                {
                    MOS_STRNCPY(stHttpParseHead->ucRedirectUrl, pucPtr+1, iLen-1);
                    // MOS_PRINTF("%s:%d: RedirectUrl:%s \r\n", __FUNCTION__, __LINE__, pstHttpParseHead->ucRedirectUrl);
                }
            }
            pucPtr = MOS_STRSTR(aucHeader,"WWW-Authenticate:");
            if (pucPtr != MOS_NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                pucPtrTmp = MOS_STRCHR(pucPtr,'\r');
                iLen = pucPtrTmp - pucPtr;
                if (stHttpParseHead->ucWWWAuthenticate)
                {
                    MOS_STRNCPY(stHttpParseHead->ucWWWAuthenticate, pucPtr+1, iLen-1);
                    // MOS_PRINTF("%s:%d: WWW-Authenticate:%s \r\n", __FUNCTION__, __LINE__, pstHttpParseHead->ucWWWAuthenticate);
                }
            }
            // MOS_PRINTF_DEBUG("%s", aucHeader);
            //"\r\n"后接着"\r\n"
            if (aucHeader[0] == '\r' && aucHeader[1] == '\n')
            {
                return MOS_OK;
            }
            uiPos = -1;
        }
        uiPos++;
    }

    return MOS_ERR;
}

static _INT Http_Parser_Execute(ST_HTTP_NODE *pstHttpNode, _UC *pucData, _UI uiLength, _UI uiFirstFlag)
{
    _UI uiHeaderLength    = 0;
    _UC *pucBody          = pucData;
    ST_HTTP_PRASE_HEAD stHttpParseHead = {0};

    // 解析http头部
    while(uiFirstFlag && uiHeaderLength <= uiLength && pstHttpNode->iHeaderIndex <= HTTP_HEADER_SIZE)
    {
        pstHttpNode->aucHeader[pstHttpNode->iHeaderIndex] = *pucBody++;
        uiHeaderLength++;
        if (pstHttpNode->iHeaderIndex >= 3 &&
            pstHttpNode->aucHeader[pstHttpNode->iHeaderIndex-3] == '\r' &&
            pstHttpNode->aucHeader[pstHttpNode->iHeaderIndex-2] == '\n' &&
            pstHttpNode->aucHeader[pstHttpNode->iHeaderIndex-1] == '\r' &&
            pstHttpNode->aucHeader[pstHttpNode->iHeaderIndex]   == '\n')
        {
            _INT iRet = Http_Parser_Header(pstHttpNode->aucHeader, pstHttpNode->iHeaderIndex, &stHttpParseHead);
            if (iRet == MOS_ERR)
                return MOS_ERR;
            if (pstHttpNode->pfuncRecvHeader)
            {
                pstHttpNode->pfuncRecvHeader(pstHttpNode->vpUserPtr, pstHttpNode->uiReqId, stHttpParseHead);
            }
            pstHttpNode->iResultCode  = stHttpParseHead.iResultCode;
            pstHttpNode->iChunkFlag   = stHttpParseHead.iChunkFlag;
            pstHttpNode->iReservLen   = stHttpParseHead.iContentLength;
            MOS_MEMSET(pstHttpNode->aucHeader, 0, sizeof(pstHttpNode->aucHeader));
            pstHttpNode->iHeaderIndex = 0;
            break;
        }
        pstHttpNode->iHeaderIndex++;
    }
    if (pstHttpNode->iResultCode == 0)
    {
        // 查找头部失败
        if (pstHttpNode->iHeaderIndex > HTTP_HEADER_SIZE)
        {
            MOS_LOG_ERR(HTTP_LOGSTR, "[%u] RECV Header size > HTTP_HEADER_SIZE", pstHttpNode->uiReqId);
            return MOS_ERR;
        }
        else
        {
            return EN_HTTP_RECV_CONTINUE;
        }
    }

    if (pstHttpNode->iChunkFlag == 0)
    {
        if (uiLength - uiHeaderLength > 0)
        {
            if (pstHttpNode->pfuncRecv)
            {
                pstHttpNode->pfuncRecv(pucBody, uiLength - uiHeaderLength, pstHttpNode->vpUserPtr, pstHttpNode->uiReqId);
                HTTP_LOG_INF("RECV DataLength %d HeadLength %d ReservLen %d",uiLength,uiHeaderLength,pstHttpNode->iReservLen);
                pstHttpNode->iReservLen -= (uiLength - uiHeaderLength);
            }
            
            if (pstHttpNode->iReservLen <= 0)
            {
                return EN_HTTP_RECV_FINISH;
            }
            else
            {
                return EN_HTTP_RECV_CONTINUE;
            }
        }
        else if (uiLength - uiHeaderLength == 0 && pstHttpNode->iReservLen == 0)
        {
            /*服务器的回复内容为空*/
            return EN_HTTP_RECV_FINISH;
        }
        else
        {
            return EN_HTTP_RECV_CONTINUE;
        }
    }
    else if (pstHttpNode->iChunkFlag == 1)
    {
        _UI uiIndex = 0;
        _UI uiChunkHeadLength = 0;
        _UI uiDataLength  = 0;
        _UI uiChunkLength = 0;

        do
        {
            uiIndex = 0;
            uiChunkHeadLength  = 0;
            _INT iEndFlagIndex = uiLength - uiHeaderLength;
            if (iEndFlagIndex <= 0)
            {
                return EN_HTTP_RECV_CONTINUE;
            }
            // ReservLen == 0 需要获取chunk size
            if (pstHttpNode->iReservLen == 0)
            {
                uiIndex = pstHttpNode->iHeaderIndex;
                while(iEndFlagIndex > 0)
                {
                    pstHttpNode->aucHeader[uiIndex] = *pucBody;
                    uiIndex++;
                    uiChunkHeadLength++;
                    // 非第一次读取的\r\n去除
                    if (pstHttpNode->aucHeader[0] == '\r' && pstHttpNode->aucHeader[1] == '\n')
                    {
                        uiIndex = 0;
                        pucBody++;
                        continue;
                    }
                    
                    if (*pucBody == '\n')
                    {
                        pstHttpNode->iReservLen = MOS_STRTOL(pstHttpNode->aucHeader, 16);
                        MOS_MEMSET(pstHttpNode->aucHeader, 0, sizeof(pstHttpNode->aucHeader));
                        pstHttpNode->iHeaderIndex = 0;
                        if (pstHttpNode->iReservLen == 0)
                        {
                            return EN_HTTP_RECV_FINISH;
                        }
                        pucBody++;
                        break;
                    }
                    pucBody++;
                    iEndFlagIndex--;
                }

                // 仍未成功组合chunk size
                if (pstHttpNode->iReservLen == 0)
                {
                    pstHttpNode->iHeaderIndex = uiIndex;
                    return EN_HTTP_RECV_CONTINUE;
                }
            }

            uiDataLength = uiLength - uiHeaderLength - uiChunkHeadLength;
            HTTP_LOG_INF("RECV inputLength :%d headlength :%d chunklength :%d datalength :%d chunksize :%d\n", uiLength,uiHeaderLength,uiChunkHeadLength,uiDataLength,pstHttpNode->iReservLen);
            if (uiDataLength <= 0)
            {
                return EN_HTTP_RECV_CONTINUE;
            }
            // 回调数据
            if (pstHttpNode->iReservLen >= uiDataLength)
            {
                if (pstHttpNode->pfuncRecv)
                {
                    // printf("[%d] [%d]\n",pucBody[0],pucBody[uiDataLength-1]);
                    pstHttpNode->pfuncRecv(pucBody, uiDataLength, pstHttpNode->vpUserPtr, pstHttpNode->uiReqId);
                }
                pucBody += uiDataLength;
                pstHttpNode->iReservLen = pstHttpNode->iReservLen - uiDataLength;
                return EN_HTTP_RECV_CONTINUE;      // continue get data
            }
            else if (pstHttpNode->iReservLen < uiDataLength)
            {
                if (pstHttpNode->pfuncRecv)
                {
                    // printf("[%d] [%d]\n",pucBody[0],pucBody[pstHttpNode->iReservLen-1]);
                    pstHttpNode->pfuncRecv(pucBody, pstHttpNode->iReservLen, pstHttpNode->vpUserPtr, pstHttpNode->uiReqId);
                }
                pucBody += pstHttpNode->iReservLen;
                uiLength = uiLength - (pstHttpNode->iReservLen + uiHeaderLength + uiChunkHeadLength);
                uiHeaderLength = 0;
                pstHttpNode->iReservLen = 0;
                continue;     // continue get next chunk
            }

        }while(1);

    }

    return MOS_ERR;       // fail
}

_INT Http_Process_Recv(ST_HTTP_NODE *pstHttpNode)
{
    _INT i                               = 0;
    _INT iRet                            = 0;
    _INT iRecvLen                        = 0;
    _BOOL bClosed                        = MOS_FALSE;
    _UI uiReadLength                     = 0;
    _UC ucRecvBuf[HTTP_RECV_BUFFER_SIZE] = {0};
    _INT iRecvMaxTime                    = ((256*1024)/sizeof(ucRecvBuf));
    _UI uiUseTime                        = 0;

    // 读数据, 限制最大接收次数, 防止循环接收造成函数阻塞
    for (i = 0; i<iRecvMaxTime; i++)
    {
        // 判断读取长度
        if ((pstHttpNode->iReservLen == 0) || (pstHttpNode->iReservLen > sizeof(ucRecvBuf)))
        {
            uiReadLength = sizeof(ucRecvBuf);
        }
        else
        {
            uiReadLength = pstHttpNode->iReservLen;
        }

        bClosed  = MOS_FALSE;
        iRecvLen = 0;
        MOS_MEMSET(ucRecvBuf, 0, sizeof(ucRecvBuf));
        if (pstHttpNode->uiSSLFlag == 1)
        {
            iRet = Adpt_SSL_Read_Ex(pstHttpNode->hSSL, (_UC *)ucRecvBuf, uiReadLength, &iRecvLen);
        }
        else
        {
            iRecvLen = Mos_SocketRecv(pstHttpNode->hSocket, (_UC *)ucRecvBuf, uiReadLength, &bClosed);
        }

        if (((pstHttpNode->uiSSLFlag == 1) && (iRet == ITRD_ERR)) || ((pstHttpNode->uiSSLFlag == 0) && ((iRecvLen == 0) || (bClosed == MOS_TRUE))))
        {
            // recv ret 0 means the socket is closed by server
            MOS_LOG_ERR(HTTP_LOGSTR, "HTTP Recv Error [%u] ret=%d recvlen=%d close=%d", pstHttpNode->uiReqId, iRet, iRecvLen, bClosed);
            return MOS_ERR;
        }
        else if (iRecvLen > 0)
        {
            if (HTTP_LOG_FLAG)
            {
                printf("************************\n");
                printf("RECV %d %d %s\n", iRecvLen,pstHttpNode->iReservLen,ucRecvBuf);
            }
            iRet = Http_Parser_Execute(pstHttpNode, ucRecvBuf, iRecvLen, (pstHttpNode->iResultCode == 0));
            if (iRet == EN_HTTP_RECV_FINISH)
            {
                return MOS_OK;
            }
            else if (iRet == EN_HTTP_RECV_CONTINUE)
            {
                continue;
                // return EN_HTTP_TRY_AGAIN;
            }
            else
            {
                return MOS_ERR;
            } 
        }
        else /*if ((pstHttpNode->uiSSLFlag == 1) || (pstHttpNode->uiSSLFlag == 0 && iRecvLen < 0 && bClosed == MOS_TRUE))*/
        {
            // Mos_SocketRecv的recvlen小于0的情况不一定是socket错误
            if (HTTP_LOG_FLAG)
            {
                printf("RECV TRY AGAIN ssl-%d sslret-%d rlen-%d close-%d\n", pstHttpNode->uiSSLFlag, iRet, iRecvLen, bClosed);
            }
            return EN_HTTP_TRY_AGAIN;
        }
    }
    return EN_HTTP_TRY_AGAIN;
}
