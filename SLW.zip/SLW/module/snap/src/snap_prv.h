#ifndef _SNAP_PRV_H
#define _SNAP_PRV_H

#ifdef __cplusplus
extern "C" {
#endif

#define SNAP_LOGSTR                           (_UC*)"SP"
#define SNAP_DIR                              (_UC*)"Snap"
#define SNAP_DATECFG_NAME                     (_UC*)"Snapdate.txt"
#define SNAP_FILEDES_NAME                     (_UC*)"Snapfiledes.txt"
#define SNAP_DATECFG_VERSION                  (_UC*)"0001000100010001"
#define SNAP_FILEDES_VERSION                  (_UC*)"0001000100010001"

#define SNAP_AUTODELETE 7

typedef enum EN_SNAP_MSG{

    EN_SNAP_MSG_START    = 1, // 开始抓图
    EN_SNAP_MSG_SETPATH  = 2, // 设置抓拍路径
    EN_SNAP_MSG_DELETE   = 3,
    EN_SNAP_MSG_STOP     = 4
}EN_SNAP_MSG;

typedef struct st_SNAP_AUTO
{
    _UC ucOpenFlag;
    _UC ucSrv[3];
    _UI uiPicType;
    _UI uiSnapInterval;
    _CTIME_T cNextSnapTime;
}ST_TIMER_SNAP;

typedef struct str_SNAP_SNAPDATA_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _INT iSeconds;
    _INT iCamId;
    _UI uiSnapType;
    _UI uiPicType;
    _CTIME_T tCreateTime;
}ST_SNAP_MSG_INF;

typedef struct str_SNAP_SETPATH_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UC aucBuf[256];
}ST_SNAP_SETPATH_MSG;

typedef struct str_SNAP_DELETE_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _INT iCamId;
    _INT iDeleteType;
    _UI uiDeleteSize;
    _UC aucName[32];
    _UC aucTime[20];
    _UC aucDay[12];
}ST_SNAP_DELETE_MSG;

typedef struct st_SNAP_FileDes
{
    _UC      ucCheckFlag;
    _UC      ucBInUse;
    _UC      ucRsv[2];
    _UI      uiJpgType;
    _UI      uiSnapType;
    _CTIME_T cSnapTime;
    _UC      aucFileName[32];
}ST_SNAP_FILEDES;

typedef struct stru_SNAP_Cam_Node
{
    _INT iCamId;
    _INT iStatus;
    _UC ucCamOpenFlag;
    _UC aucDay[12];
    _CTIME_T cLastSnapTime;
    ST_TIMER_SNAP stTimerSnap;
    ST_SNAP_FILEDES stFileDes;
    ST_MOS_LIST_NODE stNode;
}ST_SNAPCAM_NODE;

typedef struct stru_SNAP_Task_Mng
{
    _INT iChangeFlag;
    _INT iChangePathFlag;
    _INT iInitFlag;
    _INT iStopFlag;
    _INT iMaxCamCount;
    _HQUEUE hMsgQueue;
    _UC aucCachePath[CFG_STRING_MAXLEN];
    ST_MOS_LIST stCamList;
}ST_SNAP_TASK_MNG;

#ifdef __cplusplus
}
#endif

#endif