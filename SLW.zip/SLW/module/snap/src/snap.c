#include "mos.h"
#include "IoManage_api.h"
#include "zj_interface.h"
#include "config_api.h"
#include "snap_api.h"
#include "snap_prv.h"
#include "adpt_json_adapt.h"
#include "kjiot_device_api.h"

static ST_SNAP_TASK_MNG g_SnapTaskMng;

ST_SNAP_TASK_MNG *Snap_GetMng()
{
    return &g_SnapTaskMng;
}

//路径检查OK
_VOID Snap_CheckDir(_INT iCamId,_UC *pucDay)
{
    MOS_PARAM_NULL_NORET(pucDay);

    _UC aucSnapDir[256];
    if(Snap_GetMng()->iInitFlag == 0)
    {
        MOS_LOG_WARN(SNAP_LOGSTR,"Snap task not init");
        return;
    }
     
    Mos_DirMake(Snap_GetMng()->aucCachePath,MOS_DIR_MAKE_FLAG);

    MOS_VSNPRINTF(aucSnapDir,256,"%s/%s",Snap_GetMng()->aucCachePath,SNAP_DIR);
    Mos_DirMake(aucSnapDir,MOS_DIR_MAKE_FLAG);

    MOS_VSNPRINTF(aucSnapDir,256,"%s/%s/%d",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId);
    Mos_DirMake(aucSnapDir,MOS_DIR_MAKE_FLAG);

    MOS_VSNPRINTF(aucSnapDir,256,"%s/%s/%d/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId,pucDay);
    Mos_DirMake(aucSnapDir,MOS_DIR_MAKE_FLAG);

    Snap_GetMng()->iChangePathFlag = 0;

    return ;
}

//添加filedes信息OK
_INT Snap_AddFileDes(ST_SNAPCAM_NODE *pstInNode)
{
    MOS_PARAM_NULL_RETERR(pstInNode);

    _UC aucDesName[256];
    MOS_VSNPRINTF(aucDesName,256,"%s/%s/%d/%s/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,
        pstInNode->iCamId,pstInNode->aucDay,SNAP_FILEDES_NAME);
    if(Mos_FileIsExist(aucDesName)==MOS_FALSE)
    {
        Mos_FileWriteAppend(aucDesName,SNAP_FILEDES_VERSION,MOS_STRLEN(SNAP_FILEDES_VERSION));
    }
    Mos_FileWriteAppend(aucDesName,(_UC*)&pstInNode->stFileDes,sizeof(ST_SNAP_FILEDES));
    return MOS_OK;
} 

//添加日期OK
_INT Snap_AddDate(_INT iCamId,_UC *pucDay)
{
    MOS_PARAM_NULL_RETERR(pucDay);

    _HFILE hFile;
    _INT iRet  = 0;
    _INT iSize = sizeof(ST_SNAP_DATE);
    _UC aucVersion[20]={0};
    _UC aucFileName[256];
    ST_SNAP_DATE stDateInf;

    if(MOS_STRLEN(Snap_GetMng()->aucCachePath)==0)
    {
        return MOS_OK;
    }
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%d/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId,SNAP_DATECFG_NAME);
    
    if(Mos_FileIsExist(aucFileName)==MOS_FALSE)
    {
        Mos_FileWriteAppend(aucFileName,(_UC*)SNAP_DATECFG_VERSION,MOS_STRLEN(SNAP_DATECFG_VERSION));
    }
    
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);

    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(SNAP_DATECFG_VERSION));

    if(MOS_STRCMP(aucVersion,SNAP_DATECFG_VERSION)){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap Date File Version error");
        return MOS_ERR;
    }
    while(Mos_FileEof(hFile) == MOS_FALSE)
    {
        iRet=Mos_FileRead(hFile,(_UC*)&stDateInf,iSize);
        if(iRet > 0 && iRet < iSize)
        {
            stDateInf.ucBInUse = ' ';
            stDateInf.ucCheck = '$';
            Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iRet);
            Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
            break;
        }
    }
    stDateInf.ucCheck = '$';
    stDateInf.ucBInUse = 1;

    if(MOS_STRCMP(pucDay,stDateInf.aucDate) == 0)
    {
        Mos_FileSeek(hFile,MOS_FILE_SEEK_END,-iSize);
        Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
    }
    else
    {
        MOS_STRNCPY(stDateInf.aucDate,pucDay,sizeof(stDateInf.aucDate));
        Mos_FileWrite(hFile,(_UC*)&stDateInf,iSize);
    }
    Mos_FileClose(hFile);
    return MOS_OK;
}

//查找节点
static ST_SNAPCAM_NODE *Snap_FindOrCreatCamNode(_INT iCamId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_SNAPCAM_NODE *pstCamNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Snap_GetMng()->stCamList, pstCamNode, stIterator)
    {
        if(pstCamNode->iCamId == iCamId)
        {
            return pstCamNode;
        }
    }
    pstCamNode = (ST_SNAPCAM_NODE*)MOS_MALLOCCLR(sizeof(ST_SNAPCAM_NODE));
    pstCamNode->iCamId = iCamId;
    pstCamNode->stFileDes.ucCheckFlag = 'S';
    pstCamNode->stFileDes.ucBInUse    = 'Z';
    pstCamNode->cLastSnapTime = 0;
    MOS_LIST_ADDTAIL(&Snap_GetMng()->stCamList, pstCamNode);
    return pstCamNode;
}

//根据日期删除抓拍OK
_INT Snap_DeleteJpgByDay(_INT iCamId,_UC *pucDay)
{
    MOS_PARAM_NULL_RETERR(pucDay);

    _INT iRet = 0;
    _INT iSize = sizeof(ST_SNAP_DATE);
    _UC aucFileName[256];
    _UC aucVersion[24]={0};
    _HFILE hFile=MOS_NULL;
    ST_SNAP_DATE stDate={0};
    if(MOS_STRLEN(Snap_GetMng()->aucCachePath)==0)
    {
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap save path not exist");
        return MOS_ERR;
    }
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%d/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId,SNAP_DATECFG_NAME);
    hFile=Mos_FileOpen(aucFileName, MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hFile==MOS_NULL)
    {
        MOS_LOG_WARN(SNAP_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return MOS_OK;
    }
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(SNAP_DATECFG_VERSION));
    if(MOS_STRNCMP(aucVersion, SNAP_DATECFG_VERSION,MOS_STRLEN(SNAP_DATECFG_VERSION))!=0)
    {
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap Date File Version error");
        return MOS_OK;
    }

    while(!Mos_FileEof(hFile))
    {
        iRet=Mos_FileRead(hFile,(_UC*)&stDate,iSize);
        if(iRet < iSize)
        {
            break;
        }
        if(stDate.ucCheck=='$'&&MOS_STRNCMP(stDate.aucDate,pucDay,MOS_STRLEN(pucDay))==0&& stDate.ucBInUse==1)
        {
            MOS_VSNPRINTF(aucFileName,255,"%s/%s/%d/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId,pucDay);
            Mos_DirRecurRmv(aucFileName);
            stDate.ucBInUse=' ';
            iSize=-iSize;
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,iSize);
            Mos_FileWrite(hFile,(_UC*)&stDate,sizeof(ST_SNAP_DATE));
            break;
        }
    }
    Mos_FileClose(hFile);
    MOS_LOG_INF(SNAP_LOGSTR,"delete snap OK,Camid %d,Day %s",iCamId,pucDay);
    return MOS_OK;
}

//删除多个日期(标准时间OK
_VOID Snap_DeleteMultipleDays(_UC *pucDatePath,_UC *pucDay)
{
    MOS_PARAM_NULL_NORET(pucDay);
    MOS_PARAM_NULL_NORET(pucDatePath);

    _INT iRet  = 0;
    _INT iSize = sizeof(ST_SNAP_DATE);
    _HFILE hDateFile=MOS_NULL;
    _UC aucVersion[20];
    _UC aucSnapPath[256];
    ST_SNAP_DATE stTmpDate;
    MOS_VSNPRINTF(aucSnapPath,256,"%s/%s",pucDatePath,SNAP_DATECFG_NAME);	
    hDateFile=Mos_FileOpen(aucSnapPath,MOS_FILE_O_RDWR|MOS_FILE_O_BIN);
    if(hDateFile==MOS_NULL)
    {
        MOS_LOG_WARN(SNAP_LOGSTR,"open file %s fail errno = %u",aucSnapPath,errno);
        return;
    }
    MOS_MEMSET(aucVersion,0,20);
    Mos_FileRead(hDateFile,aucVersion,MOS_STRLEN(SNAP_DATECFG_VERSION));
    if(MOS_STRCMP(aucVersion,SNAP_DATECFG_VERSION)){
        Mos_FileClose(hDateFile);
        Mos_FileRmv(aucSnapPath);
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap Date File Version error");
        return;
    }

    while(!Mos_FileEof(hDateFile))
    {
        iRet = Mos_FileRead(hDateFile,(_UC*)&stTmpDate,iSize);
        if(iRet < iSize || stTmpDate.ucCheck != '$')
        {
            break;
        }
        if(stTmpDate.ucBInUse != 1)
        {
            continue;
        }
        if(MOS_STRNCMP(stTmpDate.aucDate,pucDay,MOS_STRLEN(pucDay)) < 0)
        {
            MOS_VSNPRINTF(aucSnapPath,256,"%s/%s",pucDatePath,stTmpDate.aucDate);
            Mos_DirRecurRmv(aucSnapPath);//删除抓取文件夹
            stTmpDate.ucBInUse=' ';
            Mos_FileSeek(hDateFile,MOS_FILE_SEEK_CUR,-iSize);
            Mos_FileWrite(hDateFile,(_UC*)&stTmpDate,iSize);
        }
        else
        {
            break;
        }
    }
    Mos_FileClose(hDateFile);
    return;
}

//自动老化维护OK
_INT Snap_IoAutoDelete()
{
    _INT i = 0;
    _UC aucDay[12];
    _UC aucDatePath[256];
    _CTIME_T cTimeNow = Mos_Time() - 7*86400;
    ST_MOS_SYS_TIME stSysTime;

    Mos_TimetoSysTime(&cTimeNow,&stSysTime);
    MOS_VSNPRINTF(aucDay,12,"%04hu-%02hu-%02hu",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    for( i=0; i < Snap_GetMng()->iMaxCamCount; i++)
    {
        MOS_VSNPRINTF(aucDatePath,256,"%s/%s/%d",Snap_GetMng()->aucCachePath,SNAP_DIR,i);
        if(Mos_DirIsExist(aucDatePath))
        {
            Snap_DeleteMultipleDays(aucDatePath,aucDay);
        }
    }
    MOS_LOG_INF(SNAP_LOGSTR,"auto delete OK");
    return MOS_OK;
}

//通过名称删除对应文件OK
_INT Snap_DeleteJpgByName(_UI iCamId,_UC *pucName)
{
    MOS_PARAM_NULL_RETERR(pucName);

    _CTIME_T cFileTime;
    _HFILE hFile = MOS_NULL;
    _INT iSize = sizeof(ST_SNAP_FILEDES);
    _INT iBufSize = 0;
    _UC aucDay[12];//日期
    _UC aucVersion[20]={0};
    _UC aucFileName[256];//删除图片文件名
    ST_MOS_SYS_TIME stSysTime;
    ST_SNAP_FILEDES stFileDes = {0};

    Mos_GetSysTime(&stSysTime);

    MOS_SSCANF(pucName,"%04hu-%02hu-%02hu%02hu%02hu%02hu.jpg",&stSysTime.usYear,&stSysTime.usMonth,
               &stSysTime.usDay,&stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);

    cFileTime = Mos_SysTimetoTime(&stSysTime);

    MOS_VSNPRINTF(aucDay,12,"%04hu-%02hu-%02hu",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);

    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%d/%s/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId,aucDay,SNAP_FILEDES_NAME);
    hFile=Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
    if(hFile==MOS_NULL)
    {
        MOS_LOG_WARN(SNAP_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return MOS_OK;
    }
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(SNAP_FILEDES_VERSION));
    if(MOS_STRNCMP(aucVersion,SNAP_FILEDES_VERSION,MOS_STRLEN(SNAP_FILEDES_VERSION))){
        Mos_FileClose(hFile);
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap Des File Version error");
        return MOS_ERR;
    }
    MOS_MEMSET(&stFileDes,0,iSize);

    while(!Mos_FileEof(hFile))
    {
        iBufSize=Mos_FileRead(hFile,(_UC*)&stFileDes,iSize);
        if(iBufSize < iSize)
            break;
        if(stFileDes.cSnapTime == cFileTime)
        {
            MOS_VSNPRINTF(aucFileName,256,"%s/%s/%d/%s/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId,aucDay,pucName);
            if(Mos_FileIsExist(aucFileName)){
                Mos_FileRmv(aucFileName);
            }
            stFileDes.ucBInUse=' ';
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,-iSize);
            Mos_FileWrite(hFile,(_UC*)&stFileDes,iSize);
            break;
        }
    }
    Mos_FileClose(hFile);
    MOS_LOG_INF(SNAP_LOGSTR,"delete snap OK,Camid %d,FileName %s",iCamId,pucName);
    return MOS_OK;
}

//删除对应镜头指定时间前文件OK
_INT Snap_DeleteJpgBeforeTime(_UI iCamId,_UC *pucTime)
{
    MOS_PARAM_NULL_RETERR(pucTime);

    _CTIME_T cGiveTime;
    _HFILE hFile = MOS_NULL;
    _INT iSize = sizeof(ST_SNAP_FILEDES);
    _INT iBufSize=0;
    _UC aucDay[12];      //日期
    _UC aucVersion[20]={0};
    _UC aucDatePath[256];//snapdate文件夹
    _UC aucFileName[256];//删除图片文件名
    ST_MOS_SYS_TIME stSysTime;
    ST_SNAP_FILEDES stFileDes={0};

    Mos_GetSysTime(&stSysTime);

    MOS_SSCANF(pucTime,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",&stSysTime.usYear,&stSysTime.usMonth,
        &stSysTime.usDay,&stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);

    cGiveTime=Mos_SysTimetoTime(&stSysTime);

    MOS_VSNPRINTF(aucDatePath,256,"%s/%s/%d",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId);

    MOS_VSNPRINTF(aucDay,12,"%04hu-%02hu-%02hu",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s",aucDatePath,aucDay,SNAP_FILEDES_NAME);

    hFile=Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
    if(hFile==MOS_NULL)
    {
        MOS_LOG_WARN(SNAP_LOGSTR,"open file %s fail errno = %u",aucFileName,errno);
        return MOS_OK;
    }
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(SNAP_FILEDES_VERSION));
    
    if(MOS_STRCMP(aucVersion,SNAP_FILEDES_VERSION)){
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap Des File Version error");
        return MOS_ERR;
    }

    while(!Mos_FileEof(hFile))
    {
        iBufSize=Mos_FileRead(hFile,(_UC*)&stFileDes,iSize);
        if(iBufSize < iSize)
            break;
        if((stFileDes.cSnapTime <= cGiveTime)&& stFileDes.ucBInUse=='Z' )
        {
            Mos_TimetoSysTime(&stFileDes.cSnapTime,&stSysTime);
            MOS_VSNPRINTF(aucFileName,256,"%s/%s/%s%02hu%02hu%02hu.jpg",aucDatePath,aucDay,aucDay,
                stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
            if(Mos_FileIsExist(aucFileName)==MOS_TRUE)
            {
                Mos_FileRmv(aucFileName);
            }
            stFileDes.ucBInUse=' ';
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,-iSize);
            Mos_FileWrite(hFile,(_UC*)&stFileDes,iSize);
        }
        if(stFileDes.cSnapTime > cGiveTime){
            break;
        }
    }
    Mos_FileClose(hFile);

    Snap_DeleteMultipleDays(aucDatePath,aucDay);
    MOS_LOG_INF(SNAP_LOGSTR,"delete snap OK,Camid %d,EndTime %s",iCamId,pucTime);
    return MOS_TRUE;
}

//根据指定相机和空间大小删除文件OK
// 返回 -1 表示数据出错 
static _INT Snap_DeleteOneDayBySize(_INT iCamid,_UC *pucDay,_UI uiNeedDelSize)
{
    MOS_PARAM_NULL_RETERR(pucDay);

    _UI uiHaveDelSize = 0;
    _INT iRet = 0,iDesSize = 0;
    _HFILE hFile = MOS_NULL;
    _UC aucFileName[256];
    _UC aucVersion[24];
    ST_MOS_SYS_TIME stSysTime;
    ST_SNAP_FILEDES   stFileDes;
    ST_MOS_FILE_INF stFileInf;
    
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%d/%s/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamid,pucDay,SNAP_FILEDES_NAME);
    hFile = Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
    if(hFile == MOS_NULL)
    {
        return 0;
    }
    MOS_MEMSET(aucVersion,0,24);
    iRet = Mos_FileRead(hFile,aucVersion,MOS_STRLEN(SNAP_FILEDES_VERSION));
    if(iRet < MOS_STRLEN(SNAP_FILEDES_VERSION))
    {
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        return 0;
    }
    if(MOS_STRCMP(aucVersion,SNAP_FILEDES_VERSION) != 0)
    {
        Mos_FileClose(hFile);
        Mos_FileRmv(aucFileName);
        return -1;
    }
    
    iDesSize = sizeof(ST_SNAP_FILEDES);
    
    while(!Mos_FileEof(hFile))
    {
        iRet = Mos_FileRead(hFile,(_UC*)&stFileDes,iDesSize);
        if(iRet < iDesSize)
        {
            break;
        }
        Mos_TimetoSysTime(&stFileDes.cSnapTime,&stSysTime);
        
        MOS_VSNPRINTF(aucFileName,256,"%s/%s/%d/%s/%s%02hu%02hu%02hu.jpg",
            Snap_GetMng()->aucCachePath,SNAP_DIR,iCamid,pucDay,pucDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
        
        if(Mos_FileStat(aucFileName,&stFileInf) == MOS_OK)
        {
            uiHaveDelSize += stFileInf.uiSize;
            Mos_FileRmv(aucFileName);
            stFileDes.ucBInUse=' ';
            Mos_FileSeek(hFile,MOS_FILE_SEEK_CUR,-iDesSize);
            Mos_FileWrite(hFile,(_UC*)&stFileDes,iDesSize);
        }
        if(uiHaveDelSize >= uiNeedDelSize)
        {
            break;
        }
    }
    Mos_FileClose(hFile);
    return uiHaveDelSize;
}

_INT Snap_DeleteJpgBySize(_INT iCamId,_UI uiNeedDelSize)
{
    _INT iRet=0;
    _UI uiHaveDelSize=0;
    _UC aucVersion[24];
    _UC aucDirName[256];
    ST_SNAP_DATE stDate;
    _HFILE hDateFile = MOS_NULL;
    _INT iDateSize = sizeof(ST_SNAP_DATE);

    MOS_VSNPRINTF(aucDirName,256,"%s/%s/%d/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId,SNAP_DATECFG_NAME);
    hDateFile=Mos_FileOpen(aucDirName,MOS_FILE_O_BIN|MOS_FILE_O_RDWR);
    if(hDateFile==MOS_NULL)
    {
        MOS_LOG_WARN(SNAP_LOGSTR,"open file %s fail errno = %u",aucDirName,errno);
        return MOS_OK;
    }
    MOS_MEMSET(aucVersion,0,20);
    Mos_FileRead(hDateFile,aucVersion,MOS_STRLEN(SNAP_DATECFG_VERSION));  
    if(MOS_STRCMP(aucVersion,SNAP_DATECFG_VERSION))
    {
        Mos_FileClose(hDateFile);
        Mos_FileRmv(aucDirName);
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap Date File Version error");
        return MOS_ERR;
    }
    while(!Mos_FileEof(hDateFile))
    {
        if(Mos_FileRead(hDateFile,(_UC*)&stDate,iDateSize) < iDateSize)
        {
            break;
        }
        if(stDate.ucBInUse != 1)
        {
            continue;
        }
        iRet = Snap_DeleteOneDayBySize(iCamId,stDate.aucDate,uiNeedDelSize);
        if(iRet == 0)
        {
            continue;
        }
        if(iRet >= uiNeedDelSize)
        {
            uiHaveDelSize += iRet;
            break;
        } 
        if(iRet > 0)
        {
            uiNeedDelSize -= iRet;
            uiHaveDelSize += iRet;
        }
        MOS_VSNPRINTF(aucDirName,256,"%s/%s/%d/%s/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,iCamId,stDate.aucDate);
        Mos_DirRecurRmv(aucDirName);
        stDate.ucBInUse=' ';
        Mos_FileSeek(hDateFile,MOS_FILE_SEEK_CUR,-iDateSize);
        Mos_FileWrite(hDateFile,(_UC*)&stDate,iDateSize);
    }
    Mos_FileClose(hDateFile);
    MOS_LOG_INF(SNAP_LOGSTR,"delete snap OK,Camid %d,DeleteSize %u",iCamId,uiHaveDelSize);
    return MOS_OK;
}

//处理队列信息
_VOID Snap_TaskProcMsg(_VPTR pstMsg)
{
    MOS_PARAM_NULL_NORET(pstMsg);

    ST_MOS_MSGHEAD *pstMsgHead = (ST_MOS_MSGHEAD*)pstMsg;
    ST_SNAPCAM_NODE *pstSnCamNode = MOS_NULL;

    if(EN_SNAP_MSG_START == pstMsgHead->usMsgType)
    {
        ST_SNAP_MSG_INF *pstSnapMsgInf = (ST_SNAP_MSG_INF*)pstMsg;
        if(pstSnapMsgInf->iCamId + 1 > Snap_GetMng()->iMaxCamCount){
            MOS_LOG_ERR(SNAP_LOGSTR,"Device Camid err ,maxCamCount: %d",Snap_GetMng()->iMaxCamCount);
            return;
        }
        pstSnCamNode = Snap_FindOrCreatCamNode(pstSnapMsgInf->iCamId);
        
        if(EN_SNAP_AUTO == pstSnapMsgInf->uiSnapType){
            pstSnCamNode->stTimerSnap.uiPicType      = pstSnapMsgInf->uiPicType;
            pstSnCamNode->stTimerSnap.uiSnapInterval = pstSnapMsgInf->iSeconds;
            pstSnCamNode->stTimerSnap.cNextSnapTime  = Mos_Time();
            pstSnCamNode->stTimerSnap.ucOpenFlag = 1;
            MOS_LOG_INF(SNAP_LOGSTR,"auto snap start,CamId %d,Second %d,PicType %u",pstSnapMsgInf->iCamId,pstSnapMsgInf->iSeconds,pstSnapMsgInf->uiPicType);
        }
        else
        {
            pstSnCamNode->stFileDes.cSnapTime = pstSnapMsgInf->tCreateTime;
            pstSnCamNode->stFileDes.uiSnapType |= pstSnapMsgInf->uiSnapType;
            if(pstSnCamNode->stFileDes.uiJpgType == 0)
            {
                pstSnCamNode->stFileDes.uiJpgType = pstSnapMsgInf->uiPicType;
            }
            if(pstSnCamNode->stFileDes.uiJpgType >= pstSnapMsgInf->uiPicType)
            {
                pstSnCamNode->stFileDes.uiJpgType = pstSnapMsgInf->uiPicType;
            }
            pstSnCamNode->iStatus = 1;
        }
    }
    else if(EN_SNAP_MSG_SETPATH == pstMsgHead->usMsgType)
    {
        ST_SNAP_SETPATH_MSG *pstSnapMsgInf = (ST_SNAP_SETPATH_MSG*)pstMsg;
        if(!MOS_STRISEMPTY(pstSnapMsgInf->aucBuf)){
            MOS_MEMSET(Snap_GetMng()->aucCachePath,0,256);
            MOS_STRNCPY(Snap_GetMng()->aucCachePath,pstSnapMsgInf->aucBuf,sizeof(Snap_GetMng()->aucCachePath));
            Snap_GetMng()->iStopFlag=0;
        }
        Snap_GetMng()->iChangePathFlag=1;
        MOS_LOG_INF(SNAP_LOGSTR,"Snap task set path:%s",pstSnapMsgInf->aucBuf);
    }
    else if(EN_SNAP_MSG_DELETE == pstMsgHead->usMsgType)
    {
        ST_SNAP_DELETE_MSG *pstSnapMsgInf = (ST_SNAP_DELETE_MSG*)pstMsg;
        switch(pstSnapMsgInf->iDeleteType)
        {
        case EN_SNAP_DAY:
            Snap_DeleteJpgByDay(pstSnapMsgInf->iCamId,pstSnapMsgInf->aucDay);
            break;
        case EN_SNAP_NAME:
            Snap_DeleteJpgByName(pstSnapMsgInf->iCamId,pstSnapMsgInf->aucName);
            break;
        case EN_SNAP_TIME:
            Snap_DeleteJpgBeforeTime(pstSnapMsgInf->iCamId,pstSnapMsgInf->aucTime);
            break;
        case EN_SNAP_SIZE:
            Snap_DeleteJpgBySize(pstSnapMsgInf->iCamId,pstSnapMsgInf->uiDeleteSize);
            break;
        default:
            break;
        }
    }
    else if(EN_SNAP_MSG_STOP == pstMsgHead->usMsgType)
    {
        ST_SNAP_MSG_INF *pstSnapMsgInf=(ST_SNAP_MSG_INF*)pstMsg;
        pstSnCamNode = Snap_FindOrCreatCamNode(pstSnapMsgInf->iCamId);
        if(pstSnCamNode == MOS_NULL)
        {
            return;
        }
        pstSnCamNode->stTimerSnap.uiPicType      = 0;
        pstSnCamNode->stTimerSnap.uiSnapInterval = 0;
        pstSnCamNode->stTimerSnap.cNextSnapTime  = 0;
        pstSnCamNode->stTimerSnap.ucOpenFlag = 0;
        MOS_LOG_INF(SNAP_LOGSTR,"auto snap stop,CamId %d",pstSnapMsgInf->iCamId);
    }
    return;
}

//节点执行抓拍OK
_INT Snap_IoProcess()
{
    _INT iTotalLen=0;
    _INT iJpgLen = 0;
    _UC *pucJpgBuff = MOS_NULL;
    _CTIME_T cNowTime = Mos_Time();
    _VPTR pstMsg = MOS_NULL;
    _UC aucDate[12];
    _UC aucPathName[256];
    ST_MOS_SYS_TIME stSysTime;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_SNAPCAM_NODE *pstCamNode = MOS_NULL;

    while(Mos_MsgQueueGetCount(Snap_GetMng()->hMsgQueue) > 0)
    {
        pstMsg = Mos_MsgQueuePop(Snap_GetMng()->hMsgQueue);
        Snap_TaskProcMsg(pstMsg);
        MOS_FREE(pstMsg);
    }

    FOR_EACHDATA_INLIST(&Snap_GetMng()->stCamList, pstCamNode, stIterator)
    {
        if(pstCamNode->stTimerSnap.ucOpenFlag == 1 && pstCamNode->ucCamOpenFlag == 1)
        {
            if(cNowTime >= pstCamNode->stTimerSnap.cNextSnapTime)
            {
                pstCamNode->iStatus = 1;
                pstCamNode->stFileDes.uiSnapType |= EN_SNAP_AUTO;
                pstCamNode->stTimerSnap.cNextSnapTime = cNowTime + pstCamNode->stTimerSnap.uiSnapInterval;
                if(pstCamNode->stFileDes.uiJpgType == 0)
                {
                    pstCamNode->stFileDes.uiJpgType = pstCamNode->stTimerSnap.uiPicType;
                }
                if(pstCamNode->stFileDes.uiJpgType > pstCamNode->stTimerSnap.uiPicType)
                {
                    pstCamNode->stFileDes.uiJpgType = pstCamNode->stTimerSnap.uiPicType;
                }
            }
        }        
        if(pstCamNode->iStatus == 0)
        {
            continue;
        }
        if(pstCamNode->stFileDes.uiSnapType != EN_SNAP_EVENT)
        {
            pstCamNode->stFileDes.cSnapTime = cNowTime;
        }
        Mos_TimetoSysTime(&pstCamNode->stFileDes.cSnapTime,&stSysTime);
        MOS_VSNPRINTF(aucDate,12,"%04hu-%02hu-%02hu",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
        
        if(0 != MOS_STRNCMP(pstCamNode->aucDay,aucDate,MOS_STRLEN(aucDate)) || 1 == Snap_GetMng()->iChangePathFlag)
        {
            Snap_CheckDir(pstCamNode->iCamId,aucDate);
            MOS_STRNCPY(pstCamNode->aucDay,aucDate,sizeof(pstCamNode->aucDay));
            Snap_GetMng()->iChangeFlag = 1;
        }
        if(MOS_ABS_NUM(pstCamNode->stFileDes.cSnapTime - pstCamNode->cLastSnapTime) >= 1)
        {
            ZJ_GetJpgLock();
            iJpgLen = ZJ_GetOneJpg(pstCamNode->iCamId,pstCamNode->stFileDes.uiJpgType,&pucJpgBuff);
            if(iJpgLen > 0)
            {
                if(Snap_GetMng()->iChangeFlag == 1)
                {
                    if(Snap_AddDate(pstCamNode->iCamId,pstCamNode->aucDay) == MOS_OK)
                    {
                        Snap_GetMng()->iChangeFlag = 0;
                    }
                }
                MOS_VSNPRINTF(pstCamNode->stFileDes.aucFileName,32,"%s%02hu%02hu%02hu.jpg",pstCamNode->aucDay,
                    stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
                
                MOS_VSNPRINTF(aucPathName,255,"%s/%s/%d/%s/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,pstCamNode->iCamId,
                    pstCamNode->aucDay,pstCamNode->stFileDes.aucFileName);

                Mos_FileSave(aucPathName,pucJpgBuff,iJpgLen);
                pstCamNode->cLastSnapTime = pstCamNode->stFileDes.cSnapTime;
                Snap_AddFileDes(pstCamNode);
                iTotalLen += iJpgLen;
            }
            ZJ_GetJpgUnlock();
        }
        pstCamNode->stFileDes.uiJpgType = 0;
        pstCamNode->stFileDes.uiSnapType = 0;
        pstCamNode->iStatus = 0; 
    }
    return iTotalLen;
}

//查找有图片的日期OK
ST_MOS_LIST *Snap_QueryJpgCanlender(_INT iCamId,_UC *pucDay)
{
    MOS_PARAM_NULL_RETNULL(pucDay);

    _HFILE hFile;
    _INT iSize=0,iRet=0;
    _UC aucVersion[20]={0};
    _UC aucDateDes[256]={0};
    ST_SNAP_DATE stDate={0};
    ST_MOS_SYS_TIME stSysTime={0};
    ST_MOS_LIST *pstList=MOS_NULL;
    ST_SNAP_DATENODE *pstSnDateNode=MOS_NULL;

    MOS_LOG_INF(SNAP_LOGSTR,"query canlender start,Camid %d,Date %s",iCamId,pucDay);
    iSize=sizeof(ST_SNAP_DATE);

    MOS_SSCANF(pucDay,"%04hu-%02hu-%02hu",&stSysTime.usYear,&stSysTime.usMonth,&stSysTime.usDay);
    MOS_VSNPRINTF(aucDateDes,256,"%s/%s/%d/%s",Snap_GetMng()->aucCachePath,
        SNAP_DIR,iCamId,SNAP_DATECFG_NAME);
    if(!Mos_FileIsExist(aucDateDes)){
        MOS_LOG_WARN(SNAP_LOGSTR,"Snap Datedes can't find,file name : %s",aucDateDes);
        return MOS_NULL;
    }
    hFile=Mos_FileOpen(aucDateDes,MOS_FILE_O_BIN|MOS_FILE_O_RDONLY);
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(SNAP_DATECFG_VERSION));
    if(MOS_STRCMP(aucVersion,SNAP_DATECFG_VERSION)){
        Mos_FileClose(hFile);
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap desfile Version error");
        return MOS_NULL;
    }

    if(pstList == MOS_NULL){
        pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
        if(pstList == MOS_NULL){
            Mos_FileClose(hFile);
            return MOS_NULL;
        }
    }
    while(!Mos_FileEof(hFile))
    {
        iRet=Mos_FileRead(hFile,(_UC*)&stDate,iSize);
        if(iRet<iSize){
            break;
        }
        if(stDate.ucCheck=='$'&&MOS_STRNCMP(stDate.aucDate,pucDay,MOS_STRLEN(pucDay))>=0&& stDate.ucBInUse==1)
        {
            pstSnDateNode= (ST_SNAP_DATENODE *)MOS_MALLOCCLR(sizeof(ST_SNAP_DATENODE));
            if(pstSnDateNode != MOS_NULL){
                MOS_MEMCPY(&pstSnDateNode->stDate,&stDate, sizeof(ST_SNAP_DATE));
                MOS_LIST_ADDTAIL(pstList, pstSnDateNode);
            }
        }
    }
    Mos_FileClose(hFile);
    MOS_LOG_INF(SNAP_LOGSTR,"query canlender OK,result %d",pstList->uiTotalCount);
    return pstList;
}

//从文件中获取对应Snap信息，返回链表OK
ST_MOS_LIST *Snap_QueryJpgListByTime(_INT iCamId,_INT iJpgType,_INT iSnType,_UC *pucFromTime,_UI uiPageSize)
{
    MOS_PARAM_NULL_RETNULL(pucFromTime);

    _HFILE hFile;
    _INT iSize = sizeof(ST_SNAP_FILEDES);
    _INT iRet=0;
    _UC aucVersion[20]={0};
    _UC aucFileName[256]={0};
    _CTIME_T cFromTime=0;
    ST_SNAP_FILEDES stFileDes; 
    ST_MOS_SYS_TIME stSysTime={0};
    ST_MOS_LIST *pstList = MOS_NULL;
    ST_JPGFILE_NODE *pstSnapNode = MOS_NULL;

    MOS_LOG_INF(SNAP_LOGSTR,"query info by time start,CamId %d,JpgType %d,SnType %d,StartTime %s,PageSize %u",
                        iCamId,iJpgType,iSnType,pucFromTime,uiPageSize);

    pstList = (ST_MOS_LIST*)MOS_MALLOCCLR(sizeof(ST_MOS_LIST));
    if(pstList == MOS_NULL){
        return MOS_NULL;
    }

    Mos_GetSysTime(&stSysTime);
    
    MOS_SSCANF(pucFromTime,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",&stSysTime.usYear,&stSysTime.usMonth,
        &stSysTime.usDay,&stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
    
    cFromTime=Mos_SysTimetoTime(&stSysTime);
    
    MOS_VSNPRINTF(aucFileName,256,"%s/%s/%d/%04hu-%02hu-%02hu/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,
        iCamId,stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,SNAP_FILEDES_NAME);
    
    if(!Mos_FileIsExist(aucFileName)){
        MOS_LOG_WARN(SNAP_LOGSTR,"Snap desfile can't find,file name : %s",aucFileName);
        return pstList;
    }
    
    hFile=Mos_FileOpen(aucFileName,MOS_FILE_O_BIN|MOS_FILE_O_RDONLY);
    Mos_FileRead(hFile,aucVersion,MOS_STRLEN(SNAP_FILEDES_VERSION));
    if(MOS_STRCMP(aucVersion,SNAP_FILEDES_VERSION)){
        Mos_FileClose(hFile);
        MOS_LOG_ERR(SNAP_LOGSTR,"Snap desfile Version error");
        return pstList;
    }

    while(!Mos_FileEof(hFile))
    {
        if(pstList->uiTotalCount >= uiPageSize){
            break;
        }
        iRet=Mos_FileRead(hFile,(_UC*)&stFileDes,iSize);
        if(iRet<iSize){
            break;
        }
        if(cFromTime <= stFileDes.cSnapTime)
        {
            if('Z' == stFileDes.ucBInUse && (iJpgType & stFileDes.uiJpgType) > 0 &&(iSnType & stFileDes.uiSnapType) > 0)
            {
                pstSnapNode = (ST_JPGFILE_NODE *)MOS_MALLOCCLR(sizeof(ST_JPGFILE_NODE));
                if(pstSnapNode != MOS_NULL){
                    MOS_STRNCPY(pstSnapNode->stJpgInf.aucFileName,stFileDes.aucFileName,sizeof(pstSnapNode->stJpgInf.aucFileName));
                    pstSnapNode->stJpgInf.cSnapTime     = stFileDes.cSnapTime;
                    pstSnapNode->stJpgInf.uiSnapType    = stFileDes.uiSnapType;
                    pstSnapNode->stJpgInf.uiJpgType     = stFileDes.uiJpgType;
                    MOS_LIST_ADDTAIL(pstList,pstSnapNode);
                }
            }
        }
    }
    Mos_FileClose(hFile);
    MOS_LOG_INF(SNAP_LOGSTR,"query info by time OK,result %d",pstList->uiTotalCount);
    return pstList;
}

//根据给定名称返回照片路径OK
_INT Snap_GetJpgPathByName(_INT iCamId,_UC *pucName,_UC *pucSnPath,_UI uiPathLen)
{
    MOS_PARAM_NULL_RETERR(pucName);
    MOS_PARAM_NULL_RETERR(pucSnPath);

    ST_MOS_SYS_TIME stSysTime;
    
    MOS_SSCANF(pucName,"%04hu-%02hu-%02hu%02hu%02hu%02hu.jpg",&stSysTime.usYear,&stSysTime.usMonth,
        &stSysTime.usDay,&stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
    
    MOS_VSNPRINTF(pucSnPath,uiPathLen,"%s/%s/%d/%04hu-%02hu-%02hu/%s",Snap_GetMng()->aucCachePath,SNAP_DIR,
        iCamId,stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,pucName);
    
    if(!Mos_FileIsExist(pucSnPath)){
        MOS_LOG_WARN(SNAP_LOGSTR,"Snap Picture can't find,file path : %s",pucSnPath);
        return MOS_ERR;
    }
    return MOS_OK;
}

//自动抓图
_INT Snap_StartAutoSnap(_INT iCamId,_INT iSeconds,_UI uiSnPicType)
{
    ST_SNAP_MSG_INF *pstSnMsg;
    if( Snap_GetMng()->iStopFlag == 1)
    {
        return MOS_OK;
    }
    pstSnMsg = (ST_SNAP_MSG_INF*)MOS_MALLOCCLR(sizeof(ST_SNAP_MSG_INF));
    pstSnMsg->stMsgHead.usMsgType = EN_SNAP_MSG_START;
    pstSnMsg->uiPicType  = uiSnPicType;
    pstSnMsg->iCamId     = iCamId;
    if(iSeconds < 60)
    {
        pstSnMsg->iSeconds = 60;
    }
    else
    {
        pstSnMsg->iSeconds = iSeconds;
    }
    pstSnMsg->uiSnapType = EN_SNAP_AUTO;
    MOS_LOG_INF(SNAP_LOGSTR,"start timer snap jpg");

    _INT iRet = Mos_MsgQueuePush(Snap_GetMng()->hMsgQueue,pstSnMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstSnMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Snap_StopAutoSnap(_INT iCamId)
{
    ST_SNAP_MSG_INF *pstSnMsg = MOS_NULL;
    if(Snap_GetMng()->iStopFlag == 1 || MOS_STRLEN(Snap_GetMng()->aucCachePath) == 0){
        return MOS_OK;
    }
    
    pstSnMsg = (ST_SNAP_MSG_INF*)MOS_MALLOCCLR(sizeof(ST_SNAP_MSG_INF));
    pstSnMsg->iCamId     = 0;
    pstSnMsg->stMsgHead.usMsgType = EN_SNAP_MSG_STOP;
    _INT iRet = Mos_MsgQueuePush(Snap_GetMng()->hMsgQueue,pstSnMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstSnMsg);
        return MOS_ERR;
    }
    return iRet;
}

//手动抓图
_INT Snap_StartManualSnap(_INT iCamId,_UI uiSnPicType)
{
    ST_SNAP_MSG_INF *pstSnMsg = (ST_SNAP_MSG_INF*)MOS_MALLOCCLR(sizeof(ST_SNAP_MSG_INF));

    if(Snap_GetMng()->iStopFlag == 1 || MOS_STRLEN(Snap_GetMng()->aucCachePath) == 0){
        MOS_FREE(pstSnMsg);
        return MOS_OK;
    }
    pstSnMsg->stMsgHead.usMsgType = EN_SNAP_MSG_START;
    pstSnMsg->uiPicType  = uiSnPicType;
    pstSnMsg->iCamId     = iCamId;
    pstSnMsg->uiSnapType = EN_SNAP_MANUAL;
    MOS_LOG_INF(SNAP_LOGSTR,"manual snap start,CamId %d,PicType %u",iCamId,uiSnPicType);

    _INT iRet = Mos_MsgQueuePush(Snap_GetMng()->hMsgQueue,pstSnMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstSnMsg);
        return MOS_ERR;
    }
    return iRet;
}

//事件抓图
_INT Snap_StartEventSnap(_INT iCamId,_UI uiSnPicType,_CTIME_T tCreateTime)
{
    ST_SNAP_MSG_INF *pstSnMsg = MOS_NULL;
    if(Snap_GetMng()->iStopFlag == 1 || MOS_STRLEN(Snap_GetMng()->aucCachePath) == 0)
    {
        return MOS_OK;
    }
    pstSnMsg = (ST_SNAP_MSG_INF*)MOS_MALLOCCLR(sizeof(ST_SNAP_MSG_INF));
    pstSnMsg->stMsgHead.usMsgType = EN_SNAP_MSG_START;
    pstSnMsg->uiPicType  = uiSnPicType;
    pstSnMsg->iCamId     = iCamId;
    pstSnMsg->uiSnapType = EN_SNAP_EVENT;
    pstSnMsg->tCreateTime = tCreateTime;
    // MOS_LOG_INF(SNAP_LOGSTR,"start event snap,create time %u",tCreateTime);

    _INT iRet = Mos_MsgQueuePush(Snap_GetMng()->hMsgQueue,pstSnMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstSnMsg);
        return MOS_ERR;
    }
    return iRet;
}

//设置存储路径OK
_INT Snap_SetPath(_UC *pucBuf)
{
    MOS_PARAM_NULL_RETERR(pucBuf);

    ST_SNAP_SETPATH_MSG *pstSnMsg = (ST_SNAP_SETPATH_MSG*)MOS_MALLOCCLR(sizeof(ST_SNAP_SETPATH_MSG));

    MOS_LOG_INF(SNAP_LOGSTR,"send set path msg,Path %s",pucBuf);
    pstSnMsg->stMsgHead.usMsgType = EN_SNAP_MSG_SETPATH;
    MOS_STRNCPY(pstSnMsg->aucBuf,pucBuf,sizeof(pstSnMsg->aucBuf));
    _INT iRet = Mos_MsgQueuePush(Snap_GetMng()->hMsgQueue,pstSnMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstSnMsg);
        return MOS_ERR;
    }
    return iRet;
}

//设置删除方式
_INT Snap_SendDeleteMsg(_INT iCamId,_INT iDeleteType,_UI uiDeleteSize,_UC *pucDay,_UC *pucTime,_UC *pucName)
{
    MOS_PARAM_NULL_RETERR(pucDay);
    MOS_PARAM_NULL_RETERR(pucTime);
    MOS_PARAM_NULL_RETERR(pucName);

    ST_SNAP_DELETE_MSG *pstSnMsg = MOS_NULL;
    if(Snap_GetMng()->iStopFlag == 1 || MOS_STRLEN(Snap_GetMng()->aucCachePath) == 0){
        MOS_LOG_WARN(SNAP_LOGSTR,"send delete msg fail,Stop status %d,Path %s",Snap_GetMng()->iStopFlag,Snap_GetMng()->aucCachePath);
        return MOS_OK;
    }
    pstSnMsg = (ST_SNAP_DELETE_MSG*)MOS_MALLOCCLR(sizeof(ST_SNAP_DELETE_MSG));
    pstSnMsg->stMsgHead.usMsgType = EN_SNAP_MSG_DELETE;
    pstSnMsg->iCamId = iCamId;
    switch(iDeleteType)
    {
        case EN_SNAP_DAY:
            pstSnMsg->iDeleteType = 1;
            MOS_STRNCPY(pstSnMsg->aucDay,pucDay,sizeof(pstSnMsg->aucDay));
            break;
        case EN_SNAP_NAME:
            pstSnMsg->iDeleteType = 2;
            MOS_STRNCPY(pstSnMsg->aucName,pucName,sizeof(pstSnMsg->aucName));
            break;
        case EN_SNAP_TIME:
            pstSnMsg->iDeleteType = 3;
            MOS_STRNCPY(pstSnMsg->aucTime,pucTime,sizeof(pstSnMsg->aucTime));
            break;
        case EN_SNAP_SIZE:
            pstSnMsg->iDeleteType = 4;
            pstSnMsg->uiDeleteSize = uiDeleteSize;
            break;
        default:{

        }
    }
    MOS_LOG_INF(SNAP_LOGSTR,"send delete msg start,Type %d",iDeleteType);
    _INT iRet = Mos_MsgQueuePush(Snap_GetMng()->hMsgQueue,pstSnMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstSnMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Snap_SetCamOpenFlag(_INT iCamId,_INT iCamOpenFlag)
{
    ST_SNAPCAM_NODE *pstSnCamNode = Snap_FindOrCreatCamNode(iCamId);
    pstSnCamNode->ucCamOpenFlag = iCamOpenFlag;
    return MOS_OK;
}

_INT Snap_IoStop()
{
    ST_SNAPCAM_NODE *pstInNode;
    ST_MOS_LIST_ITERATOR stIteator;

    FOR_EACHDATA_INLIST(&Snap_GetMng()->stCamList,pstInNode,stIteator)
    {
        pstInNode->iStatus = 0;
    }
    Snap_GetMng()->iStopFlag=1;

    MOS_LOG_INF(SNAP_LOGSTR,"Snap io stop ok");

    return MOS_OK;
}

_INT Snap_IoRestart(_UC *pucLocalPath)
{
    MOS_PARAM_NULL_RETERR(pucLocalPath);

    if(MOS_STRISEMPTY(pucLocalPath)){
        Snap_GetMng()->iStopFlag = 1;
    }
    else{
        Snap_GetMng()->iStopFlag = 0;
    }
    MOS_STRNCPY(Snap_GetMng()->aucCachePath,pucLocalPath,sizeof(Snap_GetMng()->aucCachePath));
    Snap_GetMng()->iChangePathFlag=1;
    MOS_LOG_INF(SNAP_LOGSTR,"Snap io restart ok,set path :%s",Snap_GetMng()->aucCachePath);

    return MOS_OK;
}

//OK
_INT Snap_ProcEventOutput(_UI uiAIIoTType,_LLID lluAIIoTID, _UC* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    MOS_PARAM_NULL_RETERR(pSignalValue);
    MOS_PARAM_NULL_RETERR(pstTriggerInf);

    _UI uiSnapType = 0;
    JSON_HANDLE hRoot = Adpt_Json_Parse((_UC*)pSignalValue);
    ST_CFG_INIOT_NODE *pstInIotNode = Config_FindInnerIotDevice(uiAIIoTType,lluAIIoTID);

    if(pstInIotNode == MOS_NULL || pstInIotNode->uiOpenFlag == 0)
    {
        MOS_LOG_ERR(SNAP_LOGSTR,"KjIot %u %llu can't find device node or func close",uiAIIoTType,lluAIIoTID);
        return MOS_OK;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PicType"),(_INT*)&uiSnapType);
    
    Snap_StartEventSnap(0,uiSnapType,pstTriggerInf->tCreateTime);
    MOS_LOG_INF(SNAP_LOGSTR,"Event snap time %u",pstTriggerInf->tCreateTime);
    
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_INT Snap_Init(_INT iMaxCameraNum)
{
    if(Snap_GetMng()->iInitFlag == 1){
        MOS_LOG_WARN(SNAP_LOGSTR,"Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_SnapTaskMng, 0, sizeof(g_SnapTaskMng));
    Snap_GetMng()->iChangeFlag = 0;
    Snap_GetMng()->iStopFlag = 0;
    Snap_GetMng()->iChangePathFlag=1;
    Snap_GetMng()->iMaxCamCount=iMaxCameraNum;
    Snap_GetMng()->hMsgQueue=Mos_MsgQueueCreate(MOS_FALSE,10, __FUNCTION__);
    KjIoT_AddDevContrlFun(EN_ZJ_AIIOT_TYPE_SNAPSHORT,Snap_ProcEventOutput,MOS_NULL,MOS_NULL,MOS_NULL);

    IoMng_Register((_UC*)"Snap",Snap_IoProcess,Snap_IoStop,Snap_IoRestart,Snap_IoAutoDelete);
    Snap_GetMng()->iInitFlag = 1;
    MOS_LOG_INF(SNAP_LOGSTR,"Snap init task done msg queue %p ",Snap_GetMng()->hMsgQueue);
    return MOS_OK;
}

//OK
_INT Snap_Destory()
{
    _VPTR pstMsg = MOS_NULL;
    if(Snap_GetMng()->iInitFlag == 0){
        MOS_LOG_WARN(SNAP_LOGSTR,"Already Destory");
        return MOS_OK;
    }
    MOS_LIST_RMVALL(&Snap_GetMng()->stCamList,MOS_TRUE);
    while(Mos_MsgQueueGetCount(Snap_GetMng()->hMsgQueue)>0)
    {
        pstMsg=Mos_MsgQueuePop(Snap_GetMng()->hMsgQueue);
        MOS_FREE(pstMsg);
    }
    Mos_MsgQueueDelete(Snap_GetMng()->hMsgQueue);
    Snap_GetMng()->hMsgQueue = MOS_NULL;
    Snap_GetMng()->iInitFlag=0;
    MOS_LOG_INF(SNAP_LOGSTR,"Snap task destory ok");
    return MOS_OK;
}
