#ifndef _SNAP_H
#define _SNAP_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum enum_snap_TYPE
{
    EN_SNAP_AUTO     = 0x01,
    EN_SNAP_MANUAL   = 0x02,
    EN_SNAP_EVENT    = 0x04
}EN_SNAP_TYPE;

typedef enum enum_snap_delete_TYPE
{
    EN_SNAP_DAY      = 1,
    EN_SNAP_NAME     = 2,
    EN_SNAP_TIME     = 3,
    EN_SNAP_SIZE     = 4 
}EN_SNAP_DELETE_TYPE;

/**********************************
抓图日期
*************************************/
typedef struct st_SNAP_DATE//返回的日期
{
    _UC ucCheck;
    _UC ucBInUse;
    _UC ucRsv[2];
    _UC aucDate[12];
}ST_SNAP_DATE;

typedef struct st_SNAP_DATENODE
{
    ST_SNAP_DATE stDate;
    ST_MOS_LIST_NODE stNode;
}ST_SNAP_DATENODE;

/*抓图的文件列表*/
typedef struct st_JPGFILE_INF//返回的时间点和文件名称
{
    _UI uiJpgType;
    _UI uiSnapType;
    _CTIME_T cSnapTime;
    _UC aucFileName[32];
}ST_JPGFILE_INF;

typedef struct stru_JPGFILE_NODE
{
    ST_JPGFILE_INF stJpgInf;
    ST_MOS_LIST_NODE stNode;
}ST_JPGFILE_NODE;

_INT Snap_Init(_INT iMaxCameraNum);

_INT Snap_Destory();

//设置SD卡存储路径OK
_INT Snap_SetPath(_UC *pucBuf);

_INT Snap_SendDeleteMsg(_INT iCamId,_INT iDeleteType,_UI uiDeleteSize,_UC *pucDay,_UC *pucTime,_UC *pucName);

_INT Snap_SetCamOpenFlag(_INT iCamId,_INT iCamOpenFlag);

//自动抓图OK
_INT Snap_StartAutoSnap(_INT iCamId,_INT iSnapIntervale,_UI uiPicType);

_INT Snap_StopAutoSnap(_INT iCamId);
//手动抓图
_INT Snap_StartManualSnap(_INT iCamId,_UI uiSnPicType);

//事件抓图
_INT Snap_StartEventSnap(_INT iCamId,_UI uiSnPicType,_CTIME_T tCreateTime);

//根据给定时间点返回照片全路径(Yy-Mm-DdHh:Mm:Ss.jpg)OK
_INT Snap_GetJpgPathByName(_INT iCamId,_UC *pucName,_UC *pucSnPath,_UI uiPathLen);

//根据日期，返回有图片的日期链表(Yy-Mm-Dd)OK
ST_MOS_LIST *Snap_QueryJpgCanlender(_INT iCamId,_UC *pucDay);

//根据时间，返回指定的图片（Yy-Mm-Dd Hh:Mm:Ss)OK  ST_JPGFILE_NODE
ST_MOS_LIST *Snap_QueryJpgListByTime(_INT iCamId,_INT iJpgType,_INT iSnType,_UC *pucFromTime,_UI uiPageSize);

#ifdef __cplusplus
}
#endif
#endif