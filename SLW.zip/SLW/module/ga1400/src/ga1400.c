#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "config_prv.h"
#include "ga1400_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "adpt_json_adapt.h"
#include "msgmng_api.h"
#include "msgmng_cmdserver.h"
#include "kj_timer.h"
#include "watchdog_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

#define HTTP_RECVBUF_SIZE 1024

// 1400图片类型
typedef enum enum_1400_PIC_TYPE
{
    EN_1400_PIC_TYPE_FACE   = 0, // 人脸
    EN_1400_PIC_TYPE_CARNUM = 1, // 车牌

}EN_1400_PIC_TYPE;

static ST_GA1400_MNG g_Ga1400TaskMng        = {0};
static ST_GA1400_HTTP_TASK g_Ga1400HttpTask = {0};

ST_GA1400_MNG *Ga1400_GetTaskMng()
{
    return &g_Ga1400TaskMng;
}

ST_GA1400_HTTP_TASK *Ga1400_GetHttpTask()
{
    return &g_Ga1400HttpTask;
}

#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
// 获取GA1400配置参数失败次数
_INT Ga1400_SetTaskConnectFailTime(_UI uiConnectFailTime)
{
    // 接口只在Ga1400_Task_Loop、Ga1400_Task_LoopEx调用，因此不存在线程安全问题
    Ga1400_GetTaskMng()->uiConnectFailTime = uiConnectFailTime;
    return MOS_OK;
}

_UI Ga1400_GetTaskConnectFailTime()
{
    // 接口只在Ga1400_Task_Loop、Ga1400_Task_LoopEx调用，因此不存在线程安全问题
    return Ga1400_GetTaskMng()->uiConnectFailTime;
}

_INT Ga1400_SetTaskConnectFailTimeByMsg(_BOOL bIsInc, _UI uiConnectFailTime)
{
    // MOS_LOG_INF(GA1400_LOGSTR, "ga1400 ConnectFailTime change to %u", uiConnectFailTime);
    ST_1400_STATUS_MSG *pstMsg = (ST_1400_STATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_1400_STATUS_MSG));
    if (pstMsg == NULL)
    {
        return MOS_ERR;
    }
    pstMsg->stMsgHead.usMsgType = bIsInc?EN_1400_MSG_INCCONNECTFAILTIME:EN_1400_MSG_SETCONNECTFAILTIME;
    pstMsg->uiConnectFailTime   = uiConnectFailTime;
    if (Mos_MsgQueuePush(Ga1400_GetTaskMng()->hMsgQueue, pstMsg) == MOS_ERR)
    {
        MOS_FREE(pstMsg);
        return MOS_ERR;
    }

    return MOS_OK;
}

// 获取GA1400配置参数
_INT Ga1400_SetTaskGetInfoFlag(_UI uiGa1400TaskGetInfoFlag)
{
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    Ga1400_GetTaskMng()->uiGa1400TaskGetInfoFlag = uiGa1400TaskGetInfoFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return MOS_OK;
}

_UI Ga1400_GetTaskGetInfoFlag()
{
    _UI uiGa1400TaskGetInfoFlag = 0;
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    uiGa1400TaskGetInfoFlag = Ga1400_GetTaskMng()->uiGa1400TaskGetInfoFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return uiGa1400TaskGetInfoFlag;
}

_INT Ga1400_SetTaskGetInfoFlagByMsg(_UI uiGa1400TaskGetInfoFlag)
{
    // MOS_LOG_INF(GA1400_LOGSTR, "ga1400 GetInfoFlag change to %u", uiGa1400TaskGetInfoFlag);

    ST_1400_STATUS_MSG *pstMsg = (ST_1400_STATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_1400_STATUS_MSG));
    if (pstMsg == NULL)
    {
        return MOS_ERR;
    }
    pstMsg->stMsgHead.usMsgType = EN_1400_MSG_GETINFOFLAG;
    pstMsg->uiGetInfoFlag       = uiGa1400TaskGetInfoFlag;
    if (Mos_MsgQueuePush(Ga1400_GetTaskMng()->hMsgQueue, pstMsg) == MOS_ERR)
    {
        MOS_FREE(pstMsg);
        return MOS_ERR;
    }

    return MOS_OK;
}

// GA1400注册
_INT Ga1400_SetTaskRegisterFlag(_UI uiGa1400TaskRegisterFlag)
{
    // MOS_LOG_INF(GA1400_LOGSTR, "ga1400 RegisterFlag change to %u", uiGa1400TaskRegisterFlag);
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    Ga1400_GetTaskMng()->uiGa1400TaskRegisterFlag = uiGa1400TaskRegisterFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return MOS_OK;
}
_UI Ga1400_GetTaskRegisterFlag()
{
    _UI uiGa1400TaskRegisterFlag = 0;
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    uiGa1400TaskRegisterFlag = Ga1400_GetTaskMng()->uiGa1400TaskRegisterFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return uiGa1400TaskRegisterFlag;
}

// GA1400注销
_INT Ga1400_SetTaskUnRegisterFlag(_UI uiGa1400TaskUnRegisterFlag)
{
    // 接口只在Ga1400_Task_Loop、Ga1400_Task_LoopEx调用，因此不存在线程安全问题
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    Ga1400_GetTaskMng()->uiGa1400TaskUnRegisterFlag = uiGa1400TaskUnRegisterFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return MOS_OK;
}
_UI Ga1400_GetTaskUnRegisterFlag()
{
    // 接口只在Ga1400_Task_Loop、Ga1400_Task_LoopEx调用，因此不存在线程安全问题
    _UI uiGa1400TaskUnRegisterFlag = 0;
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    uiGa1400TaskUnRegisterFlag =  Ga1400_GetTaskMng()->uiGa1400TaskUnRegisterFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return uiGa1400TaskUnRegisterFlag;
}
_INT Ga1400_SetTaskUnRegisterFlagByMsg(_UI uiGa1400TaskUnRegisterFlag)
{
    // MOS_LOG_INF(GA1400_LOGSTR, "ga1400 UnRegisterFlag change to %u", uiGa1400TaskUnRegisterFlag);
    ST_1400_STATUS_MSG *pstMsg = (ST_1400_STATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_1400_STATUS_MSG));
    if (pstMsg == NULL)
    {
        return MOS_ERR;
    }
    pstMsg->stMsgHead.usMsgType = EN_1400_MSG_SETUNREGISTERFLAG;
    pstMsg->uiUnRegisterFlag    = uiGa1400TaskUnRegisterFlag;
    if (Mos_MsgQueuePush(Ga1400_GetTaskMng()->hMsgQueue, pstMsg) == MOS_ERR)
    {
        MOS_FREE(pstMsg);
        return MOS_ERR;
    }

    return MOS_OK;
}
// GA1400保活
_INT Ga1400_SetTaskKeepAliveFlag(_UI uiGa1400TaskKeepAliveFlag)
{
    // 接口只在Ga1400_Task_Loop、Ga1400_Task_LoopEx调用，因此不存在线程安全问题
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    Ga1400_GetTaskMng()->uiGa1400TaskKeepAliveFlag = uiGa1400TaskKeepAliveFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return MOS_OK;
}
_UI Ga1400_GetTaskKeepAliveFlag()
{
    // 接口只在Ga1400_Task_Loop、Ga1400_Task_LoopEx调用，因此不存在线程安全问题
    _UI uiGa1400TaskKeepAliveFlag;
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    uiGa1400TaskKeepAliveFlag = Ga1400_GetTaskMng()->uiGa1400TaskKeepAliveFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return uiGa1400TaskKeepAliveFlag;
}
_INT Ga1400_SetTaskKeepAliveFlagByMsg(_UI uiGa1400TaskKeepAliveFlag)
{
    // MOS_LOG_INF(GA1400_LOGSTR, "ga1400 KeepAliveFlag change to %u", uiGa1400TaskKeepAliveFlag);
    ST_1400_STATUS_MSG *pstMsg = (ST_1400_STATUS_MSG*)MOS_MALLOCCLR(sizeof(ST_1400_STATUS_MSG));
    if (pstMsg == NULL)
    {
        return MOS_ERR;
    }
    pstMsg->stMsgHead.usMsgType = EN_1400_MSG_SETKEEPALIVEFLAG;
    pstMsg->uiKeepAliveFlag     = uiGa1400TaskKeepAliveFlag;
    if (Mos_MsgQueuePush(Ga1400_GetTaskMng()->hMsgQueue, pstMsg) == MOS_ERR)
    {
        MOS_FREE(pstMsg);
        return MOS_ERR;
    }

    return MOS_OK;
}
// GA1400 图片上传标志
_INT Ga1400_SetTaskUploadPicFlag(_UI uiUploadPicFlag)
{
    // MOS_LOG_INF(GA1400_LOGSTR, "ga1400 UploadPicFlag change to %u", uiUploadPicFlag);
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    Ga1400_GetTaskMng()->uiUploadPicFlag = uiUploadPicFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return MOS_OK;
}
_UI Ga1400_GetTaskUploadPicFlag()
{
    _UI uiUploadPicFlag = 0;
    Mos_MutexLock(&Ga1400_GetTaskMng()->hMutex);
    uiUploadPicFlag = Ga1400_GetTaskMng()->uiUploadPicFlag;
    Mos_MutexUnLock(&Ga1400_GetTaskMng()->hMutex);
    return uiUploadPicFlag;
}

// GA1400模块初始化
_INT Ga1400_Task_Init()
{
    if(Ga1400_GetTaskMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(GA1400_LOGSTR, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_Ga1400TaskMng , 0, sizeof(g_Ga1400TaskMng));

    Mos_MutexCreate(&Ga1400_GetTaskMng()->hMutex);
    Ga1400_GetTaskMng()->tTimeUploadPic             = 0;
    Ga1400_GetTaskMng()->uiConnectFailTime          = 0;
    Ga1400_GetTaskMng()->uiGa1400TaskGetInfoFlag    = EN_GA1400_GETINFO_NEED_LOOP;
    Ga1400_GetTaskMng()->uiGa1400TaskRegisterFlag   = EN_GA1400_REGISTER_NONEED;
    Ga1400_GetTaskMng()->uiGa1400TaskUnRegisterFlag = EN_GA1400_UNREGISTER_NONEED;
    Ga1400_GetTaskMng()->uiGa1400TaskKeepAliveFlag  = EN_GA1400_KEEPALIVE_NONEED;
    Ga1400_GetTaskMng()->hMsgQueue = Mos_MsgQueueCreate(MOS_FALSE, 10, __FUNCTION__);
    Ga1400_GetTaskMng()->ucInitFlag                 = 1;
    // MOS_LOG_INF(GA1400_LOGSTR, "GA1400 msg queue %p", Ga1400_GetTaskMng()->hMsgQueque);
    MOS_LOG_INF(GA1400_LOGSTR, "GA1400 INIT OK !!!!!!!!!!!!!!!!");
    return MOS_OK;
}

// GA1400模块 组合获取Ga1400信息的URL GET方式获取
int Ga1400_BuildGetGa1400InfoUrl(_UC *pucUrl, _INT iUrlLen)
{
    _CTIME_T ctime          = 0;
    _UC aucInBuf[512]       = {0};
    _UC *pucOutBuff         = MOS_NULL;

    ctime = Mos_Time();
    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);

#if GA1400_SUPPORTIPANDPORT
    _INT iIsSupportIpAndPort= 1;
    MOS_VSNPRINTF(aucInBuf, sizeof(aucInBuf), "isSupportIpAndPort=%d&timestamp=%u&uid=%s", iIsSupportIpAndPort, ctime, Config_GetSystemMng()->aucDevUID);
    Adpt_HmacSha256_Encrypt(aucInBuf, pucOutBuff, 128, Config_GetSystemMng()->aucDevkey);

    MOS_VSNPRINTF(pucUrl, iUrlLen, "%s?isSupportIpAndPort=%d&uid=%s&timestamp=%u&signature=%s", 
                GA1400_GETGA1400INFO_URL, iIsSupportIpAndPort, Config_GetSystemMng()->aucDevUID, ctime, pucOutBuff);
#else
    MOS_VSNPRINTF(aucInBuf, sizeof(aucInBuf), "timestamp=%u&uid=%s", ctime, Config_GetSystemMng()->aucDevUID);
    Adpt_HmacSha256_Encrypt(aucInBuf, pucOutBuff, 128, Config_GetSystemMng()->aucDevkey);

    MOS_VSNPRINTF(pucUrl, iUrlLen, "%s?uid=%s&timestamp=%u&signature=%s", 
                    GA1400_GETGA1400INFO_URL, Config_GetSystemMng()->aucDevUID, ctime, pucOutBuff);
#endif

    MOS_LOG_INF(GA1400_LOGSTR, "pucUrl:%s", pucUrl);

    MOS_FREE(pucOutBuff);
    return MOS_OK;
}

// GA1400模块 解析Ga1400回复的Ga1400信息的json数据
_INT Ga1400_ParseGetGa1400InfoRsp(_UC *pucJson)
{
    _INT  iRet              = 0;
    _INT  iStatus           = MOS_ERR;
    _INT  iValue            = MOS_ERR;
    _LLID ullTimeStamp      = 0;
    _UC   aucUrl[128]       = {0};
    _UC   aucStrErrLog[128] = {0};
    _UC  *pMsg              = MOS_NULL;
    _UC  *pUID              = MOS_NULL;
    _UC  *pGa1400ID         = MOS_NULL;
    _UC  *pDomain           = MOS_NULL;

    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucGa1400Addr, GA1400_GETGA1400INFO_URL);

    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "getGAT1400Config Body Json Is Null");
        CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), aucUrl, -1, 
                                EN_1400_RT_GET1400INFO_PLAT_RSP_JSON_NULL_ERR, aucStrErrLog, MOS_NULL, 1); 
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC*)"code"), &iValue);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot, (_UC*)"msg"), &pMsg);
    if (iValue == 0)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC*)"Timestamp"), &ullTimeStamp);

        JSON_HANDLE hGa1400Info = Adpt_Json_GetObjectItem(hRoot, (_UC*)"GAT1400Config");
        if (MOS_NULL != hGa1400Info)
        {
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hGa1400Info, (_UC*)"DevID"), &pUID);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hGa1400Info, (_UC*)"GAT1400ID"), &pGa1400ID);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hGa1400Info, (_UC*)"Domain"), &pDomain);
        }
        else
        {
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Ga1400Info Json Is Null");
            CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), aucUrl, -1, 
                                    EN_1400_RT_GET1400INFO_PLAT_RSP_CFG_NULL_ERR, aucStrErrLog, MOS_NULL, 1); 
            iRet = -1;
        }

        if (MOS_STRNCMP(Config_GetSystemMng()->aucDevUID, pUID, sizeof(Config_GetSystemMng()->aucDevUID)) == 0)
        {
            MOS_LOG_INF(GA1400_LOGSTR, "get ga1400 info success UID:%s  Ga1400ID:%s  Domain:%s", pUID, pGa1400ID, pDomain);

            if (Config_GetCamaraMng()->uiInterGAT1400Ability == 1) // 内嵌Ga1400
            {
                // 已注册 且 Gat1400参数改变，重新注册(平台会做注销操作)，注册成功后再保活
                if(Ga1400_GetTaskRegisterFlag() == EN_GA1400_REGISTER_SUCCESS)
                {
                    if (MOS_STRNCMP(Config_GetCamaraMng()->ucGAT1400ID,     pGa1400ID, sizeof(Config_GetCamaraMng()->ucGAT1400ID))     != 0 || 
                        MOS_STRNCMP(Config_GetCamaraMng()->ucGAT1400Domain, pDomain,   sizeof(Config_GetCamaraMng()->ucGAT1400Domain)) != 0 )
                    {
                        Config_SetCamerGat1400Info(0, pGa1400ID, pDomain);
                        Ga1400_SetTaskRegisterFlag(EN_GA1400_REGISTER_NEED);
                        Ga1400_SetTaskKeepAliveFlag(EN_GA1400_KEEPALIVE_NONEED);
                        Ga1400_SetTaskUnRegisterFlag(EN_GA1400_UNREGISTER_NONEED);
                    }
                    else
                    {
                        MOS_LOG_INF(GA1400_LOGSTR, "ga1400 info Ga1400ID:%s  Domain:%s no change", pGa1400ID, pDomain);
                    }
                }
                else  // 未注册, 注册成功后再保活
                {
                    Config_SetCamerGat1400Info(0, pGa1400ID, pDomain);
                    Ga1400_SetTaskRegisterFlag(EN_GA1400_REGISTER_NEED);
                    Ga1400_SetTaskKeepAliveFlag(EN_GA1400_KEEPALIVE_NONEED);
                    Ga1400_SetTaskUnRegisterFlag(EN_GA1400_UNREGISTER_NONEED);
                }
                iRet = MOS_OK;
            }
            else
            {
                // 回调到厂商设置GA1400信息
                if (ZJ_GetFuncTable()->pFunSetGa1400InfoCb)
                {
                    iStatus = ZJ_GetFuncTable()->pFunSetGa1400InfoCb(pGa1400ID, pDomain);
                    if (MOS_OK == iStatus)
                    {
                        Config_SetCamerGat1400Info(0, pGa1400ID, pDomain);
                    }
                }
                else
                {
                    MOS_LOG_ERR(GA1400_LOGSTR,"pFunSetGa1400InfoCb is NULL!");
                    iRet = -4;
                }
            }
        }
        else
        {
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Get Ga1400 info error wrong UID:%s right:%s", pUID, Config_GetSystemMng()->aucDevUID);
            CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), aucUrl, -1, 
                                    EN_1400_RT_GET1400INFO_PLAT_RSP_UID_ERR, aucStrErrLog, MOS_NULL, 1); 
            iRet = -2;
        }
    }
    else
    {
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Get Ga1400 info error code:%d, msg:%s", iValue, pMsg);
        CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), aucUrl, -1, 
                                EN_1400_RT_GET1400INFO_PLAT_RSP_CODE_NOT_0_ERR, aucStrErrLog, MOS_NULL, 1);         
        iRet = -3;
    }
    
    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Get Ga1400Info(pUID: %s, pGa1400ID:%s, pDomain:%s) Success, Code:%d, Msg:%s", pUID, pGa1400ID, pDomain, iValue, pMsg);
    CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), aucUrl, 0, 
                            EN_1400_RT_GET1400INFO_SUCCESS, aucStrErrLog, MOS_NULL, 1);
    Adpt_Json_Delete(hRoot);
    return iRet;
}

// GA1400模块 建立获取Ga1400信息的json数据  POST方式
_UC *Ga1400_BuildGetGa1400InfoJson()
{
    _CTIME_T ctime          = 0;
    _UC *pStrTmp            = MOS_NULL;
    _UC *pucOutBuff         = MOS_NULL;
    _UC aucInBuf[512]       = {0};
    JSON_HANDLE hRoot       = Adpt_Json_CreateObject( );

    ctime = Mos_Time();

#if GA1400_SUPPORTIPANDPORT
    _INT iIsSupportIpAndPort= 1;
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"isSupportIpAndPort", Adpt_Json_CreateStrWithNum((_DOUBLE)iIsSupportIpAndPort));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"uid", Adpt_Json_CreateString((_UC*)(Config_GetSystemMng()->aucDevUID)));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"timestamp", Adpt_Json_CreateStrWithNum((_DOUBLE)ctime));

    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);
    MOS_VSNPRINTF(aucInBuf, sizeof(aucInBuf), "isSupportIpAndPort=%d&timestamp=%u&uid=%s", iIsSupportIpAndPort, ctime, Config_GetSystemMng()->aucDevUID);
    Adpt_HmacSha256_Encrypt(aucInBuf, pucOutBuff, 128, Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"signature", Adpt_Json_CreateString(pucOutBuff));
#else
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"uid", Adpt_Json_CreateString((_UC*)(Config_GetSystemMng()->aucDevUID)));
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"timestamp", Adpt_Json_CreateStrWithNum((_DOUBLE)ctime));

    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);
    MOS_VSNPRINTF(aucInBuf, sizeof(aucInBuf), "timestamp=%u&uid=%s", ctime, Config_GetSystemMng()->aucDevUID);
    Adpt_HmacSha256_Encrypt(aucInBuf, pucOutBuff, 128, Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"signature", Adpt_Json_CreateString(pucOutBuff));
#endif

    pStrTmp = Adpt_Json_Print(hRoot);

    MOS_LOG_INF(GA1400_LOGSTR, "GA1400 INFO INPUT pStrTmp:%s", pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;

}

// GA1400模块 接收Ga1400平台回复Ga1400信息的数据
_VOID Ga1400_GetGa1400InfoRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    if(Ga1400_GetHttpTask()->usBuffLen == 0)
    {
        Ga1400_GetHttpTask()->usBuffLen   = 1024;
        Ga1400_GetHttpTask()->pucHttpBuff = (_UC*)MOS_MALLOC(Ga1400_GetHttpTask()->usBuffLen);
    }
    if(Ga1400_GetHttpTask()->usRecvLen + uiLen < Ga1400_GetHttpTask()->usBuffLen)
    {
        MOS_MEMCPY(Ga1400_GetHttpTask()->pucHttpBuff + Ga1400_GetHttpTask()->usRecvLen, pucData, uiLen);
        Ga1400_GetHttpTask()->usRecvLen += uiLen;
    }

    return;
}

// GA1400模块 接收Ga1400平台回复Ga1400信息的数据结束
_VOID Ga1400_RecvGa1400InfoFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{   
    if(Ga1400_GetHttpTask()->pucHttpBuff)
    {
        Ga1400_GetHttpTask()->pucHttpBuff[Ga1400_GetHttpTask()->usRecvLen] = 0;
    }
    
    // GA1400模块 解析Ga1400回复的Ga1400信息的json数据
    Ga1400_ParseGetGa1400InfoRsp(Ga1400_GetHttpTask()->pucHttpBuff);
    MOS_LOG_INF(GA1400_LOGSTR, "GET GA1400 INFO Finish Recv %s", Ga1400_GetHttpTask()->pucHttpBuff);
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->pucHttpBuff   = MOS_NULL;
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
    Ga1400_GetHttpTask()->uiHttpHandle  = 0;
    
    Ga1400_SetTaskConnectFailTimeByMsg(MOS_FALSE, 0);

    return ;
}

// GA1400模块 接收Ga1400平台回复Ga1400信息的数据失败
_VOID Ga1400_RecvGa1400InfoFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC  aucUrl[128] = {0};
    _UC  aucStrErrLog[128] = {0};

    if(Ga1400_GetHttpTask()->pucHttpBuff)
    {
        if (Ga1400_GetHttpTask()->usRecvLen)
        {
            Ga1400_GetHttpTask()->pucHttpBuff[Ga1400_GetHttpTask()->usRecvLen-1] = 0;
        }
    }
    
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->pucHttpBuff   = MOS_NULL;
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
    Ga1400_GetHttpTask()->uiHttpHandle  = 0;

    Ga1400_SetTaskConnectFailTimeByMsg(MOS_TRUE, 0);

    MOS_VSNPRINTF(aucUrl, sizeof(aucUrl), "%s%s", Config_GetSystemMng()->aucGa1400Addr, GA1400_GETGA1400INFO_URL);
    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "GET GA1400 INFO Fail(%u)", uiReqId);
    CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), aucUrl, -1, 
                            EN_1400_RT_GET1400INFO_PLAT_RSP_ERR, aucStrErrLog, MOS_NULL, 1);  
    return;
}

// GA1400模块 获取Ga1400信息(配置参数)
_INT GA1400_GetGa1400Info()
{
    _INT iRet              =  0;
    _UI  uiHttpsFlag       =  0;
    _UC  ucTemp[1]         = {0};
    _UC  auAdmonAddr[128]  = {0};
    ST_MOS_INET_IP stNetIp = {0};   

    // 获取平台域名地址
    Http_Parse_Url(Config_GetSystemMng()->aucGa1400Addr, auAdmonAddr, ucTemp, &uiHttpsFlag);
    #if GA1400_POST_SUPPORT      // POST方式
    // 建立获取Ga1400信息的json数据  POST方式
    pStrTmp = Ga1400_BuildGetGa1400InfoJson();
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = Ga1400_GetGa1400InfoRsp;
    stHttpInfoNode.pfuncFinished   = Ga1400_RecvGa1400InfoFinish;
    stHttpInfoNode.pfuncFailed     = Ga1400_RecvGa1400InfoFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, GA1400_GETGA1400INFO_URL, EN_HTTP_METHOD_POST, Mos_GetSessionId());
    
    MOS_FREE(pStrTmp);
    #else                 // GET方式
    _UC aucUrl[512] = {0};

    // GA1400模块 组合获取Ga1400信息的URL GET方式获取
    Ga1400_BuildGetGa1400InfoUrl(aucUrl, sizeof(aucUrl));
    MOS_PRINTF("%s:%d: aucUrl:%s \r\n", __FUNCTION__, __LINE__, aucUrl);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = Ga1400_GetGa1400InfoRsp;
    stHttpInfoNode.pfuncFinished   = Ga1400_RecvGa1400InfoFinish;
    stHttpInfoNode.pfuncFailed     = Ga1400_RecvGa1400InfoFail;
    stHttpInfoNode.iTimeOut        = 15;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, aucUrl, EN_HTTP_METHOD_GET, Mos_GetSessionId());
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC  pucUrl[128] = {0};
        _UC  aucStrErrLog[128] = {0};
        MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucGa1400Addr, GA1400_GETGA1400INFO_URL);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "UpLoad AI 1400 Pic get Host(%s) AddrInfo error", auAdmonAddr);
        CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), pucUrl, -1, 
                                EN_1400_RT_GET1400INFO_URL_GET_HOST_ADDRINFO_ERR, aucStrErrLog, MOS_NULL, 1);
    }
    #endif

    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

static _VOID Ga1400_FirstRegisterRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    if(Ga1400_GetHttpTask()->usBuffLen == 0)
    {
        Ga1400_GetHttpTask()->usBuffLen   = HTTP_RECVBUF_SIZE;
        Ga1400_GetHttpTask()->pucHttpBuff = (_UC*)MOS_MALLOC(Ga1400_GetHttpTask()->usBuffLen);
    }
    if(Ga1400_GetHttpTask()->usRecvLen + uiLen < Ga1400_GetHttpTask()->usBuffLen)
    {
        MOS_MEMCPY(Ga1400_GetHttpTask()->pucHttpBuff + Ga1400_GetHttpTask()->usRecvLen, pucData, uiLen);
        Ga1400_GetHttpTask()->usRecvLen += uiLen;
    }
}

static _VOID Ga1400_FirstRegisterFinished(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iStatusCode       = 0;
    _UC  aucStrErrLog[128] = {0};
    if (Ga1400_GetHttpTask()->pucHttpBuff)
    {
        Ga1400_GetHttpTask()->pucHttpBuff[Ga1400_GetHttpTask()->usRecvLen] = 0;
    }
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(Ga1400_GetHttpTask()->pucHttpBuff);
    if (hJsonRoot)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"StatusCode"), &iStatusCode);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 Register 1400Domain:%s code:%d", Config_GetCamaraMng()->ucGAT1400Domain, iStatusCode);
        if (iStatusCode == 0)
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_REGISTER_SUCCESS, aucStrErrLog, MOS_NULL, 1); 
        }
        Adpt_Json_Delete(hJsonRoot);
    }
    else
    {
        MOS_LOG_ERR(GA1400_LOGSTR, "Https Post 1400 Register Parse StatusCode Json is Null");
    }

    /*清除http缓存*/
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
}

static _VOID Ga1400_FirstRegisterFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    if (uiErrCode != 401)
    {
        _UC  aucStrErrLog[256] = {0};
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 First Register ResultCode is %u", uiErrCode);
        CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                            EN_1400_RT_1ST_REG_URL_RT_NOT_401_REDIRECT_ERR, aucStrErrLog, MOS_NULL, 1);
    }
    /*清除http缓存*/                           
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
}

static _VOID Ga1400_FirstRegisterRecvHeader(_VPTR vpUserPtr, _UI uiReqId, ST_HTTP_PRASE_HEAD stHttpParseHead)
{
    if (stHttpParseHead.iResultCode == 401)
    {
        static _UI  m_uiNc                   =  2;
        _INT iLen                            =  0;
        _UC *pucPtr                          =  MOS_NULL;
        _UC *pucPtrTmp                       =  MOS_NULL;
        _UC  aucStrQop[16]                   = {0};
        _UC  aucStrRealm[16]                 = {0};
        _UC  aucStrNonce[36]                 = {0};
        _UC  aucStrCnonce[32]                = {0};
        _UC  aucRegisterUrl[128]             = {0};
        _UC  aucHttpsPostData[128]           = {0};
        _UC  aucWWWAuthenticate[512]         = {0};

        _UC aucMd5HD[128]                    = {0};
        _UC aucMd5HA1In[256]                 = {0};
        _UC aucMd5HA1Out16[16]               = {0};
        _UC aucMd5HA1Out32[36]               = {0};
        _UC aucMd5HA2In[128]                 = {0};
        _UC aucMd5HA2Out16[16]               = {0};
        _UC aucMd5HA2Out32[36]               = {0};
        _UC aucMd5ResponseOut16[16]          = {0};
        _UC aucMd5ResponseOut32[36]          = {0};
        _UC aucFirstRegHeadEx[64]            = {0};

        MOS_VSNPRINTF(aucFirstRegHeadEx, sizeof(aucFirstRegHeadEx), "User-Identify: %s\r\n", Config_GetCamaraMng()->ucGAT1400ID);
        MOS_STRNCPY(aucWWWAuthenticate, stHttpParseHead.ucWWWAuthenticate, sizeof(aucWWWAuthenticate));
        // MOS_LOG_INF(GA1400_LOGSTR, "WWWAuthenticate: %s", aucWWWAuthenticate);
        pucPtr = MOS_STRSTR(aucWWWAuthenticate,"realm");
        if (pucPtr != NULL)
        {
            pucPtr = MOS_STRCHR(pucPtr,'\"');
            pucPtr++;
            pucPtrTmp = MOS_STRCHR(pucPtr,'\"');
            iLen = pucPtrTmp - pucPtr;
            MOS_STRNCPY(aucStrRealm, pucPtr, iLen);
        }
        pucPtr = MOS_STRSTR(aucWWWAuthenticate,"nonce");
        if (pucPtr != NULL)
        {
            pucPtr = MOS_STRCHR(pucPtr,'\"');
            pucPtr++;
            pucPtrTmp = MOS_STRCHR(pucPtr,'\"');
            iLen = pucPtrTmp - pucPtr;
            MOS_STRNCPY(aucStrNonce, pucPtr, iLen);
        }
        pucPtr = MOS_STRSTR(aucWWWAuthenticate,"qop");
        if (pucPtr != NULL)
        {
            pucPtr = MOS_STRCHR(pucPtr,'=');
            pucPtr++;
            pucPtrTmp = MOS_STRCHR(pucPtr,',');
            iLen = pucPtrTmp - pucPtr;
            MOS_STRNCPY(aucStrQop, pucPtr, iLen);
        }
        Mos_GetRandomString(16, aucStrCnonce);
        MOS_VSNPRINTF(aucMd5HD,    sizeof(aucMd5HD),    "%s:%08X:%s:%s", aucStrNonce, m_uiNc, aucStrCnonce, aucStrQop);
        MOS_VSNPRINTF(aucMd5HA1In, sizeof(aucMd5HA1In), "%s:%s:%s",      Config_GetSystemMng()->aucDevUID, aucStrRealm, Config_GetSystemMng()->aucDevkey);
        MOS_VSNPRINTF(aucMd5HA2In, sizeof(aucMd5HA2In), "POST:/%s",      GA1400_REGISTER_URL);

        Mos_MD5(aucMd5HA1In, MOS_STRLEN(aucMd5HA1In), aucMd5HA1Out16);
        Mos_MD5_Decode16To32(aucMd5HA1Out16, aucMd5HA1Out32);

        Mos_MD5(aucMd5HA2In, MOS_STRLEN(aucMd5HA2In), aucMd5HA2Out16);
        Mos_MD5_Decode16To32(aucMd5HA2Out16, aucMd5HA2Out32);

        MOS_VSNPRINTF(aucMd5HA1In, sizeof(aucMd5HA1In),"%s:%s:%s", aucMd5HA1Out32, aucMd5HD, aucMd5HA2Out32);
        Mos_MD5(aucMd5HA1In, MOS_STRLEN(aucMd5HA1In), aucMd5ResponseOut16);
        Mos_MD5_Decode16To32(aucMd5ResponseOut16, aucMd5ResponseOut32);

        if (Ga1400_GetHttpTask()->pucSecondRegHeadEx == MOS_NULL)
        {
            Ga1400_GetHttpTask()->pucSecondRegHeadEx = (_UC*)MOS_MALLOC(512);
        }
        MOS_MEMSET(Ga1400_GetHttpTask()->pucSecondRegHeadEx, 0, 512);
        MOS_VSNPRINTF(Ga1400_GetHttpTask()->pucSecondRegHeadEx, 512, "%sAuthorization: Digest username=\"%s\",realm=\"%s\", nonce=\"%s\", uri=\"/%s\", cnonce=\"%s\", nc=%08X, qop=%s, response=\"%s\", opaque=\"\", algorithm=\"MD5\", deviceId=\"%s\"\r\n", 
                                            aucFirstRegHeadEx, Config_GetSystemMng()->aucDevUID, aucStrRealm, aucStrNonce, GA1400_REGISTER_URL, aucStrCnonce, m_uiNc, aucStrQop, aucMd5ResponseOut32, Config_GetCamaraMng()->ucGAT1400ID);
    }
}

static _VOID Ga1400_SecondRegisterRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    if(Ga1400_GetHttpTask()->usBuffLen == 0)
    {
        Ga1400_GetHttpTask()->usBuffLen   = HTTP_RECVBUF_SIZE;
        Ga1400_GetHttpTask()->pucHttpBuff = (_UC*)MOS_MALLOC(Ga1400_GetHttpTask()->usBuffLen);
    }
    if(Ga1400_GetHttpTask()->usRecvLen + uiLen < Ga1400_GetHttpTask()->usBuffLen)
    {
        MOS_MEMCPY(Ga1400_GetHttpTask()->pucHttpBuff + Ga1400_GetHttpTask()->usRecvLen, pucData, uiLen);
        Ga1400_GetHttpTask()->usRecvLen += uiLen;
    }
}

static _VOID Ga1400_SecondRegisterFinished(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iStatusCode       = 0;
    _UC  aucStrErrLog[128] = {0};
    if (Ga1400_GetHttpTask()->pucHttpBuff)
    {
        Ga1400_GetHttpTask()->pucHttpBuff[Ga1400_GetHttpTask()->usRecvLen] = 0;
    }
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(Ga1400_GetHttpTask()->pucHttpBuff);
    if (hJsonRoot)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"StatusCode"), &iStatusCode);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 Second Register 1400Domain:%s code:%d", Config_GetCamaraMng()->ucGAT1400Domain, iStatusCode);
        if (iStatusCode == 0)
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_REGISTER_SUCCESS, aucStrErrLog, MOS_NULL, 1); 
        }
        else
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_2ND_REG_URL_RT_STATUSCODE_NOT_0_ERR, aucStrErrLog, MOS_NULL, 1); 
        }
        Adpt_Json_Delete(hJsonRoot);
    }
    else
    {
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 Second Register Parse StatusCode Json is Null");
        CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, -1, 
                                EN_1400_RT_2ND_REG_URL_RT_JSON_NULL_ERR, aucStrErrLog, MOS_NULL, 1);
    }

    /*清除http缓存*/
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
}

static _VOID Ga1400_SecondRegisterFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC  aucStrErrLog[256] = {0};
    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 Second Register ResultCode is %u", uiErrCode);
    CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                        EN_1400_RT_2ND_REG_URL_RT_NOT_200_ERR, aucStrErrLog, MOS_NULL, 1);
    /*清除http缓存*/                           
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
}
// Ga1400 注册
_INT Ga1400_Register()
{
    MOS_LOG_INF(GA1400_LOGSTR, "Ga1400 Register Start GAT1400ID:%s  GAT1400Domain:%s", Config_GetCamaraMng()->ucGAT1400ID, Config_GetCamaraMng()->ucGAT1400Domain);

    _INT iRet = MOS_ERR;
    _UC *pStrStart   = MOS_NULL;
    _UC *pStrEnd     = MOS_NULL;
    _UC  aucAdmonAddr[64]      = {0};
    _UC  aucHttpsPostData[128] = {0};
    _UC  aucFirstRegHeadEx[64] = {0};

    // MOS_VSNPRINTF(aucRegisterUrl, sizeof(aucRegisterUrl), "%s%s", "https://222.81.123.40:443/", GA1400_REGISTER_URL);
    // MOS_VSNPRINTF(aucRegisterUrl, sizeof(aucRegisterUrl), "%s%s", "https://viid-vcp.21cn.com:443/", GA1400_REGISTER_URL);
    // MOS_VSNPRINTF(aucRegisterUrl, sizeof(aucRegisterUrl), "%s%s", Config_GetCamaraMng()->ucGAT1400Domain, GA1400_REGISTER_URL);
    MOS_VSNPRINTF(aucHttpsPostData,  sizeof(aucHttpsPostData),  "{\"RegisterObject\": {\"DeviceID\": \"%s\"}}", Config_GetCamaraMng()->ucGAT1400ID);
    MOS_VSNPRINTF(aucFirstRegHeadEx, sizeof(aucFirstRegHeadEx), "User-Identify: %s\r\n", Config_GetCamaraMng()->ucGAT1400ID);

    pStrStart = MOS_STRSTR(Config_GetCamaraMng()->ucGAT1400Domain,"//");
    pStrStart += MOS_STRLEN("//");
    pStrEnd = MOS_STRSTR(pStrStart,"/");
    MOS_MEMCPY(aucAdmonAddr, pStrStart, pStrEnd-pStrStart);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.pfuncRecv        = Ga1400_FirstRegisterRecvFunc;
    stHttpInfoNode.pfuncFinished    = Ga1400_FirstRegisterFinished;
    stHttpInfoNode.pfuncFailed      = Ga1400_FirstRegisterFailed;
    stHttpInfoNode.pfuncRecvHeader  = Ga1400_FirstRegisterRecvHeader;
    stHttpInfoNode.pucExpandHeader  = aucFirstRegHeadEx;
    stHttpInfoNode.pucContent       = aucHttpsPostData;
    stHttpInfoNode.uiContentLen     = MOS_STRLEN(aucHttpsPostData);
    iRet = Http_SendSyncRequest(&stHttpInfoNode, aucAdmonAddr, GA1400_REGISTER_URL, EN_HTTP_METHOD_POST, Mos_GetSessionId());
    if (iRet == MOS_OK)
    {
        return MOS_OK;
    }
    else if (iRet == EN_HTTP_RET_COMMON_ERR)
    {
        Mos_Sleep(100);
        /*需要第二次注册*/
        if (Ga1400_GetHttpTask()->pucSecondRegHeadEx == MOS_NULL)
        {
            MOS_LOG_ERR(GA1400_LOGSTR, "SecondRegHeadEx is null");
            return MOS_ERR;
        }
        MOS_MEMSET(&stHttpInfoNode, 0, sizeof(ST_HTTP_INFO_NODE));
        Http_GetDefaultConfig(&stHttpInfoNode);
        stHttpInfoNode.pfuncRecv        = Ga1400_SecondRegisterRecvFunc;
        stHttpInfoNode.pfuncFinished    = Ga1400_SecondRegisterFinished;
        stHttpInfoNode.pfuncFailed      = Ga1400_SecondRegisterFailed;
        stHttpInfoNode.pucContent       = aucHttpsPostData;
        stHttpInfoNode.uiContentLen     = MOS_STRLEN(aucHttpsPostData);
        stHttpInfoNode.pucExpandHeader = Ga1400_GetHttpTask()->pucSecondRegHeadEx;

        iRet = Http_SendSyncRequest(&stHttpInfoNode, aucAdmonAddr, GA1400_REGISTER_URL, EN_HTTP_METHOD_POST, Mos_GetSessionId());
        MOS_FREE(Ga1400_GetHttpTask()->pucSecondRegHeadEx);
        return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
    }
    else
    {
        MOS_LOG_ERR(GA1400_LOGSTR, "HTTP Add Node Fail %d\n", iRet);
    }
    return MOS_ERR;
}

static _VOID Ga1400_UnRegisterRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    if(Ga1400_GetHttpTask()->usBuffLen == 0)
    {
        Ga1400_GetHttpTask()->usBuffLen   = HTTP_RECVBUF_SIZE;
        Ga1400_GetHttpTask()->pucHttpBuff = (_UC*)MOS_MALLOC(Ga1400_GetHttpTask()->usBuffLen);
    }
    if(Ga1400_GetHttpTask()->usRecvLen + uiLen < Ga1400_GetHttpTask()->usBuffLen)
    {
        MOS_MEMCPY(Ga1400_GetHttpTask()->pucHttpBuff + Ga1400_GetHttpTask()->usRecvLen, pucData, uiLen);
        Ga1400_GetHttpTask()->usRecvLen += uiLen;
    }
}

static _VOID Ga1400_UnRegisterFinished(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _INT iStatusCode = -1;
    _UC aucStrErrLog[128]   = {0};
    if (Ga1400_GetHttpTask()->pucHttpBuff)
    {
        Ga1400_GetHttpTask()->pucHttpBuff[Ga1400_GetHttpTask()->usRecvLen] = 0;
    }
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(Ga1400_GetHttpTask()->pucHttpBuff);
    if (hJsonRoot)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"StatusCode"), &iStatusCode);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 UnRegister 1400Domain:%s code:%d", Config_GetCamaraMng()->ucGAT1400Domain, iStatusCode);
        if (iStatusCode == 0)
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_UNREGISTER_SUCCESS, aucStrErrLog, MOS_NULL, 1); 
        }
        else
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_UNREG_URL_RT_STATUSCODE_NOT_0_ERR, aucStrErrLog, MOS_NULL, 1); 
        }
        Adpt_Json_Delete(hJsonRoot);
    }
    else
    {
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 UnRegister Parse StatusCode Json is Null");
        CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, -1, 
                                EN_1400_RT_UNREG_URL_RT_JSON_NULL_ERR, aucStrErrLog, MOS_NULL, 1);
    }
    /*清除http缓存*/                           
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
}

static _VOID Ga1400_UnRegisterFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC aucStrErrLog[128]   = {0};
    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 UnRegister ResultCode is %u not 200", uiErrCode);
    CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, -1, 
                            EN_1400_RT_UNREG_URL_RT_NOT_200_ERR, aucStrErrLog, MOS_NULL, 1);
    /*清除http缓存*/                           
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
}

// Ga1400 注销
_INT Ga1400_UnRegister()
{
    // MOS_PRINTF("%s:%d: Start \r\n", __FUNCTION__, __LINE__);
    _UC *pStrStart   = MOS_NULL;
    _UC *pStrEnd     = MOS_NULL;
    _UC  aucAdmonAddr[64]         = {0};
    _UC  aucHttpsPostData[128]    = {0};
    _UC  aucUnRegisterHeadEx[128] = {0};

    // MOS_VSNPRINTF(aucUnRegisterUrl, sizeof(aucUnRegisterUrl),    "%s%s", Config_GetCamaraMng()->ucGAT1400Domain, GA1400_UNREGISTER_URL);
    MOS_VSNPRINTF(aucHttpsPostData,    sizeof(aucHttpsPostData),    "{\"UnRegisterObject\": {\"DeviceID\": \"%s\"}}", Config_GetCamaraMng()->ucGAT1400ID);
    MOS_VSNPRINTF(aucUnRegisterHeadEx, sizeof(aucUnRegisterHeadEx), "User-Identify: %s\r\n", Config_GetCamaraMng()->ucGAT1400ID);

    pStrStart = MOS_STRSTR(Config_GetCamaraMng()->ucGAT1400Domain,"//");
    pStrStart += MOS_STRLEN("//");
    pStrEnd = MOS_STRSTR(pStrStart,"/");
    MOS_MEMCPY(aucAdmonAddr, pStrStart, pStrEnd-pStrStart);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.pfuncRecv        = Ga1400_UnRegisterRecvFunc;
    stHttpInfoNode.pfuncFinished    = Ga1400_UnRegisterFinished;
    stHttpInfoNode.pfuncFailed      = Ga1400_UnRegisterFailed;
    stHttpInfoNode.pucExpandHeader  = aucUnRegisterHeadEx;
    stHttpInfoNode.pucContent       = aucHttpsPostData;
    stHttpInfoNode.uiContentLen     = MOS_STRLEN(aucHttpsPostData);
    _INT iRet = Http_SendSyncRequest(&stHttpInfoNode, aucAdmonAddr, GA1400_UNREGISTER_URL, EN_HTTP_METHOD_POST, Mos_GetSessionId());
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

static _VOID Ga1400_KeepAliveRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    if(Ga1400_GetHttpTask()->usBuffLen == 0)
    {
        Ga1400_GetHttpTask()->usBuffLen   = HTTP_RECVBUF_SIZE;
        Ga1400_GetHttpTask()->pucHttpBuff = (_UC*)MOS_MALLOC(Ga1400_GetHttpTask()->usBuffLen);
    }
    if(Ga1400_GetHttpTask()->usRecvLen + uiLen < Ga1400_GetHttpTask()->usBuffLen)
    {
        MOS_MEMCPY(Ga1400_GetHttpTask()->pucHttpBuff + Ga1400_GetHttpTask()->usRecvLen, pucData, uiLen);
        Ga1400_GetHttpTask()->usRecvLen += uiLen;
    }
}

static _VOID Ga1400_KeepAliveFinished(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _UI iStatusCode         = -1;
    _UC aucStrErrLog[128]   = {0};
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(Ga1400_GetHttpTask()->pucHttpBuff);
    if (hJsonRoot)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"StatusCode"), &iStatusCode);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post KeepAlive Ga1400ID:%s code:%d",  Config_GetCamaraMng()->ucGAT1400ID, iStatusCode);
        if (iStatusCode == 0)
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_KEEPALIVE_SUCCESS, aucStrErrLog, MOS_NULL, 1); 
        }
        else
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_KEEPALIVE_URL_RT_STATUSCODE_NOT_0_ERR, aucStrErrLog, MOS_NULL, 1); 
        }
        Adpt_Json_Delete(hJsonRoot);
    }
    else
    {
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 KeepAlive Parse StatusCode Json is Null");
        CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, -1, 
                                EN_1400_RT_KEEPALIVE_URL_RT_JSON_NULL_ERR, aucStrErrLog, MOS_NULL, 1);
    }
    /*清除http缓存*/ 
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
}

static _VOID Ga1400_KeepAliveFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC aucStrErrLog[128]   = {0};
    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 KeepAlive ResultCode is %u not 200", uiErrCode);
    CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, -1, 
                            EN_1400_RT_KEEPALIVE_URL_RT_NOT_200_ERR, aucStrErrLog, MOS_NULL, 1);
    /*清除http缓存*/ 
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpBuff);
    Ga1400_GetHttpTask()->usBuffLen     = 0;
    Ga1400_GetHttpTask()->usRecvLen     = 0;
}

// Ga1400 保活
_INT Ga1400_KeepAlive()
{
    // MOS_PRINTF("%s:%d: Start \r\n", __FUNCTION__, __LINE__);
    _UC *pStrStart   = MOS_NULL;
    _UC *pStrEnd     = MOS_NULL;
    _UC  aucAdmonAddr[64]        = {0};
    _UC  aucHttpsPostData[128]   = {0};
    _UC  aucKeepAliveHeadEx[128] = {0};

    // MOS_VSNPRINTF(aucKeepAliveUrl, sizeof(aucKeepAliveUrl),    "%s%s", Config_GetCamaraMng()->ucGAT1400Domain, GA1400_KEEPALIVE_URL);
    MOS_VSNPRINTF(aucHttpsPostData,   sizeof(aucHttpsPostData),   "{\"KeepaliveObject\": {\"DeviceID\": \"%s\"}}", Config_GetCamaraMng()->ucGAT1400ID);
    MOS_VSNPRINTF(aucKeepAliveHeadEx, sizeof(aucKeepAliveHeadEx), "User-Identify: %s\r\n", Config_GetCamaraMng()->ucGAT1400ID);

    pStrStart = MOS_STRSTR(Config_GetCamaraMng()->ucGAT1400Domain,"//");
    pStrStart += MOS_STRLEN("//");
    pStrEnd = MOS_STRSTR(pStrStart,"/");
    MOS_MEMCPY(aucAdmonAddr, pStrStart, pStrEnd-pStrStart);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.pfuncRecv        = Ga1400_KeepAliveRecvFunc;
    stHttpInfoNode.pfuncFinished    = Ga1400_KeepAliveFinished;
    stHttpInfoNode.pfuncFailed      = Ga1400_KeepAliveFailed;
    stHttpInfoNode.pucExpandHeader  = aucKeepAliveHeadEx;
    stHttpInfoNode.pucContent       = aucHttpsPostData;
    stHttpInfoNode.uiContentLen     = MOS_STRLEN(aucHttpsPostData);
    _INT iRet = Http_SendSyncRequest(&stHttpInfoNode, aucAdmonAddr, GA1400_KEEPALIVE_URL, EN_HTTP_METHOD_POST, Mos_GetSessionId());
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

// JSON添加拓展字段
static int Ga1400_JsonAddExpandField(JSON_HANDLE hObject, _UC *pucExpandField)
{
    if (hObject == MOS_NULL || pucExpandField == MOS_NULL)
    {
        return MOS_ERR;
    }

    _UC *pucKName       = MOS_NULL;
    JSON_HANDLE hCur    = MOS_NULL;
    JSON_HANDLE hNew    = MOS_NULL;
    JSON_HANDLE hChild  = MOS_NULL;
    JSON_HANDLE hExpandField = MOS_NULL;

    hExpandField = Adpt_Json_Parse(pucExpandField);
    if (hExpandField == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 轮训拓展字段
    hChild = Adpt_Json_GetChild(hExpandField);
    while (hChild != MOS_NULL)
    {
        hCur   = hChild;
        Adpt_Json_GetName(hCur, &pucKName);
        hChild = Adpt_Json_GetNext(hCur);

        if (MOS_STRLEN(pucKName))
        {
            // Adpt_Json_AddItemReferenceToObject(hObject, (_UC*)pucKName, hChild);  // 新json对象的字符串地址还会指向原json对象，该处调用有问题
            hNew = Adpt_Json_DetachItemViaPointer(hExpandField, hCur);               // 拆卸json对象，对原json有影响
            // hNew = Adpt_Json_Duplicate(hCur, 1);                                  // 复制json对象，对原json无影响
            if (hNew != MOS_NULL) 
            {
                Adpt_Json_AddItemToObject(hObject, (_UC*)pucKName, hNew);
            }
        }
    }
    Adpt_Json_Delete(hExpandField);
    return MOS_OK;
}

// 删除人脸节点
static _INT Ga1400_DelFaceListNode(_UI uiAIIoTType, _UI uiEventId)
{
    ST_MOS_LIST_ITERATOR stIterator2;
    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfFaceNode = MOS_NULL;

    // 查找要释放缓存的节点
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfFaceNode, stIterator2)
    {
        // MOS_LOG_INF(GA1400_LOGSTR,"uiUseFlag:%u uiUploadFlag:%u uiAIIoTType:%u uiEventId:%u reqId:%u", \
        // pstUploadAIPic1400InfFaceNode->uiUseFlag, \
        // pstUploadAIPic1400InfFaceNode->uiUploadFlag, \
        // pstUploadAIPic1400InfFaceNode->uiAIIoTType, \
        // pstUploadAIPic1400InfFaceNode->uiEventId, \
        // pstUploadAIPic1400InfFaceNode->uiReqId);

        if ((1 == pstUploadAIPic1400InfFaceNode->uiUseFlag)             && 
            (2 == pstUploadAIPic1400InfFaceNode->uiUploadFlag)          && 
            (pstUploadAIPic1400InfFaceNode->uiAIIoTType == uiAIIoTType) && 
            (pstUploadAIPic1400InfFaceNode->uiEventId   == uiEventId))
        {
            Config_DelUploadAIPic1400TaskNode(0, pstUploadAIPic1400InfFaceNode->uiReqId);
        }
    }
    return MOS_OK;
}

// 删除车牌节点
static _INT Ga1400_DelCarListNode(_UI uiAIIoTType, _UI uiEventId)
{
    ST_MOS_LIST_ITERATOR stIterator1;
    ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfCarNode = MOS_NULL;

    // 查找要释放缓存的节点
    FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfCarNode, stIterator1)
    {
        if ((1 == pstUploadAIPic1400InfCarNode->uiUseFlag)             && 
            (2 == pstUploadAIPic1400InfCarNode->uiUploadFlag)          && 
            (pstUploadAIPic1400InfCarNode->uiAIIoTType == uiAIIoTType) && 
            (pstUploadAIPic1400InfCarNode->uiEventId   == uiEventId))
        {
            Config_DelUploadAIPic1400TaskNode(0, pstUploadAIPic1400InfCarNode->uiReqId);
        }
    }
    return MOS_OK;
}

_UC *Ga1400_BuildUploadAIPicTo1400Json(ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode)
{
    MOS_PARAM_NULL_RETNULL(pstUploadAIPic1400InfNode);

    _INT iRet                           =  0;
    _INT iAiAlarmCount                  =  0;
    static _INT iAiPicCount             =  0;
    _UC aucSourceID[64]                 = {0};
    _UC aucImageIDBg[64]                = {0};
    _UC aucImageIDPic[64]               = {0};
    _UC aucHappenTime[16]               = {0};
    ST_MOS_SYS_TIME stSysTime           = {0};
    _UC *pStrTmp                        = MOS_NULL;
    JSON_HANDLE hRoot                   = MOS_NULL;
    JSON_HANDLE hPicExpandField         = MOS_NULL;
    JSON_HANDLE hBgPicExpandField       = MOS_NULL;
    JSON_HANDLE hEventExpandField       = MOS_NULL;
    JSON_HANDLE hSubImageList           = MOS_NULL;
    JSON_HANDLE hSubImageInfoArray      = MOS_NULL;
    JSON_HANDLE hSubImageInfoObjectBg   = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    EN_1400_PIC_TYPE enPicType          = EN_1400_PIC_TYPE_FACE;

    // 图片类型
    switch (pstUploadAIPic1400InfNode->uiAIIoTType)
    {
        case EN_ZJ_AIIOT_TYPE_FACE_CAPTURE: // 新人脸抓拍
        {
            enPicType = EN_1400_PIC_TYPE_FACE;
            break;
        }
        case EN_ZJ_AIIOT_TYPE_MOTION:
        {
            if (EN_ZJ_MOTION_EVENT_CARNUM_DISCERN == pstUploadAIPic1400InfNode->uiEventId) // 车牌
            {
                enPicType = EN_1400_PIC_TYPE_CARNUM;
            }
            else if (EN_ZJ_MOTION_EVENT_FACE == pstUploadAIPic1400InfNode->uiEventId) // 旧人脸抓拍
            {
                enPicType = EN_1400_PIC_TYPE_FACE;
            }
            else
            {
                enPicType = EN_1400_PIC_TYPE_FACE;
            }
            break;
        }
        default:
            enPicType = EN_1400_PIC_TYPE_FACE;
            break;
    }

    MOS_PRINTF("Ga1400_BuildUploadAIPicTo1400Json start enPicType:%d \r\n", enPicType);
    if (EN_1400_PIC_TYPE_FACE == enPicType) // 人脸抓拍
    {
        _UC aucFaceID[64]                   = {0};
        JSON_HANDLE hFaceListObject         = MOS_NULL;
        JSON_HANDLE hFaceObject             = MOS_NULL;
        JSON_HANDLE hFaceObjectArray        = MOS_NULL;
        JSON_HANDLE hSubImageInfoObjectFace = MOS_NULL;
        ST_CFG_UPLOAD_AIPIC_1400_INF_NODE  *pstUploadAIPic1400InfFaceNode = MOS_NULL;

        hRoot = Adpt_Json_CreateObject();
        // 人脸对象列表
        hFaceListObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot, (_UC*)"FaceListObject", hFaceListObject);
        // 人脸对象信息
        hFaceObjectArray = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hFaceListObject, (_UC*)"FaceObject", hFaceObjectArray);

        // 查找要上传图片到1400平台的节点
        FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfFaceNode, stIterator)
        {
            if ((1 == pstUploadAIPic1400InfFaceNode->uiUseFlag) \
                && (1 == pstUploadAIPic1400InfFaceNode->uiUploadFlag) \
                && (pstUploadAIPic1400InfFaceNode->uiAIIoTType == pstUploadAIPic1400InfNode->uiAIIoTType) \
                && (pstUploadAIPic1400InfFaceNode->uiEventId == pstUploadAIPic1400InfNode->uiEventId))
            {
                // MOS_LOG_INF(GA1400_LOGSTR, "Find Upload Pic 1400 Face Node Id:%u", pstUploadAIPic1400InfFaceNode->uiReqId);
                iAiAlarmCount++;
                if (pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead)
                {
                    hFaceObject = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToArray(hFaceObjectArray, hFaceObject);

                    Mos_TimetoSysTime(&pstUploadAIPic1400InfFaceNode->cAlarmTime,&stSysTime);
                    // Mos_GetSysTime(&stSysTime); 
                    MOS_VSNPRINTF(aucHappenTime, sizeof(aucHappenTime), "%04u%02u%02u%02u%02u%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond); 
                    MOS_VSNPRINTF(aucSourceID,   sizeof(aucSourceID),   "%s02%s%05d", Config_GetCamaraMng()->ucGAT1400ID, aucHappenTime, iAiPicCount);
                    MOS_VSNPRINTF(aucImageIDBg,  sizeof(aucImageIDBg),  "%s02%s%05d", Config_GetCamaraMng()->ucGAT1400ID, aucHappenTime, iAiPicCount);
                    iAiPicCount++;
                    MOS_VSNPRINTF(aucFaceID,     sizeof(aucFaceID),     "%s06%05d",   aucSourceID, iAiPicCount);
                    MOS_VSNPRINTF(aucImageIDPic, sizeof(aucImageIDPic), "%s02%s%05d", Config_GetCamaraMng()->ucGAT1400ID, aucHappenTime, iAiPicCount);
                    iAiPicCount++;
                    // 人脸标识
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"FaceID",Adpt_Json_CreateString(aucFaceID));
                    // 信息分类 自动采集:1 人工采集:2 其他：0
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"InfoKind",Adpt_Json_CreateNumber(1));
                    // 来源标识
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"SourceID",Adpt_Json_CreateString(aucSourceID));
                    // 设备编码(GA1400ID)
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"DeviceID",Adpt_Json_CreateString(Config_GetCamaraMng()->ucGAT1400ID));
                    // 人脸出现时间
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"FaceAppearTime",Adpt_Json_CreateString(aucHappenTime));
                    // 人脸消失时间
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"FaceDisAppearTime",Adpt_Json_CreateString(aucHappenTime));
                    // 位置标记时间
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"LocationMarkTime",Adpt_Json_CreateString(aucHappenTime));
                    // 左上角X坐标
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"LeftTopX",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiLeftTopX));
                    // 左上角Y坐标
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"LeftTopY",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiLeftTopY));
                    // 右下角X坐标
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"RightBtmX",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiRightBtmX));
                    // 右下角Y坐标
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"RightBtmY",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiRightBtmY));
                    #if 0  // 修改为由厂商按需求透传
                    // 是否驾驶员 0：否 1：是 2：不确定
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsDriver",Adpt_Json_CreateNumber(2)); // 必选字段
                    // 是否涉外人员 0：否 1：是 2：不确定
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsForeigner",Adpt_Json_CreateNumber(2)); // 必选字段
                    // 是否涉恐人员 0：否 1：是 2：不确定
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsSuspectedTerrorist",Adpt_Json_CreateNumber(2)); // 必选字段
                    // 是否涉案人员 0：否 1：是 2：不确定
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsCriminalInvolved",Adpt_Json_CreateNumber(2)); // 必选字段
                    // 是否在押人员 0：否 1：是 2：不确定
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsDetainees",Adpt_Json_CreateNumber(2)); // 必选字段
                    // 是否被害人 0：否 1：是 2：不确定
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsVictim",Adpt_Json_CreateNumber(2)); // 必选字段
                    // 是否可疑人 0：否 1：是 2：不确定
                    Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsSuspiciousPerson",Adpt_Json_CreateNumber(2)); // 必选字段
                    #endif

                    // 对于必选字段, 厂家没有透传时, SDK需要加上该字段
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucEventExpandDes, "\"IsDriver\""))
                    {
                        // 是否驾驶员 0：否 1：是 2：不确定
                        Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsDriver",Adpt_Json_CreateNumber(2));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucEventExpandDes, "\"IsForeigner\""))
                    {
                        // 是否涉外人员 0：否 1：是 2：不确定
                        Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsForeigner",Adpt_Json_CreateNumber(2));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucEventExpandDes, "\"IsSuspectedTerrorist\""))
                    {
                        // 是否涉恐人员 0：否 1：是 2：不确定
                        Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsSuspectedTerrorist",Adpt_Json_CreateNumber(2));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucEventExpandDes, "\"IsCriminalInvolved\""))
                    {
                        // 是否涉案人员 0：否 1：是 2：不确定
                        Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsCriminalInvolved",Adpt_Json_CreateNumber(2));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucEventExpandDes, "\"IsDetainees\""))
                    {
                        // 是否在押人员 0：否 1：是 2：不确定
                        Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsDetainees",Adpt_Json_CreateNumber(2));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucEventExpandDes, "\"IsVictim\""))
                    {
                        // 是否被害人 0：否 1：是 2：不确定
                        Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsVictim",Adpt_Json_CreateNumber(2));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucEventExpandDes, "\"IsSuspiciousPerson\""))
                    {
                        // 是否可疑人 0：否 1：是 2：不确定
                        Adpt_Json_AddItemToObject(hFaceObject,(_UC*)"IsSuspiciousPerson",Adpt_Json_CreateNumber(2));
                    }

                    // 厂商透传字段
                    Ga1400_JsonAddExpandField(hFaceObject, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucEventExpandDes);

                    // 图像对象列表
                    hSubImageList = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToObject(hFaceObject, (_UC*)"SubImageList", hSubImageList);
                    // 图像对象信息
                    hSubImageInfoArray = Adpt_Json_CreateArray();
                    Adpt_Json_AddItemToObject(hSubImageList, (_UC*)"SubImageInfoObject", hSubImageInfoArray);
                    // 背景图信息
                    hSubImageInfoObjectBg = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToArray(hSubImageInfoArray, hSubImageInfoObjectBg);
                    // 设备编码(GA1400ID)
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"DeviceID",Adpt_Json_CreateString(Config_GetCamaraMng()->ucGAT1400ID));
                    // 图像标识
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ImageID",Adpt_Json_CreateString(aucImageIDBg));
                    // MOS_PRINTF("GAAAAAAAA: Face  ImageID:%s  \r\n", aucImageIDBg);
                    // 信息分类 自动采集:1 人工采集:2 其他：0
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"InfoKind",Adpt_Json_CreateNumber(1));
                    // 图像来源 99:其他
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ImageSource",Adpt_Json_CreateString((_UC *)"99"));
                    // 图像分析处理事件类型  人脸检测：10  人脸比对：11  车辆检测：12  车辆比对：13  车牌识别：16
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"EventSort",Adpt_Json_CreateNumber(10));
                    // 图像文件格式
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"FileFormat",Adpt_Json_CreateString((_UC *)"Jpeg"));
                    // 抓拍时间
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ShotTime",Adpt_Json_CreateString(aucHappenTime));
                    #if 0  // 修改为由厂商按需求透传
                    // 图像图片存储路径 采用 URI 命名规则
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"StoragePath",Adpt_Json_CreateString((_UC *)""));
                    // 题名
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Title",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 内容描述
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ContentDescription",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 拍摄地点区划内详细地址
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ShotPlaceFullAdress",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 密级代码 自动采集时取值为5(公开)
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"SecurityLevel",Adpt_Json_CreateString((_UC *)"5")); // 必选字段
                    #endif

                    // 对于必选字段, 厂家没有透传时, SDK需要加上该字段
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucBgPicExpandDes, "\"Title\""))
                    {
                        // 题名
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Title",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucBgPicExpandDes, "\"ContentDescription\""))
                    {
                        // 内容描述
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ContentDescription",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucBgPicExpandDes, "\"ShotPlaceFullAdress\""))
                    {
                        // 拍摄地点区划内详细地址
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ShotPlaceFullAdress",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucBgPicExpandDes, "\"SecurityLevel\""))
                    {
                        // 密级代码 自动采集时取值为5(公开)
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"SecurityLevel",Adpt_Json_CreateString((_UC *)"5"));
                    }

                    // 图像类型 场景图：14 人脸图：11  车辆图：09
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Type",Adpt_Json_CreateString((_UC *)"14"));
                    // 图像宽
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Width",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.dBgWidth));
                    // 图像高
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Height",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.dBgHeight));
                    // 图片大小
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"FileSize",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen));

                    // 事件背景图厂商透传字段
                    Ga1400_JsonAddExpandField(hSubImageInfoObjectBg, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.aucBgPicExpandDes);
#if GA1400_BASEDATA_USE_NODE
                    if (pstUploadAIPic1400InfFaceNode->pucBgPicBaseData == MOS_NULL)
                    {
                        MOS_PRINTF("BG Face Malloc DataLen:%u \r\n", pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen);
                        pstUploadAIPic1400InfFaceNode->pucBgPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen * (4/3.0) + 8));
                        pstUploadAIPic1400InfFaceNode->uiBgPicBaseDataLen = pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen;
                    }
                    else
                    {
                        if (pstUploadAIPic1400InfFaceNode->uiBgPicBaseDataLen < pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen)
                        {
                            MOS_PRINTF("BG Face Free DataLen:%u Malloc DataLen:%u \r\n", pstUploadAIPic1400InfFaceNode->uiBgPicBaseDataLen, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen);
                            MOS_FREE(pstUploadAIPic1400InfFaceNode->pucBgPicBaseData);
                            pstUploadAIPic1400InfFaceNode->pucBgPicBaseData   = MOS_NULL;
                            pstUploadAIPic1400InfFaceNode->pucBgPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen * (4/3.0) + 8));
                            pstUploadAIPic1400InfFaceNode->uiBgPicBaseDataLen = pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen;
                        }
                        else
                        {
                            MOS_PRINTF("BG Face NO Malloc \r\n");
                            MOS_MEMSET(pstUploadAIPic1400InfFaceNode->pucBgPicBaseData, 0, ((float)pstUploadAIPic1400InfFaceNode->uiBgPicBaseDataLen * (4/3.0) + 8));
                        }
                    }
                    Adpt_Base64_Enc(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pucBgJpgBuff, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen, pstUploadAIPic1400InfFaceNode->pucBgPicBaseData);
                    // 图像数据 base64 字符串
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Data",Adpt_Json_CreateString(pstUploadAIPic1400InfFaceNode->pucBgPicBaseData));
#else
                    if (Ga1400_GetTaskMng()->pucBgPicBaseData == MOS_NULL)
                    {
                        MOS_PRINTF("BG Face Malloc DataLen:%u \r\n", pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen);
                        Ga1400_GetTaskMng()->pucBgPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen * (4/3.0) + 8));
                        Ga1400_GetTaskMng()->uiBgPicBaseDataLen = pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen;
                    }
                    else
                    {
                        if (Ga1400_GetTaskMng()->uiBgPicBaseDataLen < pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen)
                        {
                            MOS_PRINTF("BG Face Free DataLen:%u Malloc DataLen:%u \r\n", Ga1400_GetTaskMng()->uiBgPicBaseDataLen, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen);
                            MOS_FREE(Ga1400_GetTaskMng()->pucBgPicBaseData);
                            Ga1400_GetTaskMng()->pucBgPicBaseData   = MOS_NULL;
                            Ga1400_GetTaskMng()->pucBgPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen * (4/3.0) + 8));
                            Ga1400_GetTaskMng()->uiBgPicBaseDataLen = pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen;
                        }
                        else
                        {
                            // MOS_PRINTF("BG Face NO Malloc \r\n");
                            MOS_MEMSET(Ga1400_GetTaskMng()->pucBgPicBaseData, 0, ((float)Ga1400_GetTaskMng()->uiBgPicBaseDataLen * (4/3.0) + 8));
                        }
                    }

                    Adpt_Base64_Enc(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pucBgJpgBuff, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.uiBgJpgLen, Ga1400_GetTaskMng()->pucBgPicBaseData);
                    // 图像数据 base64 字符串
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Data",Adpt_Json_CreateString(Ga1400_GetTaskMng()->pucBgPicBaseData));
#endif
                    // 人脸图信息
                    hSubImageInfoObjectFace = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToArray(hSubImageInfoArray, hSubImageInfoObjectFace);
                    // 设备编码(GA1400ID)
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"DeviceID",Adpt_Json_CreateString(Config_GetCamaraMng()->ucGAT1400ID));
                    // 图像标识
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"ImageID",Adpt_Json_CreateString(aucImageIDPic));
                    // MOS_PRINTF("GAAAAAAAA: Face  ImageID:%s  \r\n", aucImageIDPic);
                    // 信息分类 自动采集:1 人工采集:2 其他：0
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"InfoKind",Adpt_Json_CreateNumber(1));
                    // 图像来源 99:其他
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"ImageSource",Adpt_Json_CreateString((_UC *)"99"));
                    // 图像分析处理事件类型  人脸检测：10  人脸比对：11  车辆检测：12  车辆比对：13  车牌识别：16
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"EventSort",Adpt_Json_CreateNumber(10));
                    // 图像文件格式
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"FileFormat",Adpt_Json_CreateString((_UC *)"Jpeg"));
                    // 抓拍时间
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"ShotTime",Adpt_Json_CreateString(aucHappenTime));
                    #if 0  // 修改为由厂商按需求透传
                    // 图像图片存储路径 采用 URI 命名规则
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"StoragePath",Adpt_Json_CreateString((_UC *)""));
                    // 题名
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"Title",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 内容描述
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"ContentDescription",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 拍摄地点区划内详细地址
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"ShotPlaceFullAdress",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 密级代码 自动采集时取值为5(公开)
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"SecurityLevel",Adpt_Json_CreateString((_UC *)"5")); // 必选字段
                    #endif

                    // 对于必选字段, 厂家没有透传时, SDK需要加上该字段
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, "\"Title\""))
                    {
                        // 题名
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"Title",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, "\"ContentDescription\""))
                    {
                        // 内容描述
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"ContentDescription",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, "\"ShotPlaceFullAdress\""))
                    {
                        // 拍摄地点区划内详细地址
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"ShotPlaceFullAdress",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, "\"SecurityLevel\""))
                    {
                        // 密级代码 自动采集时取值为5(公开)
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"SecurityLevel",Adpt_Json_CreateString((_UC *)"5"));
                    }

                    // 图像类型   场景图：14  人脸图：11  车辆图：09
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"Type",Adpt_Json_CreateString((_UC *)"11"));
                    // 图像宽
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"Width",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->dWidth));
                    // 图像高
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"Height",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->dHeight));
                    // 图片大小
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"FileSize",Adpt_Json_CreateNumber(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen));

                    // 事件人脸抓拍图厂商透传字段
                    Ga1400_JsonAddExpandField(hSubImageInfoObjectFace, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes);

#if GA1400_BASEDATA_USE_NODE
                    if (pstUploadAIPic1400InfFaceNode->pucFaceOrCarPicBaseData == MOS_NULL)
                    {
                        MOS_PRINTF("Face Malloc DataLen:%u \r\n", pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen);
                        pstUploadAIPic1400InfFaceNode->pucFaceOrCarPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen * (4/3.0) + 8));
                        pstUploadAIPic1400InfFaceNode->uiFaceOrCarPicBaseDataLen = pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen;
                    }
                    else
                    {
                        if (pstUploadAIPic1400InfFaceNode->uiFaceOrCarPicBaseDataLen < pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen)
                        {
                            MOS_PRINTF("Face Free DataLen:%u Malloc DataLen:%u \r\n", pstUploadAIPic1400InfFaceNode->uiFaceOrCarPicBaseDataLen, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen);
                            MOS_FREE(pstUploadAIPic1400InfFaceNode->pucFaceOrCarPicBaseData);
                            pstUploadAIPic1400InfFaceNode->pucFaceOrCarPicBaseData   = MOS_NULL;
                            pstUploadAIPic1400InfFaceNode->pucFaceOrCarPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen * (4/3.0) + 8));
                            pstUploadAIPic1400InfFaceNode->uiFaceOrCarPicBaseDataLen = pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen;
                        }
                        else
                        {
                            MOS_PRINTF("Face NO Malloc \r\n");
                            MOS_MEMSET(pstUploadAIPic1400InfFaceNode->pucFaceOrCarPicBaseData, 0, (pstUploadAIPic1400InfFaceNode->uiFaceOrCarPicBaseDataLen * (4/3.0) + 8));
                        }
                    }
                    Adpt_Base64_Enc(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf , pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen ,pstUploadAIPic1400InfFaceNode->pucFaceOrCarPicBaseData);
                    // 图像数据 base64 字符串
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"Data",Adpt_Json_CreateString(pstUploadAIPic1400InfFaceNode->pucFaceOrCarPicBaseData));
#else
                    if (Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData == MOS_NULL)
                    {
                        MOS_PRINTF("Pic Face Malloc DataLen:%u \r\n", pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen);
                        Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen * (4/3.0) + 8));
                        Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen = pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen;
                    }
                    else
                    {
                        if (Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen < pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen)
                        {
                            MOS_PRINTF("Pic Face Free DataLen:%u Malloc DataLen:%u \r\n", Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen, pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen);
                            MOS_FREE(Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData);
                            Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData   = MOS_NULL;
                            Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen * (4/3.0) + 8));
                            Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen = pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen;
                        }
                        else
                        {
                            // MOS_PRINTF("Face NO Malloc \r\n");
                            MOS_MEMSET(Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData, 0, (Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen * (4/3.0) + 8));
                        }
                    }
                    Adpt_Base64_Enc(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf ,pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->uiPicLen, Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData);
                    // 图像数据 base64 字符串
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectFace,(_UC*)"Data",Adpt_Json_CreateString(Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData));
#endif
                    // 通知厂商清除AI图片数据缓存 ADD by LWJ
                    if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
                    {
                        iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->aucLabelID,
                                                                    pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf,
                                                                    pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pucBgJpgBuff);
                        if (MOS_OK == iRet)
                        {
                            // MOS_LOG_INF(GA1400_LOGSTR,"Device pFunFreeAiPicCache Face OK ");
                        }
                        else
                        {
                            MOS_LOG_ERR(GA1400_LOGSTR,"Device pFunFreeAiPicCache Face failed");
                        }
                    }
                    else
                    {
                        MOS_LOG_ERR(GA1400_LOGSTR,"Device pFunFreeAiPicCache Face is NULL!");
                    }
                    #if GA1400_UPLOAD_PIC_DEBUG
                    if (pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf)
                    {
                        free(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf);
                        // MOS_LOG_INF(GA1400_LOGSTR,"free face pic OK ");
                    }
                    if (pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pucBgJpgBuff)
                    {
                        free(pstUploadAIPic1400InfFaceNode->stAiPicEventInfo.pucBgJpgBuff);
                        // MOS_LOG_INF(GA1400_LOGSTR,"free bg pic OK ");
                    }
                    #endif

                    Config_SetUploadAIPic1400TaskNodeUploadFlag(0, pstUploadAIPic1400InfFaceNode->uiReqId, 2);
                }
                else
                {
                    MOS_VSNPRINTF(aucImageIDPic, sizeof(aucImageIDPic), "FACE AiPicHead is Null");
                    MOS_LOG_ERR(GA1400_LOGSTR, aucImageIDPic);
                    CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), GA1400_UPLOADPIC_FACE_URL, -1, EN_GA1400_RT_UPLOADPIC_ERR, aucImageIDPic, MOS_NULL, 1);
                }
            }
        }

        pStrTmp = Adpt_Json_Print(hRoot);
        _UI uiStrTmpLen = MOS_STRLEN(pStrTmp);
        MOS_LOG_INF(GA1400_LOGSTR, "AIPIC 1400 INPUT FACE DataLen:%u  AiAlarmCount:%d ImageID:%s", uiStrTmpLen, iAiAlarmCount, aucImageIDPic);
        // MOS_PRINTF("AIPIC 1400 INPUT FACE Data:%s \r\n", pStrTmp);
        // MOS_PRINTF("AIPIC 1400 INPUT FACE StrTmpLen:%u  AiAlarmCount:%d \r\n", uiStrTmpLen, iAiAlarmCount);

        Adpt_Json_Delete(hRoot);

        // 删除人脸节点
        Ga1400_DelFaceListNode(pstUploadAIPic1400InfNode->uiAIIoTType, pstUploadAIPic1400InfNode->uiEventId);
        return pStrTmp;
    }
    else if (EN_1400_PIC_TYPE_CARNUM == enPicType)     // 车牌抓拍
    {
        _UC aucMotorVehicleID[64]              = {0};
        JSON_HANDLE hMotorVehicleListObject   = MOS_NULL;
        JSON_HANDLE hMotorVehicleObject       = MOS_NULL;
        JSON_HANDLE hMotorVehicleObjectArray  = MOS_NULL;
        JSON_HANDLE hSubImageInfoObjectCar    = MOS_NULL;
        ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfCarNode = MOS_NULL;

        hRoot = Adpt_Json_CreateObject();
        // 机动车对象列表
        hMotorVehicleListObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot, (_UC*)"MotorVehicleListObject", hMotorVehicleListObject);
        // 机动车对象信息
        hMotorVehicleObjectArray = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hMotorVehicleListObject, (_UC*)"MotorVehicleObject", hMotorVehicleObjectArray);

        // 查找要上传图片到1400平台的节点
        FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfCarNode, stIterator)
        {
            if ((1 == pstUploadAIPic1400InfCarNode->uiUseFlag) \
                && (1 == pstUploadAIPic1400InfCarNode->uiUploadFlag) \
                && (pstUploadAIPic1400InfCarNode->uiAIIoTType == pstUploadAIPic1400InfNode->uiAIIoTType) \
                && (pstUploadAIPic1400InfCarNode->uiEventId == pstUploadAIPic1400InfNode->uiEventId))
            {
                // MOS_LOG_INF(GA1400_LOGSTR, "Find Upload Pic 1400 Car Node Id:%u", pstUploadAIPic1400InfCarNode->uiReqId);
                iAiAlarmCount++;
                if (pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead)
                {
                    hMotorVehicleObject = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToArray(hMotorVehicleObjectArray, hMotorVehicleObject);

                    Mos_TimetoSysTime(&pstUploadAIPic1400InfCarNode->cAlarmTime,&stSysTime);
                    // Mos_GetSysTime(&stSysTime); 
                    MOS_VSNPRINTF(aucHappenTime,     sizeof(aucHappenTime), "%04u%02u%02u%02u%02u%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond); 
                    MOS_VSNPRINTF(aucSourceID,       sizeof(aucSourceID),   "%s02%s%05d", Config_GetCamaraMng()->ucGAT1400ID, aucHappenTime, iAiPicCount);
                    MOS_VSNPRINTF(aucImageIDBg,      sizeof(aucImageIDBg),  "%s02%s%05d", Config_GetCamaraMng()->ucGAT1400ID, aucHappenTime, iAiPicCount);
                    iAiPicCount++;
                    MOS_VSNPRINTF(aucMotorVehicleID, sizeof(aucMotorVehicleID), "%s02%05d",   aucSourceID, iAiPicCount);
                    MOS_VSNPRINTF(aucImageIDPic,     sizeof(aucImageIDPic),     "%s02%s%05d", Config_GetCamaraMng()->ucGAT1400ID, aucHappenTime, iAiPicCount);
                    iAiPicCount++;
                    // 机动车标识
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"MotorVehicleID",Adpt_Json_CreateString(aucMotorVehicleID));
                    // 信息分类 自动采集:1 人工采集:2 其他：0
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"InfoKind",Adpt_Json_CreateNumber(1));
                    // 来源标识
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"SourceID",Adpt_Json_CreateString(aucSourceID));
                    // 设备编码(GA1400ID)
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"DeviceID",Adpt_Json_CreateString(Config_GetCamaraMng()->ucGAT1400ID));
                    // 近景照片
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"StorageUrl1",Adpt_Json_CreateString((_UC *)""));
                    // 车辆出现时间
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"AppearTime",Adpt_Json_CreateString(aucHappenTime));
                    // 车辆消失时间
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"DisAppearTime",Adpt_Json_CreateString(aucHappenTime));
                    // 位置标记时间
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"MarkTime",Adpt_Json_CreateString(aucHappenTime));
                    // 经过时间
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"PassTime",Adpt_Json_CreateString(aucHappenTime));
                    // 左上角X坐标
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"LeftTopX",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiLeftTopX));
                    // 左上角Y坐标
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"LeftTopY",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiLeftTopY));
                    // 右下角X坐标
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"RightBtmX",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiRightBtmX));
                    // 右下角Y坐标
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"RightBtmY",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiRightBtmY));
                    // 有无车牌
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"HasPlate",Adpt_Json_CreateNumber(1));
                    // 车牌号
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"PlateNo",Adpt_Json_CreateString(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->aucCarNum));
                    #if 0  // 修改为由厂商按需求透传
                    // 车速
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"Speed",Adpt_Json_CreateNumber(0));
                    // 号牌种类
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"PlateClass",Adpt_Json_CreateNumber(2));  // 必选字段
                    // 车牌颜色 ColorType string(2) 1：黑  2:白  5:蓝  6：黄  9：绿  99:其他
                    // Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"PlateColor",Adpt_Json_CreateNumber(5)); // 必选字段
                    // 车辆类型
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"VehicleClass",Adpt_Json_CreateString((_UC *)""));
                    // 车辆品牌 VehicleBrandType string(3)
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"VehicleBrand",Adpt_Json_CreateStrWithNum(0));
                    // 车辆型号
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"VehicleModel",Adpt_Json_CreateString((_UC *)""));
                    // 车辆颜色 ColorType string(2)
                    Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"VehicleColor",Adpt_Json_CreateStrWithNum(99)); // 必选字段
                    #endif

                    // 对于必选字段, 厂家没有透传时, SDK需要加上该字段
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucEventExpandDes, "\"PlateClass\""))
                    {
                        // 号牌种类
                        Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"PlateClass",Adpt_Json_CreateNumber(2));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucEventExpandDes, "\"PlateColor\""))
                    {
                        // 车牌颜色 ColorType string(2) 1：黑  2:白  5:蓝  6：黄  9：绿  99:其他
                        Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"PlateColor",Adpt_Json_CreateNumber(5));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucEventExpandDes, "\"VehicleColor\""))
                    {
                        // 车辆颜色 ColorType string(2)
                        Adpt_Json_AddItemToObject(hMotorVehicleObject,(_UC*)"VehicleColor",Adpt_Json_CreateStrWithNum(99));
                    }

                    // 厂商透传字段
                    Ga1400_JsonAddExpandField(hMotorVehicleObject, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucEventExpandDes);
                    // 图像对象列表
                    hSubImageList = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToObject(hMotorVehicleObject, (_UC*)"SubImageList", hSubImageList);
                    // 图像对象信息
                    hSubImageInfoArray = Adpt_Json_CreateArray();
                    Adpt_Json_AddItemToObject(hSubImageList, (_UC*)"SubImageInfoObject", hSubImageInfoArray);
                    // 背景图信息
                    hSubImageInfoObjectBg = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToArray(hSubImageInfoArray, hSubImageInfoObjectBg);
                    // 设备编码(GA1400ID)
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"DeviceID",Adpt_Json_CreateString(Config_GetCamaraMng()->ucGAT1400ID));
                    // 图像标识
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ImageID",Adpt_Json_CreateString(aucImageIDBg));
                    // MOS_PRINTF("GAAAAAAAA: Car   ImageID:%s  \r\n", aucImageIDBg);
                    // 信息分类 自动采集:1 人工采集:2 其他：0
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"InfoKind",Adpt_Json_CreateNumber(1));
                    // 图像来源 99:其他
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ImageSource",Adpt_Json_CreateStrWithNum(99));
                    // 图像分析处理事件类型 人脸检测：10  人脸比对：11  车辆检测：12  车辆比对：13  车牌识别：16
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"EventSort",Adpt_Json_CreateNumber(16));
                    // 图像文件格式
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"FileFormat",Adpt_Json_CreateString((_UC *)"Jpeg"));
                    // 抓拍时间
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ShotTime",Adpt_Json_CreateString(aucHappenTime));
                    #if 0  // 修改为由厂商按需求透传
                    // 图像图片存储路径 采用 URI 命名规则
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"StoragePath",Adpt_Json_CreateString((_UC *)""));
                    // 题名
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Title",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 内容描述
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ContentDescription",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 拍摄地点区划内详细地址
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ShotPlaceFullAdress",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 密级代码 自动采集时取值为5(公开)
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"SecurityLevel",Adpt_Json_CreateStrWithNum(5)); // 必选字段
                    #endif

                    // 对于必选字段, 厂家没有透传时, SDK需要加上该字段
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucBgPicExpandDes, "\"Title\""))
                    {
                        // 题名
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Title",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucBgPicExpandDes, "\"ContentDescription\""))
                    {
                        // 内容描述
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ContentDescription",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucBgPicExpandDes, "\"ShotPlaceFullAdress\""))
                    {
                        // 拍摄地点区划内详细地址
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"ShotPlaceFullAdress",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucBgPicExpandDes, "\"SecurityLevel\""))
                    {
                        // 密级代码 自动采集时取值为5(公开)
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"SecurityLevel",Adpt_Json_CreateStrWithNum(5));
                    }

                    // 图像类型 场景图：14    人脸图：11   车辆图：09
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Type",Adpt_Json_CreateStrWithNum(14));
                    // 图像宽
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Width",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.dBgWidth));
                    // 图像高
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Height",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.dBgHeight));
                    // 图片大小
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"FileSize",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen));

                    // 事件背景图厂商透传字段
                    Ga1400_JsonAddExpandField(hSubImageInfoObjectBg, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.aucBgPicExpandDes);

#if GA1400_BASEDATA_USE_NODE
                    if (pstUploadAIPic1400InfCarNode->pucBgPicBaseData == MOS_NULL)
                    {
                        // MOS_PRINTF("BG Car Malloc DataLen:%u", pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen);
                        pstUploadAIPic1400InfCarNode->pucBgPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen * (4/3.0) + 8));
                        pstUploadAIPic1400InfCarNode->uiBgPicBaseDataLen = pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen;
                    }
                    else
                    {
                        if (pstUploadAIPic1400InfCarNode->uiBgPicBaseDataLen < pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen)
                        {
                            // MOS_PRINTF("BG Car Free DataLen:%u Malloc DataLen:%u", pstUploadAIPic1400InfCarNode->uiBgPicBaseDataLen, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen);
                            MOS_FREE(pstUploadAIPic1400InfCarNode->pucBgPicBaseData);
                            pstUploadAIPic1400InfCarNode->pucBgPicBaseData   = MOS_NULL;
                            pstUploadAIPic1400InfCarNode->pucBgPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen * (4/3.0) + 8));
                            pstUploadAIPic1400InfCarNode->uiBgPicBaseDataLen = pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen;
                        }
                        else
                        {
                            MOS_MEMSET(pstUploadAIPic1400InfCarNode->pucBgPicBaseData, 0, ((float)pstUploadAIPic1400InfCarNode->uiBgPicBaseDataLen * (4/3.0) + 8));
                        }
                    }
                    Adpt_Base64_Enc(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pucBgJpgBuff, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen, pstUploadAIPic1400InfCarNode->pucBgPicBaseData);
                    // 图像数据 base64 字符串
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Data",Adpt_Json_CreateString(pstUploadAIPic1400InfCarNode->pucBgPicBaseData));
#else
                    if (Ga1400_GetTaskMng()->pucBgPicBaseData == MOS_NULL)
                    {
                        // MOS_PRINTF("BG Car Malloc DataLen:%u", pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen);
                        Ga1400_GetTaskMng()->pucBgPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen * (4/3.0) + 8));
                        Ga1400_GetTaskMng()->uiBgPicBaseDataLen = pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen;
                    }
                    else
                    {
                        if (Ga1400_GetTaskMng()->uiBgPicBaseDataLen < pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen)
                        {
                            // MOS_PRINTF("BG Car Free DataLen:%u Malloc DataLen:%u", Ga1400_GetTaskMng()->uiBgPicBaseDataLen, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen);
                            MOS_FREE(Ga1400_GetTaskMng()->pucBgPicBaseData);
                            Ga1400_GetTaskMng()->pucBgPicBaseData   = MOS_NULL;
                            Ga1400_GetTaskMng()->pucBgPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen * (4/3.0) + 8));
                            Ga1400_GetTaskMng()->uiBgPicBaseDataLen = pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen;
                        }
                        else
                        {
                            MOS_MEMSET(Ga1400_GetTaskMng()->pucBgPicBaseData, 0, ((float)Ga1400_GetTaskMng()->uiBgPicBaseDataLen * (4/3.0) + 8));
                        }
                    }
                    Adpt_Base64_Enc(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pucBgJpgBuff, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.uiBgJpgLen, Ga1400_GetTaskMng()->pucBgPicBaseData);
                    // 图像数据 base64 字符串
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectBg,(_UC*)"Data",Adpt_Json_CreateString(Ga1400_GetTaskMng()->pucBgPicBaseData));
#endif
                    // 车牌图信息
                    hSubImageInfoObjectCar = Adpt_Json_CreateObject();
                    Adpt_Json_AddItemToArray(hSubImageInfoArray, hSubImageInfoObjectCar);
                    // 设备编码(GA1400ID)
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"DeviceID",Adpt_Json_CreateString(Config_GetCamaraMng()->ucGAT1400ID));
                    // 图像标识
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"ImageID",Adpt_Json_CreateString(aucImageIDPic));
                    // MOS_PRINTF("GAAAAAAAA: Car   ImageID:%s  \r\n", aucImageIDPic);
                    // 信息分类 自动采集:1 人工采集:2 其他：0
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"InfoKind",Adpt_Json_CreateNumber(1));
                    // 图像来源 99:其他
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"ImageSource",Adpt_Json_CreateStrWithNum(99));
                    // 图像分析处理事件类型  人脸检测：10  人脸比对：11  车辆检测：12  车辆比对：13  车牌识别：16
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"EventSort",Adpt_Json_CreateNumber(16));
                    // 图像文件格式
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"FileFormat",Adpt_Json_CreateString((_UC *)"Jpeg"));
                    // 抓拍时间
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"ShotTime",Adpt_Json_CreateString(aucHappenTime));
                    #if 0  // 修改为由厂商按需求透传
                    // 图像图片存储路径 采用 URI 命名规则
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"StoragePath",Adpt_Json_CreateString((_UC *)""));
                    // 题名
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"Title",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 内容描述
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"ContentDescription",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 拍摄地点区划内详细地址
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"ShotPlaceFullAdress",Adpt_Json_CreateString((_UC *)"")); // 必选字段
                    // 密级代码 自动采集时取值为5(公开)
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"SecurityLevel",Adpt_Json_CreateStrWithNum(5));  // 必选字段
                    #endif

                    // 对于必选字段, 厂家没有透传时, SDK需要加上该字段
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, "\"Title\""))
                    {
                        // 题名
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"Title",Adpt_Json_CreateString((_UC *)""));   
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, "\"ContentDescription\""))
                    {
                        // 内容描述
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"ContentDescription",Adpt_Json_CreateString((_UC *)""));
                    }
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, "\"ShotPlaceFullAdress\""))
                    {
                        // 拍摄地点区划内详细地址
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"ShotPlaceFullAdress",Adpt_Json_CreateString((_UC *)""));
                    }  
                    if (MOS_NULL == MOS_STRSTR(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes, "\"SecurityLevel\""))
                    {
                        // 密级代码 自动采集时取值为5(公开)
                        Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"SecurityLevel",Adpt_Json_CreateStrWithNum(5));
                    }

                    // 图像类型   场景图：14  人脸图：11  车辆图：09
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"Type",Adpt_Json_CreateStrWithNum(9));
                    // 图像宽
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"Width",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->dWidth));
                    // 图像高
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"Height",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->dHeight));
                    // 图片大小
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"FileSize",Adpt_Json_CreateNumber(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen));

                    // 事件车牌抓拍图厂商透传字段
                    Ga1400_JsonAddExpandField(hSubImageInfoObjectCar, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->aucPicExpandDes);

#if GA1400_BASEDATA_USE_NODE
                    if (pstUploadAIPic1400InfCarNode->pucFaceOrCarPicBaseData == MOS_NULL)
                    {
                        // MOS_PRINTF("Pic Car Malloc DataLen:%u", pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen);
                        pstUploadAIPic1400InfCarNode->pucFaceOrCarPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen * (4/3.0) + 8));
                        pstUploadAIPic1400InfCarNode->uiFaceOrCarPicBaseDataLen = pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen;
                    }
                    else
                    {
                        if (pstUploadAIPic1400InfCarNode->uiFaceOrCarPicBaseDataLen < pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen)
                        {
                            // MOS_PRINTF("Pic Car Free DataLen:%u Malloc DataLen:%u", pstUploadAIPic1400InfCarNode->uiFaceOrCarPicBaseDataLen, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen);
                            MOS_FREE(pstUploadAIPic1400InfCarNode->pucFaceOrCarPicBaseData);
                            pstUploadAIPic1400InfCarNode->pucFaceOrCarPicBaseData   = MOS_NULL;
                            pstUploadAIPic1400InfCarNode->pucFaceOrCarPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen * (4/3.0) + 8));
                            pstUploadAIPic1400InfCarNode->uiFaceOrCarPicBaseDataLen = pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen;
                        }
                        else
                        {
                            MOS_MEMSET(pstUploadAIPic1400InfCarNode->pucFaceOrCarPicBaseData, 0, ((float)pstUploadAIPic1400InfCarNode->uiFaceOrCarPicBaseDataLen * (4/3.0) + 8));
                        }
                    }
                    Adpt_Base64_Enc(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf , pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen ,pstUploadAIPic1400InfCarNode->pucFaceOrCarPicBaseData);
                    // 图像数据 base64 字符串
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"Data",Adpt_Json_CreateString(pstUploadAIPic1400InfCarNode->pucFaceOrCarPicBaseData));
#else
                    if (Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData == MOS_NULL)
                    {
                        // MOS_PRINTF("Car Malloc DataLen:%u", pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen);
                        Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen * (4/3.0) + 8));
                        Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen = pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen;
                    }
                    else
                    {
                        if (Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen < pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen)
                        {
                            // MOS_PRINTF("Car Free DataLen:%u Malloc DataLen:%u", Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen, pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen);
                            MOS_FREE(Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData);
                            Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData   = MOS_NULL;
                            Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData   = (_UC*)MOS_MALLOCCLR((_UI)((float)pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen * (4/3.0) + 8));
                            Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen = pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen;
                        }
                        else
                        {
                            MOS_MEMSET(Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData, 0, ((float)Ga1400_GetTaskMng()->uiFaceOrCarPicBaseDataLen * (4/3.0) + 8));
                        }
                    }
                    Adpt_Base64_Enc(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf , pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->uiPicLen ,Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData);
                    // 图像数据 base64 字符串
                    Adpt_Json_AddItemToObject(hSubImageInfoObjectCar,(_UC*)"Data",Adpt_Json_CreateString(Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData));
#endif
                    // 通知厂商清除AI图片数据缓存 ADD by LWJ
                    if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
                    {
                        iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->aucLabelID,
                                                                    pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf,
                                                                    pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pucBgJpgBuff);
                        if (MOS_OK == iRet)
                        {
                            // MOS_LOG_INF(GA1400_LOGSTR,"Device pFunFreeAiPicCache Car OK ");
                        }
                        else
                        {
                            MOS_LOG_ERR(GA1400_LOGSTR,"Device pFunFreeAiPicCache Car failed");
                        }
                    }
                    else
                    {
                        MOS_LOG_ERR(GA1400_LOGSTR,"Device pFunFreeAiPicCache Car is NULL!");
                    }
                    #if GA1400_UPLOAD_PIC_DEBUG
                    if (pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf)
                    {
                        free(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf);
                        // MOS_LOG_INF(GA1400_LOGSTR,"free face pic OK ");
                    }
                    if (pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pucBgJpgBuff)
                    {
                        free(pstUploadAIPic1400InfCarNode->stAiPicEventInfo.pucBgJpgBuff);
                        // MOS_LOG_INF(GA1400_LOGSTR,"free bg pic OK ");
                    }
                    #endif
                    Config_SetUploadAIPic1400TaskNodeUploadFlag(0, pstUploadAIPic1400InfCarNode->uiReqId, 2);
                }
                else
                {
                    MOS_VSNPRINTF(aucImageIDPic, sizeof(aucImageIDPic), "CAR AiPicHead is Null");
                    MOS_LOG_ERR(GA1400_LOGSTR, aucImageIDPic);
                    CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), GA1400_UPLOADPIC_CAR_URL, -1, EN_GA1400_RT_UPLOADPIC_ERR, aucImageIDPic, MOS_NULL, 1);
                }
            }
        }

        pStrTmp = Adpt_Json_Print(hRoot);
        _UI uiStrTmpLen = MOS_STRLEN(pStrTmp);
        MOS_LOG_INF(GA1400_LOGSTR, "AIPIC 1400 INPUT CAR DataLen:%u  AiAlarmCount:%d  ImageID:%s", uiStrTmpLen, iAiAlarmCount, aucImageIDPic);
        // MOS_PRINTF("AIPIC 1400 INPUT CAR Data:%s \r\n", pStrTmp);
        // MOS_PRINTF("AIPIC 1400 INPUT CAR StrTmpLen:%u  AiAlarmCount:%d \r\n", uiStrTmpLen, iAiAlarmCount);

        Adpt_Json_Delete(hRoot);

        // 删除车牌节点
        Ga1400_DelCarListNode(pstUploadAIPic1400InfNode->uiAIIoTType, pstUploadAIPic1400InfNode->uiEventId);
        return pStrTmp;
    }
    else 
    {
        MOS_VSNPRINTF(aucImageIDPic, sizeof(aucImageIDPic), "AIIoTType:%u EventId:%u error", pstUploadAIPic1400InfNode->uiAIIoTType, pstUploadAIPic1400InfNode->uiEventId);
        MOS_LOG_ERR(GA1400_LOGSTR, aucImageIDPic);
        CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), GA1400_UPLOADPIC_FACE_URL, -1, EN_GA1400_RT_UPLOADPIC_ERR, aucImageIDPic, MOS_NULL, 1);
        return MOS_NULL;
    }

    return pStrTmp;
}

static _VOID Ga1400_UploadPicRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    if(Ga1400_GetHttpTask()->usUploadPicBuffLen == 0)
    {
        Ga1400_GetHttpTask()->usUploadPicBuffLen   = HTTP_RECVBUF_SIZE;
        Ga1400_GetHttpTask()->pucHttpUploadPicBuff = (_UC*)MOS_MALLOC(Ga1400_GetHttpTask()->usUploadPicBuffLen);
    }
    if(Ga1400_GetHttpTask()->usUploadPicRecvLen + uiLen < Ga1400_GetHttpTask()->usUploadPicBuffLen)
    {
        MOS_MEMCPY(Ga1400_GetHttpTask()->pucHttpUploadPicBuff + Ga1400_GetHttpTask()->usUploadPicRecvLen, pucData, uiLen);
        Ga1400_GetHttpTask()->usUploadPicRecvLen += uiLen;
    }
}

static _VOID Ga1400_UploadPicFinished(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    _UI iStatusCode = -1;
    _UC aucStrErrLog[128] = {0};
    if (Ga1400_GetHttpTask()->pucHttpUploadPicBuff)
    {
        Ga1400_GetHttpTask()->pucHttpUploadPicBuff[Ga1400_GetHttpTask()->usUploadPicRecvLen ] = 0;
    }
    JSON_HANDLE hJsonRoot = Adpt_Json_Parse(Ga1400_GetHttpTask()->pucHttpUploadPicBuff);
    if (hJsonRoot)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"StatusCode"), &iStatusCode);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post Upload 1400 Pic StatusCode is %d", iStatusCode);
        if (iStatusCode == 0)
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_UPLOAD_PIC_SUCCESS, aucStrErrLog, MOS_NULL, 1); 
        }
        else
        {
            CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_UPLOAD_PIC_URL_RT_STATUSCODE_NOT_0_ERR, aucStrErrLog, MOS_NULL, 1); 
        }
        Adpt_Json_Delete(hJsonRoot);
    }
    else
    {
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post 1400 Upload 1400 Pic Json is Null");
        CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, -1, 
                                EN_1400_RT_UPLOAD_PIC_URL_RT_JSON_NULL_ERR, aucStrErrLog, MOS_NULL, 1);
    }
    /*清除http缓存*/                           
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpUploadPicBuff);
    Ga1400_GetHttpTask()->usUploadPicRecvLen     = 0;
    Ga1400_GetHttpTask()->usUploadPicBuffLen     = 0;
}

static _VOID Ga1400_UploadPicFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC aucStrErrLog[128] = {0};
    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post Upload 1400 Pic http code %u", uiErrCode);
    CloudStg_UploadLogEx2(GA1400_LOGSTR, uiReqId, __FUNCTION__, 0, EN_1400_RT_UPLOAD_PIC_URL_RT_NOT_200_ERR, aucStrErrLog, MOS_NULL, 1); 
    /*清除http缓存*/                           
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpUploadPicBuff);
    Ga1400_GetHttpTask()->usUploadPicRecvLen     = 0;
    Ga1400_GetHttpTask()->usUploadPicBuffLen     = 0;
}

static _INT Ga1400_UploadPicGetData(_VPTR vpUserPtr, _UC* pucData, _UI uiMaxDataLen, _UI uiReqId)
{
    _UI uiDataLen   = MOS_STRLEN(Ga1400_GetHttpTask()->pucHttpsPostData);
    _UI uiUploadLen = ((uiDataLen - Ga1400_GetHttpTask()->uiUploadPicindex) > uiMaxDataLen) ? uiMaxDataLen : (uiDataLen - Ga1400_GetHttpTask()->uiUploadPicindex);

    if (uiUploadLen > 0)
    {
        MOS_MEMCPY(pucData, Ga1400_GetHttpTask()->pucHttpsPostData + Ga1400_GetHttpTask()->uiUploadPicindex, uiUploadLen);
        Ga1400_GetHttpTask()->uiUploadPicindex += uiUploadLen;
        return uiUploadLen;
    }
    return 0;
}

// 上传图片到1400平台
_INT Ga1400_UploadAIPicTo1400Plat(ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode, struct kj_timer_t* ptGa1400FeedDogTimeOut, _HSWDWRITE hSwdGa1400FeedDog)
{
    MOS_PRINTF("%s:%d: Start \r\n", __FUNCTION__, __LINE__);
    _INT iRet        = MOS_ERR;
    _UC *pStrStart   = MOS_NULL;
    _UC *pStrEnd     = MOS_NULL;
    _UC  aucAdmonAddr[64]         = {0};
    _UC  aucStrErrLog[128]        = {0};
    _UC  aucUploadPicFileUrl[128] = {0};
    _INT iUploadFailTime          =  0;
    _UC  aucUploadPicHeadEx[128]  = {0};

    // 图片类型
    if (EN_ZJ_AIIOT_TYPE_FACE_CAPTURE == pstUploadAIPic1400InfNode->uiAIIoTType)// 新人脸抓拍
    {
        MOS_MEMCPY(aucUploadPicFileUrl, GA1400_UPLOADPIC_FACE_URL, MOS_STRLEN(GA1400_UPLOADPIC_FACE_URL));
    }
    else if (EN_ZJ_AIIOT_TYPE_MOTION == pstUploadAIPic1400InfNode->uiAIIoTType)
    {
        if (EN_ZJ_MOTION_EVENT_FACE == pstUploadAIPic1400InfNode->uiEventId)// 旧人脸抓拍
        {
            MOS_MEMCPY(aucUploadPicFileUrl, GA1400_UPLOADPIC_FACE_URL, MOS_STRLEN(GA1400_UPLOADPIC_FACE_URL));
        }
        else if (EN_ZJ_MOTION_EVENT_CARNUM_DISCERN == pstUploadAIPic1400InfNode->uiEventId)// 车牌抓拍
        {
            MOS_MEMCPY(aucUploadPicFileUrl, GA1400_UPLOADPIC_CAR_URL, MOS_STRLEN(GA1400_UPLOADPIC_CAR_URL));
        }
        else
        {
            MOS_LOG_ERR(GA1400_LOGSTR, "AIIoTType:%u EventId:%u error", pstUploadAIPic1400InfNode->uiAIIoTType, pstUploadAIPic1400InfNode->uiEventId);
            return MOS_ERR;
        }
    }
    else
    {
        MOS_LOG_ERR(GA1400_LOGSTR, "AIIoTType:%u EventId:%u error", pstUploadAIPic1400InfNode->uiAIIoTType, pstUploadAIPic1400InfNode->uiEventId);
        return MOS_ERR;
    }

    #if GA1400_SUPPORTFACTORYTRANS
    _INT iIsSupportFactoryTrans = 1;
    MOS_VSNPRINTF(aucUploadPicHeadEx, sizeof(aucUploadPicHeadEx), "isSupportFactoryTrans: %d\r\nUser-Identify: %s\r\n", iIsSupportFactoryTrans, Config_GetCamaraMng()->ucGAT1400ID);
    #else
    MOS_VSNPRINTF(aucUploadPicHeadEx, sizeof(aucUploadPicHeadEx), "User-Identify: %s\r\n", Config_GetCamaraMng()->ucGAT1400ID);
    #endif
    MOS_LOG_INF(GA1400_LOGSTR, "Upload AIPic 1400 UploadPicHeadEx:%s", aucUploadPicHeadEx);

    pStrStart  = MOS_STRSTR(Config_GetCamaraMng()->ucGAT1400Domain, "//");
    pStrStart += MOS_STRLEN("//");
    pStrEnd    = MOS_STRSTR(pStrStart, "/");
    MOS_MEMCPY(aucAdmonAddr, pStrStart, pStrEnd-pStrStart);

    Ga1400_SetTaskUploadPicFlag(1);
    Ga1400_GetHttpTask()->pucHttpsPostData = Ga1400_BuildUploadAIPicTo1400Json(pstUploadAIPic1400InfNode);
    Ga1400_SetTaskUploadPicFlag(0);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.pfuncRecv        = Ga1400_UploadPicRecvFunc;
    stHttpInfoNode.pfuncFinished    = Ga1400_UploadPicFinished;
    stHttpInfoNode.pfuncFailed      = Ga1400_UploadPicFailed;
    stHttpInfoNode.pfuncGetData     = Ga1400_UploadPicGetData;
    stHttpInfoNode.pucExpandHeader  = aucUploadPicHeadEx;
    stHttpInfoNode.uiContentLen     = MOS_STRLEN(Ga1400_GetHttpTask()->pucHttpsPostData);
    stHttpInfoNode.iTimeOut         = 120;// 上传文件超时120秒
    
    while(1)
    {
        // 重试期间, 软件看门狗喂狗 间隔：3S
        if (getDiffTimems(ptGa1400FeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= GA1400_LOOP_FEEDDOG_TIME)
        {
            Swd_AppThreadFeedDog(hSwdGa1400FeedDog);
            getDiffTimems(ptGa1400FeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }

        if (iUploadFailTime >= GA1400_UPLOADPIC_FAIL_RETRY_TIMES)
        {
            MOS_LOG_ERR(GA1400_LOGSTR, "Upload AIPic 1400 ERR");
            break;
        }
        
        Ga1400_GetHttpTask()->uiUploadPicindex = 0;
        iRet = Http_SendSyncRequest(&stHttpInfoNode, aucAdmonAddr, aucUploadPicFileUrl, EN_HTTP_METHOD_POST, Mos_GetSessionId());
        if (iRet == MOS_OK)
        {
            iUploadFailTime = 0;
            break;
        }
        else
        {
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Https Post Upload Pic FAIL retryTime %d", iUploadFailTime);
            CloudStg_UploadLogEx2(GA1400_LOGSTR, 0, __FUNCTION__, 0, EN_GA1400_RT_UPLOADPIC_ERR, aucStrErrLog, MOS_NULL, 1); 
            iUploadFailTime++;
            Mos_Sleep(50);
            continue;
        }
    }
    MOS_FREE(Ga1400_GetHttpTask()->pucHttpsPostData);
    
    if (iUploadFailTime < GA1400_UPLOADPIC_FAIL_RETRY_TIMES)
    {
        return MOS_OK;
    }
    else
    {
        iUploadFailTime = 0;
        return MOS_ERR;
    }
}

#if GA1400_UPLOAD_PIC_DEBUG
#include "zj_cameraiot.h"
_INT Ga1400_UploadPicTest()
{
    MOS_PRINTF("Ga1400_UploadTest: start");
    ST_ZJ_AIPIC_NODE       stAiPicHead      = {0};
    ST_ZJ_AIPIC_EVENT_INFO stAiPicEventInfo = {0};

    static _INT iUploadPicType = 0;

    _UI   uiTargetSizeBg = 0;
    FILE *hFileBg        = NULL;
    _UC  *pucPacDateBg   = NULL;
    _UC   aucFileNameBg[256]     = {0};
    _UC   aucFileNameCarBg[256]  = "/tmp/udisk0/3.jpg";
    _UC   aucFileNameFaceBg[256] = "/tmp/udisk0/1.jpg";
    if (iUploadPicType == 0) // car
    {
        MOS_STRNCPY(aucFileNameBg, aucFileNameCarBg, sizeof(aucFileNameBg));
    }
    else
    {
        MOS_STRNCPY(aucFileNameBg, aucFileNameFaceBg, sizeof(aucFileNameBg));
    }

    if (NULL == hFileBg)
    {
        hFileBg = fopen(aucFileNameBg, "r+");
        if (NULL == hFileBg)
        {
            MOS_PRINTF("fopen: %s failed", aucFileNameBg);
            return -1;
        }
        else
        {
            struct   stat   buf = {0}; 
            stat(aucFileNameBg, &buf);
            uiTargetSizeBg = buf.st_size;
            MOS_PRINTF("Bg uiTargetSizeBg:%u \r\n", uiTargetSizeBg);
            pucPacDateBg  = (_UC *)malloc(uiTargetSizeBg);
        }
    }

    if (hFileBg)
    {
        fseek(hFileBg, SEEK_SET, 0);
        fread(pucPacDateBg, uiTargetSizeBg, 1, hFileBg);
        fclose(hFileBg);
        hFileBg = NULL;
    }

    stAiPicEventInfo.pucBgJpgBuff = pucPacDateBg;
    stAiPicEventInfo.uiBgJpgLen   = uiTargetSizeBg;

    _UI   uiTargetSize = 0;
    FILE *hFile        = NULL;
    _UC  *pucPacDate   = NULL;

    _UC   aucFileName[256]     = {0};
    _UC   aucFileNameCar[256]  = "/tmp/udisk0/4.jpg";
    _UC   aucFileNameFace[256] = "/tmp/udisk0/2.jpg";

    if (iUploadPicType == 0)  // car
    {
        MOS_STRNCPY(aucFileName, aucFileNameCar, sizeof(aucFileName));
    }
    else
    {
        MOS_STRNCPY(aucFileName, aucFileNameFace, sizeof(aucFileName));
    }

    if (NULL == hFile)
    {
        hFile = fopen(aucFileName, "r+");
        if (NULL == hFile)
        {
            MOS_PRINTF("fopen: %s failed", aucFileName);
            return -1;
        }
        else
        {
            struct   stat   buf = {0}; 
            stat(aucFileName, &buf);
            uiTargetSize = buf.st_size;
            MOS_PRINTF("PIC uiTargetSize:%u \r\n", uiTargetSize);
            pucPacDate  = (_UC *)malloc(uiTargetSize);
        }
    }

    if (hFile)
    {
        fseek(hFile, SEEK_SET, 0);
        fread(pucPacDate, uiTargetSize, 1, hFile);
        fclose(hFile);
        hFile = NULL;
    }

    if (iUploadPicType == 0) // car
    {
        _UC ucCarNum[16] = "粤AA21CN";
        MOS_STRNCPY(stAiPicHead.aucCarNum, ucCarNum, sizeof(stAiPicHead.aucCarNum));
    }

    stAiPicHead.pucPicBuf       = pucPacDate;
    stAiPicHead.uiPicLen        = uiTargetSize;
    stAiPicHead.uiSimilarity    = 98;
    stAiPicHead.dWidth          = 320;
    stAiPicHead.dHeight         = 160;
    stAiPicHead.pstNextNode     = MOS_NULL;

    stAiPicEventInfo.pstAiPicHead = &stAiPicHead;

    if (&stAiPicEventInfo)
    {
        if (iUploadPicType == 0) // car
        {
            ZJ_SetAiPicEventEx2(1000, 0, 16, &stAiPicEventInfo);
            iUploadPicType = 1;
        }
        else
        {
            ZJ_SetAiPicEventEx2(1000, 0, 2, &stAiPicEventInfo);
            iUploadPicType = 0;
        }
    }
    else
    {
        MOS_PRINTF("stAiPicEventInfo: is null \r\n");
    }
    MOS_PRINTF("Ga1400_UploadTest: end \r\n");
    return MOS_OK;
}
#endif

// GA1400模块任务轮询 非内嵌1400
_INT Ga1400_Task_Loop(_VPTR pstArg)
{
    _INT iRet                    = MOS_ERR;
    _INT iStatus                 = MOS_ERR;
    _INT iLoopFlag               = 0;
    _CTIME_T ctime               = 0;
    _CTIME_T cOldTimeSwd         = 0;
    _UI  uiSubTime               = 0;
    _UI  uiGAT1400Switch         = 0;
    _UI  uiConnectFailTime       = 0;
    _UI  uiGa1400TaskGetInfoFlag = 0;
    _HSWDWRITE hSwdFeedDog = MOS_NULL;

     // 检测网络状态，通网才能继续
    do
    {
        if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET)
        {
            iLoopFlag++;
        }
        else if(Http_GetNetWorkType() != EN_ZJ_NETWORK_TYPE_AP)
        {
            break;
        }
        Mos_Sleep(1000);
    }while(iLoopFlag < 40);

    // 通知厂商设置GAT1400开关 ADD by LWJ
    if (ZJ_GetFuncTable()->pfunSetGa1400SwitchCb)
    {
        uiGAT1400Switch = Config_GetCamerGat1400Switch(0);
        iStatus = ZJ_GetFuncTable()->pfunSetGa1400SwitchCb(uiGAT1400Switch);
        if (MOS_OK == iStatus)
        {
            MOS_LOG_INF(GA1400_LOGSTR,"Device pfunSetGa1400SwitchCb OK");
        }
        else
        {
            MOS_LOG_ERR(GA1400_LOGSTR,"Device pfunSetGa1400SwitchCb failed");
        }
    }
    else
    {
        MOS_LOG_ERR(GA1400_LOGSTR,"pfunSetGa1400SwitchCb is NULL!");
    }

    MOS_LOG_INF(GA1400_LOGSTR, "Start  GAT1400Switch:%u  GAT1400ID:%s  GAT1400Domain:%s", 
                                uiGAT1400Switch, Config_GetCamaraMng()->ucGAT1400ID, Config_GetCamaraMng()->ucGAT1400Domain);

    hSwdFeedDog = Swd_AppThreadRegist(GA1400_APP, FEED_DOG_BIG_MAX_TIMESEC);

    while(Ga1400_GetTaskMng ()->ucRunFlag)
    {
        uiSubTime = MOS_ABS_NUM(Mos_Time() - ctime);
        uiGAT1400Switch   = Config_GetCamerGat1400Switch(0);
        uiConnectFailTime = Ga1400_GetTaskConnectFailTime();

        // 正常1小时查询一次  第一次失败1分钟后查询  第2次失败5分钟后查询 多于2次失败1小时后再查询
        if ((uiConnectFailTime == 0 && uiGAT1400Switch == 1 && uiSubTime >= GA1400_LOOP_GET_GA1400INFO_SUBTIME)     ||
            (uiConnectFailTime == 1 && uiGAT1400Switch == 1 && uiSubTime >= GA1400_LOOP_GET_GA1400INFO_FAILTIME1)   ||
            (uiConnectFailTime >= 2 && uiGAT1400Switch == 1 && uiSubTime >= GA1400_LOOP_GET_GA1400INFO_FAILTIME2)   )
        {
            Ga1400_SetTaskGetInfoFlag(EN_GA1400_GETINFO_NEED_NOW);
            MOS_LOG_INF(GA1400_LOGSTR, "Goto Get Ga1400 Info uiSubTime(%u)  ConnectFailTime:%u", uiSubTime, uiConnectFailTime);
        }

        if (Mos_MsgQueueGetCount(Ga1400_GetTaskMng()->hMsgQueue) > 0)
        {  
            ST_1400_STATUS_MSG *pst1400Msg = (ST_1400_STATUS_MSG *)Mos_MsgQueuePop(Ga1400_GetTaskMng()->hMsgQueue);

            if (pst1400Msg != NULL)
            {
                if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_ONLINESTATUS)
                {
                    if (pst1400Msg->uiOnlineStatus == EN_ZJ_DEVICE_STATUS_ONLINE && uiGAT1400Switch == 1)
                    {
                        Ga1400_SetTaskGetInfoFlag(EN_GA1400_GETINFO_NEED_NOW);
                        MOS_LOG_INF(GA1400_LOGSTR, "Device Online ! Get Ga1400 Info");
                    }
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_GETINFOFLAG)
                {
                    Ga1400_SetTaskGetInfoFlag(pst1400Msg->uiGetInfoFlag);
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_SETCONNECTFAILTIME)
                {
                    Ga1400_SetTaskConnectFailTime(pst1400Msg->uiConnectFailTime);
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_INCCONNECTFAILTIME)
                {
                    Ga1400_GetTaskMng()->uiConnectFailTime++;
                    if (Ga1400_GetTaskMng()->uiConnectFailTime >= 3)
                    {
                        Ga1400_GetTaskMng()->uiConnectFailTime = 0;
                    }
                }        
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_SETUNREGISTERFLAG)
                {
                    Ga1400_SetTaskUnRegisterFlag(pst1400Msg->uiUnRegisterFlag);
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_SETKEEPALIVEFLAG)
                {
                    Ga1400_SetTaskKeepAliveFlag(pst1400Msg->uiKeepAliveFlag);
                }
                MOS_FREE(pst1400Msg);
            }            
        }

        uiGa1400TaskGetInfoFlag = Ga1400_GetTaskGetInfoFlag();
        if (uiGa1400TaskGetInfoFlag == EN_GA1400_GETINFO_NEED_NOW)
        {
            iRet = GA1400_GetGa1400Info();
            
            // 成功解析DNS并插入HTTPS链表中
            if (MOS_OK == iRet)
            {
                ctime = Mos_Time();
                Ga1400_SetTaskGetInfoFlag(EN_GA1400_GETINFO_NEED_LOOP);
            }
        }

        if (MOS_ABS_NUM(Mos_Time() - cOldTimeSwd) >= 3)
        {
            cOldTimeSwd = Mos_Time();
            Swd_AppThreadFeedDog(hSwdFeedDog);
        }

        Mos_Sleep(5000);
    }

    Swd_AppThreadUnRegist(hSwdFeedDog);

    return MOS_OK;
}

// GA1400模块任务轮询
_INT Ga1400_Task_LoopEx(_VPTR pstArg)
{
    _INT iRet                       = MOS_ERR;
    _INT iLoopFlag                  = 0;
    _ULLID lluNowTime               = 0;
    _ULLID lluDuration              = 0;
    _UI  uiGAT1400Switch            = 0;
    _CTIME_T cKeepAliveTime         = 0;
    _CTIME_T cRegisterFailTime      = 0;
    _CTIME_T cGetGa1400InfoTime     = Mos_Time();
    _UI  uiConnectFailTime          = 0;
    _UI  uiKeepAliveFailTime        = 0;
    _UI  uiUnRegisterFailTime       = 0;
    _UI  uiGa1400UploadInterval     = 0;
    _UI  uiGetGa1400InfoSubTime     = 0;
    _UI  uiGa1400UploadPicSubTime   = 0;
    _UI  uiGa1400TaskGetInfoFlag    = EN_GA1400_GETINFO_NEED_LOOP;
    _UI  uiGa1400TaskRegisterFlag   = EN_GA1400_REGISTER_NONEED;
    _UI  uiGa1400TaskKeepAliveFlag  = EN_GA1400_KEEPALIVE_NONEED;
    _UI  uiGa1400TaskUnRegisterFlag = EN_GA1400_UNREGISTER_NONEED;
    _UI  uiGa1400UnRegisterEndFlag  = 0;
    _HSWDWRITE hSwdGa1400FeedDog    = MOS_NULL;
    kj_timer_t tGa1400FeedDogTimeOut;

     // 检测网络状态，通网才能继续
    do
    {
        if(Http_GetNetWorkType() == EN_ZJ_NETWORK_TYPE_NONET)
        {
            iLoopFlag++;
        }
        else if(Http_GetNetWorkType() != EN_ZJ_NETWORK_TYPE_AP)
        {
            break;
        }
        Mos_Sleep(1000);
    }while(iLoopFlag < 40);

    if ( MOS_STRLEN(Config_GetCamaraMng()->ucGAT1400ID)     > 0 &&
         MOS_STRLEN(Config_GetCamaraMng()->ucGAT1400Domain) > 0  )
    {
        // 设备启动后先把之前的注销
        Ga1400_SetTaskUnRegisterFlag(EN_GA1400_UNREGISTER_NEED);
    }

    uiGAT1400Switch = Config_GetCamerGat1400Switch(0);
    MOS_LOG_INF(GA1400_LOGSTR, "Start  GAT1400Switch:%u  GAT1400ID:%s  GAT1400Domain:%s", 
                                uiGAT1400Switch, Config_GetCamaraMng()->ucGAT1400ID, Config_GetCamaraMng()->ucGAT1400Domain);

    hSwdGa1400FeedDog = Swd_AppThreadRegist(GA1400_APP, FEED_DOG_SUPER_MAX_TIMESEC);
    kj_timer_init(&tGa1400FeedDogTimeOut);
    getDiffTimems(&tGa1400FeedDogTimeOut, 1, ENUM_SECONDS_TYPE_SECONDS, 60*10);

    while(Ga1400_GetTaskMng ()->ucRunFlag)
    {
        if (Mos_MsgQueueGetCount(Ga1400_GetTaskMng()->hMsgQueue) > 0)
        {  
            ST_1400_STATUS_MSG *pst1400Msg = (ST_1400_STATUS_MSG *)Mos_MsgQueuePop(Ga1400_GetTaskMng()->hMsgQueue);
            if (pst1400Msg != NULL)
            {
                if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_ONLINESTATUS)
                {
                    if (pst1400Msg->uiOnlineStatus == EN_ZJ_DEVICE_STATUS_ONLINE && uiGAT1400Switch == 1)
                    {
                        // 设备上线， 获取1400配置
                        Ga1400_SetTaskGetInfoFlag(EN_GA1400_GETINFO_NEED_NOW);
                        MOS_LOG_INF(GA1400_LOGSTR, "Device Online ! Get Ga1400 Info");
                    }
                    else if (pst1400Msg->uiOnlineStatus == EN_ZJ_DEVICE_STATUS_OFFLINE && uiGAT1400Switch == 1)
                    {
                        // 设备掉线，注销1400注册
                        if(Ga1400_GetTaskRegisterFlag() == EN_GA1400_REGISTER_SUCCESS)
                        {
                            Ga1400_SetTaskUnRegisterFlag(EN_GA1400_UNREGISTER_NEED);
                            MOS_LOG_INF(GA1400_LOGSTR, "Device Offline ! Ga1400 UnRegister");
                        }
                    }
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_GETINFOFLAG)
                {
                    Ga1400_SetTaskGetInfoFlag(pst1400Msg->uiGetInfoFlag);
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_SETCONNECTFAILTIME)
                {
                    Ga1400_SetTaskConnectFailTime(pst1400Msg->uiConnectFailTime);
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_INCCONNECTFAILTIME)
                {
                    Ga1400_GetTaskMng()->uiConnectFailTime++;
                    if (Ga1400_GetTaskMng()->uiConnectFailTime >= 3)
                    {
                        Ga1400_GetTaskMng()->uiConnectFailTime = 0;
                    }
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_SETUNREGISTERFLAG)
                {
                    Ga1400_SetTaskUnRegisterFlag(pst1400Msg->uiUnRegisterFlag);
                }
                else if (pst1400Msg->stMsgHead.usMsgType == EN_1400_MSG_SETKEEPALIVEFLAG)
                {
                    Ga1400_SetTaskKeepAliveFlag(pst1400Msg->uiKeepAliveFlag);
                }
                MOS_FREE(pst1400Msg);
            }
        }

        // 软件看门狗喂狗 间隔：3S
        if (getDiffTimems(&tGa1400FeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= GA1400_LOOP_FEEDDOG_TIME)
        {
            Swd_AppThreadFeedDog(hSwdGa1400FeedDog);
            getDiffTimems(&tGa1400FeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }

        // 注销
        uiGa1400TaskUnRegisterFlag = Ga1400_GetTaskUnRegisterFlag();
        if (uiGa1400TaskUnRegisterFlag == EN_GA1400_UNREGISTER_NEED)
        {
            MOS_LOG_INF(GA1400_LOGSTR, "Ga1400 UnRegister Info GAT1400ID:%s  GAT1400Domain:%s UnRegisterEndFlag", 
                                        Config_GetCamaraMng()->ucGAT1400ID, Config_GetCamaraMng()->ucGAT1400Domain, uiGa1400UnRegisterEndFlag);

            // 发送注销数据
            iRet = Ga1400_UnRegister();
            if (MOS_OK == iRet)
            {
                // 注销成功，不再发送保活数据
                uiGa1400UnRegisterEndFlag = 1;
            }
            else
            {
                uiUnRegisterFailTime++;
                if (uiUnRegisterFailTime >= GA1400_UNREGISTER_FAIL_RETRY_TIMES)
                {
                    uiGa1400UnRegisterEndFlag = 1;
                }
            }

            if (uiGa1400UnRegisterEndFlag == 1)
            {
                // 注销成功，不再发送保活数据
                uiUnRegisterFailTime      = 0;
                uiGa1400UnRegisterEndFlag = 0;
                Ga1400_SetTaskRegisterFlag(EN_GA1400_REGISTER_NONEED);
                Ga1400_SetTaskKeepAliveFlag(EN_GA1400_KEEPALIVE_NONEED);
                Ga1400_SetTaskUnRegisterFlag(EN_GA1400_UNREGISTER_NONEED);
                Config_SetCamerGat1400Info(0, (_UC *)"", (_UC *)"");

                // 通知厂商Ga1400掉线 注销成功 ADD by LWJ
                if (ZJ_GetFuncTable()->pFunSetGa1400StatusCb)
                {
                    iRet = ZJ_GetFuncTable()->pFunSetGa1400StatusCb(EN_GA1400_OFFLINE);
                    if (MOS_OK == iRet)
                    {
                        // MOS_LOG_INF(GA1400_LOGSTR,"Device pFunSetGa1400StatusCb OK");
                    }
                    else
                    {
                        MOS_LOG_ERR(GA1400_LOGSTR,"Device pFunSetGa1400StatusCb failed");
                    }
                }
                else
                {
                    MOS_LOG_ERR(GA1400_LOGSTR,"pFunSetGa1400StatusCb is NULL!");
                }
            }
        }
        
        // 获取Ga1400配置
        uiGetGa1400InfoSubTime   = MOS_ABS_NUM(Mos_Time() - cGetGa1400InfoTime);
        uiGAT1400Switch          = Config_GetCamerGat1400Switch(0);
        uiConnectFailTime        = Ga1400_GetTaskConnectFailTime();
        uiGa1400TaskGetInfoFlag  = Ga1400_GetTaskGetInfoFlag();
        // 正常1小时查询一次  第一次失败1分钟后查询  第2次失败5分钟后查询 多于2次失败1小时后再查询
        // 设备重新上线，重新获取配置
        if ((uiGa1400TaskGetInfoFlag  == EN_GA1400_GETINFO_NEED_LOOP && uiGAT1400Switch == 1 && uiConnectFailTime == 0 && uiGetGa1400InfoSubTime >= GA1400_LOOP_GET_GA1400INFO_SUBTIME)   ||
            (uiGa1400TaskGetInfoFlag  == EN_GA1400_GETINFO_NEED_LOOP && uiGAT1400Switch == 1 && uiConnectFailTime == 1 && uiGetGa1400InfoSubTime >= GA1400_LOOP_GET_GA1400INFO_FAILTIME1) ||
            (uiGa1400TaskGetInfoFlag  == EN_GA1400_GETINFO_NEED_LOOP && uiGAT1400Switch == 1 && uiConnectFailTime >= 2 && uiGetGa1400InfoSubTime >= GA1400_LOOP_GET_GA1400INFO_FAILTIME2) ||
            (uiGa1400TaskGetInfoFlag  == EN_GA1400_GETINFO_NEED_NOW  && uiGAT1400Switch == 1 ))
        {
            MOS_LOG_INF(GA1400_LOGSTR, "Goto Get Ga1400 Info  SubTime(%u)  ConnectFailTime:%u  GetInfoFlag:%u", uiGetGa1400InfoSubTime, uiConnectFailTime, uiGa1400TaskGetInfoFlag);
            
            // 发送获取GA1400配置参数请求
            iRet = GA1400_GetGa1400Info();
            if (MOS_OK == iRet)
            {
                // 成功解析DNS并插入HTTPS链表中
                Ga1400_SetTaskGetInfoFlag(EN_GA1400_GETINFO_NEED_LOOP);
                cGetGa1400InfoTime = Mos_Time();
            }
        }

        // 注册
        uiGa1400TaskRegisterFlag = Ga1400_GetTaskRegisterFlag();
        if ((uiGa1400TaskRegisterFlag == EN_GA1400_REGISTER_NEED) || 
            (uiGa1400TaskRegisterFlag == EN_GA1400_REGISTER_FAIL  && MOS_ABS_NUM(Mos_Time() - cRegisterFailTime) >= GA1400_LOOP_KEEPALIVE_TIME))
        {
            // 发送注册数据
            iRet = Ga1400_Register();
            if (MOS_OK == iRet)
            {
                // 注册成功，保活开始
                cRegisterFailTime   = 0;
                uiKeepAliveFailTime = 0;
                Ga1400_SetTaskRegisterFlag(EN_GA1400_REGISTER_SUCCESS);
                Ga1400_SetTaskKeepAliveFlag(EN_GA1400_KEEPALIVE_NEED);

                // 通知厂商Ga1400在线 注册成功 ADD by LWJ
                if (ZJ_GetFuncTable()->pFunSetGa1400StatusCb)
                {
                    iRet = ZJ_GetFuncTable()->pFunSetGa1400StatusCb(EN_GA1400_ONLINE);
                    if (MOS_OK == iRet)
                    {
                        // MOS_LOG_INF(GA1400_LOGSTR,"Device pFunSetGa1400StatusCb OK");
                    }
                    else
                    {
                        _UC aucStrErrLog[128]   = {0};
                        _UC aucRegisterUrl[128] = {0};
                        MOS_VSNPRINTF(aucRegisterUrl, 128, "%s%s", Config_GetCamaraMng()->ucGAT1400Domain, GA1400_REGISTER_URL);
                        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunSetGa1400StatusCb Ga1400Status:%d return failed", EN_GA1400_ONLINE);
                        CloudStg_UploadLogEx2(GA1400_LOGSTR, Mos_GetSessionId(), aucRegisterUrl, -1, 
                                                EN_1400_RT_REG_FUNC1400STATUS_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);
                    }
                }
                else
                {
                    MOS_LOG_ERR(GA1400_LOGSTR,"pFunSetGa1400StatusCb is NULL!");
                }
            }
            else
            {
                // 注册失败后 60s后重试注册
                cRegisterFailTime = Mos_Time();
                MOS_LOG_ERR(GA1400_LOGSTR, "Ga1400 Register ERR");
                Ga1400_SetTaskRegisterFlag(EN_GA1400_REGISTER_FAIL);
                // Mos_Sleep(55 * 1000); 
            }
        }

        // 保活  间隔：60S
        uiGa1400TaskKeepAliveFlag = Ga1400_GetTaskKeepAliveFlag();
        if (uiGa1400TaskKeepAliveFlag == EN_GA1400_KEEPALIVE_NEED)
        {
            if (MOS_ABS_NUM(Mos_Time() - cKeepAliveTime) >= GA1400_LOOP_KEEPALIVE_TIME)
            {
                MOS_LOG_INF(GA1400_LOGSTR, "Ga1400 Go To Keep Alive");
                cKeepAliveTime = Mos_Time();

                // 发送保活数据
                iRet = Ga1400_KeepAlive();
                if (iRet != MOS_OK)
                {
                    uiKeepAliveFailTime++;
                    if (uiKeepAliveFailTime >= GA1400_KEEPALIVE_FAIL_RETRY_TIMES)
                    {
                        MOS_LOG_ERR(GA1400_LOGSTR, "Keep Alive ERR");
                        uiKeepAliveFailTime = 0;
                        uiUnRegisterFailTime = 0;
                        Ga1400_SetTaskUnRegisterFlag(EN_GA1400_UNREGISTER_NEED);
                        Ga1400_SetTaskKeepAliveFlag(EN_GA1400_KEEPALIVE_NONEED);
                    }
                }
                else
                {
                    uiKeepAliveFailTime = 0;
                    // MOS_LOG_INF(GA1400_LOGSTR, "Keep Alive OK");
                }

                #if GA1400_UPLOAD_PIC_DEBUG
                // test
                Ga1400_UploadPicTest();
                #endif
            }
        }

        // 上传图片到1400平台
        uiGa1400UploadInterval   = Config_GetCamerGat1400UploadInterval(0);
        uiGa1400TaskRegisterFlag = Ga1400_GetTaskRegisterFlag();
        uiGa1400UploadPicSubTime = Mos_Time() - Ga1400_GetTaskMng()->tTimeUploadPic;
        // MOS_LOG_INF(GA1400_LOGSTR, "uiGa1400TaskRegisterFlag:%u   Ga1400UploadPicSubTime:%u   Ga1400UploadInterval:%u", uiGa1400TaskRegisterFlag, uiGa1400UploadPicSubTime, uiGa1400UploadInterval);
        if (uiGa1400TaskRegisterFlag == EN_GA1400_REGISTER_SUCCESS && uiGa1400UploadPicSubTime >= uiGa1400UploadInterval)  // 已注册 且 时间大于上报间隔
        {
            ST_MOS_LIST_ITERATOR stIterator;
            ST_CFG_UPLOAD_AIPIC_1400_INF_NODE *pstUploadAIPic1400InfNode = MOS_NULL;

            lluNowTime = (_ULLID)Mos_Time();

            // 查找要上传图片到1400平台的节点
            FOR_EACHDATA_INLIST(&Config_GetAIMng()->stUpload1400PlatTaskInfList, pstUploadAIPic1400InfNode, stIterator)
            {
                if (pstUploadAIPic1400InfNode->uiUseFlag == 1 && pstUploadAIPic1400InfNode->uiUploadFlag == 1)
                {
                    lluDuration = MOS_ABS_NUM(lluNowTime - (_ULLID)pstUploadAIPic1400InfNode->lluReportTimeStamp);
                    // 查找上传AI人脸/车牌抓拍图片到1400平台的超时节点
                    if (lluDuration >= GA1400_UPLOADPIC_TIMEOUT_SEC)
                    {
                        MOS_LOG_ERR(GA1400_LOGSTR, "Upload 1400 PIC ReqId:%u EventId:%u is Timeout (%llu - %llu) = %llu > %d",
                                                                        pstUploadAIPic1400InfNode->uiReqId, pstUploadAIPic1400InfNode->uiEventId,
                                                                        lluNowTime,  (_ULLID)pstUploadAIPic1400InfNode->lluReportTimeStamp,
                                                                        lluDuration, (_INT)GA1400_UPLOADPIC_TIMEOUT_SEC);    
                                            

                        // 通知厂商清除AI图片数据缓存 ADD by LWJ
                        if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
                        {
                            iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->aucLabelID,
                                                                        pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf,
                                                                        pstUploadAIPic1400InfNode->stAiPicEventInfo.pucBgJpgBuff);
                            if (MOS_OK == iRet)
                            {
                                // MOS_LOG_INF(GA1400_LOGSTR,"Device pFunFreeAiPicCache Face OK ");
                            }
                            else
                            {
                                MOS_LOG_ERR(GA1400_LOGSTR,"Device pFunFreeAiPicCache Face failed");
                            }
                        }
                        else
                        {
                            MOS_LOG_ERR(GA1400_LOGSTR,"Device pFunFreeAiPicCache Face is NULL!");
                        }
                        #if GA1400_UPLOAD_PIC_DEBUG
                        if (pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf)
                        {
                            free(pstUploadAIPic1400InfNode->stAiPicEventInfo.pstAiPicHead->pucPicBuf);
                            // MOS_LOG_INF(GA1400_LOGSTR,"free face pic OK ");
                        }
                        if (pstUploadAIPic1400InfNode->stAiPicEventInfo.pucBgJpgBuff)
                        {
                            free(pstUploadAIPic1400InfNode->stAiPicEventInfo.pucBgJpgBuff);
                            // MOS_LOG_INF(GA1400_LOGSTR,"free bg pic OK ");
                        }
                        #endif
                        Config_DelUploadAIPic1400TaskNode(0, pstUploadAIPic1400InfNode->uiReqId);
                        lluDuration = 0;
                    }
                    else
                    {
                        // MOS_LOG_INF(GA1400_LOGSTR, "Find Upload Pic 1400 Node Id:%u", pstUploadAIPic1400InfNode->uiReqId);
                        break;
                    }
                }
            }

            if (pstUploadAIPic1400InfNode)
            {
                Ga1400_GetTaskMng()->tTimeUploadPic = Mos_Time();
                // 上传图片到1400平台
                Ga1400_UploadAIPicTo1400Plat(pstUploadAIPic1400InfNode, &tGa1400FeedDogTimeOut, hSwdGa1400FeedDog);
            }
        }

        Mos_Sleep(100);
    }

    // GA1400功能退出，已注册则注销
    uiGa1400TaskRegisterFlag = Ga1400_GetTaskRegisterFlag();
    if (uiGa1400TaskRegisterFlag == EN_GA1400_REGISTER_SUCCESS)
    {
        iRet = Ga1400_UnRegister();
        if (MOS_OK == iRet)
        {
            // MOS_LOG_INF(GA1400_LOGSTR, "Ga1400 UnRegister OK");
        }
        else
        {
            MOS_LOG_ERR(GA1400_LOGSTR, "Ga1400 UnRegister ERR");
        }
    }

    Swd_AppThreadUnRegist(hSwdGa1400FeedDog);

    MOS_LOG_INF(GA1400_LOGSTR, "Ga1400 Thread Exit");
    return MOS_OK;
}

// GA1400模块启动
_INT Ga1400_Task_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    #ifdef MOS_LINUX_RTOS
    uiStackSize     = MOS_THREAD_STACK_MIN_SIZE;
    #endif

    if(Ga1400_GetTaskMng ()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    
    if(Ga1400_GetTaskMng ()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(GA1400_LOGSTR, "Already Start");
        return MOS_OK;
    }

    if (Config_GetCamaraMng()->uiGAT1400Ability == 1)
    {
        Ga1400_GetTaskMng ()->ucRunFlag  = 1;
        // GA1400模块任务轮询
        if (Config_GetCamaraMng()->uiInterGAT1400Ability == 1) // 内嵌Ga1400
        {
            if(Mos_ThreadCreate((_UC*)"GA1400_task", EN_THREAD_PRIORITY_NORMAL, uiStackSize,
                                Ga1400_Task_LoopEx, MOS_NULL,MOS_NULL, &Ga1400_GetTaskMng()->hThread) == MOS_ERR)
            {
                Ga1400_GetTaskMng()->ucRunFlag = 0;
                return MOS_ERR;
            }
        }
        else
        {
            if(Mos_ThreadCreate((_UC*)"GA1400_task", EN_THREAD_PRIORITY_NORMAL, uiStackSize,
                                Ga1400_Task_Loop, MOS_NULL,MOS_NULL, &Ga1400_GetTaskMng()->hThread) == MOS_ERR)
            {
                Ga1400_GetTaskMng()->ucRunFlag = 0;
                return MOS_ERR;
            } 
        }
        MOS_LOG_INF(GA1400_LOGSTR, "GA1400 Start OK !!!!!!!!!!!!!!!!");
    }
    else
    {
        MOS_LOG_INF(GA1400_LOGSTR, "GA1400 GAT1400Ability No Support !!!!!!!!!!!!!!!!");
    }

    return MOS_OK;
}

// GA1400模块停止
_INT Ga1400_Task_Stop()
{
    if(Ga1400_GetTaskMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(GA1400_LOGSTR, "Already Stop");
        return MOS_OK;
    }
    Ga1400_GetTaskMng()->ucRunFlag = 0;
    //Mos_MsgQueueWake(Ga1400_GetTaskMng()->hMsgQueue, MOS_TRUE);
    
    Mos_ThreadDelete(Ga1400_GetTaskMng()->hThread);

    if (Ga1400_GetTaskMng()->pucBgPicBaseData)
    {
        MOS_FREE(Ga1400_GetTaskMng()->pucBgPicBaseData);
        Ga1400_GetTaskMng()->pucBgPicBaseData = MOS_NULL;
    }
    if (Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData)
    {
        MOS_FREE(Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData);
        Ga1400_GetTaskMng()->pucFaceOrCarPicBaseData = MOS_NULL;
    }

    MOS_LOG_INF(GA1400_LOGSTR, "GA1400 task stop ok");
    return MOS_OK;
}

// GA1400模块销毁
_INT Ga1400_Task_Destroy()
{
    if(Ga1400_GetTaskMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(GA1400_LOGSTR, "Already Destroy");
        return MOS_OK;
    }

    ST_1400_STATUS_MSG *pst1400Msg = NULL;
    while((pst1400Msg = Mos_MsgQueuePop(Ga1400_GetTaskMng()->hMsgQueue)) != MOS_NULL)
    {
        MOS_FREE(pst1400Msg);
    }
    Mos_MsgQueueDelete(Ga1400_GetTaskMng()->hMsgQueue);
    Mos_MutexDelete(&Ga1400_GetTaskMng()->hMutex);
    MOS_MEMSET(&g_Ga1400TaskMng, 0, sizeof(g_Ga1400TaskMng));
    Ga1400_GetTaskMng()->ucInitFlag = 0;
    MOS_LOG_INF(GA1400_LOGSTR, "GA1400 task Destroy ok");
    return MOS_OK;
}

#endif
