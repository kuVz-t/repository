#ifndef _GA1400_API_H
#define _GA1400_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"

#define GA1400_UPLOAD_PIC_DEBUG                 0
#define GA1400_SUPPORTIPANDPORT                 1
#define GA1400_BASEDATA_USE_NODE                0
#define GA1400_SUPPORTFACTORYTRANS              1

#define GA1400_POST_SUPPORT                     0
#define GA1400_GETGA1400INFO_URL                (_UC*)"/gw/VIID/device/getGAT1400Config"
#define GA1400_REGISTER_URL                     (_UC*)"VIID/System/Register"            // 平台返回的域名带“/”
#define GA1400_UNREGISTER_URL                   (_UC*)"VIID/System/UnRegister"
#define GA1400_KEEPALIVE_URL                    (_UC*)"VIID/System/Keepalive"
#define GA1400_UPLOADPIC_CAR_URL                (_UC*)"VIID/MotorVehicles"
#define GA1400_UPLOADPIC_FACE_URL               (_UC*)"VIID/Faces"

#define GA1400_LOOP_GET_GA1400INFO_SUBTIME      3600    // 1小时
#define GA1400_LOOP_GET_GA1400INFO_FAILTIME1    60      // 1分钟
#define GA1400_LOOP_GET_GA1400INFO_FAILTIME2    300     // 5分钟

#define GA1400_LOOP_FEEDDOG_TIME                3       // 3S  喂狗
#define GA1400_LOOP_KEEPALIVE_TIME              60      // 60S 保活

#ifdef  JOVISION_GA1400
#define GA1400_ALARM_LISTNODE_MAXCOUNT          20      // GA1400告警事件链表最大节点数
#else
#define GA1400_ALARM_LISTNODE_MAXCOUNT          40      // GA1400告警事件链表最大节点数
#endif

#define GA1400_UPLOADPIC_FAIL_RETRY_TIMES       2       // GA1400上传抓拍图失败重试次数
#define GA1400_KEEPALIVE_FAIL_RETRY_TIMES       3       // GA1400注销失败重试次数
#define GA1400_UNREGISTER_FAIL_RETRY_TIMES      3       // GA1400保活失败重试次数

#define GA1400_UPLOADPIC_TIMEOUT_SEC            60      // GA1400上传抓拍图超时时间

typedef enum enum_GA1400_RT_TYPE1
{
    EN_GA1400_RT_GETGA1400INFOJSON_ERR      = 210001,    // 回复的Json异常，导致获取GA1400信息失败
    EN_GA1400_RT_SETGA1400INFOCB_ERR        = 210002,    // 没有设置1400回调函数
    EN_GA1400_RT_GETGA1400INFOPLATRT_ERR    = 210003,    // 获取GA1400信息1400平台返回错误吗
    EN_GA1400_RT_FIRSTREGISTER_ERR          = 210004,    // 1400平台第一次注册失败
    EN_GA1400_RT_SECONDREGISTER_ERR         = 210005,    // 1400平台第二次注册失败
    EN_GA1400_RT_UNREGISTER_ERR             = 210006,    // 1400平台注销失败
    EN_GA1400_RT_KEEPALIVE_ERR              = 210007,    // 1400平台心跳保活失败
    EN_GA1400_RT_UPLOADPIC_ERR              = 210008,    // 1400平台上报图片失败

}EN_GA1400_RT_TYPE1;
typedef enum enum_GA1400_ONLINE_TYPE{

    EN_GA1400_OFFLINE            = 0,    // GA1400离线
    EN_GA1400_ONLINE             = 1     // GA1400在线
}EN_GA1400_ONLINE_TYPE;

typedef enum enum_GA1400_GETINFO_TYPE{

    EN_GA1400_GETINFO_NONEED     = 0,    // GA1400 不需获取配置
    EN_GA1400_GETINFO_NEED_NOW   = 1,    // GA1400 需立刻获取配置
    EN_GA1400_GETINFO_NEED_LOOP  = 2     // GA1400 需轮询获取配置

}EN_GA1400_GETINFO_TYPE;

typedef enum enum_GA1400_REGISTER_TYPE{

    EN_GA1400_REGISTER_NONEED    = 0,    // GA1400 不需注册
    EN_GA1400_REGISTER_NEED      = 1,    // GA1400 需注册
    EN_GA1400_REGISTER_SUCCESS   = 2,    // GA1400 已注册
    EN_GA1400_REGISTER_FAIL      = 3     // GA1400 注册失败
}EN_GA1400_REGISTER_TYPE;

typedef enum enum_GA1400_UNREGISTER_TYPE{

    EN_GA1400_UNREGISTER_NONEED  = 0,    // GA1400 不需注销
    EN_GA1400_UNREGISTER_NEED    = 1     // GA1400 需注销
}EN_GA1400_UNREGISTER_TYPE;

typedef enum enum_GA1400_KEEPALIVE_TYPE{

    EN_GA1400_KEEPALIVE_NONEED   = 0,    // GA1400 不需保活
    EN_GA1400_KEEPALIVE_NEED     = 1     // GA1400 需保活
}EN_GA1400_KEEPALIVE_TYPE;

typedef enum enum_1400_MSG_TYPE
{
    //注意与EN_CFG_MSG_TYPE的冲突
    EN_1400_MSG_ONLINESTATUS        = 1,       // 设备上线状态
    EN_1400_MSG_GETINFOFLAG         = 0x1000,  // 获取1400信息标志
    EN_1400_MSG_SETCONNECTFAILTIME  = 0x1001,  // 设置1400连接失败次数
    EN_1400_MSG_INCCONNECTFAILTIME  = 0x1002,  // 递增1400连接失败次数
    EN_1400_MSG_SETUNREGISTERFLAG   = 0x1003,  // 设置1400注册销毁标志
    EN_1400_MSG_SETKEEPALIVEFLAG    = 0x1004,  // 设置1400保活标志
}EN_1400_MSG_TYPE;

typedef struct stru_1400_STATUS_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UI uiOnlineStatus;
    _UI uiGetInfoFlag;
    _UI uiConnectFailTime;
    _UI uiUnRegisterFlag;
    _UI uiKeepAliveFlag;
}ST_1400_STATUS_MSG;

typedef struct stru_GA1400_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _UC             ucRsv[2];
    _HTHREAD        hThread;
    _HMUTEX         hMutex;
    _CTIME_T        tTimeUploadPic;             // 图片上传时间点
    _UI             uiUploadPicFlag;            // 图片上传标志 0:未有上传图片动作 1.正在进行上传图片json拼接
    _UI             uiConnectFailTime;          // 获取GA1400配置参数失败次数
    _UI             uiGa1400TaskGetInfoFlag;    // 获取GA1400配置参数标志 
    _UI             uiGa1400TaskRegisterFlag;   // GA1400注册标志   0：不需注册 1：需注册 2.已注册 3.注册失败
    _UI             uiGa1400TaskUnRegisterFlag; // GA1400注销标志   0：不需注销 1：需注销
    _UI             uiGa1400TaskKeepAliveFlag;  // GA1400保活标志   0：不需保活 1：需保活
    _UC             *pucBgPicBaseData;          // 背景图的base数据
    _UI             uiBgPicBaseDataLen;         // 背景图的base数据长度
    _UC             *pucFaceOrCarPicBaseData;   // 抓拍图的base数据
    _UI             uiFaceOrCarPicBaseDataLen;  // 抓拍图的base数据长度
    _HQUEUE         hMsgQueue;
}ST_GA1400_MNG;

typedef struct stru_GA1400_HTTP_TASK
{
    _UI             uiHttpCode;           // http码
    _UI             uiHttpHandle;         // handle
    _US             usBuffLen;            // 单次接收数据长度
    _US             usRecvLen;            // 总共接收数据长度
    _UC*            pucHttpBuff;          // httpbuf
    _UC*            pucSecondRegHeadEx;   // 第二次注册数据
    _UI             uiUploadPicindex;     // 上传图片索引
    _UC*            pucHttpsPostData;     // 上传数据
    _UI             uiUploadPicHttpCode;  // 上传图片http码
    _US             usUploadPicBuffLen;   // 上传图片接收数据长度
    _US             usUploadPicRecvLen;   // 上传图片接收数据长度
    _UC*            pucHttpUploadPicBuff; // 上传图片接收buf
}ST_GA1400_HTTP_TASK;


ST_GA1400_MNG *Ga1400_GetTaskMng();

#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDE
// GA1400模块初始化
_INT Ga1400_Task_Init();

// GA1400模块启动
_INT Ga1400_Task_Start();

// GA1400模块停止
_INT Ga1400_Task_Stop();

// GA1400模块销毁
_INT Ga1400_Task_Destroy();

// 获取GA1400配置参数失败次数
_UI  Ga1400_GetTaskConnectFailTime();
_INT Ga1400_SetTaskConnectFailTime(_UI uiConnectFailTime);
_INT Ga1400_SetTaskConnectFailTimeByMsg(_BOOL bIsInc, _UI uiConnectFailTime);

// 获取GA1400配置参数
_INT GA1400_GetGa1400Info();
_UI  Ga1400_GetTaskGetInfoFlag();
_INT Ga1400_SetTaskGetInfoFlag(_UI uiGa1400TaskGetInfoFlag);
_INT Ga1400_SetTaskGetInfoFlagByMsg(_UI uiGa1400TaskGetInfoFlag);

// GA1400 注册
_INT Ga1400_Register();
_UI  Ga1400_GetTaskRegisterFlag();
_INT Ga1400_SetTaskRegisterFlag(_UI uiGa1400TaskRegisterFlag);

// GA1400 注销
_INT Ga1400_UnRegister();
_UI  Ga1400_GetTaskUnRegisterFlag();
_INT Ga1400_SetTaskUnRegisterFlag(_UI uiGa1400TaskUnRegisterFlag);
_INT Ga1400_SetTaskUnRegisterFlagByMsg(_UI uiGa1400TaskUnRegisterFlag);

// GA1400 保活
_INT Ga1400_KeepAlive();
_UI  Ga1400_GetTaskKeepAliveFlag();
_INT Ga1400_SetTaskKeepAliveFlag(_UI uiGa1400TaskKeepAliveFlag);
_INT Ga1400_SetTaskKeepAliveFlagByMsg(_UI uiGa1400TaskKeepAliveFlag);

// GA1400 图片上传标志
_INT Ga1400_SetTaskUploadPicFlag(_UI uiUploadPicFlag);
_UI  Ga1400_GetTaskUploadPicFlag();
#endif

#ifdef __cplusplus
}
#endif
#endif
