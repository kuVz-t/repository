#ifndef _IOMANAGE_API_H
#define _IOMANAGE_API_H

#ifdef __cplusplus
extern "C" {
#endif

// 返回写入磁盘的数据大小
typedef _INT (*PFUN_IOMNG_PROCESS)();
typedef _INT (*PFUN_IOMNG_STOP)();
typedef _INT (*PFUN_IOMNG_RESTART)(_UC *pucLocalPath);
// 返回删除文件的大小
typedef _INT (*PFUN_IOMNG_AUTODEL)();

_INT IoMng_Init();
_INT IoMng_Destory();
_INT IoMng_Start();
_INT IoMng_Stop();

_INT IoMng_Register(_UC *pucModuleName, PFUN_IOMNG_PROCESS pfuncProcess,PFUN_IOMNG_STOP pfuncStop, 
                    PFUN_IOMNG_RESTART pfuncRestart,PFUN_IOMNG_AUTODEL pFunAutoDelCb);

_INT IoMng_UnRegister(_UC *pucModuleName);

_INT IoMng_SetPath(_UC *pucLocalPath);

#ifdef __cplusplus
}
#endif
#endif
