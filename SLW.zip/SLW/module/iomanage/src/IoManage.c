#include "mos.h"
#include "IoManage_api.h"
#include "IoManage_prv.h"
#include "zj_interface.h"
#include "kj_timer.h"
#include "watchdog_api.h"

// static _HSWDWRITE    g_hSwdIoMngFeedDog;
// static kj_timer_t    g_tIoMngFeedDogTimeOut;

static ST_IOTASK_MNG g_IoTaskMng;

static _INT IoMng_TaskLoopProc(_VPTR pParam);

/************************************************************
*************************************************************/
static ST_IOTASK_MNG *IoMng_GetTaskMng()
{
    return &g_IoTaskMng;
}

// local IO 初始化
_INT IoMng_Init()
{
    if(IoMng_GetTaskMng()->ucInitFlag == 1){
        MOS_LOG_WARN(IOMNG_LOGSTR, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_IoTaskMng,0,sizeof(g_IoTaskMng));
    Mos_MutexCreate(&IoMng_GetTaskMng()->hMutex);
    IoMng_GetTaskMng()->ucInitFlag = 1;
    MOS_LOG_INF(IOMNG_LOGSTR,"init ok");
    return MOS_OK;
}

// local IO 启动
_INT IoMng_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    if(0 == IoMng_GetTaskMng()->ucInitFlag)
    {
       MOS_LOG_WARN(IOMNG_LOGSTR,"not init");
       return MOS_ERR;
    }
    
    if(IoMng_GetTaskMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(IOMNG_LOGSTR, "Already Start");
        return MOS_OK;
    }

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    IoMng_GetTaskMng()->ucRunFlag = 1;
    if(Mos_ThreadCreate((_UC*)"IoManage_task",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
            IoMng_TaskLoopProc,MOS_NULL,MOS_NULL,&IoMng_GetTaskMng()->hThreadId) == MOS_ERR)
    {
        IoMng_GetTaskMng()->ucRunFlag = 0;
        return MOS_ERR;
    }
    MOS_LOG_INF(IOMNG_LOGSTR,"task start ok");
    return MOS_OK;
}

// local IO 停止
_INT IoMng_Stop()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_IOMNG_TASK_NODE *pstTaskNode = MOS_NULL;
    if (IoMng_GetTaskMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(IOMNG_LOGSTR, "Already Stop");
        return MOS_OK;
    }
    
    IoMng_GetTaskMng()->ucRunFlag = 0;
    Mos_ThreadDelete(IoMng_GetTaskMng()->hThreadId);
    IoMng_GetTaskMng()->hThreadId = MOS_NULL;
    FOR_EACHDATA_INLIST(&IoMng_GetTaskMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(EN_IOTASK_STATUS_WORK == pstTaskNode->ucStatus)
        {
            if(pstTaskNode->pfuncStop != MOS_NULL)
                pstTaskNode->pfuncStop();
        }
    }
    MOS_LOG_INF(IOMNG_LOGSTR,"task stop ok");
    return MOS_OK;
}

// local IO 销毁
_INT IoMng_Destory()
{
    if(IoMng_GetTaskMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(IOMNG_LOGSTR, "Already Destroy");
        return MOS_OK;
    }
    Mos_MutexLock(&IoMng_GetTaskMng()->hMutex);
    MOS_LIST_RMVALL(&IoMng_GetTaskMng()->stTaskList, MOS_TRUE);
    Mos_MutexUnLock(&IoMng_GetTaskMng()->hMutex);
    Mos_MutexDelete(&IoMng_GetTaskMng()->hMutex);
    IoMng_GetTaskMng()->ucInitFlag = 0;
    MOS_LOG_INF(IOMNG_LOGSTR,"IoMng_TaskLoopProc destroy ok");
    return MOS_OK;
}

// 外部模块 注册local IO
_INT IoMng_Register(_UC *pucModuleName, PFUN_IOMNG_PROCESS pfuncProcess,
        PFUN_IOMNG_STOP pfuncStop, PFUN_IOMNG_RESTART pfuncRestart,PFUN_IOMNG_AUTODEL pFunAutoDelCb)
{
    MOS_PARAM_NULL_RETERR(pucModuleName);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_IOMNG_TASK_NODE *pstTaskNode = MOS_NULL;
    ST_IOMNG_TASK_NODE *pstTaskTmpNode = MOS_NULL;

    Mos_MutexLock(&IoMng_GetTaskMng()->hMutex);
    FOR_EACHDATA_INLIST(&IoMng_GetTaskMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->ucIsUsing && MOS_STRNCMP(pstTaskNode->uiModuLeName, pucModuleName, MODULE_NAME_LEN) == 0)
        {
            Mos_MutexUnLock(&IoMng_GetTaskMng()->hMutex);
            return MOS_OK;
        }
        else if(pstTaskNode->ucIsUsing == 0)
        {
            pstTaskTmpNode = pstTaskNode;
        }
    }
    if(pstTaskTmpNode == MOS_NULL)
    {
        pstTaskTmpNode = (ST_IOMNG_TASK_NODE*)MOS_MALLOCCLR(sizeof(ST_IOMNG_TASK_NODE));
        MOS_LIST_ADDTAIL(&IoMng_GetTaskMng()->stTaskList, pstTaskTmpNode);
    }
    MOS_STRNCPY(pstTaskTmpNode->uiModuLeName, pucModuleName, sizeof(pstTaskTmpNode->uiModuLeName));
    pstTaskTmpNode->pfuncProcess  = pfuncProcess;
    pstTaskTmpNode->pfuncStop     = pfuncStop;
    pstTaskTmpNode->pfuncRestart  = pfuncRestart;
    pstTaskTmpNode->pFunAutoDelCb = pFunAutoDelCb;
    pstTaskTmpNode->ucStatus = EN_IOTASK_STATUS_INIT;
    pstTaskTmpNode->ucIsUsing = 1;
    Mos_MutexUnLock(&IoMng_GetTaskMng()->hMutex);
    return MOS_OK;
}

// 外部模块 注销 local IO
_INT IoMng_UnRegister(_UC *pucModuleName)
{
    MOS_PARAM_NULL_RETERR(pucModuleName);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_IOMNG_TASK_NODE *pstTaskNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&IoMng_GetTaskMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->ucIsUsing && MOS_STRNCMP(pstTaskNode->uiModuLeName, pucModuleName, MODULE_NAME_LEN) == 0)
        {
            if(pstTaskNode->ucStatus==EN_IOTASK_STATUS_WORK){
                pstTaskNode->pfuncStop();
            }
            pstTaskNode->pfuncProcess = MOS_NULL;
            pstTaskNode->pfuncRestart = MOS_NULL;
            pstTaskNode->pfuncStop    = MOS_NULL;
            pstTaskNode->uiModuLeName[0] = 0;
            pstTaskNode->ucIsUsing = 0;
            return MOS_OK;
        }
    }
    return MOS_OK;
}

// 停止所有 local IO 任务
_INT IoMng_StopAllTask()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_IOMNG_TASK_NODE *pstTaskNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&IoMng_GetTaskMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->ucIsUsing == 0){
            continue;
        }
        if(pstTaskNode->pfuncStop && pstTaskNode->ucStatus==EN_IOTASK_STATUS_WORK){
            pstTaskNode->pfuncStop();
        }
        pstTaskNode->ucStatus=EN_IOTASK_STATUS_STOP;
    }
    return MOS_OK;
}

// 暂停所有 local IO 任务
_INT IoMng_PauseAllTask( )
{
    _INT iSleepCount = 0;
    if(IoMng_GetTaskMng()->ucRunFlag == 0)
    {
        return MOS_OK;
    }
    IoMng_GetTaskMng()->ucStopFlag = 1;
    
    while(IoMng_GetTaskMng()->uiWorkNodeCnt != 0 && (iSleepCount++ < 1000))
    {
        Mos_Sleep(100);
    }
    MOS_LOG_INF(IOMNG_LOGSTR,"stop all task work node count %u",IoMng_GetTaskMng()->uiWorkNodeCnt );
    return MOS_OK;
}

// 重启(恢复)所有 local IO 任务
_INT IoMng_ReStartAllTask()
{
    IoMng_GetTaskMng()->ucStopFlag     = 0;
    IoMng_GetTaskMng()->uiReStartFlag  = 1;
    MOS_LOG_INF(IOMNG_LOGSTR,"start all task work node count %u",IoMng_GetTaskMng()->uiWorkNodeCnt );
    return MOS_OK;
}

// 启动 local IO 任务
_INT IoMng_StartTask()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_IOMNG_TASK_NODE *pstTaskNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&IoMng_GetTaskMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->ucIsUsing ==0){
            continue;
        }
        if(pstTaskNode->ucStatus == EN_IOTASK_STATUS_STOP)
        {
            pstTaskNode->ucStatus = EN_IOTASK_STATUS_INIT;
        }
    }
    return MOS_OK;
}

// 检查磁盘空间 5分钟调用一次
static _INT IoMng_CheckDiskSpace()
{
    _UI uiHaveDelSize = 0;
    _CTIME_T  cTimeNow = Mos_Time();
    _XXLSIZE lluTotalSpace,lluFreeSpace = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_IOMNG_TASK_NODE *pstTaskNode = MOS_NULL;

    if(MOS_STRLEN(IoMng_GetTaskMng()->aucCachePath) == 0 )
    {
        return MOS_ERR;
    }
    // 30分钟检查一次 或者 磁盘空间为0
    if((_UI)(cTimeNow - IoMng_GetTaskMng()->cDiskCheckTime) > IOMNG_DISK_CHECK_SPACE_TIME ||  IoMng_GetTaskMng()->uiTotalSpace == 0)
    {
        // 获取磁盘信息 总空间 剩余空间 单位K
        if(ZJ_GetFuncTable()->pfunGetSDCardInfo)
        {
            _INT iRet = MOS_ERR;
            iRet = ZJ_GetFuncTable()->pfunGetSDCardInfo(&IoMng_GetTaskMng()->uiTotalSpace,&IoMng_GetTaskMng()->uiFreeSpace);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(IOMNG_LOGSTR,"Device pfunGetSDCardInfo err");
            }
        }
        else if(Mos_GetDiskSize(IoMng_GetTaskMng()->aucCachePath,&lluFreeSpace,&lluTotalSpace) == MOS_OK)
        {
            IoMng_GetTaskMng()->uiTotalSpace = (_UI)lluTotalSpace;
            IoMng_GetTaskMng()->uiFreeSpace  = (_UI)lluFreeSpace;
        }
        IoMng_GetTaskMng()->cDiskCheckTime = cTimeNow;
        IoMng_GetTaskMng()->lluWriteLen = 0;
    }
    
    if(IoMng_GetTaskMng()->uiFreeSpace > IoMng_GetTaskMng()->lluWriteLen/1024/1024)
    {
        lluFreeSpace = IoMng_GetTaskMng()->uiFreeSpace - IoMng_GetTaskMng()->lluWriteLen/1024/1024;
    }
    else
    {
        lluFreeSpace = IoMng_GetTaskMng()->uiFreeSpace;
    }

    MOS_LOG_INF(IOMNG_LOGSTR,"get disk size total %u total(15per) %u Free %llu,last free %u ",
                            IoMng_GetTaskMng()->uiTotalSpace, IoMng_GetTaskMng()->uiTotalSpace*IOMNG_DISK_CLEAN_PERCENTAGE/100, 
                            lluFreeSpace, IoMng_GetTaskMng()->uiFreeSpace); 
    
    if(IoMng_GetTaskMng()->uiTotalSpace == 0)
    {
        return MOS_ERR;
    }
    
    // 剩余空间大于15%时不做删除处理
    if(lluFreeSpace > IOMNG_DISK_RSV_SIZE && ((_UI)lluFreeSpace)* 100/IoMng_GetTaskMng()->uiTotalSpace > IOMNG_DISK_CLEAN_PERCENTAGE)
    {
        return MOS_ERR;
    }

    FOR_EACHDATA_INLIST(&IoMng_GetTaskMng()->stTaskList, pstTaskNode, stIterator)
    {
        if(pstTaskNode->ucIsUsing == 0){
            continue;
        }
        if(pstTaskNode->pFunAutoDelCb)
        {
            uiHaveDelSize += pstTaskNode->pFunAutoDelCb();
        }
    }
    IoMng_GetTaskMng()->lluWriteLen = 0;
    IoMng_GetTaskMng()->uiFreeSpace += uiHaveDelSize/1024/1024;
    return MOS_OK;
}

// _VOID IoMng_CheckAndFeedDog()
// {
//     // 软看门狗喂狗
//     if (getDiffTimems(&g_tIoMngFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
//     {            
//         Swd_AppThreadFeedDog(g_hSwdIoMngFeedDog);
//         getDiffTimems(&g_tIoMngFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
//     }
// }

// 轮询local IO 任务
static _INT IoMng_TaskLoopProc(_VPTR pParam)
{
    _INT iRet = MOS_OK;
    _UI uiLoopCnt = 30000;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_IOMNG_TASK_NODE *pstTaskNode = MOS_NULL;

    // g_hSwdIoMngFeedDog = Swd_AppThreadRegist(IOMANAGE_APP, FEED_DOG_MAX_TIMESEC);

    // kj_timer_init(&g_tIoMngFeedDogTimeOut);
    // getDiffTimems(&g_tIoMngFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);

    // 开始
    while(IoMng_GetTaskMng()->ucRunFlag )
    {
        // 软看门狗检测喂狗
        // IoMng_CheckAndFeedDog();

        if(IoMng_GetTaskMng()->uiReStartFlag)
        {
            IoMng_StartTask();
            IoMng_GetTaskMng()->uiReStartFlag = 0;
        }
        
        // 遍历local IO的任务注册链表
        FOR_EACHDATA_INLIST(&IoMng_GetTaskMng()->stTaskList, pstTaskNode, stIterator)
        {
            if(pstTaskNode->ucIsUsing == 0){
                continue;
            }
            if(EN_IOTASK_STATUS_INIT == pstTaskNode->ucStatus && pstTaskNode->pfuncRestart){
                IoMng_GetTaskMng()->uiWorkNodeCnt++;
                // 注册的IO设备启动
                pstTaskNode->pfuncRestart(IoMng_GetTaskMng()->aucCachePath);
                pstTaskNode->ucStatus = EN_IOTASK_STATUS_WORK;
            }
            if(EN_IOTASK_STATUS_WORK == pstTaskNode->ucStatus)
            {
                if(IoMng_GetTaskMng()->ucStopFlag == 1)
                {
                    // io设备停止
                    if(pstTaskNode->pfuncStop != MOS_NULL)
                        pstTaskNode->pfuncStop();
                    IoMng_GetTaskMng()->uiWorkNodeCnt--;
                    pstTaskNode->ucStatus = EN_IOTASK_STATUS_STOP;
                }
                else if(pstTaskNode->pfuncProcess != MOS_NULL)
                {
                    // IO设备运行
                    iRet = pstTaskNode->pfuncProcess();
                    if(iRet > 0)
                    {
                        IoMng_GetTaskMng()->lluWriteLen += iRet;
                    }
                }
            }   
        }
        //60*100 *1.5  total 5 minite 
        if(uiLoopCnt++ > 6000)
        {
            IoMng_CheckDiskSpace();
            uiLoopCnt = 0;
        }
        Mos_Sleep(10);
    }
    // Swd_AppThreadUnRegist(g_hSwdIoMngFeedDog);
    MOS_LOG_INF(IOMNG_LOGSTR,"IoManage task out");
    return MOS_OK;
}

// 设置local IO路径
_INT IoMng_SetPath(_UC *pucLocalPath)
{
    if(MOS_STRCMP(pucLocalPath,IoMng_GetTaskMng()->aucCachePath) != 0)
    {
        IoMng_PauseAllTask();
    }
    MOS_STRNCPY(IoMng_GetTaskMng()->aucCachePath, pucLocalPath, sizeof(IoMng_GetTaskMng()->aucCachePath));
    
    if(MOS_STRLEN(pucLocalPath) > 0){
        
        IoMng_ReStartAllTask();
    }
    
    return MOS_OK;
}

