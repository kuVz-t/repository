#ifndef _IOMANAGE_PRV_H
#define _IOMANAGE_PRV_H


#ifdef __cplusplus
extern "C" {
#endif

#define IOMNG_LOGSTR                (_UC*)"IO"

#define MODULE_NAME_LEN           16
#define IOMNG_DISK_RSV_SIZE          600
#define IOMNG_DISK_CLEAN_PERCENTAGE  15
#define IOMNG_DISK_CHECK_SPACE_TIME  1800
typedef enum{
    EN_IOTASK_STATUS_INIT = 0,
    EN_IOTASK_STATUS_WORK = 1,
    EN_IOTASK_STATUS_STOP = 2,
}EN_IOTASK_STATUS;


typedef struct st_IOMNG_TASK_NODE
{
    _UC ucIsUsing;
    _UC ucStatus;
    _UC ucR[2];
    _UC uiModuLeName[MODULE_NAME_LEN];
    PFUN_IOMNG_PROCESS pfuncProcess;
    PFUN_IOMNG_STOP pfuncStop;
    PFUN_IOMNG_RESTART pfuncRestart;
    PFUN_IOMNG_AUTODEL pFunAutoDelCb;
    ST_MOS_LIST_NODE stNode;
}ST_IOMNG_TASK_NODE;

typedef struct stru_IoTask_Mng
{
    _UC ucInitFlag;
    _UC ucRunFlag;
    _UC ucStopFlag;
    _UC uiReStartFlag;
    
    _UC uiWorkNodeCnt;
    _UC ucRsv[3];

    _CTIME_T  cDiskCheckTime;

    _UI uiTotalSpace; // 单位M
    _UI uiFreeSpace;
    _LLID lluWriteLen;
    
    _UC aucCachePath[256];
    _HTHREAD hThreadId;
    _HMUTEX hMutex;
    ST_MOS_LIST stTaskList; //ST_IOMNG_TASK_NODE
}ST_IOTASK_MNG;

#ifdef __cplusplus
}
#endif

#endif

