#ifndef  _MSGMNG_TYPE_H_
#define  _MSGMNG_TYPE_H_

#ifdef __cplusplus
extern "C" {
#endif

#define MSGMNG_AP_SERVER_ID                   (_UC*)"ap_server_id"
#define MSGMNG_GB_SERVER_ID                   (_UC*)"gb_server_id"
#define MSGMNG_CMD_SERVER_ID                  (_UC*)"dx_server_id"
#define MSGMNG_P2P_SERVER_ID                  (_UC*)"p2p_server_id"
#ifdef BUILD_SUPPORT_MSGTEST_FALG
#define MSGTEST_SERVER_ID                     (_UC*)"msgtest_server_id"
#endif

#define MSGMNG_CMD_SERVER_ADDR                (_UC*)"http://cmdserver/method/"

typedef enum enum_MSG_SETCMD_TYPE
{
    EN_MSG_SETCMD_TYPE_ADD_OR_SET = 1,
	EN_MSG_SETCMD_TYPE_DEL        = 2,
}EN_OGCT_SETCMD_TYPE;

typedef enum enum_OGCT_ENCRYPT_LEVEL
{
    EN_OGCT_ENCRYPT_LEVEL_NONE   = 0,
    EN_OGCT_ENCRYPT_LEVEL_LOW    = 0X30,
    EN_OGCT_ENCRYPT_LEVEL_AES128 = 0X31,
	EN_OGCT_ENCRYPT_LEVEL_AES192 = 0X32,
	EN_OGCT_ENCRYPT_LEVEL_AES256 = 0X33

}EN_OGCT_ENCRYPT_LEVEL;

typedef enum enum_OGCT_EVENTCLOUD_RANGE
{
    EN_OGCT_EVENTCLOUD_RANGE_NONE           = 0,
    EN_OGCT_EVENTCLOUD_RANGE_MAXTIME_MIN    = 60,
    EN_OGCT_EVENTCLOUD_RANGE_MAXTIME_MAX    = 600,
	EN_OGCT_EVENTCLOUD_RANGE_MINTIME_MIN    = 20,
	EN_OGCT_EVENTCLOUD_RANGE_MINTIME_MAX    = 60,
    EN_OGCT_EVENTCLOUD_RANGE_DETECTTIME_MIN = 3,
    EN_OGCT_EVENTCLOUD_RANGE_DETECTTIME_MAX = 10,
	EN_OGCT_EVENTCLOUD_RANGE_APPENDTIME_MIN = 5,
	EN_OGCT_EVENTCLOUD_RANGE_APPENDTIME_MAX = 30,
}EN_OGCT_EVENTCLOUD_RANGE;

/*************************************************
方法类
**************************************************/
typedef enum enum_OGCT_METHOD_TYPE
{
    EN_OGCT_METHOD_FORCEKEEPALIVE       = 0X00,
    EN_OGCT_METHOD_FEEDBACK             = 0X01,
    EN_OGCT_METHOD_ENCKEY               = 0X11,
    EN_OGCT_METHOD_NATP2P               = 0X20,   // 通道建立  p2p 内部
    EN_OGCT_METHOD_VODPLAY              = 0X21,   // 媒体点播  p2p 内部
    EN_OGCT_METHOD_MULMEDIA             = 0X22,   // 流媒体

    EN_OGCT_METHOD_CN21_CMD             = 0X23,   // 21cn p2p 内部cmd
    EN_OGCT_METHOD_CN21_MULMEDIA        = 0X24,   // 流媒体

    EN_OGCT_METHOD_LOCALLAN             = 0X31,  // 本地网络    p2p内部
    EN_OGCT_METHOD_DEVPLAT              = 0x32,  // 平台的注册和登录类
    EN_OGCT_METHOD_CFGBUSS              = 0X33,  // 配置业务
    EN_OGCT_METHOD_CMDMSG               = 0X34,  // 命令类
    
    EN_OGCT_METHOD_CLOUDEVENT           = 0X35, // 云事件
    EN_OGCT_METHOD_CLOUDFILE            = 0X36, // 云文件
    EN_OGCT_METHOD_GROUP                = 0X37, // 组信息
    EN_OGCT_METHOD_EXTERNFUNC           = 0X38, // 扩展
    
    EN_OGCT_METHOD_USERPLAT             = 0x41, //用户平台
    
    EN_OGCT_METHOD_USERAI               = 0x43, //AI

    EN_OGCT_METHOD_DEVAI                = 0x44, //AI

    EN_OGCT_METHOD_DATA                 = 0x50, // 媒体 数据  p2p 内

	EN_OGCT_METHOD_PRIVATE              = 0x51, //用户自定义私有传输

    EN_OGCT_METHOD_GETCLOUDINFO         = 0x60,

    EN_OGCT_METHOD_21CN_REG             = 0x62, //register 21cn platform

    EN_OGCT_METHOD_21CN_P2P_CMD         = 0x64, //get terminal sdp info

    EN_OGCT_METHOD_DEVTRACK             = 0x70, //行车轨迹
    EN_OGCT_METHOD_KEEPALIVE            = 0XFF
  
}EN_OGCT_METHOD_TYPE;

typedef enum enum_OGCT_METHOD_ENCKEY_MSG
{
    EN_OGCT_METHOD_ENCKEY_ERR_REQ = 0X10,
    EN_OGCT_METHOD_ENCKEY_ERR_RSP = 0X11, 
}EN_OGCT_METHOD_ENCKEY_MSG;


/*********************************************************************
 p2p平台p2p relay 类 0x64
**********************************************************************/
#ifdef  OLD_P2P_SERVER
typedef enum enum_CN21_P2P_MSG
{
    //0x64 types
    EN_CN21_P2P_GETSDP_REQ              = 0X10, //get device sdp info
    EN_CN21_P2P_GETSDP_RESP             = 0X11,

    //0x62 types
    EN_CN21_P2P_LOGIN_REQ               = 0X13, //login message server
    EN_CN21_P2P_LOGIN_RESP              = 0X14,

}EN_CN21_P2P_REALY_CMD_MSG;
#else
typedef enum enum_CN21_P2P_MSG
{
    //0x64 types
    EN_CN21_P2P_SETSDP_REQ              = 0X10, //app send sdp info
    EN_CN21_P2P_SETSDP_RESP             = 0X11,

    EN_CN21_P2P_SENDSDP_REQ             = 0X12, //device send sdp info
    EN_CN21_P2P_SENDSDP_RESP            = 0X13,

    EN_CN21_P2P_CONNECTPRE_REQ          = 0X14, //device send sdp info
    EN_CN21_P2P_CONNECTPRE_RESP         = 0X15,

    EN_CN21_P2P_REPORT_P2P_STATUS_REQ   = 0X18, //report p2p status
    EN_CN21_P2P_REPORT_P2P_STATUS_RESP  = 0X19,

    EN_CN21_P2P_GET_ONLINE_NUMBER_REQ   = 0X20, //get online client number
    EN_CN21_P2P_GET_ONLINE_NUMBER_RESP  = 0X21,

    EN_CN21_P2P_APP_SEND_SDP_REQ        = 0X22, //client send sdp
    EN_CN21_P2P_APP_SEND_SDP_RESP       = 0X23,

    EN_CN21_P2P_DEV_SEND_SDP_REQ        = 0X24, //dev send sdp
    EN_CN21_P2P_DEV_SEND_SDP_RESP       = 0X25,
}EN_CN21_P2P_REALY_CMD_MSG;
#endif

/*********************************************************************
 p2p keep alive
**********************************************************************/
typedef enum enum_CN21_P2P_KEEPALIVE_MSG
{
    //0x64 types
    EN_CN21_P2P_KEEPALIVE_REQ              = 0XFF, //get device sdp info
    EN_CN21_P2P_KEEPALIVE_FORCE            = 0X00,
    EN_CN21_P2P_FEEDBACK_REQ               = 0X01, //resend data feedback
}EN_CN21_P2P_KEEPALIVE_CMD_MSG;

/*********************************************************************
 p2p平台internal命令类 EN_OGCT_METHOD_CN21_CMD
**********************************************************************/
typedef enum enum_EN_OGCT_METHOD_CN21_CMD
{
    EN_CN21_P2P_CMD_GETDEVINFO_REQ          = 0X10,//get dev info
    EN_CN21_P2P_CMD_GETDEVINFO_RESP         = 0X11,

    EN_CN21_P2P_CMD_STARTMEDIA_REQ          = 0X12,//start video & audio
    EN_CN21_P2P_CMD_STARTMEDIA_RESP         = 0X13,

    EN_CN21_P2P_CMD_STOPMEDIA_REQ           = 0X14,//close video & media
    EN_CN21_P2P_CMD_STOPMEDIA_RESP          = 0X15,

    EN_CN21_P2P_CMD_STARTSPEAK_REQ          = 0X16,//start audio speak
    EN_CN21_P2P_CMD_STARTSPEAK_RESP         = 0X17,

    EN_CN21_P2P_CMD_STOPSPEAK_REQ           = 0X18,//close audio speak
    EN_CN21_P2P_CMD_STOPTSPEAK_RESP         = 0X19,

    EN_CN21_P2P_CMD_GETRECORDCALENDER       = 0X1A,  //获取录像日历
    EN_CN21_P2P_CMD_GETRECORDCALENDER_RSP   = 0X1B,

    EN_CN21_P2P_CMD_GETRECORDLIST           = 0X1C,  //获取录像列表
    EN_CN21_P2P_CMD_GETRECORDLIST_RSP       = 0X1D,

    EN_CN21_P2P_CMD_GETJPGCANLEADER         = 0X1E,  //获取抓图的日历
    EN_CN21_P2P_CMD_GETJPGCANLENDER_RSP     = 0X1F,

    EN_CN21_P2P_CMD_GETJPGLIST              = 0X20,  //获取抓图列表
    EN_CN21_P2P_CMD_GETJPGLIST_RSP          = 0X21,

    EN_CN21_P2P_CMD_PLAYBACK_START_REQ      = 0X22,//start plaback video & media
    EN_CN21_P2P_CMD_PLAYBACK_START_RESP     = 0X23,

    EN_CN21_P2P_CMD_PLAYBACK_CONTROL_REQ    = 0X24,//control plaback video & media
    EN_CN21_P2P_CMD_PLAYBACK_CONTROL_RESP   = 0X25,

    EN_CN21_P2P_CMD_PLAYBACK_STOP_REQ       = 0X26,//stop plaback video & media
    EN_CN21_P2P_CMD_PLAYBACK_STOP_RESP      = 0X27,

    EN_CN21_P2P_CMD_P2PSESSION_CLOSE_REQ    = 0X28,//close p2p channel
    EN_CN21_P2P_CMD_P2PSESSION_CLOSE_RESP   = 0X29,

    EN_CN21_P2P_CMD_STARTDISPLAY_REQ        = 0X2A,//start video display
    EN_CN21_P2P_CMD_STARTDISPLAY_RESP       = 0X2B,

    EN_CN21_P2P_CMD_CONTORLDISPLAY_REQ      = 0X2C,//contorl video display
    EN_CN21_P2P_CMD_CONTORLDISPLAY_RESP     = 0X2D,

    EN_CN21_P2P_CMD_STOPDISPLAY_REQ         = 0X2E,//close video display
    EN_CN21_P2P_CMD_STOPTDISPLAY_RESP       = 0X2F,

    EN_CN21_P2P_CMD_START_NAT4HOLE_REQ      = 0X30,//start nat3-nat4 hole req
    EN_CN21_P2P_CMD_START_NAT4HOLE_RESP     = 0X31,

    EN_CN21_P2P_CMD_CLIENT_NAT4_INF_REQ     = 0X32,//client sirfix info req
    EN_CN21_P2P_CMD_CLIENT_NAT4_INF_RESP    = 0X33,

    EN_CN21_P2P_CMD_DEVICE_NAT4_INF_REQ     = 0X34,//device sirfix info req
    EN_CN21_P2P_CMD_DEVICE_NAT4_INF_RESP    = 0X35,

    EN_CN21_P2P_CMD_SELECT_CNTID_REQ        = 0X36,//client sirfix info req
    EN_CN21_P2P_CMD_SELECT_CNTID_RESP       = 0X37
}EN_CN21_P2P_CMD_MSG;

//媒体数据定义类型 0x50
typedef enum enum_OGCT_MEDIA_DATA_MSG{
    EN_OGCT_MEDIA_DATA_LIVESTREAM       = 0x10,
    EN_OGCT_MEDIA_DATA_RECORDSTREAM     = 0x11,
    EN_OGCT_MEDIA_DATA_FILEDATA         = 0x12, //图片，日志，声音文件
    EN_OGCT_MEDIA_DATA_PUSHSTREAM       = 0x13,
    EN_OGCT_MEDIA_DATA_MULTIMEDIA       = 0X14,
    EN_OGCT_MEDIA_DATA_PLAYBACK         = 0X15,

    EN_OGCT_MEDIA_DATA_ACK              = 0x20,
    EN_OGCT_MEDIA_DATA_REQ              = 0x21, //请求重传
    EN_OGCT_MEDIA_DATA_PARAM            = 0x30
}EN_OGCT_MEDIA_DATA_MSG;


/*EN_OGCT_METHOD_NATP2P 0X20 */
typedef enum enum_OGCT_METHOD_NATP2P_MSG
{
    EN_OGCT_NATP2P_GETNATSERV_REQ        = 0X10,  // 获取nat 检测服务器
    EN_OGCT_NATP2P_GETNATSERV_RSP        = 0X11,

    EN_OGCT_NATP2P_GETPROXY_REQ           = 0X12, // 获取proxy 服务器
    EN_OGCT_NATP2P_GETPROXY_RSP           = 0X13,
 
    EN_OGCT_NATP2P_GETPROXY_NTC            = 0X14, // 通知设备开始连接proxy
    EN_OGCT_NATP2P_GETPROXY_NTC_RSP        = 0X15,

    EN_OGCT_NATP2P_DEV_CONNPROXY           = 0X16, // 设备 连接proxy
    EN_OGCT_NATP2P_DEV_CONNPROXY_RSP       = 0X17,

    EN_OGCT_NATP2P_USER_CONNPROXY          = 0X18, // 用户连接proxy
    EN_OGCT_NATP2P_USER_CONNPROXY_RSP      = 0X19,

    EN_OGCT_NATP2P_NATTYPECHECK            = 0X1A, // nat 类型检测
    EN_OGCT_NATP2P_NATTYPECHECK_RSP        = 0X1B,

    EN_OGCT_NATP2P_CONETYPECHECK           = 0X1C, // cone 具体类型检测 终端到服务器
    EN_OGCT_NATP2P_CONETYPECHECK_RSP       = 0X1D,
 
    EN_OGCT_NATP2P_GETP2PINF_REQ           = 0X1E, // 用户获取设备的p2p信息
    EN_OGCT_NATP2P_GETP2PINF_RSP           = 0X1F,

    EN_OGCT_NATP2P_CONETEST                = 0X20, // 服务器向终端 发送探测指令
    EN_OGCT_NATP2P_CONETEST_RSP            = 0X21,

    EN_OGCT_NATP2P_HOLETEST                = 0X22, // 连接校验请求
    EN_OGCT_NATP2P_HOLETEST_RSP            = 0X23,

    EN_OGCT_NATP2P_CONFIRM                  = 0x24,

    EN_OGCT_NATP2P_GETNATINFO_REQ           = 0x26,
    EN_OGCT_NATP2P_GETNATINFO_RSP           = 0x27,

    EN_OGCT_NATP2P_GETODPROXY_REQ           = 0x30,
    EN_OGCT_NATP2P_GETODPROXY_RSP           = 0x31

}EN_OGCT_METHOD_NATP2P_MSG;

/*EN_OGCT_METHOD_VODPLAY 0X21 */
typedef enum enum_OGCT_METHOD_VOD_MSG
{
    EN_OGCT_METHOD_VOD_CREAT_ALIVE          = 0X10,
    EN_OGCT_METHOD_VOD_CREAT_ALIVE_RSP      = 0X11, 

    EN_OGCT_METHOD_VOD_CREAT_RECORD         = 0X12,
    EN_OGCT_METHOD_VOD_CREAT_RECORD_RSP     = 0X13, 

    EN_OGCT_METHOD_VOD_CREAT_CAMPIC         = 0X14,
    EN_OGCT_METHOD_VOD_CREAT_CAMPIC_RSP     = 0X15,

    EN_OGCT_METHOD_VOD_CREAT_LOGFILE        = 0X16,
    EN_OGCT_METHOD_VOD_CREAT_LOGFILE_RSP    = 0X17,

    EN_OGCT_METHOD_VOD_CREAT_PUSHLIVE       = 0X18,
    EN_OGCT_METHOD_VOD_CREAT_PUSHLIVE_RSP   = 0X19,

    EN_OGCT_METHOD_VOD_CREAT_SOUNDFILE      = 0X1A,
    EN_OGCT_METHOD_VOD_CREAT_SOUNDFILE_RSP  = 0X1B,

    EN_OGCT_METHOD_VOD_CONTROL              = 0X1C,

    EN_OGCT_METHOD_VOD_CLOSE                = 0X1E,

    EN_OGCT_METHOD_VOD_CREAT_AIPIC          = 0X20,
    EN_OGCT_METHOD_VOD_CREAT_AIPIC_RSP      = 0X21,
}EN_OGCT_METHOD_VOD_MSG;

// 多媒体服务器
typedef enum enum_ogct_mulmedia_msg
{
    EN_OGCT_MULMEDIA_USR_GETADDR           = 0X10,
    EN_OGCT_MULMEDIA_USR_GETADDR_RSP       = 0X11,

    EN_OGCT_MULMEDIA_DEV_ADDR_NTC          = 0X12, // 设备分配流媒体地址
    EN_OGCT_MULMEDIA_DEV_ADDR_NTC_RSP      = 0X13,

    EN_OGCT_MULMEDIA_DEV_LOGIN             = 0X14,  //设备登录 流媒体服务器
    EN_OGCT_MULMEDIA_DEV_LOGIN_RSP         = 0x15,

    EN_OGCT_MULMEDIA_APP_GETADDR           = 0X16,
    EN_OGCT_MULMEDIA_APP_GETADDR_RSP       = 0X17,

    EN_OGCT_MULMEDIA_APP_LOGIN             = 0X18, // 客户端请求流媒体地址
    EN_OGCT_MULMEDIA_APP_LOGIN_RSP         = 0X19,

    EN_OGCT_MULMEDIA_START_PUSH            = 0X1A, // 请求推流
    EN_OGCT_MULMEDIA_START_PUSH_RSP        = 0X1B,

    EN_OGCT_MULMEDIA_PAUSE_PUSH            = 0X1C, // 暂停
    EN_OGCT_MULMEDIA_PAUSE_PUSH_RSP        = 0X1D,

    EN_OGCT_MULMEDIA_RESUME_PUSH           = 0X1E, // 恢复播放
    EN_OGCT_MULMEDIA_RESUME_PUSH_RSP       = 0X1F,

    EN_OGCT_MULMEDIA_NEED_KEYFRAME         = 0X20, // 关键帧
    EN_OGCT_MULMEDIA_NEED_KEYFRAME_RSP     = 0X21,

    EN_OGCT_MULMEDIA_UPDATE_KEY_NTC        = 0X22, // 更新秘钥
    EN_OGCT_MULMEDIA_UPDATE_KEY_NTC_RSP    = 0X23,

    EN_OGCT_MULMEDIA_APP_START_STREAM      = 0X24, // APP 点播
    EN_OGCT_MULMEDIA_APP_START_STREAM_RSP  = 0X25,

    EN_OGCT_MULMEDIA_CLOSE_STREAM          = 0X26, // 关闭流
    EN_OGCT_MULMEDIA_CLOSE_STREAM_RSP      = 0X27,

    EN_OGCT_MULMEDIA_DEV_ADDR_CLEAN_NTC      = 0X28, // 设备分配流媒体地址
    EN_OGCT_MULMEDIA_DEV_ADDR_CLEAN_NTC_RSP  = 0X29,

    EN_OGCT_MULMEDIA_OPEN_AUDIO_REVERSE_STREAM       = 0X36, // 开语音
    EN_OGCT_MULMEDIA_OPEN_AUDIO_REVERSE_STREAM_RSP   = 0X37,

    EN_OGCT_MULMEDIA_CLOSE_AUDIO_REVERSE_STREAM      = 0X38, // 关语音
    EN_OGCT_MULMEDIA_CLOSE_AUDIO_REVERSE_STREAM_RSP  = 0X39,

    EN_OGCT_MULMEDIA_PLAYBACK_ADDR_NTC      = 0X40, // 卡回放分配
    EN_OGCT_MULMEDIA_PLAYBACK_ADDR_NTC_RSP  = 0X41,

    EN_OGCT_MULMEDIA_PLAYBACK_LOGIN         = 0X42, // 卡回放登录
    EN_OGCT_MULMEDIA_PLAYBACK_LOGIN_RSP     = 0x43,

    EN_OGCT_MULMEDIA_PLAYBACK_CLOSE         = 0X44, // 卡回放关闭
    EN_OGCT_MULMEDIA_PLAYBACK_CLOSE_RSP     = 0x45,

    EN_OGCT_MULMEDIA_PLAYBACK_CONTROL       = 0X48, // 卡回放 control plaback video & media
    EN_OGCT_MULMEDIA_PLAYBACK_CONTROL_RSP   = 0X49,    
}EN_OGCT_MULMEDIA_MSG;


/* 广播消息 0x31*/
typedef enum enum_OGCT_LOCALLAN_MSG
{
    EN_OGCT_LOCALLAN_DEVSEARCH          = 0X10, // 设备发现 主要应用于 设备添加

    EN_OGCT_LOCALLAN_BROADCAST          = 0X12, //  用户或者设备起来触发广播

    EN_OGCT_LOCALLAN_DEVICE_TCP_REQ     = 0X14, //设备主动握手用户
    EN_OGCT_LOCALLAN_DEVICE_TCP_RSP     = 0x15,

    EN_OGCT_LOCALLAN_USER_TCP_REQ       = 0X16, //APP主动握手设备
    EN_OGCT_LOCALLAN_USER_TCP_RSP       = 0x17,

    EN_OGCT_LOCALLAN_SETWIFI_OK         = 0X20, // 设备配网成功
}EN_OGCT_LOCALLAN_MSG;

/* 平台鉴权类消息 0x32*/
typedef enum enum_ogct_devplat_msg
{
    EN_OGCT_DEVPLAT_SIGN_REGIST       = 0X10, // 设备平台接入
    EN_OGCT_DEVPLAT_SIGN_REGIST_RSP   = 0X11,

    EN_OGCT_DEVPLAT_LINK_REGSIT       = 0X12, // 设备注册
    EN_OGCT_DEVPLAT_LINK_REGSIT_RSP   = 0X13,

    EN_OGCT_DEVPLAT_LINK_LOGIN        = 0X14, // 设备登录
    EN_OGCT_DEVPLAT_LINK_LOGIN_RSP    = 0X15,

    EN_OGCT_DEVPLAT_LINK_ADDRCHG_NTC      = 0X16,  // 设备地址变更
    EN_OGCT_DEVPLAT_LINK_ADDRCHG_NTC_RSP  = 0X17,

    EN_OGCT_DEVPLAT_LINK_KEYCHG_NTC          = 0X18,  // 设备秘钥变更
    EN_OGCT_DEVPLAT_LINK_KEYCHG_NTC_RSP      = 0X19,
    
    EN_OGCT_DEVPLAT_LINK_BINDDEV            = 0X1C,  //自己link平台bindcode绑定
    EN_OGCT_DEVPLAT_LINK_BINDDEV_RSP        = 0X1D,

    EN_OGCT_DEVPLAT_ZJCMD_BINDDEV            = 0X20,  // 智家平台绑定
    EN_OGCT_DEVPLAT_ZJCMD_BINDDEV_RSP        = 0X21,
    
    EN_OGCT_DEVPLAT_ZJMNG_REGIST             = 0X40,  // 智家 平台
    EN_OGCT_DEVPLAT_ZJMNG_REGIST_RSP         = 0X41,

    EN_OGCT_DEVPLAT_ZJABILIT_REGIST          = 0X42,  // 能力平台  HTTPS
    EN_OGCT_DEVPLAT_ZJABILITY_REGIST_RSP     = 0X43,

    EN_OGCT_DEVPLAT_ZJCMD_LOGIN              = 0X44,  // 能力平台登录 tcp
    EN_OGCT_DEVPLAT_ZJCMD_LOGIN_RSP          = 0X45,

    EN_OGCT_DEVPLAT_ZJCMDADDR_GET            = 0X46,  //重新获取信令服务器地址 HTTPS
    EN_OGCT_DEVPLAT_ZJCMDADDR_GET_RSP        = 0X47

}EN_OGCT_DEVPLAT_MSG;

/*********************************************************************
配置业务 0X33
**********************************************************************/
typedef enum enum_OGCT_CFGBUSS_MSG
{
    EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD          = 0X10, // 设备能力上报
    EN_OGCT_CFGBUSS_DEVABILITY_UPLOAD_RSP      = 0X11,     

    EN_OGCT_CFGBUSS_DEVBUSS_UPLOAD             = 0X12, // 设备配置上报
    EN_OGCT_CFGBUSS_DEVBUSS_UPLOAD_RSP         = 0X13, 

    EN_OGCT_CFGBUSS_DEVSTATUS_UPDATE           = 0X14, // 状态上报
    EN_OGCT_CFGBUSS_DEVSTATUS_UPDATE_RSP       = 0X15,

    EN_OGCT_CFGBUSS_DEVBUSS_NOTICE             = 0X16, // 配置变更通知 携带配置信息 服务器通知客户端
    EN_OGCT_CFGBUSS_DEVBUSS_NOTICE_RSP         = 0X17, 

    EN_OGCT_CFGBUSS_DEVBUSS_UPDATE             = 0X18, // 配置更新到服务器,只更新条目
    EN_OGCT_CFGBUSS_DEVBUSS_UPDATE_RSP         = 0X19,

    EN_OGCT_CFGBUSS_DEVCHARGE_NOTICE           = 0X1A, // 增值服务更新
    EN_OGCT_CFGBUSS_DEVCHARGE_NOTICE_RSP       = 0X1B, 

    EN_OGCT_CFGBUSS_P2P_CFGSYNC                = 0X1C, // 客户端请求设备的配置
    EN_OGCT_CFGBUSS_P2P_CFGSYNC_RSP            = 0X1D, 

    EN_OGCT_CFGBUSS_UPLOGFILE_NOTICE           = 0X1E, // 开始上传配置
    EN_OGCT_CFGBUSS_UPLOGFILE_NOTICE_RSP       = 0X1F,

    EN_OGCT_CFGBUSS_OWNERINF_UPDATA            = 0X20, // 用户信息上报
    EN_OGCT_CFGBUSS_OWNERINF_UPDATA_RSP        = 0X21, 

    EN_OGCT_CFGBUSS_OWNERINF_DOWN              = 0X22, // 用户信息下载
    EN_OGCT_CFGBUSS_OWNERINF_DOWN_RSP          = 0X23,  

    EN_OGCT_CFGBUSS_PUSHTOKEN_UP               = 0X24, // 用户信息下载
    EN_OGCT_CFGBUSS_PUSHTOKEN_UP_RSP           = 0X25,   
    
    EN_OGCT_CFGBUSS_USRCHARGE_REQ              = 0X26, //用户套餐获取
    EN_OGCT_CFGBUSS_USRCHARGE_RSP              = 0X27,   
    
    EN_OGCT_CFGBUSS_USRINFCHAGE_NOTICE         = 0X28, //用户套餐获取
    EN_OGCT_CFGBUSS_USRINFCHAGE_NOTICE_RSP     = 0X29,  
    
    EN_OGCT_CFGBUSS_UPDATESTATTUS              = 0X30, // 升级进度 汇报
    EN_OGCT_CFGBUSS_UPDATESTATTUS_RSP          = 0X31,

    EN_OGCT_CFGBUSS_UPDATE_NTC                 = 0X32, // 升级通知
    EN_OGCT_CFGBUSS_UPDATE_NTC_RSP             = 0X33,

    EN_OGCT_CFGBUSS_VERSION_CHECK              = 0X34, // 版本检测
    EN_OGCT_CFGBUSS_VERSION_CHECK_RSP          = 0X35,

    EN_OGCT_CFGBUSS_USRSETDEV_PACKAGE          = 0X36, //用户给设备赋值套餐
    EN_OGCT_CFGBUSS_USRSETDEV_PACKAGE_RSP      = 0X37, 

    EN_OGCT_CFGBUSS_USRGETDEV_PACKAGE          = 0X38, //用户查询设备套餐
    EN_OGCT_CFGBUSS_USRGETDEV_PACKAGE_RSP      = 0X39,

    EN_OGCT_CFGBUSS_USRSMSPACKAGE_REQ          = 0X3A,  //查询用户短信套餐
    EN_OGCT_CFGBUSS_USRSMSPACKAGE_RSP          = 0X3B, 

    EN_OGCT_CFGBUSS_USRGET4GPACKAGE_REQ        = 0X3C,  //用户获取4G设备流量套餐
    EN_OGCT_CFGBUSS_USRGET4GPACKAGE_RSP        = 0X3D,

    EN_OGCT_CFGBUSS_DEV4GFLOWUPLOAD_REQ        = 0X3E,  //设备上报4g流量使用数目
    EN_OGCT_CFGBUSS_DEV4GFLOWUPLOAD_RSP        = 0X3F,

    EN_OGCT_CFGBUSS_CLOUDPOLICY_NTC            = 0X40,   //平台通知设备云套餐发生变化
    EN_OGCT_CFGBUSS_CLOUDPOLICY_NTC_RSP        = 0X41,

    EN_OGCT_CFGBUSS_CLOUDCFG_NTC               = 0X42,   //修改设备云存配置
    EN_OGCT_CFGBUSS_CLOUDCFG_NTC_RSP           = 0X43,
    
    EN_OGCT_PLATCMD_EVENTCLOUD                 = 0x48,   // 事件云存追加逻辑
    EN_OGCT_PLATCMD_EVENTCLOUD_RSP             = 0x49,

    EN_OGCT_CFGBUSS_QUERY_IMS_CONFIG           = 0X44,   //IMS业务配置查询
    EN_OGCT_CFGBUSS_QUERY_IMS_CONFIG_RSP       = 0X45,

    EN_OGCT_PLATCMD_SETIMSBUSINESSCFG          = 0X46,   //下发IMS业务配置  
    EN_OGCT_PLATCMD_SETIMSBUSINESSCFG_RSP      = 0X47,
    EN_OGCT_CFGBUSS_LIMITFLOW_NTC              = 0X80,   //通知设备限制流量notice
    EN_OGCT_CFGBUSS_LIMITFLOW_NTC_RSP          = 0X81,

    EN_OGCT_CFGBUSS_GTEDTS                     = 0x82,   //获取夏令时
    EN_OGCT_CFGBUSS_GETDTS_RSP                 = 0X83,

}EN_OGCT_DEVBUSS_MSG;


/*********************************************************************
平台命令类 0x34
**********************************************************************/
typedef enum enum_OGCT_PLATCMD_MSG
{ 
    EN_OGCT_PLATCMD_SUPERCODES              = 0X04, // 超级编码开关
    EN_OGCT_PLATCMD_SUPERCODES_RSP          = 0X05,    
    
    EN_OGCT_PLATCMD_NETWORK_CHECK           = 0x06, // 全链路感知排障
    EN_OGCT_PLATCMD_NETWORK_CHECK_RSP       = 0x07,

    EN_OGCT_PLATCMD_IPV6SWITCH              = 0X08, // IPv6开关
    EN_OGCT_PLATCMD_IPV6SWITCH_RSP          = 0X09,

    EN_OGCT_PLATCMD_SETOSDCOMMONINF         = 0X0A, // 设备OSD默认(时间)水印设置
    EN_OGCT_PLATCMD_SETOSDCOMMONINF_RSP     = 0X0B, 

    EN_OGCT_PLATCMD_SET_GETOUTERIPINF       = 0X0C, // 对设备获取外网IP操作涉及的参数配置
    EN_OGCT_PLATCMD_SET_GETOUTERIPINF_RSP   = 0X0D, 

    EN_OGCT_PLATCMD_UPLOAD_DEVSTATUS        = 0X10, // 设备状态（休眠、唤醒）上报
    EN_OGCT_PLATCMD_UPLOAD_DEVSTATUS_RSP    = 0X11, 

    EN_OGCT_PLATCMD_REBOOT                  = 0X12, // 远程重启
    EN_OGCT_PLATCMD_REBOOT_RSP              = 0X13, 

    EN_OGCT_PLATCMD_CHEACKVERSION           = 0X14,  // 远程升级
    EN_OGCT_PLATCMD_CHEACKVERSION_RSP       = 0X15, 

    EN_OGCT_PLATCMD_FACTORYSETTING          = 0X16,  // 恢复出厂设置
    EN_OGCT_PLATCMD_FACTORYSETTING_RSP      = 0X17, 

    EN_OGCT_PLATCMD_VENCODE_PARAM           = 0X18,  // 视频编码参数
    EN_OGCT_PLATCMD_VENCODE_PARAM_RSP       = 0X19, 

    EN_OGCT_PLATCMD_INVERSION               = 0X1A,  // 图像翻转
    EN_OGCT_PLATCMD_INVERSION_RSP           = 0X1B, 

    EN_OGCT_PLATCMD_SETOSD                  = 0X1C,  // 设备OSD自定义(文本)水印信息设置
    EN_OGCT_PLATCMD_SETOSD_RSP              = 0X1D, 

    EN_OGCT_PLATCMD_CAMSTATUS               = 0X1E,  // CAM 的 开关
    EN_OGCT_PLATCMD_CAMSTATUS_RSP           = 0X1F, 

    EN_OGCT_PLATCMD_SETPTZPROP              = 0X20,  // PTZ的PROP
    EN_OGCT_PLATCMD_SETPTZPROP_RSP          = 0X21, 

    EN_OGCT_PLATCMD_SETPRESET               = 0X22,  // PTZ的预置点
    EN_OGCT_PLATCMD_SETPRESET_RSP           = 0X23, 

    EN_OGCT_PLATCMD_SETCRUISE               = 0X24,  // PTZ的巡航轨迹
    EN_OGCT_PLATCMD_SETCRUISE_RSP           = 0X25, 

    EN_OGCT_PLATCMD_SETWATCHPOINT           = 0X26,  // PTZ的看守位
    EN_OGCT_PLATCMD_SETWATCHPOINT_RSP       = 0X27, 

    EN_OGCT_PLATCMD_CONTRLPTZ               = 0X28,  // PTZ的控制
    EN_OGCT_PLATCMD_CONTRLPTZ_RSP           = 0X29,

    EN_OGCT_PLATCMD_SETAUDIOPARAM           = 0X2A,  // 音频编码参数
    EN_OGCT_PLATCMD_SETAUDIOPARAM_RSP       = 0X2B,

    EN_OGCT_PLATCMD_LOCALRECORD             = 0X2C,  // 本地录制参数
    EN_OGCT_PLATCMD_LOCALRECORD_RSP         = 0X2D,

    EN_OGCT_PLATCMD_IRMODE                  = 0X2E,  // 红外灯
    EN_OGCT_PLATCMD_IRMODE_RSP              = 0X2F,

    EN_OGCT_PLATCMD_CTRLKJIOT               = 0X30,  // IOT 设备控制
    EN_OGCT_PLATCMD_CTRLKJIOT_RSP           = 0X31,

    EN_OGCT_PLATCMD_SETINIOTPROP            = 0X32,  // 内置功能的prop
    EN_OGCT_PLATCMD_SETINIOTPROP_RSP        = 0X33,

    EN_OGCT_PLATCMD_SETMICOPENFLA           = 0X34,  // mic OPEN
    EN_OGCT_PLATCMD_SETMICOPENFLAG_RSP      = 0X35,

    EN_OGCT_PLATCMD_TIMER_POLICY            = 0X36,  //定时策略
    EN_OGCT_PLATCMD_TIMER_POLICY_RSP        = 0X37,

    EN_OGCT_PLATCMD_ALARM_POLICY            = 0X38,  //报警策略
    EN_OGCT_PLATCMD_ALARM_POLICY_RSP        = 0X39,

    EN_OGCT_PLATCMD_CLEAN_SERVADDR          = 0X3A,  //清除地址缓存
    EN_OGCT_PLATCMD_CLEAN_SERVADDR_RSP      = 0X3B,

    EN_OGCT_PLATCMD_SET_TIMEANDZONE          = 0X3C,  //同步本地时间
    EN_OGCT_PLATCMD_SET_TIMEANDZONE_RSP      = 0X3D,

    EN_OGCT_PLATCMD_GET_TIMEANDZONE          = 0X3E,  //获取本地时间
    EN_OGCT_PLATCMD_GET_TIMEANDZONE_RSP      = 0X3F,

    EN_OGCT_PLATCMD_PTZCHECK                  = 0X48,  //PTZ 自检
    EN_OGCT_PLATCMD_PTZCHECK_RSP              = 0X49,

    EN_OGCT_PLATCMD_SETAWAKETIME              = 0X4A,  //设备休眠时间
    EN_OGCT_PLATCMD_SETAWAKETIME_RSP          = 0X4B,

    EN_OGCT_PLATCMD_FORMATTFCRAD              = 0X4C,  //格式化TF 卡
    EN_OGCT_PLATCMD_FORMATTFCRAD_RSP          = 0X4D,

    EN_OGCT_PLATCMD_GETTFCRADINF              = 0X4E,  //查询TF信息
    EN_OGCT_PLATCMD_GETTFCRADINF_RSP          = 0X4F,
  
    EN_OGCT_PLATCMD_SWITCHLEN                 = 0X50,  //切换镜头
    EN_OGCT_PLATCMD_SWITCHLEN_RSP             = 0X51,

    EN_OGCT_PLATCMD_ADDDEVTOHUB               = 0X52,  // 添加433 列表
    EN_OGCT_PLATCMD_ADDDEVTOHUB_RSP           = 0X53,

    EN_OGCT_PLATCMD_GETIOTSTATUSLIST          = 0X54,  //获取433 列表的 状态
    EN_OGCT_PLATCMD_GETIOTSTATUSLIST_RSP      = 0X55,

    EN_OGCT_PLATCMD_SETHUBDEVPROP             = 0X56,  //设置433 的属性
    EN_OGCT_PLATCMD_SETHUBDEVPROP_RSP         = 0X57,

    EN_OGCT_PLATCMD_DELHUBDEV                 = 0X58,  //删除某一个433
    EN_OGCT_PLATCMD_DELHUBDEV_RSP             = 0X59,

    EN_OGCT_PLATCMD_DELALLHUBDEV              = 0X5A,  //433 全部删除
    EN_OGCT_PLATCMD_DELALLHUBDEV_RSP          = 0X5B,

    EN_OGCT_PLATCMD_SETLOGFILELIVEL           = 0X60,  //日志上传级别
    EN_OGCT_PLATCMD_SETLOGFILELIVEL_RSP       = 0X61,
    
    EN_OGCT_PLATCMD_QUERYSTATUS               = 0X62,  //状态查询
    EN_OGCT_PLATCMD_QUERYSTATUS_RSP           = 0X63,

    EN_OGCT_PLATCMD_SETDEVNAME                = 0X66,  //设置设备名称
    EN_OGCT_PLATCMD_SETDEVNAME_RSP            = 0X67,

    EN_OGCT_PLATCMD_PLAYALARM                 = 0X68,  //播放报警
    EN_OGCT_PLATCMD_PLAYALARM_RSP             = 0X69,

    EN_OGCT_PLATCMD_SETBELLFLAG               = 0X6A,  //门铃强拆
    EN_OGCT_PLATCMD_SETBELLFLAG_RSP           = 0X6B,

    EN_OGCT_PLATCMD_SETWAITALARM              = 0X6C,  //门铃逗留报警
    EN_OGCT_PLATCMD_SETWAITALARM_RSP          = 0X6D,
   
    EN_OGCT_PLATCMD_SETWDR                    = 0X6E,  //门铃宽动态
    EN_OGCT_PLATCMD_SETWDR_RSP                = 0X6F,

    EN_OGCT_PLATCMD_SETWIFI                   = 0X70,  //设备wifi
    EN_OGCT_PLATCMD_SETWIFI_RSP               = 0X71,

    EN_OGCT_PLATCMD_GETCURNATINF              = 0X72,  //获取当前网络信息
    EN_OGCT_PLATCMD_GETCURNATINF_RSP          = 0X73,

    EN_OGCT_PLATCMD_GETWIFILIST               = 0X74,  //获取wifi 列表
    EN_OGCT_PLATCMD_GETWIFILIST_RSP           = 0X75,

    EN_OGCT_PLATCMD_GETEVENTCALENDER          = 0X76,  //获取事件时间记录
    EN_OGCT_PLATCMD_GETEVENTCALENDER_RSP      = 0X77,

    EN_OGCT_PLATCMD_GETEVENTLIST              = 0X78,  //获取事件 列表
    EN_OGCT_PLATCMD_GETEVENTLIST_RSP          = 0X79,

    EN_OGCT_PLATCMD_GETRECORDCALENDER         = 0X7A,  //获取录像日历
    EN_OGCT_PLATCMD_GETRECORDCALENDER_RSP     = 0X7B,

    EN_OGCT_PLATCMD_GETRECORDLIST             = 0X7C,  //获取录像列表
    EN_OGCT_PLATCMD_GETRECORDLIST_RSP         = 0X7D,

    EN_OGCT_PLATCMD_GETJPGLIST                = 0X7E,  //获取抓图列表
    EN_OGCT_PLATCMD_GETJPGLIST_RSP            = 0X7F,

    EN_OGCT_PLATCMD_GETJPGCANLEADER           = 0X80,  //获取抓图的日历
    EN_OGCT_PLATCMD_GETJPGCANLENDER_RSP       = 0X81,

    EN_OGCT_PLATCMD_ADDDEVICEBYAP             = 0X82,  //AP配网
    EN_OGCT_PLATCMD_ADDDEVICEBYAP_RSP         = 0X83,

    EN_OGCT_PLATCMD_STARTUPGRADE              = 0X84,  //开始升级
    EN_OGCT_PLATCMD_STARTUPGRADE_RSP          = 0X85,

    EN_OGCT_PLATCMD_STOPUPGRADE               = 0X86,  //停止升级
    EN_OGCT_PLATCMD_STOPUPGRADE_RSP           = 0X87,

    EN_OGCT_PLATCMD_SETBELLQUICKREPLY         = 0X90,   //设置门铃快速回复
    EN_OGCT_PLATCMD_SETBELLQUICKREPLY_RSP     = 0X91,

    EN_OGCT_PLATCMD_CHANGEBELLSOUND           = 0X92,    //修改门铃的声音
    EN_OGCT_PLATCMD_CHANGEBELLSOUND_RSP       = 0X93,

    EN_OGCT_PLATCMD_SETSCENEPOLICY            = 0X94,  //设置场景策略
    EN_OGCT_PLATCMD_SETSCENEPOLICY_RSP        = 0X95,
    
    EN_OGCT_PLATCMD_SWITCH_SCENE              = 0X96,  // 手动切换场景
    EN_OGCT_PLATCMD_SWITCH_SCENE_RSP          = 0X97,

    EN_OGCT_PLATCMD_RELAY_MODE                = 0X98,  // RELAY mode
    EN_OGCT_PLATCMD_RELAY_MODE_RSP            = 0X99,

    EN_OGCT_PLATCMD_GETSIMCARD_INF            = 0X9A,  // 获取4G 设备的网络信息
    EN_OGCT_PLATCMD_GETSIMCARD_INF_RSP        = 0X9B,

    EN_OGCT_PLATCMD_UPLOAD_LOGFILE            = 0X9C,  //上传日志文件
    EN_OGCT_PLATCMD_UPLOAD_LOGFILE_RSP        = 0X9D,

    EN_OGCT_PLATCMD_SETDEVAUTOUPDATE          = 0X9E,   //设置设备自动升级
    EN_OGCT_PLATCMD_SETDEVAUTOUPDATE_RSP      = 0X9F,

    EN_OGCT_PLATCMD_GETSOUNDLIST              = 0XA0,   //获取声音文件列表
    EN_OGCT_PLATCMD_GETSOUNDLIST_RSP          = 0XA1,

    EN_OGCT_PLATCMD_DELSOUNDFILE              = 0XA2,   //删除自定义声音文件
    EN_OGCT_PLATCMD_DELSOUNDFILE_RSP          = 0XA3,

    EN_OGCT_PLATCMD_PLAYSOUNDFILE             = 0XA4,   //播放自定义声音文件
    EN_OGCT_PLATCMD_PLAYSOUNDFILE_RSP         = 0XA5,

    EN_OGCT_PLATCMD_RELAYDEV_AWAKE            = 0XA6,    //中继设备唤醒
    EN_OGCT_PLATCMD_RELAYDEV_AWAKE_RSP        = 0XA7,

    EN_OGCT_PLATCMD_LIMITSTREAM_NTC           = 0XA8,   //设备收到限流的notice
    EN_OGCT_PLATCMD_LIMITSTREAM_NTC_RSP       = 0XA9,

    EN_OGCT_PLATCMD_SETVOLUME                 = 0XB0,   //设置门铃的音量
    EN_OGCT_PLATCMD_SETVOLUME_RSP             = 0XB1, 

    EN_OGCT_PLATCMD_SETMAXSESSION             = 0XB2,   //设置最大的连接数
    EN_OGCT_PLATCMD_SETMAXSESSION_RSP         = 0XB3, 

    EN_OGCT_PLATCMD_SETDEFAULTLENID           = 0XB4,   //设置默认lenId
    EN_OGCT_PLATCMD_SETDEFAULTLENID_RSP       = 0XB5,

    EN_OGCT_PLATCMD_GETSNAPSHOTTIME           = 0XB6,   //获取时间戳快照
    EN_OGCT_PLATCMD_GETSNAPSHOTTIME_RSP       = 0XB7,

    EN_OGCT_PLATCMD_WEBRTC_SDP                = 0XB8,   //获取webrtc的sdp 信息
    EN_OGCT_PLATCMD_WEBRTC_SDP_RSP            = 0XB9,

    EN_OGCT_PLATCMD_SETINIOTSPROP             = 0XC0,   // 批量设置内置功能的prop
    EN_OGCT_PLATCMD_SETINIOTSPROP_RSP         = 0XC1,

    EN_OGCT_PLATCMD_SETOSDDISPLAY             = 0XD0,   // 设备OSD默认(时间)/自定义(文本)水印显示设置
    EN_OGCT_PLATCMD_SETOSDDISPLAY_RSP         = 0XD1, 

    EN_OGCT_PLATCMD_SETHUMANCOUNTREGIONS         = 0XD2,   // 设置客流统计区域坐标
    EN_OGCT_PLATCMD_SETHUMANCOUNTREGIONS_RSP     = 0XD3, 

    EN_OGCT_PLATCMD_SETHUMANCOUNTPARAM           = 0XD4,   // 设置客流统计参数
    EN_OGCT_PLATCMD_SETHUMANCOUNTPARAM_RSP       = 0XD5,     

    EN_OGCT_PLATCMD_CREATEREALTIMEBROADCAST      = 0XD6,   // 创建实时音频广播
    EN_OGCT_PLATCMD_CREATEREALTIMEBROADCAST_RSP  = 0XD7,

    EN_OGCT_PLATCMD_CREATESCHEDULEDBROADCAST     = 0XD8,   // 创建回放音频广播定时任务
    EN_OGCT_PLATCMD_CREATESCHEDULEDBROADCAST_RSP = 0XD9,

    EN_OGCT_PLATCMD_CANCELSCHEDULEDBROADCAST     = 0XDA,   // 取消回放音频广播定时任务
    EN_OGCT_PLATCMD_CANCELSCHEDULEDBROADCAST_RSP = 0XDB,

    EN_OGCT_PLATCMD_GAT1400SWITCH                = 0XDE,   // GAT1400功能开关
    EN_OGCT_PLATCMD_GAT1400SWITCH_RSP            = 0XDF,          

    EN_OGCT_PLATCMD_DOWNSOUNDFILE                = 0XE0,   // 下发自定义声音文件
    EN_OGCT_PLATCMD_DOWNSOUNDFILE_RSP            = 0XE1,   
    
    EN_OGCT_PLATCMD_UPDATESOUNDFILESTATTUS       = 0XE2,   // 上报自定义文件入库结果
    EN_OGCT_PLATCMD_UPDATESOUNDFILESTATTUS_RSP   = 0XE3,

    EN_OGCT_PLATCMD_BUSINESSSTRATEGYCHANGE       = 0XF2,   // 业务策略变更通知
    EN_OGCT_PLATCMD_BUSINESSSTRATEGYCHANGE_RSP   = 0XF3,

    EN_OGCT_PLATCMD_SENDIMSCALL                  = 0XF4,   // 下发设备IMS通话呼叫(AI强告警)
    EN_OGCT_PLATCMD_SENDIMSCALL_RSP              = 0XF5,

    EN_OGCT_PLATCMD_UPLOADBUSINESSCFG            = 0XF8,   // 下发设备返回当前全部配置
    EN_OGCT_PLATCMD_UPLOADBUSINESSCFG_RSP        = 0XF9,

    EN_OGCT_PLATCMD_STOPALARMRING                = 0XFA,   // 消警信令
    EN_OGCT_PLATCMD_STOPALARMRING_RSP            = 0XFB,           

    EN_OGCT_PLATCMD_SETPILOTLIGHT                = 0XFC,   // 设置指示灯状态
    EN_OGCT_PLATCMD_SETPILOTLIGHT_RSP            = 0XFD,    

}EN_OGCT_PLATCMD_MSG;

/**************************************************************
云端事件 0x35
***************************************************************/
typedef enum enum_CLOUDEVENT_msg
{
    EN_OGCT_CLOUDLOG_SETTING                        = 0X02,
    EN_OGCT_CLOUDLOG_SETTING_RSP                    = 0X03,

    EN_OGCT_CLOUDEVENT_EXCEPT_UPLOAD                = 0X10,
    EN_OGCT_CLOUDEVENT_EXCEPT_UPLOAD_RSP            = 0X11,
    
    EN_OGCT_CLOUDEVENT_ALARM_UPLOAD                 = 0X12,
    EN_OGCT_CLOUDEVENT_ALARM_UPLOAD_RSP             = 0X13,

    EN_OGCT_CLOUDEVENT_GETALARMCALENDER             = 0X14,
    EN_OGCT_CLOUDEVENT_GETALARMCALENDER_RSP         = 0X15,

    EN_OGCT_CLOUDEVENT_GETALARMLIST                 = 0X16,
    EN_OGCT_CLOUDEVENT_GETALARMLIST_RSP             = 0X17,

    EN_OGCT_CLOUDEVENT_GETEXCAPTLIST                = 0X18,
    EN_OGCT_CLOUDEVENT_GETEXCEPTLIST_RSP            = 0X19,

    EN_OGCT_CLOUDEVENT_APP_EXCEPTION                = 0X1A,
    EN_OGCT_CLOUDEVENT_APP_EXCEPTION_RSP            = 0X1B,

    EN_OGCT_CLOUDEVENT_AIPIC_ALARM_UPLOAD           = 0X1C,
    EN_OGCT_CLOUDEVENT_AIPIC_ALARM_UPLOAD_RSP       = 0X1D,

    EN_OGCT_CLOUDEVENT_PIC_ALARM_MAPPING            = 0X1E,
    EN_OGCT_CLOUDEVENT_PIC_ALARM_MAPPING_RSP        = 0X1F,

    EN_OGCT_CLOUDEVENT_AI_HUMANCOUNT     			= 0X20,
    EN_OGCT_CLOUDEVENT_AI_HUMANCOUNT_RSP  			= 0X21,

    EN_OGCT_CLOUDEVENT_AI_RECOGNITIONV2_UPLOAD      = 0X22,
    EN_OGCT_CLOUDEVENT_AI_RECOGNITIONV2_UPLOAD_RSP  = 0X23,

    EN_OGCT_CLOUDEVENT_IOTAIUPLOAD                  = 0X26,
    EN_OGCT_CLOUDEVENT_IOTAIUPLOAD_RSP              = 0X27,

    EN_OGCT_CLOUDEVENT_AI_RECOGNITION_UPLOAD        = 0X2E,
    EN_OGCT_CLOUDEVENT_AI_RECOGNITION_UPLOAD_RSP    = 0X2F,
}EN_OGCT_CLOUDEVENT_MSG;

/******************************************************
云端文件 0x36
******************************************************/
typedef enum enum_CLOUDFILE_msg
{
    EN_OGCT_CLOUDFILE_PREFETH_URL        = 0X10,  // 文件url 预取
    EN_OGCT_CLOUDFILE_PREFETH_URL_RSP    = 0X11,

    EN_OGCT_CLOUDFILE_UPDATE             = 0X12, // 文件上传后 信息更新
    EN_OGCT_CLOUDFILE_UPDATE_RSP         = 0X13,

    EN_OGCT_CLOUDFILE_GETCALENDER        = 0X14, // 获取媒体日历
    EN_OGCT_CLOUDFILE_GETCALENDER_RSP    = 0X15, 

    EN_OGCT_CLOUDFILE_GETAXIS            = 0X16, // 获取文件列表
    EN_OGCT_CLOUDFILE_GETAXIS_RSP        = 0X17, 

    EN_OGCT_CLOUDFILE_GETDES             = 0X18, // 查询文件详情
    EN_OGCT_CLOUDFILE_GETDES_RSP         = 0X19, 

}EN_OGCT_CLOUDFILE_MSG;

/*******************************************************************
0X37  组信息
*********************************************************************/
typedef enum enum_OGCT_GROUP_MSG
{
    EN_OGCT_GROUP_DEVJOIN_NTC            = 0X10,
    EN_OGCT_GROUP_DEVJOIN_NTC_RSP        = 0X11,    

    EN_OGCT_GROUP_DEVEXIT_NTC            = 0X12,
    EN_OGCT_GROUP_DEVEXIT_NTC_RSP        = 0X13,  

    EN_OGCT_GROUP_DEVJOIN                = 0X14,
    EN_OGCT_GROUP_DEVJOIN_RSP            = 0X15, 

    EN_OGCT_GROUP_DEVEXIT                = 0X16,
    EN_OGCT_GROUP_DEVEXIT_RSP            = 0X17, 

    EN_OGCT_GROUP_GETLIST                = 0X18,
    EN_OGCT_GROUP_GETLIST_RSP            = 0X19, 

    EN_OGCT_GROUP_GETINF                 = 0X1A,
    EN_OGCT_GROUP_GETINF_RSP             = 0X1B, 

    EN_OGCT_GROUP_CREATGROUP             = 0X1C,
    EN_OGCT_GROUP_CREATGROUP_RSP         = 0X1D, 

    EN_OGCT_GROUP_USEREXIT               = 0X1E,
    EN_OGCT_GROUP_USEREXIT_RSP           = 0X1F, 

    
    EN_OGCT_GROUP_INVITEUSER             = 0X20,
    EN_OGCT_GROUP_INVITEUSER_RSP         = 0X21, 

    EN_OGCT_GROUP_USERJOIN               = 0X22,
    EN_OGCT_GROUP_USERJOIN_RSP           = 0X23,
    
    EN_OGCT_GROUP_ADDDEVICE              = 0X24,
    EN_OGCT_GROUP_ADDDEVICE_RSP          = 0X25, 

    EN_OGCT_GROUP_RMVDEVICE              = 0X26,
    EN_OGCT_GROUP_RMVDEVICE_RSP          = 0X27, 

    EN_OGCT_GROUP_ADDGROUP               = 0X28, // 添加子组
    EN_OGCT_GROUP_ADDGROUP_RSP           = 0X29, 

    EN_OGCT_GROUP_RMVGROUP               = 0X2A,
    EN_OGCT_GROUP_RMVGROUP_RSP           = 0X2B, 

    EN_OGCT_GROUP_MODIFYROLE             = 0X2C,
    EN_OGCT_GROUP_MODIFYROLE_RSP         = 0X2D, 

    EN_OGCT_GROUP_CHANGEUSERROLE         = 0X2E,
    EN_OGCT_GROUP_CHANGEUSERROLE_RSP     = 0X2F, 

    EN_OGCT_GROUP_SYNCDEVLIST            = 0X30,
    EN_OGCT_GROUP_SYNCDEVLIST_RSP        = 0X31, 

    EN_OGCT_GROUP_GETUSRPUBINF           = 0X32,
    EN_OGCT_GROUP_GETUSRPUBINF_RSP       = 0X33, 

    EN_OGCT_GROUP_GETDEVSTATUS           = 0X34,
    EN_OGCT_GROUP_GETDEVSTATUS_RSP       = 0X35, 

    EN_OGCT_GROUP_USERJOINGROUP_NTC      = 0X36,
    EN_OGCT_GROUP_USERJOINGROUP_NTC_RSP  = 0X37, 

    EN_OGCT_GROUP_USERBERMV_NTC          = 0X38,
    EN_OGCT_GROUP_USERBERMV_NTC_RSP      = 0X39, 

    EN_OGCT_GROUP_USERROLEIDCHANGE_NTC       = 0X3A,
    EN_OGCT_GROUP_USERROLEIDCHANGE_NTC_RSP   = 0X3B, 

    EN_OGCT_GROUP_GROUPINFCHG_NTC            = 0X3C,
    EN_OGCT_GROUP_GROUPINFCHG_NTC_RSP        = 0X3D, 

    EN_OGCT_GROUP_DEVSTATUS_NTC              = 0X3E,
    EN_OGCT_GROUP_DEVSTATUS_NTC_RSP          = 0X3F, 

    EN_OGCT_GROUP_EVENTHAPPEN_NTC            = 0X40,
    EN_OGCT_GROUP_EVENTHAPPEN_NTC_RSP        = 0X41, 

    EN_OGCT_GROUP_DEVCFGCHG_NTC              = 0X42,
    EN_OGCT_GROUP_DEVCFGCHG_NTC_RSP          = 0X43, 

    EN_OGCT_GROUP_CUSTOM_NTC                 = 0X44,
    EN_OGCT_GROUP_CUSTOM_NTC_RSP             = 0X45, 

    EN_OGCT_GROUP_EXCEPT_NTC                 = 0X46,
    EN_OGCT_GROUP_EXCAPT_NTC_RSP             = 0X47, 

    EN_OGCT_GROUP_CFGCHANGE_NTC              = 0X48,
    EN_OGCT_GROUP_CFGCHANGE_NTC_RSP          = 0X49, 

    EN_OGCT_GROUP_CUSTOMMSG_PUB              = 0X4A,
    EN_OGCT_GROUP_CUSTOMMSG_PUB_RSP          = 0X4B,

    EN_OGCT_GROUP_EXCEPTMSG_PUB              = 0X4C,
    EN_OGCT_GROUP_EXCEPTMSG_PUB_RSP          = 0X4D,

    EN_OGCT_GROUP_JOINGROUP_NTC              = 0X52,
    EN_OGCT_GROUP_JOINGROUP_NTC_RSP          = 0X53,

    EN_OGCT_GROUP_REMOVEUSER                 = 0X54,// 删除普通用户
    EN_OGCT_GROUP_REMOVEUSER_RSP             = 0X55,
    
    EN_OGCT_GROUP_SETGROUPINFO               = 0X56,// 设置组的信息名字 
    EN_OGCT_GROUP_SETGROUPINFO_RSP           = 0X57,

    EN_OGCT_GROUP_DEVC4GPACKAGES_NTC         = 0X58, //4G套餐实时notice
    EN_OGCT_GROUP_DEVC4GPACKAGES_NTC_RSP     = 0X59,

    EN_OGCT_GROUP_DEVRESET                   = 0X60,
    EN_OGCT_GROUP_DEVRESET_RSP               = 0X61,
}EN_OGCT_GROUP_MSG;

typedef enum enum_OGCT_EXTERN_MSG
{
    EN_OGCT_CFGBUSS_GETUTC                     = 0x00,   //获取UTC时间
    EN_OGCT_CFGBUSS_GETUTC_RSP                 = 0X01,
}EN_OGCT_EXTERN_MSG;

//EN_OGCT_METHOD_USERPLAT 0X41
typedef enum EN_OGCT_USRPLAT_MSG
{
    EN_OGCT_USRPLAT_SIGNREGIST         = 0X10,  // 用户平台接入分配
    EN_OGCT_USRPLAT_SIGNREGIST_RSP     = 0X11,

    EN_OGCT_USRPLAT_REGIST             = 0X12, // 用户注册
    EN_OGCT_USRPLAT_REGIST_RSP         = 0X13,

    EN_OGCT_USRPLAT_LOGIN              = 0X14, //用户登录
    EN_OGCT_USRPLAT_LOGIN_RSP          = 0X15,

    EN_OGCT_USRPLAT_AUTH               = 0X16, // 用户token 
    EN_OGCT_USRPLAT_AUTH_RSP           = 0X17,

    EN_OGCT_USRPLAT_LOGOUT             = 0X18, // 用户注销
    EN_OGCT_USRPLAT_LOGOUT_RSP         = 0X19,

    EN_OGCT_USRPLAT_GETVERYCODE        = 0X1A, // 验证码
    EN_OGCT_USRPLAT_GETVERYCODE_RSP    = 0X1B,

    EN_OGCT_USRPLAT_RESETPSWD          = 0X1C, // 密码重置
    EN_OGCT_USRPLAT_RESETPSWD_RSP      = 0X1D,

    EN_OGCT_USRPLAT_BINDACCOUT          = 0X1E, // 密码重置
    EN_OGCT_USRPLAT_BINDACCOUT_RSP      = 0X1F,

    EN_OGCT_USRPLAT_CHANGELINK_NTC       = 0X20, // link 地址变更
    EN_OGCT_USRPLAT_CHANGELINK_NTC_RSP   = 0X21,

    EN_OGCT_USRPLAT_TOKENINVAILD_NTC     = 0X22, // token 失效
    EN_OGCT_USRPLAT_TOKENINVAILD_NTC_RSP = 0X23,

    EN_OGCT_USRPLAT_SYSTEM_NTC           = 0X24, // 系统消息
    EN_OGCT_USRPLAT_SYSTEM_NTC_RSP       = 0X25,

    EN_OGCT_USRPLAT_GETACCOUNTINF        = 0X26,  //获取账户信息
    EN_OGCT_USRPLAT_GETACCOUNTINF_RSP    = 0X27,

    EN_OGCT_USRPLAT_GETBINDCODE          = 0X28,  //用户去平台获取bindcode
    EN_OGCT_USRPLAT_GETBINDCODE_RSP      = 0X29,

    EN_OGCT_USRPLAT_DELETEUSRACCOUNT     = 0X2A,    //删除用户
    EN_OGCT_USRPLAT_DELETEUSRACCOUNT_RSP = 0X2B,

}EN_OGCT_USRPLAT_MSG;


//EN_OGCT_METHOD_USERAI  0X43   EN_OGCT_METHOD_DEVAI 0x44
typedef enum enum_EN_OGCT_USERAI_MSG
{
    EN_OGCT_USRAI_GETFACEINFOLIST_REQ        = 0X10,  //获取人脸样本列表
    EN_OGCT_USRAI_GETFACEINFOLIST_RSP        = 0X11,

    EN_OGCT_USRAI_GETFACELABELLIST_REQ       = 0X12,  //获取人脸标签列表
    EN_OGCT_USRAI_GETFACELABELLIST_RSP       = 0X13,

    EN_OGCT_USRAI_SETFACELABEL_REQ           = 0X14,  //编辑人脸标签
    EN_OGCT_USRAI_SETFACELABEL_RSP           = 0X15,

    EN_OGCT_USRAI_SETFACEINFO_REQ            = 0X16,  //编辑人脸样本信息
    EN_OGCT_USRAI_SETFACEINFO_RSP            = 0X17,

    EN_OGCT_USRAI_DELETEFACEINFO_REQ         = 0X18,  //删除人脸样本
    EN_OGCT_USRAI_DELETEFACEINFO_RSP         = 0X19,

    EN_OGCT_USRAI_DELETEFACELABEL_REQ        = 0X1A,  //删除人脸标签
    EN_OGCT_USRAI_DELETEFACELABEL_RSP        = 0X1B,   

    EN_OGCT_USRAI_CREATEFACE_REQ             = 0X1C,  //创建人脸标签
    EN_OGCT_USRAI_CREATEFACE_RSP             = 0X1D,   

}EN_OGCT_USERAI_MSG;

typedef enum enum_EN_OGCT_DEDVAI_MSG
{
    EN_OGCT_DEVAI_ADDFACEORLICENSELIB_REQ      = 0X20,  // 平台下发底库信息
    EN_OGCT_DEVAI_ADDFACEORLICENSELIB_RSP      = 0X21,
  
    EN_OGCT_DEVAI_UPLOADFACEORLICENSELIB_REQ   = 0X22,  // 向平台汇报库下载状态
    EN_OGCT_DEVAI_UPLOADFACEORLICENSELIB_RSP   = 0X23,

    EN_OGCT_DEVAI_DELFACEORLICENSELIB_REQ      = 0X24,  // 平台下发删除底库信息
    EN_OGCT_DEVAI_DELFACEORLICENSELIB_RSP      = 0X25,

}EN_OGCT_DEVAI_MSG;

typedef enum enum_EN_OGCT_CLOUDINFO_MSG
{
    EN_OGCT_GETCLOUDINFO_REQ        = 0X10,  //获取云存信息
    EN_OGCT_GETCLOUDINFO_RSP        = 0X11,
}EN_OGCT_CLOUDINFO_MSG;

//行车轨迹 EN_OGCT_METHOD_DEVTRACK 0X70
typedef enum enum_EN_OGCT_DEVTRACK_MSG
{
    EN_OGCT_DEVTRACK_CREATE_REQ             = 0X10,   // 创建行程轨迹
    EN_OGCT_DEVTRACK_CREATE_RSP             = 0X11,   

    EN_OGCT_DEVTRACK_UPLOAD_REQ             = 0X12,   //上传行程轨迹
    EN_OGCT_DEVTRACK_UPLOAD_RSP             = 0X13,

    EN_OGCT_DEVTRACK_FINISH_REQ             = 0X14,   // 结束行程轨迹
    EN_OGCT_DEVTRACK_FINISH_RSP             = 0X15,    

}EN_OGCT_DEVTRACK_MSG;



typedef enum enum_PUBCOSTOM_MSGTYPE 
{   
    EN_PUBCOSTOMMSG_SETNET     = 0x01,
    EN_PUBCOSTOMMSG_FORMAT     = 0X02

}EN_PUBCOSTOM_MSGTYPE;

typedef enum enum_uplogfile_type
{
    EN_UPLOGFILE_TYPE_ALIVE  = 0X01,
    EN_UPLOGFILE_TYPE_RECORD = 0X02,
    EN_UPLOGFILE_TYPE_CLOUD  = 0X04,
    EN_UPLOGFILE_TYPE_ALL    = 0XFFFF,
}EN_UPLOGFILE_TYPE;

typedef enum enum_log_alive_type
{
    EN_LOG_ALIVE_TYPE_NODATA         = 0X01,  // 无数据
    EN_LOG_ALIVE_TYPE_NOKEYFRAME     = 0X02,  // 无关键帧
    EN_LOG_ALIVE_TYPE_VIEWER_FULL    = 0X03,  // 观看人数满
    EN_LOG_ALIVE_TYPE_SLOT_INTERAPUT = 0X04
}EN_LOG_ALIVE_TYPE;


typedef enum enum_log_record_type
{
    EN_LOG_RECORD_TYPE_NOTFCARD          = 0X01,  // 无TF 卡
    EN_LOG_RECORD_TYPE_TFCARD_ERR        = 0X02,  // TF卡 错误
    EN_LOG_RECORD_TYPE_TFCARD_FULL       = 0X03,  // TF卡 满
    EN_LOG_RECORD_TYPE_TFCARD_NEEDFORMAT = 0X04   // 需要格式化
}EN_LOG_RECORD_TYPE;


typedef enum enum_log_cloudstg_type
{
    EN_LOG_CLOUDSTG_TYPE_NOURL            = 0X01,  // 无URL
    EN_LOG_CLOUDSTG_TYPE_NODATA           = 0X02,  // 没有数据
    EN_LOG_CLOUDSTG_TYPE_UPS3ERR          = 0X03,  // 上传s3 错误
    EN_LOG_CLOUDSTG_TYPE_UPMANGEERR       = 0X04   // 上传 云管理 错误
}EN_LOG_CLOUDSTG_TYPE;

typedef enum enum_MSGMNG_CONNECT_TYPE
{
    EN_MSGMNG_CONNECT_NOTYET = 0x00,
    EN_MSGMNG_CONNECT_IPV4   = 0x01,
    EN_MSGMNG_CONNECT_IPV6   = 0x02
}EN_MSGMN_CONNECT_TYPE;


typedef enum enum_MSG_CLOUDSTG_NETCHECK_TYPE
{
    EN_MSG_CLOUDSTG_NETCHECK_TCPING    = 0x01, // Tcping
    EN_MSG_CLOUDSTG_NETCHECK_DNS       = 0x02, // DNS
    EN_MSG_CLOUDSTG_NETCHECK_BANDWIDTH = 0x03, // Bandwidth
}EN_MSG_CLOUDSTG_NETCHECK_TYPE;

#ifdef __cplusplus
}
#endif

#endif


