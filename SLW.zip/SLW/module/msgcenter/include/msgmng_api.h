#ifndef _MSGCENTER_API_H_
#define _MSGCENTER_API_H_

#include "msgmng_type.h"
#include "mos.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CMD_NOT_SUPPORT_ERR 9527

typedef enum enum_ZJ_DEVICE_STATUS
{
    EN_ZJ_DEVICE_STATUS_OFFLINE = 0,
    EN_ZJ_DEVICE_STATUS_ONLINE
}EN_ZJ_DEVICE_STATUS;

typedef struct stru_Http_Event_ext
{
    _UI uiDuration;
    _UI uiCostomType;
    ST_MOS_LIST *pstFaceList;
}ST_HTTP_EVENT_EXT;

// 设备状态
typedef enum enum_DEV_STATUS_TYPE
{
    EN_DEV_STATUS_SLEEP = 0,    // 0: 设备休眠
    EN_DEV_STATUS_AWAKE = 1,    // 1: 设备唤醒
} EN_DEV_STATUS_TYPE;

// 设备状态变更方式
typedef enum enum_DEV_STATUS_CHANGE_WAY
{
    EN_DEV_STATUS_CHANGE_WAY_ONLINE       = 1,    // 1: 设备上线
    EN_DEV_STATUS_CHANGE_WAY_CMD          = 2,    // 2: 信令手动修改(手动休眠)
    EN_DEV_STATUS_CHANGE_WAY_TIMER        = 3,    // 3: 定时任务修改(定时休眠)
    EN_DEV_STATUS_CHANGE_WAY_PHYSICALMASK = 4,    // 4: 物理遮蔽修改
} EN_DEV_STATUS_CHANGE_WAY;

typedef _INT (*PFUN_MSGMNG_ACTIVEPROC)(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

typedef _INT (*PFUN_MSGMNG_RSPDATACB)(_UI uiReqId,_VPTR hJsonRoot);

typedef _INT (*PFUN_MSGMNG_MULTIMEDIA_ACTIVEPROC)(_VPTR hConn, _UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

typedef _INT (*PFUN_MSGMNG_MULTIMEDIA_RSPDATACB)(_VPTR hConn, _UI uiReqId,_VPTR hJsonRoot);

_INT MsgMng_Init();

_INT MsgMng_Start();

_INT MsgMng_Stop();

_INT MsgMng_Destroy();

_VOID MsgMng_RegistActiveFunc(_UC usMsgType,_UC ucMsgId,PFUN_MSGMNG_ACTIVEPROC pFunActiveMsgProc);

_INT  MsgMng_SendMsg(_UC *pucPeerId,_UI uiReqId, _UC ucMsgType,_UC ucMsgId,_UC *pucMsgBuff,_INT iMsgLen,PFUN_MSGMNG_RSPDATACB pFunRspDataCb);

// 取消处理请求消息的回应
_INT  MsgMng_CancleReqMsg(_UI uiReqId);

_INT  MsgMng_DispatchMsg(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_VPTR hJsonRoot);

_VOID MsgMng_SetNetWorkStatus(_INT iNetStatus);

/**************************************************************
信令服务
 ************************************************************/
_INT MsgMng_CleanCmdServerAddr();

/*p2p 服务 广播功能*/
_INT MsgMng_SendCustomPubMsgByP2pServer(_UI uiReqId,_UI uiPubMsgType,_UC *ucPubInf,PFUN_MSGMNG_RSPDATACB pFunOgctMsgCb);

// 设备状态（休眠、唤醒）上报 0x3410
_INT MsgMng_UploadDevStatus(_INT iCamStatus, _INT iStateChangeWay);

#ifdef __cplusplus
}
#endif

#endif


