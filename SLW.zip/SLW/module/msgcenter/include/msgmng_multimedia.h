#ifndef MSGMNG_MULTIMEDIA_H
#define MSGMNG_MULTIMEDIA_H
#ifdef __cplusplus
extern "C" {
#endif

#include "msgmng_api.h"
#include "media_type_prv.h"

#define MULTI_MEDIA_AUDIODATA_TIMEOUT     (15*1000)  //流媒体对讲音频超时时间为15秒

#define MSGMNG_MULTI_MEDIA_CONNTIME          10
#define MAX_STREAM_NUMBER                   2

/* u16转u8 buf */
#define U16_TO_U8S(u16, u8_buf) \
        *(u8_buf) = (unsigned char)(((u16) & 0xff00) >> 8); \
        *(u8_buf + 1) = (unsigned char)(((u16) & 0x00ff));

//8 bytes
#pragma pack (1)
typedef struct tagSDKHeader
{
    unsigned char code1;//'#'
    unsigned char code2;//'$'
    unsigned char type;
    unsigned char method;
    unsigned short length;//2 bytes
    unsigned char encrypt;//0x00 none,0x30 blowfish,0x31 AES
    unsigned char reserve;
}SDKHeader;

//min size is 6 ,max size is 14,the data may be encrypted
typedef struct tagSDKMediaHeader
{
    unsigned char   cam_id;
    unsigned char   stream_id;
    unsigned short  seq;
    //big endian windows
#if 0//BIG_ENDIAN
    unsigned char   frame_type:4;//1:I frame 0:P frame
    unsigned char   frame_start:1;
    unsigned char   frame_end:1;
    unsigned char   nal_start:1;
    unsigned char   nal_end:1;
#else
    //little endian
    unsigned char   nal_end:1;
    unsigned char   nal_start:1;
    unsigned char   frame_end:1;
    unsigned char   frame_start:1;
    unsigned char   frame_type:4;//1:I frame 0:P frame
#endif
    unsigned char   av_type;//1: video 2: audio
    unsigned int    frame_length;
    unsigned int    timestamp;
}SDKMediaHeader;
#pragma pack ()

typedef enum enum_MSGMNG_MULTI_MEDIA_STATUS{
    EN_MSGMNG_MULTI_MEDIA_STATUS_INIT                 = 0,
    EN_MSGMNG_MULTI_MEDIA_STATUS_STARTCONN,
    EN_MSGMNG_MULTI_MEDIA_STATUS_CONNECTING,
    EN_MSGMNG_MULTI_MEDIA_STATUS_CONNECTED,
    EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINING,
    EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINED,
    EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR
}EN_MSGMNG_MULTI_MEDIA_STATUS;

_INT MsgMng_RecvMultiMediaAddrNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaPauseNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaResumeNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaNewPlatKeyNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaAddrCleanNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_SetMultiMediaLinkEncrypPlatInf(ST_MSGMNG_MULTI_MEDIA *pstMultimedia,_INT iEncType,_UC *paucEncKey, _UC *paucEncLv);

_INT MsgMng_SetMultiMediaLinkEncrypInf(ST_MSGMNG_MULTI_MEDIA *pstMultimedia,_INT iEncType,_UC *paucEncKey, _UC *paucEncLv);

_INT MsgMng_MultiMediaPlatLogin();

_INT MsgMng_SendNotAuthToMultiMedia(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen);

_INT MsgMng_MultiMediaSendMsg(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC *pucPeerId,_UI uiReqId, _UC ucMsgType,_UC ucMsgId,
                    _UC *pucMsgBuff,_INT iMsgLen,PFUN_MSGMNG_MULTIMEDIA_RSPDATACB pFunRspDataCb);
                    
_INT MsgMng_SendDataToMultiMedia(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen);

_INT MsgMng_ProcMultiMediaRecv(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia);

_INT MsgMng_ParseMultiMediaData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia);

_INT MsgMng_DecodeMultiMediaData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC *pucMsgBuff,_INT iMsgBuffLen);

_INT MsgMng_ProcMultiMediaMsg(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC *pucMsgBuff,_INT iMsgBuffLen);

_INT MsgMng_MultiMediaDispatchMsg(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_VPTR hJsonRoot);

_VOID MsgMng_MultiMediaRegistActiveFunc(_UC usMsgType,_UC ucMsgId,PFUN_MSGMNG_MULTIMEDIA_ACTIVEPROC pFunActiveMsgProc);

_UC* MsgMng_BuildMultiMediaRspJson(_UI uiSeqID, _UC ucMsgType, _UC ucMsgId, _INT iStreamId, _INT iCode);

_INT MsgMng_RecvMultiMediaAskStartStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaAskPauseStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaNotSupportStream(_VPTR hConn, _UC *pucPeerId, _UI uiSeqId, _UC ucMsgType, _UC ucMsgId, _VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaAskResumeStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaAskCloseStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaAskIdr(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaAskUpdateKey(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaOpenAudioReverseStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaCloseAudioReverseStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaPlayBackAddrNtc(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaPlayBackClose(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvMultiMediaPlayBackControl(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_MultiMediaGetVideoData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT StreamId, _INT UsedFlag);

//int handle_audio_data(char * pData,int iDataSize,int64_t iTimeStamp);

_INT MsgMng_MultiMediaGetAudioData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT StreamId, _INT UsedFlag);

_INT MsgMng_MultiMediaClose(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT StreamId);

_INT MsgMng_MultiMediaPause(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT StreamId);

_INT MsgMng_MultiMediaResume(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT StreamId);

// 关闭流媒体所有连接/线程
_INT MsgMng_MultiMediaCloseAllConnect();

_UI MsgMng_MultiMediaSetLocalIPv6Addr(_UC *pucLocalIPv6Addr);

#ifdef __cplusplus
}
#endif

#endif


