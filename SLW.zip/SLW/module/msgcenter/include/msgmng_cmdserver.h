#ifndef MSGMNG_CMDSERVER_H
#define MSGMNG_CMDSERVER_H

#include "http_api.h"
#ifdef __cplusplus
extern "C" {
#endif

#define MSGMNG_CMDSERVER_CONNTIME               10        // 连接信令服务器超时时间
#define MSGMNG_CMDSERVER_SELFREGISTION_ERROR    60        // 自注册信息上报时间间隔(上报失败)
#define MSGMNG_CMDSERVER_SELFREGISTION_SUCCESS  24*60*60  // 自注册信息上报时间间隔(上报成功)
#define MSGMNG_CMDSERVER_REGETADDRTIME          45        // 等待重新获取信令服务器地址时间

#define MSGMNG_ROUTEADDR_ENABLE                 (1)       // 单元化改造功能是否开启 0:关闭 1:开启      
#define MSGMNG_CMDSERVER_GETROUTETIMEOUT        (120)     // 获取调度地址超时时间

#define MSGMNG_SELFREGISTION_URL          (_UC*)"deviceInfo/deviceStatus"
#define MSGMNG_ROUTEADDR_URL              (_UC*)"deviceAlloc"

#ifdef OFFICIAL_SERVER
    #if SDK40_REGISTER    // 4.0
    #define MSGMNG_ABLPLATREGIST_URL      (_UC*)"/app2/device/e_deviceRegister"   // (_UC*)"/app2/device/DeviceRegister"
    #define MSGMNG_REGETABLADDR_URL       (_UC*)"/app2/device/GetNatInfo"
    #else               // 3.0
    #define MSGMNG_ABLPLATREGIST_URL      (_UC*)"/app2/device/DeviceRegister"
    #define MSGMNG_REGETABLADDR_URL       (_UC*)"/app2/device/GetNatInfo"
    #endif
#else
    #if SDK40_REGISTER // 4.0
    #ifdef SDK40_30_REGISTER
        #define MSGMNG_ABLPLATREGIST_URL      (_UC*)"/app2/device/e_deviceRegister"
    #else
        #define MSGMNG_ABLPLATREGIST_URL      (_UC*)"/app2/device/gray/DeviceRegister"
    #endif
    #define MSGMNG_REGETABLADDR_URL       (_UC*)"/esigtran/GetNatInfo"
    #else             // 3.0
    #define MSGMNG_ABLPLATREGIST_URL      (_UC*)"/app2/device/DeviceRegister"
    #define MSGMNG_REGETABLADDR_URL       (_UC*)"/app2/device/GetNatInfo"
    #endif
#endif
typedef enum enum_CMD_RT_TYPE
{
    EN_CMD_RT_EXECUTE_CMD_FAIL            = 60001,    // 信令执行失败
    EN_CMD_RT_EXECUTE_CALLBACK_FAIL       = 60002,    // 设置 告警策略回调失败
}EN_CMD_RT_TYPE;

typedef enum enum_REPORT_RT_TYPE
{
    EN_REPORT_RT_PDM_FAIL                 = 170001,    // 上报北京终端失败
    EN_REPORT_RT_SMARTHOME_FAIL           = 170002,    // 上报智家失败  
    EN_REPORT_RT_EHOME_FAIL               = 170003,    // 上报能力平台失败
}EN_REPORT_RT_TYPE;

typedef enum enum_MSGMNG_RT_TYPE
{
    EN_MSGMNG_RT_GET_URL_FAIL            = 120001,    // 信令服务器地址获取失败
    EN_MSGMNG_RT_GET_URL_RETRY           = 120002,    // 信令服务器地址重新获取
    EN_MSGMNG_RT_LOGIN_FAIL              = 120003,    // 登录信令服务失败 - 流媒体转发
    EN_MSGMNG_RT_PUSH_STREAM_FAIL        = 120004,    // 推流失败 - 流媒体转发
    EN_MSGMNG_RT_P2P_GET_ADDR_FAIL       = 120005,    // P2P服务器地址获取失败
    EN_MSGMNG_RT_P2P_REGISTER_FAIL       = 120006,    // p2p服务注册失败     
    EN_MSGMNG_RT_P2P_AUTH_FAIL           = 120007,    // p2p服务auth失败
    EN_MSGMNG_RT_P2P_NAT_CHECK_FAIL      = 120008,    // nat检测失败
    EN_MSGMNG_RT_P2P_SLOT_FAIL           = 120009,    // p2p打洞失败
    EN_MSGMNG_RT_P2P_CHANGE_FAIL         = 120010,    // 直连/转发的切换失败（P2P）

    EN_MSGMNG_RT_UPLOADINFO_PDM_FAIL     = 120018,    // 北京终端CTEI设备信息上报失败
    EN_MSGMNG_RT_UPLOADINFO_PDM_SUC      = 120019,    // 北京终端CTEI设备信息上报成功
    EN_MSGMNG_RT_UPLOADINFO_SRTHOME_FAIL = 120020,    // 南京智家CTEI设备信息上报失败
    EN_MSGMNG_RT_UPLOADINFO_SRTHOME_SUC  = 120021,    // 南京智家CTEI设备信息上报成功

    EN_MSGMNG_RT_GET_ROUTE_FAIL          = 120022,    // 单元化改造功能（获取动态域名地址）失败
    
    EN_MSGMNG_RT_TEMP                    = 120023,    // 自定义失败
    
}EN_MSGMNG_RT_TYPE;

typedef enum enum_MSGMNG_CMDSERVER_STATUS{
    EN_MSGMNG_CMDSERVER_STATUS_INIT                 = 0,
    EN_MSGMNG_CMDSERVER_STATUS_REGISTING,           // 注册中
    EN_MSGMNG_CMDSERVER_STATUS_STARTCONN,
    EN_MSGMNG_CMDSERVER_STATUS_CONNECTING,
    EN_MSGMNG_CMDSERVER_STATUS_CONNECTED,
    EN_MSGMNG_CMDSERVER_STATUS_LOGINING,
    EN_MSGMNG_CMDSERVER_STATUS_PROCESS,
    EN_MSGMNG_CMDSERVER_STATUS_ERROR,
    EN_MSGMNG_CMDSERVER_STATUS_DEINIT
}EN_MSGMNG_CMDSERVER_STATUS;

typedef enum enum_MSGMNG_CMDSERVER_FLAG{
    EN_MSGMNG_CMDSERVER_FLAG_NOTYET                   = 0,
    EN_MSGMNG_CMDSERVER_FLAG_DOING,
    EN_MSGMNG_CMDSERVER_FLAG_FINSH,
    EN_MSGMNG_CMDSERVER_FLAG_ERROR,

}EN_MSGMNG_CMDSERVER_FLAG;

typedef enum enum_MSGMNG_ROUTE_STATUS{
    EN_MSGMNG_ROUTE_STATUS_INIT      = 0,//请求各模块的调度
    EN_MSGMNG_ROUTE_STATUS_WORKING,      //请求调度地址中
    EN_MSGMNG_ROUTE_STATUS_FAIL,         //请求调度失败标志
    EN_MSGMNG_ROUTE_STATUS_SUCCESS       //请求调度成功
}EN_MSGMNG_ROUTE_STATUS;

typedef enum enum_MSGMNG_ROUTE_REGET_STATUS{
    EN_MSGMNG_ROUTE_REGET_NONE      = 0, //重调度默认值
    EN_MSGMNG_ROUTE_REGET_NOW       = 1, //立刻进行重调度请求
    EN_MSGMNG_ROUTE_REGET_LATER     = 2, //稍后30秒再进行调度请求
}EN_MSGMNG_ROUTE_REGET_STATUS;

typedef struct stru_MSGMNG_HTTP_GET_TASK
{
    _UI             uiHttpHandle;       // handle
    _US             usBuffLen;          // 单次接收数据长度
    _US             usRecvLen;          // 总共接收数据长度
    _UC*            pucHttpBuff;        // httpbuf
}ST_MSGMNG_HTTP_GET_TASK;

typedef struct stru_MSGMNG_CMDSERVER{
    _UC                 ucStatus;           // 信令服务器状态
    _UC                 ucConnectFlag;      // 0. Not Connect; 1. Connecting; 2. Connnected. 3.Connect Err.
    _UC                 ucLoginFlag;        // 0. Not login;   1.logining;2.logined.3.login err.    
    _UC                 ucHeartInterval;    // 心跳间隔
    _UI                 uiConnectType;      // connect type
    _UI                 bRollbackToIPv4;    // v6回落v4的状态值 0 保持当前状态 1 回落 

    _UC                 ucHeartCount;       // 心跳数
    _UC                 ucConnFailCount;    // 连接信令服务器失败次数
    _UC                 ucGetMsgAddrCount;  // 获取信令服务器地址次数
    _UC                 ucReGetAddrFlag;    // 重新获取地址标识
    
    _UC                 ucResetFlag;        // 重置设备标识
    _UC                 ucRegistFlag;       // 0. Not regist;   1.registing;2.registed.3.registed err. 

    _UC                 ucHeartFailCount;   // 心跳失败数
    _UC                 ucSendHeartFlag;    // 是否发送心跳包标记

    _UC                 aucLinkAddrIPv4[64];// 休眠保活连接服务器地址ipv4
    _UC                 aucLinkAddrIPv6[64];// 休眠保活连接服务器地址ipv6
    _UI                 uiLinkPort;         // 休眠保活连接服务器端口
    _UC                 aucSleepToken[128]; // 休眠保活token

    _UC*                pucHttpBuff;        // httpbuf
    _US                 usBuffLen;          // httpbuf长度
    _US                 usRecvLen;          // 接收数据长度
    _UI                 uiHttpHandle;       // 
    _UI                 uiReqID;            // 请求ID
    _ULLID              ullTimeReq;         // 请求时间 毫秒 - socket连接信令->登录 的时间记录
    _CTIME_T            timeReq;            // 请求时间
    _CTIME_T            timePing;           // ping的时间 (发送心跳包时间点)
    _CTIME_T            timeSelfReg;        // 自注册的时间
    _SOCKET             isockFd;            // socket id
    _HMUTEX             hMutexSendB;        // 发送数据的互斥锁
    _UI                 uiForceCloseCmdFlag;// 强制关闭信令服务器标志位（检测到重启或重置信令）

    _UI                 uiPayloadLen;       // 有效数据长度
    _HSOCKBUFF          hSockBuffPool;      // 
    ST_MOS_SOCKBUF*     pstSendB;           // 发送到信令服务器的json数据
    ST_MOS_SOCKBUF*     pstRecvB;           // 接收到信令服务器的json数据
    ST_HTTP_ENCRYPTO_INF stPlatEncryInf;
    ST_HTTP_ENCRYPTO_INF stEncrypInf;

    _UC                 ucRouteStatus;      // 请求各模块调度状态值
    _UC                 ucRouteFailCount;   // 请求各模块调度失败次数
    _UC                 ucRouteReGetFlag;   // 是否重新请求调度 refer to EN_MSGMNG_ROUTE_REGET_STATUS
    _UC                 ucRes1[5];          // 保留
    _UI                 uiRouteReGetSec;    // 重新请求调度秒数，当ucRouteReGetFlag==EN_MSGMNG_ROUTE_REGET_LATER有用
    _CTIME_T            timeRouteReq;       // 请求各模块调度时间
}ST_MSGMNG_CMDSERVER;

// 获取是否开始执行功能任务
// 返回值0:不开始 1:开始
_UI MsgMng_GetStartWorkFlag();

// 获取指定平台域名地址
_INT MsgMng_GetPlatAddrInfo(_UC *pucPlatAddr, _UC *pucAdmonAddr, ST_MOS_INET_IP *pstNetIp, _UI *puiHttpsFlag, _UC *pucFuncStr);

ST_MSGMNG_CMDSERVER* MsgMng_GetCmdServer();

_VOID MsgMng_DeleteCmdServer();

_INT MsgMng_ResetCmdServer(ST_MSGMNG_CMDSERVER* pstCmdServer);

_INT MsgMng_ProcCmdServerStatus(_CTIME_T timeNow);

_INT MsgMng_ProcRouteStatus(_CTIME_T timeNow);

_INT MsgMng_ResetRouteParam(ST_MSGMNG_CMDSERVER* pstCmdServer);

_INT MsgMng_SendCmdServerBuffer();

_INT MsgMng_ProcCmdServerRecv(ST_MSGMNG_CMDSERVER* pstCmdServer);

_INT MsgMng_ParseCmdServerData(ST_MSGMNG_CMDSERVER* pstCmdServer);

// 设置信令服务的 秘钥
_INT MsgMng_SetCmdLinkEncrypInf(_INT iEncType,_UC *paucEncKey, _UC *paucEncLv);

_INT MsgMng_SetCmdPlatEncryInf(ST_MSGMNG_CMDSERVER* pstCmdServer,_INT iEncType,_UC *paucEncKey, _UC *paucEncLv);

_INT MsgMng_SendDataToCmdServer(_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen);
// 平台秘钥加密指令
_INT MsgMng_SendNotAuthToCmdServer(ST_MSGMNG_CMDSERVER* pstCmdServer,_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen);

/*********************************************************************************
 平台注册
*********************************************************************************/
_INT MsgMng_AblityPlatRegist();
// 重新获取信令平台地址
_INT MsgMng_ReGetCmdServerAddr();

// 获取各个模块调度地址
_INT MsgMng_AblityGetRouteStatus();

#ifdef __cplusplus
}
#endif

#endif


