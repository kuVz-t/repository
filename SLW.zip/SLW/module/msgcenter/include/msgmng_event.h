#ifndef HTTP_EVENTTASK_H
#define HTTP_EVENTTASK_H

#ifdef __cplusplus
extern "C" {
#endif

#define ALARMEVENT_REPORT2  1
#define ALARMEVENT_SNAP     0

#define HTTP_ALARMEVENT_URL            (_UC*)"/alarm/report"     //21CN Alarm Plat
#define HTTP_ALARMEVENT_URL2           (_UC*)"/alarm/report2"    //21CN Alarm Plat
#define HTTP_ALARMEVENT_URLMSG         (_UC*)"/alarm/reportMsg"  //事件上报接口
#define HTTP_ALARMEVENT_MAPPING_URL    (_UC*)"/alarm/alarmMapping"

// 使用reportMsg上报事件的信息
typedef struct stru_aievent_reportmsg_inf
{
    _UI uiIsUploadAIAlarmPV;    // AI事件是否使用reportMsg上报接口
    _UI uiNeedPicUrl;           // 是否需要返回上传AI事件图片的Url地址
    _UI uiNeedVideoUrl;         // 是否需要返回上传AI事件视频的Url地址
}ST_AIEVENT_REPORTMSD_INF;

typedef struct stru_eventtask_node
{
    _UC ucStatus;           // 类似 uiUseflag
    _UI uiReqId;            // https请求ID
    _CTIME_T CTime;         // 时间触发时间
    _UI uiIoTType;          // IOT告警类型
    _UI uiEventID;          // IOT事件类型
    _UC ucEventNo[64];      // 告警事件请求流水号
    _UI uiEventPushFlag;    // 告警时间是否已经推到服务器
    _UC ucPicObjId[64];     // 告警图片ObjId
    _UC ucPicCid[64];       // 告警图片id
    _UC ucFileObjId[64];    // 告警视频ObjId
    _UC ucFileCid[64];      // 告警视频id
    _UI uiHttpCancelFlag;   // http取消标志
    _UC* pucHttpBuff;       // httpbuf
    _UI uiBuffLen;          // httpbuf长度
    _UI uiRecvLen;          // 接收数据长度    
    ST_MOS_LIST_NODE stNode;
}ST_EVENTTASK_NODE;

_INT MsgMng_ProcEventNodeStatus();

ST_EVENTTASK_NODE *MsgMng_FindEventNodeByCTime(_CTIME_T CTime);

/**************************************************************
告警事件上报
 ************************************************************/
_INT MsgMng_UploadEventToDxServer(ST_ZJ_IOT_INF* pstIoTInf,_LLID lluHappenTime,_UI uiPushFlag,_VOID* pstHandler);

_INT MsgMng_SendExceptionToServer(_UC *pucPeerId,_UI uiErrType,_UI uiErrId,_UC *pucDes);

/* 告警消息关联 */
_INT MsgMng_UploadEventMappingToDxServer(_VPTR pEventNode);

#ifdef __cplusplus
}
#endif

#endif
