#ifndef _MSGMNG_QUALITY_STATISTICS_H_
#define _MSGMNG_QUALITY_STATISTICS_H_

#include "mos.h"
#include "kj_timer.h"

#ifdef __cplusplus
extern "C" {
#endif

#define QUALITY_STA_UPLOAD_INTERVAL     (_UI)1800 // 节点上报统计信息间隔(秒;默认1800s)

// 关键接口质量节点信息
typedef struct stru_QUALITY_STATISTICS_NODE
{
    _UI                     uiUseFlag;                 // 节点使用标志 0:未使用 1:使用
    _UC                     aucUrl[256];               // 域名
    EN_QUALITY_STA_RT_TYPE  enStatusCode;              // 状态码
    kj_timer_t              tUploadTimer;              // 用于统计上报时间是否到达(秒)
    _UI                     uiUploadInterval;          // 该节点上报统计信息间隔(秒;默认1800s)
   
    _UI                     uiSucCnt;                  // 成功次数
    _UI                     uiSucAvgUseTime;           // 成功平均耗时(毫秒)
    _UI                     uiSucTotalUseTime;         // 成功累计耗时(毫秒)

    _UI                     uiFailCnt;                 // 失败次数
    _UI                     uiFailAvgUseTime;          // 失败平均耗时(毫秒)
    _UI                     uiFailTotalUseTime;        // 失败累计耗时(毫秒)
    ST_MOS_LIST_NODE        stNode;
}ST_QUALITY_STATISTICS_NODE;

// 关键接口质量模块信息
typedef struct stru_QUALITY_STATISTICS_MNG
{
    _HMUTEX hMutex;
    ST_MOS_LIST stQualityStatisticsList;   // 质量统计链表 (ST_QUALITY_STATISTICS_NODE)
}ST_QUALITY_STATISTICS_MNG;

/**
 * brief 关键接口质量统计模块初始化
 * param 无
 * return 0:成功 -1:失败
*/
_INT MsgMng_QualityStatistics_Init();

/**
 * brief 关键接口质量统计模块去初始化
 * param 无
 * return 0:成功 -1:失败
*/
_INT MsgMng_QualityStatistics_Destroy();

/**
 * brief 创建或查找关键接口质量信息节点
 * param[in] enStatusCode 状态码
 * param[in] pucUrl 域名
 * return 信息节点
*/
 ST_QUALITY_STATISTICS_NODE* MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_TYPE enStatusCode, _UC *pucUrl);

/**
 * brief 关键接口质量成功信息设置
 * param[in] enStatusCode 状态码
 * param[in] uiUseTime 请求耗时
 * return 0:成功 -1:失败
*/
_INT MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_TYPE enStatusCode, _UI uiUseTime);

/**
 * brief 关键接口质量失败信息设置
 * param[in] enStatusCode 状态码
 * param[in] uiUseTime 请求耗时
 * return 0:成功 -1:失败
*/
_INT MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_TYPE enStatusCode, _UI uiUseTime);

/**
 * brief 上报关键接口质量信息
 * param 无
 * return 0:成功 -1:失败
*/
_INT MsgMng_QualityStatistics_Upload();

#ifdef __cplusplus
}
#endif

#endif