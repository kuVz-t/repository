#ifndef _MSGMNG_AI_H
#define _MSGMNG_AI_H

#ifdef __cplusplus
extern "C" {
#endif

#define HTTP_HUMANCOUNTNUM_URL            (_UC*)"/alarm/passengerFlow"                //21CN HumanCount Alarm Plat
#define HTTP_AI_RECOGNITIONV2_URL         (_UC*)"/alarm/AIRecognitionV2"             //21CN AIPIC Alarm Plat
#define HTTP_AIPIC_ALARMEVENT_URL         (_UC*)"/alarm/dispositionNotifications"    //21CN AIPIC Alarm Plat

// AIPic布控事件推送到云端
_INT MsgMng_UploadAIPicEventToDxServer(_UI uiKjIoTType, _LLID lluKjIotId, _UI uiKjIoTEventId, ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInfo);

// AI识别ZIP打包上传到云端
_INT MsgMng_UploadAIZipEventToDxServer(_UI uiKjIoTType, _LLID lluKjIotId, _UI uiKjIoTEventId, ST_ZJ_AI_ZIP_EVENT_SIGNAL *pstZipEventInfo);

// 上传客流统计到云端
_INT MsgMng_UploadHumanCountInfToDxServer(_UI uiHumInNum, _UI uiHumOutNum, _UC *pucStartDate, _UC *pucEndDate);
#ifdef __cplusplus
}
#endif

#endif
