#ifndef _MSGCENTER_PRV_H_
#define _MSGCENTER_PRV_H_

#ifdef __cplusplus
extern "C" {
#endif

#define MSGMNG_SOCKBUFF_LEN                 (50*1024)   //FIXME: 4096 有逻辑bug,单次信令接收数据超过这个值就会有问题
#define MSGMNG_MULTIMEDIA_SOCKBUFF_LEN      (4*1024)    //FIXME: 4096
typedef struct stru_msgmng_Active_Node
{
    _UC usMsgType;
    _UC ucMsgId;
    _UC ucRsv[2];
    PFUN_MSGMNG_ACTIVEPROC pFunActiveProc;
    ST_MOS_LIST_NODE stNode;
}ST_MSGMNG_ACTIVE_NODE;

typedef struct stru_msgmng_req_Node
{
    _UC ucUseFlag;
    _UC usMsgType;
    _UC ucMsgId;
    _UC ucRsv;
    _UI uiReqId;
    PFUN_MSGMNG_RSPDATACB pfunRspMsgProc;
    ST_MOS_LIST_NODE stNode;  
}ST_MSGMNG_RSP_NODE;

typedef struct stru_msgmng_multimedia_Active_Node
{
    _UC usMsgType;
    _UC ucMsgId;
    _UC ucRsv[2];
    PFUN_MSGMNG_MULTIMEDIA_ACTIVEPROC pFunActiveProc;
    ST_MOS_LIST_NODE stNode;
}ST_MSGMNG_MULTIMEDIA_ACTIVE_NODE;

typedef struct stru_msgmng_multimedia_req_Node
{
    _UC ucUseFlag;
    _UC usMsgType;
    _UC ucMsgId;
    _UC ucRsv;
    _UI uiReqId;
    PFUN_MSGMNG_MULTIMEDIA_RSPDATACB pfunRspMsgProc;
    ST_MOS_LIST_NODE stNode;  
}ST_MSGMNG_MULTIMEDIA_RSP_NODE;

typedef struct str_Msgmng_mng
{
    _UC ucInitFlag;
    _UC ucRunFlag;
    _UC ucNetworkType;
    _UC ucNetChangFlag;
    _HMUTEX hMutex;
    _HMUTEX hEventListMutex;
    ST_MOS_LIST stActiveFunList;    // ST_MSGMNG_ACTIVE_NODE
    ST_MOS_LIST stRspList;          // ST_MSGMNG_RSP_NODE

    ST_MOS_LIST stEventList;        // ST_EVENTTASK_NODE

    ST_MSGMNG_CMDSERVER *pstCmdServer;
    
    _HTHREAD  hThreadProc;
}ST_MSGMNG_MNG;

ST_MSGMNG_MNG *MsgMng_GetMng();

_UC* MsgMng_BuildCommonNtcRspJson(_UI uiSeqID, _UC ucMsgType,_UC ucMsgId,_INT iCode);

_UC* MsgMng_BuildOpenAudioReverseStreamRspJson(_INT iCamId, _UI uiSeqID, _UC ucMsgType,_UC ucMsgId,_INT AudioFlag);

_UC* MsgMng_BuildCloseAudioReverseStreamRspJson(_INT iCamId, _UI uiSeqID, _UC ucMsgType,_UC ucMsgId);

_UC* MsgMng_BuildNotSupportJson(_UI uiSeqID, _UC ucMsgType, _UC ucMsgId, _INT iCode);

#ifdef __cplusplus
}
#endif


#endif

