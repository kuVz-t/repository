#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "msgmng_pdm.h"
#include "config_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_crypto_adapt.h"
#include "adpt_json_adapt.h"
#include "qualityprobe_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "msgmng_quality_statistics.h"
#include "p2p_avclient.h"
#include "msgmng_multimedia.h"

#define PDM_UPDEVINFO_INTERVAL        86400
static ST_MSGMNG_PDM_MNG g_stReportPDMMng = {0};

ST_MSGMNG_PDM_MNG *MsgMng_PDM_GetMng()
{
    return &g_stReportPDMMng;
}

//uuid为32个字节
static _INT MsgMng_PDM_UUID_NoCrossBar(_UC * pucUUID)
{
    _INT n;
    const _UC *c = "89ab";
    _UC *p = pucUUID;

    srand(Mos_GetTickCount());
    
    for ( n = 0; n < 16; ++n )
    {
        int b = rand()%255;
        switch( n )
        {
            case 6:
                sprintf(p, "4%x", b%15 );
            break;
            case 8:
                sprintf(p, "%c%x", c[rand()%strlen(c)], b%15 );
            break;
            default:
                sprintf(p, "%02x", b);
            break;
        }
 
        p += 2;
    }
    *p = 0;

    return MOS_OK;
}

static _UI MsgMng_PDM_EncodeUrl(_UC *pucEncOutBuff,_INT iOutBuffLen,_UC *pucEncStr)
{
    _UC aucUrlBuff[1024];
    Adpt_Https_URLEncode(pucEncStr, MOS_STRLEN(pucEncStr), aucUrlBuff, 1024);
    
    MOS_VSNPRINTF(pucEncOutBuff,iOutBuffLen,"/?jsonstr=%s",aucUrlBuff);

    return MOS_OK;
}

static _VOID MsgMng_PDM_RecvUpLoadInfoRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    ST_MSGMNG_PDM_MNG *pstReportMng = MsgMng_PDM_GetMng();
    if (pstReportMng->uiBufTotalLen == 0)
    {
        pstReportMng->uiBufTotalLen = 1024;
        pstReportMng->pucRcvBuf = (_UC *)MOS_MALLOC(1024);
    }
    if(pstReportMng->uiRecvLen + uiLen < pstReportMng->uiBufTotalLen)
    {
        MOS_MEMCPY(pstReportMng->pucRcvBuf + pstReportMng->uiRecvLen,pucData,uiLen);
        pstReportMng->uiRecvLen += uiLen;
    }
    return ;
}

static _VOID MsgMng_PDM_RecvUpLoadInfoFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMNG_PDM_MNG *pstReportMng = MsgMng_PDM_GetMng();
    if(pstReportMng->pucRcvBuf)
    {
        pstReportMng->pucRcvBuf[pstReportMng->uiRecvLen] = 0;
    }
    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"aucUuid:%s recv reportInfo rsp is %s",pstReportMng->aucUuid,pstReportMng->pucRcvBuf);
    _UC aucMsgString[128] = {0}; 
    MOS_SPRINTF(aucMsgString, "%s Upload PDM Info Successfully",MSGMNG_REGIST_INFO_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), PDM_HOST, -1, EN_REGISTINFO_RT_UPLOADINFO_PDM_SUC, aucMsgString, 1);

    pstReportMng->uiBufTotalLen = 0;
    pstReportMng->uiRecvLen     = 0;
    pstReportMng->uiHttpHandle  = 0;
    MOS_FREE(pstReportMng->pucRcvBuf);

    MsgMng_PDM_GetMng()->ucPdmUpStatus = EN_MSGMNG_PDM_FLAG_FINSH;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_PDM, uiUseTime);

    return ;
}

static _VOID MsgMng_PDM_RecvUpLoadInfoFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMNG_PDM_MNG *pstReportMng = MsgMng_PDM_GetMng();
    MOS_FREE(pstReportMng->pucRcvBuf);
    pstReportMng->uiBufTotalLen = 0;
    pstReportMng->uiRecvLen     = 0;
    pstReportMng->uiHttpHandle  = 0;
    MsgMng_PDM_GetMng()->ucPdmUpStatus = EN_MSGMNG_PDM_FLAG_ERR;

    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"aucUuid:%s recv reportInfo rsp fail",pstReportMng->aucUuid);
    _UC aucMsgString[128] = {0}; 
    MOS_SPRINTF(aucMsgString, "%s Recv PDM Rsp Failed",MSGMNG_REGIST_INFO_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), PDM_HOST, -1, EN_REGISTINFO_RT_RECV_PDM_RSP_FAIL, aucMsgString, 1);

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_PDM, uiUseTime);

    return ;
}

static _UC* MsgMng_PDM_BuildDevJson()
{
    _UC *pucStrTmp    = MOS_NULL;
    _UC aucReportTime[32];
    ST_MOS_SYS_TIME stSysTime;
    ST_ZJ_NETWORK_INFO  stNetInfo;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

	MOS_MEMSET(&stNetInfo,0,sizeof(stNetInfo));
    if(ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetInfo);
    }
    Config_SetCamerLocalIPv6Addr(0, stNetInfo.aucIPv6Addr);
    AvClient_SetLocalIPv6Addr(stNetInfo.aucIPv6Addr);
    MsgMng_MultiMediaSetLocalIPv6Addr(stNetInfo.aucIPv6Addr);
    Mos_GetSysTime(&stSysTime);
    
    MOS_VSNPRINTF(aucReportTime, 32, "%04u-%02u-%02u %02u:%02u:%02u",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"VER",Adpt_Json_CreateString((_UC*)"03"));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CTEI",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
    if(MOS_STRLEN(stNetInfo.aucMacAddr))
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MAC",Adpt_Json_CreateString(stNetInfo.aucMacAddr));
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MAC",Adpt_Json_CreateString((_UC*)""));
    }
    if(MOS_STRLEN(stNetInfo.aucIPAddr))
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IP",Adpt_Json_CreateString(stNetInfo.aucIPAddr));
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"IP",Adpt_Json_CreateString((_UC*)""));
    }
    // if(MOS_STRLEN(stNetInfo.aucIPv6Addr))
    // {
    //     Adpt_Json_AddItemToObject(hRoot,(_UC*)"IPv6",Adpt_Json_CreateString(stNetInfo.aucIPv6Addr));
    // }
    // else
    // {
    //     Adpt_Json_AddItemToObject(hRoot,(_UC*)"IPv6",Adpt_Json_CreateString((_UC*)""));
    // }
    if(MOS_STRLEN(stNetInfo.aucUpMacAddr))
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"UPLINKMAC",Adpt_Json_CreateString(stNetInfo.aucUpMacAddr));
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"UPLINKMAC",Adpt_Json_CreateString((_UC*)""));
    }
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"LINK",Adpt_Json_CreateStrWithNum(2)); 
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"FWVER",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"DATE",Adpt_Json_CreateString(aucReportTime));
    pucStrTmp = Adpt_Json_Print(hRoot);
    
    Adpt_Json_Delete(hRoot);
    return pucStrTmp;
}


static _INT MsgMng_PDM_UpLoadDevInfo()
{
    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"is time to report to PDM");

    _INT iRet                = 0;
    _US usPort               = 80;
    _UC *pStrTmp             = MOS_NULL;
    _UC aucSubUrl[1024]      = {0};
    _UC auAdmonAddrPort[128] = {0};
    _UC aucAddBuf[64]        = {0};
    _UC auQualityUrl[128]    = {0}; // 关键接口质量URL

    pStrTmp = MsgMng_PDM_BuildDevJson();
    MsgMng_PDM_EncodeUrl(aucSubUrl,1024,pStrTmp);
    MOS_MEMSET(MsgMng_PDM_GetMng()->aucUuid,0,64);

    MsgMng_PDM_UUID_NoCrossBar(MsgMng_PDM_GetMng()->aucUuid);
    MOS_VSNPRINTF(aucAddBuf, 64, "reqId: %s\r\n", MsgMng_PDM_GetMng()->aucUuid);
    MOS_SPRINTF(auAdmonAddrPort, "%s:%d", PDM_HOST, usPort);

    // 创建关键接口质量信息节点 http://pdm.tydevice.com:80
    MOS_SPRINTF(auQualityUrl, "http://%s", auAdmonAddrPort);
    MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_PDM, auQualityUrl);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = 0;
    stHttpInfoNode.pfuncRecv       = MsgMng_PDM_RecvUpLoadInfoRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_PDM_RecvUpLoadInfoFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_PDM_RecvUpLoadInfoFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    stHttpInfoNode.pucExpandHeader = aucAddBuf;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddrPort, aucSubUrl, EN_HTTP_METHOD_POST, Mos_GetSessionId());
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC aucMsgString[128] = {0};
        MOS_SPRINTF(aucMsgString, "%s Parse PDM Addr Failed",MSGMNG_REGIST_INFO_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), PDM_HOST, -1, EN_REGISTINFO_RT_PARSE_PDM_ADDR_FAIL, aucMsgString, 1);
    }
    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"report dev aucAddBuf %s", aucAddBuf);
    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"report devInfo %s to PDM Server %s ,ret %d", pStrTmp, auAdmonAddrPort, iRet);
    Adpt_Json_DePrint(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

_INT MsgMng_PDM_StartUpLoadDevInfo(_CTIME_T timeNow)
{
    // 无网、ap热点、未登录信令平台
    if(MsgMng_GetMng()->ucNetworkType == EN_ZJ_NETWORK_TYPE_NONET || EN_ZJ_NETWORK_TYPE_AP == MsgMng_GetMng()->ucNetworkType || MsgMng_GetCmdServer()->ucStatus != EN_MSGMNG_CMDSERVER_STATUS_PROCESS)
    {
        return MOS_OK;
    }

    if(MsgMng_PDM_GetMng()->ucPdmUpStatus == EN_MSGMNG_PDM_FLAG_NOTYET)
    {
        if(MsgMng_PDM_UpLoadDevInfo() == MOS_OK)
        {
            MsgMng_PDM_GetMng()->ucPdmUpStatus = EN_MSGMNG_PDM_FLAG_DOING;
        }
        else
        {
            MsgMng_PDM_GetMng()->ucPdmUpStatus = EN_MSGMNG_PDM_FLAG_ERR;
        }
        MsgMng_PDM_GetMng()->cPdmUpTime = timeNow;
    }
    else if((MsgMng_PDM_GetMng()->ucPdmUpStatus == EN_MSGMNG_PDM_FLAG_DOING || MsgMng_PDM_GetMng()->ucPdmUpStatus == EN_MSGMNG_PDM_FLAG_ERR) && (_UI)(timeNow - MsgMng_PDM_GetMng()->cPdmUpTime) > 1800)
    {
        MsgMng_PDM_GetMng()->ucPdmUpStatus = EN_MSGMNG_PDM_FLAG_NOTYET;
    }
    else if(MsgMng_PDM_GetMng()->ucPdmUpStatus == EN_MSGMNG_PDM_FLAG_FINSH && (_UI)(timeNow - MsgMng_PDM_GetMng()->cPdmUpTime) > PDM_UPDEVINFO_INTERVAL)
    {
        MsgMng_PDM_GetMng()->ucPdmUpStatus = EN_MSGMNG_PDM_FLAG_NOTYET;
    }
    else if (MsgMng_PDM_GetMng()->ucPdmUpStatus > EN_MSGMNG_PDM_FLAG_FINSH)
    {
        MsgMng_PDM_GetMng()->ucPdmUpStatus = EN_MSGMNG_PDM_FLAG_NOTYET;
    }

    return MOS_OK;
}

