#ifndef _MSGMNG_UTC_H
#define _MSGMNG_UTC_H

#include "mos.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * brief 获取平台utc时间
 * param 无
 * return 0成功 其它失败
*/
_INT MsgMng_GetUtcTimeFromServer(void);

#ifdef __cplusplus
}
#endif

#endif


