#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "config_api.h"
#include "http_api.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_json_adapt.h"
#include "msgmng_devplat.h"
#include "http_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "cloudstg_type.h"

#ifdef BUILD_IMSSDK_FALG
#include "ims_api.h"
#include "ims_type.h"
#include "ims_render.h"
#endif

// 平台通知设备进行固件升级 0x3332
_INT MsgMng_RecvHardwareNeedUpgradeNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pucStrTmp      = MOS_NULL;
    _UC *pucDescURL     = MOS_NULL;
    _UC *pucNewVersion  = MOS_NULL;
    _UC *pucDownUrl     = MOS_NULL;
    _UC *pucPubkey      = MOS_NULL;
    _UC *pucSignature   = MOS_NULL;
    _UI uiFileSize      = 0;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Version"),&pucNewVersion);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"DownloadUrl"),&pucDownUrl);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"PublicKey"),&pucPubkey);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Signature"),&pucSignature);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"DescURL"),&pucDescURL);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"FileSize"),(_INT*)&uiFileSize);

    pucStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_UPDATE_NTC_RSP,MOS_OK);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CFGBUSS, EN_OGCT_CFGBUSS_UPDATE_NTC_RSP,
        pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);

    MOS_FREE(pucStrTmp);

    // 设置OTA升级所需要的参数
    return Ota_SetNewVersionInf(pucNewVersion,pucDownUrl,pucPubkey,pucSignature,pucDescURL,uiFileSize);
}

// 业务配置 3316
_INT MsgMng_RecvSetDevBussCfgNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT  iValue           = 0;
    _INT  i, iArraySize    = 0;
    _UI   uiPolicyId       = 0;
    _UC   aucPolicyId[64]  = {0};
    _UI   uiStartTime      = 0;
    _UI   uiEndTime        = 0;
    _UI   uiWeekFlag       = 0;
    _UI   uiSpanFlag       = 0;
    _UI   uiLoopType       = 0;
    _UI   uiKjIoTType      = 0;
    _LLID lluKjIoTId       = 0;
    _UC  *pStrTmp          = MOS_NULL;
    JSON_HANDLE hProp      = MOS_NULL;
    JSON_HANDLE hObject    = MOS_NULL;
    JSON_HANDLE hSubBody   = MOS_NULL;
    JSON_HANDLE hAppBody   = MOS_NULL;
    JSON_HANDLE hArray     = MOS_NULL;
    JSON_HANDLE hArrayItem = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    pStrTmp = Adpt_Json_Print(hBody);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"recv server set buss notice %s",pStrTmp);
    MOS_FREE(pStrTmp);
// 设备信息
    hSubBody = Adpt_Json_GetObjectItem(hBody,(_UC*)"Device");
    if(hSubBody)
    {
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hSubBody,(_UC*)"DevName"),&pStrTmp);
        Config_SetDeviceName(pStrTmp);
    }
// 摄像头
    hSubBody = Adpt_Json_GetObjectItem(hBody,(_UC*)"Camera");
    if(hSubBody)
    {
        JSON_HANDLE hCircle      = MOS_NULL;
        JSON_HANDLE hDistortion  = MOS_NULL;
        JSON_HANDLE hAudioParam  = MOS_NULL;
        
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubBody,(_UC*)"CamStatus"),(_INT*)&iValue);
        Config_SetCamerOpenFlag(0,iValue);
        
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubBody,(_UC*)"MicroPhoneStatus"),(_INT*)&iValue);
        Config_SetCamerMicOpenFlag(0,iValue);
        
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubBody,(_UC*)"IRRedMode"),&iValue);
        Config_SetCamerCurIRWorkMode(0,iValue);
        
        hArray = Adpt_Json_GetObjectItem(hSubBody,(_UC*)"StreamParam");
        iArraySize = Adpt_Json_GetArraySize(hArray);
        for(i = 0; i < iArraySize; i++)
        {
            ST_ZJ_VIDEO_CIRCLE stCircle;
            ST_ZJ_VIDEO_PARAM stVideoParam;
            ST_ZJ_VIDEO_DISTORTION stDistortion;
            hArrayItem = Adpt_Json_GetArrayItem(hArray, i);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"StreamID"),&iValue);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Width"),(_INT*)&stVideoParam.uiWidth);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Height"),(_INT*)&stVideoParam.uiHeight);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"EncType"),(_INT*)&stVideoParam.uiEncodeType);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"SmartEncFlag"),(_INT*)&stVideoParam.uiSmartEncFlag);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Quality"),(_INT*)&stVideoParam.uiQuality);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"FrameRate"),(_INT*)&stVideoParam.uiFramerate);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"BitRate"),(_INT*)&stVideoParam.uiBitrate);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"RateType"),(_INT*)&stVideoParam.uiRateType);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"FrameInterval"),(_INT*)&stVideoParam.uiFrameInterval);
            Config_SetCameraStreamParam(0,iValue,&stVideoParam);

            hCircle = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"VideoCircle");
            if(hCircle)
            {
                MOS_MEMSET(&stCircle,0,sizeof(stCircle));
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hCircle,(_UC*)"Radius"),(_INT*)&stCircle.uiRadius);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hCircle,(_UC*)"C1X"),(_INT*)&stCircle.uiCc1x);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hCircle,(_UC*)"C1Y"),(_INT*)&stCircle.uiCc1Y);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hCircle,(_UC*)"C2X"),(_INT*)&stCircle.uiCc2x);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hCircle,(_UC*)"C2Y"),(_INT*)&stCircle.uiCc2Y);
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hCircle,(_UC*)"Angle"),&stCircle.doubleAngle);
                Config_SetStreamerFisheyeInf(0,iValue,&stCircle);
            }
            
            hDistortion = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"VideoDistortion");
            if(hDistortion)
            {
                MOS_MEMSET(&stDistortion,0,sizeof(stDistortion));
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hDistortion,(_UC*)"Fx"),&stDistortion.fx);
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hDistortion,(_UC*)"Fy"),&stDistortion.fy);
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hDistortion,(_UC*)"Fa"),&stDistortion.a);
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hDistortion,(_UC*)"Fb"),&stDistortion.b);
                Adpt_Json_GetDouble(Adpt_Json_GetObjectItem(hDistortion,(_UC*)"Scale"),&stDistortion.scale);
                Config_SetStreamerDistortion(0,iValue,&stDistortion);
            }
        }
        hAudioParam = Adpt_Json_GetObjectItem(hSubBody,(_UC*)"AudioParam");
        if(hAudioParam)
        {
            ST_ZJ_AUDIO_PARAM stAudioParm;
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioParam,(_UC*)"EncType"),(_INT*)&stAudioParm.uiEncodeType);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioParam,(_UC*)"SampleRate"),(_INT*)&stAudioParm.uiSampleRate);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioParam,(_UC*)"Channel"),(_INT*)&stAudioParm.uiChannel);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioParam,(_UC*)"Depth"),(_INT*)&stAudioParm.uiDepth);
            Config_SetCamAudioParam(0,&stAudioParm);
        }
    }
// 预置位
    hSubBody = Adpt_Json_GetObjectItem(hBody,(_UC*)"PresetSetting");
    if(hSubBody)
    {
        _INT iTime,iSpeed;
        _UI uiPresetId,uiCruiseId,uiIndex;
        _UC *pucName = MOS_NULL;
        ST_CFG_PRESET_POINT stPoint = {0};
        JSON_HANDLE hPoint = MOS_NULL;

        //预置点
        Config_DelAllPresetPoints();
        hArray = Adpt_Json_GetObjectItem(hSubBody,(_UC*)"PreSets");
        iArraySize = Adpt_Json_GetArraySize(hArray);
        for(i = 0 ; i < iArraySize; i++)
        {
            hArrayItem = Adpt_Json_GetArrayItem(hArray,i);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PresetId"), (_INT*)&uiPresetId);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Name"),&pucName);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PicID"),&pStrTmp);

            hPoint = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Point");
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"X"), &stPoint.iX);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Y"), &stPoint.iY);
            Config_AddPresetPoint(0,uiPresetId,pucName,&stPoint);
            Config_SetPresetPictureId(0,uiPresetId,pStrTmp);
        }

        // 巡航轨迹 
        hArray = Adpt_Json_GetObjectItem(hSubBody,(_UC*)"Cruises");
        iArraySize = Adpt_Json_GetArraySize(hArray);
        Config_BegainSyncCruise(0);
        for(i = 0 ; i < iArraySize; i++)
        {
            _INT j,iPointArryCnt;
            JSON_HANDLE hPointArry,hPointItem;
            
            hArrayItem = Adpt_Json_GetArrayItem(hArray,i);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"CruiseID"), (_INT*)&uiCruiseId);
            Config_AddCurise(0,uiCruiseId);
                
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Name"),&pucName);
            Config_SetCuriseName(0,uiCruiseId,pucName);
            
            hPointArry = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PresetPoints");
            iPointArryCnt = Adpt_Json_GetArraySize(hPointArry);
            for(j = 0; j < iPointArryCnt; j++)
            {
                hPointItem = Adpt_Json_GetArrayItem(hPointArry,i);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointItem,(_UC*)"PresetID"), (_INT*)&uiPresetId);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointItem,(_UC*)"DwellTime"), &iTime);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointItem,(_UC*)"Speed"), &iSpeed);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointItem,(_UC*)"Index"), (_INT*)&uiIndex);
                Config_AddPresetIdToCurise(0,uiCruiseId,uiIndex,uiPresetId,iTime,iSpeed);
            }
        }
        // 看守位
        hObject = Adpt_Json_GetObjectItem(hSubBody,(_UC*)"WatchPoint");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObject,(_UC*)"PresetID"), (_INT*)&uiPresetId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hObject,(_UC*)"WatchTime"), &iTime);
        Config_AddWatchPoint(0,uiPresetId,iTime); 
        Config_EndSyncCruise(0);
    }
// 内置KjIot
    hArray = Adpt_Json_GetObjectItem(hBody,(_UC*)"InAIIoT");
    iArraySize = Adpt_Json_GetArraySize(hArray);
    for(i = 0; i < iArraySize; i++)
    {
        hArrayItem = Adpt_Json_GetArrayItem(hArray, i);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTID"),&pStrTmp);
        MOS_SSCANF(pStrTmp,"%llu",&lluKjIoTId);
        hProp = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Prop");
        if(hProp == MOS_NULL)
        {
            continue;
        }
        pStrTmp = Adpt_Json_Print(hProp);
        Config_SetInIotProp(uiKjIoTType,lluKjIoTId,pStrTmp);
        MOS_FREE(pStrTmp);
    }
// 定时策略
    hArray = Adpt_Json_GetObjectItem(hBody,(_UC*)"TimePolicy");
    if(hArray)
        Config_BegainSyncTimerPolicy();
    iArraySize = Adpt_Json_GetArraySize(hArray);
    for(i = 0; i < iArraySize; i++)
    {
        _UI uiOutputCnt,k;
        JSON_HANDLE hOutputArray,hOutputItem;
        ST_CFG_TIMEPOLICY_NODE *pstTimerNode = MOS_NULL;
        
        hArrayItem = Adpt_Json_GetArrayItem(hArray, i);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PolicyID"),&pStrTmp);
        MOS_STRNCPY(aucPolicyId, pStrTmp, sizeof(aucPolicyId));
        pstTimerNode = Config_FindOrCreatTimePolicy(aucPolicyId);


        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Week"), (_INT*)&uiWeekFlag);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"StartTime"), (_INT*)&uiStartTime);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"EndTime"), (_INT*)&uiEndTime);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"SpanFlag"),(_INT*)&uiSpanFlag);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"LoopType"),(_INT*)&uiLoopType);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Day"),&pStrTmp);
        Config_SetTimePolicyTime(pstTimerNode,uiLoopType,pStrTmp,uiWeekFlag,uiStartTime,uiEndTime,uiSpanFlag);

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PolicyName"),&pStrTmp);
        Config_SetTimePolicyName(pstTimerNode,pStrTmp);

        hOutputArray = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Action");
        uiOutputCnt  = Adpt_Json_GetArraySize(hOutputArray);

        for(k = 0; k < uiOutputCnt; k++)
        {
            hOutputItem = Adpt_Json_GetArrayItem(hOutputArray,k);
            
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hOutputItem,(_UC*)"AIIoTType"), (_INT*)&uiKjIoTType);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hOutputItem,(_UC*)"AIIoTID"),&pStrTmp);
            MOS_SSCANF(pStrTmp,"%llu",&lluKjIoTId);
            hObject = Adpt_Json_GetObjectItem(hOutputItem,(_UC*)"Output");
            pStrTmp = Adpt_Json_Print(hObject);
            Config_AddTimerPolicyOutput(pstTimerNode,uiKjIoTType,lluKjIoTId,pStrTmp);
            MOS_FREE(pStrTmp);
        }
    }
    if(hArray)
        Config_EndSyncTimerPolicy();
// 报警策略
    hArray = Adpt_Json_GetObjectItem(hBody,(_UC*)"IoTPolicy");
    if(hArray)
        Config_AlarmPolicyBegainSync();
    
    iArraySize = Adpt_Json_GetArraySize(hArray);
    for(i = 0; i < iArraySize; i++)
    {
        _UI uiEventArryCnt,j;
        JSON_HANDLE hEventArray,hEventItem;
       
        hArrayItem = Adpt_Json_GetArrayItem(hArray, i);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTID"),&pStrTmp);
        MOS_SSCANF(pStrTmp,"%llu",&lluKjIoTId); 
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PolicyID"),(_INT*)&uiPolicyId);
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiPolicyId);

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"PolicyName"), &pStrTmp); 
        Config_SetAlarmPolicyName(pstAPolicyNode,pStrTmp);
        
        hProp = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Prop");
        pStrTmp = Adpt_Json_Print(hProp);
        Config_SetAlarmPolicyProp(pstAPolicyNode,pStrTmp);
        MOS_FREE(pStrTmp);

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Week"),(_INT*)&uiWeekFlag);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"StartTime"),(_INT*)&uiStartTime);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"EndTime"),(_INT*)&uiEndTime);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"SnapFlag"),(_INT*)&uiSpanFlag);
        Config_SetAlarmPolicyTime(pstAPolicyNode,uiSpanFlag,uiWeekFlag,uiStartTime,uiEndTime);
        
        hEventArray = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Events");
        uiEventArryCnt = Adpt_Json_GetArraySize(hEventArray);
        for(j = 0; j < uiEventArryCnt; j++)
        {
            _UI uiKjIoTEventId = 0;
            _UI uiOutputArryCnt,k;
            JSON_HANDLE hOutputArray,hOutputItem;
            hEventItem = Adpt_Json_GetArrayItem(hEventArray, j);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hEventItem,(_UC*)"EventID"),(_INT*)&uiKjIoTEventId); 
            Config_AddAlarmPolicyEvent(pstAPolicyNode,uiKjIoTEventId);
            
            hOutputArray = Adpt_Json_GetObjectItem(hEventItem,(_UC*)"Action");
            uiOutputArryCnt = Adpt_Json_GetArraySize(hOutputArray);
            for(k = 0; k < uiOutputArryCnt ; k++)
            {
                _UI uiOutIotType = 0;
                _LLID lluOutIotId = 0;
                hOutputItem = Adpt_Json_GetArrayItem(hOutputArray, k);
                
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hOutputItem,(_UC*)"AIIoTType"), (_INT*)&uiOutIotType);
                
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTID"),&pStrTmp);
                MOS_SSCANF(pStrTmp,"%llu",&lluOutIotId);

                hObject = Adpt_Json_GetObjectItem(hOutputItem,(_UC*)"OutPut");
                pStrTmp = Adpt_Json_Print(hObject);
                Config_AddAlarmPolicyOutput(pstAPolicyNode,uiKjIoTEventId,uiOutIotType,lluOutIotId,pStrTmp);
                MOS_FREE(pStrTmp);
            }
        }
    }
    if(hArray)
        Config_AlarmPolicyEndSync();
// 增值业务
    hAppBody = Adpt_Json_GetObjectItem(hBody,(_UC*)"AppSetting");
    if(hAppBody)
    {
        _INT iHubLimit= 0;
        JSON_HANDLE hIotsArry,hInKjIoTBody;
        hSubBody = Adpt_Json_GetObjectItem(hAppBody,(_UC*)"AppLimit");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubBody,(_UC*)"ResolutionLimit"), (_INT*)&iValue);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hSubBody,(_UC*)"IoTHubLimit"), (_INT*)&iHubLimit);

        Config_SetDeviceLimitAbility(iValue,iHubLimit);
        
        hSubBody = Adpt_Json_GetObjectItem(hAppBody,(_UC*)"AppSet");
        hInKjIoTBody = Adpt_Json_GetObjectItem(hSubBody,(_UC*)"InAIIoT");

        hIotsArry = Adpt_Json_GetObjectItem(hInKjIoTBody,(_UC*)"IoTs");
        iArraySize= Adpt_Json_GetArraySize(hIotsArry);
        for(i = 0; i < iArraySize; i++)
        {
            hArrayItem = Adpt_Json_GetArrayItem(hIotsArry, i);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTType"), (_INT*)&uiKjIoTType);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"AIIoTID"),&pStrTmp);
            MOS_SSCANF(pStrTmp,"%llu",&lluKjIoTId);
            Config_AddInIotDevice(uiKjIoTType,lluKjIoTId);
            
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"OpenFlag"), (_INT*)&iValue);
            Config_SetInIotOpenFlag(uiKjIoTType,lluKjIoTId,iValue);
            
            hProp = Adpt_Json_GetObjectItem(hArrayItem,(_UC*)"Prop");
            if(hProp)
            {
                pStrTmp = Adpt_Json_Print(hProp);
                Config_SetInIotProp(uiKjIoTType,lluKjIoTId,pStrTmp);
                MOS_FREE(pStrTmp);
            }
        }
    }

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_NOTICE_RSP,MOS_OK);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_NOTICE_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 增值套餐 331A
_INT MsgMng_RecvSetDevChargeNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp = MOS_NULL;
    _INT iSetCmd;
    _UI i,iPackageSize;
    _UI j, iIotSize;
    JSON_HANDLE hInKjIoT       = MOS_NULL;
    JSON_HANDLE hProp          = MOS_NULL;
    JSON_HANDLE hPackages      = MOS_NULL;
    JSON_HANDLE hPackageItem   = MOS_NULL;
    JSON_HANDLE hSettings      = MOS_NULL;
    JSON_HANDLE hIots,hIotItem = MOS_NULL; 
    ST_CFG_PACKAGE_NODE stPackageInfo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
  
    hPackages = Adpt_Json_GetObjectItem(hBody,(_UC*)"Packages");
    iPackageSize = Adpt_Json_GetArraySize(hPackages); 
    for(i = 0; i < iPackageSize; i++)
    {
        MOS_MEMSET(&stPackageInfo,0,sizeof(stPackageInfo));
        hPackageItem = Adpt_Json_GetArrayItem(hPackages,i);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPackageItem,(_UC*)"SetCmd"),&iSetCmd);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPackageItem,(_UC*)"PackageID"),(_INT*)&stPackageInfo.uiPackageId);

        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"recv charge notice setcmd %u packageid %u",iSetCmd,stPackageInfo.uiPackageId);
        
        if(iSetCmd == 1)
        {
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPackageItem,(_UC*)"StartDate"),&pStrTmp);
            MOS_STRNCPY(stPackageInfo.aucStartData, pStrTmp, sizeof(stPackageInfo.aucStartData));
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPackageItem,(_UC*)"ExpireDate"),&pStrTmp);
            MOS_STRNCPY(stPackageInfo.aucExpireData, pStrTmp, sizeof(stPackageInfo.aucExpireData));
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPackageItem,(_UC*)"UID"),&pStrTmp);
            MOS_STRNCPY(stPackageInfo.aucUid, pStrTmp, sizeof(stPackageInfo.aucUid));
            Config_AddNewChargePackage(&stPackageInfo);
            Config_SetChargeFlag(1);
        }
        else if(iSetCmd == 2)
        {
            Config_RemoveChargePackage(stPackageInfo.uiPackageId);
            Config_SetChargeFlag(0);
        }
        hSettings = Adpt_Json_GetObjectItem(hPackageItem,(_UC*)"Setting");
        hInKjIoT = Adpt_Json_GetObjectItem(hSettings,(_UC*)"InAIIoT");
        hIots = Adpt_Json_GetObjectItem(hInKjIoT,(_UC*)"IoTs");
        iIotSize = Adpt_Json_GetArraySize(hIots);
        for(j = 0 ; j < iIotSize; j++)
        {
            _UI uiKjIoTType,uiOpenFlag;
            _LLID lluKjIotId = 0;
            hIotItem = Adpt_Json_GetArrayItem(hIots,j);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"AIIoTID"),&pStrTmp);
            MOS_SSCANF(pStrTmp, "%llu",&lluKjIotId);
            if(iSetCmd == 1)
            {
                Config_AddInIotDevice(uiKjIoTType,lluKjIotId);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotItem,(_UC*)"OpenFlag"),(_INT*)&uiOpenFlag);
                Config_SetInIotOpenFlag(uiKjIoTType,lluKjIotId,uiOpenFlag);
                hProp = Adpt_Json_GetObjectItem(hIotItem,"Prop");
                pStrTmp = Adpt_Json_Print(hProp);
                Config_SetInIotProp(uiKjIoTType,lluKjIotId,pStrTmp);
                MOS_FREE(pStrTmp);
            }
            else
            {
                Config_RemoveInIotDevice(uiKjIoTType,lluKjIotId);
            }
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"recv charge notice devices KjIot %u %llu",uiKjIoTType,lluKjIotId);  
        }
    }

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVCHARGE_NOTICE_RSP,MOS_OK);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVCHARGE_NOTICE_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);
    
    return MOS_OK;
}

// 日志上传 331E
_INT MsgMng_RecvUploadLocalLogNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT iErrType   = 0;
    _INT iOpenFlag  = 0;
    _UC *pStrTmp    = MOS_NULL;
    _INT iStatus    = MOS_ERR;
    _UC  pucUrl[64] = {0};
    _UC  pucErrorString[128] = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ErrType"),(_INT*)&iErrType);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),(_INT*)&iOpenFlag);

    Config_SetUpLogFlag(iOpenFlag,iErrType);
    
    if(ZJ_GetFuncTable()->pFunCollectLogFiles && iOpenFlag == 1)
    {
        iStatus = ZJ_GetFuncTable()->pFunCollectLogFiles("",0,"");
        if(iStatus != MOS_OK)
        {
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOAD_LOGFILE);
            MOS_SPRINTF(pucErrorString, "Device pFunCollectLogFiles err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else if (ZJ_GetFuncTable()->pFunCollectLogFiles == MOS_NULL)
    {
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOAD_LOGFILE);
        MOS_SPRINTF(pucErrorString, "pFunCollectLogFiles is NULL");
        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
    }

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_UPLOGFILE_NOTICE_RSP,MOS_OK);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_UPLOGFILE_NOTICE_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);
    
    return MOS_OK;
}

// 端到端的配置同步 331C
_INT MsgMng_RecvGetBussCfgByP2p(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UI uiCfgItem = 0;
    _UI uiSign    = 0;
    _UC *pStrTmp  = MOS_NULL;
    ST_CFG_MSGSRCINF stMsgSrcInf;
    JSON_HANDLE hBody,hFromObject;

    MOS_MEMSET(&stMsgSrcInf,0,sizeof(stMsgSrcInf));
    hFromObject = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"FROM");
    if(hFromObject)
    {
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"UserToken"),&pStrTmp);
        MOS_STRNCPY(stMsgSrcInf.aucUsrToken, pStrTmp, sizeof(stMsgSrcInf.aucUsrToken));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"SvrID"),&pStrTmp);
        MOS_STRNCPY(stMsgSrcInf.aucServId, pStrTmp, sizeof(stMsgSrcInf.aucServId));
    }
    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ConfType"), (_INT*)&uiCfgItem);
    if(uiCfgItem == 0)
    {
        uiCfgItem = 0XFFFFFF;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Sign"), (_INT*)&uiSign);

    return Config_SetSyncCfgByp2pFlag(pucPeerId,uiSeqId,uiCfgItem,uiSign,&stMsgSrcInf);
}

// 电信云套餐变更 3340
_INT MsgMng_RecvSetCloudPolicyNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp = MOS_NULL;
    CloudStg_InitChargeInfo();
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"cloudstg_inf CloudPolicy changed");

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_CLOUDPOLICY_NTC_RSP,MOS_OK);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_CLOUDPOLICY_NTC_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 电信云 配置 3342
_INT MsgMng_RecvSetCloudBussCfgNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp            = MOS_NULL;
    _INT iStreamID          = 0;
    _INT iCloudIconType     = 0;
    _INT iCloudEncPKId      = 0;
    _UC  *pucCloudEncPKValue= MOS_NULL;
    _INT iCloudEncSwitch    = 0;
    _INT iCloudEncType      = 0;
    _INT iCloudEncLen       = 0;
    _BOOL bNeedGenerateCloudEnc = MOS_FALSE;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"StreamID"),(_INT*)&iStreamID);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudIconType"),(_INT*)&iCloudIconType);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudEncPKId"),(_INT*)&iCloudEncPKId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudEncPKValue"),&pucCloudEncPKValue);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudEncSwitch"),(_INT*)&iCloudEncSwitch);
    // DEBUG: 开启云存加密开关
    // iCloudEncSwitch = 1;
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudEncType"),(_INT*)&iCloudEncType);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudEncLen"),(_INT*)&iCloudEncLen);

    bNeedGenerateCloudEnc = Config_NeedGenerateCloudEnc(iCloudEncSwitch);

    Config_SetStreamID(iStreamID);
    Config_SetCloudIconType(iCloudIconType);
    Config_SetCloudEncPKId(iCloudEncPKId);
    Config_SetCloudEncPKValue(pucCloudEncPKValue);
    Config_SetCloudEncSwitch(iCloudEncSwitch);
    if (iCloudEncSwitch == 1)
    {
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_ENC_SWITCH, "CD cloud encrypt switch to open", 1);
    }
    else if (iCloudEncSwitch == 2)
    {
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CLOUDSTG_RT_ENC_SWITCH, "CD cloud encrypt switch to close", 1);
    }
    // Config_SetCloudEncSwitch(0); // TEST:
    Config_SetCloudEncType(iCloudEncType);
    Config_SetCloudEncLen(iCloudEncLen);

    if (bNeedGenerateCloudEnc == MOS_TRUE)
    {
        CloudStg_Res_NotifyGenerateEncInfo();
    }

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_CLOUDCFG_NTC_RSP,MOS_OK);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_CLOUDCFG_NTC_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"cloudstg_inf CloudCFG changed,StreamID %d ,CloudIconType %d",iStreamID, iCloudIconType);
    return MOS_OK;
}

// 4G 限流通知 3380
_INT MsgMng_RecvSet4GFlowLimitNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UI uiFlowLimitFlag = 0;
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"LimitFlow"),(_INT*)&uiFlowLimitFlag);
    Config_SetDevLimitStreamFlag(uiFlowLimitFlag);

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_LIMITFLOW_NTC_RSP,MOS_OK);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_LIMITFLOW_NTC_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 事件云存监控上报开关 3502
_INT MsgMng_RecvSetCloudLog(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UI uiCloudLogFlag = 0;
    _UI uiCloudLogInterval = 0;
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudLogFlag"),(_INT*)&uiCloudLogFlag);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudLogInterval"),(_INT*)&uiCloudLogInterval);
    if (Config_SetCloudLogInterval(uiCloudLogInterval) == MOS_ERR)
    {
        pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDLOG_SETTING_RSP,MOS_ERR);
    }
    else
    {
        Config_SetCloudLogStatus(uiCloudLogFlag);
        pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDLOG_SETTING_RSP,MOS_OK);
    }
    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDLOG_SETTING_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 下发IMS业务配置
_INT MsgMng_RecvSetImsBusinessCfg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC ucSign[16]        = {0};
    _UC ucBindKey[128]    = {0};
    _UC *pStrTmp          = MOS_NULL;
    _UI uiPollingStatus   = 0;
    _UI uiPollingInterval = 0;
    _UI uiHaveIMS         = 0;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

#ifdef BUILD_IMSSDK_FALG
    // 版本号，可依据该字段判断IMS业务参数是否是否有变化
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Sign"),&pStrTmp);
    MOS_STRNCPY(ucSign, pStrTmp, sizeof(ucSign));

    if (MOS_STRNCMP(Config_GetImsMng()->ucSign, ucSign, sizeof(Config_GetImsMng()->ucSign)) != 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IMSCFG changed Sign (%s) change to (%s)", Config_GetImsMng()->ucSign, ucSign);
        Config_SetImsSign(ucSign);

        Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
        // 轮询间隔
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PollingInterval"),(_INT*)&uiPollingInterval);
        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IMSCFG PollingInterval (%u)", uiPollingInterval);
        Config_SetImsPollingInterval(uiPollingInterval);

        // 轮询开关 0.关闭，1.开启，默认关，轮询依赖套餐开通
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PollingStatus"),(_INT*)&uiPollingStatus);
        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IMSCFG PollingStatus (%u)", uiPollingStatus);
        Config_SetImsPollingStatus(uiPollingStatus);

        // 是否开通 0.关闭 1.开通
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"HaveIMS"),(_INT*)&uiHaveIMS);
        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IMSCFG HaveIMS (%u)", uiHaveIMS);
        Config_SetImsHaveIMSValue(uiHaveIMS);

        // 备份绑定码
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Bindkey"),&pStrTmp);
        MOS_STRNCPY(ucBindKey, pStrTmp, sizeof(ucBindKey));
        Config_SetImsBindKey(ucBindKey);

        Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);

        // IMS业务参数
        _UC *pucImsBusiParamJson = Adpt_Json_Print(hBody);
        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IMSCFG ImsBusiParamJson (%s)", pucImsBusiParamJson);
        Config_SetImsBusiParamJson(pucImsBusiParamJson);
        IMS_SetBusiParamsInf(Config_GetSystemMng()->aucDevCTEI, pucImsBusiParamJson);
        Adpt_Json_DePrint(pucImsBusiParamJson);

        // 若设备上线为获取到IMS配置，通知结束获取，但轮询获取继续
        ImsMedia_SetOnlineQueryCfgStatus(EN_IMS_QUERY_CFG_STATUS_SUCCESS);
        ImsMedia_SetQueryBusiCfgFailTimes(0);
    }

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_SETIMSBUSINESSCFG_RSP,MOS_OK);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_SETIMSBUSINESSCFG_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);

#endif
    return MOS_OK;
}
