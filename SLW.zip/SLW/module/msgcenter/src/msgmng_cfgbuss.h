#ifndef MSGMNG_BUSSCFG_H
#define MSGMNG_BUSSCFG_H

#ifdef __cplusplus
extern "C" {
#endif

// 固件升级
_INT MsgMng_RecvHardwareNeedUpgradeNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

// 业务配置
_INT MsgMng_RecvSetDevBussCfgNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

// 增值套餐
_INT MsgMng_RecvSetDevChargeNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

// 日志上传
_INT MsgMng_RecvUploadLocalLogNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

// 端到端的日志同步
_INT MsgMng_RecvGetBussCfgByP2p(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

// 电信云套餐变更
_INT MsgMng_RecvSetCloudPolicyNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

// 电信云 配置
_INT MsgMng_RecvSetCloudBussCfgNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

// 4G 限流通知
_INT MsgMng_RecvSet4GFlowLimitNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

// 事件云存监控上报开关 3502
_INT MsgMng_RecvSetCloudLog(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
#ifdef __cplusplus
}
#endif

#endif


