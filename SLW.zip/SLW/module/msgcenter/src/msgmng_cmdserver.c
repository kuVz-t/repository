#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "config_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_json_adapt.h"
#include "p2p_connect.h"
#include "msgmng_pdm.h"
#include "msgmng_smart_home.h"
#include "msgmng_outerip.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "qualityprobe_api.h"
#include "msgmng_quality_statistics.h"
#include "p2p_avclient.h"
#include "msgmng_multimedia.h"

#define  PLATRSPTEST_FLAG        (0)
#define  ROUTEPLATRSPTEST_FILE   "/tmp/routeplatsptest"
#define  CMDLATRSPTEST_FILE      "/tmp/msgplatsptest"

static _INT g_iUploadSelfRegistStatus                   =  0;
static ST_MSGMNG_HTTP_GET_TASK g_stHttpGetTaskSelfReg   = {0};  // 自注册     HTTP任务结构图

static _UI uiRouteRetryTime[8] = {0,5,15,30,60,120,300,600};

static _UI uiIsStartWork = 0; //是否开始云存、告警上报等任务

_UI MsgMng_GetStartWorkFlag()
{
    return uiIsStartWork;
}

/*
检查平台下发的域名是否多带'/'
如下发ehome.21cn.com或ehome.21cn.com/
当下发ehome.21cn.com/，需要去掉去后的'/'
*/
static _INT MsgMng_GetDomainAddr(_UC *pucInputDomainAddr, _UC *pucOutputDomainAddr)
{
    if (pucInputDomainAddr == MOS_NULL || pucOutputDomainAddr == MOS_NULL)
    {
        return MOS_ERR;
    }

    _UI uiStrLen = MOS_STRLEN(pucInputDomainAddr);
    if(uiStrLen < 1 || uiStrLen > CFG_STRING_MAXLEN)
    {
        return MOS_ERR;
    }

    _UC pucOutputTmp[CFG_STRING_MAXLEN + 4] = {0};

    if (pucInputDomainAddr[uiStrLen-1] == '/')
    { 
        MOS_STRNCPY(pucOutputTmp,pucInputDomainAddr,uiStrLen-1);
    }
    else
    {
        MOS_STRNCPY(pucOutputTmp,pucInputDomainAddr,uiStrLen);
    }

    if (MOS_STRSTR(pucOutputTmp,"https://") == MOS_NULL && MOS_STRSTR(pucOutputTmp,"http://") == MOS_NULL)
    {
        MOS_SPRINTF(pucOutputDomainAddr, "https://%s", pucOutputTmp);
    }
    else
    {
        MOS_SPRINTF(pucOutputDomainAddr, "%s", pucOutputTmp);
    }

    return MOS_OK;
}

// 获取平台域名地址
_INT MsgMng_GetPlatAddrInfo(_UC *pucPlatAddr, _UC *pucAdmonAddr, ST_MOS_INET_IP *pstNetIp, _UI *puiHttpsFlag, _UC *pucFuncStr)
{
    static _US usLoopCnt  = 0;
    _INT i                = 0;
    _INT iRet             = 0;
    _US  usPort           = 80;
    _UI  uiHttpsFlag      = 0;
    _UC  *pStrStart       = MOS_NULL;
    _UC  *pStrTmp         = MOS_NULL;
    _UC  ucStrErrLog[128] = {0};
    ST_MOS_INET_IPARRAY *pstIpArray = MOS_NULL;

    pStrTmp = MOS_STRSTR(pucPlatAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        usPort        = 443;
        *puiHttpsFlag = 1;
    } 

    pStrStart = MOS_STRSTR(pucPlatAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = pucPlatAddr;
    }
    else
    {
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(pucAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRNCPY(pucAdmonAddr, pStrStart, 128);
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"HxLink Begain %s aucPlatAddr %s", pucFuncStr, pucPlatAddr);
    
    pstIpArray = (ST_MOS_INET_IPARRAY*)MOS_MALLOCCLR(sizeof(ST_MOS_INET_IPARRAY));
    if(Mos_InetGetAddrInfo(pucAdmonAddr, usPort, EN_CINET_PRTL_TCP, MOS_FALSE, pstIpArray) != MOS_OK)
    {
        MOS_VSNPRINTF(ucStrErrLog, 128, "%s Sign Host(%s) AddrInfo error", pucFuncStr, pucPlatAddr);
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,  "%s", ucStrErrLog);

        _UC aucMsgString[128] = {0};
        MOS_SPRINTF(aucMsgString, "%s REG Parse SelfRegist Addr Failed",MSGMNG_REGIST_INFO_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, -1, EN_REGISTINFO_RT_PARSE_SELFREGIST_ADDR_FAIL, aucMsgString, 1);
        MOS_FREE(pstIpArray);
        return MOS_ERR;
    }

#ifdef SDK_ADPT_IPV6
    pstNetIp = &pstIpArray->astIps[usLoopCnt%pstIpArray->uiCount];
#else
    for(i = 0; i < pstIpArray->uiCount; i++)
    {
        pstNetIp = &pstIpArray->astIps[i];
        if(pstNetIp->usType == EN_CINET_TYPE_IPV4)
        {
            break;
        }
    }
#endif
    
    usLoopCnt++;
    
    MOS_FREE(pstIpArray);
    return MOS_OK;
}

/********************************************************************************************
*********************************************************************************************/
ST_MSGMNG_CMDSERVER* MsgMng_GetCmdServer()
{
    ST_MSGMNG_CMDSERVER *pstCmdServer = MOS_NULL;
    if(MsgMng_GetMng()->pstCmdServer != MOS_NULL)
    {
        return MsgMng_GetMng()->pstCmdServer;
    }
    pstCmdServer = (ST_MSGMNG_CMDSERVER*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_CMDSERVER));
    Mos_MutexCreate(&(pstCmdServer->hMutexSendB));
    pstCmdServer->hSockBuffPool = Mos_MallocSockBuf(MSGMNG_SOCKBUFF_LEN);
    pstCmdServer->uiPayloadLen = MSGMNG_SOCKBUFF_LEN - sizeof(ST_MOS_SOCKBUF);
    pstCmdServer->pstRecvB = Mos_PopSockBuf(pstCmdServer->hSockBuffPool);
    pstCmdServer->pstSendB = Mos_PopSockBuf(pstCmdServer->hSockBuffPool);
    pstCmdServer->ucHeartInterval = 30;
    pstCmdServer->isockFd         = MOS_SOCKET_INVALID;
    pstCmdServer->uiForceCloseCmdFlag = 0;
    pstCmdServer->bRollbackToIPv4   = MOS_FALSE;
    pstCmdServer->ucConnectFlag     = EN_MSGMNG_CMDSERVER_FLAG_NOTYET;
    pstCmdServer->timeReq           = 0;
    pstCmdServer->ullTimeReq        = 0;
    MsgMng_SetCmdPlatEncryInf(pstCmdServer,Config_GetCoreMng()->iEncType,Config_GetCoreMng()->aucEncKey,Config_GetCoreMng()->aucEncLoad);
    MsgMng_GetMng()->pstCmdServer = pstCmdServer;
    return pstCmdServer;
}

_VOID MsgMng_DeleteCmdServer()
{
    ST_MSGMNG_CMDSERVER *pstCmdServer = MsgMng_GetMng()->pstCmdServer;
    if(pstCmdServer == MOS_NULL)
    {
        return;
    }
    MsgMng_GetMng()->pstCmdServer = MOS_NULL;
     
    if(pstCmdServer->isockFd != MOS_SOCKET_INVALID){
        Mos_SocketClose(pstCmdServer->isockFd);
        pstCmdServer->isockFd = MOS_SOCKET_INVALID;
    }
    Mos_PushSockBuf(pstCmdServer->hSockBuffPool, pstCmdServer->pstRecvB);
    Mos_PushSockBuf(pstCmdServer->hSockBuffPool, pstCmdServer->pstSendB);
    pstCmdServer->pstRecvB = MOS_NULL;
    pstCmdServer->pstSendB = MOS_NULL;

    Mos_DeleteSockBuf(pstCmdServer->hSockBuffPool);
    pstCmdServer->hSockBuffPool = MOS_NULL;
    
    if(pstCmdServer->stEncrypInf.hCryptoCtx)
    {
        Adpt_DeleteCrypto(pstCmdServer->stEncrypInf.hCryptoCtx);
        pstCmdServer->stEncrypInf.hCryptoCtx = MOS_NULL;
    }
    if(pstCmdServer->stPlatEncryInf.hCryptoCtx)
    {
        Adpt_DeleteCrypto(pstCmdServer->stPlatEncryInf.hCryptoCtx);
        pstCmdServer->stPlatEncryInf.hCryptoCtx = MOS_NULL;
    }
    Mos_MutexDelete(&(pstCmdServer->hMutexSendB));

    MOS_FREE(pstCmdServer);
    return ;
}

// 重置信令服务器
_INT MsgMng_ResetCmdServer(ST_MSGMNG_CMDSERVER* pstCmdServer)
{
    if(pstCmdServer == MOS_NULL)
    {
        return MOS_OK;
    }
    pstCmdServer->ucRouteReGetFlag  = EN_MSGMNG_ROUTE_REGET_NOW;
    pstCmdServer->ucGetMsgAddrCount = 0;
    pstCmdServer->ucConnectFlag     = EN_MSGMNG_CMDSERVER_FLAG_NOTYET;
    pstCmdServer->ucConnFailCount   = 0;
    pstCmdServer->timeReq           = 0;
    pstCmdServer->ullTimeReq        = 0;

    if(pstCmdServer->isockFd != MOS_SOCKET_INVALID){
        Mos_SocketClose(pstCmdServer->isockFd);
        pstCmdServer->isockFd = MOS_SOCKET_INVALID;
    }
    Mos_InitSockBuf(pstCmdServer->pstRecvB);
    Mos_InitSockBuf(pstCmdServer->pstSendB);

    // 重置网络时通知厂家设备为离线状态
    if (EN_MSGMNG_CMDSERVER_STATUS_PROCESS == pstCmdServer->ucStatus)
    {
        Config_SetDeviOnlineStatus(EN_ZJ_DEVICE_STATUS_OFFLINE);
    }

    pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_INIT;
    
    return MOS_OK;
}

// 重置单元化调度参数
_INT MsgMng_ResetRouteParam(ST_MSGMNG_CMDSERVER* pstCmdServer)
{
    if(pstCmdServer == MOS_NULL)
    {
        return MOS_OK;
    }
    pstCmdServer->ucRouteFailCount = 0;
    pstCmdServer->ucRouteReGetFlag = EN_MSGMNG_ROUTE_REGET_NONE;
    pstCmdServer->timeRouteReq     = 0;
    pstCmdServer->uiRouteReGetSec  = 0;
    pstCmdServer->ucRouteStatus    = EN_MSGMNG_ROUTE_STATUS_INIT;
    
    return MOS_OK;
}


// 连接信令服务器 异步处理
_INT MsgMng_ConnectCmdServerIPv4(ST_MSGMNG_CMDSERVER* pstCmdServer,_CTIME_T timeNow)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    _BOOL bConnect;
    ST_MOS_INET_IP *pstPeerIP = MOS_NULL;
    ST_CFG_CORE_MNG* pstCoreInfo = Config_GetCoreMng();
    ST_MOS_INET_IPARRAY *pstIpArrray = (ST_MOS_INET_IPARRAY*)MOS_MALLOCCLR(sizeof(ST_MOS_INET_IPARRAY));

    pstCmdServer->uiConnectType = EN_MSGMNG_CONNECT_IPV4;
    pstCmdServer->ullTimeReq = Mos_GetLLTickCount();

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IPv4Addr:%s IPv4LinkPort:%d", pstCoreInfo->aucHxLinkAddr, pstCoreInfo->usHxLinkPort);

    do
    {
        if (MOS_STRLEN(pstCoreInfo->aucHxLinkAddr) == 0)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "pstCoreInfo->aucHxLinkAddr is NULL!");
            break;
        }
        // 使用Mos_InetAddrPton判断是否为ipv4地址，否则使用获取域名接口转化为具体ip信息
        // 注意Mos_InetGetAddrInfo在某些网络环境会频繁获取超时导致失败
        if (Mos_InetAddrPton(EN_CINET_TYPE_IPV4, pstCoreInfo->aucHxLinkAddr, pstIpArrray->astIps[0].u.aucIp) == MOS_OK)
        {
            pstIpArrray->uiCount = 1;
            pstIpArrray->astIps[0].usType = EN_CINET_TYPE_IPV4;
            pstIpArrray->astIps[0].usPort = pstCoreInfo->usHxLinkPort;
        }
        else
        {
            if (Mos_InetGetAddrInfo(pstCoreInfo->aucHxLinkAddr,pstCoreInfo->usHxLinkPort,EN_CINET_PRTL_TCP,MOS_FALSE,pstIpArrray) != MOS_OK)
            {       
                MOS_LOG_WARN(MSGMNG_ID_LOG_STR, "IPv4 Get CmdServerAddrInfo(%s %d) Failed, Again",pstCoreInfo->aucHxLinkAddr,pstCoreInfo->usHxLinkPort); 
                if (Mos_InetGetAddrInfo(pstCoreInfo->aucHxLinkAddr,pstCoreInfo->usHxLinkPort,EN_CINET_PRTL_TCP,MOS_FALSE,pstIpArrray) != MOS_OK)
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "IPv4 Get CmdServerAddrInfo(%s %d) Failed",pstCoreInfo->aucHxLinkAddr,pstCoreInfo->usHxLinkPort); 
                    break;
                }
            }
        }

        // 从pstIpArrray获取ipv4 ip信息
        pstPeerIP = Http_GetInetIPByIpArray(pstIpArrray, EN_CINET_TYPE_IPV4);
        if (pstPeerIP == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "IPv4 Get CmdServerAddrInfo(%s %d) pstPeerIP Not EN_CINET_TYPE_IPV4",pstCoreInfo->aucHxLinkAddr,pstCoreInfo->usHxLinkPort);   
            break;
        }

        pstCmdServer->isockFd  = Mos_SocketOpen(pstPeerIP->usType,EN_CINET_PRTL_TCP,MOS_FALSE,MOS_TRUE);
        if (pstCmdServer->isockFd == MOS_SOCKET_INVALID)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "IPv4 HxLink Open Socket Error.");
            break;
        }

        Mos_SocketSetRecvBuf(pstCmdServer->isockFd ,32*1024);
        if (Mos_SocketConnect(pstCmdServer->isockFd, pstPeerIP, &bConnect) != MOS_OK)
        { 
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "IPv4 HxLink Connect Server Error.Conn Count:%d", pstCmdServer->ucConnFailCount);
            break;
        }

        if (bConnect == MOS_TRUE)
        {
            pstCmdServer->ucConnectFlag = EN_MSGMNG_CMDSERVER_FLAG_FINSH;
        }
        else
        {
            pstCmdServer->ucConnectFlag = EN_MSGMNG_CMDSERVER_FLAG_DOING;
        }

        // 保存连接的IP与端口
        MOS_MEMSET(pstCmdServer->aucLinkAddrIPv4, 0, sizeof(pstCmdServer->aucLinkAddrIPv4));
        pstCmdServer->uiLinkPort = pstCoreInfo->usHxLinkPort;
        Mos_InetAddrNtop(EN_CINET_TYPE_IPV4, pstPeerIP->u.aucIp, pstCmdServer->aucLinkAddrIPv4, sizeof(pstCmdServer->aucLinkAddrIPv4));
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IPv4 HxLink Connect Addr:%s:%u,ConnectFlag:%u", pstCoreInfo->aucHxLinkAddr, pstCoreInfo->usHxLinkPort, pstCmdServer->ucConnectFlag);
        
        EN_COUNT_VALUE CountLess2Value = (Mos_GetLLTickCount() - pstCmdServer->ullTimeReq >= 2000) ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
        Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_SUCCESS,CountLess2Value);
        
        MOS_FREE(pstIpArrray);
        return MOS_OK;
        
    } while (0);

    MOS_FREE(pstIpArrray);
    if (pstCmdServer->isockFd != MOS_SOCKET_INVALID)
    {
        Mos_SocketClose(pstCmdServer->isockFd);
        pstCmdServer->isockFd = MOS_SOCKET_INVALID;
    }
    pstCmdServer->ucConnectFlag = EN_MSGMNG_CMDSERVER_FLAG_NOTYET;
    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);
    return MOS_ERR;
}
// 连接信令服务器 异步处理
_INT MsgMng_ConnectCmdServerIPv6(ST_MSGMNG_CMDSERVER* pstCmdServer,_CTIME_T timeNow)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    _BOOL bConnect;
    
    ST_MOS_INET_IP *pstPeerIP = MOS_NULL;
    ST_CFG_CORE_MNG* pstCoreInfo = Config_GetCoreMng();
    ST_MOS_INET_IPARRAY *pstIpArrray = (ST_MOS_INET_IPARRAY*)MOS_MALLOCCLR(sizeof(ST_MOS_INET_IPARRAY));

    pstCmdServer->uiConnectType = EN_MSGMNG_CONNECT_IPV6;
    pstCmdServer->ullTimeReq = Mos_GetLLTickCount();

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IPv6Addr:%s IPv6LinkPort:%d", pstCoreInfo->aucHxLinkIPv6Addr, pstCoreInfo->usHxLinkPort);

    do
    {
        if (MOS_STRLEN(pstCoreInfo->aucHxLinkIPv6Addr) == 0)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "pstCoreInfo->aucHxLinkIPv6Addr is NULL!");
            break;
        }
        // 使用Mos_InetAddrPton判断是否为ipv6地址，否则使用获取域名接口转化为具体ip信息
        // 注意Mos_InetGetAddrInfo在某些网络环境会频繁获取超时导致失败
        if (Mos_InetAddrPton(EN_CINET_TYPE_IPV6, pstCoreInfo->aucHxLinkIPv6Addr, pstIpArrray->astIps[0].u.aucIpv6) == MOS_OK)
        {
            pstIpArrray->uiCount = 1;
            pstIpArrray->astIps[0].usType = EN_CINET_TYPE_IPV6;
            pstIpArrray->astIps[0].usPort = pstCoreInfo->usHxLinkPort;
        }
        else
        {
            if (Mos_InetGetAddrInfo(pstCoreInfo->aucHxLinkIPv6Addr,pstCoreInfo->usHxLinkPort,EN_CINET_PRTL_TCP,MOS_FALSE,pstIpArrray) != MOS_OK)
            {
                MOS_LOG_WARN(MSGMNG_ID_LOG_STR, "IPv6 Get CmdServerAddrInfo(%s %d) Failed, Again",pstCoreInfo->aucHxLinkIPv6Addr,pstCoreInfo->usHxLinkPort);
                if (Mos_InetGetAddrInfo(pstCoreInfo->aucHxLinkIPv6Addr,pstCoreInfo->usHxLinkPort,EN_CINET_PRTL_TCP,MOS_FALSE,pstIpArrray) != MOS_OK)
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "IPv6 Get CmdServerAddrInfo(%s %d) Failed",pstCoreInfo->aucHxLinkIPv6Addr,pstCoreInfo->usHxLinkPort);   
                    break;
                } 
            }
        }

        // 从pstIpArrray获取ipv6 ip信息
        pstPeerIP = Http_GetInetIPByIpArray(pstIpArrray, EN_CINET_TYPE_IPV6);
        if (pstPeerIP == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "IPv6 Get CmdServerAddrInfo(%s %d) pstPeerIP Not EN_CINET_TYPE_IPV6",pstCoreInfo->aucHxLinkIPv6Addr,pstCoreInfo->usHxLinkPort);   
            break;
        }

        pstCmdServer->isockFd = Mos_SocketOpen(pstPeerIP->usType,EN_CINET_PRTL_TCP,MOS_FALSE,MOS_TRUE);
        if (pstCmdServer->isockFd == MOS_SOCKET_INVALID)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "IPv6 HxLink Open Socket Error.");
            break;
        }

        Mos_SocketSetRecvBuf(pstCmdServer->isockFd ,32*1024);

        if (Mos_SocketConnect(pstCmdServer->isockFd, pstPeerIP, &bConnect) != MOS_OK)
        { 
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "IPv6 HxLink Connect Server Error.Conn Count:%d", pstCmdServer->ucConnFailCount);
            break;
        }

        if (bConnect == MOS_TRUE)
        {
            pstCmdServer->ucConnectFlag = EN_MSGMNG_CMDSERVER_FLAG_FINSH;
        }
        else
        {
            pstCmdServer->ucConnectFlag = EN_MSGMNG_CMDSERVER_FLAG_DOING;
        }

        // 保存连接的IP与端口
        MOS_MEMSET(pstCmdServer->aucLinkAddrIPv6, 0, sizeof(pstCmdServer->aucLinkAddrIPv6));
        pstCmdServer->uiLinkPort = pstCoreInfo->usHxLinkPort;
        Mos_InetAddrNtop(EN_CINET_TYPE_IPV6, pstPeerIP->u.aucIpv6, pstCmdServer->aucLinkAddrIPv6, sizeof(pstCmdServer->aucLinkAddrIPv6));
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IPv6 HxLink Connect Addr:%s:%u,ConnectFlag:%u", pstCoreInfo->aucHxLinkIPv6Addr, pstCoreInfo->usHxLinkPort, pstCmdServer->ucConnectFlag);

        EN_COUNT_VALUE CountLess2Value = pstCmdServer->ullTimeReq - Mos_GetLLTickCount() > MOS_INET_IPV6_TIMEOUT_MS ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
        Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_SUCCESS,CountLess2Value);
        MOS_FREE(pstIpArrray);
        return MOS_OK;
    } while (0);

    MOS_FREE(pstIpArrray);
    if (pstCmdServer->isockFd != MOS_SOCKET_INVALID)
    {
        Mos_SocketClose(pstCmdServer->isockFd);
        pstCmdServer->isockFd = MOS_SOCKET_INVALID;
    }
    pstCmdServer->ucConnectFlag = EN_MSGMNG_CMDSERVER_FLAG_NOTYET;
    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);
    return MOS_ERR;
}

// ipv6连接失败，回落到ipv4连接
// 返回值：MOS_OK-回落到ipv4，MOS_ERR-不回落
static _INT MsgMng_IPv6RollbackToIPv4(ST_MSGMNG_CMDSERVER* pstCmdServer)
{
    if ((pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV6) && (pstCmdServer->ucStatus < EN_MSGMNG_CMDSERVER_STATUS_PROCESS))
    {
        pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_STARTCONN;
        pstCmdServer->bRollbackToIPv4 = MOS_TRUE;
        if (pstCmdServer->isockFd != MOS_SOCKET_INVALID)
        {
            Mos_SocketClose(pstCmdServer->isockFd);
            pstCmdServer->isockFd = MOS_SOCKET_INVALID;
        }
        MOS_PRINTF("msgmng connect/login ipv6 failed, rollback ipv4\n");
        // 不需要单独打印ipv6失败
        return MOS_OK;
    }
    return MOS_ERR;
}

/****************************************************************************************
设备登录
*****************************************************************************************/
_INT MsgMng_ProcCmdServerLoginRsp(_UI uiReqId,_VPTR hRoot)
{
    MOS_PARAM_NULL_RETERR(hRoot);

    _INT iValue  = 0;
    _UC *pStrTmp      = MOS_NULL;
    _UC *pucEncKey    = MOS_NULL;
    _UC *pucEnload    = MOS_NULL;
    _UC *pucToken     = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();

    do
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct %u MsgCt recv login rsp code %u",uiReqId,iValue);
        if(iValue != 0)
        {
            if (MsgMng_IPv6RollbackToIPv4(pstCmdServer) == MOS_ERR) // 登录应答失败
            {
                pstCmdServer->ucConnFailCount++;
                pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_ERROR;                
            }

            Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);
            break;
        }
        hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Time"),&pStrTmp); 
        
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncKey"),&pucEncKey);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncLoad"),&pucEnload);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncType"),&iValue);
        MsgMng_SetCmdLinkEncrypInf(iValue,pucEncKey,pucEnload);
        
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"TimeOut"),&iValue);
        if(iValue > 0 && iValue <= 256)
        {
            pstCmdServer->ucHeartInterval = iValue;
        }

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Token"),&pucToken);// 休眠设备token
        if (pucToken != MOS_NULL)
        {
            MOS_STRNCPY(pstCmdServer->aucSleepToken, pucToken, sizeof(pstCmdServer->aucSleepToken));
        }
        pstCmdServer->ucLoginFlag = EN_MSGMNG_CMDSERVER_FLAG_FINSH;
        EN_COUNT_VALUE CountLess2Value = (Mos_GetLLTickCount() - pstCmdServer->ullTimeReq >= 2000) ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
        Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_SUCCESS,CountLess2Value);
    }while(0);
    
    return MOS_OK;
}

_UC *MsgMng_BuildCmdServLoginJson(_UI uiOgctId)
{
    _UC *pStrTmp = MOS_NULL;
    _UC auMethod[8];
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    
    MOS_VSNPRINTF(auMethod, 8, "%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJCMD_LOGIN);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(auMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiOgctId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    Adpt_Json_AddItemToObject(hBody,(_UC*)"CTEI", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));

    Adpt_Json_AddItemToObject(hBody,(_UC*)"DevToken", Adpt_Json_CreateString(Config_GetCoreMng()->aucDevToken));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Version", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"InitFlag", Adpt_Json_CreateStrWithNum(Config_GetCoreMng()->uiCmdLoginStatus));
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"LoginJson InitFlag %u", Config_GetCoreMng()->uiCmdLoginStatus);

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}

// 登录信令服务器 异步处理
_INT MsgMng_CmdServerLogin(ST_MSGMNG_CMDSERVER* pstCmdServer,_CTIME_T timeNow)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    _INT iRet = 0;
    _UC *pStrTmp  = MOS_NULL;
    
    pstCmdServer->uiReqID = Mos_GetSessionId();
    
    // 组合登录信令服务器的json数据
    pStrTmp = MsgMng_BuildCmdServLoginJson(pstCmdServer->uiReqID);

    // 发送登录信令服务器的请求
    iRet = MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID,pstCmdServer->uiReqID,EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJCMD_LOGIN,
        pStrTmp,MOS_STRLEN(pStrTmp),MsgMng_ProcCmdServerLoginRsp);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct %u Msgct Send login requst body %s iret %d",pstCmdServer->uiReqID,pStrTmp,iRet);
   
    pstCmdServer->timeReq = timeNow;

    MOS_FREE(pStrTmp);
    return iRet;
}

/**********************************************************************
**********************************************************************/

// 获取向能力平台自注册的json数据
_UC *MsgMng_BuildSelfRegistJson(_INT iRefreshState)
{
    _INT iStatus        = 0;
    _UC *pStrTmp        = MOS_NULL;
    _UC ucTimeNow[32]   = {0};
    ST_ZJ_NETWORK_INFO  stNetInfo = {0};

    if(ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        iStatus = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetInfo);
        if (iStatus != MOS_OK)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunGetCurNetInfo Device Return error(%d)", iStatus);
            Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunGetCurNetInfo Is Null)");
        Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);
    }
    Config_SetCamerLocalIPv6Addr(0, stNetInfo.aucIPv6Addr);
    AvClient_SetLocalIPv6Addr(stNetInfo.aucIPv6Addr);
    MsgMng_MultiMediaSetLocalIPv6Addr(stNetInfo.aucIPv6Addr);
    ST_MOS_SYS_TIME stSysTime ;
    ST_MOS_INET_IPARRAY stIpArrayInfo = {0};
    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"VER",  Adpt_Json_CreateString((_UC *)"01"));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CTEI", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
#if 0
    _UC ucLocalIP[16]   = {0};
    _UC ucLocalIP1[16]  = {0};
    _UC ucUplinkIP[16]  = {0};
    _UC ucLocalMac[18]  = {0};
    _UC ucUplinkMac[18] = {0};
    Mos_InetGetLocalMac(ucLocalMac);
    MOS_PRINTF("%s:%d Local MAC:  %s \r\n", __FUNCTION__, __LINE__, ucLocalMac);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"MAC", Adpt_Json_CreateString(ucLocalMac));

    Mlin_InetGetLocalIps(&stIpArrayInfo);
    MOS_VSNPRINTF(ucLocalIP, 16,"%d:%d:%d:%d", stIpArrayInfo.astIps[0].u.aucIp[0]
                                             , stIpArrayInfo.astIps[0].u.aucIp[1]
                                             , stIpArrayInfo.astIps[0].u.aucIp[2]
                                             , stIpArrayInfo.astIps[0].u.aucIp[3]);
    MOS_PRINTF("%s:%d Local IP:   %s \r\n", __FUNCTION__, __LINE__, ucLocalIP);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"IP", Adpt_Json_CreateString(ucLocalIP));

    MOS_VSNPRINTF(ucLocalIP1, 16,"%d.%d.%d.%d", stIpArrayInfo.astIps[0].u.aucIp[0]
                                             , stIpArrayInfo.astIps[0].u.aucIp[1]
                                             , stIpArrayInfo.astIps[0].u.aucIp[2]
                                             , stIpArrayInfo.astIps[0].u.aucIp[3]);
    MOS_VSNPRINTF(ucUplinkIP, 16,"%d.%d.%d.%d", stIpArrayInfo.astIps[0].u.aucIp[0]
                                              , stIpArrayInfo.astIps[0].u.aucIp[1]
                                              , stIpArrayInfo.astIps[0].u.aucIp[2]
                                              , 1);
    MOS_PRINTF("%s:%d UPLINK IP:  %s \r\n", __FUNCTION__, __LINE__, ucUplinkIP);
    Mos_InetGetRemoteMac(ucLocalIP1, ucUplinkIP, ucUplinkMac);
    MOS_PRINTF("%s:%d UPLINK MAC: %s \r\n", __FUNCTION__, __LINE__, ucUplinkMac);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"UPLINKMAC", Adpt_Json_CreateString(ucUplinkMac));
#else
    if(MOS_STRLEN(stNetInfo.aucMacAddr))
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"MAC",Adpt_Json_CreateString(stNetInfo.aucMacAddr));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"MAC",Adpt_Json_CreateString((_UC*)""));
    }
    if(MOS_STRLEN(stNetInfo.aucIPAddr))
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"IP",Adpt_Json_CreateString(stNetInfo.aucIPAddr));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"IP",Adpt_Json_CreateString((_UC*)""));
    }
    // if(MOS_STRLEN(stNetInfo.aucIPv6Addr))
    // {
    //     Adpt_Json_AddItemToObject(hBody,(_UC*)"IPv6",Adpt_Json_CreateString(stNetInfo.aucIPv6Addr));
    // }
    // else
    // {
    //     Adpt_Json_AddItemToObject(hBody,(_UC*)"IPv6",Adpt_Json_CreateString((_UC*)""));
    // }
    if(MOS_STRLEN(stNetInfo.aucUpMacAddr))
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"UPLINKMAC",Adpt_Json_CreateString(stNetInfo.aucUpMacAddr));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"UPLINKMAC",Adpt_Json_CreateString((_UC*)""));
    }
#endif
    if (MsgMng_GetMng()->ucNetworkType == EN_ZJ_NETWORK_TYPE_NONSENSE)
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"LINK",  Adpt_Json_CreateStrWithNum(1));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"LINK",  Adpt_Json_CreateStrWithNum(0));
    }

    Adpt_Json_AddItemToObject(hBody,(_UC*)"FWVER", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    Mos_GetSysTime(&stSysTime); 
    MOS_VSNPRINTF(ucTimeNow, 32, "%04u-%02u-%02u %02u:%02u:%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond); 
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DATE", Adpt_Json_CreateString(ucTimeNow));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"UID",  Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"SN",   Adpt_Json_CreateString(Config_GetSystemMng()->aucDevSN));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"REFRESHSTATE", Adpt_Json_CreateStrWithNum(iRefreshState));
    pStrTmp = Adpt_Json_Print(hBody);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"dev Self Regist json %s", pStrTmp);
    Adpt_Json_Delete(hBody);
    return pStrTmp;
}

// 接收自注册返回的信息数据
_VOID MsgMng_UploadSelfRegInfoRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    if(g_stHttpGetTaskSelfReg.usBuffLen == 0)
    {
        g_stHttpGetTaskSelfReg.usBuffLen   = 1024;
        g_stHttpGetTaskSelfReg.pucHttpBuff = (_UC*)MOS_MALLOC(g_stHttpGetTaskSelfReg.usBuffLen);
    }
    if(g_stHttpGetTaskSelfReg.usRecvLen + uiLen < g_stHttpGetTaskSelfReg.usBuffLen)
    {
        MOS_MEMCPY(g_stHttpGetTaskSelfReg.pucHttpBuff + g_stHttpGetTaskSelfReg.usRecvLen, pucData, uiLen);
        g_stHttpGetTaskSelfReg.usRecvLen += uiLen;
    }

    return;
}

// 接收自注册信息数据结束
_VOID MsgMng_UploadSelfRegInfoFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    if(pstCmdServer != MOS_NULL)
    {
        EN_COUNT_VALUE CountLess2Value = Mos_Time() - pstCmdServer->timeSelfReg >= 2 ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
        Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_SUCCESS,CountLess2Value);
    }

    if(g_stHttpGetTaskSelfReg.pucHttpBuff)
    {
        g_stHttpGetTaskSelfReg.pucHttpBuff[g_stHttpGetTaskSelfReg.usRecvLen] = 0;
    }

    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR, "Upload SelfReg Info Finish Recv[%d] %s", g_stHttpGetTaskSelfReg.usRecvLen, g_stHttpGetTaskSelfReg.pucHttpBuff);
    MOS_FREE(g_stHttpGetTaskSelfReg.pucHttpBuff);
    g_stHttpGetTaskSelfReg.pucHttpBuff   = MOS_NULL;
    g_stHttpGetTaskSelfReg.usBuffLen     = 0;
    g_stHttpGetTaskSelfReg.usRecvLen     = 0;
    g_stHttpGetTaskSelfReg.uiHttpHandle  = 0;
    g_iUploadSelfRegistStatus            = 1;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_SELF_REGISTER, uiUseTime);

    return ;
}

// 接收自注册信息数据失败
_VOID MsgMng_UploadSelfRegInfoFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC ucUrl[256]         = {0};
    _UC aucMsgString[128]  = {0};

    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);
    MOS_SPRINTF(ucUrl, "%s/%s", Config_GetSystemMng()->aucPuAddr, MSGMNG_SELFREGISTION_URL);
    MOS_SPRINTF(aucMsgString, "%s Recv SelfRegist Rsp Failed",MSGMNG_REGIST_INFO_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), ucUrl, uiErrCode, EN_REGISTINFO_RT_RECV_SELFREGIST_RSP_FAIL, aucMsgString, 1);

    if(g_stHttpGetTaskSelfReg.pucHttpBuff)
    {
        MOS_LOG_ERR(MSGMNG_REGIST_INFO_STR,"Upload SelfReg Info Fail Recv %s",g_stHttpGetTaskSelfReg.pucHttpBuff);
    }
    MOS_FREE(g_stHttpGetTaskSelfReg.pucHttpBuff);
    g_stHttpGetTaskSelfReg.pucHttpBuff   = MOS_NULL;
    g_stHttpGetTaskSelfReg.usBuffLen     = 0;
    g_stHttpGetTaskSelfReg.usRecvLen     = 0;
    g_stHttpGetTaskSelfReg.uiHttpHandle  = 0;
    g_iUploadSelfRegistStatus            = 0;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_SELF_REGISTER, uiUseTime);

    return;
}

// 自注册信息上报
_INT MsgMng_SendSelfRegistInfoToCmdServ(_INT iRefreshState)
{
    _INT iRet                       = 0;
    _UC *pStrTmp                    = MOS_NULL;
    _UI uiHttpsFlag                 = 0;
    _UC  ucUrl[512]                 = {0};
    _UC  ucTemp[1]                  = {0};
    _UC  aucURLEnc[512]             = {0};
    _UC  auAdmonAddr[128]           = {0};
    ST_MOS_INET_IP stNetIp          = {0};

    // 创建关键接口质量信息节点 https://ehome.21cn.com/deviceInfo/deviceStatus
    MOS_VSNPRINTF(auAdmonAddr, sizeof(auAdmonAddr), "%s%s", Config_GetSystemMng()->aucReportAddr, MSGMNG_SELFREGISTION_URL);
    MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_SELF_REGISTER, auAdmonAddr);

    // 获取向能力平台自注册的json数据
    pStrTmp = MsgMng_BuildSelfRegistJson(iRefreshState);
    // 做url编码处理
    Adpt_Https_URLEncode((const char* )pStrTmp, MOS_STRLEN(pStrTmp), aucURLEnc, sizeof(aucURLEnc));

    MOS_VSNPRINTF(ucUrl, 512, "%s?jsonstr=%s", MSGMNG_SELFREGISTION_URL, aucURLEnc);
    // MOS_PRINTF("%s:%d SelfRegist: %s \r\n", __FUNCTION__, __LINE__, ucUrl);

    MOS_MEMSET(auAdmonAddr, 0, 128);
    // 获取平台域名地址
    Http_Parse_Url(Config_GetSystemMng()->aucReportAddr, auAdmonAddr, ucTemp, &uiHttpsFlag);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.pfuncRecv       = MsgMng_UploadSelfRegInfoRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_UploadSelfRegInfoFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_UploadSelfRegInfoFail;
    stHttpInfoNode.iTimeOut        = 15;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, ucUrl, EN_HTTP_METHOD_GET, Mos_GetSessionId());
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"dev %s ,Upload SelfReg Info:%s From SelfRegAddr %s:%s ,ret %d",
        Config_GetSystemMng()->aucDevUID, ucUrl, auAdmonAddr, MSGMNG_SELFREGISTION_URL, iRet);
    if (iRet != MOS_OK)
    {
        // MOS_SPRINTF(ucUrl, "%s/%s", Config_GetSystemMng()->aucReportAddr, MSGMNG_SELFREGISTION_URL);
        CloudStg_UploadLog(Mos_GetSessionId(), ucUrl, 0, EN_REPORT_RT_EHOME_FAIL, "report capability platform failed", 1);
    }
    
    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}
/**********************************************************************
**********************************************************************/
// 发送心跳
_INT MsgMng_SendHeatBeatToCmdServ(ST_MSGMNG_CMDSERVER* pstCmdServer, _CTIME_T timeNow)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    MsgMng_SendDataToCmdServer(0x00, 0x00, MOS_NULL, 0);
    MOS_PRINTF("Send HeartBeat Packet To PLATFROM !!! timeNow:%u\r\n", timeNow);
    // pstCmdServer->ucHeartCount++;
    // 已发送信令心跳包
    pstCmdServer->ucSendHeartFlag = 1;
    // 记录发送信令心跳包时间点
    pstCmdServer->timePing = timeNow;
    return MOS_OK;
}

static _INT g_iIsFirstTimeFlag    = 1;
static _INT g_iCmdServerStatusBak = EN_MSGMNG_CMDSERVER_STATUS_INIT;
// 处理信令服务器注册登录流程
_INT MsgMng_ProcCmdServerStatus(_CTIME_T timeNow)
{
    _INT iRtn = MOS_ERR;
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();

    if (g_iIsFirstTimeFlag)
    {
        g_iIsFirstTimeFlag    = 0;
        g_iCmdServerStatusBak = pstCmdServer->ucStatus;
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"{{{{{{{{{{ Go To Online pstCmdServer->ucStatus: %d   ucNetworkType:%d }}}}}}}}}}}\r\n", 
                        g_iCmdServerStatusBak, MsgMng_GetMng()->ucNetworkType);
    }
    else
    {
        if (g_iCmdServerStatusBak != pstCmdServer->ucStatus)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"{{{{{{{{{{ Go To Online pstCmdServer->ucStatus: %d change to %d  ucNetworkType:%d }}}}}}}}}}}\r\n", 
                        g_iCmdServerStatusBak, pstCmdServer->ucStatus, MsgMng_GetMng()->ucNetworkType);
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ucPdmUpStatus : %d   ucSmartHomeStatus : %d\r\n", MsgMng_PDM_GetMng()->ucPdmUpStatus,MsgMng_SmartHome_GetMng()->ucSmartHomeStatus);
            g_iCmdServerStatusBak = pstCmdServer->ucStatus;
        }
    }
    
    // 无网和ap热点
    if(MsgMng_GetMng()->ucNetworkType == EN_ZJ_NETWORK_TYPE_NONET || EN_ZJ_NETWORK_TYPE_AP == MsgMng_GetMng()->ucNetworkType)
    {
        return iRtn;
    }
    
    // 信令服务器正在重置
    if(pstCmdServer->ucResetFlag == 1)
    {
        pstCmdServer->ucResetFlag = 0;
        pstCmdServer->ucReGetAddrFlag = 1;
        pstCmdServer->ucStatus    = EN_MSGMNG_CMDSERVER_STATUS_ERROR;
    }

    if (pstCmdServer->ucRouteStatus != EN_MSGMNG_ROUTE_STATUS_SUCCESS)
    {
        return iRtn;
    }
    // 信令服务器状态
    switch(pstCmdServer->ucStatus)
    {
        // 信令服务器初始化状态
        case EN_MSGMNG_CMDSERVER_STATUS_INIT:
        {
            if(Config_GetCamaraMng()->uiPolicyDomainAbility >= 1)
            {
                // 连续3次获取信令服务器地址失败时，重新获取调度域名
                if(pstCmdServer->ucGetMsgAddrCount > 12 || pstCmdServer->ucConnFailCount > 3)//失败超时为45秒，失败13次后重新调度（即10分钟左右重试）
                {
                    pstCmdServer->ucGetMsgAddrCount = 0;
                    pstCmdServer->ucConnFailCount   = 0;
                    pstCmdServer->ucRouteReGetFlag  = EN_MSGMNG_ROUTE_REGET_NOW;
                    break;
                }
            }

            if(pstCmdServer->ucConnFailCount == 0 || pstCmdServer->ucReGetAddrFlag == 1)
            {
                pstCmdServer->ucGetMsgAddrCount++;
                // 去能力平台注册 获取信令服务器地址和aes密钥 异步处理
                if (MsgMng_AblityPlatRegist() == MOS_OK)
                {
                    pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_DOING;
                    pstCmdServer->timeReq      = timeNow;
                    pstCmdServer->ucStatus     = EN_MSGMNG_CMDSERVER_STATUS_REGISTING;
                }
                // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"-------------------- EN_MSGMNG_CMDSERVER_STATUS_REGIST --------------------");
            }
            else
            {
                // 异常处理
                if(pstCmdServer->ucConnFailCount > 3)
                {
                    pstCmdServer->ucGetMsgAddrCount++;
                    if (MsgMng_ReGetCmdServerAddr() != MOS_ERR)
                    {
                        pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_DOING;
                        pstCmdServer->ucConnFailCount = 0;
                        pstCmdServer->timeReq         = timeNow;
                        pstCmdServer->ucStatus        = EN_MSGMNG_CMDSERVER_STATUS_REGISTING;
                    }
                }
                // 尝试连接
                else if(pstCmdServer->timeReq != 0 && (timeNow - pstCmdServer->timeReq > 3*(1 + 2*pstCmdServer->ucConnFailCount)))
                {
                    pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_STARTCONN;
                }
                else if(pstCmdServer->timeReq == 0)
                {
                    pstCmdServer->ucConnFailCount = 0;
                    pstCmdServer->ucReGetAddrFlag = 1;
                }
             }
            break;
        }
        // 注册信令服务器  异步等待 MsgMng_AblityPlatRegist 能力平台注册完成 获取信令服务器地址和aes密钥
        case EN_MSGMNG_CMDSERVER_STATUS_REGISTING:
        {
            if(pstCmdServer->ucRegistFlag != EN_MSGMNG_CMDSERVER_FLAG_FINSH && (_UI)(timeNow - pstCmdServer->timeReq) > MSGMNG_CMDSERVER_REGETADDRTIME)
            {
                pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_INIT;
            }
            else if(pstCmdServer->ucRegistFlag == EN_MSGMNG_CMDSERVER_FLAG_FINSH)
            {
                pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_STARTCONN;
                pstCmdServer->ucReGetAddrFlag = 0;
            }
            break;
        }
        // 开始连接信令服务器
        case EN_MSGMNG_CMDSERVER_STATUS_STARTCONN:
        {
            // 连接信令服务器 异步处理
            // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"-------------------- EN_MSGMNG_CMDSERVER_STATUS_CONNECT --------------------");
            // 设备支持IPv6 优先使用IPv6进行连接
            int iRet = MOS_ERR;
            if (Config_GetCamaraMng()->uiIPv6Ability && Config_GetCamaraMng()->uiIPv6Switch)
            {
                if (pstCmdServer->bRollbackToIPv4 == MOS_FALSE)
                {
                    iRet = MsgMng_ConnectCmdServerIPv6(pstCmdServer,timeNow);
                }
                else
                {
                    iRet = MsgMng_ConnectCmdServerIPv4(pstCmdServer,timeNow);
                }
                pstCmdServer->bRollbackToIPv4 = MOS_FALSE;
            }
            else
            {
                iRet = MsgMng_ConnectCmdServerIPv4(pstCmdServer,timeNow);
            }
            pstCmdServer->timeReq    = timeNow;
            
            if(iRet == MOS_OK)
            {
                if (pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_DOING)
                {
                    pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_CONNECTING;
                }
                else if (pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_FINSH)
                {
                    pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_CONNECTED;
                }
            }
            else
            {
                if (MsgMng_IPv6RollbackToIPv4(pstCmdServer) == MOS_ERR) // socket连接失败
                {
                    pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_ERROR;
                    pstCmdServer->ucConnFailCount++;
                }
            }
            break;
        }
        // 正在连接信令服务器 异步等待 MsgMng_ConnectCmdServer 
        case EN_MSGMNG_CMDSERVER_STATUS_CONNECTING:
        {
            // if (Mos_SockCheckBoolConnectLink(pstCmdServer->isockFd) == MOS_TRUE)
            // {
            //     pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_CONNECTED;
            // }

            if (pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_FINSH)
            {
                if (pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV4)
                {
                    Config_SetCamerMsgConnectNetType(0, 0);
                }
                else
                {
                    Config_SetCamerMsgConnectNetType(0, 1);
                }
                pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_CONNECTED;
            }
            else
            {
                if (pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV6)
                {
                    if (pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_ERROR || 
                        pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_NOTYET || 
                        (Mos_GetLLTickCount() - pstCmdServer->ullTimeReq) > MOS_INET_IPV6_TIMEOUT_MS)
                    {
                        MsgMng_IPv6RollbackToIPv4(pstCmdServer);// 连接失败、超时500ms
                    }
                }
                else if (pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV4)
                {
                    if (pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_ERROR || 
                        pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_NOTYET || 
                        (Mos_GetLLTickCount() - pstCmdServer->ullTimeReq) > 1000*MSGMNG_CMDSERVER_CONNTIME)
                    {
                        pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_ERROR;
                        pstCmdServer->ucConnFailCount++;
                    }
                }
            }
            break;
        }
        // 连接上信令服务器
        case EN_MSGMNG_CMDSERVER_STATUS_CONNECTED:
        {
            // 登录信令服务器 异步处理
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"-------------------- EN_MSGMNG_CMDSERVER_STATUS_LOGIN --------------------");
            pstCmdServer->ucLoginFlag = EN_MSGMNG_CMDSERVER_FLAG_DOING;
            MsgMng_CmdServerLogin(pstCmdServer,timeNow);
            pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_LOGINING;
            break;
        }
        // 正在登录信令服务器
        case EN_MSGMNG_CMDSERVER_STATUS_LOGINING:
        {
            // 登录信令服务器成功
            if(pstCmdServer->ucLoginFlag == EN_MSGMNG_CMDSERVER_FLAG_FINSH)
            {
                pstCmdServer->ucGetMsgAddrCount = 0;
                pstCmdServer->ucConnFailCount   = 0;
                // 先自注册信息上报 获取设备的网络信息，用于提供上线时候的云涛日志使用
                iRtn = MsgMng_SendSelfRegistInfoToCmdServ(0);
                if (iRtn != MOS_OK)
                {   
                    g_iUploadSelfRegistStatus = 0;                    
                }

                // 通知厂商设备已上线
                Config_SetDeviOnlineStatus(EN_ZJ_DEVICE_STATUS_ONLINE);
                if (pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV4)
                {
                    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"msg login succeed ipv4 time: %llu", Mos_GetLLTickCount() - pstCmdServer->ullTimeReq);
                }
                else if (pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV6)
                {
                    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"msg login succeed ipv6 time: %llu", Mos_GetLLTickCount() - pstCmdServer->ullTimeReq);
                }

                pstCmdServer->timePing    = timeNow;
                pstCmdServer->timeSelfReg = timeNow;
                // 第一次登录信令服务状态 initflag = 0
                Config_SetCmdLoginStatus(EN_CMDLOGIN_STATUS_REBOOT);
                pstCmdServer->ucStatus    = EN_MSGMNG_CMDSERVER_STATUS_PROCESS;
                Config_SetSLeepMonotorForceNotify(); //配网后，强制通知

                // 当获取设备外网IP功能开关开启时
                if (Config_GetDeviceMng()->uiGetDevOuterIPStatus == EN_GETOUTERIP_STATUS_OPEN)
                {
                    // 获取外网IP管理结构体
                    ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();
                    // 记录设备上线时间点
                    g_stOuterIPMng->cDevOnlineTime    = timeNow;
                    // 设置触发获取设备外网IP的类型为设备上线
                    g_stOuterIPMng->iCheckOuterIPType = EN_MSG_CHECK_OUTERIP_TYPE_DEV_ONLINE;
                    // 设置未获取设备外网IP的冷却随机时长标记
                    g_stOuterIPMng->iGetRandomTimeDurationFlag = 0;
                }
                break;
            }
            if (pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV6)
            {
                // ipv6 “登录中”->“登录成功”的时间，判断超时延长到3*500ms，避免常规网络波动导致登录失败
                if (pstCmdServer->ucLoginFlag == EN_MSGMNG_CMDSERVER_FLAG_ERROR || 
                    ((Mos_GetLLTickCount() - pstCmdServer->ullTimeReq) > 3*MOS_INET_IPV6_TIMEOUT_MS))
                {
                    MsgMng_IPv6RollbackToIPv4(pstCmdServer);// 登录失败，超时1500毫秒
                }
            }
            else if (pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV4)
            {
                if (pstCmdServer->ucLoginFlag == EN_MSGMNG_CMDSERVER_FLAG_ERROR || ((Mos_GetLLTickCount() - pstCmdServer->ullTimeReq) > 30*1000))
                {
                    pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_ERROR;
                    pstCmdServer->ucConnFailCount++;
                }
            }

            break;
        }
        // 登录信令服务器成功
        case EN_MSGMNG_CMDSERVER_STATUS_PROCESS:
        {
            if ((_UI)(timeNow -  pstCmdServer->timePing) >= pstCmdServer->ucHeartInterval)
            {
                // 发送心跳
                MsgMng_SendHeatBeatToCmdServ(pstCmdServer, timeNow);
            }

            // 已发送心跳包，未回复
            if (pstCmdServer->ucSendHeartFlag == 1)
            {
                // 能力中台响应设备心跳包的超时时长为3秒
                if ((_UI)(timeNow -  pstCmdServer->timePing) > 3)
                {
                    // 心跳失败次数+1
                    pstCmdServer->ucHeartFailCount++;
                    // 心跳超时，标记心跳包为未发送，待下次心跳包发送
                    pstCmdServer->ucSendHeartFlag = 0;
                    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "-------------------- Check Heart FailCount:%d --------------------", pstCmdServer->ucHeartFailCount);

                    // 当获取设备外网IP功能开关开启时
                    if (Config_GetDeviceMng()->uiGetDevOuterIPStatus == EN_GETOUTERIP_STATUS_OPEN)
                    {
                        // 获取外网IP管理结构体
                        ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();
                        // 第一次心跳超时
                        if (pstCmdServer->ucHeartFailCount == 1)
                        {
                            // 设置触发获取设备外网IP的类型为信令心跳包丢失(超时)
                            g_stOuterIPMng->iCheckOuterIPType = EN_MSG_CHECK_OUTERIP_TYPE_HEART_LOST;
                        }
                        // 第二次心跳超时
                        else if (pstCmdServer->ucHeartFailCount == 2)
                        {
                            // 若第一次心跳包超时获取设备外网IP超时，第二次心跳包超时时继续获取设备外网IP
                            if (g_stOuterIPMng->iGetOutIPTimeOutFlag == 1)
                            {
                                // 设置触发获取设备外网IP的类型为信令心跳包丢失(超时)
                                g_stOuterIPMng->iCheckOuterIPType = EN_MSG_CHECK_OUTERIP_TYPE_HEART_LOST;
                                g_stOuterIPMng->iGetOutIPTimeOutFlag = 0;
                            }
                        }
                    }

                    // if (pstCmdServer->ucHeartCount > 3)
                    if (pstCmdServer->ucHeartFailCount >= 3)
                    {
                        _UC aucMsgString[128] = {0};
                        MOS_SPRINTF(aucMsgString, "%s Check MsgPlat Heart TimeOut", MSGMNG_REGIST_INFO_STR);
                        CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, -1, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_HEART_TIMEOUT, aucMsgString, 1);
                        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "-------------------- Check Heart TimeOut --------------------");
                        // pstCmdServer->ucHeartCount = 0;
                        pstCmdServer->ucHeartFailCount = 0;
                        pstCmdServer->ucConnFailCount++;    
                        pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_ERROR;
                        // 当获取设备外网IP功能开关开启时
                        if (Config_GetDeviceMng()->uiGetDevOuterIPStatus == EN_GETOUTERIP_STATUS_OPEN)
                        {
                            // 获取外网IP管理结构体
                            ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();
                            g_stOuterIPMng->iGetOutIPTimeOutFlag = 0;
                        }
                    }
                }
            }

            if (g_iUploadSelfRegistStatus == 1)
            {
                if ((_UI)(timeNow -  pstCmdServer->timeSelfReg) > MSGMNG_CMDSERVER_SELFREGISTION_SUCCESS)
                {
                    // 自注册信息上报
                    iRtn = MsgMng_SendSelfRegistInfoToCmdServ(1);
                    if (iRtn != MOS_OK)
                    {   
                        g_iUploadSelfRegistStatus = 0;                    
                    }
                    pstCmdServer->timeSelfReg = timeNow;
                }
            }
            else
            {
                if ((_UI)(timeNow -  pstCmdServer->timeSelfReg) > MSGMNG_CMDSERVER_SELFREGISTION_ERROR)
                {
                    // 自注册信息上报
                    MsgMng_SendSelfRegistInfoToCmdServ(0);
                    pstCmdServer->timeSelfReg = timeNow;
                }
            }

            break;
        }
        // 信令服务器出错
        case EN_MSGMNG_CMDSERVER_STATUS_ERROR:
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"-------------------- EN_MSGMNG_CMDSERVER_STATUS_ERROR --------------------");
            if (pstCmdServer->ucLoginFlag != EN_MSGMNG_CMDSERVER_FLAG_FINSH)
            {
                // 打印登录失败信息
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"msg login failed time: %llu", Mos_GetLLTickCount() - pstCmdServer->ullTimeReq);
            }
            pstCmdServer->ucLoginFlag = EN_MSGMNG_CMDSERVER_FLAG_NOTYET;
            pstCmdServer->timeReq     = timeNow;
            pstCmdServer->ucStatus    = EN_MSGMNG_CMDSERVER_STATUS_INIT;
            pstCmdServer->uiConnectType = EN_MSGMNG_CONNECT_NOTYET;
            Mos_InitSockBuf(pstCmdServer->pstRecvB);
            Mos_InitSockBuf(pstCmdServer->pstSendB);
            if(pstCmdServer->isockFd != MOS_SOCKET_INVALID)
            {
                Mos_SocketClose(pstCmdServer->isockFd);
                pstCmdServer->isockFd = MOS_SOCKET_INVALID;
            }
            Config_SetDeviOnlineStatus(EN_ZJ_DEVICE_STATUS_OFFLINE);
            break;
        }
        // 信令服务器反初始化状态
        case EN_MSGMNG_CMDSERVER_STATUS_DEINIT:
        {
            if(pstCmdServer->isockFd != MOS_SOCKET_INVALID)
            {
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"-------------------- EN_MSGMNG_CMDSERVER_STATUS_DEINIT --------------------");
                Mos_InitSockBuf(pstCmdServer->pstRecvB);
                Mos_InitSockBuf(pstCmdServer->pstSendB);
                Mos_SocketClose(pstCmdServer->isockFd);
                pstCmdServer->isockFd = MOS_SOCKET_INVALID;
                Config_SetDeviOnlineStatus(EN_ZJ_DEVICE_STATUS_OFFLINE);
            }
            break;
        }
        default:
        {

        }
    }
    return MOS_OK;
}

// 处理动态域名获取流程
static _INT g_iIsFirstRouteFlag  = 1;
static _INT g_iRouteStatusBak    = EN_MSGMNG_ROUTE_STATUS_INIT;
static _UI  uiTmpRouteRetryTime  = 0;
_INT MsgMng_ProcRouteStatus(_CTIME_T timeNow)
{
    _INT iRtn                         = MOS_ERR;
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    if(Config_GetCamaraMng()->uiPolicyDomainAbility >= 1)
    {
        // 无网和ap热点
        if(MsgMng_GetMng()->ucNetworkType == EN_ZJ_NETWORK_TYPE_NONET || EN_ZJ_NETWORK_TYPE_AP == MsgMng_GetMng()->ucNetworkType)
        {
            return iRtn;
        }

        // 状态变更时输出打印信息
        if (g_iIsFirstRouteFlag)
        {
            g_iIsFirstRouteFlag    = 0;
            g_iRouteStatusBak = pstCmdServer->ucRouteStatus;
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"{{{{{{{{{{ Go To Online pstCmdServer->ucRouteStatus: %d   ucNetworkType:%d }}}}}}}}}}}\r\n", 
                            g_iRouteStatusBak, MsgMng_GetMng()->ucNetworkType);
        }
        else
        {
            if (g_iRouteStatusBak != pstCmdServer->ucRouteStatus)
            {
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"{{{{{{{{{{ Go To Online pstCmdServer->ucRouteStatus: %d change to %d  ucNetworkType:%d }}}}}}}}}}}\r\n", 
                            g_iRouteStatusBak, pstCmdServer->ucRouteStatus, MsgMng_GetMng()->ucNetworkType);
                g_iRouteStatusBak = pstCmdServer->ucRouteStatus;
            }
        }    

        if ((pstCmdServer->ucRouteReGetFlag == EN_MSGMNG_ROUTE_REGET_NOW) || \
                ((pstCmdServer->ucRouteReGetFlag == EN_MSGMNG_ROUTE_REGET_LATER) && (((_UI)(timeNow -  pstCmdServer->timeRouteReq) > pstCmdServer->uiRouteReGetSec) || ((_UI)(timeNow -  pstCmdServer->timeRouteReq) > 60))))
        {
            MsgMng_ResetCmdServer(pstCmdServer);
            MsgMng_ResetRouteParam(pstCmdServer);
        }
        else if (pstCmdServer->ucRouteStatus == EN_MSGMNG_ROUTE_STATUS_SUCCESS)
        {
            pstCmdServer->ucRouteFailCount = 0;
            if (uiIsStartWork != 1)
            {
                uiIsStartWork = 1;
            }
            return iRtn;
        }         

        switch (pstCmdServer->ucRouteStatus)
        {
            case EN_MSGMNG_ROUTE_STATUS_INIT:
            {
                if(pstCmdServer->ucRouteFailCount == 0 || \
                    (_UI)(timeNow -  pstCmdServer->timeRouteReq) > uiTmpRouteRetryTime)
                {
                    if (MsgMng_AblityGetRouteStatus() == MOS_OK)
                    {
                        pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_WORKING;
                    }
                    else
                    {
                        pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
                    }
                    pstCmdServer->timeRouteReq = timeNow;
                }         
                break;
            }
            case EN_MSGMNG_ROUTE_STATUS_WORKING:
            {
                if ((_UI)(timeNow - pstCmdServer->timeRouteReq) >= MSGMNG_CMDSERVER_GETROUTETIMEOUT)
                {
                    pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
                }
                break;
            }      
            case EN_MSGMNG_ROUTE_STATUS_SUCCESS:
            {
                pstCmdServer->ucRouteFailCount = 0;
                uiIsStartWork = 1;
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"RegistRoute Get Route Status Successful");
                break;
            }
            case EN_MSGMNG_ROUTE_STATUS_FAIL:
            {
                if (pstCmdServer->ucRouteFailCount < 255)
                {
                    pstCmdServer->ucRouteFailCount++;
                    if(pstCmdServer->ucRouteFailCount >= 3 && Config_GetSystemMng()->uiSetDomainFlag == 1)
                    {
                        uiIsStartWork = 1;
                    }
                }
                pstCmdServer->timeRouteReq  = timeNow;
                pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_INIT;
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"RegistRoute Get Route Status Failed(%d) !",pstCmdServer->ucRouteFailCount);

                if(pstCmdServer->ucRouteFailCount >= 0 && pstCmdServer->ucRouteFailCount <=7)
                {
                    uiTmpRouteRetryTime = uiRouteRetryTime[pstCmdServer->ucRouteFailCount];
                }
                else
                {
                    //选择一个randtime
                    srand((unsigned)time(NULL));
                    _UI uiRanTime = rand() % 600;
                    uiTmpRouteRetryTime = 360 + uiRanTime;
                }
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"RegistRoute Get Route After %d s",uiTmpRouteRetryTime);
                break;
            }
            default:
            {
                pstCmdServer->ucRouteFailCount = 0;
                pstCmdServer->timeRouteReq     = timeNow;
                pstCmdServer->ucRouteStatus    = EN_MSGMNG_ROUTE_STATUS_FAIL;
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"RegistRoute Get Route Status Is Other");
                break;
            }
        }  
    }
    else
    {
        pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_SUCCESS;
        if (uiIsStartWork != 1)
        {
            uiIsStartWork = 1;
        }        
    }
    return MOS_OK;
}

// 回复信令结果
_INT MsgMng_SendCmdServerBuffer()
{
    _UI uiDataLen;
    _INT iRetLen = 0;
    _BOOL bBlocked = MOS_FALSE;
    _BOOL bCloseCmdServerFlag = MOS_FALSE;
    ST_MOS_SOCKBUF* pstTmp1 = MOS_NULL;
    static _UC aucRebootRsp[] = {0x23, 0x24, 0x34, 0x13};
    static _UC aucResetRsp[]  = {0x23, 0x24, 0x34, 0x17};

    // 获取回复的信令结果
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
     
    if(pstCmdServer->isockFd == MOS_SOCKET_INVALID || pstCmdServer->ucConnectFlag != EN_MSGMNG_CMDSERVER_FLAG_FINSH)
    {
        return MOS_OK;
    }
    Mos_MutexLock(&pstCmdServer->hMutexSendB);
    uiDataLen = MOS_BLEN(pstCmdServer->pstSendB);
    if(uiDataLen == 0)
    {
        Mos_MutexUnLock(&pstCmdServer->hMutexSendB);
        return MOS_OK;
    }

    if (pstCmdServer->uiForceCloseCmdFlag == 1 &&
       (MOS_MEMCMP(MOS_BPTR(pstCmdServer->pstSendB), aucRebootRsp, 4) == 0 ||
        MOS_MEMCMP(MOS_BPTR(pstCmdServer->pstSendB), aucResetRsp, 4) == 0))
    {
        MOS_PRINTF("detect reset or reboot rsp...\r\n");
        bCloseCmdServerFlag = MOS_TRUE;
    }
    
    do 
    {
        // BUF_PRINTF_EX("MOS_BPTR(pstCmdServer->pstSendB)", MOS_BPTR(pstCmdServer->pstSendB), uiDataLen);
        // 发送回复的信令结果 或者登录信息
        iRetLen = Mos_SocketSend(pstCmdServer->isockFd, MOS_BPTR(pstCmdServer->pstSendB), uiDataLen, &bBlocked);
        if (iRetLen <= 0)
        {
            if (!bBlocked)
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "Cmd server send data err %d",errno);

                if (MsgMng_IPv6RollbackToIPv4(pstCmdServer) == MOS_ERR) //socket 发送失败
                {
                    if(pstCmdServer->isockFd!= MOS_SOCKET_INVALID)
                    {
                        Mos_SocketClose(pstCmdServer->isockFd);
                        pstCmdServer->isockFd = MOS_SOCKET_INVALID;
                    }
                    pstCmdServer->ucConnFailCount++;
                    pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_ERROR;
                }
            }
            break;
        }
        else if (iRetLen == MOS_BLEN(pstCmdServer->pstSendB))
        {
            if (pstCmdServer->pstSendB->pstNext != MOS_NULL)
            {
                pstTmp1 = pstCmdServer->pstSendB;
                pstCmdServer->pstSendB = pstCmdServer->pstSendB->pstNext;
                pstTmp1->pstNext = MOS_NULL;

                uiDataLen = MOS_BLEN(pstCmdServer->pstSendB);
            }
            else
            {
                Mos_InitSockBuf(pstCmdServer->pstSendB);
            }
        }
        else if (iRetLen < MOS_BLEN(pstCmdServer->pstSendB))
        {
            MOS_BOFF(pstCmdServer->pstSendB) += iRetLen;
            MOS_BLEN(pstCmdServer->pstSendB) -= iRetLen;
        }
        if (pstTmp1 != MOS_NULL)
        {
            Mos_PushSockBuf(pstCmdServer->hSockBuffPool, pstTmp1);
            pstTmp1 = MOS_NULL;
        }
    } while (pstCmdServer->pstSendB->pstNext && uiDataLen);
    Mos_MutexUnLock(&pstCmdServer->hMutexSendB);
    if (bCloseCmdServerFlag)
    {
        Mos_Sleep(1000);
        MsgMng_CloseCmdServer();
    }
    return iRetLen;
}

// 处理接受到信令服务器下发的信令 (解密解json包)
_INT MsgMng_ProcCmdServerRecv(ST_MSGMNG_CMDSERVER* pstCmdServer)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    _INT iRetLen = 0;
    _BOOL bClosed = MOS_FALSE;
    _UI uiByteLen = pstCmdServer->uiPayloadLen - MOS_BOFF(pstCmdServer->pstRecvB) - MOS_BLEN(pstCmdServer->pstRecvB);

    // 接受到信令服务器下发的信令
    iRetLen = Mos_SocketRecv(pstCmdServer->isockFd, (_VPTR)(MOS_BEND(pstCmdServer->pstRecvB)), uiByteLen, &bClosed);
    if(iRetLen > 0){
        MOS_BLEN(pstCmdServer->pstRecvB) += iRetLen;
        // pstCmdServer->ucHeartCount = 0;
        pstCmdServer->ucHeartFailCount = 0; // 接收到信令也意味着接收到信令心跳包

        // 处理信令服务器下发的信令 
        MsgMng_ParseCmdServerData(pstCmdServer);
    }
    else if(bClosed == MOS_TRUE || iRetLen == 0)  // recv ret 0 means the socket is closed by server
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Cmd Server rcv data err %u  buff len %d",errno,uiByteLen);

        if (MsgMng_IPv6RollbackToIPv4(pstCmdServer) == MOS_ERR) //socket 接收失败
        {
            if(pstCmdServer->isockFd!= MOS_SOCKET_INVALID)
            {
                Mos_SocketClose(pstCmdServer->isockFd);
                pstCmdServer->isockFd = MOS_SOCKET_INVALID;
            }
            pstCmdServer->ucConnFailCount++;
            pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_ERROR;            
        }

        return MOS_ERR;
    }
    return iRetLen;
}

_INT MsgMng_RspEncKeyChangeNotice(_UI uiSeqId)
{
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[8] = {0};
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    
    MOS_SPRINTF(aucMethod, (_UC*)"%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_LINK_KEYCHG_NTC_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(0));
    pStrTmp = Adpt_Json_Print(hRoot);

    MsgMng_SendDataToCmdServer(EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_LINK_KEYCHG_NTC_RSP,pStrTmp,MOS_STRLEN(pStrTmp));
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

static _INT MsgMng_RspRouteChangeNotice()
{
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[8] = {0};
    _UI uiSeqId = 1;
    JSON_HANDLE hFromObject = MOS_NULL;
    JSON_HANDLE hToObject   = MOS_NULL;

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, (_UC*)"%02X%02X",EN_OGCT_METHOD_ENCKEY,EN_OGCT_METHOD_ENCKEY_ERR_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(0));

    hFromObject = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"FROM",hFromObject);
    Adpt_Json_AddItemToObject(hFromObject,(_UC*)"DID",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));

    hToObject = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"TO",hToObject);

    pStrTmp = Adpt_Json_Print(hRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"pStrTmp : %s",pStrTmp);

    MsgMng_SendDataToCmdServer(EN_OGCT_METHOD_ENCKEY,EN_OGCT_METHOD_ENCKEY_ERR_RSP, pStrTmp, MOS_STRLEN(pStrTmp));

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 处理信令服务器下发的信令
static _INT MsgMng_ProcCmdServerMsg(ST_MSGMNG_CMDSERVER* pstCmdServer,_UC *pucMsgBuff,_INT iMsgBuffLen)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);
    MOS_PARAM_NULL_RETERR(pucMsgBuff);

    _INT iSeqID = 0;
    _UC aucMethod[8];
    _UC *pucMethod = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_OGCT_PROTOCAL_HEAD stOgctHead;
    ST_HTTP_ENCRYPTO_INF *pstEncrypInf = MOS_NULL;
   
    if(iMsgBuffLen < sizeof(stOgctHead))
    {
        return 0;
    }
    MOS_MEMCPY(&stOgctHead, pucMsgBuff, sizeof(ST_OGCT_PROTOCAL_HEAD));
    if(stOgctHead.aucheck[0] != '#' || stOgctHead.aucheck[1] != '$')
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"parse msg head err");
        return -1;
    }
    stOgctHead.usBodyLen = MOS_INET_NTOHS(stOgctHead.usBodyLen);
    if(stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD) > (_US)iMsgBuffLen)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"parse msg len err [bodylen=%d bufflen=%d]", stOgctHead.usBodyLen,iMsgBuffLen);
        return 0;
    }
    
    pucMsgBuff  += sizeof(ST_OGCT_PROTOCAL_HEAD);
    iMsgBuffLen -= sizeof(ST_OGCT_PROTOCAL_HEAD);

    if(pstCmdServer->ucLoginFlag != EN_MSGMNG_CMDSERVER_FLAG_FINSH)
    {
        pstEncrypInf = &pstCmdServer->stPlatEncryInf;
    }
    else
    {
        pstEncrypInf = &pstCmdServer->stEncrypInf;
    }
    if(stOgctHead.ucMsgType == EN_OGCT_METHOD_ENCKEY && stOgctHead.ucMsgId == EN_OGCT_METHOD_ENCKEY_ERR_REQ)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Recv EncKey Changge notice");
        // 处理信令服务器下发的信令
        MsgMng_RspRouteChangeNotice();

        if(Config_GetCamaraMng()->uiPolicyDomainAbility >= 1)
        {
            pstCmdServer->ucRouteReGetFlag  = EN_MSGMNG_ROUTE_REGET_LATER;
            pstCmdServer->timeRouteReq      = Mos_Time();
            pstCmdServer->uiRouteReGetSec   = 3;//3秒后重调度
        }
        else
        {
            pstCmdServer->ucReGetAddrFlag   = 1;    
            pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_ERROR;
        }
        return sizeof(ST_OGCT_PROTOCAL_HEAD);
    }
    // 此为平台响应的心跳包
    if(stOgctHead.usBodyLen == 0)
    {
        // FIXME
        // pucMsgBuff  -= sizeof(ST_OGCT_PROTOCAL_HEAD);
        // BUF_PRINTF_EX("HEAD", pucMsgBuff, sizeof(ST_OGCT_PROTOCAL_HEAD));
        #if 1
        // MOS_PRINTF("ucMsgType:0x%x  ucMsgId:0x%x \r\n",stOgctHead.ucMsgType, stOgctHead.ucMsgId);
        // 能力中台对设备发送的0x00 0x00心跳包的响应
        if (stOgctHead.ucMsgType == 0xff && stOgctHead.ucMsgId == 0xff)
        {
            MOS_PRINTF("This is a HeartBeat Packet Coming !!! \r\n");
            // 心跳包已回复，标记为未发送心跳包，待下次发送心跳包
            pstCmdServer->ucSendHeartFlag  = 0;
            // 心跳包已回复，心跳包失败次数清零
            pstCmdServer->ucHeartFailCount = 0;
        }
        // 低功耗设备远程唤醒设备的包
        else if (stOgctHead.ucMsgType == 0xff && stOgctHead.ucMsgId == 0x00)
        {
            // MOS_PRINTF("This is a Awake Device Packet Coming !!! \r\n");
        }
        // 低功耗设备 休眠时的心跳包
        else if (stOgctHead.ucMsgType == 0x00 && stOgctHead.ucMsgId == 0xff)
        {
            // MOS_PRINTF("This is a Sleep Device HeartBeat Packet Coming !!! \r\n");
        }
        #endif
        return sizeof(ST_OGCT_PROTOCAL_HEAD);
    }
    
    Http_DecMsgBody(stOgctHead.ucEncFlag,pucMsgBuff,stOgctHead.usBodyLen,pstEncrypInf);

    if (MOS_STRNCMP(pucMethod, (_UC *)"3245", 4) != 0) // 3245为登录信息回复，关闭打印
    {
        MOS_PRINTF_DEBUG("pucInOutBody: %s\r\n", pucMsgBuff);
    }

    hRoot = Adpt_Json_Parse(pucMsgBuff);
    do
    {
        if(hRoot == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "parse net msg body err");
            break;
        }
        MOS_SPRINTF(aucMethod, "%02X%02X",stOgctHead.ucMsgType, stOgctHead.ucMsgId);
        // 解析 方法METHOD 字段
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"), &pucMethod);

        if (MOS_STRNCMP(pucMethod, (_UC *)"3331", 4) != 0) // 3331为上报升级状态的回复，避免升级刷屏
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR, "RECV MSG METHOD %s !!!!!!!!!!!!", pucMethod);
        }

        if(MOS_STRCMP(aucMethod, pucMethod) != 0)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "msg check method err(%s) real(%s)", pucMethod, aucMethod);
            break;
        }

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"), &iSeqID);
        
        // 处理信令服务器下发的信令
        MsgMng_DispatchMsg(MSGMNG_CMD_SERVER_ID,stOgctHead.ucMsgType, stOgctHead.ucMsgId,hRoot);
        
    }while(0);

    Adpt_Json_Delete(hRoot);    
    return stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD);
}

// 处理接收到的信令data数据
_INT MsgMng_DecodeCmdServerData(ST_MSGMNG_CMDSERVER* pstCmdServer,_UC *pucMsgBuff,_INT iMsgBuffLen)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);
    MOS_PARAM_NULL_RETERR(pucMsgBuff);

    _INT iRet      = 0;
    _INT iParseLen = 0;

    do
    {
        // 处理接收到的信令data数据
        iRet = MsgMng_ProcCmdServerMsg(pstCmdServer,pucMsgBuff,iMsgBuffLen - iParseLen); 
        if(iRet <= 0)
        {
            break;
        }
        iParseLen   += iRet;
        pucMsgBuff  += iRet;
    }while(iParseLen < iMsgBuffLen);

    if(iRet < 0)
    {
        while(iMsgBuffLen - iParseLen > 0)
        {
            if(pucMsgBuff[0] == '#' && pucMsgBuff[1] == '$')
            {
                break;
            }
            iParseLen++;
            pucMsgBuff++;
        }
    }
    return iParseLen;
}

// 处理信令服务器下发的信令 
_INT MsgMng_ParseCmdServerData(ST_MSGMNG_CMDSERVER* pstCmdServer)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    _INT iRetLen   = 0;

    if(MOS_BLEN(pstCmdServer->pstRecvB) < sizeof(ST_OGCT_PROTOCAL_HEAD))
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Cmd Server recv data len err");
        return MOS_OK;
    }

    // 处理信令服务器下发的信令
    iRetLen = MsgMng_DecodeCmdServerData(pstCmdServer,MOS_BPTR(pstCmdServer->pstRecvB), MOS_BLEN(pstCmdServer->pstRecvB));
    if(iRetLen > 0){
        MOS_BOFF(pstCmdServer->pstRecvB) += iRetLen;
        MOS_BLEN(pstCmdServer->pstRecvB) -= iRetLen;
    }
    if(MOS_BLEN(pstCmdServer->pstRecvB) > 0){
        MOS_MEMMOVE(pstCmdServer->pstRecvB->aucPayload, MOS_BPTR(pstCmdServer->pstRecvB), MOS_BLEN(pstCmdServer->pstRecvB));
        MOS_BOFF(pstCmdServer->pstRecvB) = 0;
    }else{
        Mos_InitSockBuf(pstCmdServer->pstRecvB);
    }
    return MOS_OK;
}

_INT MsgMng_SetCmdLinkEncrypInf(_INT iEncType,_UC *paucEncKey, _UC *paucEncLv)
{ 
    MOS_PARAM_NULL_RETERR(paucEncKey);
    MOS_PARAM_NULL_RETERR(paucEncLv);

    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    
    if(pstCmdServer->stEncrypInf.hCryptoCtx)
    {
        Adpt_DeleteCrypto(pstCmdServer->stEncrypInf.hCryptoCtx);
        pstCmdServer->stEncrypInf.hCryptoCtx = MOS_NULL;
    }
    if(iEncType == EN_OGCT_ENCRYPT_LEVEL_LOW)
    {
        pstCmdServer->stEncrypInf.hCryptoCtx = Adpt_CreateCrypto(paucEncKey,MOS_STRLEN(paucEncKey),EN_CRYPTO_BLOWFISH_TYPE);;
    }
    pstCmdServer->stEncrypInf.iEncType = iEncType;
    MOS_STRNCPY(pstCmdServer->stEncrypInf.aucEncKey, paucEncKey, sizeof(pstCmdServer->stEncrypInf.aucEncKey));
    MOS_STRNCPY(pstCmdServer->stEncrypInf.aucEncLv, paucEncLv, sizeof(pstCmdServer->stEncrypInf.aucEncLv));
    return MOS_OK;
}

_INT MsgMng_SetCmdPlatEncryInf(ST_MSGMNG_CMDSERVER* pstCmdServer,_INT iEncType,_UC *paucEncKey, _UC *paucEncLv)
{
    MOS_PARAM_NULL_RETERR(pstCmdServer);
    MOS_PARAM_NULL_RETERR(paucEncKey);
    MOS_PARAM_NULL_RETERR(paucEncLv);


    if(pstCmdServer->stPlatEncryInf.hCryptoCtx)
    {
        Adpt_DeleteCrypto(pstCmdServer->stPlatEncryInf.hCryptoCtx);
        pstCmdServer->stPlatEncryInf.hCryptoCtx = MOS_NULL;
    }
    if(iEncType == EN_OGCT_ENCRYPT_LEVEL_LOW)
    {
        pstCmdServer->stPlatEncryInf.hCryptoCtx = Adpt_CreateCrypto(paucEncKey,MOS_STRLEN(paucEncKey),EN_CRYPTO_BLOWFISH_TYPE);;
    }
    pstCmdServer->stPlatEncryInf.iEncType = iEncType;
    MOS_STRNCPY(pstCmdServer->stPlatEncryInf.aucEncKey, paucEncKey, sizeof(pstCmdServer->stPlatEncryInf.aucEncKey));
    MOS_STRNCPY(pstCmdServer->stPlatEncryInf.aucEncLv, paucEncLv, sizeof(pstCmdServer->stEncrypInf.aucEncLv));
    return MOS_OK;
}

// 发送数据到信令服务器
_INT MsgMng_SendDataToCmdServer(_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen)
{
    _UI uiBuffLen    = 0;
    _UI uiHeadlen    =  sizeof(ST_OGCT_PROTOCAL_HEAD);
    _UI uiDataLenEx  =  MOS_HEX_NUM(uiDatalen);
    ST_OGCT_PROTOCAL_HEAD *pstOgctHead  = MOS_NULL;
    ST_MSGMNG_CMDSERVER    *pstCmdServer = MsgMng_GetCmdServer();

    // 设备回复的数据 包头加加密后的接送数据
    _INT iPacketBufLen = 0;
    _UC  *ucStrPacketBuf = MOS_NULL;

    // Methon 0x3244 login
    if(ucMsgType == EN_OGCT_METHOD_DEVPLAT && ucMsgId == EN_OGCT_DEVPLAT_ZJCMD_LOGIN)
    {
        return MsgMng_SendNotAuthToCmdServer(pstCmdServer,ucMsgType,ucMsgId,pucData,uiDatalen);
    }

    if(pstCmdServer->ucLoginFlag != EN_MSGMNG_CMDSERVER_FLAG_FINSH)
    {
        return MOS_ERR;
    }

    // 信令body长度最大为0xFFFF
    if (uiDataLenEx > 0xFFFF)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "Message body too long %u", uiDataLenEx);
        return MOS_ERR;
    }

    ucStrPacketBuf = (_UC *)MOS_MALLOC(uiDataLenEx + 1);
    if (MOS_NULL == ucStrPacketBuf)
    {
        return MOS_ERR;
    }

    // 登录成功，非登录的信令处理
    Mos_MutexLock(&pstCmdServer->hMutexSendB);
    uiBuffLen = pstCmdServer->uiPayloadLen - MOS_BOFF(pstCmdServer->pstSendB) - MOS_BLEN(pstCmdServer->pstSendB);
    
    if (uiDataLenEx + uiHeadlen <= uiBuffLen)
    {

        pstOgctHead = (ST_OGCT_PROTOCAL_HEAD*)MOS_BEND(pstCmdServer->pstSendB);
        Http_EncMsgHead(pstOgctHead, ucMsgType, ucMsgId, uiDataLenEx, pstCmdServer->stPlatEncryInf.iEncType);
        MOS_BLEN(pstCmdServer->pstSendB) += sizeof(ST_OGCT_PROTOCAL_HEAD);
        if (uiDataLenEx > 0)
        {
            if (ucMsgType == 0x11 && ucMsgId == 0x11)
            {
                MOS_PRINTF("............1.4 ucMsgType:%d  ucMsgId:%d \r\n", ucMsgType, ucMsgId);
            }

            MOS_MEMCPY(MOS_BEND(pstCmdServer->pstSendB), pucData, uiDatalen);
            MOS_PRINTF_DEBUG("pucData: %s len:%d\n", pucData, uiDatalen);
            // if(uiDataLenEx - uiDatalen >  0){
            //     MOS_MEMSET(MOS_BEND(pstCmdServer->pstSendB) + uiDatalen,0, uiDataLenEx - uiDatalen);
            // }

            // BUF_PRINTF_EX("1.3", MOS_BEND(pstCmdServer->pstSendB), uiDatalen);
            Http_EncMsgBody(pstOgctHead, MOS_BEND(pstCmdServer->pstSendB), uiDatalen, &(pstCmdServer->stEncrypInf), ucStrPacketBuf, &iPacketBufLen);
            MOS_MEMCPY(MOS_BEND(pstCmdServer->pstSendB), ucStrPacketBuf, iPacketBufLen);
            MOS_BLEN(pstCmdServer->pstSendB) += iPacketBufLen;
            // BUF_PRINTF_EX("1.4", ucStrPacketBuf, iPacketBufLen);
            // MOS_PRINTF("MOS_BLEN(pstCmdServer->pstSendB): %d  iPacketBufLen:%d \r\n", MOS_BLEN(pstCmdServer->pstSendB), iPacketBufLen);
        }
    }
    else
    {
        // MOS_PRINTF("............1.5\r\n");
        _UI uiWriteLen = 0;
        ST_MOS_SOCKBUF* pstTmp1 = MOS_NULL;
        ST_MOS_SOCKBUF* pstTmp2 = MOS_NULL;
        _UC* pucBuff = (_UC*)MOS_MALLOCCLR(uiDataLenEx + uiHeadlen);
        
        pstOgctHead = (ST_OGCT_PROTOCAL_HEAD*)pucBuff;
        Http_EncMsgHead(pstOgctHead, ucMsgType, ucMsgId, uiDataLenEx, pstCmdServer->stPlatEncryInf.iEncType);
        
        // 有body才能调用Http_EncMsgBody，不然iPacketBufLen等于16 造成内存越界
        if (uiDataLenEx > 0)
        {
            MOS_MEMCPY(pucBuff + uiHeadlen, pucData, uiDatalen);
            Http_EncMsgBody(pstOgctHead, pucBuff + uiHeadlen, uiDatalen, &(pstCmdServer->stEncrypInf), ucStrPacketBuf, &iPacketBufLen);

            MOS_MEMCPY(pucBuff + uiHeadlen, ucStrPacketBuf, iPacketBufLen);
        }

        pstTmp1 = pstCmdServer->pstSendB;
        // 查找链表最后一个buf
        while (pstTmp1->pstNext)
        {
            pstTmp1 = pstTmp1->pstNext;
        }
        uiBuffLen = pstCmdServer->uiPayloadLen - MOS_BOFF(pstTmp1) - MOS_BLEN(pstTmp1);

        // buf剩余长度为0
        if (uiBuffLen == 0)
        {
            pstTmp2 = Mos_PopSockBuf(pstCmdServer->hSockBuffPool);
            pstTmp1->pstNext = pstTmp2;
            pstTmp1 = pstTmp2;
            uiBuffLen = pstCmdServer->uiPayloadLen;
        }
        while (uiDataLenEx + uiHeadlen - uiWriteLen > uiBuffLen)
        {
            MOS_MEMCPY(MOS_BEND(pstTmp1), pucBuff + uiWriteLen, uiBuffLen);
            MOS_BLEN(pstTmp1) += uiBuffLen;
            uiWriteLen += uiBuffLen;
            pstTmp2 = Mos_PopSockBuf(pstCmdServer->hSockBuffPool);
            pstTmp1->pstNext = pstTmp2;
            pstTmp1 = pstTmp2;
            uiBuffLen = pstCmdServer->uiPayloadLen;
        }
        MOS_MEMCPY(MOS_BEND(pstTmp1), pucBuff + uiWriteLen, uiDataLenEx + uiHeadlen - uiWriteLen);
        MOS_BLEN(pstTmp1) +=  (uiDataLenEx + uiHeadlen - uiWriteLen);
        MOS_FREE(pucBuff);
    }
    Mos_MutexUnLock(&pstCmdServer->hMutexSendB);

    // sleep(1);
    MOS_FREE(ucStrPacketBuf);
    return uiDataLenEx + sizeof(ST_OGCT_PROTOCAL_HEAD);
}

// 发送未验证数据到信令服务器
_INT MsgMng_SendNotAuthToCmdServer(ST_MSGMNG_CMDSERVER* pstCmdServer,_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen)
{
    _UI uiBuffLen = 0;
    _UI uiMsgLen  =  MOS_HEX_NUM(uiDatalen);
    ST_OGCT_PROTOCAL_HEAD *pstOgctHead;

    // 设备回复的数据 包头加加密后的接送数据
    _INT iPacketBufLen = 0;
    _UC  *ucStrPacketBuf = (_UC *)MOS_MALLOCCLR(uiMsgLen + sizeof(ST_OGCT_PROTOCAL_HEAD) + 1);
    //iEncType为0时，执行Http_EncMsgBody后ucStrPacketBuf会包含pucData+ST_OGCT_PROTOCAL_HEAD

    if(pstCmdServer->ucConnectFlag != EN_MSGMNG_CMDSERVER_FLAG_FINSH)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstCmdServer->ucConnectFlag != 2");
        MOS_FREE(ucStrPacketBuf);
        return MOS_ERR;
    }
    
    Mos_MutexLock(&pstCmdServer->hMutexSendB);
    uiBuffLen = pstCmdServer->uiPayloadLen - MOS_BOFF(pstCmdServer->pstSendB) - MOS_BLEN(pstCmdServer->pstSendB);

    if(uiMsgLen + sizeof(ST_OGCT_PROTOCAL_HEAD) <= uiBuffLen)
    {
        pstOgctHead = (ST_OGCT_PROTOCAL_HEAD*)MOS_BEND(pstCmdServer->pstSendB);
        // 加密报文头
        Http_EncMsgHead(pstOgctHead, ucMsgType, ucMsgId, uiMsgLen, pstCmdServer->stPlatEncryInf.iEncType);
        MOS_BLEN(pstCmdServer->pstSendB) += sizeof(ST_OGCT_PROTOCAL_HEAD);
        MOS_MEMCPY(MOS_BEND(pstCmdServer->pstSendB), pucData, uiDatalen);
        if(uiMsgLen - uiDatalen > 0)
        {
            MOS_MEMSET(MOS_BEND(pstCmdServer->pstSendB) + uiDatalen, 0, uiMsgLen - uiDatalen);
        }

        // 加密json数据
        Http_EncMsgBody(pstOgctHead,MOS_BEND(pstCmdServer->pstSendB),uiDatalen,&pstCmdServer->stPlatEncryInf, ucStrPacketBuf, &iPacketBufLen);
        // // 如果iEncType为0，则ucStrPacketBuf包含head，因此除去pstSendB的head
        if (pstCmdServer->stPlatEncryInf.iEncType == 0)
        {
            MOS_BLEN(pstCmdServer->pstSendB) -= sizeof(ST_OGCT_PROTOCAL_HEAD);
        }
        
        MOS_MEMCPY(MOS_BEND(pstCmdServer->pstSendB), ucStrPacketBuf, iPacketBufLen);

        MOS_BLEN(pstCmdServer->pstSendB) += iPacketBufLen;

        // BUF_PRINTF_EX("out: ", MOS_BPTR(pstCmdServer->pstSendB), MOS_BLEN(pstCmdServer->pstSendB));
    }
    Mos_MutexUnLock(&pstCmdServer->hMutexSendB);
    MOS_FREE(ucStrPacketBuf);
    return uiMsgLen + sizeof(ST_OGCT_PROTOCAL_HEAD);
}

/********************************************************************************
平台注册接口 接收能力平台的post回复
*********************************************************************************/
_VOID MsgMng_RecvAblityPlatRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    // BUF_PRINTF_EX("MsgMng_RecvAblityPlatRsp", pucData, uiLen);

    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    
    if(pstCmdServer->usBuffLen == 0)
    {
        pstCmdServer->usBuffLen   = 1024;
        pstCmdServer->pucHttpBuff = (_UC*)MOS_MALLOCCLR(pstCmdServer->usBuffLen);
    }
    if(pstCmdServer->usRecvLen + uiLen < pstCmdServer->usBuffLen)
    {
        MOS_MEMCPY(pstCmdServer->pucHttpBuff + pstCmdServer->usRecvLen, pucData, uiLen);
        pstCmdServer->usRecvLen += uiLen;
    }
    return;
}

_INT MsgMng_ParseAblityPlatRegistRsp(ST_MSGMNG_CMDSERVER* pstCmdServer,_UC *pucJson)
{
    _LLID illSecond   = 0;
    _INT iValue       = 0;
    _INT iStatus      = 0;
    _UC *pStrTime     = MOS_NULL;
    _UC *pStrTmp      = MOS_NULL;
    _UC *pucNatIp     = MOS_NULL;   // 信令服务IP地址
    _UC *pucNatIPv6   = MOS_NULL;   // 信令服务IPv6地址
    _INT iNatPort     = 0;          // 信令服务端口
    _UC aucMethod[8]  = {0};        // 类型字方法字
    _INT iEncType     = 0;          // 信令加密类型
    _UC  *pucEncKey   = MOS_NULL;   // 信令加密密钥
    _UC  *pucEncLoad  = MOS_NULL;   // 信令加密向量

    _UC  *pucSturnUrl           = MOS_NULL;     // stun服务地址
    _UC  *pucSturnCredential    = MOS_NULL;     // stun服务请求凭证
    _UC  *pucTurnUrl            = MOS_NULL;     // Turn服务地址
    _UC  *pucTurnUsername       = MOS_NULL;     // Turn服务登录帐号
    _UC  *pucTurnCredential     = MOS_NULL;     // Turn服务登录凭证


    JSON_HANDLE hBody = MOS_NULL;
    _UC *pucTempBuf   = MOS_NULL;

    MOS_PARAM_NULL_RETERR(pucJson);
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    // 截取JSON字符串
    pucTempBuf = MOS_STRSTR(pucJson, "{");
#if PLATRSPTEST_FLAG
    _UC pucJsonTset[4096] = {0};
    if (Mos_FileIsExist(CMDLATRSPTEST_FILE) == MOS_TRUE)
    {
        _HFILE *hFile = MOS_NULL;
        hFile = Mos_FileOpen(CMDLATRSPTEST_FILE, MOS_FILE_O_RDONLY | MOS_FILE_O_BIN);
        if (hFile != MOS_NULL)
        {
            _INT iRet = Mos_FileRead(hFile,pucJsonTset,4096);
            if (iRet > 0)
            {
                pucTempBuf = MOS_STRSTR(pucJsonTset, "{");
            }
            Mos_FileClose(hFile);
        }
    }
#endif
    JSON_HANDLE hRoot = Adpt_Json_Parse(pucTempBuf);
    if(MOS_NULL == hRoot)
    {
        pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_ERROR;
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hRoot == MOS_NULL");

        _UC aucMsgString[128] = {0};
        MOS_SPRINTF(aucMsgString, "%s Check AblityPlat Rsp Josn Failed",MSGMNG_REGIST_INFO_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 0, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_JOSN_FAIL, aucMsgString, 1);
        return MOS_ERR;
    }
    do
    {
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pStrTmp);
        MOS_VSNPRINTF(aucMethod, 8,(_UC*)"%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJABILITY_REGIST_RSP);
        if(MOS_STRCMP(aucMethod, pStrTmp) != 0)
        {
            pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_ERROR;           
            _UC aucMsgString[128] = {0};
            MOS_SPRINTF(aucMsgString, "%s Check AblityPlat Rsp Param(aucMethod : %s %s) Failed",MSGMNG_REGIST_INFO_STR,aucMethod,pStrTmp);
            CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 0, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_PARAM_FAIL, aucMsgString, 1);       
            break;
        }
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
        if(iValue != 0)
        {
            _UC aucMsgString[128] = {0};
            MOS_SPRINTF(aucMsgString, "%s Check AblityPlat Rsp Param(Code : %d) Failed",MSGMNG_REGIST_INFO_STR,iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 0, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_PARAM_FAIL, aucMsgString, 1);
            pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_ERROR;

            if (iValue == 999)//错误码999:信令平台返回告知设备重新获取调度地址
            {
                pstCmdServer->ucRouteReGetFlag  = EN_MSGMNG_ROUTE_REGET_LATER;
                pstCmdServer->timeRouteReq      = Mos_Time();
                pstCmdServer->uiRouteReGetSec   = 30;//30秒后重调度
            }
            break;
        }
        hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
        if(hBody == MOS_NULL)
        {
            pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_ERROR;             
            _UC aucMsgString[128] = {0};
            MOS_SPRINTF(aucMsgString, "%s Check AblityPlat Rsp Param(Body is Null) Failed",MSGMNG_REGIST_INFO_STR);
            CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 0, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_PARAM_FAIL, aucMsgString, 1);
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,pucJson);
            break;
        }
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Time"),&pStrTime);
        illSecond = MOS_ATOLL(pStrTime);

        // 有pfunSetUtcTime回调，就回调pfunSetUtcTime；如果没有pfunSetUtcTime回调，就回调pFunSetDefaultZoneAndTime
        if (ZJ_GetFuncTable()->pfunSetUtcTime)
        {
            if (illSecond > 0)
            {
                iStatus = ZJ_GetFuncTable()->pfunSetUtcTime(illSecond);
                if (MOS_OK != iStatus)
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "SetUtcTime(aucTimeStr:%s) err", pStrTime);
                }
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "Time is illegal! pStrTime = %s", pStrTime);
            }
        }
        else if (ZJ_GetFuncTable()->pFunSetDefaultZoneAndTime)
        {
            iStatus = ZJ_GetFuncTable()->pFunSetDefaultZoneAndTime(0, 0, illSecond);// 不同步时区, 与厂家沟通iSetZoneFlag为0时应该默认为东8区/北京时间
            if (MOS_OK != iStatus)
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "SetDefaultTimeZone(aucTimeStr:%s) err", pStrTime);                
            }
        }
#if 0
        _UL ulTime = MOS_STRTOUL(pStrTmp, 10);
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"ulTime is %u    iTimeZone:%d!", ulTime, Config_GetSystemMng()->iTimeZone);
        ST_MOS_SYS_TIME stTmTime        = {0};
        if(Mos_TimetoSysTime((time_t *)&ulTime, &stTmTime) == MOS_ERR)
        {
            return ;
        }
        MOS_VSNPRINTF(pStrTmp,32, "%04u-%02u-%02u %02u:%02u:%02u",stTmTime.usYear,stTmTime.usMonth,stTmTime.usDay,stTmTime.usHour,stTmTime.usMinute,stTmTime.usSecond);
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"strTime is %s!", pStrTmp);

        if(ZJ_GetFuncTable()->pfunSetTimeZone)
        {
            iStatus = ZJ_GetFuncTable()->pfunSetTimeZone(0, 28800, pStrTmp ,Config_GetDeviceMng()->aucDst);
            if (MOS_OK != iStatus)
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "Device pfunSetTimeZone(aucTimeStr:%s) err", pStrTmp);
            }
            else
            {
                Config_SetLocalTimeZone((_INT)28800);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunSetTimeZone is NULL!");
        }
#endif
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"DevToken"),&pStrTmp);
        Config_SetAblPlatDevToken(pStrTmp);
        
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"NatIP"),&pucNatIp);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SignalingIpv6Addr"),&pucNatIPv6);
        if (pucNatIPv6 == MOS_NULL)
        {
            MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"SignalingIpv6Addr is NULL");
        }
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"NatPort"),&iNatPort);
        Config_SetHxLinkAddr(pucNatIp,iNatPort);
        Config_SetHxLinkIPv6Addr(pucNatIPv6,iNatPort);

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncType"),&iEncType);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncKey"),&pucEncKey);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncLoad"),&pucEncLoad);

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"StunUrl"),&pucSturnUrl);
        if (0)//pucSturnUrl) //abandon 21-10-08
        {
           MOS_LOG_INF(MSGMNG_ID_LOG_STR,"DeviceRegister StunUrl: %s", pucSturnUrl);
           Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SturnCredential"),&pucSturnCredential);
           if (pucSturnCredential)
           {
               MOS_LOG_INF(MSGMNG_ID_LOG_STR,"DeviceRegister SturnCredential: %s", pucSturnCredential);
           }
           Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"TurnUrl"),&pucTurnUrl);
           if (pucTurnUrl)
           {
               MOS_LOG_INF(MSGMNG_ID_LOG_STR,"DeviceRegister TurnUrl: %s", pucTurnUrl);
           }
           Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"TurnUsername"),&pucTurnUsername);//user
           if (pucTurnUsername)
           {
               MOS_LOG_INF(MSGMNG_ID_LOG_STR,"DeviceRegister TurnUsername: %s", pucTurnUsername); //pass
           }
           Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"TurnCredential"),&pucTurnCredential);
           if (pucTurnCredential)
           {
               MOS_LOG_INF(MSGMNG_ID_LOG_STR,"DeviceRegister TurnCredential: %s", pucTurnCredential);
           }

           if (pucSturnUrl && pucTurnUrl && pucTurnUsername)
           {
               P2p_Config_Addr(pucSturnUrl, pucTurnUrl, pucTurnUsername, pucTurnCredential);
           }
        }
        Config_SetCmdPlatEncrypInf(iEncType,pucEncKey,pucEncLoad);
        MsgMng_SetCmdPlatEncryInf(pstCmdServer,iEncType,pucEncKey,pucEncLoad);
        pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_FINSH;
    }while(0);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_VOID MsgMng_RecvAblityPlatRegistFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    EN_COUNT_VALUE CountLess2Value = Mos_Time() - pstCmdServer->timeReq >= 2 ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_SUCCESS,CountLess2Value);
    
    if(pstCmdServer->pucHttpBuff)
    {
        pstCmdServer->pucHttpBuff[pstCmdServer->usRecvLen] = 0;
    }
    MsgMng_ParseAblityPlatRegistRsp(pstCmdServer,pstCmdServer->pucHttpBuff);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Get Cmd Server Rsp Len %d", pstCmdServer->usRecvLen);
    MOS_FREE(pstCmdServer->pucHttpBuff);
    pstCmdServer->pucHttpBuff = MOS_NULL;
    pstCmdServer->usBuffLen   = 0;
    pstCmdServer->usRecvLen   = 0;
    pstCmdServer->uiHttpHandle= 0;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_ABLITY_PLAT_REGIST, uiUseTime);

    // FIXME: Use for debuging cloud upload log
    // CloudStg_UploadLocalLog(Mos_GetSessionId(),"/mnt/sdcard/log/hm_run_0.log",MOS_NULL);
    // CloudStg_UploadLog(Mos_GetSessionId(), "123456", 0, "123", "geturl request fail", 1);
    // CloudStg_UploadLog(Mos_GetSessionId(), "1", 0, "123", "geturl request fail.........1", 1);
    // CloudStg_UploadLog(Mos_GetSessionId(), "2", 0, "123", "geturl request fail.........2", 1);
    // CloudStg_UploadLog(Mos_GetSessionId(), "3", 0, "123", "geturl request fail.........3", 1);
    // CloudStg_UploadLog(Mos_GetSessionId(), "4", 0, "123", "geturl request fail.........4", 1);
    // CloudStg_UploadLog(Mos_GetSessionId(), "5", 0, "123", "geturl request fail.........5", 1);

    return ;
}

_VOID MsgMng_RecvAblityPlatFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC aucUrl[128]        = {0};
    _UC aucMsgString[128]  = {0};
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();

    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);   
    MOS_SPRINTF(aucUrl,"%s%s", Config_GetSystemMng()->aucPuAddr, MSGMNG_ABLPLATREGIST_URL);
    MOS_SPRINTF(aucMsgString, "%s Recv AblityPlat Rsp Failed",MSGMNG_REGIST_INFO_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, uiErrCode, EN_REGISTINFO_RT_RECV_ABLITYPLAT_RSP_FAIL, aucMsgString, 1);
    
    if(pstCmdServer->pucHttpBuff)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Get Cmd Server Fail rsp %s",pstCmdServer->pucHttpBuff);
    }
    MOS_FREE(pstCmdServer->pucHttpBuff);
    pstCmdServer->pucHttpBuff   = MOS_NULL;
    pstCmdServer->usBuffLen     = 0;
    pstCmdServer->usRecvLen     = 0;
    pstCmdServer->uiHttpHandle  = 0;
    pstCmdServer->ucRegistFlag  = EN_MSGMNG_CMDSERVER_FLAG_ERROR;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_ABLITY_PLAT_REGIST, uiUseTime);

    return;
}
_VOID MsgMng_RecvReGetCmdAddrFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC aucUrl[128] = {0};
    _UC aucMsgString[128] = {0};
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();

    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);   
    MOS_SPRINTF(aucUrl,"%s%s", Config_GetSystemMng()->aucPuAddr, MSGMNG_REGETABLADDR_URL);
    MOS_SPRINTF(aucMsgString, "%s Recv AblityPlat Rsp Failed",MSGMNG_REGIST_INFO_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, uiErrCode, EN_REGISTINFO_RT_RECV_ABLITYPLAT_RSP_FAIL, aucMsgString, 1);
    
    if(pstCmdServer->pucHttpBuff)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Get Cmd Server Fail rsp %s",pstCmdServer->pucHttpBuff);
    }
    MOS_FREE(pstCmdServer->pucHttpBuff);
    pstCmdServer->pucHttpBuff   = MOS_NULL;
    pstCmdServer->usBuffLen     = 0;
    pstCmdServer->usRecvLen     = 0;
    pstCmdServer->uiHttpHandle  = 0;
    return;
}


/********************************************************************************
平台注册接口 接收能力平台的post回复
*********************************************************************************/
_VOID MsgMng_RecvRoutePlatRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    // BUF_PRINTF_EX("MsgMng_RecvRoutePlatRsp", pucData, uiLen);

    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    
    if(pstCmdServer->usBuffLen == 0)
    {
        pstCmdServer->usBuffLen   = 1024;
        pstCmdServer->pucHttpBuff = (_UC*)MOS_MALLOCCLR(pstCmdServer->usBuffLen);
    }
    if(pstCmdServer->usRecvLen + uiLen < pstCmdServer->usBuffLen)
    {
        MOS_MEMCPY(pstCmdServer->pucHttpBuff + pstCmdServer->usRecvLen, pucData, uiLen);
        pstCmdServer->usRecvLen += uiLen;
    }
    return;
}

_INT MsgMng_ParseRoutePlatRegistRsp(ST_MSGMNG_CMDSERVER* pstCmdServer,_UC *pucJson)
{
    _INT iValue       = 0;
    _INT iRet         = MOS_ERR;
    _UC *pStrTime     = MOS_NULL;
    _UC *pStrTmp      = MOS_NULL;
    _UC aucMethod[8]  = {0};        // 类型字方法字

    JSON_HANDLE hBody = MOS_NULL;
    _UC *pucTempBuf     = MOS_NULL;

    MOS_PARAM_NULL_RETERR(pucJson);
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    // 截取JSON字符串
    pucTempBuf = MOS_STRSTR(pucJson, "{");
#if PLATRSPTEST_FLAG
    _UC pucJsonTset[4096] = {0};
    if (Mos_FileIsExist(ROUTEPLATRSPTEST_FILE) == MOS_TRUE)
    {
        _HFILE *hFile = MOS_NULL;
        hFile = Mos_FileOpen(ROUTEPLATRSPTEST_FILE, MOS_FILE_O_RDONLY | MOS_FILE_O_BIN);
        if (hFile != MOS_NULL)
        {
            _INT iRet = Mos_FileRead(hFile,pucJsonTset,4096);
            if (iRet > 0)
            {
                pucTempBuf = MOS_STRSTR(pucJsonTset, "{");
            }
            Mos_FileClose(hFile);
        }
    }
#endif    
    JSON_HANDLE hRoot = Adpt_Json_Parse(pucTempBuf);
    if(MOS_NULL == hRoot)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hRoot == MOS_NULL");
        pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
        return MOS_ERR;
    }
    do
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"DeviceRegister pucJson : %s", pucTempBuf);
        
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pStrTmp);
        MOS_VSNPRINTF(aucMethod, 8,(_UC*)"%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJMNG_REGIST_RSP);
        if(pStrTmp && MOS_STRCMP(aucMethod, pStrTmp) != 0)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Method Is Error");
            pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;
        }
  
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
        if(iValue != 0)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Code Is Error");
            pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;
        }
        hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
        if(hBody == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Body Is Error");
            pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;
        }

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SigtranDomain"),&pStrTmp);
        if (pStrTmp &&  MOS_STRLEN(pStrTmp) > 1)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"SigtranDomain strtmp Is %s",pStrTmp);  
            _UC pucDomainAddr[CFG_STRING_MAXLEN + 4] = {0};
            iRet = MsgMng_GetDomainAddr(pStrTmp, pucDomainAddr);
            if (iRet == MOS_OK)
            {
                Config_SetAblPlatAddr(0, (_UC *)pucDomainAddr);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"SigtranDomain Is Error");
            pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;
        }

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"CloudDomain"),&pStrTmp);
        if (pStrTmp &&  MOS_STRLEN(pStrTmp) > 1)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"CloudDomain strtmp Is %s",pStrTmp);
            _UC pucDomainAddr[CFG_STRING_MAXLEN + 4] = {0};
            iRet = MsgMng_GetDomainAddr(pStrTmp, pucDomainAddr);
            if (iRet == MOS_OK)
            {
                Config_SetCloudPlatAddr((_UC *)pucDomainAddr);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"CloudDomain Is Error");
            pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;
        }

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AlarmDomain"),&pStrTmp);
        if (pStrTmp &&  MOS_STRLEN(pStrTmp) > 1)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"AlarmDomain strtmp Is %s",pStrTmp);
            _UC pucDomainAddr[CFG_STRING_MAXLEN + 4] = {0};
            iRet = MsgMng_GetDomainAddr(pStrTmp, pucDomainAddr);
            if (iRet == MOS_OK)
            {
                Config_SetAlarmPlatAddr((_UC *)pucDomainAddr);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"AlarmDomain Is Error");
            pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
            Adpt_Json_Delete(hRoot);
            return MOS_ERR; 
        }

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"ReportDomain"),&pStrTmp);
        if (pStrTmp &&  MOS_STRLEN(pStrTmp) > 1)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ReportDomain strtmp Is %s",pStrTmp);
            _UC pucDomainAddr[CFG_STRING_MAXLEN + 4] = {0};
            iRet = MsgMng_GetDomainAddr(pStrTmp, pucDomainAddr);
            if (iRet == MOS_OK)
            {
                Config_SetReportPlatAddr((_UC *)pucDomainAddr);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"ReportDomain Is Error");
            pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;             
        }

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"OtherDomain"),&pStrTmp);
        if (pStrTmp &&  MOS_STRLEN(pStrTmp) > 1)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"OtherDomain strtmp Is %s",pStrTmp);
            _UC pucDomainAddr[CFG_STRING_MAXLEN + 4] = {0};
            iRet = MsgMng_GetDomainAddr(pStrTmp, pucDomainAddr);
            if (iRet == MOS_OK)
            {
                Config_SetOtherPlatAddr((_UC *)pucDomainAddr);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"OtherDomain Is Error");
            pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;
        }

        //扩展域名，当无下发时，用https://vcp.21cn.com
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Ga1400Domain"),&pStrTmp);
        if (pStrTmp &&  MOS_STRLEN(pStrTmp) > 1)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Ga1400Domain strtmp Is %s",pStrTmp);
            _UC pucDomainAddr[CFG_STRING_MAXLEN + 4] = {0};
            iRet = MsgMng_GetDomainAddr(pStrTmp, pucDomainAddr);
            if (iRet == MOS_OK)
            {
                Config_SetGa1400PlatAddr((_UC *)pucDomainAddr);
            }
        }
        else
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Ga1400Domain Is NUll");;
        }

        Config_SetDomainFlag(1);
        pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_SUCCESS;
    }while(0);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_VOID MsgMng_RecvRoutePlatRegistFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    EN_COUNT_VALUE CountLess2Value = Mos_Time() - pstCmdServer->timeRouteReq >= 2 ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_SUCCESS,CountLess2Value);
    
    if(pstCmdServer->pucHttpBuff)
    {
        pstCmdServer->pucHttpBuff[pstCmdServer->usRecvLen] = 0;
    }
    MsgMng_ParseRoutePlatRegistRsp(pstCmdServer,pstCmdServer->pucHttpBuff);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"aucRouteAddr  = %s\n", Config_GetSystemMng()->aucRouteAddr);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"aucPuAddr     = %s\n", Config_GetSystemMng()->aucPuAddr);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"aucAlarmAddr  = %s\n", Config_GetSystemMng()->aucAlarmAddr);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"aucCloudAddr  = %s\n", Config_GetSystemMng()->aucCloudAddr);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"aucReportAddr = %s\n", Config_GetSystemMng()->aucReportAddr);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"aucOtherAddr  = %s\n", Config_GetSystemMng()->aucOtherAddr);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"aucGa1400Addr = %s\n", Config_GetSystemMng()->aucGa1400Addr);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Get Cmd Server Rsp Len %d", pstCmdServer->usRecvLen);
    MOS_FREE(pstCmdServer->pucHttpBuff);
    pstCmdServer->usBuffLen = 0;
    pstCmdServer->usRecvLen = 0;
    pstCmdServer->uiHttpHandle  = 0;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_GET_ROUTE, uiUseTime);

    return ;
}

_VOID MsgMng_RecvRoutePlatFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_FAIL,COUNT_VALUE_FAIL);   
    MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Send RoutePlatRegist Failed");
    
    if(pstCmdServer->pucHttpBuff)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Get Cmd Server Fail rsp %s",pstCmdServer->pucHttpBuff);
    }
    MOS_FREE(pstCmdServer->pucHttpBuff);
    pstCmdServer->ucRouteStatus = EN_MSGMNG_ROUTE_STATUS_FAIL;
    pstCmdServer->usBuffLen     = 0;
    pstCmdServer->usRecvLen     = 0;
    pstCmdServer->uiHttpHandle  = 0;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_GET_ROUTE, uiUseTime);

    return;
}

// 获取向能力平台注册的json数据
_UC *MsgMng_BuildAblityPlatRegistJson(_UI uiSeqId)
{
    _UC *pStrTmp    = MOS_NULL;
    _UC *pucOutBuff = MOS_NULL;
    _UI uiTime      = 0;
    _UC aucMethod[8];
    _UC aucInBuf[256]     = {0};
    _UC aucSdkVersion[32] = {0};
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    MOS_VSNPRINTF(aucMethod, 8,(_UC*)"%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJABILIT_REGIST);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiSeqId));
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CTEI", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Version", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    //#if SDK40_REGISTER
    Config_GetSdkVersion(aucSdkVersion);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"sdkVersion IS %s", aucSdkVersion);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"SdkVersion", Adpt_Json_CreateString(aucSdkVersion));
    //#endif

    uiTime = Mos_GetTickCount();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp", Adpt_Json_CreateStrWithNum(uiTime));// ;
    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);
    MOS_VSNPRINTF(aucInBuf, 256,"CTEI=%s&DID=%s&TimeStamp=%u&Version=%s",
        Config_GetSystemMng()->aucDevCTEI,Config_GetSystemMng()->aucDevUID,uiTime,Config_GetDeviceMng()->aucDevVerSion);

    // 对数据惊醒sha256加密
    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,128,Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature",
                             Adpt_Json_CreateString(pucOutBuff));
    pStrTmp = Adpt_Json_Print(hRoot);
    // MOS_PRINTF_DEBUG(", aucDevkey:%s aucInBuf:%s\n", Config_GetSystemMng()->aucDevkey, aucInBuf);
    // MOS_PRINTF_DEBUG("my Signature:%s\n", pucOutBuff);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d,dev Regist json %s",uiSeqId,pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}

// 获取域名调度的json数据
_UC *MsgMng_BuildRoutePlatRegistJson(_UI uiSeqId)
{
    _UC *pStrTmp    = MOS_NULL;
    _UC *pucOutBuff = MOS_NULL;
    _UI uiTime      = 0;
    _UC aucMethod[8];
    _UC aucInBuf[256]     = {0};
    _UC aucSdkVersion[32] = {0};
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    MOS_VSNPRINTF(aucMethod, 8,(_UC*)"%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJMNG_REGIST);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiSeqId));
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CTEI", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    uiTime = Mos_GetTickCount();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp", Adpt_Json_CreateStrWithNum(uiTime));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Version", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    
    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);
    MOS_VSNPRINTF(aucInBuf, 256,"CTEI=%s&DID=%s&TimeStamp=%u&Version=%s",
        Config_GetSystemMng()->aucDevCTEI,Config_GetSystemMng()->aucDevUID,uiTime,Config_GetDeviceMng()->aucDevVerSion);

    // 对数据惊醒sha256加密
    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,128,Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature",
                             Adpt_Json_CreateString(pucOutBuff));
    pStrTmp = Adpt_Json_Print(hRoot);
    // MOS_PRINTF_DEBUG(", aucDevkey:%s aucInBuf:%s\n", Config_GetSystemMng()->aucDevkey, aucInBuf);
    // MOS_PRINTF_DEBUG("my Signature:%s\n", pucOutBuff);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d,dev Regist json %s",uiSeqId,pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}

// 去能力平台注册 获取信令服务器地址和aes密钥 异步处理
_INT MsgMng_AblityPlatRegist()
{
    _US usPort           = 80;
    _UI uiHttpsFlag      = 0;
    _INT i,iRet          = 0;
    _UC *pStrTmp         = MOS_NULL;
    _UC *pStrStart       = MOS_NULL;
    _UC auAdmonAddr[128] = {0};

    // 创建关键接口质量信息节点 https://ehome.21cn.com/app2/device/DeviceRegister
    MOS_VSNPRINTF(auAdmonAddr, sizeof(auAdmonAddr), "%s%s", Config_GetSystemMng()->aucPuAddr, MSGMNG_ABLPLATREGIST_URL);
    MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_ABLITY_PLAT_REGIST, auAdmonAddr);

    MOS_MEMSET(auAdmonAddr, 0, sizeof(auAdmonAddr));

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucPuAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 

    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucPuAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucPuAddr;
    }
    else
    {
        pStrStart += 2;
    }

    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else
    {
        MOS_STRNCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"msgct begain regist server addr %s",Config_GetSystemMng()->aucPuAddr);

    _UI uiSeqId = Mos_GetSessionId();
    // 获取向能力平台注册的json数据
    pStrTmp = MsgMng_BuildAblityPlatRegistJson(uiSeqId);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = MsgMng_RecvAblityPlatRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_RecvAblityPlatRegistFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_RecvAblityPlatFail;
    stHttpInfoNode.iTimeOut        = 20;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, MSGMNG_ABLPLATREGIST_URL, EN_HTTP_METHOD_POST, uiSeqId);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC  aucMsgString[128] = {0};
        MOS_SPRINTF(aucMsgString, "%s Parse AblityPlat Addr Failed",MSGMNG_REGIST_INFO_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 502, EN_REGISTINFO_RT_PARSE_ABLITYPLAT_ADDR_FAIL, aucMsgString, 1);
    }
    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

// 去能力平台获取业务模块的域名地址
_INT MsgMng_AblityGetRouteStatus()
{
    _US usPort           = 443;
    _INT i,iRet          = 0;
    _UC *pStrTmp         = MOS_NULL;
    _UC *pStrStart       = MOS_NULL;
    _UC auAdmonAddr[128] = {0};

    // 创建关键接口质量信息节点 https://vnet-sroute.21cn.com/deviceAlloc
    MOS_VSNPRINTF(auAdmonAddr, sizeof(auAdmonAddr), "%s%s", Config_GetSystemMng()->aucRouteAddr, MSGMNG_ROUTEADDR_URL);
    MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_GET_ROUTE, auAdmonAddr);

    MOS_MEMSET(auAdmonAddr, 0, sizeof(auAdmonAddr));

    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucRouteAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucRouteAddr;
    }
    else
    {
        pStrStart += 2;
    }

    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else
    {
        MOS_STRNCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"msgct begain regist server addr %s  auAdmonAddr : %s",Config_GetSystemMng()->aucRouteAddr,auAdmonAddr);
    printf("msgct begain regist server addr %s  auAdmonAddr : %s\n",Config_GetSystemMng()->aucRouteAddr,auAdmonAddr);

    // 获取域名调度地址的json数据
    _UI uiSeqId = Mos_GetSessionId();
    pStrTmp = MsgMng_BuildRoutePlatRegistJson(uiSeqId);
    
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.pfuncRecv       = MsgMng_RecvRoutePlatRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_RecvRoutePlatRegistFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_RecvRoutePlatFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, MSGMNG_ROUTEADDR_URL, EN_HTTP_METHOD_POST, uiSeqId);

    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

/*********************************************************************************************
***********************************************************************************************/
static _INT MsgMng_ParseRegetCmdServerRsp(ST_MSGMNG_CMDSERVER* pstCmdServer,_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);
    MOS_PARAM_NULL_RETERR(pstCmdServer);

    _INT iValue       = 0;
    _UC aucMethod[8];
    _UC *pStrTmp      = MOS_NULL;
    _UC *pucNatIP     = MOS_NULL;   // 信令服务IP地址
    _UC *pucNatIPv6   = MOS_NULL;   // 信令服务IPv6地址
    _INT iNatPort     = 0;
    _INT iEncType     = 0;
    _UC  *pucEncKey   = MOS_NULL;
    _UC  *pucEncLoad  = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;

#if PLATRSPTEST_FLAG
    _UC pucJsonTset[4096] = {0};
    if (Mos_FileIsExist(CMDLATRSPTEST_FILE) == MOS_TRUE)
    {
        _HFILE *hFile = MOS_NULL;
        hFile = Mos_FileOpen(CMDLATRSPTEST_FILE, MOS_FILE_O_RDONLY | MOS_FILE_O_BIN);
        if (hFile != MOS_NULL)
        {
            _INT iRet = Mos_FileRead(hFile,pucJsonTset,4096);
            if (iRet > 0)
            {
                hRoot = Adpt_Json_Parse(pucJsonTset);
            }
            Mos_FileClose(hFile);
        }
    }
#endif  
    if (hRoot == MOS_NULL)
    {
        hRoot = Adpt_Json_Parse(pucJson);
    }

    if(hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"regetAddr Rsp is NULL!");
        _UC aucMsgString[128] = {0};
        MOS_SPRINTF(aucMsgString, "%s Check AblityPlat Rsp Josn Failed",MSGMNG_REGIST_INFO_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 0, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_JOSN_FAIL, aucMsgString, 1);
        return MOS_ERR;
    }
    do
    {
        MOS_VSNPRINTF(aucMethod, 8,(_UC*)"%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJCMDADDR_GET_RSP);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pStrTmp);
        if(MOS_STRCMP(pStrTmp,aucMethod) != 0)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"MSGID WRONG! rcv msgid %s",pStrTmp);
            _UC aucMsgString[128] = {0};
            MOS_SPRINTF(aucMsgString, "%s Check AblityPlat Rsp Param(aucMethod : %s %s) Failed",MSGMNG_REGIST_INFO_STR,aucMethod,pStrTmp);
            CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 0, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_PARAM_FAIL, aucMsgString, 1);  
            pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_ERROR;
            break;
        }
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
        if(iValue != 0)
        {
            Config_SetAblPlatDevToken((_UC*)"");
            _UC aucMsgString[128] = {0};
            MOS_SPRINTF(aucMsgString, "%s Check AblityPlat Rsp Param(Code : %d) Failed",MSGMNG_REGIST_INFO_STR,iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 0, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_PARAM_FAIL, aucMsgString, 1);
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"reget cmd server rsp code is %d,device turn to AblPlat regist",iValue);
            pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_ERROR;
            break;
        }
        hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
        if(hBody == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"reget HXLinkAddr Body is NULL!");
            _UC aucMsgString[128] = {0};
            MOS_SPRINTF(aucMsgString, "%s Check AblityPlat Rsp Param(Body is Null) Failed",MSGMNG_REGIST_INFO_STR);
            CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 0, EN_REGISTINFO_RT_CHECK_ABLITYPLAT_PARAM_FAIL, aucMsgString, 1);
            pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_ERROR;
            break;
        }
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Time"),&pStrTmp);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"DevToken"),&pStrTmp);
        Config_SetAblPlatDevToken(pStrTmp);

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"NatIP"),&pucNatIP);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SignalingIpv6Addr"),&pucNatIPv6);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"NatPort"),&iNatPort);
        Config_SetHxLinkAddr(pucNatIP,iNatPort);
        Config_SetHxLinkIPv6Addr(pucNatIPv6,iNatPort);

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncType"),&iEncType);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncKey"),&pucEncKey);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncLoad"),&pucEncLoad);

        Config_SetCmdPlatEncrypInf(iEncType,pucEncKey,pucEncLoad);
        MsgMng_SetCmdPlatEncryInf(pstCmdServer,iEncType,pucEncKey,pucEncLoad);
        
        pstCmdServer->ucRegistFlag = EN_MSGMNG_CMDSERVER_FLAG_FINSH;
    }while(0);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_VOID MsgMng_RecvReGetCmdAddrFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    EN_COUNT_VALUE CountLess2Value = Mos_Time() - pstCmdServer->timeReq >= 2 ? COUNT_VALUE_FAIL : COUNT_VALUE_SUCCESS;
    Qp_CountIF_Post(COUNT_TYPE_DEVREGISTER, COUNT_VALUE_SUCCESS,CountLess2Value);

    if(pstCmdServer->pucHttpBuff)
    {
        pstCmdServer->pucHttpBuff[pstCmdServer->usRecvLen] = 0;
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ReGet CmdServer Finished , Recv Msg %s",pstCmdServer->pucHttpBuff);
    }
    MsgMng_ParseRegetCmdServerRsp(pstCmdServer,pstCmdServer->pucHttpBuff);  
    MOS_FREE(pstCmdServer->pucHttpBuff);
    pstCmdServer->pucHttpBuff = MOS_NULL;
    pstCmdServer->usBuffLen   = 0;
    pstCmdServer->usRecvLen   = 0;
    pstCmdServer->uiHttpHandle= 0;

    return;
}

static _UC *MsgMng_BuildRegetCmdServerJson(_UI uiSeqId)
{
    _UC *pStrTmp      = MOS_NULL;
    _UC *pucOutBuff   = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    _UC aucMethod[8];
    _UC aucInBuf[256];
    _CTIME_T ctime;
    _LLID lluTime;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
     
    MOS_VSNPRINTF(aucMethod, 8,(_UC*)"%02X%02X",EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_ZJCMDADDR_GET);
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiSeqId));

    ctime = Mos_Time();
    lluTime = ctime * 1000;
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CTEI", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Version", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp", Adpt_Json_CreateStrWithNum(lluTime));

    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);
    MOS_VSNPRINTF(aucInBuf, 256,"CTEI=%s&DID=%s&TimeStamp=%llu&Version=%s",
        Config_GetSystemMng()->aucDevCTEI,Config_GetSystemMng()->aucDevUID,lluTime,Config_GetDeviceMng()->aucDevVerSion);

    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,128,Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}

_INT MsgMng_ReGetCmdServerAddr()
{
    _INT i,iRet  = 0;
    _US usPort = 80;
    _UI uiHttpsFlag = 0;
    _UC *pStrTmp  = MOS_NULL;
    _UC *pStrStart = MOS_NULL;
    _UC auAdmonAddr[MOS_INET_IPV6_STR_SIZE];

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucPuAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 
    
    MOS_MEMSET(auAdmonAddr, 0, MOS_INET_IPV6_STR_SIZE);
    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucPuAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucPuAddr;
    }
    else
    {
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRNCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }
    
    _UI uiSeqId = Mos_GetSessionId();
    pStrTmp = MsgMng_BuildRegetCmdServerJson(uiSeqId);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = MsgMng_RecvAblityPlatRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_RecvReGetCmdAddrFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_RecvReGetCmdAddrFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, MSGMNG_REGETABLADDR_URL, EN_HTTP_METHOD_POST, uiSeqId);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC  aucMsgString[128] = {0};
        MOS_SPRINTF(aucMsgString, "%s Parse AblityPlat Addr Failed",MSGMNG_REGIST_INFO_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), Config_GetSystemMng()->aucPuAddr, 502, EN_REGISTINFO_RT_PARSE_ABLITYPLAT_ADDR_FAIL, aucMsgString, 1);
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ReGet Cmd addr, hostAddr %s ret %d",Config_GetSystemMng()->aucPuAddr,iRet);
    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

_INT MsgMng_CleanCmdServerAddr()
{
    if(MsgMng_GetMng()->pstCmdServer == MOS_NULL)
    {
        return MOS_OK;
    }
    Config_SetAblPlatDevToken("");
    MsgMng_GetMng()->pstCmdServer->ucResetFlag = 1;
    MsgMng_GetMng()->pstCmdServer->ucRouteReGetFlag = EN_MSGMNG_ROUTE_REGET_NOW;
    return MOS_OK;
}

_INT MsgMng_SendCustomPubMsgByP2pServer(_UI uiReqId,_UI uiPubMsgType,_UC *pucPubInf,PFUN_MSGMNG_RSPDATACB pFunOgctMsgCb)
{
    _INT iRet = 0;
    _UC aucMethod[8];
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hParam = MOS_NULL;
    JSON_HANDLE hBody  = MOS_NULL;
    JSON_HANDLE hRoot  = Adpt_Json_CreateObject( );

    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_GROUP,EN_OGCT_GROUP_CUSTOMMSG_PUB);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiReqId));
    
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"GID", Adpt_Json_CreateString(Config_GetGroupInf()->aucGrpid));
    
    hParam = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Param",hParam);
    Adpt_Json_AddItemToObject(hParam,(_UC*)"EventType", Adpt_Json_CreateStrWithNum(uiPubMsgType));
    if(pucPubInf != MOS_NULL)
    {
        Adpt_Json_AddItemToObject(hParam,(_UC*)"EventParam", Adpt_Json_CreateString(pucPubInf));
    }

    pStrTmp = Adpt_Json_Print(hRoot);
    
    iRet = MsgMng_SendMsg(MSGMNG_P2P_SERVER_ID,uiReqId,EN_OGCT_METHOD_GROUP,EN_OGCT_GROUP_CUSTOMMSG_PUB,
        pStrTmp,MOS_STRLEN(pStrTmp),pFunOgctMsgCb);

    Adpt_Json_Delete(hRoot);   
    MOS_FREE(pStrTmp);
    return iRet;
}

_INT MsgMng_CloseCmdServer()
{
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
    pstCmdServer->ucStatus = EN_MSGMNG_CMDSERVER_STATUS_DEINIT;
    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "cmd server is closing...");
    return MOS_OK;
}
