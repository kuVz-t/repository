#ifndef MSGMNG_DEVPLAT_H
#define MSGMNG_DEVPLAT_H

#ifdef __cplusplus
extern "C" {
#endif

_INT MsgMng_RecvDevPlatLinkEncryChangeNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

#ifdef __cplusplus
}
#endif

#endif

