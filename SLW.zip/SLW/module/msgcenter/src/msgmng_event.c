#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "config_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_json_adapt.h"
#include "msgmng_multimedia.h"
#include "msgmng_devplat.h"
#include "msgmng_cfgbuss.h"
#include "msgmng_event.h"
#include "qualityprobe_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "kjiot_device_type.h"

// 创建消息告警上报列表节点
static ST_EVENTTASK_NODE *MsgMng_CreateEventNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_EVENTTASK_NODE* pstEventNode = MOS_NULL;

    Mos_MutexLock(&MsgMng_GetMng()->hEventListMutex);
    FOR_EACHDATA_INLIST(&MsgMng_GetMng()->stEventList, pstEventNode, stIterator)
    {
        if(pstEventNode->ucStatus == 0)
        {
            break;
        }
    }
    if(pstEventNode == MOS_NULL)
    {
        pstEventNode = (ST_EVENTTASK_NODE*)MOS_MALLOCCLR(sizeof(ST_EVENTTASK_NODE));
        MOS_LIST_ADDTAIL(&MsgMng_GetMng()->stEventList, pstEventNode);
    }
    pstEventNode->uiHttpCancelFlag = 0;
    pstEventNode->CTime            = Mos_Time();
    pstEventNode->ucStatus         = 1;
    Mos_MutexUnLock(&MsgMng_GetMng()->hEventListMutex);
    return pstEventNode;
}

static ST_EVENTTASK_NODE *MsgMng_FindEventNodeById(_UI uiSeqID)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_EVENTTASK_NODE* pstEventNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&MsgMng_GetMng()->stEventList, pstEventNode, stIterator)
    {
        if(pstEventNode->ucStatus == 1 && pstEventNode->uiReqId == uiSeqID)
        {
            break;
        }
    }
    return pstEventNode;
}

ST_EVENTTASK_NODE *MsgMng_FindEventNodeByCTime(_CTIME_T CTime)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_EVENTTASK_NODE* pstEventNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&MsgMng_GetMng()->stEventList, pstEventNode, stIterator)
    {
        if(pstEventNode->ucStatus == 1 && pstEventNode->CTime == CTime)
        {
            break;
        }
    }
    return pstEventNode;
}

// 删除消息告警上报列表节点
static _VOID MsgMng_DelEventNodeEx(ST_EVENTTASK_NODE* pstEventNode)
{
    Mos_MutexLock(&MsgMng_GetMng()->hEventListMutex);
    if (pstEventNode)
    {
        pstEventNode->CTime             = 0;
        pstEventNode->uiReqId           = 0;
        pstEventNode->ucStatus          = 0;
        pstEventNode->uiIoTType         = 0;
        pstEventNode->uiEventID         = 0;
        pstEventNode->uiEventPushFlag   = 0;
        pstEventNode->uiHttpCancelFlag  = 0;
        MOS_MEMSET(pstEventNode->ucEventNo, 0x0, sizeof(pstEventNode->ucEventNo));

        if (pstEventNode->pucHttpBuff)
        {
            MOS_FREE(pstEventNode->pucHttpBuff);
            pstEventNode->pucHttpBuff = MOS_NULL;
        }
        pstEventNode->uiBuffLen        = 0;
        pstEventNode->uiRecvLen        = 0;
        pstEventNode->uiHttpCancelFlag = 0;
    }
    Mos_MutexUnLock(&MsgMng_GetMng()->hEventListMutex);
    return;
}
static _VOID MsgMng_DelEventNode(_UI uiSeqID)
{
    ST_EVENTTASK_NODE* pstEventNode = MOS_NULL;

    pstEventNode = MsgMng_FindEventNodeById(uiSeqID);
    MsgMng_DelEventNodeEx(pstEventNode);

    return;
}

/**********************************************************************************************
Dx 普通报警事件上报
***********************************************************************************************/
_VOID MsgMng_RecvDxUpAlarmRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);
    MOS_PARAM_NULL_NORET(vpUserPtr);

    ST_EVENTTASK_NODE* pstEventNode = (ST_EVENTTASK_NODE* )vpUserPtr;
    
    if(pstEventNode->uiBuffLen == 0)
    {
        pstEventNode->uiBuffLen   = 1024;
        pstEventNode->pucHttpBuff = (_UC*)MOS_MALLOC(pstEventNode->uiBuffLen);
    }
    if(pstEventNode->uiRecvLen + uiLen < pstEventNode->uiBuffLen)
    {
        MOS_MEMCPY(pstEventNode->pucHttpBuff + pstEventNode->uiRecvLen, pucData, uiLen);
        pstEventNode->uiRecvLen += uiLen;
    }
    return;
}

_INT MsgMng_ParseDxUpAlarmEventRsp(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);
    _UC pStrInfo[128] = {0};
    _INT iValue  = 0;
    _UC *pStrTmp     = MOS_NULL;
    _UI uiReqId      = 0;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        CloudStg_UploadLogEx2(MSGMNG_EVENT_STR, Mos_GetSessionId(), __FUNCTION__, -1, EN_ALARM_RT_PRASE_JSON_NULL, (_UC*)"hRoot is Null",MOS_NULL, 1);
        return MOS_ERR;
    }
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"),(_INT*)&uiReqId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pStrTmp);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
    // 删除消息告警上报列表节点
    // MsgMng_DelEventNode(uiReqId);    //上层函数调用处已具备删除逻辑

    if (iValue != 0)
    {
        MOS_VSNPRINTF(pStrInfo, sizeof(pStrInfo), "ogct %u recv upload event rsp code %d method %s",uiReqId,iValue,pStrTmp);
        CloudStg_UploadLogEx2(MSGMNG_EVENT_STR, Mos_GetSessionId(), __FUNCTION__, -1, EN_ALARM_RT_WRONG_CODE, pStrInfo,MOS_NULL, 1);
    }
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_VOID MsgMng_RecvDxUpAlarmFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    MOS_PARAM_NULL_NORET(vpUserPtr);

    ST_EVENTTASK_NODE* pstEventNode = (ST_EVENTTASK_NODE* )vpUserPtr;
    
    if(pstEventNode->pucHttpBuff)
    {
        pstEventNode->pucHttpBuff[pstEventNode->uiRecvLen] = 0;
    }
    MsgMng_ParseDxUpAlarmEventRsp(pstEventNode->pucHttpBuff);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UpLoad Alarm  Event Finish Recv %s",pstEventNode->pucHttpBuff);
    Qp_CountIF_Post(COUNT_TYPE_WARNING, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    
    // 删除消息告警上报列表节点 & 清空缓存
    MsgMng_DelEventNodeEx(pstEventNode);
    return ;
}

_VOID MsgMng_RecvDxUpAlarmFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    MOS_PARAM_NULL_NORET(vpUserPtr);

    _UC aucUrl[256] = {0};
    ST_EVENTTASK_NODE* pstEventNode = (ST_EVENTTASK_NODE* )vpUserPtr;

    MOS_SPRINTF(aucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_ALARMEVENT_URL);
    CloudStg_UploadLogEx2(MSGMNG_EVENT_STR, Mos_GetSessionId(), aucUrl, uiErrCode, EN_ALARM_RT_ALARM_REPORT_FAIL, (_UC*)"AlarmPolicy Send DxUpAlarm Failed",MOS_NULL, 1);
    Qp_CountIF_Post(COUNT_TYPE_WARNING, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);

    // 删除消息告警上报列表节点 & 清空缓存
    MsgMng_DelEventNodeEx(pstEventNode);
    return;
}

// NotifyParam添加拓展字段
static _INT MsgMng_NotifyParamAddExpandField(JSON_HANDLE hBody, _UC * pucExpandField)
{
    if (hBody == MOS_NULL || pucExpandField == MOS_NULL)
    {
        return MOS_ERR;
    }

    _UC *pucKName            = MOS_NULL;
    JSON_HANDLE hCur         = MOS_NULL;
    JSON_HANDLE hNew         = MOS_NULL;
    JSON_HANDLE hChild       = MOS_NULL;
    JSON_HANDLE hExpandField = MOS_NULL;
    JSON_HANDLE hNotifyParam = MOS_NULL;

    hExpandField = Adpt_Json_Parse(pucExpandField);
    if (hExpandField == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    // 添加NotifyParam字段到Body
    hNotifyParam = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"NotifyParam",hNotifyParam);

    // 轮训拓展字段
    hChild = Adpt_Json_GetChild(hExpandField);
    while (hChild != NULL)
    {
        hCur = hChild;
        Adpt_Json_GetName(hCur, &pucKName);
        hChild = Adpt_Json_GetNext(hCur);
        if (MOS_STRLEN(pucKName))
        {
            // Adpt_Json_AddItemReferenceToObject(hNotifyParam,(_UC*)pucKName, hChild);//新json对象的字符串地址还会指向原json对象，该处调用有问题
            hNew = Adpt_Json_DetachItemViaPointer(hExpandField, hCur); // 拆卸json对象，对原json有影响
            // hNew = Adpt_Json_Duplicate(hCur, 1); // 复制json对象，对原json无影响
            if (hNew != MOS_NULL) 
            {
                Adpt_Json_AddItemToObject(hNotifyParam,(_UC*)pucKName, hNew);
            }
        }
    }
    Adpt_Json_Delete(hExpandField);
    return MOS_OK;
}
#if 0
// Sign添加拓展字段 - 能力中台明确拓展字段不需要添加到sign
static _INT MsgMng_SignatureAddExpandField(_UC *pucSignature, _INT iSignatureMaxSize, JSON_HANDLE hExpandField)
{
    if (pucSignature == MOS_NULL || hExpandField == MOS_NULL)
    {
        return MOS_ERR;
    }

    _UC *pucKName = MOS_NULL;
    _UC *pucVName = MOS_NULL;
    JSON_HANDLE hChild      = MOS_NULL;
    _INT iSignatureLen      = 0;
    _INT iSignatureLiftLen  = 0;
    
    // 轮训拓展字段
    hChild = Adpt_Json_GetChild(hExpandField);
    while (hChild != NULL)
    {
        Adpt_Json_GetName(hChild, &pucKName);
        Adpt_Json_GetString(hChild, &pucVName);
        
        iSignatureLen = MOS_STRLEN(pucSignature);
        iSignatureLiftLen = iSignatureMaxSize - iSignatureLen;
        if ((MOS_STRLEN(pucKName) + MOS_STRLEN(pucVName) + 2) < iSignatureLiftLen)
        {
            MOS_VSNPRINTF(pucSignature+iSignatureLen, iSignatureLiftLen,"&%s=%s", pucKName, pucVName);
        }
        else
        {
            MOS_PRINTF("%s Signature size not enough (%d+%d+2)<%d\n", __FUNCTION__, MOS_STRLEN(pucKName), MOS_STRLEN(pucVName), iSignatureLiftLen);
            break;
        }
        
        hChild = Adpt_Json_GetNext(hChild);
    }

    MOS_PRINTF("%s Signature %s\n", __FUNCTION__, pucSignature);

    return MOS_OK;
}
#endif
_UC *MsgMng_BuildDxEventUploadJson(_UI uiReqId, _UI uiKjIoTType,_UI uiKjIoTEventId,_LLID lluHappenTime,_UI uiPushFlag,ST_EVENTTASK_NODE *pstEventNode,_LLID lluKjIotId)
{
    MOS_PARAM_NULL_RETNULL(pstEventNode);

    _UC *pStrTmp        = MOS_NULL;
    _UC *pucOutBuff     = MOS_NULL;
    _UC aucNonce[32]    = {0};
    _UC aucNonce1[32]   = {0};
    _UC aucMethod[16]   = {0};
    _UC aucInBuf[512]   = {0};
    _UC aucEventNo[64]  = {0};
    _CTIME_T ctime;
    ST_MOS_SYS_TIME stSysTime;
    JSON_HANDLE hBody                   = MOS_NULL;
    JSON_HANDLE hDesCrible              = MOS_NULL;
    ST_CFG_HUBIOT_NODE *pstIotNode      = MOS_NULL;
    JSON_HANDLE hRoot  = Adpt_Json_CreateObject( );

    ctime = Mos_Time();

    pstEventNode->uiReqId   = uiReqId;
    pstEventNode->CTime     = ctime;    // 请求时间使用当前系统时间, 用于超时判断
    pstEventNode->uiIoTType = uiKjIoTType;
    pstEventNode->uiEventID = uiKjIoTEventId;
    
    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDEVENT_ALARM_UPLOAD);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstEventNode->uiReqId));

    hBody = Adpt_Json_CreateObject();
    MOS_MEMSET(aucNonce,0,sizeof(aucNonce));
    Mos_GetRandomString(16,aucNonce);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    Adpt_Json_AddItemToObject(hBody,(_UC*)"AIIoTType",  Adpt_Json_CreateStrWithNum(uiKjIoTType));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID",        Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"EventID",    Adpt_Json_CreateStrWithNum(uiKjIoTEventId));
#if ALARMEVENT_REPORT2
    MOS_MEMSET(aucNonce1,0,sizeof(aucNonce1));
    Mos_GetRandomString(4,aucNonce1);
    Mos_TimetoSysTime(&lluHappenTime, &stSysTime);
    MOS_SPRINTF(aucEventNo, "%s%04d%02d%02d%02d%02d%02d%s", Config_GetSystemMng()->aucDevUID,stSysTime.usYear, 
                                                            stSysTime.usMonth, stSysTime.usDay, stSysTime.usHour, 
                                                            stSysTime.usMinute, stSysTime.usSecond, aucNonce1);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"EventNo",    Adpt_Json_CreateString(aucEventNo));
    MOS_STRNCPY(pstEventNode->ucEventNo, aucEventNo, sizeof(pstEventNode->ucEventNo));
    // 云化SDK获取流水号
    MOS_PRINTF("uiKjIoTType:%d pstEventNode->ucEventNo: %s\r\n", uiKjIoTType, pstEventNode->ucEventNo);
    if (ZJ_GetFuncTable()->pfunGetEventNum)
    {
        ZJ_GetFuncTable()->pfunGetEventNum(uiKjIoTType, pstEventNode->ucEventNo);
    }
#endif
    Adpt_Json_AddItemToObject(hBody,(_UC*)"PushFlag",   Adpt_Json_CreateStrWithNum(uiPushFlag));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Time",       Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime))); //  + 28800
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp",  Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime)));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Nonce",      Adpt_Json_CreateString(aucNonce));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"PicID",      Adpt_Json_CreateString((_UC*)""));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"FileID",     Adpt_Json_CreateString((_UC*)""));

    pucOutBuff = (_UC*)MOS_MALLOCCLR(512);
#if ALARMEVENT_REPORT2
    MOS_VSNPRINTF(aucInBuf,sizeof(aucInBuf),"AIIoTType=%d&DID=%s&EventID=%d&EventNo=%s&Nonce=%s&PushFlag=%d&Time=%llu&TimeStamp=%u",
        uiKjIoTType,Config_GetSystemMng()->aucDevUID,uiKjIoTEventId,aucEventNo,aucNonce,uiPushFlag,lluHappenTime,lluHappenTime);
#else
    MOS_VSNPRINTF(aucInBuf,sizeof(aucInBuf),"AIIoTType=%d&DID=%s&EventID=%d&PushFlag=%d&Time=%llu&TimeStamp=%u&nonce=%s",
        uiKjIoTType,Config_GetSystemMng()->aucDevUID,uiKjIoTEventId,uiPushFlag,lluHappenTime,lluHappenTime,aucNonce);
#endif

    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,512,Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

    hDesCrible = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Describe",hDesCrible);
    Adpt_Json_AddItemToObject(hDesCrible,(_UC*)"DeviceName", Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevName));

    pstIotNode = Config_FindIotForHub(uiKjIoTType,lluKjIotId);
    if(pstIotNode)
    {
        Adpt_Json_AddItemToObject(hDesCrible,(_UC*)"AIIotName", Adpt_Json_CreateString(pstIotNode->aucIotName));
    }

    pStrTmp = Adpt_Json_Print(hRoot);
    MOS_PRINTF("EVENT INPUT pStrTmp:%s \r\n", pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}

/**********************************************************************************************
Dx IOT AI报警事件上报
***********************************************************************************************/
_VOID MsgMng_RecvDxUploadAIAlarmPVFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    MOS_PARAM_NULL_NORET(vpUserPtr);

    _UC  aucUrl[256] = {0};
    ST_EVENTTASK_NODE* pstEventNode = (ST_EVENTTASK_NODE* )vpUserPtr;

    MOS_SPRINTF(aucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_ALARMEVENT_URLMSG);
    CloudStg_UploadLogEx2(MSGMNG_EVENT_STR, Mos_GetSessionId(), aucUrl, uiErrCode, EN_ALARM_RT_ALARM_HTTP_FAIL, (_UC*)"AlarmPolicy Send DxIotAIUpload Failed",MOS_NULL, 1);
    Qp_CountIF_Post(COUNT_TYPE_WARNING, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);

    // 通知厂商清除图片数据缓存 
    if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
    {
        _INT iRet = MOS_ERR;
        ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;
        pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNode(0, uiReqId);
        if (pstUplaodAIAlarmPVInfNode)
        {
            iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                                                pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
            if (MOS_OK != iRet)
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed",
                            pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
            }
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
    }

    // 删除上传AI告警图片和视频的节点
    Config_DelUploadAIAlarmPVTaskNode(0, uiReqId);

    if(pstEventNode->pucHttpBuff)
    {
        MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"ReqId:%u UpLoad Alarm Event Fail Recv %s", uiReqId, pstEventNode->pucHttpBuff);
    }
    else
    {
        MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"ReqId:%u UpLoad Alarm Event Fail Recv null", uiReqId);
    }
    // 删除消息告警上报列表节点 & 清空缓存
    MsgMng_DelEventNodeEx(pstEventNode);
    return;
}

_VOID MsgMng_RecvDxUploadAIAlarmPVRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);
    MOS_PARAM_NULL_NORET(vpUserPtr);

    ST_EVENTTASK_NODE* pstEventNode = (ST_EVENTTASK_NODE* )vpUserPtr;
    
    if(pstEventNode->uiBuffLen == 0)
    {
        pstEventNode->uiBuffLen   = 1024;
        pstEventNode->pucHttpBuff = (_UC*)MOS_MALLOC(pstEventNode->uiBuffLen);
    }
    if(pstEventNode->uiRecvLen + uiLen < pstEventNode->uiBuffLen)
    {
        MOS_MEMCPY(pstEventNode->pucHttpBuff + pstEventNode->uiRecvLen, pucData, uiLen);
        pstEventNode->uiRecvLen += uiLen;
    }
    return;
}

_INT MsgMng_ParseUploadAIAlarmPVRsp(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT iValue      = 0;
    _UI uiReqId      = 0;
    _UC *pStrMethod  = MOS_NULL;
    _UC *pStrAIAlarmPVUrl   = MOS_NULL;
    _UC *pStrRequestDate    = MOS_NULL;
    _UC *pStrAuthorization  = MOS_NULL;
    ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf = MOS_NULL;
    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "hRoot is Null");
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"),(_INT*)&uiReqId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pStrMethod);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
    // 删除消息告警上报列表节点
    // MsgMng_DelEventNode(uiReqId);    //上层函数调用处已具备删除逻辑

    // 返回码不是0
    if (iValue == 0)
    {
        _UI uiPicUploadFlag   = 0;
        _UI uiVideoUploadFlag = 0;
        JSON_HANDLE *hBody    = MOS_NULL;
        JSON_HANDLE *hPicInfo = MOS_NULL;        
        ST_CFG_AIALARM_PV_NETINF stAIAlarmPVNetInf = {0};

        hBody    = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
        hPicInfo = Adpt_Json_GetObjectItem(hBody,(_UC*)"PicInfo");
        if (hPicInfo)
        {
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPicInfo,(_UC*)"RequestURL"),&pStrAIAlarmPVUrl);
            if (MOS_STRLEN(pStrAIAlarmPVUrl) > 0)
            {
                MOS_STRNCPY(stAIAlarmPVNetInf.ucPicRequestUrl, pStrAIAlarmPVUrl, sizeof(stAIAlarmPVNetInf.ucPicRequestUrl));
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPicInfo,(_UC*)"requestDate"),&pStrRequestDate);
                MOS_STRNCPY(stAIAlarmPVNetInf.ucPicRequestDate, pStrRequestDate, sizeof(stAIAlarmPVNetInf.ucPicRequestDate));
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPicInfo,(_UC*)"Authorization"),&pStrAuthorization);
                MOS_STRNCPY(stAIAlarmPVNetInf.ucPicAuthorization, pStrAuthorization, sizeof(stAIAlarmPVNetInf.ucPicAuthorization));
                // 回复图片信息,AI告警图片可上传 (图片快生成，可以直接上传)
                // Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, uiReqId, 1);
                uiPicUploadFlag = 1;
            }
            else
            {
                MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"ReqId:%u AIAlarmPVUrl Pic Len <= 0", uiReqId);
                // 平台无图片信息回复 AI告警图片的缓存可以释放
                // Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, uiReqId, 2);
                uiPicUploadFlag = 2;
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"ReqId:%u hPicInfo is NULL!", uiReqId);
            // 平台无图片信息回复 AI告警图片的缓存可以释放
            // Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, uiReqId, 2);
            uiPicUploadFlag = 2;
        }

        JSON_HANDLE *hVideoInfo = Adpt_Json_GetObjectItem(hBody,(_UC*)"VideoInfo");
        if (hVideoInfo)
        {
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hVideoInfo,(_UC*)"RequestURL"),&pStrAIAlarmPVUrl);
            if (MOS_STRLEN(pStrAIAlarmPVUrl) > 0)
            {
                MOS_STRNCPY(stAIAlarmPVNetInf.ucVideoRequestUrl, pStrAIAlarmPVUrl, sizeof(stAIAlarmPVNetInf.ucVideoRequestUrl));
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hVideoInfo,(_UC*)"requestDate"),&pStrRequestDate);
                MOS_STRNCPY(stAIAlarmPVNetInf.ucVideoRequestDate, pStrRequestDate, sizeof(stAIAlarmPVNetInf.ucVideoRequestDate));
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hVideoInfo,(_UC*)"Authorization"),&pStrAuthorization);
                MOS_STRNCPY(stAIAlarmPVNetInf.ucVideoAuthorization, pStrAuthorization, sizeof(stAIAlarmPVNetInf.ucVideoAuthorization));
                // (视频生成较久, 需要厂商主动调用 ZJ_SetUploadAIAlarmPVFileFinish 通知sdk视频已制作成功)
            }
            else
            {
                MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"ReqId:%u AIAlarmPVUrl Video Len <= 0", uiReqId);
                // AI告警视频的缓存可以释放
                // Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(0, uiReqId, 2); 
                uiVideoUploadFlag = 2;
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"ReqId:%u hVideoInfo is NULL!", uiReqId);
            // AI告警图片的缓存可以释放
            // Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(0, uiReqId, 2); 
            uiVideoUploadFlag = 2;
        }

        // 设置 UploadAIAlarmPVTask 节点 ReportMsg上报信息
        Config_SetUploadAIAlarmPVTaskNodeReportInf(0, uiReqId, 1, Mos_Time());

        // 设置上传AI告警图片和视频的网络信息
        Config_SetUploadAIAlarmPVTaskNodeNetInfo(0, uiReqId, &stAIAlarmPVNetInf);

        // 设置上传AI告警图片和视频的上报标志
        Config_SetUploadAIAlarmPVTaskNodePicUploadFlag(0, uiReqId, uiPicUploadFlag);
        Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlag(0, uiReqId, uiVideoUploadFlag);

        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ReqId %u recv upload AIAlarmPV rsp code %d method %s PicUrl: %s VideoUrl: %s",
                    uiReqId,iValue,pStrMethod,stAIAlarmPVNetInf.ucPicRequestUrl,stAIAlarmPVNetInf.ucVideoRequestUrl);
        Adpt_Json_Delete(hRoot);
        return MOS_OK;
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "ReqId:%u Upload AIAlarmPV 3526 Recv Code = %d Error", uiReqId, iValue);
        Adpt_Json_Delete(hRoot);
        return MOS_ERR;
    }
}

_VOID MsgMng_RecvDxUploadAIAlarmPVFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    MOS_PARAM_NULL_NORET(vpUserPtr);

    _INT iRet = MOS_ERR;
    ST_EVENTTASK_NODE* pstEventNode = (ST_EVENTTASK_NODE* )vpUserPtr;
    if(pstEventNode->pucHttpBuff)
    {
        pstEventNode->pucHttpBuff[pstEventNode->uiRecvLen] = 0;
    }
    iRet = MsgMng_ParseUploadAIAlarmPVRsp(pstEventNode->pucHttpBuff);
    if (iRet != MOS_OK)
    {
        // 通知厂商清除图片数据缓存 
        if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
        {
            ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;
            pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNode(0, uiReqId);
            if (pstUplaodAIAlarmPVInfNode)
            {
                iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                                                   pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                if (MOS_OK != iRet)
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed",
                                                pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                                pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                }
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
        }

        // 删除上传AI告警图片和视频的节点
        Config_DelUploadAIAlarmPVTaskNode(0, uiReqId);
    }
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UPLOAD AIALARM_PV Finish Recv %s",pstEventNode->pucHttpBuff);
    Qp_CountIF_Post(COUNT_TYPE_WARNING, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    // 删除消息告警上报列表节点 & 清空缓存
    MsgMng_DelEventNodeEx(pstEventNode);
    return ;
}

_UC *MsgMng_BuildUploadAIAlarmPVJson(_UI uiReqId, _UI uiKjIoTType,_UI uiKjIoTEventId,_LLID lluHappenTime,_UI uiPushFlag,ST_EVENTTASK_NODE *pstEventNode,_LLID lluKjIotId,_UI uiNeedPicUrl,_UI uiNeedVideoUrl,_UC *pucExpandField)
{
    MOS_PARAM_NULL_RETNULL(pstEventNode);

    _UC *pStrTmp        = MOS_NULL;
    _UC *pucOutBuff     = MOS_NULL;
    _UC aucNonce[32]    = {0};
    _UC aucNonce1[32]   = {0};
    _UC aucMethod[16]   = {0};
    _UC aucInBuf[512]   = {0};
    _UC aucEventNo[64]  = {0};
    _CTIME_T ctime;
    ST_MOS_SYS_TIME stSysTime;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = Adpt_Json_CreateObject();

    ctime = Mos_Time();

    pstEventNode->uiReqId   = uiReqId;
    pstEventNode->CTime     = ctime;    // 请求时间使用当前系统时间, 用于超时判断
    pstEventNode->uiIoTType = uiKjIoTType;
    pstEventNode->uiEventID = uiKjIoTEventId;

    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDEVENT_IOTAIUPLOAD);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstEventNode->uiReqId));

    hBody = Adpt_Json_CreateObject();
    MOS_MEMSET(aucNonce,0,sizeof(aucNonce));
    Mos_GetRandomString(16,aucNonce);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    Adpt_Json_AddItemToObject(hBody,(_UC*)"AIIoTType",  Adpt_Json_CreateStrWithNum(uiKjIoTType));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID",        Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"EventID",    Adpt_Json_CreateStrWithNum(uiKjIoTEventId));

    MOS_MEMSET(aucNonce1,0,sizeof(aucNonce1));
    Mos_GetRandomString(4,aucNonce1);
    Mos_TimetoSysTime(&lluHappenTime, &stSysTime);
    MOS_SPRINTF(aucEventNo, "%s%04d%02d%02d%02d%02d%02d%s", Config_GetSystemMng()->aucDevUID,stSysTime.usYear, 
                                                            stSysTime.usMonth, stSysTime.usDay, stSysTime.usHour, 
                                                            stSysTime.usMinute, stSysTime.usSecond, aucNonce1);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"EventNo",    Adpt_Json_CreateString(aucEventNo));
    MOS_STRNCPY(pstEventNode->ucEventNo, aucEventNo, sizeof(pstEventNode->ucEventNo));
    
    Adpt_Json_AddItemToObject(hBody,(_UC*)"NeedPicUrl",   Adpt_Json_CreateStrWithNum(uiNeedPicUrl));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"NeedVideoUrl", Adpt_Json_CreateStrWithNum(uiNeedVideoUrl));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Time",         Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime))); //  + 28800
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp",    Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime)));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Nonce",        Adpt_Json_CreateString(aucNonce));
    
    // NotifyParam添加拓展字段
    MsgMng_NotifyParamAddExpandField(hBody, pucExpandField);
    
    pucOutBuff = (_UC*)MOS_MALLOCCLR(512);
    if (pucOutBuff != MOS_NULL)
    {
        MOS_VSNPRINTF(aucInBuf,sizeof(aucInBuf),"AIIoTType=%d&DID=%s&EventID=%d&EventNo=%s&NeedPicUrl=%d&NeedVideoUrl=%d&Nonce=%s&Time=%llu&TimeStamp=%u",
        uiKjIoTType,Config_GetSystemMng()->aucDevUID,uiKjIoTEventId,aucEventNo,uiNeedPicUrl,uiNeedVideoUrl,aucNonce,lluHappenTime,lluHappenTime);

        Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,512,Config_GetSystemMng()->aucDevkey);
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

        pStrTmp = Adpt_Json_Print(hRoot);

        MOS_PRINTF("EVENT INPUT pStrTmp:%s \r\n", pStrTmp);
        MOS_FREE(pucOutBuff);
    }

    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}

// 创建上传AI告警图片或AI告警视频节点
_INT MsgMng_CreateAIAlarmPVNode(_UI uiReqId, ST_ZJ_IOT_INF* pstIoTInf, _UI uiNeedPicUrl, _UI uiNeedVideoUrl, _VOID* pstHandler)
{
    _UI uiSetAIEventPVFailFlag = 0;
    if (pstHandler)
    {
        if (uiNeedPicUrl == 1 || uiNeedVideoUrl == 1)
        {
            // 设备有网
            if ((EN_ZJ_NETWORK_TYPE_NONET != Http_GetNetWorkType()) && (EN_ZJ_NETWORK_TYPE_AP != Http_GetNetWorkType()))
            {
                _UI uiUploadAIAlarmPVNodeCount = 0;
                Config_GetUploadAIAlarmPVTaskNodeCount(0, &uiUploadAIAlarmPVNodeCount);
                // AI告警节点数未超过链表最大值
                if (uiUploadAIAlarmPVNodeCount <= AI_IOTPV_ALARM_LISTNODE_MAXCOUNT)
                {
                    // 添加 上传AI告警图片和视频 链表节点
                    Config_AddUploadAIAlarmPVTaskNode(0, uiReqId, pstIoTInf, (ST_ZJ_AI_AlARM_UPLOAD_INF*)pstHandler);
                    return MOS_OK;
                }
                else // AI告警节点数超过链表最大值
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "AIAlarmPV UploadAIAlarmPVNodeCount(%u) > AI_IOTPV_ALARM_LISTNODE_MAXCOUNT(%d), Set Event Err",
                                    uiUploadAIAlarmPVNodeCount, (_INT)AI_IOTPV_ALARM_LISTNODE_MAXCOUNT);
                    uiSetAIEventPVFailFlag = 1;
                }
            }
            else    // 设备无网
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "AIAlarmPV Camera in No NetWork Status");
                uiSetAIEventPVFailFlag = 1;
            }
        }
        else
        {
            // IoT属性上传开关都为关,但是厂商没有传入上传数据
            MOS_LOG_WARN(MSGMNG_ID_LOG_STR, "NeedPicUrl=%d NeedVideoUrl=%d, Notice Device to Free Data", uiNeedPicUrl, uiNeedVideoUrl);           
            uiSetAIEventPVFailFlag = 1;
        }

        // 通知厂商释放数据
        if (uiSetAIEventPVFailFlag)
        {
            ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf = (ST_ZJ_AI_AlARM_UPLOAD_INF*)pstHandler;
            if (pstAIAlarmUploadInf)
            {
                if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
                {
                    _INT iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
                    if (MOS_OK != iRet)
                    {
                        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed", pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
                    }
                }
                else
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
                }
            }
        }
        return MOS_ERR; 
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "pstHandler Device have not pic or video data");
        return MOS_ERR;
    }
}

// 获取使用reportMsg上报事件的信息
_VOID MsgMng_GetAiEventReportMsgInf(_UI uiReqId, ST_ZJ_IOT_INF* pstIoTInf, _VOID* pstHandler, ST_AIEVENT_REPORTMSD_INF* pstAiEventReportMsgInf)
{
    _INT iRet = MOS_ERR;
    // 电子围栏,使用ReportMsg事件上报接口
    if (KJIOT_EVENT_IS_FENCE(pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId))
    {
        // 获取MOTION的策略
        ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = Config_FindAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION,EN_ZJ_DEFAULT_IOTID,IOT_DEFAULT_POLICYID_MOTION);
        if (pstAlarmNode)
        {
            // 提取MOTION策略的属性
            // MOS_PRINTF("%s 1000 pstAlarmNode->pucProp %s\n", __FUNCTION__, pstAlarmNode->pucProp);
            JSON_HANDLE hIotAIRoot = Adpt_Json_Parse(pstAlarmNode->pucProp);
            if (hIotAIRoot)
            {
                // 电子围栏支持该功能
                JSON_HANDLE hIotAIFenceRoot = Adpt_Json_GetObjectItem(hIotAIRoot, (_UC*)"Fence");
                if (hIotAIFenceRoot)
                {
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotAIFenceRoot, (_UC*)"Capture"), &(pstAiEventReportMsgInf->uiNeedPicUrl));
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotAIFenceRoot, (_UC*)"Video"), &(pstAiEventReportMsgInf->uiNeedVideoUrl));
                    Adpt_Json_Delete(hIotAIRoot);
                    iRet = MsgMng_CreateAIAlarmPVNode(uiReqId, pstIoTInf, pstAiEventReportMsgInf->uiNeedPicUrl, pstAiEventReportMsgInf->uiNeedVideoUrl, pstHandler);
                    if (MOS_OK == iRet)
                    {
                        pstAiEventReportMsgInf->uiIsUploadAIAlarmPV = 1;
                        return;
                    }
                    else
                    {
                        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "[%u %u] MsgMng_CreateAIAlarmPVNode return err",
                                                    pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId);
                    }
                }
                else
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "[%u %u] Get Fence Json fail, hIotAIFenceRoot is Null",
                                                pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId);
                    Adpt_Json_Delete(hIotAIRoot);
                }
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "[%u %u] Get MOTION Json fail, hIotAIRoot is Null",
                                            pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "[%u %u] Get iot alarm policy node fail, pstAlarmNode is Null",
                                        pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId);
        }
        pstAiEventReportMsgInf->uiIsUploadAIAlarmPV = 1;
        pstAiEventReportMsgInf->uiNeedPicUrl        = 0;
        pstAiEventReportMsgInf->uiNeedVideoUrl      = 0;
        return; // 电子围栏告警返回
    }
    // 大于等于跌倒(电瓶车,高空抛物,口罩识别) 使用ReportMsg事件上报接口
    else if (pstIoTInf->uiIoTType >= EN_ZJ_AIIOT_TYPE_FALLDOWN)
    {
        // 获取AI事件的策略
        ST_CFG_ALARMPOLICY_NODE *pstAlarmNode = Config_FindAlarmPolicyNode(pstIoTInf->uiIoTType,EN_ZJ_DEFAULT_IOTID,pstIoTInf->uiIoTType);
        if (pstAlarmNode)
        {
            // 提取AI事件策略的属性
            // MOS_PRINTF("%s %d pstAlarmNode->pucProp %s\n", __FUNCTION__, uiKjIoTType, pstAlarmNode->pucProp);
            JSON_HANDLE hIotAIRoot = Adpt_Json_Parse(pstAlarmNode->pucProp);
            if (hIotAIRoot)
            {
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotAIRoot, (_UC*)"Capture"), &pstAiEventReportMsgInf->uiNeedPicUrl);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hIotAIRoot, (_UC*)"Video"), &pstAiEventReportMsgInf->uiNeedVideoUrl);
                pstAiEventReportMsgInf->uiIsUploadAIAlarmPV = 1;
                Adpt_Json_Delete(hIotAIRoot);
                // 创建上传AI告警图片或AI告警视频节点
                iRet = MsgMng_CreateAIAlarmPVNode(uiReqId, pstIoTInf, pstAiEventReportMsgInf->uiNeedPicUrl, pstAiEventReportMsgInf->uiNeedVideoUrl, pstHandler);
                if (MOS_OK == iRet)
                {
                    pstAiEventReportMsgInf->uiIsUploadAIAlarmPV = 1;
                    return;
                }
                else
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "[%u %u] MsgMng_CreateAIAlarmPVNode return err",
                                                pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId);
                }
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "[%u %u] Get AI Prop Json fail, hIotAIRoot is Null",
                                            pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId);
                Adpt_Json_Delete(hIotAIRoot);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "[%u %u] Get iot alarm policy node fail, pstAlarmNode is Null",
                                        pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId);
        }
        pstAiEventReportMsgInf->uiIsUploadAIAlarmPV = 1;
        pstAiEventReportMsgInf->uiNeedPicUrl        = 0;
        pstAiEventReportMsgInf->uiNeedVideoUrl      = 0;
        return; // AI IoT设备告警返回
    }

    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "[%u %u] No Need Upload AIAlarm PV",
                                pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId);
    pstAiEventReportMsgInf->uiIsUploadAIAlarmPV = 0;
    pstAiEventReportMsgInf->uiNeedPicUrl        = 0;
    pstAiEventReportMsgInf->uiNeedVideoUrl      = 0;
    return; // 非电子围栏和非AI IoT设备 告警返回
}

// 事件推送到云端
_INT MsgMng_UploadEventToDxServer(ST_ZJ_IOT_INF* pstIoTInf,_LLID lluHappenTime,_UI uiPushFlag,_VOID* pstHandler)
{
    if (MsgMng_GetStartWorkFlag() == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Get StartWorkFlag is %d", MsgMng_GetStartWorkFlag());
        return MOS_OK;
    }
    MOS_PARAM_NULL_RETNULL(pstIoTInf);

    _INT iRet             = 0;
    _UI  uiHttpsFlag      = 0;
    _UC  *pStrTmp         = MOS_NULL;
    _UC  *pReportUrl      = MOS_NULL;
    _UC  *pucExpandField  = MOS_NULL;
    _UC  auAdmonAddr[128] = {0};
    _UC  aucUrl[128]      = {0};  /*不使用，仅作入参功能*/
    ST_AIEVENT_REPORTMSD_INF stAiEventReportMsgInf = {0};

    #if ALARMEVENT_REPORT2
    pReportUrl = (_UC *)HTTP_ALARMEVENT_URL2;
    #else
    pReportUrl = (_UC *)HTTP_ALARMEVENT_URL;
    #endif
    
    // 获取平台域名地址
    iRet = Http_Parse_Url(Config_GetSystemMng()->aucAlarmAddr, auAdmonAddr, aucUrl, &uiHttpsFlag);
    if (iRet == MOS_ERR)
    {
        MOS_LOG_ERR(MSGMNG_EVENT_STR, "Http_Parse_Url error");
        return MOS_ERR;
    }
    _UI uiReqId = Mos_GetSessionId();
    // 创建消息告警上报列表节点
    ST_EVENTTASK_NODE *pstEventNode = MsgMng_CreateEventNode();

    // 获取使用reportMsg上报事件的信息
    MsgMng_GetAiEventReportMsgInf(uiReqId, pstIoTInf, pstHandler, &stAiEventReportMsgInf);
    // 使用厂商的告警时间
    if (pstHandler != MOS_NULL)
    {
        ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf = (ST_ZJ_AI_AlARM_UPLOAD_INF*)pstHandler;
        lluHappenTime  = pstAIAlarmUploadInf->lluTimeStamp;
        // 简易json格式才会赋值
        if (pstAIAlarmUploadInf->aucExpandField[0] == '{')
        {
            pucExpandField = pstAIAlarmUploadInf->aucExpandField;
        }
    }

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    if (stAiEventReportMsgInf.uiIsUploadAIAlarmPV)
    {
        pReportUrl = (_UC *)HTTP_ALARMEVENT_URLMSG;
        pStrTmp = MsgMng_BuildUploadAIAlarmPVJson(uiReqId, pstIoTInf->uiIoTType,pstIoTInf->uiIoTEventId,lluHappenTime,
                uiPushFlag,pstEventNode,pstIoTInf->lluIoTId,stAiEventReportMsgInf.uiNeedPicUrl,stAiEventReportMsgInf.uiNeedVideoUrl,pucExpandField);
        stHttpInfoNode.pfuncRecv       = MsgMng_RecvDxUploadAIAlarmPVRsp;
        stHttpInfoNode.pfuncFinished   = MsgMng_RecvDxUploadAIAlarmPVFinish;
        stHttpInfoNode.pfuncFailed     = MsgMng_RecvDxUploadAIAlarmPVFail;
    }
    else
    {
        pStrTmp = MsgMng_BuildDxEventUploadJson(uiReqId, pstIoTInf->uiIoTType,pstIoTInf->uiIoTEventId,lluHappenTime,uiPushFlag,pstEventNode,pstIoTInf->lluIoTId);
        stHttpInfoNode.pfuncRecv       = MsgMng_RecvDxUpAlarmRsp;
        stHttpInfoNode.pfuncFinished   = MsgMng_RecvDxUpAlarmFinish;
        stHttpInfoNode.pfuncFailed     = MsgMng_RecvDxUpAlarmFail;
    }
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.vpUserPtr       = pstEventNode;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, pReportUrl, EN_HTTP_METHOD_POST, uiReqId);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct %u dev %s ,send AIAlarmPV alarmEvent %s to alarmPlatAddr %s ,ret %d",
        pstEventNode->uiReqId,Config_GetSystemMng()->aucDevUID, pStrTmp, auAdmonAddr, iRet);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        CloudStg_UploadLogEx2(MSGMNG_EVENT_STR, uiReqId, auAdmonAddr, 502, EN_ALARM_RT_GET_IPADDR_FAIL, (_UC*)"AlarmPolicy Get IpArray From AucAlarmAddr Failed",MOS_NULL, 1);
    }
    if(iRet != MOS_OK)
    {
        if (KJIOT_EVENT_IS_FENCE(pstIoTInf->uiIoTType, pstIoTInf->uiIoTEventId) ||
            (pstIoTInf->uiIoTType >= EN_ZJ_AIIOT_TYPE_FALLDOWN))
        {
            if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
            {
                ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf = (ST_ZJ_AI_AlARM_UPLOAD_INF*)pstHandler;
                iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
                if (MOS_OK != iRet)
                {
                    MOS_LOG_ERR(MSGMNG_EVENT_STR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s  VideoPath:%s failed", pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
                }
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_EVENT_STR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
            }
        }

        MOS_LOG_ERR(MSGMNG_EVENT_STR,"send AIAlarmPV alarmEvent Add http(s) error!");
        // 删除消息告警上报列表节点
        MsgMng_DelEventNodeEx(pstEventNode);
    }
    if (pStrTmp)
    {
        MOS_FREE(pStrTmp);
    }
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}
#if 0
/**********************************************************************************************
Dx 报警Mapping
***********************************************************************************************/
_VOID MsgMng_RecvDxAlarmMappingRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    ST_MSGMNG_CMDSERVER *pstCmdServer = MsgMng_GetCmdServer();
    
    if(pstCmdServer->usBuffLen == 0)
    {
        pstCmdServer->usBuffLen   = 1024;
        pstCmdServer->pucHttpBuff = (_UC*)MOS_MALLOC(pstCmdServer->usBuffLen);
    }
    if(pstCmdServer->usRecvLen + uiLen < pstCmdServer->usBuffLen)
    {
        MOS_MEMCPY(pstCmdServer->pucHttpBuff + pstCmdServer->usRecvLen, pucData, uiLen);
        pstCmdServer->usRecvLen += uiLen;
    }
    return;
}

_INT MsgMng_ParseDxAlarmMappingRsp(_UC *pucJson, ST_EVENTTASK_NODE *pstEventNode)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT iValue  = 0;
    _UC *pStrTmp     = MOS_NULL;
    _UI uiReqId      = 0;
    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "hRoot == MOS_NULL");
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"),(_INT*)&uiReqId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pStrTmp);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
    if (pstEventNode)
    {
        pstEventNode->uiReqId  = 0;
        pstEventNode->ucStatus = 0;
        pstEventNode->uiEventPushFlag = 0;
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct %u recv upload event rsp code %d method %s",uiReqId,iValue,pStrTmp);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_VOID MsgMng_RecvDxAlarmMappingFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMNG_CMDSERVER *pstCmdServer = MsgMng_GetCmdServer();
    ST_EVENTTASK_NODE *pstEventNode = (ST_EVENTTASK_NODE *)vpUserPtr;
    
    if(pstCmdServer->pucHttpBuff)
    {
        pstCmdServer->pucHttpBuff[pstCmdServer->usRecvLen] = 0;
    }
    
    MsgMng_ParseDxAlarmMappingRsp(pstCmdServer->pucHttpBuff, pstEventNode);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UpLoad Alarm  Event Finish Recv %s",pstCmdServer->pucHttpBuff);
    Qp_CountIF_Post(COUNT_TYPE_WARNING, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    MOS_FREE(pstCmdServer->pucHttpBuff);
    pstCmdServer->usBuffLen = 0;
    pstCmdServer->usRecvLen = 0;
    pstCmdServer->uiHttpHandle  = 0;
    return ;
}

_VOID MsgMng_RecvDxAlarmMappingFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC pucUrl[256] = {0};
    ST_MSGMNG_CMDSERVER *pstCmdServer = MsgMng_GetCmdServer();
    MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_ALARMEVENT_URL);

    Qp_CountIF_Post(COUNT_TYPE_WARNING, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);   
            
    if(pstCmdServer->pucHttpBuff)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UpLoad Alarm  Event Fail Recv %s",pstCmdServer->pucHttpBuff);
    }
    MOS_FREE(pstCmdServer->pucHttpBuff);
    pstCmdServer->pucHttpBuff  = MOS_NULL;
    pstCmdServer->usBuffLen    = 0;
    pstCmdServer->usRecvLen    = 0;
    pstCmdServer->uiHttpHandle = 0;
    return;
}

// 报警映射上报
_UC *MsgMng_BuildDxEventMappingJson(_UI uiReqId,_UI uiKjIoTType,_UC *pucEventNo,_UC *pucPicObjId,_UC *pucPicCid,_UC *pucFileObjId,_UC *pucFileCid)
{
    MOS_PARAM_NULL_RETNULL(pucEventNo);

    _UC *pStrTmp        = MOS_NULL;
    _UC *pucOutBuff     = MOS_NULL;
    _UC aucNonce[32]    = {0};
    _UC aucMethod[16]   = {0};
    _UC aucInBuf[512]   = {0};
    JSON_HANDLE hBody                   = MOS_NULL;
    JSON_HANDLE hRoot  = Adpt_Json_CreateObject( );
    JSON_HANDLE hArray = Adpt_Json_CreateArray();
    JSON_HANDLE hArrayItem = MOS_NULL;

    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDEVENT_PIC_ALARM_MAPPING);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiReqId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));

    // AlarmMappingList数组
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"AlarmMappingList", hArray);
    {
        hArrayItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArray,hArrayItem);
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTType",  Adpt_Json_CreateStrWithNum(uiKjIoTType));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"EventNo",    Adpt_Json_CreateString(pucEventNo));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"PicObjId",   Adpt_Json_CreateString(pucPicObjId));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"PicCid",   Adpt_Json_CreateString(pucPicCid));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"FileObjId",   Adpt_Json_CreateString(pucFileObjId));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"FileCid",   Adpt_Json_CreateString(pucFileCid));
    }

    MOS_MEMSET(aucNonce,0,sizeof(aucNonce));
    Mos_GetRandomString(16,aucNonce);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Nonce",Adpt_Json_CreateString(aucNonce));

    pucOutBuff = (_UC*)MOS_MALLOCCLR(512);
    pStrTmp = Adpt_Json_Print(hArray);
    MOS_VSNPRINTF(aucInBuf, 512,"AlarmMappingList=%s&DID=%s&Nonce=%s",
        pStrTmp,Config_GetSystemMng()->aucDevUID,aucNonce);
    if (pStrTmp)
    {
        MOS_FREE(pStrTmp);
        pStrTmp = MOS_NULL;
    }

    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,512,Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

    pStrTmp = Adpt_Json_Print(hRoot);
    MOS_PRINTF("EVENT INPUT pStrTmp:%s \r\n", pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}

// 告警事件关联云存和图片
_INT MsgMng_UploadEventMappingToDxServer(_VPTR pEventNode)
{
    if (MsgMng_GetStartWorkFlag() == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Get StartWorkFlag is %d", MsgMng_GetStartWorkFlag());
        return MOS_OK;
    }
    
    _INT i,iRet = 0;
    _US  usPort = 80;
    static _US usLoopCnt = 0;
    _UI uiHttpsFlag = 0;
    _UC *pStrTmp    = MOS_NULL;
    _UC *pStrStart  = MOS_NULL;
    _UC auAdmonAddr[128] = {0};
    ST_MOS_INET_IPARRAY *pstIpArray = MOS_NULL;
    ST_MOS_INET_IP *pstNetIp = MOS_NULL;
    ST_EVENTTASK_NODE *pstEventNode = (ST_EVENTTASK_NODE *)pEventNode;

    MOS_MEMSET(auAdmonAddr, 0, sizeof(auAdmonAddr));

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucAlarmAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort     = 443;
    } 
    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucAlarmAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucAlarmAddr;
    }
    else
    {
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRNCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Now Mapping pucPicObjId: %s, pucPicCid: %s, pucFileObjId: %s, pucFileCid: %s to ALarm uiKjIoTType: %d, pucEventNo: %s"
        , pstEventNode->ucPicObjId, pstEventNode->ucPicCid, pstEventNode->ucFileObjId, pstEventNode->ucFileCid, pstEventNode->uiIoTType, pstEventNode->ucEventNo);
    
    pstIpArray = (ST_MOS_INET_IPARRAY*)MOS_MALLOCCLR(sizeof(ST_MOS_INET_IPARRAY));
    if(Mos_InetGetAddrInfo(auAdmonAddr,usPort,EN_CINET_PRTL_TCP,MOS_FALSE,pstIpArray) != MOS_OK)
    {
        pstEventNode->ucStatus = 0;
        pstEventNode->uiEventPushFlag = 0;
        MOS_LOG_ERRFILTER(MSGMNG_ID_LOG_STR, "Get Sign Host Error!");
        MOS_FREE(pstIpArray);
        return MOS_ERR;
    }
#ifdef SDK_ADPT_IPV6
    pstNetIp = &pstIpArray->astIps[usLoopCnt%pstIpArray->uiCount];
#else
    for(i = 0; i < pstIpArray->uiCount; i++)
    {
        pstNetIp = &pstIpArray->astIps[i];
        if(pstNetIp->usType == EN_CINET_TYPE_IPV4)
        {
            break;
        }
    }
#endif
    usLoopCnt++;

    _UI uiReqId = Mos_GetSessionId();
    pStrTmp = MsgMng_BuildDxEventMappingJson(uiReqId,pstEventNode->uiIoTType,pstEventNode->ucEventNo,pstEventNode->ucPicObjId,
                                                pstEventNode->ucPicCid,pstEventNode->ucFileObjId,pstEventNode->ucFileCid);
    if(uiHttpsFlag)
        iRet = Http_Httpsclient_SendAsyncPostRequest(pstNetIp,auAdmonAddr,HTTP_ALARMEVENT_MAPPING_URL, pStrTmp,MOS_STRLEN(pStrTmp),
            EN_HTTP_TYPE_NORMAL, MsgMng_RecvDxAlarmMappingRsp,MsgMng_RecvDxAlarmMappingFinish,MsgMng_RecvDxAlarmMappingFail,pstEventNode,MOS_NULL,MOS_NULL,uiReqId,EN_HTTP_PRIORITY_HIGH);
    else
        iRet = Http_Httpclient_SendAsyncPostRequest(pstNetIp,auAdmonAddr,HTTP_ALARMEVENT_MAPPING_URL, pStrTmp,MOS_STRLEN(pStrTmp),
            EN_HTTP_TYPE_NORMAL, MsgMng_RecvDxAlarmMappingRsp,MsgMng_RecvDxAlarmMappingFinish,MsgMng_RecvDxAlarmMappingFail,MOS_NULL,MOS_NULL,MOS_NULL,uiReqId,EN_HTTP_PRIORITY_HIGH);     
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct dev %s ,send alarmEvent %s to alarmPlatAddr %s ,ret %d",
                                    Config_GetSystemMng()->aucDevUID, pStrTmp, auAdmonAddr, iRet);
    if(iRet != MOS_OK)
    {
        pstEventNode->uiReqId  = 0;
        pstEventNode->ucStatus = 0;
        pstEventNode->uiEventPushFlag = 0;    
    }

    MOS_FREE(pstIpArray);
    MOS_FREE(pStrTmp);
    return iRet;
}
#endif
#if 0
/**********************************************************************************************
异常类型上报
***********************************************************************************************/
static _INT MsgMng_RecvExceptEventCb(_UI uiReqId,_VPTR hJsonRoot)
{
    _INT iCode = 0;
    ST_EVENTTASK_NODE *pstEventNode = MsgMng_FindEventNodeById(uiReqId);
    if(pstEventNode != MOS_NULL)
    {
        pstEventNode->ucStatus = 0;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"),&iCode);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct %u recv upload exception rsp code %d",uiReqId,iCode);
    return MOS_OK;
}
// 目前该函数调用的MsgMng_AllocEventNode接口涉及的MsgMng_GetMng()->stEventList
_INT MsgMng_SendExceptionToServer(_UC *pucPeerId,_UI uiErrType,_UI uiErrId,_UC *pucDes)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pucDes);

    _INT iRet = 0;
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[32];
    JSON_HANDLE hBody  = MOS_NULL;
    JSON_HANDLE hRoot  = Adpt_Json_CreateObject();
    // 创建消息告警上报列表节点
    ST_EVENTTASK_NODE *pstEventNode = MsgMng_CreateEventNode();
    
    pstEventNode->uiReqId = Mos_GetSessionId();
  
    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDEVENT_EXCEPT_UPLOAD);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstEventNode->uiReqId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ExceptionType", Adpt_Json_CreateStrWithNum(uiErrType));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ExceptionId", Adpt_Json_CreateStrWithNum(uiErrId));
    if(MOS_STRLEN(pucDes) > 0)
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"ExceptionDesc", Adpt_Json_CreateString(pucDes));
    }
    pStrTmp = Adpt_Json_Print(hRoot);
    iRet = MsgMng_SendMsg(pucPeerId,pstEventNode->uiReqId, EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDEVENT_EXCEPT_UPLOAD,
        pStrTmp,MOS_STRLEN(pStrTmp),MsgMng_RecvExceptEventCb);

    if(iRet != MOS_OK)
    {
        pstEventNode->ucStatus = 0;
    }
    MOS_FREE(pStrTmp);
    Adpt_Json_Delete( hRoot);
    return MOS_OK;
}
#endif
// 处理报警事件的状态
_INT MsgMng_ProcEventNodeStatus()
{
    _ULLID lluTimeNow  = 0;
    _ULLID lluDuration = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    // 报警事件任务节点
    ST_EVENTTASK_NODE* pstEventNode = MOS_NULL;

    lluTimeNow = (_ULLID)Mos_Time();
    // 遍历报警事件的链表
    FOR_EACHDATA_INLIST(&MsgMng_GetMng()->stEventList, pstEventNode, stIterator)
    {
        lluDuration = MOS_ABS_NUM(lluTimeNow - (_ULLID)pstEventNode->CTime);
        // 上报超时
        if((pstEventNode->ucStatus == 1) && (pstEventNode->uiHttpCancelFlag == 0) && (lluDuration > AI_IOTPV_ALARM_REPORT_TIMEOUT_SEC))
        {
            // 删除事件节点，不做上传处理
            MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"ReqId:%u report event[%u %u] err for TimeOut (%llu - %llu) = %llu > %d", 
                                pstEventNode->uiReqId, pstEventNode->uiIoTType, pstEventNode->uiEventID,
                                lluTimeNow, (_ULLID)pstEventNode->CTime, lluDuration, (_INT)AI_IOTPV_ALARM_REPORT_TIMEOUT_SEC);

            // 设置HTTP取消标志
            Http_Httpclient_CancelAsyncRequestEx(pstEventNode->uiReqId);
            pstEventNode->uiHttpCancelFlag = 1;
#if 0
            if (KJIOT_EVENT_IS_FENCE(pstEventNode->uiIoTType, pstEventNode->uiEventID) ||
                (pstEventNode->uiIoTType >= EN_ZJ_AIIOT_TYPE_FALLDOWN))
            {
                // 通知厂商清除图片数据缓存 
                if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
                {
                    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;
                    pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNode(0, pstEventNode->uiReqId);
                    if (pstUplaodAIAlarmPVInfNode)
                    {
                        _INT iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                                                        pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                        if (MOS_OK != iRet)
                        {
                            MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed",
                                                        pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath,
                                                        pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath);
                        }
                    }
                }
                else
                {
                    MOS_LOG_ERR(AICFG_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
                }
                MOS_LOG_WARN(AICFG_LOGSTR,"DelUploadAIAlarmPVTaskNode ReqId=%d", pstEventNode->uiReqId);

                // 删除上传AI告警图片和视频的节点
                Config_DelUploadAIAlarmPVTaskNode(0, pstEventNode->uiReqId);   
            }

            // 删除消息告警上报列表节点
            MsgMng_DelEventNode(pstEventNode->uiReqId);
#endif
            lluDuration = 0;
        }
    }
    return MOS_OK;
}