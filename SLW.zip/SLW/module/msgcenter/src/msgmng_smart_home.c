#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "msgmng_smart_home.h"
#include "config_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_crypto_adapt.h"
#include "adpt_json_adapt.h"
#include "qualityprobe_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "msgmng_quality_statistics.h"
#include "p2p_avclient.h"
#include "msgmng_multimedia.h"

#define SMHOME_UPDEVINFO_INTERVAL        86400
static ST_MSGMMG_SMARTHOME_MNG g_stReportSmartHomeMng = {0};

ST_MSGMMG_SMARTHOME_MNG *MsgMng_SmartHome_GetMng()
{
    return &g_stReportSmartHomeMng;
}

/***************************************************************************************
****************************************************************************************/
//uuid为32个字节
static _INT MsgMng_SmartHome_UUID_NoCrossBar(_UC * pucUUID)
{
    _INT n;
    const _UC *c = "89ab";
    _UC *p = pucUUID;

    srand(Mos_GetTickCount());
    
    for ( n = 0; n < 16; ++n )
    {
        int b = rand()%255;
        switch( n )
        {
            case 6:
                sprintf(p, "4%x", b%15 );
            break;
            case 8:
                sprintf(p, "%c%x", c[rand()%strlen(c)], b%15 );
            break;
            default:
                sprintf(p, "%02x", b);
            break;
        }
 
        p += 2;
    }
    *p = 0;

    return MOS_OK;
}

static _VOID MsgMng_SmartHome_RecvUpLoadInfoRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    ST_MSGMMG_SMARTHOME_MNG *pstReportMng = MsgMng_SmartHome_GetMng();
    if (pstReportMng->uiBufTotalLen == 0)
    {
        pstReportMng->uiBufTotalLen = 1024;
        pstReportMng->pucRcvBuf = (_UC *)MOS_MALLOCCLR(1024);
    }
    if(pstReportMng->uiRecvLen + uiLen < pstReportMng->uiBufTotalLen)
    {
        MOS_MEMCPY(pstReportMng->pucRcvBuf + pstReportMng->uiRecvLen,pucData,uiLen);
        pstReportMng->uiRecvLen += uiLen;
    }
    return ;
}

static _VOID MsgMng_SmartHome_RecvUpLoadInfoFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMMG_SMARTHOME_MNG *pstReportMng = MsgMng_SmartHome_GetMng();
    if(pstReportMng->pucRcvBuf)
    {
        pstReportMng->pucRcvBuf[pstReportMng->uiRecvLen] = 0;
    }
    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"aucUuid:%s recv reportInfo rsp is %s",pstReportMng->aucUuid,pstReportMng->pucRcvBuf);
    _UC aucMsgString[128] = {0}; 
    MOS_SPRINTF(aucMsgString, "%s Upload SmartHome Info Successfully",MSGMNG_REGIST_INFO_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), SMART_HOME_HOST, -1, EN_REGISTINFO_RT_UPLOADINFO_SRTHOME_SUC, aucMsgString, 1);

    MOS_FREE(pstReportMng->pucRcvBuf);
    pstReportMng->uiBufTotalLen = 0;
    pstReportMng->uiRecvLen     = 0;
    pstReportMng->uiHttpHandle  = 0;

    MsgMng_SmartHome_GetMng()->ucSmartHomeStatus = EN_MSGMNG_SMARTHOME_FLAG_FINSH;

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_SMART_HOME, uiUseTime);

    return ;
}

_VOID MsgMng_SmartHome_RecvUpLoadInfoFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    ST_MSGMMG_SMARTHOME_MNG *pstReportMng = MsgMng_SmartHome_GetMng();
    MOS_FREE(pstReportMng->pucRcvBuf);
    pstReportMng->uiBufTotalLen = 0;
    pstReportMng->uiRecvLen     = 0;
    pstReportMng->uiHttpHandle  = 0;

    MsgMng_SmartHome_GetMng()->ucSmartHomeStatus = EN_MSGMNG_SMARTHOME_FLAG_ERR;

    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"aucUuid:%s recv reportInfo rsp fail",pstReportMng->aucUuid);
    _UC aucMsgString[128] = {0}; 
    MOS_SPRINTF(aucMsgString, "%s Recv SmartHome Rsp Failed",MSGMNG_REGIST_INFO_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), SMART_HOME_HOST, -1, EN_REGISTINFO_RT_RECV_SRTHOME_RSP_FAIL, aucMsgString, 1);

    // 关键接口质量统计成功率和耗时
    MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_SMART_HOME, uiUseTime);

    return ;
}

static _UC* MsgMng_SmartHome_BuildDevJson()
{
    _UC aucReportTime[32] = {0};
    _UC aucTmpMac[64] = {0};
    _LLID lluTime	  = 0;
    _INT iMacLen,i,j  = 0;
    ST_MOS_SYS_TIME stSysTime;
    ST_ZJ_NETWORK_INFO  stNetInfo;
    _UC *pucStrTmp    = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    MOS_MEMSET(&stNetInfo,0,sizeof(stNetInfo));
    if(ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetInfo);
    }
    Config_SetCamerLocalIPv6Addr(0, stNetInfo.aucIPv6Addr);
    AvClient_SetLocalIPv6Addr(stNetInfo.aucIPv6Addr);
    MsgMng_MultiMediaSetLocalIPv6Addr(stNetInfo.aucIPv6Addr);
    Mos_GetSysTime(&stSysTime);
    MOS_VSNPRINTF(aucReportTime, 32, "%04u-%02u-%02u %02u:%02u:%02u",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
    
    lluTime = (_LLID)Mos_Time() * 1000;
    MOS_MEMSET(aucTmpMac,0,64);
    iMacLen = MOS_STRLEN(stNetInfo.aucMacAddr);
    for(i = 0 ; i < iMacLen ; i++)
    {
        if(stNetInfo.aucMacAddr[i] != ':')
        {
            aucTmpMac[j++] = stNetInfo.aucMacAddr[i];
        }
    }
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"ctei",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevCTEI));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"mac",Adpt_Json_CreateString(aucTmpMac));
    if(MOS_STRLEN(stNetInfo.aucIPAddr))
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ip",Adpt_Json_CreateString(stNetInfo.aucIPAddr));
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"ip",Adpt_Json_CreateString((_UC*)""));
    }
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"parentDevMac",Adpt_Json_CreateString((_UC*)""));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"linkType",Adpt_Json_CreateStrWithNum(2));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"fmwVersion",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDevVerSion));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"date",Adpt_Json_CreateString(aucReportTime));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"timeStamp",Adpt_Json_CreateStrWithNum(lluTime));
    if(MOS_STRLEN(Config_GetSystemMng()->aucDevUID))
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"sn",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"sn",Adpt_Json_CreateString(Config_GetSystemMng()->aucDevSN));
    }
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"rptType",Adpt_Json_CreateStrWithNum(1));
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pucStrTmp;
}

static _INT MsgMng_SmartHome_UpLoadDevInf()
{
    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"is time to report to SMART_HOME");

    _INT iRet       = 0;
    _INT iTotalLen  = 0;
    _INT iStrLen    = 0;
    _US usPort      = SMART_HOME_HOST_PORT;
    _UC *pStrTmp       = MOS_NULL;
    _UC *pucDevJson    = MOS_NULL;
    _UC *pucEncode     = MOS_NULL; 
    _UC *pucAesEncBody = MOS_NULL;
    _UC aucKey[128]    = {0};
    _UC aucAddBuf[64]  = {0};
    _LLID lluTime      = 0;
    _UC auAdmonAddrPort[128] = {0};
    _UC auQualityUrl[128]    = {0}; // 关键接口质量URL
    _UC *pucBase64EncBody    = MOS_NULL;

    JSON_HANDLE hRoot = MOS_NULL;
    pucDevJson = MsgMng_SmartHome_BuildDevJson(); 
    iStrLen    = MOS_STRLEN(pucDevJson); 
    pucEncode = (_UC*)MOS_MALLOCCLR(iStrLen + 32);
    MOS_STRNCPY(pucEncode, pucDevJson,iStrLen);
    iTotalLen = MOS_HEX_NUM(iStrLen);
    MOS_MEMSET(pucEncode + iStrLen, iTotalLen - iStrLen,  iTotalLen - iStrLen);

    MOS_STRNCPY(aucKey,(_UC*)"48b7fb0cc5d58ad6",128);

    pucAesEncBody  = (_UC*)MOS_MALLOCCLR(iTotalLen + 32);
    pucBase64EncBody = (_UC*)MOS_MALLOCCLR(iTotalLen*2);
    Adpt_Aec_Ecb_Encrypt(aucKey, 128, pucEncode,pucAesEncBody);
    
    Adpt_Base64_Enc(pucAesEncBody,iTotalLen,pucBase64EncBody);
    
    lluTime = (_LLID)Mos_Time() * 1000;
    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"manufacturerId",Adpt_Json_CreateString((_UC*)"B015"));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"version",Adpt_Json_CreateString((_UC*)"1.0"));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"decryptData",Adpt_Json_CreateString(pucBase64EncBody));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"timeStamp",Adpt_Json_CreateStrWithNum(lluTime));

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    MOS_MEMSET(MsgMng_SmartHome_GetMng()->aucUuid,0,64);
    MsgMng_SmartHome_UUID_NoCrossBar(MsgMng_SmartHome_GetMng()->aucUuid);
    MOS_VSNPRINTF(aucAddBuf, 64, "reqId: %s\r\n", MsgMng_SmartHome_GetMng()->aucUuid);
    MOS_SPRINTF(auAdmonAddrPort, "%s:%d", SMART_HOME_HOST, usPort);

    // 创建关键接口质量信息节点 http://smarthome.ctdevice.ott4china.com:9010
    MOS_SPRINTF(auQualityUrl, "http://%s", auAdmonAddrPort);
    MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_SMART_HOME, auQualityUrl);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = 0;
    stHttpInfoNode.pfuncRecv       = MsgMng_SmartHome_RecvUpLoadInfoRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_SmartHome_RecvUpLoadInfoFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_SmartHome_RecvUpLoadInfoFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    stHttpInfoNode.pucExpandHeader = aucAddBuf;
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddrPort, SMART_HOME_URL, EN_HTTP_METHOD_POST, Mos_GetSessionId());
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC aucMsgString[128] = {0};
        MOS_SPRINTF(aucMsgString, "%s Parse SmartHome Addr Failed",MSGMNG_REGIST_INFO_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), SMART_HOME_HOST, -1, EN_REGISTINFO_RT_PARSE_SRTHOME_ADDR_FAIL, aucMsgString, 1);
    }

    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"report before Enc devJsonInfo %s", pucDevJson);
    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"report dev aucAddBuf %s", aucAddBuf);
    MOS_LOG_INF(MSGMNG_REGIST_INFO_STR,"report devInfo %s to SMART_HOME %s ,ret %d", pStrTmp, auAdmonAddrPort, iRet);
    MOS_FREE(pucAesEncBody);
    MOS_FREE(pucBase64EncBody);
    Adpt_Json_DePrint(pStrTmp);
    Adpt_Json_DePrint(pucDevJson);
    MOS_FREE(pucEncode);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

_INT MsgMng_SmartHome_StartUpLoadDevInf(_CTIME_T timeNow)
{
    // 无网、ap热点、未登录信令平台
    if(MsgMng_GetMng()->ucNetworkType == EN_ZJ_NETWORK_TYPE_NONET || EN_ZJ_NETWORK_TYPE_AP == MsgMng_GetMng()->ucNetworkType || MsgMng_GetCmdServer()->ucStatus != EN_MSGMNG_CMDSERVER_STATUS_PROCESS)
    {
        return MOS_OK;
    }

    if(MsgMng_SmartHome_GetMng()->ucSmartHomeStatus == EN_MSGMNG_SMARTHOME_FLAG_NOTYET)
    {
        if(MsgMng_SmartHome_UpLoadDevInf() == MOS_OK)
        {
            MsgMng_SmartHome_GetMng()->ucSmartHomeStatus = EN_MSGMNG_SMARTHOME_FLAG_DOING;
        }
        else
        {
            MsgMng_SmartHome_GetMng()->ucSmartHomeStatus = EN_MSGMNG_SMARTHOME_FLAG_ERR;
        }        
        MsgMng_SmartHome_GetMng()->cSmHomeUpTime = timeNow;
    }
    else if((MsgMng_SmartHome_GetMng()->ucSmartHomeStatus == EN_MSGMNG_SMARTHOME_FLAG_DOING || MsgMng_SmartHome_GetMng()->ucSmartHomeStatus == EN_MSGMNG_SMARTHOME_FLAG_ERR) && (_UI)(timeNow - MsgMng_SmartHome_GetMng()->cSmHomeUpTime) > 1800)
    {
        MsgMng_SmartHome_GetMng()->ucSmartHomeStatus = EN_MSGMNG_SMARTHOME_FLAG_NOTYET;
    }
    else if(MsgMng_SmartHome_GetMng()->ucSmartHomeStatus == EN_MSGMNG_SMARTHOME_FLAG_FINSH && (_UI)(timeNow - MsgMng_SmartHome_GetMng()->cSmHomeUpTime) > SMHOME_UPDEVINFO_INTERVAL)
    {
        MsgMng_SmartHome_GetMng()->ucSmartHomeStatus = EN_MSGMNG_SMARTHOME_FLAG_NOTYET;
    }
    else if (MsgMng_SmartHome_GetMng()->ucSmartHomeStatus > EN_MSGMNG_SMARTHOME_FLAG_FINSH)
    {
        MsgMng_SmartHome_GetMng()->ucSmartHomeStatus = EN_MSGMNG_SMARTHOME_FLAG_NOTYET;
    }
    return MOS_OK;
}
