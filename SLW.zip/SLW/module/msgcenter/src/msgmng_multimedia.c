#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "config_api.h"
#include "http_api.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_json_adapt.h"
#include "msgmng_multimedia.h"
#include "media_type_prv.h"
#include "media_video.h"
#include "media_audio.h"
#include "kj_timer.h"
#include "watchdog_api.h"
#include "cloudstg_api.h"
#include "record_api.h"
#include "media_playback.h"
#include "qualityprobe_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

#ifdef BUILD_IMSSDK_FALG
#include "ims_render.h"
#endif

#ifdef BUILD_ONBROADCAST_FALG
#include "AudioDeviceAPI.h"
#include "broadcast_api.h"
#endif

#include <sys/epoll.h>
#include <poll.h>


//#define MSGMNG_MULTIPATH_DEBUG_OUTFRAME//多路流媒体出帧打印开关

#define MSGMNG_MULTI_MEDIA_RECV_BUF_SIZE            (32*1024)
#define MSGMNG_MULTI_MEDIA_AUDIO_PLAY_SIZE          (640+14)
#define MSGMNG_MULTI_MEDIA_SEND_TIMEOUT             3
#define MSGMNG_MULTI_MEDIA_SEND_FAIL_FREQ           4   //send_data连续错误次数
#define MSGMNG_MULTI_MEDIA_KEPPALIVE_INTERVAL       5
#define MSGMNG_MULTI_MEDIA_HEARTBEAT_FAIL_TIME      (4*MSGMNG_MULTI_MEDIA_KEPPALIVE_INTERVAL)
#define MSGMNG_MULTI_MEDIA_NOILOGIN_FAIL_TIME       (2*MSGMNG_MULTI_MEDIA_KEPPALIVE_INTERVAL)
#define MSGMNG_MULTI_MEDIA_PLAYBACK_LIST_MIN_CNT    6       // 卡回放帧列表最小数量，小于这个值就读录像文件
#define MSGMNG_MULTI_MEDIA_PLAYBACK_VIDEO_LIST_MAX_CNT 12   // 卡回放帧视频列表最大数量，大于这个值就停止读录像文件
#define MSGMNG_MULTI_MEDIA_PLAYBACK_AUDIO_LIST_MAX_CNT 20   // 卡回放帧音频列表最大数量，大于这个值就停止读录像文件
#define MSGMNG_MULTI_MEDIA_PLAYBACK_FAST_TIMESTAMP  3000 // 卡回放快速发送时间长度-毫秒
#define MSGMNG_MULTI_MEDIA_CONNTIME_MS              (MSGMNG_MULTI_MEDIA_CONNTIME*1000) // socket连接超时时间

typedef enum media_connect_addr_ntc_err
{
    EN_MEDIA_SERVER_ADDRNTC_MAX_ERROR         = -1, // 连接达到最大数
    EN_MEDIA_SERVER_ADDRNTC_SAME_DOING_ERROR  = -2, // 已存在相同连接, 正在连接中
    EN_MEDIA_SERVER_ADDRNTC_SAME_DONE_ERROR   = -3  // 已存在相同连接，已连接完成
}EN_MEDIA_CONNECT_ADDR_NTC_ERR;

typedef enum media_connect_flag
{
    EN_MEDIA_CONNECT_FLAG_NOTCONNECT  = 0,
    EN_MEDIA_CONNECT_FLAG_CONNECTTING = 1,
    EN_MEDIA_CONNECT_FLAG_CONNECTED   = 2,
    EN_MEDIA_CONNECT_FLAG_CONECTERROR = 3
}EN_MEDIA_CONNECT_FLAG;

typedef enum media_login_status
{
    EN_MEDIA_SERVER_NOTLOGIN    = 0,
    EN_MEDIA_SERVER_LOGINING    = 1,
    EN_MEDIA_SERVER_LOGINED     = 2,
    EN_MEDIA_SERVER_LOGIN_ERROR = 3,
}EN_MEDIA_LOGIN_STATUS;

typedef enum en_VOD_CMD_TYPE
{
    VOD_CMD_PAUSE    = 0X01,
    VOD_CMD_REPLAY   = 0X02,
    VOD_CMD_KEYFRAME = 0X04,
    VOD_CMD_TEADOWN  = 0X08,
    VOD_CMD_SEEK     = 0X10
}EN_VOD_CMD_TYPE;

typedef enum en_PLAYBACK_STATUS
{
    EN_PLAYBACK_STATUS_UNKNOW= 0,
    EN_PLAYBACK_STATUS_INIT  = 1,
    EN_PLAYBACK_STATUS_START = 2,
    EN_PLAYBACK_STATUS_PAUSE = 3,
    EN_PLAYBACK_STATUS_SEEK  = 4,
}EN_PLAYBACK_STATUS;

static _VOID MsgMng_MultiMediaUpdateLiveBusyStatus(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia);
static _INT MsgMng_ProcMultiMediaStatus(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia, _CTIME_T cTimeNow, _INT iIntervalMseconds);
static _INT MsgMng_ProcMultiMediaHeartbeat(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia, _INT iIntervalMseconds);
static _VOID MsgMng_ProcMultiMediaLiveData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia);
static _VOID MsgMng_ProcMultiMediaPlayBackData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia);
static _INT MsgMng_MultiMediaThreadProc(_VPTR vpParam);
static _INT MsgMng_MultiMediaLogin(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_CTIME_T cTimeNow);
static _INT MsgMng_MultiMediaPlayBackLogin(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_CTIME_T cTimeNow);
static _INT procSendMedia(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iCamId, _INT iStreamId, _UC msgType, _UC msgId, 
                    ST_FRAME_NODE *pstNode,_INT iFrmeLen, _INT iTimeStamp, _INT trasTye);
static _INT procSendMediaPlayback(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia, _US usChannel, _UC msgType, _UC msgId, 
                    ST_FRAME_NODE *pstNode,_INT iFrmeLen, _INT iTimeStamp, _INT trasTye);
static _UI MsgMng_MultiMediaGetLocalIPv6Addr(_UC *pucLocalIPv6Addr, _UI uiLocalIPv6AddrLen);

static _UI g_uiMultiMediaMark = 0;//用于打印区分多媒体连接的标记

static _VOID MsgMng_MultiMediaGenerateMaskName(ST_MSGMNG_MULTI_MEDIA *pstMultiMedia)
{
    MOS_PARAM_NULL_NORET(pstMultiMedia);

    if (pstMultiMedia->uiType == EN_MSGMNG_MULTI_MEDIA_LIVE)
    {
        MOS_SPRINTF(pstMultiMedia->aucMaskName, "%sLive-%d", MSGMNG_MULTI_MEDIA_STR, pstMultiMedia->uiMark);
    }
    else
    {
        MOS_SPRINTF(pstMultiMedia->aucMaskName, "%sPB-%d", MSGMNG_MULTI_MEDIA_STR, pstMultiMedia->uiMark);
    }
}

static _VOID MsgMng_UploadLog(ST_MSGMNG_MULTI_MEDIA *pstMultiMedia, const _C *pcFun, _INT iRet, _UC *pucMsg)
{
    MOS_PARAM_NULL_NORET(pstMultiMedia);
    MOS_PARAM_NULL_NORET(pcFun);
    MOS_PARAM_NULL_NORET(pucMsg);

    _UC aucAddrStr[MOS_INET_ADDR_MAX_NUM] = {0};
    _UC aucTmp[256] = {0};

    if (pstMultiMedia == MOS_NULL)
    {
        return;
    }

    if (pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV4)
    {
        // Mos_InetAddrNtoa线程不安全
        Mos_InetAddrNtop(pstMultiMedia->stInetIPv4.usType, &pstMultiMedia->stInetIPv4.u.uiIp, aucAddrStr, sizeof(aucAddrStr));
        MOS_VSNPRINTF(aucTmp, sizeof(aucTmp), "%s %s [%s:%d]", pstMultiMedia->aucMaskName, pucMsg, aucAddrStr, pstMultiMedia->stInetIPv4.usPort);
        CloudStg_UploadLog(Mos_GetSessionId(), (_UC*)pcFun, 0, iRet, aucTmp, 1);
    }
    else if (pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV6)
    {
        Mos_InetAddrNtop(pstMultiMedia->stInetIPv6.usType, pstMultiMedia->stInetIPv6.u.aucIpv6, aucAddrStr, sizeof(aucAddrStr));
        MOS_VSNPRINTF(aucTmp, sizeof(aucTmp), "%s %s [%s:%d]", pstMultiMedia->aucMaskName, pucMsg, aucAddrStr, pstMultiMedia->stInetIPv6.usPort);
        CloudStg_UploadLog(Mos_GetSessionId(), (_UC*)pcFun, 0, iRet, aucTmp, 1);
    }
}
static _INT MsgMng_ProcPlayBackCmdMsg(ST_MSGMNG_MULTI_MEDIA *pstMultiMedia, _UC ucMsgType, _UC ucMsgId, _INT iSeqID,
                                      _UC *pucMsgBuff,_INT iMsgBuffLen)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    ST_MSGMNG_MULTI_MEDIA_CMD_MSG *pstCmdMsg = (ST_MSGMNG_MULTI_MEDIA_CMD_MSG*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_MULTI_MEDIA_CMD_MSG) + iMsgBuffLen);
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdMsg->stMsgHead.usMsgType = 0;
    pstCmdMsg->stMsgHead.usMsgLen  = iMsgBuffLen;
    pstCmdMsg->ucMsgType = ucMsgType;
    pstCmdMsg->ucMsgId   = ucMsgId;
    pstCmdMsg->iSeqNum   = iSeqID;
    if (iMsgBuffLen >= 0)
    {
        MOS_MEMCPY(pstCmdMsg->aucMsgBody, pucMsgBuff, iMsgBuffLen);
    }

    return MOS_OK;
}

// 创建流媒体连接
static ST_MSGMNG_MULTI_MEDIA *MsgMng_MultiMediaMallocConnect()
{
    _INT i = 0;
    ST_MSGMNG_MULTI_MEDIA *pstMultiMedia = MOS_NULL;

    pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_MULTI_MEDIA));
    Mos_MutexCreate(&(pstMultiMedia->hMutexSendB));
    Mos_MutexCreate(&(pstMultiMedia->hMutexStatus));
    pstMultiMedia->hSockBuffPool = Mos_MallocSockBuf(MSGMNG_MULTIMEDIA_SOCKBUFF_LEN);
    pstMultiMedia->uiPayloadLen = MSGMNG_MULTIMEDIA_SOCKBUFF_LEN - sizeof(ST_MOS_SOCKBUF);
    pstMultiMedia->pstRecvB = Mos_PopSockBuf(pstMultiMedia->hSockBuffPool);
    pstMultiMedia->pstSendB = Mos_PopSockBuf(pstMultiMedia->hSockBuffPool);
    pstMultiMedia->uiHeartInterval = 0;
    pstMultiMedia->bRollbackToIPv4 = MOS_FALSE;
    pstMultiMedia->isockFd         = MOS_SOCKET_INVALID;
    pstMultiMedia->iNeedIframe[0]  = MOS_FALSE;
    pstMultiMedia->iNeedIframe[1]  = MOS_FALSE;
    pstMultiMedia->uiVideoSeq[0]   = 0;
    pstMultiMedia->uiVideoSeq[1]   = 0;
    pstMultiMedia->uiAudioSeq[0]   = 0;
    pstMultiMedia->uiAudioSeq[1]   = 0;
    pstMultiMedia->iStatusCountDown= 0;
    pstMultiMedia->ucLoginFlag     = EN_MEDIA_SERVER_NOTLOGIN;

    for (i = 0; i < MAX_STREAM_NUMBER; i++)
    {
        pstMultiMedia->m_hAudioHandel[i] = MOS_NULL;
    }
    for (i = 0; i < MAX_STREAM_NUMBER; i++)
    {
        pstMultiMedia->m_hVideoHandel[i] = MOS_NULL;
    }

    // MsgMng_SetCmdPlatEncryInf(pstMultiMedia,Config_GetCoreMng()->iEncType,Config_GetCoreMng()->aucEncKey,Config_GetCoreMng()->aucEncLoad);
    //Media_GetTaskMng()->pstMultiMedia = pstMultiMedia;
    return pstMultiMedia;
}

// 释放流媒体连接
static _VOID MsgMng_MultiMediaFreeConnect(ST_MSGMNG_MULTI_MEDIA *pstMultiMedia)
{
    _INT i = 0;
    if(pstMultiMedia == MOS_NULL)
    {
        return;
    }
     
    if(pstMultiMedia->isockFd != MOS_SOCKET_INVALID)
    {
        Mos_SocketClose(pstMultiMedia->isockFd);
        pstMultiMedia->isockFd = MOS_SOCKET_INVALID;
    }
    Mos_PushSockBuf(pstMultiMedia->hSockBuffPool, pstMultiMedia->pstRecvB);
    Mos_PushSockBuf(pstMultiMedia->hSockBuffPool, pstMultiMedia->pstSendB);
    pstMultiMedia->pstRecvB = MOS_NULL;
    pstMultiMedia->pstSendB = MOS_NULL;

    Mos_DeleteSockBuf(pstMultiMedia->hSockBuffPool);
    pstMultiMedia->hSockBuffPool = MOS_NULL;
    
    if(pstMultiMedia->stEncrypInf.hCryptoCtx)
    {
        Adpt_DeleteCrypto(pstMultiMedia->stEncrypInf.hCryptoCtx);
        pstMultiMedia->stEncrypInf.hCryptoCtx = MOS_NULL;
    }
    if(pstMultiMedia->stPlatEncryInf.hCryptoCtx)
    {
        Adpt_DeleteCrypto(pstMultiMedia->stPlatEncryInf.hCryptoCtx);
        pstMultiMedia->stPlatEncryInf.hCryptoCtx = MOS_NULL;
    }

    for (i = 0; i < MAX_STREAM_NUMBER; i++)
    {
        if (pstMultiMedia->m_hAudioHandel[i] != MOS_NULL)
        {
            Media_AudioDestroyReadHandle2(pstMultiMedia->m_hAudioHandel[i]);
            pstMultiMedia->m_hAudioHandel[i] = MOS_NULL;
        }
    }
    for (i = 0; i < MAX_STREAM_NUMBER; i++)
    {
        if (pstMultiMedia->m_hVideoHandel[i] != MOS_NULL)
        {
            Media_VideoDestroyReadHandle2(pstMultiMedia->m_hVideoHandel[i]);
            pstMultiMedia->m_hVideoHandel[i] = MOS_NULL;
        }
    }
    Mos_MutexDelete(&(pstMultiMedia->hMutexSendB));

    MOS_FREE(pstMultiMedia);
}
// 加入流媒体连接到链表中
static _INT MsgMng_MultiMediaAddConnectNode(ST_MSGMNG_MULTI_MEDIA * pstMultiMedia, _UI uiType, ST_MSGMNG_MULTI_MEDIA ** ppstSameConnect)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MSGMNG_MULTIMEDIA_CONNECT_NODE *pstConnectNode = MOS_NULL;
    _BOOL bSameIpAndPort = MOS_FALSE;

    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    Mos_MutexLock(&Media_GetTaskMng()->hMutex);
    if (uiType == EN_MSGMNG_MULTI_MEDIA_LIVE)
    {
        ST_MSGMNG_MULTIMEDIA_CONNECT_NODE *pstConnectNode1 = MOS_NULL;
        ST_MSGMNG_MULTIMEDIA_CONNECT_NODE *pstConnectNode2 = MOS_NULL;
        _INT iLastConnectBusy = 0;
        _INT iBusy = 0;

        FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stConnectList, pstConnectNode, stIterator)
        {
            if (pstConnectNode->uiType != EN_MSGMNG_MULTI_MEDIA_LIVE) continue;
            if (pstConnectNode->pstMultiMedia->ucResetFlag) continue;
            
            // 判断是否存在相同IP端口的流媒体服务器 - 由于ipv4、ipv6地址属于同一服务器，只判断ipv4地址即可
            if ((pstConnectNode->pstMultiMedia->stInetIPv4.u.uiIp == pstMultiMedia->stInetIPv4.u.uiIp) &&
                (pstConnectNode->pstMultiMedia->stInetIPv4.usPort == pstMultiMedia->stInetIPv4.usPort))
            {
                bSameIpAndPort = MOS_TRUE;
            }

            if (bSameIpAndPort)
            {
                if (ppstSameConnect)
                {
                    *ppstSameConnect = pstConnectNode->pstMultiMedia;
                }

                if (pstConnectNode->pstMultiMedia->ucLoginFlag == EN_MEDIA_SERVER_LOGINED)
                {
                    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
                    return EN_MEDIA_SERVER_ADDRNTC_SAME_DONE_ERROR;
                }
                else
                {
                    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
                    return EN_MEDIA_SERVER_ADDRNTC_SAME_DOING_ERROR;
                }
            }
            
            // 查找存活时间最长的连接
            if (pstConnectNode1 == MOS_NULL || (pstConnectNode1->uiTime>pstConnectNode->uiTime))
            {
                pstConnectNode1 = pstConnectNode;
            }

            // 查找空闲的连接 - 已找到一个空闲连接的情况，不需要再继续查找
            if (iLastConnectBusy)
            {
                Mos_MutexLock(&pstConnectNode->pstMultiMedia->hMutexStatus);
                if (pstConnectNode->pstMultiMedia->ucStreamStatus[0] || 
                    pstConnectNode->pstMultiMedia->ucStreamStatus[1] ||
                    pstConnectNode->pstMultiMedia->m_bEnableSpeaker == MOS_TRUE)
                {
                    iBusy = 1;
                }
                else
                {
                    iBusy = 0;
                }
                Mos_MutexUnLock(&pstConnectNode->pstMultiMedia->hMutexStatus);
                if (iBusy)
                {
                    pstConnectNode2 = pstConnectNode;
                }
                iLastConnectBusy = iBusy;
            }
        }

        if (Media_GetTaskMng()->uiConnectLiveCnt >= MSGMNG_MULTI_MEDIA_LIVE_CONNECT_MAX_COUNT)
        {
            if (pstConnectNode2)// 优先释放空闲连接
            {
                pstConnectNode2->pstMultiMedia->ucBeOccupyFlag = 1;
                pstConnectNode2->pstMultiMedia->ucResetFlag = 1;
                MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "Mulmedia release free connect");
            }
            else if (pstConnectNode1)// 再考虑释放存活时间最长的连接
            {
                pstConnectNode1->pstMultiMedia->ucBeOccupyFlag = 1;
                pstConnectNode1->pstMultiMedia->ucResetFlag = 1;
                MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "Mulmedia release longest time connect");
            }
        }
        pstConnectNode = (ST_MSGMNG_MULTIMEDIA_CONNECT_NODE*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_MULTIMEDIA_CONNECT_NODE));
        pstConnectNode->pstMultiMedia = pstMultiMedia;
        pstConnectNode->uiType = uiType;
        pstConnectNode->uiTime = Mos_Time();

        MOS_LIST_ADDTAIL(&Media_GetTaskMng()->stConnectList, pstConnectNode);
        Media_GetTaskMng()->uiConnectLiveCnt++;

        Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
        return MOS_OK;
    }
    else if (uiType == EN_MSGMNG_MULTI_MEDIA_PLAYBACK)
    {
        if (Media_GetTaskMng()->uiConnectPlayBackCnt < MSGMNG_MULTI_MEDIA_PLAYBACK_CONNECT_MAX_COUNT)
        {
            pstConnectNode = (ST_MSGMNG_MULTIMEDIA_CONNECT_NODE*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_MULTIMEDIA_CONNECT_NODE));
            pstConnectNode->pstMultiMedia = pstMultiMedia;
            pstConnectNode->uiType = uiType;
            pstConnectNode->uiTime = Mos_Time();

            MOS_LIST_ADDTAIL(&Media_GetTaskMng()->stConnectList, pstConnectNode);
            Media_GetTaskMng()->uiConnectPlayBackCnt++;

            Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
            return MOS_OK;
        }
        else
        {
            Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
            return EN_MEDIA_SERVER_ADDRNTC_MAX_ERROR;
        }
    }
    return MOS_ERR;
}
// 删除链表节点
static _INT MsgMng_MultiMediaDelConnectNode(ST_MSGMNG_MULTI_MEDIA * pstMultiMedia)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MSGMNG_MULTIMEDIA_CONNECT_NODE *pstConnectNode = MOS_NULL;

    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    Mos_MutexLock(&Media_GetTaskMng()->hMutex);

    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stConnectList, pstConnectNode, stIterator)
    {
        if (pstConnectNode->pstMultiMedia == pstMultiMedia)
        {
            // MOS_LIST_RMVNODE(&Media_GetTaskMng()->stConnectList, pstConnectNode);
            if (pstConnectNode->uiType == EN_MSGMNG_MULTI_MEDIA_LIVE && Media_GetTaskMng()->uiConnectLiveCnt)
            {
                Media_GetTaskMng()->uiConnectLiveCnt--;
            }
            else if (pstConnectNode->uiType == EN_MSGMNG_MULTI_MEDIA_PLAYBACK && Media_GetTaskMng()->uiConnectPlayBackCnt)
            {
                Media_GetTaskMng()->uiConnectPlayBackCnt--;
            }
            Mos_ListLoopRmv(&Media_GetTaskMng()->stConnectList, &stIterator);
            MOS_FREE(pstConnectNode);
            MOS_PRINTF("%s uiConnectLiveCnt=%d uiConnectPlayBackCnt=%d\n", 
                        __FUNCTION__, Media_GetTaskMng()->uiConnectLiveCnt, Media_GetTaskMng()->uiConnectPlayBackCnt);
            break;
        }
    }

    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
    return MOS_OK;
}
// 更新流媒体直播的繁忙状态
static _VOID MsgMng_MultiMediaUpdateLiveBusyStatus(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
#if 0
    _INT iStreamId   = 0;
    _INT iBusyStatus = 0;

    if (pstMultiMedia->uiType != EN_MSGMNG_MULTI_MEDIA_LIVE)
    {
        return;
    }

    for (iStreamId = 0; iStreamId < MAX_STREAM_NUMBER; iStreamId++)
    {
        if (pstMultiMedia->iLastVideoUsedFlag[iStreamId])
        {
            iBusyStatus = 1;
            break;
        }
    }
    if (iBusyStatus || pstMultiMedia->m_bEnableSpeaker)
    {
        iBusyStatus = 1;
    }

    // MOS_PRINTF("%s %d\n", __FUNCTION__, iBusyStatus);
    Config_AppSLeepMonotorUpdateStatus(pstMultiMedia->uiSleepMonitorId, iBusyStatus);
#endif
}
// 更新流媒体卡回放的繁忙状态
static _VOID MsgMng_MultiMediaUpdatePlayBackBusyStatus(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
#if 0
    if (pstMultiMedia->uiType != EN_MSGMNG_MULTI_MEDIA_PLAYBACK)
    {
        return;
    }

    Config_AppSLeepMonotorUpdateStatus(pstMultiMedia->uiSleepMonitorId, pstMultiMedia->ucPBPlayStatus==EN_PLAYBACK_STATUS_START);
#endif
}

static _VOID MsgMng_OutFrameTimeBegin(ST_MSGMNG_MULTI_MEDIA * pstMultiMedia, _UC * pucFlag)
{
#ifdef MSGMNG_MULTIPATH_DEBUG_OUTFRAME
    kj_timer_init(&pstMultiMedia->stOutFrameTimer);
    getDiffTimems(&pstMultiMedia->stOutFrameTimer, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);

    MOS_STRCPY(pstMultiMedia->aucOutFrameFlag, pucFlag);
    pstMultiMedia->ucOutFramePrintfIF = 1;
#endif
}

static _VOID MsgMng_OutFrameTimeUpdate(ST_MSGMNG_MULTI_MEDIA * pstMultiMedia, _UC * pucSubFlag)
{
#ifdef MSGMNG_MULTIPATH_DEBUG_OUTFRAME
    MOS_PRINTF("\n[%s] [%s] %dms\n\n", pstMultiMedia->aucOutFrameFlag, pucSubFlag, 
            getDiffTimems(&pstMultiMedia->stOutFrameTimer, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10));
#endif
}

// 更新直播连接应答信令的登录信息
static _VOID MsgMng_UpdateliveConnectLoginInfo(ST_MSGMNG_MULTI_MEDIA * pstMultiMedia, _UC *pucPeerId,_UI uiSeqId)
{
    MOS_PARAM_NULL_NORET(pstMultiMedia);
    MOS_PARAM_NULL_NORET(pucPeerId);

    Mos_MutexLock(&Media_GetTaskMng()->hMutex);
    
    if (pstMultiMedia->ucLoginFlag != EN_MEDIA_SERVER_LOGINED)
    {
        MOS_STRCPY(pstMultiMedia->stLoginInfo.pucPeerId, pucPeerId);
        pstMultiMedia->stLoginInfo.uiSeqId = uiSeqId;
    }

    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);

    return;
}
/************************************************************************************
媒体服务地址通知
*************************************************************************************/
// 平台向设备发送流媒体服务分配通知 2212
_INT MsgMng_RecvMultiMediaAddrNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PRINTF("A streaming media service allocation notification to the device %s\n", __FUNCTION__);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT iRet           = 0;
    _INT iEncType       = 0;
    _UC *pucEncKey      = MOS_NULL;
    _UC *pucEncLv       = MOS_NULL;
    _UC *pucMediaIP     = MOS_NULL;
    _UC *pucMediaIPv6   = MOS_NULL;
    _UC *pucMediaPort   = MOS_NULL;
    _UC *pucResourceID  = MOS_NULL;
    ST_MOS_INET_IPARRAY stIpArrayInfo = {0};
    ST_MOS_INET_IP *pstIpInfo         = MOS_NULL;
    _UC aucIpBuff[256]                = {0};

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        return MOS_OK;
    } 
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncType"),&iEncType);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncKey"),&pucEncKey);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncLoad"),&pucEncLv);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"MediaIP"),&pucMediaIP);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"MediaIPv6"),&pucMediaIPv6);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"MediaPort"),&pucMediaPort);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"ResourceID"),&pucResourceID);
    ST_MSGMNG_MULTI_MEDIA *pstMultiMedia  = MsgMng_MultiMediaMallocConnect();
    ST_MSGMNG_MULTI_MEDIA *pstSameConnect = 0; 

    if (MOS_STRCMP(pucPeerId, MSGMNG_CMD_SERVER_ID) == 0)
    {
        // MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "media server: iEncType=%d pucEncKey=%s pucEncLv=%s",
        //                                         iEncType,pucEncKey,pucEncLv);
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "media server: pucMediaIP=%s MediaIPv6=%s pucMediaPort=%s",
                                                pucMediaIP,pucMediaIPv6,pucMediaPort);
        MsgMng_SetMultiMediaLinkEncrypPlatInf(pstMultiMedia,iEncType,pucEncKey,pucEncLv);

        // FIXME: 随机生成type、key、iv, 并保存
        _UC iEncType1      = 0x31;
        _UC pucEncKey1[17] = {0};
        _UC pucEncLv1[17]  = {0};
        Adapt_GenerateString(pucEncKey1, sizeof(pucEncKey1));
        Adapt_GenerateString(pucEncLv1, sizeof(pucEncLv1));

        MsgMng_SetMultiMediaLinkEncrypInf(pstMultiMedia,iEncType1,pucEncKey1,pucEncLv1);
    }
    else
    {
        // Http_SetP2PLinkEncryKeyInf(pucPeerId,iEncType,pucEncKey,pucEncLv);
    }
    
    // 保存ipv4地址
    if (MOS_STRLEN(pucMediaIP) > 0)
    {
        Mos_InetAddrPton(EN_CINET_TYPE_IPV4, pucMediaIP, pstMultiMedia->stInetIPv4.u.aucIp);
        pstMultiMedia->stInetIPv4.usType = EN_CINET_TYPE_IPV4;
        pstMultiMedia->stInetIPv4.usPort = MOS_ATOI((_C*)pucMediaPort);
        //MOS_PRINTF("MultiMedia EN_CINET_TYPE_IPV4: %s\n", pucMediaIP);
    }
    // 保存ipv6地址
    if (MOS_STRLEN(pucMediaIPv6) > 0)
    {
        Mos_InetAddrPton(EN_CINET_TYPE_IPV6, pucMediaIPv6, pstMultiMedia->stInetIPv6.u.aucIpv6);
        pstMultiMedia->stInetIPv6.usType = EN_CINET_TYPE_IPV6;
        pstMultiMedia->stInetIPv6.usPort = MOS_ATOI((_C*)pucMediaPort);
        //MOS_PRINTF("MultiMedia EN_CINET_TYPE_IPV6: %s\n", pucMediaIPv6);
    }
    else
    {
        // ipv6地址为空，不尝试连接ipv6，直接使用ipv4连接
        pstMultiMedia->bRollbackToIPv4 = MOS_TRUE;
        MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "IPv6 addr is emtpy, rollback to ipv4");
    }

    // 保存资源ID
    MOS_STRCPY(pstMultiMedia->pucResourceID, pucResourceID);
    
    pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_STARTCONN;
    pstMultiMedia->uiType   = EN_MSGMNG_MULTI_MEDIA_LIVE;

    // 保存状态值
    MOS_STRCPY(pstMultiMedia->stLoginInfo.pucPeerId, pucPeerId);
    pstMultiMedia->stLoginInfo.uiSeqId  = uiSeqId;
    pstMultiMedia->uiTheardSleepMescond = 10;

    MOS_STRCPY(pstMultiMedia->aucDevUID, Config_GetSystemMng()->aucDevUID);
    
    pstMultiMedia->uiMark = ++g_uiMultiMediaMark;
    MsgMng_MultiMediaGenerateMaskName(pstMultiMedia);

    MsgMng_OutFrameTimeBegin(pstMultiMedia, (_UC*)"OutFrame First");
    iRet = MsgMng_MultiMediaAddConnectNode(pstMultiMedia, EN_MSGMNG_MULTI_MEDIA_LIVE, &pstSameConnect);
    if (iRet == MOS_OK)
    {
        MOS_PRINTF("MsgMng_MultiMediaAddConnectNode uiConnectLiveCnt=%d\n", Media_GetTaskMng()->uiConnectLiveCnt);
    }
    else
    {
        if (iRet == EN_MEDIA_SERVER_ADDRNTC_MAX_ERROR)
        {
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "Mulmedia connect max count");    
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_NTC_FAIL, (_UC*)"live connect max count");
        }
        else if (iRet == EN_MEDIA_SERVER_ADDRNTC_SAME_DOING_ERROR)
        {
            MsgMng_UpdateliveConnectLoginInfo(pstSameConnect, pucPeerId, uiSeqId);
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "Mulmedia connecting live server same ip nad port");    
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_NTC_FAIL, (_UC*)"connecting live server same ip nad port");
        }
        else if (iRet == EN_MEDIA_SERVER_ADDRNTC_SAME_DONE_ERROR)
        {
            // 已存在相同IP端口的流媒体服务器，应该直接回复成功给信令服务器
            _UC * pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId, EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_DEV_ADDR_NTC_RSP,0);
            MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_DEV_ADDR_NTC_RSP,
                pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
            Qp_CountIF_Post(COUNT_TYPE_VOD, COUNT_VALUE_SUCCESS, COUNT_VALUE_SUCCESS);
            MOS_FREE(pStrTmp);
                        
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "Mulmedia connected live server same ip nad port");    
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_NTC_FAIL, (_UC*)"connected live server same ip nad port");            
        }
        MsgMng_MultiMediaFreeConnect(pstMultiMedia);
        return MOS_ERR;
    }

    if(MOS_ERR == Mos_ThreadCreate((_UC *)pstMultiMedia->aucMaskName, EN_THREAD_PRIORITY_NORMAL, MOS_THREAD_STACK_NORMAL_SIZE,
        MsgMng_MultiMediaThreadProc, pstMultiMedia, MOS_NULL, &pstMultiMedia->hMgrThread))
    {
        MsgMng_MultiMediaFreeConnect(pstMultiMedia);
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "live task create pthread failed\n");
        MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_NTC_FAIL, (_UC*)"live task create pthread failed");
        return MOS_ERR;
    }
    return MOS_OK;
}

// 流媒体平台向设备发送暂停媒体推流请求 221C
_INT MsgMng_RecvMultiMediaPauseNtc(_UC *pucPeerId,_UI uiOgctId,_VPTR hRoot)
{
    MOS_PRINTF("Pause the media push stream request\n");
    MOS_PARAM_NULL_RETERR(pucPeerId);

    MOS_PARAM_NULL_RETERR(hRoot);

    return MOS_OK;
}

// 流媒体平台向设备发送回复媒体推流请求 221E
_INT MsgMng_RecvMultiMediaResumeNtc(_UC *pucPeerId,_UI uiOgctId,_VPTR hRoot)
{
    MOS_PRINTF("Resume the media push request\n");
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hRoot);
    return MOS_OK;
}

// 流媒体服务向设备/APP更新密钥指令 2222
_INT MsgMng_RecvMultiMediaNewPlatKeyNtc(_UC *pucPeerId,_UI uiOgctId,_VPTR hRoot)
{
    MOS_PRINTF("The streaming service updates the key instruction to the device\n");
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hRoot);
    return MOS_OK;
}

// 流媒体服务地址清除 2228
_INT MsgMng_RecvMultiMediaAddrCleanNtc(_UC *pucPeerId,_UI uiOgctId,_VPTR hRoot)
{
    MOS_PRINTF("The IP address of the streaming media service is cleared\n");
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hRoot);

   return MOS_OK;
}

// 流媒体服务设置信令密钥
_INT MsgMng_SetMultiMediaLinkEncrypPlatInf(ST_MSGMNG_MULTI_MEDIA *pstMultimedia,_INT iEncType,_UC *paucEncKey, _UC *paucEncLv)
{ 
    MOS_PARAM_NULL_RETERR(pstMultimedia);
    MOS_PARAM_NULL_RETERR(paucEncKey);
    MOS_PARAM_NULL_RETERR(paucEncLv);

    if(pstMultimedia->stPlatEncryInf.hCryptoCtx)
    {
        Adpt_DeleteCrypto(pstMultimedia->stPlatEncryInf.hCryptoCtx);
        pstMultimedia->stPlatEncryInf.hCryptoCtx = MOS_NULL;
    }
    if(iEncType == EN_OGCT_ENCRYPT_LEVEL_LOW)
    {
        pstMultimedia->stPlatEncryInf.hCryptoCtx = Adpt_CreateCrypto(paucEncKey,MOS_STRLEN(paucEncKey),EN_CRYPTO_BLOWFISH_TYPE);
    }
    pstMultimedia->stPlatEncryInf.iEncType = iEncType;
    
    MOS_MEMSET(pstMultimedia->stPlatEncryInf.aucEncKey, 0x00, sizeof(pstMultimedia->stPlatEncryInf.aucEncKey));
    MOS_MEMSET(pstMultimedia->stPlatEncryInf.aucEncLv, 0x00, sizeof(pstMultimedia->stPlatEncryInf.aucEncLv));
    MOS_STRNCPY(pstMultimedia->stPlatEncryInf.aucEncKey, paucEncKey, sizeof(pstMultimedia->stPlatEncryInf.aucEncKey));
    MOS_STRNCPY(pstMultimedia->stPlatEncryInf.aucEncLv, paucEncLv, sizeof(pstMultimedia->stPlatEncryInf.aucEncLv));
    return MOS_OK;
}

// 流媒体服务设置视频加密密钥
_INT MsgMng_SetMultiMediaLinkEncrypInf(ST_MSGMNG_MULTI_MEDIA *pstMultimedia,_INT iEncType,_UC *paucEncKey, _UC *paucEncLv)
{ 
    MOS_PARAM_NULL_RETERR(pstMultimedia);
    MOS_PARAM_NULL_RETERR(paucEncKey);
    MOS_PARAM_NULL_RETERR(paucEncLv);

    if(pstMultimedia->stEncrypInf.hCryptoCtx)
    {
        Adpt_DeleteCrypto(pstMultimedia->stEncrypInf.hCryptoCtx);
        pstMultimedia->stEncrypInf.hCryptoCtx = MOS_NULL;
    }
    if(iEncType == EN_OGCT_ENCRYPT_LEVEL_LOW)
    {
        pstMultimedia->stEncrypInf.hCryptoCtx = Adpt_CreateCrypto(paucEncKey,MOS_STRLEN(paucEncKey),EN_CRYPTO_BLOWFISH_TYPE);
    }
    pstMultimedia->stEncrypInf.iEncType = iEncType;
    MOS_MEMSET(pstMultimedia->stEncrypInf.aucEncKey, 0, sizeof(pstMultimedia->stEncrypInf.aucEncKey));
    MOS_MEMSET(pstMultimedia->stEncrypInf.aucEncLv, 0, sizeof(pstMultimedia->stEncrypInf.aucEncLv));
    MOS_STRNCPY(pstMultimedia->stEncrypInf.aucEncKey, paucEncKey, sizeof(pstMultimedia->stEncrypInf.aucEncKey));
    MOS_STRNCPY(pstMultimedia->stEncrypInf.aucEncLv, paucEncLv, sizeof(pstMultimedia->stEncrypInf.aucEncLv));
    MOS_PRINTF_DEBUG("msgMng recive set encrypt:%d\n",  pstMultimedia->stEncrypInf.iEncType);
    return MOS_OK;
}

static _VOID MsgMng_CloseSocketAndDestoryHandle(ST_MSGMNG_MULTI_MEDIA *pstMultiMedia,_INT iIsCloseSocket)
{
    MOS_PARAM_NULL_NORET(pstMultiMedia);
    
    _INT i = 0;
    ST_PLAYBACK_FRAME_NODE * pstFrameTmp  = MOS_NULL;
    ST_PLAYBACK_FRAME_NODE * pstFrameNote = MOS_NULL;

    if (iIsCloseSocket == 1)
    {
        if (pstMultiMedia->isockFd != MOS_SOCKET_INVALID)
        {
            Mos_SocketClose(pstMultiMedia->isockFd);
            pstMultiMedia->isockFd = MOS_SOCKET_INVALID;
            MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "Socket stop mark=%s", pstMultiMedia->aucMaskName);
        }
    }

    for (i = 0; i < MAX_STREAM_NUMBER; i++)
    {
        if (pstMultiMedia->m_hAudioHandel[i] != MOS_NULL)
        {
            Media_AudioDestroyReadHandle2(pstMultiMedia->m_hAudioHandel[i]);
            pstMultiMedia->m_hAudioHandel[i] = MOS_NULL;
            MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "Audio stop mark=%s", pstMultiMedia->aucMaskName);
        }
    }

    for (i = 0; i < MAX_STREAM_NUMBER; i++)
    {
        if (pstMultiMedia->m_hVideoHandel[i] != MOS_NULL)
        {
            Media_VideoDestroyReadHandle2(pstMultiMedia->m_hVideoHandel[i]);
            pstMultiMedia->m_hVideoHandel[i]     = MOS_NULL;
            pstMultiMedia->iLastVideoUsedFlag[i] = 0;
            MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "Video stop mark=%s", pstMultiMedia->aucMaskName);
        }
    }
    // 释放卡回放录像句柄
    if (pstMultiMedia->pstPBRdFileFD)
    {
        RdStg_ClosePlayBackFile(pstMultiMedia->pstPBRdFileFD);
        pstMultiMedia->pstPBRdFileFD = MOS_NULL;
    }

    // 清空卡回放音视频数据列表节点
    pstFrameNote = pstMultiMedia->pstPBVFrameHead;
    while (pstFrameNote != MOS_NULL)
    {
        pstFrameTmp = pstFrameNote->pstnext;
        MOS_FREE(pstFrameNote->stNote.ptDatabuff);
        MOS_FREE(pstFrameNote);
        pstFrameNote = pstFrameTmp;
    }
    pstMultiMedia->pstPBVFrameHead = MOS_NULL;

    pstFrameNote = pstMultiMedia->pstPBAFrameHead;
    while (pstFrameNote != MOS_NULL)
    {
        pstFrameTmp = pstFrameNote->pstnext;
        MOS_FREE(pstFrameNote->stNote.ptDatabuff);
        MOS_FREE(pstFrameNote);
        pstFrameNote = pstFrameTmp;
    }
    pstMultiMedia->pstPBAFrameHead = MOS_NULL;   

    // 更新繁忙状态
    if (pstMultiMedia->uiType == EN_MSGMNG_MULTI_MEDIA_LIVE)
    {
        MsgMng_MultiMediaUpdateLiveBusyStatus(pstMultiMedia);
    }
    else
    {
        MsgMng_MultiMediaUpdatePlayBackBusyStatus(pstMultiMedia);
    }
    return;
}

// 连接流媒体服务器 异步处理
static _INT MsgMng_ConnectMultiMediaIPv4(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_CTIME_T cTimeNow)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    _INT  iRet;
    _BOOL bConnect;
    pstMultiMedia->uiConnectType = EN_MSGMNG_CONNECT_IPV4;
    pstMultiMedia->ullTimeReq = Mos_GetLLTickCount();

    do
    {
        pstMultiMedia->isockFd  = Mos_SocketOpen(pstMultiMedia->stInetIPv4.usType,EN_CINET_PRTL_TCP,MOS_FALSE,MOS_TRUE);
        if(pstMultiMedia->isockFd == MOS_SOCKET_INVALID)
        {
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "IPv4 Open Socket Error.");
            break;
        }
        // iRet = Mos_SocketSetSendBuf(pstMultiMedia->isockFd , 50000);
        // if (iRet != MOS_OK)
        // {
        //     break;
        // }
        iRet = Mos_SocketSetRecvBuf(pstMultiMedia->isockFd, MSGMNG_MULTI_MEDIA_RECV_BUF_SIZE);
        if (iRet != MOS_OK)
        {
            break;
        }
        iRet = Mos_SocketSetSendTimeOut(pstMultiMedia->isockFd, 3);
        if (iRet != MOS_OK)
        {
            break;
        }
        if(Mos_SocketConnect(pstMultiMedia->isockFd, &pstMultiMedia->stInetIPv4, &bConnect) != MOS_OK)
        { 
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "IPv4 Connect Server Error");
            break;
        }
        
        if(bConnect == MOS_TRUE)
        {
            pstMultiMedia->uiConnectFlag = EN_MEDIA_CONNECT_FLAG_CONNECTED;
        }
        else
        {
            pstMultiMedia->uiConnectFlag = EN_MEDIA_CONNECT_FLAG_CONNECTTING;
        }

        return MOS_OK;
    }while(0);

    MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia,1);
    pstMultiMedia->uiConnectFlag = EN_MEDIA_CONNECT_FLAG_NOTCONNECT;
    return MOS_ERR;
}
// 连接流媒体服务器 异步处理
static _INT MsgMng_ConnectMultiMediaIPv6(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_CTIME_T cTimeNow)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    _INT  iRet;
    _BOOL bConnect;
    pstMultiMedia->uiConnectType = EN_MSGMNG_CONNECT_IPV6;
    pstMultiMedia->ullTimeReq = Mos_GetLLTickCount();
    do
    {
        pstMultiMedia->isockFd  = Mos_SocketOpen(pstMultiMedia->stInetIPv6.usType,EN_CINET_PRTL_TCP,MOS_FALSE,MOS_TRUE);
        if(pstMultiMedia->isockFd == MOS_SOCKET_INVALID)
        {
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "IPv6 Open Socket Error.");
            break;
        }
        iRet = Mos_SocketSetRecvBuf(pstMultiMedia->isockFd, MSGMNG_MULTI_MEDIA_RECV_BUF_SIZE);
        if (iRet != MOS_OK)
        {
            break;
        }
        iRet = Mos_SocketSetSendTimeOut(pstMultiMedia->isockFd, 3);
        if (iRet != MOS_OK)
        {
            break;
        }
        if(Mos_SocketConnect(pstMultiMedia->isockFd, &pstMultiMedia->stInetIPv6, &bConnect) != MOS_OK)
        { 
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "IPv6 Connect Server Error");
            break;
        }

        if(bConnect == MOS_TRUE)
        {
            pstMultiMedia->uiConnectFlag = EN_MEDIA_CONNECT_FLAG_CONNECTED;
        }
        else
        {
            pstMultiMedia->uiConnectFlag = EN_MEDIA_CONNECT_FLAG_CONNECTTING;
        }

        return MOS_OK;
        
    } while (0);

    MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia,1);
    pstMultiMedia->uiConnectFlag = EN_MEDIA_CONNECT_FLAG_NOTCONNECT;
    return MOS_ERR;
}

// ipv6连接失败，回落到ipv4连接
static _INT MsgMng_IPv6RollbackToIPv4(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    if ((pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV6) && (pstMultiMedia->ucStatus < EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINED))
    {
        pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_STARTCONN;
        pstMultiMedia->bRollbackToIPv4 = MOS_TRUE;
        if (pstMultiMedia->isockFd != MOS_SOCKET_INVALID)
        {
            Mos_SocketClose(pstMultiMedia->isockFd);
            pstMultiMedia->isockFd = MOS_SOCKET_INVALID;
            pstMultiMedia->stPollFd.fd = MOS_SOCKET_INVALID;
        }
        MOS_PRINTF("media connect/login ipv6 failed, rollback ipv4\n");
        // 不需要单独打印ipv6失败
        // MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"media login failed ipv6 time: %llu", Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq);
        return MOS_OK;
    }
    return MOS_ERR;
}
// 打印登录前的失败信息
// 前提：ipv6+ipv4的登录流程，以ipv4登录失败结束
static _INT MsgMng_PrintLoginFailed(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    if ((pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV4) && (pstMultiMedia->ucStatus < EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINED))
    {
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"media login failed time: %llu", Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq);
        return MOS_OK;
    }
    return MOS_ERR;
}

// 流媒体线程
static _INT MsgMng_MultiMediaThreadProc(_VPTR vpParam)
{
    _INT i       = 0;
    _INT iResult = 0;

    _CTIME_T cTimeNow       = Mos_Time();
    _INT iStatusMseconds    = 0;
    _INT ikeepAliveMseconds = 0;
    
    kj_timer_t  tStatusTimer;
    kj_timer_t  tKeepAliveTimer;
    kj_timer_t  tFeedDogTimeOut;
    
    ST_MSGMNG_MULTI_MEDIA *pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA *)vpParam;

    _HSWDWRITE hSwdFeedDog = Swd_AppThreadRegist(pstMultiMedia->aucMaskName, FEED_DOG_MAX_TIMESEC);

    kj_timer_init(&tStatusTimer);
    getDiffTimems(&tStatusTimer, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);

    kj_timer_init(&tKeepAliveTimer);
    getDiffTimems(&tKeepAliveTimer, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);

    kj_timer_init(&tFeedDogTimeOut);
    getDiffTimems(&tFeedDogTimeOut, 1, ENUM_SECONDS_TYPE_SECONDS, 60*10);

    pstMultiMedia->uiSleepMonitorId = Config_AppSLeepMonotorRegist(pstMultiMedia->aucMaskName);

    pstMultiMedia->stPollFd.fd = MOS_SOCKET_INVALID;
    pstMultiMedia->ucRunFlag = 1;

    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"%s Start %s ", __FUNCTION__, pstMultiMedia->aucMaskName);

    while (pstMultiMedia->ucRunFlag && Media_GetTaskMng()->ucRunFlag)
    {
        if (pstMultiMedia->stPollFd.fd != MOS_SOCKET_INVALID)
        {
            if (pstMultiMedia->uiConnectFlag == EN_MEDIA_CONNECT_FLAG_CONNECTTING)
            {
                pstMultiMedia->stPollFd.events = POLLOUT;    // connecting 监听可写事件（socket连接中&接收到可读信号 -> socket已连接）
            }
            else
            {
                pstMultiMedia->stPollFd.events = POLLIN;    // 监听可读事件
            }
            
            iResult = poll(&(pstMultiMedia->stPollFd), 1, pstMultiMedia->uiTheardSleepMescond);
        }
        else
        {
            iResult = 0;
            Mos_Sleep(pstMultiMedia->uiTheardSleepMescond);
        }

        cTimeNow = Mos_Time();
        // 流媒体状态逻辑
        iStatusMseconds = getDiffTimems(&tStatusTimer, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
        if (MOS_ERR == MsgMng_ProcMultiMediaStatus(pstMultiMedia, cTimeNow, iStatusMseconds))
        {
            break;
        }

        if (pstMultiMedia->m_bEnableSpeaker)
        {
            if ((Mos_GetLLTickCount() - pstMultiMedia->ullReiveAudioTime) >= MULTI_MEDIA_AUDIODATA_TIMEOUT)
            {
                MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "long time(%ds) not recv audiodata, need to close MultiMedia speaker!!", (MULTI_MEDIA_AUDIODATA_TIMEOUT/1000));   
                MsgMng_MultiMediaCloseAudioReverse(pstMultiMedia, 0, 1);
            }
        }        
        // 检测无网/ap热点/关闭摄像头
        if(MsgMng_GetMng()->ucNetworkType == EN_ZJ_NETWORK_TYPE_NONET ||
           MsgMng_GetMng()->ucNetworkType == EN_ZJ_NETWORK_TYPE_AP ||
           Config_GetCamaraMng()->uiCamOpenFlag == 0)
        {
            // 关闭当前连接
            pstMultiMedia->ucResetFlag = 1;
            Mos_Sleep(100);
            continue;
        }

        // 软看门狗喂狗
        if (getDiffTimems(&tFeedDogTimeOut, 0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
        {            
            if (Mos_FileIsExist("/tmp/test_no_media_watchdog") == MOS_FALSE)
            {
                Swd_AppThreadFeedDog(hSwdFeedDog);
            }
            getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }

        // poll失败
        if (iResult < 0)
        {
            // 未登录状态下，ipv6连接失败，尝试连接ipv4
            if (MsgMng_IPv6RollbackToIPv4(pstMultiMedia) == MOS_ERR) // poll失败
            {
                // 关闭当前连接
                pstMultiMedia->ucResetFlag = 1;
                MsgMng_PrintLoginFailed(pstMultiMedia);
            }
            
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "Error in media poll" );
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_POLL_ERROR, (_UC*)"poll error");
        }
        // 无数据接收
        else if (iResult == 0)
        {
            // 信令发送
            MsgMng_SendMultiMediaBuffer(pstMultiMedia);      

            // 心跳包发送与心跳超时检测
            ikeepAliveMseconds = getDiffTimems(&tKeepAliveTimer, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
            if (MOS_OK == MsgMng_ProcMultiMediaHeartbeat(pstMultiMedia, ikeepAliveMseconds))
            {
                getDiffTimems(&tKeepAliveTimer, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
            }
            
            if (pstMultiMedia->uiType == EN_MSGMNG_MULTI_MEDIA_LIVE)
            {
                // 直播音视频数据发送
                MsgMng_ProcMultiMediaLiveData(pstMultiMedia);
            }
            else
            {
                // 卡回放音视频数据发送
                MsgMng_ProcMultiMediaPlayBackData(pstMultiMedia);
            }
        }
        // 有数据接收
        else if (iResult > 0)
        {
            if ((pstMultiMedia->stPollFd.revents & POLLOUT) != 0)
            {
                if (pstMultiMedia->uiConnectFlag == EN_MEDIA_CONNECT_FLAG_CONNECTTING)
                {
                    // 监听到可写信号
                    // 判断连接是否正常
                    if(Mos_SockCheckBoolConnect(pstMultiMedia->isockFd) == MOS_TRUE)
                    {
                        pstMultiMedia->uiConnectFlag = EN_MEDIA_CONNECT_FLAG_CONNECTED;
                    }
                    else
                    {
                        pstMultiMedia->uiConnectFlag = EN_MEDIA_CONNECT_FLAG_CONECTERROR;
                        // 未登录状态下，ipv6连接失败，尝试连接ipv4
                        if (MsgMng_IPv6RollbackToIPv4(pstMultiMedia) == MOS_ERR) // 异步连接失败
                        {
                            pstMultiMedia->ucResetFlag = 1;
                            MsgMng_PrintLoginFailed(pstMultiMedia);
                        }
                    }
                }
                else
                {
                    // 逻辑错误,等待超时
                    MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "poll revents<%d> and connectflag<%u> logic err mark=%s\n", 
                                pstMultiMedia->stPollFd.revents, pstMultiMedia->uiConnectFlag, pstMultiMedia->aucMaskName);
                }
            }
            else if ((pstMultiMedia->stPollFd.revents & POLLIN) != 0)
            {
                MsgMng_ProcMultiMediaRecv(pstMultiMedia);
                MsgMng_SendMultiMediaBuffer(pstMultiMedia);
                if(pstMultiMedia->ucStatus == EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR)
                {
                    pstMultiMedia->ucResetFlag = 1;
                    MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "MOS_SOCKET_INVALID close multi media server mark=%s", 
                                pstMultiMedia->aucMaskName);
                }
            }
            else if (pstMultiMedia->stPollFd.revents != 0)
            {
                // 未登录状态下，ipv6连接失败，尝试连接ipv4
                if (MsgMng_IPv6RollbackToIPv4(pstMultiMedia) == MOS_ERR) // poll revents失败
                {
                    pstMultiMedia->ucResetFlag = 1;
                    MsgMng_PrintLoginFailed(pstMultiMedia);
                }
                MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "result  > 0000000000000000000000000000 mark=%s", 
                            pstMultiMedia->aucMaskName);
                MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_POLL_ERROR, (_UC*)"poll revent error");
            }
        }
    }

    _VOID * hMgrThread   = pstMultiMedia->hMgrThread;
    _UI uiSleepMonitorId = pstMultiMedia->uiSleepMonitorId;
#ifdef SEND_DATA_DEBUG
    if (pstMultiMedia->hFile)
    {
        fclose(pstMultiMedia->hFile);
        pstMultiMedia->hFile = NULL;
    }
#endif
    // 释放网络连接&直播媒体句柄&卡回放句柄数据
    MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia, 1);
    // 释放直播&卡回放缓存
    MsgMng_MultiMediaFreeConnect(pstMultiMedia);
    // 删除直播&卡回放 连接列表节点
    MsgMng_MultiMediaDelConnectNode(pstMultiMedia);
    
    Swd_AppThreadUnRegist(hSwdFeedDog);
    Config_AppSLeepMonotorUnRegist(uiSleepMonitorId);

    // 删除线程
    if(MOS_OK != Mos_ThreadDelete(hMgrThread))
    {
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"Mos_ThreadDelete failed !!");
        return MOS_ERR;
    }

    MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR,"%s Exit", __FUNCTION__);

    return MOS_OK;
}
// 回复信令结果
_INT MsgMng_SendMultiMediaBuffer(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    _UI uiDataLen;
    _INT iRetLen = 0;
    _BOOL bBlocked = MOS_FALSE;
    ST_MOS_SOCKBUF* pstTmp1 = MOS_NULL;

    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    if(pstMultiMedia->isockFd == MOS_SOCKET_INVALID || pstMultiMedia->uiConnectFlag != EN_MEDIA_CONNECT_FLAG_CONNECTED)
    {
        return MOS_OK;
    }
    Mos_MutexLock(&pstMultiMedia->hMutexSendB);
    uiDataLen = MOS_BLEN(pstMultiMedia->pstSendB);
    if(uiDataLen == 0)
    {
        Mos_MutexUnLock(&pstMultiMedia->hMutexSendB);
        return MOS_OK;
    }
    do 
    {
        // BUF_PRINTF_EX("MOS_BPTR(pstMultiMedia->pstSendB)", MOS_BPTR(pstMultiMedia->pstSendB), uiDataLen);
        // 发送回复的信令结果 或者登录信息
        iRetLen = Mos_SocketSend(pstMultiMedia->isockFd, MOS_BPTR(pstMultiMedia->pstSendB), uiDataLen, &bBlocked);
        if (iRetLen <= 0)
        {
            if (!bBlocked)
            {
                _UC aucBuff[128] = {0};
                MOS_VSNPRINTF(aucBuff, sizeof(aucBuff), "socket send error %d",errno);
                MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_SEND_ERROR, (_UC*)aucBuff);
                // 未登录状态下，ipv6连接失败，尝试连接ipv4
                if (MsgMng_IPv6RollbackToIPv4(pstMultiMedia) == MOS_ERR) // socket 发送失败
                {
                    MsgMng_PrintLoginFailed(pstMultiMedia);
                    MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia,1);
                    pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR;
                }
            }
            break;
        }
        else if (iRetLen == MOS_BLEN(pstMultiMedia->pstSendB))
        {
            if (pstMultiMedia->pstSendB->pstNext != MOS_NULL)
            {
                pstTmp1 = pstMultiMedia->pstSendB;
                pstMultiMedia->pstSendB = pstMultiMedia->pstSendB->pstNext;
                pstTmp1->pstNext = MOS_NULL;

                uiDataLen = MOS_BLEN(pstMultiMedia->pstSendB);
            } 
            else
            {
                Mos_InitSockBuf(pstMultiMedia->pstSendB);
            }
        }
        else if (iRetLen < MOS_BLEN(pstMultiMedia->pstSendB))
        {
            MOS_BOFF(pstMultiMedia->pstSendB) += iRetLen;
            MOS_BLEN(pstMultiMedia->pstSendB) -= iRetLen;
        }
        if (pstTmp1 != MOS_NULL)
        {
            Mos_PushSockBuf(pstMultiMedia->hSockBuffPool, pstTmp1);
            pstTmp1 = MOS_NULL;
        }
    } while (pstMultiMedia->pstSendB->pstNext && uiDataLen);
    Mos_MutexUnLock(&pstMultiMedia->hMutexSendB);
    return iRetLen;
}

// 发送心跳
static _INT MsgMng_SendHeatBeatToMultiMedia(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    MsgMng_SendDataToMultiMedia(pstMultiMedia,0x00,0x00,MOS_NULL,0);

    return MOS_OK;
}

// 处理流媒体服务器注册登录流程
static _INT MsgMng_ProcMultiMediaStatus(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia, _CTIME_T cTimeNow, _INT iIntervalMseconds)
{
    // 流媒体服务器正在重置
    if(pstMultiMedia->ucResetFlag == 1)
    {
        pstMultiMedia->ucResetFlag      = 0;
        pstMultiMedia->uiHeartInterval  = 0;
        pstMultiMedia->iStatusCountDown = 0;
        pstMultiMedia->ucStatus         = EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR;
        MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "Ready to reset multimedia mark=%s", pstMultiMedia->aucMaskName);
    }

    // 流媒体服务器状态倒计时
    pstMultiMedia->iStatusCountDown -= iIntervalMseconds;
    if(pstMultiMedia->iStatusCountDown > 0)
    {
        return MOS_OK;
    }
    else
    {
        pstMultiMedia->iStatusCountDown = 0;
    }
    
    // 流媒体服务器状态
    switch(pstMultiMedia->ucStatus)
    {
        // 开始连接流媒体服务器
        case EN_MSGMNG_MULTI_MEDIA_STATUS_STARTCONN:
        {
            int iRet = MOS_ERR;
            if (Config_GetCamaraMng()->uiIPv6Ability && Config_GetCamaraMng()->uiIPv6Switch)
            {
                if (pstMultiMedia->bRollbackToIPv4 == MOS_FALSE)
                {
                    iRet = MsgMng_ConnectMultiMediaIPv6(pstMultiMedia, cTimeNow);
                }
                else
                {
                    iRet = MsgMng_ConnectMultiMediaIPv4(pstMultiMedia, cTimeNow);
                }
                pstMultiMedia->bRollbackToIPv4 = MOS_FALSE;
            }
            else
            {
                iRet = MsgMng_ConnectMultiMediaIPv4(pstMultiMedia, cTimeNow);
            }
            // 连接流媒体服务器 异步处理
            if(iRet == MOS_OK)
            {
                pstMultiMedia->stPollFd.fd = pstMultiMedia->isockFd;
                if (pstMultiMedia->uiConnectFlag == EN_MEDIA_CONNECT_FLAG_CONNECTTING)
                {
                    pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_CONNECTING;
                }
                else if (pstMultiMedia->uiConnectFlag == EN_MEDIA_CONNECT_FLAG_CONNECTED)
                {
                    pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_CONNECTED;
                    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"------------------ MULTIMEDIA V%d CONNECTED %s ------------------",
                            (pstMultiMedia->uiConnectType==EN_MSGMNG_CONNECT_IPV6)?6:4, pstMultiMedia->aucMaskName);
                }
                
                pstMultiMedia->iStatusCountDown = 100;//100毫秒后执行性下一步
            }
            else    
            {
                // 未登录状态下，ipv6连接失败，尝试连接ipv4
                if (MsgMng_IPv6RollbackToIPv4(pstMultiMedia) == MOS_ERR) // 立刻连接失败
                {  
                    MsgMng_PrintLoginFailed(pstMultiMedia);
                    MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia,1);
                    pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR;
                }
                MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_CONNECT_ERROR, (_UC*)"socket connect error");
            }
            break;
        }
        // 正在连接流媒体服务器 异步等待 MsgMng_ConnectMultiMedia 
        case EN_MSGMNG_MULTI_MEDIA_STATUS_CONNECTING:
        {
            if (pstMultiMedia->uiConnectFlag == EN_MEDIA_CONNECT_FLAG_CONNECTED)
            {
                pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_CONNECTED;
                MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"------------------ MULTIMEDIA V%d CONNECTED %s ------------------",
                        (pstMultiMedia->uiConnectType==EN_MSGMNG_CONNECT_IPV6)?6:4, pstMultiMedia->aucMaskName);
                pstMultiMedia->iStatusCountDown = 100;//100毫秒后执行性下一步
            }
            else // 非"已连接"状态
            {
                if ((pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV6) && ((Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq) > MOS_INET_IPV6_TIMEOUT_MS))
                {
                    // 连接超时500ms
                    // ipv6连接失败，尝试连接ipv4
                    MOS_PRINTF("Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq: %llu\n", Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq);
                    MsgMng_IPv6RollbackToIPv4(pstMultiMedia);   // 连接超时500ms
                    MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_TIMEOUT_ERROR, (_UC*)"socket IPv6 connect async wait timeout error");
                }
                else if((pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV4) && ((Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq) > MSGMNG_MULTI_MEDIA_CONNTIME_MS))
                {
                    // 连接超时10*1000ms
                    MsgMng_PrintLoginFailed(pstMultiMedia);
                    MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia,1);
                    pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR;
                    MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_TIMEOUT_ERROR, (_UC*)"socket IPv4 connect async wait timeout error");
                }
            }
            break;
        }
        // 连接上流媒体服务器
        case EN_MSGMNG_MULTI_MEDIA_STATUS_CONNECTED:
        {
            // 登录流媒体服务器 异步处理
            if (pstMultiMedia->uiType == EN_MSGMNG_MULTI_MEDIA_LIVE)
            {
                MsgMng_MultiMediaLogin(pstMultiMedia, cTimeNow);
            }
            else
            {
                MsgMng_MultiMediaPlayBackLogin(pstMultiMedia, cTimeNow);
            }
            
            pstMultiMedia->ucLoginFlag      = EN_MEDIA_SERVER_LOGINING;
            pstMultiMedia->ucStatus         = EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINING;
            //pstMultiMedia->iStatusCountDown = 100;//100毫秒后执行性下一步
            //下一步接收流媒体登录应答

            MsgMng_OutFrameTimeUpdate(pstMultiMedia, "EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINING");
            MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"------------------ EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINING %s ------------------",
                        pstMultiMedia->aucMaskName);
            break;
        }
        case EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINING:
        {
            if (pstMultiMedia->ucLoginFlag == EN_MEDIA_SERVER_LOGINED)
            {
                MsgMng_OutFrameTimeUpdate(pstMultiMedia, "MULTIMEDIA LOGIN");
                MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"-------------------- MULTIMEDIA LOGIN %s --------------------",
                        pstMultiMedia->aucMaskName);
                pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINED;
                //pstMultiMedia->iStatusCountDown = 100;//100毫秒后执行性下一步
            }
            else
            {
                if ((pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV6) && ((Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq) > 4*MOS_INET_IPV6_TIMEOUT_MS))
                {
                    MsgMng_IPv6RollbackToIPv4(pstMultiMedia);   // 登录超时2000ms
                }
            }
            break;
        }
        // 流媒体服务器出错
        case EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR:
        {
            pstMultiMedia->ucLoginFlag = EN_MEDIA_SERVER_NOTLOGIN;
            pstMultiMedia->ucStatus    = EN_MSGMNG_MULTI_MEDIA_STATUS_INIT;
            Mos_InitSockBuf(pstMultiMedia->pstRecvB);
            Mos_InitSockBuf(pstMultiMedia->pstSendB);

            // FIXME: ADAPT TO NVR 关闭语音
            MsgMng_MultiMediaCloseAudioReverse(pstMultiMedia, 0, 1);
            
            MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia, 1);
            
            pstMultiMedia->ucRunFlag = 0;
            MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR,"-------------------- MULTIMEDIA ERROR %s --------------------",
                        pstMultiMedia->aucMaskName);
            if (pstMultiMedia->ucBeOccupyFlag)
            {
                MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_BE_OCCUPY, "be occupy!");
            }
            return MOS_ERR;
        }
        default:
        {

        }
    }        
    return MOS_OK;
}
// 处理流媒体服务器心跳流程
static _INT MsgMng_ProcMultiMediaHeartbeat(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia, _INT iIntervalMseconds)
{
    if (iIntervalMseconds < MSGMNG_MULTI_MEDIA_KEPPALIVE_INTERVAL*1000)
    {
        return MOS_ERR;
    }

    if (pstMultiMedia->ucStatus != EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINED)
    {
        // 检测登陆流媒体服务器超时
        if (pstMultiMedia->ucStatus == EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR)
        {
            return MOS_OK;
        }
        pstMultiMedia->uiHeartInterval += iIntervalMseconds;
        MOS_PRINTF("%s %d %d\n", __FUNCTION__, pstMultiMedia->uiHeartInterval, iIntervalMseconds);
        if (pstMultiMedia->uiHeartInterval >= MSGMNG_MULTI_MEDIA_NOILOGIN_FAIL_TIME*1000)
        {
            // 关闭连接
            pstMultiMedia->ucResetFlag = 1;
            MsgMng_PrintLoginFailed(pstMultiMedia);

            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "connect timeout1 before login ucLoginFlag:%d mark=%s", 
                        pstMultiMedia->ucLoginFlag, pstMultiMedia->aucMaskName);
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_TIMEOUT_ERROR, (_UC*)"connect timeout1 before login");
        }
    }
    else
    {
        MsgMng_SendHeatBeatToMultiMedia(pstMultiMedia);
        pstMultiMedia->uiHeartInterval += iIntervalMseconds;
        //MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "send heatbeat!!!pstMultiMedia->uiHeartInterval:%d\n", pstMultiMedia->uiHeartInterval);
        if (pstMultiMedia->uiHeartInterval >= MSGMNG_MULTI_MEDIA_HEARTBEAT_FAIL_TIME*1000)
        {
            // 关闭连接
            pstMultiMedia->ucResetFlag = 1;
            // MsgMng_PrintLoginFailed(pstMultiMedia);// 当前代码流程已确认流媒体连接登录成功

            // MEDIA SERVER ONLINE
            if (pstMultiMedia->ucLoginFlag == EN_MEDIA_SERVER_LOGINED)
            {                            
                MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "connect timeout after login mark=%s",
                            pstMultiMedia->aucMaskName);
                MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_TIMEOUT_ERROR, (_UC*)"connect timeout after login");
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "connect timeout2 before login ucLoginFlag:%d mark=%s", 
                            pstMultiMedia->ucLoginFlag, pstMultiMedia->aucMaskName);
                MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_TIMEOUT_ERROR, (_UC*)"connect timeout2 before login");
            }
        }                          
    }

    return MOS_OK;
}
// 处理流媒体服务器音视频数据流程-直播
static _VOID MsgMng_ProcMultiMediaLiveData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    _INT iStreamId = 0;

    if (pstMultiMedia->ucStatus == EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINED)
    {
        for (iStreamId = 0; iStreamId < MAX_STREAM_NUMBER; iStreamId++)
        {
            switch (MsgMng_GetMediaStatus(pstMultiMedia,iStreamId))
            {
                case EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_START:
                {
                    MsgMng_MultiMediaGetVideoData(pstMultiMedia, iStreamId, MOS_TRUE);
                    MsgMng_MultiMediaGetAudioData(pstMultiMedia, iStreamId, MOS_TRUE);
                }
                break;
                case EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_PAUSE:
                {
                    MsgMng_MultiMediaGetVideoData(pstMultiMedia, iStreamId, MOS_FALSE);
                    MsgMng_MultiMediaGetAudioData(pstMultiMedia, iStreamId, MOS_FALSE);
                }
                break;
                case EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_RESUME:
                {
                    MsgMng_MultiMediaStart(pstMultiMedia, iStreamId);
                }
                break;
                case EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_CLOSE:
                {
                    MsgMng_MultiMediaGetVideoData(pstMultiMedia, iStreamId, MOS_FALSE);
                    MsgMng_MultiMediaGetAudioData(pstMultiMedia, iStreamId, MOS_FALSE);
                }
                break;
                default:
                {
                    MsgMng_MultiMediaGetVideoData(pstMultiMedia, iStreamId, MOS_FALSE);
                    MsgMng_MultiMediaGetAudioData(pstMultiMedia, iStreamId, MOS_FALSE); 
                }
                break;
            }
        }
    }
}
// 处理流媒体服务器音视频数据流程-卡回放
static _VOID MsgMng_ProcMultiMediaPlayBackData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
// #define DEBUG_PLAYBACK_VIDEO
// #define DEBUG_PLAYBACK_AUDIO
    _INT iRet           = 0;
    _UI uiBufLen        = 0;
    _UC ucAVFlag        = 0;
    _UC  ucAvType       = 0;
    _UC ucFramePos      = 0;
    _UI uiTimeStamp     = 0;
    _UI uiFrameLen      = 0;
    _INT iAdjustTime    = 0;
    _UI uiNowTimeStamp  = 0;
    _UI uiDiffTimeStamp = 0;
    _UC aucBuf[1400]    = {0};
    _BOOL bVBuffValid   = MOS_TRUE;
    _BOOL bABuffValid   = MOS_TRUE;    
    ST_PLAYBACK_FRAME_NODE * pstFrameNote = MOS_NULL;

    if (pstMultiMedia->ucStatus != EN_MSGMNG_MULTI_MEDIA_STATUS_LOGINED ||
        pstMultiMedia->ucPBPlayStatus != EN_PLAYBACK_STATUS_START)
    {
        return;
    }

    // 打开录像文件
    if (pstMultiMedia->pstPBRdFileFD == MOS_NULL)
    {
        pstMultiMedia->pstPBRdFileFD = RdStg_OpenPlayBackFile(pstMultiMedia->aucPBFilePath, &iAdjustTime, pstMultiMedia->uiPBMode);
        if (MOS_NULL == pstMultiMedia->pstPBRdFileFD)
        {
            pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_PAUSE;
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"-------------------- MULTIMEDIA PlayBack open, file:%s Failed", pstMultiMedia->aucPBFilePath);
            return;
        }
        
        kj_timer_init(&pstMultiMedia->stPBSendTimer);
        getDiffTimems(&pstMultiMedia->stPBSendTimer, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
        pstMultiMedia->uiPBNextVSendTimeStamp = 0;
        pstMultiMedia->uiPBNextASendTimeStamp = 0;
        pstMultiMedia->ucPBVideoSendFrameDone = MOS_TRUE;
        pstMultiMedia->iPBFastSendTimeStamp   = MSGMNG_MULTI_MEDIA_PLAYBACK_FAST_TIMESTAMP;
        MsgMng_MultiMediaUpdatePlayBackBusyStatus(pstMultiMedia);
#ifdef SEND_DATA_DEBUG
        _UC pucFileName[64] = {0};

        sprintf(pucFileName, "/home/wuxj/%s.bin", pstMultiMedia->aucMaskName);
        if (!pstMultiMedia->hFile)
        {
            pstMultiMedia->hFile = (_VOID*)fopen(pucFileName, "wb");
            if (pstMultiMedia->hFile)
            {
                MOS_PRINTF("SEND_DATA_DEBUG file:%s success\n", pucFileName);
            }
            else
            {
                MOS_PRINTF("SEND_DATA_DEBUG file:%s error\n", pucFileName);
            }
        }
#endif
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "-------------------- MULTIMEDIA PlayBack Start, file:%s", pstMultiMedia->aucPBFilePath);
    }

    // 发送视频数据
    while (bVBuffValid)
    {
        uiNowTimeStamp = getDiffTimems(&pstMultiMedia->stPBSendTimer, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
        uiNowTimeStamp += pstMultiMedia->iPBFastSendTimeStamp; // 加上快速发送的时间基准

         // 数据列表内至少存在一帧数据，用于计算发送时序
        if (((pstMultiMedia->uiPBVFrameCnt && pstMultiMedia->uiPBFileEndFlag) || pstMultiMedia->uiPBVFrameCnt > 1) &&
            (pstMultiMedia->uiPBNextVSendTimeStamp <= uiNowTimeStamp))
        {
            bVBuffValid = MOS_TRUE;
            // 提取frame
            pstFrameNote = pstMultiMedia->pstPBVFrameHead;
            pstMultiMedia->pstPBVFrameHead = (ST_PLAYBACK_FRAME_NODE *)pstMultiMedia->pstPBVFrameHead->pstnext;
            pstMultiMedia->uiPBVFrameCnt--;

            // 记录下次发送的时间戳
            if (pstMultiMedia->pstPBVFrameHead && (pstMultiMedia->pstPBVFrameHead->uiTimeStamp != pstFrameNote->uiTimeStamp))
            {
                if (pstMultiMedia->ucPBDownFlag)
                {
                    pstMultiMedia->uiPBNextVSendTimeStamp += 4;
                }
                else
                {
                    // 获取当前帧与下一帧的差值
                    uiDiffTimeStamp = pstMultiMedia->pstPBVFrameHead->uiTimeStamp - pstFrameNote->uiTimeStamp;
                    if (uiDiffTimeStamp > 1000) //判断上下帧差值大于1秒，则直接发送
                    {
                        pstMultiMedia->uiPBNextVSendTimeStamp += 0;
                    }
                    else
                    {
                        pstMultiMedia->uiPBNextVSendTimeStamp += uiDiffTimeStamp;
                    }
                }
            }
            // 判断一帧视频是否已发送完成，防止一帧视频中间插音频数据，APP会出现播放异常
            if (MD_GETFRAMEPOS(pstFrameNote->stNote.ucFramPos) & (MD_FRAME_TAIL | MD_NALU_TAIL))
            {
                pstMultiMedia->ucPBVideoSendFrameDone = MOS_TRUE;
            }
            else
            {
                pstMultiMedia->ucPBVideoSendFrameDone = MOS_FALSE;
            }
            pstMultiMedia->uiPBLastVFrameTimeStamp = pstFrameNote->uiTimeStamp;

#ifdef DEBUG_PLAYBACK_VIDEO
            MOS_PRINTF("%s VIDEO send frame_cnt:%02d now_time:%u next_time:%u frame[time:%u pos:%02X len:%d] FrameDone:%d\n", 
            __FUNCTION__, pstMultiMedia->uiPBVFrameCnt, uiNowTimeStamp, pstMultiMedia->uiPBNextVSendTimeStamp, 
            pstFrameNote->uiTimeStamp, pstFrameNote->stNote.ucFramPos, pstFrameNote->stNote.usDatalen,
            pstMultiMedia->ucPBVideoSendFrameDone);
#endif
            //发送数据
            procSendMediaPlayback(pstMultiMedia, pstMultiMedia->usChannel, EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_PLAYBACK,
                        &(pstFrameNote->stNote), pstFrameNote->stNote.usDatalen, pstFrameNote->uiTimeStamp, EN_HTTP_STREAMER_VIDEO);

            MOS_FREE(pstFrameNote->stNote.ptDatabuff);
            MOS_FREE(pstFrameNote);   

            // 完成发送一帧视频数据，接下来发送音频数据
            if (pstMultiMedia->ucPBVideoSendFrameDone)
            {
                bVBuffValid = MOS_FALSE;
                break;
            }
        }
        else
        {
            bVBuffValid = MOS_FALSE;
        }
    }
    // 发送音频数据 & 发送完一帧视频数据才会发送音频数据
    while (bABuffValid && pstMultiMedia->ucPBVideoSendFrameDone == MOS_TRUE)
    {
        uiNowTimeStamp = getDiffTimems(&pstMultiMedia->stPBSendTimer, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10);   
        uiNowTimeStamp += pstMultiMedia->iPBFastSendTimeStamp;// 加上快速发送的时间基准 

        // 数据列表内至少存在一帧数据，用于计算发送时序         
        if (((pstMultiMedia->uiPBAFrameCnt && pstMultiMedia->uiPBFileEndFlag) || pstMultiMedia->uiPBAFrameCnt > 1) && 
            ((pstMultiMedia->uiPBNextASendTimeStamp <= uiNowTimeStamp) || 
            (pstMultiMedia->uiPBLastVFrameTimeStamp >= pstMultiMedia->pstPBAFrameHead->uiTimeStamp)))
        {
            //下一帧时间到了会触发发送，当前音频帧时间戳小于最后发送视频帧时间戳也会触发发送
            bABuffValid = MOS_TRUE;
            // 提取frame
            pstFrameNote = pstMultiMedia->pstPBAFrameHead;
            pstMultiMedia->pstPBAFrameHead = (ST_PLAYBACK_FRAME_NODE *)pstMultiMedia->pstPBAFrameHead->pstnext;
            pstMultiMedia->uiPBAFrameCnt--;

            // 记录下次发送的时间戳
            if (pstMultiMedia->pstPBAFrameHead && (pstMultiMedia->pstPBAFrameHead->uiTimeStamp != pstFrameNote->uiTimeStamp))
            {
                if (pstMultiMedia->ucPBDownFlag)
                {
                    pstMultiMedia->uiPBNextASendTimeStamp += 4;
                }
                else
                {
                    // uiDiffTimeStamp = (pstMultiMedia->pstPBAFrameHead->uiTimeStamp - pstMultiMedia->uiPBStartFrameTimeStamp);
                    uiDiffTimeStamp = pstMultiMedia->pstPBAFrameHead->uiTimeStamp - pstFrameNote->uiTimeStamp;
                    if (uiDiffTimeStamp > 1000) //判断上下帧差值大于1秒，则直接发送
                    {
                        pstMultiMedia->uiPBNextASendTimeStamp += 0;
                    }
                    else
                    {
                        pstMultiMedia->uiPBNextASendTimeStamp += uiDiffTimeStamp;
                    }
                }
            }

#ifdef DEBUG_PLAYBACK_AUDIO          
            MOS_PRINTF("%s AUDIO send frame_cnt:%02d now_time:%u next_time:%u frame[time:%u pos:%02X len:%d]\n", 
            __FUNCTION__, pstMultiMedia->uiPBAFrameCnt, uiNowTimeStamp, pstMultiMedia->uiPBNextASendTimeStamp, 
            pstFrameNote->uiTimeStamp, pstFrameNote->stNote.ucFramPos, pstFrameNote->stNote.usDatalen);
#endif
            // 发送数据
            procSendMediaPlayback(pstMultiMedia, pstMultiMedia->usChannel, EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_PLAYBACK,
                        &(pstFrameNote->stNote), pstFrameNote->stNote.usDatalen, pstFrameNote->uiTimeStamp, EN_HTTP_STREAMER_AUDIO);

            MOS_FREE(pstFrameNote->stNote.ptDatabuff);
            MOS_FREE(pstFrameNote);
        }
        else
        {
            bABuffValid = MOS_FALSE;
        }
    }
    // 读取文件结束并数据列表无数据，设置为暂停状态
    if (pstMultiMedia->uiPBFileEndFlag && pstMultiMedia->uiPBVFrameCnt==0 && pstMultiMedia->uiPBAFrameCnt==0)
    {
        pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_PAUSE;
        return;
    }
    // 判断是否继续读取卡录像
    while (pstMultiMedia->uiPBFileEndFlag == 0 &&
          (pstMultiMedia->uiPBVFrameCnt < MSGMNG_MULTI_MEDIA_PLAYBACK_LIST_MIN_CNT || 
          pstMultiMedia->uiPBAFrameCnt < MSGMNG_MULTI_MEDIA_PLAYBACK_LIST_MIN_CNT))
    {
        // 限制数据列表最大数
        if (pstMultiMedia->uiPBVFrameCnt >= MSGMNG_MULTI_MEDIA_PLAYBACK_VIDEO_LIST_MAX_CNT || 
            pstMultiMedia->uiPBAFrameCnt >= MSGMNG_MULTI_MEDIA_PLAYBACK_AUDIO_LIST_MAX_CNT)
        {
            if (pstMultiMedia->uiPBVFrameCnt == 1 && 
                pstMultiMedia->uiPBAFrameCnt >= MSGMNG_MULTI_MEDIA_PLAYBACK_AUDIO_LIST_MAX_CNT &&
                pstMultiMedia->ucPBVideoSendFrameDone == MOS_FALSE)
            {
                pstMultiMedia->uiPBFileEndFlag = 1;
                MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "Login ERR PlayBack file:%s read end", pstMultiMedia->aucPBFilePath);
            }
            break;
        }
        // 读取卡录像数据到媒体句柄
        iRet = RdStg_ReadPlayBackFile(pstMultiMedia->pstPBRdFileFD, aucBuf, &uiBufLen, &ucAVFlag, &uiTimeStamp, &ucFramePos, &uiFrameLen);
        if (uiBufLen > 0)
        {
            if (iRet != MOS_OK)
            {
                MOS_PRINTF("RECORD READ ERROR DATA %s read file  buflen:%u time:%u frame_pos:0x%02x frame_len:%u\n", 
                ucAVFlag==1?"VIDEO":"AUDIO", uiBufLen, uiTimeStamp, ucFramePos, uiFrameLen);
                continue;
            }
            ucAvType = EN_HTTP_STREAMER_AUDIO;
            if (ucAVFlag == 1)
            {
                ucAvType = EN_HTTP_STREAMER_VIDEO;
            }
            if ((ucAVFlag == 1) || (ucAVFlag == 2))// Video Or Audio
            {
                ST_PLAYBACK_FRAME_NODE * pstNote = MOS_NULL;

                pstFrameNote = (ST_PLAYBACK_FRAME_NODE *)MOS_MALLOCCLR(sizeof(ST_PLAYBACK_FRAME_NODE));
                pstFrameNote->stNote.ucVideoResolutionChangeFlag = EN_VIDEOPARAM_CHANGED_NONE;
                pstFrameNote->stNote.ucFramPos     = ucFramePos;
                pstFrameNote->stNote.usDatalen     = uiFrameLen;
                pstFrameNote->stNote.uiNaluLen     = uiBufLen;
                pstFrameNote->stNote.uiRemFrameLen = uiBufLen;   
                pstFrameNote->stNote.ptnest        = MOS_NULL;    
                pstFrameNote->stNote.ptDatabuff    = MOS_MALLOCCLR(uiBufLen);  
                MOS_MEMCPY(pstFrameNote->stNote.ptDatabuff, aucBuf, uiBufLen);  
                
                pstFrameNote->uiTimeStamp           = uiTimeStamp;
                pstFrameNote->pstnext               = MOS_NULL;
                if (ucAvType == EN_HTTP_STREAMER_VIDEO)
                {
                    pstMultiMedia->uiPBVFrameCnt++;
                    pstNote = pstMultiMedia->pstPBVFrameHead;
                    if (pstNote == MOS_NULL)
                    {
                        pstMultiMedia->pstPBVFrameHead = pstFrameNote;
                    }
                    else
                    {
                        while (pstNote->pstnext)
                        {
                            pstNote = pstNote->pstnext;
                        }
                        pstNote->pstnext = pstFrameNote;
                    }
                }
                else
                {
                    pstMultiMedia->uiPBAFrameCnt++;
                    pstNote = pstMultiMedia->pstPBAFrameHead;
                    if (pstNote == MOS_NULL)
                    {
                        pstMultiMedia->pstPBAFrameHead = pstFrameNote;
                    }
                    else
                    {
                        while (pstNote->pstnext)
                        {
                            pstNote = pstNote->pstnext;
                        }
                        pstNote->pstnext = pstFrameNote;
                    }
                }
#ifdef DEBUG_PLAYBACK_VIDEO1
                if (ucAvType == EN_HTTP_STREAMER_VIDEO)
                {
                    MOS_PRINTF("%s VIDEO read file  frame_cnt:%d buflen:%u time:%u frame_pos:0x%02x frame_len:%u\n", 
                    __FUNCTION__, pstMultiMedia->uiPBVFrameCnt, uiBufLen, uiTimeStamp, ucFramePos, uiFrameLen);
                }
#endif
#ifdef DEBUG_PLAYBACK_AUDIO1
                if (ucAvType == EN_HTTP_STREAMER_AUDIO)
                {
                    MOS_PRINTF("%s AUDIO read file  frame_cnt:%d buflen:%u time:%u frame_pos:0x%02x frame_len:%u\n", 
                    __FUNCTION__, pstMultiMedia->uiPBAFrameCnt, uiBufLen, uiTimeStamp, ucFramePos, uiFrameLen);
                }     
#endif             
            }
        }
        else
        {
            if (iRet == MOS_ERR_FILEFINISH)
            {
                pstMultiMedia->uiPBFileEndFlag = 1;
                MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "PlayBack file:%s read end", pstMultiMedia->aucPBFilePath);
                break;
            }
        }
    }
}

static _INT MsgMng_ProcMultiMediaPlayBackVod(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia, _UI uiChannelId, _UI uiVod, _UI uiParamFlag, _UC *pucPosTime)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    _INT iVodUsed    = 0;
    _INT iAdjustTime = 0;
    _UI uiTimeStamp  = 0;
    ST_PLAYBACK_FRAME_NODE * pstFrameTmp  = MOS_NULL;
    ST_PLAYBACK_FRAME_NODE * pstFrameNote = MOS_NULL;

    if (uiVod & VOD_CMD_PAUSE)
    {
        iVodUsed = 1;
        if (pstMultiMedia->ucPBPlayStatus == EN_PLAYBACK_STATUS_START)
        {
            pstMultiMedia->uiPBPauseTimeStamp = getDiffTimems(&pstMultiMedia->stPBSendTimer, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
            MsgMng_MultiMediaUpdatePlayBackBusyStatus(pstMultiMedia);
        }

        pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_PAUSE;
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "recive PlayBack Vod pause cmd!!!! %u", pstMultiMedia->uiPBNextASendTimeStamp);
    }

    if (uiVod & VOD_CMD_REPLAY)
    {
        iVodUsed = 1;
        if (pstMultiMedia->ucPBPlayStatus != EN_PLAYBACK_STATUS_START)
        {
            uiTimeStamp = getDiffTimems(&pstMultiMedia->stPBSendTimer, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
            uiTimeStamp = uiTimeStamp - pstMultiMedia->uiPBPauseTimeStamp;
            pstMultiMedia->uiPBNextVSendTimeStamp += uiTimeStamp;
            pstMultiMedia->uiPBNextASendTimeStamp += uiTimeStamp;
            MOS_PRINTF("uiPBNextVSendTimeStamp=%u uiPBNextASendTimeStamp=%u\n", 
            pstMultiMedia->uiPBNextVSendTimeStamp, pstMultiMedia->uiPBNextASendTimeStamp);
            MsgMng_MultiMediaUpdatePlayBackBusyStatus(pstMultiMedia);
        }
        pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_START;
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "recive PlayBack Vod Replay cmd!!!!\n");
    }
    if ((uiVod & VOD_CMD_SEEK) && (pucPosTime != MOS_NULL))
    {
        iVodUsed = 1;
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "recive PlayBack Vod SEEK POS: %s", pucPosTime);
        pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_START;
        if (1)//pstMultiMedia->ucPlayFlag ==1)
        {
            RdStg_ClosePlayBackFile(pstMultiMedia->pstPBRdFileFD);
            pstMultiMedia->pstPBRdFileFD = MOS_NULL;
            pstMultiMedia->pstPBRdFileFD = RdStg_OpenPlayBackFile(pucPosTime, &iAdjustTime, pstMultiMedia->uiPBMode);
            if (MOS_NULL == pstMultiMedia->pstPBRdFileFD)
            {
                _UC aucErrString[128] = {0};
                MOS_VSNPRINTF(aucErrString, sizeof(aucErrString), "playback vod seek error %s", pucPosTime);
                MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, aucErrString);
                MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_PLAYBACK_SEEK_FAIL, (_UC*)aucErrString);
                pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_PAUSE;
                return MOS_ERR;
            }
            else
            {
                MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "Vod Seek open playback file %s successful !!!", pstMultiMedia->aucPBFilePath);
            }
        }
        else//Todo:just for seek on one file
        {
            RdStg_SeekOnOneFile(pstMultiMedia->pstPBRdFileFD, pucPosTime, &iAdjustTime);
        }
        pstMultiMedia->uiPBFileEndFlag = 0;
        //清除旧数据
        pstMultiMedia->uiPBVFrameCnt = 0;
        pstMultiMedia->uiPBAFrameCnt = 0;
        pstMultiMedia->uiPBNextVSendTimeStamp = 0;
        pstMultiMedia->uiPBNextASendTimeStamp = 0;
        pstMultiMedia->ucPBVideoSendFrameDone = MOS_TRUE;
        pstMultiMedia->iPBFastSendTimeStamp   = MSGMNG_MULTI_MEDIA_PLAYBACK_FAST_TIMESTAMP;

        pstFrameNote = pstMultiMedia->pstPBVFrameHead;
        while (pstFrameNote != MOS_NULL)
        {
            pstFrameTmp = pstFrameNote->pstnext;
            MOS_FREE(pstFrameNote->stNote.ptDatabuff);
            MOS_FREE(pstFrameNote);
            pstFrameNote = pstFrameTmp;
        }
        pstMultiMedia->pstPBVFrameHead = MOS_NULL;
        
        pstFrameNote = pstMultiMedia->pstPBAFrameHead;
        while (pstFrameNote != MOS_NULL)
        {
            pstFrameTmp = pstFrameNote->pstnext;
            MOS_FREE(pstFrameNote->stNote.ptDatabuff);
            MOS_FREE(pstFrameNote);
            pstFrameNote = pstFrameTmp;
        }
        pstMultiMedia->pstPBAFrameHead = MOS_NULL;

        getDiffTimems(&pstMultiMedia->stPBSendTimer, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    }

    if (uiVod & VOD_CMD_KEYFRAME)
    {
        iVodUsed = 1;
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "PlayBack VOD_CMD_KEYFRAME");
    }

    if (uiVod & VOD_CMD_TEADOWN)
    {
        iVodUsed = 1;
        MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "PlayBack VOD_CMD_TEADOWN");
        pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_PAUSE;
        MsgMng_MultiMediaUpdatePlayBackBusyStatus(pstMultiMedia);
    }
    
    if (iVodUsed == 0)
    {
        MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "PlayBack VOD 0x%02X dont support", uiVod);
        return MOS_ERR;
    }

    return MOS_OK;
}
// 登录流媒体服务器指令应答回调函数
static _INT MsgMng_ProcMultiMediaLoginRsp(_VPTR hConn, _UI uiReqId,_VPTR hRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(hRoot);

    _INT iValue       = MOS_ERR;
    _UC *pStrTmp      = MOS_NULL;
    _UC *pucEncKey    = MOS_NULL;
    _UC *pucEnload    = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    do
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"ogct %u MsgCt recv login rsp code %u",uiReqId,iValue);
        if(iValue != 0)
        {
            _UC aucErrString[128] = {0};
            MOS_VSNPRINTF(aucErrString, sizeof(aucErrString), "live login server error %d ", iValue);
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_LOGIN_RSP_FAIL, (_UC*)aucErrString);

            if (MsgMng_IPv6RollbackToIPv4(pstMultiMedia) == MOS_ERR) // 登录应答失败
            {
                MsgMng_PrintLoginFailed(pstMultiMedia);
                MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia,1);
                pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR;
            }
            break;
        }
        /*
        if(iValue > 0 && iValue <= 256)
        {
            pstMultiMedia->ucHeartInterval = iValue;
        }
        */
        Mos_MutexLock(&Media_GetTaskMng()->hMutex);
        pstMultiMedia->ucLoginFlag = EN_MEDIA_SERVER_LOGINED;

        pStrTmp = MsgMng_BuildCommonNtcRspJson(pstMultiMedia->stLoginInfo.uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_DEV_ADDR_NTC_RSP,0);
        MsgMng_SendMsg(pstMultiMedia->stLoginInfo.pucPeerId,pstMultiMedia->stLoginInfo.uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_DEV_ADDR_NTC_RSP,
            pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
        Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
        MOS_FREE(pStrTmp);

        _UC aucUploadLog[256] = {0};
        _UC aucStrcatLocalV6Buf[128] = {0};
        _UC aucLocalV6Addr[CFG_STRING_LEN] = {0};

        MOS_VSNPRINTF(aucUploadLog, sizeof(aucUploadLog), "live login server success linkv%d, hasipv6addr: %d", 
            pstMultiMedia->uiConnectType==EN_MSGMNG_CONNECT_IPV4?4:6, MOS_STRLEN(pstMultiMedia->stInetIPv6.u.aucIpv6)?1:0);
        MsgMng_MultiMediaGetLocalIPv6Addr(aucLocalV6Addr, sizeof(aucLocalV6Addr));
        if (MOS_STRLEN(aucLocalV6Addr) > 0)
        {
            MOS_VSNPRINTF(aucStrcatLocalV6Buf, sizeof(aucStrcatLocalV6Buf), ", localv6:%s", aucLocalV6Addr);
            MOS_STRCAT(aucUploadLog, aucStrcatLocalV6Buf);
        }

        MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_LOGIN_RSP_SUCCESS, (_UC*)aucUploadLog);
        if (pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV4)
        {
            MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"media server connect succeed ipv4 time: %llu", Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq);
        }
        else if (pstMultiMedia->uiConnectType == EN_MSGMNG_CONNECT_IPV6)
        {
            MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"media server connect succeed ipv6 time: %llu", Mos_GetLLTickCount() - pstMultiMedia->ullTimeReq);
        }

    }while(0);
    
    return MOS_OK;
}
// 组装登录流媒体服务器json
static _UC *MsgMng_BuildMultiMediaLoginJson(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    _UC *pStrTmp = MOS_NULL;
    _UC auMethod[8];
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    MOS_VSNPRINTF(auMethod, 8, "%02X%02X",EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_DEV_LOGIN);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(auMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstMultiMedia->uiReqID));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID", Adpt_Json_CreateString(pstMultiMedia->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ResourceID", Adpt_Json_CreateString(pstMultiMedia->pucResourceID));

    Adpt_Json_AddItemToObject(hBody,(_UC*)"EncType", Adpt_Json_CreateStrWithNum(pstMultiMedia->stEncrypInf.iEncType));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"EncKey", Adpt_Json_CreateString(pstMultiMedia->stEncrypInf.aucEncKey));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"EncLoad", Adpt_Json_CreateString(pstMultiMedia->stEncrypInf.aucEncLv));

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}
// 登录流媒体服务器 异步处理
static _INT MsgMng_MultiMediaLogin(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_CTIME_T cTimeNow)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    _INT iRet = 0;
    _UC *pStrTmp  = MOS_NULL;
    
    pstMultiMedia->uiReqID = Mos_GetSessionId();
    
    // 组合登录流媒体服务器的json数据
    pStrTmp = MsgMng_BuildMultiMediaLoginJson(pstMultiMedia);

    // 发送登录流媒体服务器的请求
    iRet = MsgMng_MultiMediaSendMsg(pstMultiMedia,MSGMNG_CMD_SERVER_ID,pstMultiMedia->uiReqID,EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_DEV_LOGIN,
        pStrTmp,MOS_STRLEN(pStrTmp),MsgMng_ProcMultiMediaLoginRsp);

    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"ogct %u Msgct Send login requst body %s iret %d",pstMultiMedia->uiReqID,pStrTmp,iRet);
    
    // pstMultiMedia->timeReq = cTimeNow;
    MOS_FREE(pStrTmp);
    return iRet;
}
// 登录流媒体服务器指令应答回调函数-卡回放
static _INT MsgMng_ProcMultiMediaPlayBackLoginRsp(_VPTR hConn, _UI uiReqId,_VPTR hRoot)
{
    MOS_PARAM_NULL_RETERR(hRoot);

    _INT iValue  = 0;
    _UC *pStrTmp      = MOS_NULL;
    _UC *pucEncKey    = MOS_NULL;
    _UC *pucEnload    = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    do
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"ogct %u MsgCt recv playback login rsp code %u",uiReqId,iValue);
        if(iValue != 0)
        {
            if (MsgMng_IPv6RollbackToIPv4(pstMultiMedia) == MOS_ERR) // 登录应答失败
            {
                MsgMng_PrintLoginFailed(pstMultiMedia);
                MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia,1);
                pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR;      
            }
            
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_PLAYBACK_LOGIN_RSP_FAIL, (_UC*)"playback login server error");
            break;
        }
        pstMultiMedia->ucLoginFlag    = EN_MEDIA_SERVER_LOGINED;
        pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_START;
    }while(0);
    
    return MOS_OK;
}
// 组装登录流媒体服务器json-卡回放
static _UC *MsgMng_BuildMultiMediaPlayBackLoginJson(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    _UC *pStrTmp = MOS_NULL;
    _UC auMethod[8];
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    MOS_VSNPRINTF(auMethod, 8, "%02X%02X",EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_PLAYBACK_LOGIN);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(auMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(pstMultiMedia->uiReqID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"FROM", Adpt_Json_CreateString(pstMultiMedia->aucDevUID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"TO", Adpt_Json_CreateString(pstMultiMedia->aucPBClinetToken));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"SessionId", Adpt_Json_CreateString(pstMultiMedia->aucPBSessionId));

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}
// 登录流媒体服务器-卡回放
static _INT MsgMng_MultiMediaPlayBackLogin(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_CTIME_T cTimeNow)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    _INT iRet = 0;
    _UC *pStrTmp  = MOS_NULL;
    
    pstMultiMedia->uiReqID = Mos_GetSessionId();
    
    // 组合登录流媒体服务器的json数据
    pStrTmp = MsgMng_BuildMultiMediaPlayBackLoginJson(pstMultiMedia);

    // 发送登录流媒体服务器的请求
    iRet = MsgMng_MultiMediaSendMsg(pstMultiMedia,MSGMNG_CMD_SERVER_ID,pstMultiMedia->uiReqID,EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_PLAYBACK_LOGIN,
        pStrTmp,MOS_STRLEN(pStrTmp),MsgMng_ProcMultiMediaPlayBackLoginRsp);

    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"ogct %u Msgct Send login requst body %s iret %d",pstMultiMedia->uiReqID,pStrTmp,iRet);
    
    // pstMultiMedia->timeReq = cTimeNow;
    MOS_FREE(pStrTmp);
    return iRet;
}

_INT MsgMng_SetMediaStatus(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iStreamId, _INT status)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    Mos_MutexLock(&pstMultiMedia->hMutexStatus);
    pstMultiMedia->ucStreamStatus[iStreamId] = status;
    Mos_MutexUnLock(&pstMultiMedia->hMutexStatus);
    return MOS_OK;
}

_INT MsgMng_GetMediaStatus(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iStreamId)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    _INT status =0;
    Mos_MutexLock(&pstMultiMedia->hMutexStatus);
    status = pstMultiMedia->ucStreamStatus[iStreamId];
    Mos_MutexUnLock(&pstMultiMedia->hMutexStatus);
    return status;
}


_INT MsgMng_MultiMediaStart(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iStreamId)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    MsgMng_OutFrameTimeUpdate(pstMultiMedia, __FUNCTION__);
    if (iStreamId>=0 && iStreamId<=1)
    {
        MOS_PRINTF("%s iStreamId: %d mark=%s\r\n", __FUNCTION__, iStreamId, pstMultiMedia->aucMaskName);
        pstMultiMedia->iNeedIframe[iStreamId] = MOS_TRUE;
        MsgMng_SetMediaStatus(pstMultiMedia, iStreamId, EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_START);
        return MOS_OK;
    }
    else
    {
        MOS_PRINTF("%s error iStreamId: %d mark=%s\r\n", __FUNCTION__, iStreamId, pstMultiMedia->aucMaskName);
        return MOS_ERR;
    }
}

_INT MsgMng_MultiMediaClose(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iStreamId)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    MOS_PRINTF("MsgMng_MultiMediaClose iStreamId: %d mark=%s\r\n", iStreamId, pstMultiMedia->aucMaskName);
    MsgMng_SetMediaStatus(pstMultiMedia, iStreamId, EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_CLOSE);
    return MOS_OK;
}

_INT MsgMng_MultiMediaPause(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iStreamId)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    MsgMng_OutFrameTimeBegin(pstMultiMedia, "OutFrame Switch");
    MOS_PRINTF("MsgMng_MultiMediaPause iStreamId: %d mark=%s\r\n", iStreamId, pstMultiMedia->aucMaskName);
    MsgMng_SetMediaStatus(pstMultiMedia, iStreamId, EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_PAUSE);
    return MOS_OK;
}

_INT MsgMng_MultiMediaResume(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iStreamId)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    MsgMng_OutFrameTimeBegin(pstMultiMedia, "OutFrame Again");
    MOS_PRINTF("MsgMng_MultiMediaResume iStreamId: %d mark=%s\r\n", iStreamId, pstMultiMedia->aucMaskName);
    MsgMng_SetMediaStatus(pstMultiMedia, iStreamId, EN_MSGMNG_MULTI_MEDIA_STREAM_STATUS_RESUME);
    return MOS_OK;
}

_INT MsgMng_MultiMediaOpenAudioReverse(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia, ST_ZJ_AUDIO_PARAM audioParams, _INT iCamId, _INT iChannelId)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

#ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Pause_OpenTalk();
#endif    

    if (Config_GetCamaraMng()->uiSpkOpenFlag == MOS_FALSE)
    {
#ifdef BUILD_IMSSDK_FALG
        if (ImsMedia_GetTaskMng()->bEnableSpeaker)
        {
            MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "ImsMedia Is Working");
            return MOS_OK;
        }
#endif
        #ifdef BUILD_ONBROADCAST_FALG
        Broadcast_Task_SetBroadcastState(BROADCAST_STATE_TALK);
        #endif   
        Mos_MutexLock(&pstMultiMedia->hMutexStatus);            
        Media_AudioPlayCancelFrameBuff(MOS_NULL);
        Config_SetCamerSpkOpenFlag(iCamId, MOS_TRUE);
        pstMultiMedia->ullReiveAudioTime = Mos_GetLLTickCount();
        pstMultiMedia->m_bEnableSpeaker  = MOS_TRUE;
        pstMultiMedia->m_sAudioSpeakChn  = iChannelId;
        
        pstMultiMedia->m_hAudioPlay = Media_AudioPlayCreatWriteHandle(pstMultiMedia->pucResourceID, iChannelId, &audioParams);
        Media_Notify_AudioPlay(pstMultiMedia->pucResourceID, 1, pstMultiMedia->m_bEnableSpeaker, iChannelId);
#ifdef BUILD_IMSSDK_FALG
        ImsMedia_SetMultiMedia((_VOID*)pstMultiMedia);
#endif
        Mos_MutexUnLock(&pstMultiMedia->hMutexStatus);
        MsgMng_MultiMediaUpdateLiveBusyStatus(pstMultiMedia);
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "Opening audio reverse");
        return MOS_OK;
    }

    return MOS_ERR;
}

_INT MsgMng_MultiMediaCloseAudioReverse(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iCamId, _INT iChannelId)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    Mos_MutexLock(&pstMultiMedia->hMutexStatus);
    if (pstMultiMedia->m_bEnableSpeaker)
    {
        Config_SetCamerSpkOpenFlag(iCamId, MOS_FALSE);
        pstMultiMedia->m_bEnableSpeaker  = MOS_FALSE;
        pstMultiMedia->m_sAudioSpeakChn  =  0;
        Media_Notify_AudioPlay(pstMultiMedia->pucResourceID, 1, pstMultiMedia->m_bEnableSpeaker, iChannelId);
        Media_AudioPlayDestroyWriteHandle(pstMultiMedia->m_hAudioPlay);
        pstMultiMedia->m_hAudioPlay = MOS_NULL;
        MsgMng_MultiMediaUpdateLiveBusyStatus(pstMultiMedia);
        MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "Closing audio reverse");
    }
    Mos_MutexUnLock(&pstMultiMedia->hMutexStatus);
    
    Media_AudioPlayCancelFrameBuff(MOS_NULL);
    
#ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Resume_CloseTalk();
#endif    
    return MOS_OK;
}

/***********************************************************************
主动发起请求 节点的申请 和 查找
************************************************************************/
static ST_MSGMNG_MULTIMEDIA_RSP_NODE *MsgMng_MultiMediaFindRspNode(_UI uiReqId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MSGMNG_MULTIMEDIA_RSP_NODE *pstMsgRspNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stRspList, pstMsgRspNode, stIterator)
    {
        if(pstMsgRspNode->ucUseFlag && pstMsgRspNode->uiReqId == uiReqId)
        {
            return pstMsgRspNode;
        }
    }
    return MOS_NULL;
}

static ST_MSGMNG_MULTIMEDIA_RSP_NODE *MsgMng_MultiMediaMallocRspNode(_UI uiReqId,_UC ucMsgType,_UC ucMsgId,PFUN_MSGMNG_MULTIMEDIA_RSPDATACB pFunRspDataCb)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MSGMNG_MULTIMEDIA_RSP_NODE *pstMsgRspNode = MOS_NULL;

    Mos_MutexLock(&Media_GetTaskMng()->hMutex);
    
    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stRspList, pstMsgRspNode, stIterator)
    {
        if(pstMsgRspNode->ucUseFlag  == 0)
        {
            break;
        }
    }
    if(pstMsgRspNode == MOS_NULL)
    {
        pstMsgRspNode = (ST_MSGMNG_MULTIMEDIA_RSP_NODE*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_MULTIMEDIA_RSP_NODE));
        MOS_LIST_ADDTAIL(&Media_GetTaskMng()->stRspList, pstMsgRspNode);
    }
    pstMsgRspNode->pfunRspMsgProc = pFunRspDataCb;
    pstMsgRspNode->ucMsgId        = ucMsgId;
    pstMsgRspNode->usMsgType      = ucMsgType;
    pstMsgRspNode->uiReqId        = uiReqId;
    pstMsgRspNode->ucUseFlag      = 1;
    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
    return pstMsgRspNode;
}


// 发送请求数据到流媒体服务器
_INT MsgMng_SendDataToMultiMedia(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen)
{
    _UI uiBuffLen    = 0;
    _UI uiHeadlen    =  sizeof(ST_OGCT_PROTOCAL_HEAD);
    _UI uiDataLenEx  =  MOS_HEX_NUM(uiDatalen);
    ST_OGCT_PROTOCAL_HEAD *pstOgctHead  = MOS_NULL;

    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    if (pstMultiMedia->stPlatEncryInf.iEncType == 0)
    {
        uiDataLenEx = uiDatalen;
    }

    // 设备回复的数据 包头加加密后的接送数据
    _INT iPacketBufLen = 0;
    _UC  *ucStrPacketBuf = (_UC *)MOS_MALLOC(uiDataLenEx + sizeof(ST_OGCT_PROTOCAL_HEAD) +  1);

    // Methon 0x3244 login
    if(ucMsgType == EN_OGCT_METHOD_MULMEDIA && (ucMsgId == EN_OGCT_MULMEDIA_DEV_LOGIN || ucMsgId == EN_OGCT_MULMEDIA_PLAYBACK_LOGIN))
    {
        MOS_FREE(ucStrPacketBuf);
        return MsgMng_SendNotAuthToMultiMedia(pstMultiMedia,ucMsgType,ucMsgId,pucData,uiDatalen);
    }

    if(pstMultiMedia->ucLoginFlag != EN_MEDIA_SERVER_LOGINED)
    {
        MOS_FREE(ucStrPacketBuf);
        return MOS_ERR;
    }

    // 登录成功，非登录的信令处理
    Mos_MutexLock(&pstMultiMedia->hMutexSendB);
    uiBuffLen = pstMultiMedia->uiPayloadLen - MOS_BOFF(pstMultiMedia->pstSendB) - MOS_BLEN(pstMultiMedia->pstSendB);
    
    if (uiDataLenEx + uiHeadlen <= uiBuffLen)
    {

        pstOgctHead = (ST_OGCT_PROTOCAL_HEAD*)MOS_BEND(pstMultiMedia->pstSendB);
        Http_EncMsgHead(pstOgctHead, ucMsgType, ucMsgId, uiDataLenEx, pstMultiMedia->stPlatEncryInf.iEncType);
        MOS_BLEN(pstMultiMedia->pstSendB) += sizeof(ST_OGCT_PROTOCAL_HEAD);
        // printf("............1.4\r\n");
        if (uiDataLenEx > 0)
        {

            MOS_MEMCPY(MOS_BEND(pstMultiMedia->pstSendB), pucData, uiDatalen);
            // if(uiDataLenEx - uiDatalen >  0){
            //     MOS_MEMSET(MOS_BEND(pstMultiMedia->pstSendB) + uiDatalen,0, uiDataLenEx - uiDatalen);
            // }

            // BUF_PRINTF_EX("1.3", MOS_BEND(pstMultiMedia->pstSendB), uiDatalen);
            Http_EncMsgBody(pstOgctHead, MOS_BEND(pstMultiMedia->pstSendB), uiDatalen, &(pstMultiMedia->stPlatEncryInf), ucStrPacketBuf, &iPacketBufLen);
            if (pstMultiMedia->stPlatEncryInf.iEncType == 0)
            {
                MOS_BLEN(pstMultiMedia->pstSendB) -= sizeof(ST_OGCT_PROTOCAL_HEAD);
            }
            MOS_MEMCPY(MOS_BEND(pstMultiMedia->pstSendB), ucStrPacketBuf, iPacketBufLen);
            MOS_BLEN(pstMultiMedia->pstSendB) += iPacketBufLen;
            // BUF_PRINTF_EX("1.4", ucStrPacketBuf, iPacketBufLen);/
            // printf("MOS_BLEN(pstMultiMedia->pstSendB): %d\r\n", MOS_BLEN(pstMultiMedia->pstSendB));
        }
    }
    else
    {
        // printf("............1.5\r\n");
        _UI uiWriteLen = 0;
        ST_MOS_SOCKBUF* pstTmp1 = MOS_NULL;
        ST_MOS_SOCKBUF* pstTmp2 = MOS_NULL;
        _UC* pucBuff = (_UC*)MOS_MALLOCCLR(uiDataLenEx + uiHeadlen);
        
        pstOgctHead = (ST_OGCT_PROTOCAL_HEAD*)pucBuff;
        Http_EncMsgHead(pstOgctHead, ucMsgType, ucMsgId, uiDataLenEx, pstMultiMedia->stPlatEncryInf.iEncType);
        
        // 有body才能调用Http_EncMsgBody，不然iPacketBufLen等于16 造成内存越界
        if (uiDataLenEx > 0)
        {
            MOS_MEMCPY(pucBuff + uiHeadlen, pucData, uiDatalen);
            Http_EncMsgBody(pstOgctHead, pucBuff + uiHeadlen, uiDatalen, &(pstMultiMedia->stPlatEncryInf), ucStrPacketBuf, &iPacketBufLen);
            
            MOS_MEMCPY(pucBuff + uiHeadlen, ucStrPacketBuf, iPacketBufLen);
        }

        pstTmp1 = pstMultiMedia->pstSendB;
        // 查找链表最后一个buf
        while (pstTmp1->pstNext)
        {
            pstTmp1 = pstTmp1->pstNext;
        }
        uiBuffLen = pstMultiMedia->uiPayloadLen - MOS_BOFF(pstTmp1) - MOS_BLEN(pstTmp1);
        
        while (uiDataLenEx + uiHeadlen - uiWriteLen > uiBuffLen)
        {
            MOS_MEMCPY(MOS_BEND(pstTmp1), pucBuff + uiWriteLen, uiBuffLen);
            MOS_BLEN(pstTmp1) += uiBuffLen;
            uiWriteLen += uiBuffLen;
            pstTmp2 = Mos_PopSockBuf(pstMultiMedia->hSockBuffPool);
            pstTmp1->pstNext = pstTmp2;
            pstTmp1 = pstTmp2;
            uiBuffLen = pstMultiMedia->uiPayloadLen;
        }
        MOS_MEMCPY(MOS_BEND(pstTmp1), pucBuff + uiWriteLen, uiDataLenEx + uiHeadlen - uiWriteLen);
        MOS_BLEN(pstTmp1) +=  uiDataLenEx + uiHeadlen - uiWriteLen;
        MOS_FREE(pucBuff);
    }
    Mos_MutexUnLock(&pstMultiMedia->hMutexSendB);

    // sleep(1);
    MOS_FREE(ucStrPacketBuf);
    return uiDataLenEx + sizeof(ST_OGCT_PROTOCAL_HEAD);
}

// 发送未验证数据到流媒体服务器
_INT MsgMng_SendNotAuthToMultiMedia(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen)
{
    _UI uiBuffLen = 0;
    _UI uiMsgLen  =  MOS_HEX_NUM(uiDatalen);
    ST_OGCT_PROTOCAL_HEAD *pstOgctHead;

    if (pstMultiMedia->stPlatEncryInf.iEncType == 0)
    {
        uiMsgLen = uiDatalen;
    }

    // 设备回复的数据 包头加加密后的接送数据
    _INT iPacketBufLen = 0;
    _UC  *ucStrPacketBuf = (_UC *)MOS_MALLOCCLR(uiMsgLen + sizeof(ST_OGCT_PROTOCAL_HEAD) + 1);
    //iEncType为0时，执行Http_EncMsgBody后ucStrPacketBuf会包含pucData+ST_OGCT_PROTOCAL_HEAD

    if(pstMultiMedia->uiConnectFlag != EN_MEDIA_CONNECT_FLAG_CONNECTED)
    {
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"pstMultiMedia->uiConnectFlag != 2 mark=%s", pstMultiMedia->aucMaskName);
        MOS_FREE(ucStrPacketBuf);
        return MOS_ERR;
    }
    
    Mos_MutexLock(&pstMultiMedia->hMutexSendB);
    uiBuffLen = pstMultiMedia->uiPayloadLen - MOS_BOFF(pstMultiMedia->pstSendB) - MOS_BLEN(pstMultiMedia->pstSendB);

    if(uiMsgLen + sizeof(ST_OGCT_PROTOCAL_HEAD) <= uiBuffLen)
    {
        pstOgctHead = (ST_OGCT_PROTOCAL_HEAD*)MOS_BEND(pstMultiMedia->pstSendB);
        // 加密报文头
        Http_EncMsgHead(pstOgctHead, ucMsgType, ucMsgId, uiMsgLen, pstMultiMedia->stPlatEncryInf.iEncType);
        
        MOS_BLEN(pstMultiMedia->pstSendB) += sizeof(ST_OGCT_PROTOCAL_HEAD);
        MOS_MEMCPY(MOS_BEND(pstMultiMedia->pstSendB), pucData, uiDatalen);
        if(uiMsgLen - uiDatalen > 0)
        {
            MOS_MEMSET(MOS_BEND(pstMultiMedia->pstSendB) + uiDatalen, 0, uiMsgLen - uiDatalen);
        }

        // 加密json数据
        Http_EncMsgBody(pstOgctHead,MOS_BEND(pstMultiMedia->pstSendB),uiDatalen,&pstMultiMedia->stPlatEncryInf, ucStrPacketBuf, &iPacketBufLen);

        // BUF_PRINTF_EX("head: ", MOS_BPTR(pstMultiMedia->pstSendB), MOS_BLEN(pstMultiMedia->pstSendB));
        // 如果iEncType为0，则ucStrPacketBuf包含head，因此除去pstSendB的head
        if (pstMultiMedia->stPlatEncryInf.iEncType == 0)
        {
            MOS_BLEN(pstMultiMedia->pstSendB) -= sizeof(ST_OGCT_PROTOCAL_HEAD);
        }

        MOS_MEMCPY(MOS_BEND(pstMultiMedia->pstSendB), ucStrPacketBuf, iPacketBufLen);

        MOS_BLEN(pstMultiMedia->pstSendB) += iPacketBufLen;

        // BUF_PRINTF_EX("out: ", MOS_BPTR(pstMultiMedia->pstSendB), MOS_BLEN(pstMultiMedia->pstSendB));
    }
    Mos_MutexUnLock(&pstMultiMedia->hMutexSendB);
    MOS_FREE(ucStrPacketBuf);
    return uiMsgLen + sizeof(ST_OGCT_PROTOCAL_HEAD);
}


_INT MsgMng_MultiMediaSendMsg(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC *pucPeerId,_UI uiReqId, _UC ucMsgType,_UC ucMsgId,
                    _UC *pucMsgBuff,_INT iMsgLen,PFUN_MSGMNG_MULTIMEDIA_RSPDATACB pFunRspDataCb)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pucMsgBuff);

    _INT iRet = MOS_OK;
    ST_MSGMNG_MULTIMEDIA_RSP_NODE *pstRspNode = MOS_NULL;

    if(pFunRspDataCb != MOS_NULL)
    {
        // 申请登录流媒体服务器的回复数据内存
        pstRspNode = MsgMng_MultiMediaMallocRspNode(uiReqId,ucMsgType,ucMsgId,pFunRspDataCb);
    }

    if(MOS_STRCMP(pucPeerId,MSGMNG_CMD_SERVER_ID) == 0)
    {
        // 发送登录请求数据到流媒体服务器
        iRet = MsgMng_SendDataToMultiMedia(pstMultiMedia,ucMsgType,ucMsgId,pucMsgBuff,iMsgLen);
    }
    else
    {
        // 发送数据
        // iRet = Http_SendDataToPeer(pucPeerId,ucMsgType,ucMsgId,pucMsgBuff,iMsgLen);
    }

    if(iRet <= 0)
    {
        if(pstRspNode != MOS_NULL)
        {
            pstRspNode->ucUseFlag = 0;
        }
        return MOS_ERR;
    }
    return MOS_OK;
}

// 处理接受到流媒体服务器下发的信令 (解密解json包)
_INT MsgMng_ProcMultiMediaRecv(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    _INT iRetLen = 0;
    _BOOL bClosed = MOS_FALSE;
    _UI uiByteLen = pstMultiMedia->uiPayloadLen - MOS_BOFF(pstMultiMedia->pstRecvB) - MOS_BLEN(pstMultiMedia->pstRecvB);

    // 接受到流媒体服务器下发的信令
    iRetLen = Mos_SocketRecv(pstMultiMedia->isockFd, ((_VPTR)(MOS_BEND(pstMultiMedia->pstRecvB))), uiByteLen, &bClosed);
    if(iRetLen > 0)
    {
        MOS_BLEN(pstMultiMedia->pstRecvB) += iRetLen;
        pstMultiMedia->uiHeartInterval = 0;
        // 处理流媒体服务器下发的信令 
        MsgMng_ParseMultiMediaData(pstMultiMedia);
        // MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR,"MsgMng_ProcMultiMediaRecv iRetLen: %d", iRetLen);
    }
    else if (bClosed == MOS_TRUE || iRetLen == 0) // recv ret 0 means the socket is closed by server
    {
        _UC aucBuff[128] = {0};
        MOS_SPRINTF(aucBuff, "socket recv error err %d len %d close %d", errno, uiByteLen, bClosed);
        MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_SOCKET_RECV_ERROR, (_UC*)aucBuff);

        // 未登录状态下，ipv6连接失败，尝试连接ipv4
        if (MsgMng_IPv6RollbackToIPv4(pstMultiMedia) == MOS_ERR) // socket接收失败
        {
            MsgMng_PrintLoginFailed(pstMultiMedia);
            MsgMng_CloseSocketAndDestoryHandle(pstMultiMedia,1);
            pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR;
        }
        return MOS_ERR;
    }
    return iRetLen;
}


// 处理流媒体服务器下发的信令 
_INT MsgMng_ParseMultiMediaData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);

    _INT iRetLen   = 0;

    if(MOS_BLEN(pstMultiMedia->pstRecvB) < sizeof(ST_OGCT_PROTOCAL_HEAD))
    {
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"Cmd Server recv data len err");
        return MOS_OK;
    }

    // BUF_PRINTF("Mos_SocketRecv", MOS_BPTR(pstMultiMedia->pstRecvB), MOS_BLEN(pstMultiMedia->pstRecvB));
    // 处理流媒体服务器下发的信令
    iRetLen = MsgMng_DecodeMultiMediaData(pstMultiMedia,MOS_BPTR(pstMultiMedia->pstRecvB), MOS_BLEN(pstMultiMedia->pstRecvB));
    if(iRetLen > 0){
        MOS_BOFF(pstMultiMedia->pstRecvB) += iRetLen;
        MOS_BLEN(pstMultiMedia->pstRecvB) -= iRetLen;
    }
    if(MOS_BLEN(pstMultiMedia->pstRecvB) > 0){
        MOS_MEMMOVE(pstMultiMedia->pstRecvB->aucPayload, MOS_BPTR(pstMultiMedia->pstRecvB), MOS_BLEN(pstMultiMedia->pstRecvB));
        MOS_BOFF(pstMultiMedia->pstRecvB) = 0;
    }else{
        Mos_InitSockBuf(pstMultiMedia->pstRecvB);
    }
    return MOS_OK;
}


// 处理接收到的信令data数据
_INT MsgMng_DecodeMultiMediaData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC *pucMsgBuff,_INT iMsgBuffLen)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    MOS_PARAM_NULL_RETERR(pucMsgBuff);

    _INT iRet      = 0;
    _INT iParseLen = 0;

    do
    {
        // 处理接收到的信令data数据
        iRet = MsgMng_ProcMultiMediaMsg(pstMultiMedia,pucMsgBuff,iMsgBuffLen - iParseLen); 
        if(iRet <= 0)
        {
            break;
        }
        iParseLen   += iRet;
        pucMsgBuff  += iRet;
    }while(iParseLen < iMsgBuffLen);

    if(iRet < 0)
    {
        while(iMsgBuffLen - iParseLen > 0)
        {
            if(pucMsgBuff[0] == '#' && pucMsgBuff[1] == '$')
            {
                break;
            }
            iParseLen++;
            pucMsgBuff++;
        }
    }
    return iParseLen;
}


/***********************************************************************
接受到的请求处理节点
************************************************************************/
static ST_MSGMNG_MULTIMEDIA_ACTIVE_NODE *MsgMng_MultiMediaFindActiveNode(_UC usMsgType,_UC ucMsgId)
{
    ST_MSGMNG_MULTIMEDIA_ACTIVE_NODE *pstActiveMsgNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;

    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stActiveFunList, pstActiveMsgNode, stIterator)
    {
        if(pstActiveMsgNode->usMsgType == usMsgType && pstActiveMsgNode->ucMsgId == ucMsgId )
        {
            return pstActiveMsgNode;
        }
    }
    return MOS_NULL;
}

// 处理流媒体服务器下发的信令
_INT MsgMng_ProcMultiMediaMsg(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC *pucMsgBuff,_INT iMsgBuffLen)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    MOS_PARAM_NULL_RETERR(pucMsgBuff);

    // FILE *fp = MOS_NULL;
    _INT iSeqID = 0;
    _UC aucMethod[8];
    _UC *pucMethod = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_OGCT_PROTOCAL_HEAD stOgctHead;
    ST_HTTP_ENCRYPTO_INF *pstEncrypInf = MOS_NULL;
   
    if(iMsgBuffLen < sizeof(stOgctHead))
    {
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"parse msg head err");
        return 0;
    }
    MOS_MEMCPY(&stOgctHead, pucMsgBuff, sizeof(ST_OGCT_PROTOCAL_HEAD));
    if(stOgctHead.aucheck[0] != '#' || stOgctHead.aucheck[1] != '$')
    {
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"parse msg head err");
        return -1;
    }
    
    stOgctHead.usBodyLen = MOS_INET_NTOHS(stOgctHead.usBodyLen);
    if(stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD) > (_US)iMsgBuffLen)
    {
        _UC *temp = MOS_NULL;
        temp = stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD);
        // MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"parse msg len err, headlen: %d, datalen: %d", stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD), (_US)iMsgBuffLen);
        return 0;
    }
    
    pucMsgBuff  += sizeof(ST_OGCT_PROTOCAL_HEAD);
    iMsgBuffLen -= sizeof(ST_OGCT_PROTOCAL_HEAD);

    if(pstMultiMedia->ucLoginFlag != EN_MEDIA_SERVER_LOGINED)
    {
        pstEncrypInf = &pstMultiMedia->stPlatEncryInf;
    }
    else
    {
        pstEncrypInf = &pstMultiMedia->stEncrypInf;
    }
    if(stOgctHead.ucMsgType == EN_OGCT_METHOD_ENCKEY && stOgctHead.ucMsgId == EN_OGCT_METHOD_ENCKEY_ERR_REQ)
    {
        MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR,"Recv EncKey Change notice");
        pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_ERROR;
        return sizeof(ST_OGCT_PROTOCAL_HEAD);
    }
    if(stOgctHead.usBodyLen == 0)
    {
        return sizeof(ST_OGCT_PROTOCAL_HEAD);
    }

    if (stOgctHead.ucMsgType != EN_OGCT_METHOD_DATA)
    {
        Http_DecMsgBody(stOgctHead.ucEncFlag,pucMsgBuff,stOgctHead.usBodyLen,pstEncrypInf);

        MOS_PRINTF_DEBUG("pucInOutBody: %s\r\n", pucMsgBuff);

        hRoot = Adpt_Json_Parse(pucMsgBuff);
        do
        {
            if(hRoot == MOS_NULL)
            {
                MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "parse net msg body err");
                break;
            }
            MOS_SPRINTF(aucMethod, "%02X%02X",stOgctHead.ucMsgType, stOgctHead.ucMsgId);
            // 解析 方法METHOD 字段
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"), &pucMethod);

            if(MOS_STRCMP(aucMethod, pucMethod) != 0)
            {
                MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "msg check method err");
                break;
            }

            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"), &iSeqID);
            
            // 处理流媒体服务器下发的信令
            MsgMng_MultiMediaDispatchMsg(pstMultiMedia,MSGMNG_CMD_SERVER_ID,stOgctHead.ucMsgType, stOgctHead.ucMsgId,hRoot);
            
        }while(0);
        
        Adpt_Json_Delete(hRoot);
    }
    else if ((stOgctHead.ucMsgType == EN_OGCT_METHOD_DATA) && (stOgctHead.ucMsgId == EN_OGCT_MEDIA_DATA_PUSHSTREAM)) //audio data
    {
        _INT iOffset = 0;
        _UC  ucAudioBufer[MSGMNG_MULTI_MEDIA_AUDIO_PLAY_SIZE] = {0};
        _UI  uiEncLen = stOgctHead.usBodyLen;

        if (uiEncLen >= 32)
        {
            uiEncLen = 32;
            Http_DecMsgBodyMedia(stOgctHead.ucEncFlag, pucMsgBuff, uiEncLen, pstEncrypInf);
        }
        else if (uiEncLen >= 16)
        {
            uiEncLen = 16;
            Http_DecMsgBodyMedia(stOgctHead.ucEncFlag, pucMsgBuff, uiEncLen, pstEncrypInf);
        }

        MOS_MEMCPY(ucAudioBufer, pucMsgBuff, (iMsgBuffLen>sizeof(ucAudioBufer))?sizeof(ucAudioBufer):iMsgBuffLen);

        ST_MEDIA_PROTOCAL_HEAD *mediaHeader = (ST_MEDIA_PROTOCAL_HEAD *)ucAudioBufer;
        static _INT oldSeqId = -1;
        mediaHeader->usChannel  = MOS_INET_NTOHS(mediaHeader->usChannel);
        mediaHeader->usSeqId    = MOS_INET_NTOHS(mediaHeader->usSeqId);
        mediaHeader->iTimeStamp = MOS_INET_NTOHL(mediaHeader->iTimeStamp);
        mediaHeader->iFrameLen  = MOS_INET_NTOHL(mediaHeader->iFrameLen);
        if (oldSeqId == -1)
        {
          oldSeqId = mediaHeader->usSeqId;
        }
        if (stOgctHead.usBodyLen  != (mediaHeader->iFrameLen+sizeof(ST_MEDIA_PROTOCAL_HEAD)))
        {
            MOS_PRINTF("recive audio data error, incrroct length:%d, %d\n", stOgctHead.usBodyLen, (mediaHeader->iFrameLen+sizeof(ST_MEDIA_PROTOCAL_HEAD)));
            return stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD);
        }
        else
        {
            if (pstMultiMedia->m_bEnableSpeaker && (pstMultiMedia->m_hAudioPlay != MOS_NULL) && mediaHeader->iFrameLen>0)
            {
                if (oldSeqId != (mediaHeader->usSeqId-1))
                {
                    MOS_PRINTF("recive wrong speaker data!!old:%d new:%d!\n", oldSeqId, mediaHeader->usSeqId);
                }
                oldSeqId = mediaHeader->usSeqId;
                // if (fp == MOS_NULL)
                // {
                //     fp = fopen("./abc.g711a", "a+");
                // }

                // if (fp)
                // {
                //     printf("timestamp: %ul\r\n", mediaHeader->iTimeStamp);
                //     fwrite(ucAudioBufer+sizeof(ST_MEDIA_PROTOCAL_HEAD), mediaHeader->iFrameLen, 1, fp);
                //     fclose(fp);
                // }

                pstMultiMedia->ullReiveAudioTime = Mos_GetLLTickCount();
                // getDiffTimems(&pstMultiMedia->m_tReiveAliveTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
                Media_AudioPlayWriteFrame(pstMultiMedia->m_hAudioPlay, ucAudioBufer+sizeof(ST_MEDIA_PROTOCAL_HEAD),
                                       mediaHeader->iFrameLen, mediaHeader->iTimeStamp);
            }
        }
    }
    
    return stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD);
}

// 处理流媒体服务器下发的信令
_INT MsgMng_MultiMediaDispatchMsg(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    Qp_CountIF_Post(COUNT_TYPE_CMD, COUNT_VALUE_SUCCESS, COUNT_VALUE_SUCCESS);

    _UI uiSeqID = 0;
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"SEQID"), (_INT*)&uiSeqID);
    // 下发的信令命令
    if(ucMsgId%2 == 0)
    {
        //FIXME: 查找对应的信令的sdk回调接口
        ST_MSGMNG_MULTIMEDIA_ACTIVE_NODE *pstActiveMsgNode = MsgMng_MultiMediaFindActiveNode(ucMsgType,ucMsgId);
        if(pstActiveMsgNode == MOS_NULL || pstActiveMsgNode->pFunActiveProc == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR,"FIND NO MsgCt CALLback FUNC");
            MsgMng_RecvMultiMediaNotSupportStream(pstMultiMedia, pucPeerId, uiSeqID, ucMsgType, ucMsgId, hJsonRoot);
            return MOS_ERR;
        }

        // 回调对应的sdk接口  传入hJsonRoot数据
        pstActiveMsgNode->pFunActiveProc(pstMultiMedia,pucPeerId,uiSeqID,hJsonRoot);
    }
    // 回复下发的信令的命令 +1
    else
    {
        ST_MSGMNG_MULTIMEDIA_RSP_NODE *pstRspMsgNode = MsgMng_MultiMediaFindRspNode(uiSeqID);
        if(pstRspMsgNode == MOS_NULL || pstRspMsgNode->pfunRspMsgProc == MOS_NULL)
        {
            return MOS_ERR;
        }
        pstRspMsgNode->pfunRspMsgProc(pstMultiMedia,uiSeqID,hJsonRoot);
        pstRspMsgNode->pfunRspMsgProc = MOS_NULL;
        pstRspMsgNode->ucUseFlag = 0;
    }
    return MOS_OK;
}

// 注册信令
_VOID MsgMng_MultiMediaRegistActiveFunc(_UC usMsgType,_UC ucMsgId,PFUN_MSGMNG_MULTIMEDIA_ACTIVEPROC pFunActiveMsgProc)
{
    ST_MSGMNG_MULTIMEDIA_ACTIVE_NODE *pstActiveMsgNode = MOS_NULL;

    Mos_MutexLock(&Media_GetTaskMng()->hMutex);
    // 查找信令节点
    pstActiveMsgNode = MsgMng_MultiMediaFindActiveNode(usMsgType,ucMsgId);
    if(pstActiveMsgNode != MOS_NULL)
    {
        Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
        return;
    }
    // 初始化信令
    pstActiveMsgNode = (ST_MSGMNG_MULTIMEDIA_ACTIVE_NODE*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_MULTIMEDIA_ACTIVE_NODE));
    pstActiveMsgNode->ucMsgId        = ucMsgId;
    pstActiveMsgNode->usMsgType      = usMsgType;
    pstActiveMsgNode->pFunActiveProc = pFunActiveMsgProc;
    MOS_LIST_ADDTAIL(&Media_GetTaskMng()->stActiveFunList, pstActiveMsgNode);
    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
    return;
}

_UC* MsgMng_BuildMultiMediaRspJson(_UI uiSeqID, _UC ucMsgType, _UC ucMsgId, _INT iStreamId, _INT iCode)
{
    _UC *pStrTmp     = MOS_NULL;
    _UC aucMethod[8] = {0};
    //_UC *pRspStr = "{\"METHOD\":\"221B\",\"SEQID\":\"%d\",\"CODE\":\"0\",\"BODY\":{\"VideoParam\":{\"EncType\":\"2\",\"FrameRate\":\"17\",\"Width\":\"1920\",\"Height\":\"1080\",\"LensType\":\"0\",\"VideoCircle\":{},\"Radius\":\"0\",\"Angle\":\"0\",\"C1X\":\"0\",\"C1Y\":\"0\",\"C2Y\":\"0\",\"C2Y\":\"0\",\"VideoDistortion\":{},\"Fx\":\"0\",\"Fy\":\"0\",\"Fa\":\"0\",\"Fb\":\"0\",\"Scale\":\"0\"},\"AudioParam\":{\"EncType\":\"2\",\"SampleRate\":\"8000\",\"Channel\":\"1\",\"Depth\":\"16\"}}}";

    ST_CFG_VIDEODES *pstVideoDes    = MOS_NULL;
    pstVideoDes  = Config_GetVideoDes(0, iStreamId);
    ST_ZJ_AUDIO_PARAM *pstAudioParam = Config_GetCamAudioParm(0);

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    MOS_SPRINTF(aucMethod, "%02X%02X", ucMsgType, ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iCode));

    JSON_HANDLE hBody = Adpt_Json_CreateObject();

    JSON_HANDLE hVBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiEncodeType));
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiFramerate));
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"Width",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiWidth));
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"Height",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiHeight));
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"LensType",Adpt_Json_CreateStrWithNum(0));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"VideoParam",hVBody);

    JSON_HANDLE hABody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hABody,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(pstAudioParam->uiEncodeType));
    Adpt_Json_AddItemToObject(hABody,(_UC*)"SampleRate",Adpt_Json_CreateStrWithNum(pstAudioParam->uiSampleRate));
    Adpt_Json_AddItemToObject(hABody,(_UC*)"Channel",Adpt_Json_CreateStrWithNum(pstAudioParam->uiChannel));
    Adpt_Json_AddItemToObject(hABody,(_UC*)"Depth",Adpt_Json_CreateStrWithNum(pstAudioParam->uiDepth));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"AudioParam",hABody);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot); 
    //MOS_PRINTF("SEND video info:%s\n", pStrTmp);
    return pStrTmp;
}

// 221A
_INT MsgMng_RecvMultiMediaAskStartStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp      = NULL;
    _UC *pucCamId     = MOS_NULL;
    _UI *pucStreamId  = MOS_NULL;
    _UC *pucAudioId   = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    } 
    _UC *pStReciv = Adpt_Json_Print(hJsonRoot);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "RecvMultiMediaAskStartStream req: %s", pStReciv);
    MOS_FREE(pStReciv);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&pucCamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"StreamId"),&pucStreamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AudioID"),&pucAudioId);

    pStrTmp = MsgMng_BuildMultiMediaRspJson(uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_START_PUSH_RSP, MOS_ATOI(pucStreamId), 0);
    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_START_PUSH_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
    
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "send StartStreamresp:%s", pStrTmp);

    // 开流
    if (MsgMng_MultiMediaStart(pstMultiMedia, MOS_ATOI(pucStreamId)) == MOS_OK)
    {   
        MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_START_STREAM_SUCCESS, "live task start stream success!");
    }
    else
    {
        MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_START_STREAM_FAIL, "live task start stream fail!");
    }

    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 221C
_INT MsgMng_RecvMultiMediaAskPauseStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp      = NULL;
    _UC *pucCamId     = MOS_NULL;
    _UC *pucStreamId  = MOS_NULL;
    _UC *pucAudioId   = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;
    //if(MOS_STRCMP(pucPeerId, MSGMNG_CMD_SERVER_ID) == 0)
    //{
    //}

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    } 
    _UC *pStReciv = Adpt_Json_Print(hJsonRoot);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "RecvMultiMediaAskPauseStream req: %s", pStReciv);
    MOS_FREE(pStReciv);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&pucCamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"StreamId"),&pucStreamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AudioID"),&pucAudioId);

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_PAUSE_PUSH_RSP,0);
    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_PAUSE_PUSH_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    // 暂停流
    MsgMng_MultiMediaPause(pstMultiMedia,MOS_ATOI(pucStreamId));
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "send pauseStreamresp:%s", pStrTmp);
    MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_PAUSE_STREAM_SUCCESS, "live task pause stream!");
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT MsgMng_RecvMultiMediaNotSupportStream(_VPTR hConn, _UC *pucPeerId, _UI uiSeqId, _UC ucMsgType, _UC ucMsgId, _VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp = NULL;

    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    _UC *pStReciv = Adpt_Json_Print(hJsonRoot);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "RecvMultiMediaStream req is Not Exit: %s", pStReciv);
    MOS_FREE(pStReciv);

    pStrTmp = MsgMng_BuildNotSupportJson(uiSeqId,ucMsgType, ucMsgId + 1, CMD_NOT_SUPPORT_ERR);
    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,ucMsgType, ucMsgId + 1,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
    
    MOS_FREE(pStrTmp);

    return MOS_OK;
}

// 221E
_INT MsgMng_RecvMultiMediaAskResumeStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp     = NULL;
    _UC *pucCamId    = MOS_NULL;
    _UC *pucStreamId = MOS_NULL;
    _UC *pucAudioId  = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;
    //if(MOS_STRCMP(pucPeerId, MSGMNG_CMD_SERVER_ID) == 0)
    //{
    //}

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    } 
    _UC *pStReciv = Adpt_Json_Print(hJsonRoot);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "RecvMultiMediaAskResumeStream req: %s", pStReciv);
    MOS_FREE(pStReciv);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&pucCamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"StreamId"),&pucStreamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AudioID"),&pucAudioId);

    pStrTmp = MsgMng_BuildMultiMediaRspJson(uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_RESUME_PUSH_RSP, MOS_ATOI(pucStreamId), 0);
    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_RESUME_PUSH_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    // 恢复流
    MsgMng_MultiMediaResume(pstMultiMedia,MOS_ATOI(pucStreamId));
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "send resumeStreamresp:%s", pStrTmp);
    MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_RESUME_STREAM_SUCCESS, "live task resume stream!");
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 2226
_INT MsgMng_RecvMultiMediaAskCloseStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp      = NULL;
    _UC *pucCamId     = MOS_NULL;
    _UC *pucStreamId  = MOS_NULL;
    _UC *pucAudioId   = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;
    //if(MOS_STRCMP(pucPeerId, MSGMNG_CMD_SERVER_ID) == 0)
    //{
    //}

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    } 

    _UC *pStReciv = Adpt_Json_Print(hJsonRoot);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "RecvMultiMediaAskCloseStream req: %s", pStReciv);
    MOS_FREE(pStReciv);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&pucCamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"StreamId"),&pucStreamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AudioID"),&pucAudioId);

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_CLOSE_STREAM_RSP,0);
    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_CLOSE_STREAM_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    // 关流
    MsgMng_MultiMediaClose(pstMultiMedia, MOS_ATOI(pucStreamId));
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "send closeStreamresp:%s", pStrTmp);
    MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_CLOSE_STREAM_SUCCESS, "live task close stream!");
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 2236
_INT MsgMng_RecvMultiMediaOpenAudioReverseStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp        = NULL;
    _INT iCamId         = 0;
    _INT iChannelId     = 0;
    _INT iOpenFlag      = 0;
    ST_ZJ_AUDIO_PARAM   audioParams = {0};
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");
    if(hDataObj == MOS_NULL)
    {
        return MOS_OK;
    } 
    _UC *pStReciv = Adpt_Json_Print(hJsonRoot);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "RecvMultiMediaOpenAudioReverseStream req: %s", pStReciv);
    MOS_FREE(pStReciv);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CamID"),&iCamId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"ChannelID"), &iChannelId);

    JSON_HANDLE hAudioObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"AudioParam");
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioObj,(_UC*)"EncType"), &audioParams.uiEncodeType);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioObj,(_UC*)"SampleRate"), &audioParams.uiSampleRate);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioObj,(_UC*)"Channel"), &audioParams.uiChannel);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioObj,(_UC*)"Depth"), &audioParams.uiDepth);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"##start speaker iChannelId:%d EncType:%d audiochannel:%d, depth:%d\n",
                iChannelId, audioParams.uiEncodeType, audioParams.uiChannel, audioParams.uiDepth);


    // open流
    if (MsgMng_MultiMediaOpenAudioReverse(pstMultiMedia, audioParams, iCamId, iChannelId) == MOS_ERR)
    {
        iOpenFlag = 0;
    }
    else
    {
        iOpenFlag = 1;
    }
    pStrTmp = MsgMng_BuildOpenAudioReverseStreamRspJson(iCamId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_OPEN_AUDIO_REVERSE_STREAM_RSP, iOpenFlag);

    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_OPEN_AUDIO_REVERSE_STREAM_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "send OpenAudioReverseStream resp:%s, openflag:%d", pStrTmp, iOpenFlag);
    if (iOpenFlag == 1)
    {
        MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_VOICE_TALK_OPEN_SUCCESS, "live task open audio stream success!");
    }
    else
    {
        _UC aucErrString[128] = {0};
        MOS_VSNPRINTF(aucErrString, sizeof(aucErrString), "live task open audio stream fail! spk[open-%d,enable-%d]", Config_GetCamaraMng()->uiSpkOpenFlag, pstMultiMedia->m_bEnableSpeaker);
        MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_VOICE_TALK_OPEN_FAIL, aucErrString);
    }
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 2238
_INT MsgMng_RecvMultiMediaCloseAudioReverseStream(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp    = NULL;
    _INT iCamId     = 0;
    _INT iChannelId = 0;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    } 
    _UC *pStReciv = Adpt_Json_Print(hJsonRoot);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "RecvCloseAudioReverseStream req: %s", pStReciv);
    MOS_FREE(pStReciv);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&iCamId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID"), &iChannelId);
    // Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Code"), &pStrTmp);


    pStrTmp = MsgMng_BuildCloseAudioReverseStreamRspJson(iCamId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_CLOSE_AUDIO_REVERSE_STREAM_RSP);
    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_CLOSE_AUDIO_REVERSE_STREAM_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    // 关流
    MsgMng_MultiMediaCloseAudioReverse(pstMultiMedia, iCamId, iChannelId);

    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "send CloseAudioReverseStream resp:%s", pStrTmp);
    MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_VOICE_TALK_CLOSE_SUCCESS, "live task close audio stream!");
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 2220
_INT MsgMng_RecvMultiMediaAskIdr(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pStrTmp      = NULL;
    _UC *pucCamId     = MOS_NULL;
    _UC *pucStreamId  = MOS_NULL;
    _UC *pucAudioId   = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    //if(MOS_STRCMP(pucPeerId, MSGMNG_CMD_SERVER_ID) == 0)
    //{
    //}
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&pucCamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"StreamId"),&pucStreamId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AudioID"),&pucAudioId);
    
    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_NEED_KEYFRAME_RSP,0);
    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_NEED_KEYFRAME_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    // 请求I帧
    if (ZJ_GetFuncTable()->pfunVideoNeedIFrame)
    {
        ZJ_GetFuncTable()->pfunVideoNeedIFrame(MOS_ATOI(pucStreamId), EN_ZJ_KEYFRAME_QUALITY_NORMAL);
    }
    MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_IDR_SUCCESS, "live task ask I frame!");
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

// 2222
_INT MsgMng_RecvMultiMediaAskUpdateKey(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT iEncType  = 2;
    _UC *pStrTmp   = MOS_NULL;
    _UC *pucEncKey = MOS_NULL;
    _UC *pucEncLv  = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA* pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    } 
    _UC *pStReciv = Adpt_Json_Print(hJsonRoot);
    // MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "RecvAskUpdateKey req: %s", pStReciv);
    MOS_FREE(pStReciv);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncType"),&iEncType);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncKey"),&pucEncKey);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncLoad"),&pucEncLv);

    if(MOS_STRCMP(pucPeerId, MSGMNG_CMD_SERVER_ID) == 0)
    {
        MsgMng_SetMultiMediaLinkEncrypPlatInf(0, iEncType,pucEncKey,pucEncLv);
    }

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_UPDATE_KEY_NTC_RSP,0);
    MsgMng_MultiMediaSendMsg(pstMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_UPDATE_KEY_NTC_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    // TODO: 服务器端暂时没做
    // MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR, "send AskUpdateKey resp:%s", pStrTmp);
    MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_UPDATE_ENCKEY_SUCCESS, "live task update key!");
    MOS_FREE(pStrTmp);
    return MOS_OK;
}
// 流媒体服务器分配卡回看 2240
_INT MsgMng_RecvMultiMediaPlayBackAddrNtc(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PRINTF("A streaming media service allocation notification to the device %s\n", __FUNCTION__);
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _CTIME_T cTime              = 0;
    _UC aucMethod[8]            = {0};
    _INT iResultCode            = 0;
    _UI uiCamId                 = 0;
    _UI uiDownFlag              = 0;
    _UI uiChannelId             = 0;
    _UI uiPlayBackMode          = 0;
    _UI uiVideoWin              = 100;
    _UI uiAudioWin              = 100;  
    _UC *pucResultMsg           = MOS_NULL;
    _UC *pStrTmp                = MOS_NULL;
    _UC *pucSessionId           = MOS_NULL;
    _UC *pucClientToken         = MOS_NULL;  
    _UC *pucPlayBackStartTime   = MOS_NULL;
    JSON_HANDLE hRoot           = MOS_NULL;
    JSON_HANDLE hBody           = MOS_NULL;
    JSON_HANDLE hVParam         = MOS_NULL;
    JSON_HANDLE hAParam         = MOS_NULL;
    _UC aucErrString[128]       = {0};
    _INT              iAdjustTime = 0;    
    ST_RDSTG_FILEDES  stRDFileDes = {0};
    ST_CFG_VIDEODES   stVideoDes  = {0};
    ST_ZJ_AUDIO_PARAM stAudioParm = {0};
    _RDFILEFD *pstRdStg_fileFD    = MOS_NULL;

    ST_MSGMNG_MULTI_MEDIA *pstMultiMedia     = MOS_NULL;
    ST_MSGMNG_MULTI_MEDIA *pstRootMultiMedia = (ST_MSGMNG_MULTI_MEDIA *)hConn;
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"FROM"),&pucClientToken);
    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        return MOS_OK;
    }
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SessionId"),&pucSessionId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Time"),&pucPlayBackStartTime);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID"),&uiChannelId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&uiCamId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"DownFlag"),&uiDownFlag);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PlayFlag"),&uiPlayBackMode);    // 0:d单文件回放 1：时间轴连续回放

    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,">>>>recive startPlaybsck time:%s chan:%d camId:%d DownFlag:%d PlayBackMode：%d, uiVideoWin:%d uiAudioWin:%d",
               pucPlayBackStartTime, uiChannelId, uiCamId, uiDownFlag, uiPlayBackMode, uiVideoWin, uiAudioWin);
    do 
    {   
        // 打开录像文件 - 判断是否存在，提取视频参数
        pstRdStg_fileFD = RdStg_OpenPlayBackFile(pucPlayBackStartTime, &iAdjustTime, 0);
        if (MOS_NULL == pstRdStg_fileFD)
        {
            MOS_VSNPRINTF(aucErrString, sizeof(aucErrString), "playback file %s open error", pucPlayBackStartTime);

            iResultCode = 10004;
            pucResultMsg = aucErrString;
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, aucErrString);
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_PLAYBACK_NTC_FAIL, (_UC*)aucErrString);
            break;
        }
        RdStg_ReadFileDes((_RDFILEFD)pstRdStg_fileFD, &stVideoDes, &stAudioParm);
        RdStg_ClosePlayBackFile(pstRdStg_fileFD);

        pstMultiMedia = MsgMng_MultiMediaMallocConnect();

        // 取live链接加密参数和流媒体IP数据
        MsgMng_SetMultiMediaLinkEncrypPlatInf(pstMultiMedia,
                                            pstRootMultiMedia->stPlatEncryInf.iEncType,
                                            pstRootMultiMedia->stPlatEncryInf.aucEncKey,
                                            pstRootMultiMedia->stPlatEncryInf.aucEncLv);

        MsgMng_SetMultiMediaLinkEncrypInf(pstMultiMedia,
                                        pstRootMultiMedia->stEncrypInf.iEncType,
                                        pstRootMultiMedia->stEncrypInf.aucEncKey,
                                        pstRootMultiMedia->stEncrypInf.aucEncLv);

        pstMultiMedia->stInetIPv4.u.uiIp = pstRootMultiMedia->stInetIPv4.u.uiIp;
        pstMultiMedia->stInetIPv4.usType = pstRootMultiMedia->stInetIPv4.usType;
        pstMultiMedia->stInetIPv4.usPort = pstRootMultiMedia->stInetIPv4.usPort;

        pstMultiMedia->stInetIPv6.usType = pstRootMultiMedia->stInetIPv6.usType;
        pstMultiMedia->stInetIPv6.usPort = pstRootMultiMedia->stInetIPv6.usPort;
        MOS_MEMCPY( pstMultiMedia->stInetIPv6.u.aucIpv6, pstRootMultiMedia->stInetIPv6.u.aucIpv6, MOS_INET_IPV6_ADDR_SIZE);
    
        MOS_STRCPY(pstMultiMedia->pucResourceID, pstRootMultiMedia->pucResourceID);

        pstMultiMedia->ucStatus = EN_MSGMNG_MULTI_MEDIA_STATUS_STARTCONN;
        pstMultiMedia->uiType   = EN_MSGMNG_MULTI_MEDIA_PLAYBACK;

        // 保存状态值
        MOS_STRCPY(pstMultiMedia->stLoginInfo.pucPeerId, pucPeerId);
        pstMultiMedia->stLoginInfo.uiSeqId  = uiSeqId;
        if (uiDownFlag)
        {
            pstMultiMedia->uiTheardSleepMescond = 4;
        }
        else
        {
            pstMultiMedia->uiTheardSleepMescond = 5;
        }

        // 初始化数据-卡回放
        MOS_STRCPY(pstMultiMedia->aucDevUID, Config_GetSystemMng()->aucDevUID);
        MOS_STRNCPY(pstMultiMedia->aucPBSessionId, pucSessionId, sizeof(pstMultiMedia->aucPBSessionId));
        MOS_STRNCPY(pstMultiMedia->aucPBClinetToken, pucClientToken, sizeof(pstMultiMedia->aucPBClinetToken));
        // 客户端的uiChannelId可能为两个字节数值，因此不能(uiCamId<<8|(uiChannelId0xff))实现
        pstMultiMedia->usChannel      = (uiCamId<<8|uiChannelId);// uiCamId用于兼容NVR, 目前默认为0
        pstMultiMedia->ucPBDownFlag   = uiDownFlag;
        pstMultiMedia->uiPBMode       = uiPlayBackMode;
        pstMultiMedia->uiPBFileEndFlag= 0;
        pstMultiMedia->ucPBPlayStatus = EN_PLAYBACK_STATUS_INIT;
        MOS_STRNCPY(pstMultiMedia->aucPBFilePath, pucPlayBackStartTime, sizeof(pstMultiMedia->aucPBFilePath));

        pstMultiMedia->uiMark = ++g_uiMultiMediaMark;
        MsgMng_MultiMediaGenerateMaskName(pstMultiMedia);
        
        if (MsgMng_MultiMediaAddConnectNode(pstMultiMedia, EN_MSGMNG_MULTI_MEDIA_PLAYBACK, MOS_NULL) == MOS_OK)
        {
            MOS_PRINTF("MsgMng_MultiMediaAddConnectNode uiConnectPlayBackCnt=%d\n", Media_GetTaskMng()->uiConnectPlayBackCnt);
        }
        else
        {
            iResultCode = 10011;
            pucResultMsg = (_UC*)"playback connect is max count";
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, pucResultMsg);    
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_PLAYBACK_NTC_FAIL, (_UC*)"playback connect max count");
            MsgMng_MultiMediaFreeConnect(pstMultiMedia);
            break;
        }
        
        if(MOS_ERR == Mos_ThreadCreate((_UC *)pstMultiMedia->aucMaskName, EN_THREAD_PRIORITY_NORMAL, MOS_THREAD_STACK_NORMAL_SIZE,
            MsgMng_MultiMediaThreadProc, pstMultiMedia, MOS_NULL, &pstMultiMedia->hMgrThread))
        {
            iResultCode = 10012;
            pucResultMsg = (_UC*)"playback thread create failed";
            MsgMng_MultiMediaFreeConnect(pstMultiMedia);
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, pucResultMsg);
            MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_PLAYBACK_NTC_FAIL, (_UC*)"playback task create pthread failed");
            break;
        }
    } while(0);

    // 回复JSON
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_PLAYBACK_ADDR_NTC_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"FROM",  Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"TO",  Adpt_Json_CreateString(pucClientToken));
    if (iResultCode != 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",  Adpt_Json_CreateStrWithNum(iResultCode));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",  Adpt_Json_CreateString(pucResultMsg));
        hBody = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hBody,(_UC*)"SessionId",   Adpt_Json_CreateString(pucSessionId));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",  Adpt_Json_CreateStrWithNum(iResultCode));

        hBody = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hBody,(_UC*)"SessionId",   Adpt_Json_CreateString(pucSessionId));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",   Adpt_Json_CreateStrWithNum(uiChannelId));
        // Adpt_Json_AddItemToObject(hBody,(_UC*)"VideoWinSize",Adpt_Json_CreateStrWithNum(uiVideoWin));
        // Adpt_Json_AddItemToObject(hBody,(_UC*)"AudioWinSize",Adpt_Json_CreateStrWithNum(uiAudioWin));
        
        hVParam = Adpt_Json_CreateObject();
#ifdef USER_RD_EXTERN_FILEDES
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(stRDFileDes.uiVideoEncType));   // 265
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(stRDFileDes.uiVideoFrameRate));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"Width",Adpt_Json_CreateStrWithNum(stRDFileDes.uiVideoWidth));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"Height",Adpt_Json_CreateStrWithNum(stRDFileDes.uiVideoHeight));
#endif
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(stVideoDes.stVideoPara.uiEncodeType));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(stVideoDes.stVideoPara.uiFramerate));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"Width",Adpt_Json_CreateStrWithNum(stVideoDes.stVideoPara.uiWidth));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"Height",Adpt_Json_CreateStrWithNum(stVideoDes.stVideoPara.uiHeight));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"LensType",Adpt_Json_CreateStrWithNum(0));
        Adpt_Json_AddItemToObject(hBody ,(_UC*)"VideoParam",hVParam);

        hAParam = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hAParam,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(stAudioParm.uiEncodeType));
        Adpt_Json_AddItemToObject(hAParam,(_UC*)"SampleRate",Adpt_Json_CreateStrWithNum(8000));
        Adpt_Json_AddItemToObject(hAParam,(_UC*)"Channel",Adpt_Json_CreateStrWithNum(1));
        Adpt_Json_AddItemToObject(hAParam,(_UC*)"Depth",Adpt_Json_CreateStrWithNum(16));
        Adpt_Json_AddItemToObject(hBody ,(_UC*)"AudioParam",hAParam);

        Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    }

    pStrTmp = Adpt_Json_Print(hRoot);
    MsgMng_MultiMediaSendMsg(pstRootMultiMedia,pucPeerId,uiSeqId,EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_PLAYBACK_ADDR_NTC_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,">>>reqid %d rsp get PlayBack Calender %s", uiSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);

    return MOS_OK;
}

// 2244
_INT MsgMng_RecvMultiMediaPlayBackClose(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UI uiChannelId     = 0;
    _UC aucMethod[8]    = {0};
    _UC *pStrTmp        = MOS_NULL;
    _UC* pucParamCode   = MOS_NULL;
    _UC *pucSessionId   = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;

    ST_MSGMNG_MULTI_MEDIA *pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

     // 解析json
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SessionId"),&pucSessionId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID"),&uiChannelId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Code"), &pucParamCode);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,">>>>recive close mulmedia session, code:%s",   pucParamCode);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_PLAYBACK_CLOSE_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"SessionId",Adpt_Json_CreateString(pstMultiMedia->aucPBSessionId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);

    MsgMng_MultiMediaSendMsg(pstMultiMedia, pucPeerId, uiSeqId, EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_PLAYBACK_CLOSE_RSP,
        pStrTmp, MOS_STRLEN(pStrTmp), MOS_NULL);

    pstMultiMedia->ucResetFlag = 1;
    MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR,"-------------------- MULTIMEDIA Stop, send seqid:%u json:%s", uiSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);

    return MOS_OK;
}

// 2248
_INT MsgMng_RecvMultiMediaPlayBackControl(_VPTR hConn,_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(hConn);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT iRet            = MOS_OK;
    _UI uiVod            = 0;
    _UI uiParamFlag      = 0;
    _UI uiChannelId      = 0;
    _UC aucMethod[8]     = {0};
    _UC *pStrTmp         = MOS_NULL;
    _UC *pucSessionId    = MOS_NULL;
    _UC *pucPosTime      = MOS_NULL;
    JSON_HANDLE hRoot    = MOS_NULL;
    JSON_HANDLE hBody    = MOS_NULL;
    JSON_HANDLE hRspBody = MOS_NULL;

    ST_MSGMNG_MULTI_MEDIA *pstMultiMedia = (ST_MSGMNG_MULTI_MEDIA*)hConn;

    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 解析json
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SessionId"),&pucSessionId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID"),&uiChannelId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Vod"),&uiVod);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Param"),&uiParamFlag);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Pos"),&pucPosTime);
    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,">>>>recive control playback chan:%d uiVod:%d flag:%d",  uiChannelId, uiVod, uiParamFlag);
    
    // 处理vod
    iRet = MsgMng_ProcMultiMediaPlayBackVod(pstMultiMedia, uiChannelId, uiVod, uiParamFlag, pucPosTime);

    // 回复json
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_PLAYBACK_CONTROL_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));
    if (iRet == MOS_OK)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(10013));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("Vod Seek Error"));
    }
    
    hRspBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRspBody,(_UC*)"SessionId",Adpt_Json_CreateString(pucSessionId));
    Adpt_Json_AddItemToObject(hRspBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(uiChannelId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hRspBody);

    pStrTmp = Adpt_Json_Print(hRoot);

    MsgMng_MultiMediaSendMsg(pstMultiMedia, pucPeerId, uiSeqId, EN_OGCT_METHOD_MULMEDIA, EN_OGCT_MULMEDIA_PLAYBACK_CONTROL_RSP,
        pStrTmp, MOS_STRLEN(pStrTmp), MOS_NULL);

    MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,">>>reqid %d rsp get PlayBack Calender %s",uiSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);

    return MOS_OK;
}

static _INT *MsgMng_MultiMediaDataEncrypto(SDKHeader *Header, _UC *pucEncKey, _UC *pucEncLv, _UC *Data, _UI Len)
{
    MOS_PARAM_NULL_RETERR(Data);

    SDKHeader *pHeader  = Header;
    _UC  *ucEncrypttext = (_UC *)MOS_MALLOC(MOS_HEX_NUM(Len));
    if (Len >= 32)
    {
        Adpt_Aes_Encrypt(Data, 32, pucEncKey, pucEncLv, ucEncrypttext);
        MOS_MEMSET(Data, 0, 32);
        MOS_MEMCPY(Data, ucEncrypttext, 32);
    }
    else if (Len >= 16 && Len < 32)
    {
        Adpt_Aes_Encrypt(Data, 16, pucEncKey, pucEncLv, ucEncrypttext);
        MOS_MEMSET(Data, 0, 16);
        MOS_MEMCPY(Data, ucEncrypttext, 16);
    }
    else
    {
        // 数据小于16，不加密
        pHeader->encrypt = 0x00;
        *(Data - 2) = 0x00;
    }
    MOS_FREE(ucEncrypttext);
    return MOS_OK;
}

static _INT send_data2(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,SDKHeader *Header, char*Buf, int Len)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    SDKHeader *pHeader    = Header;
    _INT iWrittenLen      = 0;
    _INT iTotalWrittenLen = 0;
    _BOOL pbOutWait       = MOS_FALSE;
    kj_timer_t   tsendFrameTimeOut;
    kj_timer_init(&tsendFrameTimeOut);

    // socket 复位/销毁 不需要执行发送
    if(pstMultiMedia->ucResetFlag) return 0;
    
    // 加密
    if (pHeader->encrypt == 0x31)
    {
        // MOS_PRINTF("Media Data encrypt!!! \r\n");
        MsgMng_MultiMediaDataEncrypto(pHeader, pstMultiMedia->stEncrypInf.aucEncKey, 
                                    pstMultiMedia->stEncrypInf.aucEncLv,Buf + 8, Len - 8);
    }
    pHeader->reserve = 0x40;// 流媒体服务器区分4.0设备
    getDiffTimems(&tsendFrameTimeOut,  1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
#ifdef SEND_DATA_DEBUG
    if (pstMultiMedia->hFile)
    {
        fwrite(Buf, 1, Len, pstMultiMedia->hFile);
    }
#endif
    while (iTotalWrittenLen < Len)
    {
        iWrittenLen = Mos_SocketSend(pstMultiMedia->isockFd, Buf + iTotalWrittenLen, Len - iTotalWrittenLen, &pbOutWait);
        if (iWrittenLen < 0)
        {
            if (getDiffTimems(&tsendFrameTimeOut,  0, ENUM_SECONDS_TYPE_MSECONDS, 60*10) >= 1000)
            {
                getDiffTimems(&tsendFrameTimeOut,  1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
                MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "send_data2 timeout");
                // 弱网络环境下，连续6秒超时错误触发复位/销毁socket，为了避免影响软看门狗喂狗，不宜超过10秒
                pstMultiMedia->ucSendDataFailCount++;
                if(pstMultiMedia->ucSendDataFailCount >= MSGMNG_MULTI_MEDIA_SEND_FAIL_FREQ)
                {
                    pstMultiMedia->ucSendDataFailCount = 0;
                    // pstMultiMedia->ucResetFlag = 1; // 不重启网络连接
                    MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "send_data2 timeout many time");
                }
                return iWrittenLen;
            }

            if (pbOutWait)
            {
                continue;
            }
            else
            {
                pstMultiMedia->ucSendDataFailCount = 0;
                return iWrittenLen;
            }
        }
        pbOutWait = MOS_FALSE;
        iTotalWrittenLen += iWrittenLen;
    }
    pstMultiMedia->ucSendDataFailCount = 0;
    return iTotalWrittenLen;
}

static _INT procSendMedia(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iCamId, _INT iStreamId, _UC msgType, _UC msgId, 
                    ST_FRAME_NODE *pstNode,_INT iFrmeLen, _INT iTimeStamp, _INT trasTye)
{
    //ST_MSGMNG_MULTI_MEDIA *avMediaServer = MsgMng_GetMultiMedia();
    ST_OGCT_PROTOCAL_HEAD   msgHeader;
    ST_MEDIA_PROTOCAL_HEAD  msgMediaHeader;
    ST_MEDIA_PROTOCAL_HEAD2 msgMediaHeader2;
    ST_MEDIA_PROTOCAL_HEAD  *mediaHeader = &msgMediaHeader;
    _INT iMsgBuffLen = 0;
    _INT iSeqIndex   = trasTye==EN_HTTP_STREAMER_VIDEO ? 0 : 1;
    _INT iSeqMedia   = iSeqIndex==0?
                        pstMultiMedia->uiVideoSeq[iStreamId]:
                        pstMultiMedia->uiAudioSeq[iStreamId];

    _INT i              = 0;
    _INT j              = 0;
    _INT pucOutLen      = 0;
    _INT iNeedEcrypt    = 0;
    _UI  uiListCnt      = 0;
    _INT iRet           = 0;
    _BOOL bStartFrame   = MOS_FALSE;        
    _BOOL bSendTimeout  = MOS_FALSE;  
    kj_timer_t tTimer                    = {0};
    ST_HTTP_ENCRYPTO_INF transEnc        = {0};
    ST_FRAME_NODE *pstFrameNode          = MOS_NULL;
    _UC pucSendBuf[MAX_MEDIA_PACKEG_LEN] = {0};

    kj_timer_init(&tTimer);
    getDiffTimems(&tTimer, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);

    MOS_MEMSET(&transEnc, 0, sizeof(transEnc));

    if(pstNode != MOS_NULL)
    {
        pstFrameNode = pstNode;
        while(pstFrameNode != MOS_NULL)
        {
            uiListCnt++;
            pstFrameNode = pstFrameNode->ptnest;
        }
    }

    pstFrameNode = pstNode;
    for (i=0; i<uiListCnt; i++)
    {
        pucOutLen = 0;
        bStartFrame = MOS_FALSE;
        MOS_MEMSET(&msgHeader, 0, sizeof(ST_OGCT_PROTOCAL_HEAD));
        if (i == 0)
        {
            bStartFrame = MOS_TRUE;
            mediaHeader = &msgMediaHeader;
            mediaHeader->usChannel = MOS_INET_HTONS(iCamId<<8|iStreamId);
            if (iSeqMedia > 65535)
                iSeqMedia = 0;

            mediaHeader->ucAVType  = trasTye;
            mediaHeader->iFrameLen = MOS_INET_HTONL(iFrmeLen);
            mediaHeader->iTimeStamp= MOS_INET_HTONL(iTimeStamp);
            //mediaHeader->ucFrameType = pstFrameNode->ucFramPos + MD_FRAME_HEAD + MD_NAUL_HEAD;
        }
        else
        {
            mediaHeader = (ST_MEDIA_PROTOCAL_HEAD*)&msgMediaHeader2;
            mediaHeader->usChannel = MOS_INET_HTONS(iCamId<<8|iStreamId);
            if (iSeqMedia > 65535)
                iSeqMedia = 0;
            mediaHeader->ucAVType  = trasTye;
            //mediaHeader->ucFrameType = pstFrameNode->ucFramPos + MD_NAUL_HEAD;
            //Http_EncMsgBody(&msgHeader, mediaHeader, sizeof(ST_MEDIA_PROTOCAL_HEAD2), &transEnc, (_UC*)pucSendBuf, &pucOutLen);
        }
        iNeedEcrypt = 0;
        if ((_UC)(MD_GETFRAMETYPE(pstFrameNode->ucFramPos)) == EN_FRAMETYPE_I)
        {
            iNeedEcrypt = 1;
        }

        if (pstFrameNode->uiNaluLen <= MAX_MEDIA_BODY_LEN)//one frame video send
        {
            _INT   iHeaderSize = sizeof(ST_MEDIA_PROTOCAL_HEAD2);
            mediaHeader->ucFrameType = MD_GETFRAMEHIGH(pstFrameNode->ucFramPos);
            if (bStartFrame)//start frame
            {
                iHeaderSize = sizeof(ST_MEDIA_PROTOCAL_HEAD);
                mediaHeader->ucFrameType |=  MD_FRAME_HEAD + MD_NAUL_HEAD;
            }
            else
            {
                mediaHeader->ucFrameType |=  MD_NAUL_HEAD;
            }

            if (iSeqMedia > 65535)
                iSeqMedia = 0;

            if (i == (uiListCnt-1))//last frame
            {
                mediaHeader->ucFrameType |= MD_FRAME_TAIL + MD_NALU_TAIL;
                mediaHeader->usSeqId   = MOS_INET_HTONS(iSeqMedia++);
                iMsgBuffLen = pstFrameNode->uiNaluLen + iHeaderSize;
                if (iNeedEcrypt == 1)
                {
                    Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, pstMultiMedia->stEncrypInf.iEncType);
                }
                else
                {
                    Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, transEnc.iEncType);
                }
                Http_EncMsgBody(&msgHeader, (_UC*)mediaHeader, iHeaderSize, &transEnc, (_UC*)pucSendBuf, &pucOutLen);
            }
            else
            {
                mediaHeader->ucFrameType |=  MD_NALU_TAIL;
                mediaHeader->usSeqId   = MOS_INET_HTONS(iSeqMedia++);
                iMsgBuffLen = pstFrameNode->uiNaluLen + iHeaderSize;
                if (iNeedEcrypt == 1)
                {
                    Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, pstMultiMedia->stEncrypInf.iEncType);
                }
                else
                {
                    Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, transEnc.iEncType);
                }
                Http_EncMsgBody(&msgHeader, (_UC*)mediaHeader, iHeaderSize, &transEnc, (_UC*)pucSendBuf, &pucOutLen);
            }
            MOS_MEMCPY(pucSendBuf+pucOutLen, pstFrameNode->ptDatabuff, pstFrameNode->uiNaluLen);
            pucOutLen += pstFrameNode->uiNaluLen;

            iRet = send_data2(pstMultiMedia, (SDKHeader*)&msgHeader, pucSendBuf, pucOutLen);
            if (iRet < 0)
            {
                bSendTimeout = MOS_TRUE;
            }

            if (getDiffTimems(&tTimer, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10) >= MSGMNG_MULTI_MEDIA_SEND_TIMEOUT*1000)
            {
                bSendTimeout = MOS_TRUE;
            }
            //avMediaServer->m_iceTranSport->sendData(1, pucSendBuf, pucOutLen);

            //MOS_BUFPRINTF("senbuf", pucSendBuf, pucOutLen>20?20:pucOutLen);
            //MOS_PRINTF("fun:%s, line:%d\n", __FUNCTION__, __LINE__);
        }
        else // large frame, multiy frames
        {
            int packeg_count = pstFrameNode->uiNaluLen/MAX_MEDIA_BODY_LEN ;
            if ((pstFrameNode->uiNaluLen%MAX_MEDIA_BODY_LEN) !=0)
            {
                packeg_count += 1;
            }

            for (j=0; j<packeg_count; j++)
            {
                _BOOL bFirstFrmame = MOS_FALSE;
                _INT  iSizeofHead  = sizeof(ST_MEDIA_PROTOCAL_HEAD2);
                pucOutLen = 0;
                mediaHeader->ucFrameType = MD_GETFRAMEHIGH(pstFrameNode->ucFramPos);
                iMsgBuffLen =sizeof(ST_MEDIA_PROTOCAL_HEAD2);
                if (j==0 && i == 0)
                {
                    mediaHeader->ucFrameType |= MD_FRAME_HEAD; //first frame
                    mediaHeader->ucFrameType |= MD_NAUL_HEAD;
                    bFirstFrmame = MOS_TRUE;
                    iSizeofHead  = sizeof(ST_MEDIA_PROTOCAL_HEAD);
                    iMsgBuffLen =  sizeof(ST_MEDIA_PROTOCAL_HEAD);
                }
                else
                {
                    iNeedEcrypt = 0;
                }
                

                _INT offset = j*MAX_MEDIA_BODY_LEN;
                _INT dataLen = (j==(packeg_count-1)) ?  (pstFrameNode->uiNaluLen%MAX_MEDIA_BODY_LEN) : MAX_MEDIA_BODY_LEN ;
                iMsgBuffLen += dataLen;

                if (iSeqMedia > 65535)
                    iSeqMedia = 0;

                if (i == (uiListCnt-1) && j==(packeg_count-1))
                {
                    mediaHeader->ucFrameType |= MD_FRAME_TAIL + MD_NALU_TAIL;
                    mediaHeader->usSeqId   = MOS_INET_HTONS(iSeqMedia++);
                    if (iNeedEcrypt == 1)
                    {
                        Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, pstMultiMedia->stEncrypInf.iEncType);
                    }
                    else
                    {
                        Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, transEnc.iEncType);
                    }
                    Http_EncMsgBody(&msgHeader, (_UC*)mediaHeader, iSizeofHead, &transEnc, (_UC*)pucSendBuf, &pucOutLen);
                }
                else
                {
                    mediaHeader->ucFrameType |= (j == 0)?MD_NAUL_HEAD:0;
                    mediaHeader->usSeqId   = MOS_INET_HTONS(iSeqMedia++);
                    if (iNeedEcrypt == 1)
                    {
                        Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, pstMultiMedia->stEncrypInf.iEncType);
                    }
                    else
                    {
                        Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, transEnc.iEncType);
                    }
                    Http_EncMsgBody(&msgHeader, (_UC*)mediaHeader, iSizeofHead, &transEnc, (_UC*)pucSendBuf, &pucOutLen);
                }
                MOS_MEMCPY(pucSendBuf+pucOutLen, pstFrameNode->ptDatabuff+offset, dataLen);
                pucOutLen += dataLen;
                //avMediaServer->m_iceTranSport->sendData(1, pucSendBuf, pucOutLen);
                iRet = send_data2(pstMultiMedia, (SDKHeader*)&msgHeader, pucSendBuf, pucOutLen);
                if (iRet < 0)
                {
                    bSendTimeout = MOS_TRUE;
                    break;
                }

                if (getDiffTimems(&tTimer, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10) >= MSGMNG_MULTI_MEDIA_SEND_TIMEOUT*1000)
                {
                    bSendTimeout = MOS_TRUE;
                    break;
                }               
//               MOS_PRINTF("dataLen:%d, current pack:j:%d, maxpac:%d, uiListCnt:%d, naullen:%d\n",
//                          dataLen, j, packeg_count, uiListCnt, pstFrameNode->uiNaluLen);
            }
            //MOS_PRINTF("fun:%s, line:%d\n", __FUNCTION__, __LINE__);
        }
        pstFrameNode = pstFrameNode->ptnest;
        if (bSendTimeout)
        {
            MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "%s timeout", __FUNCTION__);
            break;
        }        
    }
    if (iSeqIndex == 0)
    {
        pstMultiMedia->uiVideoSeq[iStreamId] = iSeqMedia;
    }
    else
    {
        pstMultiMedia->uiAudioSeq[iStreamId] = iSeqMedia;
    }
    if (bSendTimeout)
    {
        return MOS_ERR;
    }
    else
    {
        return MOS_OK;
    }
}

static _INT procSendMediaPlayback(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia, _US usChannel, _UC msgType, _UC msgId, 
                    ST_FRAME_NODE *pstNode,_INT iFrmeLen, _INT iTimeStamp, _INT trasTye)
{
    //ST_MSGMNG_MULTI_MEDIA *avMediaServer = MsgMng_GetMultiMedia();
    ST_OGCT_PROTOCAL_HEAD   msgHeader;
    ST_MEDIA_PROTOCAL_HEAD  msgMediaHeader;
    ST_MEDIA_PROTOCAL_HEAD2 msgMediaHeader2;
    ST_MEDIA_PROTOCAL_HEAD  *mediaHeader = &msgMediaHeader;
    _INT iStreamId   = 0;
    _INT iMsgBuffLen = 0;
    _INT iSeqIndex   = trasTye==EN_HTTP_STREAMER_VIDEO ? 0 : 1;
    _INT iSeqMedia   = iSeqIndex==0?
                        pstMultiMedia->uiVideoSeq[iStreamId]:
                        pstMultiMedia->uiAudioSeq[iStreamId];
    _INT pucOutLen   = 0;
    _INT iHeaderSize = 0;

    ST_HTTP_ENCRYPTO_INF transEnc        = {0};
    ST_FRAME_NODE *pstFrameNode          = pstNode;
    _UC pucSendBuf[MAX_MEDIA_PACKEG_LEN] = {0};

    MOS_MEMCPY(&transEnc, &pstMultiMedia->stEncrypInf, sizeof(transEnc));
    
    {
        transEnc.iEncType = MD_GETFRAMETYPE(pstFrameNode->ucFramPos)==EN_FRAMETYPE_I?transEnc.iEncType:0;
        MOS_MEMSET(&msgHeader, 0, sizeof(ST_OGCT_PROTOCAL_HEAD));
        pucOutLen = 0;
        
        if ((MD_GETFRAMEPOS(pstFrameNode->ucFramPos)&MD_FRAME_HEAD) > 0)
        {
            iHeaderSize = sizeof(ST_MEDIA_PROTOCAL_HEAD);
            mediaHeader = (ST_MEDIA_PROTOCAL_HEAD*)&msgMediaHeader;
            mediaHeader->iFrameLen = MOS_INET_HTONL(iFrmeLen);
            mediaHeader->iTimeStamp= MOS_INET_HTONL(iTimeStamp);
        }
        else
        {
            iHeaderSize = sizeof(ST_MEDIA_PROTOCAL_HEAD2);
            mediaHeader = (ST_MEDIA_PROTOCAL_HEAD*)&msgMediaHeader2;
        }
        mediaHeader->ucFrameType= pstFrameNode->ucFramPos;
        mediaHeader->usSeqId    = MOS_INET_HTONS(iSeqMedia++);
        mediaHeader->usChannel  = MOS_INET_HTONS(usChannel);
        mediaHeader->ucAVType   = trasTye;

        if (iSeqMedia > 65535)
            iSeqMedia = 0;

        iMsgBuffLen = pstFrameNode->uiNaluLen + iHeaderSize;
        // transEnc.iEncType = 0;//临时改为不加密
        Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, transEnc.iEncType);
        transEnc.iEncType = 0;//Http_EncMsgBody调用非加密逻辑
        Http_EncMsgBody(&msgHeader, (_UC*)mediaHeader, iHeaderSize, &transEnc, (_UC*)pucSendBuf, &pucOutLen);

        MOS_MEMCPY(pucSendBuf+pucOutLen, pstFrameNode->ptDatabuff, pstFrameNode->uiNaluLen);
        pucOutLen += pstFrameNode->uiNaluLen;

        send_data2(pstMultiMedia, (SDKHeader*)&msgHeader, pucSendBuf, pucOutLen);
    }

    if (iSeqIndex == 0)
    {
        pstMultiMedia->uiVideoSeq[iStreamId] = iSeqMedia;
    }
    else
    {
        pstMultiMedia->uiAudioSeq[iStreamId] = iSeqMedia;
    }

    return MOS_OK;
}

_INT MsgMng_MultiMediaGetVideoData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iStreamId, _INT UsedFlag)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    _HVIDEOREAD handle = pstMultiMedia->m_hVideoHandel[iStreamId];
    if (handle == NULL)
    {
        pstMultiMedia->iLastVideoUsedFlag[iStreamId] = 0;
        pstMultiMedia->m_hVideoHandel[iStreamId] = Media_VideoCreatReadHandle2(0, iStreamId, EN_READ_NEWKEY, EN_ZJ_KEYFRAME_QUALITY_NORMAL, __FUNCTION__);
        handle = pstMultiMedia->m_hVideoHandel[iStreamId];
    }

    if (pstMultiMedia->iLastVideoUsedFlag[iStreamId] != UsedFlag)
    {
        pstMultiMedia->iLastVideoUsedFlag[iStreamId] = UsedFlag;
        MsgMng_MultiMediaUpdateLiveBusyStatus(pstMultiMedia);
    }

    ST_FRAME_NODE *pucFramHeader  = MOS_NULL;
    _INT  iTimeStamp = 0;
    _LLID llTimePts  = 0;
    _INT  bRet = Media_VideoGetFrame2(handle, &pucFramHeader, &iTimeStamp, &llTimePts);
    if (bRet > 0 && (pucFramHeader != MOS_NULL))
    {    
        if (pucFramHeader->ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_RES)
        {    
            //printf("ucVideoResolutionChangeFlag = %d\n",pucFramHeader->ucVideoResolutionChangeFlag);
        }
        else if (pucFramHeader->ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_ENC)
        {
            //printf("ucVideoResolutionChangeFlag = %d\n",pucFramHeader->ucVideoResolutionChangeFlag);
            Media_VideoSetFrameUsed2(handle);
            Media_VideoDestroyReadHandle2(handle);    
            pstMultiMedia->m_hVideoHandel[iStreamId] = Media_VideoCreatReadHandle2(0, iStreamId, EN_READ_NEWKEY, EN_ZJ_KEYFRAME_QUALITY_NORMAL, __FUNCTION__);

            //流媒体服务器未上线221E协议解析视频参数前, 变更视频参数后都断开流媒体连接
            // if (UsedFlag)
            {
                pstMultiMedia->ucResetFlag = 1;
                MsgMng_UploadLog(pstMultiMedia, __FUNCTION__, EN_MULTIMEDIA_RT_LIVE_VIDEOPARAM_CHANGE, (_UC*)"live video param change, disconnect connect");
            }
            MOS_LOG_WARN(MSGMNG_MULTI_MEDIA_STR, "stream %d [use %d] video param change", iStreamId, UsedFlag);
            return MOS_ERR;
        }

        if (UsedFlag)
        {
            if ((pstMultiMedia->iNeedIframe[iStreamId]==MOS_TRUE ))
            {
                #ifdef MSGMNG_MULTIPATH_DEBUG_OUTFRAME
                if (pstMultiMedia->ucOutFramePrintfIF)
                {
                    pstMultiMedia->ucOutFramePrintfIF = 0;
                    MsgMng_OutFrameTimeUpdate(pstMultiMedia, "NEED IFRAME");
                }
                #endif
                if (MD_GETFRAMETYPE(pucFramHeader->ucFramPos) == 1)
                {
                    MsgMng_OutFrameTimeUpdate(pstMultiMedia, "SEND IFRAME");
                    MOS_PRINTF("MEDIA SEND IIIIIIIIIIIIIIIII FRAME!! %d mark=%u\n", iStreamId, pstMultiMedia->uiMark);
                    pstMultiMedia->iNeedIframe[iStreamId] = MOS_FALSE;
                    if (MOS_ERR == procSendMedia(pstMultiMedia, 0, iStreamId, EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_MULTIMEDIA,
                                   pucFramHeader,  bRet, iTimeStamp,EN_HTTP_STREAMER_VIDEO))
                    {
                        pstMultiMedia->iNeedIframe[iStreamId] = MOS_TRUE;
                    }
                }
            }
            else
            {
                if (MOS_ERR == procSendMedia(pstMultiMedia, 0, iStreamId, EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_MULTIMEDIA,
                               pucFramHeader,  bRet, iTimeStamp,EN_HTTP_STREAMER_VIDEO))
                {
                    pstMultiMedia->iNeedIframe[iStreamId] = MOS_TRUE;
                }
            }
        }

        Media_VideoSetFrameUsed2(handle);        
    }

    return bRet;
}

_INT MsgMng_MultiMediaGetAudioData(ST_MSGMNG_MULTI_MEDIA* pstMultiMedia,_INT iStreamId, _INT UsedFlag)
{
    MOS_PARAM_NULL_RETERR(pstMultiMedia);
    
    _INT  iTimeStamp = 0;
    ST_FRAME_NODE *pucFramHeader  = MOS_NULL;
    _HAUDIOREAD handle = pstMultiMedia->m_hAudioHandel[iStreamId];
    if (handle == NULL)
    {
        pstMultiMedia->m_hAudioHandel[iStreamId] = Media_AudioCreatReadHandle2(0, EN_READ_NEWKEY, __FUNCTION__);
        handle = pstMultiMedia->m_hAudioHandel[iStreamId];
    }
    if (handle)
    {
        _INT  bRet = Media_AudioGetFrame2(handle, &pucFramHeader, (_UI*)&iTimeStamp);
        if ((bRet > 0) && (pucFramHeader != MOS_NULL))
        {
            if (UsedFlag)
            procSendMedia(pstMultiMedia, 0, iStreamId, EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_MULTIMEDIA,
                        pucFramHeader,  bRet, iTimeStamp,EN_HTTP_STREAMER_AUDIO);
            Media_AudioSetFrameUsed2(handle);
        }
        return bRet;
    }
    return MOS_FALSE;
}

// 关闭流媒体所有连接/线程
_INT MsgMng_MultiMediaCloseAllConnect()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MSGMNG_MULTIMEDIA_CONNECT_NODE *pstConnectNode = MOS_NULL;

    Mos_MutexLock(&Media_GetTaskMng()->hMutex);

    FOR_EACHDATA_INLIST(&Media_GetTaskMng()->stConnectList, pstConnectNode, stIterator)
    {
        MOS_PRINTF("%s MaskName=%s\n", __FUNCTION__, pstConnectNode->pstMultiMedia->aucMaskName);
        pstConnectNode->pstMultiMedia->ucRunFlag = 0;
    }

    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
    return MOS_OK;
}

static _UI MsgMng_MultiMediaGetLocalIPv6Addr(_UC *pucLocalIPv6Addr, _UI uiLocalIPv6AddrLen)
{
    if ((pucLocalIPv6Addr == MOS_NULL))
    {
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "pucLocalIPv6Addr is null");
        return MOS_ERR;
    }
    Mos_MutexLock(&Media_GetTaskMng()->hMutex);
    MOS_STRNCPY(pucLocalIPv6Addr, Media_GetTaskMng()->aucIPv6Addr, uiLocalIPv6AddrLen);
    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
    return MOS_OK;
}

_UI MsgMng_MultiMediaSetLocalIPv6Addr(_UC *pucLocalIPv6Addr)
{
    if ((pucLocalIPv6Addr == MOS_NULL))
    {
        MOS_LOG_ERR(MSGMNG_MULTI_MEDIA_STR, "pucLocalIPv6Addr is null");
        return MOS_ERR;
    }
    Mos_MutexLock(&Media_GetTaskMng()->hMutex);
    if(MOS_STRCMP(Media_GetTaskMng()->aucIPv6Addr, pucLocalIPv6Addr) == 0)
    {
        Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);
        return MOS_OK;
    }
    MOS_STRNCPY(Media_GetTaskMng()->aucIPv6Addr, pucLocalIPv6Addr, sizeof(Media_GetTaskMng()->aucIPv6Addr));
    // MOS_LOG_INF(MSGMNG_MULTI_MEDIA_STR,"set IPv6Addr %s", Media_GetTaskMng()->aucIPv6Addr);
    Mos_MutexUnLock(&Media_GetTaskMng()->hMutex);

    return MOS_OK;
}

