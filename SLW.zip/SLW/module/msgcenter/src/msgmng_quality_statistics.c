#include "mos.h"
#include "msgmng_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "msgmng_quality_statistics.h"

static ST_QUALITY_STATISTICS_MNG g_stQualityStatisticsMng = {0};

static ST_QUALITY_STATISTICS_MNG* MsgMng_GetQualityStatisticsMng()
{
    return &g_stQualityStatisticsMng;
}

_INT MsgMng_QualityStatistics_Init()
{
    Mos_MutexCreate(&MsgMng_GetQualityStatisticsMng()->hMutex);
    MOS_LIST_INIT(&MsgMng_GetQualityStatisticsMng()->stQualityStatisticsList);
    
    return MOS_OK;
}

_INT MsgMng_QualityStatistics_Destroy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_QUALITY_STATISTICS_NODE *pstQualityStatisticsNode = MOS_NULL;

    Mos_MutexLock(&MsgMng_GetQualityStatisticsMng()->hMutex);

    FOR_EACHDATA_INLIST(&MsgMng_GetQualityStatisticsMng()->stQualityStatisticsList, pstQualityStatisticsNode, stIterator)
    {
        MOS_LIST_RMVNODE(&MsgMng_GetQualityStatisticsMng()->stQualityStatisticsList, pstQualityStatisticsNode);
        MOS_FREE(pstQualityStatisticsNode);
    }

    Mos_MutexUnLock(&MsgMng_GetQualityStatisticsMng()->hMutex);
    
    Mos_MutexDelete(&MsgMng_GetQualityStatisticsMng()->hMutex);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"QualityStatistics destory Ok");
    
    return MOS_OK;
}

// 查找对应链表中的节点
ST_QUALITY_STATISTICS_NODE *MsgMng_QualityStatistics_FindNode(EN_QUALITY_STA_RT_TYPE enStatusCode)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_QUALITY_STATISTICS_NODE *pstQualityStatisticsNode = MOS_NULL;
    
    // 遍历链表
    FOR_EACHDATA_INLIST(&MsgMng_GetQualityStatisticsMng()->stQualityStatisticsList, pstQualityStatisticsNode, stIterator)
    {
        // 符合条件的节点
        if ((0 != pstQualityStatisticsNode->uiUseFlag) && (enStatusCode == pstQualityStatisticsNode->enStatusCode))
        {
            break;
        }
    }

    // 返回符合条件节点
    return pstQualityStatisticsNode;
}

// 添加或查找节点
ST_QUALITY_STATISTICS_NODE* MsgMng_QualityStatistics_FindAndCreatNode(EN_QUALITY_STA_RT_TYPE enStatusCode, _UC *pucUrl)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_QUALITY_STATISTICS_NODE *pstQualityStatisticsNode    = MOS_NULL;
    ST_QUALITY_STATISTICS_NODE *pstQualityStatisticsTmpNode = MOS_NULL;
    
    // 遍历链表
    FOR_EACHDATA_INLIST(&MsgMng_GetQualityStatisticsMng()->stQualityStatisticsList, pstQualityStatisticsNode, stIterator)
    {
        // 符合条件的节点
        if ((0 != pstQualityStatisticsNode->uiUseFlag) && (enStatusCode == pstQualityStatisticsNode->enStatusCode))
        {
            // 返回存在的节点
            return pstQualityStatisticsNode;
        }
        // 创建节点
        else if (0 == pstQualityStatisticsNode->uiUseFlag)
        {
            // 备份节点
            pstQualityStatisticsTmpNode = pstQualityStatisticsNode;
        }
    }

    if(pstQualityStatisticsTmpNode == MOS_NULL)
    {
        // 申请新增的节点内存空间
        pstQualityStatisticsTmpNode = (ST_QUALITY_STATISTICS_NODE *)MOS_MALLOCCLR(sizeof(ST_QUALITY_STATISTICS_NODE));

        Mos_MutexLock(&MsgMng_GetQualityStatisticsMng()->hMutex);
        MOS_LIST_ADDTAIL(&MsgMng_GetQualityStatisticsMng()->stQualityStatisticsList, pstQualityStatisticsTmpNode);
        Mos_MutexUnLock(&MsgMng_GetQualityStatisticsMng()->hMutex);
    }

    // 初始化新增的节点
    if (MOS_NULL != pucUrl)
    {
        MOS_STRLCPY(pstQualityStatisticsTmpNode->aucUrl, pucUrl, sizeof(pstQualityStatisticsTmpNode->aucUrl));
    }

    pstQualityStatisticsTmpNode->enStatusCode       = enStatusCode;
    pstQualityStatisticsTmpNode->uiSucCnt           = 0;
    pstQualityStatisticsTmpNode->uiSucAvgUseTime    = 0;
    pstQualityStatisticsTmpNode->uiSucTotalUseTime  = 0;

    pstQualityStatisticsTmpNode->uiFailCnt          = 0;
    pstQualityStatisticsTmpNode->uiFailAvgUseTime   = 0;
    pstQualityStatisticsTmpNode->uiFailTotalUseTime = 0;

    pstQualityStatisticsTmpNode->uiUploadInterval   = QUALITY_STA_UPLOAD_INTERVAL;

    kj_timer_init(&pstQualityStatisticsTmpNode->tUploadTimer);
    getDiffTimems(&pstQualityStatisticsTmpNode->tUploadTimer, 1, ENUM_SECONDS_TYPE_SECONDS, 600);

    // uiUseFlag要在最后面才能置1
    pstQualityStatisticsTmpNode->uiUseFlag          = 1; 

    // MOS_LOG_INF(MSGMNG_ID_LOG_STR, "QualityStatistics add new node[%d], pucUrl=>%s", enStatusCode, pucUrl);

    // 返回新增的节点
    return pstQualityStatisticsTmpNode;
}

_INT MsgMng_QualityStatistics_DelNode(EN_QUALITY_STA_RT_TYPE enStatusCode)
{
    ST_QUALITY_STATISTICS_NODE *pstQualityStatisticsNode = MsgMng_QualityStatistics_FindNode(enStatusCode);
    if (MOS_NULL == pstQualityStatisticsNode)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "pstQualityStatisticsNode == MOS_NULL");
        return MOS_OK;
    }

    pstQualityStatisticsNode->uiUseFlag = 0;
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "QualityStatistics del node[%d]", enStatusCode);

    return MOS_OK;
}

_INT MsgMng_QualityStatistics_SetSuccessInf(EN_QUALITY_STA_RT_TYPE enStatusCode, _UI uiUseTime)
{
    ST_QUALITY_STATISTICS_NODE *pstQualityStatisticsNode = MsgMng_QualityStatistics_FindNode(enStatusCode);
    if (MOS_NULL == pstQualityStatisticsNode)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "pstQualityStatisticsNode == MOS_NULL");
        return MOS_ERR;
    }

    Mos_MutexLock(&MsgMng_GetQualityStatisticsMng()->hMutex);
    pstQualityStatisticsNode->uiSucCnt++;
    pstQualityStatisticsNode->uiSucTotalUseTime += uiUseTime;
    pstQualityStatisticsNode->uiSucAvgUseTime = pstQualityStatisticsNode->uiSucTotalUseTime / pstQualityStatisticsNode->uiSucCnt;
    Mos_MutexUnLock(&MsgMng_GetQualityStatisticsMng()->hMutex);

    // MOS_LOG_INF(MSGMNG_ID_LOG_STR, "set [%d] success info:Cnt[%u] AvgUseTime[%u] TotalUseTime[%u]", \
    //             enStatusCode, \
    //             pstQualityStatisticsNode->uiSucCnt, \
    //             pstQualityStatisticsNode->uiSucAvgUseTime, \
    //             pstQualityStatisticsNode->uiSucTotalUseTime);

    return MOS_OK;
}

_INT MsgMng_QualityStatistics_SetFailInf(EN_QUALITY_STA_RT_TYPE enStatusCode, _UI uiUseTime)
{
    
    ST_QUALITY_STATISTICS_NODE *pstQualityStatisticsNode = MsgMng_QualityStatistics_FindNode(enStatusCode);
    if (MOS_NULL == pstQualityStatisticsNode)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "pstQualityStatisticsNode == MOS_NULL");
        return MOS_ERR;
    }

    Mos_MutexLock(&MsgMng_GetQualityStatisticsMng()->hMutex);
    pstQualityStatisticsNode->uiFailCnt++;
    pstQualityStatisticsNode->uiFailTotalUseTime += uiUseTime;
    pstQualityStatisticsNode->uiFailAvgUseTime = pstQualityStatisticsNode->uiFailTotalUseTime / pstQualityStatisticsNode->uiFailCnt;
    Mos_MutexUnLock(&MsgMng_GetQualityStatisticsMng()->hMutex);

    // MOS_LOG_INF(MSGMNG_ID_LOG_STR, "set [%d] fail info:Cnt[%u] AvgUseTime[%u] TotalUseTime[%u]", \
    //             enStatusCode, \
    //             pstQualityStatisticsNode->uiFailCnt, \
    //             pstQualityStatisticsNode->uiFailAvgUseTime, \
    //             pstQualityStatisticsNode->uiFailTotalUseTime);

    return MOS_OK;
}

_INT MsgMng_QualityStatistics_Upload()
{
    _UC aucMsg[128] = {0};
    ST_MOS_LIST_ITERATOR stIterator;
    ST_QUALITY_STATISTICS_NODE *pstQualityStatisticsNode = MOS_NULL;

    // 遍历链表
    FOR_EACHDATA_INLIST(&MsgMng_GetQualityStatisticsMng()->stQualityStatisticsList, pstQualityStatisticsNode, stIterator)
    {
        // 正常使用且有统计的节点
        if ((0 != pstQualityStatisticsNode->uiUseFlag) && ((pstQualityStatisticsNode->uiSucCnt > 0) || (pstQualityStatisticsNode->uiFailCnt > 0)))
        {
            // 上报时间到
            if (getDiffTimems(&pstQualityStatisticsNode->tUploadTimer, 0, ENUM_SECONDS_TYPE_SECONDS, 600) >= pstQualityStatisticsNode->uiUploadInterval)
            {
                // 重置上报时间点
                getDiffTimems(&pstQualityStatisticsNode->tUploadTimer, 1, ENUM_SECONDS_TYPE_SECONDS, 600);

                // 关键接口质量上报
                Mos_MutexLock(&MsgMng_GetQualityStatisticsMng()->hMutex);
                MOS_SPRINTF(aucMsg, "successCnt[%u] successAvgUseTime[%u]; failCnt[%u] failAvgUseTime[%u]", \
                                    pstQualityStatisticsNode->uiSucCnt, pstQualityStatisticsNode->uiSucAvgUseTime, \
                                    pstQualityStatisticsNode->uiFailCnt, pstQualityStatisticsNode->uiFailAvgUseTime);

                // 上报完重置成功次数、时间
                pstQualityStatisticsNode->uiSucCnt           = 0;
                pstQualityStatisticsNode->uiSucAvgUseTime    = 0;
                pstQualityStatisticsNode->uiSucTotalUseTime  = 0;
                // 上报完重置失败次数、时间
                pstQualityStatisticsNode->uiFailCnt          = 0;
                pstQualityStatisticsNode->uiFailAvgUseTime   = 0;
                pstQualityStatisticsNode->uiFailTotalUseTime = 0;
                Mos_MutexUnLock(&MsgMng_GetQualityStatisticsMng()->hMutex);

                // 上报云涛
                CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), pstQualityStatisticsNode->aucUrl, 0, pstQualityStatisticsNode->enStatusCode, aucMsg, MOS_NULL, 1);

                // MOS_LOG_INF(MSGMNG_ID_LOG_STR, "upload [%d] info: %s", pstQualityStatisticsNode->enStatusCode, aucMsg);
            }
        }
    }

    return MOS_OK;
}
