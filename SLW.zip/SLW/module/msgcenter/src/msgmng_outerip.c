#include "mos.h"
#include "zj_interface.h"
#include "config_type.h"
#include "config_api.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "adpt_json_adapt.h"
#include "msgmng_api.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "qualityprobe_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "msgmng_outerip.h"

// 获取外网IP管理结构体
static ST_MSGMMG_OUTERIP_MNG g_stOuterIPMng = {0};

// 获取外网IP管理结构体
ST_MSGMMG_OUTERIP_MNG *MsgMng_OuterIP_GetMng()
{
    return &g_stOuterIPMng;
}

// 获取设备外网IP回复
_VOID MsgMng_RecvGetOuterIPRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    // 获取外网IP管理结构体
    ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();

    if (g_stOuterIPMng)
    {
        if (g_stOuterIPMng->stHttpGetTaskOuterIP.usBuffLen == 0)
        {
            g_stOuterIPMng->stHttpGetTaskOuterIP.usBuffLen   = 1024;
            g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff = (_UC*)MOS_MALLOC(g_stOuterIPMng->stHttpGetTaskOuterIP.usBuffLen);
        }

        if ((g_stOuterIPMng->stHttpGetTaskOuterIP.usRecvLen + uiLen) < (g_stOuterIPMng->stHttpGetTaskOuterIP.usBuffLen))
        {
            MOS_MEMCPY(g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff + g_stOuterIPMng->stHttpGetTaskOuterIP.usRecvLen, pucData, uiLen);
            g_stOuterIPMng->stHttpGetTaskOuterIP.usRecvLen += uiLen;
        }
    }

    return;
}

// 获取设备外网IP完成
_VOID MsgMng_RecvGetOuterIPFinish(_VPTR vpUserPtr, _UI uiReqId)
{    
    // 获取外网IP管理结构体
    ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();
    if (g_stOuterIPMng)
    {
        if (g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff)
        {
            g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff[g_stOuterIPMng->stHttpGetTaskOuterIP.usRecvLen] = 0;
        }

        _UC aucMsgString[128] = {0};
        MOS_VSNPRINTF(aucMsgString, sizeof(aucMsgString), "HttpHandle:%u Now ReqId:%u DevOnlineCheckOuterIPReqId:%u Recv GetOuterIP Rsp is %s", 
                                                        g_stOuterIPMng->stHttpGetTaskOuterIP.uiHttpHandle, uiReqId,
                                                        g_stOuterIPMng->uiDevOnlineCheckOuterIPReqId, g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff);
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), GETOUTERIP_HOST, 0, 
                                EN_REGISTINFO_RT_GETOUTERIP_SUC, aucMsgString, MOS_NULL, 1);

        // TODO 使用内部域名获取设备外网IP的返回数据的解释
        // {"outerip_address":"183.6.180185"}
        _UC *pucOuterIP = MOS_NULL;
        JSON_HANDLE hGetOuterIPRoot = Adpt_Json_Parse(g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff);
        if (hGetOuterIPRoot != MOS_NULL)
        {
            // 设备外网IP
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hGetOuterIPRoot,(_UC*)"outerip_address"),&pucOuterIP);

            // 无基础外网IP
            if (MOS_STRLEN(g_stOuterIPMng->aucBaseOuterIP) == 0)
            {
                if (pucOuterIP)
                {
                    // DO nothing 继续发送信令心跳包
                    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "No Base OutIP, Now Base OutIP is %s, GoAhead Send Heart Alive", pucOuterIP);
                    // 记录基础外网IP
                    MOS_STRNCPY(g_stOuterIPMng->aucBaseOuterIP, pucOuterIP, sizeof(g_stOuterIPMng->aucBaseOuterIP));
                }
                else
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "No Base OutIP, pucOuterIP Is Null");
                }
            }
            // 有基础外网IP
            else
            {
                if (pucOuterIP)
                {
                    // 外网IP变更
                    if (MOS_STRNCMP(g_stOuterIPMng->aucBaseOuterIP, pucOuterIP, sizeof(g_stOuterIPMng->aucBaseOuterIP)) != 0)
                    {
                        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "OutIP %s Change To %s, Reset Server Connet And Notify Cloud ToDo Something",
                                                        g_stOuterIPMng->aucBaseOuterIP, pucOuterIP);
                        // 设备外网IP变更次数+1
                        g_stOuterIPMng->iOuterIPChangeCount++;  

                        // 设备上线触发的获取设备外网IP的请求回复
                        if (g_stOuterIPMng->uiDevOnlineCheckOuterIPReqId == uiReqId)
                        {
                            // 记录新的基础外网IP
                            MOS_STRNCPY(g_stOuterIPMng->aucBaseOuterIP, pucOuterIP, sizeof(g_stOuterIPMng->aucBaseOuterIP));
                        }
                        // 非设备上线触发的获取设备外网IP的请求回复
                        else
                        {
                            // 记录新的基础外网IP
                            MOS_STRNCPY(g_stOuterIPMng->aucBaseOuterIP, pucOuterIP, sizeof(g_stOuterIPMng->aucBaseOuterIP));

                            // TODO 主动断开信令服务器链接，并重连
                            ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetCmdServer();
                            pstCmdServer->ucResetFlag = 1;

                            // 通知云存模块设备外网IP变更
                            CloudStg_NotifyOuterIPChange();
                        }
                    }
                    // 外网IP未变更
                    else
                    {
                        // DO nothing 继续发送信令心跳包
                        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "OutIP No Change, GoAhead Send Heart Alive");
                    }
                }
                else
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "Have Base OutIP, pucOuterIP Is Null");
                }
            }
            // 获取设备外网IP成功次数+1
            g_stOuterIPMng->iGetOuterIPSucCount++;
        }
        else
        {
            // 设备外网IP数据异常 
            // 获取设备外网IP失败次数+1
            g_stOuterIPMng->iGetOuterIPFailCount++;
        }
        
        // 获取设备外网IP超时标记置0
        g_stOuterIPMng->iGetOutIPTimeOutFlag = 1;

        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "GetOuterIPSucCount:%d GetOuterIPFailCount:%d OuterIPChangeCount:%d BaseOuterIP:%s", 
                                        g_stOuterIPMng->iGetOuterIPSucCount, g_stOuterIPMng->iGetOuterIPFailCount,
                                        g_stOuterIPMng->iOuterIPChangeCount, g_stOuterIPMng->aucBaseOuterIP);

        MOS_FREE(g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff);
        g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff   = MOS_NULL;
        g_stOuterIPMng->stHttpGetTaskOuterIP.usBuffLen     = 0;
        g_stOuterIPMng->stHttpGetTaskOuterIP.usRecvLen     = 0;
        g_stOuterIPMng->stHttpGetTaskOuterIP.uiHttpHandle  = 0;
    }
    return;
}

// 获取设备外网IP失败
_VOID MsgMng_RecvGetOuterIPFail(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId)
{
    // 获取外网IP管理结构体
    ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();
    
    if (g_stOuterIPMng)
    {
        _UC aucMsgString[128] = {0};
        MOS_VSNPRINTF(aucMsgString, sizeof(aucMsgString), "HttpHandle:%u ReqId:%u Recv GetOuterIP Rsp Fail ErrCode:%u", 
                                    g_stOuterIPMng->stHttpGetTaskOuterIP.uiHttpHandle, uiReqId, uiErrCode);
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), GETOUTERIP_HOST, -1, 
                                    EN_REGISTINFO_RT_RECV_GETOUTERIP_RSP_FAIL, aucMsgString, MOS_NULL, 1);

        // 请求超时
        if (uiErrCode == EN_HTTP_RET_TIMEOUT)
        {
            g_stOuterIPMng->iGetOutIPTimeOutFlag = 1;
        }
        else
        {
            g_stOuterIPMng->iGetOutIPTimeOutFlag = 0;
        }

        // 获取设备外网IP失败次数+1
        g_stOuterIPMng->iGetOuterIPFailCount++;

        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "GetOuterIPSucCount:%d GetOuterIPFailCount:%d OuterIPChangeCount:%d BaseOuterIP:%s", 
                                            g_stOuterIPMng->iGetOuterIPSucCount, g_stOuterIPMng->iGetOuterIPFailCount,
                                            g_stOuterIPMng->iOuterIPChangeCount, g_stOuterIPMng->aucBaseOuterIP);

        MOS_FREE(g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff);
        g_stOuterIPMng->stHttpGetTaskOuterIP.pucHttpBuff   = MOS_NULL;
        g_stOuterIPMng->stHttpGetTaskOuterIP.usBuffLen     = 0;
        g_stOuterIPMng->stHttpGetTaskOuterIP.usRecvLen     = 0;
        g_stOuterIPMng->stHttpGetTaskOuterIP.uiHttpHandle  = 0;
    }

    return;
}

// 获取设备外网IP
_INT MsgMng_GetOuterIP(_INT iCheckOuterIPType)
{
    _INT iRet              = MOS_ERR;
    _UI  uiReqId           =  0;
    _INT iHttpsFlag        =  0;
    _UC  aucFuncStr[64]    = {0};
    _UC  aucAdmonAddr[128] = {0};

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);

    // 获取平台域名地址
    Http_Parse_Url(GETOUTERIP_HOST, aucAdmonAddr, aucFuncStr, &iHttpsFlag);

    stHttpInfoNode.uiSSLFlag     = iHttpsFlag;
    stHttpInfoNode.pfuncRecv     = MsgMng_RecvGetOuterIPRsp;
    stHttpInfoNode.pfuncFinished = MsgMng_RecvGetOuterIPFinish;
    stHttpInfoNode.pfuncFailed   = MsgMng_RecvGetOuterIPFail;
    stHttpInfoNode.iTimeOut      = 15;

    uiReqId = Mos_GetSessionId();

    // 获取获取外网IP管理结构体
    ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();
    // 设备上线触发获取设备外网IP时，记录一下请求ReqId
    if (iCheckOuterIPType == EN_MSG_CHECK_OUTERIP_TYPE_DEV_ONLINE)
    {
        g_stOuterIPMng->uiDevOnlineCheckOuterIPReqId = uiReqId;
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "aucAdmonAddr:%s aucFuncStr:%s iHttpsFlag:%d", 
                                        aucAdmonAddr, aucFuncStr, iHttpsFlag);

    // 向 GETOUTERIP_HOST 请求设备的外网IP GET的方式 https://beta.ehome.21cn.com/api/getIP.do
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, aucAdmonAddr, aucFuncStr, EN_HTTP_METHOD_GET, uiReqId);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC aucMsgString[128] = {0};
        MOS_SPRINTF(aucMsgString, "%s Parse GetOuterIP Addr Failed ReqId:%u", 
                                MSGMNG_ID_LOG_STR, g_stOuterIPMng->uiDevOnlineCheckOuterIPReqId);
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), GETOUTERIP_HOST, -1, 
                                EN_REGISTINFO_RT_PARSE_GETOUTERIP_ADDR_FAIL, aucMsgString, MOS_NULL, 1);
        
        // 获取设备外网IP失败次数+1
        g_stOuterIPMng->iGetOuterIPFailCount++;
    }

    return iRet;
}

// 上报时间段内获取设备外网IP的统计数据到云涛
_INT MsgMng_UploadGetDevOuterIPDataToCDLog(_CTIME_T cTimeNow)
{
    // 获取获取外网IP管理结构体
    ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();

    if (g_stOuterIPMng)
    {
        // 设备外网IP统计数据都为0 不做上报云涛处理
        if (g_stOuterIPMng->iOuterIPChangeCount  == 0 &&
            g_stOuterIPMng->iGetOuterIPSucCount  == 0 &&
            g_stOuterIPMng->iGetOuterIPFailCount == 0)
        {
            // Do Nothing
            MOS_LOG_INF(MSGMNG_ID_LOG_STR, "OuterIPData: Time:[%u - %u] GetOuterIPSucCount:%d GetOuterIPFailCount:%d OuterIPChangeCount:%d Nothing ToDo", 
                            cTimeNow, g_stOuterIPMng->cUploadDataTime, g_stOuterIPMng->iGetOuterIPSucCount, 
                            g_stOuterIPMng->iGetOuterIPFailCount, g_stOuterIPMng->iOuterIPChangeCount);
        }
        else
        {
            _UC aucMsgString[128] = {0};
            MOS_SPRINTF(aucMsgString, "OuterIPData: Time:[%u - %u] GetOuterIPSucCount:%d GetOuterIPFailCount:%d OuterIPChangeCount:%d", 
                                        cTimeNow, g_stOuterIPMng->cUploadDataTime, g_stOuterIPMng->iGetOuterIPSucCount, 
                                        g_stOuterIPMng->iGetOuterIPFailCount, g_stOuterIPMng->iOuterIPChangeCount);
            CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), GETOUTERIP_HOST, -1, 
                                        EN_REGISTINFO_RT_PARSE_GETOUTERIP_ADDR_FAIL, aucMsgString, MOS_NULL, 1);

            // 清空获取设备外网IP的统计数据
            g_stOuterIPMng->iOuterIPChangeCount  = 0;
            g_stOuterIPMng->iGetOuterIPSucCount  = 0;
            g_stOuterIPMng->iGetOuterIPFailCount = 0;
        }

        // 记录上报上报获取设备外网IP的统计数据到云涛时间点
        g_stOuterIPMng->cUploadDataTime = cTimeNow;
    }

    return MOS_OK;
}

// 处理获取设备外网IP并上报统计数据到云涛的流程
_INT MsgMng_ProcGetDevOuterIP(_CTIME_T cTimeNow)
{
    // 获取获取外网IP管理结构体
    ST_MSGMMG_OUTERIP_MNG *g_stOuterIPMng = MsgMng_OuterIP_GetMng();

    if (g_stOuterIPMng)
    {
        // 首先判断是否暂停检查设备外网IP
        // 暂停检查设备外网IP
        if (g_stOuterIPMng->iStopCheckOuterIPFlag == 1)
        {
            // 判断是否已达到暂停检查设备外网IP时长
            _INT iStopCheckDurationNow = 0;
            iStopCheckDurationNow = MOS_ABS_NUM(cTimeNow - g_stOuterIPMng->cStopUploadTime);

            // 已到达暂停检查设备外网IP时长
            if (iStopCheckDurationNow >= (Config_GetDeviceMng()->uiStopCheckDuration * 3600))
            {
                MOS_LOG_INF(MSGMNG_ID_LOG_STR, "StopCheck OuterIP Duration(%u - %u = %d >= %u)", cTimeNow, g_stOuterIPMng->cStopUploadTime,
                                                    iStopCheckDurationNow, (Config_GetDeviceMng()->uiStopCheckDuration * 3600));

                // 修改暂停检查设备外网IP标志位
                g_stOuterIPMng->iStopCheckOuterIPFlag = 0;
            }
        }
        // 未暂停检查设备外网IP
        else
        {
            // 设备上线触发获取设备外网IP
            if (g_stOuterIPMng->iCheckOuterIPType == EN_MSG_CHECK_OUTERIP_TYPE_DEV_ONLINE)
            {
                // 设备上线触发判断冷却时长 是否已经获取随机冷却时长
                // 未获取随机冷却时长
                if (g_stOuterIPMng->iGetRandomTimeDurationFlag == 0)
                {
                    //选择一个randtime  获取随机冷却时长
                    srand((unsigned)time(NULL));
                    g_stOuterIPMng->iRandomTimeDuration = rand() % (Config_GetDeviceMng()->uiOnlineRandomTime * 60);
                    
                    // 标记已获取随机冷却时长
                    g_stOuterIPMng->iGetRandomTimeDurationFlag = 1;
                    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "EN_MSG_CHECK_OUTERIP_TYPE_DEV_ONLINE  RandomTimeDuration:%d", g_stOuterIPMng->iRandomTimeDuration);
                }
                // 已获取随机冷却时长
                else
                {
                    // 判断是否达到冷却期时长
                    _INT iRandomTimeDurationNow = 0;
                    iRandomTimeDurationNow = MOS_ABS_NUM(cTimeNow - g_stOuterIPMng->cDevOnlineTime);

                    // 已到达冷却期时长
                    if (iRandomTimeDurationNow >= g_stOuterIPMng->iRandomTimeDuration)
                    {
                        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "EN_MSG_CHECK_OUTERIP_TYPE_DEV_ONLINE \
                                                        TimeNow(%u) - DevOnlineTime(%u) = RandomTimeDurationNow(%d) >= RandomTimeDuration(%d)",
                                                        cTimeNow, g_stOuterIPMng->cDevOnlineTime, iRandomTimeDurationNow, g_stOuterIPMng->iRandomTimeDuration);
                        // 获取设备外网IP
                        MsgMng_GetOuterIP(EN_MSG_CHECK_OUTERIP_TYPE_DEV_ONLINE);

                        // 标记未获取随机冷却时长
                        g_stOuterIPMng->iRandomTimeDuration = 0;
                        g_stOuterIPMng->iGetRandomTimeDurationFlag = 0;
                        // 将触发获取设备外网IP的类型改为无需触发
                        g_stOuterIPMng->iCheckOuterIPType = EN_MSG_CHECK_OUTERIP_TYPE_NONEED;
                    }
                }
            }
            // 丢失信令心跳包触发获取设备外网IP
            else if (g_stOuterIPMng->iCheckOuterIPType == EN_MSG_CHECK_OUTERIP_TYPE_HEART_LOST)
            {
                MOS_LOG_INF(MSGMNG_ID_LOG_STR, "EN_MSG_CHECK_OUTERIP_TYPE_HEART_LOST");

                // 获取设备外网IP
                MsgMng_GetOuterIP(EN_MSG_CHECK_OUTERIP_TYPE_HEART_LOST);

                // 将触发获取设备外网IP的类型改为无需触发
                g_stOuterIPMng->iCheckOuterIPType = EN_MSG_CHECK_OUTERIP_TYPE_NONEED;
            }
            // 无需触发获取设备外网IP
            else // EN_MSG_CHECK_OUTERIP_TYPE_NONEED
            {
                // MOS_LOG_INF(MSGMNG_ID_LOG_STR, "EN_MSG_CHECK_OUTERIP_TYPE_NONEED");
            }
        }

        // 判断获取设备外网IP变更次数是否已达到最大值
        // 获取设备外网IP变更次数已达到最大值
        if (g_stOuterIPMng->iOuterIPChangeCount >= Config_GetDeviceMng()->uiMaxChangeCount)
        {
            // 上报时间段内获取设备外网IP的统计数据到云涛
            MsgMng_UploadGetDevOuterIPDataToCDLog(cTimeNow);

            MOS_LOG_INF(MSGMNG_ID_LOG_STR, "OuterIP ChangeCount(%d) > MaxChangeCount(%u)",
                            g_stOuterIPMng->iOuterIPChangeCount, Config_GetDeviceMng()->uiMaxChangeCount);

            // 停止获取设备外网IP 时长由uiStopCheckDuration(单位:h)决定
            g_stOuterIPMng->cStopUploadTime = cTimeNow;
            g_stOuterIPMng->iStopCheckOuterIPFlag = 1;
        }
        // 获取设备外网IP变更次数未达到最大值
        else
        {
            // 判断是否已达到上报获取设备外网IP的统计数据到云涛的时间点
            _INT iUploadIntervalNow = 0;
            iUploadIntervalNow = MOS_ABS_NUM(cTimeNow - g_stOuterIPMng->cUploadDataTime);

            // 已到达上报获取设备外网IP的统计数据到云涛的时间点
            if (iUploadIntervalNow > (Config_GetDeviceMng()->uiUploadInterval * 3600))
            {
                MOS_LOG_INF(MSGMNG_ID_LOG_STR, "OuterIP UploadTime is Coming (%u - %u = %d > %u)", cTimeNow, 
                        g_stOuterIPMng->cUploadDataTime, iUploadIntervalNow, (Config_GetDeviceMng()->uiUploadInterval * 3600));

                // 上报时间段内获取设备外网IP的统计数据到云涛
                MsgMng_UploadGetDevOuterIPDataToCDLog(cTimeNow);
            }
        }
    }

    return MOS_OK;
}