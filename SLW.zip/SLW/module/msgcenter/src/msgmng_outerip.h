#ifndef _MSGMNG_OUTERIP_H
#define _MSGMNG_OUTERIP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "msgmng_cmdserver.h"


#define GETOUTERIP_HOST     (_UC*)"https://vnet-ping.21cn.com/api/getIP.do" // 内部获取外网域名
// #define GETOUTERIP_HOST     (_UC*)"https://beta.ehome.21cn.com/api/getIP.do" // 内部获取外网域名 

// 触发获取设备外网IP的类型
typedef enum enum_Check_OuterIP_Type
{
    EN_MSG_CHECK_OUTERIP_TYPE_NONEED        = 0X00,  // 无需触发
    EN_MSG_CHECK_OUTERIP_TYPE_DEV_ONLINE    = 0X01,  // 设备上线触发
    EN_MSG_CHECK_OUTERIP_TYPE_HEART_LOST    = 0X02,  // 心跳包丢失触发
}EN_MSG_CHECK_OUTERIP_TYPE;

// 获取外网IP管理结构体
typedef struct stru_MSGMMG_OUTERIP_MNG
{
    _INT iCheckOuterIPType;             // 触发检查设备外网IP的类型   0.没触发 1.设备上线 2.心跳包丢失 参考: EN_MSG_CHECK_OUTERIP_TYPE
    
    _CTIME_T cDevOnlineTime;            // 设备上线时间点
    _INT iRandomTimeDuration;           // 设备上线后获取设备外网IP的冷却随机时长 单位：秒(s)
    _INT iGetRandomTimeDurationFlag;    // 是否获取设备外网IP的冷却随机时长标记
    _UI  uiDevOnlineCheckOuterIPReqId;  // 设备上线后获取设备外网IP的请求ReqId
    
    _INT iGetOutIPTimeOutFlag;          // 是否获取设备外网IP超时标记  用于第一次心跳包超时获取设备外网IP超时，第二次心跳包超时时继续获取设备外网IP的场景

    _CTIME_T cStopUploadTime;           // 停止检查设备外网IP的时间点
    _INT iStopCheckOuterIPFlag;         // 是否停止检查设备外网IP标记

    _CTIME_T cUploadDataTime;           // 上传获取设备外网IP统计数据到云涛的时间点
    _INT iOuterIPChangeCount;           // 外网IP变更次数
    _INT iGetOuterIPSucCount;           // 获取外网IP成功次数
    _INT iGetOuterIPFailCount;          // 获取外网IP失败次数

    _UC  aucBaseOuterIP[64];            // 基础外网IP

    ST_MSGMNG_HTTP_GET_TASK stHttpGetTaskOuterIP;  // 获取外网IP HTTP任务结构体
}ST_MSGMMG_OUTERIP_MNG;


// 获取外网IP管理结构体
ST_MSGMMG_OUTERIP_MNG *MsgMng_OuterIP_GetMng();

// 处理获取设备外网IP流程
_INT MsgMng_ProcGetDevOuterIP(_CTIME_T cTimeNow);

// 获取设备外网IP
_INT MsgMng_GetOuterIP(_INT iCheckOuterIPType);

// 上报时间段内获取设备外网IP的统计数据到云涛
_INT MsgMng_UploadGetDevOuterIPDataToCDLog(_CTIME_T cTimeNow);

#ifdef __cplusplus

}
#endif

#endif