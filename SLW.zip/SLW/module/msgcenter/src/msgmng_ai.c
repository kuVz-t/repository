#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "config_api.h"
#include "config_ai.h"
#include "http_api.h"
#include "tras_httpclient.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_json_adapt.h"
#include "msgmng_devplat.h"
#include "msgmng_cfgbuss.h"
#include "msgmng_ai.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

// AI图片类型
typedef enum enum_AI_PIC_TYPE
{
    EN_AI_PIC_TYPE_FACE   = 1, // 人脸
    EN_AI_PIC_TYPE_CARNUM = 2, // 车牌

}EN_AI_PIC_TYPE;

/**********************************************************************************************
// AIPIC 布控告警消息报警事件上报回复接收
***********************************************************************************************/
_VOID MsgMng_RecvDxUpAIPicAlarmRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    ST_CFG_AI_HTTP_TASK* pstDxUpAIPicAlarmData = MOS_NULL;

    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = Config_FindUploadAIFacePicTaskNode(0, uiReqId);
    if (pstUploadAIFacePicInfNode)
    {
        pstDxUpAIPicAlarmData = &pstUploadAIFacePicInfNode->stDxUpAIPicAlarmData;
        if (pstDxUpAIPicAlarmData)
        {
            if(pstDxUpAIPicAlarmData->usBuffLen == 0)
            {
                pstDxUpAIPicAlarmData->usBuffLen   = 2048;
                pstDxUpAIPicAlarmData->pucHttpBuff = (_UC*)MOS_MALLOC(pstDxUpAIPicAlarmData->usBuffLen);
            }
            if(pstDxUpAIPicAlarmData->usRecvLen + uiLen < pstDxUpAIPicAlarmData->usBuffLen)
            {
                MOS_MEMCPY(pstDxUpAIPicAlarmData->pucHttpBuff + pstDxUpAIPicAlarmData->usRecvLen, pucData, uiLen);
                pstDxUpAIPicAlarmData->usRecvLen += uiLen;
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstDxUpAIPicAlarmData is Null ! uiReqId:%u", uiReqId);
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstUploadAIFacePicInfNode is Null ! uiReqId:%u", uiReqId);
    }
    return;
}

// AIPIC 布控告警消息报警事件上报回复数据 JSON分析 351D
_INT MsgMng_ParseDxUpAIPicAlarmEventRsp(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT iValue       = 0;
    _UC *pStrTmp      = MOS_NULL;
    _UC *pMethod      = MOS_NULL;
    _UI  uiReqId      = 0;
    _UC *pucDevUID    = 0;
    _UC  pucUrl[256]  = {0};
    _UC  aucStrErrLog[128] = {0};
    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE stUploadAIFacePicInfNode = {0};

    _INT i = 0;
    _INT iUploadFaceUrlArrySize          = 0;
    JSON_HANDLE hUploadFaceUrlArry       = MOS_NULL;
    JSON_HANDLE hUploadFaceUrlObject     = MOS_NULL;

    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AIPIC_ALARMEVENT_URL);
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, -1, EN_AI_RT_UPLOAD_FACEREC_PLAT_RSP_JSON_NULL_ERR, 
                                (_UC*)"UpLoad AI FaceRec Alarm Platform RSP JSON Is Null", MOS_NULL, 1);     
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"),(_INT*)&uiReqId);
    stUploadAIFacePicInfNode.uiReqId = uiReqId;
    // MOS_PRINTF("%s:%d: Upload ReqId:%u \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.uiReqId);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pMethod);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
    if (iValue != 0)
    {
        MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AIPIC_ALARMEVENT_URL);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "UpLoad AI FaceRec Alarm Platform RSP JSON Code(%d) Error", iValue);
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, -1, 
                                EN_AI_RT_UPLOAD_FACEREC_PLAT_RSP_CODE_NOT_0_ERR, aucStrErrLog, MOS_NULL, 1);
        return MOS_ERR;
    }
    else
    {
        // 设置 AiFace 节点上报信息
        Config_SetUploadAIFacePicTaskNodeReportInf(0, uiReqId, 1, Mos_Time());

        JSON_HANDLE *hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"DID"), &pucDevUID);
        if(MOS_STRCMP(Config_GetSystemMng()->aucDevUID, pucDevUID) == 0)
        {
            JSON_HANDLE *hBgUrlObject = Adpt_Json_GetObjectItem(hBody, (_UC*)"OriginImage");

            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBgUrlObject, (_UC*)"RequestURL"), &pStrTmp);
            MOS_STRNCPY(stUploadAIFacePicInfNode.ucBgRequestURL, pStrTmp, sizeof(stUploadAIFacePicInfNode.ucBgRequestURL));
            // MOS_PRINTF("%s:%d: Upload BG RequestURL:%s \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.ucBgRequestURL);
            
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBgUrlObject, (_UC*)"RequestDate"), &pStrTmp);
            MOS_STRNCPY(stUploadAIFacePicInfNode.ucBgRequestDate, pStrTmp, sizeof(stUploadAIFacePicInfNode.ucBgRequestDate));
            // MOS_PRINTF("%s:%d: Upload BG RequestDate:%s \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.ucBgRequestDate);
            
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBgUrlObject, (_UC*)"Authorization"), &pStrTmp);
            MOS_STRNCPY(stUploadAIFacePicInfNode.ucBgAuthorization, pStrTmp, sizeof(stUploadAIFacePicInfNode.ucBgAuthorization));
            // MOS_PRINTF("%s:%d: Upload BG Authorization:%s \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.ucBgAuthorization);
            
            // Notifications
            hUploadFaceUrlArry = Adpt_Json_GetObjectItem(hBody,(_UC*)"Notifications");
            iUploadFaceUrlArrySize = Adpt_Json_GetArraySize(hUploadFaceUrlArry);

            iUploadFaceUrlArrySize = 1; // 目前人脸图和背景图一对一
            for(i = 0; i < iUploadFaceUrlArrySize; i++)
            {
                hUploadFaceUrlObject = Adpt_Json_GetArrayItem(hUploadFaceUrlArry,i);

                // 布控标识
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hUploadFaceUrlObject, (_UC*)"DispositionID"), &pStrTmp);
                MOS_STRNCPY(stUploadAIFacePicInfNode.ucDispositionID, pStrTmp, sizeof(stUploadAIFacePicInfNode.ucDispositionID));
                // MOS_PRINTF("%s:%d: Upload AIFACE DispositionID:%s \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.ucDispositionID);

                // 告警标识（流水号）
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hUploadFaceUrlObject, (_UC*)"NotificationID"),&pStrTmp);
                MOS_STRNCPY(stUploadAIFacePicInfNode.ucNotificationID, pStrTmp, sizeof(stUploadAIFacePicInfNode.ucNotificationID));
                // MOS_PRINTF("%s:%d: Upload AIFACE NotificationID:%s \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.ucNotificationID);

                // 消息类型：1、人脸；2、车牌
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hUploadFaceUrlObject, (_UC*)"NotifyType"), &stUploadAIFacePicInfNode.uiNotifyType);
                // MOS_PRINTF("%s:%d: Upload AIFACE NotifyType:%d \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.uiNotifyType);

                // 直连分流的资源池访问地址
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hUploadFaceUrlObject, (_UC*)"RequestURL"), &pStrTmp);
                MOS_STRNCPY(stUploadAIFacePicInfNode.ucFaceRequestURL, pStrTmp, sizeof(stUploadAIFacePicInfNode.ucFaceRequestURL));
                // MOS_PRINTF("%s:%d: Upload AIFACE RequestURL:%s \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.ucFaceRequestURL);

                // 上传请求所需要的时间参数
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hUploadFaceUrlObject, (_UC*)"RequestDate"), &pStrTmp);
                MOS_STRNCPY(stUploadAIFacePicInfNode.ucFaceRequestDate, pStrTmp, sizeof(stUploadAIFacePicInfNode.ucFaceRequestDate));
                // MOS_PRINTF("%s:%d: Upload AIFACE RequestDate:%s \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.ucFaceRequestDate);

                // 上传请求所需要的授权凭证
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hUploadFaceUrlObject, (_UC*)"Authorization"), &pStrTmp);
                MOS_STRNCPY(stUploadAIFacePicInfNode.ucFaceAuthorization, pStrTmp, sizeof(stUploadAIFacePicInfNode.ucFaceAuthorization));
                // MOS_PRINTF("%s:%d: Upload AIFACE Authorization:%s \r\n", __FUNCTION__, __LINE__, stUploadAIFacePicInfNode.ucFaceAuthorization);

                Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
                // 设置上传AIFace任务节点的信息
                Config_SetUploadAIFacePicTaskNodeInfo(0, &stUploadAIFacePicInfNode);
                Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));
            }
        }
        else
        {
            MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AIPIC_ALARMEVENT_URL);
            MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "UpLoad AI FaceRec Alarm Platform RSP DevUid(%s) Error, the right Uid is %s", pucDevUID, Config_GetSystemMng()->aucDevUID);
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, -1, 
                                    EN_AI_RT_UPLOAD_FACEREC_PLAT_RSP_UID_ERR, aucStrErrLog, MOS_NULL, 1);
            Adpt_Json_Delete(hRoot);
            return MOS_ERR; 
        }
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct %u recv upload aipic event rsp code %d method %s", uiReqId, iValue, pMethod);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

// AIPIC 布控告警消息报警事件上报回复数据 351D 成功
_VOID MsgMng_RecvDxUpAIPicAlarmFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_CFG_AI_HTTP_TASK* pstDxUpAIPicAlarmData = MOS_NULL;

    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = Config_FindUploadAIFacePicTaskNode(0, uiReqId);
    if (pstUploadAIFacePicInfNode)
    {
        pstDxUpAIPicAlarmData = &pstUploadAIFacePicInfNode->stDxUpAIPicAlarmData;
        if (pstDxUpAIPicAlarmData)
        {
            if(pstDxUpAIPicAlarmData->pucHttpBuff)
            {
                pstDxUpAIPicAlarmData->pucHttpBuff[pstDxUpAIPicAlarmData->usRecvLen] = 0;
            }
            // AIPIC 布控告警消息报警事件上报回复数据 JSON分析 351D
            _INT iRet = MsgMng_ParseDxUpAIPicAlarmEventRsp(pstDxUpAIPicAlarmData->pucHttpBuff);
            if (iRet != MOS_OK)
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"AI_REC PLATFROM RETURN ERR! uiReqId:%u", uiReqId);
                
                // 通知厂商清除AI图片数据缓存 ADD by LWJ
                if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
                {
                    iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucFaceDataBuf, pstUploadAIFacePicInfNode->pucBgDataBuf);
                    if (MOS_OK == iRet)
                    {
                        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pFunFreeAiPicCache DispositionID:%s OK", pstUploadAIFacePicInfNode->ucDispositionID);
                    }
                    else
                    {
                        _UC aucStrErrLog[128] = {0};
                        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunFreeAiPicCache DispositionID:%s Bgbuf:%p Picbuf:%p return failed", pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucBgDataBuf, pstUploadAIFacePicInfNode->pucFaceDataBuf);        
                        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                                EN_AI_RT_UPLOAD_FACEREC_FUNCFREECACHE_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);   
                    }
                }
                else
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeAiPicCache is NULL!");
                }

                // 从上传AIFace任务节点删除人脸
                Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
                Config_DelUploadAIFacePicTaskNode(0, pstUploadAIFacePicInfNode->uiReqId);
                Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));     
            }
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UpLoad AIPIC Alarm  Event Finish Recv %s",pstDxUpAIPicAlarmData->pucHttpBuff);
            if(pstDxUpAIPicAlarmData->pucHttpBuff)
            {
                MOS_FREE(pstDxUpAIPicAlarmData->pucHttpBuff);
                pstDxUpAIPicAlarmData->pucHttpBuff = MOS_NULL;
            }
            pstDxUpAIPicAlarmData->usBuffLen   = 0;
            pstDxUpAIPicAlarmData->usRecvLen   = 0;
            pstDxUpAIPicAlarmData->uiHttpHandle= 0;
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstDxUpAIPicAlarmData is Null ! uiReqId:%u", uiReqId);
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstUploadAIFacePicInfNode is Null ! uiReqId:%u", uiReqId);
    }

    return ;
}

// AIPIC 布控告警消息报警事件上报回复数据 351D 失败
_VOID MsgMng_RecvDxUpAIPicAlarmFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _INT iRet = 0;
    _UC  pucUrl[256] = {0};
    _UC  aucStrErrLog[128] = {0};

    ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = Config_FindUploadAIFacePicTaskNode(0, uiReqId);
    if (pstUploadAIFacePicInfNode)
    {
        // 通知厂商清除AI图片数据缓存 ADD by LWJ
        if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
        {
            iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucFaceDataBuf, pstUploadAIFacePicInfNode->pucBgDataBuf);
            if (MOS_OK == iRet)
            {
                // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pFunFreeAiPicCache DispositionID:%s OK", pstUploadAIFacePicInfNode->ucDispositionID);
            }
            {
                _UC aucStrErrLog[128] = {0};
                MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunFreeAiPicCache DispositionID:%s Bgbuf:%p Picbuf:%p return failed", pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucBgDataBuf, pstUploadAIFacePicInfNode->pucFaceDataBuf);        
                CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                        EN_AI_RT_UPLOAD_FACEREC_FUNCFREECACHE_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);   
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeAiPicCache is NULL!");
        }
    
        ST_CFG_AI_HTTP_TASK* pstDxUpAIPicAlarmData = MOS_NULL;
        pstDxUpAIPicAlarmData = &pstUploadAIFacePicInfNode->stDxUpAIPicAlarmData; 
        if (pstDxUpAIPicAlarmData)
        {
            if(pstDxUpAIPicAlarmData->pucHttpBuff)
            {
                MOS_FREE(pstDxUpAIPicAlarmData->pucHttpBuff);
                pstDxUpAIPicAlarmData->pucHttpBuff = MOS_NULL;
            }
            pstDxUpAIPicAlarmData->usBuffLen = 0;
            pstDxUpAIPicAlarmData->usRecvLen = 0;
            pstDxUpAIPicAlarmData->uiHttpHandle  = 0;
            }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstDxUpAIPicAlarmData is Null ! uiReqId:%u", uiReqId);
        }

        // 从上传AIFace任务节点删除人脸
        Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
        Config_DelUploadAIFacePicTaskNode(0, pstUploadAIFacePicInfNode->uiReqId);
        Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstUploadAIFacePicInfNode is Null ! uiReqId:%u", uiReqId);
    }

    MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AIPIC_ALARMEVENT_URL);
    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "UpLoad AI FaceRec Alarm Platform RSP Fail(%u) ", uiReqId);
    CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, uiErrCode, 
                            EN_AI_RT_UPLOAD_FACEREC_PLAT_RSP_ERR, aucStrErrLog, MOS_NULL, 1);             

    return;
}

// AIPIC 布控告警消息报警事件上报 JSON拼接 351C
_UC *MsgMng_BuildDxAIPicEventUploadJson(_UI uiKjIoTType,_LLID lluKjIotId,_UI uiKjIoTEventId,_LLID lluHappenTime,_UI uiPushFlag,ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInfo, _UI uiReqId)
{
    MOS_PARAM_NULL_RETNULL(pstAiPicEventInfo);

    _UC *pStrTmp                         = MOS_NULL;
    _UC *pucOutBuff                      = MOS_NULL;
    _UC aucNonce[32]                     = {0};
    _UC aucNonce1[32]                    = {0};
    _UC aucMethod[16]                    = {0};
    _UC aucInBuf[512]                    = {0};
    _UC aucNValue[512]                   = {0};
    _UC aucNValueTmp[512]                = {0};
    _UC aucNotificationID[64]            = {0};
    JSON_HANDLE hBody                    = MOS_NULL;
    JSON_HANDLE hNotificationsArry       = MOS_NULL;
    JSON_HANDLE hNotificationsArryObject = MOS_NULL;
    EN_AI_PIC_TYPE enPicType             = EN_AI_PIC_TYPE_FACE;
    EN_AICFG_LABEL enLabelType           = EN_BLACK_LIST;
    ST_AICFG_LABEL *stAICfgLabel         = NULL;
    ST_ZJ_AIPIC_NODE  *pstAiPicTmpNode   = MOS_NULL;
    JSON_HANDLE hRoot  = Adpt_Json_CreateObject( );

    lluHappenTime = lluHappenTime * 1000;
    
    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDEVENT_AIPIC_ALARM_UPLOAD);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiReqId));

    hBody = Adpt_Json_CreateObject();
    MOS_MEMSET(aucNonce,0,32);
    Mos_GetRandomString(16,aucNonce);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp", Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime))); // - 28800
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Nonce", Adpt_Json_CreateString(aucNonce));
    // Adpt_Json_AddItemToObject(hBody,(_UC*)"PushFlag", Adpt_Json_CreateStrWithNum(uiPushFlag));

    // ST_ZJ_AIPIC_EVENT_INFO
    hNotificationsArry = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Notifications",hNotificationsArry);
    if (pstAiPicEventInfo->pstAiPicHead)
    {
        MOS_MEMSET(aucNonce1, 0, sizeof(aucNonce1));
        Mos_GetRandomString(5, aucNonce1);
        MOS_VSNPRINTF(aucNotificationID, sizeof(aucNotificationID), "%s%llu%s", Config_GetSystemMng()->aucDevUID , lluHappenTime, aucNonce1);
        MOS_VSNPRINTF(aucNValue, sizeof(aucNValue), "%s%s", pstAiPicEventInfo->pstAiPicHead->aucLabelID, aucNotificationID);
        MOS_STRNCPY(aucNValueTmp, aucNValue, sizeof(aucNValueTmp));
        hNotificationsArryObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hNotificationsArry, hNotificationsArryObject);

        if (EN_WHITE_LIST == pstAiPicEventInfo->uiWBList)
        {
            enLabelType = EN_AICFG_LABEL_FACE_WHITELIST;

            // 白名单图片ID置空, 相识度置0
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"DispositionID",Adpt_Json_CreateString((_UC*)""));
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"Similarity",Adpt_Json_CreateStrWithNum(0));
        }
        else
        {
            pstAiPicEventInfo->uiWBList = EN_BLACK_LIST;
            enLabelType = EN_AICFG_LABEL_FACE_BLACKLIST;

            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"DispositionID",Adpt_Json_CreateString(pstAiPicEventInfo->pstAiPicHead->aucLabelID));
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"Similarity",Adpt_Json_CreateStrWithNum(pstAiPicEventInfo->pstAiPicHead->uiSimilarity));
        }

        stAICfgLabel = Get_AICfgLabel();

        Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"NotificationID",Adpt_Json_CreateString(aucNotificationID));
        Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"NotifyType",Adpt_Json_CreateStrWithNum(enPicType));
        Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"UserID",Adpt_Json_CreateString(stAICfgLabel[enLabelType].pucUserID));
        Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"WBList",Adpt_Json_CreateStrWithNum(pstAiPicEventInfo->uiWBList));
        Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"NTimeStamp", Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime)));

        #if 0 // 目前只上传1张图片
        pstAiPicTmpNode = pstAiPicEventInfo->pstAiPicHead->pstNextNode;
        while(pstAiPicTmpNode)
        {
            MOS_MEMSET(aucNonce1, 0, sizeof(aucNonce1));
            MOS_MEMSET(aucNValue, 0, sizeof(aucNValue));
            MOS_MEMSET(aucNotificationID, 0, sizeof(aucNotificationID));
            Mos_GetRandomString(5, aucNonce1);
            MOS_VSNPRINTF(aucNotificationID, sizeof(aucNotificationID), "%s%llu%s", Config_GetSystemMng()->aucDevUID , lluHappenTime, aucNonce1);
            MOS_VSNPRINTF(aucNValue, sizeof(aucNValue), "%s%s%s", aucNValueTmp, pstAiPicTmpNode->aucLabelID, aucNotificationID);
            hNotificationsArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hNotificationsArry, hNotificationsArryObject);
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"DispositionID",Adpt_Json_CreateString(pstAiPicTmpNode->aucLabelID));     
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"NotificationID",Adpt_Json_CreateString(aucNotificationID));
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"NotifyType",Adpt_Json_CreateStrWithNum(enPicType));
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"UserID",Adpt_Json_CreateString("AICFG_USERID"));
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"WBList",Adpt_Json_CreateStrWithNum(1));
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"NTimeStamp", Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime)));
            Adpt_Json_AddItemToObject(hNotificationsArryObject,(_UC*)"Similarity",Adpt_Json_CreateStrWithNum(pstAiPicTmpNode->uiSimilarity));
            pstAiPicTmpNode = pstAiPicTmpNode->pstNextNode;
            MOS_STRNCPY(aucNValueTmp, aucNValue, sizeof(aucNValueTmp));
        }
        #endif
    }

    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);

    MOS_VSNPRINTF(aucInBuf, 512,"DID=%s&Nonce=%s&Notifications=%s&TimeStamp=%llu", Config_GetSystemMng()->aucDevUID, aucNonce, aucNValue, lluHappenTime);
    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,128,Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
    // 添加 UPLOAD_AIFACE_PIC 链表节点
    Config_AddUploadAIFacePicTaskNode(0, uiReqId, lluHappenTime, aucNotificationID, pstAiPicEventInfo);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));

    pStrTmp = Adpt_Json_Print(hRoot);
    MOS_PRINTF("AIPIC EVENT INPUT pStrTmp:%s \r\n", pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}

// AIPic布控告警消息事件推送到云端 351C
_INT MsgMng_UploadAIPicEventToDxServer(_UI uiKjIoTType, _LLID lluKjIotId, _UI uiKjIoTEventId, ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInfo)
{
    if (MsgMng_GetStartWorkFlag() == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Get StartWorkFlag is %d", MsgMng_GetStartWorkFlag());
        return MOS_OK;
    }

    _INT i,iRet          = 0;
    _US usPort           = 80;
    _UI  uiHttpHandle    = 1000;
    _UI uiPushFlag  = 1;
    _UI uiHttpsFlag = 0;
    _UC *pStrTmp    = MOS_NULL;
    _UC *pStrStart  = MOS_NULL;
    _UC auAdmonAddr[128] = {0};

    _CTIME_T cHappentime = 0;
    if (pstAiPicEventInfo->lluTimeStamp == 0)
    {
        cHappentime = Mos_Time();
    }
    else
    {
        cHappentime = pstAiPicEventInfo->lluTimeStamp;
    }

    MOS_MEMSET(auAdmonAddr, 0, 128);

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucAlarmAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 
    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucAlarmAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucAlarmAddr;
    }
    else
    {
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRNCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"HxLink Begain Send AIPIC EventAlarm ,Plataddr %s",Config_GetSystemMng()->aucAlarmAddr);
    
    // AIPIC 布控告警消息报警事件上报 JSON拼接 351C
    _UI uiReqId = Mos_GetSessionId();
    pStrTmp = MsgMng_BuildDxAIPicEventUploadJson(uiKjIoTType,lluKjIotId,uiKjIoTEventId,(_LLID)cHappentime,uiPushFlag,pstAiPicEventInfo, uiReqId);
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = MsgMng_RecvDxUpAIPicAlarmRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_RecvDxUpAIPicAlarmFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_RecvDxUpAIPicAlarmFail;
    stHttpInfoNode.iTimeOut        = 30;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, HTTP_AIPIC_ALARMEVENT_URL, EN_HTTP_METHOD_POST, uiReqId);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC  pucUrl[128] = {0};
        _UC  aucStrErrLog[128] = {0};
        MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucPuAddr, HTTP_AIPIC_ALARMEVENT_URL);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Upload FaceRec Pic get Host(%s) port(%u) AddrInfo error", auAdmonAddr, usPort);
                CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, -1, 
                                        EN_AI_RT_UPLOAD_FACEREC_URL_GET_HOST_ADDRINFO_ERR, aucStrErrLog, MOS_NULL, 1);
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct  dev %s ,send AIPIC alarmEvent %s to alarmPlatAddr %s ,ret %d",
        Config_GetSystemMng()->aucDevUID, pStrTmp, auAdmonAddr, iRet);
    if (MOS_OK != iRet)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"send AIPIC alarmEvent Add http(s) error!");
        ST_CFG_UPLOAD_AIFACE_PIC_INF_NODE *pstUploadAIFacePicInfNode = Config_FindUploadAIFacePicTaskNode(0, uiReqId);
        if (pstUploadAIFacePicInfNode)
        {
            // 通知厂商清除AI图片数据缓存 ADD by LWJ
            if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
            {
                iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucFaceDataBuf, pstUploadAIFacePicInfNode->pucBgDataBuf);
                if (MOS_OK == iRet)
                {
                    // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pFunFreeAiPicCache DispositionID:%s OK", pstUploadAIFacePicInfNode->ucDispositionID);
                }
                {
                    _UC aucStrErrLog[128] = {0};
                    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunFreeAiPicCache DispositionID:%s Bgbuf:%p Picbuf:%p return failed", pstUploadAIFacePicInfNode->ucDispositionID, pstUploadAIFacePicInfNode->pucBgDataBuf, pstUploadAIFacePicInfNode->pucFaceDataBuf);        
                    CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                            EN_AI_RT_UPLOAD_FACEREC_FUNCFREECACHE_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);   
                }
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunFreeAiPicCache is NULL!");
            }

            // 从上传AIFace任务节点删除人脸
            Mos_MutexLock(&(Config_GetAIMng()->hUpLoadMutex));
            Config_DelUploadAIFacePicTaskNode(0, pstUploadAIFacePicInfNode->uiReqId);
            Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadMutex));
        } 
    }

    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

/**********************************************************************************************
// AI识别消息(ZIP打包)上传回复接收 3523
***********************************************************************************************/
_VOID MsgMng_RecvDxUpAIZipEventRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    ST_CFG_AI_HTTP_TASK* pstDxUpAIZipEventData = MOS_NULL;

    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = Config_FindUploadAIZipTaskNode(0, uiReqId);
    if (pstUploadAIZipInfNode)
    {
        pstDxUpAIZipEventData = &pstUploadAIZipInfNode->stDxUpAIZipEventData;
        if (pstDxUpAIZipEventData)
        {
            if(pstDxUpAIZipEventData->usBuffLen == 0)
            {
                pstDxUpAIZipEventData->usBuffLen   = 2048;
                pstDxUpAIZipEventData->pucHttpBuff = (_UC*)MOS_MALLOC(pstDxUpAIZipEventData->usBuffLen);
            }
            if(pstDxUpAIZipEventData->usRecvLen + uiLen < pstDxUpAIZipEventData->usBuffLen)
            {
                MOS_MEMCPY(pstDxUpAIZipEventData->pucHttpBuff + pstDxUpAIZipEventData->usRecvLen, pucData, uiLen);
                pstDxUpAIZipEventData->usRecvLen += uiLen;
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstDxUpAIZipEventData is Null ! uiReqId:%u", uiReqId);
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstUploadAIZipInfNode is Null ! uiReqId:%u", uiReqId);
    }
    return;
}

// AI识别消息(ZIP打包)上传回复数据 JSON分析 3523
_INT MsgMng_ParseDxUpAIZipEventRsp(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT iValue       = 0;
    _UC *pStrTmp      = MOS_NULL;
    _UC *pMethod      = MOS_NULL;
    _UC *pucDevUID    = 0;
    _UC  pucUrl[256]  = {0};
    _UC  aucStrErrLog[128] = {0};
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE stUploadAIZipInfNode = {0};

    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AI_RECOGNITIONV2_URL);
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, -1, EN_AI_RT_UPLOAD_ZIP_PLAT_RSP_JSON_NULL_ERR, 
                                (_UC*)"UpLoad AI ZIP Alarm Platform RSP JSON Is Null", MOS_NULL, 1);   
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"),(_INT*)&stUploadAIZipInfNode.uiReqId);
    MOS_PRINTF("%s:%d: ZipFile  uiReqId:%u \r\n", __FUNCTION__, __LINE__, stUploadAIZipInfNode.uiReqId);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pMethod);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);
    if (iValue != 0)
    {
        MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AIPIC_ALARMEVENT_URL);
        MOS_SPRINTF(aucStrErrLog, "UpLoad AI ZIP Alarm Platform RSP JSON Code(%d) Error", iValue);
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, -1, 
                                EN_AI_RT_UPLOAD_ZIP_PLAT_RSP_CODE_NOT_0_ERR, aucStrErrLog, MOS_NULL, 1);
        return MOS_ERR;
    }
    else
    {
        // 设置 AIZIP 节点上报信息
        Config_SetUploadAIZipTaskNodeReportInf(0, stUploadAIZipInfNode.uiReqId, 1, Mos_Time());

        JSON_HANDLE *hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"DID"), &pucDevUID);
        if(MOS_STRCMP(Config_GetSystemMng()->aucDevUID, pucDevUID) == 0)
        {
            JSON_HANDLE *hZipFileObject = Adpt_Json_GetObjectItem(hBody, (_UC*)"ZipFile");

            // 打包文件直连分流的资源池访问地址
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hZipFileObject, (_UC*)"RequestURL"), &pStrTmp);
            MOS_STRNCPY(stUploadAIZipInfNode.ucZipRequestURL, pStrTmp, sizeof(stUploadAIZipInfNode.ucZipRequestURL));
            // MOS_PRINTF("%s:%d: ZipFile  RequestURL:%s \r\n", __FUNCTION__, __LINE__, stUploadAIZipInfNode.ucZipRequestURL);
            
            // 打包文件上传请求所需要的时间参数
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hZipFileObject, (_UC*)"RequestDate"), &pStrTmp);
            MOS_STRNCPY(stUploadAIZipInfNode.ucZipRequestDate, pStrTmp, sizeof(stUploadAIZipInfNode.ucZipRequestDate));
            // MOS_PRINTF("%s:%d: ZipFile  RequestDate:%s \r\n", __FUNCTION__, __LINE__, stUploadAIZipInfNode.ucZipRequestDate);
            
            // 上传请求所需要的授权凭证
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hZipFileObject, (_UC*)"Authorization"), &pStrTmp);
            MOS_STRNCPY(stUploadAIZipInfNode.ucZipAuthorization, pStrTmp, sizeof(stUploadAIZipInfNode.ucZipAuthorization));
            // MOS_PRINTF("%s:%d: ZipFile  Authorization:%s \r\n", __FUNCTION__, __LINE__, stUploadAIZipInfNode.ucZipAuthorization);

            Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
            // 设置上传AI_ZIP任务节点的信息
            Config_SetUploadAIZipTaskNodeInfo(0, &stUploadAIZipInfNode);
            Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));
        }
        else
        {
            MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AI_RECOGNITIONV2_URL);
            MOS_SPRINTF(aucStrErrLog, "UpLoad AI ZIP Alarm Platform RSP DevUID(%s) Error, the right Uid is %s", pucDevUID, Config_GetSystemMng()->aucDevUID);
            CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, -1, 
                                    EN_AI_RT_UPLOAD_ZIP_PLAT_RSP_UID_ERR, aucStrErrLog, MOS_NULL, 1);
            Adpt_Json_Delete(hRoot);
            return MOS_ERR;  
        }
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Uid:%s ogct %u recv upload AI Zip Event rsp code %d method %s", pucDevUID, stUploadAIZipInfNode.uiReqId, iValue, pMethod);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

// AI识别消息(ZIP打包)上传回复数据  3523 成功
_VOID MsgMng_RecvDxUpAIZipEventFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_CFG_AI_HTTP_TASK* pstDxUpAIZipEventData = MOS_NULL;
   
    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = Config_FindUploadAIZipTaskNode(0, uiReqId);
    if (pstUploadAIZipInfNode)
    {
        pstDxUpAIZipEventData = &pstUploadAIZipInfNode->stDxUpAIZipEventData;
        if (pstDxUpAIZipEventData)
        {
            if(pstDxUpAIZipEventData->pucHttpBuff)
            {
                pstDxUpAIZipEventData->pucHttpBuff[pstDxUpAIZipEventData->usRecvLen] = 0;
            }
            // AI识别消息(ZIP打包)上传回复数据 JSON分析 3523
            _INT iRet = MsgMng_ParseDxUpAIZipEventRsp(pstDxUpAIZipEventData->pucHttpBuff);
            if (iRet != MOS_OK)
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"AI_ZIP PLATFROM RETURN ERR! uiReqId:%u", uiReqId);

                // 删除ZIP文件
                Mos_FileRmv(pstUploadAIZipInfNode->ucZipFilePath);

                // 从上传AI_ZIP任务节点删除人脸
                Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
                Config_DelUploadAIZipTaskNode(0, pstUploadAIZipInfNode->uiReqId);
                Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));
            }
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UpLoad AI Zip Event Finish Recv %s",pstDxUpAIZipEventData->pucHttpBuff);
            if (pstDxUpAIZipEventData->pucHttpBuff)
            {
                MOS_FREE(pstDxUpAIZipEventData->pucHttpBuff);
                pstDxUpAIZipEventData->pucHttpBuff = MOS_NULL;
            }
            pstDxUpAIZipEventData->usBuffLen   = 0;
            pstDxUpAIZipEventData->usRecvLen   = 0;
            pstDxUpAIZipEventData->uiHttpHandle= 0;
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstDxUpAIZipEventData is Null ! uiReqId:%u", uiReqId);
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstUploadAIZipInfNode is Null ! uiReqId:%u", uiReqId);
    }

    return ;
}

// AI识别消息(ZIP打包)上传回复数据  3523 失败
_VOID MsgMng_RecvDxUpAIZipEventFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC pucUrl[256] = {0};
    _UC  aucStrErrLog[128] = {0};

    ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = Config_FindUploadAIZipTaskNode(0, uiReqId);
    if (pstUploadAIZipInfNode)
    {
        ST_CFG_AI_HTTP_TASK* pstDxUpAIZipEventData = MOS_NULL;
        pstDxUpAIZipEventData = &pstUploadAIZipInfNode->stDxUpAIZipEventData;
        if (pstDxUpAIZipEventData)
        {
            if(pstDxUpAIZipEventData->pucHttpBuff)
            {
                MOS_FREE(pstDxUpAIZipEventData->pucHttpBuff);
                pstDxUpAIZipEventData->pucHttpBuff = MOS_NULL;
            }
            pstDxUpAIZipEventData->usBuffLen = 0;
            pstDxUpAIZipEventData->usRecvLen = 0;
            pstDxUpAIZipEventData->uiHttpHandle  = 0;
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstDxUpAIZipEventData is Null ! uiReqId:%u", uiReqId);
        }

        // 删除ZIP文件
        Mos_FileRmv(pstUploadAIZipInfNode->ucZipFilePath);

        // 从上传AI_ZIP任务节点删除人脸
        Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
        Config_DelUploadAIZipTaskNode(0, pstUploadAIZipInfNode->uiReqId);
        Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstUploadAIZipInfNode is Null ! uiReqId:%u", uiReqId);
    }
 
    MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AI_RECOGNITIONV2_URL);
    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "UpLoad AI ZIP Alarm Platform RSP Fail(%u)", uiReqId);
    CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, uiErrCode, 
                            EN_AI_RT_UPLOAD_ZIP_PLAT_RSP_ERR, aucStrErrLog, MOS_NULL, 1);            

    return;
}

// AI识别消息(ZIP打包)上传到云端 JSON拼接 3522
_UC *MsgMng_BuildDxAIZipEventUploadJson(_UI uiKjIoTType,_LLID lluKjIotId,_UI uiKjIoTEventId,_LLID lluHappenTime, ST_ZJ_AI_ZIP_EVENT_SIGNAL *pstZipEventInfo, _UI uiReqId)
{
    MOS_PARAM_NULL_RETNULL(pstZipEventInfo);

    _UC *pStrTmp                         = MOS_NULL;
    _UC *pucOutBuff                      = MOS_NULL;
    _UC aucNonce[32]                     = {0};
    _UC aucNonce1[32]                    = {0};
    _UC aucMethod[16]                    = {0};
    _UC aucInBuf[512]                    = {0};
    _UC aucNValue[512]                   = {0};
    _UC aucNValueTmp[512]                = {0};
    _UC aucObjectID[64]                  = {0};
    JSON_HANDLE hBody                    = MOS_NULL;
    JSON_HANDLE hItemsArry               = MOS_NULL;
    JSON_HANDLE hItemsArryObject         = MOS_NULL;
    JSON_HANDLE hSubItemsArry            = MOS_NULL;
    JSON_HANDLE hSubItemsArryObject      = MOS_NULL;
    EN_AI_PIC_TYPE enPicType             = EN_AI_PIC_TYPE_FACE;
    ST_ZJ_ZIP_AIFACEFILE_INFO  *pstAiFaceFileTmpNode = MOS_NULL;
    JSON_HANDLE hRoot  = Adpt_Json_CreateObject();

    if (pstZipEventInfo->pstZipBgFileHead->lluTimeStamp == 0)
    {
        lluHappenTime = lluHappenTime * 1000;
    }
    else
    {
        lluHappenTime = pstZipEventInfo->pstZipBgFileHead->lluTimeStamp;
    }

    // 图片类型
    switch (uiKjIoTType)
    {
        case EN_ZJ_AIIOT_TYPE_FACE_CAPTURE:// 新人脸抓拍
        {
            enPicType = EN_AI_PIC_TYPE_FACE;
            break;
        }
        case EN_ZJ_AIIOT_TYPE_MOTION:
        {
            if (EN_ZJ_MOTION_EVENT_CARNUM_DISCERN == uiKjIoTEventId)// 车牌
            {
                enPicType = EN_AI_PIC_TYPE_CARNUM;
            }
            else if (EN_ZJ_MOTION_EVENT_FACE == uiKjIoTEventId)// 旧人脸抓拍
            {
                enPicType = EN_AI_PIC_TYPE_FACE;
            }
            else
            {
                enPicType = EN_AI_PIC_TYPE_FACE;
            }
            break;
        }
        default:
            enPicType = EN_AI_PIC_TYPE_FACE;
            break;
    }

    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDEVENT_AI_RECOGNITIONV2_UPLOAD);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",  Adpt_Json_CreateStrWithNum(uiReqId));

    hBody = Adpt_Json_CreateObject();
    MOS_MEMSET(aucNonce,0,32);
    Mos_GetRandomString(16,aucNonce);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID", Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp", Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime)));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Nonce", Adpt_Json_CreateString(aucNonce));

    hItemsArry = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Items",hItemsArry);
    hItemsArryObject = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToArray(hItemsArry, hItemsArryObject);
    Adpt_Json_AddItemToObject(hItemsArryObject,(_UC*)"OriginName",Adpt_Json_CreateString(pstZipEventInfo->pstZipBgFileHead->aucBgFileName));     
    Adpt_Json_AddItemToObject(hItemsArryObject,(_UC*)"CaptureTime", Adpt_Json_CreateStrWithNum((_DOUBLE)(lluHappenTime)));

    MOS_VSNPRINTF(aucNValue, 512, "%s%llu", pstZipEventInfo->pstZipBgFileHead->aucBgFileName, lluHappenTime);
    MOS_STRNCPY(aucNValueTmp, aucNValue, sizeof(aucNValueTmp));

    hSubItemsArry = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hItemsArryObject,(_UC*)"SubItems",hSubItemsArry);   

    if (pstZipEventInfo->pstZipBgFileHead->pstZipFaceFileHead)
    {
        MOS_MEMSET(aucNValue, 0, sizeof(aucNValue));
        MOS_MEMSET(aucNonce1, 0, sizeof(aucNonce1));
        Mos_GetRandomString(5, aucNonce1);
        MOS_VSNPRINTF(aucObjectID, 512, "%s%llu%s", Config_GetSystemMng()->aucDevUID, lluHappenTime, aucNonce1);
        hSubItemsArryObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hSubItemsArry, hSubItemsArryObject);
        Adpt_Json_AddItemToObject(hSubItemsArryObject,(_UC*)"ObjectName",Adpt_Json_CreateString(pstZipEventInfo->pstZipBgFileHead->pstZipFaceFileHead->aucFaceFileName));     
        Adpt_Json_AddItemToObject(hSubItemsArryObject,(_UC*)"ObjectID",Adpt_Json_CreateString(aucObjectID));
        Adpt_Json_AddItemToObject(hSubItemsArryObject,(_UC*)"RType",Adpt_Json_CreateStrWithNum(enPicType));
        Adpt_Json_AddItemToObject(hSubItemsArryObject,(_UC*)"ObjectValue",Adpt_Json_CreateString(pstZipEventInfo->pstZipBgFileHead->pstZipFaceFileHead->aucCarNum));
        MOS_VSNPRINTF(aucNValue, 512, "%s%s%s", aucNValueTmp, aucObjectID, pstZipEventInfo->pstZipBgFileHead->pstZipFaceFileHead->aucFaceFileName);
        MOS_STRNCPY(aucNValueTmp, aucNValue, sizeof(aucNValueTmp));
#if 0 // 目前只上传1张图片
        pstAiFaceFileTmpNode = pstZipEventInfo->pstZipBgFileHead->pstZipFaceFileHead->pstNextNode;
        while(pstAiFaceFileTmpNode)
        {
            MOS_MEMSET(aucNValue, 0, sizeof(aucNValue));
            MOS_MEMSET(aucNonce1, 0, sizeof(aucNonce1));
            Mos_GetRandomString(5, aucNonce1);
            MOS_VSNPRINTF(aucObjectID, 512, "%s%llu%s", Config_GetSystemMng()->aucDevUID , lluHappenTime, aucNonce1);
            hSubItemsArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hSubItemsArry, hSubItemsArryObject);
            Adpt_Json_AddItemToObject(hSubItemsArryObject,(_UC*)"ObjectName",Adpt_Json_CreateString(pstAiFaceFileTmpNode->aucFaceFileName));     
            Adpt_Json_AddItemToObject(hSubItemsArryObject,(_UC*)"ObjectID",Adpt_Json_CreateString(aucObjectID));
            Adpt_Json_AddItemToObject(hSubItemsArryObject,(_UC*)"RType",Adpt_Json_CreateStrWithNum(enPicType));
            Adpt_Json_AddItemToObject(hSubItemsArryObject,(_UC*)"ObjectValue",Adpt_Json_CreateString(pstAiFaceFileTmpNode->aucCarNum));
            MOS_VSNPRINTF(aucNValue, 512, "%s%s%s", aucNValueTmp, aucObjectID, pstAiFaceFileTmpNode->aucFaceFileName);
            MOS_STRNCPY(aucNValueTmp, aucNValue, sizeof(aucNValueTmp));

            pstAiFaceFileTmpNode = pstAiFaceFileTmpNode->pstNextNode;
        }
#endif
    }

    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);

    MOS_VSNPRINTF(aucInBuf, 512,"DID=%s&Items=%s&Nonce=%s&TimeStamp=%llu", Config_GetSystemMng()->aucDevUID, aucNValue, aucNonce, lluHappenTime);
    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,128,Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

    Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
    // 添加 UPLOAD_AI_ZIP_INF 链表节点
    Config_AddUploadAIZipTaskNode(0, uiReqId, lluHappenTime, pstZipEventInfo->aucFilePath);
    Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));

    pStrTmp = Adpt_Json_Print(hRoot);

    MOS_PRINTF("AIZIP EVENT INPUT pStrTmp:%s \r\n", pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}

// AI识别消息(ZIP打包)上传到云端 3522
_INT MsgMng_UploadAIZipEventToDxServer(_UI uiKjIoTType, _LLID lluKjIotId, _UI uiKjIoTEventId, ST_ZJ_AI_ZIP_EVENT_SIGNAL *pstZipEventInfo)
{
    if (MsgMng_GetStartWorkFlag() == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Get StartWorkFlag is %d", MsgMng_GetStartWorkFlag());
        return MOS_OK;
    }

    _INT i,iRet          = 0;
    _US usPort           = 80;
    _UI  uiHttpHandle    = 1000;
    _UI uiHttpsFlag = 0;
    _UC *pStrTmp    = MOS_NULL;
    _UC *pStrStart  = MOS_NULL;
    _UC auAdmonAddr[128] = {0};
    _CTIME_T cHappentime = 0;
    cHappentime = Mos_Time();

    MOS_MEMSET(auAdmonAddr, 0, 128);

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucAlarmAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 
    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucAlarmAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucAlarmAddr;
    }
    else
    {
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRNCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"HxLink Begain Send AI Zip Event ,Plataddr %s",Config_GetSystemMng()->aucAlarmAddr);
    // AI识别消息(ZIP打包)上传到云端 JSON拼接 3522
    _UI uiReqId = Mos_GetSessionId();
    pStrTmp = MsgMng_BuildDxAIZipEventUploadJson(uiKjIoTType,lluKjIotId,uiKjIoTEventId,(_LLID)cHappentime,pstZipEventInfo, uiReqId);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = MsgMng_RecvDxUpAIZipEventRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_RecvDxUpAIZipEventFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_RecvDxUpAIZipEventFail;
    stHttpInfoNode.iTimeOut        = 60;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, HTTP_AI_RECOGNITIONV2_URL, EN_HTTP_METHOD_POST, uiReqId);
    if (iRet == EN_HTTP_RET_GETHOSTBYNAME_ERR)
    {
        _UC  pucUrl[128] = {0};
        _UC  aucStrErrLog[128] = {0};
        MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucPuAddr, HTTP_AI_RECOGNITIONV2_URL);
        MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "UpLoad AI ZIP Pic get Host(%s) port(%d) AddrInfo error", auAdmonAddr, usPort);
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, -1, 
                                EN_AI_RT_UPLOAD_ZIP_URL_GET_HOST_ADDRINFO_ERR, aucStrErrLog, MOS_NULL, 1);
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct  dev %s ,send AI Zip Event %s to alarmPlatAddr %s ,ret %d",
        Config_GetSystemMng()->aucDevUID, pStrTmp, auAdmonAddr, iRet);

    if (MOS_OK != iRet)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"send AI Zip Event Add http(s) error!");
        ST_CFG_UPLOAD_AI_ZIP_INF_NODE *pstUploadAIZipInfNode = Config_FindUploadAIZipTaskNode(0, uiReqId);
        if (pstUploadAIZipInfNode)
        {
            // 删除ZIP文件
            Mos_FileRmv(pstUploadAIZipInfNode->ucZipFilePath);

            // 从上传AI_ZIP任务节点删除人脸
            Mos_MutexLock(&(Config_GetAIMng()->hUpLoadZipMutex));
            Config_DelUploadAIZipTaskNode(0, pstUploadAIZipInfNode->uiReqId);
            Mos_MutexUnLock(&(Config_GetAIMng()->hUpLoadZipMutex));
        }
    }

    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}

/**********************************************************************************************
// 上传客流统计到云端回复数据  3521
***********************************************************************************************/
_VOID MsgMng_RecvDxUpHumanCountInfRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    ST_CFG_AI_HTTP_TASK* pstDxUpHumanCountData = MOS_NULL;

    pstDxUpHumanCountData = &Config_GetAIMng()->stDxUpHumanCountData;
    if(pstDxUpHumanCountData->usBuffLen == 0)
    {
        pstDxUpHumanCountData->usBuffLen   = 2048;
        pstDxUpHumanCountData->pucHttpBuff = (_UC*)MOS_MALLOC(pstDxUpHumanCountData->usBuffLen);
    }
    if(pstDxUpHumanCountData->usRecvLen + uiLen < pstDxUpHumanCountData->usBuffLen)
    {
        MOS_MEMCPY(pstDxUpHumanCountData->pucHttpBuff + pstDxUpHumanCountData->usRecvLen, pucData, uiLen);
        pstDxUpHumanCountData->usRecvLen += uiLen;
    }
    return;
}

// 上传客流统计到云端回复数据  3521 JSON分析
_INT MsgMng_ParseDxUpHumanCountInfRsp(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT iValue       = 0;
    _UC *pMethod      = MOS_NULL;
    _UI  uiReqId      = 0;

    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {        
        CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, -1, "HumanCount Parse HumanCountInfoRsp Is Null", MOS_NULL, 1);       
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"),(_INT*)&uiReqId);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"),&pMethod);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CODE"),&iValue);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct %u recv upload Human Count Info rsp code %d method %s", uiReqId, iValue, pMethod);
    Adpt_Json_Delete(hRoot);

    return MOS_OK;
}

// 上传客流统计到云端回复数据  3521 成功
_VOID MsgMng_RecvDxUpHumanCountInfFinish(_VPTR vpUserPtr, _UI uiReqId, _UI uiUseTime)
{
    ST_CFG_AI_HTTP_TASK* pstDxUpHumanCountData = MOS_NULL;

    pstDxUpHumanCountData = &Config_GetAIMng()->stDxUpHumanCountData;    
    if(pstDxUpHumanCountData->pucHttpBuff)
    {
        pstDxUpHumanCountData->pucHttpBuff[pstDxUpHumanCountData->usRecvLen] = 0;
    }
    // 上传客流统计到云端回复数据 JSON分析 3521
    MsgMng_ParseDxUpHumanCountInfRsp(pstDxUpHumanCountData->pucHttpBuff);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UpLoad Human Count Info Finish Recv %s",pstDxUpHumanCountData->pucHttpBuff);
    MOS_FREE(pstDxUpHumanCountData->pucHttpBuff);
    pstDxUpHumanCountData->pucHttpBuff   = MOS_NULL;
    pstDxUpHumanCountData->usBuffLen     = 0;
    pstDxUpHumanCountData->usRecvLen     = 0;
    pstDxUpHumanCountData->uiHttpHandle  = 0;
    pstDxUpHumanCountData->uiAsyncStatus = EN_AI_HTTP_ASYNC_STATUS_NOTRANS;
    return ;
}

// 上传客流统计到云端回复数据  3521 失败
_VOID MsgMng_RecvDxUpHumanCountInfFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId, _UI uiUseTime)
{
    _UC pucUrl[256] = {0};
    ST_CFG_AI_HTTP_TASK* pstDxUpHumanCountData = MOS_NULL;
    pstDxUpHumanCountData = &Config_GetAIMng()->stDxUpHumanCountData;

    MOS_SPRINTF(pucUrl, "%s%s", Config_GetSystemMng()->aucAlarmAddr, HTTP_AI_RECOGNITIONV2_URL);
    CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), pucUrl, uiErrCode, -1, "Human Count Info upload error", MOS_NULL, 1);             
            
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UpLoad Human Count Info Fail(%d)", uiReqId);
    CloudStg_UploadLogEx2(AICFG_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, -1, "HumanCount Send HumanCountInfo Failed", MOS_NULL, 1);       
    
    if(pstDxUpHumanCountData->pucHttpBuff)
    {
        MOS_FREE(pstDxUpHumanCountData->pucHttpBuff);
        pstDxUpHumanCountData->pucHttpBuff = MOS_NULL;
    }
    pstDxUpHumanCountData->usBuffLen     = 0;
    pstDxUpHumanCountData->usRecvLen     = 0;
    pstDxUpHumanCountData->uiHttpHandle  = 0;
    pstDxUpHumanCountData->uiAsyncStatus = EN_AI_HTTP_ASYNC_STATUS_NOTRANS;
    return;
}

// 上传客流统计到云端 3520
_UC *MsgMng_BuildDxHumanCountInfUploadJson(_UI uiHumInNum, _UI uiHumOutNum, _UC *pucStartDate, _UC *pucEndDate, _LLID lluHappenTime, _UI uiReqId)
{
    _UC aucNonce[32]  = {0};
    _UC aucMethod[16] = {0};
    _UC aucInBuf[512] = {0};
    _UC *pucOutBuff   = MOS_NULL;
    _UC *pStrTmp      = MOS_NULL;
    
    _UC aucHappenTime[64] = {0};
    MOS_VSNPRINTF(aucHappenTime, 64, "%llu000",lluHappenTime);

    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CLOUDEVENT,EN_OGCT_CLOUDEVENT_AI_HUMANCOUNT);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",  Adpt_Json_CreateStrWithNum(uiReqId));

    hBody = Adpt_Json_CreateObject();
    MOS_MEMSET(aucNonce,0,32);
    Mos_GetRandomString(16,aucNonce);

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    Adpt_Json_AddItemToObject(hBody,(_UC*)"DID",        Adpt_Json_CreateString(Config_GetSystemMng()->aucDevUID));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"TimeStamp",  Adpt_Json_CreateString(aucHappenTime));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Nonce",      Adpt_Json_CreateString(aucNonce));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"StartDate",  Adpt_Json_CreateString(pucStartDate));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"EndDate",    Adpt_Json_CreateString(pucEndDate));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Incoming",   Adpt_Json_CreateStrWithNum(uiHumInNum));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Outgoing",   Adpt_Json_CreateStrWithNum(uiHumOutNum));

    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);

    MOS_VSNPRINTF(aucInBuf, 512,"DID=%s&EndDate=%s&Incoming=%d&Nonce=%s&Outgoing=%d&StartDate=%s&TimeStamp=%s", 
            Config_GetSystemMng()->aucDevUID, pucEndDate, uiHumInNum, aucNonce, uiHumOutNum, pucStartDate, aucHappenTime);
    
    // MOS_PRINTF_DEBUG("aucInBuf:%s aucDevkey = %s\r\n", aucInBuf,Config_GetSystemMng()->aucDevkey);
    
    Adpt_HmacSha256_Encrypt(aucInBuf, pucOutBuff, 128, Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

    pStrTmp = Adpt_Json_Print(hRoot);

    MOS_PRINTF("Human Count Info Upload pStrTmp:%s \r\n", pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);

    return pStrTmp;
}

// 上传客流统计到云端 3520
_INT MsgMng_UploadHumanCountInfToDxServer(_UI uiHumInNum, _UI uiHumOutNum, _UC *pucStartDate, _UC *pucEndDate)
{
    ST_CFG_AI_HTTP_TASK* pstDxUpHumanCountData = &Config_GetAIMng()->stDxUpHumanCountData;
    if (MsgMng_GetStartWorkFlag() == 0 || pstDxUpHumanCountData->uiAsyncStatus == EN_AI_HTTP_ASYNC_STATUS_TRANSED)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Get StartWorkFlag is %d  uiAsyncStatus is %d", MsgMng_GetStartWorkFlag(), pstDxUpHumanCountData->uiAsyncStatus);
        return MOS_OK;
    }
    
    _INT i,iRet          = 0;
    _US  usPort          = 80;
    _UI  uiHttpHandle    = 1000;
    _UI uiHttpsFlag = 0;
    _UC *pStrTmp    = MOS_NULL;
    _UC *pStrStart  = MOS_NULL;
    _UC auAdmonAddr[128] = {0};
    _CTIME_T cHappentime = Mos_Time();

    MOS_MEMSET(auAdmonAddr, 0, 128);

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucAlarmAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 
    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucAlarmAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucAlarmAddr;
    }
    else
    {
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else{
        MOS_STRNCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"HxLink Begain Send Human Count Info ,Plataddr %s",Config_GetSystemMng()->aucAlarmAddr);

    pstDxUpHumanCountData->uiAsyncStatus = EN_AI_HTTP_ASYNC_STATUS_TRANSED;

    // 上传客流统计到云端 3520 JSON拼接
    _UI uiReqId = Mos_GetSessionId();
    pStrTmp = MsgMng_BuildDxHumanCountInfUploadJson(uiHumInNum, uiHumOutNum, pucStartDate, pucEndDate, (_LLID)cHappentime, uiReqId);
    
    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = MsgMng_RecvDxUpHumanCountInfRsp;
    stHttpInfoNode.pfuncFinished   = MsgMng_RecvDxUpHumanCountInfFinish;
    stHttpInfoNode.pfuncFailed     = MsgMng_RecvDxUpHumanCountInfFail;
    stHttpInfoNode.iTimeOut        = 30;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, HTTP_HUMANCOUNTNUM_URL, EN_HTTP_METHOD_POST, uiReqId);
    if (iRet != MOS_OK)
    {
        pstDxUpHumanCountData->uiAsyncStatus = EN_AI_HTTP_ASYNC_STATUS_NOTRANS;
    }
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"ogct  dev %s ,send Human Count Info %s to alarmPlatAddr %s ,ret %d",
        Config_GetSystemMng()->aucDevUID, pStrTmp, auAdmonAddr, iRet);

    MOS_FREE(pStrTmp);
    return (iRet == MOS_OK)?MOS_OK:MOS_ERR;
}