#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "config_api.h"
#include "http_api.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_json_adapt.h"
#include "msgmng_multimedia.h"
#include "msgmng_devplat.h"
#include "msgmng_cfgbuss.h"
#include "msgmng_event.h"
#include "msgmng_cmd.h"
#include "msgmng_outerip.h"
#include "p2p_connect.h"
#include "config_ap.h"
#include "kj_timer.h"
#include "watchdog_api.h"
#include "qualityprobe_api.h"
#include "cloudstg_logcode.h"

#include "msgmng_pdm.h"
#include "msgmng_smart_home.h"
#include "msgmng_quality_statistics.h"
#include "msgmng_utc.h"

#ifdef BUILD_SUPPORT_MSGTEST_FALG
#include "msgtest.h"
#endif

#ifdef BUILD_IMSSDK_FALG
#include "ims_api.h"
#endif

static _HSWDWRITE    g_hSwdMsgMngFeedDog;
static kj_timer_t    g_tMsgMngFeedDogTimeOut;

// 请求平台时间
#define UTC_REQ_INTERVAL (3 * 3600) // UTC请求时间间隔, 3小时(单位秒)
#define UTC_REQ_RAND      3600      // UTC请求随机数，1小时(单位秒)
static _UI g_uiUtcReqInterval = 0;  // 保存UTC下次请求的时间间隔

ST_MSGMNG_MNG g_stMsgCtMng;
/**********************************************************************
***********************************************************************/
ST_MSGMNG_MNG *MsgMng_GetMng()
{
    return &g_stMsgCtMng;
}

/***********************************************************************
主动发起请求 节点的申请 和 查找
************************************************************************/
static ST_MSGMNG_RSP_NODE *MsgMng_FindRspNode(_UI uiReqId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MSGMNG_RSP_NODE *pstMsgRspNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&MsgMng_GetMng()->stRspList, pstMsgRspNode, stIterator)
    {
        if(pstMsgRspNode->ucUseFlag && pstMsgRspNode->uiReqId == uiReqId)
        {
            return pstMsgRspNode;
        }
    }
    return MOS_NULL;
}

/***********************************************************************
查找登录信令服务器请求的节点信息
************************************************************************/
static ST_MSGMNG_RSP_NODE *MsgMng_FindCmdRspNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MSGMNG_RSP_NODE *pstMsgRspNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&MsgMng_GetMng()->stRspList, pstMsgRspNode, stIterator)
    {
        if(pstMsgRspNode->ucUseFlag && pstMsgRspNode->usMsgType == EN_OGCT_METHOD_DEVPLAT && pstMsgRspNode->ucMsgId == EN_OGCT_DEVPLAT_ZJCMD_LOGIN)
        {
            return pstMsgRspNode;
        }
    }
    return MOS_NULL;
}

static ST_MSGMNG_RSP_NODE *MsgMng_MallocRspNode(_UI uiReqId,_UC ucMsgType,_UC ucMsgId,PFUN_MSGMNG_RSPDATACB pFunRspDataCb)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MSGMNG_RSP_NODE *pstMsgRspNode = MOS_NULL;

    Mos_MutexLock(&MsgMng_GetMng()->hMutex);
    
    FOR_EACHDATA_INLIST(&MsgMng_GetMng()->stRspList, pstMsgRspNode, stIterator)
    {
        if(pstMsgRspNode->ucUseFlag  == 0)
        {
            break;
        }
    }
    if(pstMsgRspNode == MOS_NULL)
    {
        pstMsgRspNode = (ST_MSGMNG_RSP_NODE*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_RSP_NODE));
        MOS_LIST_ADDTAIL(&MsgMng_GetMng()->stRspList, pstMsgRspNode);
    }
    pstMsgRspNode->pfunRspMsgProc = pFunRspDataCb;
    pstMsgRspNode->ucMsgId        = ucMsgId;
    pstMsgRspNode->usMsgType      = ucMsgType;
    pstMsgRspNode->uiReqId        = uiReqId;
    pstMsgRspNode->ucUseFlag      = 1;
    Mos_MutexUnLock(&MsgMng_GetMng()->hMutex);
    return pstMsgRspNode;
}

/***********************************************************************
接受到的请求处理节点
************************************************************************/
static ST_MSGMNG_ACTIVE_NODE *MsgMng_FindActiveNode(_UC usMsgType,_UC ucMsgId)
{
    ST_MSGMNG_ACTIVE_NODE *pstActiveMsgNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;

    FOR_EACHDATA_INLIST(&MsgMng_GetMng()->stActiveFunList, pstActiveMsgNode, stIterator)
    {
        if(pstActiveMsgNode->usMsgType == usMsgType && pstActiveMsgNode->ucMsgId == ucMsgId )
        {
            return pstActiveMsgNode;
        }
    }
    return MOS_NULL;
}

//  从平台（信令服务）获取utc时间
static _INT MsgMng_GetUtcTimeFromServerProc(kj_timer_t *pTimerTicket)
{
    _INT iRet     = MOS_ERR;
    _UI uiRanTime = 0;

    // 厂家未对接直接返回
    if (MOS_NULL == ZJ_GetFuncTable()->pfunSetUtcTime)
    {
         return MOS_ERR;
    }

    // 无网、ap热点、未登录信令平台
    if ((EN_ZJ_NETWORK_TYPE_NONET == MsgMng_GetMng()->ucNetworkType) || (EN_ZJ_NETWORK_TYPE_AP == MsgMng_GetMng()->ucNetworkType) \
        || (EN_MSGMNG_CMDSERVER_STATUS_PROCESS != MsgMng_GetCmdServer()->ucStatus))
    {
        // 每次上线都需要马上请求时间
        g_uiUtcReqInterval = 0;
        getDiffTimems(pTimerTicket, 1, ENUM_SECONDS_TYPE_SECONDS, 600);
        return MOS_ERR;
    }

    // SDK完成注册登录之后和每3个小时+1小时(按秒为单位随机打散)，调用信令获取时间接门获取平台时间，并将获取到的时间返回给设备
    if (getDiffTimems(pTimerTicket, 0, ENUM_SECONDS_TYPE_SECONDS, 600) >= g_uiUtcReqInterval)
    {
        // 重置请求时间点   
        getDiffTimems(pTimerTicket, 1, ENUM_SECONDS_TYPE_SECONDS, 600);

        // 选择一个randtime, 计算下次请求时间间隔
        srand((unsigned)time(NULL));
        uiRanTime          = rand() % UTC_REQ_RAND;
        g_uiUtcReqInterval = UTC_REQ_INTERVAL + uiRanTime;

        // MOS_LOG_INF(MSGMNG_ID_LOG_STR, "uiRanTime %u, g_uiUtcReqInterval %u", uiRanTime, g_uiUtcReqInterval);

        // 请求UTC
        iRet = MsgMng_GetUtcTimeFromServer();
    }

    return iRet;
}

// 监听信令服务器下发信令
static _INT MsgMng_ProcSockets( MOS_FD_SET fdRSet, MOS_FD_SET fdWSet, _CTIME_T timeNow)
{
    _INT iReady = 0;
    _INT iMaxFd = 0;
    // _UC aucString[128] = {0};
    ST_MSGMNG_CMDSERVER* pstCmdServer = MsgMng_GetMng()->pstCmdServer;
    if(pstCmdServer == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    MOS_INET_FD_ZERO(fdRSet);
    MOS_INET_FD_ZERO(fdWSet);

    if(pstCmdServer->isockFd != MOS_SOCKET_INVALID){
        if(pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_DOING){
             Mos_InetFDSet(pstCmdServer->isockFd, fdWSet);
        }else if(pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_FINSH){
             Mos_InetFDSet(pstCmdServer->isockFd, fdRSet);
        }
        iMaxFd = MOS_MAX_NUM(iMaxFd,(_INT)pstCmdServer->isockFd);
    }

    if(iMaxFd <= 0)
    {
        return MOS_ERR;
    }

    // 监听信令服务器socket
    iReady = Mos_SocketSelect(iMaxFd + 1, fdRSet, fdWSet, MOS_NULL, 20);
    if(iReady < 0)
    {
        return MOS_ERR;
    }
    else if(iReady > 0)
    {
        if(pstCmdServer->isockFd != MOS_SOCKET_INVALID){
            if((pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_DOING) && (Mos_InetFDIsSet(pstCmdServer->isockFd, fdWSet)))
            {
                // 检测是否连接上信令服务器
                if(Mos_SockCheckBoolConnect(pstCmdServer->isockFd) == MOS_TRUE)
                {
                    pstCmdServer->ucConnectFlag = EN_MSGMNG_CMDSERVER_FLAG_FINSH;
                }
                else
                {
                    if (pstCmdServer->uiConnectType == EN_MSGMNG_CONNECT_IPV4)
                    {
                        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"IPv4 Device Can Not Connect Msg Plat");
                    }
                    else
                    {
                        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"IPv6 Device Can Not Connect Msg Plat");
                    }
                    pstCmdServer->ucConnectFlag = EN_MSGMNG_CMDSERVER_FLAG_ERROR;
                }
            }
            else if((pstCmdServer->ucConnectFlag == EN_MSGMNG_CMDSERVER_FLAG_FINSH) && (Mos_InetFDIsSet(pstCmdServer->isockFd, fdRSet)))
            {
                // 接受信令服务器下发的信令，并处理 (解密解json包)
                MsgMng_ProcCmdServerRecv(pstCmdServer);
            }
        }
    }
    return MOS_OK;
}

_VOID MsgMng_CheckAndFeedDog()
{
    // 软看门狗喂狗
    if (getDiffTimems(&g_tMsgMngFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
    {            
        Swd_AppThreadFeedDog(g_hSwdMsgMngFeedDog);
        getDiffTimems(&g_tMsgMngFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
    }
}

/*********************************************************************
主处理流程
**********************************************************************/
_INT MsgMng_LoopProc(_VPTR vpParam)
{
    _UI  uiLoopCnt = 0;
    MOS_FD_SET     fdRSet;
    MOS_FD_SET     fdWSet;
    _CTIME_T cTimeNow = Mos_Time();
    kj_timer_t stGetUtcTimer; //用于定时获取平台时间

    g_hSwdMsgMngFeedDog = Swd_AppThreadRegist(MSGMNG_APP, FEED_DOG_BIG_MAX_TIMESEC);

    kj_timer_init(&g_tMsgMngFeedDogTimeOut);
    getDiffTimems(&g_tMsgMngFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);

    kj_timer_init(&stGetUtcTimer);
    getDiffTimems(&stGetUtcTimer, 1, ENUM_SECONDS_TYPE_SECONDS, 600);

    Mos_InetFDCreate(&fdRSet);
    Mos_InetFDCreate(&fdWSet);
    while(MsgMng_GetMng()->ucRunFlag == 1)
    {
        // 软看门狗检测喂狗
        MsgMng_CheckAndFeedDog();

        // 网络状体变化
        if(MsgMng_GetMng()->ucNetChangFlag == 1)
        {
            // 重置信令服务器
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"NetWork Type Had Changed");
            MsgMng_ResetCmdServer(MsgMng_GetMng()->pstCmdServer);
            MsgMng_GetMng()->ucNetChangFlag = 0;
        }
        if((++uiLoopCnt)%5 == 0)
        {
            cTimeNow = Mos_Time();
        }

        // 获取动态域名流程
        MsgMng_ProcRouteStatus(cTimeNow);

        // 动态信令服务器注册登录流程
        MsgMng_ProcCmdServerStatus(cTimeNow);

        // 北京终端CTEI设备信息上报流程
        MsgMng_PDM_StartUpLoadDevInfo(cTimeNow);

        // 南京智家CTEI设备信息上报流程
        MsgMng_SmartHome_StartUpLoadDevInf(cTimeNow);

        // 发送数据到信令服务器
        MsgMng_SendCmdServerBuffer();

        // 监听信令服务器下发信令
        if(MsgMng_ProcSockets(fdRSet,fdWSet,cTimeNow) != MOS_OK)
        {
            Mos_Sleep(100);
        }

        // 动态处理报警事件的状态 是否超时
        MsgMng_ProcEventNodeStatus();

        // 当获取设备外网IP功能开关开启时
        if (Config_GetDeviceMng()->uiGetDevOuterIPStatus == EN_GETOUTERIP_STATUS_OPEN)
        {
            // 处理获取设备外网IP流程
            MsgMng_ProcGetDevOuterIP(cTimeNow);
        }
        // 关键接口质量上报
        MsgMng_QualityStatistics_Upload();

        // 定时获取平台时间
        MsgMng_GetUtcTimeFromServerProc(&stGetUtcTimer);
    }

    Mos_InetFDDelete(fdRSet);
    Mos_InetFDDelete(fdWSet);

    Swd_AppThreadUnRegist(g_hSwdMsgMngFeedDog);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"MsgMng_LoopProc Exit");

    return MOS_OK;
}

/**********************************************************************
***********************************************************************/
_INT MsgMng_Init()
{
    if(MsgMng_GetMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"Already Init !!");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stMsgCtMng, 0, sizeof(ST_MSGMNG_MNG));
    Mos_MutexCreate(&MsgMng_GetMng()->hMutex);
    Mos_MutexCreate(&MsgMng_GetMng()->hEventListMutex);
    MsgMng_GetCmdServer(); 

    // 关键接口质量统计模块初始化
    MsgMng_QualityStatistics_Init();

    MsgMng_GetMng()->ucInitFlag = 1;
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"task init ok");
    return MOS_OK;
}

// 信令收发模块
_INT MsgMng_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_HIGH_SIZE; // MOS_THREAD_STACK_HIGH_SIZE
    if(MsgMng_GetMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"Already Start !!");
        return MOS_OK;
    }
#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif

// 多媒体 注册
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_DEV_ADDR_NTC,  MsgMng_RecvMultiMediaAddrNtc);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_PAUSE_PUSH,    MsgMng_RecvMultiMediaPauseNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_RESUME_PUSH,   MsgMng_RecvMultiMediaResumeNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_UPDATE_KEY_NTC,MsgMng_RecvMultiMediaNewPlatKeyNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_DEV_ADDR_CLEAN_NTC,      MsgMng_RecvMultiMediaAddrCleanNtc);

    // 直播
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_START_PUSH,    MsgMng_RecvMultiMediaAskStartStream);
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_PAUSE_PUSH,    MsgMng_RecvMultiMediaAskPauseStream);
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_RESUME_PUSH,   MsgMng_RecvMultiMediaAskResumeStream);
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_NEED_KEYFRAME, MsgMng_RecvMultiMediaAskIdr);
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_UPDATE_KEY_NTC,MsgMng_RecvMultiMediaAskUpdateKey);
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_CLOSE_STREAM,  MsgMng_RecvMultiMediaAskCloseStream);

    // 语音对讲
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_OPEN_AUDIO_REVERSE_STREAM, MsgMng_RecvMultiMediaOpenAudioReverseStream);
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_CLOSE_AUDIO_REVERSE_STREAM,MsgMng_RecvMultiMediaCloseAudioReverseStream);

    // 卡回看
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_PLAYBACK_ADDR_NTC,     MsgMng_RecvMultiMediaPlayBackAddrNtc);
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_PLAYBACK_CLOSE,        MsgMng_RecvMultiMediaPlayBackClose);
    MsgMng_MultiMediaRegistActiveFunc(EN_OGCT_METHOD_MULMEDIA,EN_OGCT_MULMEDIA_PLAYBACK_CONTROL,      MsgMng_RecvMultiMediaPlayBackControl);

// 平台类消息注册
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_DEVPLAT,EN_OGCT_DEVPLAT_LINK_KEYCHG_NTC,  MsgMng_RecvDevPlatLinkEncryChangeNtc);

//配置业务的相关 处理
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_UPDATE_NTC,       MsgMng_RecvHardwareNeedUpgradeNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVBUSS_NOTICE,   MsgMng_RecvSetDevBussCfgNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_DEVCHARGE_NOTICE, MsgMng_RecvSetDevChargeNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_UPLOGFILE_NOTICE, MsgMng_RecvUploadLocalLogNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_P2P_CFGSYNC,      MsgMng_RecvGetBussCfgByP2p);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_CLOUDPOLICY_NTC,  MsgMng_RecvSetCloudPolicyNtc);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_CLOUDCFG_NTC,     MsgMng_RecvSetCloudBussCfgNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_LIMITFLOW_NTC,    MsgMng_RecvSet4GFlowLimitNtc);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_EVENTCLOUD,       MsgMng_RecvSetEventcloud);
// 命令相关处理 
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GET_TIMEANDZONE,  MsgMng_RecvGetTimeZoneMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SET_TIMEANDZONE,  MsgMng_RecvSetTimeZoneMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETTFCRADINF,     MsgMng_RecvGetSdcardInfMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_FORMATTFCRAD,     MsgMng_RecvFormatSdcardMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ,        MsgMng_RecvContrlPtzMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETPTZPROP,       MsgMng_RecvSetPtzPropMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_REBOOT,           MsgMng_RecvRebootDevMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CHEACKVERSION,    MsgMng_RecvCheckNewVersionMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSD,           MsgMng_RecvSetCamOsdMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSDDISPLAY,    MsgMng_RecvSetCamOsdDisplayMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSDCOMMONINF,  MsgMng_RecvSetCamCommonOsdInfMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_FACTORYSETTING,   MsgMng_RecvSetDevFactoryMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CAMSTATUS,        MsgMng_RecvSetCamStatusMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_INVERSION,        MsgMng_RecvSetImageRotateMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_VENCODE_PARAM,    MsgMng_RecvSetVideoEncParamMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETPRESET,        MsgMng_RecvSetPreSetPointMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETCRUISE,        MsgMng_RecvSetCruiseMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWATCHPOINT,    MsgMng_RecvSetWatchPointMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETAUDIOPARAM,    MsgMng_RecvSetAudioParamMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETMICOPENFLA,    MsgMng_RecvSetMicOpenMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_TIMER_POLICY,     MsgMng_RecvSetTimePolicyMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_LOCALRECORD,      MsgMng_RecvSetLocalRecordPropMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_ALARM_POLICY,     MsgMng_RecvSetAlarmPolicyMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CTRLKJIOT,        MsgMng_RecvCtrlKjIoTMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETINIOTPROP,     MsgMng_RecvSetInIotPropMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_PTZCHECK,         MsgMng_RecvSetPtzCheckMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETAWAKETIME,     MsgMng_RecvSetAwakeTimeMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_ADDDEVTOHUB,      MsgcCt_RecvAddIotToHubMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETHUBDEVPROP,    MsgMng_RecvSetHubIotPropMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_DELHUBDEV,        MsgMng_RecvDelHubIotMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_DELALLHUBDEV,     MsgMng_RecvDelAllHubIotMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETIOTSTATUSLIST, MsgMng_RecvGetIotsStatusMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_IRMODE,           MsgMng_RecvSetIrModeMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWIFI,          MsgMng_RecvSetWifiMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETWIFILIST,      MsgMng_RecvGetWifiListMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETCURNATINF,     MsgMng_RecvGetCurNetInfMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CLEAN_SERVADDR,   MsgMng_RecvSetCleanServAddrMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETDEVNAME,       MsgMng_RecvSetDevNameMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_PLAYALARM,        MsgMng_RecvPlayAlarmFileMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETBELLFLAG,      MsgMng_RecvSwitchDismantableAlarmMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWAITALARM,     MsgMng_RecvSetWaitAlarmMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWDR,           MsgMng_RecvSetCamWdrMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETRECORDCALENDER,MsgMng_RecvGetRecordCalenderMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETRECORDLIST,    MsgMng_RecvGetRecordAxisMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETJPGLIST,       MsgMng_RecvGetJpgListMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETJPGCANLEADER,  MsgMng_RecvGetJpgCalenderMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETEVENTCALENDER, MsgMng_RecvGetEventCalenderMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETEVENTLIST,     MsgMng_RecvGetEventAxisMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_ADDDEVICEBYAP,    MsgMng_RecvAddDevByAPMsg);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_STARTUPGRADE,     MsgMng_RecvStartUpgradeMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_STOPUPGRADE,      MsgMng_RecvStopUpgradeMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SWITCHLEN,        MsgMng_RecvSwitchLensMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETSCENEPOLICY,   MsgMng_RecvSetSceneInfMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETBELLQUICKREPLY,MsgMng_RecvSetBellQuckReplayMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CHANGEBELLSOUND,  MsgMng_RecvSwitchBellSoundMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOAD_LOGFILE,   MsgMng_RecvUpLoadLogFileMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETLOGFILELIVEL,  MsgMng_RecvSetLogFileLevelMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_NETWORK_CHECK,    MsgMng_RecvSetNetworkCheck);
    
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_RELAY_MODE,       MsgMng_RecvSetRelayModeMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETDEVAUTOUPDATE, MsgMng_RecvSetAutoUpgradeMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETSOUNDLIST,     MsgMng_RecvGetSoundListMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_DELSOUNDFILE,     MsgMng_RecvDelSoundFileMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_PLAYSOUNDFILE,    MsgMng_RecvPlaySoundFileMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_DOWNSOUNDFILE,    MsgMng_RecvDownSoundFileMsg);

    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_RELAYDEV_AWAKE,   MsgMng_RecvAwakeRelayDevMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_LIMITSTREAM_NTC,  MsgMng_RecvLimitStreamMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETVOLUME,        MsgMng_RecvSetVolumeMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETMAXSESSION,    MsgMng_RecvSetMaxSessionCntMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETDEFAULTLENID,  MsgMng_RecvSetDefaultLenIdMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETSNAPSHOTTIME,  MsgMng_RecvGetShotTimeMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETINIOTSPROP,    MsgMng_RecvSetInIotsPropMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SUPERCODES,       MsgMng_RecvSetSuperCodesMsg);

    // 消警
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_STOPALARMRING,  MsgMng_RecvStopAlarmRingMsg);

    //内置指示灯
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETPILOTLIGHT,  MsgMng_RecvSetPilotLightStatusMsg);

    // 事件云存监控
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CLOUDEVENT, EN_OGCT_CLOUDLOG_SETTING,  MsgMng_RecvSetCloudLog);

    //cn21 p2p command
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_SETSDP_REQ,             MsgMng_RecvSetClientSdpMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_CONNECTPRE_REQ,         MsgMng_RecvSetReadyConnectMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_CONNECTPRE_RESP,        MsgMng_RecvP2pStatusMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_REPORT_P2P_STATUS_RESP, MsgMng_RecvP2pStatusMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_GET_ONLINE_NUMBER_REQ,  MsgMng_RecvGetOnlineClientMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_APP_SEND_SDP_REQ,       MsgMng_RecvClientSendSdpMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_DEV_SEND_SDP_RESP,      MsgMng_RecvClientSdpResp);
    //MsgMng_RegistActiveFunc(EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_LOGIN_REQ, MsgMng_RecvSetTimeZoneMsg);

    // AI相关
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_DEVAI, EN_OGCT_DEVAI_ADDFACEORLICENSELIB_REQ,     MsgMng_RecvAddFaceOrLicenseLibMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_DEVAI, EN_OGCT_DEVAI_DELFACEORLICENSELIB_REQ,     MsgMng_RecvDelFaceOrLicenseLibMsg);

    // 客流统计相关
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETHUMANCOUNTREGIONS,     MsgMng_RecvSetHumanCountRegionsMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETHUMANCOUNTPARAM,       MsgMng_RecvSetHumanCountParamMsg);

    // 云广播相关
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CREATEREALTIMEBROADCAST,  MsgMng_RecvCreateRealTimeBroadcastMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CREATESCHEDULEDBROADCAST, MsgMng_RecvCreateScheduleBroadcastMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CANCELSCHEDULEDBROADCAST, MsgMng_RecvCancelScheduleBroadcastMsg);

    // 业务策略变更通知
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_BUSINESSSTRATEGYCHANGE,   MsgMng_RecvBusinessPolicyChangeMsg);

    // GAT1400相关
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GAT1400SWITCH,            MsgMng_RecvGat1400SwitchMsg);

    // 应用与获取设备外网IP处理方案
    // 对设备获取外网IP操作涉及的参数配置
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SET_GETOUTERIPINF,        MsgMng_RecvSetGetOuterIPInfMsg);

    // IPv6开关
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_IPV6SWITCH,               MsgMng_RecvIPv6SwitchMsg);


#ifdef BUILD_IMSSDK_FALG
    // IMS SDK相关
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_BUSINESSSTRATEGYCHANGE,   MsgMng_RecvBusinessStrategyChangeMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SENDIMSCALL,              MsgMng_RecvSendIMSCallMsg);
    MsgMng_RegistActiveFunc(EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOADBUSINESSCFG,        MsgMng_RecvUploadBusinessCfg);
#endif
	
	MsgMng_GetMng()->ucRunFlag = 1;
#ifndef SUPPORT_DEBUG_P2P
    
    if(MOS_OK != Mos_ThreadCreate((_UC*)"MSGMNG_MODULE", EN_THREAD_PRIORITY_NORMAL, uiStackSize,
            MsgMng_LoopProc, MOS_NULL, MOS_NULL, &(g_stMsgCtMng.hThreadProc)))
    {
        MsgMng_GetMng()->ucRunFlag = 0;
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Mos_ThreadCreate failed !!");
        return MOS_ERR;
    }
#endif
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"task start ok");
    return MOS_OK;
}

_INT MsgMng_Stop()
{
    if(MsgMng_GetMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"Already Stop !!");
        return MOS_OK;
    }
    MsgMng_GetMng()->ucRunFlag = 0;
    MOS_LIST_RMVALL(&MsgMng_GetMng()->stActiveFunList, MOS_TRUE);
    MOS_LIST_RMVALL(&MsgMng_GetMng()->stRspList, MOS_TRUE);
    MOS_LIST_RMVALL(&MsgMng_GetMng()->stEventList, MOS_TRUE);
    Mos_ThreadDelete(g_stMsgCtMng.hThreadProc);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"task stop ok");
    return MOS_OK;    
}

_INT MsgMng_Destroy()
{
    if (MsgMng_GetMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"Already Destroy !!");
        return MOS_OK;
    }
    
    Mos_MutexDelete(&MsgMng_GetMng()->hMutex);
    Mos_MutexDelete(&MsgMng_GetMng()->hEventListMutex);
    MsgMng_DeleteCmdServer();
    MsgMng_GetMng()->ucInitFlag = 0;

    // 关键接口质量统计模块去初始化
    MsgMng_QualityStatistics_Destroy();
   
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"task Destroy ok");
    return MOS_OK;
}

// 注册信令
_VOID MsgMng_RegistActiveFunc(_UC usMsgType,_UC ucMsgId,PFUN_MSGMNG_ACTIVEPROC pFunActiveMsgProc)
{
    ST_MSGMNG_ACTIVE_NODE *pstActiveMsgNode = MOS_NULL;

    Mos_MutexLock(&MsgMng_GetMng()->hMutex);
    // 查找信令节点
    pstActiveMsgNode = MsgMng_FindActiveNode(usMsgType,ucMsgId);
    if(pstActiveMsgNode != MOS_NULL)
    {
        Mos_MutexUnLock(&MsgMng_GetMng()->hMutex);
        return;
    }
    // 初始化信令
    pstActiveMsgNode = (ST_MSGMNG_ACTIVE_NODE*)MOS_MALLOCCLR(sizeof(ST_MSGMNG_ACTIVE_NODE));
    pstActiveMsgNode->ucMsgId        = ucMsgId;
    pstActiveMsgNode->usMsgType      = usMsgType;
    pstActiveMsgNode->pFunActiveProc = pFunActiveMsgProc;
    MOS_LIST_ADDTAIL(&MsgMng_GetMng()->stActiveFunList, pstActiveMsgNode);
    Mos_MutexUnLock(&MsgMng_GetMng()->hMutex);
    return;
}

// 发送消息到信令服务器
_INT  MsgMng_SendMsg(_UC *pucPeerId,_UI uiReqId, _UC ucMsgType,_UC ucMsgId,
                    _UC *pucMsgBuff,_INT iMsgLen,PFUN_MSGMNG_RSPDATACB pFunRspDataCb)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pucMsgBuff);

    _INT iRet = MOS_OK;
    ST_MSGMNG_RSP_NODE *pstRspNode = MOS_NULL;

    if(pFunRspDataCb != MOS_NULL)
    {
        // 申请登录信令服务器的回复数据内存
        pstRspNode = MsgMng_MallocRspNode(uiReqId,ucMsgType,ucMsgId,pFunRspDataCb);
    }

    // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"TO MSG CENTER JSON: pucMsgBuff: %s ", pucMsgBuff);

    if(MOS_STRCMP(pucPeerId,MSGMNG_CMD_SERVER_ID) == 0)
    {
        // 发送数据到信令服务器
        iRet = MsgMng_SendDataToCmdServer(ucMsgType,ucMsgId,pucMsgBuff,iMsgLen);
    }
    else if(MOS_STRCMP(pucPeerId,MSGMNG_AP_SERVER_ID) == 0)
    {
        // 发送数据到AP热点客户端
        MOS_PRINTF("\r\n AAAAAAAAAAAAAPPPPPPPPPPPPPPPP RSP !!!!!! \r\n");
        iRet = AP_SendDataToApClient(ucMsgType,ucMsgId,pucMsgBuff,iMsgLen);
    }
#ifdef BUILD_SUPPORT_MSGTEST_FALG
    else if(MOS_STRCMP(pucPeerId,MSGTEST_SERVER_ID) == 0)
    {
        // 信令测试的回复
        iRet = MsgTest_SendMsg(pucMsgBuff,iMsgLen);
    }
#endif
    else
    {
        // 发送数据
        iRet = P2p_SendDataToPeer(pucPeerId,ucMsgType,ucMsgId,pucMsgBuff,iMsgLen);//Http_SendDataToPeer
    }

    if(iRet <= 0)
    {
        if(pstRspNode != MOS_NULL)
        {
            pstRspNode->ucUseFlag = 0;
        }
        return MOS_ERR;
    }
    return MOS_OK;
}

_INT  MsgMng_CancleReqMsg(_UI uiReqId)
{
    ST_MSGMNG_RSP_NODE *pstRspMsgNode = MsgMng_FindRspNode(uiReqId);
    if(pstRspMsgNode == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstRspMsgNode == MOS_NULL");
        return MOS_ERR;
    }
    pstRspMsgNode->uiReqId        = 0;
    pstRspMsgNode->pfunRspMsgProc = MOS_NULL;
    pstRspMsgNode->ucUseFlag = 0;
    return MOS_OK;
}

// 处理信令服务器下发的信令
_INT MsgMng_DispatchMsg(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UI uiSeqID = 0;
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"SEQID"), (_INT*)&uiSeqID);
    // 下发的信令命令
    if(ucMsgId%2 == 0)
    {
        Qp_CountIF_Post(COUNT_TYPE_CMD, COUNT_VALUE_SUCCESS, COUNT_VALUE_SUCCESS);
        // 查找对应的信令的sdk回调接口
        ST_MSGMNG_ACTIVE_NODE *pstActiveMsgNode = MsgMng_FindActiveNode(ucMsgType,ucMsgId);
        if(pstActiveMsgNode == MOS_NULL || pstActiveMsgNode->pFunActiveProc == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"FIND NO MsgCt(%02X%02X) CALLback FUNC", ucMsgType, ucMsgId);
            MsgMng_RecvCmdNotSupportMsg(pucPeerId, uiSeqID, ucMsgType, ucMsgId, NULL);
            return MOS_ERR;
        }

        // 回调对应的sdk接口  传入hJsonRoot数据
        pstActiveMsgNode->pFunActiveProc(pucPeerId,uiSeqID,hJsonRoot);
    }
    // 回复下发的信令的命令 +1
    else
    {
        ST_MSGMNG_RSP_NODE *pstRspMsgNode = MOS_NULL;
        
        if (ucMsgType == EN_OGCT_METHOD_DEVPLAT && ucMsgId == EN_OGCT_DEVPLAT_ZJCMD_LOGIN_RSP)
        {
            pstRspMsgNode = MsgMng_FindCmdRspNode();
        }
        else
        {
            pstRspMsgNode = MsgMng_FindRspNode(uiSeqID);         
        }
    
        if(pstRspMsgNode == MOS_NULL || pstRspMsgNode->pfunRspMsgProc == MOS_NULL)
        {
            return MOS_ERR;
        }
        pstRspMsgNode->pfunRspMsgProc(uiSeqID,hJsonRoot);
        pstRspMsgNode->pfunRspMsgProc = MOS_NULL;
        pstRspMsgNode->ucUseFlag = 0;
    }
    return MOS_OK;
}

_VOID MsgMng_SetNetWorkStatus(_INT iNetStatus)
{
    if (MsgMng_GetMng()->ucNetworkType == iNetStatus)
    {
        MOS_PRINTF("same NetworkType = %d\n", iNetStatus);
        return;
    }

    MsgMng_GetMng()->ucNetworkType = iNetStatus;
    MsgMng_GetMng()->ucNetChangFlag = 1; 
}

_UC* MsgMng_BuildCommonNtcRspJson(_UI uiSeqID, _UC ucMsgType,_UC ucMsgId,_INT iCode)
{
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[8];
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    
    MOS_SPRINTF(aucMethod, "%02X%02X",ucMsgType, ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iCode));

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}

_UC* MsgMng_BuildNotSupportJson(_UI uiSeqID, _UC ucMsgType,_UC ucMsgId,_INT iCode)
{
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[8] = {0};
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    
    MOS_SPRINTF(aucMethod, "%02X%02X",ucMsgType, ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iCode));

    pStrTmp = Adpt_Json_Print(hRoot); 
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}


_UC* MsgMng_BuildOpenAudioReverseStreamRspJson(_INT iCamId, _UI uiSeqID, _UC ucMsgType,_UC ucMsgId,_INT AudioFlag)
{
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[8];
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    
    MOS_SPRINTF(aucMethod, "%02X%02X",ucMsgType, ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqID));
    
    if (AudioFlag)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("success"));
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(10001));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("Can't Open device speaker..."));
    }
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"CamID",Adpt_Json_CreateStrWithNum(0));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"AudioFlag",Adpt_Json_CreateStrWithNum(AudioFlag));
    }

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}


_UC* MsgMng_BuildCloseAudioReverseStreamRspJson(_INT iCamId, _UI uiSeqID, _UC ucMsgType,_UC ucMsgId)
{
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[8];
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    JSON_HANDLE hBody = Adpt_Json_CreateObject();

    MOS_SPRINTF(aucMethod, "%02X%02X",ucMsgType, ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("success"));

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CamID",Adpt_Json_CreateStrWithNum(iCamId));

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pStrTmp;
}

// 设备状态（休眠、唤醒）上报应答 0x3411
static _INT MsgMng_RecvUploadDevStatusRsp(_UI uiReqId, _VPTR hJsonRoot)
{
    _INT iCode = 0;

    Mos_MutexLock(&Config_GetCamaraMng()->hUploadDevStatusMutex);
    if (Config_GetCamaraMng()->uiUploadDevStatusReqId == uiReqId)
    {
        Config_GetCamaraMng()->uiUploadDevStatusReqId = 0;
    }
    Mos_MutexUnLock(&Config_GetCamaraMng()->hUploadDevStatusMutex);

    if (hJsonRoot == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"CODE"), &iCode);
    if (iCode != 0)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "UploadDevStatus Rsp ERROR ReqId:%u Code:%d", uiReqId, iCode);
    }
    else
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "UploadDevStatus Rsp SUCCESS ReqId:%u Code:%d", uiReqId, iCode);
    }
    return MOS_OK;
}

// 设备状态（休眠、唤醒）上报 获取Describe字段内容
static _INT MsgMng_GetUploadDevStatusDescribe(_INT iCamStatus, _INT iStateChangeWay, _UC *pucDescribe, _INT iDescribeLen)
{
    // Sleep By ONLINE
    if ((iCamStatus == EN_DEV_STATUS_SLEEP) && (iStateChangeWay == EN_DEV_STATUS_CHANGE_WAY_ONLINE))
    {
        MOS_VSNPRINTF(pucDescribe, iDescribeLen, "Device Go To Sleep By ONLINE");
    }
    // Awake By ONLINE
    else if ((iCamStatus == EN_DEV_STATUS_AWAKE) && (iStateChangeWay == EN_DEV_STATUS_CHANGE_WAY_ONLINE))
    {
        MOS_VSNPRINTF(pucDescribe, iDescribeLen, "Device Go To Awake By ONLINE");
    }
    // Sleep By CMD
    else if ((iCamStatus == EN_DEV_STATUS_SLEEP) && (iStateChangeWay == EN_DEV_STATUS_CHANGE_WAY_CMD))
    {
        MOS_VSNPRINTF(pucDescribe, iDescribeLen, "Device Go To Sleep By CMD");
    }
    // Awake By CMD
    else if ((iCamStatus == EN_DEV_STATUS_AWAKE) && (iStateChangeWay == EN_DEV_STATUS_CHANGE_WAY_CMD))
    {
        MOS_VSNPRINTF(pucDescribe, iDescribeLen, "Device Go To Awake By CMD");
    }
    // Sleep By TIMER
    else if ((iCamStatus == EN_DEV_STATUS_SLEEP) && (iStateChangeWay == EN_DEV_STATUS_CHANGE_WAY_TIMER))
    {
        MOS_VSNPRINTF(pucDescribe, iDescribeLen, "Device Go To Sleep By TIMER");
    }
    // Awake By TIMER
    else if ((iCamStatus == EN_DEV_STATUS_AWAKE) && (iStateChangeWay == EN_DEV_STATUS_CHANGE_WAY_TIMER))
    {
        MOS_VSNPRINTF(pucDescribe, iDescribeLen, "Device Go To Awake By TIMER");
    }
    // Sleep By PHYSICALMASK
    else if ((iCamStatus == EN_DEV_STATUS_SLEEP) && (iStateChangeWay == EN_DEV_STATUS_CHANGE_WAY_PHYSICALMASK))
    {
        MOS_VSNPRINTF(pucDescribe, iDescribeLen, "Device Go To Sleep By PHYSICALMASK");
    }
    // Awake By PHYSICALMASK
    else if ((iCamStatus == EN_DEV_STATUS_AWAKE) && (iStateChangeWay == EN_DEV_STATUS_CHANGE_WAY_PHYSICALMASK))
    {
        MOS_VSNPRINTF(pucDescribe, iDescribeLen, "Device Go To Awake By PHYSICALMASK");
    }

    // 非设备上线情况 则需上报到云涛
    if (iStateChangeWay != EN_DEV_STATUS_CHANGE_WAY_ONLINE)
    {
        if (iCamStatus == EN_DEV_STATUS_SLEEP)
        {
            CloudStg_UploadLogEx2(MSGMNG_CMD_SERVER_ID, Mos_GetSessionId(), __FUNCTION__, 0, 
                                            EN_DEVICE_RT_GOTO_SLEEP, pucDescribe, MOS_NULL, 1);  
        }
        else if (iCamStatus == EN_DEV_STATUS_AWAKE)
        {
            CloudStg_UploadLogEx2(MSGMNG_CMD_SERVER_ID, Mos_GetSessionId(), __FUNCTION__, 0, 
                                            EN_DEVICE_RT_GOTO_AWAKE, pucDescribe, MOS_NULL, 1);  
        }
    }

    return MOS_OK;
}

// 设备状态（休眠、唤醒）上报 0x3410
_INT MsgMng_UploadDevStatus(_INT iCamStatus, _INT iStateChangeWay)
{
    _UI uiReqId          =  0;
    _UC aucMethod[16]    = {0};
    _UC aucDescribe[128] = {0};
    _UC *pStrTmp         = MOS_NULL;
    JSON_HANDLE hBody    = MOS_NULL;
    JSON_HANDLE hRoot    = MOS_NULL;

    Mos_MutexLock(&Config_GetCamaraMng()->hUploadDevStatusMutex);
    if (Config_GetCamaraMng()->uiUploadDevStatusReqId != 0)
    {
        MsgMng_CancleReqMsg(Config_GetCamaraMng()->uiUploadDevStatusReqId);
    }
    uiReqId = Mos_GetSessionId();
    Config_GetCamaraMng()->uiUploadDevStatusReqId = uiReqId; 
    Mos_MutexUnLock(&Config_GetCamaraMng()->hUploadDevStatusMutex);

    MsgMng_GetUploadDevStatusDescribe(iCamStatus, iStateChangeWay, aucDescribe, sizeof(aucDescribe));

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%0X%0X", EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOAD_DEVSTATUS);
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"SEQID",  Adpt_Json_CreateStrWithNum(uiReqId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot, (_UC *)"BODY", hBody);
    Adpt_Json_AddItemToObject(hBody, (_UC *)"CamStatus",      Adpt_Json_CreateStrWithNum(iCamStatus));
    Adpt_Json_AddItemToObject(hBody, (_UC *)"StateChangeWay", Adpt_Json_CreateStrWithNum(iStateChangeWay));
    Adpt_Json_AddItemToObject(hBody, (_UC *)"Describe",       Adpt_Json_CreateString(aucDescribe));

    pStrTmp = Adpt_Json_Print(hRoot);

    MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID, uiReqId, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOAD_DEVSTATUS,
                    pStrTmp, MOS_STRLEN(pStrTmp), MsgMng_RecvUploadDevStatusRsp);

    MOS_FREE(pStrTmp);
    Adpt_Json_Delete(hRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "ReqId %u UploadDevStatus:%d StateChangeWay:%d Describe:%s", 
                                    uiReqId, iCamStatus, iStateChangeWay, aucDescribe);
    return MOS_OK;
}
