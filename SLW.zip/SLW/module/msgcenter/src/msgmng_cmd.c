#include "mos.h"
#include "zj_interface.h"
#include "config_type.h"
#include "config_api.h"
#include "config_ai.h"
#include "config_ai.h"
#include "cmdhdl_type.h"
#include "cmdhdl_api.h"
#include "http_api.h"
#include "adpt_json_adapt.h"
#include "record_api.h"
#include "rf_radio_api.h"
#include "snap_api.h"
#include "event_api.h"
#include "cloudstg_api.h"
#include "IoManage_api.h"
#include "kjiot_device_api.h"
#include "msgmng_api.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "p2p_connect.h"
#include "ga1400_api.h"
#include "qualityprobe_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "cloudstg_config.h"
#include "msgmng_multimedia.h"

#ifdef BUILD_ONBROADCAST_FALG
#include "AudioDeviceAPI.h"
#endif

#ifdef BUILD_IMSSDK_FALG
#include "ims_render.h"
#endif

static _VOID MsgMng_GetMsgSrcAndDstInf(_VPTR hJsonRoot,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_NORET(pstMsgFromTo);
    MOS_PARAM_NULL_NORET(hJsonRoot);

    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hFromObject = MOS_NULL;
    JSON_HANDLE hToObject   = MOS_NULL;
    hFromObject = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"FROM");
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hFromObject,(_UC*)"UserToken"),&pStrTmp );
    MOS_STRNCPY(pstMsgFromTo->aucUserToken, pStrTmp, sizeof(pstMsgFromTo->aucUserToken));
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hFromObject,(_UC*)"SvrID"),&pStrTmp);
    MOS_STRNCPY(pstMsgFromTo->aucSvrID, pStrTmp, sizeof(pstMsgFromTo->aucSvrID));
    
    hToObject   = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"TO");
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hToObject,(_UC*)"DID"),&pStrTmp);
    MOS_STRNCPY(pstMsgFromTo->aucDID, pStrTmp, sizeof(pstMsgFromTo->aucDID));
    return;
}

#ifdef SUPPORT_DEBUG_P2P
static _VOID MsgMng_GetMsgSrcAndDstInf2(_VPTR hJsonRoot,ST_FROM_TO_MSG *pstMsgFromTo)
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hFromObject = MOS_NULL;
    JSON_HANDLE hToObject   = MOS_NULL;

    hFromObject = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"FROM");
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hFromObject,(_UC*)"UserId"),&pStrTmp );
    MOS_STRNCPY(pstMsgFromTo->aucUserToken, pStrTmp, sizeof(pstMsgFromTo->aucUserToken));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hFromObject,(_UC*)"SvrID"),&pStrTmp);
    MOS_STRNCPY(pstMsgFromTo->aucSvrID, pStrTmp, sizeof(pstMsgFromTo->aucSvrID));

    hToObject   = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"TO");
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hToObject,(_UC*)"UserId"),&pStrTmp);
    MOS_STRNCPY(pstMsgFromTo->aucDID, pStrTmp, sizeof(pstMsgFromTo->aucDID));
    return;
}
#else
static _VOID MsgMng_GetMsgSrcAndDstInf2(_VPTR hJsonRoot,ST_FROM_TO_MSG *pstMsgFromTo)
{
    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hFromObject = MOS_NULL;
    JSON_HANDLE hToObject   = MOS_NULL;
    hFromObject = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"FROM");

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hFromObject,(_UC*)"ClientID"),&pStrTmp );
    MOS_STRNCPY(pstMsgFromTo->aucUserToken, pStrTmp, sizeof(pstMsgFromTo->aucUserToken));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hFromObject,(_UC*)"SvrID"),&pStrTmp);
    MOS_STRNCPY(pstMsgFromTo->aucSvrID, pStrTmp, sizeof(pstMsgFromTo->aucSvrID));

    hToObject   = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"TO");
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hToObject,(_UC*)"DID"),&pStrTmp);
    MOS_STRNCPY(pstMsgFromTo->aucDID, pStrTmp, sizeof(pstMsgFromTo->aucDID));

    return;
}
#endif

//recive client ready connectting device by p2p 6414
_INT MsgMng_RecvSetReadyConnectMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_PRINTF("############MSGP2P %s %d\n", __FUNCTION__, __LINE__);

    _UC *pucStrTmp    = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    _UC ClientRole[CFG_STRING_LEN] = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf2(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Role"),&pucStrTmp);
    MOS_STRNCPY(ClientRole, pucStrTmp, sizeof(ClientRole));

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u peerid:%s recv connect prepare sdptype:%s\n",
        uiSeqId,pucPeerId,ClientRole);

    return P2p_SetPrepareConnectMsg(pucPeerId,uiSeqId,&stMsgFromTo,ClientRole);
}

// 6415  6418
_INT MsgMng_RecvP2pStatusMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pucStrTmp    = MOS_NULL;
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"),&pucStrTmp );
    MOS_PRINTF("recive server status resp code:%s\n", pucStrTmp);

    return MOS_OK;
}

// 6410
_INT MsgMng_RecvSetClientSdpMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC *pucStrTmp    = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_CMTASK_GETSDPINFO stGetSdpMsg;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf2(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SDPType"),&pucStrTmp);
    MOS_STRNCPY(stGetSdpMsg.aucSdpType, pucStrTmp, sizeof(stGetSdpMsg.aucSdpType));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SDP"),&pucStrTmp);
    MOS_STRNCPY(stGetSdpMsg.aucSdpInfo, pucStrTmp, sizeof(stGetSdpMsg.aucSdpInfo));
#ifndef SUPPORT_DEBUG_P2P
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"P2PToken"),&pucStrTmp);
    MOS_STRNCPY(stGetSdpMsg.aucP2PToken, pucStrTmp, sizeof(stGetSdpMsg.aucP2PToken));
#endif
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u peerid:%s recv getsdp sdptype:%s sdpInfo:%s\n",
        uiSeqId,pucPeerId,stGetSdpMsg.aucSdpType,stGetSdpMsg.aucSdpInfo);

    return P2p_SetGetDevSdpMsg(pucPeerId,uiSeqId,&stMsgFromTo,&stGetSdpMsg);
}

// 6425
_INT MsgMng_RecvClientSdpResp(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PRINTF("%s client recive sdp ok!!\n", __FUNCTION__);
    return MOS_OK;
}

// 6422
_INT MsgMng_RecvClientSendSdpMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);


    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    _UC *pucStrTmp    = MOS_NULL;
    ST_FROM_TO_MSG        stMsgFromTo;
    ST_CMTASK_P2PDATAINFO stGetSdpMsg;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf2(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Type"),&pucStrTmp);
    stGetSdpMsg.uiP2pInfoType = MOS_ATOI(pucStrTmp);

    MOS_PRINTF("stGetSdpMsg.uiP2pInfoType:%d\n", stGetSdpMsg.uiP2pInfoType);
    if (stGetSdpMsg.uiP2pInfoType == EN_P2PMSG_IP_TYPE_V4_TYPE || stGetSdpMsg.uiP2pInfoType == EN_P2PMSG_IP_TYPE_V6_TYPE)
    {
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SDP"),&pucStrTmp);
        MOS_STRNCPY(stGetSdpMsg.aucRemoteSdpInfo, pucStrTmp, sizeof(stGetSdpMsg.aucRemoteSdpInfo));

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"CntId"),&pucStrTmp);
        MOS_STRNCPY(stGetSdpMsg.aucChnId, pucStrTmp, sizeof(stGetSdpMsg.aucChnId));

        MOS_PRINTF("stGetSdpMsg.aucSdpInfo:%s\n", stGetSdpMsg.aucRemoteSdpInfo);
        MOS_PRINTF("stGetSdpMsg.CntId:%s\n", stGetSdpMsg.aucChnId);
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u peerid:%s type:%d\n",    uiSeqId,pucPeerId,stGetSdpMsg.uiP2pInfoType);

    return P2p_ReciveClientP2pDataMsg(pucPeerId,uiSeqId,&stMsgFromTo,&stGetSdpMsg);
}

// 6420
_INT MsgMng_RecvGetOnlineClientMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);
    _UC *pucStrTmp      = MOS_NULL;
    _UC *pucPortPos     = MOS_NULL;
    _UI uiIPv6StunPort  = 0;
    _UI uiIPv6StunPort2 = 0;
    _UI uiIPv6TurnPort  = 0;    
    ST_FROM_TO_MSG      stMsgFromTo;
    ST_P2PTURN_ADDRINFO stP2pAddrCfgMsg;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    _UC *pstrJosn = Adpt_Json_Print(hJsonRoot);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"pstrJosn : %s",pstrJosn);
    MOS_FREE(pstrJosn);

    MOS_MEMSET(&stP2pAddrCfgMsg, 0, sizeof(stP2pAddrCfgMsg));
    MsgMng_GetMsgSrcAndDstInf2(hJsonRoot,&stMsgFromTo);


    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"StunUrl"),&pucStrTmp);
    pucPortPos = MOS_STRSTR(pucStrTmp,":");
    if (pucPortPos != MOS_NULL)
    {
        _UI uiHostLen = (pucPortPos - pucStrTmp) > sizeof(stP2pAddrCfgMsg.aucStunHost) ? sizeof(stP2pAddrCfgMsg.aucStunHost) : (pucPortPos - pucStrTmp);
        MOS_STRNCPY(stP2pAddrCfgMsg.aucStunHost, pucStrTmp, uiHostLen);
        MOS_STRNCPY(stP2pAddrCfgMsg.aucStunPort, pucPortPos+1, sizeof(stP2pAddrCfgMsg.aucStunPort));
    }
    else
    {
        MOS_STRNCPY(stP2pAddrCfgMsg.aucStunHost, pucStrTmp, sizeof(stP2pAddrCfgMsg.aucStunHost));
    }


    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"StunUrl2"),&pucStrTmp);
    pucPortPos = MOS_STRSTR(pucStrTmp,":");
    if (pucPortPos != MOS_NULL)
    {
        _UI uiHostLen = (pucPortPos - pucStrTmp) > sizeof(stP2pAddrCfgMsg.aucStun2Host) ? sizeof(stP2pAddrCfgMsg.aucStun2Host) : (pucPortPos - pucStrTmp);
        MOS_STRNCPY(stP2pAddrCfgMsg.aucStun2Host, pucStrTmp, uiHostLen);
        MOS_STRNCPY(stP2pAddrCfgMsg.aucStun2Port, pucPortPos+1, sizeof(stP2pAddrCfgMsg.aucStun2Port));
    }
    else
    {
        MOS_STRNCPY(stP2pAddrCfgMsg.aucStun2Host, pucStrTmp, sizeof(stP2pAddrCfgMsg.aucStun2Host));
    }


    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"TurnUrl"),&pucStrTmp);
    pucPortPos = MOS_STRSTR(pucStrTmp,":");
    if (pucPortPos != MOS_NULL)
    {
        _UI uiHostLen = (pucPortPos - pucStrTmp) > sizeof(stP2pAddrCfgMsg.aucTurnHost) ? sizeof(stP2pAddrCfgMsg.aucTurnHost) : (pucPortPos - pucStrTmp);
        MOS_STRNCPY(stP2pAddrCfgMsg.aucTurnHost, pucStrTmp, uiHostLen);
        MOS_STRNCPY(stP2pAddrCfgMsg.aucTurnPort, pucPortPos+1, sizeof(stP2pAddrCfgMsg.aucTurnPort));
    }
    else
    {
        MOS_STRNCPY(stP2pAddrCfgMsg.aucTurnHost, pucStrTmp, sizeof(stP2pAddrCfgMsg.aucTurnHost));
    }

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"TurnUsername"),&pucStrTmp);
    MOS_STRNCPY(stP2pAddrCfgMsg.aucTurnUsername, pucStrTmp, sizeof(stP2pAddrCfgMsg.aucTurnUsername));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"TurnCredential"),&pucStrTmp);
    MOS_STRNCPY(stP2pAddrCfgMsg.TurnCredential, pucStrTmp, sizeof(stP2pAddrCfgMsg.TurnCredential));

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"IPv6Stun"),&pucStrTmp);
    MOS_STRNCPY(stP2pAddrCfgMsg.aucIPv6StunHost, pucStrTmp, sizeof(stP2pAddrCfgMsg.aucIPv6StunHost));
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"IPv6StunPort"),&uiIPv6StunPort);
    MOS_SPRINTF(stP2pAddrCfgMsg.aucIPv6StunPort,"%d",uiIPv6StunPort);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"IPv6Stun2"),&pucStrTmp);
    MOS_STRNCPY(stP2pAddrCfgMsg.aucIPv6Stun2Host, pucStrTmp, sizeof(stP2pAddrCfgMsg.aucIPv6Stun2Host));
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"IPv6StunPort2"),&uiIPv6StunPort2);
    MOS_SPRINTF(stP2pAddrCfgMsg.aucIPv6Stun2Port,"%d",uiIPv6StunPort2);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Ipv6Turn"),&pucStrTmp);
    MOS_STRNCPY(stP2pAddrCfgMsg.aucIPv6TurnHost, pucStrTmp, sizeof(stP2pAddrCfgMsg.aucIPv6TurnHost));
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Ipv6TurnPort"),&uiIPv6TurnPort);
    MOS_SPRINTF(stP2pAddrCfgMsg.aucIPv6TurnPort,"%d",uiIPv6TurnPort);

    if ((MOS_STRLEN(stP2pAddrCfgMsg.aucIPv6StunHost) > 4) && (Config_GetCamaraMng()->uiIPv6Ability) && (Config_GetCamaraMng()->uiIPv6Switch))
    {
        stP2pAddrCfgMsg.iIpv6Support = 1;
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u peerid : %s username : %s  credential : %s stun : %s:%s stun2 : %s:%s turn : %s:%s ipv6stun : %s:%s ipv6stun2 : %s:%s ipv6turn : %s:%s  ipv6support : %d\n",
                    uiSeqId,pucPeerId,  stP2pAddrCfgMsg.aucTurnUsername, stP2pAddrCfgMsg.TurnCredential,
                                        stP2pAddrCfgMsg.aucStunHost, stP2pAddrCfgMsg.aucStunPort, 
                                        stP2pAddrCfgMsg.aucStun2Host, stP2pAddrCfgMsg.aucStun2Port, 
                                        stP2pAddrCfgMsg.aucTurnHost, stP2pAddrCfgMsg.aucTurnPort,
                                        stP2pAddrCfgMsg.aucIPv6StunHost, stP2pAddrCfgMsg.aucIPv6StunPort,
                                        stP2pAddrCfgMsg.aucIPv6Stun2Host, stP2pAddrCfgMsg.aucIPv6Stun2Port,
                                        stP2pAddrCfgMsg.aucIPv6TurnHost, stP2pAddrCfgMsg.aucIPv6TurnPort,
                                        stP2pAddrCfgMsg.iIpv6Support);

    return P2p_SetGetClientNumberMsg(pucPeerId,uiSeqId,&stMsgFromTo, &stP2pAddrCfgMsg);
}

// 获取系统时间和时区 343E
_INT MsgMng_RecvGetTimeZoneMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv get timeZone Msg From peer %s",uiSeqId,pucPeerId);
    return Cmdhdl_SetCommonMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GET_TIMEANDZONE,&stMsgFromTo);
}

// 设置系统时间和时区 343C
_INT MsgMng_RecvSetTimeZoneMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC *pucStrTmp    = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_CMSTASK_SETTIMEZONE stSetTimeMsg;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    // 时区
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Area"),&pucStrTmp);
    MOS_STRNCPY(stSetTimeMsg.aucArea, pucStrTmp, sizeof(stSetTimeMsg.aucArea));
    
    // 系统时间
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Time"),&pucStrTmp);
    MOS_STRNCPY(stSetTimeMsg.aucTimeStr, pucStrTmp, sizeof(stSetTimeMsg.aucTimeStr));
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Zone"),&stSetTimeMsg.iZone);
    // 自动同步标志。0.不同步；1.同步手机时区
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SyncFlag"),&stSetTimeMsg.iSyncFlag);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"DstUseFlag"),&stSetTimeMsg.iUseDstFlag);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set timeZone Msg From peer %s use dstflag %u timestr %s zone %d",
        uiSeqId,pucPeerId,stSetTimeMsg.iUseDstFlag,stSetTimeMsg.aucTimeStr,stSetTimeMsg.iZone);
    
    return Cmdhdl_SetDevTimeAndZoneMsg(pucPeerId,uiSeqId,&stMsgFromTo,&stSetTimeMsg); 
}

// 查询SDCard信息 344E
_INT MsgMng_RecvGetSdcardInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv get TfCard info From peer %s",uiSeqId,pucPeerId);
    return Cmdhdl_SetCommonMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETTFCRADINF,&stMsgFromTo);
}

// 格式化SDCard 344C
_INT MsgMng_RecvFormatSdcardMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    
    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv format TfCard msg from peer %s",uiSeqId,pucPeerId);
    return Cmdhdl_SetCommonMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_FORMATTFCRAD,&stMsgFromTo); 
}

// 3428
_INT MsgMng_RecvContrlPtzMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_CMSTASK_PTZOPT stPtzOpt  = {0};
    ST_FROM_TO_MSG stMsgFromTo  = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PTZType"),&stPtzOpt.iPtzCtrlType);
    if(stPtzOpt.iPtzCtrlType == 0)      // PTZ操作
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PTZControl"),&stPtzOpt.u.stOnPtzInf.iPTZControl);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Speed"),&stPtzOpt.u.stOnPtzInf.iSpeed);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Step"),&stPtzOpt.u.stOnPtzInf.iStep);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Zoom"),&stPtzOpt.u.stOnPtzInf.iZoom);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Foucus"),&stPtzOpt.u.stOnPtzInf.iFocus);
    }
    else if(stPtzOpt.iPtzCtrlType == 1) // 预置位操作
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PresetID"),&stPtzOpt.u.uiPreSetId);
    }
    else if(stPtzOpt.iPtzCtrlType == 2) // 自定义巡航
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CruiseID"),&stPtzOpt.u.uiCruiseId);
    }
    else if(stPtzOpt.iPtzCtrlType == 3) // 没有其他参数，立刻停止PTZ转动
    {

    }
    else if(stPtzOpt.iPtzCtrlType == 4) // 移动到预置位，触发设备联动消息
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PresetID"),&stPtzOpt.u.uiPreSetId);
    }
    else if(stPtzOpt.iPtzCtrlType == 5) // 执行全景巡航 定时定点巡航
    {
        // Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CruiseID"),  &stPtzOpt.u.uiCruiseId);
        // Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"DwellTime"), &stPtzOpt.u.uiCruiseId);
        // Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PointCount"),&stPtzOpt.u.uiCruiseId);
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv ctrl ptz msg from peer %s ctrltype %u speed %u step %u zoom %u focus %u",uiSeqId,pucPeerId,stPtzOpt.iPtzCtrlType,
               stPtzOpt.u.stOnPtzInf.iSpeed, stPtzOpt.u.stOnPtzInf.iStep, stPtzOpt.u.stOnPtzInf.iZoom, stPtzOpt.u.stOnPtzInf.iFocus); 
    return Cmdhdl_SetDevPtzCtrlMsg(pucPeerId,uiSeqId,&stMsgFromTo,&stPtzOpt); 
}

// 设置PTZ参数 3420
_INT MsgMng_RecvSetPtzPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iOpenFlag    = 0;
    _INT iSpeed       = 0;
    _INT iStep        = 0;
    _UC *pStrTmp      = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),&iOpenFlag); // PTZ模块是否开启 :0 关闭、1 打开
    Config_SetInIotOpenFlag(EN_ZJ_AIIOT_TYPE_PTZ,0,iOpenFlag);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Speed"),&iSpeed);       // 默认转速: 1-100
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Step"),&iStep);         // 默认步长: 1-360

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set ptz prop msg speed %d step %d",uiSeqId, iSpeed, iStep);
    
    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Speed",Adpt_Json_CreateStrWithNum(iSpeed));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"Step",Adpt_Json_CreateStrWithNum(iStep));
    pStrTmp = Adpt_Json_Print(hRoot);
    
    Config_SetInIotProp(EN_ZJ_AIIOT_TYPE_PTZ,0,pStrTmp);
    
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETPTZPROP_RSP,uiSeqId,MOS_OK,&stMsgFromTo);

}

// 全链路感知排障参数 3406
_INT MsgMng_RecvSetNetworkCheck(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiType = 0;
    _UI uiDetectType = 0;
    _UI uiSiteId = 0;
    _UI uiDetectFreq  = 0;
    _UI uiDetectCount = 0;
    _UI uiCollectFreq = 0;

    _UC *pucTarget        = MOS_NULL;
    _UC *pucAuthorization = MOS_NULL;
    _UC *pucRequestURL    = MOS_NULL;
    _UC *pucRequestDate   = MOS_NULL;

    _INT i = 0;
    _INT iSiteIdArraySize       = 0;
    _INT iTargetArraySize       = 0;
    _INT iExtendArraySize       = 0;
    _INT iArraySize             = 0;
    _UC	 aucHost[5][128]        = {0};
    _INT piSiteId[5]            = {0};
    _UC  pucUrl[64]             = {0};
    _UC  aucAuthorization[2][64]= {0};
    _UC  aucRequestURL[2][1024] = {0};
    _UC  aucRequestDate[2][32]  = {0};

    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hSiteIdObject   = MOS_NULL;
    JSON_HANDLE hTargetObject   = MOS_NULL;
    JSON_HANDLE hExtendObject   = MOS_NULL;
    JSON_HANDLE hCloudUrlObject = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_NETWORK_CHECK);
        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "CMD setnetwork check error body = NULL", 1);
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_NETWORK_CHECK);
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    // Type：
    // 1-常驻探测指令(tcpping)
    // 2-排障探测指令 (tcpping\dns\速度)
    // 3-关闭探测指令（关闭常驻）
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Type"), (_INT*)&uiType);

    // DetectType:
    // 1-tcping
    // 2-dns
    // 3-带宽测试
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"detectType"), (_INT*)&uiDetectType);

    // 常驻探测指令(tcpping) 但DetectType不为tcping
    if (uiType == 1 && uiDetectType != 1)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv fail, uiType: %d, uiDetectType: %d", uiType, uiDetectType);
        Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
        return MOS_ERR;
    }

    // 常驻探测指令(tcpping) or 排障探测指令 (tcpping\dns\速度)
    if (uiType == 1 || uiType == 2)
    {
        hSiteIdObject = Adpt_Json_GetObjectItem(hBody,(_UC*)"SiteId");
        if (hSiteIdObject == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "can't resolve key \"SiteId\"");
            Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
            return MOS_ERR;
        }
        iSiteIdArraySize = Adpt_Json_GetArraySize(hSiteIdObject);

        hTargetObject = Adpt_Json_GetObjectItem(hBody,(_UC*)"Target");
        if (hTargetObject == MOS_NULL)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "can't resolve key \"Target\"");
            Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
            return MOS_ERR;
        }
        iTargetArraySize = Adpt_Json_GetArraySize(hTargetObject);
        if (iSiteIdArraySize != iTargetArraySize)
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv num of SiteId: %d and num of Target: %d is different", iSiteIdArraySize, iTargetArraySize);
            Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
            return MOS_ERR;
        }

        // 最大支持5个域名
        iTargetArraySize = (iTargetArraySize > 5) ? 5 : iTargetArraySize;
        for (i = 0; i < iTargetArraySize; i++)
        {
            Adpt_Json_GetString(Adpt_Json_GetArrayItem(hTargetObject, i), &pucTarget);
            MOS_VSNPRINTF(aucHost[i], sizeof(aucHost[i]), "%s", pucTarget);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetArrayItem(hSiteIdObject, i), (_INT*)&uiSiteId);
            piSiteId[i] = uiSiteId;
        }
        switch (uiDetectType)
        {
            // Tcping
            case EN_MSG_CLOUDSTG_NETCHECK_TCPING:
            {
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"DetectFreq"), (_INT*)&uiDetectFreq);

                // DetectFreq: 每个设备每条链路每次TCP检测间隔，以秒为单位
                // 取值范围: [0-5], default 2
                if (uiDetectFreq > 5)
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv DetectFreq: %d error", uiDetectFreq);
                    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
                    return MOS_ERR;
                }

                // DetectCount: 每个设备每条链路一轮TCP检测一共检测多少次
                // 取值范围: [1-100], default 50
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"DetectCount"), (_INT*)&uiDetectCount);
                if ((uiDetectCount < 1) || (uiDetectCount > 100))
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv DetectCount: %d error", uiDetectCount);
                    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
                    return MOS_ERR;
                }

                // CollectFreq: 每个设备一轮TCP检测的时间间隔，以秒为单位
                // 取值范围: [0, 300-1200], default 300
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CollectFreq"), (_INT*)&uiCollectFreq);
                if (((uiCollectFreq > 0) && (uiCollectFreq < 300))  || (uiCollectFreq > 1200))
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv CollectFreq: %d error", uiCollectFreq);
                    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
                    return MOS_ERR;
                }

                // 网络异常时，Tcping完成测试的时长不能大于采集周期
                if (uiType == 1 && (((uiDetectFreq + 1) * uiDetectCount * iTargetArraySize) >= uiCollectFreq))
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv DetectFreq: %d DetectCount: %d TargetArraySize: %d CollectFreq: %d error", uiDetectFreq, uiDetectCount, iTargetArraySize, uiCollectFreq);
                    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
                    return MOS_ERR;
                }

                // 常驻但CollectFreq为0
                if (uiType == 1 && uiCollectFreq == 0)
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv fail, uiType: %d, uiCollectFreq: %d", uiType, uiCollectFreq);
                    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
                    return MOS_ERR;
                }

                // 常驻
                if (uiType == 1)
                {
                    Config_setNetCheckPermanent(MOS_TRUE);
                    Config_SetNetCheckHostNum(iTargetArraySize);
                    Config_SetNetCheckCollectFreq(uiCollectFreq);
                    Config_SetNetCheckDetectFreq(uiDetectFreq);
                    Config_SetNetCheckDetectCount(uiDetectCount);
                    Config_SetNetCheckSiteId(piSiteId, sizeof(piSiteId));
                    Config_SetNetCheckHost(aucHost, sizeof(aucHost));
                }

                CloudStg_NetcheckTaskAdd_Tcping(iTargetArraySize, aucHost, sizeof(aucHost), piSiteId, sizeof(piSiteId), 
                                                uiDetectFreq, uiDetectCount, uiCollectFreq, (uiType==1)?MOS_TRUE:MOS_FALSE);
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d set network check type %u, detectType: %d, DetectFreq: %d, DetectCount: %d, CollectFreq: %d", uiSeqId, uiType, uiDetectType, uiDetectFreq, uiDetectCount, uiCollectFreq);
            }
            break;
            // Dns
            case EN_MSG_CLOUDSTG_NETCHECK_DNS:
            {
                CloudStg_NetcheckTaskAdd_Dns(iTargetArraySize, aucHost, sizeof(aucHost), piSiteId, sizeof(piSiteId));
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d set network check type %u, DetectFreq: %d", uiSeqId, uiType, uiDetectType);
            }
            break;
            // Bandwidth
            case EN_MSG_CLOUDSTG_NETCHECK_BANDWIDTH:
            {
                hExtendObject = Adpt_Json_GetObjectItem(hBody,(_UC*)"Extend");
                if (hExtendObject == MOS_NULL)
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "can't resolve key \"Extend\"");
                    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
                    return MOS_ERR;
                }
                iExtendArraySize = Adpt_Json_GetArraySize(hExtendObject);
                if (iSiteIdArraySize != iExtendArraySize)
                {
                    MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv num of SiteId: %d and num of CloudUrl: %d is different", iSiteIdArraySize, iExtendArraySize);
                    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
                    return MOS_ERR;
                }

                // 最大支持2个资源池地址
                iExtendArraySize = (iExtendArraySize > 2) ? 2 : iExtendArraySize;
                for (i = 0; i < iExtendArraySize; i++)
                {
                    hCloudUrlObject = Adpt_Json_GetArrayItem(hExtendObject, i);
                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hCloudUrlObject,(_UC*)"authorization"), &pucAuthorization);
                    MOS_VSNPRINTF(aucAuthorization[i], sizeof(aucAuthorization[i]), "%s", pucAuthorization);
                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hCloudUrlObject,(_UC*)"requestURL"), &pucRequestURL);
                    MOS_VSNPRINTF(aucRequestURL[i], sizeof(aucRequestURL[i]), "%s", pucRequestURL);
                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hCloudUrlObject,(_UC*)"requestDate"), &pucRequestDate);
                    MOS_VSNPRINTF(aucRequestDate[i], sizeof(aucRequestDate[i]), "%s", pucRequestDate);
                }
                CloudStg_NetcheckTaskAdd_Bandwidth(iExtendArraySize, aucHost, sizeof(aucHost), piSiteId, sizeof(piSiteId), aucAuthorization, sizeof(aucAuthorization), aucRequestURL, sizeof(aucRequestURL), aucRequestDate, sizeof(aucRequestDate));
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d set network check type %u, DetectFreq: %d", uiSeqId, uiType, uiDetectType);
            }
            break;
            default:
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv wrong DetectType: %d", uiDetectType);
            }
            break;
        }
    }
    // 3-关闭探测指令（关闭常驻）
    else if (uiType == 3)
    {
        Config_setNetCheckPermanent(MOS_FALSE);
        CloudStg_NetcheckTaskClosePermanent();
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d set network check type %u", uiSeqId, uiType);
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv wrong type: %d", uiType);
    }

    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_NETWORK_CHECK_RSP,uiSeqId,0,&stMsgFromTo);
    return MOS_OK;
}

// 平台通知设备事件云存追加参数配置设置3348
_INT MsgMng_RecvSetEventcloud(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_FROM_TO_MSG stMsgFromTo;
    _UC pucUrl[64]             = {0};
    _UI uiEventCloudSwitch     = 0;
    _UI uiEventCloudMaxTime    = 0;
    _UI uiEventCloudMinTime    = 0;
    _UI uiEventCloudDetectTime = 0;
    _UI uiEventCloudAppendTime = 0;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CFGBUSS, EN_OGCT_PLATCMD_EVENTCLOUD);
        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "CMD eventcloud ex error body = NULL", 1);
        Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_EVENTCLOUD_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CFGBUSS, EN_OGCT_PLATCMD_EVENTCLOUD);
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EventCloudSwitch"), (_INT*)&uiEventCloudSwitch);
    if (uiEventCloudSwitch == 1)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EventCloudMaxTime"), (_INT*)&uiEventCloudMaxTime);
        if ((uiEventCloudMaxTime < EN_OGCT_EVENTCLOUD_RANGE_MAXTIME_MIN) || (uiEventCloudMaxTime > EN_OGCT_EVENTCLOUD_RANGE_MAXTIME_MAX))
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv wrong parameters");
            Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_EVENTCLOUD_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
            return MOS_ERR;
        }

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EventCloudMinTime"), (_INT*)&uiEventCloudMinTime);
        if ((uiEventCloudMinTime < EN_OGCT_EVENTCLOUD_RANGE_MINTIME_MIN) || (uiEventCloudMinTime > EN_OGCT_EVENTCLOUD_RANGE_MINTIME_MAX))
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv wrong parameters");
            Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_EVENTCLOUD_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
            return MOS_ERR;
        }

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EventCloudDetectTime"), (_INT*)&uiEventCloudDetectTime);
        if ((uiEventCloudDetectTime < EN_OGCT_EVENTCLOUD_RANGE_DETECTTIME_MIN) || (uiEventCloudDetectTime > EN_OGCT_EVENTCLOUD_RANGE_DETECTTIME_MAX))
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv wrong parameters");
            Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_EVENTCLOUD_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
            return MOS_ERR;
        }

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EventCloudAppendTime"), (_INT*)&uiEventCloudAppendTime);
        if ((uiEventCloudAppendTime < EN_OGCT_EVENTCLOUD_RANGE_APPENDTIME_MIN) || (uiEventCloudAppendTime > EN_OGCT_EVENTCLOUD_RANGE_APPENDTIME_MAX))
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "recv wrong parameters");
            Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_EVENTCLOUD_RSP,(_INT)uiSeqId,MOS_ERR,&stMsgFromTo);
            return MOS_ERR;
        }

        // 设置参数至cloudstg模块及云存config
        Config_SetEventCloudSwitch(uiEventCloudSwitch);
        Config_SetEventCloudMaxTime(uiEventCloudMaxTime);
        Config_SetEventCloudMinTime(uiEventCloudMinTime);
        Config_SetEventCloudDetectTime(uiEventCloudDetectTime);
        Config_SetEventCloudAppendTime(uiEventCloudAppendTime);

        CloudStg_SetEventCloudSwitch(uiEventCloudSwitch);
        CloudStg_SetEventCloudMaxTime(uiEventCloudMaxTime);
        CloudStg_SetEventCloudMinTime(uiEventCloudMinTime);
        CloudStg_SetEventCloudDetectTime(uiEventCloudDetectTime);
        CloudStg_SetEventCloudAppendTime(uiEventCloudAppendTime);
        CloudStg_SetStartNextEventCloudFlag(MOS_FALSE);
    }
    else
    {
        Config_SetEventCloudSwitch(uiEventCloudSwitch);
    }

    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CFGBUSS,EN_OGCT_PLATCMD_EVENTCLOUD_RSP,uiSeqId,0,&stMsgFromTo);
    return MOS_OK;
}

// 3412
_INT MsgMng_RecvRebootDevMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IS COMING");

    _INT iStatus     = 0;
    _INT iRebootType = 0;
    ST_FROM_TO_MSG stMsgFromTo = {0};

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot, &stMsgFromTo);

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        // 兼容新增静默重启前平台下发的情况
        iRebootType = EN_ZJ_REBOOT_NORMAL;
    }
    else
    {
        // 0-正常重启 1-静默重启  默认0 参考:EN_ZJ_REBOOT_TYPE
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"Type"),&iRebootType);
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "reqid %u recv reboot msg from peer %s RebootType:%d", uiSeqId, pucPeerId, iRebootType);
    
    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_REBOOT_RSP, uiSeqId, iStatus, &stMsgFromTo);

    // 关闭MP4、Commit云存任务、即将关闭信令服务器，流媒体连接
    MsgMng_GetCmdServer()->uiForceCloseCmdFlag = 1;
    Cmdhdl_CloseSomethingBeforeReboot(MOS_FALSE);
    MsgMng_MultiMediaCloseAllConnect();
    if(ZJ_GetFuncTable()->pfunDevRebootCb)
    {
        iStatus = ZJ_GetFuncTable()->pfunDevRebootCb(iRebootType);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_REBOOT);
            MOS_SPRINTF(pucErrorString, "Device pfunDevRebootCb err RebootType:%d", iRebootType);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, pucErrorString, 1);
        }
    }
    return MOS_OK;
}

// 回复检查固件版本3415
static _INT MsgMng_SendCheckNewVersionRsp(_VPTR pstUsrInf,_UI uiCode,_UC *pucNewVersion,_UC *pucDownUrl,_UC *pucDes)
{
    MOS_PARAM_NULL_RETERR(pstUsrInf);
    MOS_PARAM_NULL_RETERR(pucNewVersion);
    MOS_PARAM_NULL_RETERR(pucDownUrl);
    //MOS_PARAM_NULL_RETERR(pucDes);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC aucMethod[16];
    _UC *pucStrTmp = MOS_NULL;
    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_CMD_MSG_INF *pstMsgInf = (ST_CMD_MSG_INF*)pstUsrInf;
    if(pstMsgInf == MOS_NULL)
    {
        return MOS_ERR;
    }
    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
    
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",pstMsgInf->ucMsgType,pstMsgInf->ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    
    Cmdhdl_AddMsgSrcInfObject(hRoot,pstMsgInf->uiSeqId,&pstMsgInf->stMsgFromTo); 

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    if(uiCode != 0 && uiCode != 1)
    {
        uiCode = 0;
    }
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Version",Adpt_Json_CreateString(pucNewVersion));
    if (pucDes == MOS_NULL)
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"DescURL",Adpt_Json_CreateString(""));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"DescURL",Adpt_Json_CreateString(pucDes));  
    }
    Adpt_Json_AddItemToObject(hBody,(_UC*)"UpdateFlag",Adpt_Json_CreateStrWithNum(uiCode));
    
    pucStrTmp = Adpt_Json_Print(hRoot);
    
    MsgMng_SendMsg(pstMsgInf->aucPeerId,pstMsgInf->uiSeqId,pstMsgInf->ucMsgType,pstMsgInf->ucMsgId,
        pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u send check version rsp %s",pstMsgInf->uiSeqId,pucStrTmp);

    MOS_FREE(pstMsgInf);
    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;
}

// 设备远程升级  设备固件版本检测指令 3414
_INT MsgMng_RecvCheckNewVersionMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    CloudStg_UploadLogEx2(OVER_THE_AIR_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_OTA_RT_NEED_CHECK_NEWVERSION, "Recv check hardfire version Msg",MOS_NULL, 1);

    ST_CMD_MSG_INF *pstMsgInf = MOS_NULL;
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    pstMsgInf = (ST_CMD_MSG_INF*)MOS_MALLOCCLR(sizeof(ST_CMD_MSG_INF));
    pstMsgInf->ucMsgId   = EN_OGCT_PLATCMD_CHEACKVERSION_RSP;
    pstMsgInf->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstMsgInf->uiSeqId   = uiSeqId; 
    MOS_STRNCPY(pstMsgInf->aucPeerId,pucPeerId,sizeof(pstMsgInf->aucPeerId));
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&pstMsgInf->stMsgFromTo);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv check hardfire version msg from peer %s",pstMsgInf->uiSeqId,pucPeerId);    
    // 检查固件新版本
    Ota_CheckNewVersion(pstMsgInf,MsgMng_SendCheckNewVersionRsp);
    return MOS_OK;
}

// 设备OSD自定义(文本)水印信息设置 341C
_INT MsgMng_RecvSetCamOsdMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IS COMING");
    // _UC * pucJson = Adpt_Json_Print(hJsonRoot);
    // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING %s", pucJson);
    // MOS_FREE(pucJson);

    _INT iPostion             = 0;
    _UC *pucOsdName           = MOS_NULL;
    _INT iOSDCustomMode       = 0; // OSD自定义水印模式默认为0
    _UC *pucOsdTopLeftName    = MOS_NULL;
    _UC *pucOsdTopRightName   = MOS_NULL;
    _UC *pucOsdLowerLeftName  = MOS_NULL;
    _UC *pucOsdLowerRightName = MOS_NULL;

    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "hBody == MOS_NULL");
        return MOS_ERR;
    }

    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot, &stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OSDCustomMode"),&iOSDCustomMode);

    // 0.默认，只能显示一个位置水印
    if (iOSDCustomMode == 0)
    {
        // OSD自定义(文本)水印内容      格式:UTF-8，最大支持512字节
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Name"),&pucOsdName);

        // OSD自定义(文本)水印位置      0.默认；1.左上；2.左下；3.右上；4.右下
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Position"),&iPostion);

        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "reqid %u recv set Osd msg Position %d name %s", uiSeqId, iPostion, pucOsdName);

        return Cmdhdl_SetCamOsdInfMsg(pucPeerId,uiSeqId,&stMsgFromTo,iPostion,pucOsdName);
    }
    // 1.支持同时显示四个位置水印
    else
    {
        JSON_HANDLE hOSDName   = MOS_NULL;
        JSON_HANDLE hOSDExpand = Adpt_Json_GetObjectItem(hBody,(_UC*)"OSDExpand");
        if (hOSDExpand == MOS_NULL)
        {
            // JSON出错也需要回复中台设置错误
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "OSDCustomMode is %d OSDExpand is null", iOSDCustomMode);
            return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETOSD_RSP,uiSeqId,MOS_ERR,&stMsgFromTo);
        }
        // OSD左上自定义(文本),四角水印
        hOSDName = Adpt_Json_GetObjectItem(hOSDExpand,(_UC*)"TopLeftName");
        if (hOSDName)
        {
            Adpt_Json_GetString(hOSDName,&pucOsdTopLeftName);
        }
        // OSD左下自定义(文本),四角水印
        hOSDName = Adpt_Json_GetObjectItem(hOSDExpand,(_UC*)"LowerLeftName");
        if (hOSDName)
        {
            Adpt_Json_GetString(hOSDName,&pucOsdLowerLeftName);
        }
        // OSD右上自定义(文本),四角水印
        hOSDName = Adpt_Json_GetObjectItem(hOSDExpand,(_UC*)"TopRightName");
        if (hOSDName)
        {
            Adpt_Json_GetString(hOSDName,&pucOsdTopRightName);
        }
        // OSD右下自定义(文本),四角水印
        hOSDName = Adpt_Json_GetObjectItem(hOSDExpand,(_UC*)"LowerRightName");
        if (hOSDName)
        {
            Adpt_Json_GetString(hOSDName,&pucOsdLowerRightName);
        }

        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "reqid %u recv set Osd msg name TL:%s LL:%s TR:%s LR:%s",
                    uiSeqId,pucOsdTopLeftName,pucOsdLowerLeftName,pucOsdTopRightName,pucOsdLowerRightName);

        return Cmdhdl_SetCamOsdInfExMsg(pucPeerId,uiSeqId,&stMsgFromTo,pucOsdTopLeftName,pucOsdLowerLeftName,pucOsdTopRightName,pucOsdLowerRightName);
    }
}

// 设备OSD默认(时间)/自定义(文本)水印显示设置 34D0
_INT MsgMng_RecvSetCamOsdDisplayMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IS COMING");

    _INT iOSDType     = 0;
    _INT iDisplayFlag = 0;
    ST_FROM_TO_MSG stMsgFromTo = {0};

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "hBody == MOS_NULL");
        return MOS_ERR;
    }

    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot, &stMsgFromTo);
    
    // 显示状态 0.关闭(不显示)，1.开启(显示)
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"DisplayFlag"),&iDisplayFlag);

    // 显示类型 0.默认(时间)水印，1.自定义(文本)水印
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OSDType"),&iOSDType);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "reqid %u recv set Osd msg DisplayFlag %d OSDType %d", uiSeqId, iDisplayFlag, iOSDType);

    return Cmdhdl_SetCamOsdDisplayInfMsg(pucPeerId, uiSeqId, &stMsgFromTo, iDisplayFlag, iOSDType);
}

// 设备OSD默认(时间)水印信息设置 340A
_INT MsgMng_RecvSetCamCommonOsdInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iOSDCommonFormat      = 0;
    _INT iOSDCommonPosition    = 0;
    ST_FROM_TO_MSG stMsgFromTo = {0};

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "hBody == MOS_NULL");
        return MOS_ERR;
    }

    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot, &stMsgFromTo);
    
    // OSD默认(时间)水印位置  0.默认（右上）；1.左上；2.左下；3.右上；4.右下
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OSDCommonPosition"),&iOSDCommonPosition);

    // OSD默认(时间)水印格式
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OSDCommonFormat"),&iOSDCommonFormat);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "reqid %u recv set Common Osd Inf msg OSDCommonPosition %d OSDCommonFormat %d",
                                    uiSeqId, iOSDCommonPosition, iOSDCommonFormat);

    return Cmdhdl_SetCamCommonOsdInfMsg(pucPeerId, uiSeqId, &stMsgFromTo, iOSDCommonPosition, iOSDCommonFormat);
}

// 恢复出厂设置 3416
_INT MsgMng_RecvSetDevFactoryMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv restore to factory msg from peer %s",uiSeqId,pucPeerId);
    return Cmdhdl_SetCommonMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_FACTORYSETTING,&stMsgFromTo); 
}

// 设置摄像头开关 341E
_INT MsgMng_RecvSetCamStatusMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus       = MOS_ERR;
    _INT iOpenFlag     = 0;
    _UC aucBuf[256]    = {0};
    _UC aucStrLog[128] = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody  = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    // 摄像头开关状态，0.关闭； 1.打开
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Status"),&iOpenFlag);

    if(ZJ_GetFuncTable()->pfunCameraSwitch)
    {
        iStatus = ZJ_GetFuncTable()->pfunCameraSwitch(iOpenFlag);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CAMSTATUS);
            MOS_SPRINTF(pucErrorString, "Device pfunCameraSwitch(iOpenFlag:%d) err", iOpenFlag);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, pucErrorString, 1);
        } 
    }
    else
    {
        // 厂商无对接，SDK内部处理
        iStatus = MOS_OK;
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunCameraSwitch is NULL!");
    }

    MOS_VSNPRINTF(aucBuf, sizeof(aucBuf), "reqid %u recv set camopenFlag %d from peer %s",uiSeqId,iOpenFlag,pucPeerId);
    if (MOS_OK == iStatus)
    {
        Config_SetCamerOpenFlag(0,iOpenFlag);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, 0, aucBuf, 1);

        // 手动设置休眠状态后，上报当前休眠状态 0x3410
        MsgMng_UploadDevStatus(iOpenFlag, EN_DEV_STATUS_CHANGE_WAY_CMD);      
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"%s", aucBuf);
    
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CAMSTATUS_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 设备图像倒置设置 341A
_INT MsgMng_RecvSetImageRotateMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{ 
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iRatateType = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody  = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo); 

    // 倒置状态：1、旋转180° 2、逆向旋转180° 3、镜像翻转 4、取消镜像翻转
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Inversion"),&iRatateType);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set camrotate %d msg from %s",uiSeqId,iRatateType,pucPeerId);
    
    return Cmdhdl_SetImageRotateMsg(pucPeerId,uiSeqId,&stMsgFromTo, iRatateType);
}

// 设置设备视频参数 3418
_INT MsgMng_RecvSetVideoEncParamMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT iStreamId = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_ZJ_VIDEO_PARAM stVideoParam;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo); 
     
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"StreamID"),     &iStreamId);                            // 码流序号
    ST_CFG_VIDEODES *pstVideoDes = Config_GetVideoDes(0,iStreamId);
    if(pstVideoDes)
    {
        MOS_MEMCPY(&stVideoParam,&pstVideoDes->stVideoPara,sizeof(ST_ZJ_VIDEO_PARAM));
    }
    else
    {
        MOS_MEMSET(&stVideoParam,0,sizeof(ST_ZJ_VIDEO_PARAM));
    }

    /**
     * 协议存在部分字段未下发，对未下发的字段的值不作处理
    */
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hBody,(_UC*)"Resolution"),    (_INT*)&stVideoParam.uiResolution, stVideoParam.uiResolution);        // 分辨率，见分辨率定义 EN_ZJ_CARERA_RESOLUTION_ABILITY
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncType"),       (_INT*)&stVideoParam.uiEncodeType, stVideoParam.uiEncodeType);        // 编码类型
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hBody,(_UC*)"SmartEncFlag"),  (_INT*)&stVideoParam.uiSmartEncFlag, stVideoParam.uiSmartEncFlag);    // Smart编码标记
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hBody,(_UC*)"Quality"),       (_INT*)&stVideoParam.uiQuality, stVideoParam.uiQuality);              // 编码质量，VBR编码方式时
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hBody,(_UC*)"FrameRate"),     (_INT*)&stVideoParam.uiFramerate, stVideoParam.uiFramerate);          // 帧率
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hBody,(_UC*)"BitRate"),       (_INT*)&stVideoParam.uiBitrate, stVideoParam.uiBitrate);              // 码率，见码率定义 EN_ZJ_CAMERA_BITRATE_TYPE
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hBody,(_UC*)"RateType"),      (_INT*)&stVideoParam.uiRateType, stVideoParam.uiRateType);            // 编码方式：0=CBR 固定码率, 1=VBR 固定质量
    Adpt_Json_GetIntegerEx2(Adpt_Json_GetObjectItem(hBody,(_UC*)"FrameInterval"), (_INT*)&stVideoParam.uiFrameInterval, stVideoParam.uiFrameInterval);  // I帧间隔 50帧、100帧、200帧
    // 高清云存套餐
    _UI uiResolution = stVideoParam.uiResolution;
    if(uiResolution == EN_ZJ_CARERA_RESOLUTION_ABILITY_300W)
    {
        if(Config_GetCloudMng()->iPackageType <= 1 && stVideoParam.uiBitrate > EN_ZJ_CAMERA_BITRATE_TYPE_1536K)
        {
            stVideoParam.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_1536K;
        }
        else if(Config_GetCloudMng()->iPackageType == 2 && stVideoParam.uiBitrate > EN_ZJ_CAMERA_BITRATE_TYPE_3072K)
        {
            stVideoParam.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_3072K;
        }
    }
    else if(uiResolution == EN_ZJ_CARERA_RESOLUTION_ABILITY_400W || uiResolution == EN_ZJ_CAMERA_RESOLUTION_ABILITY_600W \
    || uiResolution == EN_ZJ_CARERA_RESOLUTION_ABILITY_500W || uiResolution == EN_ZJ_CAMERA_RESOLUTION_ABILITY_1440P \
    || uiResolution == EN_ZJ_CARERA_RESOLUTION_ABILITY_4K)
    {
        if(Config_GetCloudMng()->iPackageType <= 1 && stVideoParam.uiBitrate > EN_ZJ_CAMERA_BITRATE_TYPE_2048K)
        {
            stVideoParam.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_2048K;
        }
        else if(Config_GetCloudMng()->iPackageType == 2 && stVideoParam.uiBitrate > EN_ZJ_CAMERA_BITRATE_TYPE_4096K)
        {
            stVideoParam.uiBitrate = EN_ZJ_CAMERA_BITRATE_TYPE_4096K;
        }
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set Cam video resolution %u bitrate:%u FrameRate:%u EncType:%u", 
                    uiSeqId, stVideoParam.uiResolution, stVideoParam.uiBitrate, stVideoParam.uiFramerate, stVideoParam.uiEncodeType);

    return Cmdhdl_SetVideoEncParamMsg(pucPeerId,uiSeqId,&stMsgFromTo,iStreamId,&stVideoParam);
}

// 设置预置位PTZ 3422
_INT MsgMng_RecvSetPreSetPointMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iPreSetId,iSetCmd;
    _UC *pucPointName = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo); 
     
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PresetID"),&iPreSetId); // 预置点序号（1-256）
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SetCmd"), &iSetCmd);    // 设置操作：1-设置，2-删除，3-全部删除
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Name"),&pucPointName);     // 预置点名称

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set presetpoint setcmd %u presetid %u name %s",uiSeqId,iSetCmd,iPreSetId,pucPointName);
    return Cmdhdl_SetPreSetPointMsg(pucPeerId,uiSeqId,&stMsgFromTo,iSetCmd,iPreSetId,pucPointName);
}

// 设置巡航轨迹预置位PTZ 3424
_INT MsgMng_RecvSetCruiseMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iSetCmd                = 0;
    _UI uiCruiseID              = 0;
    _INT i,iArraySize           = 0;
    _INT iPresetId,iDwellTime,iSpeed;
    ST_FROM_TO_MSG stMsgFromTo;
    _UC *pStrTmp                = MOS_NULL;
    JSON_HANDLE hCuriseObject   = MOS_NULL;
    JSON_HANDLE hPointObject    = MOS_NULL;
    JSON_HANDLE hBody           = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SetCmd"),&iSetCmd);             // 设置操作：1-设置，2-删除
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CruiseID"),(_INT*)&uiCruiseID); // 轨迹序号（1-8）

    if(iSetCmd == 2)
    {
        Config_DeleteCurise(0,uiCruiseID);
    }
    else if(iSetCmd == 1)
    {
        Config_AddCurise(0,uiCruiseID);
        
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"CruiseName"),&pStrTmp);    // 轨迹名称
        Config_SetCuriseName(0,uiCruiseID,pStrTmp);
        
        hCuriseObject = Adpt_Json_GetObjectItem(hBody,(_UC*)"PresetPoints");    // 预置位点
        iArraySize = Adpt_Json_GetArraySize(hCuriseObject);
        for(i = 0; i < iArraySize; i++)
        {
            hPointObject = Adpt_Json_GetArrayItem(hCuriseObject,i);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointObject,(_UC*)"PresetID"),&iPresetId);      // 预置点序号（1-256）
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointObject,(_UC*)"DwellTime"),&iDwellTime);    // 停留时间(5-60s)
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPointObject,(_UC*)"Speed"),&iSpeed);            // 云台速度（1-7）
            Config_AddPresetIdToCuriseEx(0,uiCruiseID,iPresetId,iDwellTime,iSpeed);
        }
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set Curise Cmdtype %d, cruiseID %u",uiSeqId,iSetCmd, uiCruiseID); 
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETCRUISE_RSP,uiSeqId,MOS_OK,&stMsgFromTo);

}

// 设置看守位 3426
_INT MsgMng_RecvSetWatchPointMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iSetCmd                = 0;
    _UI uiPresetID              = 0;
    _UI uiWatchTime             = 0; 
    ST_FROM_TO_MSG  stMsgFromTo;
    JSON_HANDLE hBody =  Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SetCmd"),&iSetCmd); // 设置操作：1-设置，2-删除 
    if(iSetCmd == 1)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PresetID"),(_INT*)&uiPresetID);     // 预置点序号（1-256）
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"WatchTime"),(_INT*)&uiWatchTime);   // 看守位回归时间（5-360s）
        Config_AddWatchPoint(0,uiPresetID,uiWatchTime);
    }
    else if(iSetCmd == 2)
    {
        Config_DeleteWatchPoint(0);
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set WatchPoint CmdType %d, presetID %u,watchTime %u",uiSeqId,iSetCmd,uiPresetID,uiWatchTime);
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETWATCHPOINT_RSP,uiSeqId,MOS_OK,&stMsgFromTo);
}

// 设置设备音频参数 342A
_INT MsgMng_RecvSetAudioParamMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_ZJ_AUDIO_PARAM  stAudioParm;
    ST_FROM_TO_MSG     stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 音频编码模式 PCM16 0x01、G711A 0x02、G711U 0x04
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncType"),(_INT*)&stAudioParm.uiEncodeType);
    // 采样率 例如8000
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SampleRate"),(_INT*)&stAudioParm.uiSampleRate);
    // 声道数
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Channel"),(_INT*)&stAudioParm.uiChannel);
    // 深度
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Depth"),(_INT*)&stAudioParm.uiDepth);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set audio enctype %u sampleRate %u",uiSeqId,stAudioParm.uiEncodeType,stAudioParm.uiSampleRate);
    return Cmdhdl_SetAudioParamMsg(pucPeerId,uiSeqId,&stMsgFromTo,&stAudioParm);
}

// 设备麦克风开关设置 3434
_INT MsgMng_RecvSetMicOpenMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iMicStatus = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 麦克风开关状态，0.关闭； 1.打开
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Status"),&iMicStatus);

    Config_SetCamerMicOpenFlag(0,iMicStatus);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set Mic OpenFlag %d from peer %s",uiSeqId,iMicStatus,pucPeerId);
    
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETMICOPENFLAG_RSP,uiSeqId,MOS_OK,&stMsgFromTo);

}

// 定时策略设置 定时策略为定时时间段内对各模块的功能参数配置 3436
_INT MsgMng_RecvSetTimePolicyMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING   3436");

    _INT i           = 0;
    _INT iStatus     = MOS_ERR;
    _UI uiOpenFlag   = 0;
    _UI uiSceneId    = 0;
    _UI uiSetCmd     = 0;
    _UI uiArraySize  = 0;
    _UI uiKjIoTType  = 0;
    _UI uiWeekFlag   = 0;
    _UI uiStartTime  = 0;
    _UI uiEndTime    = 0;
    _UI uiSpanFlag   = 0;
    _UI uiLoopType   = 0;
    _LLID lluKjIotId = 0 ;
    _UC aucPolicyId[64] = {0};
    _INT iTaskChageFlag = 0;
    _UC *pucDay         = MOS_NULL;
    _UC *pStrTmp        = MOS_NULL;
    _UC *pucPolicyId    = MOS_NULL;
    _UC *pucPolicyName  = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hPropObj     = MOS_NULL;
    JSON_HANDLE hOutputArray = MOS_NULL;
    JSON_HANDLE hOutoutItem  = MOS_NULL;
    ST_CFG_TIMEPOLICY_NODE *pstTimerNode = MOS_NULL;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
   
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SetCmd"),(_INT*)&uiSetCmd);         // 1-设置，2-删除
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"PolicyID"),&pucPolicyId);
    MOS_STRNCPY(aucPolicyId, pucPolicyId, sizeof(aucPolicyId));

    if (uiSetCmd == EN_MSG_SETCMD_TYPE_ADD_OR_SET)
    {
        pstTimerNode = Config_FindOrCreatTimePolicy(aucPolicyId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),(_INT*)&uiOpenFlag);     // 策略开关 :1开 0关
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SceneID"),(_INT*)&uiSceneId);       // 场景Id 例如0
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"PolicyName"),&pucPolicyName);          // 策略名
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Week"),(_INT*)&uiWeekFlag);         // 周几,为掩码代表一周中的一天或多天
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"StartTime"),(_INT*)&uiStartTime);   // 开始时间(时间戳,精确秒)
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EndTime"),(_INT*)&uiEndTime);       // 结束时间(时间戳,精确秒)
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SpanFlag"),(_INT*)&uiSpanFlag);     // 是否跨天
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"LoopType"),(_INT*)&uiLoopType);     // 0 循环定时任务 , 1 一次性定时任务
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Day"),&pucDay);                        // 一次性任务的执行日期 例如,2014-08-02

        // 定时任务开关时，若该任务在运行中，则需要停止该定时任务
        if (pstTimerNode->uiOpenFlag != uiOpenFlag)
        {
            if (pstTimerNode->uiWorkFlag == EN_TIMEPOLICY_STATUS_WORKING)
            {
                Config_MutexLock();
                Config_SetTimePolicyOutPutWorkFlag(pstTimerNode, EN_TIMEPOLICY_STATUS_NOWORK);
                KjIoT_StopTimePolicyActions(pstTimerNode);
                Config_MutexUnLock();
            }
        }
        Config_SetTimePolicyOpenFlag(pstTimerNode,uiOpenFlag);
        Config_SetTimePolicyOutPutSceneId(pstTimerNode,uiSceneId);
        iStatus = Config_SetTimePolicyName(pstTimerNode,pucPolicyName);
        if (iStatus == MOS_OK)
        {
            // 定时任务的参数变化标志
            iTaskChageFlag = 1;
        }
        iStatus = Config_SetTimePolicyTime(pstTimerNode,uiLoopType,pucDay,uiWeekFlag,uiStartTime,uiEndTime,uiSpanFlag);
        if (iStatus == MOS_OK)
        {
            // 定时任务的参数变化标志
            iTaskChageFlag = 1;
        }
        // 定时任务的参数变化，若该任务在运行中，则需要停止该定时任务
        if (iTaskChageFlag == 1)
        {
            if (pstTimerNode->uiWorkFlag == EN_TIMEPOLICY_STATUS_WORKING)
            {
                Config_MutexLock();
                Config_SetTimePolicyOutPutWorkFlag(pstTimerNode, EN_TIMEPOLICY_STATUS_NOWORK);
                KjIoT_StopTimePolicyActions(pstTimerNode);
                Config_MutexUnLock();
            }
        }
        
        hOutputArray = Adpt_Json_GetObjectItem(hBody,(_UC*)"Action");
        uiArraySize  = Adpt_Json_GetArraySize(hOutputArray);
        for (i = 0; i < uiArraySize; i++)
        {
            hOutoutItem = Adpt_Json_GetArrayItem(hOutputArray, i);
            pStrTmp  = Adpt_Json_Print(hOutoutItem);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hOutoutItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);   // IoT类型
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hOutoutItem,(_UC*)"AIIoTID"),&pStrTmp); // 设备ID
            MOS_SSCANF(pStrTmp, "%llu",&lluKjIotId);
            hPropObj = Adpt_Json_GetObjectItem(hOutoutItem,(_UC*)"Output");   // 具体见AIIoT类型事件、属性、输出定义 （键值对JSON）
            pStrTmp  = Adpt_Json_Print(hPropObj);
            Config_AddTimerPolicyOutput(pstTimerNode,uiKjIoTType,lluKjIotId,pStrTmp);
            Adpt_Json_DePrint(pStrTmp);
        }
        iStatus = MOS_OK;
    }
    else if (uiSetCmd == EN_MSG_SETCMD_TYPE_DEL)
    {
        // TODO 操作删除正在工作的定时任务时，先停止定时任务再删除任务
        pstTimerNode = Config_FindOrCreatTimePolicy(aucPolicyId);
        if (pstTimerNode->uiWorkFlag == EN_TIMEPOLICY_STATUS_WORKING)
        {
            Config_MutexLock();
            Config_SetTimePolicyOutPutWorkFlag(pstTimerNode, EN_TIMEPOLICY_STATUS_NOWORK);
            KjIoT_StopTimePolicyActions(pstTimerNode);
            Config_MutexUnLock();
        }
        Config_DeleteTimePolicyByStr(aucPolicyId);
        iStatus = MOS_OK;
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"3436 SetCmd(%u) is wrong", uiSetCmd);
        iStatus = MOS_ERR;
    }

    KjIoT_SetTimerInfChange();
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set TimePolicyId %s setCmd %u OpenFlag %u",uiSeqId, aucPolicyId, uiSetCmd, uiOpenFlag);
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_TIMER_POLICY_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 本地卡录制参数配置 342C
_INT MsgMng_RecvSetLocalRecordPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiLoopRecordFlag = 0;
    _UI uiRecordFullFlag = 0;
    _UI uiStreamId       = 0;
    _UI uiOpenFlag       = 0;
    _UI uiDuration       = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),(_INT*)&uiOpenFlag); // 录制模块是否开启: 1开 ,0 关
    Config_SetInIotOpenFlag(EN_ZJ_AIIOT_TYPE_RECORD,0,uiOpenFlag);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"RecordLoop"),(_INT*)&uiLoopRecordFlag); // 本地是否循环录制 :1 是, 2:否
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"RecordFull"),(_INT*)&uiRecordFullFlag); // 是否全天录制，1.全天录制；0.按策略录制
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"StreamID"),(_INT*)&uiStreamId);         // 录制码流ID选择
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Duration"),(_INT*)&uiDuration);         // 报警录制时长
    Config_SetRecordProp(uiLoopRecordFlag,uiRecordFullFlag,uiStreamId,uiDuration);
    Config_SetSnapProp(1,uiRecordFullFlag,180,EN_ZJ_PICTURE_MIDDLE);
    RdStg_ResetStreamId(0,uiStreamId);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set LocalRecord openFlag %u,Loop %u,Full %u, streamID %u",
        uiSeqId,uiOpenFlag, uiLoopRecordFlag, uiRecordFullFlag, uiStreamId);
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_LOCALRECORD_RSP,uiSeqId,0,&stMsgFromTo);
}

// 事件联动触发策略设置 3438
_INT MsgMng_RecvSetAlarmPolicyMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, 0, "AlarmPolicy Recv SetAlarmPolicyMsg", 1);

    _INT  i = 0;
    _INT  j = 0;
    _INT  iRet              = MOS_ERR;
    _UI   uiSetCmd          = 0;
    _INT  iSetLampFlag      = 0;
    _UI   uiOpenFlag        = 0;
    _UI   uiSpanFlag        = 0;
    _UI   uiSceneId         = 0;
    _INT  iArraySize        = 0;
    _UI   uiPolicyId        = 0;
    _UI   uiKjIoTType       = 0;
    _LLID lluKjIotId        = 0;
    _UI   uiKjIoTEventId    = 0;
    _UI   uiOutIotType      = 0;
    _LLID uiOutIotId        = 0;
    _UI   uiWeekFlag        = 0;
    _UI   uiStartTime       = 0;
    _UI   uiEndTime         = 0;;
    _INT  iActionArrySize   = 0;
    _INT  iHumanPushFlag    = 0;
    _INT  iMothionPushFlag  = 0;
    _UC   *pucStrTmp        = MOS_NULL;
    JSON_HANDLE hPropObj    = MOS_NULL;
    JSON_HANDLE hActionArry = MOS_NULL;
    JSON_HANDLE hActionItem = MOS_NULL;
    JSON_HANDLE hEventArry  = MOS_NULL;
    JSON_HANDLE hEventItem  = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo = {0};
    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
    ST_KJIOT_CONTRLDEV_NODE *pstIotDevNode  = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_LAMP);
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");        
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "AlarmPolicy Check The hJsonRoot Is Null", 1);
        return MOS_ERR;
    }

    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");       
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType); // 设备类型
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTID"),&pucStrTmp);             // 该类型下设备ID
    MOS_SSCANF(pucStrTmp, "%llu",&lluKjIotId);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PolicyID"),(_INT*)&uiPolicyId); // 策略ID

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SetCmd"),(_INT*)&uiSetCmd);     // 1-设置，2-删除
    
    if (uiSetCmd == EN_MSG_SETCMD_TYPE_DEL)
    {
        Config_DeleteAlarmPolicyNode(uiKjIoTType,lluKjIotId,uiPolicyId);
        iRet = MOS_OK;
    }
    else if (uiSetCmd == EN_MSG_SETCMD_TYPE_ADD_OR_SET)
    {
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType,lluKjIotId,uiPolicyId);

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),(_INT*)&uiOpenFlag); // 报警策略开关 :1 开 0 关
        Config_SetAlarmPolicyOpenFlag(pstAPolicyNode,uiOpenFlag);
        
        hPropObj = Adpt_Json_GetObjectItem(hBody,(_UC*)"Prop"); // 属性
        if (hPropObj != MOS_NULL)
        {
            // 存在新人脸，则删除IOT 1000属性Face字段（非必须，SDK上报无Face字段，则平台不会下发Face字段）
            if (EN_ZJ_AIIOT_TYPE_MOTION == uiKjIoTType)
            {
                if (1 == Config_GetNewFaceAbility())
                {
                    Adpt_Json_DeleteItemFromObject(hPropObj, (_UC *)"Face");
                }
            }

            pucStrTmp = Adpt_Json_Print(hPropObj);
            // 云化 iot属性变化通知
            if (ZJ_GetFuncTable()->pfunSetAIIotProp)
            {
                ZJ_GetFuncTable()->pfunSetAIIotProp(uiKjIoTType, lluKjIotId, pucStrTmp);
            }
            ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(pstAPolicyNode->uiKjIoTType);
            if (pstDevCtrlNode && pstDevCtrlNode->pfunSetProp)
            {
                // 属性不一致时才回调给厂商（批量下发人脸时会伴随大量的3438信令，导致产商AI功能开关频繁）
                if (MOS_STRCMP(pstAPolicyNode->pucProp, pucStrTmp) != 0)
                {
                    iRet = pstDevCtrlNode->pfunSetProp(pstAPolicyNode->uiKjIoTType,pstAPolicyNode->lluKjIotId,pucStrTmp);
                    // 更新到本地配置
                    if (iRet == MOS_OK)
                    {
                        Config_SetAlarmPolicyProp(pstAPolicyNode,pucStrTmp);
                    }
                    else
                    {
                        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CALLBACK_FAIL, "callback pfunSetProp error", 1);
                    }
                }
                else
                {
                    // prop属性相同时不需要回调pfunSetProp接口，则返回成功。
                    iRet = MOS_OK;
                }
            }
            MOS_FREE(pucStrTmp);
        }
        
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"PolicyName"),&pucStrTmp);  // 策略名
        Config_SetAlarmPolicyName(pstAPolicyNode,pucStrTmp);
            
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Week"),(_INT*)&uiWeekFlag);       // 周几,为掩码代表一周中的一天或多天
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"StartTime"),(_INT*)&uiStartTime); // 开始时间 距离0点的秒数
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EndTime"),(_INT*)&uiEndTime);     // 结束时间 距离0点的秒数
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SpanFlag"),(_INT*)&uiSpanFlag);   // 跨天开关 1 开 0 关
        
        Config_SetAlarmPolicyTime(pstAPolicyNode,uiSpanFlag,uiWeekFlag,uiStartTime,uiEndTime);
        
        hEventArry = Adpt_Json_GetObjectItem(hBody,(_UC*)"Events");
        iArraySize = Adpt_Json_GetArraySize(hEventArry);

        Config_AlarmPolicyEventBegainSync(pstAPolicyNode);
        for (i = 0; i < iArraySize; i++)
        {
            hEventItem = Adpt_Json_GetArrayItem(hEventArry,i);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hEventItem,(_UC*)"EventID"),(_INT*)&uiKjIoTEventId);  // 事件ID
            Config_AddAlarmPolicyEvent(pstAPolicyNode,uiKjIoTEventId);

            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hEventItem,(_UC*)"SceneID"),(_INT*)&uiSceneId);  // 场景ID
            Config_AddAlarmPolicyOutputScene(pstAPolicyNode,uiKjIoTEventId,uiSceneId);
            
            hActionArry = Adpt_Json_GetObjectItem(hEventItem, (_UC*)"Action");
            iActionArrySize = Adpt_Json_GetArraySize(hActionArry);

            iSetLampFlag = 0;
            for (j = 0 ; j < iActionArrySize; j++)
            {
                hActionItem = Adpt_Json_GetArrayItem(hActionArry,j);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hActionItem,(_UC*)"AIIoTType"),(_INT*)&uiOutIotType);  // AIIoT类型
                Adpt_Json_GetString(Adpt_Json_GetObjectItem(hActionItem,(_UC*)"AIIoTID"),&pucStrTmp);   // 设备ID
                MOS_SSCANF(pucStrTmp, "%llu",&uiOutIotId);
                if (uiOutIotType == EN_ZJ_AIIOT_TYPE_INNER_LAMP)
                {
                    iSetLampFlag = 1;
                }
                hPropObj = Adpt_Json_GetObjectItem(hActionItem,(_UC*)"OutPut"); // 具体见AIIoT类型事件、属性、输出定义
                pucStrTmp = Adpt_Json_Print(hPropObj);
// #ifdef DX_DOORBELL
#if 1//开启，通知回调门铃的铃声控制/选择
                if ( (uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_DOORBELL) && (uiOutIotType == EN_ZJ_AIIOT_TYPE_BUZZER))
                {
                    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_BUZZER);
                    if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
                    {
                        pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_BUZZER,uiOutIotId,pucStrTmp,MOS_NULL);
                    }
                }

                // 移动、人形pushflag回调
                if (ZJ_GetFuncTable()->pfunSetEventPushFlag != MOS_NULL)
                {
                    if ((uiOutIotType == EN_ZJ_AIIOT_TYPE_EVENT) && (uiKjIoTEventId == EN_ZJ_MOTION_EVENT_MOTION))
                    {
                        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPropObj,(_UC*)"PushFlag"),(_INT*)&iMothionPushFlag);
                    }
                    else if ((uiOutIotType == EN_ZJ_AIIOT_TYPE_EVENT) && (uiKjIoTEventId == EN_ZJ_MOTION_EVENT_HUMAN))
                    {
                        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPropObj,(_UC*)"PushFlag"),(_INT*)&iHumanPushFlag);
                    }
                }

                Config_AddAlarmPolicyOutput(pstAPolicyNode,uiKjIoTEventId,uiOutIotType,uiOutIotId,pucStrTmp);    
#endif
                MOS_FREE(pucStrTmp);
            }
            // 自动模式下，非motion策略，添加白光灯联动output
            // if (Config_GetCamaraMng()->uiCurIRWorkMode == EN_ZJ_IRMODE_AUTO && pstIotDevNode != MOS_NULL && iSetLampFlag == 0 && uiKjIoTType != EN_ZJ_AIIOT_TYPE_MOTION)
            // {
            //     Config_AddAlarmPolicyOutput(pstAPolicyNode,uiKjIoTEventId,EN_ZJ_AIIOT_TYPE_INNER_LAMP,0,(_UC*)"{\"CtrlType\":\"1\",\"Duration\":\"30\",\"Flicker\":\"0\"}");
            // }
        }
        if (ZJ_GetFuncTable()->pfunSetEventPushFlag)
        {
            ZJ_GetFuncTable()->pfunSetEventPushFlag(iMothionPushFlag, iHumanPushFlag);
        }
        else
        {
            // MOS_PRINTF("pfunSetEventPushFlag is null\n");
        }
        Config_AlarmPolicyEventEndSync(pstAPolicyNode);
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"3438 SetCmd(%u) is wrong", uiSetCmd);
        iRet = MOS_ERR;
    }

    if (iRet == MOS_OK)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set AlarmPolicy %u setCmd %u, OpenFlag %u, Week %u,time [%u-%u], iRet: %d",
            uiSeqId, uiPolicyId,uiSetCmd, uiOpenFlag, uiWeekFlag, uiStartTime, uiEndTime, iRet);
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunSetProp error reqid %u set AlarmPolicy %u setCmd %u, OpenFlag %u, Week %u,time [%u-%u], iRet: %d",
            uiSeqId, uiPolicyId,uiSetCmd, uiOpenFlag, uiWeekFlag, uiStartTime, uiEndTime, iRet);
    }
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_ALARM_POLICY_RSP,uiSeqId,iRet,&stMsgFromTo);
}

// InAIIoT模块开关配置 3430
_INT MsgMng_RecvCtrlKjIoTMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiKjIoTType      = 0;
    _LLID lluKjIoTId     = 0;
    _UI uiCtrlFlag       = 0;
    _INT iOpenFlag       = 0;
    _UC *pucStrTmp       = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrNode = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
   
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);   // AIIoT类型
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTID"),&pucStrTmp);                 // 设备ID,一般0
    MOS_SSCANF(pucStrTmp, "%llu",&lluKjIoTId);

    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),(_INT*)&iOpenFlag) == ITRD_OK) // 模块是否开启 文档是CtrlType
    {
        Config_SetInIotOpenFlag(uiKjIoTType,lluKjIoTId,iOpenFlag);
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CTRLKJIOT_RSP,uiSeqId,0,&stMsgFromTo);
#if 0
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"OutPut"),&pucStrTmp);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv ctrl KjIot [%u %llu] msg, OutPut %s",uiSeqId,uiKjIoTType,lluKjIoTId,pucStrTmp);
    
    if(uiKjIoTType >= EN_ZJ_AIIOT_TYPE_MOTION)
    {
        pstDevCtrNode = KjIoT_FindDevContrlNode(uiKjIoTType);
        if(pstDevCtrNode && pstDevCtrNode->pFunContrlDev)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv ctrl KjIot [%u %llu] msg, OutPut %s",uiSeqId,uiKjIoTType,lluKjIoTId,pucStrTmp);
    
            pstDevCtrNode->pFunContrlDev(uiKjIoTType,lluKjIoTId,pucStrTmp,MOS_NULL);
        }
        return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CTRLKJIOT_RSP,uiSeqId,0,&stMsgFromTo);
    }
    else if(MOS_STRLEN(pucStrTmp) > 0)
    {
        ST_RF_CMDRSPINFO stCmdRspInfo;
        JSON_HANDLE hParam = Adpt_Json_Parse(pucStrTmp);

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hParam,"CtrlType"),&uiCtrlFlag);
        Adpt_Json_Delete(hParam);

        stCmdRspInfo.ucMsgId   = EN_OGCT_PLATCMD_CTRLKJIOT;
        stCmdRspInfo.ucMsgType = EN_OGCT_PLATCMD_CTRLKJIOT_RSP;
        stCmdRspInfo.uiSeqId   = uiSeqId;
        MOS_STRNCPY(stCmdRspInfo.aucPeerId, pucPeerId,sizeof(stCmdRspInfo.aucPeerId));
        MOS_MEMCPY(&stCmdRspInfo.stCmdSrcInf, &stMsgFromTo, sizeof(ST_FROM_TO_MSG));
        return Rf_ContrlRdDevice(uiKjIoTType,lluKjIoTId,uiCtrlFlag,&stCmdRspInfo);
    }
#endif
    return MOS_OK;
}

// InAIIoT模块属性配置 3432
_INT MsgMng_RecvSetInIotPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiKjIoTType      = 0;
    _LLID lluKjIoTId     = 0;
    _INT iOpenFlag       = 0;
    _UI uiCtrlFlag       = 0;
    _UI uiDuration       = 0;
    _UC *pucStrTmp       = MOS_NULL;
    _UC *pucpProp        = MOS_NULL;
    _UC *pucTmpProp      = MOS_NULL;
    JSON_HANDLE hPropObj = MOS_NULL;
    JSON_HANDLE hTmpPropObj = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);   // AIIoT类型
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTID"),&pucStrTmp);                 // 设备ID
    MOS_SSCANF(pucStrTmp, "%llu",&lluKjIoTId);
    
    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),(_INT*)&iOpenFlag) == ITRD_OK)    // 模块是否开启
    {
        Config_SetInIotOpenFlag(uiKjIoTType,lluKjIoTId,iOpenFlag);
    }

    hPropObj = Adpt_Json_GetObjectItem(hBody,(_UC*)"Prop"); // 根据不同的AIIoT类型配置不同的属性
    if(hPropObj != MOS_NULL)
    {
        if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_CLOUDRECORD)
        {
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPropObj,(_UC*)"Duration"),(_INT*)&uiDuration);
            pucTmpProp = Config_GetInIotProp(uiKjIoTType,lluKjIoTId);
            if(pucTmpProp)
            {
                hTmpPropObj = Adpt_Json_Parse(pucTmpProp);
                Adpt_Json_DeleteItemFromObject(hTmpPropObj, (_UC*)"Duration");
                Adpt_Json_AddItemToObject(hTmpPropObj, (_UC*)"Duration", Adpt_Json_CreateStrWithNum(uiDuration));
                pucpProp = Adpt_Json_Print(hTmpPropObj);
                Adpt_Json_Delete(hTmpPropObj);
            }
        }
        else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_BUZZER)
        {
            pucpProp = Adpt_Json_Print(hPropObj);

            ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
            pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiKjIoTType);
            Config_SetAlarmPolicyTime(pstAPolicyNode, 1, 0X7F, 0, 86400);
            Config_SetAlarmPolicyProp(pstAPolicyNode,(_UC*)pucpProp);
            
            pstDevCtrlNode = KjIoT_FindDevContrlNode(uiKjIoTType);
            if(pstDevCtrlNode && pstDevCtrlNode->pfunSetProp)
            {
                pstDevCtrlNode->pfunSetProp(uiKjIoTType,lluKjIoTId,pucpProp);
            }
        }
        else
        {
            // 存在新人脸，则删除IOT 1000属性Face字段（非必须，SDK上报无Face字段，则平台不会下发Face字段）
            if (EN_ZJ_AIIOT_TYPE_MOTION == uiKjIoTType)
            {
                if (1 == Config_GetNewFaceAbility())
                {
                    Adpt_Json_DeleteItemFromObject(hPropObj, (_UC *)"Face");
                }
            }

            pucpProp = Adpt_Json_Print(hPropObj);
        }

        Config_SetInIotProp(uiKjIoTType,lluKjIoTId,pucpProp);
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set Iot [%u %llu] Prop %s",uiSeqId,uiKjIoTType,lluKjIoTId, pucpProp);
        Adpt_Json_DePrint(pucpProp);
        pucpProp = MOS_NULL;
    }

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"OutPut"),&pucStrTmp);  // 根据不同的AIIoT类型配置不同的OUTPUT

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv ctrl KjIot [%u %llu] msg, OutPut %s",uiSeqId,uiKjIoTType,lluKjIoTId,pucStrTmp);
    
    if(uiKjIoTType >= EN_ZJ_AIIOT_TYPE_MOTION)
    {
        pstDevCtrlNode = KjIoT_FindDevContrlNode(uiKjIoTType);
        if(pstDevCtrlNode && pstDevCtrlNode->pFunContrlDev)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv ctrl KjIot [%u %llu] msg, OutPut %s",uiSeqId,uiKjIoTType,lluKjIoTId,pucStrTmp);
    
            pstDevCtrlNode->pFunContrlDev(uiKjIoTType,lluKjIoTId,pucStrTmp,MOS_NULL);
        }
        // return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CTRLKJIOT_RSP,uiSeqId,0,&stMsgFromTo);
    }
    else if(MOS_STRLEN(pucStrTmp) > 0)
    {
        ST_RF_CMDRSPINFO stCmdRspInfo;
        JSON_HANDLE hParam = Adpt_Json_Parse(pucStrTmp);

        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hParam,"CtrlType"),&uiCtrlFlag); // 模块是否开启
        Adpt_Json_Delete(hParam);

        stCmdRspInfo.ucMsgId   = EN_OGCT_PLATCMD_CTRLKJIOT;
        stCmdRspInfo.ucMsgType = EN_OGCT_PLATCMD_CTRLKJIOT_RSP;
        stCmdRspInfo.uiSeqId   = uiSeqId;
        MOS_STRNCPY(stCmdRspInfo.aucPeerId, pucPeerId,sizeof(stCmdRspInfo.aucPeerId));
        MOS_MEMCPY(&stCmdRspInfo.stCmdSrcInf, &stMsgFromTo, sizeof(ST_FROM_TO_MSG));
        return Rf_ContrlRdDevice(uiKjIoTType,lluKjIoTId,uiCtrlFlag,&stCmdRspInfo);
    }
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETINIOTPROP_RSP,uiSeqId,MOS_OK,&stMsgFromTo);
}

// PTZ预置位自检 3448
_INT MsgMng_RecvSetPtzCheckMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set ptz self check msg from peer %s ",uiSeqId,pucPeerId);
    return Cmdhdl_SetCommonMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_PTZCHECK,&stMsgFromTo);
}

// 设置设备休眠等待时长 344A
_INT MsgMng_RecvSetAwakeTimeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iAwakeInterval  = 0;
    _INT iStatus         = MOS_ERR;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    // 休眠设备唤醒后，等待此时长后，继续休眠。即唤醒后工作时长。
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AwakeInterval"),&iAwakeInterval);   // 休眠等待时间
#if 1
    iStatus = Config_SetDevAwakeInterval(iAwakeInterval);
    Config_SetSLeepMonotorForceNotify();//更新休眠值，强制通知厂商
#else
    if(ZJ_GetFuncTable()->pfuncStartSleep)
    {
        iStatus = ZJ_GetFuncTable()->pfuncStartSleep(iAwakeInterval);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETAWAKETIME);
            MOS_SPRINTF(pucErrorString, "Device pfuncStartSleep(iAwakeInterval:%d) err", iAwakeInterval);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        } 
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfuncStartSleep is NULL!");
    }
#endif
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set dev awaketime %d from %s ",uiSeqId,iAwakeInterval,pucPeerId);
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETAWAKETIME_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 3452
_INT MsgcCt_RecvAddIotToHubMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiKjIoTType      = 0;
    _LLID lluKjIoTId     = 0;
    _INT iStatus         = 0;
    _UI uiOpenFlag       = 0;
    _UC *pucProp         = MOS_NULL; 
    _UC *pucStrTmp       = MOS_NULL;
    JSON_HANDLE hPropObj = MOS_NULL;
    ST_RF_CMDRSPINFO stRfCmdRspInf;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTID"),&pucStrTmp);
    MOS_SSCANF(pucStrTmp, "%llu",&lluKjIoTId);
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"IoTName"),&pucStrTmp);
    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),(_INT*)&uiOpenFlag) != ITRD_OK)
    {
        uiOpenFlag = 1;
    }
    
    hPropObj = Adpt_Json_GetObjectItem(hBody,(_UC*)"Prop");
    
    pucProp  = Adpt_Json_Print(hPropObj);
    iStatus = Config_AddIotToHubEx(uiKjIoTType,lluKjIoTId,pucStrTmp,uiOpenFlag,pucProp);
    Adpt_Json_DePrint(pucProp);
    
    stRfCmdRspInf.ucMsgId   = EN_OGCT_PLATCMD_ADDDEVTOHUB_RSP;
    stRfCmdRspInf.ucMsgType = EN_OGCT_METHOD_CMDMSG;
    stRfCmdRspInf.uiSeqId   = uiSeqId;
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stRfCmdRspInf.stCmdSrcInf);
    MOS_STRNCPY(stRfCmdRspInf.aucPeerId, pucPeerId, sizeof(stRfCmdRspInf.aucPeerId));

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u add KjIot[%u %llu] Name %s openFlag %u To Hub",uiSeqId, uiKjIoTType, lluKjIoTId, pucStrTmp, uiOpenFlag);
    return Rf_AddRdDevice(uiKjIoTType,lluKjIoTId,&stRfCmdRspInf);
}

// 3456
_INT MsgMng_RecvSetHubIotPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    
    _UI uiKjIoTType      = 0;
    _LLID lluKjIoTId     = 0;
    _UI uiOpenFlag       = 0;
    _UC *pucStrTmp       = MOS_NULL;
    JSON_HANDLE hPropObj = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
       return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTID"),&pucStrTmp);
    MOS_SSCANF(pucStrTmp, "%llu",&lluKjIoTId);
    
    if(Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"IoTName"),&pucStrTmp) == ITRD_OK)
    {
        Config_SetIotNameInHub(uiKjIoTType,lluKjIoTId,pucStrTmp);
    }
    if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"OpenFlag"),(_INT*)&uiOpenFlag) == ITRD_OK)
    {
        Config_SetIotOpenFlagInHub(uiKjIoTType,lluKjIoTId,uiOpenFlag);
    }
    hPropObj = Adpt_Json_GetObjectItem(hBody,(_UC*)"Prop");
    if(hPropObj != MOS_NULL)
    {
        pucStrTmp = Adpt_Json_Print(hPropObj);
        Config_SetIotPropInHub(uiKjIoTType,lluKjIoTId,pucStrTmp);
        Adpt_Json_DePrint(pucStrTmp);
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv Set IotDev [%u %llu] Prop",uiSeqId,uiKjIoTType,lluKjIoTId);
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETHUBDEVPROP_RSP,uiSeqId,MOS_OK,&stMsgFromTo);
}

// 3458
_INT MsgMng_RecvDelHubIotMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiKjIoTType      = 0;
    _LLID lluKjIoTId     = 0;
    _UC *pucStrTmp       = MOS_NULL;
    ST_RF_CMDRSPINFO    stCmdRspInfo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY"); 
    if(hBody == MOS_NULL)
    {
       return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"AIIoTID"),&pucStrTmp);
    MOS_SSCANF(pucStrTmp, "%llu",&lluKjIoTId);
    
    stCmdRspInfo.ucMsgId   = EN_OGCT_PLATCMD_DELHUBDEV_RSP;
    stCmdRspInfo.ucMsgType = EN_OGCT_METHOD_CMDMSG;
    stCmdRspInfo.uiSeqId   = uiSeqId;
    MOS_STRNCPY(stCmdRspInfo.aucPeerId, pucPeerId,sizeof(stCmdRspInfo.aucPeerId));
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stCmdRspInfo.stCmdSrcInf);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u delete KjIot[%u %llu] From Hub",uiSeqId, uiKjIoTType,lluKjIoTId);
    return Rf_DeleteRdDevice(uiKjIoTType,lluKjIoTId,&stCmdRspInfo); 
}

// 345A
_INT MsgMng_RecvDelAllHubIotMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_RF_CMDRSPINFO stCmdRspInfo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    stCmdRspInfo.ucMsgId   = EN_OGCT_PLATCMD_DELALLHUBDEV_RSP;
    stCmdRspInfo.ucMsgType = EN_OGCT_METHOD_CMDMSG;
    stCmdRspInfo.uiSeqId   = uiSeqId;
    MOS_STRNCPY(stCmdRspInfo.aucPeerId, pucPeerId,sizeof(stCmdRspInfo.aucPeerId));
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stCmdRspInfo.stCmdSrcInf);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u delete all KjIots From Hub",uiSeqId);
    return Rf_DeletAllRdDevice(&stCmdRspInfo);
}

static _UC *Cmdhdl_BuildGetKjIoTStatusListRsp(_UI uiSeqId,_INT iStatus,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETNULL(pstMsgFromTo);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC aucBuff[64];
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hArray      = MOS_NULL;
    JSON_HANDLE hArrayItem  = MOS_NULL;
    JSON_HANDLE hBody       = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RFDEV_NODE *pstRfNode   = MOS_NULL;
    ST_CFG_INIOT_NODE *pstIniot = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    MOS_VSNPRINTF(aucBuff, 8, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETIOTSTATUSLIST_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucBuff));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    
    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,pstMsgFromTo);

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"IoTs",hArray);
    
    FOR_EACHDATA_INLIST(Rf_GetRdDeviceList(), pstRfNode, stIterator)
    {
        if(pstRfNode->uiUseFlag == 0)
        {
            continue;
        }
        hArrayItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArray,hArrayItem);
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstRfNode->uiDacType));
        MOS_VSNPRINTF(aucBuff, 64,(_UC*)"%llu",pstRfNode->lluDacId);
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Status",Adpt_Json_CreateStrWithNum(pstRfNode->ucCurStatus));
    }

    FOR_EACHDATA_INLIST(&Config_GetInIotMng()->stInIotList, pstIniot, stIterator)
    {
        if(pstIniot->uiUseFlag == 0 || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_DOORBELL
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_PIR 
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_PTZ
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_BUZZER
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_CAMERA
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_EVENT
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_DNSET
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_FORCEREMOVE
            || pstIniot->uiKjIoTType == EN_ZJ_AIIOT_TYPE_STAY)
        {
            continue;
        }
        hArrayItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArray,hArrayItem);
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstIniot->uiKjIoTType));
        MOS_VSNPRINTF(aucBuff, 64,(_UC*)"%llu",pstIniot->lluKjIotId);
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Status",Adpt_Json_CreateStrWithNum(pstIniot->uiWorkStatus));
    }
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pucStrTmp;
}

// 3454
_INT MsgMng_RecvGetIotsStatusMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus      = MOS_OK;
    _UC *pucStrTmp    = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    pucStrTmp = Cmdhdl_BuildGetKjIoTStatusListRsp(uiSeqId,iStatus,&stMsgFromTo);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETIOTSTATUSLIST_RSP,
        pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u send Iot List Status rsp %s",uiSeqId,pucStrTmp);
    
    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;   
}

// 设置红外夜视模式 342E
_INT MsgMng_RecvSetIrModeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiIrWorkMode = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 0.自动模式，1.红外模式，2.全彩模式
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"IRRedMode"),(_INT*)&uiIrWorkMode);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set irmode %d from peer %s",uiSeqId,uiIrWorkMode,pucPeerId);
    
    return Cmdhdl_RSetIrWorkModeMsg(pucPeerId,uiSeqId,&stMsgFromTo,uiIrWorkMode);
}

// 设置连接WIFI 3470
_INT MsgMng_RecvSetWifiMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC *pucSsid    = MOS_NULL;
    _UC *pucPswd    = MOS_NULL;
    _INT iSecurity  = 0; 
    _INT iStatus    = MOS_ERR;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"Security"),&iSecurity);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,    (_UC*)"SSID"),&pucSsid);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,    (_UC*)"Password"),&pucPswd); 

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set Wifi Parm,security %d, ssid %s, password %s",uiSeqId, iSecurity, pucSsid, pucPswd);

    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETWIFI_RSP,uiSeqId,0,&stMsgFromTo);

    if(ZJ_GetFuncTable()->pfuncSetWifi)
    {
        iStatus = ZJ_GetFuncTable()->pfuncSetWifi(EN_ZJ_NETWORK_TYPE_WIFI,(char*)pucSsid,(char*)pucPswd,iSecurity);
        if(iStatus != MOS_OK)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWIFI);
            MOS_SPRINTF(pucErrorString, "Device pfuncSetWifi(aucSSID:%s, aucPasswd:%s) err", 
                                                    (char*)pucSsid,(char*)pucPswd,iSecurity);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, pucErrorString, 1);
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        }
        else
        {
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_SUCCESS, COUNT_VALUE_SUCCESS);
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfuncSetWifi is NULL!");
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
    }
    return MOS_OK;
}

// 获取WIFI列表 3474
_INT MsgMng_RecvGetWifiListMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv get wifilist msg from peer %s",uiSeqId,pucPeerId);
    
    return Cmdhdl_SetCommonMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETWIFILIST,&stMsgFromTo);
}

// 获取WiFi信息 3472
_INT MsgMng_RecvGetCurNetInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv get cur netInfo msg",uiSeqId);
    
    return Cmdhdl_SetCommonMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETCURNATINF,&stMsgFromTo);
}

// 清除设备缓存 343A
_INT MsgMng_RecvSetCleanServAddrMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Http_ClearServersAddr();

    MsgMng_CleanCmdServerAddr();

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv clean server addr msg",uiSeqId);
    
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CLEAN_SERVADDR_RSP,uiSeqId,MOS_OK,&stMsgFromTo);
}

// 设置设备名称 3466
_INT MsgMng_RecvSetDevNameMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC *pucStrTmp = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
        
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"DevName"),&pucStrTmp); // 设备名称
    
    Config_SetDeviceName(pucStrTmp);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set devName %s",uiSeqId,pucStrTmp);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETDEVNAME_RSP,uiSeqId,MOS_OK,&stMsgFromTo);
}

// 门铃/IPC智能播报 播放警报音  让设备播放警报音指令 3468
_INT MsgMng_RecvPlayAlarmFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    
    _INT iLoopCnt     = 0;
    _UC *pucSoundName = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"LoopCnt"),&iLoopCnt);       // 播放次数
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"FileName"),&pucSoundName);    // 声音文件名称
    

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u play alarm sound for doorbell",uiSeqId);
    
    return Cmdhdl_PlayAlarmAudioMsg(pucPeerId,uiSeqId,&stMsgFromTo,iLoopCnt,pucSoundName);
}

// 强拆告警开关 346A
_INT MsgMng_RecvSwitchDismantableAlarmMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iOpenFlag = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Status"),(_INT*)&iOpenFlag);    // 强拆告警开关

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set Force Broken Flag %u",uiSeqId,iOpenFlag);
    return Cmdhdl_SwitchDismantableAlarmMsg(pucPeerId,uiSeqId,&stMsgFromTo,iOpenFlag);
}

// 逗留报警 346C
_INT MsgMng_RecvSetWaitAlarmMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iOpenFlag = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Status"),(_INT*)&iOpenFlag);    // 逗留告警开关

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set stay alarm Flag %u",uiSeqId,iOpenFlag);
    
    return Cmdhdl_SetWaitAlarmMsg(pucPeerId,uiSeqId,&stMsgFromTo,iOpenFlag);
}

// 解释wdr信令的接送数据 346E
_INT MsgMng_RecvSetCamWdrMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iOpenFlag = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    // 获取信令的from to信息
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // WDR开关  0.关闭，1开启
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Status"),(_INT*)&iOpenFlag);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set WDR Flag %u",uiSeqId,iOpenFlag); 
    
    // 设置wdr 携带信令的from to信息
    return Cmdhdl_SetCamWdrMsg(pucPeerId,uiSeqId,&stMsgFromTo,iOpenFlag);
}

// 347A
_INT MsgMng_RecvGetRecordCalenderMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC aucMethod[8];
    _UC *pStrTmp        = MOS_NULL;
    _UC *pucDay         = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hArray  = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RDSTG_DATENODE *pstDataNode = MOS_NULL;
    ST_MOS_LIST    *pstDateList = MOS_NULL;
 
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    pstDateList = RdStg_GetDateList(0);

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Date"),&pucDay);
    
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETRECORDCALENDER_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,&stMsgFromTo);
   
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Dates",hArray);
    FOR_EACHDATA_INLIST(pstDateList, pstDataNode, stIterator)
    {
        if(MOS_STRCMP(pstDataNode->stDate.aucDate,pucDay) >= 0)
        {
            Adpt_Json_AddItemToArray(hArray,Adpt_Json_CreateString(pstDataNode->stDate.aucDate));
        }
        MOS_LIST_RMVNODE(pstDateList, pstDataNode);
        MOS_FREE(pstDataNode);
    }
    MOS_FREE(pstDateList);
    
    pStrTmp = Adpt_Json_Print(hRoot);
    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETRECORDCALENDER_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d rsp get Record Calender %s",uiSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;

}

// 查询卡录像文件列表 347C
_INT MsgMng_RecvGetRecordAxisMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiDuration = 0;
    _UC aucBuff[32];
    _INT iPageSize   = 0;
    _UC *pucFromTime = MOS_NULL;
    _UC *pStrTmp     = MOS_NULL;
    JSON_HANDLE hArrayItem = MOS_NULL;
    JSON_HANDLE hArray  = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_MOS_SYS_TIME stSysTime ;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST *pstAxisList = MOS_NULL;
    ST_RDSTG_FILEDESNODE *pstFileDesNode = MOS_NULL;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Date"),&pucFromTime);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PageSize"),&iPageSize);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucBuff, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETRECORDLIST_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucBuff));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,&stMsgFromTo);
   
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    // 通过page查询卡录像文件列表 通过信令调用 (卡录像查询入口)
    pstAxisList = RdStg_GetFileListByPage(0,pucFromTime,iPageSize);
    if (pstAxisList == MOS_NULL)
    {
        MOS_LOG_ERR(P2P_STRLOG,"pstAxisList == MOS_NULL");
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Size",Adpt_Json_CreateStrWithNum(0));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Size",Adpt_Json_CreateStrWithNum(MOS_LIST_GETCOUNT(pstAxisList)));
    }

    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Files",hArray);

    if (pstAxisList)
    {
        FOR_EACHDATA_INLIST_CONVERSE(pstAxisList, pstFileDesNode, stIterator)
        {
            hArrayItem = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hArray, hArrayItem);
            
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"FileID",Adpt_Json_CreateStrWithNum(pstFileDesNode->stFileDes.uiFileSeq));

            Mos_TimetoSysTime(&pstFileDesNode->stFileDes.cStartTime,&stSysTime); 
            MOS_SPRINTF(aucBuff, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"SrcTime",Adpt_Json_CreateString(aucBuff));

            if(pstFileDesNode->stFileDes.cStopTime > pstFileDesNode->stFileDes.cStartTime)
            {
                uiDuration = (_UI)(pstFileDesNode->stFileDes.cStopTime- pstFileDesNode->stFileDes.cStartTime);
                if(uiDuration == 0)
                {
                    uiDuration = 1;
                }
                Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDuration));
            }
            else
            {
                uiDuration = (pstFileDesNode->stFileDes.uiEndTimeStamp - pstFileDesNode->stFileDes.uiStartTimeStamp)/1000;
                if(uiDuration == 0)
                {
                    uiDuration = 1;
                }
                Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDuration));
            }
            MOS_LIST_RMVNODE(pstAxisList, pstFileDesNode);
            MOS_FREE(pstFileDesNode);
        }
    }

    pStrTmp = Adpt_Json_Print(hRoot);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETRECORDLIST_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d get MediaAxis rsp %s",uiSeqId,pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    MOS_FREE(pstAxisList);
    return MOS_OK;
}

// 347E
_INT MsgMng_RecvGetJpgListMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC aucBuff[32];
    _INT iCamId      = 0;
    _INT iPageSize   = 0;
    _INT iSnapType   = 0;
    _UC *pucFromTime = MOS_NULL;
    _UC *pStrTmp     = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_MOS_SYS_TIME stSysTime;
    JSON_HANDLE hArrayItem = MOS_NULL;
    JSON_HANDLE hArray  = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST *pstJpgList = MOS_NULL;
    ST_JPGFILE_NODE *pstJpgNode = MOS_NULL;

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Date"),&pucFromTime);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PageSize"), &iPageSize);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"), &iCamId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SnapType"), &iSnapType);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucBuff, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETJPGLIST_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucBuff));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,&stMsgFromTo);
   
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    pstJpgList = Snap_QueryJpgListByTime(iCamId,0XFF,iSnapType,pucFromTime,iPageSize);
    
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Size",Adpt_Json_CreateStrWithNum(MOS_LIST_GETCOUNT(pstJpgList)));

    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Files",hArray);

    FOR_EACHDATA_INLIST(pstJpgList, pstJpgNode, stIterator)
    {
        hArrayItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArray, hArrayItem);
        
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"PicType",Adpt_Json_CreateStrWithNum(pstJpgNode->stJpgInf.uiJpgType));

        Mos_TimetoSysTime(&pstJpgNode->stJpgInf.cSnapTime, &stSysTime);

        MOS_SPRINTF(aucBuff,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
            stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
        
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"SrcTime",Adpt_Json_CreateString(aucBuff));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Name",Adpt_Json_CreateString(pstJpgNode->stJpgInf.aucFileName));
        MOS_LIST_RMVNODE(pstJpgList, pstJpgNode);
        MOS_FREE(pstJpgNode);
    }
    pStrTmp = Adpt_Json_Print(hRoot);
    
    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETJPGLIST_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d Rsp getJpgFileList body %s",uiSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    MOS_FREE(pstJpgList);
    return MOS_OK;
}

// 3480
_INT MsgMng_RecvGetJpgCalenderMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC aucMethod[8];
    _INT iCamId         = 0;
    _UC *pStrTmp        = MOS_NULL;
    _UC *pucDay         = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hArray  = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_SNAP_DATENODE *pstDataNode = MOS_NULL; 
    ST_MOS_LIST *pstDateList = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Date"),&pucDay);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&iCamId);

    if(MOS_STRLEN(pucDay) == 0)
    {
        pucDay = (_UC*)"2000-01-01";
    }
    pstDateList = Snap_QueryJpgCanlender(iCamId,pucDay);
    
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETJPGCANLENDER_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,&stMsgFromTo);
   
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Dates",hArray);
    FOR_EACHDATA_INLIST(pstDateList, pstDataNode, stIterator)
    {
        Adpt_Json_AddItemToArray(hArray,Adpt_Json_CreateString(pstDataNode->stDate.aucDate));
        MOS_LIST_RMVNODE(pstDateList, pstDataNode);
        MOS_FREE(pstDataNode);
    }
    pStrTmp = Adpt_Json_Print(hRoot);
    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETJPGCANLENDER_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d rsp get Jpg Calender body %s",uiSeqId,pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    MOS_FREE(pstDateList);
    return MOS_OK; 
}

// 3476
_INT MsgMng_RecvGetEventCalenderMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC aucMethod[8];
    _UC *pStrTmp        = MOS_NULL;
    _UC *pucDay         = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hArray  = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_EVENT_DATENODE *pstDataNode = MOS_NULL; 
    ST_MOS_LIST *pstDateList = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Date"),&pucDay);
    if(MOS_STRLEN(pucDay) == 0)
    {
        pucDay = (_UC*)"2000-01-01";
    }
    pstDateList = Event_QueryCanlender(pucDay);
    
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETEVENTCALENDER_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,&stMsgFromTo);
   
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Dates",hArray);
    FOR_EACHDATA_INLIST(pstDateList, pstDataNode, stIterator)
    {
        Adpt_Json_AddItemToArray(hArray,Adpt_Json_CreateString(pstDataNode->stDate.aucDate));
        MOS_LIST_RMVNODE(pstDateList, pstDataNode);
        MOS_FREE(pstDataNode);
    }
    pStrTmp = Adpt_Json_Print(hRoot);
    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETEVENTCALENDER_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d rsp get Event Calender body %s",uiSeqId,pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    MOS_FREE(pstDateList);
    return MOS_OK; 
}

// 3478
_INT MsgMng_RecvGetEventAxisMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC aucBuff[64];
    _INT iPageSize   = 0;
    _UC *pucFromTime = MOS_NULL;
    _UC *pStrTmp     = MOS_NULL;
    ST_MOS_SYS_TIME stSysTime;
    JSON_HANDLE hArrayItem = MOS_NULL;
    JSON_HANDLE hArray  = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST *pstEventList = MOS_NULL;
    ST_EVENT_NODE *pstEventNode = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Date"),&pucFromTime);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PageSize"), &iPageSize);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucBuff, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETEVENTLIST_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucBuff));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,&stMsgFromTo);
   
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    
    pstEventList = Event_QueryInfoByTime(pucFromTime,iPageSize);
    
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Size",Adpt_Json_CreateStrWithNum(MOS_LIST_GETCOUNT(pstEventList)));
    
    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Events",hArray);

    FOR_EACHDATA_INLIST(pstEventList, pstEventNode, stIterator)
    {
        hArrayItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArray, hArrayItem);

        Mos_TimetoSysTime(&pstEventNode->stEventInf.cEventTime,&stSysTime);
        
        MOS_SPRINTF(aucBuff,"%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
            stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
            stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
        
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Time",Adpt_Json_CreateString(aucBuff));

        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTType",Adpt_Json_CreateStrWithNum(pstEventNode->stEventInf.uiKjIoTType));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"EventID",Adpt_Json_CreateStrWithNum(pstEventNode->stEventInf.uiKjIoTEventId));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Eid",Adpt_Json_CreateString(pstEventNode->stEventInf.aucEventName));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(pstEventNode->stEventInf.uiDuration));
        
        MOS_SPRINTF(aucBuff,"%llu",pstEventNode->stEventInf.uillKjIoTId);
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"AIIoTID",Adpt_Json_CreateString(aucBuff));

        MOS_LIST_RMVNODE(pstEventList, pstEventNode);
        MOS_FREE(pstEventNode);
    }
    pStrTmp = Adpt_Json_Print(hRoot);
    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETEVENTLIST_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d rsp get Event List body %s",uiSeqId,pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    MOS_FREE(pstEventList);
    return MOS_OK;
}

// 3482
_INT MsgMng_RecvAddDevByAPMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC *pucBindCode = MOS_NULL;
    _UC *pucGroupId  = MOS_NULL;
    _UC *pucSSID     = MOS_NULL;
    _UC *pucPasswd   = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
   
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"BindCode"),&pucBindCode);
    
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"GID"),&pucGroupId);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SSID"),&pucSSID);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Password"),&pucPasswd);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d recv BindCode %s, Gid %s, ssid %s, pswd %s",uiSeqId,pucBindCode,pucGroupId,pucSSID,pucPasswd);

    return Cmdhdl_AddDevByAPMsg(pucPeerId,uiSeqId,&stMsgFromTo,pucBindCode,pucGroupId,pucSSID,pucPasswd); 
}

// APP 通知开始升级 0x3484
_INT MsgMng_RecvStartUpgradeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    CloudStg_UploadLogEx2(RDSTG_LOGSTR_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_OTA_RT_RECV_START_UPGRDE, "recv start upgrade 0x3484" ,MOS_NULL, 1);
    _INT iStatus = 0;
    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    // 通知设备去升级
    if(Ota_NoticeDevToUpgrade() != MOS_OK)
    {
        iStatus = 1;
        // 上报升级状态和进度
        Ota_PubUpgradePrecentage(0, EN_CFG_OTA_UPGRADE_NONEED);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_OTA_RT_NOTIFY_DEVICE_COVER, "notify device upgreade fail" , 1); 
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d recv upgrade msg, needFlag %d",uiSeqId,iStatus);
    
    // 开始升级回复 0x3485
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_STARTUPGRADE_RSP,uiSeqId,iStatus,&stMsgFromTo);

}

// APP 通知停止升级 0x3486
_INT MsgMng_RecvStopUpgradeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    CloudStg_UploadLogEx2(RDSTG_LOGSTR_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_OTA_RT_RECV_STOP_UPGRDE, "recv stop upgrade 0x3486" ,MOS_NULL, 1);

    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    Ota_StopUpgrade();

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d recv stop upgrade msg",uiSeqId);
    
    // 停止升级 0x3487
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_STOPUPGRADE_RSP,uiSeqId,0,&stMsgFromTo);
}

// 3450
_INT MsgMng_RecvSwitchLensMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iLenId = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"LenID"),&iLenId);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d recv switch lenid %u msg",uiSeqId,iLenId);
    
    return Cmdhdl_SwitchCamLensMsg(pucPeerId,uiSeqId,&stMsgFromTo,iLenId); 
}

// 3494
_INT MsgMng_RecvSetSceneInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiSceneId = 0;
    _UI uiSetCmd   = 0;
    _UI i, uiArraySize = 0;
    _UI uiKjIoTType;
    _LLID lluKjIotId = 0 ;
    _UC *pStrTmp   = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hPropObj = MOS_NULL;
    JSON_HANDLE hOutputArray = MOS_NULL;
    JSON_HANDLE hOutoutItem  = MOS_NULL;
    ST_CFG_SCENEPOLICY_NODE *pstPolicyNode = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SetCmd"),(_INT*)&uiSetCmd);//1-设置，2-删除
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SceneID"),(_INT*)&uiSceneId);

    Config_DeleteScenePolicy(uiSceneId);

    if(uiSetCmd == EN_MSG_SETCMD_TYPE_ADD_OR_SET)
    {
        pstPolicyNode = Config_FindOrCreatScenePolicy(uiSceneId);

        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SceneName"),&pStrTmp);
        Config_SetScenePolicyName(pstPolicyNode,pStrTmp); 

        hOutputArray = Adpt_Json_GetObjectItem(hBody,(_UC*)"Action");
        uiArraySize  = Adpt_Json_GetArraySize(hOutputArray);
        for(i = 0 ; i < uiArraySize; i++)
        {
            hOutoutItem = Adpt_Json_GetArrayItem(hOutputArray, i);

            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hOutoutItem,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hOutoutItem,(_UC*)"AIIoTID"),&pStrTmp);
            MOS_SSCANF(pStrTmp, "%llu",&lluKjIotId);
            hPropObj = Adpt_Json_GetObjectItem(hOutoutItem,(_UC*)"Output");
            pStrTmp = Adpt_Json_Print(hPropObj);
            Config_AddScenePolicyOutput(pstPolicyNode,uiKjIoTType,lluKjIotId,pStrTmp);
            Adpt_Json_DePrint(pStrTmp);
        }
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set ScenePolicy setCmd %u, sceneId %u",uiSeqId, uiSetCmd, uiSceneId); 
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETSCENEPOLICY_RSP,uiSeqId,0,&stMsgFromTo);
}

// 3490
_INT MsgMng_RecvSetBellQuckReplayMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    return MOS_OK;
}

// 选择门铃声(门铃类) 3492
_INT MsgMng_RecvSwitchBellSoundMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

     return MOS_OK;
}

// 349C
_INT MsgMng_RecvUpLoadLogFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iErrType  = 0;
    _UC *pucErrDes = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"ErrDesc"),&pucErrDes);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ErrType"), &iErrType);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d recv upload log msg,Desc %s errType %d",uiSeqId,pucErrDes,iErrType);

    return Cmdhdl_SetUpLoadLogFileMsg(pucPeerId,uiSeqId,&stMsgFromTo,pucErrDes,iErrType); 
}

// 3460
_INT MsgMng_RecvSetLogFileLevelMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UI uiLogType  = 0;
    _UC *pucErrDes = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"LogType"), &uiLogType);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d recv set upload log file level msg, LogType %d",uiLogType);

    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETLOGFILELIVEL_RSP,uiSeqId,0,&stMsgFromTo);

    Mos_SetLogFileLevel(uiLogType);

    return MOS_OK;
}

// 3498
_INT MsgMng_RecvSetRelayModeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iOpenFlag = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Flag"), &iOpenFlag);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d set RelayMode open flag %d",uiSeqId,iOpenFlag);

    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_RELAY_MODE_RSP,uiSeqId,0,&stMsgFromTo);
 
    Http_SetPeerRelayMode(pucPeerId,iOpenFlag);
    return MOS_OK;
}

// 设置设备自动升级 349E
_INT MsgMng_RecvSetAutoUpgradeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiAutoFlag   =  0;
    _UI uiWeekDay    =  0; 
    _UI uiTime       =  0;
    _UC pucUrl[64]   = {0};
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETDEVAUTOUPDATE);
        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "CMD set autograde error body = NULL", 1);
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETDEVAUTOUPDATE);
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Flag"), (_INT*)&uiAutoFlag);
    if(uiAutoFlag == 1)
    {
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"WeekDay"),(_INT*)&uiWeekDay);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Time"), (_INT*)&uiTime);
    }
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %d set autoUpflag %u,weekDay %u, time %u",uiSeqId,uiAutoFlag, uiWeekDay, uiTime);

    Config_SetDevAutoUpgradeParam(uiAutoFlag,uiWeekDay,uiTime);

    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETDEVAUTOUPDATE_RSP,uiSeqId,0,&stMsgFromTo);
    return MOS_OK;
}

// 34A0
_INT MsgMng_RecvGetSoundListMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iSoundType = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"SoundType"),(_INT*)&iSoundType);

    return Cmdhdl_GetSoundListMsg(pucPeerId,uiSeqId,&stMsgFromTo,iSoundType); 
}

// 34A2
_INT MsgMng_RecvDelSoundFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC *pucFileName = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"FileName"),&pucFileName);
    return Cmdhdl_DeleteSoundFileMsg(pucPeerId,uiSeqId,&stMsgFromTo,pucFileName); 
}

// 快捷回复铃声指令(门铃类） 34A4
_INT MsgMng_RecvPlaySoundFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC *pucFileName = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    // 声音文件的名称，字符串
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"FileName"),&pucFileName);  // FIXME: FileName

    return Cmdhdl_PlaySoundFileMsg(pucPeerId,uiSeqId,&stMsgFromTo,pucFileName); 
}

// 34E0
_INT MsgMng_RecvDownSoundFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC *pucFileName = MOS_NULL;
    _UC *pucSoundUrl = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    // 声音文件的名称，字符串
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"FileName"),&pucFileName);  // FIXME: FileName
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"SoundUrl"),&pucSoundUrl);

    return Cmdhdl_DownSoundFileMsg(pucPeerId,uiSeqId,&stMsgFromTo,pucFileName,pucSoundUrl); 
}

// 34A6
_INT MsgMng_RecvAwakeRelayDevMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iValue = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CtrlType"),&iValue);
    
    return Cmdhdl_SetAwakeRelayDevMsg(pucPeerId,uiSeqId,&stMsgFromTo,iValue); 
}

// 34A8
_INT MsgMng_RecvLimitStreamMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iLimitFlag   = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CtrlType"),&iLimitFlag);
    
    Config_SetDevLimitStreamFlag(iLimitFlag);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set limit Stream Flag %u ",uiSeqId,iLimitFlag);
    
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_LIMITSTREAM_NTC_RSP,uiSeqId,0,&stMsgFromTo);
}

// 34B0
_INT MsgMng_RecvSetVolumeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iValue = 0;
    ST_FROM_TO_MSG stMsgFromTo;  
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Volume"),&iValue);
    return Cmdhdl_SetMicVolumeMsg(pucPeerId,uiSeqId,&stMsgFromTo,iValue); 
}

// 34B2
_INT MsgMng_RecvSetMaxSessionCntMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iMaxSessionCnt = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"MaxSessionCnt"),&iMaxSessionCnt);
    
    Config_SetMaxSessionCnt(iMaxSessionCnt);
    
    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETMAXSESSION_RSP,uiSeqId,MOS_OK,&stMsgFromTo);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u set max Session Cnt %d",uiSeqId,iMaxSessionCnt);
    return MOS_OK;

}

// 34B4
_INT MsgMng_RecvSetDefaultLenIdMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iDefaultLenId = 0;
    _INT iAutoFlag     = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    
    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"LenId"),&iDefaultLenId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AutoFlag"),&iAutoFlag);

    Config_SetDefaultLenId(iDefaultLenId, iAutoFlag);
    Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETDEFAULTLENID_RSP,uiSeqId,MOS_OK,&stMsgFromTo);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u recv set defaultLen autoFlag %d, lenId %d ",uiSeqId,iAutoFlag,iDefaultLenId);
    return MOS_OK;

}

static _UC *MsgMng_BuildGetSnapShotTimeRsp(_UI uiSeqId,_INT iStatus,_INT iTimeInSec,_INT iTimeInMs,_UI iTicket,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETNULL(pstMsgFromTo);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UC aucMethod[64];
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBodyObject = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    
    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,pstMsgFromTo);

    hBodyObject = Adpt_Json_CreateObject();
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETSNAPSHOTTIME_RSP);
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"TimeInSec",Adpt_Json_CreateStrWithNum(iTimeInSec));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"TimeInMs",Adpt_Json_CreateStrWithNum(iTimeInMs));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"Ticket",Adpt_Json_CreateStrWithNum(iTicket));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBodyObject);

    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pucStrTmp;
}

// 34B6
_INT MsgMng_RecvGetShotTimeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus    = MOS_ERR;
    _INT iTimeInSec = 0;
    _INT iTimeInMs  = 0;
    _INT iTicket    = 0;
    _UC *pucStrTmp  = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    if(ZJ_GetFuncTable()->pfunGetSnapShotTime)
    {
        iStatus = ZJ_GetFuncTable()->pfunGetSnapShotTime(&iTimeInSec,&iTimeInMs,&iTicket);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETSNAPSHOTTIME);
            MOS_SPRINTF(pucErrorString, "Device pfunGetSnapShotTime err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, pucErrorString, 1);
        } 
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunGetSnapShotTime is NULL!");
    }

    pucStrTmp = MsgMng_BuildGetSnapShotTimeRsp(uiSeqId,iStatus,iTimeInSec,iTimeInMs,iTicket,&stMsgFromTo);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETSNAPSHOTTIME_RSP,
        pucStrTmp, MOS_STRLEN(pucStrTmp),MOS_NULL);
    
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u send shot time rspMsg %s",uiSeqId,pucStrTmp);
    
    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;

}

// 34C0
_INT MsgMng_RecvSetInIotsPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _UI uiKjIoTType      = 0;
    _LLID lluKjIoTId     = 0;
    _INT iOpenFlag       = 0;
    _INT iStatus         = 0;
    _INT iArraySize,i    = 0;
    _UI uiDuration       = 0;
    _UC *pucStrTmp       = MOS_NULL;
    _UC *pucpProp        = MOS_NULL;
    _UC *pucTmpProp      = MOS_NULL;
    JSON_HANDLE hIotsObj = MOS_NULL;
    JSON_HANDLE hPropObj = MOS_NULL;
    JSON_HANDLE hItemObj = MOS_NULL;
    JSON_HANDLE hArryObj = MOS_NULL;
    JSON_HANDLE hTmpPropObj = MOS_NULL;
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");

    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    hIotsObj = Adpt_Json_GetObjectItem(hBody,(_UC*)"IOTs");
    iArraySize = Adpt_Json_GetArraySize(hIotsObj);
    for(i = 0; i < iArraySize; i++)
    {
        hItemObj = Adpt_Json_GetArrayItem(hIotsObj,i);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hItemObj,(_UC*)"AIIoTType"),(_INT*)&uiKjIoTType);
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hItemObj,(_UC*)"AIIoTID"),&pucStrTmp);
        MOS_SSCANF(pucStrTmp, "%llu",&lluKjIoTId);
        if(Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hItemObj,(_UC*)"OpenFlag"),(_INT*)&iOpenFlag) == ITRD_OK)
        {
            Config_SetInIotOpenFlag(uiKjIoTType,lluKjIoTId,iOpenFlag);
        }
        hPropObj = Adpt_Json_GetObjectItem(hItemObj,(_UC*)"Prop");
        if(hPropObj != MOS_NULL)
        {
            if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_CLOUDRECORD)
            {
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPropObj,(_UC*)"Duration"),(_INT*)&uiDuration);
                pucTmpProp = Config_GetInIotProp(uiKjIoTType,lluKjIoTId);
                if(pucTmpProp)
                {
                    hTmpPropObj = Adpt_Json_Parse(pucTmpProp);
                    Adpt_Json_DeleteItemFromObject(hTmpPropObj, (_UC*)"Duration");
                    Adpt_Json_AddItemToObject(hTmpPropObj, (_UC*)"Duration", Adpt_Json_CreateStrWithNum(uiDuration));
#if SDK_AWAKE_SLEEP_ENABLE
                    if (Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //低功耗设备
                    {
                        Config_GetInIotMng()->stRecordInf.uiDuration = uiDuration;    //云存根据这个全局变量获取间隔，或者修改云存根据IOT属性获取
                        MOS_LOG_WARN(MSGMNG_ID_LOG_STR,"update record duration %d",uiDuration);
                    }
#endif
                    pucpProp = Adpt_Json_Print(hTmpPropObj);
                    Adpt_Json_Delete(hTmpPropObj);
                }

            }
            else if(uiKjIoTType == EN_ZJ_AIIOT_TYPE_BUZZER)
            {
                pucpProp = Adpt_Json_Print(hPropObj);

                ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
                pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiKjIoTType);
                Config_SetAlarmPolicyTime(pstAPolicyNode, 1, 0X7F, 0, 86400);
                Config_SetAlarmPolicyProp(pstAPolicyNode,(_UC*)pucpProp);
                
                pstDevCtrlNode = KjIoT_FindDevContrlNode(uiKjIoTType);
                if(pstDevCtrlNode && pstDevCtrlNode->pfunSetProp)
                {
                    pstDevCtrlNode->pfunSetProp(uiKjIoTType,lluKjIoTId,pucpProp);
                }
            }
            else
            {
                pucpProp = Adpt_Json_Print(hPropObj);
            }
            Config_SetInIotProp(uiKjIoTType,lluKjIoTId,pucpProp);
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u, recv set KjIoT prop %s",uiSeqId, pucpProp);
            Adpt_Json_DePrint(pucpProp);
            pucpProp = MOS_NULL;
        }
    }
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETINIOTSPROP_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 平台下发底库信息 4420
_INT MsgMng_RecvAddFaceOrLicenseLibMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT i                       = 0;
    _INT iArrySize               = 0;
    _INT iStatus                 = MOS_ERR;
    _UI  uiPicType               = 0;
    _UC  ucTaskID[16]            = {0};
    _UC  ucUserID[16]            = {0};
    _UC  *pStrTmp                = MOS_NULL;
    _UC  aucStrErrLog[128]       = {0};
    _INT iIsExistDispositionID   = 0;
    EN_AICFG_LABEL enLabelType   = EN_BLACK_LIST;
    ST_AICFG_LABEL *stAICfgLabel = NULL;
    JSON_HANDLE hArry,  hArryObject;
    ST_FROM_TO_MSG stMsgFromTo   = {0};
    ST_MOS_LIST_ITERATOR  stIterator;
    ST_CFG_LABELS_INF_NODE  *pstLabelInfNode            = MOS_NULL;
    ST_CFG_PICTURE_INF_NODE *pstPictureInfNode          = MOS_NULL;
    ST_CFG_DOWNLOAD_PIC_INF_NODE  stDownloadPicInfNode  = {0};
    ST_CFG_DOWNLOAD_TASK_INF_NODE stDownloadTaskInfNode = {0};
    ST_CMSTASK_DOWNLOAD_PICTURE_INF stDownloadPicInf    = {0};

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_AI_RT_4420_JSON_NULL_ERR, (_UC*)"4420 Body Json Is Null", MOS_NULL, 1);
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_AI_RT_4420_DEV_SLEEP_NOW_ERR, (_UC*)"4420 Device Is Sleeping Now CamOpenFlag:0", MOS_NULL, 1);
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);


    // 任务ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"TaskID"),&pStrTmp);
    MOS_STRNCPY(ucTaskID, pStrTmp, sizeof(ucTaskID));
    // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"TaskID:%s", ucTaskID);

    // 用户标识
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"UserID"),&pStrTmp);
    MOS_STRNCPY(ucUserID, pStrTmp, sizeof(ucUserID));
    // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UserID:%s", ucUserID);

    // 图片类型 1、人脸；2、车牌
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PicType"),&uiPicType);
    // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"PicType:%d", uiPicType);

    if (2 == uiPicType)
    {
        // SDK不支持车牌布控，响应下发失败
        return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_DEVAI,EN_OGCT_DEVAI_ADDFACEORLICENSELIB_RSP,uiSeqId,1,&stMsgFromTo);
    }

    // Pictures
    hArry = Adpt_Json_GetObjectItem(hBody,(_UC*)"Pictures");
    iArrySize = Adpt_Json_GetArraySize(hArry);
    for(i = 0; i < iArrySize; i++)
    {
        hArryObject = Adpt_Json_GetArrayItem(hArry,i);
        // 所属名单 0.都不属于；1.黑名单；2.白名单
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hArryObject, (_UC*)"WBList"), &stDownloadPicInf.uiWBList);
        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"WBList:%d", stDownloadPicInf.uiWBList);

        // 人脸图片父集ID
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject, (_UC*)"DispositionID"),&pStrTmp);
        MOS_STRNCPY(stDownloadPicInf.ucDispositionID, pStrTmp, sizeof(stDownloadPicInf.ucDispositionID));
        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"DispositionID:%s", stDownloadPicInf.ucDispositionID);

        // 布控时平台下发的图片描述信息
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject, (_UC*)"Desc"),&pStrTmp);
        MOS_STRNCPY(stDownloadPicInf.ucDesc, pStrTmp, sizeof(stDownloadPicInf.ucDesc));
        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Desc:%s", stDownloadPicInf.ucDesc);

        // 图片下载地址
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hArryObject, (_UC*)"PicUrl"),&pStrTmp);
        MOS_STRNCPY(stDownloadPicInf.ucPicUrl, pStrTmp, sizeof(stDownloadPicInf.ucPicUrl));
        // MOS_LOG_INF(MSGMNG_ID_LOG_STR,"PicUrl:%s", stDownloadPicInf.ucPicUrl);

        stDownloadTaskInfNode.uiPicType = uiPicType;
        MOS_STRNCPY(stDownloadTaskInfNode.ucTaskID, ucTaskID, sizeof(stDownloadTaskInfNode.ucTaskID));
        MOS_STRNCPY(stDownloadPicInfNode.ucDispositionID, stDownloadPicInf.ucDispositionID, sizeof(stDownloadPicInfNode.ucDispositionID));

        if (EN_WHITE_LIST == stDownloadPicInf.uiWBList)
        {
            enLabelType = EN_AICFG_LABEL_FACE_WHITELIST;
        }
        else
        {
            stDownloadPicInf.uiWBList = EN_BLACK_LIST;
            enLabelType = EN_AICFG_LABEL_FACE_BLACKLIST;
        }

        stAICfgLabel = Get_AICfgLabel();

        Mos_MutexLock(&(Config_GetAIMng()->hDownLoadMutex));

        pstLabelInfNode = Config_FindLabelNode(0, stAICfgLabel[enLabelType].pucLabelID);
        if (pstLabelInfNode == MOS_NULL)
        {
            // 通知厂商创建lableID ADD by LWJ
            if (ZJ_GetFuncTable()->pFunCreateLabel)
            {
                iStatus = ZJ_GetFuncTable()->pFunCreateLabel(stAICfgLabel[enLabelType].pucLabelID, 1, stDownloadPicInf.uiWBList);
                if (MOS_OK == iStatus)
                {
                    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pFunCreateLabel LABELID:%s OK ", stAICfgLabel[enLabelType].pucLabelID);

                    // 创建label管理列表
                    Config_AddAILabelNode(0, stAICfgLabel[enLabelType].pucLabelID);
                    Config_SetLabelNodeName(0, stAICfgLabel[enLabelType].pucLabelID, stAICfgLabel[enLabelType].pucLabelName);
                    Config_SetLabelNodePicType(0, stAICfgLabel[enLabelType].pucLabelID, 1);
                    Config_SetLabelNodeWBList(0, stAICfgLabel[enLabelType].pucLabelID, stDownloadPicInf.uiWBList);
                    Config_SetLabelNodeUserID(0, stAICfgLabel[enLabelType].pucLabelID, stAICfgLabel[enLabelType].pucUserID);

                    // 创建下载布控图片节点
                    Config_AddAIDownloadTaskNode(0, ucTaskID);
                    Config_SetDownloadTaskNodeUserID(0,  ucTaskID, ucUserID);
                    Config_SetDownloadTaskNodePicType(0, ucTaskID, uiPicType);
                    Config_AddPictureToDownloadTask(0, ucTaskID, stDownloadPicInf.uiWBList, stDownloadPicInf.ucDesc, stDownloadPicInf.ucDispositionID, stDownloadPicInf.ucPicUrl);
                }
                else
                {
                    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunCreateLabel AICFG_LABELID:%s failed", stAICfgLabel[enLabelType].pucLabelID);
                    CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, EN_AI_RT_4420_FUNCCREATELABEL_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);

                    // 向平台汇报库下载状态 失败 0x4422
                    AI_PubUpgradeDownPicStatus(&stDownloadTaskInfNode, &stDownloadPicInfNode, 0);
                }
            }
            else
            {
                CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1,
                                    EN_AI_RT_4420_NOT_CREATE_LABELID_ERR, (_UC*)"Device pFunCreateLabel and pstLabelInfNode is Null", MOS_NULL, 1);

                // 向平台汇报库下载状态 失败 0x4422
                AI_PubUpgradeDownPicStatus(&stDownloadTaskInfNode, &stDownloadPicInfNode, 0);
            }
        }
        else
        {
            FOR_EACHDATA_INLIST(&pstLabelInfNode->stPictureInfList, pstPictureInfNode, stIterator)
            {
                // 布控ID与已经布控的不重复，就添加到下载链表
                if((MOS_STRCMP(pstPictureInfNode->ucDispositionID, stDownloadPicInf.ucDispositionID) == 0))
                {
                    MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Find Same DispositionID(%s)", stDownloadPicInf.ucDispositionID);
                    CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                            EN_AI_RT_4420_REPEAT_DISPOSITIONID_ERR, aucStrErrLog, MOS_NULL, 1);

                    // 向平台汇报库下载状态 成功 0x4422
                    AI_PubUpgradeDownPicStatus(&stDownloadTaskInfNode, &stDownloadPicInfNode, 1);
                    iIsExistDispositionID = 1;
                    break;
                }
            }

            // 创建下载布控图片节点
            if (iIsExistDispositionID == 0)
            {
                Config_AddAIDownloadTaskNode(0, ucTaskID);
                Config_SetDownloadTaskNodeUserID(0,  ucTaskID, ucUserID);
                Config_SetDownloadTaskNodePicType(0, ucTaskID, uiPicType);
                Config_AddPictureToDownloadTask(0, ucTaskID, stDownloadPicInf.uiWBList, stDownloadPicInf.ucDesc, stDownloadPicInf.ucDispositionID, stDownloadPicInf.ucPicUrl);
            }
        }

        Mos_MutexUnLock(&(Config_GetAIMng()->hDownLoadMutex));
    }
    
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_DEVAI,EN_OGCT_DEVAI_ADDFACEORLICENSELIB_RSP,uiSeqId,MOS_OK,&stMsgFromTo);
}

// 平台下发删除底库信息 4424
_INT MsgMng_RecvDelFaceOrLicenseLibMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus                 = MOS_ERR;
    _UI  uiPicType               = 0;
    _UI  uiWBList                = 0;
    _UC  *pStrTmp                = MOS_NULL;
    _INT i                       = 0;
    _INT iPictureArrySize        = 0;
    _UC  aucStrErrLog[128]       = {0};
    EN_AICFG_LABEL enLabelType   = EN_BLACK_LIST;
    ST_AICFG_LABEL *stAICfgLabel = NULL;
    ST_FROM_TO_MSG stMsgFromTo   = {0};
    JSON_HANDLE hPictureArry,hPictureArryObject;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_AI_RT_4424_JSON_NULL_ERR, (_UC*)"4424 Body Json Is Null", MOS_NULL, 1);
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_AI_RT_4424_DEV_SLEEP_NOW_ERR, (_UC*)"4424 Device Is Sleeping Now CamOpenFlag:0", MOS_NULL, 1);

        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 用户标识
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"UserID"),&pStrTmp);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"UserID:%s", pStrTmp);

    // 图片类型 1、人脸；2、车牌
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PicType"),&uiPicType);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"PicType:%d", uiPicType);

    stAICfgLabel = Get_AICfgLabel();

    // Pictures
    hPictureArry = Adpt_Json_GetObjectItem(hBody,(_UC*)"Pictures");
    iPictureArrySize = Adpt_Json_GetArraySize(hPictureArry);
    for(i = 0; i < iPictureArrySize; i++)
    {
        hPictureArryObject = Adpt_Json_GetArrayItem(hPictureArry,i);

        // 所属名单 0.都不属于；1.黑名单；2.白名单
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPictureArryObject, (_UC*)"WBList"), &uiWBList);
        if (EN_WHITE_LIST == uiWBList)
        {
            enLabelType = EN_AICFG_LABEL_FACE_WHITELIST;
        }
        else
        {
            uiWBList = EN_BLACK_LIST;
            enLabelType = EN_AICFG_LABEL_FACE_BLACKLIST;
        }

        // 人脸图片父集ID
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hPictureArryObject, (_UC*)"DispositionID"),&pStrTmp);

        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"uiWBList:%u DispositionID:%s", uiWBList, pStrTmp);
        
        // 通知厂商删除AI图片数据 ADD by LWJ
        if (ZJ_GetFuncTable()->pFunDelSingleAiPic)
        {
            iStatus = ZJ_GetFuncTable()->pFunDelSingleAiPic(stAICfgLabel[enLabelType].pucLabelID, pStrTmp);
            if (MOS_OK == iStatus)
            {
                MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunDelSingleAiPic DispositionID:%s OK", pStrTmp);
                CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                        EN_AI_RT_4424_FUNCDELSINGLEAIPIC_DEV_RT_OK, aucStrErrLog, MOS_NULL, 1);
                // 删除LAbel中指定的Pic
                Mos_MutexLock(&(Config_GetAIMng()->hDownLoadMutex));
                Config_DelPictureToLabel(0, stAICfgLabel[enLabelType].pucLabelID, pStrTmp);
                Mos_MutexUnLock(&(Config_GetAIMng()->hDownLoadMutex));
            }
            else
            {
                MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunDelSingleAiPic DispositionID:%s return failed", pStrTmp);
                CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                        EN_AI_RT_4424_FUNCDELSINGLEAIPIC_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pFunDelSingleAiPic is NULL!");
        }
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_DEVAI,EN_OGCT_DEVAI_DELFACEORLICENSELIB_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 设置客流统计区域坐标 34D2
_INT MsgMng_RecvSetHumanCountRegionsMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, 0, "HumanCount Recv SetHumanCountRegionsMsg", 1);

    _INT iStatus     = MOS_ERR;
    _UC *pstrRegions = MOS_NULL;
    ST_CFG_HUMAN_COUNT_REGION stHumanCountRegion = {0};

    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");    
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "HumanCount Check The hJsonRoot Is Null", 1);
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");       
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    _INT i, iRegionsArrySize   = 0;
    JSON_HANDLE hRegionsArry   = MOS_NULL;
    JSON_HANDLE hRegionsObject = MOS_NULL;

    hRegionsArry     = Adpt_Json_GetObjectItem(hBody,(_UC*)"Regions");
    if (hRegionsArry == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hRegionsArry == MOS_NULL");        
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "HumanCount Check The Regions Is Null", 1);
        return MOS_ERR;
    }
    
    iRegionsArrySize = Adpt_Json_GetArraySize(hRegionsArry);
    for(i = 0; i < iRegionsArrySize; i++)
    {
        hRegionsObject = Adpt_Json_GetArrayItem(hRegionsArry,i);

        // 区域X
        Adpt_Json_GetDouble_Ex(Adpt_Json_GetObjectItem(hRegionsObject, (_UC*)"x"), &stHumanCountRegion.iX[i]);
        MOS_PRINTF("%s:%d: X[%d]:%lf \r\n", __FUNCTION__, __LINE__, i, stHumanCountRegion.iX[i]);

        // 区域Y
        Adpt_Json_GetDouble_Ex(Adpt_Json_GetObjectItem(hRegionsObject, (_UC*)"y"), &stHumanCountRegion.iY[i]);
        MOS_PRINTF("%s:%d: Y[%d]:%lf \r\n", __FUNCTION__, __LINE__, i, stHumanCountRegion.iY[i]);
    }

    pstrRegions = Adpt_Json_Print(hRegionsArry);
    if (pstrRegions == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pstrRegions == MOS_NULL");       
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "HumanCount Check The Regions Is Error", 1);
        return MOS_ERR;
    }

    MOS_PRINTF("%s:%d: pstrRegions = %s \r\n", __FUNCTION__, __LINE__,pstrRegions);
    // 通知厂商人流量统计区域 ADD by LWJ
    if (ZJ_GetFuncTable()->pfunSetHumCountRegions)
    {
        iStatus = ZJ_GetFuncTable()->pfunSetHumCountRegions(pstrRegions);
        if (MOS_OK == iStatus)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pfunSetHumCountRegions %s OK", pstrRegions);
            // 保存配置
            Config_SetHumanCountRegions(&stHumanCountRegion);
        }
        else
        {        
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "HumanCount pfunSetHumCountRegions Set Failed", 1);
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pfunSetHumCountRegions %s failed \r\n", pstrRegions);
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunSetHumCountRegions is NULL!");        
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "HumanCount pfunSetHumCountRegions not registered", 1);
    }
    MOS_FREE(pstrRegions);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETHUMANCOUNTREGIONS_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 设置客流统计参数 34D4
_INT MsgMng_RecvSetHumanCountParamMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, 0, "HumanCount Recv SetHumanCountParamMsg", 1);

    _INT iStatus   = MOS_ERR;
    _UI uiOpenFlag = 0;
    _UI uiInterval = 0;

    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");      
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "HumanCount Check The hJsonRoot Is Null", 1);
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 客流统计开关 0.关，1.开
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"OpenFlag"),&uiOpenFlag);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"OpenFlag:%d \r\n", uiOpenFlag);

    // 客流统计事件检测间隔 分钟
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"Interval"),&uiInterval);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Interval:%d \r\n", uiInterval);

    // 通知厂商人流量统计开关、统计间隔 ADD by LWJ
    if (ZJ_GetFuncTable()->pfunSetHumCountParam)
    {
        iStatus = ZJ_GetFuncTable()->pfunSetHumCountParam(uiOpenFlag, uiInterval);
        if (MOS_OK == iStatus)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pfunSetHumCountParam OK");
            // 保存配置
            Config_SetHumanCountOpenFlag(uiOpenFlag);
            Config_SetHumanCountInterval(uiInterval);
        }
        else
        {        
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "HumanCount pfunSetHumCountParam Set Failed", 1);
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pfunSetHumCountParam failed");
        }
    }
    else
    {   
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "HumanCount pfunSetHumCountParam not registered", 1);
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunSetHumCountParam is NULL!");
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETHUMANCOUNTPARAM_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 创建实时音频广播 34D6
_INT MsgMng_RecvCreateRealTimeBroadcastMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    _UC aucMsgString[128] = {0}; 
    MOS_SPRINTF(aucMsgString, "%s Recv Msg",BROADCAST_ID_LOG_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_RECV_MSG, aucMsgString, 1);

#ifdef BUILD_ONBROADCAST_FALG
    if (Config_GetCamaraMng()->uiCloudBroadcastAbility <= 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "uiCloudBroadcastAbility is disabled,ignore run broadcast!");

        MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
        MOS_SPRINTF(aucMsgString, "%s Ability is disabled",BROADCAST_ID_LOG_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_ABILITY_DISABLE, aucMsgString, 1);
        return MOS_OK;
    }

    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    
    _INT iRet      = 0;
    _INT iStatus   = 0;
    _UC *pStrTmp   = MOS_NULL;
    _UI uiVoiceGwPort   =  0;
    _UC ucSessionId[33] = {0};
    _UC ucVoiceGwIp[33] = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");

        MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
        MOS_SPRINTF(aucMsgString, "%s Check The Body Is Null",BROADCAST_ID_LOG_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_CHECK_BODY_FAIL, aucMsgString, 1);
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 会话ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"sessionId"),&pStrTmp);
    
    MOS_STRLCPY(ucSessionId, pStrTmp, sizeof(ucSessionId));

    // 语音网关IP
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"voiceGwIp"),&pStrTmp);
    
    MOS_STRLCPY(ucVoiceGwIp, pStrTmp, sizeof(ucVoiceGwIp));

    // 语音网关端口 5005
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"voiceGwPort"), &uiVoiceGwPort);

    MOS_PRINTF("%s:%d: ucSessionId = %s  ucVoiceGwIp = %s  uiVoiceGwPort = %d\n", __FUNCTION__, __LINE__, ucSessionId,ucVoiceGwIp,uiVoiceGwPort);

    //暂停所有定时广播
    Broadcast_Task_Pause_StartLive();
    //pause_all_task();

    // 调用云广播sdk的接口 实现实时音频广播会话创建
    iRet = create_live_session(ucVoiceGwIp, uiVoiceGwPort, Config_GetSystemMng()->aucDevUID, ucSessionId);
    if (MOS_ERR == iRet)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"create_live_session failed!");  

        MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
        MOS_SPRINTF(aucMsgString, "%s Create Live Senssion Failed",BROADCAST_ID_LOG_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_CREATE_PLAYBACK_TASK_FAIL, aucMsgString, 1);
        return MOS_ERR;
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CREATEREALTIMEBROADCAST_RSP,uiSeqId,iStatus,&stMsgFromTo);
#else
    MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
    MOS_SPRINTF(aucMsgString, "%s is not support",BROADCAST_ID_LOG_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_NO_SUPPORT, aucMsgString, 1);

    return MOS_OK;
#endif        
}

// 创建回放音频广播定时任务 34D8
_INT MsgMng_RecvCreateScheduleBroadcastMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    _UC aucMsgString[128] = {0}; 
    MOS_SPRINTF(aucMsgString, "%s Recv Msg",BROADCAST_ID_LOG_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_RECV_MSG, aucMsgString, 1);

#ifdef BUILD_ONBROADCAST_FALG
    if (Config_GetCamaraMng()->uiCloudBroadcastAbility <= 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "uiCloudBroadcastAbility is disabled,ignore run broadcast!");

        MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
        MOS_SPRINTF(aucMsgString, "%s Ability is disabled",BROADCAST_ID_LOG_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_ABILITY_DISABLE, aucMsgString, 1);
        return MOS_OK;
    }   

    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT iRet      = 0;
    _INT iStatus   = 0;
    _UC *pStrTmp   = MOS_NULL;
    _UC  ucTaskId[64]  = {0};
    _UC *pStrScheduleJson      = MOS_NULL;
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");        

        MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
        MOS_SPRINTF(aucMsgString, "%s Check The Body Is Null",BROADCAST_ID_LOG_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_CHECK_BODY_FAIL, aucMsgString, 1);
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");        
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 任务ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"TaskId"),&pStrTmp);
    MOS_STRLCPY(ucTaskId, pStrTmp, sizeof(ucTaskId));
    
    // 定时广播的策略json
    pStrScheduleJson = Adpt_Json_Print(hBody);
    if (pStrScheduleJson == MOS_NULL)
    {  
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "Broadcast Check The Playback Json Str Is Error", 1);
        return MOS_ERR;
    }

    MOS_PRINTF("ucTaskId = %s  pStrScheduleJson = %s\n",ucTaskId,pStrScheduleJson);

    //调用云广播sdk的接口 实现创建回放音频广播定时任务
    iRet = create_playback_schedule(ucTaskId, pStrScheduleJson);
    if (MOS_ERR == iRet)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"create_playback_schedule failed!");   

        MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
        MOS_SPRINTF(aucMsgString, "%s Create Playback Schedule Failed",BROADCAST_ID_LOG_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_CREATE_LIVE_TASK_FAIL, aucMsgString, 1);
        MOS_FREE(pStrScheduleJson);
        return MOS_ERR;
    }
    
    MOS_FREE(pStrScheduleJson); 

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CREATESCHEDULEDBROADCAST_RSP,uiSeqId,iStatus,&stMsgFromTo);
#else
    MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
    MOS_SPRINTF(aucMsgString, "%s is not support",BROADCAST_ID_LOG_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_NO_SUPPORT, aucMsgString, 1);

    return MOS_OK;
#endif    
}

// 取消回放音频广播定时任务 34DA
_INT MsgMng_RecvCancelScheduleBroadcastMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");
    _UC aucMsgString[128] = {0}; 
    MOS_SPRINTF(aucMsgString, "%s Recv Msg",BROADCAST_ID_LOG_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_RECV_MSG, aucMsgString, 1);

#ifdef BUILD_ONBROADCAST_FALG
    if (Config_GetCamaraMng()->uiCloudBroadcastAbility <= 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "uiCloudBroadcastAbility is disabled,ignore run broadcast!");

        MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
        MOS_SPRINTF(aucMsgString, "%s Ability is disabled",BROADCAST_ID_LOG_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_ABILITY_DISABLE, aucMsgString, 1);
        return MOS_OK;
    }   

    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);
    
    _INT iRet      = 0;
    _INT iStatus   = 0;
    _UC *pStrTmp   = MOS_NULL;
    _UC  ucTaskId[64]  = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");

        MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
        MOS_SPRINTF(aucMsgString, "%s Check The Body Is Null",BROADCAST_ID_LOG_STR);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_CHECK_BODY_FAIL, aucMsgString, 1);
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");        
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 任务ID
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"taskId"),&pStrTmp);
    MOS_STRLCPY(ucTaskId, pStrTmp, sizeof(ucTaskId));
    
    MOS_PRINTF("ucTaskId = %s\n",ucTaskId);
    
    // 调用云广播sdk的接口 实现回放音频广播会话任务停止
    if (MOS_STRSTR(ucTaskId, "ALL") != MOS_NULL)
    {
        iRet = stop_all_task(ucTaskId);
        if (MOS_ERR == iRet)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"stop_all_task failed!");            
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "Broadcast Stop All Playback Task Failed", 1);
            return MOS_ERR;
        }            
    }
    else
    {
        iRet = stop_playback_schedule(ucTaskId);
        if (MOS_ERR == iRet)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"stop_playback_schedule failed!");            
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "Broadcast Stop One Playback Task Failed", 1);
            return MOS_ERR;
        }        
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CANCELSCHEDULEDBROADCAST_RSP,uiSeqId,iStatus,&stMsgFromTo);
#else
    MOS_MEMSET(aucMsgString,0,sizeof(aucMsgString));
    MOS_SPRINTF(aucMsgString, "%s is not support",BROADCAST_ID_LOG_STR);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_BROADCAST_RT_NO_SUPPORT, aucMsgString, 1);

    return MOS_OK;
#endif
    
}

// GAT1400功能开关 34DE
_INT MsgMng_RecvGat1400SwitchMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus               = 0;
    _UI  uiGAT1400Switch       = 0;
    _UC  pucString[128]        = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_1400_RT_34DE_JSON_NULL_ERR, (_UC*)"34DE Body Json Is Null", MOS_NULL, 1);
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), __FUNCTION__, -1, 
                                EN_1400_RT_34DE_DEV_SLEEP_NOW_ERR, (_UC*)"34DE Device Is Sleeping Now CamOpenFlag:0", MOS_NULL, 1);
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // GAT1400开关
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"GAT1400Switch"), &uiGAT1400Switch);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"uiGAT1400Switch:%d", uiGAT1400Switch);

    if (Config_GetCamaraMng()->uiInterGAT1400Ability == 1) // 内嵌Ga1400
    {
        // 保存配置
        Config_SetCamerGat1400Switch(0, uiGAT1400Switch);

#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
        Ga1400_SetTaskGetInfoFlag(uiGAT1400Switch?EN_GA1400_GETINFO_NEED_NOW:EN_GA1400_GETINFO_NEED_LOOP);
        // 关闭Ga1400开关，已注册的话要注销
        if (uiGAT1400Switch == 0 && (Ga1400_GetTaskRegisterFlag() == EN_GA1400_REGISTER_SUCCESS))
        {
            Ga1400_SetTaskUnRegisterFlag(EN_GA1400_UNREGISTER_NEED);
        }
#endif
    }
    else
    {
        // 通知厂商设置GAT1400开关 ADD by LWJ
        if (ZJ_GetFuncTable()->pfunSetGa1400SwitchCb)
        {
            iStatus = ZJ_GetFuncTable()->pfunSetGa1400SwitchCb(uiGAT1400Switch);
            if (MOS_OK == iStatus)
            {
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pfunSetGa1400SwitchCb OK");
                // 保存配置
#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
                Config_SetCamerGat1400Switch(0, uiGAT1400Switch);
                Ga1400_SetTaskGetInfoFlag(uiGAT1400Switch?EN_GA1400_GETINFO_NEED_NOW:EN_GA1400_GETINFO_NEED_LOOP);
#endif
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pfunSetGa1400SwitchCb failed");
                iStatus = -1;
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunSetGa1400SwitchCb is NULL!");
            iStatus = -2;
        }
    }
    
    MOS_SPRINTF(pucString, "Now receive uiGAT1400Switch:%d, iRet: %d\r\n", uiGAT1400Switch, iStatus);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, iStatus, pucString, 1);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GAT1400SWITCH_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 业务策略变更通知
_INT MsgMng_RecvBusinessStrategyChangeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus               = 0;
    _UI  uiImsSid              = 0;
    _UC  aucString[128]        = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 系统ID 0/1:云化摄像头平台，2:IMS业务策略变更
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"SID"), &uiImsSid);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"uiImsSid:%u", uiImsSid);

    if (uiImsSid == 2)
    {
        // TODO 重新获取IMS业务参数

    }
    
    MOS_SPRINTF(aucString, "Now receive uiImsSid:%d, iRet: %d\r\n", uiImsSid, iStatus);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, iStatus, aucString, 1);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_BUSINESSSTRATEGYCHANGE_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

// 下发设备IMS通话呼叫(AI强告警)
_INT MsgMng_RecvSendIMSCallMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

#ifdef BUILD_IMSSDK_FALG
    _INT iStatus               = 0;
    _INT iCallType             = 0;
    _UC *pStrTmp               = MOS_NULL;
    _UC  ucCallNum[16]         = {0};
    _UC  aucString[128]        = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 呼叫类型  0:音频呼叫 1:视频呼叫  注：不修改SDK本地持久化数据
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"CallType"), &iCallType);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"CallType:%d", iCallType);

    // 通知IMS SDK通话呼叫
    iStatus = ImsMedia_CallOut(&ucCallNum, iCallType);
    
    MOS_SPRINTF(aucString, "Now Receive IMSCall, iStatus: %d \r\n", iStatus);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, iStatus, aucString, 1);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SENDIMSCALL_RSP,uiSeqId,iStatus,&stMsgFromTo);
#endif
    return MOS_OK;
}

// 下发设备返回当前全部配置
_INT MsgMng_RecvUploadBusinessCfg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus               = 0;
    _UC *pStrTmp               = MOS_NULL;
    _UC  aucString[128]        = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // TODO 获取设备参数返回到平台
    JSON_HANDLE hBodyRsp = MOS_NULL;
    hBodyRsp = Config_BuildAllLocalBussJson();
    MOS_SPRINTF(aucString, "Now receive UploadBusinessCfg, iRet: %d \r\n", iStatus);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, iStatus, aucString, 1);

    return Cmdhdl_Task_SendCommonDevMsgRspEx(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_UPLOADBUSINESSCFG_RSP,uiSeqId,iStatus,&stMsgFromTo,hBodyRsp);
}

_INT MsgMng_RecvCmdNotSupportMsg(_UC *pucPeerId, _UI uiSeqId, _UC ucMsgType, _UC ucMsgId, _VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);

    ST_FROM_TO_MSG stMsgFromTo = {0};

    //MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"reqid %u Cmd is Not Exit %s", uiSeqId, pucPeerId);
    return Cmdhdl_CmdNotSupporMsg(pucPeerId, uiSeqId, ucMsgType, ucMsgId, &stMsgFromTo);
}

// 消警开关
_INT MsgMng_RecvStopAlarmRingMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus               = 0;
    _UI  uiStopType            = 0;
    _UC  pucString[128]        = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 0.不停止任何声音，1.停止区域告警播放，2.停止云广播播放， 255.停止全部告警声音；使用掩码方式
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"StopType"), &uiStopType);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Now receive stop alarm uiStopType:%d", uiStopType);

    if (uiStopType & 0x01 == 1)
    {
        _UC aucBuzzerBuff[256] = {0};
        MOS_VSNPRINTF(aucBuzzerBuff, 256, "{\"CtrlType\":\"0\",\"AlarmType\":\"%d\",\"SoundType\":\"%d\",\"LoopCnt\":\"1\"}", EN_ZJ_AIIOT_TYPE_BATTERYBIKE, EN_ZJ_RING_ALARM);
        ST_ZJ_TRIGGER_INFO* pstTriggerInf;
        ST_KJIOT_CONTRLDEV_NODE *pstEventProcNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_BUZZER);
        iStatus = pstEventProcNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_BUZZER, 0, (_UC*)"{\"CtrlType\":\"1\",,\"SoundType\":\"0\"}", pstTriggerInf);
        // pstEventProcNode->pfunSetProp(EN_ZJ_AIIOT_TYPE_BUZZER, 0, aucBuzzerBuff);
    }
    if (uiStopType & 0x02 == 1)
    {

    }


    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, iStatus, pucString, 1);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_STOPALARMRING_RSP,uiSeqId,iStatus,&stMsgFromTo);
}

//指示灯开关状态
_INT MsgMng_RecvSetPilotLightStatusMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IS COMING");

    _INT iStatus               = 0;
    _UI  uiPilotLightStatus    = 0;
    _UC  aucStatusStr[128]     = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "hBody == MOS_NULL");
        return MOS_ERR;
    }

    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    //0：关闭指示灯，1：打开指示灯
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"PilotLightFlag"), &uiPilotLightStatus);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "Now receive pilot light status uiPilotLightStatus:%d", uiPilotLightStatus);
    MOS_VSNPRINTF(aucStatusStr, sizeof(aucStatusStr), (_UC*)"{\"CtrlType\":\"%d\",\"Flicker\":\"\"}", uiPilotLightStatus);

    // 通知厂商指示灯开关
    ST_KJIOT_CONTRLDEV_NODE *pstEventProcNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_STATELAMP); 
    if (pstEventProcNode != MOS_NULL)
    {
        if (pstEventProcNode->pFunContrlDev)
        {
            iStatus = pstEventProcNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_STATELAMP, 0, aucStatusStr, NULL);
            if (MOS_OK == iStatus)
            {
                MOS_LOG_INF(MSGMNG_ID_LOG_STR, "Device pfunSetPilotLightStatus OK \r\n");
                // 保存配置
                Config_SetPilotLightStatus(uiPilotLightStatus);
            }
            else
            {
                CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_CMD_RT_EXECUTE_CMD_FAIL, "PilotLight pfunSetPilotLightStatus Set Failed", 1);
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "Device pfunSetPilotLightStatus failed \r\n");
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "pfunSetPilotLightStatus is NULL!");
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "PilotLight kjiot not registered");
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETPILOTLIGHT_RSP, uiSeqId, iStatus, &stMsgFromTo);
}

// 业务策略变更通知 34F2
_INT MsgMng_RecvBusinessPolicyChangeMsg(_UC *pucPeerId, _UI uiSeqId, _VPTR hJsonRoot)
{
#define CLOUD_CAMERA_BUSINESS_POLICY 1
#define IMS_BUSINESS_POLICY 2

    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus               = 0;
    _UI  uiSystemId            = 0;
    _UC  aucString[128]        = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // 业务策略变更通知
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"SID"), &uiSystemId);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"uiSystemId:%d", uiSystemId);

    if (uiSystemId == CLOUD_CAMERA_BUSINESS_POLICY)
    {
        if (ZJ_GetFuncTable()->pfunNtcCloudCamera)
        {
            iStatus = ZJ_GetFuncTable()->pfunNtcCloudCamera();
            if (MOS_OK == iStatus)
            {
                MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pfunNtcCloudCamera OK");
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pfunNtcCloudCamera failed");
                iStatus = -1;
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunNtcCloudCamera is NULL!");
            iStatus = -2;
        }
    }

    MOS_SPRINTF(aucString, "Now receive uiSystemId:%d, iRet: %d\r\n", uiSystemId, iStatus);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, iStatus, aucString, 1);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_BUSINESSSTRATEGYCHANGE_RSP,uiSeqId,iStatus,&stMsgFromTo);
}
// 设置超级编码开关 3404
_INT MsgMng_RecvSetSuperCodesMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IS COMING");

    _INT iOpenFlag = 0;
    ST_FROM_TO_MSG stMsgFromTo;
    _UC aucBuf[256] = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");
        return MOS_ERR;
    }
	
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);
    
    // 超级编码开关状态，0.关闭； 1.打开
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"SuperCodesStatus"), &iOpenFlag);
	
    return Cmdhdl_SetCamSuperCodesMsg(pucPeerId, uiSeqId, &stMsgFromTo, iOpenFlag);
}

// 应用与获取设备外网IP处理方案
// 对设备获取外网IP操作涉及的参数配置（340C）
_INT MsgMng_RecvSetGetOuterIPInfMsg(_UC *pucPeerId, _UI uiSeqId, _VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "IS COMING");

    _INT iStatus               = 0;
    _UI  uiGetDevOuterIPStatus = 0;     // 获取设备外网IP开关状态，0.关闭， 1:开启 默认：关闭
    _UI  uiOnlineRandomTime    = 0;     // 设备上线后在该值的随机时间点内获取外网IP 单位：分钟(min), 范围：[1-10] 默认：3分钟
    _UI  uiUploadInterval      = 0;     // 将获取外网IP统计数据上报云涛间隔(也可理解成数据统计周期) 单位：小时(h), 范围：[1-24] 默认：6小时
    _UI  uiMaxChangeCount      = 0;     // 统计周期内外网IP变更次数最大值   范围：[3-10] 默认：5次
    _UI  uiStopCheckDuration   = 0;     // 统计周期内外网IP变更次数达到上限后,停止检查设备外网IP的时长  单位：小时(h), 范围：[1-24] 默认：12小时
    _UC  aucStatusStr[128]     = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE  hGetDevOuterIPStatus = MOS_NULL;     // 获取设备外网IP开关状态，0.关闭， 1:开启 默认：关闭
    JSON_HANDLE  hOnlineRandomTime    = MOS_NULL;     // 设备上线后在该值的随机时间点内获取外网IP 单位：分钟(min), 范围：[1-10] 默认：3分钟
    JSON_HANDLE  hUploadInterval      = MOS_NULL;     // 将获取外网IP统计数据上报云涛间隔(也可理解成数据统计周期) 单位：小时(h), 范围：[1-24] 默认：6小时
    JSON_HANDLE  hMaxChangeCount      = MOS_NULL;     // 统计周期内外网IP变更次数最大值   范围：[3-10] 默认：5次
    JSON_HANDLE  hStopCheckDuration   = MOS_NULL;     // 统计周期内外网IP变更次数达到上限后,停止检查设备外网IP的时长  单位：小时(h), 范围：[1-24] 默认：12小时
    
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");
    if (hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "hBody == MOS_NULL");
        return MOS_ERR;
    }

    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR, "Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot, &stMsgFromTo);
    ST_CFG_DEVICE_MNG *pstDeviceMng = Config_GetDeviceMng();

    hGetDevOuterIPStatus = Adpt_Json_GetObjectItem(hBody, (_UC*)"GetDevOuterIPStatus");
    if (hGetDevOuterIPStatus)
    {
        // 获取设备外网IP开关状态，0.关闭， 1:开启 默认：关闭
        Adpt_Json_GetIntegerEx(hGetDevOuterIPStatus, &uiGetDevOuterIPStatus);
    }
    else
    {
        uiGetDevOuterIPStatus = pstDeviceMng->uiGetDevOuterIPStatus;
    }

    hOnlineRandomTime = Adpt_Json_GetObjectItem(hBody, (_UC*)"OnlineRandomTime");
    if (hOnlineRandomTime)
    {
        // 设备上线后在该值的随机时间点内获取外网IP 单位：分钟(min), 范围：[1-10] 默认：3分钟
        Adpt_Json_GetIntegerEx(hOnlineRandomTime, &uiOnlineRandomTime); 
    }
    else
    {
        uiOnlineRandomTime = pstDeviceMng->uiOnlineRandomTime;
    }

    hUploadInterval = Adpt_Json_GetObjectItem(hBody, (_UC*)"UploadInterval");
    if (hUploadInterval)
    {
        // 将获取外网IP统计数据上报云涛间隔(也可理解成数据统计周期) 单位：小时(h), 范围：[1-24] 默认：6小时
        Adpt_Json_GetIntegerEx(hUploadInterval, &uiUploadInterval);
    }
    else
    {
        uiUploadInterval = pstDeviceMng->uiUploadInterval;
    }

    hMaxChangeCount = Adpt_Json_GetObjectItem(hBody, (_UC*)"MaxChangeCount");
    if (hMaxChangeCount)
    {
        // 统计周期内外网IP变更次数最大值   范围：[3-10] 默认：5次
        Adpt_Json_GetIntegerEx(hMaxChangeCount, &uiMaxChangeCount);
    }
    else
    {
        uiMaxChangeCount = pstDeviceMng->uiMaxChangeCount;
    }

    hStopCheckDuration = Adpt_Json_GetObjectItem(hBody, (_UC*)"StopCheckDuration");
    if (hStopCheckDuration)
    {
        // 统计周期内外网IP变更次数达到上限后,停止检查设备外网IP的时长  单位：小时(h), 范围：[1-24] 默认：12小时
        Adpt_Json_GetIntegerEx(hStopCheckDuration, &uiStopCheckDuration); 
    }
    else
    {
        uiStopCheckDuration = pstDeviceMng->uiStopCheckDuration;
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "GetDevOuterIPStatus:%u OnlineRandomTime:%u UploadInterval:%u MaxChangeCount:%u StopCheckDuration:%u", 
                                    uiGetDevOuterIPStatus, uiOnlineRandomTime, uiUploadInterval, uiMaxChangeCount, uiStopCheckDuration); 

    iStatus = Config_SetGetOuterIPInf(uiGetDevOuterIPStatus, uiOnlineRandomTime, uiUploadInterval, uiMaxChangeCount, uiStopCheckDuration);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SET_GETOUTERIPINF_RSP, uiSeqId, iStatus, &stMsgFromTo);
}

// 3408 IPv6开关
_INT MsgMng_RecvIPv6SwitchMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"IS COMING");

    _INT iStatus               = 0;
    _UI  uiIPV6Status          = 0;
    _UC  pucString[128]        = {0};
    ST_FROM_TO_MSG stMsgFromTo = {0};
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"hBody == MOS_NULL");
        return MOS_ERR;
    }

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Config_GetCamaraMng()->uiCamOpenFlag == 0");
        return MOS_OK;
    }

    MsgMng_GetMsgSrcAndDstInf(hJsonRoot,&stMsgFromTo);

    // IPv6开关
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody, (_UC*)"IPV6Status"), &uiIPV6Status);
    MOS_LOG_INF(MSGMNG_ID_LOG_STR,"uiIPV6Status:%d", uiIPV6Status);

    // 通知厂商设置IPv6开关
    if (ZJ_GetFuncTable()->pfunIPv6Switch)
    {
        iStatus = ZJ_GetFuncTable()->pfunIPv6Switch(uiIPV6Status);
        if (MOS_OK == iStatus)
        {
            MOS_LOG_INF(MSGMNG_ID_LOG_STR,"Device pfunIPv6Switch OK");
            // 保存配置
            Config_SetCamerIPv6Switch(0, uiIPV6Status);
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"Device pfunIPv6Switch failed");
            iStatus = -1;
        }
    }
    else
    {
        MOS_LOG_ERR(MSGMNG_ID_LOG_STR,"pfunIPv6Switch is NULL!");
        iStatus = -2;
    }
    
    
    MOS_SPRINTF(pucString, "Now receive uiIPv6Status:%d, iRet: %d\r\n", uiIPV6Status, iStatus);
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, iStatus, pucString, 1);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_IPV6SWITCH_RSP,uiSeqId,iStatus,&stMsgFromTo);
}