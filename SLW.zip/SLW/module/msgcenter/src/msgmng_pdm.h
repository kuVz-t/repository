#ifndef _MSGMNG_PDM_H
#define _MSGMNG_PDM_H

#ifdef __cplusplus
extern "C" {
#endif

#define PDM_HOST   (_UC *)"pdm.tydevice.com"

typedef enum enum_MSGMNG_PDM_FLAG{
    EN_MSGMNG_PDM_FLAG_NOTYET  = 0,
    EN_MSGMNG_PDM_FLAG_DOING,
    EN_MSGMNG_PDM_FLAG_ERR,
    EN_MSGMNG_PDM_FLAG_FINSH,
}EN_MSGMNG_PDM_FLAG;

typedef struct stru_MSGMNG_PDM_MNG
{
    _UI uiRecvLen;
    _UI uiBufTotalLen;
    _UC *pucRcvBuf;
    _UI uiHttpHandle;
    _UC aucUuid[64];
    _CTIME_T cPdmUpTime;
    _UC ucPdmUpStatus;
}ST_MSGMNG_PDM_MNG;

ST_MSGMNG_PDM_MNG *MsgMng_PDM_GetMng();

_INT MsgMng_PDM_StartUpLoadDevInfo(_CTIME_T timeNow);

#ifdef __cplusplus
}
#endif

#endif