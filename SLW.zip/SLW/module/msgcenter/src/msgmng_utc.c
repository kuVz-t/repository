#include "msgmng_utc.h"
#include "config_api.h"
#include "http_api.h"
#include "adpt_json_adapt.h"
#include "msgmng_api.h"
#include "msgmng_cmdserver.h"
#include "cloudstg_logcode.h"
#include "msgmng_prv.h"

#define TIME_MAX_BAS 1800 // 平台时间和设备时间的最大误差(秒)

static _UI g_uiReqId = 0; // 请求ID, 注意多线程调用时存在缺陷

// 平台应答utc时间 3801
static _INT MsgMng_GetUtcTimeRsp(_UI uiReqId, _VPTR hRoot)
{
    MOS_PARAM_NULL_RETERR(hRoot);

    _UC *pucStrTmp    = MOS_NULL;
    _INT ret          = MOS_ERR;
    _INT iCode        = 0;
    _LLID illSecond   = 0;
    _CTIME_T cNowTime = 0;
    _UC aucMsg[128]   = {0};
    JSON_HANDLE hBody = MOS_NULL;
    ST_CFG_CORE_MNG* pstCoreInfo = Config_GetCoreMng();

    // 收到平台回复后不用主动释放资源，将g_uiReqId置0，
    if (g_uiReqId == uiReqId)
    {
        g_uiReqId = 0;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot, (_UC*)"CODE"), &iCode);
    if (0 == iCode)
    {
        hBody = Adpt_Json_GetObjectItem(hRoot, (_UC*)"BODY");
        if (MOS_OK == Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"Time"), &pucStrTmp))
        {
            illSecond = MOS_ATOLL(pucStrTmp);
            if (illSecond > 0)
            {
                if (ZJ_GetFuncTable()->pfunSetUtcTime)
                {
                    ret = ZJ_GetFuncTable()->pfunSetUtcTime(illSecond);
                    if (MOS_OK != ret)
                    {
                        MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "SetUtcTime(pucStrTmp:%s) err", pucStrTmp);
                    }
                }

                // 判断获取时间与设备时间，相差30分钟，上报云涛
                cNowTime = Mos_Time();
                if (MOS_ABS_NUM((_LLID)cNowTime - illSecond) >= TIME_MAX_BAS)
                {
                    // 上报云涛
                    MOS_SPRINTF(aucMsg, "Large different between server time[%lld] and dev time[%lld], server ip:%s", (_LLID)cNowTime, illSecond, pstCoreInfo->aucHxLinkAddr);
                    CloudStg_UploadLogEx2(MSGMNG_ID_LOG_STR, Mos_GetSessionId(), (_UC *)__FUNCTION__, 0, EN_ALARM_RT_TIME_ABS_TOO_LARGE, aucMsg, MOS_NULL, 1);
                }
            }
            else
            {
                MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "Time is illegal! pucStrTmp = %s", pucStrTmp);
            }
        }
        else
        {
            MOS_LOG_ERR(MSGMNG_ID_LOG_STR, "parse Time failed!");
        }
    }

    MOS_LOG_INF(MSGMNG_ID_LOG_STR, "ogct %u, recv Get Utc rspMsg, code %d, illSecond %lld", uiReqId, iCode, illSecond);

    return MOS_OK;
}

// 从平台（信令服务）获取utc时间 3800
_INT MsgMng_GetUtcTimeFromServer(void)
{
    _INT iRet         = 0;
    _UC aucMethod[64] = {0};
    _UC *pucStrTmp    = MOS_NULL;
    JSON_HANDLE hRoot = MOS_NULL;

    // 平台没有应答时需主动释放资源
    if (0 != g_uiReqId)
    {
        MsgMng_CancleReqMsg(g_uiReqId);
    }

    hRoot = Adpt_Json_CreateObject();
    if (MOS_NULL != hRoot)
    {
        g_uiReqId = Mos_GetSessionId();

        MOS_VSNPRINTF(aucMethod, 8, "%02X%02X", EN_OGCT_METHOD_EXTERNFUNC, EN_OGCT_CFGBUSS_GETUTC);
        Adpt_Json_AddItemToObject(hRoot, (_UC*)"METHOD", Adpt_Json_CreateString(aucMethod)); 
        Adpt_Json_AddItemToObject(hRoot, (_UC*)"SEQID", Adpt_Json_CreateStrWithNum(g_uiReqId)); 

        pucStrTmp = Adpt_Json_Print(hRoot);
        Adpt_Json_Delete(hRoot);

        if (MOS_NULL != pucStrTmp)
        {
            iRet = MsgMng_SendMsg(MSGMNG_CMD_SERVER_ID, g_uiReqId, EN_OGCT_METHOD_EXTERNFUNC, EN_OGCT_CFGBUSS_GETUTC,
            pucStrTmp, MOS_STRLEN(pucStrTmp), MsgMng_GetUtcTimeRsp);

            MOS_LOG_INF(MSGMNG_ID_LOG_STR, "ogct %u, send Get UTC time %s, ret %d", g_uiReqId, pucStrTmp, iRet); 

            Adpt_Json_DePrint(pucStrTmp);

            return MOS_OK;
        }
    }

    // 未请求时置0
    g_uiReqId = 0;

    return MOS_ERR;
}
