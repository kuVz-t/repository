#ifndef _MSGMNG_CMDHDL_H_
#define _MSGMNG_CMDHDL_H_

#ifdef __cplusplus
extern "C" {
#endif
_INT MsgMng_RecvSetClientSdpMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvClientSendSdpMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvP2pStatusMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetReadyConnectMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetOnlineClientMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvClientSdpResp(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvGetTimeZoneMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetTimeZoneMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetSdcardInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvFormatSdcardMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvContrlPtzMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetPtzPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvRebootDevMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvCheckNewVersionMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetCamOsdMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetCamOsdDisplayMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetCamCommonOsdInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetDevFactoryMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetCamStatusMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetImageRotateMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetVideoEncParamMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetPreSetPointMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetCruiseMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetWatchPointMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetAudioParamMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetMicOpenMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetTimePolicyMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetSuperCodesMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvSetLocalRecordPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetAlarmPolicyMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvCtrlKjIoTMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetInIotPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetPtzCheckMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetAwakeTimeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgcCt_RecvAddIotToHubMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetHubIotPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvDelHubIotMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvDelAllHubIotMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetIotsStatusMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetIrModeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetWifiMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetWifiListMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetCurNetInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetCleanServAddrMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetDevNameMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvPlayAlarmFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSwitchDismantableAlarmMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvSetWaitAlarmMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetCamWdrMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetRecordCalenderMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetRecordAxisMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetJpgListMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetJpgCalenderMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetEventCalenderMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetEventAxisMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvAddDevByAPMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvStartUpgradeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvStopUpgradeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvSwitchLensMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetSceneInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetBellQuckReplayMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSwitchBellSoundMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvUpLoadLogFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetLogFileLevelMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetRelayModeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetAutoUpgradeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetSoundListMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvDelSoundFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvPlaySoundFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvDownSoundFileMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetNetworkCheck(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetEventcloud(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvAwakeRelayDevMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvLimitStreamMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetVolumeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetMaxSessionCntMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetDefaultLenIdMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetShotTimeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetInIotsPropMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetFaceInfListMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvGetFaceLableListMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetFaceLableMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvSetFaceInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvDelFaceLableMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvDelFaceInfMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvCreatFaceMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvAddFaceOrLicenseLibMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvDelFaceOrLicenseLibMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvSetHumanCountRegionsMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSetHumanCountParamMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvCreateRealTimeBroadcastMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvCreateScheduleBroadcastMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvCancelScheduleBroadcastMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvGat1400SwitchMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvBusinessStrategyChangeMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvSendIMSCallMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvUploadBusinessCfg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);
_INT MsgMng_RecvCmdNotSupportMsg(_UC *pucPeerId, _UI uiSeqId, _UC ucMsgType, _UC ucMsgId, _VPTR hJsonRoot);

_INT MsgMng_RecvBusinessPolicyChangeMsg(_UC *pucPeerId, _UI uiSeqId, _VPTR hJsonRoot);

_INT MsgMng_RecvStopAlarmRingMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

_INT MsgMng_RecvSetPilotLightStatusMsg(_UC *pucPeerId, _UI uiSeqId, _VPTR hJsonRoot);

// 对设备获取外网IP操作涉及的参数配置（340C）
_INT MsgMng_RecvSetGetOuterIPInfMsg(_UC *pucPeerId, _UI uiSeqId, _VPTR hJsonRoot);
_INT MsgMng_RecvIPv6SwitchMsg(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot);

#ifdef __cplusplus
}
#endif

#endif


