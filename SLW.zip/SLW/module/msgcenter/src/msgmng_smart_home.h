#ifndef _MSGMNG_SMART_HOME_H
#define _MSGMNG_SMART_HOME_H

#ifdef __cplusplus
extern "C" {
#endif
#define  SMART_HOME_HOST_PORT   (9010)
#define  SMART_HOME_HOST        (_UC *)"smarthome.ctdevice.ott4china.com"
#define  SMART_HOME_URL         (_UC *)"/boot"

typedef enum enum_MSGMNG_SMARTHOME_FLAG{
    EN_MSGMNG_SMARTHOME_FLAG_NOTYET  = 0,
    EN_MSGMNG_SMARTHOME_FLAG_DOING,
    EN_MSGMNG_SMARTHOME_FLAG_ERR,
    EN_MSGMNG_SMARTHOME_FLAG_FINSH,
}EN_MSGMNG_SMARTHOME_FLAG;

typedef struct stru_MSGMMG_SMARTHOME_MNG
{
    _UI uiRecvLen;
    _UI uiBufTotalLen;
    _UC *pucRcvBuf;
    _UI uiHttpHandle;
    _UC aucUuid[64];
    _CTIME_T cSmHomeUpTime;
    _UC ucSmartHomeStatus;
}ST_MSGMMG_SMARTHOME_MNG;

ST_MSGMMG_SMARTHOME_MNG *MsgMng_SmartHome_GetMng();

_INT MsgMng_SmartHome_StartUpLoadDevInf(_CTIME_T timeNow);

#ifdef __cplusplus
}
#endif

#endif