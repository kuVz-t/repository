#include "mos.h"
#include "zj_interface.h"
#include "msgmng_api.h"
#include "config_api.h"
#include "http_api.h"
#include "msgmng_cmdserver.h"
#include "msgmng_prv.h"
#include "adpt_json_adapt.h"
#include "msgmng_devplat.h"
#include "http_api.h"
#include "cloudstg_logcode.h"

// 3218
_INT MsgMng_RecvDevPlatLinkEncryChangeNtc(_UC *pucPeerId,_UI uiSeqId,_VPTR hJsonRoot)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _INT iEncType;
    _UC *pStrTmp = MOS_NULL;
    _UC *pucEncKey = MOS_NULL;
    _UC *pucEncLv  = MOS_NULL;
    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_OK;
    } 
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncType"),&iEncType);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncKey"),&pucEncKey);
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"EncLoad"),&pucEncLv);

    if(MOS_STRCMP(pucPeerId, MSGMNG_CMD_SERVER_ID) == 0)
    {
        MsgMng_SetCmdLinkEncrypInf(iEncType,pucEncKey,pucEncLv);
    }
    else
    {
        Http_SetP2PLinkEncryKeyInf(pucPeerId,iEncType,pucEncKey,pucEncLv);
    }

    pStrTmp = MsgMng_BuildCommonNtcRspJson(uiSeqId,EN_OGCT_METHOD_DEVPLAT, EN_OGCT_DEVPLAT_LINK_KEYCHG_NTC_RSP,0);

    MsgMng_SendMsg(pucPeerId,uiSeqId,EN_OGCT_METHOD_DEVPLAT, EN_OGCT_DEVPLAT_LINK_KEYCHG_NTC_RSP,
        pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);
    return MOS_OK;
}


