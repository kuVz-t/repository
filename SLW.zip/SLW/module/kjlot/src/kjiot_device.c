#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "kjiot_device_api.h"
#include "kjiot_device_prv.h"
#include "adpt_json_adapt.h"
#include "record_api.h"
#include "snap_api.h"
#include "cloudstg_api.h"
#include "http_api.h"
#include "msgmng_api.h"
#include "kj_timer.h"
#include "watchdog_api.h"
#include "msgmng_event.h"
#include "cloudstg_type.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "config_prv.h"
#include "config_iotpolicy.h"
#include "kjiot_device_type.h"
#include "config_inneriot.h"
#include "config_ai.h"

#define MAX_PTZEVENT_NUM 100

static _INT g_iCheckSleepTaskFlag = 1; // 设备启动，需检查各定时休眠任务运行状态的标志

static _HSWDWRITE    g_hSwdIoTFeedDog;
static kj_timer_t    g_tIoTFeedDogTimeOut;
/*************************************************************************************
**************************************************************************************/
static ST_CFG_POLICYEVENT_NODE *KjIoT_FindWorkIngEventNode(_UI uiKjIoTType,_LLID lluKjIotId,_UI uiKjIoTEventId,_UI *puiInterval);
/**********************************************************
***********************************************************/
static ST_KJIOT_TASK_MNG g_StIotTaskMng;
/**********************************************************************
**********************************************************************/
ST_KJIOT_TASK_MNG *KjIoT_GetMng()
{
    return &g_StIotTaskMng;
}
/**********************************************************************
**********************************************************************/

/* IOT设备模块初始化 */
_INT KjIoT_init()
{
    if (KjIoT_GetMng()->ucbInit == 1)
    {
        MOS_LOG_WARN(KJIOTLOG_STR,"Already Init");
        return MOS_OK;
    }
    
    MOS_MEMSET(&g_StIotTaskMng, 0, sizeof(g_StIotTaskMng));
    KjIoT_GetMng()->ucFirstFlag = 1;
    Mos_MutexCreate(&KjIoT_GetMng()->hMutex);
    KjIoT_GetMng()->hMsgQueue = Mos_MsgQueueCreate(MOS_FALSE, 50, __FUNCTION__);
    KjIoT_GetMng()->ucbInit = 1;
    MOS_LOG_INF(KJIOTLOG_STR,"init ok msg queue %p",KjIoT_GetMng()->hMsgQueue);
    return MOS_OK;
}

/****************************************************************************
处理函数 查找KjIot设备回调接口链表的节点
*****************************************************************************/
ST_KJIOT_CONTRLDEV_NODE *KjIoT_FindDevContrlNode(_UI uiKjIoTType)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_KJIOT_CONTRLDEV_NODE *pstEventProcNode = MOS_NULL;
    
    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stEventProcList, pstEventProcNode, stIterator)
    {
        if (pstEventProcNode->uiKjIoTType == uiKjIoTType)
        {
            break;
        }
    }

    if (!pstEventProcNode)
    {
        MOS_LOG_ERR(KJIOTLOG_STR,"Can Not Find DevCtrl Node uiKjIoTType:%d !!", uiKjIoTType);
    }
    return pstEventProcNode;
}

// 向KjIot设备回调接口链表 添加KjIot设备回调接口节点
_INT KjIoT_AddDevContrlFun(_UI uiKjIoTType,ZJ_PFUN_AIIOT_OUTPUT pFunContrlDev,ZJ_PFUN_AIIOT_GETINPUT pFunGetInput,
    ZJ_PFUN_AIIOT_CHECKEVENT pFunCheckEvent,ZJ_PFUN_AIIOT_SETPROP pfunAIIoTSetProp)
{
    ST_KJIOT_CONTRLDEV_NODE *pstEventProcNode = KjIoT_FindDevContrlNode(uiKjIoTType); 
    if (pstEventProcNode == MOS_NULL)
    {
        pstEventProcNode = (ST_KJIOT_CONTRLDEV_NODE*)MOS_MALLOCCLR(sizeof(ST_KJIOT_CONTRLDEV_NODE));
        pstEventProcNode->uiKjIoTType = uiKjIoTType;
        MOS_LIST_ADDTAIL(&KjIoT_GetMng()->stEventProcList, pstEventProcNode);
    }
    pstEventProcNode->pfunSetProp    = pfunAIIoTSetProp;
    pstEventProcNode->pFunGetInput   = pFunGetInput;
    pstEventProcNode->pFunCheckEvent = pFunCheckEvent;
    pstEventProcNode->pFunContrlDev  = pFunContrlDev;
    return MOS_OK;
}

// set time
_INT KjIoT_SetTimerInfChange()
{
    KjIoT_GetMng()->uiChargeFlag += (_UI)Mos_Time();
    return MOS_OK;
}

/*************************************************************************
                            添加消息
**************************************************************************/
// 事件上报
_INT KjIoT_SetEvent(_UI uiKjIoTType,_LLID lluKjIotId,_INT iKjIoTEventId,_VPTR pstUsrInf)
{
    ST_KJIOT_SETEVENT_MSG *pstSetEventMsg = MOS_NULL;
    if (KjIoT_GetMng()->ucBRun == 0)
    {
        MOS_LOG_INF(KJIOTLOG_STR, "KjIoT_task Already Stop");
        return MOS_OK;
    }
    // 消息上报内容结构体
    pstSetEventMsg = (ST_KJIOT_SETEVENT_MSG *)MOS_MALLOCCLR(sizeof(ST_KJIOT_SETEVENT_MSG));
    pstSetEventMsg->stMsgHead.usMsgType = EN_KJIOT_MSG_SETEVENT;
    pstSetEventMsg->uiKjIoTType         = uiKjIoTType;
    pstSetEventMsg->lluKjIoTId          = lluKjIotId;
    pstSetEventMsg->iKjIoTEventId       = iKjIoTEventId;
    pstSetEventMsg->pstUsrInf           = pstUsrInf;
    MOS_LOG_INF(KJIOTLOG_STR,"KjIot Event [%u %llu] set event %u Is Coming",uiKjIoTType,lluKjIotId,iKjIoTEventId);

    // 通过消息队列 跳转到事件上报处理函数 传递参数 pstSetEventMsg
    _INT iRet = Mos_MsgQueuePush(KjIoT_GetMng()->hMsgQueue,pstSetEventMsg);
    if (iRet != MOS_OK)
    {
        _UC aucstrTmp[128] = {0};
        MOS_VSNPRINTF(aucstrTmp, sizeof(aucstrTmp), "Alarm Event IoTtype:%u EventId:%d Push MsgQueue Failed", pstSetEventMsg->uiKjIoTType, pstSetEventMsg->iKjIoTEventId);
        CloudStg_UploadLogEx2(MSGMNG_EVENT_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_ALARM_RT_ALARM_QUEUE_FAIL, aucstrTmp,MOS_NULL, 1);
        MOS_FREE(pstSetEventMsg);
        return MOS_ERR;
    }
    return iRet;
}
_INT KjIoT_SetEventEx(_UI uiKjIoTType,_LLID lluKjIotId,_INT iKjIoTEventId,_VPTR pstUsrInf, _BOOL bNeedFreeUsrInf)
{
    ST_KJIOT_SETEVENT_MSG *pstSetEventMsg = MOS_NULL;
    if (KjIoT_GetMng()->ucBRun == 0)
    {
        MOS_LOG_WARN(KJIOTLOG_STR, "KjIoT_task Already Stop");
        return MOS_ERR;
    }
    // 消息上报内容结构体
    pstSetEventMsg = (ST_KJIOT_SETEVENT_MSG *)MOS_MALLOCCLR(sizeof(ST_KJIOT_SETEVENT_MSG));
    pstSetEventMsg->stMsgHead.usMsgType = EN_KJIOT_MSG_SETEVENT;
    pstSetEventMsg->uiKjIoTType         = uiKjIoTType;
    pstSetEventMsg->lluKjIoTId          = lluKjIotId;
    pstSetEventMsg->iKjIoTEventId       = iKjIoTEventId;
    pstSetEventMsg->pstUsrInf           = pstUsrInf;
    pstSetEventMsg->bNeedFreeUsrInf     = bNeedFreeUsrInf;
    MOS_LOG_INF(KJIOTLOG_STR,"KjIot Event [%u %llu] set event %u Is Coming",uiKjIoTType,lluKjIotId,iKjIoTEventId);

    // 通过消息队列 跳转到事件上报处理函数 传递参数 pstSetEventMsg
    _INT iRet = Mos_MsgQueuePush(KjIoT_GetMng()->hMsgQueue,pstSetEventMsg);
    if (iRet != MOS_OK)
    {
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, "AlarmPolicy Push MsgQueue Failed", 1);
        MOS_FREE(pstSetEventMsg);
        return MOS_ERR;
    }
    return iRet;
}
//输入信号的 值
_INT KjIoT_InputValue(_UI uiKjIoTType,_LLID lluKjIotId,_UC *pStrInput)
{
    MOS_PARAM_NULL_RETERR(pStrInput);

    ST_KJIOT_SETVALUE_MSG *pstSetValueMsg = MOS_NULL;
    if (KjIoT_GetMng()->ucBRun == 0)
    {
        MOS_LOG_INF(KJIOTLOG_STR, "KjIoT_task Already Stop");
        return MOS_OK;
    }
    pstSetValueMsg = (ST_KJIOT_SETVALUE_MSG *)MOS_MALLOCCLR(sizeof(ST_KJIOT_SETVALUE_MSG));
    pstSetValueMsg->stMsgHead.usMsgType = EN_KJIOT_MSG_SETVALUE;
    pstSetValueMsg->uiKjIoTType = uiKjIoTType;
    pstSetValueMsg->lluKjIoTId  = lluKjIotId;
    if (MOS_STRLEN(pStrInput) > 0)
    {
        pstSetValueMsg->pStrInput   = (_UC*)MOS_MALLOCCLR(MOS_STRLEN(pStrInput) + 16);
        MOS_MEMCPY(pstSetValueMsg->pStrInput, pStrInput, MOS_STRLEN(pStrInput));
    }

    _INT iRet = Mos_MsgQueuePush(KjIoT_GetMng()->hMsgQueue,pstSetValueMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstSetValueMsg);
        return MOS_ERR;
    }
    return iRet;
}

// 增加一个KjIot设备的节点
_INT KjIoT_AddDevicePlug(_UI uiKjIoTType,_LLID lluKjIotId,ZJ_PFUN_AIIOT_START pfunAIIoTStart, ZJ_PFUN_AIIOT_STOP pfunAIIoTStop)
{
    // 初始化消息队列内容
    ST_KJIOT_ADDPLUG_MSG *pstAddMsg = (ST_KJIOT_ADDPLUG_MSG*)MOS_MALLOCCLR(sizeof(ST_KJIOT_ADDPLUG_MSG));
    pstAddMsg->stMsgHead.usMsgType = EN_KJIOT_MSG_ADDPLUG;
    pstAddMsg->uiKjIoTType = uiKjIoTType;
    pstAddMsg->lluKjIoTId  = lluKjIotId;
    pstAddMsg->pFunStart   = pfunAIIoTStart;
    pstAddMsg->pFunStop    = pfunAIIoTStop;

    // 发送消息队列
    _INT iRet = Mos_MsgQueuePush(KjIoT_GetMng()->hMsgQueue,pstAddMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstAddMsg);
        return MOS_ERR;
    }
    return iRet;
}

/**********************************************************************
aiKjIot plug
***********************************************************************/
// 查找IOT设备节点
static ST_KJIOTPLUG_NODE *KjIoT_FindPlugNode(_UI uiKjIoTType,_LLID lluKjIotId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_KJIOTPLUG_NODE *pstPlugNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stIotPlugList, pstPlugNode, stIterator)
    {
        if ((pstPlugNode->ucUseFlag) && (pstPlugNode->uiKjIoTType == uiKjIoTType) && (pstPlugNode->lluKjIotId == lluKjIotId))
        {
            break;
        }
    }
    return pstPlugNode;
}

// 处理设备节点的状态值
static _VOID KjIoT_ProcPlugStatus(_CTIME_T cNowTime)
{
    _INT iSignalType = 0;
    _UC  aucStrSignal[256] = {0};
    ST_MOS_LIST_ITERATOR stIterator,stIterator1,stIterator2,stIterator3;
    ST_KJIOTPLUG_NODE *pstPlugNode = MOS_NULL;
    ST_CFG_INIOT_NODE *pstIniotNode = MOS_NULL;
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = MOS_NULL;
    ST_KJIOT_ALARM_NODE *pstAlarmNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stIotPlugList, pstPlugNode, stIterator)
    {
        // KjIot设备还没初始化
        if (pstPlugNode->ucStatus == EN_KJIOTPLUG_INIT)
        {
            continue;
        }

        // KjIot设备启动
        if (pstPlugNode->ucStatus == EN_KJIOTPLUG_START)
        {
            pstDevCtrlNode = KjIoT_FindDevContrlNode(pstPlugNode->uiKjIoTType);
            if (pstPlugNode->pFunStart)
            {
                // KjIot设备启动
                pstPlugNode->pFunStart(pstPlugNode->uiKjIoTType,(_UI)pstPlugNode->lluKjIotId);
            }

            pstPlugNode->ucStatus = EN_KJIOTPLUG_RUN;
            FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode, stIterator1)
            {
                if ((pstAlarmNode->iUseFlag) && (pstAlarmNode->lluKjIotId == pstPlugNode->lluKjIotId) && (pstDevCtrlNode)
                    && (pstDevCtrlNode->pfunSetProp) && (pstAlarmNode->uiKjIoTType == pstPlugNode->uiKjIoTType) && (pstAlarmNode->pucProp != MOS_NULL))
                {
                    // 设置KjIot设备属性
                    pstDevCtrlNode->pfunSetProp(pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId,pstAlarmNode->pucProp);
                }
            }

            Config_SetInIotWorkStatus(pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId,1);

            // 内置门铃策略处理
            if (pstPlugNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_DOORBELL)
            {
                pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_BUZZER);

                // 上电运行通知回调自定义铃声文件 - 回调扬声器iot注册的output函数
                if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
                {
                    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode, stIterator1)
                    {
                        if ((pstAlarmNode->iUseFlag) && (pstAlarmNode->lluKjIotId == pstPlugNode->lluKjIotId) 
                         && (pstAlarmNode->uiKjIoTType == pstPlugNode->uiKjIoTType))
                        {
                            ST_CFG_OUTPUT_NODE *pstIotOutPutNode       = MOS_NULL;
                            ST_CFG_POLICYEVENT_NODE *pstIotEventNode   = MOS_NULL;

                            // 遍历事件链表
                            FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList,pstIotEventNode,stIterator1)
                            {
                                // 遍历事件输出链表 // 输出的json
                                FOR_EACHDATA_INLIST(&pstIotEventNode->stOutputList,pstIotOutPutNode,stIterator2)
                                {
                                    if (pstIotOutPutNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_BUZZER)
                                    {
                                        pstDevCtrlNode->pFunContrlDev(pstIotOutPutNode->uiKjIoTType, 0, pstIotOutPutNode->pucParam, MOS_NULL);
                                    }
                                }
                            }
                        }
                    }  
                }
            }

            MOS_LOG_INF(KJIOTLOG_STR,"KjIot %u %llu start ok",pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId);
        }
        // KjIot设备运行中
        if (pstPlugNode->ucStatus == EN_KJIOTPLUG_RUN)
        {
            pstDevCtrlNode = KjIoT_FindDevContrlNode(pstPlugNode->uiKjIoTType);
            if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunGetInput))
            {
                // GetInput回调
                pstDevCtrlNode->pFunGetInput(pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId,aucStrSignal);
            }
            if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunCheckEvent))
            {
                // CheckEvent 回调
                iSignalType = pstDevCtrlNode->pFunCheckEvent(pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId,aucStrSignal);
                // 事件上报
                KjIoT_SetEvent(pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId,iSignalType,MOS_NULL);
            }
        }
        // KjIot设备停止
        if (pstPlugNode->ucStatus == EN_KJIOTPLUG_STOP)
        {
            if (pstPlugNode->pFunStop)
            {
                pstPlugNode->pFunStop(pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId);
            }
            Config_SetInIotWorkStatus(pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId,0);
            pstPlugNode->ucStatus = EN_KJIOTPLUG_INIT;
            MOS_LOG_INF(KJIOTLOG_STR,"KjIot %u %llu stop ok",pstPlugNode->uiKjIoTType,pstPlugNode->lluKjIotId);
        }
    }
    return;
}

/***********************************************************************
报警策略
************************************************************************/
static _INT KjIoT_BegainSyncAlarmList()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1,stIterator2;
    ST_CFG_OUTPUT_NODE *pstIotOutPutNode       = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstIotEventNode   = MOS_NULL;
    ST_KJIOT_ALARM_NODE *pstAlarmNode          = MOS_NULL;

    // 遍历报警策略链表
    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode, stIterator)
    {
        if (pstAlarmNode->iUseFlag == 1)
        {
            pstAlarmNode->iUseFlag = 2;
            // 遍历事件链表
            FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList,pstIotEventNode,stIterator1)
            {
                if (pstIotEventNode->uiUseFlag == 1)
                {
                    pstIotEventNode->uiUseFlag = 2;
                    // 遍历事件输出链表 // 输出的json
                    FOR_EACHDATA_INLIST(&pstIotEventNode->stOutputList,pstIotOutPutNode,stIterator2)
                    {
                        if (pstIotOutPutNode->uiUseFlag == 1)
                        {
                            pstIotOutPutNode->uiUseFlag = 2;
                        }
                    }
                }
            }
        }
    }
    return MOS_OK;
}

// 同步事件链表
static _INT KjIoT_EndSyncAlarmList()
{
    ST_MOS_LIST_ITERATOR stIterator,stIterator1,stIterator2;
    ST_CFG_OUTPUT_NODE *pstIotOutPutNode       = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstIotEventNode   = MOS_NULL;
    ST_KJIOT_ALARM_NODE *pstAlarmNode          = MOS_NULL;

    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode, stIterator)
    {
        if (pstAlarmNode->iUseFlag == 2)
        {
            pstAlarmNode->iChangeFlag = 1;
            pstAlarmNode->uiWeekFlag  = 0;
            pstAlarmNode->iUseFlag = 0;
        }
        FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList,pstIotEventNode,stIterator1)
        {
            if (pstIotEventNode->uiUseFlag == 2)
            {
                pstIotEventNode->uiUseFlag = 0;
            }

            FOR_EACHDATA_INLIST(&pstIotEventNode->stOutputList,pstIotOutPutNode,stIterator2)
            {
                if (pstIotOutPutNode->uiUseFlag == 2)
                {
                    pstIotOutPutNode->uiUseFlag = 0;
                }
            }
        }
    }
    return MOS_OK;
}

// 查找正在触发的事件节点
static ST_CFG_POLICYEVENT_NODE *KjIoT_FindWorkIngEventNode(_UI uiKjIoTType,_LLID lluKjIotId,_UI uiKjIoTEventId,_UI *puiInterval)
{
    MOS_PARAM_NULL_RETNULL(puiInterval);

    _UI uiWeekDay  = 0;
    _UI uiSecInDay = 0;
    _UI uiTimerFlag = 0;
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;
    ST_CFG_POLICYEVENT_NODE *pstPolicyEvent = MOS_NULL;
    ST_KJIOT_ALARM_NODE *pstAlarmNode = MOS_NULL;
    
    // 获取时间
    Mos_GetTimeInDay(Mos_Time(), &uiWeekDay, &uiSecInDay);
    
    // 遍历报警事件信息链表数据
    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode, stIterator)
    {
        if ((pstAlarmNode->iUseFlag) && (pstAlarmNode->iOpenFlag == 1) && (pstAlarmNode->lluKjIotId == lluKjIotId) && (pstAlarmNode->uiKjIoTType == uiKjIoTType))
        {
            // 筛选符合触发事件的条件
            if ((pstAlarmNode->uiSpanFlag == 0) && (uiSecInDay >= pstAlarmNode->uiStartTime) && (uiSecInDay <= pstAlarmNode->uiEndTime))
            {
                uiTimerFlag = 1;
            }
            else if ((pstAlarmNode->uiSpanFlag == 1) && ((uiSecInDay >= pstAlarmNode->uiStartTime) || (uiSecInDay <= pstAlarmNode->uiEndTime)))
            {
                uiTimerFlag = 1;
            }
            else
            {
                uiTimerFlag = 0;
            }
            if (((uiWeekDay & pstAlarmNode->uiWeekFlag) > 0) && (uiTimerFlag == 1))
            {
                // 遍历报警事件触发链表数据
                FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList,pstPolicyEvent,stIterator1)
                {
                    if ((pstPolicyEvent->uiUseFlag) && (pstPolicyEvent->uiKjIoTEventId == uiKjIoTEventId))
                    {
                        *puiInterval = pstAlarmNode->uiInterval;
                        return pstPolicyEvent;
                    }
                }
            }
        }
    }
    return MOS_NULL;
}

// 查找和创建报警事件节点
static ST_KJIOT_ALARM_NODE *KjIoT_FindAndCreatAlarmNode(_UI uiKjIoTType,_LLID lluKjIotId,_UI uiPolicyId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_KJIOT_ALARM_NODE *pstAlarmNode    = MOS_NULL;
    ST_KJIOT_ALARM_NODE *pstAlarmTmpNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode, stIterator)
    {
        if ((pstAlarmNode->iUseFlag) && (pstAlarmNode->lluKjIotId == lluKjIotId)
            && (pstAlarmNode->uiKjIoTType == uiKjIoTType) && (pstAlarmNode->uiPolicyId == uiPolicyId))
        {
            pstAlarmNode->iUseFlag = 1;
            return pstAlarmNode;
        }
        else if (pstAlarmNode->iUseFlag == 0)
        {
            pstAlarmTmpNode = pstAlarmNode;
        }
    }
    if (pstAlarmTmpNode == MOS_NULL)
    {
        pstAlarmTmpNode = (ST_KJIOT_ALARM_NODE*)MOS_MALLOCCLR(sizeof(ST_KJIOT_ALARM_NODE));
        MOS_LIST_ADDTAIL(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmTmpNode);
    }
    pstAlarmTmpNode->uiKjIoTType = uiKjIoTType;
    pstAlarmTmpNode->lluKjIotId  = lluKjIotId;
    pstAlarmTmpNode->uiPolicyId  = uiPolicyId;
    pstAlarmTmpNode->iUseFlag    = 1;

    MOS_LOG_INF(KJIOTLOG_STR,"creat KjIot %u %llu policy ",pstAlarmTmpNode->uiKjIoTType,pstAlarmTmpNode->lluKjIotId);
    return pstAlarmTmpNode;
}

// 查找或创建事件报警的节点
static ST_CFG_POLICYEVENT_NODE *KjIoT_FindAndCreatAlarmEventNode(ST_KJIOT_ALARM_NODE *pstAlarmNode,_UI uiKjIoTEventId)
{
    MOS_PARAM_NULL_RETNULL(pstAlarmNode);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_POLICYEVENT_NODE *pstEventTmpNode = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode    = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator)
    {
        if ((pstEventNode->uiKjIoTEventId == uiKjIoTEventId) && (pstEventNode->uiUseFlag))
        {
            pstEventNode->uiUseFlag = 1;
            return pstEventNode;
        }
        else if (pstEventNode->uiUseFlag == 0)
        {
            pstEventTmpNode = pstEventNode;
        }
    }

    if (pstEventTmpNode == MOS_NULL)
    {
        pstEventTmpNode = (ST_CFG_POLICYEVENT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_POLICYEVENT_NODE));
        MOS_LIST_ADDTAIL(&pstAlarmNode->stEventList, pstEventTmpNode);
    }
    pstEventTmpNode->uiKjIoTEventId = uiKjIoTEventId;
    pstEventTmpNode->uiUseFlag = 1;
    return pstEventTmpNode;
}

// 查找或创建KjIot设备output节点
ST_CFG_OUTPUT_NODE *KjIoT_FindAndCreatOutputNode(ST_CFG_POLICYEVENT_NODE *pstEventNode,_UI uiKjIoTType,_LLID lluKjIotId)
{
    MOS_PARAM_NULL_RETNULL(pstEventNode);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_OUTPUT_NODE  *pstOutputTmpNode = MOS_NULL;
    ST_CFG_OUTPUT_NODE  *pstOutputNode    = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstEventNode->stOutputList,pstOutputNode,stIterator)
    {
        if ((pstOutputNode->uiUseFlag) && (pstOutputNode->uiKjIoTType == uiKjIoTType) && (pstOutputNode->lluKjIotId == lluKjIotId))
        {
            pstOutputNode->uiUseFlag = 1;
            return pstOutputNode;
        }
        else if (pstOutputNode->uiUseFlag == 0)
        {
            pstOutputTmpNode = pstOutputNode;
        }
    }
    
    if (pstOutputTmpNode == MOS_NULL)
    {   
        pstOutputTmpNode = (ST_CFG_OUTPUT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_OUTPUT_NODE));
        MOS_LIST_ADDTAIL(&pstEventNode->stOutputList, pstOutputTmpNode);
    }
    pstOutputTmpNode->lluKjIotId  = lluKjIotId;
    pstOutputTmpNode->uiKjIoTType = uiKjIoTType;
    pstOutputTmpNode->uiUseFlag = 1;
    return pstOutputTmpNode;
}

// 启动加载报警策略
static _INT KjIoT_LoadAlarmPolicy()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST_ITERATOR stIterator1,stIterator2;
    
    // KjIot设备的output属性
    ST_CFG_OUTPUT_NODE *pstIotOutPutNode        = MOS_NULL;
    // EventId事件的策略
    ST_CFG_POLICYEVENT_NODE *pstIotEventNode    = MOS_NULL;
    // IoT设备事件联动策略
    ST_KJIOT_ALARM_NODE *pstIotAlarmNode        = MOS_NULL;

    ST_CFG_OUTPUT_NODE *pstCfgOutPutNode        = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstCfgEventNode    = MOS_NULL;
    // IoT设备联动策略
    ST_CFG_ALARMPOLICY_NODE *pstCfgAlarmNode    = MOS_NULL;

    Config_MutexLock();
    FOR_EACHDATA_INLIST(Config_GetAlarmPolicyList(), pstCfgAlarmNode, stIterator)
    {
        if (pstCfgAlarmNode->uiUseFlag == 0)
        {
            continue;
        }
        pstIotAlarmNode = (ST_KJIOT_ALARM_NODE*)MOS_MALLOCCLR(sizeof(ST_KJIOT_ALARM_NODE));
        MOS_LIST_ADDTAIL(&KjIoT_GetMng()->stAlarmPolicyList, pstIotAlarmNode);
        
        pstIotAlarmNode->uiKjIoTType = pstCfgAlarmNode->uiKjIoTType;
        pstIotAlarmNode->lluKjIotId  = pstCfgAlarmNode->lluKjIotId;
        pstIotAlarmNode->iOpenFlag   = pstCfgAlarmNode->uiOpenFlag;
        pstIotAlarmNode->uiPolicyId  = pstCfgAlarmNode->uiPolicyId;
        pstIotAlarmNode->uiWeekFlag  = pstCfgAlarmNode->uiWeekFlag;
        pstIotAlarmNode->uiStartTime = pstCfgAlarmNode->uiStartTime;
        pstIotAlarmNode->uiEndTime   = pstCfgAlarmNode->uiEndTime;
        pstIotAlarmNode->uiSpanFlag  = pstCfgAlarmNode->uiSpanFlag;
        if (MOS_STRLEN(pstCfgAlarmNode->pucProp) > 0)
        {
            pstIotAlarmNode->uiPropLen = pstCfgAlarmNode->uiPropLen;
            pstIotAlarmNode->pucProp   = MOS_MALLOCCLR(pstCfgAlarmNode->uiPropLen);
            MOS_STRNCPY(pstIotAlarmNode->pucProp, pstCfgAlarmNode->pucProp, pstCfgAlarmNode->uiPropLen);

            if (pstCfgAlarmNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_MOTION )
            {
                JSON_HANDLE hRoot = Adpt_Json_Parse(pstIotAlarmNode->pucProp);
                JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hRoot, (_UC*)"Motion");
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Interval"),(_INT*)&pstIotAlarmNode->uiInterval);
                Adpt_Json_Delete(hRoot);
            }
        }
        FOR_EACHDATA_INLIST(&pstCfgAlarmNode->stEventList,pstCfgEventNode,stIterator1)
        {
            if (pstCfgEventNode->uiUseFlag == 0)
            {
                continue;
            }
            pstIotEventNode = (ST_CFG_POLICYEVENT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_POLICYEVENT_NODE));
            MOS_LIST_ADDTAIL(&pstIotAlarmNode->stEventList, pstIotEventNode);
            pstIotEventNode->uiKjIoTEventId = pstCfgEventNode->uiKjIoTEventId;

            FOR_EACHDATA_INLIST(&pstCfgEventNode->stOutputList,pstCfgOutPutNode,stIterator2)
            {
                if (pstCfgOutPutNode->uiUseFlag == 0)
                {
                    continue;
                }
                pstIotOutPutNode = (ST_CFG_OUTPUT_NODE*)MOS_MALLOCCLR(sizeof(ST_CFG_OUTPUT_NODE));
                MOS_LIST_ADDTAIL(&pstIotEventNode->stOutputList, pstIotOutPutNode);
                
                pstIotOutPutNode->uiKjIoTType = pstCfgOutPutNode->uiKjIoTType;
                pstIotOutPutNode->lluKjIotId  = pstCfgOutPutNode->lluKjIotId;
                if (pstCfgOutPutNode->pucParam != MOS_NULL)
                {
                    pstIotOutPutNode->uiParamLen = pstCfgOutPutNode->uiParamLen; 
                    pstIotOutPutNode->pucParam   = (_UC*)MOS_MALLOCCLR(pstIotOutPutNode->uiParamLen);
                    MOS_STRNCPY(pstIotOutPutNode->pucParam, pstCfgOutPutNode->pucParam,pstIotOutPutNode->uiParamLen);
                }

                pstIotOutPutNode->uiUseFlag = 1;
            }
            pstIotEventNode->uiUseFlag = 1;
        }
        pstIotAlarmNode->iUseFlag = 1;
    }
    Config_MutexUnLock();
    MOS_LOG_INF(KJIOTLOG_STR,"Load Alarm Policy OK");
    return MOS_OK;
}

// 检查报警政策
static _INT KjIoT_CheckAlarmPolicy()
{
    _INT iOpenFlag = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST_ITERATOR stIterator1;
    ST_MOS_LIST_ITERATOR stIterator2;
    
    ST_CFG_INIOT_NODE  *pstInIotCfgNode        = MOS_NULL;      // 内部KjIot设备  MOWTION
    ST_CFG_HUBIOT_NODE *pstHubIotNode          = MOS_NULL;      // 外围KjIot设备  外设
     
    ST_CFG_OUTPUT_NODE *pstIotOutPutNode       = MOS_NULL;      // output 回调参数配置
    ST_CFG_POLICYEVENT_NODE *pstIotEventNode   = MOS_NULL;      // 报警事件的    策略配置
    ST_KJIOT_ALARM_NODE *pstIotAlarmNode       = MOS_NULL;      // KjIot设备的 报警事件配置
    
    ST_CFG_OUTPUT_NODE *pstCfgOutPutNode       = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstCfgEventNode   = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstCfgIotNode     = MOS_NULL;      //

    // 修改报警策略同步开启标志位
    KjIoT_BegainSyncAlarmList();
    // 加互斥锁
    Config_MutexLock();

    // 遍历报警策略的链表
    FOR_EACHDATA_INLIST(Config_GetAlarmPolicyList(), pstCfgIotNode, stIterator)
    {
        // 查找匹配对应的KjIot设备报警策略
        pstIotAlarmNode = KjIoT_FindAndCreatAlarmNode(pstCfgIotNode->uiKjIoTType,pstCfgIotNode->lluKjIotId,pstCfgIotNode->uiPolicyId);

        // 同步配置KjIot设备的报警策略
        if ((pstIotAlarmNode->uiWeekFlag  != pstCfgIotNode->uiWeekFlag)  ||
            (pstIotAlarmNode->uiStartTime != pstCfgIotNode->uiStartTime) ||
            (pstIotAlarmNode->uiEndTime   != pstCfgIotNode->uiEndTime)   ||
            (pstIotAlarmNode->uiSpanFlag  != pstCfgIotNode->uiSpanFlag))
        {
            pstIotAlarmNode->uiSpanFlag  = pstCfgIotNode->uiSpanFlag;       // 是否跨天
            pstIotAlarmNode->uiWeekFlag  = pstCfgIotNode->uiWeekFlag;       // 周几
            pstIotAlarmNode->uiStartTime = pstCfgIotNode->uiStartTime;      // 报警起始时间
            pstIotAlarmNode->uiEndTime   = pstCfgIotNode->uiEndTime;        // 报警结束时间
            MOS_LOG_INF(KJIOTLOG_STR,"KjIot %u %llu timer change",pstCfgIotNode->uiKjIoTType,pstCfgIotNode->lluKjIotId);
        }

        if (MOS_STRCMP(pstIotAlarmNode->pucProp, pstCfgIotNode->pucProp) != 0)   // 报警的属性
        {
            if (pstIotAlarmNode->uiPropLen < pstCfgIotNode->uiPropLen)
            {
                pstIotAlarmNode->uiPropLen  = pstCfgIotNode->uiPropLen;
                MOS_FREE(pstIotAlarmNode->pucProp);
                pstIotAlarmNode->pucProp = MOS_MALLOCCLR(pstIotAlarmNode->uiPropLen);
            }
            if (pstCfgIotNode->uiPropLen)
            {
                MOS_STRNCPY(pstIotAlarmNode->pucProp, pstCfgIotNode->pucProp, pstIotAlarmNode->uiPropLen);
            }

            // MOTION KjIot设备特殊处理 Motion Interval
            if (pstCfgIotNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_MOTION )
            {
                JSON_HANDLE hRoot = Adpt_Json_Parse(pstIotAlarmNode->pucProp);
                JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hRoot, (_UC*)"Motion");
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Interval"),(_INT*)&pstIotAlarmNode->uiInterval);    // 报警间隔
                Adpt_Json_Delete(hRoot);
            }
            
            pstIotAlarmNode->iChangeFlag = 1;   // 策略修改标志
            MOS_LOG_INF(KJIOTLOG_STR,"KjIot %u %llu policyid %u openflag %u prop change",
                pstCfgIotNode->uiKjIoTType,pstCfgIotNode->lluKjIotId,
                pstIotAlarmNode->uiPolicyId,pstIotAlarmNode->iOpenFlag);
        }

        // MOTION KjIot设备 
        if (pstCfgIotNode->uiKjIoTType >= EN_ZJ_AIIOT_TYPE_MOTION)
        {
            // 查找内部KjIot设备节点
            pstInIotCfgNode = Config_FindInnerIotDevice(pstCfgIotNode->uiKjIoTType,pstCfgIotNode->lluKjIotId);
            if (pstInIotCfgNode)
            {
                iOpenFlag = (pstInIotCfgNode->uiOpenFlag & pstCfgIotNode->uiOpenFlag);
            }
        }
        else
        {
            // 查找外部KjIot设备节点
            pstHubIotNode = Config_FindIotForHub(pstCfgIotNode->uiKjIoTType,pstCfgIotNode->lluKjIotId);
            if (pstHubIotNode)
            {
                iOpenFlag = (pstHubIotNode->uiOpenFlag & pstCfgIotNode->uiOpenFlag);
            }
        }

        if (iOpenFlag != pstIotAlarmNode->iOpenFlag )
        {
            pstIotAlarmNode->iOpenFlag = iOpenFlag;
            MOS_LOG_INF(KJIOTLOG_STR,"KjIoT %u %llu open flag %u ",pstCfgIotNode->uiKjIoTType,pstCfgIotNode->lluKjIotId,pstIotAlarmNode->iOpenFlag);
        }
        
        // 遍历事件链表
        FOR_EACHDATA_INLIST(&pstCfgIotNode->stEventList,pstCfgEventNode,stIterator1)
        {
            if (pstCfgEventNode->uiUseFlag == 0)
            {
                continue;
            }
            // 查找匹配对应的报警事件节点
            pstIotEventNode = KjIoT_FindAndCreatAlarmEventNode(pstIotAlarmNode,pstCfgEventNode->uiKjIoTEventId);
            
            // 遍历事件的output链表
            FOR_EACHDATA_INLIST(&pstCfgEventNode->stOutputList,pstCfgOutPutNode,stIterator2)
            {
                if (pstCfgOutPutNode->uiUseFlag == 0)
                {
                    continue;
                }
                // 查找匹配报警事件对应的KjIot设备的output节点
                pstIotOutPutNode = KjIoT_FindAndCreatOutputNode(pstIotEventNode,pstCfgOutPutNode->uiKjIoTType,pstCfgOutPutNode->lluKjIotId);
                if (MOS_STRCMP(pstIotOutPutNode->pucParam, pstCfgOutPutNode->pucParam) != 0)
                {
                    // 更新KjIot设备的output回调的配置 uiParamLen pucParam
                    if (pstIotOutPutNode->uiParamLen < pstCfgOutPutNode->uiParamLen)
                    {
                        MOS_FREE(pstIotOutPutNode->pucParam);
                        pstIotOutPutNode->uiParamLen = pstCfgOutPutNode->uiParamLen;
                        pstIotOutPutNode->pucParam = (_UC*)MOS_MALLOCCLR(pstIotOutPutNode->uiParamLen);
                    }
                    if (pstCfgOutPutNode->uiParamLen > 0)
                    {
                        MOS_STRNCPY(pstIotOutPutNode->pucParam, pstCfgOutPutNode->pucParam, pstCfgOutPutNode->uiParamLen);
                    }
                }
            }
        }
    }

    // 解互斥锁
    Config_MutexUnLock();
    // 修改报警策略同步结束标志位
    KjIoT_EndSyncAlarmList();  

    return MOS_OK;
}

// 处理报警策略中 的motion 开启和关闭,主要是时间段 更新 对于一级KjIot设备 的监控状态 start stop setprop
static _INT KjIoT_ProcAlarmPolicyStatus(_CTIME_T cNowTime)
{
    _INT iFlag = 0;
    _INT iRet  = MOS_ERR;
    _UI  uiWeekDay = 0;
    _UI  uiSeconds = 0;
    _UI  uiInTimerFlag = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_KJIOTPLUG_NODE   *pstPlugNode  = MOS_NULL;
    ST_KJIOT_ALARM_NODE *pstAlarmNode = MOS_NULL;
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = MOS_NULL;
    
    Mos_GetTimeInDay(cNowTime, &uiWeekDay,&uiSeconds);
    
    // 遍历报警策略链表
    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode, stIterator)
    { 
        uiInTimerFlag = 0;
        iFlag = 0;

        // 报警事件在时间策略内
        if ((pstAlarmNode->uiSpanFlag == 0) && (uiSeconds >= pstAlarmNode->uiStartTime) && (uiSeconds < pstAlarmNode->uiEndTime))
        {
            uiInTimerFlag = 1;
        }
        else if (pstAlarmNode->uiSpanFlag == 1)
        {
            if ((uiSeconds >= pstAlarmNode->uiStartTime) || (uiSeconds <= pstAlarmNode->uiEndTime))
            {
                uiInTimerFlag = 1;
            }
        }

        // KjIot设备是否启动
        if ((pstAlarmNode->iOpenFlag == 1) && ((uiWeekDay & pstAlarmNode->uiWeekFlag) > 0) && (uiInTimerFlag == 1)
            && (Config_GetCamaraMng()->uiCamOpenFlag == 1))
        {
            // KjIot设备符合运行条件
            iFlag = 1;
        }

        // 查找匹配KjIot设备节点
        pstPlugNode = KjIoT_FindPlugNode(pstAlarmNode->uiKjIoTType,pstAlarmNode->lluKjIotId);
        if (pstPlugNode != MOS_NULL)
        {
            if ((pstPlugNode->ucStatus == EN_KJIOTPLUG_INIT) && (iFlag == 1))
            {
                // KjIot设备已初始化，符合启动条件 进入启动状态
                pstPlugNode->ucStatus = EN_KJIOTPLUG_START;
                MOS_LOG_INF(KJIOTLOG_STR,"KjIot %u %llu  status turn to start",pstAlarmNode->uiKjIoTType,pstAlarmNode->lluKjIotId);
            }
            else if ((pstPlugNode->ucStatus == EN_KJIOTPLUG_RUN) && (iFlag == 0))
            {
                // KjIot设备已启动 且 不符合运行状态 进入停止状态
                pstPlugNode->ucStatus = EN_KJIOTPLUG_STOP;
                MOS_LOG_INF(KJIOTLOG_STR,"KjIot %u %llu  status turn to stop",pstAlarmNode->uiKjIoTType,pstAlarmNode->lluKjIotId);
            }

            // 查找匹配对应的KjIot设备功能控制节点
            pstDevCtrlNode = KjIoT_FindDevContrlNode(pstAlarmNode->uiKjIoTType);
            
            // KjIot设备处于运行状态， 且有报警触发
            if ((pstPlugNode->ucStatus == EN_KJIOTPLUG_RUN) && (MOS_STRLEN(pstAlarmNode->pucProp) > 0)
                && (pstAlarmNode->iChangeFlag == 1) && (pstDevCtrlNode) && (pstDevCtrlNode->pfunSetProp))
            {
                // 回调KjIot设备的setprop               
                MOS_LOG_INF(KJIOTLOG_STR,"set KjIot %u %llu prop %s",pstAlarmNode->uiKjIoTType,pstAlarmNode->lluKjIotId,pstAlarmNode->pucProp);
                iRet = pstDevCtrlNode->pfunSetProp(pstAlarmNode->uiKjIoTType,pstAlarmNode->lluKjIotId,pstAlarmNode->pucProp);
                if (iRet == MOS_ERR)
                {
                    _UC aucstrTmp[128] = {0};
                    MOS_VSNPRINTF(aucstrTmp, sizeof(aucstrTmp),"set prop failed KjIot %u %llu prop %s",pstAlarmNode->uiKjIoTType,pstAlarmNode->lluKjIotId,pstAlarmNode->pucProp);                    
                    CloudStg_UploadLogEx2(MSGMNG_EVENT_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_ALARM_RT_ALARM_SET_PROP_FAIL, aucstrTmp,MOS_NULL, 1);
                }
            } 
       }
       pstAlarmNode->iChangeFlag = 0; 
    }
    return MOS_OK;
}

// 停止定时任务动作
_VOID KjIoT_StopTimePolicyActions(ST_CFG_TIMEPOLICY_NODE *pstTimePolicyNode)
{
    _UI  uiCtrlType   = 0;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;

    // 遍历定时任务节点的output的Action
    FOR_EACHDATA_INLIST(&pstTimePolicyNode->stOutputList,pstOutputNode,stIterator)
    {
        hRoot = Adpt_Json_Parse(pstOutputNode->pucParam);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),(_INT*)&uiCtrlType); 
        // 定时任务输出的IOT类型
        switch (pstOutputNode->uiKjIoTType)
        {
            // 录像
            case EN_ZJ_AIIOT_TYPE_RECORD:
            {
                #ifndef RECORD_CLOSE
                // 停止定时录像
                RdStg_StopCustom((_UC*)"0",0);
                #endif
                break;
            }
            // 本地抓拍
            case EN_ZJ_AIIOT_TYPE_SNAPSHORT:
            {
                // 停止定时本地抓拍
                Snap_StopAutoSnap(0);
                break;
            }
            // 摄像机，用于定时休眠
            case EN_ZJ_AIIOT_TYPE_CAMERA:
            {
                // 结束定时休眠
                ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(pstOutputNode->uiKjIoTType);
                if (pstDevCtrlNode != MOS_NULL )
                {
                    pstDevCtrlNode->pFunContrlDev(pstOutputNode->uiKjIoTType,pstOutputNode->lluKjIotId,(_UC*)"{\"CtrlType\":\"1\"}",MOS_NULL);
                    // 定时休眠结束后唤醒，上报当前休眠状态 0x3410
                    MsgMng_UploadDevStatus(EN_DEV_STATUS_AWAKE, EN_DEV_STATUS_CHANGE_WAY_TIMER); 
                }
                // 更改摄像机状态配置
                Config_SetCamerOpenFlag(0,1);
                break;
            }
            // 云存录像
            case EN_ZJ_AIIOT_TYPE_CLOUDRECORD:
            {
                _UI uiRecordType = 0,uiOpenFlag = 0,uiStreamId = 0;
                if (Config_GetCloudRecordProp(MOS_NULL,&uiRecordType,&uiStreamId,&uiOpenFlag,MOS_NULL) == MOS_ERR || uiOpenFlag == 0)
                {
                    MOS_LOG_INF(KJIOTLOG_STR,"uiRecordType: %u  uiStreamId: %u  uiOpenFlag: %u", uiRecordType, uiStreamId, uiOpenFlag);
                    break;
                }
                // 停止定时云存录像
                CloudStg_StopAliveUpLoad(0,uiStreamId);
                break;
            }
            // 云存抓拍
            case EN_ZJ_AIIOT_TYPE_CLOUDSNAP:
            {
                // 停止定时云存抓拍
                CloudStg_StopTimerSnap(0);
                break;
            }
            // PTZ云台
            case EN_ZJ_AIIOT_TYPE_PTZ:
            {
                _INT iCtrlType = 0;
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),&iCtrlType);

                // 位置巡航
                if (iCtrlType == EN_PTZ_CONTROL_POSITION_CRUISE)
                {
                    // 停止位置巡航
                    if (ZJ_GetFuncTable()->pfunCruiseStop)
                    {
                        ZJ_GetFuncTable()->pfunCruiseStop();
                    }
                    else
                    {
                        MOS_LOG_WARN(KJIOTLOG_STR, "Device pfunCruiseStop is Null");
                    }
                }
                // 全景巡航
                else if (iCtrlType == EN_PTZ_CONTROL_PANORAMIC_CRUISE)
                {
                    // 停止全景巡航
                    if (ZJ_GetFuncTable()->pfunSmartCruiseStop)
                    {
                        ZJ_GetFuncTable()->pfunSmartCruiseStop();
                    }
                    else
                    {
                        MOS_LOG_WARN(KJIOTLOG_STR, "Device pfunSmartCruiseStop is Null");
                    }
                }

                break;
            }
            // 其他IOT
            default:
            {
                // 结束定时任务时，扬声器不回调 "CtrlType":"0"
                if (pstOutputNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_BUZZER)
                {
                    break;
                }

                // 其他IOT回调output关闭任务
                ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(pstOutputNode->uiKjIoTType);
                if (pstDevCtrlNode != MOS_NULL )
                {
                    ST_ZJ_TRIGGER_INFO stTriggerInf = {0};
                    stTriggerInf.uiIotType   = pstOutputNode->uiKjIoTType;
                    stTriggerInf.lluIotId    = pstOutputNode->lluKjIotId;
                    stTriggerInf.uiEventId   = EN_ZJ_DEFAULT_IOT_EVENTID;
                    // IOT OutPut回调
                    pstDevCtrlNode->pFunContrlDev(pstOutputNode->uiKjIoTType,pstOutputNode->lluKjIotId,(_UC*)"{\"CtrlType\":\"0\"}",&stTriggerInf);
                    MOS_LOG_INF(KJIOTLOG_STR,"KjIottype %u KjIotId:%llu Send Close Msg",pstOutputNode->uiKjIoTType, pstOutputNode->lluKjIotId);
                }
            }
        }
        Adpt_Json_Delete(hRoot);
    }
    return;
}

// 启动定时任务动作
_VOID KjIoT_StartTimePolicyActions(ST_CFG_TIMEPOLICY_NODE *pstTimePolicyNode)
{
    _UI  uiCtrlType   = 0;
    JSON_HANDLE hRoot = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;

    // 遍历定时任务节点的output的Action
    FOR_EACHDATA_INLIST(&pstTimePolicyNode->stOutputList,pstOutputNode,stIterator)
    {
        if (pstOutputNode->uiUseFlag == 0)
        {
            continue;
        }
        hRoot = Adpt_Json_Parse(pstOutputNode->pucParam);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),(_INT*)&uiCtrlType);
        // 定时任务输出的IOT类型
        switch (pstOutputNode->uiKjIoTType)
        {
            // 录像
            case EN_ZJ_AIIOT_TYPE_RECORD:
            {
                #ifndef RECORD_CLOSE
                // 开启定时录像
                RdStg_StartCustom((_UC*)"0",0);
                #endif
                break;
            }
            // 本地抓拍
            case EN_ZJ_AIIOT_TYPE_SNAPSHORT:
            {
                _UI uiPicType = 0;
                _UI uiSnapInterval = 0;
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PicType"),(_INT*)&uiPicType);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Interval"),(_INT*)&uiSnapInterval);
                // 开启定时本地抓拍
                Snap_StartAutoSnap(0,uiSnapInterval,uiPicType);
                break;
            }
            // 摄像机，用于定时休眠
            case EN_ZJ_AIIOT_TYPE_CAMERA:
            {
                // 开启定时休眠
                ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(pstOutputNode->uiKjIoTType);
                if (pstDevCtrlNode != MOS_NULL )
                {
                    pstDevCtrlNode->pFunContrlDev(pstOutputNode->uiKjIoTType,pstOutputNode->lluKjIotId,pstOutputNode->pucParam,MOS_NULL);

                    // 定时休眠进入休眠后，上报当前休眠状态 0x3410
                    MsgMng_UploadDevStatus(EN_DEV_STATUS_SLEEP, EN_DEV_STATUS_CHANGE_WAY_TIMER); 
                }
                // 更改摄像机状态配置
                Config_SetCamerOpenFlag(0,uiCtrlType);
                
                // 开启休眠时，若开了白光灯，则需关闭
                pstDevCtrlNode = MOS_NULL;
                pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_LAMP);
                if (pstDevCtrlNode && pstDevCtrlNode->pFunContrlDev)
                {
                    _UC aucBuff[32] = {0};
                    MOS_VSNPRINTF(aucBuff,sizeof(aucBuff),"{\"CtrlType\":\"0\"}");
                    pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_LAMP,EN_ZJ_DEFAULT_IOTID,aucBuff,MOS_NULL);
                }
                break;
            }
            // 云存录像
            case EN_ZJ_AIIOT_TYPE_CLOUDRECORD:
            {
                _UI uiOpenFlag   = 0;
                _UI uiStreamId   = 0;
                _UI uiRecordType = 0;
                // 获取云存录像的配置参数
                if (Config_GetCloudRecordProp(MOS_NULL,&uiRecordType,&uiStreamId,&uiOpenFlag,MOS_NULL) == MOS_ERR
                    || uiOpenFlag == 0 || uiRecordType != 1)
                {
                    MOS_LOG_INF(KJIOTLOG_STR,"uiRecordType: %u uiStreamId: %u uiOpenFlag: %u", uiRecordType, uiStreamId, uiOpenFlag);
                    break;
                }
                // 开启定时云存录像
                CloudStg_StartAliveUpLoad(0,uiStreamId,86400);
                break;
            }
            // 云存抓拍
            case EN_ZJ_AIIOT_TYPE_CLOUDSNAP:
            {
                _UI uiPicType       = 0;
                _UI uiRecordType    = 0;
                _UI uiSnapInterval  = 0;
                // 获取云存抓拍的配置参数
                if (Config_GetCloudSnapProp(MOS_NULL,&uiRecordType,&uiPicType,&uiSnapInterval,MOS_NULL) == MOS_OK
                    && uiRecordType == 2 )
                {
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PicType"),(_INT*)&uiPicType);
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"Interval"),(_INT*)&uiSnapInterval);
                    if (uiSnapInterval == 0)
                    {
                        uiSnapInterval = 180;
                    }
                    // 停止定时云存抓拍
                    CloudStg_StartTimerSnap(0,uiPicType,uiSnapInterval,1);
                }
                break;
            }
            // PTZ云台
            case EN_ZJ_AIIOT_TYPE_PTZ:
            {
                _INT iCtrlType   = 0;
                _INT iCruiseId   = 0;
                _INT iDwellTime  = 0;
                _INT iPointCount = 0;
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),&iCtrlType);
                // 开启PTZ转动前，先关闭PTZ，防止出错
                if (ZJ_GetFuncTable()->pfunPtzStop)
                {
                    ZJ_GetFuncTable()->pfunPtzStop();
                }

                // 位置巡航
                if (iCtrlType == EN_PTZ_CONTROL_POSITION_CRUISE)
                {
                    ST_CFG_PRESET_POINT stPreSetPoint = {0};
                    ST_CFG_CRUISE_NODE *pstCuriseNode = MOS_NULL;
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CruiseId"),&iCruiseId);
                    // 查找预置位节点
                    pstCuriseNode = Config_FindCuriseNode(0,iCruiseId);
                    if (pstCuriseNode)
                    {
                        _INT iUseCnt    = 0;
                        _INT iCruiseCnt = MOS_LIST_GETCOUNT(&pstCuriseNode->stPointList);
                        ST_MOS_LIST_ITERATOR stIterator;
                        ST_CFG_CRUISE_POINT_NODE   *pstPointNode   = 0;
                        ST_ZJ_CAMERA_CRUISE_PRESET *pstCruisePoint = (ST_ZJ_CAMERA_CRUISE_PRESET*)MOS_MALLOCCLR((iCruiseCnt + 1) * sizeof(ST_ZJ_CAMERA_CRUISE_PRESET));

                        // 遍历预置位节点
                        FOR_EACHDATA_INLIST(&pstCuriseNode->stPointList, pstPointNode, stIterator)
                        {
                            if (pstPointNode->uiUseFlag == 0)
                            {
                                continue;
                            }
                            // 通过ID查找预置点
                            if (Config_FindPresetPointById(0,pstPointNode->uiPresetId,&stPreSetPoint) == MOS_ERR)
                            {
                                continue;
                            }
                            pstCruisePoint[iUseCnt].iDwellTime = pstPointNode->uiDwellTime;
                            pstCruisePoint[iUseCnt].iSpeed     = pstPointNode->uiSpeed;
                            pstCruisePoint[iUseCnt].Idx        = pstPointNode->uiIndex;
                            pstCruisePoint[iUseCnt].iX         = stPreSetPoint.iX;
                            pstCruisePoint[iUseCnt].iY         = stPreSetPoint.iY;
                            iUseCnt++;
                        }
                        // 开启位置巡航
                        if ((ZJ_GetFuncTable()->pfunCruiseStart) && (iUseCnt > 0))
                        {
                            ZJ_GetFuncTable()->pfunCruiseStart(iUseCnt, pstCruisePoint);
                        }
                        else
                        {
                            MOS_LOG_WARN(KJIOTLOG_STR, "Device pfunCruiseStart is Null");
                        }
                        MOS_FREE(pstCruisePoint);
                    }
                }
                // 全景巡航
                else if (iCtrlType == EN_PTZ_CONTROL_PANORAMIC_CRUISE)
                {
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DwellTime"),&iDwellTime);
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PointCount"),&iPointCount);
                    // 开启全景巡航
                    if (ZJ_GetFuncTable()->pfunSmartCruiseStart)
                    {
                        ZJ_GetFuncTable()->pfunSmartCruiseStart(iPointCount, iDwellTime);
                    }
                    else
                    {
                        MOS_LOG_WARN(KJIOTLOG_STR, "Device pfunSmartCruiseStart is Null");
                    }
                }
                break;
            }
            // 其他IOT
            default:
            {
                ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(pstOutputNode->uiKjIoTType);
                if (pstDevCtrlNode != MOS_NULL)
                {
                    ST_ZJ_TRIGGER_INFO stTriggerInf = {0};
                    stTriggerInf.uiIotType   = pstOutputNode->uiKjIoTType;
                    stTriggerInf.lluIotId    = pstOutputNode->lluKjIotId;
                    stTriggerInf.uiEventId   = EN_ZJ_DEFAULT_IOT_EVENTID;
                    // IOT OutPut回调
                    pstDevCtrlNode->pFunContrlDev(pstOutputNode->uiKjIoTType,pstOutputNode->lluKjIotId,pstOutputNode->pucParam,&stTriggerInf);
                }
                MOS_LOG_INF(KJIOTLOG_STR,"KjIottype %u lluKjIotId %llu Send Open Msg:(%s)",pstOutputNode->uiKjIoTType,pstOutputNode->lluKjIotId,pstOutputNode->pucParam);
            }
        }
        Adpt_Json_Delete(hRoot);
    }
    return;
}

// 结束定时休眠
_VOID KjIoT_StopSleepTimePolicy(ST_CFG_TIMEPOLICY_NODE *pstTimePolicyNode)
{
    // 结束定时休眠
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_CAMERA);
    if (pstDevCtrlNode != MOS_NULL )
    {
        pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_CAMERA, EN_ZJ_DEFAULT_IOTID, (_UC*)"{\"CtrlType\":\"1\"}", MOS_NULL);
        // 定时休眠结束后唤醒，上报当前休眠状态 0x3410
        MsgMng_UploadDevStatus(EN_DEV_STATUS_AWAKE, EN_DEV_STATUS_CHANGE_WAY_TIMER); 
    }
    // 更改摄像机状态配置
    Config_SetCamerOpenFlag(0, 1);

    // 修改该定时休眠任务的运行状态 
    Config_SetTimePolicyOutPutWorkFlag(pstTimePolicyNode, EN_TIMEPOLICY_STATUS_NOWORK);

    // 检查各定时休眠任务运行状态的标志置0
    g_iCheckSleepTaskFlag = 0;
    return;
}

// 当设备启动第一次进入定时休眠任务
static _VOID KjIoT_ProcSleepTimePolicy(_CTIME_T cNowTime)
{
    _UI  uiWeekDay     = 0;
    _UI  uiSeconds     = 0;
    _UI  uiLastWeekDay = 0;
    _UI  uiLastSeconds = 0;
    _CTIME_T cLastTime = 0;;
    _UC aucDay[16]     = {0};
    _UC aucLastDay[16] = {0};
    ST_MOS_SYS_TIME stSysTime     = {0};
    ST_MOS_SYS_TIME stLastSysTime = {0};

    _INT iSleepTaskCnt    = 0; // 定时休眠任务数
    _INT iSleepTaskRunCnt = 0; // 定时休眠任务运行数

    ST_MOS_LIST_ITERATOR   stIterator, stIterator1;
    ST_CFG_OUTPUT_NODE     *pstOutputNode     = MOS_NULL;
    ST_CFG_TIMEPOLICY_NODE *pstTimePolicyNode = MOS_NULL;

    // 获取当天的秒数和周几
    Mos_GetSysTime(&stSysTime);
    Mos_GetTimeInDay(cNowTime, &uiWeekDay, &uiSeconds);
    MOS_SPRINTF(aucDay, "%04hu-%02hu-%02hu", stSysTime.usYear, stSysTime.usMonth, stSysTime.usDay);

    // 获取前一天的秒数和周几
    cLastTime = cNowTime - 86400;
    Mos_GetTimeInDay(cLastTime, &uiLastWeekDay, &uiLastSeconds);
    Mos_TimetoSysTime(&cLastTime, &stLastSysTime);
    MOS_SPRINTF(aucLastDay, "%04hu-%02hu-%02hu", stLastSysTime.usYear, stLastSysTime.usMonth, stLastSysTime.usDay);

    // 遍历定时任务节点
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstTimePolicyNode, stIterator)
    {
        if (pstTimePolicyNode->uiUseFlag == 0)   
        {
            continue;
        }

        // 遍历定时任务节点的output的Action
        FOR_EACHDATA_INLIST(&pstTimePolicyNode->stOutputList, pstOutputNode, stIterator1)
        {
            if (pstOutputNode->uiUseFlag == 0)
            {
                continue;
            }

            // 设备启动休眠任务特殊处理
            if (pstOutputNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_CAMERA)
            {
                iSleepTaskCnt++;
                // 该定时休眠任务已执行中
                if (pstTimePolicyNode->uiWorkFlag == EN_TIMEPOLICY_STATUS_WORKING)
                {
                    iSleepTaskRunCnt++;
                    // no span   例如:9:00--10:00
                    if (pstTimePolicyNode->uiSpanFlag == 0)
                    {
                        // 循环定时任务  校验周几
                        if (pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_LOOP)
                        {
                            // 周几对上
                            if ((uiWeekDay & pstTimePolicyNode->uiWeekFlag) > 0)
                            {
                                // 校验开始时间，+TIMEPOLICY_OFFSET_STARTTIME_SEC 为了规避校验时间缺漏问题
                                // 校验结束时间，-TIMEPOLICY_OFFSET_ENDTIME_SEC 为了提前结束定时任务，规避一段定时任务的结束时间跟另一段定时任务的开始时间重复
                                if ((uiSeconds >= (pstTimePolicyNode->uiEndTime   - TIMEPOLICY_OFFSET_ENDTIME_SEC)) || 
                                    (uiSeconds <= (pstTimePolicyNode->uiStartTime + TIMEPOLICY_OFFSET_STARTTIME_SEC)))
                                {
                                    // 结束定时休眠
                                    KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                }
                            }
                            // 周几没对上
                            else
                            {
                                // 结束定时休眠
                                KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                            }
                        }
                        // 一次性定时任务 校验日期
                        else if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_ONETIME) )
                        {
                            // 当天任务
                            if (MOS_STRNCMP(pstTimePolicyNode->aucDay, aucDay, sizeof(pstTimePolicyNode->aucDay)) == 0)
                            {
                                // 校验开始时间，+TIMEPOLICY_OFFSET_STARTTIME_SEC 为了规避校验时间缺漏问题
                                // 校验结束时间，-TIMEPOLICY_OFFSET_ENDTIME_SEC 为了提前结束定时任务，规避一段定时任务的结束时间跟另一段定时任务的开始时间重复
                                if ((uiSeconds >= (pstTimePolicyNode->uiEndTime   - TIMEPOLICY_OFFSET_ENDTIME_SEC)) || 
                                    (uiSeconds <= (pstTimePolicyNode->uiStartTime + TIMEPOLICY_OFFSET_STARTTIME_SEC)))
                                {
                                    // 结束定时休眠
                                    KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                }
                            }
                            // 非当天任务
                            else
                            {
                                // 结束定时休眠
                                KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                            }
                        }
                    }
                    // span 例如:23:00--01:00
                    else if (pstTimePolicyNode->uiSpanFlag == 1)
                    {
                        // 循环定时任务  校验周几
                        if (pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_LOOP)
                        {
                            // 校验时间 在跨天的设置范围内 starttime-86400
                            if ((uiSeconds >= pstTimePolicyNode->uiStartTime) && (uiSeconds <= 86400))
                            {
                                // 周几对上
                                if ((uiWeekDay & pstTimePolicyNode->uiWeekFlag) > 0)
                                {
                                    // 校验开始时间，+TIMEPOLICY_OFFSET_STARTTIME_SEC 为了规避校验时间缺漏问题
                                    if (uiSeconds <= (pstTimePolicyNode->uiStartTime + TIMEPOLICY_OFFSET_STARTTIME_SEC))
                                    {
                                        // 结束定时休眠
                                        KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                    }
                                }
                                // 周几没对上
                                else
                                {
                                    // 结束定时休眠
                                    KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                }
                            }
                            // 校验时间 在跨天的设置范围内 0-starttime
                            else if ((uiSeconds >= 0) && (uiSeconds < pstTimePolicyNode->uiStartTime))
                            {
                                // 周几对上
                                if ((uiLastWeekDay & pstTimePolicyNode->uiWeekFlag) > 0)
                                {
                                    // 校验结束时间，-TIMEPOLICY_OFFSET_ENDTIME_SEC 为了提前结束定时任务，规避一段定时任务的结束时间跟另一段定时任务的开始时间重复
                                    if (uiSeconds >= (pstTimePolicyNode->uiEndTime - TIMEPOLICY_OFFSET_ENDTIME_SEC))
                                    {
                                        // 结束定时休眠
                                        KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                    }
                                }
                                // 周几没对上
                                else
                                {
                                    // 结束定时休眠
                                    KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                }
                            }
                        }
                        // 一次性定时任务 校验日期
                        else if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_ONETIME) )
                        {
                            // 校验时间 在跨天的设置范围内 starttime-86400
                            if ((uiSeconds >= pstTimePolicyNode->uiStartTime) && (uiSeconds <= 86400))
                            {
                                // 当天任务
                                if (MOS_STRNCMP(pstTimePolicyNode->aucDay, aucDay, sizeof(pstTimePolicyNode->aucDay)) == 0)
                                {
                                    // 校验开始时间，+TIMEPOLICY_OFFSET_STARTTIME_SEC 为了规避校验时间缺漏问题
                                    if (uiSeconds <= (pstTimePolicyNode->uiStartTime + TIMEPOLICY_OFFSET_STARTTIME_SEC))
                                    {
                                        // 结束定时休眠
                                        KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                    }
                                }
                                // 非当天任务
                                else
                                {
                                    // 结束定时休眠
                                    KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                }
                            }
                            // 校验时间 在跨天的设置范围内 0-starttime
                            else if ((uiSeconds >= 0) && (uiSeconds < pstTimePolicyNode->uiStartTime))
                            {
                                // 当天任务
                                if (MOS_STRNCMP(pstTimePolicyNode->aucDay, aucLastDay, sizeof(pstTimePolicyNode->aucDay)) == 0)
                                {
                                    // 校验结束时间，-TIMEPOLICY_OFFSET_ENDTIME_SEC 为了提前结束定时任务，规避一段定时任务的结束时间跟另一段定时任务的开始时间重复
                                    if (uiSeconds >= (pstTimePolicyNode->uiEndTime - TIMEPOLICY_OFFSET_ENDTIME_SEC))
                                    {
                                        // 结束定时休眠
                                        KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                    }
                                }
                                // 非当天任务
                                else
                                {
                                    // 结束定时休眠
                                    KjIoT_StopSleepTimePolicy(pstTimePolicyNode);
                                }    
                            }  
                        }
                    }                 
                }
            }
        }
    }

    // 无定时休眠任务
    if (iSleepTaskCnt == 0)
    {
        // 检查各定时休眠任务运行状态的标志置0
        g_iCheckSleepTaskFlag = 0;
        MOS_LOG_INF(KJIOTLOG_STR, "NO Time Sleep Task");
    }
    // 有定时休眠任务
    else
    {
        // 无定时休眠任务运行中
        if (iSleepTaskRunCnt == 0)
        {
            // 检查各定时休眠任务运行状态的标志置0
            g_iCheckSleepTaskFlag = 0;
            MOS_LOG_INF(KJIOTLOG_STR, "NO Time Sleep Run Task");
        }
    }
    return;
}

// 定时任务处理
static _VOID KjIoT_ProcTimePolicy(_CTIME_T cNowTime)
{
    _INT iWorkFlag     = EN_TIMEPOLICY_STATUS_NOWORK;
    _UI  uiWeekDay     = 0;
    _UI  uiSeconds     = 0;
    _INT iChargeFlag   = 0;
    _UI  uiLastWeekDay = 0;
    _UI  uiLastSeconds = 0;
    _CTIME_T cLastTime = 0;;
    _UC aucDay[16]     = {0};
    _UC aucLastDay[16] = {0};
    ST_MOS_SYS_TIME stSysTime     = {0};
    ST_MOS_SYS_TIME stLastSysTime = {0};
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_TIMEPOLICY_NODE *pstTimePolicyNode = MOS_NULL;

    // 3436 定时策略信令下发会触发 KjIoT_SetTimerInfChange 修改 uiChargeFlag
    if (KjIoT_GetMng()->uiChargeFlag != Config_GetSystemMng()->uiChargeFlag)
    {
        KjIoT_GetMng()->uiChargeFlag = Config_GetSystemMng()->uiChargeFlag;
        iChargeFlag = 1;
    }

    // 获取当天的秒数和周几
    Mos_GetSysTime(&stSysTime);
    Mos_GetTimeInDay(cNowTime, &uiWeekDay, &uiSeconds);
    MOS_SPRINTF(aucDay, "%04hu-%02hu-%02hu", stSysTime.usYear, stSysTime.usMonth, stSysTime.usDay);

    // 获取前一天的秒数和周几
    cLastTime = cNowTime - 86400;
    Mos_GetTimeInDay(cLastTime, &uiLastWeekDay, &uiLastSeconds);
    Mos_TimetoSysTime(&cLastTime, &stLastSysTime);
    MOS_SPRINTF(aucLastDay, "%04hu-%02hu-%02hu", stLastSysTime.usYear, stLastSysTime.usMonth, stLastSysTime.usDay);

    // 当系统时间小于2023年8月时，定时任务不生效
    if ((stSysTime.usYear <= 2023) && (stSysTime.usMonth < 8))
    {
        MOS_LOG_INF(KJIOTLOG_STR, "Dev Date Time %d:%d < 2023:8", stSysTime.usYear, stSysTime.usMonth);
        return;
    }

    // 设备启动，需检查各定时休眠任务运行状态
    if (g_iCheckSleepTaskFlag == 1)
    {
        // MOS_LOG_INF(KJIOTLOG_STR, "GO TO ProcSleepTimePolicy");
        KjIoT_ProcSleepTimePolicy(cNowTime);
    }

    // 遍历定时任务链表
    FOR_EACHDATA_INLIST(Config_GetTimePolicyList(), pstTimePolicyNode, stIterator)
    {
        if (((pstTimePolicyNode->uiUseFlag     == 0)  ||                        // 定时策略节点未被使用  (||
             (pstTimePolicyNode->uiOpenFlag    == 0)  ||                        // 定时策略开关关闭      ||
             (KjIoT_GetMng()->ucCamOpenFlag    == 0)) &&                        // 设备休眠中           )&&
             (pstTimePolicyNode->uiWorkFlag == EN_TIMEPOLICY_STATUS_NOWORK))    // 当前定时策略未工作    
        {
            continue;
        }

        // 1 正在工作 0 没有工作
        iWorkFlag = pstTimePolicyNode->uiWorkFlag;

        // 定时策略是否开关打开
        if (pstTimePolicyNode->uiOpenFlag)
        {
            // no span   例如:9:00--10:00
            if ((pstTimePolicyNode->uiSpanFlag  == 0) && 
                (pstTimePolicyNode->uiStartTime <= pstTimePolicyNode->uiEndTime))
            {
                // 校验开始时间，+TIMEPOLICY_OFFSET_STARTTIME_SEC 为了规避校验时间缺漏问题
                if ((uiSeconds >=  pstTimePolicyNode->uiStartTime)  && 
                    (uiSeconds <= (pstTimePolicyNode->uiStartTime + TIMEPOLICY_OFFSET_STARTTIME_SEC)))
                {
                    // 循环定时任务  校验周几
                    if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_LOOP) && 
                        ((uiWeekDay & pstTimePolicyNode->uiWeekFlag) > 0))
                    {
                        // 开始定时任务
                        iWorkFlag = EN_TIMEPOLICY_STATUS_WORKING;
                        // MOS_LOG_INF(KJIOTLOG_STR,"TimePolicyID:%s Name:%s Start NoSpan Loop NowWeek:0x%02x PolicyWeek:0x%02x [Start-End]:[%u:%u] NowTime:%u", 
                        //                             pstTimePolicyNode->aucPolicyId, pstTimePolicyNode->aucPolicyName, uiWeekDay, pstTimePolicyNode->uiWeekFlag,
                        //                             pstTimePolicyNode->uiStartTime, pstTimePolicyNode->uiEndTime, uiSeconds);
                    }
                    // 一次性定时任务 校验日期
                    else if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_ONETIME) && 
                             (MOS_STRNCMP(pstTimePolicyNode->aucDay, aucDay, sizeof(pstTimePolicyNode->aucDay)) == 0))
                    {
                        // 开始定时任务
                        iWorkFlag = EN_TIMEPOLICY_STATUS_WORKING;
                        // MOS_LOG_INF(KJIOTLOG_STR,"TimePolicyID:%s Name:%s Start NoSpan NoLoop NowDay:%s PolicyDay:%s [Start-End]:[%u:%u] NowTime:%u", 
                        //                             pstTimePolicyNode->aucPolicyId, pstTimePolicyNode->aucPolicyName, aucDay, pstTimePolicyNode->aucDay,
                        //                             pstTimePolicyNode->uiStartTime, pstTimePolicyNode->uiEndTime, uiSeconds);
                    }
                }
                // 校验结束时间，-TIMEPOLICY_OFFSET_ENDTIME_SEC 为了提前结束定时任务，规避一段定时任务的结束时间跟另一段定时任务的开始时间重复
                else if (uiSeconds >= (pstTimePolicyNode->uiEndTime - TIMEPOLICY_OFFSET_ENDTIME_SEC))
                {
                    // 循环定时任务  校验周几
                    if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_LOOP) && 
                        ((uiWeekDay & pstTimePolicyNode->uiWeekFlag) > 0))
                    {
                        // 结束定时任务
                        iWorkFlag = EN_TIMEPOLICY_STATUS_NOWORK;
                        // MOS_LOG_INF(KJIOTLOG_STR,"TimePolicyID:%s Name:%s Stop NoSpan Loop NowWeek:0x%02x PolicyWeek:0x%02x [Start-End]:[%u:%u] NowTime:%u", 
                        //                             pstTimePolicyNode->aucPolicyId, pstTimePolicyNode->aucPolicyName, uiWeekDay, pstTimePolicyNode->uiWeekFlag,
                        //                             pstTimePolicyNode->uiStartTime, pstTimePolicyNode->uiEndTime, uiSeconds);
                    }
                    // 一次性定时任务 校验日期
                    else if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_ONETIME) && 
                             (MOS_STRNCMP(pstTimePolicyNode->aucDay, aucDay, sizeof(pstTimePolicyNode->aucDay)) == 0))
                    {
                        // 结束定时任务
                        iWorkFlag = EN_TIMEPOLICY_STATUS_NOWORK;
                        // MOS_LOG_INF(KJIOTLOG_STR,"TimePolicyID:%s Name:%s Stop NoSpan NoLoop NowDay:%s PolicyDay:%s [Start-End]:[%u:%u] NowTime:%u", 
                        //                             pstTimePolicyNode->aucPolicyId, pstTimePolicyNode->aucPolicyName, aucDay, pstTimePolicyNode->aucDay,
                        //                             pstTimePolicyNode->uiStartTime, pstTimePolicyNode->uiEndTime, uiSeconds);
                    }
                }
            }
            // span 例如:23:00--01:00
            else if ((pstTimePolicyNode->uiSpanFlag  == 1) && 
                     (pstTimePolicyNode->uiStartTime >= pstTimePolicyNode->uiEndTime))
            {
                // 校验开始时间，+TIMEPOLICY_OFFSET_STARTTIME_SEC 为了规避校验时间缺漏问题
                if ((uiSeconds >=  pstTimePolicyNode->uiStartTime)  && 
                    (uiSeconds <= (pstTimePolicyNode->uiStartTime + TIMEPOLICY_OFFSET_STARTTIME_SEC)))
                {
                    // 循环定时任务  校验周几
                    if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_LOOP) && 
                        ((uiWeekDay & pstTimePolicyNode->uiWeekFlag) > 0))
                    {
                        // 开始定时任务
                        iWorkFlag = EN_TIMEPOLICY_STATUS_WORKING;
                        // MOS_LOG_INF(KJIOTLOG_STR,"TimePolicyID:%s Name:%s Start Span Loop NowWeek:0x%02x PolicyWeek:0x%02x [Start-End]:[%u:%u] NowTime:%u", 
                        //                             pstTimePolicyNode->aucPolicyId, pstTimePolicyNode->aucPolicyName, uiWeekDay, pstTimePolicyNode->uiWeekFlag,
                        //                             pstTimePolicyNode->uiStartTime, pstTimePolicyNode->uiEndTime, uiSeconds);
                    }
                    // 一次性定时任务 校验日期
                    else if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_ONETIME) && 
                             (MOS_STRNCMP(pstTimePolicyNode->aucDay, aucDay, sizeof(pstTimePolicyNode->aucDay)) == 0))
                    {
                        // 开始定时任务
                        iWorkFlag = EN_TIMEPOLICY_STATUS_WORKING;
                        // MOS_LOG_INF(KJIOTLOG_STR,"TimePolicyID:%s Name:%s Start Span NoLoop NowDay:%s PolicyDay:%s [Start-End]:[%u:%u] NowTime:%u", 
                        //                             pstTimePolicyNode->aucPolicyId, pstTimePolicyNode->aucPolicyName, aucDay, pstTimePolicyNode->aucDay,
                        //                             pstTimePolicyNode->uiStartTime, pstTimePolicyNode->uiEndTime, uiSeconds);
                    }
                }
                // 校验结束时间，-TIMEPOLICY_OFFSET_ENDTIME_SEC 为了提前结束定时任务，规避一段定时任务的结束时间跟另一段定时任务的开始时间重复
                else if (uiSeconds >= (pstTimePolicyNode->uiEndTime - TIMEPOLICY_OFFSET_ENDTIME_SEC))
                {
                    // 循环定时任务  校验周几
                    if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_LOOP) && 
                        ((uiLastWeekDay & pstTimePolicyNode->uiWeekFlag) > 0))
                    {
                        // 结束定时任务
                        iWorkFlag = EN_TIMEPOLICY_STATUS_NOWORK;
                        // MOS_LOG_INF(KJIOTLOG_STR,"TimePolicyID:%s Name:%s Stop Span Loop NowWeek:0x%02x PolicyWeek:0x%02x [Start-End]:[%u:%u] NowTime:%u", 
                        //                             pstTimePolicyNode->aucPolicyId, pstTimePolicyNode->aucPolicyName, uiWeekDay, pstTimePolicyNode->uiWeekFlag,
                        //                             pstTimePolicyNode->uiStartTime, pstTimePolicyNode->uiEndTime, uiSeconds);
                    }
                    // 一次性定时任务 校验日期
                    else if ((pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_ONETIME) && 
                             (MOS_STRNCMP(pstTimePolicyNode->aucDay, aucLastDay, sizeof(pstTimePolicyNode->aucDay)) == 0))
                    {
                        // 结束定时任务
                        iWorkFlag = EN_TIMEPOLICY_STATUS_NOWORK;
                        // MOS_LOG_INF(KJIOTLOG_STR,"TimePolicyID:%s Name:%s Stop Span NoLoop NowDay:%s PolicyDay:%s [Start-End]:[%u:%u] NowTime:%u", 
                        //                             pstTimePolicyNode->aucPolicyId, pstTimePolicyNode->aucPolicyName, aucDay, pstTimePolicyNode->aucDay,
                        //                             pstTimePolicyNode->uiStartTime, pstTimePolicyNode->uiEndTime, uiSeconds);
                    }
                }
            }
        }

        // 判断定时策略是否要操作对象Action
        if (iWorkFlag != pstTimePolicyNode->uiWorkFlag)
        {
            // 定时策略操作对象开始Action
            if (iWorkFlag == EN_TIMEPOLICY_STATUS_WORKING)
            {
                Config_MutexLock();
                Config_SetTimePolicyOutPutWorkFlag(pstTimePolicyNode, EN_TIMEPOLICY_STATUS_WORKING);
                KjIoT_StartTimePolicyActions(pstTimePolicyNode);
                Config_MutexUnLock();
            }
            // 定时策略操作对象停止Action
            else if (iWorkFlag == EN_TIMEPOLICY_STATUS_NOWORK)
            {
                Config_MutexLock();
                Config_SetTimePolicyOutPutWorkFlag(pstTimePolicyNode, EN_TIMEPOLICY_STATUS_NOWORK);
                KjIoT_StopTimePolicyActions(pstTimePolicyNode);
                if ((iChargeFlag == 0) && (pstTimePolicyNode->uiLoopType == EN_TIMEPOLICY_LOOPTYPE_ONETIME))
                {
                    pstTimePolicyNode->uiOpenFlag = 0;  
                }
                Config_MutexUnLock();
            }
        }
    }
    return;
}

// KjIot设备事件处理
static _VOID KjIoT_ProcEvent(ST_KJIOT_SETEVENT_MSG *pstEventMsg)
{
    MOS_PARAM_NULL_NORET(pstEventMsg);

    _UC *pucParam           = (_UC*)"";
    _UC ucOutSignal[256]    = {0};
    _UC ucStrIotType[640]   = {0};
    _UC ucStrIotParam[640]  = {0};
    ST_MOS_LIST_ITERATOR     stIterator;
    ST_CFG_OUTPUT_NODE      *pstOutPutNode      = MOS_NULL;
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode     = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstAlarmEventNode  = MOS_NULL;
    ST_ZJ_TRIGGER_INFO       stTriggerInf       = {0};
    
    // 低电量事件
    if (pstEventMsg->iKjIoTEventId == EN_RFDEV_KJIOTEVENT_LOWPOWER)
    {
        // 设置设备当前电池余量 为 1
        Config_SetIotPowerLevelInHub(pstEventMsg->uiKjIoTType,pstEventMsg->lluKjIoTId,1);
    }
    // 充电完成事件
    else if (pstEventMsg->iKjIoTEventId == EN_RFDEV_KJIOTEVENT_POWEROK)
    {
        // 设置设备当前电池余量 为 100
        Config_SetIotPowerLevelInHub(pstEventMsg->uiKjIoTType,pstEventMsg->lluKjIoTId,100);
    }

    // 查找正在触发得到事件的链表
    pstAlarmEventNode = KjIoT_FindWorkIngEventNode(pstEventMsg->uiKjIoTType ,pstEventMsg->lluKjIoTId,
        pstEventMsg->iKjIoTEventId,&stTriggerInf.uiDuration);
    if (pstAlarmEventNode == MOS_NULL)
    {
        if ((pstEventMsg->bNeedFreeUsrInf) && (pstEventMsg->pstUsrInf))
        {
            MOS_FREE(pstEventMsg->pstUsrInf);
        }        
        MOS_LOG_ERR(KJIOTLOG_STR,"can't find KjIot[%u %llu] eventid %u node",pstEventMsg->uiKjIoTType,pstEventMsg->lluKjIoTId,pstEventMsg->iKjIoTEventId);
        return;
    }

    // 初始化事件信息
    stTriggerInf.uiIotType   = pstEventMsg->uiKjIoTType;
    stTriggerInf.lluIotId    = pstEventMsg->lluKjIoTId;
    stTriggerInf.uiEventId   = pstEventMsg->iKjIoTEventId;
    stTriggerInf.pstHandler  = pstEventMsg->pstUsrInf;
    stTriggerInf.tCreateTime = Mos_Time();

    // 遍历查找对用KjIot设备的output回调
    FOR_EACHDATA_INLIST(&pstAlarmEventNode->stOutputList, pstOutPutNode, stIterator)
    {
        // 判断该KjIot设备是否被添加使用
        if (pstOutPutNode->uiUseFlag == 0)
        {
            continue;
        }
        pstDevCtrlNode = KjIoT_FindDevContrlNode(pstOutPutNode->uiKjIoTType);
        if (pstDevCtrlNode == MOS_NULL)
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "KjIot type %u can't find",pstOutPutNode->uiKjIoTType);
            continue;
        }
        if (pstOutPutNode->pucParam)
        {
            pucParam = pstOutPutNode->pucParam;
        }

        // if((pstOutPutNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_BUZZER) && (pstEventMsg->uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_DOORBELL))
        if (pstEventMsg->uiKjIoTType == EN_ZJ_AIIOT_TYPE_INNER_DOORBELL)
        {
            continue;
        }

        if (EN_ZJ_AIIOT_TYPE_INNER_LAMP == pstOutPutNode->uiKjIoTType)
        {
            _INT        iDNFlag   = 2;  //环境光线默认为夜晚, 1.白天;2.夜晚
            _INT        iCtrlType = 0;
            JSON_HANDLE hRoot     = MOS_NULL;
            ST_KJIOT_CONTRLDEV_NODE *pstDevDnCtrlNode = MOS_NULL;

            // 白光灯事件output过滤触发开关CtrlType
            hRoot = Adpt_Json_Parse(pstOutPutNode->pucParam);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),&iCtrlType);
            Adpt_Json_Delete(hRoot);
            if (iCtrlType == 0)
            {
                continue;
            }
            
            pstDevDnCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_DNSET);
            if (pstDevDnCtrlNode->pFunGetInput)
            {
                pstDevDnCtrlNode->pFunGetInput(EN_ZJ_AIIOT_TYPE_DNSET,0,ucOutSignal);
                
                hRoot = Adpt_Json_Parse(ucOutSignal);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"DNFlag"),&iDNFlag);
                Adpt_Json_Delete(hRoot);
            }

            // 人形侦测关联白光灯事件
            if ((stTriggerInf.uiIotType == EN_ZJ_AIIOT_TYPE_MOTION) && (stTriggerInf.uiEventId == EN_ZJ_MOTION_EVENT_HUMAN))
            {
                // 全彩夜视为自动模式（红外模式为自动模式），并且环境光线不为白天，才输出人形侦测关联的白光灯
                if ((Config_GetCamaraMng()->uiCurIRWorkMode == EN_ZJ_IRMODE_AUTO) && (iDNFlag != 1))
                {
                    // MOS_LOG_INF(KJIOTLOG_STR, "Now lamp workmode is AUTO IRMODE and light is night, so work");
                }
                else
                {
                    MOS_LOG_INF(KJIOTLOG_STR, "Now lamp workmode is not AUTO IRMODE, so don't work");
                    continue;
                }
            }
        }
        else if (EN_ZJ_AIIOT_TYPE_BUZZER == pstOutPutNode->uiKjIoTType) // 扬声器事件output过滤开关CtrlType
        {
            _UI   uiCtrlType    = 0;
            _BOOL bOutputBuzzer = MOS_FALSE;
            JSON_HANDLE hRoot   = MOS_NULL;

            hRoot = Adpt_Json_Parse(pstOutPutNode->pucParam);
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),&uiCtrlType);
            Adpt_Json_Delete(hRoot);

            if (uiCtrlType == 0)
            {
                bOutputBuzzer = MOS_FALSE;
            }
            else if (uiCtrlType == 1)
            {
                bOutputBuzzer = MOS_TRUE;
            }

            if (bOutputBuzzer == MOS_FALSE)
            {
                continue;
            }
        }

        MOS_VSNPRINTF(ucStrIotType, sizeof(ucStrIotType), "%s type:%u flag:%u param:%s", ucStrIotParam, pstOutPutNode->uiKjIoTType, pstDevCtrlNode->uiInTimerCtrl, pucParam);
        MOS_STRNCPY(ucStrIotParam, ucStrIotType, sizeof(ucStrIotParam));
        // MOS_LOG_INF(KJIOTLOG_STR,"output KjIot type %u func %p param %s inTimer flag %u",
            // pstOutPutNode->uiKjIoTType,pstDevCtrlNode->pFunContrlDev,pucParam,pstDevCtrlNode->uiInTimerCtrl);

        // 调用output回调接口
        if (pstDevCtrlNode->pFunContrlDev /*&& pstDevCtrlNode->uiInTimerCtrl == 0*/) // uiInTimerCtrl 并无意义
        {         
            _INT iRet  = MOS_ERR;
            iRet = pstDevCtrlNode->pFunContrlDev(pstOutPutNode->uiKjIoTType,pstOutPutNode->lluKjIotId, pstOutPutNode->pucParam,&stTriggerInf);
            if (iRet == MOS_ERR)
            {
                if (pstOutPutNode->uiKjIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
                {
                    _UC aucstrTmp[128] = {0};
                    MOS_VSNPRINTF(aucstrTmp, sizeof(aucstrTmp), "IoTtype:%u EventId:%u pFunContrlDev failed TOUCH KjIot %u %llu prop %s",
                        stTriggerInf.uiIotType, stTriggerInf.uiEventId, pstOutPutNode->uiKjIoTType,pstOutPutNode->lluKjIotId,pstOutPutNode->pucParam);                   
                    CloudStg_UploadLogEx2(MSGMNG_EVENT_STR, Mos_GetSessionId(), __FUNCTION__, 0, EN_ALARM_RT_POLICY_OUTPUT_FAIL, aucstrTmp,MOS_NULL, 1);
                }
            }
        }
    }

    // 输出到场景 中
    if (pstAlarmEventNode->uiScenceId != 0)
    {
        ST_CFG_SCENEPOLICY_NODE *pstSceneNode = Config_FindScenePolicyNode(pstAlarmEventNode->uiScenceId);
        if (pstSceneNode == MOS_NULL)
        {
            if ((pstEventMsg->bNeedFreeUsrInf) && (pstEventMsg->pstUsrInf))
            {
                MOS_FREE(pstEventMsg->pstUsrInf);
            }
            MOS_LOG_ERR(KJIOTLOG_STR,"END output KjIot %s", ucStrIotType);            
            return;
        }
        FOR_EACHDATA_INLIST(&pstSceneNode->stOutputList, pstOutPutNode, stIterator)
        {
            if (pstOutPutNode->uiUseFlag == 0)
            {
                continue;
            }
            pstDevCtrlNode = KjIoT_FindDevContrlNode(pstOutPutNode->uiKjIoTType);
            if (pstDevCtrlNode == MOS_NULL )
            {
                MOS_LOG_ERR(KJIOTLOG_STR, "sceneid %u KjIot type %u can't find",pstAlarmEventNode->uiScenceId,pstOutPutNode->uiKjIoTType);
                continue;
            }
            MOS_LOG_INF(KJIOTLOG_STR,"sceneid %u output KjIot type %u func %p intimer flag %u",
                pstAlarmEventNode->uiScenceId,pstOutPutNode->uiKjIoTType,pstDevCtrlNode->pFunContrlDev,pstDevCtrlNode->uiInTimerCtrl);
            if ((pstDevCtrlNode->pFunContrlDev) && (pstDevCtrlNode->uiInTimerCtrl == 0))
            {
                _INT iRet  = MOS_ERR;
                iRet = pstDevCtrlNode->pFunContrlDev(pstOutPutNode->uiKjIoTType,pstOutPutNode->lluKjIotId, pstOutPutNode->pucParam,&stTriggerInf);
                if (iRet == MOS_ERR)
                {
                    MOS_LOG_INF(KJIOTLOG_STR, "ScenceId:%u IoTtype:%u EventId:%u pFunContrlDev failed TOUCH KjIot %u %llu prop %s",
                        pstAlarmEventNode->uiScenceId, stTriggerInf.uiIotType, stTriggerInf.uiEventId, pstOutPutNode->uiKjIoTType,pstOutPutNode->lluKjIotId,pstOutPutNode->pucParam);                       
                }
            }
        }
    }
    if ((pstEventMsg->bNeedFreeUsrInf) && (pstEventMsg->pstUsrInf))
    {
        MOS_FREE(pstEventMsg->pstUsrInf);
    }
    MOS_LOG_INF(KJIOTLOG_STR,"END output KjIot %s", ucStrIotType);

    return;
}

// 增加KjIot设备节点
static _VOID KjIoT_ProcAddPlugMsg(ST_KJIOT_ADDPLUG_MSG *pstAddPlugMsg)
{
    MOS_PARAM_NULL_NORET(pstAddPlugMsg);

    ST_MOS_LIST_ITERATOR stIterator;
    ST_KJIOTPLUG_NODE *pstPlugNode = MOS_NULL;
    
    // 遍历KjIot设备链表
    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stIotPlugList, pstPlugNode, stIterator)
    {
        if ((pstPlugNode->uiKjIoTType  == pstAddPlugMsg->uiKjIoTType) && 
            (pstAddPlugMsg->lluKjIoTId == pstAddPlugMsg->lluKjIoTId))
        {
            break;
        }
    }
    if (pstPlugNode == MOS_NULL)
    {
        pstPlugNode = (ST_KJIOTPLUG_NODE*)MOS_MALLOCCLR(sizeof(ST_KJIOTPLUG_NODE));
        pstPlugNode->uiKjIoTType = pstAddPlugMsg->uiKjIoTType;
        pstPlugNode->lluKjIotId  = pstAddPlugMsg->lluKjIoTId;
        MOS_LIST_ADDTAIL(&KjIoT_GetMng()->stIotPlugList, pstPlugNode);
    }
    pstPlugNode->pFunStart = pstAddPlugMsg->pFunStart;
    pstPlugNode->pFunStop  = pstAddPlugMsg->pFunStop;
    pstPlugNode->ucUseFlag      = 1;
    MOS_LOG_INF(KJIOTLOG_STR,"add KjIot device %u %llu",pstAddPlugMsg->uiKjIoTType,pstAddPlugMsg->lluKjIoTId);
    return;
}

// 处理设备信令上下线消息通知
static _INT KjIoT_ProcOnlineStatus(ST_CFG_ONLINESTATUS_MSG *pstOnlineStatusMsg)
{
    if (pstOnlineStatusMsg == MOS_NULL)
    {
        MOS_LOG_ERR(KJIOTLOG_STR,"pstOnlineStatusMsg is NULL!");
        return MOS_ERR;
    }

    KjIoT_GetMng()->iOnlineStatus = (_INT)pstOnlineStatusMsg->uiOnlineStatus;

    // 信令上线
    if (KjIoT_GetMng()->iOnlineStatus == 1)
    {
        // 设备启动信令第一次上线标志
        if (KjIoT_GetMng()->iFirstOnlineFlag == 0)
        {
            MOS_LOG_INF(KJIOTLOG_STR, "Notice IoT Msg Server First Online");
            KjIoT_GetMng()->iFirstOnlineFlag = 1;
        }
    }
    return MOS_OK;
}

// 消息队列处理函数
static _VOID KjIoT_ProcMsg(_VPTR pstMsg)
{
    MOS_PARAM_NULL_NORET(pstMsg);

    ST_MOS_MSGHEAD *pstMsgHead = (ST_MOS_MSGHEAD*)pstMsg;

    // 消息命令类型
    switch (pstMsgHead->usMsgType)
    {
        // 事件上报
        case EN_KJIOT_MSG_SETEVENT:
        {
            // KjIot设备事件处理
            KjIoT_ProcEvent((ST_KJIOT_SETEVENT_MSG*)pstMsg);
            break;
        }
        // set value 值
        case EN_KJIOT_MSG_SETVALUE:
        {
            ST_KJIOT_SETVALUE_MSG *pstSetValueMsg = (ST_KJIOT_SETVALUE_MSG*)pstMsg;
            MOS_FREE(pstSetValueMsg->pStrInput);
            break;
        }
        // 增加KjIot设备节点
        case EN_KJIOT_MSG_ADDPLUG:
        {
            KjIoT_ProcAddPlugMsg((ST_KJIOT_ADDPLUG_MSG*)pstMsg);
            break;
        }
        // 处理设备信令上下线消息通知
        case EN_KJIOT_MSG_ONLINESTATUS:
        {
            // 处理设备信令上下线消息通知
            KjIoT_ProcOnlineStatus((ST_CFG_ONLINESTATUS_MSG*)pstMsg);
            break;
        }
    }
    return;
}

// 处理默认KjIot设备策略 record cloud snap ptz
_VOID KjIoT_ProcDefaultPolicy()
{
    _UI uiRecordType,uiStreamId,uiOpenFlag;
    if (Config_GetInIotMng()->stRecordInf.uiFullFlag == 1)
    {
        #if 1 // FIXME START RECORD
        if (Config_GetInIotMng()->stRecordInf.uiStatus == 0)
        {
            RdStg_SetAllDayRecordFlag(0,1);
            Config_GetInIotMng()->stRecordInf.uiStatus = 1;
        }
        if ((Config_GetCloudRecordProp(MOS_NULL,&uiRecordType,&uiStreamId,&uiOpenFlag,MOS_NULL) == MOS_OK) &&
            (uiOpenFlag == 1) && (uiRecordType == 1) && (Config_GetInIotMng()->stRecordInf.uiCloudAllDayFlag == 0))
        {
            CloudStg_SetAllDayUpLoad(0,1,1);
            Config_GetInIotMng()->stRecordInf.uiCloudAllDayFlag = 1;
        }
        #endif
    }
    else if (Config_GetInIotMng()->stRecordInf.uiFullFlag == 0)
    {
        if (Config_GetInIotMng()->stRecordInf.uiStatus == 1)
        {
            RdStg_SetAllDayRecordFlag(0,0);
            Config_GetInIotMng()->stRecordInf.uiStatus = 0;
        }
        if (Config_GetInIotMng()->stRecordInf.uiCloudAllDayFlag == 1)
        {
            CloudStg_SetAllDayUpLoad(0,1,0);
            Config_GetInIotMng()->stRecordInf.uiCloudAllDayFlag = 0;
        }
    }
    if ((Config_GetInIotMng()->stSnapInf.uiFullFlag == 1) && (Config_GetInIotMng()->stSnapInf.uiStatus == 0))
    {
        Snap_StartAutoSnap(0,Config_GetInIotMng()->stSnapInf.uiInterval,Config_GetInIotMng()->stSnapInf.uiPicType);
        Config_GetInIotMng()->stSnapInf.uiStatus = 1;
    }
    else if ((Config_GetInIotMng()->stSnapInf.uiFullFlag == 0) && (Config_GetInIotMng()->stSnapInf.uiStatus == 1))
    {
        Snap_StopAutoSnap(0);
        Config_GetInIotMng()->stSnapInf.uiStatus = 0;
    }

    if (KjIoT_GetMng()->ucCamOpenFlag != Config_GetCamaraMng()->uiCamOpenFlag)
    {
        // 休眠->唤醒
        if ((KjIoT_GetMng()->ucCamOpenFlag == 0) && (Config_GetCamaraMng()->uiCamOpenFlag == 1))
        {
            // 强制I帧
            if (ZJ_GetFuncTable()->pfunVideoNeedIFrame)
            {
                ZJ_GetFuncTable()->pfunVideoNeedIFrame(0, EN_ZJ_KEYFRAME_QUALITY_NORMAL);
            }
        }
        KjIoT_GetMng()->ucCamOpenFlag = Config_GetCamaraMng()->uiCamOpenFlag;
        RdStg_SetCamOpenFlag(0,KjIoT_GetMng()->ucCamOpenFlag);
        Snap_SetCamOpenFlag(0,KjIoT_GetMng()->ucCamOpenFlag);
        CloudStg_SetCamOpenFlag(KjIoT_GetMng()->ucCamOpenFlag);
        if ((ZJ_GetFuncTable()->pfunPtzStop) && (KjIoT_GetMng()->ucCamOpenFlag == 0))
        {
            ZJ_GetFuncTable()->pfunPtzStop();
        }
        else if (ZJ_GetFuncTable()->pfunPtzStop == MOS_NULL)
        {
            MOS_LOG_ERR(KJIOTLOG_STR,"pfunPtzStop is NULL!");
        }
    }
    
    return;
}

_VOID KjIoT_LogFileRotate(_UC *pucClosedFileName)
{
    MOS_PARAM_NULL_NORET(pucClosedFileName);

    _UC *pucStrTmp = (_UC*)"{\"Errtype\":\"1\",\"Errid\":\"0\"}";
    if (Config_GetDeviceMng()->iLogUpLoadFlag == 0)
    {
        return ;
    }
    if (ZJ_GetFuncTable()->pFunCollectLogFiles)
    {
        _INT iStatus = MOS_ERR;
        iStatus = ZJ_GetFuncTable()->pFunCollectLogFiles((_UC*)"",0,pucStrTmp);
        if (iStatus != MOS_OK)
        {
            _UC  aucUrl[64]          = {0};
            _UC  aucErrorString[128] = {0};
            MOS_SPRINTF(aucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOAD_LOGFILE);
            MOS_SPRINTF(aucErrorString, "Device pFunCollectLogFiles err");
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, iStatus, aucErrorString, 1);
        }
    }
    return ;
}

// 设备启动 部分配置需回调同步到厂商
_INT KjIoT_ProcFirstNtyFlag()
{
    _INT iRet              = MOS_ERR;
    _UC  aucStatusStr[128] = {0};
    // 图像翻转
    if (ZJ_GetFuncTable()->pfunImageInversion)
    {
        iRet = ZJ_GetFuncTable()->pfunImageInversion(Config_GetCamaraMng()->uiCurInversionType);
        if (MOS_ERR == iRet)
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunImageInversion(iValue:%d) err", Config_GetCamaraMng()->uiCurInversionType);
        }
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR, "pfunImageInversion is NULL!");
    }

    // 内置指示灯
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_STATELAMP);
    if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
    {
        MOS_VSNPRINTF(aucStatusStr, sizeof(aucStatusStr), (_UC*)"{\"CtrlType\":\"%d\",\"Flicker\":\"\"}", Config_GetDeviceMng()->iPilotLightStatus);
        // 内置指示灯 的output接口
        if (MOS_OK == pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_STATELAMP, 0, aucStatusStr, NULL))
        {
            MOS_LOG_INF(KJIOTLOG_STR, "Device inner statelamp output OK \r\n");
        }
        else
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "Device inner statelamp output failed \r\n");
        }
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR, "Device inner statelamp not exist \r\n");
    }

    // 红外模式
    if (Config_GetCamaraMng()->uiCurIRWorkMode == EN_ZJ_IRMODE_IR)
    {
        // 查找 内置白光灯 的IOT设备的链表节点
        ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = NULL;

        // 查找  强制白天晚上,和自动(IRcut) 的IOT设备的链表节点
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_DNSET);
        if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
        {
             // 强制白天晚上,和自动 的output接口  IRcut切换
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_DNSET,0,(_UC*)"{\"CtrlType\":\"1\"}",MOS_NULL);
        }

        /* 白光灯回调在红外灯后 */
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_LAMP);
        if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
        {
            // 内置白光灯 的output接口      红外灯
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_LAMP,0,(_UC*)"{\"CtrlType\":\"0\"}",MOS_NULL);
            // if ((pstDevCtrlNode->uiInTimerCtrl & 0x02) > 0) // uiInTimerCtrl 无意义
            // {
            //     pstDevCtrlNode->uiInTimerCtrl ^= 0x02;
            // }
        }
    }
    // 自动模式
    else if (Config_GetCamaraMng()->uiCurIRWorkMode == EN_ZJ_IRMODE_AUTO)
    {
        ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = NULL;
        
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_DNSET);
        if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
        {
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_DNSET,0,(_UC*)"{\"CtrlType\":\"0\"}",MOS_NULL);
        }

        /* 白光灯回调在红外灯后 */
        pstDevCtrlNode  = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_LAMP);
        if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
        {
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_LAMP,0,(_UC*)"{\"CtrlType\":\"0\"}",MOS_NULL);
            // if ((pstDevCtrlNode->uiInTimerCtrl & 0x02) > 0) // uiInTimerCtrl 无意义
            // {
            //     pstDevCtrlNode->uiInTimerCtrl ^= 0x02;
            // }
        } 
    }
    // 全彩模式
    else if (Config_GetCamaraMng()->uiCurIRWorkMode == EN_ZJ_IRMODE_FULLCOLOR)
    {
        ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_DNSET);
        if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
        {
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_DNSET,0,(_UC*)"{\"CtrlType\":\"2\"}",MOS_NULL);
        }
        /* 全彩模式切换时，厂家已经通过红外灯（DN）知道是什么全彩模式，没必要再调用白光灯，去掉 */
        // pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_LAMP);
        // if ((pstDevCtrlNode) && (pstDevCtrlNode->pFunContrlDev))
        // {
        //     pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_LAMP,0,(_UC*)"{\"CtrlType\":\"1\",\"Duration\":\"86400\"}",MOS_NULL);
        //     pstDevCtrlNode->uiInTimerCtrl |= 0x02;
        // }
    }
#if 0   
    if (ZJ_GetFuncTable()->pFunIRLedSwitchCb)
    {
        iRet = ZJ_GetFuncTable()->pFunIRLedSwitchCb(Config_GetCamaraMng()->uiCurIRWorkMode);
        if (MOS_ERR == iRet)
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "Device pFunIRLedSwitchCb(iValue:%d) err", Config_GetCamaraMng()->uiCurIRWorkMode);
        }
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR, "pFunIRLedSwitchCb is NULL!");
    }
#endif

	// 超级编码开关
    if (ZJ_GetFuncTable()->pfunSetSuperCodes)
    {
        iRet = ZJ_GetFuncTable()->pfunSetSuperCodes(Config_GetCamaraMng()->uiSuperCodesStatus);
        if (MOS_OK != iRet)
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunSetSuperCodes(iValue:%d) err", Config_GetCamaraMng()->uiSuperCodesStatus);
        } 
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR, "pfunSetSuperCodes is NULL!");
    }
    // IPv6开关
    if (ZJ_GetFuncTable()->pfunIPv6Switch)
    {
        iRet = ZJ_GetFuncTable()->pfunIPv6Switch(Config_GetCamaraMng()->uiIPv6Switch);
        if (MOS_OK != iRet)
        {
            MOS_LOG_ERR(KJIOTLOG_STR,"Device pfunIPv6Switch(iValue:%d) err", Config_GetCamaraMng()->uiIPv6Switch);
        } 
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR,"pfunIPv6Switch is NULL!");
    }
    // 宽动态WDR
    if (ZJ_GetFuncTable()->pfunSetWideDynamicCam)
    {
        iRet = ZJ_GetFuncTable()->pfunSetWideDynamicCam(Config_GetCamaraMng()->uiWDRFlag);
        if (MOS_ERR == iRet)
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunSetWideDynamicCam(iValue:%d) err", Config_GetCamaraMng()->uiWDRFlag);
        }
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR, "pfunSetWideDynamicCam is NULL!");
    }
    
    MOS_LOG_INF(KJIOTLOG_STR, "OSDSetExpandAbility %u funCustomOSDModeSetting %p funOSDSetting %p", Config_GetCamaraMng()->uiOSDSetExpandAbility, 
                                                            ZJ_GetFuncTable()->pfunCustomOSDModeSetting, ZJ_GetFuncTable()->pfunOSDSetting);
    if ((Config_GetCamaraMng()->uiOSDSetExpandAbility) && (ZJ_GetFuncTable()->pfunCustomOSDModeSetting) && (ZJ_GetFuncTable()->pfunOSDSetting))
    {
        ZJ_GetFuncTable()->pfunCustomOSDModeSetting(Config_GetCamaraMng()->uiOSDCustomMode);

        if (Config_GetCamaraMng()->uiOSDCustomMode == 0)
        {
            // OSD自定义(文本)内容和位置设置
            iRet = ZJ_GetFuncTable()->pfunOSDSetting(Config_GetCamaraMng()->uiOSDPostion, Config_GetCamaraMng()->ucOSDName);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunOSDSetting(OSDPostion:%d, OSDName:%s) err",
                                        Config_GetCamaraMng()->uiOSDPostion, Config_GetCamaraMng()->ucOSDName);
            }
        }
        else
        {
            // 四角水印
            iRet = ZJ_GetFuncTable()->pfunOSDSetting(EN_ZJ_OSD_POSITION_LT, Config_GetCamaraMng()->aucOSDTopLeftName);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunOSDSetting(OSDPostion:%d, OSDName:%s) err",
                                        EN_ZJ_OSD_POSITION_LT, Config_GetCamaraMng()->aucOSDTopLeftName);
            }
            iRet = ZJ_GetFuncTable()->pfunOSDSetting(EN_ZJ_OSD_POSITION_LD, Config_GetCamaraMng()->aucOSDLowerLeftName);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunOSDSetting(OSDPostion:%d, OSDName:%s) err",
                                        EN_ZJ_OSD_POSITION_LD, Config_GetCamaraMng()->aucOSDLowerLeftName);
            }
            iRet = ZJ_GetFuncTable()->pfunOSDSetting(EN_ZJ_OSD_POSITION_RT, Config_GetCamaraMng()->aucOSDTopRightName);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunOSDSetting(OSDPostion:%d, OSDName:%s) err",
                                        EN_ZJ_OSD_POSITION_RT, Config_GetCamaraMng()->aucOSDTopRightName);
            }
            iRet = ZJ_GetFuncTable()->pfunOSDSetting(EN_ZJ_OSD_POSITION_RD, Config_GetCamaraMng()->aucOSDLowerRightName);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunOSDSetting(OSDPostion:%d, OSDName:%s) err",
                                        EN_ZJ_OSD_POSITION_RD, Config_GetCamaraMng()->aucOSDLowerRightName);
            }                                    
        }
    }
    else
    {
        // OSD自定义(文本)内容和位置设置
        if (ZJ_GetFuncTable()->pfunOSDSetting)
        {
            iRet = ZJ_GetFuncTable()->pfunOSDSetting(Config_GetCamaraMng()->uiOSDPostion, Config_GetCamaraMng()->ucOSDName);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunOSDSetting(OSDPostion:%u, OSDName:%s) err",
                                        Config_GetCamaraMng()->uiOSDPostion, Config_GetCamaraMng()->ucOSDName);
            }
        }
        else
        {
            MOS_LOG_ERR(KJIOTLOG_STR,"pfunOSDSetting is NULL!");
        }
    }

    MOS_LOG_INF(KJIOTLOG_STR, "OSDCommonSetAbility %u pFunOSDCommonSetting %p", 
                Config_GetCamaraMng()->uiOSDCommonSetAbility, ZJ_GetFuncTable()->pFunOSDCommonSetting);
    if ((Config_GetCamaraMng()->uiOSDCommonSetAbility) && (ZJ_GetFuncTable()->pFunOSDCommonSetting))
    {
        // 默认(时间)水印(位置，格式)设置
        if (ZJ_GetFuncTable()->pFunOSDCommonSetting)
        {
            iRet = ZJ_GetFuncTable()->pFunOSDCommonSetting(Config_GetCamaraMng()->uiOSDCommonPosition, Config_GetCamaraMng()->uiOSDCommonFormat);
            if (MOS_ERR == iRet)
            {
                MOS_LOG_ERR(KJIOTLOG_STR, "Device pFunOSDCommonSetting(OSDCommonPosition:%u, OSDCommonFormat:%u) err",
                                        Config_GetCamaraMng()->uiOSDCommonPosition, Config_GetCamaraMng()->uiOSDCommonFormat);
            }
        }
        else
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "pFunOSDCommonSetting is NULL!");
        }
    }

#if 0 // 由于sdk3.0默认(时间)/自定义(文本)水印开关默认配置为0，3.0升级到4.0开机回调厂商会存在配置问题，因此屏蔽该开机回调代码
    // 是否显示默认(时间)水印
    if (ZJ_GetFuncTable()->pFunCtrlTimeOsd)
    {
        iRet = ZJ_GetFuncTable()->pFunCtrlTimeOsd(Config_GetCamaraMng()->uiOSDCommonSwitch);
        if (MOS_ERR == iRet)
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "Device pFunCtrlTimeOsd(OSDCommonSwitch:%u err", Config_GetCamaraMng()->uiOSDCommonSwitch);
        }
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR,"pFunCtrlTimeOsd is NULL!");
    }

    // 是否显示自定义(文本)水印
    if (ZJ_GetFuncTable()->pFunCtrlCustomOsd)
    {
        iRet = ZJ_GetFuncTable()->pFunCtrlCustomOsd(Config_GetCamaraMng()->uiOSDCustomSwitch);
        if (MOS_ERR == iRet)
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "Device pFunCtrlCustomOsd(OSDCustomSwitch:%u err", Config_GetCamaraMng()->uiOSDCustomSwitch);
        }
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR,"pFunCtrlCustomOsd is NULL!");
    }
#endif

#if 1
    // 人流量统计开关、统计间隔
    if (ZJ_GetFuncTable()->pfunSetHumCountParam)
    {
    
        MOS_LOG_INF(KJIOTLOG_STR, "iHumanCountFlag:%d   iHumanCountInterval = %d", Config_GetAIMng()->iHumanCountFlag,Config_GetAIMng()->iHumanCountInterval);
        iRet = ZJ_GetFuncTable()->pfunSetHumCountParam(Config_GetAIMng()->iHumanCountFlag, Config_GetAIMng()->iHumanCountInterval);
        if (MOS_ERR == iRet)
        {
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, "HumanCount pfunSetHumCountParam Set Failed", 1);
            MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunSetHumCountParam(HumanCountFlag:%d, HumanCountFlag:%d) err", Config_GetAIMng()->iHumanCountFlag, Config_GetAIMng()->iHumanCountInterval);
        }
    }
    else
    {
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, "HumanCount pfunSetHumCountParam not registered", 1);
        MOS_LOG_ERR(KJIOTLOG_STR, "pfunSetHumCountParam is NULL!");
    }

    // 人流量统计坐标设置
    if (ZJ_GetFuncTable()->pfunSetHumCountRegions)
    {
        _INT i = 0;
        _UC *pstrRegions  = MOS_NULL;
        JSON_HANDLE hBody = MOS_NULL;
        JSON_HANDLE hHumanCountRegionArry       = MOS_NULL;
        JSON_HANDLE hHumanCountRegionArryObject = MOS_NULL;
        
        hBody = Adpt_Json_CreateObject();
        hHumanCountRegionArry = Adpt_Json_CreateArray();
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Regions",hHumanCountRegionArry);  
        for (i = 0; i < 4; i++)
        {
            hHumanCountRegionArryObject = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hHumanCountRegionArry,hHumanCountRegionArryObject);
            Adpt_Json_AddItemToObject(hHumanCountRegionArryObject,(_UC*)"x",Adpt_Json_CreateNumber(Config_GetAIMng()->stHumanCountRegion[0].iX[i]));
            Adpt_Json_AddItemToObject(hHumanCountRegionArryObject,(_UC*)"y",Adpt_Json_CreateNumber(Config_GetAIMng()->stHumanCountRegion[0].iY[i]));
        }

        JSON_HANDLE hRegionsArry = Adpt_Json_GetObjectItem(hBody,(_UC*)"Regions");
        if (hRegionsArry == MOS_NULL)
        {
            Adpt_Json_Delete(hBody);
            MOS_LOG_ERR(KJIOTLOG_STR, "hRegionsArry == MOS_NULL");
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, "HumanCount Check The Regions Is Null", 1);
            return MOS_ERR;
        }

        pstrRegions = Adpt_Json_Print(hRegionsArry);
        if (pstrRegions == MOS_NULL)
        {
            Adpt_Json_Delete(hBody);
            MOS_LOG_ERR(KJIOTLOG_STR, "pstrRegions == MOS_NULL");
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, "HumanCount Check The Regions Is Error", 1);
            return MOS_ERR;
        }

        MOS_LOG_INF(KJIOTLOG_STR, "pstrRegions = %s", pstrRegions);
        iRet = ZJ_GetFuncTable()->pfunSetHumCountRegions(pstrRegions);
        if (MOS_ERR == iRet)
        {
            MOS_LOG_ERR(KJIOTLOG_STR, "Device pfunSetHumCountRegions(strRegions:%s) err", pstrRegions);            
            CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, "HumanCount pfunSetHumCountRegions Set Failed", 1);
        }
        Adpt_Json_Delete(hBody);
        MOS_FREE(pstrRegions);
        pstrRegions = MOS_NULL;
    }
    else
    {    
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, "HumanCount pfunSetHumCountRegions not registered", 1);
        MOS_LOG_ERR(KJIOTLOG_STR, "pfunSetHumCountRegions is NULL!");
    }
#endif

    return MOS_OK;
}

_VOID KjIoT_CheckAndFeedDog()
{
    // 软看门狗喂狗
    if (getDiffTimems(&g_tIoTFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
    {            
        Swd_AppThreadFeedDog(g_hSwdIoTFeedDog);
        getDiffTimems(&g_tIoTFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
    }
}

/**
 * PTZ联动信息加入链表
*/
_VOID KjIOT_AddPtzEventNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_KJIOT_PTZEVENT_NODE *pstPtzEvent = MOS_NULL;
    Mos_MutexLock(&KjIoT_GetMng()->hMutex);
    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stPtzEventList, pstPtzEvent, stIterator)
    {
        if (pstPtzEvent->ucUseFlag == 0)
        {
            pstPtzEvent->ucUseFlag = 1;
            Mos_MutexUnLock(&KjIoT_GetMng()->hMutex);
            return;
        }
    }
    Mos_MutexUnLock(&KjIoT_GetMng()->hMutex);

    /*限制结点不能超过100个*/
    if (MOS_LIST_GETCOUNT(&KjIoT_GetMng()->stPtzEventList) > MAX_PTZEVENT_NUM)
    {
        MOS_LOG_ERR(KJIOTLOG_STR, "PtzEventList allocate too many");
        return;
    }

    pstPtzEvent = (ST_KJIOT_PTZEVENT_NODE*)MOS_MALLOCCLR(sizeof(ST_KJIOT_PTZEVENT_NODE));
    if (pstPtzEvent)
    {
        pstPtzEvent->ucUseFlag = 1;
        Mos_MutexLock(&KjIoT_GetMng()->hMutex);
        MOS_LIST_ADDTAIL(&KjIoT_GetMng()->stPtzEventList, pstPtzEvent);
        Mos_MutexUnLock(&KjIoT_GetMng()->hMutex);
        MOS_LOG_INF(KJIOTLOG_STR, "Device Link Alarm Add List");
    }
    else
    {
        MOS_LOG_ERR(KJIOTLOG_STR, "MOS_MALLOCCLR Error");
    }
}

/**
 * 轮询检查云台状态；静止时上报1022事件
*/
static _VOID KjIOT_ProcPtzEvent()
{
    _INT iPtzStatus = 0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_KJIOT_PTZEVENT_NODE *pstPtzEvent = MOS_NULL;

    if (MOS_LIST_GETCOUNT(&KjIoT_GetMng()->stPtzEventList) > 0)
    {
        Mos_MutexLock(&KjIoT_GetMng()->hMutex);
        FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stPtzEventList, pstPtzEvent, stIterator)
        {
            if (pstPtzEvent->ucUseFlag == 1)
            {
                if (ZJ_GetFuncTable()->pfunPtzStatus)
                {
                    ZJ_GetFuncTable()->pfunPtzStatus(&iPtzStatus);
                    if (iPtzStatus == 0)
                    {
                        pstPtzEvent->ucUseFlag = 0;
                        ZJ_IoTEventInPut(EN_ZJ_AIIOT_TYPE_LINKAGEALARM, EN_ZJ_DEFAULT_IOTID, 0);
                    }
                }
                else
                {
                    pstPtzEvent->ucUseFlag = 0;
                    MOS_LOG_ERR(KJIOTLOG_STR,"pfunPtzStatus is NULL");
                }
            }
        }
        Mos_MutexUnLock(&KjIoT_GetMng()->hMutex);
    }
}

// 检测支持新人脸，清除旧人脸能力与prop
static _VOID KjIoT_NewFaceCheck()
{
    if (1 == Config_GetNewFaceAbility())
    {
        // 存在新人脸，则把旧人脸能力值置0
        Config_SetCommonAiAbility("AiFaceDiscernAbility", 0);

        // 存在新人脸，则删除IOT 1000属性Face字段
        Config_DelIoTProp(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, 0, NULL, "Face");
        Config_DelAlarmPolicyProp(EN_ZJ_AIIOT_TYPE_MOTION, EN_ZJ_DEFAULT_IOTID, 0, NULL, "Face");
    }
}

// KjIot任务轮询
_INT KjIoT_TaskLoop(_VPTR pParam)
{
    _VPTR pstMsg;
    _UI uiLoopCnt = 0;
    _CTIME_T cNowTime = Mos_Time();

    // IOT模块注册内部看门狗
    g_hSwdIoTFeedDog = Swd_AppThreadRegist(IOT_APP, FEED_DOG_SUPER_MAX_TIMESEC);
    kj_timer_init(&g_tIoTFeedDogTimeOut);
    getDiffTimems(&g_tIoTFeedDogTimeOut, 1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        
    while (KjIoT_GetMng()->ucBRun)
    {
        // 软看门狗检测喂狗
        KjIoT_CheckAndFeedDog();

        uiLoopCnt++;
        // 获取消息队列里消息的个数
        if (Mos_MsgQueueGetCount(KjIoT_GetMng()->hMsgQueue) > 0)
        {
            // 接收消息队列
            pstMsg = Mos_MsgQueuePop(KjIoT_GetMng()->hMsgQueue);
            // 处理消息队列 -- 报警事件上报  设置KjIot Value值  添加KjIot设备
            KjIoT_ProcMsg(pstMsg);
            // 释放消息队列
            MOS_FREE(pstMsg);
        }

        // IOT模块是否第一次进入循环
        if (KjIoT_GetMng()->ucFirstFlag)
        {
            KjIoT_GetMng()->ucFirstFlag = 0;
            // 设备启动 部分配置需回调同步到厂商
            KjIoT_ProcFirstNtyFlag();
        }
        
        // 处理IOT节点，或者处理IOT告警事件
        if ((uiLoopCnt % 20) == 0) // 1s
        {
            cNowTime = Mos_Time();                  // 获取设备系统时间
            KjIoT_CheckAlarmPolicy();               // 同步更新配置文件的 报警策略配置和output属性配置       
            KjIoT_ProcAlarmPolicyStatus(cNowTime);  // 检测 对于一级KjIot设备 的监控状态 start stop setprop
            KjIoT_ProcPlugStatus(cNowTime);         // 处理 对于一级KjIot设备 的监控状态 start stop
            KjIoT_ProcDefaultPolicy();              // 处理默认KjIot设备策略 record cloud snap ptz
            KjIOT_ProcPtzEvent();                   // 处理ptzType:4事件上报
        }

        // 处理定时任务节点
        if ((uiLoopCnt % 5) == 0) // 250ms
        {
            // 设备启动信令第一次上线 才开始定时任务的处理
            if (KjIoT_GetMng()->iFirstOnlineFlag == 1)
            {
                cNowTime = Mos_Time();              // 获取设备系统时间
                KjIoT_ProcTimePolicy(cNowTime);     // 检查 定时任务处理 符合的回调二级KjIot设备的output接口 
            }
        }

        Mos_Sleep(50);
    }

    // IOT模块注销内部看门狗
    Swd_AppThreadUnRegist(g_hSwdIoTFeedDog);
    MOS_LOG_INF(KJIOTLOG_STR,"IOT task out");
    return MOS_OK;
}

// 启动KjIot设备模块
_INT KjIoT_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_HIGH_SIZE;
    if (ZJ_GetFuncTable()->pfunSetEventPushFlag != MOS_NULL)
    {
        _UI uiMotionFlag = 0;
        _LLID lluOutKjIoTId = 0;
        _UI uiHumanFlag = 0;
        ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
        ST_CFG_POLICYEVENT_NODE *pstEventNode = MOS_NULL;
        ST_CFG_OUTPUT_NODE *pstOutputNode = MOS_NULL;
        JSON_HANDLE hRoot = MOS_NULL;
        pstAPolicyNode = Config_FindAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION, 0, 100);
        if (pstAPolicyNode != MOS_NULL)
        {
            pstEventNode = Config_FindAlarmEventNode(pstAPolicyNode,EN_ZJ_MOTION_EVENT_MOTION);
            if (pstEventNode != MOS_NULL)
            {
                pstOutputNode = Config_FindAndCreatOutNode(&pstEventNode->stOutputList,EN_ZJ_AIIOT_TYPE_EVENT,lluOutKjIoTId);
                hRoot = Adpt_Json_Parse(pstOutputNode->pucParam);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PushFlag"),(_INT*)&uiMotionFlag);
            }

            pstEventNode = Config_FindAlarmEventNode(pstAPolicyNode,EN_ZJ_MOTION_EVENT_HUMAN);
            if (pstEventNode != MOS_NULL)
            {
                pstOutputNode = Config_FindAndCreatOutNode(&pstEventNode->stOutputList,EN_ZJ_AIIOT_TYPE_EVENT,lluOutKjIoTId);
                hRoot = Adpt_Json_Parse(pstOutputNode->pucParam);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PushFlag"),(_INT*)&uiHumanFlag); 
            }
            Adpt_Json_Delete(hRoot);
        }

        ZJ_GetFuncTable()->pfunSetEventPushFlag(uiMotionFlag, uiHumanFlag);
    }

    if (KjIoT_GetMng()->ucBRun == 1)
    {
        MOS_LOG_WARN(KJIOTLOG_STR,"Already Start");
        return MOS_OK;
    }

    // 检查新人脸是否存在, 存在则屏蔽旧人脸
    KjIoT_NewFaceCheck();

    KjIoT_LoadAlarmPolicy();     // 加载报警策略   
    KjIoT_GetMng()->uiChargeFlag = Config_GetSystemMng()->uiChargeFlag; // 设置收费标志

    // 设备启动 加载启动前的白光灯或者红外灯和irCut的切换(日夜模式)配置
    Mos_LogAddRotateNtyFun(KjIoT_LogFileRotate);

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    KjIoT_GetMng()->ucBRun = 1;  // 启动标志
    // KjIot任务轮询
    if (Mos_ThreadCreate((_UC*)"KJIOT_MODULE",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                      KjIoT_TaskLoop,MOS_NULL, MOS_NULL,&KjIoT_GetMng()->hThread) == MOS_ERR)
    {
        KjIoT_GetMng()->ucBRun = 0;
        return MOS_ERR;
    }
    
    return MOS_OK;
}

// KjIot设备模块停止
_INT KjIoT_Stop()
{
    if (KjIoT_GetMng()->ucBRun == 0)
    {
        MOS_LOG_WARN(KJIOTLOG_STR,"Already Stop");
        return MOS_OK;
    }
    KjIoT_GetMng()->ucBRun = 0;
    
    ST_MOS_LIST_ITERATOR stIterator,stIterator1,stIterator2;
    ST_CFG_OUTPUT_NODE *pstIotOutPutNode      = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode     = MOS_NULL;
    ST_KJIOT_ALARM_NODE *pstAlarmNode = MOS_NULL;
    MOS_LIST_RMVALL(&KjIoT_GetMng()->stIotPlugList, MOS_TRUE);
    MOS_LIST_RMVALL(&KjIoT_GetMng()->stEventProcList, MOS_TRUE);
    MOS_LIST_RMVALL(&KjIoT_GetMng()->stPtzEventList, MOS_TRUE);
    FOR_EACHDATA_INLIST(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode, stIterator)
    {
        FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList,pstEventNode,stIterator1)
        {
            FOR_EACHDATA_INLIST(&pstEventNode->stOutputList,pstIotOutPutNode,stIterator2)
            {
                MOS_LIST_RMVNODE(&pstEventNode->stOutputList,pstIotOutPutNode);
                MOS_FREE(pstIotOutPutNode->pucParam);
                MOS_FREE(pstIotOutPutNode);
            }
            MOS_LIST_RMVNODE(&pstAlarmNode->stEventList,pstEventNode);
            MOS_FREE(pstEventNode);
        }
        MOS_LIST_RMVNODE(&KjIoT_GetMng()->stAlarmPolicyList, pstAlarmNode);
        MOS_FREE(pstAlarmNode->pucProp);
        MOS_FREE(pstAlarmNode);
    }
    Mos_ThreadDelete(KjIoT_GetMng()->hThread);
    return MOS_OK;
}

// KjIot设备模块内存释放
_INT KjIoT_Destroy()
{
    if(KjIoT_GetMng()->ucbInit == 0)
    {
        MOS_LOG_WARN(KJIOTLOG_STR,"Already Destroy");
        return MOS_OK;
    }
    
    _VPTR pstMsg;
    while(Mos_MsgQueueGetCount(KjIoT_GetMng()->hMsgQueue) > 0)
    {
        pstMsg = Mos_MsgQueuePop(KjIoT_GetMng()->hMsgQueue);
        MOS_FREE(pstMsg);
    }
    Mos_MsgQueueDelete(KjIoT_GetMng()->hMsgQueue);
    KjIoT_GetMng()->hMsgQueue = MOS_NULL;
    Mos_MutexDelete(&KjIoT_GetMng()->hMutex);
    KjIoT_GetMng()->ucbInit = 0;
    MOS_LOG_INF(KJIOTLOG_STR,"Ai_Iot Task Destroy ok");
    return MOS_OK;
}


