#ifndef KJIOT_DEVICE_TYPE_H
#define KJIOT_DEVICE_TYPE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum  enum_RfDev_KjIotEvent
{
    EN_RFDEV_KJIOTEVENT_NO        = 0X0,
    EN_RFDEV_KJIOTEVENT_OPEN      = 0x01,
    EN_RFDEV_KJIOTEVENT_CLOSE     = 0X02,
    EN_RFDEV_KJIOTEVENT_LOWPOWER  = 0x03,
    EN_RFDEV_KJIOTEVENT_POWEROK   = 0x04
}EN_RFDEV_KJIOTEVENT_TYPE;


// 判断IOT类型是否为电子围栏
#define KJIOT_EVENT_IS_FENCE(uiIotType,uiIoTEventId) (((uiIotType) == EN_ZJ_AIIOT_TYPE_MOTION) && \
                                                    (((uiIoTEventId) >= EN_ZJ_MOTION_EVENT_FENCE_MOTION_STAY) && \
                                                    ((uiIoTEventId) <= EN_ZJ_MOTION_EVENT_FENCE_NONMOTOR_STAY)) || \
                                                    (((uiIoTEventId) >= EN_ZJ_MOTION_EVENT_FENCE_MOTION_IN) && \
                                                    ((uiIoTEventId) <= EN_ZJ_MOTION_EVENT_FENCE_FACE_OUT)))

#ifdef __cplusplus
}
#endif


#endif


