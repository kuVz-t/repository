#ifndef KJIOT_DEVICE_API_H
#define KJIOT_DEVICE_API_H

#include "kjiot_device_prv.h"
#include "kjiot_device_type.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct st_KjIot_ContrlDev_Node
{
    _UI uiKjIoTType;
    _UI uiInTimerCtrl;
    ZJ_PFUN_AIIOT_OUTPUT     pFunContrlDev;
    ZJ_PFUN_AIIOT_GETINPUT   pFunGetInput;
    ZJ_PFUN_AIIOT_CHECKEVENT pFunCheckEvent;
    ZJ_PFUN_AIIOT_SETPROP    pfunSetProp;
    ST_MOS_LIST_NODE stNode;
}ST_KJIOT_CONTRLDEV_NODE;

typedef struct st_KjIot_PtzEvent_Node
{
    _UC ucUseFlag;
    ST_MOS_LIST_NODE stNode;
}ST_KJIOT_PTZEVENT_NODE;


/*****************************************************************
对于探测器: 输入信号按照报警策略处理
对于控制器: 状态一致性交给 zj_iottask去保证 
模式中状态: 按照生效的模式进行工作
*****************************************************************/
_INT KjIoT_init();

_INT KjIoT_Start();

_INT KjIoT_Stop();

_INT KjIoT_Destroy();

ST_KJIOT_TASK_MNG *KjIoT_GetMng();

_INT KjIoT_SetTimerInfChange();

_INT KjIoT_SetEvent(_UI uiKjIoTType,_LLID lluKjIotId,int iKjIoTEventId,_VPTR pstUsrInf);

_INT KjIoT_SetEventEx(_UI uiKjIoTType,_LLID lluKjIotId,_INT iKjIoTEventId,_VPTR pstUsrInf, _BOOL bNeedFreeUsrInf);

_INT KjIoT_InputValue(_UI uiKjIoTType,_LLID lluKjIotId,_UC *pStrInput);

_INT KjIoT_AddDevContrlFun(_UI uiKjIoTType,ZJ_PFUN_AIIOT_OUTPUT pFunContrlDev,ZJ_PFUN_AIIOT_GETINPUT pFunGetInput,
                ZJ_PFUN_AIIOT_CHECKEVENT pFunCheckEvent,ZJ_PFUN_AIIOT_SETPROP pfunAIIoTSetProp);

ST_KJIOT_CONTRLDEV_NODE *KjIoT_FindDevContrlNode(_UI uiKjIoTType);

_INT KjIoT_AddDevicePlug(_UI uiKjIoTType,_LLID lluKjIotId,ZJ_PFUN_AIIOT_START pfunAIIoTStart,ZJ_PFUN_AIIOT_STOP pfunAIIoTStop);

_VOID KjIOT_AddPtzEventNode();

// 启动定时任务动作
_VOID KjIoT_StartTimePolicyActions(ST_CFG_TIMEPOLICY_NODE *pstTimePolicyNode);

// 停止定时任务动作
_VOID KjIoT_StopTimePolicyActions(ST_CFG_TIMEPOLICY_NODE *pstTimePolicyNode);

#ifdef __cplusplus
}
#endif

#endif


