#ifndef KJIOT_DEVICE_PRV_H
#define KJIOT_DEVICE_PRV_H

#ifdef __cplusplus
extern "C" {
#endif

#define KJIOTLOG_STR        "IOT"

// 定时任务开始时间点判断偏移时间（s）
#define TIMEPOLICY_OFFSET_STARTTIME_SEC      10
// 定时任务结束时间点判断偏移时间（s）
#define TIMEPOLICY_OFFSET_ENDTIME_SEC         8

// 定时任务任务类型
typedef enum enum_TIMEPOLICY_LOOPTYPE
{
    EN_TIMEPOLICY_LOOPTYPE_LOOP       = 0,  // 循环定时任务 
    EN_TIMEPOLICY_LOOPTYPE_ONETIME    = 1,  // 一次性定时任务
}EN_TIMEPOLICY_LOOPTYPE;

// 定时任务工作状态
typedef enum enum_TIMEPOLICY_WORKSTATUS
{
    EN_TIMEPOLICY_STATUS_NOWORK       = 0,  // 没有工作
    EN_TIMEPOLICY_STATUS_WORKING      = 1,  // 工作中
}EN_TIMEPOLICY_WORKSTATUS;

// IoT节点工作状态
typedef enum EN_KJIOTPLUG_WORKSTATUS
{
    EN_KJIOTPLUG_INIT   = 0,            // 初始化
    EN_KJIOTPLUG_START  = 1,            // 启动
    EN_KJIOTPLUG_RUN    = 2,            // 运行中
    EN_KJIOTPLUG_STOP   = 3,            // 停止
}EN_KJIOTPLUG_WORKSTATUS;

// KJIOT模块消息队列类型
typedef enum enum_KJIOT_MSG_TYPE
{
    EN_KJIOT_MSG_SETEVENT       = 0X01, // 有告警事件
    EN_KJIOT_MSG_SETVALUE       = 0X02, // 设置value
    EN_KJIOT_MSG_ADDPLUG        = 0X03, // 添加IoT节点
    EN_KJIOT_MSG_RMVPLUG        = 0X04, // 删除IoT节点
    EN_KJIOT_MSG_ONLINESTATUS   = 0X05, // 信令服务上线
}EN_KJIOT_MSG_TYPE;

// 告警事件信息
typedef struct stru_KJIOT_SETEVNT_MSG
{
    ST_MOS_MSGHEAD stMsgHead;   // 消息队列头
    _INT  iKjIoTEventId;        // 事件ID
    _UI   uiKjIoTType;          // IoT类型
    _LLID lluKjIoTId;           // IoTID
    _VPTR pstUsrInf;            // 用户信息（由厂商传参）
    _BOOL bNeedFreeUsrInf;      // 是否需要释放用户信息
}ST_KJIOT_SETEVENT_MSG;

// SetValue消息队列信息
typedef struct stru_KJIOT_SETVALUE_MSG
{
    ST_MOS_MSGHEAD stMsgHead;   // 消息队列头
    _UI   uiKjIoTType;          // IoT类型   
    _LLID lluKjIoTId;           // IoTID
    _UC  *pStrInput;            // Input字符串
}ST_KJIOT_SETVALUE_MSG;

// IoT节点操作消息队列信息
typedef struct stru_KJIOT_ADDPLUG_MSG
{
    ST_MOS_MSGHEAD            stMsgHead;        // 消息队列头
    _UI                       uiKjIoTType;      // IoT类型
    _LLID                     lluKjIoTId;       // IoTID
    ZJ_PFUN_AIIOT_START       pFunStart;        // IoT启动回调接口
    ZJ_PFUN_AIIOT_STOP        pFunStop;         // IoT停止回调接口
    ZJ_PFUN_AIIOT_GETINPUT    pFunGetInput;     // IoT GetInput回调接口
    ZJ_PFUN_AIIOT_SETPROP     pFunSetProp;      // IoT设置属性回调接口
    ZJ_PFUN_AIIOT_CHECKEVENT  pFunCheckEvent;   // IoT自检回调接口
}ST_KJIOT_ADDPLUG_MSG;

// IoT节点信息
typedef struct ST_KJIOTPLUG_NODE
{
    _UC   ucUseFlag;                            // IoT节点使用情况
    _UC   ucStatus;                             // IoT节点状态
    _UC   ucRsv[2];
    _UI   uiKjIoTType;                          // IoT类型
    _LLID lluKjIotId;                           // IoTID
    _CTIME_T                  cHappenTime;      // IoT触发时间
    ZJ_PFUN_AIIOT_START       pFunStart;        // IoT启动回调接口
    ZJ_PFUN_AIIOT_STOP        pFunStop;         // IoT停止回调接口
    ST_MOS_LIST_NODE          stNode;
}ST_KJIOTPLUG_NODE;

// IoT告警事件节点信息
typedef struct stru_KjIoT_Alarm_node
{
    _INT  iUseFlag;              // KjIot设备添加标志
    _INT  iChangeFlag;           // KjIot设备是否触发标志
    _INT  iOpenFlag;             // KjIot设备启动标志
    _UI   uiKjIoTType;           // KjIot设备类型
    _LLID lluKjIotId;            // KjIot设备id
    _UC  *pstValue;              
    _UI  uiPolicyId;             // 策略id
    _UI  uiWeekFlag;             // 周几
    _UI  uiStartTime;            // 事件触发时间戳
    _UI  uiEndTime;              // 事件结束时间戳
    _UI  uiSpanFlag;             // 事件是否跨天
    _CTIME_T cHappenTime;        // 事件触发时间
    _UI  uiPropLen;              // 属性长度
    _UC *pucProp;                // KjIot设备属性json string
    _UI  uiInterval;             // 事件触发间隔
    ST_MOS_LIST  stEventList;    // ST_KJIOT_OUTPUT_NODE 事件链表
    ST_MOS_LIST_NODE stNode;
}ST_KJIOT_ALARM_NODE;

// IoT模块管理信息
typedef struct ST_KJIOT_TASK_MNG
{
    _UC  ucbInit;                   // IOT 模块初始化标志
    _UC  ucBRun;                    // IOT 模块启动标志
    _UC  ucCamOpenFlag;             // IOT 摄像头打开标志
    _UC  ucFirstFlag;               // IOT 模块第一次启动标志
    _UI  uiChargeFlag;              // IOT 模块收费标志
    _INT iOnlineStatus;             // IOT 信令上线状态
    _INT iFirstOnlineFlag;          // IOT 设备启动信令第一次上线标志
    _HMUTEX hMutex;                 // IOT 模块的互斥锁
    _HQUEUE hMsgQueue;              // IOT 模块的消息队列
    _HTHREAD hThread;               // IOT 模块的启动线程
    ST_MOS_LIST stIotPlugList;      // 注册的报警器列表 ST_KJIOTPLUG_NODE
    ST_MOS_LIST stAlarmPolicyList;  // 报警策略
    ST_MOS_LIST stEventProcList;    // 事件处理函数列表
    ST_MOS_LIST stPtzEventList;     // 设备联动事件链表
}ST_KJIOT_TASK_MNG;

#ifdef __cplusplus
}
#endif

#endif



