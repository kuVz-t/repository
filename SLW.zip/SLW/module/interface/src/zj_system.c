#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "kjiot_device_api.h"
#include "http_api.h"
#include "http.h"
#include "media_cache_api.h"
#include "adpt_ssl_adapt.h"
#include "IoManage_api.h"
#include "snap_api.h"
#include "event_api.h"
#include "record_api.h"
#include "cmdhdl_api.h"
#include "rf_radio_api.h"
#include "cloudstg_api.h"
#include "media_api.h"
#include "msgmng_api.h"
#include "p2p_connect.h"
#include "ga1400_api.h"
#include "qualityprobe_api.h"

#ifdef BUILD_SUPPORT_MSGTEST_FALG
#include "msgtest.h"
#endif

#ifdef BUILD_IMSSDK_FALG
#include "ims_render.h"
#endif

#ifdef BUILD_ONBROADCAST_FALG
#include "broadcast_api.h"
#endif    
#include "watchdog_api.h"
#ifdef OFFICIAL_SERVER
_INT  g_SdkRunMode = 1;
#else
_INT  g_SdkRunMode = 0;
#endif

int ZJ_SetSdkRunMode(unsigned int uiOfficalFlag)
{
    printf(" set sdk run in %s\n", (uiOfficalFlag>=1) ? "offical environment" : "develop environment");
    g_SdkRunMode = uiOfficalFlag;
    return MOS_OK;
}
// 设备SDK初始化
int ZJ_Init(char *pucSystemPath, char* pcConfPath)
{    
    _INT iOfficalFlag = MOS_FALSE;
    printf("sdkver:%04x %s complie time:%s-%s\n",STR_SDK_VERSION, __FUNCTION__, __DATE__, __TIME__);

    // 设置系统路径，配置文件路径
    Config_Task_Init((_UC*)pucSystemPath,(_UC*)pcConfPath); //adapter diffrent system operation
    
    // 设置回调
    ZJ_InitFunTable(); //all vender setCallBack functions
    
    // 云涛日志模块初始化
    CloudStg_LoggerInit();

    // Http模块初始化
    Http_Init();

    // start Watchdog module
    Swd_Module_Init();

    // Iot
    KjIoT_init();

    // 信令
    MsgMng_Init();

    // 对讲缓冲区初始化
    Media_AudioPlayInit();

    // 控制模块
    Cmdhdl_Task_Init();
    
    // 红外设备
#ifdef SUPPORT_RF_MODULE
    Rf_Init();
#endif

#ifdef OFFICIAL_SERVER
    iOfficalFlag = MOS_TRUE;
    if ((Mos_FileIsExist("/tmp/sdk_debug_flag") == MOS_TRUE) || (g_SdkRunMode==0))
    {
        iOfficalFlag = MOS_FALSE;
    }
#else
    if ((Mos_FileIsExist("/tmp/sdk_release_flag") == MOS_TRUE) || (g_SdkRunMode==1))
    {
        iOfficalFlag = MOS_TRUE;
    }
#endif

    MOS_LOG_INF("SDKINIT", "sdkver:%04x %s complie time:%s-%s, iOfficalFlag:%d\n",STR_SDK_VERSION, __FUNCTION__, __DATE__, __TIME__, iOfficalFlag );
    // 本地存储管理
    IoMng_Init();

    // AP配网
    if (Mos_FileIsExist("/tmp/test_no_softap") == MOS_FALSE)
    Cfgap_Task_Init();

    // 无感配网
    AutoConn_Task_Init();

    // 录像
    if (Mos_FileIsExist("/tmp/test_no_record") == MOS_FALSE)
    RdStg_Init(0,1);

    // 抓拍
    Snap_Init(1);

    // 报警
    Event_Init();

    // GA1400

#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
    if (Mos_FileIsExist("/tmp/test_no_1400") == MOS_FALSE)
    Ga1400_Task_Init();
#endif

#ifdef BUILD_ONBROADCAST_FALG
    // 云广播
    Broadcast_Task_Init();
#endif

    // 流媒体转发00
    Media_Task_Init();

    // SSL初始化
    Adpt_SSL_Init();

    // P2P
    if (Mos_FileIsExist("/tmp/test_no_p2p") == MOS_FALSE)
    {
        if (Config_GetCamaraMng()->uiP2PAbility >= 1)
        {
            P2p_Task_Init();
        }
    }

    // 云存
    if (Mos_FileIsExist("/tmp/test_no_cloud") == MOS_FALSE)
    {
        CloudStg_Init();
        CloudStg_Patch_Init();
    }
    
    //质量探针
    if (Mos_FileIsExist("/tmp/test_no_ProbeAbility") == MOS_FALSE)
    {
        if (Config_GetCamaraMng()->uiQualityProbeAbility >= 1)
        {
            Qp_Task_Init();
        }
    }

    // 全链路感知探测
    CloudStg_Netcheck_Init();

     Config_SetLoginServerAddr(iOfficalFlag);
    if (Config_GetLoginServerFlag() >= 1)
    {
        Config_SetMediaPlatSignAddr((_UC *)"p2p.ehome.21cn.com");
        Config_SetCompanyInfo((_UC *)"1000000000000001", (_UC *)"2000000000000008");
        Config_SetRoutePlatAddr((_UC *)"https://vnet-sroute.21cn.com");
        Config_SetImsPlatAddr((_UC *)"https://ehome.21cn.com");
        if(Config_GetCamaraMng()->uiPolicyDomainAbility >= 1)
        {
            Config_SetGa1400PlatAddr((_UC *)"https://vcp.21cn.com");
        }
        else
        {
            Config_SetAblPlatAddr(0, (_UC *)"https://ehome-signal.21cn.com");
            Config_SetAlarmPlatAddr((_UC *)"https://ehome-alarm.21cn.com");
            Config_SetCloudPlatAddr((_UC *)"https://cloud-ehome.21cn.com");
            Config_SetGa1400PlatAddr((_UC *)"https://vcp.21cn.com");
            Config_SetReportPlatAddr((_UC *)"https://ehome.21cn.com");
            Config_SetOtherPlatAddr((_UC *)"https://ehome.21cn.com");
        } 
        //ZJ_SetCTEIID((_UC *)"C03200HZ4OH");
        //Config_SetMngPlatDevUID((_UC *)"3ELB024031RHFGW",(_UC *)"TUnqdbGbDy");
    }
    else
    {
        Config_SetMediaPlatSignAddr((_UC *)"182.43.198.36:42003");
        Config_SetCompanyInfo((_UC *)"2000000000000001", (_UC *)"2000000000000008");
        Config_SetRoutePlatAddr((_UC *)"https://t-vnet-sroute.21cn.com");
        Config_SetImsPlatAddr((_UC *)"https://beta.ehome.21cn.com");
        if(Config_GetCamaraMng()->uiPolicyDomainAbility >= 1)
        {
            Config_SetGa1400PlatAddr((_UC *)"https://t-vcp.21cn.com");
        }
        else
        {
            Config_SetAblPlatAddr(0, (_UC *)"https://beta.ehome.21cn.com");
            Config_SetCloudPlatAddr((_UC *)"https://beta.ehome.21cn.com");
            Config_SetAlarmPlatAddr((_UC *)"https://beta.ehome.21cn.com"); //standard environment alarm host
            Config_SetGa1400PlatAddr((_UC *)"https://t-vcp.21cn.com");
            Config_SetReportPlatAddr((_UC *)"https://beta.ehome.21cn.com");
            Config_SetOtherPlatAddr((_UC *)"https://beta.ehome.21cn.com");
        }    
    }
    
    MOS_LOG_INF(ZJ_LOGSTR, "zj task init ok, officalFlag:%d", Config_GetLoginServerFlag());
    return MOS_OK;
}

int ZJ_SetPlatSignAddr(unsigned char *pucSignAddr)
{
    return Config_SetMediaPlatSignAddr(pucSignAddr);
}

int ZJ_SetCompanyInfo(unsigned char *pucCompanyId,unsigned char* pucAppId)
{
    return Config_SetCompanyInfo(pucCompanyId,pucAppId);
}

int ZJ_SetSN(unsigned char* pucDevSn)
{
    return Config_SetDevSn(pucDevSn);
}

int ZJ_SetCTEIID(unsigned char* pucCTEI)
{
#ifdef DX_SECOND_LINK
    Config_SetGBCTEIID(pucCTEI);
#endif
    return Config_SetCTEIID(pucCTEI);
}

int ZJ_SetDeviceUID(unsigned char *pucDevUID, unsigned char *pucDevKey)
{
    Config_SetMediaPlatDeviceId(pucDevUID);
    return Config_SetMngPlatDevUID(pucDevUID,pucDevKey);
}

int ZJ_SetDeviceModel(unsigned char *pucDevModel)
{
    return Config_SetDevModel(pucDevModel);
}

unsigned char* ZJ_GetDeviceModel()
{
    return Config_GetDeviceMng()->aucDevModel;
}

int ZJ_SetDevOsType(unsigned int uiOsType)
{
    return Config_SetDevOsType(uiOsType);
}

int ZJ_SetDevType(unsigned int uiDevType)
{
    return Config_SetDevType(uiDevType);
}

int ZJ_SetAppVersion(const char* pcVersion)
{
    return Config_SetAppVersion((_UC*)pcVersion);
}

unsigned char* ZJ_GetAppVersion()
{
    return Config_GetDeviceMng()->aucDevVerSion;
}

int ZJ_Set_SystemStatusCB(ZJ_PFUN_DEVICE_STATUS pFunSelfStatusCb)
{
    ZJ_GetFuncTable()->pFunSelfStatusCb = pFunSelfStatusCb;
    return MOS_OK;
}

int ZJ_SetDeviceRebootCbFunc(ZJ_PFUN_DEV_REBOOT pfunDevRebootCb)
{
    ZJ_GetFuncTable()->pfunDevRebootCb = pfunDevRebootCb;
    return MOS_OK;
}

int ZJ_SetDeviceExitCbFunc(ZJ_PFUN_DEV_EXIT pfunDevExitCb)
{
    ZJ_GetFuncTable()->pfunDevExitCb = pfunDevExitCb;
    return MOS_OK;
}

int ZJ_SetUtcTimeCB(ZJ_PFUN_DEVICE_SETUTC pfunSetUtcTime)
{
    ZJ_GetFuncTable()->pfunSetUtcTime = pfunSetUtcTime;
    return MOS_OK;
}

int ZJ_SetZoneAndTimeCB(ZJ_PFUN_DEVICE_SETTIMEZONE pfunSetTimeZone, ZJ_PFUN_DEVICE_GETTIMEANDZONE pfunGetTimeZone)
{
    ZJ_GetFuncTable()->pfunSetTimeZone = pfunSetTimeZone;
    ZJ_GetFuncTable()->pfunGetTimeZone = pfunGetTimeZone;
    return MOS_OK;
}

int ZJ_SetDefaultZoneAndTimeCB(ZJ_PFUN_DEVICE_SETDEFAULTZONETIME pFunSetDefaultTimeAndZone)
{
    ZJ_GetFuncTable()->pFunSetDefaultZoneAndTime = pFunSetDefaultTimeAndZone;
    return MOS_OK;
}

int ZJ_SetGetSnapShotTimeCB(ZJ_PFUN_DEVICE_GETSNAPSHOTTIME pfunGetSnapShotTime)
{
    ZJ_GetFuncTable()->pfunGetSnapShotTime = pfunGetSnapShotTime;
    return MOS_OK;
}

int ZJ_SetRestoreFactorySettingCB(ZJ_PFUN_DEVICE_RESTOREFACTORYSETTING pfunRestoreFactorySetting)
{
    ZJ_GetFuncTable()->pfunRestoreFactorySetting = pfunRestoreFactorySetting;
    return MOS_OK;
}

void ZJ_SetSysMemLevel(EN_ZJ_DEVICE_MEM_ABILITY enZJDevAblity)
{
    Mos_SysSetDeviceAbility(enZJDevAblity);
    return ;
}

int ZJ_SetEncryptAbility(int iEncAbility)
{
    return Config_SetEncryptAbility(iEncAbility);
}

_UC* ZJ_GetDeviceId()
{
    return Config_GetSystemMng()->aucDid;
}


int ZJ_CtrlDeviceId(_UI uiCtrlType)
{
    _UI uiCnt = 0;

    Config_SetDevCtrlType(uiCtrlType);
    
    while(uiCtrlType == EN_ZJ_CTRLDID_EXITGROUP && Config_GetExitGroupFlag() != 0 && uiCnt++ < 30)
    {
        Mos_Sleep(100);
    }
    
    return MOS_OK;
}
unsigned char *ZJ_GetDeviceName()
{
    return Config_GetDeviceMng()->aucDevName;
}

unsigned char* ZJ_GetDeviceUID()
{
    static _UC aucDevUID[CFG_STRING_LEN] = {0};
    MOS_MEMCPY(aucDevUID, Config_GetSystemMng()->aucDevUID, sizeof(aucDevUID));
    return aucDevUID;
}

unsigned char* ZJ_GetDeviceCTEI()
{
    static _UC aucDevCTEI[CFG_CTEI_LEN + 4] = {0};
    MOS_MEMCPY(aucDevCTEI, Config_GetSystemMng()->aucDevCTEI, sizeof(aucDevCTEI));
    return aucDevCTEI;
}

unsigned char* ZJ_GetDeviceSN()
{
    static _UC aucDevSN[CFG_STRING_LEN + 4] = {0};
    MOS_MEMCPY(aucDevSN, Config_GetSystemMng()->aucDevSN, sizeof(aucDevSN));
    return aucDevSN;
}

unsigned char* ZJ_GetDeviceKey()
{
    static _UC aucDevkey[CFG_STRING_LEN + 4] = {0};
    MOS_MEMCPY(aucDevkey, Config_GetSystemMng()->aucDevkey, sizeof(aucDevkey));
    return aucDevkey;
}

int ZJ_SetDeviceName(unsigned char *pucDevName)
{
    return Config_SetDeviceName(pucDevName);
}

int ZJ_BoolDeviceJoinGroup()
{
    if(MOS_STRLEN(Config_GetGroupInf()->aucGrpid) > 0)
    {
        return 1;
    }
    return 0;
}
int ZJ_GetDeviceOwnerPubInf(unsigned char aucName[64],unsigned char aucCcount[64],unsigned char aucMobile[32])
{
    MOS_STRNCPY(aucName,Config_GetGroupInf()->aucOwnerName,64);
    MOS_STRNCPY(aucCcount,Config_GetGroupInf()->aucOwnerAccout,64);
    MOS_STRNCPY(aucMobile,Config_GetGroupInf()->aucOwnerMobile,32);
    return MOS_OK;
}


_ZJ_API int ZJ_SetSIMCardInfo(unsigned char aucSIMCard[64])
{
    return Config_SetSIMCardAccount(aucSIMCard);
}

int ZJ_Set4GAbility(int i4GAbility)
{
    return Config_Set4GAbility(i4GAbility);
}

int ZJ_SetCpuRamUsageCB(ZJ_PFUN_CAMERA_CPU_RAM_USAGE pFunGetCpuRamUsageCb)
{
    ZJ_GetFuncTable()->pfunGetCpuRamUsage = pFunGetCpuRamUsageCb;
    return MOS_OK;
}

int ZJ_SetPingInfoCB(ZJ_PFUN_DEVICE_PINGINF pFunGetPingInfoCb)
{
    ZJ_GetFuncTable()->pfunGetPingInfo = pFunGetPingInfoCb;
    return MOS_OK;
}

#if 0
int ZJ_RF_Recv(unsigned char* pucData, int iLen)
{
    if(pucData[0] == 0X36)
    {
        pucData[0] = 0X30;
    }
    else if(0X32 == pucData[0])
    {
        pucData[0] = 0X37;
    }
    else if(pucData[0] == 0X33)
    {
        pucData[0] = 0x38;
    }
    ZJ_IoTHubWriteData(pucData,iLen);
    return MOS_OK;
}
#endif

// 设备SDK启动
int ZJ_Start()
{
    _INT iRet = MOS_ERR;
    // 记录第一次上电时间
    Config_SetFirstLaunchTime();

    // 通知厂商清除图片数据缓存 
    if (ZJ_GetFuncTable()->pFunFreeBeforeStartUpCache)
    { 
        iRet = ZJ_GetFuncTable()->pFunFreeBeforeStartUpCache(EN_ZJ_FREE_BEFORE_STARTUP_CACHE_AIALARMPV);
        if (MOS_OK != iRet)
        {
            MOS_LOG_ERR(ZJ_LOGSTR,"Device pFunFreeBeforeStartUpCache FreeCacheType:%d failed", EN_ZJ_FREE_BEFORE_STARTUP_CACHE_AIALARMPV);
        }
    }
    else
    {
        MOS_LOG_ERR(ZJ_LOGSTR,"Device pFunFreeBeforeStartUpCache is NULL!");
    }

    Swd_Module_Start();
    Media_VideoInit();
    Media_AuidoInit();
    // 双向视频通话缓冲区初始化
    Media_VideoDisPlayInit();

    Config_SetDefaultSnapProp(1,0,180,EN_ZJ_PICTURE_MIDDLE);

    if (SDK_AWAKE_SLEEP_ENABLE && Config_GetDeviceMng()->iAwakeAbility != EN_ZJ_AWAKE_ABILITY_NOTSUPPORT)   //支持低功耗设备
    {
        // 门铃设备或低功耗设备默认的自定义录像时长为6秒
        Config_SetDefaultRecordProp(1,0,0,6);
    }
    else
    {
        Config_SetDefaultRecordProp(1,1,0,60);
        // Config_AddCommonDefaultPolicy(EN_ZJ_AIIOT_TYPE_FALLDOWN,0,(_UC*)"FALL_DOWN");
        // Config_AddCommonDefaultPolicy(EN_ZJ_AIIOT_TYPE_FLAMEDETECT,0,(_UC*)"FLAME_DETECT");
        // Config_AddCommonDefaultPolicy(EN_ZJ_AIIOT_TYPE_SMOKEDETECT,0,(_UC*)"SMOKE_DETECT");
        Config_AddDefaultVoicePolicy(EN_ZJ_AIIOT_TYPE_VOICEALARMDETECT,0,(_UC*)"VOICE_DETECT"); //兼容3.0的对接方式
        // Config_AddDefaultVoicePolicy(EN_ZJ_AIIOT_TYPE_CRYALARM,0,(_UC*)"CRY_ALARM");            //兼容3.0的对接方式
    }

    Config_Task_Start();
    KjIoT_Start();
    Cmdhdl_Task_Start();
#ifdef SUPPORT_RF_MODULE
    Rf_Start();
#endif

    // LocalIo 开始
    if (Mos_FileIsExist("/tmp/test_no_record") == MOS_FALSE)
    IoMng_Start();
    
    // AP配网
    Cfgap_Task_Start();

#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
    // GA1400
    Ga1400_Task_Start();
#endif

    // IMS
    if (Config_GetCamaraMng()->uiIMSAbility >= 1)
    {
#ifdef BUILD_IMSSDK_FALG
        ImsMedia_Task_Init();

        // IMS模块睡眠监控注册
        ImsMedia_AppSLeepMonotorRegist();
#endif
    }

#ifdef BUILD_ONBROADCAST_FALG
    // 云广播
    Broadcast_Task_Start();
#endif

    Http_Start();
    CloudStg_LoggerStart();
    MsgMng_Start();
    CloudStg_Start();
    CloudStg_Patch_Start();
    CloudStg_Netcheck_Start();
    Media_Task_Start();
    P2p_Task_Start();
    
    // 质量探针
    Qp_Task_Start();

    if (Config_GetDeviceMng()->uiUpgradedEndFlag == 0)
    {
        // 上报OTA升级进度和状态
        Ota_PubUpgradePrecentage(0, EN_CFG_OTA_UPGRADE_NONEED);
    }

#ifdef BUILD_SUPPORT_MSGTEST_FALG
    // 模拟信令服务器下发信令
    MsgTest_Start();
#endif

    MOS_LOG_INF(ZJ_LOGSTR,"zj task start ok");
    return MOS_OK;
}

int ZJ_Stop()
{
    KjIoT_Stop();
    Cmdhdl_Task_Stop();
#ifdef SUPPORT_RF_MODULE
    Rf_Stop();
#endif
    CloudStg_LoggerStop();
    IoMng_Stop();
    CloudStg_Stop();
    CloudStg_Patch_Stop();
    CloudStg_Netcheck_Stop();
    Http_Stop(); 
    MsgMng_Stop();
    Qp_Task_Stop();
    Media_Task_Stop();
    Config_Task_Stop();
    P2p_Task_Stop();
    Cfgap_Task_Stop();
    AutoConn_Task_Stop();

#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
    Ga1400_Task_Stop();
#endif

#ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Stop();
#endif        

#ifdef BUILD_IMSSDK_FALG
    // IMS
    if (Config_GetCamaraMng()->uiIMSAbility >= 1)
    {
        // IMS模块睡眠监控解注册
        ImsMedia_AppSLeepMonotorUnRegist();
    }
#endif
    Swd_Module_Stop();
    MOS_LOG_INF(ZJ_LOGSTR,"zj task stop ok");
    return MOS_OK;
}

int ZJ_Destroy()
{
#ifdef ENABLE_ZJ_DESTROY
    KjIoT_Destroy();
    IoMng_Destory();
#ifdef SUPPORT_RF_MODULE
    Rf_Destroy();
#endif
    CloudStg_LoggerDestroy();
    Http_Destroyed();
    MsgMng_Destroy();
    CloudStg_Destroy();
    CloudStg_Patch_Destroy();
    CloudStg_Netcheck_Destroy();
    Cmdhdl_Task_Destroy();
    Snap_Destory();
    Event_Destory();
    RdStg_Destory();
    P2p_Task_Destroy();
    Media_Task_Destroy();
    Mos_Sleep(500);
    Media_AuidoDestroy();
    Media_AudioPlayDestroy();
    Media_VideoDisPlayDestroy();
    Media_VideoDestroy();
    Adpt_SSL_DeInit();
    ZJ_DestoryFunTable();
    Config_Task_Destroy();
    Cfgap_Task_Destroy();
    AutoConn_Task_Destroy();
#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
    Ga1400_Task_Destroy();
#endif
#ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Destroy();
#endif       
    Qp_Task_Destroy();
    
    Swd_Module_Destroy();
    MOS_LOG_INF(ZJ_LOGSTR,"zj task destroy ok");
    Mos_SysDestroy();
#endif /*ENABLE_ZJ_DESTROY*/
    return MOS_OK;
}

int ZJ_SetNoticeCfgChangeCbFun(ZJ_PFUN_CFGITEM_CHANGE pfunCfgItemChangeCb)
{
    ZJ_GetFuncTable()->pfunCfgItemChangeCb = pfunCfgItemChangeCb;
    return MOS_OK;
}

_ZJ_API int ZJ_SetLogSize(_UI uiFileSize, _UI uiFileNum)
{
    if (MOS_STRLEN(Config_GetCoreMng()->aucCachePath) > 0)
    {
        MOS_PRINTF("already have SDCard\n");
        return MOS_OK;
    }
    return Mos_SetFlashLogSize(uiFileSize, uiFileNum);
}
