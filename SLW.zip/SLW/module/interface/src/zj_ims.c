#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#ifdef BUILD_IMSSDK_FALG
#include "ims_render.h"
#endif

int ZJ_SetIMSAbility(int iIMSAbility)
{
#ifdef BUILD_IMSSDK_FALG
    return Config_SetCameraIMSAbility(0,iIMSAbility);
#else
    return -1;
#endif
}

void ZJ_GetImsBindInfo(EN_ZJ_IMS_INFO *pInfo)
{
    _UI uiCallStatus = 0;

    if (NULL != pInfo)
    {
        #ifdef BUILD_IMSSDK_FALG
        if ((1 == Config_GetCamaraMng()->uiIMSAbility) && (1 == Config_GetImsMng()->uiHaveIMS))
        {
            uiCallStatus = IMS_GetCallStatus();
            if (0 == uiCallStatus) //IMS不可用状态
            {
                *pInfo = EN_ZJ_IMS_BIND_OFFLINE;
            }
            else
            {
                *pInfo = EN_ZJ_IMS_BIND_ONLINE;
            }
        }
        else
        #endif
        {
            *pInfo = EN_ZJ_IMS_NO_BIND;
        }
        
    }

    return;
}

int ZJ_ImsCallOut(unsigned char* pucCallNum, EN_ZJ_IMS_CALL_TYPE iCallType)
{
#ifdef BUILD_IMSSDK_FALG
    return ImsMedia_CallOut(pucCallNum, iCallType);
#else
    return -1;
#endif
}

int ZJ_ImsHangUp()
{
#ifdef BUILD_IMSSDK_FALG
    return ImsMedia_HangUp();
#else
    return -1;
#endif
}

int ZJ_SetRecvImsErrCB(ZJ_PFUN_IMS_RECV_ERRNTC pfun_RecvErrNtc)
{
#ifdef BUILD_IMSSDK_FALG
    ZJ_GetFuncTable()->pfunImsRecvErrNtcCb = pfun_RecvErrNtc;
    return MOS_OK; 
#else
    return -1;
#endif
}