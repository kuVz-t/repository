#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "http_api.h"

/**********************************************************************************
发送自定义消息指令；
pucPeerID: 对方的标识号
pucData: 数据内容
iLen:    数据长度
***********************************************************************************/
int ZJ_SendCustomData(const unsigned char* pucPeerID, unsigned char* pucData, int iDataLen)
{
    return Http_SendPrivateData((unsigned char*)pucPeerID, pucData, iDataLen);
}
 
/******************************************************************************************************
注册接受自定义数据的函数
pFuncOnRecvCustomData ：自定义接受数据回调
********************************************************************************************************/             
int ZJ_SetRecvCustomDataFunc(ZJ_PFUN_DEVICE_RECVCUSTOMDATA pFuncOnRecvCustomData)
{
    ZJ_GetFuncTable()->pFuncOnRecvCustomData = pFuncOnRecvCustomData;
    return MOS_OK;
}

/******************************************************************************************************
ptz转动到底了，发送此消息
********************************************************************************************************/   
int ZJ_SendPTZtoEndFlag(unsigned int uiEndFlag)
{
    if (uiEndFlag == 1)
    {
        return Cmdhdl_SetPtzEndMsg();
    }
    return MOS_ERR;
}

