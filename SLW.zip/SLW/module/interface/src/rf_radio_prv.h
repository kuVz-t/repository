#ifndef RF_RADIO_PRV_H
#define RF_RADIO_PRV_H

#ifdef __cplusplus
extern "C" {
#endif

#define RF_DACID_LEN                       8


#define RF_MSG_LEN                         13

#define RF_ALIVE_TIME                      7200
        
#define RF_LOGSTR                         (_UC*)"RF"

// 表示探头上报 报警消息
#define RF_STATUS_REPORT                   0X30
// 表示 控制 智能设备工作
#define RF_DEVICE_CONTROL                  0X31

// 获取智能设备列表
#define RF_DEVICELIST_REQ                  0x32
// 智能列表 开始 返还
#define RF_DEVICELIST_RES                  0X35
// 最后一个智能设备信息 
#define RF_DEVICELIST_END                  0X37

// 删除 某一个智能 设备
#define RF_DEVICE_DELECT                   0X33
// 删除 所有的 智能设备
#define RF_DEVICE_ALLDELECT                0X34
// 添加一个智能设备
#define RF_DEVICE_ADD                      0X36
// 删除 一个 设备
#define RF_DEVICE_DELSUSS                  0X38
// 添加 智能设备存在
#define RF_DEVICE_EXIST                    0X39
// 设备列表已满
#define RF_DEVICE_FULL                     0X3A


typedef enum EN_DAC_REMOTE_CTRLSTATUS
{
    EN_DAC_REMOTE_CTRLER_SET_DEFENCE    = 0,  
    EN_DAC_REMOTE_CTRLER_CLEAR_DEFENCE,    
    EN_DAC_REMOTE_CTRLER_SOS,               
    EN_DAC_REMOTE_CTRLER_SET_HOMEDEFENCE = 3, 
}EN_DAC_REMOTE_CTRLSTATUS;

typedef enum enum_DAC_DOORBELL_STATUS
{
    EN_DAC_DOORBELL_OPEN      = 8,//门铃按钮
    EN_DAC_DOORBELL_LOWPOWER  = 3,//门铃低电
    EN_DAC_DOORBELL_POWER_OK  = 5,//低压恢复
    EN_DAC_DOORBELL_ONLINE    = 6 //在线
    
}EN_DAC_DOORBELL_STATUS;

typedef enum EN_DAC_DOOR_SWITCHSTATUS
{
    EN_DAC_DOOR_SWITCH_ALARM    = 10, // 开门
    EN_DAC_DOOR_SWITCH_LOWPOWER, // 电量低
    EN_DAC_DOOR_SWITCH_OFF,//关门
    EN_DAC_DOOR_SWITCH_ONLINE,// 在线
    EN_DAC_DOOR_SWITCH_POWER_OK  = 15,// 低电量恢复
}EN_DAC_DOOR_SWITCHSTATUS;

typedef enum EN_DAC_SMOKE_TRANSDUCER_STATUS
{
    EN_DAC_SMOKE_TRANSDUCER_ALARM    = 20,// 烟雾报警
    EN_DAC_SMOKE_TRANSDUCER_LOWPOWER ,
    EN_DAC_SMOKE_TRANSDUCER_ONLINE   = 23,
    EN_DAC_SMOKE_TRANSDUCER_POWER_OK = 25,
    
}EN_DAC_SMOKE_TRANSDUCER_STATUS;

typedef enum EN_DAC_GAS_SENSOR_STATUS
{
    EN_DAC_GAS_SENSOR_ALARM      = 30,// 煤气瓦斯报警
    EN_DAC_GAS_SENSOR_ONLINE,
}EN_DAC_GAS_SENSOR_STATUS;

typedef enum EN_DAC_CO_SENSOR_STATUS
{
    EN_DAC_CO_SENSOR_ALARM      = 33,// 一氧化碳报警
    EN_DAC_CO_SENSOR_ONLINE     = 34,
    EN_DAC_CO_SENSOR_LOWPOWER   = 35,
    EN_DAC_CO_SENSOR_POWER_OK   = 36
}EN_DAC_CO_SENSOR_STATUS;

typedef enum EN_DAC_LIGHT_SWITCH_STATUS
{
    EN_DAC_LIGHT_ON              = 40,//电灯开
    EN_DAC_LIGHT_OFF             = 41,//电灯关
    EN_DAC_LIGHT_CHECK           = 43,// 查询 电灯
}EN_DAC_LIGHT_SWITCH_STATUS;

typedef enum EN_DAC_CURTAIN_STATUS
{
    EN_DAC_CURTAIN_OPEN          = 50,  // 窗帘 打开
    EN_DAC_CURTAIN_CLOSE,               // 窗帘关闭
    EN_DAC_CURTAIN_HALF,                // 窗帘半开
    EN_DAC_CURTAIN_HALF_OPEN,           // 正在开
    EN_DAC_CURTAIN_HALF_CLOSE,          // 正在 关
    EN_DAC_CURTAIN_CHECK         = 56,  // 状态查询
}EN_DAC_CURTAIN_STATUS;

typedef enum EN_DAC_JCAK_STATUS
{
    EN_DAC_JACK_ON              = 60,// 插座上电
    EN_DAC_JACK_OFF             = 61,// 插座断电
    EN_DAC_JACK_CHECK           = 66,// 插座查询  
}EN_DAC_JCAK_STATUS;

typedef enum EN_DAC_PIR_STATUS
{
    EN_DAC_PIR_ALARM    = 70,               //70 人体红外报警
    EN_DAC_PIR_LOWPOWER = 71,               //71 人体红外低电
    EN_DAC_PIR_SWICHOFF = 72,               //72 人体红外防拆
    EN_DAC_PIR_ONLINE   = 73,               //73 人体红外在线
    EN_DAC_PIR_SWICHON  = 74,             //74防拆恢复
    EN_DAC_PIR_POWERON  = 75,             // 低电恢复
}EN_DAC_PIR_STATUS;

typedef enum EN_DAC_WATER_STATUS
{
    EN_DAC_WATER_ALARM    = 80, //水侵报警
    EN_DAC_WATER_LOWPOWER = 81,
    EN_DAC_WATER_ONLINE   = 83,
    EN_DAC_WATER_POWEON   = 85,
}EN_DAC_WATER_STATUS;

typedef enum EN_DAC_ERG_STATUS
{
    EN_DAC_ERG_ALAEM         = 90,// 紧急按钮报警
    EN_DAC_ERG_LOWPOWER      = 91,
    EN_DAC_ERG_ONLINE        = 93,
    EN_DAC_ERG_POWERON       = 95, //紧急 按钮 电量 恢复
}EN_DAC_ERG_STATUS;

typedef enum EN_DAC_ALARM_BEER_STATUS
{
    EN_DAC_ALARM_BEER_ON     = 100, //警号 开 
    EN_DAC_ALARM_BEER_OFF,
    EN_DAC_ALARM_BEER_CHECK,
}EN_DAC_ALARM_BEER_STATUS;

typedef enum EN_DAC_JCAK_HVAC_STATUS
{
    EN_DAC_JCAK_HVAC_ON       = 110,// 空调 开 
    EN_DAC_JCAK_HVAC_OFF      = 111,
    EN_DAC_JCAK_HVAC_OFF_INON = 114,
    EN_DAC_JCAK_HVAC_OFF_OFF  = 115,
    EN_DAC_JCAK_HVAC_CHECK    = 116,
}EN_DAC_JCAK_HVAC_STATUS;

typedef enum EN_DAC_MULTISWITCH_STATUS
{
    EN_DAC_MULTSWITCH_ALLOFF      = 120,
    EN_DAC_MULTSWITCH_ON1         = 121,
    EN_DAC_MULTSWITCH_ON2,
    EN_DAC_MULTSWITCH_ON3,
    EN_DAC_MULTSWITCH_ON4,
    
    EN_DAC_MULTSWITCH_OFF1        = 125,
    EN_DAC_MULTSWITCH_OFF2,
    EN_DAC_MULTSWITCH_OFF3,
    EN_DAC_MULTSWITCH_OFF4,
    EN_DAC_MULTSWITCH_CHECK      = 129,
    EN_DAC_MULTSWITCH_ALLON      = 130,
}EN_DAC_MULTISWITCH_STATUS;

typedef enum EN_DAC_SHUTTER_MOTOR_STATUS
{
    EN_DAC_SHUTTER_MOTOR_UNLOCK = 130,
    EN_DAC_SHUTTER_MOTOR_LOCK   ,
    EN_DAC_SHUTTER_MOTOR_ON,
    EN_DAC_SHUTTER_MOTOR_OFF,
    EN_DAC_SHUTTER_MOTOR_STOP,
    EN_DAC_SHUTTER_MOTOR_CHECK,
}EN_DAC_SHUTTER_MOTOR_STATUS;

typedef enum EN_DAC_INFRARED_SENSOR_STATUS
{
    EN_DAC_INFRARED_SENSOR_ONLINE = 173,
        
}EN_DAC_INFRARED_SENSOR_STATUS;

typedef enum EN_DAC_BATTERY_VALVE_STATUS
{
    EN_DAC_BATTERY_VALVE_OPEN  = 180,
    EN_DAC_BATTERY_VALVE_CLOSE = 181,
    EN_DAC_BATTERY_VALVE_CHECK = 186
    
}EN_DAC_BATTERY_VALVE_STATUS;

typedef enum EN_DAC_AIRFLOW_SENSOR_STATUS
{
    EN_DAC_AIRFLOW_SENSOR_FLOW    = 190,
    EN_DAC_AIRFLOW_SENSOR_NOTFLOW = 191,
    EN_DAC_AIRFLOW_SENSOR_CHECK   = 196,
    
}EN_DAC_AIRFLOW_SENSOR_STATUS;


typedef enum EN_RF_DEVICE_ACTION
{
    EN_RF_DEVICE_ATION_OK,
    EN_RF_DEVICE_ATION_TOADD,
    EN_RF_DEVICE_ATION_ADDING,
    EN_RF_DEVICE_ATION_TOCTRL,
    EN_RF_DEVICE_ATION_CTRLING,
    EN_RF_DEVICE_ATION_TODEL,
    EN_RF_DEVICE_ATION_DELING,
    EN_RF_DEVICE_ATION_TODELALL,
    EN_RF_DEVICE_ATION_ALLDELING,
    EN_RF_DEVICE_ATION_QUERYING, //  查询
    EN_RF_DEVICE_ATION_MODCTRLING, // 更改

    EN_RF_DEVICE_ATION_WAITADDING,
}EN_RF_DEVICE_ACTION;


typedef enum EN_RF_MSG_TYPE
{
    EN_RF_MSG_ADDDACDEV = 1,
    EN_RF_MSG_RMVDACDEV,
    EN_RF_MSG_RMVALLDEV,
    EN_RF_MSG_CTRDACDEV,
    EN_RF_MSG_GETDACLIST,
    
}EN_RF_MSG_TYPE;


typedef struct ST_RF_RDDEV_CMDMSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UI uiCtrlType;
    _UI uiRdDevType;
    _LLID lluRdDevId;
    ST_RF_CMDRSPINFO stCmdRspInf;
}ST_RF_RDDEV_CMDMSG;


typedef struct ST_RF_CMDRSP_INF
{
    _UI   uiMsgRspType;
    _UI   uiMsgID;
    _VPTR  pstSrcInf;
}ST_RF_CMDRSP_INF;

typedef struct stru_RF_NORSPDEV_NODE
{
    _UI   uiDevType;       // 设备类型
    _LLID lluDevId;        // 如果是motion从 0 开始 
    ST_MOS_LIST_NODE stNode;  
}ST_RF_NORSPDEV_NODE;

typedef struct ST_RF_DEVICE_PROTO
{
    _UC ucHeader;
    _UC ucCrc;
    _UC ucOption;
    _UC ucDevType;
    _UC ucStatus;
    _UC aucSmartId[RF_DACID_LEN];
}ST_RF_DEVICE_PROTO;

typedef struct stru_RfRadio_mng
{
    _UC ucInit;
    _UC ucRunFlag;
    _UC ucSyncFlag;
    _UC ucCheckCnt;

    _UI uiAntConnectFlag;
    
    _UI uiActionStatus;  // 操作类型
    _CTIME_T  cReqTime;    // 请求的时间
    _CTIME_T  cSyncListTime; // 设备 列表 跟新时间 

    ST_RF_CMDRSPINFO stCmdRspInf;
    _HTHREAD hThread;
    _HQUEUE  hMsgQueue;
    ST_MOS_LIST stDaclist;
}ST_RFRADIO_MNG;

#ifdef __cplusplus
}
#endif


#endif


