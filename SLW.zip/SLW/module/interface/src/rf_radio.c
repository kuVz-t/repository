#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "rf_radio_api.h"
#include "rf_radio_prv.h"
#include "kjiot_device_api.h"
#include "adpt_json_adapt.h"
#include "http_api.h"
#include "msgmng_api.h"

static _INT Rf_RdDevRspCommonCmd(ST_RF_CMDRSPINFO *pstCmdRspInfo,_INT iStatus);
static _INT Rf_RspSwitchSceneCmd(ST_RF_CMDRSPINFO *pstCmdRspInfo,_UI uiNoRspCnt,ST_MOS_LIST *pstNoRspList);
static _BOOL Rf_RdDevBoolCtrler(_UC ucDevType);
static _BOOL Rf_RdDevBoolClearStatus(_UC ucDevType);
static _UC Rf_RdDevGetPowerStatus(_UC ucDevType,_UC ucStatus);
static _UC Rf_GetRdDevQueryCode(_UC ucDevType);
static _UC Rf_GetRdDevOpenCode(_UC ucDevType);
static _UC Rf_GetRdDevCloseCode(_UC ucDevType);
static _UC Rf_CheckRdDevBoolOpen(_UC ucDevType,_UC ucStatus);
static _UC Rf_CheckRdDevBoolAlarm(_UC ucDevType,_UC ucStatus);
static _INT Rf_GetEvntIdByDacStatus(_UI uiDacType,_UC ucStatus);
static _VOID Rf_ProcMsg(_VPTR pstMsg);
/************************************************************************
*************************************************************************/
static ST_RFRADIO_MNG g_RfRadioMng;

static ST_RFRADIO_MNG *Rf_GetMng()
{
    return &g_RfRadioMng;
}

/*************************************************************************************
***************************************************************************************/
static _INT Rf_PackDevMsg(_UC ucMsgType,_UC ucDevType,_UC ucStatus,_LLID lluDevId,
                          _OUT _UC aucMsgBuff[16])
{
    _UI i = 0;
    _LLID lluNetDevId ;
    ST_RF_DEVICE_PROTO *pstRdDevMsg = (ST_RF_DEVICE_PROTO*)aucMsgBuff;
    MOS_MEMSET(pstRdDevMsg,0,RF_MSG_LEN);
    
    pstRdDevMsg->ucHeader     = ucMsgType;
    pstRdDevMsg->ucDevType    = ucDevType;
    pstRdDevMsg->ucStatus     = ucStatus;
    lluNetDevId = Mos_InetHton64(lluDevId);
    MOS_MEMCPY(pstRdDevMsg->aucSmartId,(_UC*)&lluNetDevId,8);
    pstRdDevMsg->ucCrc        = ucDevType;
    pstRdDevMsg->ucCrc = pstRdDevMsg->ucCrc^ucStatus;
    
    for( i = 0;i < RF_DACID_LEN; i++)
    {
        pstRdDevMsg->ucCrc = pstRdDevMsg->ucCrc^pstRdDevMsg->aucSmartId[i];
    }
    MOS_LOG_INF(RF_LOGSTR,"pack rf msg %0x device %u %llu,status %u",ucMsgType,ucDevType,lluDevId,ucStatus);
    return RF_MSG_LEN;
}

static _INT Rf_SendRdData(_UC *pucDataMsg,_UI uiDatalen)
{
    MOS_PARAM_NULL_RETERR(pucDataMsg);

    _INT iRet = 0;
    if(Rf_GetMng()->uiAntConnectFlag == 0) {
        MOS_LOG_ERR(RF_LOGSTR, "can't send rd data, because rd antenna is not plugin");
        return MOS_ERR;
    }
    if(ZJ_GetFuncTable()->pfunIoTHubDataRecv == MOS_NULL) { 
        MOS_LOG_ERR(RF_LOGSTR, "can't send rf data, because Send handle is NULL");
        return MOS_ERR;
    }
    iRet = ZJ_GetFuncTable()->pfunIoTHubDataRecv(pucDataMsg,uiDatalen);
    if (iRet != MOS_OK) 
    {
        MOS_LOG_ERR(RF_LOGSTR, "send rf data error[%d], data[%p] len[%d]", iRet, pucDataMsg, uiDatalen);
    } 
    return iRet;
}

_INT Rf_Init()
{
    if(Rf_GetMng()->ucInit == 1)
    {
        MOS_LOG_WARN(RF_LOGSTR, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_RfRadioMng, 0, sizeof(g_RfRadioMng));
    Rf_GetMng()->hMsgQueue = Mos_MsgQueueCreate(MOS_FALSE, 20, __FUNCTION__);
    Rf_GetMng()->ucInit = 1;
    MOS_LOG_INF(RF_LOGSTR,"rf task Init ok msg queueu %p",Rf_GetMng()->hMsgQueue);
    return MOS_OK;
}

_INT Rf_TaskLoop(_VPTR pParam)
{
    _VPTR pstMsg;
    _UI uiLoopCnt = 0;
    _CTIME_T cNowTime = Mos_Time();
    
    while(Rf_GetMng()->ucRunFlag)
    {
        if(Mos_MsgQueueGetCount(Rf_GetMng()->hMsgQueue) > 0)
        {
            pstMsg = Mos_MsgQueuePop(Rf_GetMng()->hMsgQueue);
            Rf_ProcMsg(pstMsg);
            MOS_FREE(pstMsg);
        }
        
        if(uiLoopCnt%5 == 0 )
        {
            Rf_ProcDevListStatus(cNowTime);
        }
        uiLoopCnt++;
        Mos_Sleep(100);
    }
    return MOS_OK;
}


_INT Rf_ContrlJack(_UI uiAIIoTType, _LLID lluAIIoTID, _UC* pSignalValue,ST_ZJ_TRIGGER_INFO* pstTriggerInf)
{
    MOS_PARAM_NULL_RETERR(pSignalValue);
    MOS_PARAM_NULL_RETERR(pstTriggerInf);

    _INT iValue = 0;
    _UC ucCtrlCode = 0;
    ST_RF_CMDRSPINFO stCmdRspInf;
    JSON_HANDLE hRoot = Adpt_Json_Parse((_UC*)pSignalValue);
    if(hRoot == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"CtrlType"),&iValue);

    if(EN_RFDEV_KJIOTEVENT_OPEN == iValue)
    {
        ucCtrlCode = EN_DAC_LIGHT_ON;
    }
    else if(EN_RFDEV_KJIOTEVENT_CLOSE == iValue)
    {
        ucCtrlCode = EN_DAC_LIGHT_OFF;
    }
    MOS_MEMSET(&stCmdRspInf,0,sizeof(stCmdRspInf));
    
    Rf_ContrlRdDevice(uiAIIoTType,lluAIIoTID,ucCtrlCode,&stCmdRspInf);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_INT Rf_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    if(Rf_GetMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(RF_LOGSTR, "Already Start");
        return MOS_OK;
    }

    KjIoT_AddDevContrlFun(EN_ZJ_AIIOT_TYPE_JACK,Rf_ContrlJack,MOS_NULL,MOS_NULL,MOS_NULL);

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_SMALL_SIZE;
#endif
    Rf_GetMng()->ucRunFlag = 1;
    if(Mos_ThreadCreate((_UC*)"RF_MODULE",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                      Rf_TaskLoop,MOS_NULL, MOS_NULL,&Rf_GetMng()->hThread) == MOS_ERR)
    {
        Rf_GetMng()->ucRunFlag = 0;
        return MOS_ERR;
    }

    return MOS_OK;
}

_INT Rf_Stop()
{
    if(Rf_GetMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(RF_LOGSTR, "Already Stop");
        return MOS_OK;
    }
    Rf_GetMng()->ucRunFlag = 0;
    Mos_ThreadDelete(Rf_GetMng()->hThread);

    MOS_LOG_INF(RF_LOGSTR,"rf task stop ok");
    return MOS_OK;
}

_INT Rf_Destroy()
{
    if(Rf_GetMng()->ucInit == 0)
    {
        MOS_LOG_WARN(RF_LOGSTR, "Already Destroy");
        return MOS_OK;
    }
    Rf_GetMng()->ucInit = 0;
    Mos_MsgQueueDelete(Rf_GetMng()->hMsgQueue);
    Rf_GetMng()->hMsgQueue = MOS_NULL;
    MOS_LIST_RMVALL(&Rf_GetMng()->stDaclist, MOS_TRUE);

    MOS_LOG_INF(RF_LOGSTR,"rf task Destroy ok");
    return MOS_OK;
}

static _INT Zj_RfProcDacListAtion(_CTIME_T cTimeNow)
{
    _UI uiMsgLen    = 0;
    _UI uiNoRspCnt  = 0;
    _UI uiRspFlag   = 1;
    _UC aucMsgBuff[16];
    ST_MOS_LIST stNoRspList;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RFDEV_NODE *pstRdDevNode       = MOS_NULL;
    ST_RF_NORSPDEV_NODE *pstNoRspNode = MOS_NULL;
    
    if(Rf_GetMng()->uiActionStatus == EN_RF_DEVICE_ATION_TODELALL)
    {
        Rf_GetMng()->uiActionStatus = EN_RF_DEVICE_ATION_ALLDELING;
        uiMsgLen = Rf_PackDevMsg(RF_DEVICE_ALLDELECT,0,0,0,aucMsgBuff);
        if(Rf_SendRdData(aucMsgBuff,uiMsgLen) != MOS_OK)
        {
            Rf_GetMng()->uiActionStatus= EN_RF_DEVICE_ATION_OK;
            Rf_RdDevRspCommonCmd(&Rf_GetMng()->stCmdRspInf,MOS_ERR);
            return MOS_ERR;
        }
        Rf_GetMng()->cReqTime = cTimeNow;
        MOS_LOG_INF(RF_LOGSTR, "rf send delete all dev req ok");
    }
    else if(Rf_GetMng()->uiActionStatus == EN_RF_DEVICE_ATION_ALLDELING && cTimeNow - Rf_GetMng()->cReqTime > 5)
    {
        MOS_LOG_INF(RF_LOGSTR, "rf del all dev time out curaction[%d] ", Rf_GetMng()->uiActionStatus);
        Rf_GetMng()->uiActionStatus= EN_RF_DEVICE_ATION_OK;
        Rf_RdDevRspCommonCmd(&Rf_GetMng()->stCmdRspInf,MOS_ERR);
    }
    else if(Rf_GetMng()->uiActionStatus == EN_RF_DEVICE_ATION_MODCTRLING)
    {
        MOS_MEMSET(&stNoRspList, 0, sizeof(stNoRspList));
        FOR_EACHDATA_INLIST(&Rf_GetMng()->stDaclist,pstRdDevNode,stIterator)
        {
            if(pstRdDevNode->uiUseFlag == 0)
            {
                continue;
            }
            if(pstRdDevNode->uiActionType == EN_RF_DEVICE_ATION_MODCTRLING)
            {
                uiNoRspCnt++;
                if( pstRdDevNode->ucNoRspCnt >= 2)
                {
                    pstNoRspNode = (ST_RF_NORSPDEV_NODE*)MOS_MALLOCCLR(sizeof(ST_RF_NORSPDEV_NODE));
                    pstNoRspNode->lluDevId   = pstRdDevNode->lluDacId;
                    pstNoRspNode->uiDevType  = pstRdDevNode->uiDacType;
                    MOS_LIST_ADDTAIL(&stNoRspList, pstNoRspNode);
                }
                else
                {
                    uiRspFlag = 0;
                }
            }
        }
        if((uiNoRspCnt == 0 || MOS_LIST_GETCOUNT(&stNoRspList) > 0) && uiRspFlag == 1)
        {
            Rf_RspSwitchSceneCmd(&Rf_GetMng()->stCmdRspInf,uiNoRspCnt,&stNoRspList);
            Rf_GetMng()->uiActionStatus = EN_RF_DEVICE_ATION_OK;
        }
        MOS_LIST_RMVALL(&stNoRspList, MOS_TRUE);
    }
    return MOS_OK;
}

/********************************************************************************
***********************************************************************************/
static _INT Rf_InitRdDevStatus()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RFDEV_NODE *pstRdDevNode = MOS_NULL ;

    FOR_EACHDATA_INLIST(&Rf_GetMng()->stDaclist,pstRdDevNode,stIterator)
    {
        if(pstRdDevNode->uiUseFlag == 1)
        {
            pstRdDevNode->uiStatus++;
        }
    }
    return MOS_OK;
}

static ST_RFDEV_NODE *Rf_FindRdDevNode(_UC ucDacType,_LLID lluRdDevId)
{
    ST_RFDEV_NODE *pstRfDevNode ;
    ST_MOS_LIST_ITERATOR stIterator;
    
    FOR_EACHDATA_INLIST(&Rf_GetMng()->stDaclist,pstRfDevNode,stIterator)
    {
        if(pstRfDevNode->uiUseFlag && pstRfDevNode->uiDacType == ucDacType && pstRfDevNode->lluDacId == lluRdDevId)
        {
            break;
        }
    }
    
    return pstRfDevNode;
}

static ST_RFDEV_NODE *Rf_AllocRdDevNode(_UC ucDacType,_LLID lluRdDevId)
{
    ST_RFDEV_NODE *pstRfDevNode ;
    ST_MOS_LIST_ITERATOR stIterator;
    
    FOR_EACHDATA_INLIST(&Rf_GetMng()->stDaclist,pstRfDevNode,stIterator)
    {
        if(pstRfDevNode->uiUseFlag == 0)
        {
            pstRfDevNode->uiStatus    = 0;
            pstRfDevNode->ucNoRspCnt  = 0;
            pstRfDevNode->ucCurStatus = 0;
            break;
        }
    }
    if(pstRfDevNode == MOS_NULL)
    {
        pstRfDevNode = (ST_RFDEV_NODE*)MOS_MALLOCCLR(sizeof(ST_RFDEV_NODE));
        MOS_LIST_ADDTAIL(&Rf_GetMng()->stDaclist,pstRfDevNode);
    }
    pstRfDevNode->uiDacType = ucDacType;
    pstRfDevNode->lluDacId  = lluRdDevId;
    pstRfDevNode->uiUseFlag   = 1;
    return pstRfDevNode;
}

static _INT Rf_ProcRdDevAction( ST_RFDEV_NODE *pstRfDacNode,_CTIME_T cTimeNow)
{
    MOS_PARAM_NULL_RETERR(pstRfDacNode);

    _UC ucMsgType = 0;
    _UC aucMsgBuff[16];
    _UI uiMsgLen = 0;
    _UI uiMaxInterval = 0;
    
    switch(pstRfDacNode->uiActionType)
    {
        case EN_RF_DEVICE_ATION_TOADD:
        {
            ucMsgType = RF_DEVICE_ADD;
            break;
        }
        case EN_RF_DEVICE_ATION_TOCTRL:
        {
            ucMsgType = RF_DEVICE_CONTROL;
            break;
        }
        case EN_RF_DEVICE_ATION_TODEL:
        {
            ucMsgType = RF_DEVICE_DELECT;
            break;
        } 
        case EN_RF_DEVICE_ATION_DELING:
        case EN_RF_DEVICE_ATION_ADDING:
        {
            if(cTimeNow - pstRfDacNode->cReqTime > 5)
            {
                MOS_LOG_INF(RF_LOGSTR,"node[%p],dac[%d %llu],run action[%u] time out",
                            pstRfDacNode,pstRfDacNode->uiDacType,pstRfDacNode->lluDacId,pstRfDacNode->uiActionType);
                
                Rf_RdDevRspCommonCmd(&pstRfDacNode->stCmdRspInf,MOS_ERR_TIMEOUT);
                
                if(pstRfDacNode->uiActionType == EN_RF_DEVICE_ATION_ADDING)
                {
                    pstRfDacNode->uiUseFlag = 0;
                }
                else
                {
                    pstRfDacNode->uiActionType = EN_RF_DEVICE_ATION_OK;
                }
            }
            break;
        }
        case EN_RF_DEVICE_ATION_CTRLING:
        case EN_RF_DEVICE_ATION_MODCTRLING:
        {
            uiMaxInterval = 2*pstRfDacNode->ucNoRspCnt + 1;
            if(cTimeNow - pstRfDacNode->cReqTime >= uiMaxInterval && pstRfDacNode->ucNoRspCnt < 4)
            {
                pstRfDacNode->ucNoRspCnt++;
                pstRfDacNode->cReqTime = cTimeNow;
                uiMsgLen =  Rf_PackDevMsg(RF_DEVICE_CONTROL,pstRfDacNode->uiDacType,pstRfDacNode->ucCtrlCode,pstRfDacNode->lluDacId,aucMsgBuff);
                Rf_SendRdData(aucMsgBuff,uiMsgLen);
                Mos_Sleep(1000);
            }
            else if(pstRfDacNode->ucNoRspCnt >= 3 && pstRfDacNode->uiActionType == EN_RF_DEVICE_ATION_CTRLING)
            {
                Rf_RdDevRspCommonCmd(&pstRfDacNode->stCmdRspInf,MOS_ERR_TIMEOUT);
                pstRfDacNode->uiActionType = EN_RF_DEVICE_ATION_OK;
            }
            break;
        }
        default:
        {
            break;
        }
    }
    if(ucMsgType == 0)
    {
        return MOS_OK;
    }
    uiMsgLen =  Rf_PackDevMsg(ucMsgType,pstRfDacNode->uiDacType,pstRfDacNode->ucCtrlCode, pstRfDacNode->lluDacId,aucMsgBuff);
    pstRfDacNode->uiActionType++;
    pstRfDacNode->ucNoRspCnt++;
    pstRfDacNode->cReqTime = cTimeNow;
    MOS_LOG_INF(RF_LOGSTR, "rf process node[%p] dac[%d %llu], actiontype[%d]",
                pstRfDacNode, pstRfDacNode->uiDacType,pstRfDacNode->lluDacId,pstRfDacNode->uiActionType);
    
    if(Rf_SendRdData(aucMsgBuff,uiMsgLen) != MOS_OK)
    {
        MOS_LOG_ERR(RF_LOGSTR, "rf process node[%p],send rd data error", pstRfDacNode);
        if(pstRfDacNode->uiActionType != EN_RF_DEVICE_ATION_MODCTRLING)
        {
            Rf_RdDevRspCommonCmd(&pstRfDacNode->stCmdRspInf,MOS_ERR_NET);
        }
        pstRfDacNode->uiActionType = EN_RF_DEVICE_ATION_OK;
        if(ucMsgType == RF_DEVICE_ADD)
        {
            pstRfDacNode->uiUseFlag = 0;
        }
        return MOS_ERR;
    }
    return MOS_OK;
}

/**************************************************************************
处理设备的状态 保证控制消息正确执行
***************************************************************************/
_VOID Rf_ProcDevListStatus( _CTIME_T CNowTime)
{
    _UC ucQryStatus      = 0xff;
    _UC aucMsgBuff[16];
    _INT iMsgLen         =  0;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RFDEV_NODE *pstRfDevNode = MOS_NULL;

    if(Rf_GetMng()->uiActionStatus != 0 )
    {
        Zj_RfProcDacListAtion(CNowTime);
    }

    if( Rf_GetMng()->ucSyncFlag == 1 || 
        (Rf_GetMng()->ucSyncFlag == 2 && CNowTime - Rf_GetMng()->cSyncListTime > 30))
    {
        MOS_LOG_INF(RF_LOGSTR, "dtct start sync rd dev list");
        Rf_InitRdDevStatus();
        Rf_GetMng()->ucSyncFlag = 2;
        
        iMsgLen = Rf_PackDevMsg(RF_DEVICELIST_REQ,0,0,0,aucMsgBuff);
        if(Rf_SendRdData(aucMsgBuff,iMsgLen) == MOS_OK)
        {
            MOS_LOG_INF(RF_LOGSTR, "dtct send sync rd dev list ok"); 
        }
        Rf_GetMng()->ucCheckCnt++;
        Rf_GetMng()->cSyncListTime = CNowTime;
    }

    FOR_EACHDATA_INLIST(&Rf_GetMng()->stDaclist,pstRfDevNode,stIterator)
    {
        if(pstRfDevNode->uiUseFlag == 0)
        {
            continue;
        }
        if(pstRfDevNode->uiActionType != 0)
        {
            Rf_ProcRdDevAction(pstRfDevNode,CNowTime);
        }
        else if(Rf_RdDevBoolCtrler(pstRfDevNode->uiDacType) == MOS_TRUE )
        {
           if((CNowTime - pstRfDevNode->cReqTime > RF_ALIVE_TIME)||(pstRfDevNode->ucCurStatus == 0 && CNowTime - pstRfDevNode->cReqTime > 60))
            { 
                ucQryStatus = Rf_GetRdDevQueryCode(pstRfDevNode->uiDacType);
                if(ucQryStatus != 0XFF)
                {
                    MOS_LOG_INF(RF_LOGSTR,"RF process node[%p] action, dactype[%u %llu], send query req",
                        pstRfDevNode, pstRfDevNode->uiDacType, pstRfDevNode->lluDacId);
                    
                    pstRfDevNode->uiActionType = EN_RF_DEVICE_ATION_QUERYING; 
                    iMsgLen = Rf_PackDevMsg(RF_DEVICE_CONTROL,pstRfDevNode->uiDacType,ucQryStatus,pstRfDevNode->lluDacId,aucMsgBuff);
                    Rf_SendRdData(aucMsgBuff,iMsgLen);
                    pstRfDevNode->cReqTime = CNowTime;
                    pstRfDevNode->ucNoRspCnt++;
                }
                else
                {
                     MOS_LOG_WARN(RF_LOGSTR,"unknow dactype %u dacid %llu",pstRfDevNode->uiDacType, pstRfDevNode->lluDacId);
                }
            }
        }
        else if(CNowTime - pstRfDevNode->cReqTime > 30 && Rf_RdDevBoolClearStatus(pstRfDevNode->uiDacType))
        {
            pstRfDevNode->ucCurStatus = 0;
        }
    }
    return ;
}

static _INT Rf_ProcRdDevReportStatusMsg(_UI uiRdDevType,_LLID lluRdDevId,_UC ucStatus)
{
    _INT iEventId      = 0;
    _UI ucDevOpenFlag  = 0;
    _CTIME_T cNowSec   = Mos_Time();
    ST_RFDEV_NODE *pstRfDevNode  = Rf_FindRdDevNode(uiRdDevType,lluRdDevId);
    
    if(pstRfDevNode == MOS_NULL)
    {
        pstRfDevNode = Rf_FindRdDevNode(0,0);
        if(pstRfDevNode == MOS_NULL)
        {
            pstRfDevNode = Rf_AllocRdDevNode(0,0);
            MOS_LOG_INF(RF_LOGSTR,"RF creat new node dactype[%d] dacid[%llu] by qr",uiRdDevType,lluRdDevId);
        }
        else
        {
            MOS_LOG_INF(RF_LOGSTR,"RF creat new node dactype[%d] dacid[%llu] by option",uiRdDevType,lluRdDevId);
        }
        pstRfDevNode->lluDacId   = lluRdDevId;
        pstRfDevNode->uiDacType  = uiRdDevType;
        pstRfDevNode->uiUseFlag = 1;
    }
    if(pstRfDevNode->uiActionType == EN_RF_DEVICE_ATION_MODCTRLING || pstRfDevNode->uiActionType == EN_RF_DEVICE_ATION_CTRLING )
    {
        ucDevOpenFlag = Rf_CheckRdDevBoolOpen(uiRdDevType,ucStatus);
        if(pstRfDevNode->uiActionType == EN_RF_DEVICE_ATION_CTRLING )
        {
            Rf_RdDevRspCommonCmd(&pstRfDevNode->stCmdRspInf,MOS_OK);
        }
        pstRfDevNode->ucCurStatus   = ucStatus;
        MOS_LOG_INF(RF_LOGSTR,"dev %u %llu status %u",pstRfDevNode->uiDacType,pstRfDevNode->lluDacId,ucStatus);
    }
    else if(pstRfDevNode->uiActionType == EN_RF_DEVICE_ATION_ADDING)
    {
        Rf_RdDevRspCommonCmd(&pstRfDevNode->stCmdRspInf,MOS_OK);
    }
    else 
    {
        ST_CFG_HUBIOT_NODE* pstHubNode = Config_FindIotForHub(uiRdDevType,lluRdDevId);
        iEventId = Rf_GetEvntIdByDacStatus(uiRdDevType,ucStatus);
        if(pstHubNode  && pstHubNode->uiOpenFlag == 1 && uiRdDevType != EN_ZJ_AIIOT_TYPE_JACK)
        {
            KjIoT_SetEvent(uiRdDevType,lluRdDevId,iEventId,MOS_NULL);
        }
    }
    pstRfDevNode->ucNoRspCnt    = 0;
    pstRfDevNode->uiStatus      = 0;
    pstRfDevNode->ucCtrlCode    = 0;
    if(iEventId == EN_RFDEV_KJIOTEVENT_OPEN || EN_RFDEV_KJIOTEVENT_CLOSE == iEventId)
    {
        pstRfDevNode->ucCurStatus   = ucStatus;
    }
    pstRfDevNode->cReqTime      = cNowSec;
    pstRfDevNode->uiActionType  = EN_RF_DEVICE_ATION_OK;
    return MOS_OK;
}

static _INT Rf_CheckRdDevNodeEnable()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RFDEV_NODE *pstRfDevNode = MOS_NULL;

    Config_BegainSyncIotHubDevList();
    FOR_EACHDATA_INLIST(&Rf_GetMng()->stDaclist,pstRfDevNode,stIterator)
    {
        if(pstRfDevNode->uiUseFlag == 0)
        {
            continue;
        }
        Config_AddIotToHub(pstRfDevNode->uiDacType,pstRfDevNode->lluDacId);
        if(pstRfDevNode->uiStatus >= 3)
        {
            Config_SetIotEnableFlagInHub(pstRfDevNode->uiDacType,pstRfDevNode->lluDacId,0);    
        }
        else
        {
            Config_SetIotEnableFlagInHub(pstRfDevNode->uiDacType,pstRfDevNode->lluDacId,1); 
        }
    }
    Config_EndSyncIotHubDevList();
    return MOS_OK;
}

static _INT Rf_ProcRspRdDevListMsg(_UI uiMsgType,_UI uiRdDevType,_LLID lluRdDevId,_UC ucStatus)
{
    ST_RFDEV_NODE *pstRfDevNode = MOS_NULL; 
    if(uiRdDevType != 0 || lluRdDevId != 0)
    { 
        pstRfDevNode = Rf_FindRdDevNode(uiRdDevType,lluRdDevId);
        if(pstRfDevNode == MOS_NULL)
        {
            pstRfDevNode = Rf_AllocRdDevNode(uiRdDevType,lluRdDevId);
            Config_AddIotToHub(uiRdDevType,lluRdDevId);
            MOS_LOG_INF(RF_LOGSTR,"creat new node dactype[%d] dacid[%llu]",uiRdDevType,lluRdDevId);
        }
        pstRfDevNode->uiStatus       = 0;
        pstRfDevNode->cReqTime       = Mos_Time();
        pstRfDevNode->ucCurStatus    = ucStatus;
        pstRfDevNode->ucNoRspCnt     = 0;
        pstRfDevNode->uiActionType   = 0; 
    }
    
    if(uiMsgType == RF_DEVICELIST_END)
    {
        MOS_LOG_INF(RF_LOGSTR, "dtct sync rd dev list end, msgtype[%d] dactype[%d] dacid[%llu] status[%d]", uiMsgType, uiRdDevType, lluRdDevId, ucStatus);
        Rf_GetMng()->ucSyncFlag = 3;
        Rf_CheckRdDevNodeEnable();
    }
    return MOS_OK;
}

static _INT Rf_ProcDelRdDevRspMsg(_UI uiRdDevType,_LLID lluRdDevId,_UC ucDelType)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RFDEV_NODE *pstRfDevNode = MOS_NULL; 

    FOR_EACHDATA_INLIST(&Rf_GetMng()->stDaclist,pstRfDevNode,stIterator)
    {
        if(pstRfDevNode->uiActionType == EN_RF_DEVICE_ATION_DELING || ucDelType == 3)
        {
            if(pstRfDevNode->uiActionType == EN_RF_DEVICE_ATION_DELING )
            {
                MOS_LOG_INF(RF_LOGSTR, " node[%p] dactype[%d] dacid[%llu], action[%d], del succeed",
                    pstRfDevNode, pstRfDevNode->uiDacType,pstRfDevNode->lluDacId,pstRfDevNode->uiActionType);
                
                Rf_RdDevRspCommonCmd(&pstRfDevNode->stCmdRspInf,MOS_OK);
            }
            Config_DeleteIotFromHub(pstRfDevNode->uiDacType,pstRfDevNode->lluDacId);
            pstRfDevNode->uiUseFlag = 0;
        }
    }
    if(ucDelType == 3)
    {
        MOS_LOG_INF(RF_LOGSTR, "dtct recv del all rd dev success");
        Rf_RdDevRspCommonCmd(&Rf_GetMng()->stCmdRspInf,MOS_OK);
        Rf_GetMng()->uiActionStatus= 0;
    }
    return MOS_OK;
}

static _INT Rf_ProcAddDevRspMsg(_UI uiMsgType,_UI uiRdDevType,_LLID lluRdDevId,_UC ucStatus)
{
    ST_MOS_LIST_ITERATOR stIterator;    
    ST_RFDEV_NODE *pstRdDevNode = MOS_NULL;

    FOR_EACHDATA_INLIST(&Rf_GetMng()->stDaclist,pstRdDevNode,stIterator)
    {
        if(pstRdDevNode->uiActionType == EN_RF_DEVICE_ATION_ADDING)
        {
            pstRdDevNode->uiActionType = EN_RF_DEVICE_ATION_OK;
            if(uiMsgType == RF_DEVICE_EXIST)
            {
                MOS_LOG_INF(RF_LOGSTR, "Rf process node[%p] dac[%d %llu],action[%d],add fail for rd dev exist", 
                    pstRdDevNode, uiRdDevType,lluRdDevId,pstRdDevNode->uiActionType);
                Rf_RdDevRspCommonCmd(&pstRdDevNode->stCmdRspInf,MOS_ERR_EXIST);
            }
            else if(uiMsgType == RF_DEVICE_FULL)
            {
                MOS_LOG_INF(RF_LOGSTR, "Rf process node[%p]dac[%d %llu],action[%d], add fail for list is full", 
                    pstRdDevNode,uiRdDevType,lluRdDevId,pstRdDevNode->uiActionType);
                Rf_RdDevRspCommonCmd(&pstRdDevNode->stCmdRspInf,MOS_ERR_FULL);
                Config_DeleteIotFromHub(pstRdDevNode->uiDacType, pstRdDevNode->lluDacId);
                pstRdDevNode->uiUseFlag = 0;
            }
            break;
        }
    }
    return MOS_OK;
}

static _INT Rf_ProcRcvRdDevMsg(ST_RF_DEVICE_PROTO *pstRdDevMsg)
{
    MOS_PARAM_NULL_RETERR(pstRdDevMsg);

    _LLID lluRdDevId  = 0;
    MOS_MEMCPY(&lluRdDevId,pstRdDevMsg->aucSmartId,sizeof(lluRdDevId));
    lluRdDevId = Mos_InetNtoh64(lluRdDevId);
    
    MOS_LOG_INF(RF_LOGSTR,"rcv rd dev[%u,%llu] msg %u status %u option %u",
        pstRdDevMsg->ucDevType,lluRdDevId,pstRdDevMsg->ucHeader,pstRdDevMsg->ucStatus,pstRdDevMsg->ucOption);
        
    switch(pstRdDevMsg->ucHeader)
    {
        case RF_STATUS_REPORT:
        {
            Rf_ProcRdDevReportStatusMsg(pstRdDevMsg->ucDevType,lluRdDevId,pstRdDevMsg->ucStatus);
            break;
        }
        case RF_DEVICELIST_RES:
        case RF_DEVICELIST_END:
        {
            Rf_ProcRspRdDevListMsg(pstRdDevMsg->ucHeader,pstRdDevMsg->ucDevType,lluRdDevId,pstRdDevMsg->ucStatus);
            break;
        }
        case RF_DEVICE_DELSUSS:
        {
            Rf_ProcDelRdDevRspMsg(pstRdDevMsg->ucDevType,lluRdDevId,pstRdDevMsg->ucCrc);
            break;
        }
        case RF_DEVICE_EXIST :
        case RF_DEVICE_FULL:
        {
            Rf_ProcAddDevRspMsg(pstRdDevMsg->ucHeader,pstRdDevMsg->ucDevType,lluRdDevId,pstRdDevMsg->ucStatus);
            break;
        }
        default:
        {
            
        }
    }
    return MOS_OK;
}

_INT Rf_RcvRdDevMsg(_UC *pucMsg,_UI uiMsgLen)
{
    MOS_PARAM_NULL_RETERR(pucMsg);

    _UC ucCrc = 0;
    _UI i = 0;
    ST_RF_DEVICE_PROTO *pstRdDevMsg = (ST_RF_DEVICE_PROTO*)pucMsg;
    
    if( pucMsg == MOS_NULL || uiMsgLen != RF_MSG_LEN)
    {
        MOS_LOG_ERR(RF_LOGSTR,"rf parse msg Err, msg handle %p  msg len %d", pucMsg, uiMsgLen);
        return MOS_ERR;
    }
    ucCrc = pstRdDevMsg->ucDevType^pstRdDevMsg->ucStatus;
    for( i = 0;i < RF_DACID_LEN; i++)
    {
        ucCrc = ucCrc^pstRdDevMsg->aucSmartId[i];
    }
    if(ucCrc != pstRdDevMsg->ucCrc)
    {
        MOS_LOG_ERR(RF_LOGSTR, "recv rd device data %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x", 
            pucMsg[0], pucMsg[1], pucMsg[2], pucMsg[3], pucMsg[4], pucMsg[5], pucMsg[6], pucMsg[7], 
            pucMsg[8], pucMsg[9], pucMsg[10], pucMsg[11], pucMsg[12]);
        return MOS_ERR;
    }
    Rf_ProcRcvRdDevMsg(pstRdDevMsg);
    return uiMsgLen;
}

_INT  Rf_SetAntConnectStatus(_UI uiConStatus)
{
    if(Rf_GetMng()->uiAntConnectFlag != uiConStatus && uiConStatus == 1)
    {
        Rf_GetMng()->ucSyncFlag = 1;
    }
    Rf_GetMng()->uiAntConnectFlag = uiConStatus;

    MOS_LOG_INF(RF_LOGSTR,"set ant connect flag %u",uiConStatus);
    return MOS_OK;
}

/******************************************************************************************
消息设置
*******************************************************************************************/
_INT  Rf_AddRdDevice(_UI uiDacType,_LLID lluDacId,ST_RF_CMDRSPINFO *pstCmdRspInf)
{
    MOS_PARAM_NULL_RETERR(pstCmdRspInf);

    ST_RF_RDDEV_CMDMSG *pstCmdMsg = (ST_RF_RDDEV_CMDMSG*)MOS_MALLOCCLR(sizeof(ST_RF_RDDEV_CMDMSG));
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdMsg->stMsgHead.usMsgType = EN_RF_MSG_ADDDACDEV;
    pstCmdMsg->uiRdDevType = uiDacType;
    pstCmdMsg->lluRdDevId  = lluDacId;
    MOS_MEMCPY(&pstCmdMsg->stCmdRspInf, pstCmdRspInf, sizeof(ST_RF_CMDRSPINFO));
    return Mos_MsgQueuePush(Rf_GetMng()->hMsgQueue,pstCmdMsg); 
}

_INT  Rf_DeleteRdDevice(_UI uiDacType,_LLID lluDacId,ST_RF_CMDRSPINFO *pstCmdRspInf)
{
    MOS_PARAM_NULL_RETERR(pstCmdRspInf);

    ST_RF_RDDEV_CMDMSG *pstCmdMsg = (ST_RF_RDDEV_CMDMSG*)MOS_MALLOCCLR(sizeof(ST_RF_RDDEV_CMDMSG));
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdMsg->stMsgHead.usMsgType = EN_RF_MSG_RMVDACDEV;
    pstCmdMsg->uiRdDevType = uiDacType;
    pstCmdMsg->lluRdDevId  = lluDacId;
    MOS_MEMCPY(&pstCmdMsg->stCmdRspInf, pstCmdRspInf, sizeof(ST_RF_CMDRSPINFO));
    return Mos_MsgQueuePush(Rf_GetMng()->hMsgQueue,pstCmdMsg);   
}

_INT  Rf_ContrlRdDevice(_UI uiDacType,_LLID lluDacId,_UI uiCtrlType,ST_RF_CMDRSPINFO *pstCmdRspInf)
{
    MOS_PARAM_NULL_RETERR(pstCmdRspInf);

    ST_RF_RDDEV_CMDMSG *pstCmdMsg = MOS_NULL;
    if(Rf_RdDevBoolCtrler(uiDacType) == MOS_FALSE)
    {
        Rf_RdDevRspCommonCmd(pstCmdRspInf,MOS_OK);
        MOS_LOG_ERR(RF_LOGSTR,"rf device [%u %llu] isn't contrler", uiDacType, lluDacId);
        return MOS_ERR;
    }
    pstCmdMsg = (ST_RF_RDDEV_CMDMSG*)MOS_MALLOCCLR(sizeof(ST_RF_RDDEV_CMDMSG));
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdMsg->stMsgHead.usMsgType = EN_RF_MSG_CTRDACDEV;
    pstCmdMsg->uiRdDevType = uiDacType;
    pstCmdMsg->lluRdDevId  = lluDacId;
    pstCmdMsg->uiCtrlType  = uiCtrlType; 
    MOS_MEMCPY(&pstCmdMsg->stCmdRspInf, pstCmdRspInf, sizeof(ST_RF_CMDRSPINFO));
    return Mos_MsgQueuePush(Rf_GetMng()->hMsgQueue,pstCmdMsg);   
}

_INT  Rf_DeletAllRdDevice(ST_RF_CMDRSPINFO *pstCmdRspInf)
{
    MOS_PARAM_NULL_RETERR(pstCmdRspInf);

    ST_RF_RDDEV_CMDMSG *pstCmdMsg = (ST_RF_RDDEV_CMDMSG*)MOS_MALLOCCLR(sizeof(ST_RF_RDDEV_CMDMSG));
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdMsg->stMsgHead.usMsgType = EN_RF_MSG_RMVALLDEV;
    MOS_MEMCPY(&pstCmdMsg->stCmdRspInf, pstCmdRspInf, sizeof(ST_RF_CMDRSPINFO));
    return Mos_MsgQueuePush(Rf_GetMng()->hMsgQueue,pstCmdMsg);   
}

ST_MOS_LIST *Rf_GetRdDeviceList()
{
    return &Rf_GetMng()->stDaclist;
}

static _VOID Rf_ProcAddDacDeviceMsg(ST_RF_RDDEV_CMDMSG *pstCmdMsg)
{
    MOS_PARAM_NULL_NORET(pstCmdMsg);

    ST_RFDEV_NODE *pstRfDevNode = Rf_FindRdDevNode(pstCmdMsg->uiRdDevType,pstCmdMsg->lluRdDevId);
    if(pstRfDevNode == MOS_NULL)
    {
        pstRfDevNode = Rf_AllocRdDevNode(pstCmdMsg->uiRdDevType,pstCmdMsg->lluRdDevId);
        MOS_MEMCPY(&pstRfDevNode->stCmdRspInf,&pstCmdMsg->stCmdRspInf,sizeof(ST_RF_CMDRSPINFO));
        pstRfDevNode->uiActionType  = EN_RF_DEVICE_ATION_TOADD;
        MOS_LOG_INF(RF_LOGSTR,"Rf add node[%p] in rd list,action [%d],dactype[%d] dacid[%llu]",
                    pstRfDevNode,pstRfDevNode->uiActionType,pstRfDevNode->uiDacType,pstRfDevNode->lluDacId);
    }
    else if(pstCmdMsg->uiRdDevType == 0 && pstCmdMsg->lluRdDevId == 0)
    {
        MOS_MEMCPY(&pstRfDevNode->stCmdRspInf,&pstCmdMsg->stCmdRspInf,sizeof(ST_RF_CMDRSPINFO));
        pstRfDevNode->uiActionType = EN_RF_DEVICE_ATION_WAITADDING; 
        MOS_LOG_INF(RF_LOGSTR,"find exist node ");
    }
    else 
    {
        MOS_LOG_INF(RF_LOGSTR,"Rf find node in rd list, it is an exist rd dev, dactype[%d] dacid[%llu]",
                    pstCmdMsg->uiRdDevType,pstCmdMsg->lluRdDevId);
        Rf_RdDevRspCommonCmd(&pstCmdMsg->stCmdRspInf,MOS_ERR_EXIST);
    }
    return;
}

static _VOID Rf_ProcRmvDacDeviceMsg(ST_RF_RDDEV_CMDMSG *pstCmdMsg)
{
    MOS_PARAM_NULL_NORET(pstCmdMsg);

    ST_RFDEV_NODE *pstRfDevNode = Rf_FindRdDevNode(pstCmdMsg->uiRdDevType,pstCmdMsg->lluRdDevId);

    MOS_LOG_INF(RF_LOGSTR,"Rf delete dacdevice [%u, %llu],find local dev node %p",
        pstCmdMsg->uiRdDevType,pstCmdMsg->lluRdDevId,pstRfDevNode);
    if(pstRfDevNode != MOS_NULL)
    {
        MOS_MEMCPY(&pstRfDevNode->stCmdRspInf,&pstCmdMsg->stCmdRspInf,sizeof(ST_RF_CMDRSPINFO));
        pstRfDevNode->uiActionType   = EN_RF_DEVICE_ATION_TODEL;
    }
    else 
    {
        Rf_RdDevRspCommonCmd(&pstCmdMsg->stCmdRspInf,MOS_OK);
    }
    return;
}

static _VOID Rf_ProcDelAllDacDeviceMsg(ST_RF_RDDEV_CMDMSG *pstCmdMsg)
{ 
    MOS_PARAM_NULL_NORET(pstCmdMsg);

    MOS_LOG_INF(RF_LOGSTR,"Rf deletc devlist Now device cnt %d",MOS_LIST_GETCOUNT(&Rf_GetMng()->stDaclist));
    if(MOS_LIST_GETCOUNT(&Rf_GetMng()->stDaclist) > 0)
    {
        MOS_MEMCPY(&Rf_GetMng()->stCmdRspInf,&pstCmdMsg->stCmdRspInf,sizeof(ST_RF_CMDRSPINFO));
        Rf_GetMng()->uiActionStatus = EN_RF_DEVICE_ATION_TODELALL;
    }
    else
    {
        Rf_RdDevRspCommonCmd(&pstCmdMsg->stCmdRspInf,MOS_OK);
    }
    return;
}

static _VOID Rf_ProcContrlDacDeviceMsg(ST_RF_RDDEV_CMDMSG *pstCmdMsg)
{
    MOS_PARAM_NULL_NORET(pstCmdMsg);

    ST_RFDEV_NODE *pstRfDevNode = Rf_FindRdDevNode(pstCmdMsg->uiRdDevType,pstCmdMsg->lluRdDevId);
    if(pstRfDevNode == MOS_NULL)
    {
        Rf_RdDevRspCommonCmd(&pstCmdMsg->stCmdRspInf,MOS_ERR);
        return;
    }
    MOS_MEMCPY(&pstRfDevNode->stCmdRspInf,&pstCmdMsg->stCmdRspInf,sizeof(ST_RF_CMDRSPINFO));
    if(pstCmdMsg->uiCtrlType == 1)
        pstRfDevNode->ucCtrlCode     = Rf_GetRdDevOpenCode(pstCmdMsg->uiRdDevType);
    else
        pstRfDevNode->ucCtrlCode     = Rf_GetRdDevCloseCode(pstCmdMsg->uiRdDevType);
    
    pstRfDevNode->ucNoRspCnt     = 0;
    pstRfDevNode->uiActionType   = EN_RF_DEVICE_ATION_TOCTRL;

    MOS_LOG_INF(RF_LOGSTR,"dac[%d %llu] contrl type %u",pstCmdMsg->uiRdDevType,pstCmdMsg->lluRdDevId,pstCmdMsg->uiCtrlType);  
    return ;
}

static _VOID Rf_ProcMsg(_VPTR pstMsg)
{
    MOS_PARAM_NULL_NORET(pstMsg);

    ST_MOS_MSGHEAD *pstMsgHead = (ST_MOS_MSGHEAD*)pstMsg;
    
    switch(pstMsgHead->usMsgType)
    {
        case EN_RF_MSG_ADDDACDEV:
        {
            Rf_ProcAddDacDeviceMsg(pstMsg);
            break;
        }
        case EN_RF_MSG_RMVDACDEV:
        {
            Rf_ProcRmvDacDeviceMsg(pstMsg);
            break;
        }
        case EN_RF_MSG_RMVALLDEV:
        {
            Rf_ProcDelAllDacDeviceMsg(pstMsg);
            break;
        }
        case EN_RF_MSG_CTRDACDEV:
        {
            Rf_ProcContrlDacDeviceMsg(pstMsg);
            break;
        }
        default:{
            break;
        }
    }
    return ;
}

/****************************************************************************************************
处理命令模块的消息
*****************************************************************************************************/
static _INT Rf_RdDevRspCommonCmd(ST_RF_CMDRSPINFO *pstCmdRspInfo,_INT iStatus)
{
    MOS_PARAM_NULL_RETERR(pstCmdRspInfo);

    _INT iRet = 0;
    _UC aucMethod[16];
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hFromObject = MOS_NULL;
    JSON_HANDLE hToObject   = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;

    if(MOS_STRLEN(pstCmdRspInfo->aucPeerId) == 0)
    {
        MOS_LOG_INF(RF_LOGSTR,"peerid is NULL");
        return MOS_OK;
    }
    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",pstCmdRspInfo->ucMsgType,pstCmdRspInfo->ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(pstCmdRspInfo->uiSeqId));

    if(MOS_STRLEN(pstCmdRspInfo->stCmdSrcInf.aucDID) > 0)
    {
        hFromObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"FROM",hFromObject);
        Adpt_Json_AddItemToObject(hFromObject,(_UC*)"DID",Adpt_Json_CreateString(pstCmdRspInfo->stCmdSrcInf.aucDID));
    }
    
    if(MOS_STRLEN(pstCmdRspInfo->stCmdSrcInf.aucUserToken) > 0 || MOS_STRLEN(pstCmdRspInfo->stCmdSrcInf.aucSvrID) > 0)
    {
        hToObject = Adpt_Json_CreateObject();
        if(MOS_STRLEN(pstCmdRspInfo->stCmdSrcInf.aucUserToken) > 0)
        {
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"UserToken",Adpt_Json_CreateString(pstCmdRspInfo->stCmdSrcInf.aucUserToken));
        }
        if(MOS_STRLEN(pstCmdRspInfo->stCmdSrcInf.aucSvrID) > 0)
        {
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"SvrID",Adpt_Json_CreateString(pstCmdRspInfo->stCmdSrcInf.aucSvrID));
        }
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"TO",hToObject);
    }
    
    pucStrTmp = Adpt_Json_Print(hRoot);
    
    iRet = MsgMng_SendMsg(pstCmdRspInfo->aucPeerId,pstCmdRspInfo->uiSeqId,pstCmdRspInfo->ucMsgType,pstCmdRspInfo->ucMsgId,
        pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);

    MOS_LOG_INF(RF_LOGSTR,"send rsp %s to peerid %s iRet %d",pucStrTmp,pstCmdRspInfo->aucPeerId,iRet);
    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;
}

static _INT Rf_RspSwitchSceneCmd(ST_RF_CMDRSPINFO *pstCmdRspInfo,_UI uiNoRspCnt,ST_MOS_LIST *pstNoRspList)
{
    MOS_PARAM_NULL_RETERR(pstCmdRspInfo);
    MOS_PARAM_NULL_RETERR(pstNoRspList);

    return MOS_OK;
}

static _BOOL Rf_RdDevBoolCtrler(_UC ucDevType)
{
    if(ucDevType == EN_ZJ_AIIOT_TYPE_LIGHTSWITCH || ucDevType == EN_ZJ_AIIOT_TYPE_CURTAIN 
        || ucDevType == EN_ZJ_AIIOT_TYPE_JACK|| EN_ZJ_AIIOT_TYPE_ALARMBEER == ucDevType 
        || EN_ZJ_AIIOT_TYPE_JCAKHVAC == ucDevType || EN_ZJ_AIIOT_TYPE_MULTISWITCH == ucDevType 
        || EN_ZJ_AIIOT_TYPE_SHUTTERMOTOR == ucDevType || EN_ZJ_AIIOT_TYPE_BATTERYVALVE == ucDevType 
        || EN_ZJ_AIIOT_TYPE_INTELLOCK == ucDevType || EN_ZJ_AIIOT_TYPE_MULTICTR == ucDevType )
    {
        return MOS_TRUE;
    }
    return MOS_FALSE;
}

static _BOOL Rf_RdDevBoolClearStatus(_UC ucDevType)
{
    if(ucDevType == EN_ZJ_AIIOT_TYPE_SMOKETRANSDUCER || ucDevType == EN_ZJ_AIIOT_TYPE_GASSENSOR 
       || ucDevType == EN_ZJ_AIIOT_TYPE_PIR || ucDevType == EN_ZJ_AIIOT_TYPE_WATER 
       || EN_ZJ_AIIOT_TYPE_COSENSOR == ucDevType || EN_ZJ_AIIOT_TYPE_DOORBELL == ucDevType)
    {
        return MOS_TRUE;
    }
    return MOS_FALSE;
}

/***********************************************************
100 电量正常
1 低电量
************************************************************/
static _UC Rf_RdDevGetPowerStatus(_UC ucDevType,_UC ucStatus)
{
    _UC ucPowerStatus = 0;
    switch(ucDevType)
    {
        case EN_ZJ_AIIOT_TYPE_DOORSWITCH:
        {
            if(ucStatus == EN_DAC_DOOR_SWITCH_LOWPOWER)
            {
                ucPowerStatus = 1;
            }
            else if(ucStatus == EN_DAC_DOOR_SWITCH_POWER_OK)
            {
                ucPowerStatus = 100;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_SMOKETRANSDUCER:
        {
            if(ucStatus == EN_DAC_SMOKE_TRANSDUCER_LOWPOWER)
            {
                ucPowerStatus = 1;
            }
            else if(ucStatus == EN_DAC_SMOKE_TRANSDUCER_POWER_OK)
            {
                ucPowerStatus = 100;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_PIR:
        {
            if(ucStatus == EN_DAC_PIR_LOWPOWER)
            {
                ucPowerStatus = 1;
            }
            else if(ucStatus == EN_DAC_PIR_POWERON)
            {
                ucPowerStatus = 100;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_WATER:
        {
            if(ucStatus == EN_DAC_WATER_LOWPOWER)
            {
                ucPowerStatus = 1;
            }
            else if(ucStatus == EN_DAC_WATER_POWEON )
            {
                ucPowerStatus = 100;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_DOORBELL:
        {
            if(ucStatus == EN_DAC_DOORBELL_LOWPOWER)
            {
                ucPowerStatus = 1;
            }
            else if(ucStatus == EN_DAC_DOORBELL_POWER_OK )
            {
                ucPowerStatus = 100;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_ERG:
        {
            if(ucStatus == EN_DAC_ERG_LOWPOWER)
            {
                ucPowerStatus = 1;
            }
            else if(ucStatus == EN_DAC_ERG_POWERON)
            {
                ucPowerStatus = 100;
            }
            break;
        }
    }
    return ucPowerStatus;
}

/*******************************************************************
设备的查询码
********************************************************************/
static _UC Rf_GetRdDevQueryCode(_UC ucDevType)
{
    _UC ucQryCode = 0XFF;
    switch(ucDevType)
    {
        case EN_ZJ_AIIOT_TYPE_LIGHTSWITCH:
            ucQryCode = EN_DAC_LIGHT_CHECK;
            break;
        case EN_ZJ_AIIOT_TYPE_CURTAIN:
            ucQryCode = EN_DAC_CURTAIN_CHECK;
            break;
        case EN_ZJ_AIIOT_TYPE_JACK:
            ucQryCode = EN_DAC_JACK_CHECK;
            break;
        case EN_ZJ_AIIOT_TYPE_ALARMBEER:
            ucQryCode = EN_DAC_ALARM_BEER_CHECK;
            break;
        case EN_ZJ_AIIOT_TYPE_JCAKHVAC:
            ucQryCode = EN_DAC_JCAK_HVAC_CHECK;
            break;
        case EN_ZJ_AIIOT_TYPE_MULTISWITCH:
            ucQryCode = EN_DAC_MULTSWITCH_CHECK;
            break;
        case EN_ZJ_AIIOT_TYPE_SHUTTERMOTOR:
            ucQryCode = EN_DAC_SHUTTER_MOTOR_CHECK;
            break;
        case EN_ZJ_AIIOT_TYPE_BATTERYVALVE:
            ucQryCode = EN_DAC_BATTERY_VALVE_CHECK;
            break;
        default:
        {
            break;
        }

    }
    return ucQryCode;
}

/**************************************************************************
设备的 打开码
***************************************************************************/
static _UC Rf_GetRdDevOpenCode(_UC ucDevType)
{
    _UC ucOptCode = 0XFF;
    switch(ucDevType)
    {
        case EN_ZJ_AIIOT_TYPE_LIGHTSWITCH:
            ucOptCode = EN_DAC_LIGHT_ON;
            break;
        case EN_ZJ_AIIOT_TYPE_CURTAIN:
            ucOptCode = EN_DAC_CURTAIN_OPEN;
            break;
        case EN_ZJ_AIIOT_TYPE_JACK:
            ucOptCode = EN_DAC_JACK_ON;
            break;
        case EN_ZJ_AIIOT_TYPE_ALARMBEER:
            ucOptCode = EN_DAC_ALARM_BEER_ON;
            break;
        case EN_ZJ_AIIOT_TYPE_JCAKHVAC:
            ucOptCode = EN_DAC_JCAK_HVAC_ON;
            break;
        case EN_ZJ_AIIOT_TYPE_MULTISWITCH:
            ucOptCode = EN_DAC_MULTSWITCH_ALLON;
            break;
        case EN_ZJ_AIIOT_TYPE_SHUTTERMOTOR:
            ucOptCode = EN_DAC_SHUTTER_MOTOR_ON;
            break;
        case EN_ZJ_AIIOT_TYPE_BATTERYVALVE:
            ucOptCode = EN_DAC_BATTERY_VALVE_OPEN;
            break;
        default:
        {
            break;
        }
    }
    return ucOptCode;
}

/**************************************************************************
设备的 关闭码
***************************************************************************/
static _UC Rf_GetRdDevCloseCode(_UC ucDevType)
{
    _UC ucOptCode = 0XFF;
    switch(ucDevType)
    {
        case EN_ZJ_AIIOT_TYPE_LIGHTSWITCH:
            ucOptCode = EN_DAC_LIGHT_OFF;
            break;
        case EN_ZJ_AIIOT_TYPE_CURTAIN:
            ucOptCode = EN_DAC_CURTAIN_CLOSE;
            break;
        case EN_ZJ_AIIOT_TYPE_JACK:
            ucOptCode = EN_DAC_JACK_OFF;
            break;
        case EN_ZJ_AIIOT_TYPE_ALARMBEER:
            ucOptCode = EN_DAC_ALARM_BEER_OFF;
            break;
        case EN_ZJ_AIIOT_TYPE_JCAKHVAC:
            ucOptCode = EN_DAC_JCAK_HVAC_OFF;
            break;
        case EN_ZJ_AIIOT_TYPE_MULTISWITCH:
            ucOptCode = EN_DAC_MULTSWITCH_ALLOFF;
            break;
        case EN_ZJ_AIIOT_TYPE_SHUTTERMOTOR:
            ucOptCode = EN_DAC_SHUTTER_MOTOR_OFF;
            break;
        case EN_ZJ_AIIOT_TYPE_BATTERYVALVE:
            ucOptCode = EN_DAC_BATTERY_VALVE_CLOSE;
            break;
        default:
        {
            break;
        }
    }
    return ucOptCode;
}
/**************************************************************************
根据 设备 状态 返回 openflag
***************************************************************************/
static _UC Rf_CheckRdDevBoolOpen(_UC ucDevType,_UC ucStatus)
{
    _UC ucOpenFlag = 1;
    switch(ucDevType)
    {
        case EN_ZJ_AIIOT_TYPE_LIGHTSWITCH:
            if(ucStatus == EN_DAC_LIGHT_OFF)
                ucOpenFlag = 2;
            break;
        case EN_ZJ_AIIOT_TYPE_CURTAIN:
            if(ucStatus == EN_DAC_CURTAIN_CLOSE)
                ucOpenFlag = 2;
            break;
        case EN_ZJ_AIIOT_TYPE_JACK:
            if( ucStatus == EN_DAC_JACK_OFF)
                ucOpenFlag = 2;
            break;
        case EN_ZJ_AIIOT_TYPE_ALARMBEER:
             if(ucStatus == EN_DAC_ALARM_BEER_OFF)
                ucOpenFlag = 2;
            break;
        case EN_ZJ_AIIOT_TYPE_JCAKHVAC:
            if(ucStatus == EN_DAC_JCAK_HVAC_OFF)
                ucOpenFlag = 2;
            break;
        case EN_ZJ_AIIOT_TYPE_MULTISWITCH:
            if(ucStatus ==EN_DAC_MULTSWITCH_ALLOFF)
                ucOpenFlag = 2;
            break;
        case EN_ZJ_AIIOT_TYPE_SHUTTERMOTOR:
            if(ucStatus == EN_DAC_SHUTTER_MOTOR_OFF)
                ucOpenFlag = 2;
            break;
        case EN_ZJ_AIIOT_TYPE_BATTERYVALVE:
            if(ucStatus == EN_DAC_BATTERY_VALVE_CLOSE)
                ucOpenFlag = 2;
            break;
        default:
        {
            break;
        }
    }
    return ucOpenFlag;
}

/**************************************************************************
设备的是否 报警
***************************************************************************/
static _UC Rf_CheckRdDevBoolAlarm(_UC ucDevType,_UC ucStatus)
{
    _UC ucBAlarm = 0;
    switch(ucDevType)
    {
        case EN_ZJ_AIIOT_TYPE_DOORSWITCH:
            if(ucStatus == EN_DAC_DOOR_SWITCH_ALARM )
            {
                ucBAlarm = 1;
            }
            break;
        case EN_ZJ_AIIOT_TYPE_SMOKETRANSDUCER:
            if(ucStatus == EN_DAC_SMOKE_TRANSDUCER_ALARM)
            {
                ucBAlarm = 1;
            }
            break;
        case EN_ZJ_AIIOT_TYPE_GASSENSOR:
            if(ucStatus == EN_DAC_GAS_SENSOR_ALARM)
            {
                ucBAlarm = 1;
            }
            break;
        case EN_ZJ_AIIOT_TYPE_COSENSOR:
            if(ucStatus == EN_DAC_CO_SENSOR_ALARM)
            {
                ucBAlarm = 1;
            }
            break;
        case EN_ZJ_AIIOT_TYPE_PIR:
            if(ucStatus == EN_DAC_PIR_ALARM)
            {
                ucBAlarm = 1;
            }
            break;
        case EN_ZJ_AIIOT_TYPE_ERG:
            if(ucStatus == EN_DAC_ERG_ALAEM)
            {
                ucBAlarm = 1;
            }
            break;
        case EN_ZJ_AIIOT_TYPE_WATER:
            if(ucStatus == EN_DAC_WATER_ALARM)
            {
                ucBAlarm = 1;
            }
            break;
        case EN_ZJ_AIIOT_TYPE_DOORBELL:
        {
            if(ucStatus == EN_DAC_DOORBELL_OPEN)
            {
                ucBAlarm = 1;
            }
        }
        break;
        default:
        {
            ucBAlarm = 0;
            break;
        }
    }
    return ucBAlarm;
}

static _INT Rf_GetEvntIdByDacStatus(_UI uiDacType,_UC ucStatus)
{
    _INT iEvnetId = 0;
    switch(uiDacType)
    {
        case EN_ZJ_AIIOT_TYPE_DOORSWITCH:
        {
            if(ucStatus == EN_DAC_DOOR_SWITCH_ALARM )
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            else if(EN_DAC_DOOR_SWITCH_OFF == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_CLOSE;
            }
            else if(EN_DAC_DOOR_SWITCH_LOWPOWER == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_LOWPOWER;
            }
            else if(EN_DAC_DOOR_SWITCH_POWER_OK == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_POWEROK;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_SMOKETRANSDUCER:
        {
            if(ucStatus == EN_DAC_SMOKE_TRANSDUCER_ALARM)
            {
                 iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            else if(EN_DAC_SMOKE_TRANSDUCER_LOWPOWER == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_LOWPOWER;
            }
            else if(EN_DAC_SMOKE_TRANSDUCER_POWER_OK == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_POWEROK;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_GASSENSOR:
        {
            if(ucStatus == EN_DAC_GAS_SENSOR_ALARM)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_PIR:
        {
            if(ucStatus == EN_DAC_PIR_ALARM)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            else if(EN_DAC_PIR_LOWPOWER == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_LOWPOWER;
            }
            else if(EN_DAC_PIR_POWERON == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_POWEROK;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_WATER:
        {
            if(ucStatus == EN_DAC_WATER_ALARM)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            else if(ucStatus == EN_DAC_WATER_LOWPOWER)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_LOWPOWER;
            }
            else if(EN_DAC_WATER_POWEON == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_POWEROK;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_ERG:
        {
            if(ucStatus == EN_DAC_ERG_ALAEM)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            else if(EN_DAC_ERG_LOWPOWER == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_LOWPOWER;
            }
            else if(EN_DAC_ERG_POWERON == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_POWEROK;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_DOORBELL:
        {
            if(ucStatus == EN_DAC_DOORBELL_OPEN)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            else if(EN_DAC_DOORBELL_LOWPOWER == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_LOWPOWER;
            }
            else if(EN_DAC_DOORBELL_POWER_OK == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_POWEROK;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_COSENSOR:
        {
            if(ucStatus == EN_DAC_CO_SENSOR_ALARM)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            else if(EN_DAC_CO_SENSOR_LOWPOWER == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_LOWPOWER;
            }
            else if(EN_DAC_CO_SENSOR_POWER_OK == ucStatus)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_POWEROK;
            }
            break;
        }
        case EN_ZJ_AIIOT_TYPE_JACK:
        {
            if(ucStatus == EN_DAC_JACK_ON)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_OPEN;
            }
            else if(ucStatus == EN_DAC_JACK_OFF)
            {
                iEvnetId = EN_RFDEV_KJIOTEVENT_CLOSE;
            }
            break;
        }
        default:
        {
            break;
        }
    }
    return iEvnetId;
}

