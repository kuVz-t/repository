#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "http_type.h"
#include "msgmng_cmdserver.h"

int ZJ_SetEnergySavingType(unsigned int iEngeryType)
{
    return Config_SetEngeryType(iEngeryType);
}


int ZJ_SetAwakeAbility(unsigned int uiAwakeAbility)
{
    return Config_SetAwakeAbility(uiAwakeAbility);
}

int ZJ_SetPowerSupply(unsigned int uiSupplyFlag)
{
    return Config_SetPowerSupply(uiSupplyFlag);
}

int ZJ_SetStartSleepCb(ZJ_PFUN_STARTSLEEP pfuncStartSleep)
{
    ZJ_GetFuncTable()->pfuncStartSleep = pfuncStartSleep;
    return MOS_OK;
}

int ZJ_SetPowerLevel(unsigned int uiPowerLevel)
{
    return Config_SetPowerLevel((_INT)uiPowerLevel);
}

int ZJ_GetLinkAddr(unsigned char **pucAddrIpv4, unsigned char **pucAddrIpv6, unsigned int *puiPort, unsigned char **pucToken)
{
    int iLen = 0;
    if (!pucAddrIpv4 || !pucAddrIpv6 || !puiPort || !pucToken)
    {
        return MOS_ERR;
    }
    *puiPort = MsgMng_GetCmdServer()->uiLinkPort;

    iLen = MOS_STRLEN(MsgMng_GetCmdServer()->aucLinkAddrIPv4);
    if (iLen)
    {
        *pucAddrIpv4 = MOS_MALLOC(iLen+1);
        MOS_MEMCPY(*pucAddrIpv4, MsgMng_GetCmdServer()->aucLinkAddrIPv4, iLen+1); 
    }
    else
    {
        *pucAddrIpv4 = MOS_NULL;
    }

    iLen = MOS_STRLEN(MsgMng_GetCmdServer()->aucLinkAddrIPv6);
    if (iLen)
    {
        *pucAddrIpv6 = MOS_MALLOC(iLen+1);
        MOS_MEMCPY(*pucAddrIpv6, MsgMng_GetCmdServer()->aucLinkAddrIPv6, iLen+1); 
    }
    else
    {
        *pucAddrIpv6 = MOS_NULL;
    }

    iLen = MOS_STRLEN(MsgMng_GetCmdServer()->aucSleepToken);
    if (iLen)
    {
        *pucToken = MOS_MALLOC(iLen+1);
        MOS_MEMCPY(*pucToken, MsgMng_GetCmdServer()->aucSleepToken, iLen+1); 
    }
    else
    {
        *pucToken = MOS_NULL;
    }    
    return MOS_OK;
}
