#include "mos.h"
#include "zj_interface.h"
#include "adpt_json_adapt.h"
#include "config_api.h"
#include "msgmng_api.h"
#include "http_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

/********************************************************************************
*********************************************************************************/
int ZJ_SetDebugMode(int iDebugMode)
{
    Mos_SysSetDMode(iDebugMode);
    return MOS_OK;
}

int Zj_SetLogOpenFlag(int iOpenFlag)
{
    Mos_LogSetStatus(iOpenFlag);
    return MOS_OK;
}

/********************************************************************************
*********************************************************************************/
int ZJ_SetDebugLevel(EN_ZJ_LOG_LVL enDebugLevel)
{
    Mos_SysSetDLevel(enDebugLevel);
    return MOS_OK;
}

/**********************************************************************************
***********************************************************************************/
int ZJ_LogPrintf(unsigned char* pucFunName, unsigned int uiLine, unsigned char* pucPid,unsigned int uiLeval, unsigned char* pucFormat, ...)
{
    _INT iRet = 0;
    _ICH_VA_LIST vaList;
    _ICH_VA_START(vaList, pucFormat);
    iRet =  Mos_LogVPrintf(pucFunName,uiLine,pucPid,uiLeval,pucFormat,vaList);
    _ICH_VA_END(vaList);
    return iRet;
}
/* ***********************************************************************************
**************************************************************************************/
int ZJ_SetDevCollectLogFilesFunc(ZJ_PFUN_COLLECTLOGFILES pFunCollectLogFiles)
{
    ZJ_GetFuncTable()->pFunCollectLogFiles = pFunCollectLogFiles;
    return MOS_OK;
}

/****************************************************************************************
****************************************************************************************/
int ZJ_SetCollectLogFilesStatus(unsigned char* pucPeerID, unsigned int uiSessionID,int iStatus,
    unsigned char *pucDesInfo,unsigned char *pucFileName)
{
     if(uiSessionID == 0 || MOS_STRCMP(pucPeerID,MSGMNG_P2P_SERVER_ID) == 0)
    {
        if(iStatus == 0)
        {
            if (Mos_FileIsExist(pucFileName) == MOS_FALSE)
            {
                CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, -1, -1, "log file is no exist", 1);
                MOS_LOG_ERR(ZJ_LOGSTR,"peer %s sessionid %u status %d  filename %s is no exist", pucPeerID,uiSessionID,iStatus,pucFileName);
                return MOS_ERR;
            }
            CloudStg_UploadLocalLog(Mos_GetSessionId(),pucFileName,pucDesInfo);
        }
    }
    else
    {
        Http_SetCollectLogFileStatus(pucPeerID,uiSessionID,iStatus,pucFileName);
    }
    MOS_LOG_INF(ZJ_LOGSTR,"peer %s sessionid %u filename %s status %d", pucPeerID,uiSessionID,pucFileName,iStatus);
    return MOS_OK;
}

