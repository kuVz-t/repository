#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "msgmng_ai.h"
#include "ga1400_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

// 移动、人形pushflag回调
int ZJ_SetEventPushFlagCb(ZJ_PFUN_SET_EVENT_PUSHFLAG pfunSetEventPushFlag)
{
	ZJ_GetFuncTable()->pfunSetEventPushFlag =  pfunSetEventPushFlag;
	return MOS_OK;
}

// AI人脸识别能力   0.不支持；1.支持
int ZJ_SetDevAiFaceAbility(int iAiAbility)
{
	return Config_SetCommonAiAbility("AiFaceDiscernAbility", iAiAbility);
}

// AI 设备支持的最大布控底图数目
int ZJ_SetAiMaxPicNum(int iAiMaxPicNum)
{
	return Config_SetAiMaxPicNum(iAiMaxPicNum);
}

// AI 设备当前布控地图数目
int ZJ_SetAiCurPicNum(int iAiCurPicNum)
{
	return Config_SetAiCurPicNum(iAiCurPicNum);
}

// 客流统计能力     0.不支持，1.支持
int ZJ_SetHumCountAbility(unsigned int uiHumCountAbility)
{
	return Config_SetCommonAiAbility((_UC*)"HumanCountAbility", uiHumCountAbility);
}

// 设置布控人脸图片缓存路径
int ZJ_SetFaceFileCachePath(unsigned char *pucFaceCachePath)
{
	return Config_SetFaceFileCachePath(pucFaceCachePath);
}

// AI口罩识别能力   0.不支持；1.支持
int ZJ_SetDevAiMaskDiscernAbility(int iAiMaskDiscernAbility)
{
	return Config_SetCommonAiAbility((_UC*)"AiMaskDiscernAbility", iAiMaskDiscernAbility);
}

// AI电瓶车识别能力   0.不支持；1.支持
int ZJ_SetDevAiBatteryBikeAbility(int iAiBatteryBikeAbility)
{
	return Config_SetCommonAiAbility((_UC*)"AiBatteryBikeAbility", iAiBatteryBikeAbility);
}

// AI高空抛物识别能力   0.不支持；1.支持
int ZJ_SetDevAiHighParabolicAbility(int iAiHighParabolicAbility)
{
	return Config_SetCommonAiAbility((_UC*)"AiHighParabolicAbility", iAiHighParabolicAbility);
}

// AI烟火能力   0.不支持；1.支持
int ZJ_SetDevAiFlameAlarmAbility(int iAiFlameAlarmAbility)
{
	return Config_SetCommonAiAbility((_UC*)"AiFlameAlarmAbility", iAiFlameAlarmAbility);
}

// AI通用能力   Ai名称 / 0.不支持；1.支持
_ZJ_API int ZJ_SetDevAiCommonAbility(char *pcAiName, int iAiAbility)
{
	if (pcAiName && MOS_STRLEN(pcAiName))
	{
		if(MOS_STRSTR(pcAiName, "ability") != MOS_NULL)
		{
			MOS_LOG_ERR(ZJ_LOGSTR,"AiName is invalid %s", pcAiName);
			return MOS_ERR;
		}
		else if (MOS_STRSTR(pcAiName, "Ability") == MOS_NULL)
		{
			_UC aucMyAiName[64] = {0};
			MOS_VSNPRINTF(aucMyAiName, sizeof(aucMyAiName), "%sAbility", pcAiName);
			return Config_SetCommonAiAbility((_UC*)aucMyAiName, iAiAbility);
		}
	}
	
	return Config_SetCommonAiAbility((_UC*)pcAiName, iAiAbility);
}

// Ai事件注册回调函数&&回调定义
int ZJ_SetAiPicCB(ZJ_PFUN_CREAT_AILABLE pFunCreateLabel,
						  ZJ_PFUN_MODIFY_PICINF pFunModifyPicLabel,
						  ZJ_PFUN_ADDAIPICCB 	pFunAddSingleAiPic, 
						  ZJ_PFUN_DELAIPICSCB 	pFunDelSingleAiPic,
						  ZJ_PFUN_DELAILABLE 	pFunDelLabel)
{
	ZJ_GetFuncTable()->pFunCreateLabel 		= pFunCreateLabel;
	ZJ_GetFuncTable()->pFunModifyPicLabel 	= pFunModifyPicLabel;
	ZJ_GetFuncTable()->pFunAddSingleAiPic 	= pFunAddSingleAiPic;
	ZJ_GetFuncTable()->pFunDelSingleAiPic 	= pFunDelSingleAiPic;
	ZJ_GetFuncTable()->pFunDelLabel 		= pFunDelLabel;
	return MOS_OK;
}

// 注册回调：释放上报人脸图和背景图的缓存
_ZJ_API int ZJ_SetFreeAiPicCacheCB(ZJ_PFUN_FREEAIPICCACHE pFunFreeAiPicCache)
{
	ZJ_GetFuncTable()->pFunFreeAiPicCache 	= pFunFreeAiPicCache;
	return MOS_OK;
}

// 注册函数，图片自动录入开关
int ZJ_SetAiAutoInputCb(ZJ_PFUN_SETAUTOINPUTFLAG pFunSetAutoInputFlag)
{
	ZJ_GetFuncTable()->pFunSetAutoInputFlag =  pFunSetAutoInputFlag;
	return MOS_OK;
}

// Ai事件信号输入 (布控)
void ZJ_SetAiPicEvent(unsigned int uiAIIoTType, unsigned long long lluAIIoTID,
							  unsigned int uiEvent, ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInfo)
{
	_UI uiAIFaceUploadPicNodeCount = 0;
	Config_GetUploadAIFacePicTaskNodeCount(0, &uiAIFaceUploadPicNodeCount);
	if (uiAIFaceUploadPicNodeCount <= AI_FACEREC_ALARM_LISTNODE_MAXCOUNT)
	{
		MOS_LOG_INF(ZJ_LOGSTR, "AI FaceRec Pic Event Come Time:%llu  BG_W:%u BG_H:%u PIC_W:%u PIC_H:%u UploadNodeCount:%u",
						pstAiPicEventInfo->lluTimeStamp, (_UI)(pstAiPicEventInfo->dBgWidth), (_UI)(pstAiPicEventInfo->dBgHeight),
						(_UI)(pstAiPicEventInfo->pstAiPicHead->dWidth), (_UI)(pstAiPicEventInfo->pstAiPicHead->dHeight), uiAIFaceUploadPicNodeCount);

		// AIPic布控告警消息事件推送到云端 351C
		MsgMng_UploadAIPicEventToDxServer(uiAIIoTType, lluAIIoTID, uiEvent, pstAiPicEventInfo);
	}
	else
	{
		MOS_LOG_ERR(ZJ_LOGSTR,"AI FaceRec Pic AIFaceUploadPicNodeCount(%u) > AI_FACEREC_ALARM_LISTNODE_MAXCOUNT(%d), Set Event Err", uiAIFaceUploadPicNodeCount, (_INT)AI_FACEREC_ALARM_LISTNODE_MAXCOUNT);
		// 通知厂商清除AI图片数据缓存 ADD by LWJ
        if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
        {
			_INT iRet = MOS_ERR;
            iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstAiPicEventInfo->pstAiPicHead->aucLabelID, pstAiPicEventInfo->pstAiPicHead->pucPicBuf, pstAiPicEventInfo->pucBgJpgBuff);
            if (MOS_OK == iRet)
            {
                // MOS_LOG_INF(ZJ_LOGSTR,"Device pFunFreeAiPicCache DispositionID:%s OK ", pstAiPicEventInfo->pstAiPicHead->aucLabelID);
            }
            else
            {
				_UC aucStrErrLog[128] = {0};
				MOS_VSNPRINTF(aucStrErrLog, sizeof(aucStrErrLog), "Device pFunFreeAiPicCache DispositionID:%s Bgbuf:%p Picbuf:%p return failed", pstAiPicEventInfo->pstAiPicHead->aucLabelID, pstAiPicEventInfo->pucBgJpgBuff, pstAiPicEventInfo->pstAiPicHead->pucPicBuf);        
				CloudStg_UploadLogEx2(ZJ_LOGSTR, Mos_GetSessionId(), __FUNCTION__, -1, 
										EN_AI_RT_UPLOAD_FACEREC_FUNCFREECACHE_DEV_RT_ERR, aucStrErrLog, MOS_NULL, 1);   
            }
        }
        else
        {
            MOS_LOG_ERR(ZJ_LOGSTR,"Device pFunFreeAiPicCache is NULL!");
        }
		return;
	}
	return;
}

// Ai事件信号输入(抓拍)(压缩方式)
void ZJ_SetAiPicEventEx(unsigned int uiAIIoTType, unsigned long long lluAIIoTID,
                                unsigned int uiEvent, ST_ZJ_AI_ZIP_EVENT_SIGNAL *pstZipEventInfo)
{
	_UI uiAIZipUploadPicNodeCount = 0;
	Config_GetUploadAIZipTaskNodeCount(0, &uiAIZipUploadPicNodeCount);
	if (uiAIZipUploadPicNodeCount <= AI_ZIP_ALARM_LISTNODE_MAXCOUNT)
	{
		MOS_LOG_INF(ZJ_LOGSTR,"AI PicEx ZIP Event Come Time:%llu ZipName:%s UploadPNodeCount:%u", pstZipEventInfo->pstZipBgFileHead->lluTimeStamp, pstZipEventInfo->aucFilePath, uiAIZipUploadPicNodeCount);

		// AI识别消息(ZIP打包)上传到云端 3522
		MsgMng_UploadAIZipEventToDxServer(uiAIIoTType, lluAIIoTID, uiEvent, pstZipEventInfo);
	}
	else
	{
		MOS_LOG_ERR(ZJ_LOGSTR,"AI ZIP Pic AIZipUploadPicNodeCount(%u) > AI_ZIP_ALARM_LISTNODE_MAXCOUNT(%d), Set Event Err", uiAIZipUploadPicNodeCount, (_INT)AI_ZIP_ALARM_LISTNODE_MAXCOUNT);
        // 删除ZIP文件
        Mos_FileRmv(pstZipEventInfo->aucFilePath);
		return;
	}
	return;
}

// 客流统计回调设置
int ZJ_SetHumanCountFuncsCB(ZJ_PFUN_SETHUMANCOUNT_PARAM   pfunSetHumCountParam,
									ZJ_PFUN_SETHUMANCOUNT_REGIONS pfunSetHumCountRegions)
{
	ZJ_GetFuncTable()->pfunSetHumCountParam		= pfunSetHumCountParam;
	ZJ_GetFuncTable()->pfunSetHumCountRegions 	= pfunSetHumCountRegions;
	return MOS_OK;
}

// 上传客流统计
int ZJ_SetHumanCountNum(unsigned int uiHumInNum,unsigned int uiHumOutNum,
								unsigned char *pucStartDate,unsigned char *pucEndDate)
{
	MOS_LOG_INF(ZJ_LOGSTR,"Human Count Num Is Coming ");
	// 上传客流统计到云端 3520
	MsgMng_UploadHumanCountInfToDxServer(uiHumInNum, uiHumOutNum, pucStartDate, pucEndDate);

	return MOS_OK;
}

// 小喇叭注册回调
int ZJ_SetSmallSpeakerCBFuncs(ZJ_PFUN_START_CUSTOM_AUDIO 	  pfun_StartDownData,
                                      ZJ_PFUN_CUSTOM_AUDIOD_TRANS 	  pfun_DataTrans,
                                      ZJ_PFUN_STOP_CUSTOM_AUDIO       pfun_StopDownData,
                                      ZJ_PFUN_BROADCAST_CUSTOM_STRING pfun_BroadCastCustomStr)
{
	ZJ_GetFuncTable()->pfun_StartDownData		= pfun_StartDownData;
	ZJ_GetFuncTable()->pfun_DataTrans 			= pfun_DataTrans;
	ZJ_GetFuncTable()->pfun_StopDownData 		= pfun_StopDownData;
	ZJ_GetFuncTable()->pfun_BroadCastCustomStr 	= pfun_BroadCastCustomStr;
	return MOS_OK;
}
