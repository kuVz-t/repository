#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "http_api.h"
#include "msgmng_api.h"
#include "adpt_crypto_adapt.h"
#include "adpt_json_adapt.h"
#include "config_auto_conn.h"
#include "qualityprobe_api.h"

#ifdef BUILD_IMSSDK_FALG
#include "ims_render.h"
#endif

#define TAG "Network"

static int g_networkType = -1;

int ZJ_SetNetWorkType(EN_ZJ_NETWORK_TYPE enNetType)
{
    if (g_networkType != enNetType)
    {
        g_networkType = enNetType;

        MsgMng_SetNetWorkStatus(enNetType);
        Mos_InetSetNetType(enNetType);

    #ifdef BUILD_IMSSDK_FALG
        ImsMedia_Task_SetNetworkType(enNetType);
    #endif

        Http_SetNetworkType(enNetType);
    }

    return MOS_OK;
}

int ZJ_SetNetErrStatus(EN_ZJ_NETWORK_ERR_STATUS enNetWorkErrStatus)
{
    return MOS_OK;   
}

int ZJ_SetWifiCB(ZJ_PFUN_DEVICE_SETWIFI pfuncSetWifi, ZJ_PFUN_DEVICE_GETWIFI pfuncGetWifi,
                    ZJ_PFUN_DEVICE_GETNETINFO pfunGetCurNetInfo)
{
    ZJ_GetFuncTable()->pfuncSetWifi = pfuncSetWifi;
    ZJ_GetFuncTable()->pfuncGetWifi = pfuncGetWifi;
    ZJ_GetFuncTable()->pfunGetCurNetInfo = pfunGetCurNetInfo;
    return MOS_OK;
}

int ZJ_SetWifiSetAbility(unsigned int uiSetWifiAbility)
{
    return Config_SetWifiSetAbility(uiSetWifiAbility);
}

/**********************************************************************************
利用ZJ_GetAliveStreamCnt：当前直联观看人数，>1 的时候， 可以暂停二维码识别
pstrQRCode:           识别到的二维码字符串

n=xxxxxx&p=xxxxx&i=xxxx&f=30 //30 31 国内 32 33国外
***********************************************************************************/
int ZJ_ParseWifiQRCodeString(unsigned char *pstrQRCode)
{
    _UI uiLen    = 0;
    _UI uiQRType = 0;
    _UC aucSSid[64]    ={0};
    _UC aucPwd[128]    ={0};
    _UC aucBindCode[64]={0};
    _UC *pstrTmp = MOS_NULL;
    _UC *pucEnd  = MOS_NULL; 
    ST_CFG_ISPINF stIspInf;
    ST_CFG_CORE_MNG *pstCoreInf = Config_GetCoreMng();
    
    if(MOS_STRLEN(pstrQRCode) == 0)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    MOS_LOG_INF(ZJ_LOGSTR, "recv WifiQR string is: %s",pstrQRCode);
    
    MOS_MEMSET(aucSSid, 0, 64);
    MOS_MEMSET(aucPwd,  0, sizeof(aucPwd));
    
    pstrTmp = MOS_STRSTR(pstrQRCode,"n=");
    if(pstrTmp == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    pstrTmp += MOS_STRLEN("n=");
    pucEnd = MOS_STRSTR(pstrTmp,"&p=");
    uiLen = pucEnd - pstrTmp;
    if(uiLen >= 64)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    MOS_STRNCPY(aucSSid, pstrTmp, uiLen);

    pstrTmp = pucEnd += MOS_STRLEN("&p=");
    if(pstrTmp == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    pucEnd = MOS_STRSTR(pstrTmp,"&i=");
    if(pucEnd == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    uiLen = pucEnd - pstrTmp;
    if(uiLen > 0 && uiLen < 128){
        MOS_STRNCPY(aucPwd, pstrTmp, uiLen);
    } 

    pstrTmp = pucEnd + MOS_STRLEN("&i=");
    pucEnd = MOS_STRSTR(pstrTmp,"&f=");
    if(pucEnd == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    uiLen = pucEnd - pstrTmp;

    MOS_MEMSET(aucBindCode,0,64);
    MOS_STRNCPY(aucBindCode, pstrTmp, uiLen);
    
    pucEnd += MOS_STRLEN("&f=");
    uiQRType = MOS_ATOI(pucEnd);
    
    if(MOS_STRLEN(pstCoreInf->stIspInf.aucCountryId) == 0)
    {
        if(uiQRType == 30 || uiQRType == 31)
        {
            MOS_MEMCPY(&stIspInf, &pstCoreInf->stIspInf, sizeof(ST_CFG_ISPINF));
            MOS_STRNCPY(stIspInf.aucCountryId, "CN", sizeof(stIspInf.aucCountryId));
            Config_SetDevIspInf(&stIspInf);
        }
        else 
        {
            MOS_MEMCPY(&stIspInf, &pstCoreInf->stIspInf, sizeof(ST_CFG_ISPINF));
            MOS_STRNCPY(stIspInf.aucCountryId, "OTH", sizeof(stIspInf.aucCountryId));
            Config_SetDevIspInf(&stIspInf);
        }
    }
	Config_SetDevNeedBindFlag(aucBindCode,(_UC*)"");
    Http_SetDevJoinGroupFlag(aucBindCode,(_UC*)"");
    MOS_LOG_INF(ZJ_LOGSTR,"get ssid %s pwd %s flag %u bindcode %s func %p ",aucSSid,aucPwd,uiQRType,aucBindCode,ZJ_GetFuncTable()->pfuncSetWifi);

    if(ZJ_GetFuncTable()->pfuncSetWifi)
    {
        _INT iRet = MOS_ERR; 
        iRet = ZJ_GetFuncTable()->pfuncSetWifi(EN_ZJ_NETWORK_TYPE_WIFI,(char*)aucSSid, (char*)aucPwd,0);
        if (MOS_ERR == iRet)
        {
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            MOS_LOG_ERR(ZJ_LOGSTR,"Device pfuncSetWifi ssid %s err",aucSSid);
        }
        else
        {
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
        }
    }
    else
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        MOS_LOG_ERR(ZJ_LOGSTR,"pfuncSetWifi is NULL!");
    }
    return MOS_OK;

}

void Zj_DecryptWIFIInfo(unsigned char *key,unsigned char *text,unsigned char *result,unsigned int uiLength, unsigned int uiKeyLen)
{
    if(!key || !text || !result)
        return;

	_UI index,i,j;
	_UI keyArr[CFG_STRING_MAXLEN];
	_UI reversedKeyArr[CFG_STRING_MAXLEN];
    MOS_MEMSET(keyArr, 0, CFG_STRING_MAXLEN);
    MOS_MEMSET(reversedKeyArr, 0, CFG_STRING_MAXLEN);
	for (i = 0; (i < uiKeyLen) && ((2*i + 1)<CFG_STRING_MAXLEN); i++) 
	{
		keyArr[2*i] = key[i]/10;
		keyArr[2*i + 1] = key[i]%10;
		reversedKeyArr[uiKeyLen*2 - 2 - 2*i] = key[i]/10;
		reversedKeyArr[uiKeyLen*2 - 1 - 2*i] = key[i]%10;
	}
	if (result) {
		for (j=0; j < uiLength; j++) 
		{
			if (j%2 == 0) 
			{
				index = (j%(uiKeyLen * 4))/2;
				result[j] = (text[j]^keyArr[index]);
			} 
			else
			{
				index = (j%(uiKeyLen * 4) - 1)/2;
				result[j] =( text[j]^reversedKeyArr[index]);
			}
		}
	}	
}

int ZJ_ParseHxQRCodeString(unsigned char *pstrQRCode)
{
	_UI uiRQCodeLen = 0;
	_UI uiTmpLen = 0;
    _UC aucSSid[128];
    _UC aucPwd[128];
	_UC aucBindCode[128];
	_UC aucK2[128];
	_UC aucK1[128];
	_UC aucE2[128];
	_UC aucS1[128];
	_UC aucS2[128];

	_UI uiSsidLen = 0;
	_UI uiOtherLen = 0;
    _UC *pstrTmp = MOS_NULL;
    _UC *pucEnd  = MOS_NULL; 

	MOS_MEMSET(aucSSid, 0, 128);
    MOS_MEMSET(aucPwd,  0, 128);
	MOS_MEMSET(aucBindCode,  0, 128);
    MOS_MEMSET(aucK2,  0, 128);
    MOS_MEMSET(aucK1,  0, 128);
    MOS_MEMSET(aucE2,  0, 128);
    MOS_MEMSET(aucS1,  0, 128);
    MOS_MEMSET(aucS2,  0, 128);
	
	uiRQCodeLen = MOS_STRLEN(pstrQRCode);
    if(uiRQCodeLen == 0)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
	MOS_LOG_INF(ZJ_LOGSTR, "recv QR string is: %s",pstrQRCode);
	
    //first find '|' ,get k1 k2
	pstrTmp = MOS_STRSTR(pstrQRCode,"|");
	if(pstrTmp ==  MOS_NULL)
	{
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
		return MOS_ERR;
	}
	pstrTmp += MOS_STRLEN("|");

    MOS_STRCPY(aucK2,pstrTmp);
	uiTmpLen = uiRQCodeLen - MOS_STRLEN(pstrTmp);
	pstrTmp -= uiTmpLen;

    MOS_STRNCPY(aucK1,pstrTmp,uiTmpLen-1);

	//base64 Decode
	uiSsidLen = Adpt_Base64_Dec(aucK1, aucS1);
	uiOtherLen = Adpt_Base64_Dec(aucK2, aucE2);

	// XOR
	Zj_DecryptWIFIInfo(Config_GetSystemMng()->aucDevUID, aucE2, aucS2, uiOtherLen,MOS_STRLEN(Config_GetSystemMng()->aucDevUID));
	
	pstrTmp = MOS_STRSTR(aucS2,"P:");
    if(pstrTmp == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        MOS_LOG_ERR(ZJ_LOGSTR, "Parse err: aucK2 %s aucE2 %s aucS2 : %s UID %s",aucK2,aucE2,aucS2,Config_GetSystemMng()->aucDevUID);
        return MOS_ERR;
    }

	pstrTmp += 2;
	pucEnd = MOS_STRSTR(aucS2,";C:");
    if(pucEnd == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        MOS_LOG_ERR(ZJ_LOGSTR, "Parse 22 err: aucK2 %s aucE2 %s aucS2 : %s UID %s",aucK2,aucE2,aucS2,Config_GetSystemMng()->aucDevUID);
        return MOS_ERR;
    }
    pucEnd += 3;
    while (MOS_STRSTR(pucEnd,";C:"))
    {
        pucEnd += 3;
    }
    pucEnd -= 3;

	MOS_STRNCPY(aucPwd,pstrTmp,pucEnd - pstrTmp);
	
	MOS_STRCPY(aucBindCode,pucEnd + 3);
	MOS_STRCPY(aucSSid,aucS1);
    
    Config_SetDevNeedBindFlag(aucBindCode,(_UC*)"");
    
    // 私密打印屏蔽
    // MOS_LOG_INF(ZJ_LOGSTR,"get ssid %s pwd %s bindCode %s func %p ",aucSSid,aucPwd,aucBindCode,ZJ_GetFuncTable()->pfuncSetWifi);

    if(ZJ_GetFuncTable()->pfuncSetWifi)
    {
        _INT iRet = MOS_ERR;
        iRet = ZJ_GetFuncTable()->pfuncSetWifi(EN_ZJ_NETWORK_TYPE_WIFI,(char*)aucSSid, (char*)aucPwd,0);
        if (MOS_ERR == iRet)
        {
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
            MOS_LOG_ERR(ZJ_LOGSTR,"Device pfuncSetWifi ssid %s err",aucSSid);
        }
        else
        {
            Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
        }
    }
    else
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        MOS_LOG_ERR(ZJ_LOGSTR,"pfuncSetWifi is NULL!");
    }

	return MOS_OK;
    
    
}

/**********************************************************************************
pstrQRCode:           识别到的二维码字符串
g=%s&t=%s&b=%s&f=34
g：组ID
t：GToken
b：绑定码
***********************************************************************************/
int ZJ_Parse4GQRCodeString(unsigned char *pstrQRCode)
{
    _UI uiLen    = 0;
    _UI uiQRType = 0;
    _UC aucGtoken[64];
    _UC aucBindCode[64];
    _UC aucGid[64];
    _UC *pstrTmp = MOS_NULL;
    _UC *pucEnd  = MOS_NULL; 
    ST_CFG_ISPINF stIspInf;
	ST_CFG_CORE_MNG *pstCoreInf = Config_GetCoreMng();

    if(MOS_STRLEN(pstrQRCode) == 0)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    MOS_LOG_INF(ZJ_LOGSTR, "recv 4GQR string is: %s",pstrQRCode);
    
    MOS_MEMSET(aucBindCode, 0, 64);
    MOS_MEMSET(aucGtoken, 0, 64);
    MOS_MEMSET(aucGid, 0, 64);
    
    pstrTmp = MOS_STRSTR(pstrQRCode,"g=");
    if(pstrTmp == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    pstrTmp += MOS_STRLEN("g=");
    pucEnd = MOS_STRSTR(pstrTmp,"&t=");
    uiLen = pucEnd - pstrTmp;
    if(uiLen >= 64)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    MOS_STRNCPY(aucGid, pstrTmp, uiLen);

    pstrTmp = pucEnd + MOS_STRLEN("&t=");
    if(pstrTmp == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    pucEnd = MOS_STRSTR(pstrTmp,"&b=");
    if(pucEnd == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    uiLen = pucEnd - pstrTmp;
    if(uiLen > 0 && uiLen < 64){
        MOS_STRNCPY(aucGtoken, pstrTmp, uiLen);
    } 

    pstrTmp = pucEnd + MOS_STRLEN("&b=");
    if(pstrTmp == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    pucEnd = MOS_STRSTR(pstrTmp,"&f=");
    if(pucEnd == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    uiLen = pucEnd - pstrTmp;
    if(uiLen > 0 && uiLen < 64){
        MOS_STRNCPY(aucBindCode, pstrTmp, uiLen);
    } 

    pstrTmp = pucEnd + MOS_STRLEN("&f=");
    if(pstrTmp == MOS_NULL)
    {
        Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_FAIL, COUNT_VALUE_FAIL);
        return MOS_ERR;
    }
    uiQRType = MOS_ATOI(pstrTmp);
    
    if(MOS_STRLEN(pstCoreInf->stIspInf.aucCountryId) == 0)
    {
        if(uiQRType == 34)
        {
            MOS_MEMCPY(&stIspInf, &pstCoreInf->stIspInf, sizeof(ST_CFG_ISPINF));
            MOS_STRNCPY(stIspInf.aucCountryId, "ALL", sizeof(stIspInf.aucCountryId));
            Config_SetDevIspInf(&stIspInf);
        }
    }
	Config_SetDevNeedBindFlag(aucBindCode,(_UC*)"");
    Http_SetDevJoinGroupFlag(aucBindCode,(_UC*)"");
    MOS_LOG_INF(ZJ_LOGSTR,"get bindcode %s gtoke %s flag %u ",aucBindCode,aucGtoken,uiQRType);
    Qp_CountIF_Post(COUNT_TYPE_WIFICFG, COUNT_VALUE_SUCCESS, COUNT_VALUE_FAIL);
    return MOS_OK;
}

int ZJ_SetQRCodeString(unsigned char *pstrQRCode)
{
	_UC *pstrTmp = MOS_NULL; 
    _CTIME_T ctime = Mos_Time();
    
    if(pstrQRCode == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(ctime - Config_GetDeviceMng()->uiQRScanTime <= 10)
    {
        return MOS_OK;
    }
    Config_GetDeviceMng()->uiQRScanTime = (_UI)ctime;

    pstrTmp = MOS_STRSTR(pstrQRCode,"&p=");
    if(pstrTmp != MOS_NULL)
    {
        return ZJ_ParseWifiQRCodeString(pstrQRCode);
    }
    else
    {
        pstrTmp = MOS_STRSTR(pstrQRCode,"&t=");
        if(pstrTmp != MOS_NULL)
        {
            return ZJ_Parse4GQRCodeString(pstrQRCode); 
        }
        else
        {
            return ZJ_ParseHxQRCodeString(pstrQRCode);
        }
    }
    return MOS_OK;
}

// 设置WIFI强度
int ZJ_SetWifiStrength(int iWifiStrength)
{

    return MOS_OK;
}

//声波配网， 将上层声波识别的字符串设置下来
int ZJ_SetVoiceString(unsigned char* pstrVoiceString)
{
    return MOS_OK;
}

int ZJ_SetAutoConnSSIDInfoCBFunc(ZJ_PFUN_DEVICE_SETWIFI pFunSetAutoConnSsid)
{
    ZJ_GetFuncTable()->pFunSetAutoConnSsid = pFunSetAutoConnSsid;
    return MOS_OK;
}

int ZJ_SetAutoConnResultCBFunc(ZJ_PFUN_DEVICE_AUTOCONN_RESULT pFunAutoConnResult)
{
    ZJ_GetFuncTable()->pFunAutoConnResult = pFunAutoConnResult;
    return MOS_OK;
}


int ZJ_SetAutoConnStatus(int iConnectFlag)
{
    MOS_LOG_INF(ZJ_LOGSTR, "iConnectFlag:%d",iConnectFlag);
    if(1 == iConnectFlag)
    {
#ifdef DX_QSID
        qSid_Task_Start();
#endif
        return AutoConn_Task_Start();
    }
	else if(2 == iConnectFlag)
	{
		AutoConn_SetNormalWifi_Status();
	}
    return MOS_ERR;
}

int ZJ_SetIPv6Ability(int iIPv6Ability)
{
    return Config_SetIPv6Ability(0,iIPv6Ability);
}

int ZJ_SetIPv6SwitchCB(ZJ_PFUN_IPV6_SWITCH pfunIPv6Switch)
{
    ZJ_GetFuncTable()->pfunIPv6Switch = pfunIPv6Switch;
    return MOS_OK;
}
