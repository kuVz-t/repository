#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "msgmng_ai.h"
#include "ga1400_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

int ZJ_SetGat1400Ability(int iGAT1400Ability)
{
    return Config_SetCameraGat1400Ability(0,iGAT1400Ability);
}

int ZJ_SetGa1400CB(ZJ_PFUN_SET_GA1400SWITCH pfunSetGa1400SwitchCb, ZJ_PFUN_SET_GA1400INFO pFunSetGa1400InfoCb, ZJ_PFUN_SET_GA1400STATUS pFunSetGa1400StatusCb)
{
    ZJ_GetFuncTable()->pFunSetGa1400InfoCb   = pFunSetGa1400InfoCb;
    ZJ_GetFuncTable()->pfunSetGa1400SwitchCb = pfunSetGa1400SwitchCb;
    ZJ_GetFuncTable()->pFunSetGa1400StatusCb = pFunSetGa1400StatusCb;
    return MOS_OK; 
}

// Ai事件信号输入(抓拍图)(传到1400平台) 背景图宽高要求1920*1080
void ZJ_SetAiPicEventEx2(unsigned int uiAIIoTType, unsigned long long lluAIIoTID,
                                unsigned int uiEvent, ST_ZJ_AIPIC_EVENT_INFO *pstAiPicEventInfo)
{
#ifndef BUILD_NOTSUPPORT_GAT1400_MOUDEL
	_UI uiGa1400UploadPicFlag 		= 0;
	_UI uiGa1400TaskRegisterFlag   	= 0;
	_UI uiSetAiPicEventEx2FailFlag 	= 0;
	_UI uiGa1400UploadPicNodeCount  = 0;

	if (pstAiPicEventInfo != MOS_NULL)
	{
		uiGa1400TaskRegisterFlag = Ga1400_GetTaskRegisterFlag();
		if (uiGa1400TaskRegisterFlag == EN_GA1400_REGISTER_SUCCESS)	// 已注册GA1400平台
		{
			uiGa1400UploadPicFlag = Ga1400_GetTaskUploadPicFlag();
			if (uiGa1400UploadPicFlag == 0)
			{
				Config_GetUploadAIPic1400TaskNodeCount(0, &uiGa1400UploadPicNodeCount);
				if (uiGa1400UploadPicNodeCount <= GA1400_ALARM_LISTNODE_MAXCOUNT)
				{
					// AI人脸抓拍图片上传到1400平台
					_UI uiReqId = Mos_GetSessionId();
					// 排障必要日志
					MOS_LOG_INF(ZJ_LOGSTR, "AI 1400 Event Come ReqId:%u Time:%llu  BG_W:%u BG_H:%u PIC_W:%u PIC_H:%u UploadNodeCount:%u EventExpandDes: %s",
											uiReqId, pstAiPicEventInfo->lluTimeStamp, (_UI)(pstAiPicEventInfo->dBgWidth), (_UI)(pstAiPicEventInfo->dBgHeight),
											(_UI)(pstAiPicEventInfo->pstAiPicHead->dWidth), (_UI)(pstAiPicEventInfo->pstAiPicHead->dHeight),
											uiGa1400UploadPicNodeCount, pstAiPicEventInfo->aucEventExpandDes);
					Config_AddUploadAIPic1400TaskNode(0, uiReqId, uiAIIoTType, lluAIIoTID, uiEvent, pstAiPicEventInfo);
				}
				else
				{
					MOS_LOG_ERR(ZJ_LOGSTR,"GA1400 Ga1400UploadPicNodeCount(%u) > GA1400_ALARM_LISTNODE_MAXCOUNT(%d), Set Event Err", uiGa1400UploadPicNodeCount, (_INT)GA1400_ALARM_LISTNODE_MAXCOUNT);
					uiSetAiPicEventEx2FailFlag = 1;
				}
			}
			else
			{
				MOS_LOG_ERR(ZJ_LOGSTR,"Ga1400UploadPicFlag(%u) is UploadPic Now, Set Event Err", uiGa1400UploadPicFlag);
				uiSetAiPicEventEx2FailFlag = 1;	
			}
		}
		else
		{
			MOS_LOG_ERR(ZJ_LOGSTR,"GA1400 No Register(%u), Set Event Err", uiGa1400TaskRegisterFlag);
			uiSetAiPicEventEx2FailFlag = 1;
		}
	}
	else
	{
		MOS_LOG_ERR(ZJ_LOGSTR,"GA1400 pstAiPicEventInfo is Null, Set Event Err");
		uiSetAiPicEventEx2FailFlag = 1;
	}

	if (uiSetAiPicEventEx2FailFlag == 1)
	{
		// 通知厂商清除AI图片数据缓存 ADD by LWJ
		if (ZJ_GetFuncTable()->pFunFreeAiPicCache)
		{
			_INT iRet = MOS_ERR;
			if ((pstAiPicEventInfo->pstAiPicHead->pucPicBuf != MOS_NULL) && (pstAiPicEventInfo->pucBgJpgBuff != MOS_NULL))
			{
				iRet = ZJ_GetFuncTable()->pFunFreeAiPicCache(pstAiPicEventInfo->pstAiPicHead->aucLabelID,
															 pstAiPicEventInfo->pstAiPicHead->pucPicBuf,
															 pstAiPicEventInfo->pucBgJpgBuff);
				if (MOS_OK == iRet)
				{
					// MOS_LOG_INF(ZJ_LOGSTR,"Device pFunFreeAiPicCache OK ");
				}
				else
				{
					MOS_LOG_ERR(ZJ_LOGSTR,"Device pFunFreeAiPicCache failed");
				}
			}
			else
			{
				MOS_LOG_ERR(ZJ_LOGSTR,"PicBuf is Null Or BgJpgBuff is Null");
			}
		}
		else
		{
			MOS_LOG_ERR(ZJ_LOGSTR,"Device pFunFreeAiPicCache is NULL!");
		}
		return MOS_ERR;
	}
	else
	{
		return MOS_OK;
	}
#endif
}