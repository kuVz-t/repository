#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "watchdog_api.h"
#include "cloudstg_logcode.h"

static unsigned int g_uiStatusCodeBak = 0;

// 第三方模块线程备注册SDK看门狗
unsigned int ZJ_ThirdModuleRegistSwd(unsigned char *pucModuleName, int iTimeOutSecs, int iFeedIntervalSec)
{
    if (pucModuleName == MOS_NULL)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "ZJ_SWD ModuleName is null");
        return MOS_ERR;      
    }
    if (iTimeOutSecs < iFeedIntervalSec)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "ZJ_SWD iTimeOutSecs(%d) < iFeedIntervalSec(%d) Regist Swd ERR", iTimeOutSecs, iFeedIntervalSec);
        return MOS_ERR;
    }

    _HSWDWRITE hSwdFeedDog = MOS_NULL;
    hSwdFeedDog = Swd_AppThreadRegistForZJ(pucModuleName, iTimeOutSecs, iFeedIntervalSec);
    if (hSwdFeedDog)
    {
        ST_WATCHNODE *pstAppNode  = (ST_WATCHNODE*)hSwdFeedDog;
        return pstAppNode->uiWatchId;
    }
    else
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "ZJ_SWD hSwdFeedDog is null");
        return MOS_ERR;
    }
}

// 第三方模块线程备向SDK喂狗
int ZJ_ThirdModuleFeedDog(unsigned int uiWatchId)
{
    _INT iRet = MOS_ERR;
    _CTIME_T cFeedTimeSec = 0;
    unsigned int uiFeedDogSubTime = 0;
    _HSWDWRITE    hWdWriter  = Swd_FindAppByWatchId(uiWatchId);
    ST_WATCHNODE *pstAppNode = (ST_WATCHNODE*)hWdWriter;
    if (pstAppNode)
    {
        cFeedTimeSec = Mos_Time();
        uiFeedDogSubTime = MOS_ABS_NUM(cFeedTimeSec - pstAppNode->cFeedTimeSec);
        if ((uiFeedDogSubTime >= pstAppNode->iFeedIntervalSec) || (pstAppNode->cFeedTimeSec == 0))
        {
            // MOS_PRINTF("%s %d watchId:%u gb Go to Feed DOG \n", __FUNCTION__, __LINE__, uiWatchId);
            iRet = Swd_AppThreadFeedDog((_HSWDWRITE *)pstAppNode);
            pstAppNode->cFeedTimeSec = cFeedTimeSec;
            return iRet;
        }
        else
        {
            MOS_PRINTF("%s %d watchId:%u ZJ_SWD FeedDog Too Frequent FeedDogSubTime:%u iFeedIntervalSec:%d \r\n", 
                            __FUNCTION__, __LINE__, uiWatchId, uiFeedDogSubTime, pstAppNode->iFeedIntervalSec);
            return MOS_ERR;
        }
    }
    else
    {
        MOS_PRINTF("%s %d watchId:%u ZJ_SWD pstAppNode is Null \r\n", __FUNCTION__, __LINE__, uiWatchId);
        return MOS_ERR;
    }
}

// 第三方模块线程注销SDK看门狗
int ZJ_ThirdModuleUnRegistSwd(unsigned int uiWatchId)
{
    _HSWDWRITE    hWdWriter  = Swd_FindAppByWatchId(uiWatchId);
    ST_WATCHNODE *pstAppNode = (ST_WATCHNODE*)hWdWriter;
    if (pstAppNode)
    {
        Swd_AppThreadUnRegist((_HSWDWRITE *)pstAppNode);
        return MOS_OK;
    }
    else
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "watchId:%u ZJ_SWD AppNode IS NULL", uiWatchId);
        return MOS_ERR;
    }
}

// 厂商管理第三方线程涉及的状态变更通知SDK
int ZJ_StatusChangedNotify(unsigned char *pucModuleName, unsigned int uiStatusCode, unsigned char *pucStrStatusLog)
{
    if (pucModuleName == MOS_NULL)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "ZJ_SWD ModuleName is null");
        return MOS_ERR;      
    }
    if (pucStrStatusLog == MOS_NULL)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "ZJ_SWD StrStatusLog is null");
        return MOS_ERR;      
    }

    // 状态码不在范围内不上传
    if ((uiStatusCode < EN_ZJ_SWD_STATUS_CODE_MIN_VALUE) || (uiStatusCode > EN_ZJ_SWD_STATUS_CODE_MAX_VALUE))
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "the StatusCode:%u Is Out Of Range", uiStatusCode);
        return MOS_ERR;
    }

    // 状态日志超过1024不上传
    if (MOS_STRLEN(pucStrStatusLog) > 1024)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "the StrStatusLog Size %d > 1024", (_INT)MOS_STRLEN(pucStrStatusLog));
        return MOS_ERR;
    }

    // 前后状态码相同不上传
    if (g_uiStatusCodeBak == uiStatusCode)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "the Same StatusCode:%u Upload Too Frequent", uiStatusCode);
        return MOS_ERR;
    }

    // 上传状态码到云涛
    CloudStg_UploadLogEx2(ZJ_LOGSTR, Mos_GetSessionId(), pucModuleName, -1, uiStatusCode, pucStrStatusLog, MOS_NULL, 1);
    
    // 备份当前已上传的状态码
    g_uiStatusCodeBak = uiStatusCode;
    return MOS_OK;
}