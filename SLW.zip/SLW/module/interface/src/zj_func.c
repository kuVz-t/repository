#include "mos.h"
#include "zj_interface.h"

static unsigned int g_iMothionPushFlag,g_iHumanPushFlag;
static ST_ZJ_FUNC_TABLE g_ZjFuncsTable;

/******************************************************************************
********************************************************************************/
ST_ZJ_FUNC_TABLE *ZJ_GetFuncTable()
{
    return &g_ZjFuncsTable;
}

_VOID ZJ_InitFunTable()
{
    if(ZJ_GetFuncTable()->ucInitFlag == 1)
    {
        return ;
    }
    MOS_MEMSET(&g_ZjFuncsTable, 0,sizeof(g_ZjFuncsTable));
    Mos_MutexCreate(&ZJ_GetFuncTable()->hGetJpgMutex);
    ZJ_GetFuncTable()->ucInitFlag  = 1;
    return;
}

_VOID ZJ_DestoryFunTable()
{  
    if(ZJ_GetFuncTable()->ucInitFlag == 0) 
    {
        return;
    }
    ZJ_GetFuncTable()->ucInitFlag = 0;
    Mos_MutexDelete(&ZJ_GetFuncTable()->hGetJpgMutex);
    return;
}

_INT  ZJ_SetNtyPlayStatusFun(ZJ_PFUN_NTYPLAYSTATUS pfunPlayStatusCb)
{
    ZJ_GetFuncTable()->pfunPlayStatusCb = pfunPlayStatusCb;
    return MOS_OK;
}

_INT  ZJ_GetJpgLock()
{
      return Mos_MutexLock(&(ZJ_GetFuncTable()->hGetJpgMutex));
}
_INT  ZJ_GetJpgUnlock()
{
     return Mos_MutexUnLock(&(ZJ_GetFuncTable()->hGetJpgMutex));
}

_INT  ZJ_GetOneJpg(_INT icamid, _UC ucPictureType, _UC **ppucJpegBuf)
{
    _INT iJpgLen = 0;
    if(icamid < 0  || ppucJpegBuf == MOS_NULL)
    {
        return MOS_ERR;
    }
    if(ZJ_GetFuncTable()->pfunVideoGetJpeg)
    {
        iJpgLen = ZJ_GetFuncTable()->pfunVideoGetJpeg(ucPictureType,ppucJpegBuf);
    }
    return iJpgLen;
}
_UI ZJ_GetBiteRateByIndex(_UI uiIndex)
{
    switch(uiIndex)
    {
        case 1:
        {
            return 96;
        }
        case 2:
        {
            return 128;
        }
        case 3:
        {
            return 196;
        }
        case 4:
        {
            return 256;
        }
        case 5:
        {
            return 384;
        }
        case 6:
        {
            return 512;
        }
        case 7:
        {
            return 768;
        }
        case 8:
        {
            return 1024;
        }
        case 9:
        {
            return 1536;
        }
        case 10:
        {
            return 2048;
        }
        case 11:
        {
            return 2560;
        }
        case 12:
        {
            return 3072;
        } 
        case 13:
        {
            return 4096;
        }
        default:
        {

        }
    }
    return 1024;
}

