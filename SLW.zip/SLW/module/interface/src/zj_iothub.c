#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "kjiot_device_api.h"
#include "rf_radio_api.h"

int ZJ_SetIoTHubAbility(int iSupport)
{
    return Config_SetIotHubAbility(iSupport);
}

int ZJ_SetIoTHubStatus(int iStatus)
{
    Rf_SetAntConnectStatus(iStatus);
    return Config_SetIotHubStatus(iStatus);
}

int ZJ_SetIoTHubRecvFunc(ZJ_PFUN_IOTHUB_DATARECV pfunIoTHubDataRecv)
{
    ZJ_GetFuncTable()->pfunIoTHubDataRecv = pfunIoTHubDataRecv;
    return MOS_OK;
}

//RFHub网关接收到外接设备的RF信号，进行数据转换后，写入SDK模块进行处理；
 int ZJ_IoTHubWriteData(unsigned char* pucData, int iLen)
{
    return Rf_RcvRdDevMsg(pucData,iLen);
}


