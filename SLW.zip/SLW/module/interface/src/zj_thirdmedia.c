
#include "config_api.h"
#include "media_cache_api.h"
#include "record_api.h"
#include "event_api.h"
#include "zj_func.h"

int ZJ_ThirdOpenFile(ZJ_PFUN_OPENFILE pfunOpenFile)
{
    ZJ_GetFuncTable()->pfunOpenFile = pfunOpenFile;
    return MOS_OK;
}

int ZJ_ThirdCloseFile(ZJ_PFUN_CLOSEFILE pfunCloseFile)
{
    ZJ_GetFuncTable()->pfunCloseFile = pfunCloseFile;
    return MOS_OK;
}

int ZJ_ThirdReadData(ZJ_PFUN_THIRDREADFRAME pfunReadFrame)
{
    ZJ_GetFuncTable()->pfunReadFrame = pfunReadFrame;
    return MOS_OK;
}

int ZJ_ThirdSeekTime(ZJ_PFUN_SEEKBYTIMESTAMP pfunSeekTime)
{
    ZJ_GetFuncTable()->pfunSeekTime = pfunSeekTime;
    return MOS_OK;
}

int ZJ_ThirdGetFileDes(ZJ_PFUN_READFILEDES pfunGetFileDes)
{
    ZJ_GetFuncTable()->pfunGetFileDes = pfunGetFileDes;
    return MOS_OK;
}

int ZJ_ThirdDeleteFile(ZJ_PFUN_DELETEFILE pfunDeleteFile)
{
    ZJ_GetFuncTable()->pfunDeleteFile = pfunDeleteFile;
    return MOS_OK;
}

int ZJ_RdAddCompatibleDate(unsigned char *pucDate,int iCamId)
{
    return RdStg_AddCompatibleDate(pucDate,iCamId);
}

int ZJ_RdAddCompatibleFile(unsigned char *pucDate,int iCamId,unsigned char *pucFilePath,unsigned int uiStartUnixTime,unsigned int uiEndUnixTime,unsigned int uiStartMsTime,unsigned int uiEndMsTime)
{
    return RdStg_AddCompatibleFile(pucDate,iCamId,pucFilePath,uiStartUnixTime,uiEndUnixTime,uiStartMsTime,uiEndMsTime);
}

int ZJ_EventAddCompatibleDate(unsigned char *pucDate)
{
    return Event_AddCompatibleDate(pucDate);
}

int ZJ_EventAddCompatibleFile(unsigned char *pucDate,time_t cEventTime,unsigned int uiDuration,unsigned int uiIotType,unsigned int uiEventId)
{
    return Event_AddCompatibleFile(pucDate,cEventTime,uiDuration,uiIotType,uiEventId);
}
