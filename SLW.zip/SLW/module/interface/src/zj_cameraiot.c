#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "kjiot_device_api.h"
#include "config_prv.h"
#ifdef BUILD_IMSSDK_FALG
#include "ims_render.h"
#endif
#include "p2p_connect.h"

// 厂商主动调用添加KjIot设备
int ZJ_AddIoTDevice(unsigned int uiAIIoTType, int iCamId,
        ZJ_PFUN_AIIOT_START pfunAIIoTStart, ZJ_PFUN_AIIOT_STOP pfunAIIoTStop, 
        ZJ_PFUN_AIIOT_GETINPUT pfunAIIoTGetInput, ZJ_PFUN_AIIOT_OUTPUT pfunAIIoTOutPut,
        ZJ_PFUN_AIIOT_SETPROP pfunAIIoTSetProp, ZJ_PFUN_AIIOT_CHECKEVENT pfunAIIotCheckEvent)
{
    _LLID lluAIIoTID = (_LLID)iCamId;

    // 新增KjIot设备的CFG 和 该KjIot设备能力集至1
    Config_AddInIotDevice(uiAIIoTType,lluAIIoTID);

    // 增加控制功能回调的KjIot设备链表的节点
    KjIoT_AddDevContrlFun(uiAIIoTType,pfunAIIoTOutPut,pfunAIIoTGetInput,pfunAIIotCheckEvent,pfunAIIoTSetProp);

    MOS_LOG_INF(ZJ_LOGSTR,"add KjIot %u %llu out func %p setProp func %p",uiAIIoTType,lluAIIoTID,pfunAIIoTOutPut,pfunAIIoTSetProp);

    // 新增一个KjIot设备节点
    return KjIoT_AddDevicePlug(uiAIIoTType,lluAIIoTID,pfunAIIoTStart,pfunAIIoTStop);
}

static _INT ZJ_BoolPtzSupport()
{
    if (Config_GetInIotMng()->uiPtzAbility > 0)
    {
        return MOS_TRUE;
    }
    else
    {
        return MOS_FALSE;
    }
}

// IoT设备属性转化,
// iIsNeedChangeDefaultStatus表示是否需要修改默认status参数为1，针对设备移动侦测和人形侦测默认配置要求开启等特定的需求
// iIsNeedChangeDefaultMotionSensitive表示是否需要修改默认Sensitive参数为80，针对设备移动侦测特定的需求
static _UC *Config_IoTTrasProp(_UI uiAIIoTType, _UC* pucInProp, _INT iIsNeedChangeDefaultStatus, _INT iIsNeedChangeDefaultMotionSensitive)
{
    MOS_PARAM_NULL_RETNULL(pucInProp);
    MOS_LOG_INF(ZJ_LOGSTR,"START IoTType:%u InProp %s", uiAIIoTType, pucInProp);

    _UC *pucStrProp = MOS_NULL;
    pucStrProp = (_UC *)MOS_MALLOCCLR(MOS_STRLEN(pucInProp) + 1);
    MOS_STRNCPY(pucStrProp, pucInProp, MOS_STRLEN(pucInProp));

    JSON_HANDLE hBodyJson = Adpt_Json_Parse(pucStrProp);
    if (hBodyJson)
    {
        if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
        {
            JSON_HANDLE hMotionJson = Adpt_Json_GetObjectItem(hBodyJson, (_UC*)"Motion");
            if (hMotionJson)
            {
                if (iIsNeedChangeDefaultStatus == 1)
                {
                    _INT iMotionStatus = 0;
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hMotionJson,(_UC*)"Status"), &iMotionStatus);
                    if (iMotionStatus != 1)
                    {
                        Adpt_Json_DeleteItemFromObject(hMotionJson, (_UC*)"Status");
                        Adpt_Json_AddItemToObject(hMotionJson, (_UC*)"Status", Adpt_Json_CreateStrWithNum(1));
                    }
                }

                if (iIsNeedChangeDefaultMotionSensitive == 1)
                {
                    _INT iMotionSensitive = 0;
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hMotionJson,(_UC*)"Sensitive"), &iMotionSensitive);
                    if (iMotionSensitive != 80)
                    {
                        Adpt_Json_DeleteItemFromObject(hMotionJson, (_UC*)"Sensitive");
                        Adpt_Json_AddItemToObject(hMotionJson, (_UC*)"Sensitive", Adpt_Json_CreateStrWithNum(80));
                    }
                }

                // 不支持云台功能,不开启追踪
                if (!ZJ_BoolPtzSupport())
                {
                    if (Adpt_Json_GetObjectItem(hMotionJson, (_UC*)"Trace") != NULL)
                    {
                        Adpt_Json_DeleteItemFromObject(hMotionJson, (_UC*)"Trace");
                    }
                }
            }

            JSON_HANDLE hHumanJson = Adpt_Json_GetObjectItem(hBodyJson, (_UC*)"Human");
            if (hHumanJson)
            {
                if (iIsNeedChangeDefaultStatus == 1)
                {
                    _INT iHumanStatus = 0;
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hHumanJson,(_UC*)"Status"), &iHumanStatus);
                    if (iHumanStatus != 1)
                    {
                        Adpt_Json_DeleteItemFromObject(hHumanJson, (_UC*)"Status");
                        Adpt_Json_AddItemToObject(hHumanJson, (_UC*)"Status", Adpt_Json_CreateStrWithNum(1));
                    }
                }

                // 不支持云台功能,不开启追踪
                if (!ZJ_BoolPtzSupport())
                {
                    if (Adpt_Json_GetObjectItem(hHumanJson, (_UC*)"Trace") != NULL)
                    {
                        Adpt_Json_DeleteItemFromObject(hHumanJson, (_UC*)"Trace");
                    }
                }
            }

            JSON_HANDLE hFaceJson = Adpt_Json_GetObjectItem(hBodyJson, (_UC*)"Face");
            if (hFaceJson)
            {
                // 不支持云台功能,不开启追踪
                if (!ZJ_BoolPtzSupport())
                {
                    if (Adpt_Json_GetObjectItem(hFaceJson, (_UC*)"Trace") != NULL)
                    {
                        Adpt_Json_DeleteItemFromObject(hFaceJson, (_UC*)"Trace");
                    }
                }
            }

            JSON_HANDLE hFenceJson = Adpt_Json_GetObjectItem(hBodyJson, (_UC*)"Fence");
            if (hFenceJson)
            {       
                 _INT iValue = 30;
                // 业务要求电子围栏实时告警
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hFenceJson,(_UC*)"Interval"), &iValue);
                if (iValue != 0)
                {
                    Adpt_Json_DeleteItemFromObject(hFenceJson, (_UC*)"Interval");
                    Adpt_Json_AddItemToObject(hFenceJson, (_UC*)"Interval", Adpt_Json_CreateStrWithNum(0));
                }

                // 能力中台同事要求ExpandEventAbility字段为0,则应该缺失
                JSON_HANDLE hExpand = Adpt_Json_GetObjectItem(hFenceJson,(_UC*)"ExpandEventAbility");
                if (hExpand)
                {
                    iValue = 1;
                    Adpt_Json_GetIntegerEx(hExpand, &iValue);
                    if (iValue == 0)
                    {
                        Adpt_Json_DeleteItemFromObject(hFenceJson, (_UC*)"ExpandEventAbility");
                    }
                }
            }

            JSON_HANDLE hCarNumJson = Adpt_Json_GetObjectItem(hBodyJson, (_UC*)"CarNum");
            if (hCarNumJson)
            {
                // 不支持云台功能,不开启追踪
                if (!ZJ_BoolPtzSupport())
                {
                    if (Adpt_Json_GetObjectItem(hCarNumJson, (_UC*)"Trace") != NULL)
                    {
                        Adpt_Json_DeleteItemFromObject(hCarNumJson, (_UC*)"Trace");
                    }
                }
            }

            JSON_HANDLE hCarJson = Adpt_Json_GetObjectItem(hBodyJson, (_UC*)"Car");
            if (hCarJson)
            {
                // 不支持云台功能,不开启追踪
                if (!ZJ_BoolPtzSupport())
                {
                    if (Adpt_Json_GetObjectItem(hCarJson, (_UC*)"Trace") != NULL)
                    {
                        Adpt_Json_DeleteItemFromObject(hCarJson, (_UC*)"Trace");
                    }
                }
            }
        }
        else
        {

            // 不支持云台功能,不开启追踪
            if (!ZJ_BoolPtzSupport())
            {
                if (Adpt_Json_GetObjectItem(hBodyJson, (_UC*)"Trace") != NULL)
                {
                    Adpt_Json_DeleteItemFromObject(hBodyJson, (_UC*)"Trace");
                }
            }    
        }

        if (pucStrProp != MOS_NULL)
        {
            MOS_FREE(pucStrProp);
            pucStrProp = MOS_NULL;
        }
        pucStrProp = Adpt_Json_Print(hBodyJson);
        Adpt_Json_Delete(hBodyJson);
    }

    MOS_LOG_INF(ZJ_LOGSTR,"END IoTType:%u OutStrProp %s", uiAIIoTType, pucStrProp);
    return pucStrProp;
}

unsigned char* Config_ChenkAndAddKeyToJson(unsigned char* pucOldJson, unsigned char* pucNewJson)
{
    _INT iJsonKeyType           = 0;
    _UI  uiOldKeyValue          = 0;
    _UI  uiNewKeyValue          = 0;
    _INT iJsonChangeFlag        = 0;
    _UC *pucOldKey              = MOS_NULL;
    _UC *pucNewKey              = MOS_NULL;
    _UC *pucNewKeyValue         = MOS_NULL;
    JSON_HANDLE hOldJson        = MOS_NULL;
    JSON_HANDLE hOldJsonChild   = MOS_NULL;
    JSON_HANDLE hNewJson        = MOS_NULL;
    JSON_HANDLE hNewJsonChild   = MOS_NULL;
    JSON_HANDLE hOldJsonBak     = MOS_NULL;
    
    hOldJson = Adpt_Json_Parse(pucOldJson);
    hNewJson = Adpt_Json_Parse(pucNewJson);

    if (hOldJson == MOS_NULL || hNewJson == MOS_NULL)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "OldJson or NewJson is error");
        Adpt_Json_Delete(hOldJson);
        Adpt_Json_Delete(hNewJson);
        return MOS_NULL;
    }

    hOldJsonBak   = Adpt_Json_Parse(pucOldJson);
    hNewJsonChild = Adpt_Json_GetChild(hNewJson);
    while (hNewJsonChild)
    {
        pucNewKey = MOS_NULL;
        Adpt_Json_GetName(hNewJsonChild, &pucNewKey);
        // MOS_LOG_INF(ZJ_LOGSTR, "NEW  Key:%s", pucNewKey);
        if (pucNewKey)
        {
            _INT iNeedAddProp = 1;
            hOldJsonChild = MOS_NULL;
            hOldJsonChild = Adpt_Json_GetChild(hOldJson);
            while (hOldJsonChild)
            {
                Adpt_Json_GetName(hOldJsonChild, &pucOldKey);
                // MOS_LOG_INF(ZJ_LOGSTR, "OLD  Key:%s", pucOldKey);

                if (pucOldKey)
                {
                    if (MOS_STRNCMP(pucNewKey, pucOldKey, MOS_STRLEN(pucNewKey)) == 0)
                    {
                        // 新旧属性存在相同字段，不做追加处理
                        iNeedAddProp = 0;
                        break;
                    }
                    else
                    {
                        hOldJsonChild = Adpt_Json_GetNext(hOldJsonChild);
                        continue;
                    }
                }
            }

            if (iNeedAddProp)
            {
                iJsonChangeFlag = 1;
#if 1
                //新json对象的字符串地址还会指向原json对象 /* Adpt_Json_Delete(hOldJsonBak)必须在Adpt_Json_Delete(hNewJson)前面 */
                Adpt_Json_AddItemReferenceToObject(hOldJsonBak, pucNewKey, hNewJsonChild);
                MOS_LOG_INF(ZJ_LOGSTR, "add object  (%s)", pucNewKey);
#else
                iJsonKeyType = Adpt_Json_GetType(hNewJsonChild);
                MOS_LOG_INF(ZJ_LOGSTR, "pucNewKey:%s iJsonKeyType:%d", pucNewKey, iJsonKeyType);
                switch (iJsonKeyType)
                {
                    case EN_ITRD_JSON_NODE_TYPE_NUMBER:
                        {
                            Adpt_Json_GetIntegerEx(hNewJsonChild, uiNewKeyValue);
                            Adpt_Json_AddItemToObject(hOldJsonBak, pucNewKey, Adpt_Json_CreateStrWithNum(uiNewKeyValue));
                            MOS_LOG_INF(ZJ_LOGSTR, "add Num  %s:%d", pucNewKey, uiNewKeyValue);
                            break;
                        }
                    case EN_ITRD_JSON_NODE_TYPE_STRING:
                        {
                            Adpt_Json_GetString(hNewJsonChild,&pucNewKeyValue);
                            Adpt_Json_AddItemToObject(hOldJsonBak, pucNewKey, Adpt_Json_CreateString(pucNewKeyValue));
                            MOS_LOG_INF(ZJ_LOGSTR, "add String  %s:%s", pucNewKey, pucNewKeyValue);
                            break;
                        }
                    case EN_ITRD_JSON_NODE_TYPE_ARRAY:
                    case EN_ITRD_JSON_NODE_TYPE_OBJECT:
                        {
                            MOS_LOG_INF(ZJ_LOGSTR, "add array  (%s)", pucNewKey);
                            JSON_HANDLE hNewObjectProp = MOS_NULL;
                            hNewObjectProp = Adpt_Json_GetObjectItem(hNewJson, pucNewKey);
                            if (hNewObjectProp)
                            {
                                Adpt_Json_AddItemToObject(hOldJsonBak, pucNewKey, hNewObjectProp);
                            }
                            else
                            {
                                MOS_LOG_ERR(ZJ_LOGSTR, "hNewObjectProp is Null");
                            }
                            MOS_LOG_INF(ZJ_LOGSTR, "add array  (%s)", pucNewKey);

                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
#endif
            }
        }
        hNewJsonChild = Adpt_Json_GetNext(hNewJsonChild);
    }

    if (iJsonChangeFlag == 1)
    {
        _UC *pucOutNewJson = Adpt_Json_Print(hOldJsonBak);

        MOS_LOG_INF(ZJ_LOGSTR, "pucOutNewJson %s", pucOutNewJson);
        Adpt_Json_Delete(hOldJsonBak);
        Adpt_Json_Delete(hOldJson);
        Adpt_Json_Delete(hNewJson);
        hOldJson = MOS_NULL;
        hNewJson = MOS_NULL;

        return pucOutNewJson;
    }
    else
    {
        Adpt_Json_Delete(hOldJsonBak);
        Adpt_Json_Delete(hOldJson);
        Adpt_Json_Delete(hNewJson);
        hOldJson = MOS_NULL;
        hNewJson = MOS_NULL;

        return MOS_NULL;;
    }
}

// IOT能力属性更新
_INT ZJ_IoTPropAddOrUpdate(_UI uiAIIoTType, _ULLID lluAIIoTID,_UC *pucNewIoTProp)
{
    MOS_PARAM_NULL_RETERR(pucNewIoTProp);

    _INT iMotionPropChangeFlag = 0;
    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
    pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiAIIoTType, 0, IOT_DEFAULT_POLICYID_MOTION);
    JSON_HANDLE hOldIoTPropJson = Adpt_Json_Parse(pstAPolicyNode->pucProp);
    JSON_HANDLE hNewIoTPropJson = Adpt_Json_Parse(pucNewIoTProp);

    if (hOldIoTPropJson != MOS_NULL && hNewIoTPropJson != MOS_NULL)
    {
        JSON_HANDLE hOldMotionJson = Adpt_Json_GetObjectItem(hOldIoTPropJson, (_UC*)"Motion");
        JSON_HANDLE hNewMotionJson = Adpt_Json_GetObjectItem(hNewIoTPropJson, (_UC*)"Motion");
        if (hOldMotionJson == MOS_NULL && hNewMotionJson != MOS_NULL) // 无字段 -> 有字段
        {
            _UC *pucMotionIotProp      =  Adpt_Json_Print(hNewMotionJson);
            JSON_HANDLE hMotionIotProp =  Adpt_Json_Parse(pucMotionIotProp);
            MOS_LOG_INF(ZJ_LOGSTR, "Motion Change %s", pucMotionIotProp);
            Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Motion", hMotionIotProp);
            MOS_FREE(pucMotionIotProp);
            pucMotionIotProp = MOS_NULL;
            iMotionPropChangeFlag = 1;
        }
        else if (hOldMotionJson != MOS_NULL && hNewMotionJson != MOS_NULL)    // 有字段 -> 追加属性
        {
            _UC *pucOldMotionIotProp = Adpt_Json_Print(hOldMotionJson);
            _UC *pucNewMotionIotProp = Adpt_Json_Print(hNewMotionJson);

            _UC* pucNewIotProp = MOS_NULL;
            pucNewIotProp = Config_ChenkAndAddKeyToJson(pucOldMotionIotProp, pucNewMotionIotProp);
            if (pucNewIotProp)
            {
                JSON_HANDLE hMotionIotProp =  Adpt_Json_Parse(pucNewIotProp);
                MOS_LOG_INF(ZJ_LOGSTR, "Motion Change Add Prop %s", pucNewIotProp);
                Adpt_Json_DeleteItemFromObject(hOldIoTPropJson, (_UC*)"Motion");
                Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Motion", hMotionIotProp);

                MOS_FREE(pucNewIotProp);
                pucNewIotProp = MOS_NULL;
                iMotionPropChangeFlag = 1;
            }
            MOS_FREE(pucOldMotionIotProp);
            pucOldMotionIotProp = MOS_NULL;
            MOS_FREE(pucNewMotionIotProp);
            pucNewMotionIotProp = MOS_NULL;
        }

        JSON_HANDLE hOldHumanJson = Adpt_Json_GetObjectItem(hOldIoTPropJson, (_UC*)"Human");
        JSON_HANDLE hNewHumanJson = Adpt_Json_GetObjectItem(hNewIoTPropJson, (_UC*)"Human");
        if (hOldHumanJson == MOS_NULL && hNewHumanJson != MOS_NULL) // 无字段 -> 有字段
        {
            _UC *pucHumanIotProp      =  Adpt_Json_Print(hNewHumanJson);
            JSON_HANDLE hHumanIotProp =  Adpt_Json_Parse(pucHumanIotProp);
            MOS_LOG_INF(ZJ_LOGSTR, "Human Change %s", pucHumanIotProp);
            Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Human", hHumanIotProp);
            MOS_FREE(pucHumanIotProp);
            pucHumanIotProp = MOS_NULL;
            iMotionPropChangeFlag = 1;
        }
        else if (hOldHumanJson != MOS_NULL && hNewHumanJson != MOS_NULL)    // 有字段 -> 追加属性
        {
            _UC *pucOldHumanIotProp = Adpt_Json_Print(hOldHumanJson);
            _UC *pucNewHumanIotProp = Adpt_Json_Print(hNewHumanJson);

            _UC* pucNewIotProp = MOS_NULL;
            pucNewIotProp = Config_ChenkAndAddKeyToJson(pucOldHumanIotProp, pucNewHumanIotProp);
            if (pucNewIotProp)
            {
                JSON_HANDLE hHumanIotProp =  Adpt_Json_Parse(pucNewIotProp);
                MOS_LOG_INF(ZJ_LOGSTR, "Human Change Add Prop %s", pucNewIotProp);
                Adpt_Json_DeleteItemFromObject(hOldIoTPropJson, (_UC*)"Human");
                Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Human", hHumanIotProp);

                MOS_FREE(pucNewIotProp);
                pucNewIotProp = MOS_NULL;
                iMotionPropChangeFlag = 1;
            }
            MOS_FREE(pucOldHumanIotProp);
            pucOldHumanIotProp = MOS_NULL;
            MOS_FREE(pucNewHumanIotProp);
            pucNewHumanIotProp = MOS_NULL;
        }

        // 旧人脸才可以追加Face属性字段
        if(0 == Config_GetNewFaceAbility())
        {
            JSON_HANDLE hOldFaceJson = Adpt_Json_GetObjectItem(hOldIoTPropJson, (_UC*)"Face");
            JSON_HANDLE hNewFaceJson = Adpt_Json_GetObjectItem(hNewIoTPropJson, (_UC*)"Face");
            if (hOldFaceJson == MOS_NULL && hNewFaceJson != MOS_NULL) // 无字段 -> 有字段
            {
                _UC *pucFaceIotProp      =  Adpt_Json_Print(hNewFaceJson);
                JSON_HANDLE hFaceIotProp =  Adpt_Json_Parse(pucFaceIotProp);
                MOS_LOG_INF(ZJ_LOGSTR, "Face Change %s", pucFaceIotProp);
                Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Face", hFaceIotProp);
                MOS_FREE(pucFaceIotProp);
                pucFaceIotProp = MOS_NULL;
                iMotionPropChangeFlag = 1;
            }
            else if (hOldFaceJson != MOS_NULL && hNewFaceJson != MOS_NULL)    // 有字段 -> 追加属性
            {
                _UC *pucOldFaceIotProp = Adpt_Json_Print(hOldFaceJson);
                _UC *pucNewFaceIotProp = Adpt_Json_Print(hNewFaceJson);

                _UC* pucNewIotProp = MOS_NULL;
                pucNewIotProp = Config_ChenkAndAddKeyToJson(pucOldFaceIotProp, pucNewFaceIotProp);
                if (pucNewIotProp)
                {
                    JSON_HANDLE hFaceIotProp =  Adpt_Json_Parse(pucNewIotProp);
                    MOS_LOG_INF(ZJ_LOGSTR, "Face Change Add Prop %s", pucNewIotProp);
                    Adpt_Json_DeleteItemFromObject(hOldIoTPropJson, (_UC*)"Face");
                    Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Face", hFaceIotProp);

                    MOS_FREE(pucNewIotProp);
                    pucNewIotProp = MOS_NULL;
                    iMotionPropChangeFlag = 1;
                }
                MOS_FREE(pucOldFaceIotProp);
                pucOldFaceIotProp = MOS_NULL;
                MOS_FREE(pucNewFaceIotProp);
                pucNewFaceIotProp = MOS_NULL;
            }
        }

        JSON_HANDLE hOldCarNumJson = Adpt_Json_GetObjectItem(hOldIoTPropJson, (_UC*)"CarNum");
        JSON_HANDLE hNewCarNumJson = Adpt_Json_GetObjectItem(hNewIoTPropJson, (_UC*)"CarNum");
        if (hOldCarNumJson == MOS_NULL && hNewCarNumJson != MOS_NULL) // 无字段 -> 有字段
        {
            _UC *pucCarNumIotProp      =  Adpt_Json_Print(hNewCarNumJson);
            JSON_HANDLE hCarNumIotProp =  Adpt_Json_Parse(pucCarNumIotProp);
            MOS_LOG_INF(ZJ_LOGSTR, "CarNum Change %s", pucCarNumIotProp);
            Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"CarNum", hCarNumIotProp);
            MOS_FREE(pucCarNumIotProp);
            pucCarNumIotProp = MOS_NULL;
            iMotionPropChangeFlag = 1;
        }
        else if (hOldCarNumJson != MOS_NULL && hNewCarNumJson != MOS_NULL)    // 有字段 -> 追加属性
        {
            _UC *pucOldCarNumIotProp = Adpt_Json_Print(hOldCarNumJson);
            _UC *pucNewCarNumIotProp = Adpt_Json_Print(hNewCarNumJson);

            _UC* pucNewIotProp = MOS_NULL;
            pucNewIotProp = Config_ChenkAndAddKeyToJson(pucOldCarNumIotProp, pucNewCarNumIotProp);
            if (pucNewIotProp)
            {
                JSON_HANDLE hCarNumIotProp =  Adpt_Json_Parse(pucNewIotProp);
                MOS_LOG_INF(ZJ_LOGSTR, "CarNum Change Add Prop %s", pucNewIotProp);
                Adpt_Json_DeleteItemFromObject(hOldIoTPropJson, (_UC*)"CarNum");
                Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"CarNum", hCarNumIotProp);

                MOS_FREE(pucNewIotProp);
                pucNewIotProp = MOS_NULL;
                iMotionPropChangeFlag = 1;
            }
            MOS_FREE(pucOldCarNumIotProp);
            pucOldCarNumIotProp = MOS_NULL;
            MOS_FREE(pucNewCarNumIotProp);
            pucNewCarNumIotProp = MOS_NULL;
        }

        JSON_HANDLE hOldCarJson = Adpt_Json_GetObjectItem(hOldIoTPropJson, (_UC*)"Car");
        JSON_HANDLE hNewCarJson = Adpt_Json_GetObjectItem(hNewIoTPropJson, (_UC*)"Car");
        if ((hOldCarJson == MOS_NULL) && (hNewCarJson != MOS_NULL)) // 无字段 -> 有字段
        {
            _UC *pucCarIotProp      =  Adpt_Json_Print(hNewCarJson);
            JSON_HANDLE hCarIotProp =  Adpt_Json_Parse(pucCarIotProp);
            MOS_LOG_INF(ZJ_LOGSTR, "Car Change %s", pucCarIotProp);
            Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Car", hCarIotProp);
            MOS_FREE(pucCarIotProp);
            pucCarIotProp = MOS_NULL;
            iMotionPropChangeFlag = 1;
        }
        else if ((hOldCarJson != MOS_NULL) && (hNewCarJson != MOS_NULL))    // 有字段 -> 追加属性
        {
            _UC *pucOldCarIotProp = Adpt_Json_Print(hOldCarJson);
            _UC *pucNewCarIotProp = Adpt_Json_Print(hNewCarJson);

            _UC* pucNewIotProp = MOS_NULL;
            pucNewIotProp = Config_ChenkAndAddKeyToJson(pucOldCarIotProp, pucNewCarIotProp);
            if (pucNewIotProp)
            {
                JSON_HANDLE hCarIotProp =  Adpt_Json_Parse(pucNewIotProp);
                MOS_LOG_INF(ZJ_LOGSTR, "Car Change Add Prop %s", pucNewIotProp);
                Adpt_Json_DeleteItemFromObject(hOldIoTPropJson, (_UC*)"Car");
                Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Car", hCarIotProp);

                MOS_FREE(pucNewIotProp);
                pucNewIotProp = MOS_NULL;
                iMotionPropChangeFlag = 1;
            }
            MOS_FREE(pucOldCarIotProp);
            pucOldCarIotProp = MOS_NULL;
            MOS_FREE(pucNewCarIotProp);
            pucNewCarIotProp = MOS_NULL;
        }

        JSON_HANDLE hOldFenceJson = Adpt_Json_GetObjectItem(hOldIoTPropJson, (_UC*)"Fence");
        JSON_HANDLE hNewFenceJson = Adpt_Json_GetObjectItem(hNewIoTPropJson, (_UC*)"Fence");
        if ((hOldFenceJson == MOS_NULL) && (hNewFenceJson != MOS_NULL)) // 无字段 -> 有字段
        {
            // 兼容3.0电子围栏告警间隔设置不为0，强制修改为0 业务要求实时告警
            _INT iInterval = 30;
            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hNewFenceJson,(_UC*)"Interval"), &iInterval);
            if (iInterval != 0)
            {
                Adpt_Json_DeleteItemFromObject(hNewFenceJson, (_UC*)"Interval");
                Adpt_Json_AddItemToObject(hNewFenceJson, (_UC*)"Interval", Adpt_Json_CreateStrWithNum(0));
            }

            _UC *pucFenceIotProp      =  Adpt_Json_Print(hNewFenceJson);
            JSON_HANDLE hFenceIotProp =  Adpt_Json_Parse(pucFenceIotProp);
            MOS_LOG_INF(ZJ_LOGSTR, "Fence Change %s", pucFenceIotProp);
            Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Fence", hFenceIotProp);
            MOS_FREE(pucFenceIotProp);
            pucFenceIotProp = MOS_NULL;
            iMotionPropChangeFlag = 1;
        }
        else if ((hOldFenceJson != MOS_NULL) && (hNewFenceJson != MOS_NULL)) // 已有字段, 做兼容逻辑
        {
            #if 0
            _INT iValue = 0;
            _INT iPropChangeFlag  = 0;
            JSON_HANDLE hOldValue = MOS_NULL;
            JSON_HANDLE hNewValue = MOS_NULL;

            // 兼容不支持防溺水固件升级支持防溺水固件
            // 新固件具备StayTime字段, 补上该字段
            hOldValue = Adpt_Json_GetObjectItem(hOldFenceJson,(_UC*)"StayTime");
            hNewValue = Adpt_Json_GetObjectItem(hNewFenceJson,(_UC*)"StayTime");
            if (hOldValue == MOS_NULL && hNewValue != MOS_NULL)
            {
                Adpt_Json_GetIntegerEx(hNewValue, &iValue);
                Adpt_Json_AddItemToObject(hOldFenceJson, (_UC*)"StayTime", Adpt_Json_CreateStrWithNum(iValue));
                iPropChangeFlag = 1;
            }

            // 新固件具备Capture字段, 补上该字段
            iValue    = 0;
            hOldValue = Adpt_Json_GetObjectItem(hOldFenceJson,(_UC*)"Capture");
            hNewValue = Adpt_Json_GetObjectItem(hNewFenceJson,(_UC*)"Capture");
            if (hOldValue == MOS_NULL && hNewValue != MOS_NULL)
            {
                Adpt_Json_GetIntegerEx(hNewValue, &iValue);
                Adpt_Json_AddItemToObject(hOldFenceJson, (_UC*)"Capture", Adpt_Json_CreateStrWithNum(iValue));
                iPropChangeFlag = 1;
            }

            // 新固件具备Video字段, 补上该字段
            iValue    = 0;
            hOldValue = Adpt_Json_GetObjectItem(hOldFenceJson,(_UC*)"Video");
            hNewValue = Adpt_Json_GetObjectItem(hNewFenceJson,(_UC*)"Video");
            if (hOldValue == MOS_NULL && hNewValue != MOS_NULL)
            {
                Adpt_Json_GetIntegerEx(hNewValue, &iValue);
                Adpt_Json_AddItemToObject(hOldFenceJson, (_UC*)"Video", Adpt_Json_CreateStrWithNum(iValue));
                iPropChangeFlag = 1;
            }

            // 兼容不支持人机非固件升级支持人机非固件
            // 新固件具备ExpandEventAbility字段, 补上该字段
            iValue    = 0;
            hOldValue = Adpt_Json_GetObjectItem(hOldFenceJson,(_UC*)"ExpandEventAbility");
            hNewValue = Adpt_Json_GetObjectItem(hNewFenceJson,(_UC*)"ExpandEventAbility");
            if (hOldValue == MOS_NULL && hNewValue != MOS_NULL)
            {
                Adpt_Json_GetIntegerEx(hNewValue, &iValue);
                if (iValue != 0)// 能力中台同事要求ExpandEventAbility字段为0,则应该缺失
                {
                    Adpt_Json_AddItemToObject(hOldFenceJson, (_UC*)"ExpandEventAbility", Adpt_Json_CreateStrWithNum(iValue));
                    iPropChangeFlag = 1;
                }
            }

            if (iPropChangeFlag)
            {
                _UC *pucFenceIotProp      =  Adpt_Json_Print(hOldFenceJson);
                JSON_HANDLE hFenceIotProp =  Adpt_Json_Parse(pucFenceIotProp);
                MOS_LOG_INF(ZJ_LOGSTR, "Fence Change %s", pucFenceIotProp);
                Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Fence", hFenceIotProp);
                MOS_FREE(pucFenceIotProp);
                pucFenceIotProp = MOS_NULL;
                iMotionPropChangeFlag = 1;                
            }
            #else
            _UC *pucOldFenceIotProp = Adpt_Json_Print(hOldFenceJson);
            _UC *pucNewFenceIotProp = Adpt_Json_Print(hNewFenceJson);

            _UC* pucNewIotProp = MOS_NULL;
            pucNewIotProp = Config_ChenkAndAddKeyToJson(pucOldFenceIotProp, pucNewFenceIotProp);
            if (pucNewIotProp)
            {
                JSON_HANDLE hFenceIotProp =  Adpt_Json_Parse(pucNewIotProp);
                MOS_LOG_INF(ZJ_LOGSTR, "Fence Change Add Prop %s", pucNewIotProp);
                Adpt_Json_DeleteItemFromObject(hOldIoTPropJson, (_UC*)"Fence");
                Adpt_Json_AddItemToObject(hOldIoTPropJson, (_UC*)"Fence", hFenceIotProp);

                MOS_FREE(pucNewIotProp);
                pucNewIotProp = MOS_NULL;
                iMotionPropChangeFlag = 1;
            }
            MOS_FREE(pucOldFenceIotProp);
            pucOldFenceIotProp = MOS_NULL;
            MOS_FREE(pucNewFenceIotProp);
            pucNewFenceIotProp = MOS_NULL;
            #endif
        }
        
        
        if (iMotionPropChangeFlag == 1)
        {
            _UC *pucNewIotProp = Adpt_Json_Print(hOldIoTPropJson);

            MOS_LOG_INF(ZJ_LOGSTR, "KjIot MOTION NewIotProp %s", pucNewIotProp);

            // IoT设备属性转化
            _UC *pucTrasIotProp = MOS_NULL;

            pucTrasIotProp = Config_IoTTrasProp(uiAIIoTType, pucNewIotProp, 0, 0);
            if (pucTrasIotProp)
            {
                // 设置IoT告警策略属性
                Config_SetAlarmPolicyProp(pstAPolicyNode, pucTrasIotProp);
                // 设置KjIot设备属性
                Config_SetInIotProp(uiAIIoTType, lluAIIoTID, (_UC*)pucTrasIotProp);
                MOS_FREE(pucTrasIotProp);
                pucTrasIotProp = MOS_NULL;
            }
            MOS_FREE(pucNewIotProp);
            pucNewIotProp = MOS_NULL;
        }

        Adpt_Json_Delete(hOldIoTPropJson);
        Adpt_Json_Delete(hNewIoTPropJson);
        hOldIoTPropJson = MOS_NULL;
        hNewIoTPropJson = MOS_NULL;
    }
    return MOS_OK;
}

// 新旧人脸开关状态同步
static _UC *ZJ_SyncOldFacePropToNewFaceProp(_UI uiAIIoTType, _UC *pucInProp)
{
    MOS_PARAM_INVALID_RET(pucInProp, MOS_NULL, MOS_NULL);

    _INT iRet             = MOS_ERR;
    _INT iOpen            = -1;
    _INT iStatus          = -1;
    _INT iDiscernFlag     = -1;
    _UC *pucStrProp       = MOS_NULL;
    _UC *pucOutProp       = MOS_NULL;
    JSON_HANDLE hPropJson = MOS_NULL;
    JSON_HANDLE hFaceJson = MOS_NULL;

    // 先保存原来的属性
    pucOutProp = (_UC *)MOS_MALLOCCLR(MOS_STRLEN(pucInProp) + 1);
    MOS_STRNCPY(pucOutProp, pucInProp, MOS_STRLEN(pucInProp));

    // 获取旧的人脸抓拍开关状态和旧人脸布控开关状态
    pucStrProp = Config_GetAlarmPolicyProp(EN_ZJ_AIIOT_TYPE_MOTION, 0, IOT_DEFAULT_POLICYID_MOTION);
    if (MOS_NULL != pucStrProp)
    {
        hPropJson = Adpt_Json_Parse(pucStrProp);
        if (MOS_NULL != hPropJson)
        {
            // "Face":{"Sensitive":"20","Status":"1","DiscernFlag":"1","Trace":"0","Interval":"10"}
            hFaceJson = Adpt_Json_GetObjectItem(hPropJson, (_UC*)"Face");
            if (MOS_NULL != hFaceJson)
            {
                // DiscernFlag
                iRet = Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hFaceJson,(_UC*)"DiscernFlag"), &iDiscernFlag);
                if (MOS_OK != iRet)
                {
                    iDiscernFlag = -1;
                    MOS_LOG_INF(ZJ_LOGSTR, "old Face DiscernFlag is null!");
                }
   
                // Status
                iRet = Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hFaceJson,(_UC*)"Status"), &iStatus);
                if (MOS_OK != iRet)
                {
                    iStatus = -1;
                    MOS_LOG_INF(ZJ_LOGSTR, "old Face Status is null!");
                }
            }
            else
            {
                iStatus = -1;
                iDiscernFlag = -1;
                MOS_LOG_INF(ZJ_LOGSTR, "old Face is null!");
            }

            Adpt_Json_Delete(hPropJson);
        }
    }
    else
    {
        iStatus = -1;
        iDiscernFlag = -1;
        MOS_LOG_INF(ZJ_LOGSTR, "old MOTION prop is null!");
    }

    MOS_LOG_INF(ZJ_LOGSTR, "old [iStatus = %d iDiscernFlag = %d]", iStatus, iDiscernFlag);

    // 同步开关状态
    if (EN_ZJ_AIIOT_TYPE_FACE_CAPTURE == uiAIIoTType)
    {
        // 存在Status字段
        if (-1 != iStatus)
        {
            // 存在DiscernFlag字段
            if (-1 != iDiscernFlag)
            {
                // 旧人脸布控iStatus=1并且iDiscernFlag=0才为开，因为平台打开人脸布控时iDiscernFlag=1并且iStatus=1
                if ((1 == iStatus) && (0 == iDiscernFlag))
                {
                    iOpen = 1;
                }
                else
                {
                    iOpen = 0;
                }
            }
            else
            {
                iOpen = iStatus;
            }

            // 同步人脸抓拍开关状态
            hPropJson = Adpt_Json_Parse(pucInProp);
            Adpt_Json_DeleteItemFromObject(hPropJson, (_UC*)"Status");
            Adpt_Json_AddItemToObject(hPropJson, (_UC*)"Status", Adpt_Json_CreateStrWithNum(iOpen));

            // 不使用原先分配的内存，Adpt_Json_Print的内容可能比原先分配的内存大
            if (MOS_NULL != pucOutProp)
            {
                MOS_FREE(pucOutProp);
                pucOutProp = MOS_NULL;
            }

            // 注意外部需要释放Adpt_Json_Print的内存
            pucOutProp = Adpt_Json_Print(hPropJson);
            Adpt_Json_Delete(hPropJson);

            MOS_LOG_INF(ZJ_LOGSTR, "sync old Face Status %d", iOpen);
        }
    }
    else if(EN_ZJ_AIIOT_TYPE_FACE_DISCERN == uiAIIoTType)
    {
        // 存在DiscernFlag字段
        if (-1 != iDiscernFlag)
        {
            iOpen = iDiscernFlag;

            // 同步人脸识别状态开关
            hPropJson = Adpt_Json_Parse(pucInProp);
            Adpt_Json_DeleteItemFromObject(hPropJson, (_UC*)"Status");
            Adpt_Json_AddItemToObject(hPropJson, (_UC*)"Status", Adpt_Json_CreateStrWithNum(iOpen));

            // 布控模式默认0：黑名单布控
            Adpt_Json_DeleteItemFromObject(hPropJson, (_UC*)"Model");
            Adpt_Json_AddItemToObject(hPropJson, (_UC*)"Model", Adpt_Json_CreateStrWithNum(0));

            // 不使用原先分配的内存，Adpt_Json_Print的内容可能比原先分配的内存大
            if (MOS_NULL != pucOutProp)
            {
                MOS_FREE(pucOutProp);
                pucOutProp = MOS_NULL;
            }

            // 注意外部需要释放Adpt_Json_Print的内存
            pucOutProp = Adpt_Json_Print(hPropJson);
            Adpt_Json_Delete(hPropJson);

            MOS_LOG_INF(ZJ_LOGSTR, "sync old Face DiscernFlag %d", iOpen);
        }
    }

    return pucOutProp;
}

//设置IoT设备的属性，IoT设备属性以一个JSON字符串传入
int ZJ_SetIoTDefaultProp(unsigned int uiAIIoTType, int iCamId, unsigned char* pucProp)
{
    MOS_PARAM_NULL_RETERR(pucProp);

    _UC *pucStrProp = MOS_NULL;
    _UC *pucNewIotProp = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;

    _LLID lluAIIoTID = (_LLID)iCamId;
    // 查找对应的KjIot设备属性的链表中的节点
    ST_CFG_INIOT_NODE *pInIotDevNode = Config_FindInnerIotDevice(uiAIIoTType,lluAIIoTID);

    // 若已设置，返回
    if(pInIotDevNode && pInIotDevNode->uiDefaultSetFlag == 1)
    {
        if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
        {
            // IOT能力属性更新
            ZJ_IoTPropAddOrUpdate(uiAIIoTType, lluAIIoTID, pucProp);
            // MOTION告警策略更新
            Config_MotionAlarmPolicyUpdate();
        }
        else
        {
            ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
            pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiAIIoTType, lluAIIoTID, uiAIIoTType);

            pucNewIotProp = Config_ChenkAndAddKeyToJson(pstAPolicyNode->pucProp, pucProp);
            if (pucNewIotProp)
            {

                // IoT设备属性转化
                _UC *pucTrasIotProp = MOS_NULL;
                pucTrasIotProp = Config_IoTTrasProp(uiAIIoTType, pucNewIotProp, 0, 0);
                if (pucTrasIotProp)
                {
                    // 设置IoT告警策略属性
                    Config_SetAlarmPolicyProp(pstAPolicyNode, pucTrasIotProp);
                    // 设置KjIot设备属性
                    Config_SetInIotProp(uiAIIoTType, lluAIIoTID, (_UC*)pucTrasIotProp);
                    MOS_FREE(pucTrasIotProp);
                    pucTrasIotProp = MOS_NULL;
                }
                MOS_FREE(pucNewIotProp);
                pucNewIotProp = MOS_NULL;
            }
        }
        return MOS_OK;
    }

    if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        // IoT设备属性转化
        pucStrProp = Config_IoTTrasProp(uiAIIoTType, pucProp, 1, 1);
        if (pucStrProp)
        {
            // 添加移动侦测告警IoT的联动策略类型
            pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiAIIoTType,0,IOT_DEFAULT_POLICYID_MOTION);
            // 设置IoT告警策略属性
            Config_SetAlarmPolicyProp(pstAPolicyNode,pucStrProp);
            // 设置KjIot设备属性
            Config_SetInIotProp(uiAIIoTType,lluAIIoTID,pucStrProp);
            MOS_FREE(pucStrProp);
            pucStrProp = MOS_NULL;
            // MOTION告警策略更新
            Config_MotionAlarmPolicyUpdate();
        }
        else
        {
            MOS_LOG_ERR(ZJ_LOGSTR,"IoTStrProp is Null IoTType:%d IoTID:%d", uiAIIoTType, lluAIIoTID);
            return MOS_ERR;
        }
    }
    else if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_BUZZER)
    {
        ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiAIIoTType, lluAIIoTID, uiAIIoTType);
        Config_SetAlarmPolicyName(pstAPolicyNode, (_UC*)"BUZZER");
        Config_SetAlarmPolicyTime(pstAPolicyNode, 1, 0X7F, 0, 86400);
        Config_SetAlarmPolicyProp(pstAPolicyNode, pucProp);
        // 设置KjIot设备属性
        Config_SetInIotProp(uiAIIoTType, lluAIIoTID, pucProp);
    }
    else if ((EN_ZJ_AIIOT_TYPE_FACE_CAPTURE == uiAIIoTType) || (EN_ZJ_AIIOT_TYPE_FACE_DISCERN == uiAIIoTType))
    {
        // 同步旧人脸设备属性
        pucNewIotProp = ZJ_SyncOldFacePropToNewFaceProp(uiAIIoTType, pucProp);
        if (MOS_NULL != pucNewIotProp)
        {
            // IoT设备属性转化
            pucStrProp = Config_IoTTrasProp(uiAIIoTType, pucNewIotProp, 0, 0);
            if (pucStrProp)
            {
                // 设置KjIot设备属性
                Config_SetInIotProp(uiAIIoTType, lluAIIoTID, pucStrProp);
                MOS_FREE(pucStrProp);
                pucStrProp = MOS_NULL;
            }
            else
            {
                MOS_FREE(pucNewIotProp);
                pucNewIotProp = MOS_NULL;

                MOS_LOG_ERR(ZJ_LOGSTR,"IoTStrProp is Null IoTType:%d IoTID:%d", uiAIIoTType, lluAIIoTID);

                return MOS_ERR;
            }

            MOS_FREE(pucNewIotProp);
            pucNewIotProp = MOS_NULL;
        }
    }
    else
    {
        // IoT设备属性转化
        pucStrProp = Config_IoTTrasProp(uiAIIoTType, pucProp, 0, 0);
        if (pucStrProp)
        {
            // 设置KjIot设备属性
            Config_SetInIotProp(uiAIIoTType, lluAIIoTID, pucStrProp);
            MOS_FREE(pucStrProp);
            pucStrProp = MOS_NULL;
        }
        else
        {
            MOS_LOG_ERR(ZJ_LOGSTR,"IoTStrProp is Null IoTType:%d IoTID:%d", uiAIIoTType, lluAIIoTID);
            return MOS_ERR;
        }
    }

    return MOS_OK;
}

/*
1000:
	1)pucDelProp==null && pucObjName != null 删除Motion、Human、Face、Car、Fence字段(删除1000的第一层字段)
	2)pucDelProp!=null && pucObjName != null 删除Motion、Human、Face、Car、Fence里的属性字段(删除1000的第二层字段)

非1000：
	1)pucDelProp!=null && pucObjName == null 删除非1000的IoT的第一层的属性字段
*/
// 删除IOT设备属性 (字段)
int ZJ_DelIoTProp(unsigned int uiAIIoTType,int iCamId, unsigned int uiAIIoTEventId, unsigned char* pucDelProp, unsigned char* pucObjName)
{
    _INT iRet = MOS_ERR;
    _LLID lluAIIoTID = (_LLID)iCamId;

    // 删除IOT设备属性 (字段)
    Config_DelIoTProp(uiAIIoTType, lluAIIoTID, uiAIIoTEventId, pucDelProp, pucObjName);

    // 同步删除报警策略属性 (字段)
    iRet = Config_DelAlarmPolicyProp(uiAIIoTType, lluAIIoTID, uiAIIoTEventId, pucDelProp, pucObjName);

    return iRet;
}

// 增加告警IOT设备策略类型
int ZJ_AddIoTDefaultPolicy(ST_ZJ_IOT_POLICY_INFO *pstIoTPolicyInfo)
{
    MOS_PARAM_NULL_RETERR(pstIoTPolicyInfo);
    _INT iRet = MOS_ERR;
    // 增加告警IOT设备策略类型
    iRet = Config_AddIoTDefaultPolicy(pstIoTPolicyInfo);
    return iRet;
}

// 删除告警IOT设备策略类型
int ZJ_DelIoTDefaultPolicy(unsigned int uiInIoTType, int iInCamId)
{
    _INT iRet = MOS_ERR;
    _LLID lluInIoTId = (_LLID)iInCamId;
    // 删除告警IOT设备策略类型
    iRet = Config_DelIoTDefaultPolicy(uiInIoTType, lluInIoTId);
    return iRet;
}

// 告警IOT设备 策略增加 联动响应的IOT设备
int ZJ_AddAlarmPolicyOutput(unsigned int uiInIoTType,  int iInCamId,  unsigned int uiInIoTEventId, 
                            unsigned int uiOutIoTType, int iOutCamId, unsigned char *pucOutIoTParam)
{
    MOS_PARAM_NULL_RETERR(pucOutIoTParam);
    _INT iRet = MOS_ERR;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    ST_CFG_OUTPUT_NODE      *pstOutputNode  = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;

    _LLID lluInIoTId  = (_LLID)iInCamId;
    _LLID lluOutIoTId = (_LLID)iOutCamId;

    // 查找告警IoT策略节点
    if (uiInIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION, lluInIoTId, IOT_DEFAULT_POLICYID_MOTION);
    }
    else
    {
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiInIoTType, lluInIoTId, uiInIoTType);
    }
    if (MOS_LIST_GETCOUNT(&pstAPolicyNode->stEventList) > 0)
    {
        // 查找 告警IoT策略的事件 的 节点
        pstEventNode = Config_FindAlarmEventNode(pstAPolicyNode,uiInIoTEventId);
        if(pstEventNode)
        {
            // 查找 告警IoT策略的事件 的 响应IoT的OutPut节点
            pstOutputNode = Config_FindOutNode(&pstEventNode->stOutputList,uiOutIoTType,lluOutIoTId);
            if (pstOutputNode)
            {
                if (pstOutputNode->uiSetDefaultFalg == 0)
                {
                    // 告警IOT设备 策略增加 联动响应的IOT设备
                    iRet = Config_AddAlarmPolicyOutput(pstAPolicyNode, uiInIoTEventId, uiOutIoTType, lluOutIoTId, pucOutIoTParam); 
                    MOS_LOG_INF(ZJ_LOGSTR,"InIot [%u %llu %u] add OutIot [%u %llu] Success",uiInIoTType,lluInIoTId,uiInIoTEventId,uiOutIoTType,lluOutIoTId);
                }
                else
                {
                    _UC* pucNewOutPutParam = MOS_NULL;
                    pucNewOutPutParam = Config_ChenkAndAddKeyToJson(pstOutputNode->pucParam, pucOutIoTParam);
                    if (pucNewOutPutParam)
                    {
                        iRet = Config_AddAlarmPolicyOutput(pstAPolicyNode, uiInIoTEventId, uiOutIoTType, lluOutIoTId, pucNewOutPutParam); 
                        MOS_FREE(pucNewOutPutParam);
                        pucNewOutPutParam = MOS_NULL;
                        MOS_LOG_INF(ZJ_LOGSTR,"InIot [%u %llu %u] add OutIot [%u %llu] Had Update",uiInIoTType,lluInIoTId,uiInIoTEventId,uiOutIoTType,lluOutIoTId);
                    }
                    else
                    {
                        iRet = MOS_OK;
                        MOS_LOG_INF(ZJ_LOGSTR,"InIot [%u %llu %u] add OutIot [%u %llu] NoNNeed Update",uiInIoTType,lluInIoTId,uiInIoTEventId,uiOutIoTType,lluOutIoTId);
                    }
                }
            }
            else
            {
                // 告警IOT设备 策略增加 联动响应的IOT设备
                iRet = Config_AddAlarmPolicyOutput(pstAPolicyNode, uiInIoTEventId, uiOutIoTType, lluOutIoTId, pucOutIoTParam); 
                MOS_LOG_INF(ZJ_LOGSTR,"InIot [%u %llu %u] first add OutIot [%u %llu] Success",uiInIoTType,lluInIoTId,uiInIoTEventId,uiOutIoTType,lluOutIoTId);
            }
        }
        else
        {
            MOS_LOG_ERR(ZJ_LOGSTR,"InIot [%u %llu %u] add OutIot [%u %llu] pstEventNode is null",uiInIoTType,lluInIoTId,uiInIoTEventId,uiOutIoTType,lluOutIoTId);
        }        
    }
    else
    {
        MOS_LOG_ERR(ZJ_LOGSTR,"InIot [%u %llu %u] add OutIot [%u %llu] eventlist is 0",uiInIoTType,lluInIoTId,uiInIoTEventId,uiOutIoTType,lluOutIoTId);
    }
    return iRet;
}

// 告警IOT设备 策略删除 联动响应的IOT设备
int ZJ_DelAlarmPolicyOutput(unsigned int uiInIoTType,  int iInCamId, unsigned int uiInIoTEventId, 
                            unsigned int uiOutIoTType, int iOutCamId)
{
    _INT iRet = MOS_ERR;
    ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = MOS_NULL;

    _LLID lluInIoTId  = (_LLID)iInCamId;
    _LLID lluOutIoTId = (_LLID)iOutCamId;

    // 查找告警IoT策略节点
    if (uiInIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(EN_ZJ_AIIOT_TYPE_MOTION, lluInIoTId, IOT_DEFAULT_POLICYID_MOTION);
    }
    else
    {
        pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiInIoTType, lluInIoTId, uiInIoTType);
    }
    if (MOS_LIST_GETCOUNT(&pstAPolicyNode->stEventList) > 0)
    {
        // 告警IOT设备 策略删除 联动响应的IOT设备
        iRet = Config_DeleteAlarmPolicyOutPut(pstAPolicyNode, uiInIoTEventId, uiOutIoTType, lluOutIoTId);
    }
    return iRet;
}

// 删除 联动响应的IOT设备的动作属性(字段)
int ZJ_DelAlarmPolicyOutputProp(unsigned int uiInIoTType,  int iInCamId,  unsigned int uiInIoTEventId,
                                unsigned int uiOutIoTType, int iOutCamId, unsigned char* pucDelOutputProp)
{
    MOS_PARAM_NULL_RETERR(pucDelOutputProp);
    _INT iRet = MOS_ERR;

    _LLID lluInIoTId  = (_LLID)iInCamId;
    _LLID lluOutIoTId = (_LLID)iOutCamId;

    // 删除 联动响应的IOT设备的动作属性(字段)
    iRet = Config_DelAlarmPolicyOutputProp(uiInIoTType, lluInIoTId, uiInIoTEventId, uiOutIoTType, lluOutIoTId, pucDelOutputProp);
    return iRet;
}

//IoT设备输入信号接口, 输入信号类型和对应的Json字符串作为信号描述
int ZJ_IoTInPut(unsigned int uiAIIoTType, unsigned long long lluAIIoTID, char* pcInPut)
{
    KjIoT_InputValue(uiAIIoTType,lluAIIoTID,(_UC*)pcInPut);
    return MOS_OK;
}

//IoT设备事件输入接口，IoT设备为事件单一设备，触发时直接根据属性输出事件；
int ZJ_IoTEventInPut(unsigned int uiAIIoTType, unsigned long long lluAIIoTID, int iEvent)
{
    if(Config_GetCamaraMng()->uiCamOpenFlag == 1)
    {
#ifdef BUILD_IMSSDK_FALG
        if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_CLICKBUTTON)
        {
            _INT iNetWorkType = Http_GetNetWorkType();
            MOS_LOG_INF(ZJ_LOGSTR,"IMSAbility is %d, uiHaveIMS is %d iNetworkType is %d",Config_GetCamaraMng()->uiIMSAbility,Config_GetImsMng()->uiHaveIMS,iNetWorkType);
            // 不建议使用ImsMedia_GetHaveIMS接口判断是否开通套餐
            if (Config_GetCamaraMng()->uiIMSAbility == 1 && Config_GetImsMng()->uiHaveIMS == 1)
            {
                if(iNetWorkType != EN_ZJ_NETWORK_TYPE_NONET && iNetWorkType != EN_ZJ_NETWORK_TYPE_AP)
                {
                    if (iEvent == EN_ZJ_VIDEOPLAY_EVENT_HANGUP)
                    {
                        ImsMedia_HangUp();
                    }
                    else
                    {
                        ImsMedia_CallOut("", EN_IMS_CALL_TYPE_IMS_1V1_VIDEO);
                    }
                }
            }
            else
            { 
                if(ZJ_GetFuncTable()->pfunImsRecvErrNtcCb)
                {
                    ZJ_GetFuncTable()->pfunImsRecvErrNtcCb(EN_ZJ_IMSERR_NOCHARGE);
                }
                else
                {
                    MOS_LOG_INF(ZJ_LOGSTR,"Device pfunImsRecvErrNtcCb is NULL");
                }       
            }
        }
        else
        {
            if ((uiAIIoTType == EN_ZJ_AIIOT_TYPE_VIDEOPLAY) && (iEvent == EN_ZJ_VIDEOPLAY_EVENT_HANGUP))
            {
                P2p_CloseClientSpeakerAndDisplay(1,0,0);
            }
            KjIoT_SetEvent(uiAIIoTType,lluAIIoTID,iEvent,MOS_NULL);
        }
#else
        if ((uiAIIoTType == EN_ZJ_AIIOT_TYPE_VIDEOPLAY) && (iEvent == EN_ZJ_VIDEOPLAY_EVENT_HANGUP))
        {
            P2p_CloseClientSpeakerAndDisplay(1,0,0);
        }
        KjIoT_SetEvent(uiAIIoTType,lluAIIoTID,iEvent,MOS_NULL);
#endif

    }
    else
    {
        MOS_LOG_INF(ZJ_LOGSTR,"Camera in Close Status");
#ifdef BUILD_IMSSDK_FALG
        if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_CLICKBUTTON)
        {
            if(ZJ_GetFuncTable()->pfunImsRecvErrNtcCb)
            {
                ZJ_GetFuncTable()->pfunImsRecvErrNtcCb(EN_ZJ_IMSERR_SLEEP);
            }
            else
            {
                MOS_LOG_INF(ZJ_LOGSTR,"Device pfunImsRecvErrNtcCb is NULL");
            }
        }
#endif
    } 
    return MOS_OK;
}

// IoT设备AI告警事件输入接口 (支持上传AI告警图片和视频的接口)
int ZJ_IotAIEventPVInPut(unsigned int uiAIIoTType,
                         unsigned long long lluAIIoTID,
                         unsigned int uiEvent,
                         ST_ZJ_AI_AlARM_UPLOAD_INF *pstAIAlarmUploadInf)
{
    MOS_PARAM_NULL_RETERR(pstAIAlarmUploadInf);
    _INT iRet = MOS_ERR;
    _UI  uiSetAIEventPVInPutFailFlag = 0;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 1)
    {
        ST_ZJ_AI_AlARM_UPLOAD_INF *pstIotAIUploadInf = (ST_ZJ_AI_AlARM_UPLOAD_INF*)MOS_MALLOC(sizeof(ST_ZJ_AI_AlARM_UPLOAD_INF));
        if (pstIotAIUploadInf != NULL)
        {
            MOS_LOG_INF(ZJ_LOGSTR, "IOT[%u %u] Time:%llu PicPath:%s VideoPath:%s",
                                    uiAIIoTType, uiEvent, pstAIAlarmUploadInf->lluTimeStamp,
                                    pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
            MOS_MEMCPY(pstIotAIUploadInf, pstAIAlarmUploadInf, sizeof(ST_ZJ_AI_AlARM_UPLOAD_INF));
            iRet = KjIoT_SetEventEx(uiAIIoTType,lluAIIoTID,uiEvent,pstIotAIUploadInf,MOS_TRUE);
            if (iRet != MOS_OK)
            {
                MOS_FREE(pstIotAIUploadInf);
                MOS_LOG_ERR(ZJ_LOGSTR, "AIAlarmPV SetEventEx Error");
                uiSetAIEventPVInPutFailFlag = 1;
            }
            else
            {
                return iRet;
            }
        }
        else
        {
            MOS_LOG_ERR(ZJ_LOGSTR, "AIAlarmPV MALLOC ERR");
            uiSetAIEventPVInPutFailFlag = 1;
        }
    }
    else
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "AIAlarmPV Camera in Close Status");
        uiSetAIEventPVInPutFailFlag = 1;
    }

    if (uiSetAIEventPVInPutFailFlag == 1)
    {
        // 通知厂商清除图片数据缓存 
        if (ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache)
        {
            iRet = ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache(pstAIAlarmUploadInf->ucPicPath,
                                                                   pstAIAlarmUploadInf->ucVideoPath);
            if (MOS_OK != iRet)
            {
                MOS_LOG_ERR(ZJ_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache PicPath:%s VideoPath:%s failed",
                                        pstAIAlarmUploadInf->ucPicPath, pstAIAlarmUploadInf->ucVideoPath);
            }
        }
        else
        {
            MOS_LOG_ERR(ZJ_LOGSTR,"Device pFunFreeUploadAIAlarmPVCache is NULL!");
        } 
    }
    return iRet;
}

//注册回调：释放IOT AI视频图片缓存
int ZJ_SetFreeUploadAIAlarmPVCacheCB(ZJ_PFUN_FREEUPLOADAIALARMPVCACHE pFunFreeUploadAIAlarmPVCache)
{
    ZJ_GetFuncTable()->pFunFreeUploadAIAlarmPVCache = pFunFreeUploadAIAlarmPVCache;
	return MOS_OK;
}

// 通知sdkAI告警的视频生成结果 iIsFinishFlag 1:成功 2:失败 (该接口目前只支持AI告警视频上传情况)
int ZJ_SetUploadAIAlarmPVFileFinish(unsigned char* pucFilePath, int iIsFinishFlag)
{
    MOS_PARAM_NULL_RETERR(pucFilePath);

    ST_CFG_UPLOAD_AIALARM_PV_INF_NODE *pstUplaodAIAlarmPVInfNode = MOS_NULL;
    pstUplaodAIAlarmPVInfNode = Config_FindUploadAIAlarmPVTaskNodeByPath(0, pucFilePath);
    if (pstUplaodAIAlarmPVInfNode)
    {
        if (MOS_STRNCMP(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, pucFilePath, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath)) == 0)
        {
            // AI告警图片生成成功
            if (iIsFinishFlag == 1)
            {
                Config_SetUploadAIAlarmPVTaskNodePicUploadFlagByPath(0, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, 1);
            }
            // AI告警图片生成失败
            else
            {
                Config_SetUploadAIAlarmPVTaskNodePicUploadFlagByPath(0, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucPicPath, 2);
            }
        }
        else if (MOS_STRNCMP(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath, pucFilePath, sizeof(pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath)) == 0)
        {
            // AI告警视频生成成功
            if (iIsFinishFlag == 1)
            {
                Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlagByPath(0, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath, 1);
            }
            // AI告警视频生成失败
            else
            {
                Config_SetUploadAIAlarmPVTaskNodeVideoUploadFlagByPath(0, pstUplaodAIAlarmPVInfNode->stAIAlarmUploadInf.ucVideoPath, 2);
            }
        }
        return MOS_OK;
    }
    return MOS_ERR;
}

// 注册回调: 释放启动前可能存在的缓存
int ZJ_SetFreeBeforeStartUpCacheCB(ZJ_PFUN_FREEBEFORESTARTUPCACHE pFunFreeBeforeStartUpCache)
{
    ZJ_GetFuncTable()->pFunFreeBeforeStartUpCache = pFunFreeBeforeStartUpCache;
	return MOS_OK;   
}

int ZJ_SetDefaultRecordProp(unsigned int uiLoopFlag,unsigned int  uiFullFlag,unsigned int uiStreamId)
{
    return Config_SetDefaultRecordProp(uiLoopFlag,uiFullFlag,uiStreamId,6);
}

int ZJ_SetDefaultSnapProp(unsigned int uiLoopFlag,unsigned int uiFullFlag,unsigned int uiInterval,unsigned int uiPicType)
{
    return Config_SetDefaultSnapProp(uiLoopFlag,uiFullFlag,uiInterval,uiPicType);
}

int ZJ_SetInIotWorkStatus(unsigned int uiAotType,unsigned long long lluAotId,int iWorkStatus)
{
    return Config_SetInIotWorkStatus(uiAotType,lluAotId,iWorkStatus);
}

// 设置KjIot设备的策略
int ZJ_SetIotDefaultPolicy(_UI uiIotType, _UI uiOpenFlag, _UI uiEventId, _UI uiTraceFlag, _UI uiBuzzerFlag,_UI uiSenstive, 
    _UI uiRecordFlag, _UI uiSnapFlag, _UI uiEventFlag, _UI uiEventInterval,_UI uiDuration,_UI uiActiveTime,_UI uiSoundType,_UC *pucSoundFile)
{
    // 设置KjIot设备的策略
    return Config_SetDefaultIotPolicy( uiIotType, uiOpenFlag, uiEventId, uiTraceFlag, uiBuzzerFlag, uiSenstive, 
        uiRecordFlag, uiSnapFlag, uiEventFlag, uiEventInterval,uiDuration,uiActiveTime,uiSoundType,pucSoundFile);
}

// 设置KjIot设备默认策略（通过结构体入参）,ST_ZJ_DEFAULT_POLICY
int ZJ_SetIotDefaultPolicyEx(ST_ZJ_DEFAULT_POLICY *pstPolicyInfo)
{
    // 设置KjIot设备的策略
    return Config_SetDefaultIotPolicy( pstPolicyInfo->uiIotType, pstPolicyInfo->uiOpenFlag, pstPolicyInfo->uiEventId, 
                                       pstPolicyInfo->uiTraceFlag, pstPolicyInfo->uiBuzzerFlag, pstPolicyInfo->uiSenstive, 
                                       pstPolicyInfo->uiRecordFlag, pstPolicyInfo->uiSnapFlag, pstPolicyInfo->uiEventFlag,
                                       pstPolicyInfo->uiEventInterval, pstPolicyInfo->uiDuration, pstPolicyInfo->uiActiveTime, 
                                       pstPolicyInfo->uiSoundType, pstPolicyInfo->pucSoundFile);   
}

