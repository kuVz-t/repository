#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"


// 设置设备升级状态回调函数，通过回调返回升级状态；设备上层收到后，启用升级程序下载升级固件；
int ZJ_SetOtaCBFuncs(ZJ_PFUN_NEWVERSON_NOTICE pFunNewVersionCb,ZJ_PFUN_NEWVERSON_DATADOWN pFunVersonDataDownCb,ZJ_PFUN_STOPUPGRADE pFunStopUpgrade,ZJ_PFUN_COVERIMAGE_NOTICE pFunCoverImageNotice)
{
    ZJ_GetFuncTable()->pFunNewVersionCb     = pFunNewVersionCb;
    ZJ_GetFuncTable()->pFunVersonDataDownCb = pFunVersonDataDownCb;
    ZJ_GetFuncTable()->pFunStopUpgrade      = pFunStopUpgrade;
    ZJ_GetFuncTable()->pFunCoverImageNotice = pFunCoverImageNotice;
    return MOS_OK;
}

// 设备开始升级状态，设备上报平台，进入升级状态； 当返回进入升级中状态后，启动升级进程，开始升级；
int ZJ_StartUpdate()
{
    // OTA 开始升级
    return Ota_StartUpgrade();
}

// 版本下载更新后, 汇报烧录 进度
int ZJ_SetBurnningProgress(_UI uiPercentage)
{
    // 上报升级状态和进度
    if (uiPercentage <= 0)
    {
        return Ota_PubUpgradePrecentage(0, EN_CFG_OTA_UPGRADE_FAIL);
    }
    else
    {
        return Ota_PubUpgradePrecentage(uiPercentage*3/10 + 70, EN_CFG_OTA_UPGRADE_NOW);
    }
}

// 设置OTA升级能力集 SDCard升级 本地升级 远程升级
int ZJ_SetOTAAbility(unsigned int uiOTAAbility)
{
    return Config_SetOtaAbility(uiOTAAbility);
}



