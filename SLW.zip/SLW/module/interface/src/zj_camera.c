#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "media_cache_api.h"
#include "IoManage_api.h"
#include "media_api.h"
#include "record_api.h"
#include "http_media.h"
#include "msgmng_api.h"
#include "watchdog_api.h"


int ZJ_SetLensMaxCount(int iLensCount)
{
	return Config_SetLensMaxCount(iLensCount);
}

int ZJ_SetLensInf(int iLenId,char *pucLenName,EN_ZJ_CAMERA_LENS_TYPE enLensType,double focalLenth)
{
	return Config_SetLensInf(iLenId,pucLenName,enLensType,focalLenth);
}

int ZJ_SetLenFocalLenthScale(int iLenId,double dMinFocalLenth,double dMaxFocalLenth)
{

    return MOS_OK;
}

int ZJ_GetCurLenId(int *piOutCurLenId)
{
    if(piOutCurLenId)
    {
        *piOutCurLenId = (_INT)(Config_GetCamaraMng()->stSensors.usCurLenId);
    }
    return MOS_OK;
}

int ZJ_SetStreamCount(int iStreamCount)
{
    return Config_SetCameraStreamCount(0,iStreamCount);
}

int ZJ_SetVoicePlayAbility(int iVoicePlayAbility)
{
    return Config_SetCameraVoicePlayAbility(0,iVoicePlayAbility);
}

int ZJ_SetCloudBroadcastAbility(unsigned int uiCloudBroadcastAbility)
{
    return Config_SetCameraCloudBroadCastAbility(0,uiCloudBroadcastAbility);
}

int ZJ_SetOSDSetAbility(int iOSDSetAbility)
{
    return Config_SetCameraOSDAbility(0,iOSDSetAbility);
}

int ZJ_SetCustomOSDExpandAbility(int iOSDSetExpandAbility)
{
    return Config_SetCameraOSDExpandAbility(0,iOSDSetExpandAbility);
}

int ZJ_SetOSDCommonSetAbility(int iOSDCommonSetAbility)
{
    return Config_SetCameraOSDCommonSetAbility(0,iOSDCommonSetAbility);
}

int ZJ_SetPresetPointAbility(int iPresetAbility)
{
    return Config_SetPreSetAbility(0,iPresetAbility);
}

int ZJ_SetCuriseAbility(int iCuriseAbility)
{
    return Config_SetCuriseAbility(0,iCuriseAbility);
}

int ZJ_SetResolutionAbility(int iStreamid,int iResolutionAbility)
{
    return Config_SetStreamResolutionAbility(0,iStreamid,iResolutionAbility);
}

int ZJ_SetVideoEncodeAbility(int istreamid,int iEncAbility)
{
    return Config_SetStreamCaptureAbility(0,istreamid,iEncAbility);
}

int ZJ_SetMicroPhoneAbility(int iMicroPhoneAbility)
{
    return Config_SetCameraMicPhoneAbility(0,iMicroPhoneAbility);
}

int ZJ_SetIRLedAbility(int iIRLedAbility)
{
    return Config_SetCameraIRLedAbility(0,iIRLedAbility);
}

int ZJ_SetCamerCurIRWorkMode(int iCurWorkMode)
{
    // return Config_SetCamerCurIRWorkMode(0,iCurWorkMode);
    return MOS_ERR;
}

int ZJ_SetImageInversionAbility(int iInversionAbility)
{
    return Config_SetCameraRotateAbility(0,iInversionAbility);
}

int ZJ_SetWdrAbility(int iWdrAbility)
{
    return Config_SetCameraWdrAbility(0,iWdrAbility);
}

int ZJ_SetCameraPhysicalMaskAbility(unsigned int uiPhysicalMaskAbility)
{
    return Config_SetCameraPhysicalMaskAbility(0, uiPhysicalMaskAbility);
}

int ZJ_SetCameraAlarmSoundExecuteTimeAbility(unsigned int uiAlarmSoundExecuteTimeAbility)
{
    return Config_SetCameraAlarmSoundExecuteTimeAbility(0, uiAlarmSoundExecuteTimeAbility);
}

int ZJ_SetCameraSuperCodesAbility(unsigned int uiSuperCodesAbility)
{
    return Config_SetCameraSuperCodesAbility(0, uiSuperCodesAbility);
}

int ZJ_SetExternalSpeakerAbility(unsigned int uiExternalSpeakerAbility)
{
    return Config_SetCameraExternalSpeakerAbility(0, uiExternalSpeakerAbility);
}

int ZJ_SetExternalSpeakerStatus(unsigned int uiConnectStatus, ST_ZJ_EXTERNAL_SPEAKER_INFO *pstInfo)
{
    return Config_SetCameraExternalSpeakerStatus(0, uiConnectStatus, pstInfo);
}

_ZJ_API int ZJ_SetWithScreenAbility(unsigned int uiWithScreenAbility)
{
    return Config_SetCameraWithScreenAbility(0, uiWithScreenAbility);
}

_ZJ_API int ZJ_SetVideoPlayAbility(unsigned int uiVideoPlayAbility)
{
    return Config_SetCameraVideoPlayAbility(0, uiVideoPlayAbility);
}

_ZJ_API int ZJ_SetCallButtonAbility(unsigned int uiCallButtonAbility)
{
    return Config_SetCameraCallButtonAbility(0, uiCallButtonAbility);
}

_ZJ_API int ZJ_SetHangUpButtonAbility(unsigned int uiHangUpButtonAbility)
{
    return Config_SetCameraHangUpButtonAbility(0, uiHangUpButtonAbility);
}

int ZJ_SetVideoPlaySupportAbility(ST_ZJ_VIDEOPLAY_SUPPORT_INFO *pstVideoPlaySupportAbility)
{
    return Config_SetCameraVideoPlaySupportAbility(0, pstVideoPlaySupportAbility);    
}

int ZJ_SetScreenHardwareInfo(ST_ZJ_SCREEN_HARDWARE_INFO *pstScreenHardwareInfo)
{
    return Config_SetCameraScreenHardwareInfo(0, pstScreenHardwareInfo);
}

int ZJ_SetVideoPlayInfo(ST_ZJ_VIDEO_PARAM *pstVideoPlayInfo)
{
    return Config_SetCameraVideoPlayInfo(0, pstVideoPlayInfo);
}

int ZJ_SetZoomAbility(unsigned int uiZoomAbility)
{
    return Config_SetCameraZoomAbility(0, uiZoomAbility);
}

int ZJ_SetFocusAbility(unsigned int uiFocusAbility)
{
    return Config_SetCameraFocusAbility(0, uiFocusAbility);
}

int ZJ_SetCustomizeAlarmSoundAbility(unsigned int uiCustimizeAbility)
{
    return Config_SetCameraCustomizeAlarmSoundAbility(0, uiCustimizeAbility);
}

int ZJ_SetAISwitchReturnErrAbility(int iReturnErrAbility)
{
    return Config_SetCameraAISwitchReturnErrAbility(0, iReturnErrAbility);
}

int ZJ_SetSDCardAbility(int iSDCardAbility)
{
    return Config_SetCamerStorageAbility(0,iSDCardAbility);
}

int ZJ_SetPTZAbility(int iPTZAbility)
{
    if(iPTZAbility != 0)
    {
        Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_PTZ,0);
        {
            /**
             * 创建1022 IOT，关联事件上报和录像、云存IOT策略
            */
            Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_LINKAGEALARM, 0);
            ST_ZJ_IOT_POLICY_INFO stIoTPolicyInfo = {0};
            stIoTPolicyInfo.uiInIoTType     = EN_ZJ_AIIOT_TYPE_LINKAGEALARM;
            stIoTPolicyInfo.lluInIoTId      = EN_ZJ_DEFAULT_IOTID;
            stIoTPolicyInfo.uiInIoTEventId  = EN_ZJ_DEFAULT_IOT_EVENTID;
            stIoTPolicyInfo.uiOpenFlag      = 1;
            stIoTPolicyInfo.uiSpanFlag      = 0;
            stIoTPolicyInfo.uiStartTime     = 0;
            stIoTPolicyInfo.uiEndTime       = 86400;
            stIoTPolicyInfo.uiWeekFlag      = 0X7F;  // 或者填 127
            strncpy((char*)(stIoTPolicyInfo.aucPolicyName), "DEVICELINKAGEALARM", sizeof(stIoTPolicyInfo.aucPolicyName));
            ZJ_SetIoTDefaultProp(EN_ZJ_AIIOT_TYPE_LINKAGEALARM, 0, "{\"Sensitive\":\"80\"}");
            // 添加电瓶车检测告警IoT的联动策略类型
            ZJ_AddIoTDefaultPolicy(&stIoTPolicyInfo);
        }
    }
    return Config_SetPtzAbility(iPTZAbility);
}

int ZJ_SetPTZSpeedAbility(int iPTZSpeedAbility)
{
    return Config_SetPtzSpeedAbility(iPTZSpeedAbility);
}

int ZJ_SetAttachPTZAbility(int iAttachPTZAbility)
{
    return Config_SetAttachPtzAbility(iAttachPTZAbility);
}

int ZJ_SetImageInversionCB(ZJ_PFUN_IMAGEINVERSION pfunImageInversion)
{
    ZJ_GetFuncTable()->pfunImageInversion = pfunImageInversion;
    return MOS_OK;
}

int ZJ_SetIRLedSwitchCB(ZJ_PFUN_IRLED_SWITCH pFunIRLedSwitchCb)
{
    ZJ_GetFuncTable()->pFunIRLedSwitchCb = pFunIRLedSwitchCb;
    return MOS_OK;
}

int ZJ_SetCameraSwitchCB(ZJ_PFUN_CAMERA_SWITCH pfunCameraSwitch)
{
    ZJ_GetFuncTable()->pfunCameraSwitch = pfunCameraSwitch;
    return MOS_OK;
}

int ZJ_SetCameraPTZCB(ZJ_PFUN_CAMERA_ONPTZ pfunOnPTZ, ZJ_PFUN_CAMERA_PTZ_GETPOINT pfunPTZGetPoint,
                ZJ_PFUN_CAMERA_PTZ_GOTOPOINT pfunPTZGotoPoint, ZJ_PFUN_CAMERA_PTZ_AUTOCHECK pfunPTZAutoCheck,
                ZJ_PFUN_CAMERA_CRUISE_START pfunCruiseStart,ZJ_PFUN_CAMERA_PTZ_STOP pfunPtzStop)
{
    ZJ_GetFuncTable()->pfunOnPTZ        = pfunOnPTZ;
    ZJ_GetFuncTable()->pfunPTZGetPoint  = pfunPTZGetPoint;
    ZJ_GetFuncTable()->pfunPTZGotoPoint = pfunPTZGotoPoint;
    ZJ_GetFuncTable()->pfunPTZAutoCheck = pfunPTZAutoCheck;
    ZJ_GetFuncTable()->pfunCruiseStart  = pfunCruiseStart;
    ZJ_GetFuncTable()->pfunPtzStop      = pfunPtzStop;
    return MOS_OK;
}

int ZJ_SetCameraPTZCBEx(ZJ_PFUN_CAMERA_ONPTZEX pfunOnPTZEx)
{
    ZJ_GetFuncTable()->pfunOnPTZEx = pfunOnPTZEx;
    return MOS_OK;
}

int ZJ_SetGetCameraPTZStatusCB(ZJ_PFUN_CAMERA_PTZ_STATUS pfunPtzStatus)
{
    ZJ_GetFuncTable()->pfunPtzStatus = pfunPtzStatus;
    return MOS_OK;
}

int ZJ_SetCameraSmartPtzCB(ZJ_PFUN_CAMERA_SMARTCRUISE_START pfunSmartCruiseStart, ZJ_PFUN_CAMERA_PTZ_STOP pfunSmartCruiseStop, ZJ_PFUN_CAMERA_PTZ_STOP pfunCruiseStop)
{
    ZJ_GetFuncTable()->pfunSmartCruiseStart = pfunSmartCruiseStart;
    ZJ_GetFuncTable()->pfunSmartCruiseStop  = pfunSmartCruiseStop;
    ZJ_GetFuncTable()->pfunCruiseStop       = pfunCruiseStop;
    return MOS_OK;  
}

int ZJ_SetRecordStatusCB(ZJ_PFUN_CAMERA_RECORD_STATUS pfunRecordStatus)
{
    ZJ_GetFuncTable()->pfunRecordStatus = pfunRecordStatus;
    return MOS_OK;
}
      
// 强拆设备触发报警开关
int ZJ_SetDismantableAlarmSwitchCB(ZJ_PFUN_SET_DISMANTABLE_ALARM pfunSetDismantableAlarm)
{
    ZJ_GetFuncTable()->pfunSetDismantableAlarm = pfunSetDismantableAlarm;
    return MOS_OK;
}

// 逗留报警开关
int ZJ_SetStayAlarmSwitchCB(ZJ_PFUN_SET_STAY_ALARM pfunSetStayAlarm)
{
    ZJ_GetFuncTable()->pfunSetStayAlarm = pfunSetStayAlarm;
    return MOS_OK;
}

int ZJ_SetCameraStatus(int iStatus)
{
    Config_SetCamerOpenFlag(0,iStatus);

    // 物理遮蔽上报当前休眠状态 0x3410
    MsgMng_UploadDevStatus(iStatus, EN_DEV_STATUS_CHANGE_WAY_PHYSICALMASK);
    return MOS_OK;
}

int ZJ_StartRecord(int iStreamID)
{
    return RdStg_StartCustom("11",0);;
}

int ZJ_StopRecord()
{
    return RdStg_StopCustom("11",0);;
}

int ZJ_SetOSDSettingCB(ZJ_PFUN_CAMERA_OSDSETTING pfunOSDSetting)
{
    ZJ_GetFuncTable()->pfunOSDSetting = pfunOSDSetting;
    return MOS_OK;
}

int ZJ_SetCustomOSDModeCB(ZJ_PFUN_CAMERA_CUSTOMOSDMODESETTING pfunCustomOSDModeSetting)
{
    ZJ_GetFuncTable()->pfunCustomOSDModeSetting = pfunCustomOSDModeSetting;
    return MOS_OK;
}

 int ZJ_SetShowTimeOSDCB(ZJ_PFUN_CAMERA_CTRLOSDSHOWFLAG pfunCtrlTimeOSD,ZJ_PFUN_CAMERA_CTRLOSDSHOWFLAG pFunCtrlCustomOsd)
{
    ZJ_GetFuncTable()->pFunCtrlTimeOsd   = pfunCtrlTimeOSD;
    ZJ_GetFuncTable()->pFunCtrlCustomOsd = pFunCtrlCustomOsd;
    return MOS_OK;
}

int ZJ_SetOSDCommonSettingCB(ZJ_PFUN_CAMERA_OSDCOMMONSETTING pFunOSDCommonSetting)
{
    ZJ_GetFuncTable()->pFunOSDCommonSetting = pFunOSDCommonSetting;
    return MOS_OK;
}

int ZJ_SetStoragePath(char* pcStoragePath)
{
    if(pcStoragePath == MOS_NULL)
    {
        pcStoragePath = "";
    }
    if(MOS_STRLEN(pcStoragePath) == 0)
    {
         Config_SetCamerStorageStatus(0,0);
    }
    else
    {
        Config_SetCamerStorageStatus(0,1);
    }
    Config_SetDevCachePath(pcStoragePath);
    IoMng_SetPath((_UC*)pcStoragePath);
    return MOS_OK;
}

int ZJ_SetSDCardErr()
{
    return MOS_OK;
}

int ZJ_SetDevSoudFilePath(char* pcStoragePath)
{
    return Config_SetDevSoudFilePath(pcStoragePath);
}

int ZJ_SetSDCardCB(ZJ_PFUN_CAMERA_FORMATSDCARD pfunFormatSDCard, ZJ_PFUN_CAMERA_GETSDCARDSIZE pfunGetSDCardInfo, ZJ_PFUN_CAMERA_CHECKSDCARD pfunCheckSDCard)
{
    ZJ_GetFuncTable()->pfunFormatSDCard  = pfunFormatSDCard;
    ZJ_GetFuncTable()->pfunGetSDCardInfo = pfunGetSDCardInfo;
    ZJ_GetFuncTable()->pfunCheckSDCard   = pfunCheckSDCard;
    return MOS_OK;
}

int ZJ_SetVideoToPlayCB(ZJ_PFUN_CAMERA_VIDEO_TOPLAY pfunVideoToPlay)
{
    ZJ_GetFuncTable()->pfunVideoToPlay = pfunVideoToPlay;
    return MOS_OK;
}

int ZJ_GetVideoaram(ST_ZJ_VIDEO_PARAM* pstVideoParam)
{
    return Media_VideoDisPlayGetStreamInfo(pstVideoParam);
}

int ZJ_GetVideoData(unsigned char** ppucDataBuf, int* iDataLen, int* is_keyframe, unsigned int* puiTimestamp)
{
    *iDataLen = Media_VideoDisPlayReadFrame(ppucDataBuf, is_keyframe, puiTimestamp);
    return MOS_OK;
}

int ZJ_SetMediaToPlayCB(ZJ_PFUN_CAMERA_MEDIA_TOPLAY pfunMediaToPlay)
{
    ZJ_GetFuncTable()->pfunMediaToPlay = pfunMediaToPlay;
    return MOS_OK;
}

int ZJ_GetMediaAudioParam(ZJ_HANDLE hHandle, ST_ZJ_AUDIO_PARAM* pstAudioParam)
{
    return Media_AudioPlayGetStreamInfo((_HAPLAYREAD)hHandle, pstAudioParam);

    return Media_GetAudioDescribe((_UI)hHandle,pstAudioParam);
}

int ZJ_GtMediaAudioData(ZJ_HANDLE hHandle, unsigned char** ppucDataBuf, int* iDataLen, unsigned int* puiTimestamp)
{
    _UI uiRemFrameCnt = 0;
    *iDataLen = Media_AudioPlayReadFrame((_HAPLAYREAD)hHandle, ppucDataBuf, puiTimestamp, &uiRemFrameCnt);
    return MOS_OK;

    *iDataLen =  Media_GetAudioFrame((_UI)hHandle,ppucDataBuf,puiTimestamp,&uiRemFrameCnt);
    return MOS_OK;
}

int ZJ_SetAudioEncParm(ST_ZJ_AUDIO_PARAM* pstAudioParam)
{
    return Config_SetCamAudioParam(0,pstAudioParam);
}

int ZJ_SetRingToneAbility(unsigned int uiBSupport,unsigned int uiDecAblity)
{
    return Config_SetRingToneAbilty(uiBSupport,uiDecAblity);
}

int ZJ_SetCameraMultiFocalLenthAbility(int iMultiFocalLenthAbility)
{
    return Config_SetCameraMultiFocalLenthAbility(iMultiFocalLenthAbility);
}

int ZJ_SetMaxChnNum(int iMaxChnNum)
{
    return Config_SetMaxChnNum(iMaxChnNum);
}

// 业务使用定时休眠去判断能不能使用定时休眠的下发
int ZJ_SetTimingAwakeAbility(int iTimingAwakeAbility)
{
    return Config_SetTimingAwakeAbility(iTimingAwakeAbility);
}

#include "time.h"
unsigned int ZJ_getCurrentDayMsec()
{
    struct timeval unix_time = {0,0};
    gettimeofday(&unix_time, NULL);
    struct tm *date = localtime(&unix_time.tv_sec);
    unsigned int ms = (date->tm_hour * 3600 + date->tm_min * 60 + date->tm_sec) * 1000;
    ms += (unix_time.tv_usec / 1000);
    return ms;
}

//写音频数据
int ZJ_Audio_WriteFrame(unsigned char* pucFrame, int iLen, unsigned int uiTimestamp)
{
    // unsigned int m_uiTimestamp = 0;
    // m_uiTimestamp = ZJ_getCurrentDayMsec();
#ifdef ZJ_SDK_MAGIC
    return Plugin_TaskPushAudioStream(pucFrame, iLen);
#endif
    return Media_WriteAudioFrame(0,pucFrame,iLen,uiTimestamp);
}

//重新设置音频编码参数
 int ZJ_Audio_ResetParam(ST_ZJ_AUDIO_PARAM* pstAudioParam)
{
    Media_ReSetAudioParameter(0,pstAudioParam->uiSampleRate,pstAudioParam->uiChannel,pstAudioParam->uiDepth,pstAudioParam->uiEncodeType);
    return Config_SetCamAudioParam(0,pstAudioParam);
}

//设置音频编码开关回调接口  通过该接口控制音频是否编码
int ZJ_SetAudioEncSwitchCB(ZJ_PFUN_AUDIO_SWITCH pfunAudioSwitch)
{
    ZJ_GetFuncTable()->pfunAudioSwitch = pfunAudioSwitch;
    return MOS_OK;
}

//设置视频编码参数
int ZJ_SetAudioEncParamCB(ZJ_PFUN_SET_AUDIO_PARM pfunSetAudioParm)
{
    ZJ_GetFuncTable()->pfunSetAudioParm = pfunSetAudioParm;
    return MOS_OK;
}

//设置音频采集/播放音量调节接口 通过该接口调节音量
int ZJ_SetAudioVolumnCB(ZJ_PFUN_AUDIO_VOLUMN_ADJUST pfunAudioVolumnAdjust)
{
    ZJ_GetFuncTable()->pfunAudioVolumnAdjust = pfunAudioVolumnAdjust;
    return MOS_OK;
}
//设置摄像机声音音量，当前值
int ZJ_SetAudioVolumn(int iVolumn)
{
    return Config_SetCamVolume(0,iVolumn);;
}

int ZJ_SetCamerMicOpenFlag(int iOpenFlag)
{
    return Config_SetCamerMicOpenFlag(0,iOpenFlag);
}

int ZJ_GetCameraMicOpenFlag()
{
    return Config_GetCamaraMng()->uiMicOpenFlag;
}

//设置码流 广角镜头校正参数；当镜头为广角镜头时用
int ZJ_SetStreamWideAngleLensInfo(int iStreamID, ST_ZJ_VIDEO_CIRCLE* pstCircleInfo)
{
    return Config_SetStreamerFisheyeInf(0,iStreamID,pstCircleInfo);
}

int ZJ_SetStreamWideAngleLensDistortion(int iStreamID, ST_ZJ_VIDEO_DISTORTION* pstDistortionInfo)
{
    return Config_SetStreamerDistortion(0,iStreamID,pstDistortionInfo);
}

//设置码流 视频编码参数；
int ZJ_SetVideoEncParam(int iStreamID, ST_ZJ_VIDEO_PARAM* pstVideoParam)
{
    return Config_SetCameraStreamParam(0,iStreamID,pstVideoParam);
}

//码流写入接口，以Frame一帧一帧数据来写
int ZJ_Video_WriteFrame(int iStreamID, unsigned char* pucFrame, int iLen, unsigned int uiTimestamp, unsigned int uiFrameType)
{
    // unsigned int m_uiTimestamp = 0;
    // m_uiTimestamp = ZJ_getCurrentDayMsec();
#ifdef ZJ_SDK_MAGIC
    return Plugin_TaskPushVideoStream(pucFrame, iLen);
#endif
    return Media_WriteVideoFrame(0,iStreamID,pucFrame,iLen,uiTimestamp,uiFrameType);
}

//码流写入接口，以NAL格式包的数据来写
int ZJ_Video_WriteNalFrame(int iSteramID, unsigned char* ptNal[], int iNalLen[], int iNalNum, unsigned int uiTimestamp, unsigned int iFrameType)
{
    return Media_WriteVideoNaluFrame(0,iSteramID,ptNal,iNalLen,iNalNum,uiTimestamp,iFrameType);
}

//重置编码参数，一般是改变了采集分辨率和编码方法
int ZJ_Video_ResetParam(int iStreamID, ST_ZJ_VIDEO_PARAM* pstVideoParam)
{
    Config_SetCameraStreamParam(0,iStreamID,pstVideoParam);
    return Media_ReSetVideoParameter(0,iStreamID,pstVideoParam->uiResolution,pstVideoParam->uiEncodeType);
}

//设置视频编码开关回调接口 通过该接口控制视频是否编码
int ZJ_SetVideoEncSwitchCB(ZJ_PFUN_VIDEO_SWITCH pfunVideoSwitch)
{
    ZJ_GetFuncTable()->pfunVideoSwitch = pfunVideoSwitch;
    return MOS_OK;
}

//设置视频编码参数
int ZJ_SetVideoEncParamCB(ZJ_PFUN_SET_VIDEO_PARM pfunSetVideoParm)
{
    ZJ_GetFuncTable()->pfunSetVideoParm = pfunSetVideoParm;
    return MOS_OK;
}

//设置需要一个编辑一个I帧回调接口 通过该接口通知编码器编一个I帧写下来
int ZJ_SetVideoNeedIFrameCB(ZJ_PFUN_VIDEO_NEEDIFRAME pfunVideoNeedIFrame)
{
    ZJ_GetFuncTable()->pfunVideoNeedIFrame = pfunVideoNeedIFrame;
    return MOS_OK;
}
  
//设置获取图片回调接口
int ZJ_Video_SetGetJpegCB(ZJ_PFUN_VIDEO_GETJPEG pfunVideoGetJpeg)
{
    Config_AddInIotDevice(EN_ZJ_AIIOT_TYPE_SNAPSHORT,0);
    ZJ_GetFuncTable()->pfunVideoGetJpeg = pfunVideoGetJpeg;
    return MOS_OK;
}

//设置摄像机宽动态开关
int ZJ_SetCamWdrOpenFlagCB(ZJ_PFUN_SET_WIDE_DYNAMIC_CAM pfunSetWideDynamicCam)
{
    ZJ_GetFuncTable()->pfunSetWideDynamicCam = pfunSetWideDynamicCam;
    return MOS_OK;
}
/*****************************************************************
**小鹤用
******************************************************************/
//切换摄像头
int ZJ_SetSwitchLenCB(ZJ_PFUN_SWITCH_LEN pfunSwitchLen)
{
    ZJ_GetFuncTable()->pfunSwitchLen = pfunSwitchLen;
    return MOS_OK;
}

int ZJ_SetCamAlarmSoundFileCB(ZJ_PFUN_DELSOUNDFILE  pFunDelSoundFile,ZJ_PFUN_GETSOUNDFILES  pFunGetSoudFiles)
{
    ZJ_GetFuncTable()->pFunDelSoundFile = pFunDelSoundFile;
    ZJ_GetFuncTable()->pFunGetSoudFiles = pFunGetSoudFiles;
    return MOS_OK;
}

int ZJ_SetRelayDevAwakeCB(ZJ_PFUN_SETRELAYDEVAWAKE pfunSetRelayDevAwakeStatus)
{
    ZJ_GetFuncTable()->pfunSetRelayDevAwakeStatus = pfunSetRelayDevAwakeStatus;
    return MOS_OK;
}

int ZJ_GetCurSessionsTTLTime(ST_ZJ_SESSION_TTL_INFO astSessionTTLS[8],int *piSessionCnt)
{
    return Http_GetCurSessionsTTLTime(astSessionTTLS,piSessionCnt);
}

int ZJ_SetDevCanUseStatus(unsigned int uiCanUseStatus)
{
    Config_GetCoreMng()->ucStatusUpFlag = 1;
    return Config_SetDevicePresenceFlag(uiCanUseStatus);
}

int ZJ_SetDownLoadFileCBFuncs(ZJ_PFUN_FILEDOWN_NOTICE pfunDownDataNtc,ZJ_PFUN_FILEDOWN_TRANS pfunDownDataTrans,ZJ_PFUN_FILEDOWN_STOP pfunDownDataStop)
{
    ZJ_GetFuncTable()->pfunDownDataNtc   = pfunDownDataNtc;
    ZJ_GetFuncTable()->pfunDownDataTrans = pfunDownDataTrans;
    ZJ_GetFuncTable()->pfunDownDataStop  = pfunDownDataStop;
    return MOS_OK; 
}


ZJ_HANDLE ZJ_AppThreadMonitorRegist(unsigned char *ucAppName, int iTimeOutSecs)
{
    if (ucAppName == MOS_NULL || iTimeOutSecs == 0)
    {
        return MOS_NULL;
    }
    return Swd_AppThreadRegist(ucAppName,iTimeOutSecs);
}

_INT ZJ_AppThreadMonitorFeedDog(ZJ_HANDLE hWdWriter)
{
    if (hWdWriter == MOS_NULL)
    {
        return MOS_NULL;
    }
    return Swd_AppThreadFeedDog(hWdWriter);
}

_INT ZJ_AppThreadMonitorUnRegist(ZJ_HANDLE hWdWriter)
{
    if (hWdWriter == MOS_NULL)
    {
        return MOS_NULL;
    }
    return Swd_AppThreadUnRegist(hWdWriter);
}

int ZJ_SetSuperCodesOpenFlagCB(ZJ_PFUN_SET_SUPER_CODES pfunSetSuperCodes)
{
    ZJ_GetFuncTable()->pfunSetSuperCodes = pfunSetSuperCodes;
    return MOS_OK;
}

// 通用外接设备插入状态   0.未插入 1.已插入
int ZJ_SetCommonExDevInsertStatus(char *pcExDevName, int iInsertStatus)
{
    if (pcExDevName == MOS_NULL)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "pcExDevName is null");
		return MOS_ERR;
    }

    // 例如: ExOneKeyAlarmStatus
    // 缺少Status
    if (MOS_STRSTR(pcExDevName, "Status") == MOS_NULL)
    {
        MOS_LOG_ERR(ZJ_LOGSTR, "ExDevName is invalid %s", pcExDevName);
        return MOS_ERR;
	}
	
	return Config_SeCommonExDevInsertStatus((_UC*)pcExDevName, iInsertStatus);
}