#include "mos.h"
#include "zj_interface.h"
#include "config_api.h"
#include "kjiot_device_api.h"
#include "config_prv.h"
#include "zj_aicamera.h"
#include "cloudstg_logcode.h"

//云化SDK注册iot算法到统一SDK
//uiAIIoTType:	算法iot类型
//lluAIIoTID：	camid默认0
int ZJ_AddCloudCamIoTDevice(unsigned int uiAIIoTType, unsigned long long lluAIIoTID)
{
    _UC aucPolicyname[128] = {0};
    _UC aucOutPut[256] = {0};
    _UI uiPolicyID = 0;
    ST_CFG_INIOT_NODE *pstIotNode = MOS_NULL;

    // 新增KjIot设备的CFG 和 该KjIot设备能力集至1
    Config_AddInIotDevice(uiAIIoTType, lluAIIoTID);
    pstIotNode = Config_FindInnerIotDevice(uiAIIoTType, lluAIIoTID);

    if (uiAIIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        uiPolicyID = IOT_DEFAULT_POLICYID_MOTION;
    }
    else
    {
        uiPolicyID = uiAIIoTType;
    }
    if (pstIotNode != MOS_NULL)
    {
        ST_CFG_ALARMPOLICY_NODE *pstAPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiAIIoTType, lluAIIoTID, uiPolicyID);
        if (pstAPolicyNode && MOS_LIST_GETCOUNT(&pstAPolicyNode->stEventList) == 0)  //添加相关IOT策略
        {
            MOS_VSNPRINTF(aucPolicyname, 128, "cloudCam_%u", uiAIIoTType);
            Config_SetAlarmPolicyOpenFlag(pstAPolicyNode, 1);
            Config_SetAlarmPolicyProp(pstAPolicyNode, "{\"Sensitive\":\"80\",\"Interval\":\"30\"}");
            Config_SetAlarmPolicyName(pstAPolicyNode, aucPolicyname);
            Config_SetAlarmPolicyTime(pstAPolicyNode, 0, 127, 0, 86400);

            Config_AddAlarmPolicyEvent(pstAPolicyNode, 0);
            MOS_VSNPRINTF(aucOutPut, 256, "{\"EmailFlag\":\"0\",\"PushFlag\":\"1\",\"SMSFlag\":\"0\",\"Interval\":\"0\"}");
            Config_AddAlarmPolicyOutput(pstAPolicyNode, 0, EN_ZJ_AIIOT_TYPE_EVENT, 0, aucOutPut);
            MOS_VSNPRINTF(aucOutPut, 256, "{\"CtrlType\":\"1\",\"StreamID\":\"0\",\"Duration\":\"60\"}");
            Config_AddAlarmPolicyOutput(pstAPolicyNode, 0, EN_ZJ_AIIOT_TYPE_CLOUDRECORD, 0, aucOutPut);
            MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "first regist cloud aiIot [%u %llu] success", uiAIIoTType, lluAIIoTID);
        }
    }
    else
    {
        return MOS_ERR;
    }
    return MOS_OK;
}

//add iot
int ZJ_CloudCamAddIoTDevice(unsigned int uiAIIoTType, unsigned long long lluAIIoTID,
                        ZJ_PFUN_AIIOT_START pfunAIIoTStart, ZJ_PFUN_AIIOT_STOP pfunAIIoTStop, 
                        ZJ_PFUN_AIIOT_GETINPUT pfunAIIoTGetInput, ZJ_PFUN_AIIOT_OUTPUT pfunAIIoTOutPut,
                        ZJ_PFUN_AIIOT_SETPROP pfunAIIoTSetProp, ZJ_PFUN_AIIOT_CHECKEVENT pfunAIIotCheckEvent)
{
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "uiAIIoTType:%u, lluAIIoTID:%llu", uiAIIoTType, lluAIIoTID);
    return ZJ_AddIoTDevice(uiAIIoTType,lluAIIoTID,pfunAIIoTStart,pfunAIIoTStop,
        pfunAIIoTGetInput,pfunAIIoTOutPut,pfunAIIoTSetProp,pfunAIIotCheckEvent);
}

//set default iotProp 
int ZJ_CloudCamSetIoTDefaultProp(unsigned int uiAIIoTType, unsigned long long lluAIIoTID, char* pcProp)
{
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "uiAIIoTType:%u, lluAIIoTID:%llu, pcProp:%s", uiAIIoTType, lluAIIoTID, pcProp);
    return ZJ_SetIoTDefaultProp(uiAIIoTType,lluAIIoTID,pcProp);
}

//获取流水号 注册回调
int ZJ_CloudCamSetEventNumGetCB(ZJ_PFUN_CLOUDCAM_GETEVENTNUM pfunGetEventNum)
{
    ZJ_GetFuncTable()->pfunGetEventNum = pfunGetEventNum;
    return MOS_OK;
}

//套餐变化通知 注册回调
int ZJ_SetNoticeCloudCameraCB(ZJ_PFUN_CLOUDCAMERA_NOTICE pfunNtcCloudCamera)
{
    ZJ_GetFuncTable()->pfunNtcCloudCamera = pfunNtcCloudCamera;
    return MOS_OK;
}

//iot属性变化通知 注册回调
int ZJ_SetIotPropChangeNtcCB(ZJ_PFUN_CLOUDCAM_SETPROP pfunSetAIIotProp)
{
    ZJ_GetFuncTable()->pfunSetAIIotProp = pfunSetAIIotProp;
    return MOS_OK;
}

//set default policy  ,add policy_prop,output_cloud  
int ZJ_CloudCamAddIoTDefaultPolicy(ST_ZJ_IOT_POLICY_INFO *pstIoTPolicyInfo)
{
    MOS_PARAM_NULL_RETERR(pstIoTPolicyInfo);
    _UI uiPolicyExist = 0;
    _UI uiPolicyID = 0;
    _UC aucBuff[256]= {0};
    ST_CFG_POLICYEVENT_NODE *pstEventNode = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstIotPolicyNode;
    ST_CFG_INIOT_NODE* pstInIotNode = Config_FindInnerIotDevice(pstIoTPolicyInfo->uiInIoTType,pstIoTPolicyInfo->lluInIoTId);

    if(pstInIotNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"can not find iniot[%u %llu] ",pstIoTPolicyInfo->uiInIoTType,pstIoTPolicyInfo->lluInIoTId);
        return MOS_ERR;
    }
    if (pstIoTPolicyInfo->uiInIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        uiPolicyID = IOT_DEFAULT_POLICYID_MOTION;
    }
    else
    {
        uiPolicyID = pstIoTPolicyInfo->uiInIoTType;
    }

    pstIotPolicyNode = Config_FindAlarmPolicyNode(pstIoTPolicyInfo->uiInIoTType,pstIoTPolicyInfo->lluInIoTId,uiPolicyID);
    if(pstIotPolicyNode != MOS_NULL)
    {
        uiPolicyExist = 1;
    }
    pstIotPolicyNode = Config_FindAndCreatAlarmPolicyNode(pstIoTPolicyInfo->uiInIoTType,pstIoTPolicyInfo->lluInIoTId,uiPolicyID);
    pstEventNode = Config_FindAlarmEventNode(pstIotPolicyNode, pstIoTPolicyInfo->uiInIoTEventId);
    if(pstEventNode != MOS_NULL)
    {
        MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"aiIot[%u %llu],eventid[%u] already have default policy",
            pstIoTPolicyInfo->uiInIoTType,pstIoTPolicyInfo->lluInIoTId,pstIoTPolicyInfo->uiInIoTEventId);
        return MOS_OK;
    }
    if(uiPolicyExist == 0)
    {
        pstIotPolicyNode->uiSpanFlag  = pstIoTPolicyInfo->uiSpanFlag;
        pstIotPolicyNode->uiOpenFlag  = pstIoTPolicyInfo->uiOpenFlag;
        pstIotPolicyNode->uiEndTime   = pstIoTPolicyInfo->uiEndTime;
        pstIotPolicyNode->uiStartTime = pstIoTPolicyInfo->uiStartTime;
        pstIotPolicyNode->uiWeekFlag  = pstIoTPolicyInfo->uiWeekFlag;
        pstIotPolicyNode->uiPolicyId  = uiPolicyID;
        Config_SetAlarmPolicyName(pstIotPolicyNode,pstIoTPolicyInfo->aucPolicyName);
        Config_SetAlarmPolicyProp(pstIotPolicyNode,pstInIotNode->pucProp);
    }
    Config_AddAlarmPolicyEvent(pstIotPolicyNode,pstIoTPolicyInfo->uiInIoTEventId);

    MOS_VSNPRINTF(aucBuff,256,"{\"CtrlType\":\"0\",\"Duration\":\"60\",\"StreamID\":\"0\"}");
    Config_AddAlarmPolicyOutput(pstIotPolicyNode,0,EN_ZJ_AIIOT_TYPE_CLOUDRECORD,0,aucBuff);

    MOS_VSNPRINTF(aucBuff,256,"{\"EmailFlag\":\"0\",\"PushFlag\":\"0\",\"SMSFlag\":\"0\",\"Interval\":\"300\",\"StartTime\":\"0\",\"EndTime\":\"86400\",\"SpanFlag\":\"0\"}");
    Config_AddAlarmPolicyOutput(pstIotPolicyNode,0,EN_ZJ_AIIOT_TYPE_EVENT,0,aucBuff);

    MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"aiIot[%u %llu] eventid[%u],default iotPolicy set ok",
        pstIoTPolicyInfo->uiInIoTType,pstIoTPolicyInfo->lluInIoTId,pstIoTPolicyInfo->uiInIoTEventId);
    return MOS_OK;
}

int ZJ_CloudCamGetIotRegistFlag(unsigned int uiAIIoTType, unsigned long long lluAIIoTID,unsigned int *puiRegistFlag)
{
    if(!puiRegistFlag)
    {
        return MOS_ERR;
    }
    if(Config_FindInnerIotDevice(uiAIIoTType,lluAIIoTID) == MOS_NULL)
    {
        *puiRegistFlag = 0;
    }
    else
    {
        *puiRegistFlag = 1;
    }
    
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "uiAIIoTType:%u, lluAIIoTID:%llu, puiRegistFlag:%u", uiAIIoTType, lluAIIoTID, *puiRegistFlag);
    return MOS_OK;
}

//set extance ability
int ZJ_SetCloudCameraExtAbility(unsigned char *pucJson)
{
    return Config_SetExtAbility(pucJson);
}

_INT Config_SetExtAbility(_UC *pucJson)
{
    _UI uiJsonLen = 0;
    ST_CFG_EXTINFO *pstExtCfgMng = MOS_NULL;

    uiJsonLen = MOS_STRLEN(pucJson);
    if(uiJsonLen == 0)
    {
        return MOS_OK;
    }

    pstExtCfgMng = &Config_Task_GetMng()->stExtCfg;
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    if(MOS_STRCMP(pstExtCfgMng->pucExtAbilityJson,pucJson) == 0)
    {
        Mos_MutexUnLock(&Config_Task_GetMng()->hMutex); 
        return MOS_OK;
    }
    if(pstExtCfgMng->uiExtAbilityJsonLen < uiJsonLen)
    {
        MOS_FREE(pstExtCfgMng->pucExtAbilityJson);
        pstExtCfgMng->uiExtAbilityJsonLen = uiJsonLen + 128;
        pstExtCfgMng->pucExtAbilityJson = (_UC*)MOS_MALLOCCLR(pstExtCfgMng->uiExtAbilityJsonLen);
    }
    MOS_STRNCPY(pstExtCfgMng->pucExtAbilityJson,pucJson,pstExtCfgMng->uiExtAbilityJsonLen);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex); 
    Config_GetCoreMng()->uiExtCfgUpFlag = 1;

    MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"set cloudcam extability %s",pucJson);
    return MOS_OK;
}

// 设备基础功能接口
int ZJ_CloudCamCtrlDev(unsigned int uiAIIoTType, char * pcInput)
{
    if (pcInput == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"pcInput is NULL, uiAIIoTType: %u", uiAIIoTType);
        return MOS_ERR;
    }
    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = KjIoT_FindDevContrlNode(uiAIIoTType);
    if (pstDevCtrlNode && pstDevCtrlNode->pFunContrlDev)
    {
        pstDevCtrlNode->pFunContrlDev(uiAIIoTType, 0, pcInput, MOS_NULL);
    }
    else
    {
        MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"ctrl iot %u, json %s fail", uiAIIoTType, pcInput);
    }
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "uiAIIoTType:%u, pcInput:%s", uiAIIoTType, pcInput);
    return MOS_OK;
}

// 云化摄像头设置和上报告警策略
_INT ZJ_CloudCamera_SetAndReportAlarmPolicy()
{
    JSON_HANDLE hRoot = MOS_NULL;
    _UC *pucStrTmp = MOS_NULL;
    JSON_HANDLE hObject = MOS_NULL;


    MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"set fence config");
    ST_CFG_ALARMPOLICY_NODE * pstPolicyNode = Config_FindAlarmPolicyNode(1000,0x0ULL,IOT_DEFAULT_POLICYID_MOTION);
    if (pstPolicyNode == MOS_NULL || pstPolicyNode->pucProp == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"can not find alarm node set failed");
        return MOS_ERR;
    }

    hRoot = Adpt_Json_Parse(pstPolicyNode->pucProp);

    //修改fence的status字段为1
    hObject = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Fence");
    if (hObject == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"find fence field failed");
        Adpt_Json_Delete(hRoot);
        return MOS_ERR;
    }
    else 
    {
        Adpt_Json_DeleteItemFromObject(hObject,(_UC*)"Status");
        Adpt_Json_AddItemToObject(hObject,(_UC*)"Status",Adpt_Json_CreateStrWithNum(1));
        Adpt_Json_DeleteItemFromObject(hObject,(_UC*)"Capture");
        Adpt_Json_AddItemToObject(hObject,(_UC*)"Capture",Adpt_Json_CreateStrWithNum(1));
    }
    pucStrTmp = Adpt_Json_Print(hRoot);
    Config_SetAlarmPolicyProp(pstPolicyNode,(_UC*)pucStrTmp);
    Adpt_Json_DePrint(pucStrTmp);
    Adpt_Json_Delete(hRoot);

    //修改pushflag值
    CloudCamera_ChangePushFlag(pstPolicyNode,5,1013,0x0ULL,1);
    CloudCamera_ChangePushFlag(pstPolicyNode,0,1013,0x0ULL,2);
    CloudCamera_ChangePushFlag(pstPolicyNode,1,1013,0x0ULL,2);

    //同步到本地和平台
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;

    MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"config open fence params success");
    return MOS_OK;
}

// 云化摄像头设置人型侦测告警策略
_INT ZJ_CloudCamera_CloseFenceAlarmPolicy()
{
    JSON_HANDLE hRoot = MOS_NULL;
    _UC *pucStrTmp = MOS_NULL;
    JSON_HANDLE hObject = MOS_NULL;


    MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"close fence, config alarmpolicy");
    ST_CFG_ALARMPOLICY_NODE * pstPolicyNode = Config_FindAlarmPolicyNode(1000,0x0ULL,IOT_DEFAULT_POLICYID_MOTION);
    if (pstPolicyNode == MOS_NULL || pstPolicyNode->pucProp == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"can not find alarm node %d:%d, set failed",1000,0);
        return MOS_ERR;
    }

    hRoot = Adpt_Json_Parse(pstPolicyNode->pucProp);

    //修改fence的status字段为0
    hObject = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Fence");
    if (hObject == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"find fence field failed");
        Adpt_Json_Delete(hRoot);
        return MOS_ERR;
    }
    else 
    {
        Adpt_Json_DeleteItemFromObject(hObject,(_UC*)"Status");
        Adpt_Json_AddItemToObject(hObject,(_UC*)"Status",Adpt_Json_CreateStrWithNum(0));
    }
    CloudCamera_ChangePushFlag(pstPolicyNode,5,1013,0x0ULL,0);
    //修改Human的status字段为1
    hObject = Adpt_Json_GetObjectItem(hRoot,(_UC*)"Human");
    if (hObject == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"find Human field failed");
        //打开移动侦测的pushflag值
        CloudCamera_ChangePushFlag(pstPolicyNode,0,1013,0x0ULL,1);
    }
    else 
    {
        Adpt_Json_DeleteItemFromObject(hObject,(_UC*)"Status");
        Adpt_Json_AddItemToObject(hObject,(_UC*)"Status",Adpt_Json_CreateStrWithNum(1));
        //打开人形，关闭移动侦测的pushflag值
        CloudCamera_ChangePushFlag(pstPolicyNode,1,1013,0x0ULL,1);
        CloudCamera_ChangePushFlag(pstPolicyNode,0,1013,0x0ULL,2);
    }
    //设置1000的prop
    pucStrTmp = Adpt_Json_Print(hRoot);
    Config_SetAlarmPolicyProp(pstPolicyNode,(_UC*)pucStrTmp);
    Adpt_Json_DePrint(pucStrTmp);
    Adpt_Json_Delete(hRoot);
    //同步到本地和平台
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = 1;

    MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"config close fence params success");
    return MOS_OK;
}

/*云化相关操作*/
// 查找云化摄像头告警节点
ST_CFG_POLICYEVENT_NODE *CloudCamera_FindAlarmEventNode(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UI uiEventId)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CFG_POLICYEVENT_NODE *pstEventNode = MOS_NULL;

    if (pstAlarmNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"param is null");
        return MOS_NULL;
    }

    FOR_EACHDATA_INLIST(&pstAlarmNode->stEventList, pstEventNode, stIterator)
    {
        if (pstEventNode->uiUseFlag && pstEventNode->uiKjIoTEventId == uiEventId)
        {
            pstEventNode->uiUseFlag = 1;
            break;
        }
    }
    return pstEventNode;
}

// 云化摄像头设置输出的json参数
_INT CloudCamera_SetOutputDevParam(ST_CFG_OUTPUT_NODE *pstOutputNode ,_UC *pucParam)
{
    MOS_PARAM_NULL_RETERR(pstOutputNode);
    MOS_PARAM_NULL_RETERR(pucParam);
    if (pstOutputNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"param is null");
        return MOS_ERR;
    }

    if (pucParam == MOS_NULL)
    {
        pucParam = (_UC*)"";
    }
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    if (pstOutputNode->uiParamLen < MOS_STRLEN(pucParam))
    {
        pstOutputNode->uiParamLen =  MOS_STRLEN(pucParam) + 128;
        MOS_FREE(pstOutputNode->pucParam);
        pstOutputNode->pucParam = (_UC*)MOS_MALLOCCLR(pstOutputNode->uiParamLen );
    }
    if (MOS_STRCMP(pstOutputNode->pucParam, pucParam) != 0)
    {
        MOS_STRNCPY(pstOutputNode->pucParam, pucParam, pstOutputNode->uiParamLen);
    }
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    return MOS_OK;
}

// 云化摄像头修改pushflag
_INT CloudCamera_ChangePushFlag(ST_CFG_ALARMPOLICY_NODE * pstPolicyNode,_UI uiEventId,_UI uiIotType,_LLID lluIotId, _INT iPushflag)
{
    MOS_PARAM_NULL_RETERR(pstPolicyNode);
    JSON_HANDLE hRoot = MOS_NULL;
    _UC *pucStrTmp = MOS_NULL;
    _INT iCachePushFlag = 0;

    ST_CFG_OUTPUT_NODE  *pstOutputNode      = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;

    if (pstPolicyNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"param is null");
        return MOS_ERR;
    }

    //1.查找区域入侵节点
    pstEventNode = CloudCamera_FindAlarmEventNode(pstPolicyNode,uiEventId);
    if (pstEventNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"find fence event %u failed",uiEventId);
        Adpt_Json_Delete(hRoot);
        return MOS_ERR;
    }

    //2.找到告警推送节点
    pstOutputNode = Config_FindAndCreatOutNode(&pstEventNode->stOutputList,uiIotType,lluIotId);
    if (pstOutputNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"find event node %u, id %llu failed",uiIotType,lluIotId);
        return MOS_ERR;
    }

    //MOS_LOG_INF(ZJ_LOGSTR,"error error %s",pstOutputNode->pucParam);
    hRoot = Adpt_Json_Parse(pstOutputNode->pucParam);
    if (hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"build output json failed");
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"PushFlag"), &iCachePushFlag);
   //设置原有的移动侦测与人形侦测
   if (iCachePushFlag == 0 && iPushflag == 2)
   {
        MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"event node %u, id %llu ,pushflag is %d, ignore set pushflag",uiIotType,lluIotId,iCachePushFlag);
        Adpt_Json_Delete(hRoot);
        return MOS_OK;
    }
    Adpt_Json_DeleteItemFromObject(hRoot,(_UC*)"PushFlag");
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"PushFlag",Adpt_Json_CreateStrWithNum(iPushflag));

    pucStrTmp = Adpt_Json_Print(hRoot);
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"set event [%u] AIIoTType [%u] config json : %s",uiEventId,uiIotType,pucStrTmp);
    CloudCamera_SetOutputDevParam(pstOutputNode,pucStrTmp);
    
    Adpt_Json_DePrint(pucStrTmp);  
    Adpt_Json_Delete(hRoot);

    return MOS_OK;
}

// 修改告警策略参数
int ZJ_ModifyPolicyParam(ST_ZJ_POLICY_MODIFY_INFO *pstPolicyModifyInfo)
{
    MOS_PARAM_NULL_RETERR(pstPolicyModifyInfo);
    _UI uiPolicyID                              = 0;
    ST_CFG_INIOT_NODE *pstInIotNode             = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmPolicyNode = MOS_NULL;
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "uiAIIotType:%u, lluAIIoTID:%llu, uiEventId:%u, uiOutIotType:%u, lluOutIoTID:%llu, pucOutput:%s",
        pstPolicyModifyInfo->uiAIIotType, pstPolicyModifyInfo->lluAIIoTID, pstPolicyModifyInfo->uiEventId, pstPolicyModifyInfo->uiOutIotType,
        pstPolicyModifyInfo->lluOutIoTID, pstPolicyModifyInfo->pucOutput);
    if (pstPolicyModifyInfo == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"param is null");
        return MOS_ERR;
    }

    pstInIotNode = Config_FindInnerIotDevice(pstPolicyModifyInfo->uiAIIotType,pstPolicyModifyInfo->lluAIIoTID);
    if (pstInIotNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"iot[%u %llu] not regist",pstPolicyModifyInfo->uiAIIotType,pstPolicyModifyInfo->lluAIIoTID);
        return MOS_ERR;
    }

    if (pstPolicyModifyInfo->uiAIIotType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        uiPolicyID = IOT_DEFAULT_POLICYID_MOTION;
    }
    else
    {
        uiPolicyID = pstPolicyModifyInfo->uiAIIotType;
    }

    pstAlarmPolicyNode = Config_FindAlarmPolicyNode(pstPolicyModifyInfo->uiAIIotType,pstPolicyModifyInfo->lluAIIoTID,uiPolicyID);
    if (pstAlarmPolicyNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"can not find iot[%u %llu] policyId[%u]",pstPolicyModifyInfo->uiAIIotType,pstPolicyModifyInfo->lluAIIoTID,uiPolicyID);
        return MOS_ERR;
    }

    return Config_AddAlarmPolicyOutput(pstAlarmPolicyNode,pstPolicyModifyInfo->uiEventId, \
        pstPolicyModifyInfo->uiOutIotType,pstPolicyModifyInfo->lluOutIoTID,pstPolicyModifyInfo->pucOutput);
}

_UC* ZJ_GetPolicyParam(_UI uiAIIotType,_LLID lluAIIoTID,_UI uiEventId)
{
    _UI uiPolicyID                          = 0;
    ST_CFG_OUTPUT_NODE  *pstOutputNode      = MOS_NULL;
    ST_CFG_POLICYEVENT_NODE *pstEventNode   = MOS_NULL;
    ST_CFG_ALARMPOLICY_NODE *pstAlarmPolicyNode = MOS_NULL;
    if (uiAIIotType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        uiPolicyID = IOT_DEFAULT_POLICYID_MOTION;
    }
    else
    {
        uiPolicyID = uiAIIotType;
    }
    pstAlarmPolicyNode = Config_FindAlarmPolicyNode(uiAIIotType,lluAIIoTID,uiPolicyID);
    if (pstAlarmPolicyNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"can not find iot[%u %llu] policyId[%u]",uiAIIotType,lluAIIoTID,uiPolicyID);
        return MOS_NULL;
    }
    // 查找 告警IoT策略的事件 的 节点
    pstEventNode = Config_FindAlarmEventNode(pstAlarmPolicyNode,uiEventId);
    if(pstEventNode == MOS_NULL)
    {
        return MOS_NULL;
    }
    // 添加/查找 告警IoT策略的事件 的 响应IoT的OutPut节点
    pstOutputNode = Config_FindOutNode(&pstEventNode->stOutputList,uiAIIotType,lluAIIoTID);
    return pstOutputNode->pucParam;
}

_INT Cloud_SetAlarmPolicyProp(ST_CFG_ALARMPOLICY_NODE *pstAlarmNode,_UC *pucProp, _UC ucAlarmPolicyUpdate)
{
    MOS_PARAM_NULL_RETERR(pstAlarmNode);
    MOS_PARAM_NULL_RETERR(pucProp);

    _UI uiPropLen = 0;
    
    if(pucProp == MOS_NULL)
    {
        pucProp = (_UC*)"";
    }  
    uiPropLen = MOS_STRLEN(pucProp);
    if(MOS_STRCMP(pstAlarmNode->pucProp,pucProp) == 0)
    {
        return MOS_OK;
    }     
    Mos_MutexLock(&Config_Task_GetMng()->hMutex);
    if(pstAlarmNode->uiPropLen < uiPropLen)
    {
        MOS_FREE(pstAlarmNode->pucProp);
        pstAlarmNode->uiPropLen = uiPropLen + 128;
        pstAlarmNode->pucProp  = (_UC*)MOS_MALLOCCLR(pstAlarmNode->uiPropLen);
    }
    MOS_STRNCPY(pstAlarmNode->pucProp, pucProp, pstAlarmNode->uiPropLen);
    Mos_MutexUnLock(&Config_Task_GetMng()->hMutex);
    MOS_LOG_INF(CFG_LOGSTR,"alarm policy set KjIoTType:%u policyid %u prop %s", pstAlarmNode->uiKjIoTType,pstAlarmNode->uiPolicyId,pucProp);
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;
    Config_GetItemSign()->ucAlarmPolicyUpdate = ucAlarmPolicyUpdate;
    return MOS_OK;
}

// 云化摄像头设置告警策略
_INT ZJ_CloudCamera_SetAlarmPolicy(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPolicyId, _UC* pucStrTmp, _UC ucAlarmPolicyUpdate)
{
    MOS_PARAM_NULL_RETERR(pucStrTmp);
    _UI uiPolicyIdTmp = 0;
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "uiKjIoTType:%u, lluKjIoTId:%llu, uiPolicyId:%u, pucStrTmp:%s, ucAlarmPolicyUpdate:%u", uiKjIoTType, lluKjIoTId, uiPolicyId,pucStrTmp, ucAlarmPolicyUpdate);
    if (uiKjIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        uiPolicyIdTmp = IOT_DEFAULT_POLICYID_MOTION;
    }
    else
    {
        uiPolicyIdTmp = uiPolicyId;
    }
    ST_CFG_ALARMPOLICY_NODE * pstPolicyNode = Config_FindAndCreatAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiPolicyIdTmp);
    if (pstPolicyNode == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"can not find alarm node %d:%d",uiKjIoTType,lluKjIoTId);
        return MOS_ERR;
    }

    Cloud_SetAlarmPolicyProp(pstPolicyNode,(_UC*)pucStrTmp, ucAlarmPolicyUpdate);
    //同步到本地
    Config_GetItemSign()->ucSaveAlarmPolicy = 1;

    MOS_LOG_INF(CLOUDCAMERA_LOG_STR,"config SetAlarmPolicy success");
    return MOS_OK;
}
_UC* ZJ_CloudCamera_GetAlarmPolicy(_UI uiKjIoTType,_LLID lluKjIoTId,_UI uiPolicyId)
{
    _UI uiPolicyIdTmp = 0;
    if (uiKjIoTType == EN_ZJ_AIIOT_TYPE_MOTION)
    {
        uiPolicyIdTmp = IOT_DEFAULT_POLICYID_MOTION;
    }
    else
    {
        uiPolicyIdTmp = uiPolicyId;
    }
    ST_CFG_ALARMPOLICY_NODE * pstPolicyNode = Config_FindAlarmPolicyNode(uiKjIoTType,lluKjIoTId,uiPolicyIdTmp);
    if (pstPolicyNode == MOS_NULL || pstPolicyNode->pucProp == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"can not find alarm node %d:%d",uiKjIoTType,lluKjIoTId);
        return MOS_NULL;
    }
    else if(pstPolicyNode->pucProp == MOS_NULL)
    {
        MOS_LOG_ERR(CLOUDCAMERA_LOG_STR,"pstIniotNode->pucProp == MOS_NULL");
        return MOS_NULL;
    }
    return pstPolicyNode->pucProp;
}
// 云化摄像头设置AI字段
_INT ZJ_CloudCamera_SetAIJson(_UC* pucStrTmp, _UC ucCfgAiUpdate)
{
    MOS_PARAM_NULL_RETERR(pucStrTmp);
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "ucCfgAiUpdate:%d, pucStr:%s", ucCfgAiUpdate, pucStrTmp);
    if (Config_ParseAIJson(pucStrTmp,EN_CFG_TYPE_ALL) == MOS_OK) {
        Config_GetItemSign()->ucSaveAiFlag  = 1;
        Config_GetItemSign()->ucCfgAiUpdate = ucCfgAiUpdate;
    }
    return MOS_OK;
}

// 云化摄像头获取AI字段
_UC* ZJ_CloudCamera_GetAIJson()
{
    return Config_BuildAIJson(EN_CFG_TYPE_ALL);
}

// 设置获取云摄像头SDK能力 1支持云化  0不支持云化
_INT ZJ_SetCloudCameraAbility(_UI uiCloudCameraAbility)
{
    MOS_LOG_INF(CLOUDCAMERA_LOG_STR, "CloudCameraAbility:%d", uiCloudCameraAbility);
    return Config_SetCommonAiAbility((_UC*)"CloudCameraAbility", uiCloudCameraAbility);
}