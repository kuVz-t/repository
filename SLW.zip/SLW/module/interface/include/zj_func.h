#ifndef HM_FUNC_H
#define HM_FUNC_H

#ifdef __cplusplus
extern "C" {
#endif
#include "zj_thirdmedia.h"
#include "zj_ims.h"
#include "zj_time.h"
#include "mos.h"
/******************************************************************************************************************
                                                注册回调函数
*******************************************************************************************************************/
typedef _INT (*ZJ_PFUN_NTYPLAYSTATUS)(_UC *pucPeerDid,_UI uiplayId,_UI uiOption,_UI uiCode);

//iOTHub 信号发送回调接口，通过该接口将数据用iOTHub的数据通道发送出去
typedef int (*ZJ_PFUN_IOTHUB_DATARECV)(unsigned char* pucData, int iLen);

// 获取时间快照 用于多路同步
typedef int (*ZJ_PFUN_DEVICE_GETSNAPSHOTTIME)(int *piTimeInSec, int *piTimeInMs, int *piTicket);


typedef struct stru_ZJ_SESSION_TTL_INFO
{
    unsigned int uiSessionID;
    unsigned int uiTTLTime;   //MS
    unsigned char aucPeerId[36];
}ST_ZJ_SESSION_TTL_INFO;

typedef struct stru_ZJ_FUNC_TABLE
{
    _UC ucInitFlag;
    _HMUTEX hGetJpgMutex;

    ZJ_PFUN_IMAGEINVERSION           pfunImageInversion;            // 图像翻转
    ZJ_PFUN_IRLED_SWITCH             pFunIRLedSwitchCb;             // 红外灯切换模式
    ZJ_PFUN_CAMERA_SWITCH            pfunCameraSwitch;              // cam 控制
    
    ZJ_PFUN_CAMERA_ONPTZ             pfunOnPTZ;                     // PTZ 移动
    ZJ_PFUN_CAMERA_ONPTZEX           pfunOnPTZEx;                   // 设置摄像头PTZEx
    ZJ_PFUN_CAMERA_PTZ_STOP          pfunPtzStop;                   // PTZ 移动停止
    ZJ_PFUN_CAMERA_PTZ_GETPOINT      pfunPTZGetPoint;               // 当前位置获取, 获取X,Y点值
    ZJ_PFUN_CAMERA_PTZ_GOTOPOINT     pfunPTZGotoPoint;              // 移动到预置点位置
    ZJ_PFUN_CAMERA_PTZ_AUTOCHECK     pfunPTZAutoCheck;              // 摄像机PTZ自动检测
    ZJ_PFUN_CAMERA_PTZ_STATUS        pfunPtzStatus;                 // 获取摄像头PTZ状态 
    ZJ_PFUN_CAMERA_CRUISE_START      pfunCruiseStart;               // 预置位  开始位置巡航
    ZJ_PFUN_CAMERA_PTZ_STOP          pfunCruiseStop;                // 预置位  停止位置巡航
    ZJ_PFUN_CAMERA_SMARTCRUISE_START pfunSmartCruiseStart;          // 通知摄像机 开始全景巡航
    ZJ_PFUN_CAMERA_PTZ_STOP          pfunSmartCruiseStop;           // 通知摄像机 停止全景巡航

    ZJ_PFUN_CAMERA_RECORD_STATUS     pfunRecordStatus;              // 录制状态 回调

    ZJ_PFUN_CAMERA_CUSTOMOSDMODESETTING pfunCustomOSDModeSetting;   // 自定义(文本)水印展示模式
    ZJ_PFUN_CAMERA_CTRLOSDSHOWFLAG   pFunCtrlCustomOsd;             // 自定义(文本)水印显示开关设置
    ZJ_PFUN_CAMERA_OSDSETTING        pfunOSDSetting;                // 自定义(文本)水印(位置，文本)设置
    ZJ_PFUN_CAMERA_CTRLOSDSHOWFLAG   pFunCtrlTimeOsd;               // 默认(时间)水印显示开关设置

    ZJ_PFUN_CAMERA_OSDCOMMONSETTING  pFunOSDCommonSetting;          // 默认(时间)水印(位置，格式)设置
    
    ZJ_PFUN_CAMERA_FORMATSDCARD      pfunFormatSDCard;              // tf 卡相关
    ZJ_PFUN_CAMERA_GETSDCARDSIZE     pfunGetSDCardInfo;
    ZJ_PFUN_CAMERA_CHECKSDCARD       pfunCheckSDCard;

    ZJ_PFUN_CAMERA_MEDIA_TOPLAY      pfunMediaToPlay;               // 音频逆向数据
    ZJ_PFUN_CAMERA_VIDEO_TOPLAY      pfunVideoToPlay;               // 视频逆向数据

    ZJ_PFUN_AUDIO_SWITCH             pfunAudioSwitch;
    ZJ_PFUN_AUDIO_VOLUMN_ADJUST      pfunAudioVolumnAdjust;

    ZJ_PFUN_VIDEO_SWITCH             pfunVideoSwitch;               // 视频编解码
    ZJ_PFUN_VIDEO_NEEDIFRAME         pfunVideoNeedIFrame;

    ZJ_PFUN_VIDEO_GETJPEG            pfunVideoGetJpeg;              // 抓图
    
    ZJ_PFUN_IOTHUB_DATARECV          pfunIoTHubDataRecv;            // 433天线数据接收

    ZJ_PFUN_DEVICE_STATUS            pFunSelfStatusCb;              // 设备和服务器的状态
    ZJ_PFUN_DEV_REBOOT               pfunDevRebootCb;               // 设备重启
    ZJ_PFUN_DEV_EXIT                 pfunDevExitCb;                 // 设备退出程序
    ZJ_PFUN_DEVICE_SETTIMEZONE       pfunSetTimeZone;
    ZJ_PFUN_DEVICE_GETTIMEANDZONE    pfunGetTimeZone;

    ZJ_PFUN_DEVICE_SETDEFAULTZONETIME pFunSetDefaultZoneAndTime;
    ZJ_PFUN_DEVICE_GETSNAPSHOTTIME    pfunGetSnapShotTime;          // 获取时间快照
    
    ZJ_PFUN_DEVICE_RESTOREFACTORYSETTING pfunRestoreFactorySetting; // 回复出厂设置

    ZJ_PFUN_DEVICE_SETWIFI           pfuncSetWifi;
    ZJ_PFUN_DEVICE_GETWIFI           pfuncGetWifi;
    ZJ_PFUN_DEVICE_GETNETINFO        pfunGetCurNetInfo;
    ZJ_PFUN_DEVICE_SETWIFI           pFunSetAutoConnSsid;
    ZJ_PFUN_DEVICE_AUTOCONN_RESULT   pFunAutoConnResult;
    
    ZJ_PFUN_STARTSLEEP               pfuncStartSleep;               // 开始休眠

    ZJ_PFUN_COLLECTLOGFILES          pFunCollectLogFiles;           // 日志搜集

    ZJ_PFUN_DEVICE_RECVCUSTOMDATA    pFuncOnRecvCustomData;
    ZJ_PFUN_NTYPLAYSTATUS            pfunPlayStatusCb;
    
    ZJ_PFUN_DEVICE_PINGINF           pfunGetPingInfo;               // rtos设备获取ping信息

    ZJ_PFUN_NEWVERSON_NOTICE         pFunNewVersionCb;              // 通知 有新的 版本
    ZJ_PFUN_NEWVERSON_DATADOWN       pFunVersonDataDownCb;          // 新的版本数据开始下载
    ZJ_PFUN_STOPUPGRADE              pFunStopUpgrade;               // 停止升级
    ZJ_PFUN_COVERIMAGE_NOTICE        pFunCoverImageNotice;          // 通知固件覆盖镜像 

    ZJ_PFUN_DELSOUNDFILE             pFunDelSoundFile;              // 删除自定义声音文件
    ZJ_PFUN_GETSOUNDFILES            pFunGetSoudFiles;              // 获取自定义声音文件
    
    /*author:@*/
    ZJ_PFUN_SET_AUDIO_PARM           pfunSetAudioParm;              // 配置音频采集参数
    ZJ_PFUN_SET_VIDEO_PARM           pfunSetVideoParm;              // 配置视频采集参数 
    ZJ_PFUN_SET_DISMANTABLE_ALARM    pfunSetDismantableAlarm;       // 强拆设备触发报警开关
    ZJ_PFUN_SET_STAY_ALARM           pfunSetStayAlarm;              // 逗留报警开关
    ZJ_PFUN_SET_WIDE_DYNAMIC_CAM     pfunSetWideDynamicCam;         // 设置摄像机宽动态
    ZJ_PFUN_CFGITEM_CHANGE           pfunCfgItemChangeCb;           // 设置摄像机名称
    ZJ_PFUN_SWITCH_LEN               pfunSwitchLen;                 // 切换前置摄像头
    ZJ_PFUN_SETRELAYDEVAWAKE         pfunSetRelayDevAwakeStatus;    // 设置中继设备唤醒状态
    
    ZJ_PFUN_OPENFILE                 pfunOpenFile;                  // 打开第三方厂商录像文件
    ZJ_PFUN_CLOSEFILE                pfunCloseFile;                 // 关闭第三方厂商录像文件
    ZJ_PFUN_THIRDREADFRAME           pfunReadFrame;                 // 读取第三方厂商录像文件数据
    ZJ_PFUN_SEEKBYTIMESTAMP          pfunSeekTime;                  // 跳转第三方厂商录像文件时间
    ZJ_PFUN_READFILEDES              pfunGetFileDes;                // 获取第三方厂商录像文件音视频参数
    ZJ_PFUN_DELETEFILE               pfunDeleteFile;                // 第三方厂商删除文件

    ZJ_PFUN_DEVICE_SETUTC            pfunSetUtcTime;                // 设置UTC时间

    ZJ_PFUN_SET_GA1400SWITCH         pfunSetGa1400SwitchCb;         // 设置GA1400开关
    ZJ_PFUN_SET_GA1400INFO           pFunSetGa1400InfoCb;           // 设置GA1400信息
    ZJ_PFUN_SET_GA1400STATUS         pFunSetGa1400StatusCb;         // 通知设备Ga1400在线状态

    ZJ_PFUN_CREAT_AILABLE            pFunCreateLabel;               // 创建LABEL
    ZJ_PFUN_MODIFY_PICINF            pFunModifyPicLabel;            // 更改图片归属的集合
    ZJ_PFUN_ADDAIPICCB               pFunAddSingleAiPic;            // 向底库集中添加新的图片 包括特征值提取
    ZJ_PFUN_DELAIPICSCB              pFunDelSingleAiPic;            // 从底库集中删除图片
    ZJ_PFUN_DELAILABLE               pFunDelLabel;                  // 删除底库集合
    ZJ_PFUN_FREEAIPICCACHE           pFunFreeAiPicCache;            // 释放上报人脸图和背景图的缓存

    ZJ_PFUN_FREEUPLOADAIALARMPVCACHE pFunFreeUploadAIAlarmPVCache;  // 释放上报IOT AI告警事件的视频图片的缓存
    ZJ_PFUN_FREEBEFORESTARTUPCACHE   pFunFreeBeforeStartUpCache;    // 释放启动前可能存在的缓存

    ZJ_PFUN_SETAUTOINPUTFLAG         pFunSetAutoInputFlag;          // 图片自动录入开关

    ZJ_PFUN_SETHUMANCOUNT_PARAM      pfunSetHumCountParam;          // 人流量统计开关、统计间隔
	ZJ_PFUN_SETHUMANCOUNT_REGIONS    pfunSetHumCountRegions;        // 人流量统计坐标设置
    ZJ_PFUN_CAMERA_CPU_RAM_USAGE     pfunGetCpuRamUsage;        	// 设备CPU占用率、内存使用率统计    
    ZJ_PFUN_START_CUSTOM_AUDIO       pfun_StartDownData;            // 通知设备开始下载音频文件
    ZJ_PFUN_CUSTOM_AUDIOD_TRANS      pfun_DataTrans;                // 小喇叭音频数据回调
    ZJ_PFUN_STOP_CUSTOM_AUDIO        pfun_StopDownData;             // 结束下载
    ZJ_PFUN_BROADCAST_CUSTOM_STRING  pfun_BroadCastCustomStr;       // 播放自定义字符串
    ZJ_PFUN_CLOUDCAM_GETEVENTNUM     pfunGetEventNum;               // 获取流水号回调函数定义
    ZJ_PFUN_CLOUDCAMERA_NOTICE       pfunNtcCloudCamera;            // 通知云化sdk去平台下载AI算法
    ZJ_PFUN_CLOUDCAM_SETPROP         pfunSetAIIotProp;              // 通知云化sdk iot属性变化

    ZJ_PFUN_FILEDOWN_NOTICE          pfunDownDataNtc;               // 通知下载文件
    ZJ_PFUN_FILEDOWN_TRANS           pfunDownDataTrans;             // 接收文件下载数据
    ZJ_PFUN_FILEDOWN_STOP            pfunDownDataStop;              // 通知文件下载接收
    ZJ_PFUN_IPV6_SWITCH              pfunIPv6Switch;                // 设置IPv6开关回调接口

    ZJ_PFUN_SET_EVENT_PUSHFLAG       pfunSetEventPushFlag;          // 移动、人形pushflag回调
    
    ZJ_PFUN_IMS_RECV_ERRNTC          pfunImsRecvErrNtcCb;           // 设置Ims 状态回调

	ZJ_PFUN_SET_SUPER_CODES          pfunSetSuperCodes;             // 超级编码

}ST_ZJ_FUNC_TABLE;

_VOID ZJ_InitFunTable();
_VOID ZJ_DestoryFunTable();

_INT  ZJ_SetNtyPlayStatusFun(ZJ_PFUN_NTYPLAYSTATUS pfunPlayStatusCb);

_INT  ZJ_GetJpgLock();
_INT  ZJ_GetJpgUnlock(); 
_INT  ZJ_GetOneJpg(_INT icamid, _UC ucPictureType, _UC **ppucJpegBuf);

_UI   ZJ_GetBiteRateByIndex(_UI uiIndex);

ST_ZJ_FUNC_TABLE *ZJ_GetFuncTable();

#ifdef __cplusplus
}
#endif

#endif
