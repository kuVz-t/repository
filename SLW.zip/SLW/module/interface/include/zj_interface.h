#ifndef HM_INTERFACE_H
#define HM_INTERFACE_H

#define  ZJ_LOGSTR                    (_UC*)"ZJ"

#include "zj_type.h"
#include "zj_ims.h"
#include "zj_time.h"
#include "zj_ga1400.h"
#include "zj_camera.h"
#include "zj_cameraiot.h"
#include "zj_thirdmedia.h"
#include "zj_channel.h"
//#include "zj_iothub.h"
#include "zj_log.h"
#include "zj_network.h"
#include "zj_ota.h"
#include "zj_power.h"
#include "zj_system.h"
#include "zj_func.h"
#include "zj_err.h"
#include "zj_swd.h"

#endif
