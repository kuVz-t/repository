#ifndef RF_RADIO_API_H
#define RF_RADIO_API_H

#ifdef __cplusplus
extern "C" {
#endif
#include "cmdhdl_type.h"
typedef struct stru_RF_CMDRSPINFO
{
    _UC ucMsgType;
    _UC ucMsgId;
    _UI uiSeqId;
    _UC aucPeerId[CFG_STRING_COMMONLEN+4];
    ST_FROM_TO_MSG stCmdSrcInf;
}ST_RF_CMDRSPINFO;

typedef struct stru_rfdev_node
{
    _UI   uiUseFlag;
    _UC   ucNoRspCnt;      // 没有响应的次数
    _UC   ucCurStatus;     // 当前设备 状态
    _UC   uiActionType;    // 将要进行的操作
    _UC   ucCtrlCode;      // 控制的状态
    
    _UI   uiStatus;        // < 3 表示可用 
    
    _UI   uiDacType;
    _LLID lluDacId;
    
    _CTIME_T  cReqTime;    // 请求的时间
    ST_RF_CMDRSPINFO stCmdRspInf;
    ST_MOS_LIST_NODE stNode;      
}ST_RFDEV_NODE;


_INT Rf_Init();
_INT Rf_Start();
_INT Rf_Stop();
_INT Rf_Destroy();

_VOID Rf_ProcDevListStatus(_CTIME_T CNowTime);

_INT  Rf_RcvRdDevMsg(_UC *pucMsg,_UI uiMsgLen);

_INT  Rf_SetAntConnectStatus(_UI uiConStatus);

_INT  Rf_AddRdDevice(_UI uiDacType,_LLID lluDacId,ST_RF_CMDRSPINFO *pstCmdRspInf);

_INT  Rf_DeleteRdDevice(_UI uiDacType,_LLID lluDacId,ST_RF_CMDRSPINFO *pstCmdRspInf);

_INT  Rf_ContrlRdDevice(_UI uiDacType,_LLID lluDacId,_UI uiCtrlType,ST_RF_CMDRSPINFO *pstCmdRspInf);

_INT  Rf_DeletAllRdDevice(ST_RF_CMDRSPINFO *pstCmdRspInf);

ST_MOS_LIST *Rf_GetRdDeviceList();

#ifdef __cplusplus
}
#endif

#endif


