/**
* @brief         softwatchdog apis
* @author        Hejh
* @date          2021-07-19
*/

#ifndef _WATCHDOG_API_H
#define _WATCHDOG_API_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"

#define  SWD_LOGSTR                         (_UC*)"SWD"
typedef  MOS_MASK_HANDLE_TYPE(_HSWDWRITE)   _HSWDWRITE;
#define  WATCHDOG_TIMEOUT_SEC               (10)
#define  FEED_DOG_TIMEOUT_SEC               (1)
#define  FEED_DOG_MIDDLE_TIMEOUT_SEC        (2)
#define  FEED_DOG_MAX_TIMESEC               (5)
#define  FEED_DOG_BIG_MAX_TIMESEC           (25)
#define  FEED_DOG_SUPER_MAX_TIMESEC         (120)
#define  FEED_DOG_SUPER_MAXEX_TIMESEC       (300)
#define  FEED_DOG_ULTRA_MAX_TIMESEC         (600)
#define  P2P_LIVE_VIDEO_APP                 (_UC*)"P2pLiveVideo"
#define  P2P_LIVE_AUDIO_APP                 (_UC*)"P2pLiveAudio"
#define  CLOUDSTG_PATCH_APP                 (_UC*)"CloudStgPatchMng"
#define  CLOUDSTG_NORMAL_APP                (_UC*)"CloudStgMng"
#define  CLOUDSTG_LOGGER_APP                (_UC*)"CloudStgLogger"
#define  CLOUDSTG_NETCHECK_APP              (_UC*)"CloudStgNetCheck"
#define  MULTIMEDIA_APP                     (_UC*)"MultiMedia"
#define  EPOLL_APP                          (_UC*)"EpollApp"
#define  IOMANAGE_APP                       (_UC*)"IoManage"
#define  CONFIG_APP                         (_UC*)"Config"
#define  IOT_APP                            (_UC*)"IoT"
#define  GA1400_APP                         (_UC*)"Ga1400"
#define  BROADCAST_APP                      (_UC*)"Broadcast"
#define  CMDHDL_APP                         (_UC*)"CmdHdl"
#define  MSGMNG_APP                         (_UC*)"MsgMng"
#define  P2P_CONNECT_MNG                    (_UC*)"p2pConMng"
#define  QP_CHECK_MNG                       (_UC*)"QualityProbeMng"
#define  P2P_CMD_MNG                        (_UC*)"P2pCmd"
#define  IMS_MEDIA_MNG                      (_UC*)"ImsMedia"
#define  IMS_CFG_MNG                        (_UC*)"ImCfg"

typedef struct stru_SWDOG_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _UC             ucRsv[2];
    _UI             uiWatchId;
    _HTHREAD        hThread;
    _HQUEUE         hMsgQueque;
    _HMUTEX         hMutex;
    ST_MOS_LIST     stAppInfoList;
}ST_SWDOG_MNG;

typedef struct stuct_WdAppNode
{
    _UI      uiUseFlag;                 // 0：未分配内存 1：分配内存
    _UI      uiWatchId;
    _UC      ucAppName[32];
    _INT     iOverTimeOutSec;
    _INT     iFeedTimeOutSec;
    _INT     iFeedFlag;
    _INT     iFeedIntervalSec;          // 喂狗最小间隔（秒）
    _CTIME_T cFeedTimeSec;              // 喂狗时间戳（秒）
    ST_MOS_LIST_NODE stNode;
}ST_WATCHNODE;

typedef struct stuct_WdFeedMsg
{
    _UI    uiWatchId;
    _UI    uiFeedType;
    _UC    ucAppName[32];
}ST_FEED_MSG;

ST_SWDOG_MNG *Swd_GetModuleMng();

/**
* @brief         init watchdog module
* @author        Hejh
* @date          2021-07-20
*/
_INT Swd_Module_Init();

/**
* @brief         start watchdog module
* @author        Hejh
* @date          2021-07-20
*/
_INT Swd_Module_Start();

/**
* @brief         stop watchdog module
* @author        Hejh
* @date          2021-07-20
*/
_INT Swd_Module_Stop();

/**
* @brief         destory watchdog module
* @author        Hejh
* @date          2021-07-20
*/
_INT Swd_Module_Destroy();

/**
* @brief         find watchdog ID
* @author        Liuwj
* @date          2023-06-14
*/
_HSWDWRITE Swd_FindAppByWatchId(_UI uiAppWatchId);

/**
* @brief         app Used register in watchdog module
* @author        Hejh
* @date          2021-07-20
*/
_HSWDWRITE Swd_AppThreadRegist(_UC *ucAppName, _INT iTimeOutSecs);

/**
* @brief         ZJ third app Used register in watchdog module
* @author        Liuwj
* @date          2023-06-14
*/
_HSWDWRITE Swd_AppThreadRegistForZJ(_UC *ucAppName, _INT iTimeOutSecs, _INT iFeedIntervalSec);

/**
* @brief         App user feed watdhcog in secs time interval,such as 1 seconds
* @author        Hejh
* @date          2021-07-20
*/
_INT Swd_AppThreadFeedDog(_HSWDWRITE hWdWriter);

/**
* @brief         App usr un register from watchdog module
* @author        Hejh
* @date          2021-07-20
*/
_INT Swd_AppThreadUnRegist(_HSWDWRITE hWdWriter);


#ifdef __cplusplus
}
#endif
#endif
