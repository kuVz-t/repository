#include "../include/watchdog_api.h"
#include "kj_timer.h"
#include "adpt_json_adapt.h"
#include <stdlib.h>
#include "zj_type.h"
#include "config_type.h"
#include "cmdhdl_type.h"
#include "cmdhdl_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "msgmng_type.h"
#include "zj_func.h"

extern int ZJ_Stop();
static ST_SWDOG_MNG g_stSftWatchDogMng = {0};
static _INT iSupportUploadLog = 0;
_INT Swd_Module_Task_Loop(_VPTR pstArg);


ST_SWDOG_MNG *Swd_GetModuleMng()
{
    return &g_stSftWatchDogMng;
}

_INT Swd_Module_Init()
{
    if(Swd_GetModuleMng ()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(SWD_LOGSTR, "Already Init");
        return MOS_OK;
    }

    MOS_MEMSET(&g_stSftWatchDogMng, 0, sizeof(g_stSftWatchDogMng));
    Swd_GetModuleMng()->ucRunFlag   = 0;
    Swd_GetModuleMng()->uiWatchId   = 0;
    Mos_MutexCreate(&Swd_GetModuleMng()->hMutex);
    Swd_GetModuleMng()->hMsgQueque  = Mos_MsgQueueCreate(MOS_FALSE, 45, __FUNCTION__);
    MOS_LIST_INIT(&Swd_GetModuleMng()->stAppInfoList);
    Swd_GetModuleMng ()->ucInitFlag = 1;
    MOS_LOG_INF(SWD_LOGSTR, "soft watchdog  init OK !");
    return MOS_OK;
}

_INT Swd_Module_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;

    if(Swd_GetModuleMng ()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    
    if(Swd_GetModuleMng ()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(SWD_LOGSTR, "Already Start");
        return MOS_OK;
    }

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    Swd_GetModuleMng ()->ucRunFlag = 1;
    if(Mos_ThreadCreate((_UC*)"WatchDog", EN_THREAD_PRIORITY_NORMAL, uiStackSize,
                        Swd_Module_Task_Loop, MOS_NULL, MOS_NULL, &Swd_GetModuleMng()->hThread) == MOS_ERR)
    {
        Swd_GetModuleMng()->ucRunFlag = 0;
        return MOS_ERR;
    }
    MOS_LOG_INF(SWD_LOGSTR, "softwatchDog Start OK !");

    return MOS_OK;
}

static _VOID Swd_UploadLog(_UC *pucUrl, _UC *pucErrorString)
{
    CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, -1, pucErrorString, 1);
}

_HSWDWRITE Swd_FindAppByWatchId(_UI uiAppWatchId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_WATCHNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Swd_GetModuleMng()->stAppInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 && pstBussNode->uiWatchId == uiAppWatchId)
        {
            return (_HSWDWRITE)pstBussNode;
        }
    }
    return MOS_NULL;
}

// 分配节点
ST_WATCHNODE *Swd_AllocAppNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_WATCHNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Swd_GetModuleMng()->stAppInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 0)
        {
            break;
        }
    }

    if(pstBussNode == MOS_NULL)
    {
        pstBussNode = (ST_WATCHNODE*)MOS_MALLOCCLR(sizeof(ST_WATCHNODE));
        if(pstBussNode == MOS_NULL)
        {
            return MOS_NULL;
        }
        MOS_LIST_ADDTAIL(&Swd_GetModuleMng()->stAppInfoList, pstBussNode);
    }
    pstBussNode->uiWatchId   = ++Swd_GetModuleMng()->uiWatchId;
    pstBussNode->uiUseFlag   = 1;
    return pstBussNode;
}

_INT Swd_FeedAppByWatchId(_UC *pucAppName,_UI uiAppWatchId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_WATCHNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Swd_GetModuleMng()->stAppInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 && pstBussNode->uiWatchId == uiAppWatchId
            && MOS_STRCMP(pucAppName, pstBussNode->ucAppName) == 0)
        {
            pstBussNode->iFeedFlag = 1;
        }
    }
    return MOS_TRUE;
}

_INT Swd_CheckAppStatus(_UC *pucAppErrorList)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_WATCHNODE *pstBussNode = MOS_NULL;
    _INT bRet = MOS_TRUE;
    _UI  uiErrorCount = 0;
    FOR_EACHDATA_INLIST(&Swd_GetModuleMng()->stAppInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 && pstBussNode->uiWatchId != 0
            && MOS_STRCMP(pstBussNode->ucAppName, "") != 0 )
        {
            if (pstBussNode->iFeedFlag != 1)
            {
                pstBussNode->iFeedTimeOutSec += 10;
                if (pstBussNode->iOverTimeOutSec <= pstBussNode->iFeedTimeOutSec)
                {
                    MOS_LOG_INF(SWD_LOGSTR, "check app thread :%s Id: %u error!!!\n", pstBussNode->ucAppName, pstBussNode->uiWatchId);
                    if (uiErrorCount++ <= 3)
                    {
                        MOS_STRCAT(pucAppErrorList, pstBussNode->ucAppName);
                        MOS_STRCAT(pucAppErrorList, ",");
                    }

                    bRet = MOS_FALSE;
                    if (0)
                    {
                        _UC  pucErrorString[128] = {0};
                        MOS_SPRINTF(pucErrorString, "check app thread :%s Id: %u error!!!\n", pstBussNode->ucAppName, pstBussNode->uiWatchId);
                        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, -1, pucErrorString, 1);
                    }
                }
                else
                {
                    MOS_PRINTF("check app thread :%s Id: %u overTime:%d>=feedTime:%d, recheck again\n",
                                pstBussNode->ucAppName, pstBussNode->uiWatchId, pstBussNode->iOverTimeOutSec, pstBussNode->iFeedTimeOutSec);
                }
            }
            else
            {
                pstBussNode->iFeedTimeOutSec = 0;
            }
            pstBussNode->iFeedFlag = 0;
        }
    }
    //MOS_PRINTF("check app thread feed ok!!!\n");
    return bRet;
}

_INT Swd_Module_Task_Loop(_VPTR pstArg)
{
    _INT        iRet = MOS_FALSE;
    kj_timer_t  tCheckAliveTimeout;
    kj_timer_init(&tCheckAliveTimeout);
    getDiffTimems(&tCheckAliveTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    ST_FEED_MSG *pstMsgHead = MOS_NULL;
    _INT        iIgnoreExit = MOS_FALSE;
    _UC         ucAppErrorList[320]= {0};
    _UC         pucErrorString[640] = {0};
    if (Mos_FileIsExist("/tmp/test_no_watchdog") == MOS_FALSE)
    {
        iIgnoreExit = MOS_TRUE;
    }

    while (Swd_GetModuleMng()->ucRunFlag == 1)
    {
        pstMsgHead = Mos_MsgQueuePop(Swd_GetModuleMng()->hMsgQueque);
        if(pstMsgHead != MOS_NULL)
        {
            if (pstMsgHead->uiFeedType == 1)
            {
                Mos_MutexLock(&Swd_GetModuleMng()->hMutex);
                Swd_FeedAppByWatchId(pstMsgHead->ucAppName, pstMsgHead->uiWatchId);
                Mos_MutexUnLock(&Swd_GetModuleMng()->hMutex);
                MOS_FREE(pstMsgHead);
                pstMsgHead = MOS_NULL;
                continue;
            }
            MOS_FREE(pstMsgHead);
        }
        else
        {
            Mos_Sleep(20);
        }

        if (getDiffTimems(&tCheckAliveTimeout, 0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= WATCHDOG_TIMEOUT_SEC)
        {
            static _INT count_tims = 0;
            getDiffTimems(&tCheckAliveTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
            MOS_MEMSET(ucAppErrorList, 0, sizeof(ucAppErrorList));
            Mos_MutexLock(&Swd_GetModuleMng()->hMutex);
            iRet = Swd_CheckAppStatus(ucAppErrorList);
            Mos_MutexUnLock(&Swd_GetModuleMng()->hMutex);
            if (iRet != MOS_TRUE)
            {
                MOS_MEMSET(pucErrorString, 0, sizeof(pucErrorString));
                MOS_SPRINTF(pucErrorString, "%s:%d, errorApps:%s", "检测到线程异常, error times", count_tims, ucAppErrorList);
                if (iSupportUploadLog >= 1)
                {
                    Swd_UploadLog(__FUNCTION__, pucErrorString);
                }
                MOS_LOG_INF(SWD_LOGSTR, "%s", pucErrorString);
                if (count_tims++ >= 2)
                {
                    if (iIgnoreExit == MOS_TRUE)
                    {
                        /*停止线程*/
                        Swd_GetModuleMng()->ucRunFlag = 0;
                        // 关闭信令服务器、关闭MP4、Commit云存任务
                        Cmdhdl_CloseSomethingBeforeReboot(MOS_TRUE);

                        MOS_PRINTF("检测到线程异常, exit now !!\n");
                        ZJ_Stop();
                        if(ZJ_GetFuncTable()->pfunDevExitCb)
                        {
                            MOS_PRINTF("检测到线程异常,pfunDevExitCb is not null!!\n");
                            ZJ_GetFuncTable()->pfunDevExitCb();
                            Mos_Sleep(5*1000);
                        }
                        else
                        {
                            Mos_Sleep(1*1000);
                            if(ZJ_GetFuncTable()->pfunDevRebootCb)
                            {
                                // 线程异常重启需要静默重启 参考:EN_ZJ_REBOOT_TYPE
                                MOS_PRINTF("检测到线程异常,pfunDevRebootCb is not null!!\n");
                                ZJ_GetFuncTable()->pfunDevRebootCb(EN_ZJ_REBOOT_SILENCE);
                            }
                        }
                    }
                }
            }
            else
            {
                count_tims = 0;
            }
        }
    }
    return MOS_OK;
}

_HSWDWRITE Swd_AppThreadRegist(_UC *ucAppName, _INT iTimeOutSecs)
{
    if(Swd_GetModuleMng()->ucInitFlag == 0)
    {
        return MOS_OK;
    }

     Mos_MutexLock(&Swd_GetModuleMng()->hMutex);
     ST_WATCHNODE *stAppNode = Swd_AllocAppNode();
     MOS_STRCPY(stAppNode->ucAppName, ucAppName);
     stAppNode->iFeedTimeOutSec    = 0;
     stAppNode->iOverTimeOutSec    = iTimeOutSecs;
     stAppNode->iFeedFlag          = 1;
     MOS_PRINTF("%s %s watchId:%u register\n", __FUNCTION__, stAppNode->ucAppName, stAppNode->uiWatchId);
     Mos_MutexUnLock(&Swd_GetModuleMng()->hMutex);
     return (_HSWDWRITE)stAppNode;
}

_HSWDWRITE Swd_AppThreadRegistForZJ(_UC *ucAppName, _INT iTimeOutSecs, _INT iFeedIntervalSec)
{
    if(Swd_GetModuleMng()->ucInitFlag == 0)
    {
        MOS_LOG_ERR(SWD_LOGSTR,"Swd for zj no init");
        return MOS_OK;
    }

    if (iTimeOutSecs < iFeedIntervalSec)
    {
        MOS_LOG_ERR(SWD_LOGSTR,"gb iTimeOutSecs(%d) < iFeedIntervalSec(%d) Regist Swd ERR", iTimeOutSecs, iFeedIntervalSec);
        return MOS_ERR;
    }

     Mos_MutexLock(&Swd_GetModuleMng()->hMutex);
     ST_WATCHNODE *stAppNode = Swd_AllocAppNode();
     MOS_STRCPY(stAppNode->ucAppName, ucAppName);
     stAppNode->iFeedTimeOutSec    = 0;
     stAppNode->iOverTimeOutSec    = iTimeOutSecs;
     stAppNode->cFeedTimeSec       = 0; // Mos_Time();
     stAppNode->iFeedIntervalSec   = iFeedIntervalSec;
     stAppNode->iFeedFlag          = 1;
     MOS_PRINTF("%s %s watchId:%u register iTimeOutSecs:%d iFeedIntervalSec:%d \n", 
        __FUNCTION__, stAppNode->ucAppName, stAppNode->uiWatchId, iTimeOutSecs, iFeedIntervalSec);
     Mos_MutexUnLock(&Swd_GetModuleMng()->hMutex);
     return (_HSWDWRITE)stAppNode;
}

_INT Swd_AppThreadFeedDog(_HSWDWRITE hWdWriter)
{
    if (Swd_GetModuleMng()->ucRunFlag == 0)
    {
        return MOS_FALSE;
    }

    ST_WATCHNODE *stAppNode  = (ST_WATCHNODE*)hWdWriter;
    ST_FEED_MSG  *stFeedMsg  = (ST_FEED_MSG*)Mos_MallocClr(sizeof(ST_FEED_MSG));
    stFeedMsg->uiFeedType    = 1;
    stFeedMsg->uiWatchId     = stAppNode->uiWatchId;
    MOS_STRCPY(stFeedMsg->ucAppName, stAppNode->ucAppName);
    _INT iRet = Mos_MsgQueuePush(Swd_GetModuleMng()->hMsgQueque, stFeedMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(stFeedMsg);
    }
    return iRet;
}

_INT Swd_AppThreadUnRegist(_HSWDWRITE hWdWriter)
{
    if(Swd_GetModuleMng()->ucInitFlag == 0)
    {
        return MOS_OK;
    }

    ST_WATCHNODE *stAppNode     = (ST_WATCHNODE*)hWdWriter;
    Mos_MutexLock(&Swd_GetModuleMng()->hMutex);
    stAppNode->uiUseFlag        = 0;
    stAppNode->iFeedTimeOutSec  = 0;
    stAppNode->iOverTimeOutSec  = 0;
    MOS_PRINTF("%s %s watchId:%u unregister\n", __FUNCTION__, stAppNode->ucAppName, stAppNode->uiWatchId);
    MOS_MEMSET(stAppNode->ucAppName, 0, sizeof(stAppNode->ucAppName));
    Mos_MutexUnLock(&Swd_GetModuleMng()->hMutex);
    return MOS_OK;
}

_INT Swd_Module_Stop()
{
    if(Swd_GetModuleMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(SWD_LOGSTR, "Already Stop");
        return MOS_OK;
    }

    Swd_GetModuleMng()->ucRunFlag  = 0;
    Mos_ThreadDelete(Swd_GetModuleMng()->hThread);
    return MOS_OK;
}

_INT Swd_Module_Destroy()
{
    if(Swd_GetModuleMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(SWD_LOGSTR, "Already Destroy");
        return MOS_OK;
    }

    Mos_MutexLock(&Swd_GetModuleMng()->hMutex);
    _VPTR pstMsg = MOS_NULL;
    while((pstMsg = Mos_MsgQueuePop(Swd_GetModuleMng()->hMsgQueque)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    MOS_LIST_RMVALL(&Swd_GetModuleMng()->stAppInfoList, MOS_TRUE);
    Mos_MutexUnLock(&Swd_GetModuleMng()->hMutex);
    Mos_MsgQueueDelete(Swd_GetModuleMng()->hMsgQueque);
    Mos_MutexDelete(&Swd_GetModuleMng()->hMutex);
    Swd_GetModuleMng()->ucInitFlag  = 0;
    MOS_LOG_INF(SWD_LOGSTR, "Swd Destroy ok");
    return MOS_OK;
}
