//
//  kj_thread.h
//  kj_sdk
//
//  Created by twenty on 2020/12/22.
//

#ifndef kj_thread_h
#define kj_thread_h

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>

typedef enum {
    kj_task_pri_low,
    kj_task_pri_normal,
    kj_task_pri_high
} kj_task_priority;

typedef struct kj_thread kj_thread;
// 执行任务函数的回调
typedef void kj_thread_task_execute_callback(const kj_thread *thread, const void *func, void *args);
// 取消任务的执行回调，发生在销毁线程时未执行的任务则被取消
typedef void kj_thread_task_cancel_callback(const kj_thread *thread, const void *func, void *args);
// 线程销毁前的回调
typedef void kj_thread_will_destroy_callback(const kj_thread *thread, void *user_data);

typedef struct kj_thread_task kj_thread_task;
struct kj_task_inner {
    kj_thread_task_execute_callback *execute_cb;    // 执行任务的回调，在回调中执行任务的function
    kj_thread_task_cancel_callback *cancel_cb;      // 取消任务的回调，如需处理参数args则在回调中进行操作
    kj_thread_task *next;
};
struct kj_thread_task {
    kj_task_priority priority;  // 任务的执行优先度，默认为kj_task_pri_low
    void *function;             // 任务的执行函数地址，在线程回调函数中输出
    void *args;                 // 执行函数所需的参数，在线程回调函数中输出
    size_t args_length;         // 参数的长度，如不设置则不会复制参数
    struct kj_task_inner inner; // 内部处理的私有变量，外部不可更改
};

/*
 1、kj_thread_create：创建一个线程，可选择设置线程名称
 2、kj_thread_add_task：往创建的一个线程加入要执行的任务，任务包括执行任务的回调、任务的函数、函数所需的参数、任务优先度和是否阻塞当前线程；支持多线程添加任务
 3、kj_thread_destroy：销毁线程，调用后需等待正在执行的任务执行完才销毁，未执行的任务被放弃执行
 */
kj_thread *kj_thread_create(const char *name, void *user_data, kj_thread_will_destroy_callback *destroy_cb);

// 创建任务，需设置执行任务的回调函数，根据需求对 kj_thread_task 结构体的成员变量进行设置，如何设置参考 kj_thread_task 结构体的成员变量注释说明
kj_thread_task kj_thread_task_create(kj_thread_task_execute_callback *execute_cb, kj_thread_task_cancel_callback *cancel_cb);

// 往线程任务执行队列添加一个任务，返回1添加成功，0为失败
int kj_thread_add_task(kj_thread *thread, kj_thread_task task);

// 销毁线程，需传入指针的指针，执行销毁后该指针被置NULL，避免销毁后再调用其他接口而导致不预期结果发生
void kj_thread_destroy(kj_thread **thread);

// 获取线程状态
int kj_thread_is_working(const kj_thread *thread);

// 当前线程是否与所给线程相同，1:相同；0:不相同
int kj_thread_is_equal_current(const kj_thread *thread);

#pragma mark - 锁操作
// 创建线程锁，如设置recursive则同一线程可多次取得锁，对应需释放多次锁
int kj_thread_init_mutex(pthread_mutex_t *mutex, int recursive);
int kj_thread_lock(pthread_mutex_t *mutex);
int kj_thread_try_lock(pthread_mutex_t *mutex);
void kj_thread_unlock(pthread_mutex_t *mutex);

#pragma mark - 快捷线程执行方法
int kj_thread_run_func(kj_thread *thread, void *arg, void (*func)(void *arg));

void kj_thread_new_thread(void *user_data, void (*callback)(void *user_data, pthread_t *thread));

#endif /* kj_thread_h */
