//
//  rm_sock.h
//  P2PLib
//
//  Created by twenty on 2023/5/25.
//

#ifndef kj_sock_h
#define kj_sock_h

#if (defined(_WIN32) || defined(__WIN32__))
#define ioctl ioctlsocket
#else
#include <sys/ioctl.h>
#include <netdb.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

#include "kj_rm_types.h"
#include "kj_util.h"

typedef struct kj_sock_ioqueue kj_sock_ioqueue;

typedef struct rm_sock rm_sock;

typedef struct kj_sockaddr {
    uint8_t family;
    union {
        struct sockaddr_in ipv4;
        struct sockaddr_in6 ipv6;
    } addr;
} kj_sockaddr;

typedef struct kj_sock_cb {
    void (*recv_data_callback)(rm_sock *sock, const void *data, size_t length, const kj_sockaddr *src_addr);
    void (*state_callback)(rm_sock *sock, kj_cnt_state state);
} kj_sock_cb;

struct rm_sock {
    int af;                 // 地址协议，取值AF_INET和AF_INET6
    int socket;             // socket
    int allow_poll;         // 标记是否允许sock ioqueue执行收取数据
    int socket_err_times;   // 记录ioqueue收取数据发生错误的次数，达到10次不为EAGAIN时回调中断状态
    void *user_data;        // 上层用户数据指针
    kj_sock_cb callback;    // 回调
    kj_sock_ioqueue *ioqueue;// 收取数据ioqueue
    KJ_NODE_TYPE(struct rm_sock);
};

struct kj_sock_ioqueue {
    pthread_mutex_t sock_mutex;
    rm_sock sock_node;
};

#pragma mark - sock ioqueue
kj_sock_ioqueue *kj_sock_ioqueue_create(void);
void kj_sock_ioqueue_destroy(kj_sock_ioqueue **ioqueue);

int kj_sock_ioqueue_poll(kj_sock_ioqueue *ioqueue);

#pragma mark - sock
rm_sock *kj_sock_create_udp(void *user_data, int af, kj_sock_cb callback);
void kj_sock_init_udp(rm_sock *sock, void *user_data, int af, kj_sock_cb callback);
void kj_sock_destroy(rm_sock **sock);

void *kj_sock_get_user_data(rm_sock *sock);

void kj_sock_register_to_ioqueue(rm_sock *sock, kj_sock_ioqueue *ioqueue);
void kj_sock_unregister_from_ioqueue(rm_sock *sock, kj_sock_ioqueue *ioqueue);

void kj_sock_close(rm_sock *sock, int callback);

void kj_sock_start_recvfrom(rm_sock *sock);
void kj_sock_stop_recv_data(rm_sock *sock);

ssize_t kj_sock_recvfrom(rm_sock *sock, void *data, size_t length, kj_sockaddr *src_addr);

kj_send_status kj_sock_send_to(rm_sock *sock, const void *data, size_t length, const kj_sockaddr *sockaddr);

int kj_sock_get_local_addr(rm_sock *sock, kj_sockaddr *sockaddr);

#pragma mark - utility
socklen_t kj_sockaddr_length(const kj_sockaddr *sockaddr);

/// 根据IP地址和端口初始化sockaddr
/// @param sockaddr sockaddr指针
/// @param af 地址协议，AF_INET和AF_INET6
/// @param ip IP地址
/// @param port 端口
/// @return 0：失败；1：成功
int kj_sockaddr_init(kj_sockaddr *sockaddr, int af, const char *ip, uint16_t port);

/// 复制struct sockaddr结构体数据
/// @param sockaddr kj_sockaddr结构体指针
/// @param addr struct sockaddr结构体数据指针
/// @param af 地址协议，AF_INET和AF_INET6
void kj_sockaddr_copy(kj_sockaddr *sockaddr, const void *addr, int af);

void kj_sockaddr_set_port(kj_sockaddr *sockaddr, uint16_t port);

int kj_sockaddr_is_only_addr_equal(const kj_sockaddr *addr1, const kj_sockaddr *addr2);

int kj_sockaddr_is_equal(const kj_sockaddr *addr1, const kj_sockaddr *addr2);

#endif /* kj_sock_h */
