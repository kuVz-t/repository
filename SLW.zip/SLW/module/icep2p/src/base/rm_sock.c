//
//  rm_sock.c
//  P2PLib
//
//  Created by twenty on 2023/5/25.
//

#include "rm_sock.h"
#include "kj_thread.h"

#pragma mark - sock ioqueue
kj_sock_ioqueue *kj_sock_ioqueue_create(void) {
    kj_sock_ioqueue *ioqueue = calloc(1, sizeof(kj_sock_ioqueue));
    KJ_NODE_INIT(ioqueue->sock_node);
    kj_thread_init_mutex(&ioqueue->sock_mutex, 1);
    return ioqueue;
}
void kj_sock_ioqueue_destroy(kj_sock_ioqueue **ioqueue) {
    if (*ioqueue) {
        kj_sock_ioqueue *ioq = *ioqueue;
        *ioqueue = NULL;
        pthread_mutex_lock(&ioq->sock_mutex);
        rm_sock *sock = ioq->sock_node.next;
        while (KJ_NODE_NOT_EQUAL(sock, &ioq->sock_node)) {
            rm_sock *next = sock->next;
            sock->ioqueue = NULL;
            KJ_NODE_REMOVE(sock);
            sock = next;
        }
        pthread_mutex_unlock(&ioq->sock_mutex);
    }
}
int kj_sock_ioqueue_poll(kj_sock_ioqueue *ioqueue) {
    int events = 0;
    if (ioqueue) {
        pthread_mutex_lock(&ioqueue->sock_mutex);
        char data[1500];
        ssize_t recv_len = 0;
        rm_sock *sock = ioqueue->sock_node.next;
        kj_sockaddr src_addr = {};
        while (KJ_NODE_NOT_EQUAL(sock, &ioqueue->sock_node)) {
            if (sock->allow_poll) {
                recv_len = kj_sock_recvfrom(sock, data, 1500, &src_addr);
                if (recv_len > 0) {
                    if (sock->callback.recv_data_callback) {
                        sock->callback.recv_data_callback(sock, data, recv_len, &src_addr);
                    }
                    events++;
                } else if (recv_len < 0 && EAGAIN != errno) {
                    // errno的值达到10次不为EAGAIN时，断开该sock
                    if (++sock->socket_err_times > 10) {
                        kj_sock_close(sock, 1);
                    }
                }
            }
            sock = sock->next;
        }
        pthread_mutex_unlock(&ioqueue->sock_mutex);
    }
    return events;
}

#pragma mark - sock
rm_sock *kj_sock_create_udp(void *user_data, int af, kj_sock_cb callback) {
    rm_sock *sock = calloc(1, sizeof(rm_sock));
    kj_sock_init_udp(sock, user_data, af, callback);
    return sock;
}
void kj_sock_init_udp(rm_sock *sock, void *user_data, int af, kj_sock_cb callback) {
    if (sock) {
        sock->af = af == AF_INET6 ? AF_INET6 : AF_INET;
        sock->user_data = user_data;
        sock->callback = callback;
        sock->socket = socket(sock->af, SOCK_DGRAM, IPPROTO_IP);
        unsigned long nonblock = 1;
        ioctl(sock->socket, FIONBIO, &nonblock);
    }
}
void kj_sock_destroy(rm_sock **sock) {
    rm_sock *temp = *sock;
    *sock = NULL;
    if (temp) {
        kj_sock_unregister_from_ioqueue(temp, temp->ioqueue);
        kj_sock_close(temp, 0);
        free(temp);
    }
}
void *kj_sock_get_user_data(rm_sock *sock) {
    return sock ? sock->user_data : NULL;
}
void kj_sock_register_to_ioqueue(rm_sock *sock, kj_sock_ioqueue *ioqueue) {
    if (sock && ioqueue) {
        pthread_mutex_lock(&ioqueue->sock_mutex);
        rm_sock *tail = ioqueue->sock_node.prev;
        KJ_NODE_ADD_BEHIND(tail, sock);
        sock->ioqueue = ioqueue;
        pthread_mutex_unlock(&ioqueue->sock_mutex);
    }
}
void kj_sock_unregister_from_ioqueue(rm_sock *sock, kj_sock_ioqueue *ioqueue) {
    if (sock && ioqueue) {
        pthread_mutex_lock(&ioqueue->sock_mutex);
        KJ_NODE_REMOVE(sock);
        sock->ioqueue = NULL;
        pthread_mutex_unlock(&ioqueue->sock_mutex);
    }
}
void kj_sock_close(rm_sock *sock, int callback) {
    if (sock && sock->socket > 0) {
        sock->allow_poll = 0;
        sock->socket_err_times = 0;
        close(sock->socket);
        sock->socket = 0;
        if (callback && sock->callback.state_callback) {
            sock->callback.state_callback(sock, kj_cnt_state_disconnected);
        }
    }
}
void kj_sock_start_recvfrom(rm_sock *sock) {
    if (sock) {
        sock->socket_err_times = 0;
        if (sock->socket == 0) {
            sock->socket = socket(sock->af, SOCK_DGRAM, IPPROTO_IP);
            unsigned long nonblock = 1;
            ioctl(sock->socket, FIONBIO, &nonblock);
        }
        sock->allow_poll = 1;
    }
}
void kj_sock_stop_recv_data(rm_sock *sock) {
    if (sock) {
        sock->allow_poll = 0;
    }
}
ssize_t kj_sock_recvfrom(rm_sock *sock, void *data, size_t length, kj_sockaddr *src_addr) {
    ssize_t len = 0;
    if (sock && sock->socket > 0 && data) {
        if (src_addr) {
            src_addr->family = sock->af;
            socklen_t addrlen = kj_sockaddr_length(src_addr);
            len = recvfrom(sock->socket, data, length, 0, (struct sockaddr *)&src_addr->addr, &addrlen);
        } else {
            len = recvfrom(sock->socket, data, length, 0, NULL, NULL);
        }
    }
    return len;
}
kj_send_status kj_sock_send_to(rm_sock *sock, const void *data, size_t length,const kj_sockaddr *sockaddr) {
    kj_send_status status = kj_send_status_invalid;
    if (sock && sock->socket > 0 && data && sockaddr) {
        ssize_t len = sendto(sock->socket, data, length, 0, (struct sockaddr *)&sockaddr->addr, kj_sockaddr_length(sockaddr));
        if (len >= 0) {
            status = kj_send_status_success;
        } else {
            status = kj_send_status_failed;
        }
    }
    return status;
}
int kj_sock_get_local_addr(rm_sock *sock, kj_sockaddr *sockaddr) {
    int result = 0;
    if (sock && sockaddr) {
        sockaddr->family = sock->af;
        socklen_t length = kj_sockaddr_length(sockaddr);
        result = getsockname(sock->socket, (struct sockaddr *)&sockaddr->addr, &length);
    }
    return result;
}

#pragma mark - utility
socklen_t kj_sockaddr_length(const kj_sockaddr *sockaddr) {
    socklen_t length = 0;
    if (sockaddr) {
        if (sockaddr->family == AF_INET) {
            length = sizeof(sockaddr->addr.ipv4);
        } else {
            length = sizeof(sockaddr->addr.ipv6);
        }
    }
    return length;
}
int kj_sockaddr_init(kj_sockaddr *sockaddr, int af, const char *ip, uint16_t port) {
    int success = 0;
    if (sockaddr && ip) {
        sockaddr->family = af;
        if (af == AF_INET) {
            sockaddr->addr.ipv4.sin_family = AF_INET;
            sockaddr->addr.ipv4.sin_port = htons(port);
            success = inet_pton(AF_INET, ip, &sockaddr->addr.ipv4.sin_addr.s_addr) > 0;
        } else {
            sockaddr->addr.ipv6.sin6_family = AF_INET6;
            sockaddr->addr.ipv6.sin6_port = htons(port);
            success = inet_pton(AF_INET6, ip, &sockaddr->addr.ipv6.sin6_addr) > 0;
        }
    }
    return success;
}
void kj_sockaddr_copy(kj_sockaddr *sockaddr, const void *addr, int af) {
    if (sockaddr && addr) {
        if (af == AF_INET) {
            sockaddr->family = AF_INET;
            memcpy(&sockaddr->addr.ipv4, addr, kj_sockaddr_length(sockaddr));
        } else {
            sockaddr->family = AF_INET6;
            memcpy(&sockaddr->addr.ipv6, addr, kj_sockaddr_length(sockaddr));
        }
    }
}
void kj_sockaddr_set_port(kj_sockaddr *sockaddr, uint16_t port) {
    if (sockaddr) {
        if (sockaddr->family == AF_INET) {
            sockaddr->addr.ipv4.sin_port = htons(port);
        } else {
            sockaddr->addr.ipv6.sin6_port = htons(port);
        }
    }
}
int kj_sockaddr_is_only_addr_equal(const kj_sockaddr *addr1, const kj_sockaddr *addr2) {
    int equal = 0;
    if (addr1 && addr2) {
        if (addr1->family == addr2->family) {
            if (addr1->family == AF_INET) {
                if (addr1->addr.ipv4.sin_addr.s_addr == addr2->addr.ipv4.sin_addr.s_addr) {
                    equal = 1;
                }
            } else {
                equal = 1;
                int count = sizeof(addr1->addr.ipv6.sin6_addr);
                uint8_t *first = (uint8_t *)&addr1->addr.ipv6.sin6_addr, *second = (uint8_t *)&addr2->addr.ipv6.sin6_addr;
                for (int i = 0; i < count; i++) {
                    if (first[i] != second[i]) {
                        equal = 0;
                        break;
                    }
                }
            }
        }
    }
    return equal;
}
int kj_sockaddr_is_equal(const kj_sockaddr *addr1, const kj_sockaddr *addr2) {
    int equal = 0;
    if (kj_sockaddr_is_only_addr_equal(addr1, addr2)) {
        if (addr1->family == AF_INET) {
            equal = addr1->addr.ipv4.sin_port == addr2->addr.ipv4.sin_port;
        } else {
            equal = addr1->addr.ipv6.sin6_port == addr2->addr.ipv6.sin6_port;
        }
    }
    return equal;
}
