//
//  kj_util.h
//  P2PLib
//
//  Created by twenty on 2023/5/25.
//

#ifndef kj_util_h
#define kj_util_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#include "kj_rm_types.h"
#include "kj_data.h"

// 添加环链类型
#define KJ_NODE_TYPE(type)\
type *prev;\
type *next

// 初始化环链
#define KJ_NODE_INIT(node)\
(node).prev = &(node);\
(node).next = &(node)

// 添加节点到指定节点后
#define KJ_NODE_ADD_BEHIND(node, node_add)\
(node_add)->prev = node;\
(node_add)->next = (node)->next;\
((node)->next)->prev = node_add;\
(node)->next = node_add

// 从环链移除节点并释放内存
#define KJ_NODE_REMOVE_AND_FREE(node)\
((node)->prev)->next = (node)->next;\
((node)->next)->prev = (node)->prev;\
free(node);node = NULL

// 从环链移除节点
#define KJ_NODE_REMOVE(node)\
((node)->prev)->next = (node)->next;\
((node)->next)->prev = (node)->prev;\
(node)->prev = NULL;\
(node)->next = NULL

// 环链存在节点
#define KJ_NODE_HAS_NODE(node) ((node).next != &(node))

// 两个节点不为同一个
#define KJ_NODE_NOT_EQUAL(node1, node2) ((node1) != (node2))

#pragma mark - 服务信息结构体内容复制和回收&内容判断
void kj_util_copy_rome_server_info(kj_rome_server *dst_server, const kj_rome_server *src_server);
void kj_util_free_rome_server_info(kj_rome_server *server);

/// 判断是否存在IPv4的stun或turn服务IP，用于ICE建连，只要有其一即可
int kj_util_rome_server_has_ipv4_server(const kj_rome_server *server);

/// 判断是否存在IPv6的stun或turn服务IP，用于ICE建连，只要有其一即可
int kj_util_rome_server_has_ipv6_server(const kj_rome_server *server);

/// 判断是否存在IPv6的stun或turn服务IP，用于ICE建连，只要有其一即可
/// 且利用IPv6的stun或turn服务IP判断本端是否具有IPv6网卡地址，并更新到 _kj_rm_cfg.ipv_support
int kj_util_rome_server_has_ipv6_server_and_local_support(const kj_rome_server *server);

/// 判断是否存在IPv4的stun服务，用于rome ptp获取NAT端口特性
int kj_util_rome_server_has_ipv4_stun(const kj_rome_server *server);

#pragma mark - NAT端口变化范围
/// 返回值取值范围：
/// 100 两端口相等
/// 其他则大于前一个值，但小于等于该值
/// 250,500,1000,2000,4000,8000,10000,16000,20000,25000,30000,35000,40000,45000,50000,55000,60000,65000,65535
int kj_util_get_nat_port_range(uint16_t port1, uint16_t port2);

#pragma mark - 时间函数
/// 获取当前时间
kj_time kj_time_get_current(void);

/// 两个时间点的毫秒间隔
/// @param begin 开始时间
/// @param end 结束时间
size_t kj_time_interval_between(kj_time begin, kj_time end);

/// 两个时间点的微秒间隔
/// @param begin 开始时间
/// @param end 结束时间
size_t kj_time_usecs_between(kj_time begin, kj_time end);

/// 两个时间的比较，返回结果为-1:time1 < time2 、0:time1 = time2 、1:time1 > time2
int kj_time_compare(kj_time time1, kj_time time2);

kj_time kj_time_add_usecs(kj_time time, useconds_t usecs);

uint32_t kj_time_get_current_micro_secs_of_today(void);

#pragma mark - 私有协议数据函数
int kj_util_is_rm_data(const void *data, size_t length, kj_data_head *data_head);
int kj_util_is_rm_punch_data(const void *data, size_t length, kj_data_head *data_head);
int kj_util_is_rm_kalive_data(const void *data, size_t length, kj_data_head *data_head);
kj_data_head *kj_util_create_rm_data(const void *data, size_t length);
kj_data_head *kj_util_kalive_ask_data_with_seq(uint8_t seq, const void *data, size_t length);
kj_data_head *kj_util_kalive_answer_data_with_seq(uint8_t seq, const void *data, size_t length);

#endif /* kj_util_h */
