//
//  kj_rm_types.c
//  P2PLib
//
//  Created by twenty on 2023/5/22.
//

#include "kj_rm_types.h"

struct kj_rm_config _kj_rm_cfg = {
    .version = 1,
    .ptp_ports_count = 5000,
    .ptp_per_count = 10,
    .ptp_interval_ms = 20.f,
    .ptp_punch_interval_ms = 120000,
    .nat3_punch_interval_us = 300000,
    .ptp_punch_timeout_ms = 30000,
    .waiting_sdp_timeout_ms = 10000,
    .ipv_support = kj_ipv4_support,
    .road_support = kj_road_ice | kj_road_ptp,
//    .road_support = kj_road_ptp,
//    .road_support = kj_road_ice,
};
