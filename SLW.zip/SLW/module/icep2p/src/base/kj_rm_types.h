//
//  kj_rmtypes.h
//  P2PLib
//
//  Created by twenty on 2023/5/22.
//

#ifndef kj_rm_types_h
#define kj_rm_types_h

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/time.h>

#ifdef __cplusplus
#  define RM_CPP_BEGIN  extern "C" {
#  define RM_CPP_END    }
#else
#  define RM_CPP_BEGIN
#  define RM_CPP_END
#endif

// 兼容Android、嵌入式、iOS和PC的类型差异
#if defined(__ANDROID__)
// Android
#define kj_random(range) arc4random_uniform(range)
#elif defined(__OHOS__)
#define __NEED_useconds_t
#include <bits/alltypes.h>
#define kj_random(range) (rand() % (range))
#define pthread_setname_np(pthread, name)
#elif defined(linux) || defined(__linux) || defined(__linux__)
// Linux
#define kj_random(range) (rand() % (range))
#define useconds_t __useconds_t
#define pthread_setname_np(pthread, name)
#else
// Apple和其他
#define kj_random(range) arc4random_uniform(range)
#if defined(__APPLE__)
#define pthread_setname_np(pthread, name) pthread_setname_np(name)
#endif
#endif

// NAT穿透数据包类型和方法字
#define KJ_RM_DATA_TYPE_PUNCH           0x23 // 穿透包类型
#define KJ_RM_DATA_METHOD_PUNCH_ASK     0x38 // 穿透请求包
#define KJ_RM_DATA_METHOD_PUNCH_ANSWER  0x39 // 穿透回复包

// 客户端与设备P2P心跳保活数据包类型和方法字
#define KJ_RM_DATA_TYPE_KALIVE_ASK      0x00 // 设备与媒体转发的心跳请求类型
#define KJ_RM_DATA_METHOD_KALIVE_ASK    0x00 // 心跳请求方法
#define KJ_RM_DATA_TYPE_KALIVE_ANSWER   0xff // 设备与媒体转发的心跳回复类型
#define KJ_RM_DATA_METHOD_KALIVE_ANSWER 0xff // 心跳回复方法
// 心跳包的扩展数据类型
#define KJ_RM_KALIVE_DATA_TYPE_CHANNEL      0x01 // 心跳包后拼接媒体流channel号数据类型
#define KJ_RM_KALIVE_DATA_TYPE_SELECT_CNT   0x02 // 心跳包后拼接选择连接通道类型

// 断开连接信令数据类型和方法字
#define KJ_RM_DATA_TYPE_DISCONNECT      0x23
#define KJ_RM_DATA_METHOD_DISCONNECT    0x28

// 协议所使用的时间值类型
typedef struct timeval kj_time;

// 连接状态码
typedef enum {
    // 共用状态码，范围：0～99
    kj_code_success                 = 0, // 成功
    kj_code_bypass_err              = 1, // 旁路信令不可用
    kj_code_bypass_send_sdp_err     = 2, // 旁路信令发送sdp失败
    kj_code_unsupport_road_type     = 3, // 对端不支持的连接类型
    kj_code_no_stun_turn_server     = 4, // 没有可用的stun和turn服务
    
    // ice错误码，范围：100～199
    kj_code_ice_server_err          = 100, // stun或turn服务不可用导致ice创建失败
    kj_code_ice_init_err            = 101, // ice收集候选地址失败
    kj_code_ice_init_timeout        = 102, // ice收集候选地址回调超时
    kj_code_ice_init_no_callback    = 103, // ice收集候选地址超时无结果返回
    kj_code_ice_init_ses_err        = 104, // 成功收集候选地址后初始化ice session失败
    kj_code_ice_endp_sdp_err        = 105, // 对端SDP信息无可用地址
    kj_code_ice_start_nego_fail     = 106, // 开始协商接口调用失败
    kj_code_ice_nego_cb_fail        = 107, // 协商建连回调失败
    kj_code_ice_nego_timeout        = 108, // 协商建连超时失败
    kj_code_ice_nego_no_endp_sdp    = 109, // 对端超时无sdp信息发来进行协商建连
    kj_code_ice_kalive_timeout      = 110, // 心跳超时中断
    kj_code_ice_discnt_by_endpoint  = 111, // 对端主动关闭
    
    // ptp错误码，范围：200～299
    kj_code_ptp_server_err          = 200, // stun服务不可用
    kj_code_ptp_send_stun_req_fail  = 201, // 发送stun bind request消息失败
    kj_code_ptp_srflx_err           = 202, // stun服务无映射地址返回
    kj_code_ptp_stun_timeout        = 203, // stun服务响应请求超时
    kj_code_ptp_no_change_addr_attr = 204, // stun服务响应的bind resp没有另一个stun服务
    kj_code_ptp_change_addr_equal   = 205, // stun服务响应的bind resp里的stun服务相同
    kj_code_ptp_missed_endp_addrs   = 206, // 超时无对端的地址信息进行穿透
    kj_code_ptp_punch_failed        = 207, // NAT穿透超时
    kj_code_ptp_send_punch_data_err = 208, // 发送穿透包超过20次失败
    kj_code_ptp_sock_disconnected   = 209, // udp socket接收数据异常中断
    kj_code_ptp_kalive_timeout      = 210, // 心跳超时中断
    kj_code_ptp_discnt_by_endpoint  = 211, // 对端主动关闭
    kj_code_ptp_punch_disable       = 212, // 服务配置关闭打洞
    kj_code_ptp_punch_frequent      = 213, // 距离上次打洞时间间隔不够则终止打洞，避免上次打洞在外网NAT开启的端口未被回收而打通后本次socket收不到数据
} kj_code;

/// 连接类型，用于指定rome支持的连接类型
typedef enum {
    kj_road_none = 0,
    kj_road_ice = 0x01,
    kj_road_ptp = 0x02
} kj_road_type;

// 网络支持的IPv版本
typedef enum {
    kj_ipv_unknow = 0,      // 未知
    kj_ipv4_support = 0x01, // 支持IPv4
    kj_ipv6_support = 0x02  // 支持IPv6
} kj_ipv;

/// 全局配置变量
extern struct kj_rm_config _kj_rm_cfg;
struct kj_rm_config {
    const int version;          // 版本号，取整型值，当前为1
    const int ptp_ports_count;  // 打洞发送的穿透包总数，默认5000个
    int ptp_per_count;          // 每轮穿透发送的穿透包数，默认10个
    float ptp_interval_ms;      // 每轮穿透发送的间隔，默认20ms
    kj_time ptp_punch_time;     // 记录最后一次打洞的时间点，判断每次打洞时是否已超过间隔时间而被允许
    const size_t ptp_punch_interval_ms;         // 两次打洞的时间间隔，默认两分钟即120000
    const useconds_t nat3_punch_interval_us;    // 对端是NAT3时每个穿透包的发送间隔，默认300000微秒
    const int ptp_punch_timeout_ms;   // 穿透超时时间，默认30000ms
    const int waiting_sdp_timeout_ms; // 发送本端地址信息给对端后，等待对端发来的超时时间，默认10000ms
    const kj_road_type road_support;  // rome ptp支持的连接方式，默认kj_road_ice | kj_road_ptp
    int local_nat;      // 本端NAT端口特性（端口变化范围），每次建连获取和更新，默认0
    kj_ipv ipv_support; // 本端IP网络环境，默认支持IPv4，0:未知；0x01:IPv4；0x02:IPv6
};

/// 连接状态
typedef enum {
    kj_cnt_state_disconnected,  // 初始或中断
    kj_cnt_state_connect_fail,  // 连接失败
    kj_cnt_state_connecting,    // 建立连接中
    kj_cnt_state_connected      // 连接成功
} kj_cnt_state;

/// 发送状态
typedef enum {
    kj_send_status_invalid, // 参数错误或发送通道不可用
    kj_send_status_failed,  // 发送失败
    kj_send_status_pending, // 缓存待发送
    kj_send_status_success  // 发送成功
} kj_send_status;

/// 建连角色
typedef enum {
    kj_rm_role_server = 0,  // 服务端，被动建连者
    kj_rm_role_client = 1   // 客户端，主动建连者
} kj_rm_role;

/// 连接类型
typedef enum {
    kj_cnt_type_none    = 0, // 无连接
    kj_cnt_type_turn    = 0x01, // turn转发
    kj_cnt_type_lan     = 0x02, // 局域网的P2P
    kj_cnt_type_ice_ptp = 0x04, // ICE的P2P
    kj_cnt_type_rm_ptp  = 0x08, // Rome的P2P
    kj_cnt_type_tcp     = 0x10  // TCP连接：媒体转发、信令服务
} kj_cnt_type;

/// 建连所需的stun、turn服务信息，支持IPv4、IPv6同时设置
typedef struct kj_rome_server {
    char *stun_host;        // IPv4 stun服务地址
    char *stun_port;        // IPv4 stun端口
    char *turn_host;        // IPv4 turn服务地址
    char *turn_port;        // IPv4 turn端口
    char *turn_username;    // turn服务的用户名
    char *turn_userpass;    // turn服务的密码
    int ipv6_support;       // 设备是否支持IPv6
    char *ipv6_stun_host;   // IPv6 stun服务地址
    char *ipv6_stun_port;   // IPv6 stun端口
    char *ipv6_turn_host;   // IPv6 turn服务地址
    char *ipv6_turn_port;   // IPv6 turn服务地址
} kj_rome_server;

/// ptp连接类型的打洞算法参数
typedef struct kj_ptp_alg {
    uint16_t type;          // 打洞算法类型，0:关闭；大于0有效，按位数拆分为本端和对端所使用的算法
    uint16_t ports_count;   // 打洞的端口总数
    uint16_t per_count;     // 每轮发送穿透包个数
    float per_interval_ms;  // 每轮穿透休眠时间，毫秒
} kj_ptp_alg;

/// 本端和对端的相关信息
typedef struct kj_rome_info {
    struct local {
        int version;                // 版本
        kj_rm_role role;            // 角色
        kj_road_type road_support;  // 支持的连接类型
        int nat;                    // NAT端口范围
        kj_ipv ipv_support;         // 支持的IPv版本
        kj_ptp_alg algorithm;       // 打洞算法参数
    } local;
    struct remote {
        int version;                // 版本
        kj_rm_role role;            // 角色
        kj_road_type road_support;  // 支持的连接类型
        int nat;                    // NAT端口范围
        kj_ipv ipv_support;         // 支持的IPv版本
        kj_ptp_alg algorithm;       // 打洞算法参数
    } remote;
} kj_rome_info;

#endif /* kj_rm_types_h */
