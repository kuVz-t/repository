//
//  kj_thread.c
//  kj_sdk
//
//  Created by twenty on 2020/12/22.
//

#include "kj_thread.h"
#include "kj_rm_types.h"

struct kj_thread {
    int working;
    int executing;
    char *name;
    void *user_data;
    pthread_t pthread;
    pthread_cond_t task_cond;
    pthread_mutex_t task_mutex;
    kj_thread_will_destroy_callback *destroy_cb;
    kj_thread_task *tasks;
};

void *kj_thread_invoke_function(void *arg) {
    kj_thread *thread = arg;
    if (thread->name) {
        pthread_setname_np(thread->pthread, thread->name);
    }
    while (1) {
        // 加锁，获取任务队列所有的任务执行
        kj_thread_task *task = NULL;
        if (kj_thread_try_lock(&thread->task_mutex)) {
            if (thread->working) {
                if (thread->tasks) {
                    task = thread->tasks;
                    thread->tasks = task->inner.next;
                    if (task->inner.execute_cb) {
                        thread->executing = 1;
                        kj_thread_unlock(&thread->task_mutex);
                        
                        task->inner.execute_cb(thread, task->function, task->args);
                        
                        kj_thread_lock(&thread->task_mutex);
                        thread->executing = 0;
                        if (!thread->working) {
                            pthread_cond_signal(&thread->task_cond);
                        }
                    }
                    // 释放任务资源
                    free(task);
                } else {
                    // 等待添加任务或销毁
                    pthread_cond_wait(&thread->task_cond, &thread->task_mutex);
                }
                kj_thread_unlock(&thread->task_mutex);
            } else {
                kj_thread_unlock(&thread->task_mutex);
                break;
            }
        }
    }
    // 未执行的任务中找出阻塞任务发起线程的任务
    kj_thread_task *task = thread->tasks;
    while (task) {
        thread->tasks = task->inner.next;
        // 回调任务的取消，上层对参数进行可能的处理
        if (task->inner.cancel_cb) {
            task->inner.cancel_cb(thread, task->function, task->args);
        }
        // 释放任务资源
        free(task);
        task = thread->tasks;
    }
    // 回调将要销毁
    if (thread->destroy_cb) {
        thread->destroy_cb(thread, thread->user_data);
    }
    /* 由于Android出现销毁函数处于cond wait的情况下，以上代码执行仍然比销毁中的cond wait要快
     导致以下mutex先被销毁而导致使用已销毁的mutex而崩溃
     鉴于该线程执行到此，已全部处理上层逻辑，在此休眠并不会对上层造成阻塞，因此进行10ms休眠
     */
    usleep(10000);
    // 销毁线程
    pthread_cond_destroy(&thread->task_cond);
    pthread_mutex_destroy(&thread->task_mutex);
    free(thread->name);
    free(thread);
    return NULL;
}

kj_thread *kj_thread_create(const char *name, void *user_data, kj_thread_will_destroy_callback *destroy_cb) {
    kj_thread *thread = calloc(1, sizeof(kj_thread));
    thread->working = 1;
    thread->user_data = user_data;
    thread->destroy_cb = destroy_cb;
    if (name) {
        thread->name = strdup(name);
    }
    pthread_cond_init(&thread->task_cond, NULL);
    kj_thread_init_mutex(&thread->task_mutex, 0);
    int result = pthread_create(&thread->pthread, NULL, &kj_thread_invoke_function, thread);
    pthread_detach(thread->pthread);
    if (result != 0) {
        pthread_cond_destroy(&thread->task_cond);
        pthread_mutex_destroy(&thread->task_mutex);
        free(thread->name);
        free(thread);
        thread = NULL;
    }
    return thread;
}
kj_thread_task kj_thread_task_create(kj_thread_task_execute_callback *execute_cb, kj_thread_task_cancel_callback *cancel_cb) {
    kj_thread_task task = {
        .inner = {
            .execute_cb = execute_cb,
            .cancel_cb = cancel_cb
        }
    };
    return task;
}
int kj_thread_add_task(kj_thread *thread, kj_thread_task task) {
    int added = 0;
    if (thread && thread->working) {
        kj_thread_lock(&thread->task_mutex);
        // 获得锁后再判断是否未退出线程而添加任务
        if (thread->working) {
            // 重置任务私有变量，防止外部设置错误参数
            task.inner.next = NULL;
            // 深复制任务和任务所需参数，函数不会被回收因此不需复制
            size_t length = sizeof(kj_thread_task);
            kj_thread_task *task_cpy = NULL;
            if (task.args && task.args_length > 0) {
                task_cpy = malloc(length + task.args_length);
                memcpy(task_cpy, &task, length);
                task_cpy->args = task_cpy + 1;
                memcpy(task_cpy->args, task.args, task.args_length);
            } else {
                task_cpy = malloc(length);
                memcpy(task_cpy, &task, length);
            }
            // 任务插入队列
            kj_thread_task *prev = thread->tasks;
            if (prev) {
                kj_thread_task *next = prev->inner.next;
                while (prev) {
                    if (task_cpy->priority > prev->priority) {
                        thread->tasks = task_cpy;
                        task_cpy->inner.next = prev;
                        break;
                    } else {
                        if (next) {
                            if (task_cpy->priority <= prev->priority && task_cpy->priority > next->priority) {
                                task_cpy->inner.next = next;
                                prev->inner.next = task_cpy;
                                break;;
                            } else {
                                prev = next;
                                next = next->inner.next;
                            }
                        } else {
                            prev->inner.next = task_cpy;
                            break;
                        }
                    }
                }
            } else {
                thread->tasks = task_cpy;
            }
            added = 1;
            pthread_cond_signal(&thread->task_cond);
        }
        kj_thread_unlock(&thread->task_mutex);
    }
    return added;
}
void kj_thread_destroy(kj_thread **thread) {
    if (*thread) {
        kj_thread *thread_in = *thread;
        *thread = NULL;
        // 标记线程退出
        kj_thread_lock(&thread_in->task_mutex);
        thread_in->working = 0;
        pthread_cond_signal(&thread_in->task_cond);
        // 非当前线程执行的销毁，且当前正在执行任务则阻塞等待退出，避免回调上层导致上层野指针
        if (thread_in->executing && !kj_thread_is_equal_current(thread_in)) {
            pthread_cond_wait(&thread_in->task_cond, &thread_in->task_mutex);
        }
        kj_thread_unlock(&thread_in->task_mutex);
    }
}
int kj_thread_is_working(const kj_thread *thread) {
    return thread ? thread->working : 0;
}
int kj_thread_is_equal_current(const kj_thread *thread) {
    int isEqual = 0;
    if (thread && (pthread_equal(pthread_self(), thread->pthread))) {
        isEqual = 1;
    }
    return isEqual;
}

#pragma mark - 锁操作
int kj_thread_init_mutex(pthread_mutex_t *mutex, int recursive) {
    int result = 0;
    if (mutex) {
        if (recursive) {
            pthread_mutexattr_t attr;
            pthread_mutexattr_init(&attr);
            pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
            result = pthread_mutex_init(mutex, &attr);
            pthread_mutexattr_destroy(&attr);
        } else {
            result = pthread_mutex_init(mutex, NULL);
        }
    }
    return result;
}
int kj_thread_lock(pthread_mutex_t *mutex) {
    return pthread_mutex_lock(mutex) == 0;
}
int kj_thread_try_lock(pthread_mutex_t *mutex) {
    return pthread_mutex_trylock(mutex) == 0;
}
void kj_thread_unlock(pthread_mutex_t *mutex) {
    pthread_mutex_unlock(mutex);
}

#pragma mark - 快捷线程执行方法
void kj_thread_run_func_callback(const kj_thread *thread, const void *func, void *args) {
    void (*function)(void *arg) = func;
    function(args);
}
int kj_thread_run_func(kj_thread *thread, void *arg, void (*func)(void *arg)) {
    int run = 0;
    if (thread && func) {
        kj_thread_task task = kj_thread_task_create(kj_thread_run_func_callback, NULL);
        task.function = func;
        task.args = arg;
        run = kj_thread_add_task(thread, task);
    }
    return run;
}
struct kj_thread_args {
    pthread_t thread;
    void *user_data;
    void (*callback)(void *user_data, pthread_t *thread);
};
void *kj_thread_execute_callback(void *arg) {
    struct kj_thread_args *args = arg;
    if (args->callback) {
        args->callback(args->user_data, &args->thread);
    }
    free(args);
    return NULL;
}
void kj_thread_new_thread(void *user_data, void (*callback)(void *user_data, pthread_t *thread)) {
    struct kj_thread_args *args = malloc(sizeof(struct kj_thread_args));
    args->user_data = user_data;
    args->callback = callback;
    pthread_create(&args->thread, NULL, &kj_thread_execute_callback, args);
    pthread_detach(args->thread);
}
