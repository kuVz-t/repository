//
//  kj_util.c
//  P2PLib
//
//  Created by twenty on 2023/5/25.
//

#include <endian.h>
#include <strings.h>
#include "kj_util.h"
#include "rm_sock.h"

#pragma mark - 服务信息结构体内容复制和回收、内容判断
void kj_util_copy_rome_server_info(kj_rome_server *dst_server, const kj_rome_server *src_server) {
    if (dst_server && src_server) {
        dst_server->stun_host = src_server->stun_host ? strdup(src_server->stun_host) : NULL;
        dst_server->stun_port = src_server->stun_port ? strdup(src_server->stun_port) : NULL;
        dst_server->turn_host = src_server->turn_host ? strdup(src_server->turn_host) : NULL;
        dst_server->turn_port = src_server->turn_port ? strdup(src_server->turn_port) : NULL;
        dst_server->ipv6_stun_host = src_server->ipv6_stun_host ? strdup(src_server->ipv6_stun_host) : NULL;
        dst_server->ipv6_stun_port = src_server->ipv6_stun_port ? strdup(src_server->ipv6_stun_port) : NULL;
        dst_server->ipv6_turn_host = src_server->ipv6_turn_host ? strdup(src_server->ipv6_turn_host) : NULL;
        dst_server->ipv6_turn_port = src_server->ipv6_turn_port ? strdup(src_server->ipv6_turn_port) : NULL;
        dst_server->turn_username = src_server->turn_username ? strdup(src_server->turn_username) : NULL;
        dst_server->turn_userpass = src_server->turn_userpass ? strdup(src_server->turn_userpass) : NULL;
        dst_server->ipv6_support = src_server->ipv6_support;
    }
}
void kj_util_free_rome_server_info(kj_rome_server *server) {
    if (server) {
        free(server->stun_host);
        free(server->stun_port);
        free(server->turn_host);
        free(server->turn_port);
        free(server->ipv6_stun_host);
        free(server->ipv6_stun_port);
        free(server->ipv6_turn_host);
        free(server->ipv6_turn_port);
        free(server->turn_username);
        free(server->turn_userpass);
        bzero(server, sizeof(*server));
    }
}
int kj_util_rome_server_has_ipv4_server(const kj_rome_server *server) {
    int has = 0;
    if (server) {
        if (server->stun_host && strlen(server->stun_host) > 0 && server->stun_port && strlen(server->stun_port) > 0) {
            has = 1;
        } else if (server->turn_host && strlen(server->turn_host) > 0 && server->turn_port && strlen(server->turn_port) > 0) {
            has = 1;
        }
    }
    return has;
}
int kj_util_rome_server_has_ipv6_server(const kj_rome_server *server) {
    int has = 0;
    if (server) {
        if (server->ipv6_stun_host && strlen(server->ipv6_stun_host) > 0 && server->ipv6_stun_port && strlen(server->ipv6_stun_port) > 0) {
            has = 1;
        } else if (server->ipv6_turn_host && strlen(server->ipv6_turn_host) > 0 && server->ipv6_turn_port && strlen(server->ipv6_turn_port) > 0) {
            has = 1;
        }
    }
    return has;
}
int kj_util_rome_server_has_ipv6_server_and_local_support(const kj_rome_server *server) {
    int result = 0;
    if (kj_util_rome_server_has_ipv6_server(server)) {
        // 由IP获取socket地址
        struct addrinfo hint = {
            .ai_family = AF_UNSPEC,
            .ai_socktype = SOCK_STREAM,
            .ai_protocol = IPPROTO_TCP
        }, *dst_addr = NULL;
        if (server->ipv6_stun_host) {
            result = getaddrinfo(server->ipv6_stun_host, server->ipv6_stun_port, &hint, &dst_addr);
        } else {
            result = getaddrinfo(server->ipv6_turn_host, server->ipv6_turn_port, &hint, &dst_addr);
        }
        if (result == 0 && dst_addr && dst_addr->ai_family == AF_INET6) {
            // 获取socket地址成功则创建socket进行connect获取本机地址
            int sock = socket(dst_addr->ai_family, dst_addr->ai_socktype, dst_addr->ai_protocol);
            if (sock > 0) {
                unsigned long nonblock = 1;
                int cnt_errno = 0;
                ioctl(sock, FIONBIO, &nonblock);
                result = connect(sock, dst_addr->ai_addr, dst_addr->ai_addrlen);
                cnt_errno = errno;
                // connect之后即可获取本机IPv6地址，然后关闭socket
                kj_sockaddr local_addr = {.family = dst_addr->ai_family};
                socklen_t length = kj_sockaddr_length(&local_addr);
                result = getsockname(sock, (struct sockaddr *)&local_addr.addr, &length);
                shutdown(sock, SHUT_RDWR);
                close(sock);
                // 将socket地址转换为IP地址
                char ip[50] = {};
                if (dst_addr->ai_family == AF_INET6) {
                    inet_ntop(dst_addr->ai_family, (void *)&local_addr.addr.ipv6.sin6_addr, ip, sizeof(ip));
                } else {
                    inet_ntop(dst_addr->ai_family, (void *)&local_addr.addr.ipv4.sin_addr, ip, sizeof(ip));
                }
                // 同时建连状态码和IP地址长度判定本机是否有IPv6地址，不支持的情况通过异或还原不支持IPv6的值
                _kj_rm_cfg.ipv_support |= kj_ipv6_support;
                if (cnt_errno != EINPROGRESS && strlen(ip) < 3) {
                    result = 0;
                    _kj_rm_cfg.ipv_support ^= kj_ipv6_support;
                } else {
                    result = 1;
                }
            } else {
                result = 0;
            }
        } else {
            result = 0;
        }
        freeaddrinfo(dst_addr);
    }
    return result;
}
int kj_util_rome_server_has_ipv4_stun(const kj_rome_server *server) {
    int has = 0;
    if (server) {
        if (server->stun_host && strlen(server->stun_host) > 0 && server->stun_port && strlen(server->stun_port) > 0) {
            has = 1;
        }
    }
    return has;
}

#pragma mark - NAT端口变化范围
int kj_util_get_nat_port_range(uint16_t port1, uint16_t port2) {
    int range = 100;
    if (port1 > port2) {
        range = port1 - port2;
    } else if (port2 > port1) {
        range = port2 - port1;
    } else {
        return range;
    }
    if (range < 251) {
        range = 250;
    } else if (range < 501) {
        range = 500;
    } else if (range < 1001) {
        range = 1000;
    } else if (range < 2001) {
        range = 2000;
    } else if (range < 4001) {
        range = 4000;
    } else if (range < 8001) {
        range = 8000;
    } else if (range < 10001) {
        range = 10000;
    } else if (range < 16001) {
        range = 16000;
    } else if (range < 20001) {
        range = 20000;
    } else if (range < 25001) {
        range = 25000;
    } else if (range < 30001) {
        range = 30000;
    } else if (range < 35001) {
        range = 35000;
    } else if (range < 40001) {
        range = 40000;
    } else if (range < 45001) {
        range = 45000;
    } else if (range < 50001) {
        range = 50000;
    } else if (range < 55001) {
        range = 55000;
    } else if (range < 60001) {
        range = 60000;
    } else if (range < 65001) {
        range = 65000;
    } else {
        range = 65535;
    }
    return range;
}

#pragma mark - 时间函数
kj_time kj_time_get_current(void) {
    kj_time time = {0,0};
    gettimeofday(&time, NULL);
    return time;
}
size_t kj_time_interval_between(kj_time begin, kj_time end) {
    size_t interval = labs((end.tv_sec - begin.tv_sec) * 1000 + (end.tv_usec - begin.tv_usec) / 1000);
    return interval;
}
size_t kj_time_usecs_between(kj_time begin, kj_time end) {
    size_t interval = labs((end.tv_sec - begin.tv_sec) * 1000000 + (end.tv_usec - begin.tv_usec));
    return interval;
}
int kj_time_compare(kj_time time1, kj_time time2) {
    int result = 0;
    if (time1.tv_sec > time2.tv_sec) {
        result = 1;
    } else if (time1.tv_sec < time2.tv_sec){
        result = -1;
    } else {
        if (time1.tv_usec > time2.tv_usec) {
            result = 1;
        } else if (time1.tv_usec < time2.tv_usec) {
            result = -1;
        }
    }
    return result;
}
kj_time kj_time_add_usecs(kj_time time, useconds_t usecs) {
    usecs = time.tv_usec + usecs;
    time.tv_sec += (usecs / 1000000);
    time.tv_usec = usecs % 1000000;
    return time;
}
uint32_t kj_time_get_current_micro_secs_of_today(void) {
    struct timeval unix_time = {0,0};
    gettimeofday(&unix_time, NULL);
    time_t secs = unix_time.tv_sec;
    struct tm *date = localtime(&secs);
    uint32_t ms = (date->tm_hour * 3600 + date->tm_min * 60 + date->tm_sec) * 1000;
    ms += (unix_time.tv_usec / 1000);
    return ms;
}

#pragma mark - 私有协议数据函数
int kj_util_is_rm_data(const void *data, size_t length, kj_data_head *data_head) {
    int result = 0;
    if (data && length >= kj_data_head_length) {
        const kj_data_head *temp = data;
        if (temp->head[0] == '#' && temp->head[1] == '$') {
            result = 1;
            memcpy(data_head, temp, kj_data_head_length);
            data_head->length = ntohs(data_head->length);
        }
    }
    return result;
}
int kj_util_is_rm_punch_data(const void *data, size_t length, kj_data_head *data_head) {
    int result = 0;
    if (kj_util_is_rm_data(data, length, data_head)) {
        result = data_head->type == KJ_RM_DATA_TYPE_PUNCH && (data_head->method == KJ_RM_DATA_METHOD_PUNCH_ASK || data_head->method == KJ_RM_DATA_METHOD_PUNCH_ANSWER);
    }
    return result;
}
int kj_util_is_rm_kalive_data(const void *data, size_t length, kj_data_head *data_head) {
    int result = 0;
    if (kj_util_is_rm_data(data, length, data_head)) {
        if (data_head->type == KJ_RM_DATA_TYPE_KALIVE_ASK && data_head->method == KJ_RM_DATA_METHOD_KALIVE_ASK) {
            result = 1;
        } else if (data_head->type == KJ_RM_DATA_TYPE_KALIVE_ANSWER && data_head->method == KJ_RM_DATA_METHOD_KALIVE_ANSWER) {
            result = 1;
        }
    }
    return result;
}
kj_data_head *kj_util_create_rm_data(const void *data, size_t length) {
    length = (data && length) ? length : 0;
    kj_data_head *rm_data = calloc(1, kj_data_head_length + length);
    rm_data->head[0] = '#';
    rm_data->head[1] = '$';
    if (length) {
        rm_data->length = length;
        memcpy(rm_data + 1, data, length);
    }
    return rm_data;
}
kj_data_head *kj_util_kalive_ask_data_with_seq(uint8_t seq, const void *data, size_t length) {
    kj_data_head *ask_data = kj_util_create_rm_data(data, length);
    ask_data->type = KJ_RM_DATA_TYPE_KALIVE_ASK;
    ask_data->method = KJ_RM_DATA_METHOD_KALIVE_ASK;
    ask_data->reserved = seq;
    return ask_data;
}
kj_data_head *kj_util_kalive_answer_data_with_seq(uint8_t seq, const void *data, size_t length) {
    kj_data_head *answer_data = kj_util_create_rm_data(data, length);
    answer_data->type = KJ_RM_DATA_TYPE_KALIVE_ANSWER;
    answer_data->method = KJ_RM_DATA_METHOD_KALIVE_ANSWER;
    answer_data->reserved = seq;
    return answer_data;
}
