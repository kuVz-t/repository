//
//  rm_timer.c
//  ios_demo
//
//  Created by twenty on 2022/12/16.
//

#include "rm_timer.h"

#define KJ_TIMER_MAX_SLEEP_INTERVAL 100000

typedef struct kj_timer_task_holder {
    kj_timer_task task;
    kj_time excuted_time;
    size_t usecs_interval;
    int canceled;
    int executing;
    struct kj_timer_task_holder *next;
} kj_timer_task_holder;

struct rm_timer {
    kj_timer_task_holder *holders;
    kj_timer_task_holder *holders_excuted;
    int should_sleep;
    int working;
    kj_time next_excute_time;
    pthread_cond_t task_cond;
    pthread_mutex_t task_mutex;
    pthread_t *thread;
};

#pragma mark - engine thread task execute callback
void kj_timer_thread_callback(void *arg, pthread_t *thread) {
    kj_timer *timer = arg;
    timer->thread = thread;
    while (timer->working) {
        if (kj_thread_try_lock(&timer->task_mutex)) {
            kj_timer_task_holder *holder = timer->holders;
            if (holder) {
                timer->holders = holder->next;
                if (holder->canceled) {
                    kj_thread_unlock(&timer->task_mutex);
                    free(holder);
                } else {
                    // 转移即将执行的任务到已执行任务链表
                    holder->next = timer->holders_excuted;
                    timer->holders_excuted = holder;
                    // 计算定时任务是否到时执行
                    kj_time current_time = kj_time_get_current();
                    size_t next_interval = holder->usecs_interval;
                    size_t passed_usecs = kj_time_usecs_between(holder->excuted_time, current_time);
                    if (passed_usecs >= holder->usecs_interval) {
                        holder->excuted_time = current_time;
                        if (holder->task.callback) {
                            holder->executing = 1;
                            kj_thread_unlock(&timer->task_mutex);
                            // 锁外执行定时任务
                            holder->task.callback(timer, &holder->task);
                            // 加锁判断当前任务是否在执行中进行了取消而处于阻塞等待任务执行完成，如有则释放阻塞
                            kj_thread_lock(&timer->task_mutex);
                            holder->executing = 0;
                            if (holder->canceled) {
                                pthread_cond_signal(&timer->task_cond);
                            }
                            kj_thread_unlock(&timer->task_mutex);

                            // 更新上层可能修改了定时间隔
                            holder->usecs_interval = holder->task.interval * 1000;
                            next_interval = holder->usecs_interval;
                        } else {
                            kj_thread_unlock(&timer->task_mutex);
                        }
                        if (!holder->task.repeat) {
                            holder->canceled = 1;
                        }
                    } else {
                        kj_thread_unlock(&timer->task_mutex);
                        
                        next_interval = holder->usecs_interval - passed_usecs;
                    }
                    kj_time next_time = kj_time_add_usecs(current_time, (useconds_t)next_interval);
                    // 本次计算的下次执行时间比此前的要早，则更新下次执行的时间
                    if (kj_time_compare(next_time, timer->next_excute_time) == -1) {
                        timer->next_excute_time = next_time;
                    }
                }
            } else {
                timer->should_sleep = 1;
                timer->holders = timer->holders_excuted;
                timer->holders_excuted = NULL;
                kj_thread_unlock(&timer->task_mutex);
            }
        }
        if (timer->working && timer->should_sleep) {
            timer->should_sleep = 0;
            useconds_t sleep_time = (useconds_t)kj_time_usecs_between(kj_time_get_current(), timer->next_excute_time);
            // 限制最长休眠时间以能及时响应处于休眠中新加入的定时任务
            if (sleep_time > KJ_TIMER_MAX_SLEEP_INTERVAL) {
                sleep_time = KJ_TIMER_MAX_SLEEP_INTERVAL;
            }
            // usleep函数精度不高，如休眠100ms实际上在103ms左右
            usleep(sleep_time);
            timer->next_excute_time = kj_time_add_usecs(kj_time_get_current(), KJ_TIMER_MAX_SLEEP_INTERVAL);
        }
    }
    kj_timer_task_holder *holder = timer->holders;
    while (holder) {
        timer->holders = holder->next;
        free(holder);
        holder = timer->holders;
    }
    holder = timer->holders_excuted;
    while (holder) {
        timer->holders_excuted = holder->next;
        free(holder);
        holder = timer->holders_excuted;
    }
    pthread_cond_destroy(&timer->task_cond);
    pthread_mutex_destroy(&timer->task_mutex);
    free(timer);
}

#pragma mark - kj_timer
kj_timer *kj_timer_create(void) {
    kj_timer *timer = calloc(1, sizeof(kj_timer));
    pthread_cond_init(&timer->task_cond, NULL);
    kj_thread_init_mutex(&timer->task_mutex, 0);
    timer->working = 1;
    timer->next_excute_time = kj_time_add_usecs(kj_time_get_current(), KJ_TIMER_MAX_SLEEP_INTERVAL);
    // 创建定时器线程
    kj_thread_new_thread(timer, kj_timer_thread_callback);
    return timer;
}
void kj_timer_destroy(kj_timer **timer) {
    if (*timer) {
        kj_timer *temp = *timer;
        *timer = NULL;
        temp->working = 0;
    }
}
kj_timer *kj_timer_global(void) {
    static kj_timer *timer = NULL;
    if (timer == NULL) {
        timer = kj_timer_create();
    }
    return timer;
}
void kj_timer_init_task(kj_timer_task *task,
                        void *user_data,
                        size_t interval,
                        int repeat,
                        kj_timer_task_excuting_callback *callback) {
    if (task) {
        task->user_data = user_data;
        task->interval = interval;
        task->repeat = repeat;
        task->identity = (size_t)task;
        task->callback = callback;
    }
}
void kj_timer_schedule_task(kj_timer *timer, kj_timer_task task) {
    if (timer) {
        kj_thread_lock(&timer->task_mutex);
        kj_timer_task_holder *holder = calloc(1, sizeof(kj_timer_task_holder));
        holder->task = task;
        holder->excuted_time = kj_time_get_current();
        holder->usecs_interval = task.interval * 1000;
        holder->next = timer->holders;
        timer->holders = holder;
        kj_thread_unlock(&timer->task_mutex);
    }
}
void kj_timer_cancel_task(kj_timer *timer, kj_timer_task task) {
    if (timer) {
        kj_thread_lock(&timer->task_mutex);
        kj_timer_task_holder *holder = timer->holders;
        kj_timer_task_holder *holder_excuted = timer->holders_excuted;
        while (holder || holder_excuted) {
            if (holder) {
                if (holder->task.identity == task.identity) {
                    holder->canceled = 1;
                    break;
                } else {
                    holder = holder->next;
                }
            } else {
                if (holder_excuted->task.identity == task.identity) {
                    holder_excuted->canceled = 1;
                    if (holder_excuted->executing && !pthread_equal(pthread_self(), *timer->thread)) {
                        pthread_cond_wait(&timer->task_cond, &timer->task_mutex);
                    }
                    break;
                } else {
                    holder_excuted = holder_excuted->next;
                }
            }
        }
        kj_thread_unlock(&timer->task_mutex);
    }
}
void kj_timer_cancal_all_task(kj_timer *timer) {
    if (timer) {
        kj_thread_lock(&timer->task_mutex);
        kj_timer_task_holder *holder = timer->holders;
        kj_timer_task_holder *holder_excuted = timer->holders_excuted;
        while (holder || holder_excuted) {
            if (holder) {
                holder->canceled = 1;
                holder = holder->next;
            } else {
                holder_excuted->canceled = 1;
                if (holder_excuted->executing && !pthread_equal(pthread_self(), *timer->thread)) {
                    pthread_cond_wait(&timer->task_cond, &timer->task_mutex);
                }
                holder_excuted = holder_excuted->next;
            }
        }
        kj_thread_unlock(&timer->task_mutex);
    }
}
