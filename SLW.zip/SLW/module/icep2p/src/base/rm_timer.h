//
//  rm_timer.h
//  ios_demo
//
//  Created by twenty on 2022/12/16.
//

#ifndef kj_timer_h
#define kj_timer_h

#include "kj_util.h"
#include "kj_thread.h"

/// 定时任务、定时器及定时任务执行回调函数定义
typedef struct kj_timer_task kj_timer_task;
typedef struct rm_timer kj_timer;
typedef void kj_timer_task_excuting_callback(const kj_timer *timer, kj_timer_task *task);

/// 定时任务
struct kj_timer_task {
    kj_timer_task_excuting_callback *callback;
    void *user_data;
    size_t interval;
    int repeat;
    int task_id;
    size_t identity;
};

/// 定时器功能使用步骤及生命周期
/// 1、kj_timer_create()创建定时器
/// 2、kj_timer_init_task()初始化定时任务kj_timer_task
/// 3、kj_timer_schedule_tas()添加定时任务到定时器中
/// 4、kj_timer_cancel_task()取消定时任务
/// 5、kj_timer_destroy()销毁定时器

/// 创建一个定时器
kj_timer *kj_timer_create(void);

/// 销毁定时器，销毁后所有在该定时器上的定时任务则被取消
void kj_timer_destroy(kj_timer **timer);

/// 全局唯一定时器
kj_timer *kj_timer_global(void);

/// 初始化定时任务
/// @param task 定时任务指针，由上层持有
/// @param user_data 关联对象指针
/// @param interval 定时间隔，毫秒
/// @param repeat 是否重复执行
/// @param callback 执行回调函数指针
void kj_timer_init_task(kj_timer_task *task,
                        void *user_data,
                        size_t interval,
                        int repeat,
                        kj_timer_task_excuting_callback *callback);

/// 添加定时任务到定时器
void kj_timer_schedule_task(kj_timer *timer, kj_timer_task task);

/// 从定时器中取消定时任务
void kj_timer_cancel_task(kj_timer *timer, kj_timer_task task);

/// 取消定时器上的所有定时任务
void kj_timer_cancal_all_task(kj_timer *timer);

#endif /* kj_timer_h */
