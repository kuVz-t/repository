//
//  kj_aes.h
//  kj_sdk
//
//  Created by de on 2020/12/29.
//

#ifndef kj_aes_h
#define kj_aes_h

#include <stdio.h>
#include <stdint.h>
#include "kj_data_define.h"

KJ_CPP_BEGIN

typedef enum KJ4AES_MODE
{
    KJ4AES_NONE = 0,
    KJ4AES_128 = 0x31,
    KJ4AES_192 = 0x32,
    KJ4AES_256 = 0x33,
} KJ4AESMode;

typedef enum KJ4AES_PADDINGTYPE
{
    KJ4AES_NOPadding = 1,
    KJ4AES_Pkcs7Padding,
} KJ4AESPaddingType;

//用完需要free
uint8_t* kj4aes128_encrypt_cbc(const uint8_t* buf, uint32_t* length, const uint8_t* key, const uint8_t* iv,KJ4AESPaddingType padding);

//用完需要free
uint8_t* kj4aes128_decrypt_cbc(const uint8_t* buf, uint32_t* length, const uint8_t* key, const uint8_t* iv,KJ4AESPaddingType padding);

KJ_EXPORT(uint8_t *) kj4aes128_decrypt_cbc_onpadding(const uint8_t* buf, uint32_t length, const uint8_t* key, const uint8_t* iv);

#pragma mark - 不申请新内存直接修改原数据的加解密
// 媒体数据前32或16字节加密，无需padding
KJ_EXPORT(void) kj_aes128_encrypt_cbc_nopadding(uint8_t *data, uint32_t length, const char *key, const char *iv);

// 对所有字节加密，可能需padding
KJ_EXPORT(void) kj_aes128_encrypt_cbc_padding(uint8_t *data, uint32_t *length, const char *key, const char *iv);

// 媒体数据前32或16字节解密，无需去除padding
KJ_EXPORT(void) kj_aes128_decrypt_cbc_nopadding(uint8_t *data, uint32_t length, const char *key, const char *iv);

// 对所有字节解密，可能需去除padding
KJ_EXPORT(void) kj_aes128_decrypt_cbc_padding(uint8_t *data, uint32_t *length, const char *key, const char *iv);

KJ_CPP_END

#endif /* kj_aes_h */
