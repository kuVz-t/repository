//
//  kj_data_buffer.c
//  kj_sdk
//
//  Created by twenty on 2020/12/24.
//

#include "kj_data_buffer.h"
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>

typedef struct kj_data_buffer {
    size_t buffer_id;   // 缓存id
    size_t data_count;  // 缓存中已有数据包的数量
    size_t ref_count;   // 在多线程操作读或写的操作时，记录已经进入操作的次数，用于销毁缓存的时候等待操作完才销毁缓存
    kj_data *data_head;
    kj_data *data_tail;
    int writeable;
//    pthread_cond_t cond;
    pthread_mutex_t mutex;
} kj_data_buffer;

#pragma mark - 缓存实例管理
kj_data_buffer *kj_buffer_get_buffer(size_t buffer_id) {
    kj_data_buffer *buffer = (kj_data_buffer *)buffer_id;
    if (buffer_id == 0 || buffer->buffer_id != buffer_id) {
        buffer = NULL;
    }
    return buffer;
}
void kj_buffer_destroy_inner(kj_data_buffer *buffer) {
//    pthread_cond_destroy(&buffer->cond);
    pthread_mutex_destroy(&buffer->mutex);
    free(buffer);
}
void kj_buffer_wipe_inner(kj_data_buffer *buffer) {
    kj_data *data = buffer->data_head;
    kj_data *temp = NULL;
    while (data) {
        temp = data->next;
        kj_data_free(data);
        data = temp;
    }
    buffer->data_count = 0;
    buffer->data_head = NULL;
    buffer->data_tail = NULL;
}
KJ_EXPORT(size_t) kj_buffer_create_and_retain(void) {
    kj_data_buffer *buffer = calloc(1, sizeof(kj_data_buffer));
    size_t buffer_id = (size_t)buffer;
    if (buffer) {
        buffer->buffer_id = buffer_id;
        buffer->writeable = 1;
        buffer->ref_count = 1;
//        pthread_cond_init(&buffer->cond, NULL);
        pthread_mutex_init(&buffer->mutex, NULL);
    }
    return buffer_id;
}
KJ_EXPORT(size_t) kj_buffer_retain(size_t buf_id) {
    kj_data_buffer *buffer = kj_buffer_get_buffer(buf_id);
    if (buffer) {
        pthread_mutex_lock(&buffer->mutex);
        buffer->ref_count++;
        pthread_mutex_unlock(&buffer->mutex);
    } else {
        buf_id = 0;
    }
    return buf_id;
}
KJ_EXPORT(void) kj_buffer_release(size_t *buf_id) {
    size_t temp_buf = *buf_id;
    *buf_id = 0;
    kj_data_buffer *buffer = kj_buffer_get_buffer(temp_buf);
    if (buffer) {
        int destroy = 0;
        pthread_mutex_lock(&buffer->mutex);
        if (buffer->ref_count > 0) {
            if (--buffer->ref_count == 0) {
                kj_buffer_wipe_inner(buffer);
//                pthread_cond_signal(&buffer->cond);
                destroy = 1;
            }
        }
        pthread_mutex_unlock(&buffer->mutex);
        if (destroy) {
            kj_buffer_destroy_inner(buffer);
        }
    }
}
KJ_EXPORT(void) kj_buffer_put_data(size_t buf_id, kj_data *data) {
    kj_data_buffer *buffer = kj_buffer_get_buffer(buf_id);
    if (buffer && buffer->writeable && data) {
        pthread_mutex_lock(&buffer->mutex);
        kj_data *new_data = kj_data_copy(data);
        new_data->next = NULL;
        if (buffer->data_head) {
            if (buffer->data_tail) {
                buffer->data_tail->next = new_data;
            }
            buffer->data_tail = new_data;
        } else {
            buffer->data_head = new_data;
            buffer->data_tail = new_data;
//            pthread_cond_signal(&buffer->cond);
        }
        buffer->data_count++;
        pthread_mutex_unlock(&buffer->mutex);
    }
}
KJ_EXPORT(kj_data *) kj_buffer_get_data(size_t buf_id) {
    kj_data_buffer *buffer = kj_buffer_get_buffer(buf_id);
    kj_data *data = NULL;
    if (buffer) {
        pthread_mutex_lock(&buffer->mutex);
        data = buffer->data_head;
        if (data) {
            buffer->data_head = data->next;
            data->next = NULL;
            buffer->data_count--;
        }
        
//        while (data == NULL && buffer->ref_count) {
//            data = buffer->data_head;
//            if (data == NULL) {
//                pthread_cond_wait(&buffer->cond, &buffer->mutex);
//                data = buffer->data_head;
//                if (data == NULL) { // 清空数据的信号需退出循环
//                    break;
//                }
//            }
//        }
//        if (data) {
//            buffer->data_head = data->next;
//            data->next = NULL;
//        }
        pthread_mutex_unlock(&buffer->mutex);
    }
    return data;
}
KJ_EXPORT(void) kj_buffer_set_writeable(size_t buf_id, int writeable) {
    kj_data_buffer *buffer = kj_buffer_get_buffer(buf_id);
    if (buffer) {
        buffer->writeable = writeable;
    }
}
KJ_EXPORT(void) kj_buffer_wipe(size_t buf_id) {
    kj_data_buffer *buffer = kj_buffer_get_buffer(buf_id);
    if (buffer) {
        pthread_mutex_lock(&buffer->mutex);
        kj_buffer_wipe_inner(buffer);
//        pthread_cond_signal(&buffer->cond);
        pthread_mutex_unlock(&buffer->mutex);
    }
}
KJ_EXPORT(void) kj_buffer_free_data(kj_data *data) {
    kj_data_free(data);
}
