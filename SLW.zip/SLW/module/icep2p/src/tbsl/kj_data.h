//
//  kj_data.h
//  Demo-iOS
//
//  Created by twenty on 2020/12/9.
//

#ifndef kj_data_h
#define kj_data_h

#include "kj_data_define.h"
#include "kj4aes.h"

#define kj_data_head_length         8   // 数据头长度
#define kj_media_head_length        14  // 帧首包媒体头长度
#define kj_media_head_left_length   6   // 非帧首包媒体头长度

#define kj_data_max_length          4096    // 私有协议每个包的最大数据长度

#pragma mark - 类型定义
/* 媒体头，帧首包14字节，剩余包无帧长度和时间戳因此6字节
 ｜通道号｜ 序号 ｜ 帧信息 ｜ 帧类型 ｜帧长度 ｜ 时间戳 ｜
 ｜2字节 ｜2字节 ｜ 1字节 ｜ 1字节  ｜ 4字节 ｜ 4字节 ｜
 */
typedef struct kj_media_meta {
    uint16_t channel;       // 通道号，网络字节序
    uint16_t sequence;      // 序号，网络字节序
    kj_frame_type frame_type; // 视频帧信息：高4位视频帧信息，1：I帧；0：P帧
    int8_t frame_begin;     // 视频帧信息：帧开始
    int8_t frame_end;       // 视频帧信息：帧结束
    int8_t frame_nal_begin; // 视频帧信息：NAL开始
    int8_t frame_nal_end;   // 视频帧信息：NAL结束
    kj_av_type av_type;     // 媒体数据类型：1：视频；2：音频
    uint32_t frame_len;     // 帧长度；网络字节序
    uint32_t time_stamp;    // 网络字节序，帧的时间戳，当天的毫秒数
} kj_media_meta;

/* 报文头，8字节，因内存对齐，可直接创建指针指向数据指针初始化
 ｜标志#$｜ 类型  ｜ 方法 ｜ 长度 ｜加密方式｜ 保留 ｜
 ｜ 2字节｜ 1字节 ｜ 1字节｜2字节 ｜ 1字节 ｜ 1字节｜
 */
typedef struct kj_data_head {
    char head[2];           // 报文开头标志:#$
    kj_data_type type;      // 数据类型，见类型：kj_data_type
    kj_data_method method;  // 信令方法字段，见类型：kj_data_method
    uint16_t length;        // 数据长度
    uint8_t encryption;     // 数据加密方式
    uint8_t reserved;       // 保留字节
} kj_data_head;
// 私有协议数据结构体
typedef struct kj_data {
    uint16_t refcount;      // 引用计数，使用栈内存时为0，堆内存则大于0
    kj_data_type type;      // 数据类型，见类型：kj_data_type
    kj_data_method method;  // 信令方法字段，见类型：kj_data_method
    uint16_t length;        // 数据长度
    uint8_t encryption;     // 数据加密方式
    uint8_t reserved;       // 保留字节
    kj_media_meta *media_meta;  // 媒体头
    void *raw_data;         // 实际数据
    KJ_STRUCT_ADD_NODE(struct kj_data);
} kj_data;

#pragma mark - 数据解析
/// 从网络数据解析出私有协议信息的数据
/// @param data 网络数据
/// @param length 网络数据的长度，执行完被修改为未解析的数据长度
/// @param left_length 解析后还剩余的数据长度
/// @param key aes解密密钥
/// @param iv aes解密向量
/// @return 返回私有协议数据的指针，解析成功后得到非空的私有协议数据指针
kj_data *kj_data_parse(const void *data, size_t length, size_t *left_length,
                       const char *key, const char *iv);

/// 不申请内存，使用外部提供的内存，由container指向，确保该内存空间至少比length多出kj_data的长度（即32byte）
kj_data *kj_data_parse_to(void *container, const void *data, size_t length, size_t *left_length,
                          const char *key, const char *iv);

/// 解密数据
void kj_data_decrypt(kj_data *data, const char *key, const char *iv);

#pragma mark - 数据封装
/// 私有协议数据封装为网络数据
/// @param data 包含数据报文头（或且有媒体头）和原始数据的结构体
/// @param packed_data 指向封装后的数据指针的指针，用完后需释放内存free()
/// @return 返回封装的数据长度
size_t kj_data_pack(kj_data data, char **packed_data, const char *aes_key, const char *aes_iv);

#pragma mark - 数据引用和释放
/// 复制数据，如refcount大于0则只对refcount加1，refcount为0则开辟新内存复制
/// @param data 复制目标数据
/// @return 返回复制或增加refcount的数据
KJ_EXPORT(kj_data *) kj_data_copy(kj_data *data);

/// 释放私有协议数据，对refcount进行减1，当refcount为0时释放内存空间
/// @param data 私有协议数据
KJ_EXPORT(void) kj_data_free(kj_data *data);

#pragma mark - 工具类方法
/// 获取默认的数据报文头结构体
kj_data kj_data_create(void);

/// 获取默认的媒体数据报文头结构体
kj_media_meta kj_data_create_media_meta(void);

// 获取数据详情字符串，长度为150字节
char *kj_data_info(const kj_data *data);
void kj_data_get_info(const kj_data *data, char *info, size_t length);

// 客户端与设备或媒体转发的心跳保活数据
kj_data kj_keepalive_ask_data_with_seq(uint8_t seq, void *data, size_t size);
kj_data kj_keepalive_answer_data_with_seq(uint8_t seq, void *data, size_t size);

// 客户端与信令服务的心跳保活数据
kj_data kj_keepalive_signal_ask_data(void);
kj_data kj_keepalive_signal_answer_data(void);

#endif /* kj_data_h */
