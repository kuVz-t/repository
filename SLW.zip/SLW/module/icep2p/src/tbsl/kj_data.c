//
//  kj_data.c
//  Demo-iOS
//
//  Created by twenty on 2020/12/9.
//


#include "kj_data.h"

#include <string.h>
#include <sys/time.h>

#pragma mark - 数据解析
void kj_data_parse_media_meta(kj_data *data) {
    void *raw_data = data->raw_data;
    // 解析通道号和序号
    memcpy(&data->media_meta->channel, raw_data, 2);
    memcpy(&data->media_meta->sequence, raw_data + 2, 2);
    data->media_meta->channel = ntohs(data->media_meta->channel);
    data->media_meta->sequence = ntohs(data->media_meta->sequence);
    // 解析帧信息
    uint8_t frame_info = *(uint8_t *)(raw_data + 4);
    data->media_meta->frame_type = (frame_info & 0xf0) >> 4;
    data->media_meta->frame_begin = (frame_info & 0x08) ? 1 : 0;
    data->media_meta->frame_end = (frame_info & 0x04) ? 1 : 0;
    data->media_meta->frame_nal_begin = (frame_info & 0x02) ? 1 : 0;
    data->media_meta->frame_nal_end = frame_info & 0x01;
    data->media_meta->av_type = *(uint8_t *)(raw_data + 5);
    raw_data += 6;
    data->length -= 6;
    // 解析帧长度和时间戳
    if (data->media_meta->frame_begin) {
        memcpy(&data->media_meta->frame_len, raw_data, 4);
        memcpy(&data->media_meta->time_stamp, raw_data + 4, 4);
        data->media_meta->frame_len = ntohl(data->media_meta->frame_len);
        data->media_meta->time_stamp = ntohl(data->media_meta->time_stamp);
        raw_data += 8;
        data->length -= 8;
    } else {
        data->media_meta->frame_len = 0;
        data->media_meta->time_stamp = 0;
    }
    data->raw_data = (void *)raw_data;
}
kj_data *kj_data_parse(const void *data, size_t length, size_t *left_length,
                       const char *key, const char *iv) {
    return kj_data_parse_to(NULL, data, length, left_length, key, iv);
}
kj_data *kj_data_parse_to(void *container, const void *data, size_t length, size_t *left_length,
                          const char *key, const char *iv) {
    // 移除非"#$"开头的字节
    const char *pri_data = data;
    while (length > 0) {
        if (*pri_data == '#') {
            if (length > 1 && *(pri_data + 1) != '$') {
                pri_data++;
                length--;
            } else {
                break;
            }
        } else {
            pri_data++;
            length--;
        }
    }
    // 解析私有数据
    kj_data *data_parsed = NULL;
    if (length >= kj_data_head_length) {
        kj_data_head head;
        memcpy(&head, pri_data, kj_data_head_length);
        head.length = ntohs(head.length);
        if (length >= kj_data_head_length + head.length) {
            length -= (kj_data_head_length + head.length);
            // 确定kj_data的长度以申请内存
            size_t data_length = sizeof(kj_data) + head.length;
            if (head.type == kj_data_type_media) {
                data_length += sizeof(kj_media_meta);
            }
            // 解析数据头
            data_parsed = container ? container : malloc(data_length);
            memcpy(data_parsed, pri_data, kj_data_head_length);
            pri_data += kj_data_head_length;
            data_parsed->refcount = 0;
            data_parsed->length = head.length;
            data_parsed->prev = NULL;
            data_parsed->next = NULL;
            // 媒体头和数据内存地址指向、数据复制
            if (head.type == kj_data_type_media) {
                data_parsed->media_meta = (kj_media_meta *)(data_parsed + 1);
                data_parsed->raw_data = (void *)(data_parsed->media_meta + 1);
            } else {
                data_parsed->media_meta = NULL;
                data_parsed->raw_data = (void *)(data_parsed + 1);
            }
            memcpy(data_parsed->raw_data, pri_data, head.length);
            if (head.type == kj_data_type_media && head.encryption == KJ4AES_NONE) {
                // 媒体数据且无加密则解析媒体头
                kj_data_parse_media_meta(data_parsed);
            } else {
                // 加密数据则解密数据并解析媒体头
                kj_data_decrypt(data_parsed, key, iv);
            }
        }
    }
    *left_length = length;
    return data_parsed;
}
void kj_data_decrypt(kj_data *data, const char *key, const char *iv) {
    if (data->encryption == KJ4AES_128 && key && iv) {
        data->encryption = KJ4AES_NONE;
        // 媒体数据和非媒体数据的解析
        if (data->type == kj_data_type_media) {
            // 解密数据
            uint32_t decrypt_len = 0;
            if (data->length >= 32) {
                decrypt_len = 32;
            } else if (data->length >= 16) {
                decrypt_len = 16;
            }
            if (decrypt_len) {
                kj_aes128_decrypt_cbc_nopadding(data->raw_data, decrypt_len, key, iv);
            }
            kj_data_parse_media_meta(data);
        } else {
            // 解密数据
            uint32_t dec_length = data->length;
            kj_aes128_decrypt_cbc_padding(data->raw_data, &dec_length, key, iv);
            data->length = dec_length;
        }
    }
}

#pragma mark - 数据引用和释放
KJ_EXPORT(kj_data *) kj_data_copy(kj_data *data) {
    kj_data *data_cp = NULL;
    if (data) {
        if (data->refcount) {
            data->refcount++;
            data_cp = data;
        } else {
            size_t head_length = sizeof(kj_data);
            size_t media_meta_length = data->media_meta ? sizeof(kj_media_meta) : 0;
            size_t data_length = data->length;
            data_cp = malloc(head_length + media_meta_length + data_length);
            memcpy(data_cp, data, head_length);
            data_cp->refcount = 0;
            if (data->media_meta) {
                data_cp->media_meta = (kj_media_meta *)(data_cp + 1);
                data_cp->raw_data = (void *)(data_cp->media_meta + 1);
                memcpy(data_cp->media_meta, data->media_meta, media_meta_length);
            } else {
                data_cp->raw_data = (void *)(data_cp + 1);
            }
            if (data->raw_data && data_length) {
                memcpy(data_cp->raw_data, data->raw_data, data_length);
            }
        }
    }
    return data_cp;
}
KJ_EXPORT(void) kj_data_free(kj_data *data) {
    if (data) {
        if (data->refcount) {
            data->refcount--;
        }
        if (data->refcount == 0) {
            free(data);
        }
    }
}

#pragma mark - 数据封装
kj_data_head kj_data_get_hton_head(kj_data data) {
    kj_data_head head = {
        .head = {'#','$'},
        .type = data.type,
        .method = data.method,
        .length = htons(data.length),
        .encryption = data.encryption,
        .reserved = data.reserved
    };
    return head;
}
typedef struct kj_media_net_meta {
    uint16_t channel;      // 通道号，网络字节序
    uint16_t sequence;     // 序号，网络字节序
    uint8_t frame_info; // 视频帧信息：高4位视频帧信息，1：I帧；0：P帧
    uint8_t av_type;     // 媒体数据类型：1：视频；2：音频
    uint32_t frame_len;    // 帧长度；网络字节序
    uint32_t time_stamp;   // 网络字节序，帧的时间戳，当天的毫秒数
} kj_media_net_meta;
kj_media_net_meta kj_data_get_hton_media_meta(kj_media_meta media_meta) {
    // 媒体数据属性转为网络传输数据属性
    kj_media_net_meta md_shadow = {};
    md_shadow.channel = htons(media_meta.channel);
    md_shadow.sequence = htons(media_meta.sequence);
    md_shadow.frame_info = media_meta.frame_type<<4 & 0xf0;
    md_shadow.frame_info += media_meta.frame_begin<<3 & 0x08;
    md_shadow.frame_info += media_meta.frame_end<<2 & 0x04;
    md_shadow.frame_info += media_meta.frame_nal_begin<<1 & 0x02;
    md_shadow.frame_info += media_meta.frame_nal_end & 0x01;
    md_shadow.av_type = media_meta.av_type;
    // 是否起始帧数据，起始帧数据包含长度和时间戳信息为14字节，非起始少8字节
    if (media_meta.frame_begin) {
        md_shadow.time_stamp = htonl(media_meta.time_stamp);
        md_shadow.frame_len = htonl(media_meta.frame_len);
    }
    return md_shadow;
}
size_t kj_data_pack(kj_data data, char **packed_data, const char *key, const char *iv) {
    // 计算封装后的数据长度，非媒体数据且为AES128加密则预留多16字节用于末尾填充
    size_t new_length = kj_data_head_length + data.length;
    if (data.type == kj_data_type_media && data.media_meta) {
        new_length += (data.media_meta->frame_begin ? kj_media_head_length : kj_media_head_left_length);
    } else if (data.encryption == KJ4AES_128) {
        new_length += 16;
    }
    // 申请封装数据内存
    *packed_data = malloc(new_length);
    void *raw_data = *packed_data + kj_data_head_length;
    size_t pack_length = kj_data_head_length;
    if (data.type == kj_data_type_media && data.media_meta) {
        // 先跳过数据头封装媒体头和数据
        kj_media_net_meta hton_meta = kj_data_get_hton_media_meta(*data.media_meta);
        memcpy(raw_data, &hton_meta.channel, 2);
        memcpy(raw_data + 2, &hton_meta.sequence, 2);
        memcpy(raw_data + 4, &hton_meta.frame_info, 1);
        memcpy(raw_data + 5, &hton_meta.av_type, 1);
        if (data.media_meta->frame_begin) {
            memcpy(raw_data + 6, &hton_meta.frame_len, 4);
            memcpy(raw_data + 10, &hton_meta.time_stamp, 4);
            memcpy(raw_data + 14, data.raw_data, data.length);
            data.length += 14;
        } else {
            memcpy(raw_data + 6, data.raw_data, data.length);
            data.length += 6;
        }
        // 加密数据
        uint32_t encrypt_length = 0;
        if (data.length >= 32) {
            encrypt_length = 32;
        } else if (data.length >= 16) {
            encrypt_length = 16;
        }
        if (data.encryption == KJ4AES_128 && encrypt_length) {
            kj_aes128_encrypt_cbc_nopadding(raw_data, encrypt_length, key, iv);
        }
    } else {
        // 封装数据头
        memcpy(raw_data, data.raw_data, data.length);
        // 加密数据
        if (data.encryption == KJ4AES_128) {
            uint32_t encrypt_length = data.length;
            kj_aes128_encrypt_cbc_padding(raw_data, &encrypt_length, key, iv);
            data.length = encrypt_length;
        }
    }
    pack_length += data.length;
    // 确定数据长度后封装数据头
    kj_data_head hton_head = kj_data_get_hton_head(data);
    memcpy(*packed_data, &hton_head, kj_data_head_length);
    return pack_length;
}

#pragma mark - 工具类方法
kj_data kj_data_create(void) {
    kj_data data = {};
    return data;
}
kj_media_meta kj_data_create_media_meta(void) {
    kj_media_meta meta = {};
    return meta;
}
char *kj_data_info(const kj_data *data) {
    char *info = NULL;
    if (data) {
        info = malloc(150);
        kj_data_get_info(data, info, 150);
    }
    return info;
}
// 与TBSL中的结构体kj_tbsl_ack_data保持一致定义，仅供kj_data_get_info函数获取对应属性值
typedef struct kj_tbsl_ack_data1 {
    uint16_t channel;       // 数据通道号
    kj_av_type av_type;     // 切片类型(1byte)：1 视频，2 音频
    uint8_t tbsl_mode;      // 传输协议工作模式，0关闭协议；1只处理乱序；2丢包模式；3无丢包模式；4控速传输的无丢包模式，由接收方控速
    uint8_t ack_seq;        // 发送方需把此值设置到重发数据报文头的保留字节中，用于接收方计算RTT
    uint8_t ctl_type;       // 控制类型(1byte)
    uint16_t uint_va1;      // 无丢包模式时：窗口起始值；丢包模式时：发送方所能存储数据的最大时间范围，毫秒值
    uint16_t uint_va2;      // 无丢包模式时有效：窗口大小，用于发送方可发送的包个数
    uint16_t seq_count;     // 序号数量，无丢包模式(3,4)时为收到的序号数量，丢包模式(2)时为丢包序号的数量
    uint16_t seqs[1];       // 数据包的序号，大小设为1是为了在其他地方可以使用sizeof()获得单个元素所占字节大小
} kj_tbsl_ack_data1;
void kj_data_get_info(const kj_data *data, char *info, size_t length) {
    if (data->media_meta) {
        snprintf(info, length, "kj_data:type=%x,mtd=%x,len=%d,enc=%d,保留=%d,通道=%d,seq=%d,av_type=%d,帧型=%d,begin=%d,end=%d,Nbegin=%d,Nend=%d,fLen=%d,time=%d",data->type,data->method,data->length,data->encryption,data->reserved,data->media_meta->channel,data->media_meta->sequence,data->media_meta->av_type,data->media_meta->frame_type,data->media_meta->frame_begin,data->media_meta->frame_end,data->media_meta->frame_nal_begin,data->media_meta->frame_nal_end,data->media_meta->frame_len,data->media_meta->time_stamp);
    } else if (data->type == kj_data_type_tbsl && data->method == kj_data_method_tbsl) {
        kj_tbsl_ack_data1 *ack = data->raw_data;
        uint16_t channel = ack->channel, val1 = ack->uint_va1, val2 = ack->uint_va2, seq_count = ack->seq_count;
        snprintf(info, length, "kj_data:type=%x,mtd=%x,len=%d,enc=%d,保留=%d,通道=%d,av_type=%d,mode=%d,ack_seq=%d,ctl_type=%d,val1=%d,val2=%d,seq_count=%d",data->type,data->method,data->length,data->encryption,data->reserved,ntohs(channel),ack->av_type,ack->tbsl_mode,ack->ack_seq,ack->ctl_type,ntohs(val1),ntohs(val2),ntohs(seq_count));
    } else {
        snprintf(info, length, "kj_data:type=%x,method=%x,length=%d,enc=%d,保留=%d",data->type,data->method,data->length,data->encryption,data->reserved);
    }
}
// 客户端与设备和媒体转发的心跳保活数据
kj_data kj_keepalive_ask_data_with_seq(uint8_t seq, void *data, size_t size) {
    kj_data alive_data = kj_data_create();
    alive_data.type = kj_data_type_keepalive_ask;
    alive_data.method = kj_data_method_keepalive_ask;
    alive_data.reserved = seq;
    if (data && size) {
        alive_data.raw_data = data;
        alive_data.length = size;
    }
    return alive_data;
}
kj_data kj_keepalive_answer_data_with_seq(uint8_t seq, void *data, size_t size) {
    kj_data alive_data = kj_data_create();
    alive_data.type = kj_data_type_keepalive_answer;
    alive_data.method = kj_data_method_keepalive_answer;
    alive_data.reserved = seq;
    if (data && size) {
        alive_data.raw_data = data;
        alive_data.length = size;
    }
    return alive_data;
}

// 客户端与信令服务的心跳保活数据
kj_data kj_keepalive_signal_ask_data(void) {
    kj_data alive_data = kj_data_create();
    alive_data.type = kj_data_type_keepalive_signal;
    alive_data.method = kj_data_method_keepalive_ask;
    return alive_data;
}
kj_data kj_keepalive_signal_answer_data(void) {
    kj_data alive_data = kj_data_create();
    alive_data.type = kj_data_type_keepalive_signal;
    alive_data.method = kj_data_method_keepalive_answer;
    return alive_data;
}
