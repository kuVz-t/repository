//
//  kj_tbsl.h
//  kj_sdk
//
//  Created by twenty on 2021/1/13.
//

#ifndef kj_tbsl_h
#define kj_tbsl_h

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "kj_data.h"
//#include "kj_log.h"
#include "kj_util.h"
#include "rm_timer.h"

#define KJ_TBSL_HALF_MAX_SEQ  32767

#define KJ_TBSL_DEFAULT_RTT  500

#define KJ_TBSL_MAX_RECV_WIN_SIZE          500
#define KJ_TBSL_MIN_RECV_WIN_SIZE          10
#define KJ_TBSL_DEFAULT_RECV_WIN_SIZE      100
#define KJ_TBSL_DEFAULT_STASH_MAX_INTERVAL  2000
#define KJ_TBSL_DEFAULT_THROTTLE_INTERVAL   5000

#define KJ_TBSL_DEFAULT_SENT_CAPACITY       1000

RM_CPP_BEGIN

// 协议模式
typedef enum {
    kj_tbsl_disable = 0,    // 关闭协议的工作，即不使用可靠传输协议
    kj_tbsl_in_order = 1,   // 只处理乱序，不反馈数据接收情况
    kj_tbsl_loss_selectively = 2,   // 处理乱序，只回馈丢失的包，用于实时媒体传输主动丢弃早期的数据
    kj_tbsl_lossless = 3,           // 处理乱序，回馈已收到的包和窗口大小，用于无丢包的可靠传输
    kj_tbsl_lossless_throttle = 4,  // 处理乱序，回馈已收到的包和窗口大小，根据接收数据所需要的耗时而动态改变窗口大小，用于限制传输速度
} kj_tbsl_mode;

// 控制类型
typedef uint8_t kj_tbsl_ctl;
enum {
    // 接收反馈，丢包和无丢包模式接收方都用该类型向发送方反馈接收情况
    kj_tbsl_ctl_recv_ack      = 0,
    // 无丢包模式下的暂停发送，接收方收到发送方发来该信令则停止发送请求新数据的信令，直到发送方主动发送新数据来才进行下一轮的数据收发
    kj_tbsl_ctl_send_pause    = 1,
    // 无丢包模式下发送方完成数据发送时，向接收方发送结束发送数据信令，接收方收到该信令时需回复结束接收数据控制信令，即回复kj_tbsl_ctl_recv_finish
    kj_tbsl_ctl_send_finish   = 2,
    // 无丢包模式下接收方回复发送方收到kj_tbsl_ctl_send_finish信令
    kj_tbsl_ctl_recv_finish   = 3,
    // 丢包模式下的发送方告知其所能存储最大数据时间范围
    kj_tbsl_ctl_send_buf_time = 4
};

// 数据接收反馈数据，数据均为网络字节序传输，为使整个报文数据不超过1376字节，seq_count <= (1376 - 16)/2，即680个序号
#define KJ_MAX_SEQ_COUNT_PER_TIME 680
typedef struct kj_tbsl_ack_data {
    uint16_t channel;       // 数据通道号
    kj_av_type av_type;     // 切片类型(1byte)：1 视频，2 音频
    uint8_t tbsl_mode;      // 传输协议工作模式，0关闭协议；1只处理乱序；2丢包模式；3无丢包模式；4控速传输的无丢包模式，由接收方控速
    uint8_t ack_seq;        // 发送方需把此值设置到重发数据报文头的保留字节中，用于接收方计算RTT
    kj_tbsl_ctl ctl_type;   // 控制类型(1byte)
    uint16_t uint_va1;      // 无丢包模式时：窗口起始值；丢包模式时：发送方所能存储数据的最大时间范围，毫秒值
    uint16_t uint_va2;      // 无丢包模式时有效：窗口大小，用于发送方可发送的包个数
    uint16_t seq_count;     // 序号数量，无丢包模式(3,4)时为收到的序号数量，丢包模式(2)时为丢包序号的数量
    uint16_t seqs[1];       // 数据包的序号，大小设为1是为了在其他地方可以使用sizeof()获得单个元素所占字节大小
} kj_tbsl_ack_data;

typedef struct kj_tbsl kj_tbsl;
typedef void kj_tbsl_recv_callback(const kj_tbsl *tbsl, kj_data *data);
typedef void kj_tbsl_send_callback(const kj_tbsl *tbsl, kj_data *data);

#define KJ_MAX_ACK_TIMES 3  // 丢包模式下，丢失的包最多反馈次数，超过次数则丢弃重传处理

// 丢失包的序号环链
typedef struct kj_lost_seq_node {
    uint8_t ack_seq;    // 请求重发时，从“kj_tbsl”取的ack_seq设置更新，把此值设置到重发数据报文头的保留字节中，用于接收方计算RTT
    uint8_t ack_times;  // 已发起重传的次数
    uint16_t sequence;  // 丢失包的序号
    kj_time time_stamp; // 判断该序号为丢失时的时间戳，用于主动丢包模式下判断距离发送重传时是否已超过发送方最大的缓存时间范围
    KJ_NODE_TYPE(struct kj_lost_seq_node);
} kj_lost_seq_node;

// 接收端
struct kj_tbsl_recver {
    int got_begin_data; // 标记是否已接收到了第一个包数据，用于判断第一个包序号非0时是否为第一个包
    int miss_key_frame; // 标记是否丢弃了关键帧，关键帧已被丢弃，则后面的P帧都直接丢掉，直到下一个关键帧
    int loss_count;     // 无丢包模式下的连续丢包次数，用于动态更改窗口大小
    int lossless_count; // 无丢包模式下的连续无丢包次数，用于动态更改窗口大小
    int allow_ack;      // 无丢包模式时，是否激活有定时器定时反馈接收情况控制信令
    uint16_t next_seq;  // 下个应到的数据包序号
    uint16_t win_begin; // 无丢包模式的窗口起始值
    uint16_t win_size;  // 缓存容量
    uint16_t max_data_interval;     // 暂存数据最后一个距离最早一个的最大时间范围，毫秒，用于selective loss模式
    uint16_t total_lost_count;      // 从丢包开始统计的丢包数量
    uint16_t total_recv_count;      // 从丢包开始统计的已接收数据包数量
    uint32_t first_frame_time_stamp;// 收到第一帧的数据时间
    uint32_t last_frame_time_stamp; // 最近收到的一帧数据的时间
    int32_t end_seq;                // 不等于-1则已收到发送方发来的结束信令，和结束包的序号，结束包序号从控制信令的uint_va1获取。采用32位符号整型是为了容下无符号的16位所有值
    // 接收状况反馈
    kj_time ack_time;       // 最后一次发送控制信令的时间，收到回复信令后可根据信令的序号是否与ctrl_seq_sent相等而与当前时间作差可得出RTT
    uint8_t ack_seq;        // 数据包反馈序号，先自增1，如等于0则置为1，设置到控制信令kj_tbsl_ack_data的ack_seq，用于接收方计算RTT
    uint8_t ack_seq_sent;   // 最后一次发送控制信令的序号，收到回复后置0，避免因多个相同控制序号的数据包参与到计算中

    kj_time first_frame_output_time;// 第一帧数据到达的时间
    kj_time newest_recv_time;       // 最近一个数据包到达的时间
    // 因丢包而暂存的数据
    uint16_t stash_count;           // 已缓存的数据包个数
    kj_data stash_data_queue;       // 缓存环链
    // 丢包
    uint16_t lost_count;                // 丢包个数
    kj_lost_seq_node lost_seq_node;     // 丢包序号环链
    // 输出区数据
    kj_data *output_head;   // 已处理乱序的输出数据链头
    kj_data *output_tail;   // 已处理乱序的输出数据链尾
    kj_timer_task ack_timer_task;// 数据接收情况回馈线程
};

// 发送端
struct kj_tbsl_sender {
    uint16_t endpoint_win_size;
    uint16_t win_size;
    uint16_t sent_count;
    kj_data sending_data_queue;
    pthread_cond_t send_cond;
    pthread_mutex_t send_mutex;
};

// 数据接收处理模块
struct kj_tbsl {
    kj_tbsl_mode mode;
    kj_av_type av_type;
    uint16_t channel;
    size_t rtt;     // 与连接终端一个往返数据传输耗时（RTT，毫秒），利用数据传输控制信令的回复计算
    void *os_obj;   // 上层对象指针
    // 收发回调函数指针
    kj_tbsl_recv_callback *recv_cb;
    kj_tbsl_send_callback *send_cb;
    // 接收和发送对象
    struct kj_tbsl_recver recver;
    struct kj_tbsl_sender sender;
};

/// 创建接收协议对象
kj_tbsl *kj_tbsl_create(kj_tbsl_mode mode, kj_tbsl_recv_callback recv_cb, kj_tbsl_send_callback send_cb);

/// 销毁接收协议对象的指针，执行后tbsl被置NULL
void kj_tbsl_destroy(kj_tbsl **tbsl);

/// 重置对象数据
void kj_tbsl_reset(kj_tbsl *tbsl);

/// 获取丢包率，使用从丢包开始统计的已收到包和丢失的包计算得到，取值范围：0.00～1.00
float kj_tbsl_get_loss_rate(kj_tbsl *tbsl);

/// 【线程安全】上层发送数据调用接口，通过发送回调函数调用实际发送数据的通道发送回调的数据
void kj_tbsl_send(kj_tbsl *tbsl, kj_data *data);

/// 【线程不安全】应用层网络通道收到数据后调用该接口将数据传入tbsl协议对象，通过接收回调函数获得应到的数据
void kj_tbsl_recv(kj_tbsl *tbsl, kj_data *data);

RM_CPP_END

#endif /* kj_tbsl_h */
