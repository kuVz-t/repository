//
//  kj_data_buffer.h
//  kj_sdk
//
//  Created by twenty on 2020/12/24.
//

#ifndef kj_data_buffer_h
#define kj_data_buffer_h

#include <stdio.h>
#include "kj_data.h"

KJ_CPP_BEGIN

/// 创建缓存对象，返回大于0的缓存ID，返回0为创建失败。
/// 创建的缓存对象，如不再需要使用缓存则需要调用kj_buffer_release
KJ_EXPORT(size_t) kj_buffer_create_and_retain(void);

/// 增加缓存的引用，如需使用缓存的kj_buffer_put_data、kj_buffer_get_data、kj_buffer_wipe方法，必须执行一次kj_buffer_retain
/// 执行过kj_buffer_retain后，如不再需要使用缓存则需要调用kj_buffer_release
/// @param buf_id 缓存id
KJ_EXPORT(size_t) kj_buffer_retain(size_t buf_id);

/// 不再使用缓存时需调用该接口释放缓存对象，内部会根据引用计数决定是否销毁缓存，如内部决定销毁时会同时清空数据
/// @param buf_id 缓存ID地址
KJ_EXPORT(void) kj_buffer_release(size_t *buf_id);

/// 写一个数据到缓存中
/// @param buf_id 缓存ID
/// @param data 数据
KJ_EXPORT(void) kj_buffer_put_data(size_t buf_id, kj_data *data);

/// 从缓存中取出一个数据包
/// @param buf_id 缓存ID
KJ_EXPORT(kj_data *) kj_buffer_get_data(size_t buf_id);

/// 设置缓存是否可写入数据，默认为可写
/// @param buf_id 缓存ID
/// @param writeable 1:可写；0:不可写
KJ_EXPORT(void) kj_buffer_set_writeable(size_t buf_id, int writeable);

/// 释放从缓存中取出的数据内存
/// @param data 待释放的数据
KJ_EXPORT(void) kj_buffer_free_data(kj_data *data);

/// 清空缓存中所有的数据
/// @param buf_id 缓存ID
KJ_EXPORT(void) kj_buffer_wipe(size_t buf_id);

KJ_CPP_END

#endif /* kj_data_buffer_h */
