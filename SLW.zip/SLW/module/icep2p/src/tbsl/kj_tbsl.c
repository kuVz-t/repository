//
//  kj_tbsl.c
//  kj_sdk
//
//  Created by twenty on 2021/1/13.
//

#include "kj_tbsl.h"

#pragma mark - 函数定义
// 子线程执行回调函数
void cb_tbsl_ack_timer_task_excuting_callback(const kj_timer *timer, kj_timer_task *task);

void kj_tbsl_calculate_rtt_base_on_ack_seq_of_recv_data(kj_tbsl *tbsl) {
    if (tbsl->recver.ack_time.tv_sec != 0) {
        size_t interval = kj_time_interval_between(tbsl->recver.ack_time, kj_time_get_current());
        if (tbsl->rtt == 0) {
            tbsl->rtt = interval;
        } else {
            tbsl->rtt = (tbsl->rtt + interval) / 2;
        }
        tbsl->recver.ack_time.tv_sec = 0;
        tbsl->recver.ack_seq_sent = 0;
//        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG,"tbsl:ch=%d,av=%d;calculate rtt=%d,new_rtt=%d",tbsl->channel,tbsl->av_type,tbsl->rtt,interval);
    }
}
/// 获得数据后，检查是否有丢失的包，如有回调到发送通道发送重传请求
void kj_tbsl_recv_ack(kj_tbsl *tbsl);

#pragma mark - 节点数据处理
float kj_tbsl_get_loss_rate(kj_tbsl *tbsl) {
    float rate = 0;
    if (tbsl && (tbsl->recver.total_lost_count || tbsl->recver.total_recv_count)) {
        rate = (float)tbsl->recver.total_lost_count / (float)(tbsl->recver.total_lost_count + tbsl->recver.total_recv_count);
    }
    return rate;
}

#pragma mark - tbsl sender
// 清除已发送数据
void kj_tbsl_sender_wipe_sending_data(kj_tbsl *tbsl) {
    kj_data *next = NULL, *data = tbsl->sender.sending_data_queue.next;
    while (data != &tbsl->sender.sending_data_queue) {
        next = data->next;
        kj_data_free(data);
        data = next;
    }
    tbsl->sender.sent_count = 0;
    KJ_NODE_INIT(tbsl->sender.sending_data_queue);
}
void kj_tbsl_sender_remove_and_free_data(kj_tbsl *tbsl, kj_data *data) {
    KJ_NODE_REMOVE(data);
    kj_data_free(data);
    if (tbsl->sender.sent_count > 0) {
        tbsl->sender.sent_count--;
    }
}
/// 收到重传请求后根据序号获得缓存数据
kj_data *kj_tbsl_sender_get_data(kj_tbsl *tbsl, uint16_t sequence) {
    kj_data *data = NULL;
    if (tbsl && tbsl->sender.sent_count > 0) {
        kj_data *node_data = tbsl->sender.sending_data_queue.next;
        while (node_data != &tbsl->sender.sending_data_queue) {
            if (sequence == node_data->media_meta->sequence) {
                data = node_data;
                break;
            }
            node_data = node_data->next;
        }
    }
    return data;
}
/// 移除发送队列上已完成发送的数据
void kj_tbsl_sender_remove_data(kj_tbsl *tbsl, uint16_t sequence) {
    if (tbsl && tbsl->sender.sent_count > 0) {
        kj_data *data = tbsl->sender.sending_data_queue.next;
        while (data != &tbsl->sender.sending_data_queue) {
            if (sequence == data->media_meta->sequence) {
                kj_tbsl_sender_remove_and_free_data(tbsl, data);
                break;
            }
            data = data->next;
        }
    }
}

#pragma mark - tbsl对象管理和tbsl的数据处理
void kj_tbsl_wipe_output_data(kj_tbsl *tbsl) {
    kj_data *data = tbsl->recver.output_head;
    while (data) {
        
//        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_WARN,"tbsl:ch=%d,av=%d;wipe data=%s",tbsl->channel,tbsl->av_type,info);
        
        tbsl->recver.output_head = data->next;
        kj_data_free(data);
        data = tbsl->recver.output_head;
    }
    tbsl->recver.output_tail = NULL;
}

#pragma mark - 数据接收处理模块
// 清除暂存区数据
void kj_tbsl_recver_wipe_stash_data(kj_tbsl *tbsl) {
    kj_data *data = tbsl->recver.stash_data_queue.next;
    kj_data *next = NULL;
    while (data != &tbsl->recver.stash_data_queue) {
        next = data->next;
        kj_data_free(data);
        data = next;
    }
    tbsl->recver.stash_count = 0;
    KJ_NODE_INIT(tbsl->recver.stash_data_queue);
}
// 清除丢包序号
void kj_tbsl_recver_wipe_lost_seq(kj_tbsl *tbsl) {
    kj_lost_seq_node *seq_node = tbsl->recver.lost_seq_node.next;
    while (seq_node != &tbsl->recver.lost_seq_node) {
        kj_lost_seq_node *next = seq_node->next;
        free(seq_node);
        seq_node = next;
    }
    tbsl->recver.lost_count = 0;
    KJ_NODE_INIT(tbsl->recver.lost_seq_node);
}
size_t kj_tbsl_recver_get_ack_data_size_with_sequence_count(size_t count) {
    kj_tbsl_ack_data ack;
    if (count > 1) {
        return sizeof(ack) + (count - 1) * sizeof(ack.seqs);
    } else {
        return sizeof(ack);
    }
}
void kj_tbsl_recver_reduction_total_recv_count(kj_tbsl *tbsl) {
    tbsl->recver.total_recv_count == 0 ? : tbsl->recver.total_recv_count--;
}
void kj_tbsl_recver_reduction_total_lost_count(kj_tbsl *tbsl) {
    tbsl->recver.total_lost_count == 0 ? : tbsl->recver.total_lost_count--;
}
void kj_tbsl_recver_add_lost_sequence(kj_tbsl *tbsl, uint16_t next_seq, uint16_t arrive_seq) {
    // 两字节从最大值65535->0，直接相减0-65535=1，同样得到丢失的包为一个，丢失的序号为65535
    uint16_t lost_count = arrive_seq - next_seq;
    if (lost_count > 0) {
        tbsl->recver.total_lost_count += lost_count;
        tbsl->recver.lost_count += lost_count;
        // 添加丢失的序号入列尾
        kj_lost_seq_node *tail_node = tbsl->recver.lost_seq_node.prev;
        kj_time cur_time = kj_time_get_current();
        for (uint16_t i = 0; i < lost_count; i++) {
            kj_lost_seq_node *seq = calloc(1, sizeof(kj_lost_seq_node));
            seq->time_stamp = cur_time;
            seq->sequence = next_seq + i;
            KJ_NODE_ADD_BEHIND(tail_node, seq);
            tail_node = seq;
        }
    }
}
kj_data *kj_tbsl_recver_get_a_frame_data(kj_tbsl *tbsl) {
    kj_data *begin = NULL;
    if (tbsl->recver.output_head) {
//        if (tbsl->mode > kj_tbsl_loss_selectively) {
//            // 无丢包模式不需凑到一帧的数据而输出
//            begin = tbsl->output_data;
//            tbsl->output_data = NULL;
//        } else {
//        }
        /*
         1、因音频包不会拆分多个包，因此丢帧操作只对视频帧起作用
         2、前面已丢失I帧，则后面的P帧都丢弃，直到遇到新的I帧
         3、第一个必须是开始帧，否则丢弃
         4、连续的未构成一帧数据，则放弃取出，等待新数据到来构成一帧数据
         */
//        char info[150];
        begin = tbsl->recver.output_head;
        if (begin->media_meta->av_type == kj_av_type_video) {
            // 实时模式才丢帧处理
            if (tbsl->mode == kj_tbsl_loss_selectively) {
                while (begin) {
                    if (begin->media_meta->frame_begin == 0) {
                        
//                        kj_data_get_info(begin, info, 150);
//                        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_INFO,"tbsl:ch=%d,av=%d;drop data=%s",tbsl->channel,tbsl->av_type,info);
                        
                        tbsl->recver.output_head = begin->next;
                        if (begin->media_meta->frame_type == kj_frame_type_i) {
                            tbsl->recver.miss_key_frame = 1;
                        }
                        kj_data_free(begin);
                        begin = tbsl->recver.output_head;
                        kj_tbsl_recver_reduction_total_recv_count(tbsl);
                    } else if (tbsl->recver.miss_key_frame) {
                        if (begin->media_meta->frame_type == kj_frame_type_i) {
                            tbsl->recver.miss_key_frame = 0;
                            break;
                        } else {
                            
//                            kj_data_get_info(begin, info, 150);
//                            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_INFO,"tbsl:ch=%d,av=%d;drop data=%s",tbsl->channel,tbsl->av_type,info);
                            
                            tbsl->recver.output_head = begin->next;
                            kj_data_free(begin);
                            begin = tbsl->recver.output_head;
                            kj_tbsl_recver_reduction_total_recv_count(tbsl);
                        }
                    } else {
                        break;
                    }
                }
            }
            if (begin) {
                kj_data *end = tbsl->recver.output_head;
                while (end) {
                    if (end->media_meta->frame_end) {
                        tbsl->recver.output_head = end->next;
                        end->next = NULL;
                        break;
                    } else {
                        end = end->next;
                    }
                }
                if (end) {
                    if (end->media_meta->frame_type != begin->media_meta->frame_type) {
                        
//                        kj_data_get_info(end, info, 150);
//                        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_WARN,"tbsl:ch=%d,av=%d;it's not the same type data with begin,drop data=%s",tbsl->channel,tbsl->av_type,info);
                        
                        // 连续的包帧不同类型，清除输出区数据
                        while (begin) {
                            end = begin->next;
                            kj_data_free(begin);
                            begin = end;
                            kj_tbsl_recver_reduction_total_recv_count(tbsl);
                        }
                    } else {
                        if (begin->media_meta->frame_type == kj_frame_type_i) {
//                            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_INFO,"tbsl:ch=%d,av=%d;output video iframe=%d~%d",tbsl->channel,tbsl->av_type,begin->media_meta->sequence,end->media_meta->sequence);
                        }
                    }
                } else {
                    begin = NULL;
                }
            }
        } else {
            tbsl->recver.output_head = NULL;
        }
        if (tbsl->recver.output_head == NULL) {
            tbsl->recver.output_tail = NULL;
        }
    }
    return begin;
}
void kj_tbsl_recver_flush_output_data(kj_tbsl *tbsl) {
    kj_data *data_frame = kj_tbsl_recver_get_a_frame_data(tbsl);
    while (data_frame) {
        kj_data *next = NULL;
        while (data_frame) {
            next = data_frame->next;
            if (data_frame->media_meta->frame_begin) {
                if (tbsl->recver.first_frame_time_stamp == 0) {
                    tbsl->recver.first_frame_time_stamp = data_frame->media_meta->time_stamp;
                    tbsl->recver.first_frame_output_time = kj_time_get_current();
                }
                tbsl->recver.last_frame_time_stamp = data_frame->media_meta->time_stamp;
            }
            tbsl->recv_cb(tbsl, data_frame);
            kj_data_free(data_frame);
            data_frame = next;
            kj_tbsl_recver_reduction_total_recv_count(tbsl);
        }
        data_frame = kj_tbsl_recver_get_a_frame_data(tbsl);
    }
}
void kj_tbsl_recver_output_frame_data(kj_tbsl *tbsl) {
    // 输出输出区完整的数据
    kj_tbsl_recver_flush_output_data(tbsl);
    int drop_data = 0;
    // 丢帧处理只针对选择性丢包模式
    if (tbsl->mode == kj_tbsl_loss_selectively) {
        uint32_t lately_time = 0;
//        char info[150];
        kj_data *data = tbsl->recver.stash_data_queue.prev;
        while (data != &tbsl->recver.stash_data_queue) {
            if (data->media_meta->frame_begin) {
                if (lately_time) {
                    uint32_t time_stamp = data->media_meta->time_stamp;
                    // 最后的包比最早的包时间已大于最大缓存的数据时间，丢弃最早的数据
                    if (lately_time > time_stamp && (lately_time - time_stamp > tbsl->recver.max_data_interval)) {
                        drop_data = 1;
                        while (data != &tbsl->recver.stash_data_queue) {
                            
//                            kj_data_get_info(node->data, info, 150);
//                            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_WARN,"tbsl:ch=%d,av=%d;drop data=%s",tbsl->channel,tbsl->av_type,info);
                            
                            kj_data *prev = data->prev;
                            KJ_NODE_REMOVE(data);
                            kj_data_free(data);
                            if (tbsl->recver.stash_count > 0) {
                                tbsl->recver.stash_count--;
                            }
                            
                            kj_tbsl_recver_reduction_total_recv_count(tbsl);
                            data = prev;
                        }
                        break;
                    }
                } else {
                    lately_time = data->media_meta->time_stamp;
                }
            }
            data = data->prev;
        }
    }
    if (drop_data) {
        // 清空输出区数据
        kj_tbsl_wipe_output_data(tbsl);
        // 从暂存的数据链的第一个包输出连续的包
        kj_data *data = tbsl->recver.stash_data_queue.next;
        if (data != &tbsl->recver.stash_data_queue) {
            tbsl->recver.next_seq = data->media_meta->sequence;
            while (data != &tbsl->recver.stash_data_queue) {
                if (data->media_meta->sequence == tbsl->recver.next_seq) {
                    kj_data *next_data = data->next;
                    KJ_NODE_REMOVE(data);
                    if (tbsl->recver.output_head) {
                        tbsl->recver.output_tail->next = data;
                    } else {
                        tbsl->recver.output_head = data;
                    }
                    tbsl->recver.output_tail = data;
                    tbsl->recver.next_seq++;
                    data = next_data;
                } else {
                    break;
                }
            }
            kj_tbsl_recver_flush_output_data(tbsl);
        }
        // 移除小于首个包序号的待重传序号
        int32_t last_data_seq = -1;
        int last_data_seq_is_bigger_than_next_seq = 0;
        data = tbsl->recver.stash_data_queue.prev;
        if (data != &tbsl->recver.stash_data_queue) {
            last_data_seq = data->media_meta->sequence;
            last_data_seq_is_bigger_than_next_seq = last_data_seq > tbsl->recver.next_seq;
        }
        kj_lost_seq_node *seq = tbsl->recver.lost_seq_node.next;
        while (seq != &tbsl->recver.lost_seq_node) {
            kj_lost_seq_node *next = seq->next;
            if (last_data_seq == -1 || seq->ack_times >= KJ_MAX_ACK_TIMES) {
                
//                kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_WARN,"tbsl:ch=%d,av=%d;recv-lost=%d",tbsl->channel,tbsl->av_type,seq->sequence);

                // 没有暂存数据了，可移除全部记录的丢包序号
                KJ_NODE_REMOVE_AND_FREE(seq);
                if (tbsl->recver.lost_count > 0) {
                    tbsl->recver.lost_count--;
                }
                kj_tbsl_recver_reduction_total_lost_count(tbsl);
            } else {
                if (last_data_seq_is_bigger_than_next_seq) {
                    // 暂存数据中最后一个的序号大于应到序号，那么丢失序号小于应到序号或者大于最后一个暂存数据序号需移除
                    if (seq->sequence < tbsl->recver.next_seq || seq->sequence > last_data_seq) {
                        
//                        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_WARN,"tbsl:ch=%d,av=%d;recv-lost=%d",tbsl->channel,tbsl->av_type,seq->sequence);

                        KJ_NODE_REMOVE_AND_FREE(seq);
                        if (tbsl->recver.lost_count > 0) {
                            tbsl->recver.lost_count--;
                        }
                        kj_tbsl_recver_reduction_total_lost_count(tbsl);
                    }
                } else {
                    // 暂存数据中最后一个的序号小于应到序号，那么丢失序号小于应到序号且大于最后一个暂存数据序号需移除
                    if (seq->sequence < tbsl->recver.next_seq && seq->sequence > last_data_seq) {
                        
//                        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_WARN,"tbsl:ch=%d,av=%d;recv-lost=%d",tbsl->channel,tbsl->av_type,seq->sequence);

                        KJ_NODE_REMOVE_AND_FREE(seq);
                        if (tbsl->recver.lost_count > 0) {
                            tbsl->recver.lost_count--;
                        }
                        kj_tbsl_recver_reduction_total_lost_count(tbsl);
                    }
                }
            }
            seq = next;
        }
    }
}
void kj_tbsl_recver_add_data(kj_tbsl *tbsl, kj_data *data) {
    // 记录最新数据到达的时间和数据包个数
    tbsl->recver.newest_recv_time = kj_time_get_current();
    tbsl->recver.total_recv_count++;
    // 数据处理
    kj_data *new_data = kj_data_copy(data);
    new_data->next = NULL;
    uint16_t data_seq = new_data->media_meta->sequence;
    // 查找是否是此前丢失的包，如是则从待重传的链移除
    kj_lost_seq_node *seq_cursor = tbsl->recver.lost_seq_node.next;
    while (seq_cursor != &tbsl->recver.lost_seq_node) {
        if (seq_cursor->sequence == data_seq) {
            uint8_t ack_seq = new_data->reserved;
//            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG,"tbsl:ch=%d,av=%d;recv missed;data ack_seq=%d,ack_seq=%d,ack_seq_sent=%d",tbsl->channel,tbsl->av_type,ack_seq,tbsl->recver.ack_seq,tbsl->recver.ack_seq_sent);
            
            if (ack_seq > 0) {
                // 重发的数据
                if (ack_seq == seq_cursor->ack_seq || ack_seq == tbsl->recver.ack_seq_sent) {
                    kj_tbsl_calculate_rtt_base_on_ack_seq_of_recv_data(tbsl);
                }
            }
            // 记录为丢包的数据到达后移除丢包号和个数减一
            KJ_NODE_REMOVE_AND_FREE(seq_cursor);
            tbsl->recver.lost_count == 0 ? : tbsl->recver.lost_count--;
            kj_tbsl_recver_reduction_total_lost_count(tbsl);
            break;
        } else {
            seq_cursor = seq_cursor->next;
        }
    }
    // 确认首包的序号，以计算后续的丢包序号
    if (tbsl->recver.got_begin_data == 0 && tbsl->mode == kj_tbsl_loss_selectively) {
        tbsl->recver.got_begin_data = 1;
        tbsl->recver.next_seq = data_seq;
        
//        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_INFO,"tbsl:ch=%d,av=%d;recv first mode=%d,data=%s",tbsl->channel,tbsl->av_type,tbsl->mode,info);
    } else if (tbsl->recver.got_begin_data == 0 && (data_seq == 0 || data_seq == tbsl->recver.next_seq)) {
        tbsl->recver.got_begin_data = 1;
        tbsl->recver.next_seq = data_seq;

//        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_INFO,"tbsl:ch=%d,av=%d;recv first mode=%d,data=%s",tbsl->channel,tbsl->av_type,tbsl->mode,info);
    }
    // 根据包序号处理是否入数据环链
    if (data_seq == tbsl->recver.next_seq) {
        tbsl->recver.allow_ack = 1;
        tbsl->recver.next_seq = data_seq + 1;
        // 该包为上一个包的下一个，放到输出数据链
        if (tbsl->recver.output_head) {
            tbsl->recver.output_tail->next = new_data;
        } else {
            tbsl->recver.output_head = new_data;
        }
        tbsl->recver.output_tail = new_data;
        // 查找此前到达的包是否在该包后面，转移到输出数据链
        kj_data *data = tbsl->recver.stash_data_queue.next;
        while (data != &tbsl->recver.stash_data_queue) {
            if (data->media_meta->sequence == tbsl->recver.next_seq) {
                new_data = data;
                data = data->next;
                KJ_NODE_REMOVE(new_data);
                if (tbsl->recver.stash_count > 0) {
                    tbsl->recver.stash_count--;
                }
                tbsl->recver.output_tail->next = new_data;
                tbsl->recver.output_tail = new_data;
                tbsl->recver.next_seq++;
            } else {
                break;
            }
        }
//        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG,"tbsl:ch=%d,av=%d;recv-output=%s",tbsl->channel,tbsl->av_type,info);
    } else {
        // 不为预期的下一个包，暂存包，并计算丢失的包
        uint16_t diff = data_seq - tbsl->recver.next_seq;
        if (diff <= KJ_TBSL_HALF_MAX_SEQ) {
            // 到达与应到差值小于等于最大值的一半，证明到达数据为应到数据更晚的数据，将数据从早到晚的顺序入列
            tbsl->recver.allow_ack = 1;
            kj_data *tail_data = tbsl->recver.stash_data_queue.prev;
            uint16_t stash_position_seq = 0;
            if (tail_data == &tbsl->recver.stash_data_queue) {
                // 当前无暂存数据，添加入列尾
                KJ_NODE_ADD_BEHIND(tail_data, new_data);
                tbsl->recver.stash_count = 1;
                // 添加新增丢失包序号
                kj_tbsl_recver_add_lost_sequence(tbsl, tbsl->recver.next_seq, data_seq);
            } else {
                stash_position_seq = tail_data->media_meta->sequence;
                uint16_t seq_after_node_tail_seq = stash_position_seq + 1;
                while (tail_data != &tbsl->recver.stash_data_queue) {
                    stash_position_seq = tail_data->media_meta->sequence;
                    if (data_seq == stash_position_seq) {
                        // 重复发送的数据丢弃
                        kj_data_free(new_data);
                        new_data = NULL;
                        break;
                    } else {
                        // 按最早发送的数据在头，最晚在尾存储
                        if (data_seq > tbsl->recver.next_seq) {
                            if (data_seq > stash_position_seq && stash_position_seq > tbsl->recver.next_seq) {
                                KJ_NODE_ADD_BEHIND(tail_data, new_data);
                                tbsl->recver.stash_count++;
                                new_data = NULL;
                                break;
                            }
                        } else {
                            if ((data_seq > stash_position_seq && stash_position_seq < tbsl->recver.next_seq) || (data_seq < stash_position_seq && stash_position_seq > tbsl->recver.next_seq)) {
                                KJ_NODE_ADD_BEHIND(tail_data, new_data);
                                tbsl->recver.stash_count++;
                                new_data = NULL;
                                break;
                            }
                        }
                    }
                    tail_data = tail_data->prev;
                }
                // 数据为最早的数据
                if (new_data) {
                    tail_data = &tbsl->recver.stash_data_queue;
                    KJ_NODE_ADD_BEHIND(tail_data, new_data);
                    tbsl->recver.stash_count++;
                    stash_position_seq = 0;
                }

                // 到达数据比暂存的最晚的数据要晚，则计算添加新增丢失包序号
                if (data_seq > tbsl->recver.next_seq) {
                    if (data_seq > seq_after_node_tail_seq && seq_after_node_tail_seq > tbsl->recver.next_seq) {
                        kj_tbsl_recver_add_lost_sequence(tbsl, seq_after_node_tail_seq, data_seq);
                    }
                } else {
                    if (data_seq > seq_after_node_tail_seq || seq_after_node_tail_seq > tbsl->recver.next_seq) {
                        kj_tbsl_recver_add_lost_sequence(tbsl, seq_after_node_tail_seq, data_seq);
                    }
                }
            }
            // stash log
//            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG,"tbsl:ch=%d,av=%d;recv-after=%d,data=%s",tbsl->channel,tbsl->av_type,stash_position_seq,info);
        } else {
            // 到达与应到差值大于最大值的一半，证明到达数据为应到数据前面的数据，判断为重发而不需要的数据，因此抛弃该数据
            kj_data_free(new_data);
//            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG,"tbsl:ch=%d,av=%d;recv-drop=%s",tbsl->channel,tbsl->av_type,info);
        }
    }
}
void kj_tbsl_recver_ctl_data(kj_tbsl *tbsl, const kj_data *data) {
    char container[data->length];
    kj_tbsl_ack_data *ack_data = (kj_tbsl_ack_data *)container;
    memcpy(ack_data, data->raw_data, data->length);
//    tbsl->mode = ack_data->tbsl_mode;
    ack_data->channel = ntohs(ack_data->channel);
    ack_data->uint_va1 = ntohs(ack_data->uint_va1);
    ack_data->uint_va2 = ntohs(ack_data->uint_va2);
    if (tbsl->mode == kj_tbsl_loss_selectively) { // 丢包模式
        if (ack_data->ctl_type == kj_tbsl_ctl_send_buf_time) {
            // 需大于默认值才更新
            if (ack_data->uint_va1 > KJ_TBSL_DEFAULT_STASH_MAX_INTERVAL) {
                tbsl->recver.max_data_interval = ack_data->uint_va1;
            }
        }
    } else if (tbsl->mode > kj_tbsl_loss_selectively) { // 无丢包模式
        if (ack_data->ctl_type == kj_tbsl_ctl_recv_ack) {
            tbsl->sender.win_size = ack_data->uint_va2;
            ack_data->seq_count = ntohs(ack_data->seq_count);
            uint16_t seq_count = ack_data->seq_count;
            for (uint16_t i = 0; i < seq_count; i++) {
                ack_data->seqs[i] = ntohs(ack_data->seqs[i]);
            }
            uint16_t delete_seq = ack_data->uint_va1 - 1;
            int delete_the_left = 0;
            pthread_mutex_lock(&tbsl->sender.send_mutex);
            kj_data *tail_data = tbsl->sender.sending_data_queue.prev;
            kj_data *node_prev = NULL;
            while (tail_data != &tbsl->sender.sending_data_queue) {
                node_prev = tail_data->prev;
                if (delete_the_left) {
                    kj_tbsl_sender_remove_and_free_data(tbsl, tail_data);
                } else if (tail_data->media_meta->sequence == delete_seq) {
                    kj_tbsl_sender_remove_and_free_data(tbsl, tail_data);
                    delete_the_left = 1;
                } else {
                    int is_equal = 0;
                    for (uint16_t i = 0; i < seq_count; i++) {
                        uint16_t seq = ack_data->seqs[i];
                        if (tail_data->media_meta->sequence == seq) {
                            kj_tbsl_sender_remove_and_free_data(tbsl, tail_data);
                            is_equal = 1;
                            break;
                        }
                    }
                    if (!is_equal) {
                        tail_data->reserved = ack_data->ack_seq;
                        tbsl->send_cb(tbsl, tail_data);
                    }
                }
                tail_data = node_prev;
            }
            pthread_cond_signal(&tbsl->sender.send_cond);
            pthread_mutex_unlock(&tbsl->sender.send_mutex);
        } else if (ack_data->ctl_type == kj_tbsl_ctl_recv_finish) {
            kj_tbsl_sender_wipe_sending_data(tbsl);
        } else if (ack_data->ctl_type == kj_tbsl_ctl_send_pause) {
            if (ack_data->ack_seq == tbsl->recver.ack_seq_sent) {
                // 因暂停信令可能比暂停后发送的数据晚到，在晚到的情况下不能暂停反馈
                tbsl->recver.allow_ack = 0;
                kj_tbsl_calculate_rtt_base_on_ack_seq_of_recv_data(tbsl);
            }
        } else if (ack_data->ctl_type == kj_tbsl_ctl_send_finish) {
            uint16_t end_seq = ack_data->uint_va1;
            tbsl->recver.end_seq = end_seq;
            if (tbsl->recver.next_seq - end_seq == 1) {
                // 输出该段数据传输完成的标志数据
                kj_media_meta meta_end = kj_data_create_media_meta();
                meta_end.av_type = tbsl->av_type;
                meta_end.channel = tbsl->channel;
                meta_end.sequence = tbsl->recver.next_seq;
                meta_end.frame_begin = 1;
                meta_end.frame_end = 1;
                kj_data data_end = kj_data_create();
                data_end.type = kj_data_type_tbsl;
                data_end.method = kj_data_method_tbsl_recv_finish;
                data_end.length = 0;
                data_end.media_meta = &meta_end;
                tbsl->recv_cb(tbsl, &data_end);
                
                // 下个应到序号与结束序号相差1，则确认已全部接收完毕
                size_t tbsl_ack_length = kj_tbsl_recver_get_ack_data_size_with_sequence_count(0);
                char container[tbsl_ack_length];
                kj_tbsl_ack_data *tbsl_ack = (kj_tbsl_ack_data *)container;
                tbsl_ack->channel = tbsl->channel;
                tbsl_ack->av_type = tbsl->av_type;
                tbsl_ack->tbsl_mode = tbsl->mode;
                tbsl_ack->ack_seq = ack_data->ack_seq;
                tbsl_ack->ctl_type = kj_tbsl_ctl_recv_finish;
                tbsl_ack->channel = htons(tbsl_ack->channel);
                
                kj_data data_send = kj_data_create();
                data_send.type = kj_data_type_tbsl;
                data_send.method = kj_data_method_tbsl;
                data_send.length = tbsl_ack_length;
                data_send.raw_data = (void *)tbsl_ack;
                tbsl->send_cb(tbsl, &data_send);
                kj_tbsl_reset(tbsl);
            }
        }
    }
//    kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_INFO,"tbsl:ch=%d,av=%d;control mode=%d,ack_type=%d,uint1=%d,ctrl_seq=%d",tbsl->channel,tbsl->av_type,ack_data->tbsl_mode,ack_data->ack_type,ack_data->uint_va1,ack_data->ack_seq);
}

#pragma mark - 接收端定时执行反馈数据接收丢包情况

uint8_t kj_tbsl_get_new_ack_seq(kj_tbsl *tbsl) {
    uint8_t seq = 0;
    if (tbsl) {
        seq = ++tbsl->recver.ack_seq;
        if (seq == 0) {
            seq = 1;
            tbsl->recver.ack_seq = seq;
        }
        tbsl->recver.ack_seq_sent = seq;
        tbsl->recver.ack_time = kj_time_get_current();
    }
    return seq;
}
int kj_tbsl_lossless_is_time_to_ack(kj_tbsl *tbsl, kj_time cur_time) {
    int is_allow_ack = 1;
    // 控速传输需计算已取得的数据时间是否小于现实世界已过去的时间加需要多出的时间，如小于则请求新的数据（即比播放时间多缓存些数据）
    if (tbsl->mode == kj_tbsl_lossless_throttle) {
        // 最新的数据时间与最早数据时间间隔
        size_t data_time = tbsl->recver.last_frame_time_stamp - tbsl->recver.first_frame_time_stamp;
        // 当前时间与输出第一帧数据的时间间隔
        size_t passed_time = kj_time_interval_between(tbsl->recver.first_frame_output_time, cur_time);
        /* 数据时间突然增加超过两倍或实际时间超过两倍，则认为异常
           需重新设置两者的时间起点（拖拽视频、暂停视频、更改系统时间等造成的时间差异常）
         */
        size_t interval = data_time > passed_time ? data_time - passed_time : passed_time - data_time;
        if (interval > 2 * KJ_TBSL_DEFAULT_THROTTLE_INTERVAL) {
            tbsl->recver.last_frame_time_stamp = 0;
            tbsl->recver.first_frame_time_stamp = 0;
            tbsl->recver.first_frame_output_time = cur_time;
        } else if (data_time > passed_time && (data_time - passed_time > KJ_TBSL_DEFAULT_THROTTLE_INTERVAL)) {
            is_allow_ack = 0;
        }
    }
    return is_allow_ack;
}
void kj_tbsl_update_recv_ack(kj_tbsl *tbsl) {
    kj_time cur_time = kj_time_get_current();
    if (kj_tbsl_lossless_is_time_to_ack(tbsl, cur_time)) {
        uint16_t max_seq_count = tbsl->recver.win_size > KJ_MAX_SEQ_COUNT_PER_TIME ? KJ_MAX_SEQ_COUNT_PER_TIME : tbsl->recver.win_size;
        uint8_t ack_seq = 0;
        uint16_t seq_count = 0;
        uint16_t ack_seqs[max_seq_count];
        size_t interval = kj_time_interval_between(tbsl->recver.newest_recv_time, cur_time);
        
        if (interval >= tbsl->rtt) { // 超时没有新数据来，取接收窗口内收到的数据序号
            size_t double_default_rtt = KJ_TBSL_DEFAULT_RTT * 2;
            tbsl->rtt = interval > double_default_rtt ? double_default_rtt : interval;
            ack_seq = kj_tbsl_get_new_ack_seq(tbsl);
            
            kj_data *data = tbsl->recver.stash_data_queue.next;
            uint16_t compress_seq[3];
            int adjoin_seq_count = 0;
            uint16_t prev_seq = 0;
            if (data != &tbsl->recver.stash_data_queue) {
                prev_seq = data->media_meta->sequence;
            }
            
            while (data != &tbsl->recver.stash_data_queue && seq_count < max_seq_count) {
                uint16_t seq = data->media_meta->sequence;
                if (seq - tbsl->recver.win_begin < tbsl->recver.win_size) {
                    // 序号压缩：出现四个或以上连续的序号即可压缩，即1、2、3、4可压缩为1、1、4
                    if (seq - prev_seq == 1) {
                        if (adjoin_seq_count > 2) {
                            compress_seq[1] = compress_seq[0];
                            adjoin_seq_count = 2;
                        }
                        compress_seq[adjoin_seq_count] = seq;
                        adjoin_seq_count++;
                    } else {
                        for (int i = 0; i < adjoin_seq_count; i++) {
                            
//                            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG, "tbsl:ch=%d,av=%d;%d",tbsl->channel,tbsl->av_type,compress_seq[i]);

                            ack_seqs[seq_count] = htons(compress_seq[i]);
                            seq_count++;
                        }
                        compress_seq[0] = seq;
                        adjoin_seq_count = 1;
                    }
                    prev_seq = seq;
                    
//                    ack_seqs[seq_count] = htons(seq);
//                    seq_count++;
                } else {
                    break;
                }
                data = data->next;
            }
        } else {
            kj_data *data = tbsl->recver.stash_data_queue.prev;
            if (data != &tbsl->recver.stash_data_queue) {
                // 有暂存的数据，判断是否有到达窗口的数据，有则取窗口内的数据序号，无则等待超时处理
                while (data != &tbsl->recver.stash_data_queue) {
                    uint16_t last_seq = data->media_meta->sequence;
                    if (last_seq - tbsl->recver.win_begin == tbsl->recver.win_size - 1) {
                        ack_seq = kj_tbsl_get_new_ack_seq(tbsl);
                        data = tbsl->recver.stash_data_queue.next;
                        
                        uint16_t compress_seq[3];
                        int adjoin_seq_count = 0;
                        uint16_t prev_seq = data->media_meta->sequence;
                        
                        while (data != &tbsl->recver.stash_data_queue && seq_count < max_seq_count) {
                            uint16_t seq = data->media_meta->sequence;
                            if (seq - tbsl->recver.win_begin < tbsl->recver.win_size) {
                                // 序号压缩：出现四个或以上连续的序号即可压缩，即1、2、3、4可压缩为1、1、4
                                if (seq - prev_seq == 1) {
                                    if (adjoin_seq_count > 2) {
                                        compress_seq[1] = compress_seq[0];
                                        adjoin_seq_count = 2;
                                    }
                                    compress_seq[adjoin_seq_count] = seq;
                                    adjoin_seq_count++;
                                } else {
                                    for (int i = 0; i < adjoin_seq_count; i++) {
                                        
//                                        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG, "tbsl:ch=%d,av=%d;%d",tbsl->channel,tbsl->av_type,compress_seq[i]);

                                        ack_seqs[seq_count] = htons(compress_seq[i]);
                                        seq_count++;
                                    }
                                    compress_seq[0] = seq;
                                    adjoin_seq_count = 1;
                                }
                                prev_seq = seq;
                                
//                                ack_seqs[seq_count] = htons(seq);
//                                seq_count++;
                            } else {
                                break;
                            }
                            data = data->next;
                        }
                        break;
                    } else if (last_seq - tbsl->recver.win_begin < tbsl->recver.win_size) {
                        break;
                    }
                    data = data->prev;
                }
            } else if (tbsl->recver.next_seq - tbsl->recver.win_begin >= tbsl->recver.win_size) {
                // 没有暂存的数据，判断已完整接收完一个接收窗口的数据，则请求下一个窗口的数据
                ack_seq = kj_tbsl_get_new_ack_seq(tbsl);
            }
        }
        
        if (ack_seq != 0) {
            if ((tbsl->recver.end_seq != -1) && (tbsl->recver.next_seq - (uint16_t)tbsl->recver.end_seq == 1)) {
                // 已收到结束的数据
                size_t tbsl_ack_length = kj_tbsl_recver_get_ack_data_size_with_sequence_count(0);
                char container[tbsl_ack_length];
                kj_tbsl_ack_data *tbsl_ack = (kj_tbsl_ack_data *)container;
                tbsl_ack->channel = tbsl->channel;
                tbsl_ack->av_type = tbsl->av_type;
                tbsl_ack->tbsl_mode = tbsl->mode;
                tbsl_ack->ack_seq = ack_seq;
                tbsl_ack->ctl_type = kj_tbsl_ctl_recv_finish;
                tbsl_ack->channel = htons(tbsl_ack->channel);
                
                kj_data ack_data = kj_data_create();
                ack_data.type = kj_data_type_tbsl;
                ack_data.method = kj_data_method_tbsl;
                ack_data.length = tbsl_ack_length;
                ack_data.raw_data = (void *)tbsl_ack;
                tbsl->send_cb(tbsl, &ack_data);
                kj_tbsl_reset(tbsl);
            } else {
                // 未收到结束的数据
                size_t tbsl_ack_length = kj_tbsl_recver_get_ack_data_size_with_sequence_count(seq_count);
                char container[tbsl_ack_length];
                kj_tbsl_ack_data *tbsl_ack = (kj_tbsl_ack_data *)container;
                tbsl_ack->channel = tbsl->channel;
                tbsl_ack->av_type = tbsl->av_type;
                tbsl_ack->tbsl_mode = tbsl->mode;
                tbsl_ack->ack_seq = ack_seq;
                tbsl_ack->ctl_type = kj_tbsl_ctl_recv_ack;
                tbsl_ack->seq_count = seq_count;
                if (seq_count > 0) {
                    memcpy(tbsl_ack->seqs, ack_seqs, seq_count * sizeof(tbsl_ack->seqs));
                }
                // 动态更新窗口
//                if (seq_count == 0 && (tbsl->next_seq == tbsl->win_begin + tbsl->recv_win_size)) {
//                    tbsl->loss_count = 0;
//                    tbsl->lossless_count++;
//                    if (tbsl->lossless_count % 2 == 0) {
//                        tbsl->recv_win_size += (uint16_t)pow(2,(tbsl->lossless_count / 2));
//                    }
//                } else {
//                    tbsl->lossless_count = 0;
//                    tbsl->loss_count++;
//                    if ((tbsl->loss_count % 2 == 0) && tbsl->next_seq != tbsl->win_begin) {
//                        tbsl->recv_win_size = tbsl->next_seq - tbsl->win_begin + seq_count;
//                    }
//                }
//                if (tbsl->recv_win_size > KJ_TBSL_MAX_RECV_WIN_SIZE) {
//                    tbsl->recv_win_size = KJ_TBSL_MAX_RECV_WIN_SIZE;
//                } else if (tbsl->recv_win_size < KJ_TBSL_MIN_RECV_WIN_SIZE) {
//                    tbsl->recv_win_size = KJ_TBSL_MIN_RECV_WIN_SIZE;
//                }
                // 更新窗口起始值
                tbsl->recver.win_begin = tbsl->recver.next_seq;
                tbsl_ack->uint_va1 = tbsl->recver.win_begin;
                tbsl_ack->uint_va2 = tbsl->recver.win_size;
                
//                kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_INFO,"tbsl:ch=%d,av=%d;above seqs is received,begin=%d,size=%d,count=%d,ack_seq=%d",tbsl->channel,tbsl->av_type,tbsl_ack->uint_va1,tbsl_ack->uint_va2,seq_count,ack_seq);
                
                // 网络字节序
                tbsl_ack->channel = htons(tbsl_ack->channel);
                tbsl_ack->uint_va1 = htons(tbsl_ack->uint_va1);
                tbsl_ack->uint_va2 = htons(tbsl_ack->uint_va2);
                tbsl_ack->seq_count = htons(tbsl_ack->seq_count);
                // 设置丢包序号的ack_seq，用于重传的包到达后计算RTT
                kj_lost_seq_node *seq_cursor = tbsl->recver.lost_seq_node.next;
                while (seq_cursor != &tbsl->recver.lost_seq_node) {
                    seq_cursor->ack_seq = tbsl_ack->ack_seq;
                    seq_cursor = seq_cursor->next;
                }
                // 发送数据接收反馈信息数据
                kj_data ack_data = kj_data_create();
                ack_data.type = kj_data_type_tbsl;
                ack_data.method = kj_data_method_tbsl;
                ack_data.length = tbsl_ack_length;
                ack_data.raw_data = (void *)tbsl_ack;
                tbsl->send_cb(tbsl, &ack_data);
            }
        }
    }
}
void kj_tbsl_update_recv_nack(kj_tbsl *tbsl) {
    if (tbsl->recver.lost_count > 0) {
        uint16_t max_seq_count = tbsl->recver.lost_count > KJ_MAX_SEQ_COUNT_PER_TIME ? KJ_MAX_SEQ_COUNT_PER_TIME : tbsl->recver.lost_count;
        kj_time cur_time = kj_time_get_current();
        uint16_t seq_count = 0;
        uint8_t ctrl_seq = 0;
        uint16_t nack_seqs[max_seq_count];
        kj_lost_seq_node *seq_node = tbsl->recver.lost_seq_node.next;
        
        uint16_t compress_seq[3];
        int adjoin_seq_count = 0;
        uint16_t prev_seq = seq_node->sequence;
        while (seq_node != &tbsl->recver.lost_seq_node && seq_count < max_seq_count) {
            size_t interval = kj_time_interval_between(seq_node->time_stamp, cur_time);
            if (seq_node->ack_times < KJ_MAX_ACK_TIMES && interval >= tbsl->rtt) {
                if (ctrl_seq == 0) {
                    ctrl_seq = kj_tbsl_get_new_ack_seq(tbsl);
                }
                seq_node->ack_seq = ctrl_seq;
                seq_node->time_stamp = cur_time;
                seq_node->ack_times++;
                uint16_t seq = seq_node->sequence;
                
                // 序号压缩：出现四个或以上连续的序号即可压缩，即1、2、3、4可压缩为1、1、4
                if (seq - prev_seq == 1) {
                    if (adjoin_seq_count > 2) {
                        compress_seq[1] = compress_seq[0];
                        adjoin_seq_count = 2;
                    }
                    compress_seq[adjoin_seq_count] = seq;
                    adjoin_seq_count++;
                } else {
                    for (int i = 0; i < adjoin_seq_count; i++) {
                        
//                        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG, "tbsl:ch=%d,av=%d;%d",tbsl->channel,tbsl->av_type,compress_seq[i]);

                        nack_seqs[seq_count] = htons(compress_seq[i]);
                        seq_count++;
                    }
                    compress_seq[0] = seq;
                    adjoin_seq_count = 1;
                }
                prev_seq = seq;
                
            }
            seq_node = seq_node->next;
        }
        // 处理循环未处理的剩余序号
        for (int i = 0; i < adjoin_seq_count; i++) {
            
//            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_DEBUG, "tbsl:ch=%d,av=%d;%d",tbsl->channel,tbsl->av_type,compress_seq[i]);

            nack_seqs[seq_count] = htons(compress_seq[i]);
            seq_count++;
        }
        if (seq_count > 0) {
            size_t tbsl_nack_length = kj_tbsl_recver_get_ack_data_size_with_sequence_count(seq_count);
            char container[tbsl_nack_length];
            kj_tbsl_ack_data *tbsl_nack = (kj_tbsl_ack_data *)container;
            tbsl_nack->channel = tbsl->channel;
            tbsl_nack->av_type = tbsl->av_type;
            tbsl_nack->tbsl_mode = tbsl->mode;
            tbsl_nack->ctl_type = kj_tbsl_ctl_recv_ack;
            tbsl_nack->ack_seq = ctrl_seq;
            tbsl_nack->seq_count = seq_count;
            memcpy(tbsl_nack->seqs, nack_seqs, seq_count * sizeof(tbsl_nack->seqs));
            tbsl_nack->channel = htons(tbsl_nack->channel);
            tbsl_nack->seq_count = htons(tbsl_nack->seq_count);

            kj_data nack_data = kj_data_create();
            nack_data.type = kj_data_type_tbsl;
            nack_data.method = kj_data_method_tbsl;
            nack_data.length = tbsl_nack_length;
            nack_data.raw_data = (void *)tbsl_nack;
            tbsl->send_cb(tbsl, &nack_data);
            
//            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_INFO,"tbsl:ch=%d,av=%d;above retrans seq,count=%d,length=%d",tbsl->channel,tbsl->av_type,seq_count,tbsl_nack_length);
        }
    }
}
void kj_tbsl_recv_ack(kj_tbsl *tbsl) {
    if (tbsl && tbsl->send_cb) {
        if (tbsl->mode == kj_tbsl_loss_selectively) {
            kj_tbsl_update_recv_nack(tbsl);
        } else if (tbsl->mode == kj_tbsl_lossless || tbsl->mode == kj_tbsl_lossless_throttle) {
            kj_tbsl_update_recv_ack(tbsl);
        } else {
//            kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_ERROR,"tbsl:ch=%d,av=%d;tbsl_mode is not support ack mode=%d",tbsl->channel,tbsl->av_type,tbsl->mode);
        }
    } else {
//        kj_log_write(KJ_LOG_MODULE_TBSL, KJ_LOG_LEVEL_ERROR,"tbsl:ch=%d,av=%d;paras error send_cb=%p",tbsl->channel,tbsl->av_type,tbsl->send_cb);
    }
}
#pragma mark - 定时回馈子线程回调
void cb_tbsl_ack_timer_task_excuting_callback(const kj_timer *timer, kj_timer_task *task) {
    kj_tbsl *tbsl = (kj_tbsl *)task->user_data;
    if (tbsl->mode > kj_tbsl_in_order) {
        if (tbsl->recver.allow_ack) {
            if (tbsl->mode == kj_tbsl_lossless_throttle) {
                kj_tbsl_recv_ack(tbsl);
            } else {
                kj_time cur_time = kj_time_get_current();
                size_t interval = kj_time_interval_between(tbsl->recver.ack_time, cur_time);
                if (interval > tbsl->rtt) {
                    kj_tbsl_recv_ack(tbsl);
                } else {
//                    task->interval = tbsl->rtt - interval;
                }
            }
            task->interval = tbsl->rtt;
        } else {
            task->interval = tbsl->rtt > KJ_TBSL_DEFAULT_RTT ? tbsl->rtt : KJ_TBSL_DEFAULT_RTT;
        }
    }
}

#pragma mark - public api
kj_tbsl *kj_tbsl_create(kj_tbsl_mode mode, kj_tbsl_recv_callback recv_cb, kj_tbsl_send_callback send_cb) {
    kj_tbsl *tbsl = calloc(1, sizeof(kj_tbsl));
    tbsl->mode = mode;
    tbsl->recv_cb = recv_cb;
    tbsl->send_cb = send_cb;
    tbsl->rtt = KJ_TBSL_DEFAULT_RTT;
    // 无丢包模式需要创建回馈子线程主动回复接收情况
    if (mode > kj_tbsl_loss_selectively) {
        kj_timer_init_task(&tbsl->recver.ack_timer_task, tbsl, tbsl->rtt, 1, cb_tbsl_ack_timer_task_excuting_callback);
        kj_timer_schedule_task(kj_timer_global(), tbsl->recver.ack_timer_task);
    }
    // 接收
    tbsl->recver.next_seq = 0;
    tbsl->recver.max_data_interval = KJ_TBSL_DEFAULT_STASH_MAX_INTERVAL;
    tbsl->recver.win_size = KJ_TBSL_DEFAULT_RECV_WIN_SIZE;
    tbsl->recver.end_seq = -1;
    tbsl->recver.stash_count = 0;
    KJ_NODE_INIT(tbsl->recver.stash_data_queue);
    // 丢包
    tbsl->recver.lost_count = 0;
    KJ_NODE_INIT(tbsl->recver.lost_seq_node);
    // 发送
    tbsl->sender.win_size = KJ_TBSL_DEFAULT_SENT_CAPACITY;
    tbsl->sender.sent_count = 0;
    KJ_NODE_INIT(tbsl->sender.sending_data_queue);
    // 对端信息
    tbsl->sender.endpoint_win_size = tbsl->recver.win_size;
    pthread_cond_init(&tbsl->sender.send_cond, NULL);
    pthread_mutex_init(&tbsl->sender.send_mutex, NULL);
    return tbsl;
}
void kj_tbsl_destroy(kj_tbsl **tbsl) {
    if (*tbsl) {
        kj_tbsl *tbsl_destroy = *tbsl;
        *tbsl = NULL;
        // 销毁回馈定时器
        kj_timer_cancel_task(kj_timer_global(), tbsl_destroy->recver.ack_timer_task);
        // 清除数据
        kj_tbsl_reset(tbsl_destroy);
        // 销毁线程锁
        pthread_cond_destroy(&tbsl_destroy->sender.send_cond);
        pthread_mutex_destroy(&tbsl_destroy->sender.send_mutex);
        
        free(tbsl_destroy);
    }
}
void kj_tbsl_reset(kj_tbsl *tbsl) {
    if (tbsl) {
        tbsl->recver.ack_seq_sent = 0;
        tbsl->rtt = KJ_TBSL_DEFAULT_RTT;
        tbsl->recver.got_begin_data = 0;
        tbsl->recver.allow_ack = 0;
        tbsl->recver.first_frame_time_stamp = 0;
        tbsl->recver.miss_key_frame = 0;
        tbsl->recver.win_begin = 0;
        tbsl->recver.next_seq = 0;
        tbsl->recver.end_seq = -1;
        // 清除输出区数据
        kj_tbsl_wipe_output_data(tbsl);
        // 清除暂存区数据
        kj_tbsl_recver_wipe_stash_data(tbsl);
        // 清除丢包序号
        kj_tbsl_recver_wipe_lost_seq(tbsl);
        // 清除已发送数据
        kj_tbsl_sender_wipe_sending_data(tbsl);
    }
}
void kj_tbsl_send(kj_tbsl *tbsl, kj_data *data) {
    if (tbsl && tbsl->send_cb && data) {
        if (data->type == kj_data_type_media) {
            if (tbsl->mode > kj_tbsl_in_order) {
                // 复制数据
                kj_data *new_data = kj_data_copy(data);
                new_data->next = NULL;
                pthread_mutex_lock(&tbsl->sender.send_mutex);
                if (tbsl->sender.sent_count >= tbsl->sender.win_size) {
                    if (tbsl->mode == kj_tbsl_lossless || tbsl->mode == kj_tbsl_lossless_throttle) {
                        // 需要阻塞当前线程，等待接收方确认数据已收到移除缓存数据
                        pthread_cond_wait(&tbsl->sender.send_cond, &tbsl->sender.send_mutex);
                    } else {
                        // 缓存已满，移除环链头的数据
                        kj_data *abandon_data = tbsl->sender.sending_data_queue.next;
                        if (abandon_data != &tbsl->sender.sending_data_queue) {
                            kj_tbsl_sender_remove_and_free_data(tbsl, abandon_data);
                        }
                    }
                }
                // 添加新数据至环链尾
                kj_data *tail_data = tbsl->sender.sending_data_queue.prev;
                KJ_NODE_ADD_BEHIND(tail_data, new_data);
                tbsl->sender.sent_count++;
                pthread_mutex_unlock(&tbsl->sender.send_mutex);
                
                tbsl->send_cb(tbsl, new_data);
            } else {
                tbsl->send_cb(tbsl, data);
            }
        } else {
            tbsl->send_cb(tbsl, data);
        }
    }
}
void kj_tbsl_recv(kj_tbsl *tbsl, kj_data *data) {
    if (tbsl && data) {
        if (data->type == kj_data_type_media && data->media_meta) {
            if (tbsl->mode >= kj_tbsl_in_order) {
                kj_tbsl_recver_add_data(tbsl, data);
                kj_tbsl_recver_output_frame_data(tbsl);
                kj_tbsl_recv_ack(tbsl);
            } else {
                tbsl->recv_cb(tbsl, data);
            }
        } else if (data->type == kj_data_type_tbsl && data->method == kj_data_method_tbsl) {
            kj_tbsl_recver_ctl_data(tbsl, data);
        } else {
            tbsl->recv_cb(tbsl, data);
        }
    }
}
