//
//  kj_data_define.h
//  ios_demo
//
//  Created by twenty on 2021/1/27.
//

#ifndef kj_data_define_h
#define kj_data_define_h

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#if (defined(_WIN32) || defined(__WIN32__) || defined(_WIN64))
#include <winsock2.h>
#else
#include <arpa/inet.h>
#endif

#ifdef WIN32
#include <winsock.h>
#else
#include <arpa/inet.h>
#endif

#ifdef WIN32
#define KJ_EXPORT(type) __declspec(dllexport) type __stdcall
#else
#define KJ_EXPORT(type) type
#endif

#ifdef __cplusplus
#  define KJ_CPP_BEGIN  extern "C" {
#  define KJ_CPP_END    }
#else
#  define KJ_CPP_BEGIN
#  define KJ_CPP_END
#endif

#define KJ_STRUCT_ADD_NODE(type)\
type *prev;\
type *next

// 报文数据类型
typedef uint8_t kj_data_type;
// 报文方法值
typedef uint8_t kj_data_method;

// 媒体数据帧类型
typedef uint8_t kj_frame_type;
enum {
    kj_frame_type_p = 0,    // p帧
    kj_frame_type_i = 1     // i帧
};
// 媒体数据类型
typedef uint8_t kj_av_type;
enum {
    kj_av_type_video = 1,   // 视频
    kj_av_type_audio = 2    // 音频
};

 // 客户端与设备P2P和媒体TCP转发心跳保活
#define kj_data_type_keepalive_ask      0x00 // 设备与媒体转发的心跳请求类型
#define kj_data_type_keepalive_answer   0xff // 设备与媒体转发的心跳回复类型
#define kj_data_type_keepalive_signal   0x60 // 设备与信令的心跳类型

#define kj_data_method_keepalive_ask    0x00 // 心跳请求方法
#define kj_data_method_keepalive_answer 0xff // 心跳回复方法

// 可靠传输
#define kj_data_type_tbsl     0x01 // 可靠传输数据类型
#define kj_data_method_tbsl   0x01 // 可靠传输方法
#define kj_data_method_tbsl_recv_finish   0x03 // 无丢包传输完成一段数据的接收

// 视频播放
#define kj_data_type_play_video     0x23 // 实时或SD卡视频操作
#define kj_data_method_live_play    0x12 // 播放实时视频
#define kj_data_method_live_stop    0x14 // 停止实时视频
#define kj_data_method_ptp_talk_request 0x16    // P2P通道请求发送语音数据至设备
#define kj_data_method_ptp_talk_stop    0x18    // P2P通道告知设备停止向设备发送语音数据
#define kj_data_method_sd_play      0x22 // 播放SD卡视频
#define kj_data_method_sd_vod       0x24 // 播放SD卡视频的VOD命令
#define kj_data_method_sd_stop      0x26 // 停止SD卡视频
#define kj_data_method_disconnect   0x28 // 断开与设备的连接
#define kj_data_method_request_call 0x2A // 向对端请求音视频通话
#define kj_data_method_call_control 0x2C // 通话中向对端发送音视频控制信令
#define kj_data_method_end_call     0x2E // 告知对端结束音视频通话

// 云台控制
#define kj_data_type_ptz_control    0x34
#define kj_data_method_ptz_control  0x28
#define kj_data_method_ptz_preset   0x22

// 画面反转
#define kj_data_type_video_flip     0x34
#define kj_data_method_video_flip   0x1A

// SD卡功能
#define kj_data_type_sd_card            0x34
#define kj_data_method_sd_card_format   0x4C
#define kj_data_method_sd_card_info     0x4E
#define kj_data_method_sd_date_list     0x7A
#define kj_data_method_sd_video_list    0x7C

// 信令：发送sdp或relay
#define kj_data_type_signal_send_sdp_relay      0x64
#define kj_data_method_signal_send_sdp_relay    0x22
#define kj_data_method_signal_recv_sdp_relay    0x24
// 信令：登录
#define kj_data_type_signal_login   0x62
#define kj_data_method_signal_login 0x13

// 媒体数据类型
#define kj_data_type_media          0x50 // 媒体数据
#define kj_data_method_media_live   0x10 // 实时音视频数据
#define kj_data_method_media_sd     0x11 // SD卡音视频数据
#define kj_data_method_media_talk   0x13 // 实时对讲发向设备的音频数据
#define kj_data_method_media_live_forward   0x14 // 媒体转发的实时视频数据
#define kj_data_method_media_sd_forward     0x15 // 媒体转发的SD卡视频数据

// 媒体转发服务登录
#define kj_data_type_media_login    0x22 // 登录媒体服务
#define kj_data_method_media_login  0x18 // 登录媒体服务
#define kj_data_method_media_update_key     0x22 // 媒体服务更新加密key
// 媒体转发视频播放、对讲
#define kj_data_type_forward_play_video     0x22 // 媒体转发视频播放、对讲数据类型
#define kj_data_method_forward_play_live    0x24 // 播放实时视频
#define kj_data_method_forward_stop_live    0x26 // 停止实时视频
#define kj_data_method_forward_sd_play      0x40 // 播放SD卡视频
#define kj_data_method_forward_sd_stop      0x44 // 停止SD卡视频
#define kj_data_method_forward_sd_vod       0x48 // SD卡视频控制信令
#define kj_data_method_forward_talk_request 0x36 // 请求对讲
#define kj_data_method_forward_talk_stop    0x38 // 停止对讲

#endif /* kj_data_define_h */
