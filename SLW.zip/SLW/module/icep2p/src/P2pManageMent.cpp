
#include "P2pManageMent.h"
#include "p2p_connect.h"
#include "kj_timer.h"
#include <P2pManageMent.h>
#include "media_video.h"
#include "media_audio.h"
#include "record_api.h"
#include "media_playback.h"
#include "adpt_crypto_adapt.h"
#include "watchdog_api.h"
#include "p2p_avclient.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"

#ifdef BUILD_ONBROADCAST_FALG
#include "broadcast_api.h"
#include "AudioDeviceAPI.h"
#endif

static ST_TBSL_INFO stTbslRecvInfo = {0};

#define STUN_NAT_TYPE_NUMMAX (9)
#define STUN_NAT_MSG_NUMMAX (64)
static _UC ucStunNatType = P2P_NAT_TYPE_UNKNOWN;

unsigned char gstStunNatStatusMsg[STUN_NAT_TYPE_NUMMAX][STUN_NAT_MSG_NUMMAX] = {{"STUN_NAT_TYPE_UNKNOWN"},   
                                                                                {"STUN_NAT_TYPE_ERR_UNKNOWN"}, 
                                                                                {"STUN_NAT_TYPE_OPEN"},          
                                                                                {"STUN_NAT_TYPE_BLOCKED"},       
                                                                                {"STUN_NAT_TYPE_SYMMETRIC_UDP"},     
                                                                                {"STUN_NAT_TYPE_FULL_CONE"},
                                                                                {"STUN_NAT_TYPE_SYMMETRIC"},
                                                                                {"STUN_NAT_TYPE_RESTRICTED"},
                                                                                {"STUN_NAT_TYPE_PORT_RESTRICTED"}};    

/****************************************************************************************
设备发送SDP，接受平台回复接口函数
*****************************************************************************************/
static _INT P2p_DevSendSdpClientRsp(_UI uiReqId,_VPTR hRoot)
{
    MOS_PARAM_NULL_RETERR(hRoot);
    _UC aucBuf[128] = {0};
    MOS_VSNPRINTF(aucBuf, sizeof(aucBuf), "Recv Client(reqid:%u) Sdp Rsp Ok\n", uiReqId);
    CloudStg_UploadLogEx(Mos_GetSessionId(), __FUNCTION__, 0, EN_P2P_ERROR_CODE_SDP_SENDRSP_SUCCESS, aucBuf, MOS_NULL, 1);

    return MOS_OK;
}

/**
* @brief         Just fullfill msgFromTo  infos
* @author        Hejh
* @date          2021-05-13
*/
static _VOID P2p_AddMsgObjectToJson(_VPTR hRoot,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo)
{
    JSON_HANDLE hFromObject = MOS_NULL;
    JSON_HANDLE hToObject   = MOS_NULL;

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));
    if (MOS_STRLEN(pstMsgFromTo->aucDID) > 0)
    {
        hFromObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"FROM",hFromObject);
        Adpt_Json_AddItemToObject(hFromObject,(_UC*)"DID",Adpt_Json_CreateString(pstMsgFromTo->aucDID));
    }

    if (MOS_STRLEN(pstMsgFromTo->aucUserToken) > 0 || MOS_STRLEN(pstMsgFromTo->aucSvrID) > 0)
    {
        hToObject = Adpt_Json_CreateObject();
        if (MOS_STRLEN(pstMsgFromTo->aucUserToken) > 0)
        {
#ifdef SUPPORT_DEBUG_P2P
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"UserToken",Adpt_Json_CreateString(pstMsgFromTo->aucUserToken));
#else
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"ClientID",Adpt_Json_CreateString(pstMsgFromTo->aucUserToken));
#endif
        }
        if (MOS_STRLEN(pstMsgFromTo->aucSvrID) > 0)
        {
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"SvrID",Adpt_Json_CreateString(pstMsgFromTo->aucSvrID));
        }
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"TO",hToObject);
    }
    return;
}

/**
* @brief         package p2p link info response
* @author        Hejh
* @date          2021-11-19
*/
static _UC *Cmd_BuildP2pInfoMsgRsp(_UI uiSeqId, _UC ucSdpType, _UC *pucSdpInfo, ST_FROM_TO_MSG *pstMsgFromTo, ST_HTTP_ENCRYPTO_INF *trasEnc)
{
    _UC aucMethod[64]       = {0};
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBody       = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X", EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_DEV_SEND_SDP_REQ);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));

    P2p_AddMsgObjectToJson(hRoot, uiSeqId, pstMsgFromTo);
    hBody = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",   hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Type",Adpt_Json_CreateStrWithNum(ucSdpType));
    if (ucSdpType == EN_P2PMSG_IP_TYPE_V4_TYPE || ucSdpType == EN_P2PMSG_IP_TYPE_V6_TYPE)
    {
        if (pucSdpInfo != MOS_NULL)
        {
            Adpt_Json_AddItemToObject(hBody,(_UC*)"SDP",  Adpt_Json_CreateString(pucSdpInfo));
        }
    }
    if ((trasEnc!=MOS_NULL) && (trasEnc->iEncType != 0))
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(trasEnc->iEncType));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"EncKey", Adpt_Json_CreateString(trasEnc->aucEncKey));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"EncLoad",Adpt_Json_CreateString(trasEnc->aucEncLv));
    }

    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pucStrTmp;
}

P2pManageMent::P2pManageMent():m_hProcessCmd(P2pProcessCmd::instance())
{
    MOS_LIST_INIT(&m_hIceClientList);
    m_aucP2pTrasEnc.hCryptoCtx = MOS_NULL;
    m_aucP2pTrasEnc.iEncType   = EN_OGCT_ENCRYPT_LEVEL_NONE;
    MOS_MEMSET(m_aucP2pTrasEnc.aucEncKey, 0, sizeof(m_aucP2pTrasEnc.aucEncKey));
    MOS_MEMSET(m_aucP2pTrasEnc.aucEncLv,  0, sizeof(m_aucP2pTrasEnc.aucEncLv));
}

P2pManageMent::~P2pManageMent()
{ 
    MOS_LIST_RMVALL(&m_hIceClientList, MOS_TRUE);
}

static void pjLogWriterRelease(int level, const char *buffer, int len)
{
}

_VOID  P2pManageMent::InitP2p(_UC *deviceId)
{
    AvClient_P2pInfoInit();
    P2pProcessCmd::instance().InitReciveBuf();
    if (access("/tmp/debug_log", F_OK) != 0)
        pj_log_set_log_func(&pjLogWriterRelease);

    initLiveVideo();//video thread init
    initLiveAudio();//audio thread init
    initCommandFunctions();//register functions
}

_VOID  P2pManageMent::UninitP2p()
{
    //P2p_Task_Destroy();
    destoryLiveAudio();
    destoryLiveVideo();
    P2pProcessCmd::instance().DeniReciveBuf();
    Avclient_RemoveP2pInfo();
}

        
_VOID  P2pManageMent::StartP2p()
{ 
    startLiveVideo();
    startLiveAudio();
}
        
_VOID  P2pManageMent::StopP2p()
{
    stopLiveVideo();
    stopLiveAudio();
    stopAllLiveCmd();
    MOS_LIST_RMVALL(&MsgP2p_GetMng()->stActiveFunList, MOS_TRUE);
}

_VOID  P2pManageMent::DestoryP2p()
{
    destoryLiveVideo();
    destoryLiveAudio();
    //if (m_pUnchingManager != MOS_NULL)
    {
      //  MOS_FREE(m_pUnchingManager);
    }
}

ST_AVCLIENT_INFO *P2pManageMent::GetAvClient(_UC *aucPeerId)
{
    ST_AVCLIENT_INFO* pAvclient = MOS_NULL;
    if ( (pAvclient=findAvclientById(aucPeerId)) != MOS_NULL)
    {
    }
    else
    {
        ST_AVCLIENT_INFO *pstBufNode = (ST_AVCLIENT_INFO *)Mos_MallocClr(sizeof(ST_AVCLIENT_INFO));
        MOS_FUNRET_NULL_RETNULL(P2P_STRLOG, pstBufNode, Mos_MallocClr);
        Mos_MutexCreate(&pstBufNode->hMutex);
        MOS_STRNCPY(pstBufNode->m_uacPeerId, aucPeerId, sizeof(pstBufNode->m_uacPeerId));
        pstBufNode->m_iceTranSport    = MOS_NULL;
        pAvclient = pstBufNode;
    }
     return pAvclient;
}

_UC* P2pManageMent::onNewClientIceConnectTion(_UC *uacPeerId, _VPTR pstP2pMsgInfo)
{
    ST_AVCLIENT_INFO* pAvclient = GetAvClient(uacPeerId);
    ST_P2PTURN_ADDRINFO *pstP2pAddInfo = AvClient_GetTurnAddr(uacPeerId);
    if (pAvclient->m_iceTranSport == MOS_NULL)
    {
        pAvclient->m_iceTranSport   = pstP2pAddInfo;
        MOS_LIST_ADDTAIL(&m_hIceClientList, pAvclient);
        pstP2pAddInfo->pPrivateData = pAvclient;

        pAvclient->m_bChannelTimeOut = MOS_FALSE;
        kj_timer_init(&pAvclient->m_tReiveAudioDataTimeout);
        kj_timer_init(&pAvclient->m_tReiveVideoDataTimeout);
        initProcCommand(pAvclient);
    }

    getDiffTimems(&pstP2pAddInfo->tobjTimeout, 1, 0, 60*10);
    
    ST_P2P_CMDTASK_MSG *pstCmdMsg     = (ST_P2P_CMDTASK_MSG *)pstP2pMsgInfo;
    ST_CMTASK_P2PDATAINFO *p2pMsgInfo = (ST_CMTASK_P2PDATAINFO*)pstCmdMsg->aucMsgBody;
    _UI uiIsIpv6 = p2pMsgInfo->uiP2pInfoType == EN_P2PMSG_IP_TYPE_V6_TYPE ? 1 : 0;

    if (uiIsIpv6 == 1)
    {
        pstP2pAddInfo->pIceIpv6ReqInfo = pstP2pMsgInfo;
    }
    else
    {
        pstP2pAddInfo->pIceIpv4ReqInfo = pstP2pMsgInfo;
    }

    kj_rome_connect_endpoint(pstP2pAddInfo->pKjClienRome, p2pMsgInfo->aucRemoteSdpInfo, uiIsIpv6);
                                    
    return p2pMsgInfo->aucRemoteSdpInfo;
}

ST_AVCLIENT_INFO*  P2pManageMent::findAvclientById(_UC *uacPeerId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_AVCLIENT_INFO *pstAvClient = MOS_NULL;
    m_mutexAvclientList.rdLock();
    FOR_EACHDATA_INLIST(&m_hIceClientList, pstAvClient, stIterator)
    {
        if (MOS_STRCMP(pstAvClient->m_uacPeerId, uacPeerId) == 0)
        {
             break;
        }
    }
    m_mutexAvclientList.unlock();
    return pstAvClient;
}


/*关闭喇叭输出和视频显示输出
iNeedCloseLive: 是否一并关闭推流
iNeedCheckSessionId:是否开启SessionId检测（开启时，判断上一次是否同一个iSessionId，若不相同，则不关闭喇叭输出和视频显示输出）
iSessionId: 客户端连接ID
*/
_INT P2pManageMent::CloseClientSpeakerAndDisplay(_INT iNeedCloseLive, _INT iNeedCheckSessionId, _INT iSessionId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_AVCLIENT_INFO *pAvclient = MOS_NULL;

    m_mutexAvclientList.wrLock();
    FOR_EACHDATA_INLIST(&m_hIceClientList, pAvclient, stIterator)
    {
        Mos_MutexLock(&pAvclient->hMutex);

        if ((pAvclient->m_iceTranSport != MOS_NULL) && ((pAvclient->m_iceTranSport->m_audio_tbsl != MOS_NULL) || (pAvclient->m_iceTranSport->m_video_tbsl != MOS_NULL)))
        {

            if ((iNeedCheckSessionId == 0) || ((iNeedCheckSessionId == 1) && (iSessionId == pAvclient->m_iSessionId)))
            {
                _INT iChannelId     = 0;
                _INT iCameraId      = 0;
                _INT iMsgBuffLen    = 0;
                _UC *pStrTmp        = MOS_NULL;
                _UC aucMethod[8]    = {0};
                _UI  uiSeqId        = Mos_GetSessionId();

                JSON_HANDLE hRoot = Adpt_Json_CreateObject();
                MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPDISPLAY_REQ);
                Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
                Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));

                JSON_HANDLE hBody = Adpt_Json_CreateObject();
                Adpt_Json_AddItemToObject(hBody,(_UC*)"CamID",Adpt_Json_CreateStrWithNum(iCameraId));
                Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(pAvclient->m_sVideoDisplayChn));
                Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

                pStrTmp = Adpt_Json_Print(hRoot);
                Adpt_Json_Delete(hRoot);

                iMsgBuffLen = MOS_STRLEN(pStrTmp);
                P2pProcessCmd::instance().procCmdSendMsg((_HP2PCHANNEL)pAvclient, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPDISPLAY_REQ, pStrTmp, iMsgBuffLen);
                MOS_LOG_INF(P2P_STRLOG,"send close display resp method:%02X%02X msg:%s",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPDISPLAY_REQ, pStrTmp);
                MOS_FREE(pStrTmp);

                if (iNeedCloseLive == 1)
                {
                    pAvclient->m_bEnableVideo = 0;
                    pAvclient->m_bEnableAudio = 0;
                }

                if (pAvclient->m_bEnableSpeaker == MOS_TRUE)
                {
                    MOS_LOG_INF(P2P_STRLOG, "close p2p speaker!!");                
                    Media_AudioPlayCancelFrameBuff(MOS_NULL);
                    Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                    pAvclient->m_bEnableSpeaker  = MOS_FALSE;
                    Media_Notify_AudioPlay(pAvclient->m_uacPeerId, 1, pAvclient->m_bEnableSpeaker, pAvclient->m_sAudioSpeakChn);
                    Media_AudioPlayDestroyWriteHandle(pAvclient->m_hAudioPlay);
                    pAvclient->m_sAudioSpeakChn  =  0;
                    pAvclient->m_hAudioPlay = MOS_NULL;
                    #ifdef BUILD_ONBROADCAST_FALG
                    Broadcast_Task_Resume_CloseTalk();
                    #endif
                    P2pManageMent::instance().P2pDestroyTbsl((_VPTR)pAvclient, kj_av_type_audio);
                }

                if (pAvclient->m_bEnableDisplay == MOS_TRUE)
                {
                    MOS_LOG_INF(P2P_STRLOG, "close p2p display!!");                
                    Config_SetCamerDisplayOpenFlag(0, MOS_FALSE);
                    pAvclient->m_bEnableDisplay  = MOS_FALSE;
                    Media_Notify_VideoPlay(pAvclient->m_uacPeerId, pAvclient->m_bEnableDisplay);
                    Media_VideoDisPlayDestroyHandle(pAvclient->m_hVideoPlay);  
                    pAvclient->m_sVideoDisplayChn  =  0;
                    pAvclient->m_hVideoPlay = MOS_NULL;
                    Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
                    P2pManageMent::P2pDestroyTbsl((_VPTR)pAvclient, kj_av_type_video);
                }
            }
        }

        Mos_MutexUnLock(&pAvclient->hMutex);
    }    
    m_mutexAvclientList.unlock();

    return MOS_OK;
}

_INT P2pManageMent::checkClientTimeOut(_INT iForceQuit,_INT iNoNeedNotifyClose)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_AVCLIENT_INFO *pAvclient = MOS_NULL;
    _INT iHaveClinetTimeout     = 0;
    _INT iRetryCount            = 0;

    m_mutexAvclientList.wrLock();
    FOR_EACHDATA_INLIST(&m_hIceClientList, pAvclient, stIterator)
    {
        if ((pAvclient->m_bChannelTimeOut == MOS_TRUE) || (iForceQuit >= MOS_TRUE))
        {
            if (iNoNeedNotifyClose <= 0)
            {
                P2pProcessCmd::procCmdSendCloseSession((_HP2PCHANNEL)pAvclient);
            }
            iHaveClinetTimeout = 1;
            MOS_LIST_RMVNODE(&m_hIceClientList, pAvclient);

            MOS_LOG_INF(P2P_STRLOG,"client:%s is link timeout, remove now!! !!, if force quit:%d", pAvclient->m_uacPeerId, iForceQuit);
            P2pManageMent::instance().setClientCloseLiveAll((_HP2PCHANNEL)pAvclient);

            Mos_MutexLock(&pAvclient->hMutex);

            if (pAvclient->m_playBackThreadMng.ucInitFlag == 1)
            {
                if(pAvclient->m_playBackThreadMng.ucOverFlag > EN_P2P_THREAD_MNG_TYPE_INIT)
                {
                    pAvclient->m_playBackThreadMng.ucRunFlag = 0;
                    for(;;)
                    {
                        if (++iRetryCount >= 3000 || pAvclient->m_playBackThreadMng.ucOverFlag == EN_P2P_THREAD_MNG_TYPE_END)
                        {
                            MOS_PRINTF("%s:%d Delete playBackThread.....\r\n", __FUNCTION__, __LINE__);
                            iRetryCount = 0;
                            pAvclient->m_playBackThreadMng.ucOverFlag = EN_P2P_THREAD_MNG_TYPE_INIT;
                            Mos_ThreadDelete(pAvclient->m_playBackThreadMng.hThread);
                            break;
                        }
                        Mos_Sleep(1);
                    }
                    _VPTR pstMsg = MOS_NULL;
                    while((pstMsg = Mos_MsgQueuePop(pAvclient->m_playBackThreadMng.hMsgQueque)) != MOS_NULL)
                    {
                        MOS_FREE(pstMsg);
                    }
                    Mos_MsgQueueDelete(pAvclient->m_playBackThreadMng.hMsgQueque);
                    pAvclient->m_playBackThreadMng.hMsgQueque = MOS_NULL;
                }
            }

            if (pAvclient->m_liveCmdThreadMng.ucInitFlag == 1)
            {
                if(pAvclient->m_liveCmdThreadMng.ucOverFlag > EN_P2P_THREAD_MNG_TYPE_INIT)
                {
                   pAvclient->m_liveCmdThreadMng.ucRunFlag = 0;
                    for(;;)
                    {
                        if (++iRetryCount >= 3000 || pAvclient->m_liveCmdThreadMng.ucOverFlag == EN_P2P_THREAD_MNG_TYPE_END)
                        {
                            MOS_PRINTF("%s:%d Delete playBackThread.....\r\n", __FUNCTION__, __LINE__);
                            iRetryCount = 0;
                            pAvclient->m_liveCmdThreadMng.ucOverFlag = EN_P2P_THREAD_MNG_TYPE_INIT;
                            Mos_ThreadDelete(pAvclient->m_liveCmdThreadMng.hThread);
                            break;
                        }
                        Mos_Sleep(1);
                    }
                    _VPTR pstMsg = MOS_NULL;
                    while((pstMsg = Mos_MsgQueuePop(pAvclient->m_liveCmdThreadMng.hMsgQueque)) != MOS_NULL)
                    {
                        MOS_FREE(pstMsg);
                    }
                    Mos_MsgQueueDelete(pAvclient->m_liveCmdThreadMng.hMsgQueque);
                    pAvclient->m_liveCmdThreadMng.hMsgQueque = MOS_NULL;
                }
            }

            if ((pAvclient->m_iceTranSport != MOS_NULL) && (pAvclient->m_iceTranSport->pcbDestoryClienRome != MOS_NULL))
            {
                pAvclient->m_iceTranSport->pcbDestoryClienRome((_VPTR)pAvclient->m_iceTranSport->pKjClienRome);
            }
            
            AvClient_RemoveTurnAddr(pAvclient->m_uacPeerId);
            Mos_MutexUnLock(&pAvclient->hMutex);

            if (pAvclient->m_bEnableSpeaker == MOS_TRUE)
            {
                MOS_LOG_INF(P2P_STRLOG, "TIMEOUT to close p2p speaker!!");                
                Media_AudioPlayCancelFrameBuff(MOS_NULL);
                Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                pAvclient->m_bEnableSpeaker  = MOS_FALSE;
                Media_Notify_AudioPlay(pAvclient->m_uacPeerId, 1, pAvclient->m_bEnableSpeaker, pAvclient->m_sAudioSpeakChn);
                Media_AudioPlayDestroyWriteHandle(pAvclient->m_hAudioPlay);
                pAvclient->m_sAudioSpeakChn  =  0;
                pAvclient->m_hAudioPlay = MOS_NULL;
                #ifdef BUILD_ONBROADCAST_FALG
                Broadcast_Task_Resume_CloseTalk();
                #endif
                P2pManageMent::instance().P2pDestroyTbsl((_VPTR)pAvclient, kj_av_type_audio);
            }

            if (pAvclient->m_bEnableDisplay == MOS_TRUE)
            {
                MOS_LOG_INF(P2P_STRLOG, "TIMEOUT to close p2p display!!");                
                Config_SetCamerDisplayOpenFlag(0, MOS_FALSE);
                pAvclient->m_bEnableDisplay  = MOS_FALSE;
                Media_Notify_VideoPlay(pAvclient->m_uacPeerId, pAvclient->m_bEnableDisplay);
                Media_VideoDisPlayDestroyHandle(pAvclient->m_hVideoPlay);  
                pAvclient->m_sVideoDisplayChn  =  0;
                pAvclient->m_hVideoPlay = MOS_NULL;
                Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
                P2pManageMent::P2pDestroyTbsl((_VPTR)pAvclient, kj_av_type_video);
            }

            MOS_PRINTF("delete pAvclient.......\n");
            MOS_FREE(pAvclient);
        }
        else
        {
            if (pAvclient->m_stInTransmittingChannelInfo.uiCheckFlag == 1)
            {
                _US usChannelCount = pAvclient->m_stInTransmittingChannelInfo.usChannelCount;
                MOS_PRINTF("usChannelCount:%d  \n", usChannelCount);

                {
                    _US usVideoValid    = MOS_FALSE;
                    _US usAudioValid    = MOS_FALSE;
                    _US usSpeakValid    = MOS_FALSE;
                    _US usPlayBackValid = MOS_FALSE;
                    for (int i=0; i<usChannelCount; i++)
                    {
                        MOS_PRINTF("usChannelCount:%d   usChannelNum:%d \n", usChannelCount,pAvclient->m_stInTransmittingChannelInfo.usChannelList[i]);

                        _US iChannelIndex = pAvclient->m_stInTransmittingChannelInfo.usChannelList[i];
                        if ((pAvclient->m_bEnableVideo) && (iChannelIndex ==  pAvclient->m_sLiveVideoChn))
                        {
                            usVideoValid = MOS_TRUE;
                        }
                        if ((pAvclient->m_bEnableAudio) && (iChannelIndex ==  pAvclient->m_sLiveAudioChn))
                        {
                            usAudioValid = MOS_TRUE;
                        }
                        else if ((pAvclient->m_bEnableSpeaker) && (iChannelIndex ==  pAvclient->m_sAudioSpeakChn))
                        {
                            usSpeakValid = MOS_TRUE;
                        }
                        else if ((pAvclient->m_playBackThreadMng.ucInitFlag==1) && (iChannelIndex == pAvclient->m_playBackThreadMng.usChannel) )
                        {
                            usPlayBackValid = MOS_TRUE;
                        }
                        //MOS_PRINTF("iChannelIndex:%d usChannelCount:%d, usChannelType:%d\n", iChannelIndex, usChannelCount, usChannelType);
                    }
                    //MOS_PRINTF("usVideoValid:%d usAudioValid:%d usSpeakValid:%d, usPlayBackValid:%d\n", usVideoValid, usAudioValid, usSpeakValid, usPlayBackValid);
                     if ((pAvclient->m_bEnableVideo) && (!usVideoValid))
                     {
                         MOS_PRINTF("Close client live video channel!!\n");
                         pAvclient->m_bEnableVideo  = MOS_FALSE;
                         pAvclient->m_sLiveVideoChn = 0;
                     }
                     if ((pAvclient->m_bEnableAudio) && (!usAudioValid))
                     {
                         pAvclient->m_bEnableAudio  = MOS_FALSE;
                         pAvclient->m_sLiveAudioChn = 0;
                     }
                     if (0)//(pAvclient->m_bEnableSpeaker) && (!usSpeakValid))
                     {
                         //Todo close speaker
                     }
                     if ((pAvclient->m_playBackThreadMng.ucInitFlag==1) && (!usPlayBackValid))
                     {
                         MOS_PRINTF("Close m_playBackThreadMng thread!!\n");
                         P2pProcessCmd::P2pPlaybackStop((_HP2PCHANNEL)pAvclient, pAvclient->m_playBackThreadMng.usChannel, MOS_TRUE);
                     }
                }
                pAvclient->m_stInTransmittingChannelInfo.uiCheckFlag    = 0;
                pAvclient->m_stInTransmittingChannelInfo.usChannelCount = 0;
            }
        }
    }    
    m_mutexAvclientList.unlock();

    if (iHaveClinetTimeout)
    {
        //Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, getOnVideoClient(1)?1:0);
    }
    return MOS_OK;
}

_INT P2pManageMent::setClientTimeOut(_HP2PCHANNEL hP2pChnnel)
{
    ST_AVCLIENT_INFO *pAvclient  = (ST_AVCLIENT_INFO*)hP2pChnnel;

    Mos_MutexLock(&pAvclient->hMutex);
    pAvclient->m_bChannelTimeOut = MOS_TRUE;
    pAvclient->m_bEnableAudio    = 0;
    pAvclient->m_bEnableVideo    = 0;
    pAvclient->m_liveCmdThreadMng.ucRunFlag = 0;
    Mos_MutexUnLock(&pAvclient->hMutex);
    return MOS_OK;
}

_INT P2pManageMent::setClientTimeOut(_UC *aucPeerId)
{
    ST_AVCLIENT_INFO *pAvclient = findAvclientById(aucPeerId);
    MOS_PARAM_NULL_RETFALSE(pAvclient);
    Mos_MutexLock(&pAvclient->hMutex);
    pAvclient->m_bChannelTimeOut = MOS_TRUE;
    pAvclient->m_bEnableAudio    = 0;
    pAvclient->m_bEnableVideo    = 0;
    pAvclient->m_liveCmdThreadMng.ucRunFlag = 0;
    Mos_MutexUnLock(&pAvclient->hMutex);
    return MOS_OK;
}

_INT P2pManageMent::setClientStartLiveVideo(_HP2PCHANNEL hP2pChnnel, _INT iStreamId, _UI uiChnId)
{
    ST_AVCLIENT_INFO *pAvclient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    Mos_MutexLock(&pAvclient->hMutex);
    pAvclient->m_bEnableVideo    = MOS_TRUE;
    pAvclient->m_ucStreamId      = iStreamId;
    pAvclient->m_ucNeedIframe    = MOS_TRUE;
    pAvclient->m_sLiveVideoChn   = uiChnId;
    pAvclient->m_bEnableAudio    = MOS_TRUE;
    pAvclient->m_sLiveAudioChn   = uiChnId;
    Mos_MutexUnLock(&pAvclient->hMutex);
    return MOS_OK;
}

_INT P2pManageMent::setClientCloseLiveVideo(_HP2PCHANNEL hP2pChnnel, _INT iStreamId)
{
    ST_AVCLIENT_INFO *pAvclient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    Mos_MutexLock(&pAvclient->hMutex);
    if (pAvclient->m_ucStreamId == iStreamId)
    {
        pAvclient->m_bEnableVideo = MOS_FALSE;
        pAvclient->m_bEnableAudio = MOS_FALSE;
    }
    Mos_MutexUnLock(&pAvclient->hMutex);
    return MOS_OK;
}

_INT P2pManageMent::setClientStartLiveForVideo(_HP2PCHANNEL hP2pChnnel, _INT iStreamId, _UI uiChnId)
{
    ST_AVCLIENT_INFO *pAvclient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    Mos_MutexLock(&pAvclient->hMutex);
    pAvclient->m_bEnableVideo    = MOS_TRUE;
    pAvclient->m_ucStreamId      = iStreamId;
    pAvclient->m_ucNeedIframe    = MOS_TRUE;
    pAvclient->m_sLiveVideoChn   = uiChnId;
    Mos_MutexUnLock(&pAvclient->hMutex);
    return MOS_OK;
}

_INT P2pManageMent::setClientStartLiveForAudio(_HP2PCHANNEL hP2pChnnel, _UI uiChnId)
{
    ST_AVCLIENT_INFO *pAvclient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    Mos_MutexLock(&pAvclient->hMutex);
    pAvclient->m_bEnableAudio    = MOS_TRUE;
    pAvclient->m_sLiveAudioChn   = uiChnId;
    Mos_MutexUnLock(&pAvclient->hMutex);
    return MOS_OK;
}

_INT P2pManageMent::setClientCloseLiveAll(_HP2PCHANNEL hP2pChnnel)
{
    ST_AVCLIENT_INFO *pAvclient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    Mos_MutexLock(&pAvclient->hMutex);
    pAvclient->m_bEnableVideo = MOS_FALSE;
    pAvclient->m_bEnableAudio = MOS_FALSE;
    Mos_MutexUnLock(&pAvclient->hMutex);
    return MOS_OK;
}

_INT  P2pManageMent::checkSpeakerClient()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_AVCLIENT_INFO *pstAvClient = MOS_NULL;
    _BOOL bRet = MOS_FALSE;

    m_mutexAvclientList.rdLock();
    FOR_EACHDATA_INLIST(&m_hIceClientList, pstAvClient, stIterator)
    {
        if (pstAvClient->m_bEnableSpeaker >= 1)
        {
             bRet = MOS_TRUE;
             break;
        }
    }
    m_mutexAvclientList.unlock();
    return bRet;
}

_INT  P2pManageMent::checkDisplayClient()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_AVCLIENT_INFO *pstAvClient = MOS_NULL;
    _BOOL bRet = MOS_FALSE;

    m_mutexAvclientList.rdLock();
    FOR_EACHDATA_INLIST(&m_hIceClientList, pstAvClient, stIterator)
    {
        if (pstAvClient->m_bEnableDisplay >= 1)
        {
             bRet = MOS_TRUE;
             break;
        }
    }
    m_mutexAvclientList.unlock();
    return bRet;
}


_INT  P2pManageMent::getOnVideoClient(_INT inLive)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_AVCLIENT_INFO *pstAvClient = MOS_NULL;
    _INT  iMaxOnline = 0;
    m_mutexAvclientList.rdLock();
    FOR_EACHDATA_INLIST(&m_hIceClientList, pstAvClient, stIterator)
    {
        if (inLive <= 0)
        {
            iMaxOnline++;
        }
        else
        {
            if ((pstAvClient->m_bEnableVideo >= 1) || (pstAvClient->m_bEnableAudio >=1)
                    || (pstAvClient->m_playBackThreadMng.ucRunFlag >=1))
            {
                 iMaxOnline++;
            }
        }
    }
    m_mutexAvclientList.unlock();
    return iMaxOnline;
}

/**
* @brief         generate enc p2p channel passwd
* @author        Hejh
* @date          2021-05-13
*/
_UI P2pManageMent::onGenerateEnc()
{
    _INT iOnlineUser = getOnVideoClient(0);
    if ( iOnlineUser <= 0)
    {
        _UC iEncType1      = EN_OGCT_ENCRYPT_LEVEL_AES128;
        _UC pucEncKey1[17] = {0};
        _UC pucEncLv1[17]  = {0};
        Adapt_GenerateString(pucEncKey1, sizeof(pucEncKey1));
        Adapt_GenerateString(pucEncLv1, sizeof(pucEncLv1));
        setDevTransEnc(iEncType1, pucEncKey1, pucEncLv1);
        MOS_LOG_INF(P2P_STRLOG,"iOnLineUser: %d, gererateenc key", iOnlineUser);
    }
    else
    {
        MOS_PRINTF("iOnLineUser: %d, do not gererateenc", iOnlineUser);
    }
    return MOS_OK;
}

ST_HTTP_ENCRYPTO_INF*  P2pManageMent::getDevTransEnc()
{
    return &m_aucP2pTrasEnc;
}

/**
* @brief         set P2p transfer encode passwd
* @author        Hejh
* @date          2021-07-12
*/
ST_HTTP_ENCRYPTO_INF*  P2pManageMent::setDevTransEnc(_INT iEncType,_UC *paucEncKey, _UC *paucEncLv)
{
    MOS_PARAM_NULL_RETNULL(paucEncKey);
    MOS_PARAM_NULL_RETNULL(paucEncLv);

    if(m_aucP2pTrasEnc.hCryptoCtx != MOS_NULL)
    {
        Adpt_DeleteCrypto(m_aucP2pTrasEnc.hCryptoCtx);
        m_aucP2pTrasEnc.hCryptoCtx = MOS_NULL;
    }

    if(iEncType == EN_OGCT_ENCRYPT_LEVEL_LOW)
    {
        m_aucP2pTrasEnc.hCryptoCtx = Adpt_CreateCrypto(paucEncKey,MOS_STRLEN(paucEncKey),EN_CRYPTO_BLOWFISH_TYPE);
    }

    m_aucP2pTrasEnc.iEncType = iEncType;
    MOS_MEMSET(m_aucP2pTrasEnc.aucEncKey, 0, sizeof(m_aucP2pTrasEnc.aucEncKey));
    MOS_MEMSET(m_aucP2pTrasEnc.aucEncLv,  0, sizeof(m_aucP2pTrasEnc.aucEncLv));
    MOS_STRNCPY(m_aucP2pTrasEnc.aucEncKey, paucEncKey, sizeof(m_aucP2pTrasEnc.aucEncKey));
    MOS_STRNCPY(m_aucP2pTrasEnc.aucEncLv,  paucEncLv,  sizeof(m_aucP2pTrasEnc.aucEncLv));
    return MOS_OK;
}

/**
* @brief         inti live video thread
* @author        Hejh
* @date          2021-05-13
*/
_VOID  P2pManageMent::initLiveVideo()
{
    if(m_liveVideoThread.ucInitFlag == 1)
    {
        return;
    }
    MOS_MEMSET(&m_liveVideoThread, 0, sizeof(m_liveVideoThread));
    m_liveVideoThread.ucInitFlag = 1;
    m_liveVideoThread.ucRunFlag  = 0;
    m_liveVideoThread.hMsgQueque = Mos_MsgQueueCreate(MOS_FALSE, 30, "initLiveVideo");
}

/**
* @brief         start live video thread
* @author        Hejh
* @date          2021-05-13
*/
_UI P2pManageMent::startLiveVideo()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    if(m_liveVideoThread.ucInitFlag == 0)
    {
        return MOS_ERR;
    }

    if(m_liveVideoThread.ucRunFlag == 1)
    {
        return MOS_OK;
    }

    m_liveVideoThread.ucRunFlag  = 1;
#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    if(Mos_ThreadCreate((_UC*)"liveVideo",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        P2pManageMent::createliveVideo, this,MOS_NULL,&m_liveVideoThread.hThread) == MOS_ERR)
    {
        m_liveVideoThread.ucRunFlag = 0;
        return MOS_ERR;
    }
    return MOS_OK;
}

/**
* @brief         stop all live cmd thread
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pManageMent::stopAllLiveCmd()
{
    ST_MOS_LIST_ITERATOR stIterator;
    _INT iRetryCount = 0;
    ST_AVCLIENT_INFO *pAvclient = MOS_NULL;

    m_mutexAvclientList.wrLock();
    FOR_EACHDATA_INLIST(&m_hIceClientList, pAvclient, stIterator)
    { 
        MOS_LIST_RMVNODE(&m_hIceClientList, pAvclient);
        MOS_LOG_INF(P2P_STRLOG, "%s force client:%s quit, remove now!! !!",__FUNCTION__, pAvclient->m_uacPeerId);
        P2pManageMent::instance().setClientCloseLiveAll((_HP2PCHANNEL)pAvclient);
        Mos_MutexLock(&pAvclient->hMutex);
        //pAvclient->m_iceTranSport->stop();

        if (pAvclient->m_playBackThreadMng.ucInitFlag == 1)
        {
            if(pAvclient->m_playBackThreadMng.ucOverFlag > EN_P2P_THREAD_MNG_TYPE_INIT)
            {
                pAvclient->m_playBackThreadMng.ucRunFlag = 0;
                for(;;)
                {
                    if (++iRetryCount >= 3000 || pAvclient->m_playBackThreadMng.ucOverFlag == EN_P2P_THREAD_MNG_TYPE_END)
                    {
                        MOS_PRINTF("%s:%d Delete playBackThread.....\r\n", __FUNCTION__, __LINE__);
                        iRetryCount = 0;
                        pAvclient->m_playBackThreadMng.ucOverFlag = EN_P2P_THREAD_MNG_TYPE_INIT;
                        Mos_ThreadDelete(pAvclient->m_playBackThreadMng.hThread);
                        break;
                    }
                    Mos_Sleep(1);
                }
                _VPTR pstMsg = MOS_NULL;
                while((pstMsg = Mos_MsgQueuePop(pAvclient->m_playBackThreadMng.hMsgQueque)) != MOS_NULL)
                {
                    MOS_FREE(pstMsg);
                }
                Mos_MsgQueueDelete(pAvclient->m_playBackThreadMng.hMsgQueque);
                pAvclient->m_playBackThreadMng.hMsgQueque = MOS_NULL;
            }
        }

        if (pAvclient->m_liveCmdThreadMng.ucInitFlag == 1)
        {            
            if(pAvclient->m_liveCmdThreadMng.ucOverFlag > EN_P2P_THREAD_MNG_TYPE_INIT)
            {
                pAvclient->m_liveCmdThreadMng.ucRunFlag = 0;
                for(;;)
                {
                    if (++iRetryCount >= 3000 || pAvclient->m_liveCmdThreadMng.ucOverFlag == EN_P2P_THREAD_MNG_TYPE_END)
                    {
                        MOS_PRINTF("%s:%d Delete playBackThread.....\r\n", __FUNCTION__, __LINE__);
                        iRetryCount = 0;
                        pAvclient->m_liveCmdThreadMng.ucOverFlag = EN_P2P_THREAD_MNG_TYPE_INIT;
                        Mos_ThreadDelete(pAvclient->m_liveCmdThreadMng.hThread);
                        break;
                    }
                    Mos_Sleep(1);
                }
                _VPTR pstMsg = MOS_NULL;
                while((pstMsg = Mos_MsgQueuePop(pAvclient->m_liveCmdThreadMng.hMsgQueque)) != MOS_NULL)
                {
                    MOS_FREE(pstMsg);
                }
                Mos_MsgQueueDelete(pAvclient->m_liveCmdThreadMng.hMsgQueque);
                pAvclient->m_liveCmdThreadMng.hMsgQueque = MOS_NULL;
            }
        }
        AvClient_RemoveTurnAddr(pAvclient->m_uacPeerId);
        //pAvclient->m_iceTranSport->deinit();
        //MOS_FREE(pAvclient->m_iceTranSport);
        Mos_MutexUnLock(&pAvclient->hMutex); 
        MOS_FREE(pAvclient);
    }    
    m_mutexAvclientList.unlock();
    return MOS_OK;
}

/**
* @brief         stop live video thread
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pManageMent::stopLiveVideo()
{
    _VPTR pstMsg = MOS_NULL;
    if(m_liveVideoThread.ucRunFlag == 0)
    {
        return MOS_OK;
    }
    m_liveVideoThread.ucRunFlag  = 0;
    // Mos_MsgQueueWake(m_liveVideoThread.hMsgQueque,MOS_TRUE);
    while((pstMsg = Mos_MsgQueuePop(m_liveVideoThread.hMsgQueque)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    Mos_ThreadDelete(m_liveVideoThread.hThread);

    MOS_LOG_INF(P2P_STRLOG,"livevideo task stop ok");
    return MOS_OK;
}

/**
* @brief         destory live videothread
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pManageMent::destoryLiveVideo()
{
    if(m_liveVideoThread.ucInitFlag == 0)
    {
        return MOS_OK;
    }
    Mos_MsgQueueDelete(m_liveVideoThread.hMsgQueque);
    MOS_MEMSET(&m_liveVideoThread, 0, sizeof(m_liveVideoThread));

    MOS_LOG_INF(P2P_STRLOG,"livevideo task Destroy ok");
    return MOS_OK;
}

/**
* @brief         start create live video thread
* @author        Hejh
* @date          2021-05-13
*/
_VPTR P2pManageMent::createliveVideo( _VPTR obj )
{
    P2pManageMent *live_video_thread = static_cast<P2pManageMent*>(obj);
    if(live_video_thread != NULL)
    {
        live_video_thread->liveVideoThread(NULL);
    }
    return NULL;
}

/**
* @brief         recive live media resend feedback request cmd to queue
* @author        Hejh
* @date          2021-05-13
*/
_INT  P2pManageMent::addResendMediaReq(_INT iMediaType, _VPTR pFeedBackPara)
{
    _INT iRet = MOS_ERR;
    if (iMediaType == EN_HTTP_STREAMER_VIDEO)
    {
        iRet = Mos_MsgQueuePush(m_liveVideoThread.hMsgQueque, pFeedBackPara);
    }
    else if (iMediaType == EN_HTTP_STREAMER_AUDIO)
    {
        iRet = Mos_MsgQueuePush(m_liveAudioThread.hMsgQueque, pFeedBackPara);
    }
    return iRet;
}

/**
* @brief         recive resend playback data  request cmd
* @author        Hejh
* @date          2021-05-13
*/
_INT  P2pManageMent::addResendPlaybackMediaReq(ST_AVCLIENT_INFO *pAvClientInfo, _VPTR pFeedBackPara)
{
    return Mos_MsgQueuePush(pAvClientInfo->m_playBackThreadMng.hMsgQueque, pFeedBackPara);
}

/**
* @brief         send real video thread
* @author        Hejh
* @date          2021-05-13
*/
_INT *P2pManageMent::liveVideoThread(_VPTR arg)
{    
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_MSGHEAD *pstMsgHead = MOS_NULL;
    _HVIDEOREAD hVideoRead     = Media_VideoCreatReadHandle2(0, 0, EN_READ_NEWKEY, 0, __FUNCTION__);
    _HVIDEOREAD hVideoRead2    = Media_VideoCreatReadHandle2(0, 1, EN_READ_NEWKEY, 0, __FUNCTION__);

    kj_timer_t   tFeedDogTimeOut;
    kj_timer_init(&tFeedDogTimeOut);
    getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    _HSWDWRITE hSwdFeedDog = Swd_AppThreadRegist(P2P_LIVE_VIDEO_APP, FEED_DOG_MAX_TIMESEC);

    while(m_liveVideoThread.ucRunFlag)
    {
        ST_AVCLIENT_INFO *pstAvClient = MOS_NULL;
        ST_DATA_NODE  *pstDataNode    = MOS_NULL;

        if (getDiffTimems(&tFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
        {
            Swd_AppThreadFeedDog(hSwdFeedDog);
            getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }
        //main stream
        pstDataNode = Media_VideoGetOneNode(hVideoRead);
        if (pstDataNode != MOS_NULL)
        {
            ST_DATA_NODE *pstFrameNode = pstDataNode; 
            
            if (pstFrameNode->stFrameNode.ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_RES || pstFrameNode->stFrameNode.ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_ENC)
            {
                
            }

            m_mutexAvclientList.rdLock();
            FOR_EACHDATA_INLIST(&m_hIceClientList, pstAvClient, stIterator)
            {
                if (pstAvClient->m_bEnableVideo && (pstAvClient->m_ucStreamId==0))
                {
                    if (pstAvClient->m_ucNeedIframe==MOS_TRUE)
                    {
                        if (MD_GETFRAMETYPE(pstFrameNode->pstFrameHead->stFrameNode.ucFramPos) == EN_ZJ_VIDEO_FRAME_TYPE_I)
                        {
                            P2pProcessCmd::procSendMediaNode(pstAvClient->m_iceTranSport,pstAvClient->m_sLiveVideoChn,
                                                             EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                             pstFrameNode, EN_HTTP_STREAMER_VIDEO);
                            pstAvClient->m_ucNeedIframe = MOS_FALSE;
                            MOS_PRINTF("start I FRAME!! %d", pstAvClient->m_ucStreamId);
                        }
                    }
                    else
                    {
                        P2pProcessCmd::procSendMediaNode(pstAvClient->m_iceTranSport,pstAvClient->m_sLiveVideoChn,
                                                         EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                         pstFrameNode, EN_HTTP_STREAMER_VIDEO);
                    }
                }
            }
            m_mutexAvclientList.unlock();

            Media_VideoSetNodeUsed(hVideoRead);
            Media_VideoHisAddOneNode(hVideoRead,  pstDataNode);
        }

        //sub stream
        pstDataNode = Media_VideoGetOneNode(hVideoRead2);
        if (pstDataNode != MOS_NULL)
        {
            ST_DATA_NODE *pstFrameNode = pstDataNode;
                    
            if (pstFrameNode->stFrameNode.ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_RES || pstFrameNode->stFrameNode.ucVideoResolutionChangeFlag == EN_VIDEOPARAM_CHANGED_ENC)
            {
                
            }
            
            m_mutexAvclientList.rdLock();
            FOR_EACHDATA_INLIST(&m_hIceClientList, pstAvClient, stIterator)
            {
                if (pstAvClient->m_bEnableVideo && (pstAvClient->m_ucStreamId==1))
                {
                    if (pstAvClient->m_ucNeedIframe==MOS_TRUE)//need i frame
                    {
                        if (MD_GETFRAMETYPE(pstFrameNode->pstFrameHead->stFrameNode.ucFramPos) == 1)
                        {
                            P2pProcessCmd::procSendMediaNode(pstAvClient->m_iceTranSport, pstAvClient->m_sLiveVideoChn,
                                                             EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                             pstFrameNode, EN_HTTP_STREAMER_VIDEO);
                            pstAvClient->m_ucNeedIframe = MOS_FALSE;
                            MOS_PRINTF("start I FRAME!! %d", pstAvClient->m_ucStreamId);
                        }
                    }
                    else
                    {
                        P2pProcessCmd::procSendMediaNode(pstAvClient->m_iceTranSport, pstAvClient->m_sLiveVideoChn,
                                                         EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                         pstFrameNode, EN_HTTP_STREAMER_VIDEO);
                    }
                }
            }
            m_mutexAvclientList.unlock();

            Media_VideoSetNodeUsed(hVideoRead2);
            Media_VideoHisAddOneNode(hVideoRead2,  pstDataNode);
        }

        //feedback info ,need to resend history video packages
        if ((pstDataNode == MOS_NULL) )
        {
            pstMsgHead = Mos_MsgQueuePop(m_liveVideoThread.hMsgQueque);
            if(pstMsgHead != MOS_NULL)
            {
                if (pstMsgHead->usMsgType == EN_P2P_MSG_TYPE_NET)
                {
                    ST_P2P_FEEDBACK_MSG *pMsgParam = ((ST_P2P_FEEDBACK_MSG*)pstMsgHead);
                    ST_MSGP2P_FEEDBACK *param = (ST_MSGP2P_FEEDBACK*)pMsgParam->aucMsgBody;
                    param->usChannel   = MOS_INET_NTOHS(param->usChannel);
                    param->usWinSize   = MOS_INET_NTOHS(param->usWinSize);
                    param->ucPsrtMode  = MOS_INET_NTOHS(param->ucPsrtMode);
                    param->usNackCount = MOS_INET_NTOHS(param->usNackCount);
                    //MOS_PRINTF("#######video feedback keep alive  chan:%u ackSeq:%d usWinSize:%u nackcount:%u av:%d psrtmode:%d winsize:%d,  \n",
                    //            param->usChannel, param->ucPackSeq, param->usWinSize, param->usNackCount,
                    //           param->ucAvType, (param->ucPsrtMode), (param->usWinSize));

                    _INT index    = 0;
                    _UC  ucResSeq = param->ucPackSeq;
                    if (param->usNackCount > 0)
                    {
                        ST_AVCLIENT_INFO *pstAvCli = findAvclientById(pMsgParam->aucPeerId);
                        if ((pstAvCli != MOS_NULL) && (pstAvCli->m_bEnableVideo ))
                        {
                            _US iOldPackIndex = 0;
                            for (int i=index; i<param->usNackCount; i++)
                            {
                                _US iPackIndex = MOS_INET_NTOHS(param->usSeqList[i]);
                                /*兼容起点为0开始的重传（修改之前，接收到对端的重传信息的第一个包的序号为0的话会导致计算错误，导致重传失败）*/
                                if ((iPackIndex == iOldPackIndex) && (i != 0))
                                {
                                    i++;
                                    iPackIndex = MOS_INET_NTOHS(param->usSeqList[i]);
                                    for (_US j=iOldPackIndex+1; j!=iPackIndex; j++)
                                    {
                                        ST_DATA_NODE *pstResNodeData = MOS_NULL;
                                        if ((pstResNodeData=Media_VideoHisGetPackNode((pstAvCli->m_ucStreamId==0)?hVideoRead:hVideoRead2, j)) != MOS_NULL)
                                        {
                                            P2pProcessCmd::procSendMediaNode(pstAvCli->m_iceTranSport, pstAvCli->m_sLiveVideoChn,
                                                                             EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                                             pstResNodeData, EN_HTTP_STREAMER_VIDEO, 1, ucResSeq);
                                        }
                                    }
                                }
                                ST_DATA_NODE *pstResNodeData = MOS_NULL;
                                if ((pstResNodeData=Media_VideoHisGetPackNode((pstAvCli->m_ucStreamId==0)?hVideoRead:hVideoRead2, iPackIndex)) != MOS_NULL)
                                {
                                    P2pProcessCmd::procSendMediaNode(pstAvCli->m_iceTranSport, pstAvCli->m_sLiveVideoChn,
                                                                     EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                                     pstResNodeData, EN_HTTP_STREAMER_VIDEO, 1, ucResSeq);
                                }
                                iOldPackIndex = iPackIndex;
                            }
                        }
                    }
                }
                MOS_FREE(pstMsgHead);
            }
            else
            {
                Mos_Sleep(5);
            }
        }
    }
    Swd_AppThreadUnRegist(hSwdFeedDog);
    Media_VideoHisDelAllNode(hVideoRead);
    Media_VideoHisDelAllNode(hVideoRead2);
    Media_VideoDestroyReadHandle2(hVideoRead);
    Media_VideoDestroyReadHandle2(hVideoRead2);
    MOS_PRINTF("%s exit ok!!\n", __FUNCTION__);
    return MOS_OK;
}

/************************************begin live audio functions*****************/
/// \brief P2pManageMent::initLiveAudio
/// \return
_VOID  P2pManageMent::initLiveAudio()
{
    if(m_liveAudioThread.ucInitFlag == 1)
    {
        return;
    }
    MOS_MEMSET(&m_liveAudioThread, 0, sizeof(m_liveAudioThread));
    m_liveAudioThread.ucInitFlag = 1;
    m_liveAudioThread.ucRunFlag  = 0;
    m_liveAudioThread.hMsgQueque = Mos_MsgQueueCreate(MOS_FALSE, 30, "initLiveAudio");
}

/**
* @brief         start live audio thread
* @author        Hejh
* @date          2021-05-13
*/
_UI P2pManageMent::startLiveAudio()
{
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    if(m_liveAudioThread.ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    if(m_liveAudioThread.ucRunFlag == 1)
    {
        return MOS_OK;
    }
    m_liveAudioThread.ucRunFlag  = 1;
#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif

    if(Mos_ThreadCreate((_UC*)"liveAudio",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        P2pManageMent::createliveAudio, this, MOS_NULL,&m_liveAudioThread.hThread) == MOS_ERR)
    {
        m_liveAudioThread.ucRunFlag = 0;
        return MOS_ERR;
    }
    return MOS_OK;
}

/**
* @brief         stop live audio thread
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pManageMent::stopLiveAudio()
{
    _VPTR pstMsg = MOS_NULL;
    if(m_liveAudioThread.ucRunFlag == 0)
    {
        return MOS_OK;
    }
    m_liveAudioThread.ucRunFlag  = 0;
    // Mos_MsgQueueWake(m_liveAudioThread.hMsgQueque,MOS_TRUE);
    while((pstMsg = Mos_MsgQueuePop(m_liveAudioThread.hMsgQueque)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    Mos_ThreadDelete(m_liveAudioThread.hThread);

    MOS_LOG_INF(P2P_STRLOG,"liveAudio task stop ok");
    return MOS_OK;
}

/**
* @brief         destory live audio thread
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pManageMent::destoryLiveAudio()
{
    if(m_liveAudioThread.ucInitFlag == 0)
    {
        return MOS_OK;
    }
    Mos_MsgQueueDelete(m_liveAudioThread.hMsgQueque);
    MOS_MEMSET(&m_liveAudioThread, 0, sizeof(m_liveAudioThread));

    MOS_LOG_INF(P2P_STRLOG,"liveAudio task Destroy ok");
    return MOS_OK;
}

/**
* @brief         create live audio thread
* @author        Hejh
* @date          2021-05-13
*/
_VPTR P2pManageMent::createliveAudio( _VPTR obj )
{
    P2pManageMent *live_Audio_thread = static_cast<P2pManageMent*>(obj);
    if(live_Audio_thread != NULL)
    {
        live_Audio_thread->liveAudioThread(NULL);
    }
    return NULL;
}

/**
* @brief         real live audio thread implimentation
* @author        Hejh
* @date          2021-05-13
*/
_INT *P2pManageMent::liveAudioThread(_VPTR arg)
{
    _HAUDIOREAD hAudioRead = Media_AudioCreatReadHandle2(0, EN_READ_NEWKEY, __FUNCTION__);
    ST_MOS_LIST_ITERATOR stIterator;
    kj_timer_t   tFeedDogTimeOut;
    kj_timer_init(&tFeedDogTimeOut);
    getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    _HSWDWRITE hSwdFeedDog = Swd_AppThreadRegist(P2P_LIVE_AUDIO_APP, FEED_DOG_MAX_TIMESEC);

    while(m_liveAudioThread.ucRunFlag)
    {
        if (getDiffTimems(&tFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
        {
            Swd_AppThreadFeedDog(hSwdFeedDog);
            getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }
        ST_AVCLIENT_INFO *pstAvClient = MOS_NULL;
        ST_DATA_NODE  *pstDataNode = Media_AudioGetOneNode(hAudioRead);
        if (pstDataNode != MOS_NULL)
        {
            ST_DATA_NODE *pstFrameNode = pstDataNode;
            m_mutexAvclientList.rdLock();
            FOR_EACHDATA_INLIST(&m_hIceClientList, pstAvClient, stIterator)
            {
                if (pstAvClient->m_bEnableAudio)
                {
                    P2pProcessCmd::procSendMediaNode(pstAvClient->m_iceTranSport, pstAvClient->m_sLiveAudioChn,
                                                     EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                     pstFrameNode, EN_HTTP_STREAMER_AUDIO);
                }
            }
            m_mutexAvclientList.unlock();
            Media_AudioSetNodeUsed(hAudioRead);
            Media_AudioHisAddOneNode(hAudioRead,  pstDataNode);
        }
        else
        {
            ST_MOS_MSGHEAD *pstMsgHead = MOS_NULL;
            {
                pstMsgHead = Mos_MsgQueuePop(m_liveAudioThread.hMsgQueque);
                if(pstMsgHead != MOS_NULL)
                {
                    if (pstMsgHead->usMsgType == EN_P2P_MSG_TYPE_NET)
                    {
                        ST_P2P_FEEDBACK_MSG *pMsgParam = ((ST_P2P_FEEDBACK_MSG*)pstMsgHead);
                        ST_MSGP2P_FEEDBACK *param = (ST_MSGP2P_FEEDBACK*)pMsgParam->aucMsgBody;
                        param->usChannel   = MOS_INET_NTOHS(param->usChannel);
                        param->usWinSize   = MOS_INET_NTOHS(param->usWinSize);
                        param->usNackCount = MOS_INET_NTOHS(param->usNackCount);
//                        MOS_PRINTF("#######audio feedback keep alive chan:%u ackSeq:%d account:%u nackcount:%u av:%d psrtmode:%d winsize:%d,  \n",
//                                   param->usChannel, param->ucPackSeq, param->usChannel, param->usNackCount,
//                                   param->ucAvType, (param->ucPsrtMode), (param->usWinSize));

                        _INT index    = 0;
                        _UC  ucResSeq = param->ucPackSeq;
                        if (param->usNackCount > 0)
                        {
                            ST_AVCLIENT_INFO *pstAvCli = findAvclientById(pMsgParam->aucPeerId);
                            if ((pstAvCli != MOS_NULL) && (pstAvCli->m_bEnableVideo>=1))
                            {
                                _US iOldPackIndex = 0;
                                for (_INT i=index; i<param->usNackCount; i++)
                                {
                                    _US iPackIndex = MOS_INET_NTOHS(param->usSeqList[i]);
                                    //MOS_PRINTF("a usSeqList[%d]:%d\n", i, iPackIndex);
                                    if (iPackIndex == iOldPackIndex)
                                    {
                                        i++;
                                        iPackIndex = MOS_INET_NTOHS(param->usSeqList[i]);
                                        //MOS_PRINTF("a short 1 usSeqList[%d]:%d\n", i, iPackIndex);
                                        for (_US j=iOldPackIndex+1; j!=iPackIndex; j++)
                                        {
                                            //MOS_PRINTF("a short 2 usSeqList[%d]:%d\n", i, j);
                                            ST_DATA_NODE *pstResNodeData = MOS_NULL;
                                            if ((pstResNodeData=Media_AudioHisGetPackNode(hAudioRead, j)) != MOS_NULL)
                                            {
                                                //MOS_PRINTF("audio FONDUD PACKAGE usSeqList[%d]=%d \t", i, iPackIndex);
                                                P2pProcessCmd::procSendMediaNode(pstAvCli->m_iceTranSport, pstAvCli->m_sLiveVideoChn,
                                                                                 EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                                                 pstResNodeData, EN_HTTP_STREAMER_AUDIO, 1, ucResSeq);
                                            }
                                        }
                                    }
                                    ST_DATA_NODE *pstResNodeData = MOS_NULL;
                                    if ((pstResNodeData=Media_AudioHisGetPackNode(hAudioRead, iPackIndex)) != MOS_NULL)
                                    {
                                        //MOS_PRINTF("audio FONDUD PACKAGE usSeqList[%d]=%d \t", i, iPackIndex);
                                        P2pProcessCmd::procSendMediaNode(pstAvCli->m_iceTranSport, pstAvCli->m_sLiveVideoChn,
                                                                         EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_LIVESTREAM,
                                                                         pstResNodeData, EN_HTTP_STREAMER_AUDIO, 1, ucResSeq);
                                    }
                                    iOldPackIndex = iPackIndex;
                                }
                            }
                        }
                    }
                    MOS_FREE(pstMsgHead);
                }
                else
                {
                    Mos_Sleep(10);
                }
            }
        }
    }
    Swd_AppThreadUnRegist(hSwdFeedDog);
    Media_AudioHisDelAllNode(hAudioRead);
    Media_AudioDestroyReadHandle2(hAudioRead);
    MOS_PRINTF("%s exit ok!!\n", __FUNCTION__);
    return MOS_OK;
}
/**********************end of live audio thread****************************************************/


ST_MSGP2P_MNG *P2pManageMent::MsgP2p_GetMng()
{
    return &m_p2pCmdFuncMnger;
}

/***********************************************************************
接受到的请求处理节点
************************************************************************/
static ST_MSGP2P_ACTIVE_NODE *P2pManageMent::MsgP2p_FindActiveNode(_UC usMsgType,_UC ucMsgId)
{
    ST_MSGP2P_ACTIVE_NODE *pstActiveMsgNode = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;

    KjRwMutexLockGuard mutex(m_mutexAvclientList, 0);
    FOR_EACHDATA_INLIST(&MsgP2p_GetMng()->stActiveFunList, pstActiveMsgNode, stIterator)
    {
        if(pstActiveMsgNode->usMsgType == usMsgType && pstActiveMsgNode->ucMsgId == ucMsgId )
        {
            return pstActiveMsgNode;
        }
    }
    return MOS_NULL;
}

_VOID P2pManageMent::p2pCmdregistActiveFunc(_UC usMsgType,_UC ucMsgId, PFUN_MSGMNG_ACTIVEPROC pFunActiveMsgProc)
{
    ST_MSGP2P_ACTIVE_NODE *pstActiveMsgNode = MOS_NULL;

    Mos_MutexLock(&MsgP2p_GetMng()->hMutex);
    // 查找信令节点
    pstActiveMsgNode = MsgP2p_FindActiveNode(usMsgType,ucMsgId);
    if(pstActiveMsgNode != MOS_NULL)
    {
        Mos_MutexUnLock(&MsgP2p_GetMng()->hMutex);
        return;
    }
    // 初始化信令
    pstActiveMsgNode = (ST_MSGP2P_ACTIVE_NODE*)MOS_MALLOCCLR(sizeof(ST_MSGP2P_ACTIVE_NODE));
    pstActiveMsgNode->ucMsgId        = ucMsgId;
    pstActiveMsgNode->usMsgType      = usMsgType;
    pstActiveMsgNode->pFunActiveProc = pFunActiveMsgProc;
    MOS_LIST_ADDTAIL(&MsgP2p_GetMng()->stActiveFunList, pstActiveMsgNode);
    Mos_MutexUnLock(&MsgP2p_GetMng()->hMutex);
    return;
}

/**
* @brief         init p2p command functions
* @author        Hejh
* @date          2021-05-13
*/
_VOID P2pManageMent::initCommandFunctions()
{
    if(MsgP2p_GetMng()->ucInitFlag == 1)
    {
        return;
    }
    MOS_MEMSET(&m_p2pCmdFuncMnger, 0, sizeof(ST_MSGP2P_MNG));
    MsgP2p_GetMng()->ucInitFlag = 1;
    Mos_MutexCreate(&MsgP2p_GetMng()->hMutex);
    MOS_LIST_INIT(&MsgP2p_GetMng()->stActiveFunList);    
    Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
    Config_SetCamerDisplayOpenFlag(0, MOS_FALSE);
    MOS_LOG_INF(P2PCMD_STRLOG,"p2p command init ok");

    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETDEVINFO_REQ,        P2pProcessCmd::procCmdGetDevInfo);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTMEDIA_REQ,        P2pProcessCmd::procCmdStartLiveVideo);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPMEDIA_REQ,         P2pProcessCmd::procCmdCloseLiveVideo);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTSPEAK_REQ,        P2pProcessCmd::procCmdStartSpeaker);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPSPEAK_REQ,         P2pProcessCmd::procCmdCloseSpeaker);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTDISPLAY_REQ,      P2pProcessCmd::procCmdStartDisplay);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPDISPLAY_REQ,       P2pProcessCmd::procCmdCloseDisplay);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_CONTORLDISPLAY_REQ,    P2pProcessCmd::procCmdContorlDisplay);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETRECORDCALENDER,     P2pProcessCmd::procCmdGetRecordCalender);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETRECORDLIST,         P2pProcessCmd::procCmdGetRecordList);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETJPGCANLEADER,       P2pProcessCmd::procCmdGetJpegCalender);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETJPGLIST,            P2pProcessCmd::procCmdGetJpegList);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_START_REQ,    P2pProcessCmd::procCmdStartPlayBack);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_CONTROL_REQ,  P2pProcessCmd::procCmdControlPlayBack);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_STOP_REQ,     P2pProcessCmd::procCmdStopPlayBack);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_P2PSESSION_CLOSE_REQ,  P2pProcessCmd::procCmdCloseSession);
    // p2pCmdregistActiveFunc(EN_OGCT_METHOD_KEEPALIVE, EN_CN21_P2P_KEEPALIVE_REQ,            P2pProcessCmd::procCmdReciveKeepAlive);
    // p2pCmdregistActiveFunc(EN_OGCT_METHOD_FORCEKEEPALIVE, EN_CN21_P2P_KEEPALIVE_FORCE,     P2pProcessCmd::procCmdReciveKeepAlive);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_FEEDBACK,  EN_CN21_P2P_FEEDBACK_REQ,             P2pProcessCmd::procCmdReciveFeedBack);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD,  EN_CN21_P2P_CMD_SELECT_CNTID_REQ,     P2pProcessCmd::procCmdSelectCntidReq);
#ifdef SUPPORT_NAT4_PUCH
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_START_NAT4HOLE_REQ,    P2pProcessCmd::procCmdStartNatHole);
    p2pCmdregistActiveFunc(EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_CLIENT_NAT4_INF_REQ,   P2pProcessCmd::procCmdClientNatInfoNotify);
#endif

    return;
}

/**
* @brief         Init a process command thread for one client
* @author        Hejh
* @date          2021-05-13
*/
_VOID P2pManageMent::initProcCommand( ST_AVCLIENT_INFO *pstTask)
{
    ST_THREAD_MNG *m_liveCmdThreadMng = &pstTask->m_liveCmdThreadMng;
    if(m_liveCmdThreadMng->ucInitFlag == 1)
    {
        return;
    }
    MOS_MEMSET(m_liveCmdThreadMng, 0, sizeof(ST_THREAD_MNG));
    m_liveCmdThreadMng->ucInitFlag = 1;
    m_liveCmdThreadMng->ucRunFlag  = 0;
    m_liveCmdThreadMng->hMsgQueque = Mos_MsgQueueCreate(MOS_FALSE, 30, "initProcCommand");
    MOS_LOG_INF(P2P_STRLOG,"%s Init processcmd for clentId:%s", __FUNCTION__, pstTask->m_uacPeerId );
}

/**
* @brief         Start process cmd for one client
* @author        Hejh
* @date          2021-05-13
*/
_UI P2pManageMent::startProcCommand(_VPTR uacPeerId)
{
    ST_MOS_LIST_ITERATOR             stIterator;
    ST_AVCLIENT_INFO *pstTask         = MOS_NULL;
    ST_THREAD_MNG *m_liveCmdThreadMng = MOS_NULL;
    _BOOL             bValid          = MOS_FALSE;
    m_mutexAvclientList.rdLock();
    FOR_EACHDATA_INLIST(&m_hIceClientList, pstTask, stIterator)
    {
        if (MOS_STRCMP(pstTask->m_uacPeerId, uacPeerId) == 0)
        {
            m_liveCmdThreadMng = &pstTask->m_liveCmdThreadMng;
            bValid = MOS_TRUE;
            break;
        }
    }
    m_mutexAvclientList.unlock();

    if (!bValid)
    {
        MOS_PRINTF("client %s not found in clientlist!\n", uacPeerId);
        return MOS_ERR;
    }

    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
    if(m_liveCmdThreadMng->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    if(m_liveCmdThreadMng->ucRunFlag == 1)
    {
        return MOS_OK;
    }
    m_liveCmdThreadMng->ucRunFlag  = 1;
#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif

    if(Mos_ThreadCreate((_UC*)"p2pCmdProc",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        P2pManageMent::p2pCommandThread, pstTask,MOS_NULL,&m_liveCmdThreadMng->hThread) == MOS_ERR)
    {
        m_liveCmdThreadMng->ucRunFlag = 0;
        return MOS_ERR;
    }
    MOS_LOG_INF(P2P_STRLOG,"%s start processcmd thread for clentId:%s ok", __FUNCTION__, pstTask->m_uacPeerId );
    return MOS_OK;
}

/**
* @brief         p2p process commmand thread for one client
* @author        Hejh
* @date          2021-05-13
*/
_VPTR P2pManageMent::p2pCommandThread(_VPTR arg)
{
    ST_AVCLIENT_INFO *pstTask = (ST_AVCLIENT_INFO *)arg;
    MOS_FUNRET_NULL_RETNULL(P2P_STRLOG, pstTask, __FUNCTION_);
    _UC  aucP2pThreadName[64] = {0};
    MOS_VSNPRINTF(aucP2pThreadName, sizeof(aucP2pThreadName), "%s%04x", P2P_CMD_MNG,  Mos_ThreadGetCurId());

    ST_THREAD_MNG *cmdThreadManager = &pstTask->m_liveCmdThreadMng;
    MOS_FUNRET_NULL_RETNULL(P2P_STRLOG, cmdThreadManager, __FUNCTION_);

    ST_P2P_CMD_MSG *pstMsgHead = MOS_NULL;
    getDiffTimems(&pstTask->m_tReiveAudioDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    getDiffTimems(&pstTask->m_tReiveVideoDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);

    kj_timer_t   tFeedDogTimeOut;
    kj_timer_init(&tFeedDogTimeOut);
    getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    _HSWDWRITE hSwdFeedDog = Swd_AppThreadRegist(aucP2pThreadName, FEED_DOG_MAX_TIMESEC);
    MOS_PRINTF("%s,recive userToken:%s watchdogName:%s\n", __FUNCTION__,   pstTask->m_uacPeerId, aucP2pThreadName);
    cmdThreadManager->ucOverFlag = EN_P2P_THREAD_MNG_TYPE_START;
    while(cmdThreadManager->ucRunFlag)
    {
        pstMsgHead = Mos_MsgQueuePop(cmdThreadManager->hMsgQueque);
        if(pstMsgHead)
        {
            //MOS_PRINTF("%s,recive userToken:%s type:%d id:%d\n", __FUNCTION__,  pstTask->m_uacPeerId, pstMsgHead->ucMsgType,pstMsgHead->ucMsgId);
            if (pstMsgHead->stMsgHead.usMsgType == EN_P2P_MSG_TYPE_NET)
            {
                JSON_HANDLE hRoot = Adpt_Json_Parse(pstMsgHead->aucMsgBody);
                ST_MSGP2P_ACTIVE_NODE *pstActiveMsgNode = MOS_NULL;
                // 查找信令节点
                pstActiveMsgNode =P2pManageMent::instance().MsgP2p_FindActiveNode(pstMsgHead->ucMsgType,pstMsgHead->ucMsgId);
                if ((pstActiveMsgNode != MOS_NULL) && (pstActiveMsgNode->pFunActiveProc != MOS_NULL))
                {
                    if (pstMsgHead->ucMsgType == EN_OGCT_METHOD_KEEPALIVE || pstMsgHead->ucMsgType == EN_OGCT_METHOD_FORCEKEEPALIVE)
                    {
                        ST_MSGP2P_OPTION msgParamOption;
                        MOS_MEMSET(&msgParamOption, 0, sizeof(msgParamOption));
                        msgParamOption.ucMsgId   = pstMsgHead->ucMsgId;
                        msgParamOption.usMsgType = pstMsgHead->ucMsgType;
                        msgParamOption.ucRsv[0]  = pstMsgHead->ucRsv[0];
                        msgParamOption.ucRsv[1]  = pstMsgHead->stMsgHead.usMsgLen;
                        //printf("id:%d type:%d res1:%d res2:%d\n", pstMsgHead->ucMsgId, pstMsgHead->ucMsgType, pstMsgHead->ucRsv[0], pstMsgHead->stMsgHead.usMsgLen);
                        if (msgParamOption.ucRsv[1] >0)
                        {
                            MOS_MEMCPY(msgParamOption.aucMsgBody,pstMsgHead->aucMsgBody, msgParamOption.ucRsv[1]);
                        }
                        pstActiveMsgNode->pFunActiveProc(pstTask, pstMsgHead->ucMsgType, &msgParamOption);
                    }
                    else if (pstMsgHead->ucMsgType == EN_OGCT_METHOD_FEEDBACK)
                    {
                        pstActiveMsgNode->pFunActiveProc(pstTask, pstMsgHead->stMsgHead.usMsgLen, pstMsgHead->aucMsgBody);
                    }
                    else
                    {
                        pstActiveMsgNode->pFunActiveProc(pstTask, pstMsgHead->iSeqNum, hRoot);
                    }
                }
                else
                {
                    if(hRoot != MOS_NULL)
                    {
                        // 处理信令服务器下发的信令
                        MsgMng_DispatchMsg(pstTask->m_uacPeerId, pstMsgHead->ucMsgType, pstMsgHead->ucMsgId, hRoot);
                    }
                }

                Adpt_Json_Delete(hRoot);
                if (pstTask->m_bChannelTimeOut == MOS_TRUE)
                {
                    pstTask->m_bChannelTimeOut = MOS_FALSE;
                }
            }
            MOS_FREE(pstMsgHead);

            if (getDiffTimems(&tFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
            {
                Swd_AppThreadFeedDog(hSwdFeedDog);
                getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
            }
        }
        else
        {
            if (getDiffTimems(&tFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
            {
                Swd_AppThreadFeedDog(hSwdFeedDog);
                getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
            }
                       
            if (pstTask->m_bEnableSpeaker == MOS_TRUE)
            {
                if (getDiffTimems(&pstTask->m_tReiveAudioDataTimeout,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= P2P_AUDIODATA_TIMEOUT_SEC)
                {
                    MOS_LOG_INF(P2P_STRLOG, "long time(%ds) not recv audiodata, need to close p2p speaker!!", P2P_AUDIODATA_TIMEOUT_SEC);                
                    Media_AudioPlayCancelFrameBuff(MOS_NULL);
                    Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                    pstTask->m_bEnableSpeaker  = MOS_FALSE;
                    Media_Notify_AudioPlay(pstTask->m_uacPeerId, 1, pstTask->m_bEnableSpeaker, pstTask->m_sAudioSpeakChn);
                    Media_AudioPlayDestroyWriteHandle(pstTask->m_hAudioPlay);
                    pstTask->m_sAudioSpeakChn  =  0;
                    pstTask->m_hAudioPlay = MOS_NULL;
                    #ifdef BUILD_ONBROADCAST_FALG
                    Broadcast_Task_Resume_CloseTalk();
                    #endif
                    P2pManageMent::instance().P2pDestroyTbsl((_VPTR)pstTask, kj_av_type_audio);
                }
            }

            if (pstTask->m_bEnableDisplay == MOS_TRUE)
            {
                if (getDiffTimems(&pstTask->m_tReiveVideoDataTimeout,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= P2P_AUDIODATA_TIMEOUT_SEC)
                {
                    Mos_MutexLock(&pstTask->hMutex);
                    MOS_LOG_INF(P2P_STRLOG, "long time(%ds) not recv videodata, need to close p2p display!!", P2P_AUDIODATA_TIMEOUT_SEC);                
                    Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
                    Config_SetCamerDisplayOpenFlag(0, MOS_FALSE);
                    pstTask->m_bEnableDisplay  = MOS_FALSE;
                    Media_Notify_VideoPlay(pstTask->m_uacPeerId, pstTask->m_bEnableDisplay);
                    Media_VideoDisPlayDestroyHandle(pstTask->m_hVideoPlay);   
                    pstTask->m_sVideoDisplayChn  =  0;
                    pstTask->m_hVideoPlay = MOS_NULL;
                    P2pManageMent::instance().P2pDestroyTbsl((_VPTR)pstTask, kj_av_type_video);
                    Mos_MutexUnLock(&pstTask->hMutex);
                }
            }
            Mos_Sleep(3);
        }

    }
    _VPTR pstMsg = MOS_NULL;
    Swd_AppThreadUnRegist(hSwdFeedDog);
    while((pstMsg = Mos_MsgQueuePop(cmdThreadManager->hMsgQueque)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    MOS_PRINTF("%s %d exit now!, peerId:%s \n", __FUNCTION__, __LINE__, pstTask->m_uacPeerId);
    //Mos_ThreadDelete(cmdThreadManager->hThread);
    //cmdThreadManager->hThread = MOS_NULL;
    //cmdThreadManager->ucRunFlag = 0;
    cmdThreadManager->ucOverFlag = EN_P2P_THREAD_MNG_TYPE_END;
    return MOS_OK;
}
/***********************************************************end of process cmd thread*************/

/**
* @brief         start playback thread for playing one mp4 file
* @author        Hejh
* @date          2021-05-13
*/
_UI P2pManageMent::startPlayback(_HP2PCHANNEL hP2pChannel, _UC *pucFileName)
{
    ST_AVCLIENT_INFO *pstTask         = (ST_AVCLIENT_INFO*)hP2pChannel;
    ST_PLAYBACK_MNG  *m_PlayBackMng   = &pstTask->m_playBackThreadMng;

    _UI uiStackSize =  MOS_THREAD_STACK_NORMAL_SIZE;//MOS_THREAD_STACK_HIGH_SIZE; //
    if(m_PlayBackMng->ucInitFlag == 0)
    {
        MOS_LOG_ERR(P2P_STRLOG,"%s PlayBack Not Init, start failed  \n", __FUNCTION__ );
        return MOS_ERR;
    }
    if(m_PlayBackMng->ucRunFlag == 1)
    {
        MOS_LOG_ERR(P2P_STRLOG,"%s  PlayBackThread  Is Already Running, start failed\n", __FUNCTION__ );
        return MOS_OK;
    }
    m_PlayBackMng->ucRunFlag  = 1;
    MOS_MEMSET(m_PlayBackMng->ucFilePath, 0, sizeof(m_PlayBackMng->ucFilePath));
    MOS_STRNCPY(m_PlayBackMng->ucFilePath, pucFileName, sizeof(m_PlayBackMng->ucFilePath));

#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    if(Mos_ThreadCreate((_UC*)"PlayBackProc",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        P2pManageMent::PlayBackThread, pstTask,MOS_NULL,&m_PlayBackMng->hThread) == MOS_ERR)
    {
        m_PlayBackMng->ucRunFlag = 0;
        return MOS_ERR;
    }

    MOS_LOG_INF(P2P_STRLOG,"%s PlayBack thread start ok, file:%s", __FUNCTION__, pucFileName );
    return MOS_OK;
}

/**
* @brief         Playing back files, continous or signel file mode
* @author        Hejh
* @date          2021-05-13
*/
_VPTR P2pManageMent::PlayBackThread(_VPTR arg)
{
    ST_AVCLIENT_INFO *pstTask = (ST_AVCLIENT_INFO *)arg;
    MOS_FUNRET_NULL_RETNULL(P2P_STRLOG, pstTask, __FUNCTION_);
    _INT iAdjustTime    = 0;
    _UI  uiBufLen       = 0;
    _UC  ucAVFlag       = 0;
    _UI  uiTimeStamp    = 0;
    _UC  ucFramePos     = 0;
    _UI  uiFrameLen     = 0;
    _RDFILEFD *pstRdStg_fileFD = MOS_NULL;
    ST_P2P_CMD_MSG *pstMsgHead = MOS_NULL;
    _UC  ucBuf[RECORD_VIDEO_NALU_BUFLEN]= {0};
    ST_PLAYBACK_MNG *PlayTreadMng = &pstTask->m_playBackThreadMng;

    pstRdStg_fileFD = RdStg_OpenPlayBackFile(PlayTreadMng->ucFilePath, &iAdjustTime, PlayTreadMng->ucPlayFlag);
    if (MOS_NULL == pstRdStg_fileFD)
    {
        MOS_LOG_ERR(P2P_STRLOG,"%s PlayBack open, file:%s Failed", __FUNCTION__, PlayTreadMng->ucFilePath );
        return MOS_NULL;
    }

    if (PlayTreadMng->hVideoHander == MOS_NULL)
    {
        PlayTreadMng->hVideoHander = Media_SdVideoCreatReadHandle(EN_HTTP_STREAMER_VIDEO);
    }

    if (PlayTreadMng->hAudioHander == MOS_NULL)
    {
        PlayTreadMng->hAudioHander = Media_SdVideoCreatReadHandle(EN_HTTP_STREAMER_AUDIO);
    }

    PlayTreadMng->ucPlayStatus = EN_PLAYBACK_STATUS_START;
    _UI  uiPlayStatus    = PlayTreadMng->ucPlayStatus;
    _US  usWinSize[3]    = {100, 100, 100};
    _US  usMediaEndSeq[3]= {0, 0, 0};
    _UI  uiFileEndFlag   = 0;
    _INT iDebug          = 0;
    _INT iStartIndex     = 0;
    _INT iEndIndex       = 0;
    usWinSize[EN_HTTP_STREAMER_VIDEO] = PlayTreadMng->usAvWinSize[0];
    usWinSize[EN_HTTP_STREAMER_AUDIO] = PlayTreadMng->usAvWinSize[1];

    //just for testting
    if (Mos_FileIsExist("/tmp/debug_playback") == MOS_TRUE)
        iDebug = 1;
    
    Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, 1);
    PlayTreadMng->ucOverFlag = EN_P2P_THREAD_MNG_TYPE_START;
    while(PlayTreadMng->ucRunFlag)
    {
        pstMsgHead = Mos_MsgQueuePop(PlayTreadMng->hMsgQueque);
        if(pstMsgHead)
        {
            if (pstMsgHead->stMsgHead.usMsgType == EN_P2P_MSG_TYPE_NET)
            {
                if (pstMsgHead->ucMsgId == EN_CN21_P2P_CMD_PLAYBACK_CONTROL_REQ)
                {
                    JSON_HANDLE hBody = Adpt_Json_Parse(pstMsgHead->aucMsgBody);
                    _UI uiVod       = 0;   
                    _UI uiVodBak    = 0;                  
                    _UI uiChannelId = 0;
                    _UI uiParamFlag = 0;
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Vod"),&uiVod);
                    if (uiVod & VOD_CMD_SEEK)
                    {
                        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID_New"),&uiChannelId);
                    }
                    else
                    {
                        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID"),&uiChannelId);
                    }
                    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Param"),&uiParamFlag);

                    MOS_PRINTF(">>>>recive control playback chanl:%u vod:%u flag:%u\n",  uiChannelId, uiVod, uiParamFlag);
                    uiVodBak = uiVod & VOD_CMD_PAUSE;
                    if (uiVodBak ==  VOD_CMD_PAUSE)
                    {
                        PlayTreadMng->ucPlayStatus = EN_PLAYBACK_STATUS_PAUSE;
                        uiPlayStatus = PlayTreadMng->ucPlayStatus;
                        MOS_LOG_INF(P2P_STRLOG, "recive PlayBackThread PlayBack pause cmd!!!!");
                    }

                    uiVodBak = uiVod & VOD_CMD_REPLAY;
                    if (uiVodBak == VOD_CMD_REPLAY)
                    {
                        PlayTreadMng->ucPlayStatus = EN_PLAYBACK_STATUS_START;
                        uiPlayStatus = PlayTreadMng->ucPlayStatus;
                        MOS_LOG_INF(P2P_STRLOG, "recive PlayBackThread PlayBack Replay cmd!!!!");
                    }

                    uiVodBak = uiVod & VOD_CMD_SEEK;
                    if (uiVodBak == VOD_CMD_SEEK)
                    {
                        _UC *pucSeekTime = MOS_NULL;
                        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"Pos"), &pucSeekTime);
                        if (pucSeekTime != MOS_NULL)
                        {
                            MOS_LOG_INF(P2P_STRLOG, "recive PlayBackThread PlayBack SEEK POS: %s", pucSeekTime);
                            PlayTreadMng->ucPlayStatus = EN_PLAYBACK_STATUS_START;
                            uiPlayStatus = PlayTreadMng->ucPlayStatus;
                            if (1)//PlayTreadMng->ucPlayFlag ==1)
                            {
                                RdStg_ClosePlayBackFile(pstRdStg_fileFD);
                                pstRdStg_fileFD = MOS_NULL;
                                pstRdStg_fileFD = RdStg_OpenPlayBackFile(pucSeekTime, &iAdjustTime, PlayTreadMng->ucPlayFlag);
                                if (MOS_NULL == pstRdStg_fileFD)
                                {
                                    MOS_LOG_ERR(P2P_STRLOG, "PlayBackThread Seek MOS_NULL == pstRdStg_fileFD");
                                    PlayTreadMng->ucRunFlag = 0;
                                    Adpt_Json_Delete(hBody);
                                    MOS_FREE(pstMsgHead);
                                    continue;
                                }
                                else
                                {
                                    MOS_LOG_INF(P2P_STRLOG, "PlayBackThread Seek open playback file %s successful !!!", PlayTreadMng->ucFilePath);
                                }
                            }
                            else//Todo:just for seek on one file
                            {
                                RdStg_SeekOnOneFile(pstRdStg_fileFD, pucSeekTime, &iAdjustTime);
                            }
                            uiFileEndFlag = 0;

                            if (uiChannelId != 0 && (PlayTreadMng->usChannel != uiChannelId))
                            { 
                                PlayTreadMng->usChannel = uiChannelId; 
                                Media_SdVideoDelAllNode(PlayTreadMng->hAudioHander);
                                Media_SdVideoDelAllNode(PlayTreadMng->hVideoHander);
                                usWinSize[EN_HTTP_STREAMER_VIDEO] = PlayTreadMng->usAvWinSize[0];
                                usWinSize[EN_HTTP_STREAMER_AUDIO] = PlayTreadMng->usAvWinSize[1];
                            }
                        }
                    }

                    uiVodBak = uiVod & VOD_CMD_KEYFRAME;
                    if (uiVodBak == VOD_CMD_KEYFRAME)
                    {
                       MOS_LOG_INF(P2P_STRLOG, "PlayBackThread PlayBack VOD_CMD_KEYFRAME");
                    }

                    uiVodBak = uiVod & VOD_CMD_TEADOWN;
                    if (uiVodBak == VOD_CMD_TEADOWN)
                    {
                        MOS_LOG_INF(P2P_STRLOG, "PlayBackThread PlayBack VOD_CMD_TEADOWN");
                        PlayTreadMng->ucRunFlag = 0;
                    }
                    //P2pProcessCmd::procCmdPlayBackResp((_HP2PCHANNEL)pstTask, PlayTreadMng->usChannel,  pstMsgHead->iSeqNum, uiVodBak);
                    Adpt_Json_Delete(hBody);
                }
                else if (pstMsgHead->ucMsgId ==EN_CN21_P2P_CMD_PLAYBACK_START_REQ)
                {
                    _UC *pucSeekTime = MOS_NULL;
                    uiFileEndFlag = 0;
                    JSON_HANDLE hBody = Adpt_Json_Parse(pstMsgHead->aucMsgBody);
                    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody, (_UC*)"Time"), &pucSeekTime);
                    MOS_LOG_INF(P2P_STRLOG, "PlayBackThread PlayBack replay POS: %s", pucSeekTime);
                    PlayTreadMng->ucPlayStatus = EN_PLAYBACK_STATUS_START;
                    uiPlayStatus = PlayTreadMng->ucPlayStatus;
                    if (1)//PlayTreadMng->ucPlayFlag ==1)
                    {
                        RdStg_ClosePlayBackFile(pstRdStg_fileFD);
                        pstRdStg_fileFD = MOS_NULL;
                        MOS_LOG_INF(P2P_STRLOG, "PlayBackThread PlayBack SEEK Time: %s", pucSeekTime);

                        pstRdStg_fileFD = RdStg_OpenPlayBackFile(pucSeekTime, &iAdjustTime, PlayTreadMng->ucPlayFlag);
                        if (MOS_NULL == pstRdStg_fileFD)
                        {
                            MOS_LOG_INF(P2P_STRLOG, "PlayBackThread Seek MOS_NULL == pstRdStg_fileFD \r\n");
                            PlayTreadMng->ucRunFlag = 0;
                            Adpt_Json_Delete(hBody);
                            MOS_FREE(pstMsgHead);
                            continue;
                        }
                        else
                        {
                            MOS_LOG_INF(P2P_STRLOG, "PlayBackThread Seek open playback file %s successful !!! \r\n", PlayTreadMng->ucFilePath);
                        }
                    }
                    Adpt_Json_Delete(hBody);
                }
                else if (pstMsgHead->ucMsgId == 1)
                {
                    ST_P2P_FEEDBACK_MSG *pMsgParam = ((ST_P2P_FEEDBACK_MSG*)pstMsgHead);
                    ST_MSGP2P_FEEDBACK  *param = (ST_MSGP2P_FEEDBACK*)pMsgParam->aucMsgBody;
                    param->usChannel    = MOS_INET_NTOHS(param->usChannel);
                    param->usWinSize    = MOS_INET_NTOHS(param->usWinSize);
                    param->usWinBeginSeq= MOS_INET_NTOHS(param->usWinBeginSeq);
                    param->usNackCount  = MOS_INET_NTOHS(param->usNackCount);
                    if (iDebug >0)
                    MOS_PRINTF("#######playback feedback form:%s chan:%u ackSeq:%d beginseq:%u nackcount:%u av:%d psrtmode:%d winsize:%d,acktype:%d  \n",
                               pMsgParam->aucPeerId, param->usChannel, param->ucPackSeq, param->usWinBeginSeq, param->usNackCount,
                               param->ucAvType, (param->ucPsrtMode), (param->usWinSize), param->ucAckType);
                    //P2pProcessCmd::procCmdPlayBackFeedBackResp((_HP2PCHANNEL)pstTask, param, EN_FEED_BACK_NORMAL);
                    if (param->ucAckType !=0)
                    {
                       MOS_PRINTF("recive acktype:%d, ignore\n", param->ucAckType);
                       MOS_FREE(pstMsgHead);
                       continue;
                    }

                    if ((param->ucAvType == EN_HTTP_STREAMER_AUDIO) || (param->ucAvType == EN_HTTP_STREAMER_VIDEO))
                    {
                        _UC  ucResSeq      = param->ucPackSeq;
                        _INT iMaxSendData  = param->usWinSize-param->usNackCount;
                        _UI  uiMaxNackNum  = param->usNackCount;
                        _HPBVIDEOREAD hMediaRead = PlayTreadMng->hAudioHander;
                        _UC  ucAvType = EN_HTTP_STREAMER_AUDIO;
                        if (param->ucAvType == EN_HTTP_STREAMER_VIDEO)
                        {
                            hMediaRead = PlayTreadMng->hVideoHander;
                            ucAvType   = EN_HTTP_STREAMER_VIDEO;
                        }
                        if ( uiMaxNackNum> 0)//max resend list
                        {
                            _INT index         = 0;
                            _INT iTmp          = 0;
                            _UI  iOldPackIndex = -1;
                            _UI  uiMaxPackCount= 0;
                            if (iDebug >0)
                            {
                                MOS_PRINTF("type:%d usNackCount list:", ucAvType);
                                for (int i=index; i<param->usNackCount; i++)
                                {
                                    MOS_PRINTF("%d ",  MOS_INET_NTOHS(param->usSeqList[i]));
                                }
                            }
                            ST_MOS_LIST packageList;
                            MOS_LIST_INIT(&packageList);
                            {
                                for (int i = index; i < param->usNackCount; i++)
                                {
                                    _US iPackIndex = MOS_INET_NTOHS(param->usSeqList[i]);
                                    if ((iPackIndex == iOldPackIndex) && (i != index))
                                    {
                                        iStartIndex = iPackIndex + 1;
                                        iEndIndex   = MOS_INET_NTOHS(param->usSeqList[i + 1]);
                                        for (_US j = iStartIndex; j != iEndIndex; j++)
                                        {
                                            uiMaxPackCount++;
                                        }
                                    }
                                    else
                                    {
                                        iOldPackIndex = iPackIndex;
                                        uiMaxPackCount++;
                                    }
                                }
                                if (iDebug >0)
                                    MOS_PRINTF("\n type:%d  uiMaxPackCount: %u \n", ucAvType, uiMaxPackCount); 
                            }
                            index         = 0;
                            iOldPackIndex = 0;
                            iTmp          = 0;
                            ST_DATA_PACKAGE_INFO *pstPackInfo = (ST_DATA_PACKAGE_INFO*)Mos_MallocClr(sizeof(ST_DATA_PACKAGE_INFO)*uiMaxPackCount);

                            for (_INT i = index; i < param->usNackCount; i++)
                            {
                                _US iPackIndex = MOS_INET_NTOHS(param->usSeqList[i]); 
                                if ((iPackIndex == iOldPackIndex) && (i != index))
                                {
                                    iStartIndex = iPackIndex + 1;
                                    iEndIndex   = MOS_INET_NTOHS(param->usSeqList[i + 1]);
                                    for (_US j = iStartIndex; j != iEndIndex; j++)
                                    {
                                        pstPackInfo[iTmp].uiPackNum = j;
                                        MOS_LIST_ADDTAIL(&packageList, &pstPackInfo[iTmp]);
                                        if (iDebug)
                                            printf("pstPackInfo[%d] sub push %d\n", iTmp, j);
                                        iTmp++;
                                    }
                                }
                                else
                                {
                                    iOldPackIndex = iPackIndex;
                                    pstPackInfo[iTmp].uiPackNum = iPackIndex;
                                    MOS_LIST_ADDTAIL(&packageList, &pstPackInfo[iTmp]);
                                    if (iDebug)
                                        printf("pstPackInfo[%d] push %d\n", iTmp, iPackIndex);
                                    iTmp++;
                                }
                            }
                            Media_SdVideoDelListNodes(hMediaRead, &packageList);
                            MOS_LIST_RMVALL(&packageList, MOS_FALSE);
                            MOS_FREE(pstPackInfo);
                        }

                        _US startIndex      = param->usWinBeginSeq;
                        usWinSize[ucAvType] = iMaxSendData ;

                        if (iDebug >0)
                        MOS_PRINTF("type:%d usNackCount delete startIndex: %d \n", ucAvType, startIndex);
                        Media_SdVideoDelMultiyNode(hMediaRead, startIndex-1);

                        for (int i=0; i<iMaxSendData; i++)
                        {
                            ST_DATA_NODE *stNodeData = MOS_NULL;
                            if (i==0) //first frame
                            {
                                stNodeData = Media_SdVideoHisGetHead(hMediaRead);
                            }
                            else
                            {
                                stNodeData = Media_SdVideoHisShiftNextNode(hMediaRead);
                            }

                            if (stNodeData != MOS_NULL)
                            {
                                if (iDebug >0)
                                MOS_PRINTF("Audio send packet index: %d iMaxSendData:%d\n", startIndex, iMaxSendData);

                                if (stNodeData != MOS_NULL)
                                {
                                    ST_DATA_NODE *pstTmpNode = stNodeData;
                                    if (iDebug >0)
                                        MOS_PRINTF(" SEND type:%d>>>> I:%d Time:%u, seq:%u, off:%u, framePos:%02x framebg:%d fameend:%d nalstart:%d naulend:%d, nalLen:%d,len:%u\n",
                                                   ucAvType, i, pstTmpNode->uiTimeStamp, pstTmpNode->usSeqNum, pstTmpNode->usOffset,
                                                   pstTmpNode->stFrameNode.ucFramPos,
                                                   MD_GETFRAMEPOS(pstTmpNode->stFrameNode.ucFramPos)&MD_FRAME_HEAD,
                                                   MD_GETFRAMEPOS(pstTmpNode->stFrameNode.ucFramPos)&MD_FRAME_TAIL,
                                                   MD_GETFRAMEPOS(pstTmpNode->stFrameNode.ucFramPos)&MD_NAUL_HEAD,
                                                   MD_GETFRAMEPOS(pstTmpNode->stFrameNode.ucFramPos)&MD_NALU_TAIL,
                                                   pstTmpNode->stFrameNode.uiNaluLen, pstTmpNode->stFrameNode.usDatalen);
                                }

                                P2pProcessCmd::procSendMediaNode(pstTask->m_iceTranSport, PlayTreadMng->usChannel,
                                                                 EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_RECORDSTREAM,
                                                                 stNodeData, ucAvType, 1, (stNodeData->aucUseFlag[0]==1)?ucResSeq:0);
                                stNodeData->aucUseFlag[0] = 1;
                                usWinSize[ucAvType]--;
                                if ( (uiFileEndFlag==1) && (stNodeData->usSeqNum==usMediaEndSeq[ucAvType]) )
                                {
                                    P2pProcessCmd::procCmdFeedBackResp((_HP2PCHANNEL)pstTask, ucAvType, PlayTreadMng->usChannel,
                                                                       EN_FEED_BACK_FINISH_SENDING, usMediaEndSeq[ucAvType], param->ucPackSeq);
                                }
                            }
                            else
                            {
                                break;
                            }
                        }
                        if ( (usWinSize[ucAvType]>0) &&  (Media_SdVideoWriteEmpty(hMediaRead) == MOS_TRUE))
                        {
                            P2pProcessCmd::procCmdFeedBackResp((_HP2PCHANNEL)pstTask, ucAvType, PlayTreadMng->usChannel,
                                                               EN_FEED_BACK_PAUSE_SENDDING, 0, param->ucPackSeq);
                        }
                    }
                }
            }
            MOS_FREE(pstMsgHead);
        }
        else
        {
            if (uiPlayStatus == EN_PLAYBACK_STATUS_START)
            {
                uiBufLen = 0;
                MOS_MEMSET(ucBuf, 0x0, RECORD_VIDEO_NALU_BUFLEN);
                ucFramePos = 0;
                //ucAVFlag   = 0;
                uiTimeStamp=0;
                //uiFrameLen= 0;
                _BOOL bVBuffValid = MOS_TRUE;
                _BOOL bABuffValid = MOS_TRUE;
                if (Media_SdVideoWriteAvailable(PlayTreadMng->hVideoHander) == MOS_FALSE)
                {
                     bVBuffValid = MOS_FALSE;
                }

                if (bVBuffValid == MOS_FALSE)
                {
                    if (usWinSize[EN_HTTP_STREAMER_VIDEO] > 0)
                    {
                        ST_DATA_NODE *stNodeData = Media_SdVideoHisShiftNextNode(PlayTreadMng->hVideoHander);
                        if ((stNodeData != MOS_NULL) && (stNodeData->aucUseFlag[0]==0))
                        {
                            P2pProcessCmd::procSendMediaNode(pstTask->m_iceTranSport, PlayTreadMng->usChannel,
                                                             EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_RECORDSTREAM,
                                                             stNodeData, EN_HTTP_STREAMER_VIDEO, 1, 0);
                            usWinSize[EN_HTTP_STREAMER_VIDEO]--;
                            stNodeData->aucUseFlag[0] = 1;

                            //send finish sendding data
                            if ( (uiFileEndFlag==1) && (stNodeData->usSeqNum==usMediaEndSeq[EN_HTTP_STREAMER_VIDEO]) )
                            {
                                P2pProcessCmd::procCmdFeedBackResp((_HP2PCHANNEL)pstTask, EN_HTTP_STREAMER_VIDEO, PlayTreadMng->usChannel,
                                                                   EN_FEED_BACK_FINISH_SENDING, usMediaEndSeq[EN_HTTP_STREAMER_VIDEO], 0);
                            }
                        }
                    }
                }

                if (Media_SdVideoWriteAvailable(PlayTreadMng->hAudioHander) == MOS_FALSE)
                {
                    bABuffValid = MOS_FALSE;
                }

                if (bABuffValid == MOS_FALSE)
                {
                    if (usWinSize[EN_HTTP_STREAMER_AUDIO] > 0)
                    {
                        ST_DATA_NODE *stNodeData = Media_SdVideoHisShiftNextNode(PlayTreadMng->hAudioHander);
                        if ((stNodeData != MOS_NULL) && (stNodeData->aucUseFlag[0]==0))
                        {
                            P2pProcessCmd::procSendMediaNode(pstTask->m_iceTranSport, PlayTreadMng->usChannel,
                                                             EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_RECORDSTREAM,
                                                             stNodeData, EN_HTTP_STREAMER_AUDIO, 1, 0);
                            usWinSize[EN_HTTP_STREAMER_AUDIO]--;
                            stNodeData->aucUseFlag[0] = 1;

                            //send finish sendding data
                            if ( (uiFileEndFlag==1) && (stNodeData->usSeqNum==usMediaEndSeq[EN_HTTP_STREAMER_AUDIO]) )
                            {
                                P2pProcessCmd::procCmdFeedBackResp((_HP2PCHANNEL)pstTask, EN_HTTP_STREAMER_AUDIO, PlayTreadMng->usChannel,
                                                                   EN_FEED_BACK_FINISH_SENDING, usMediaEndSeq[EN_HTTP_STREAMER_AUDIO], 0);
                            }
                        }
                        else
                        {
                            if (PlayTreadMng->ucDownFlag <=0)
                                Mos_Sleep(4);
                            continue;
                        }
                    }
                }

                //audio or video readbuffer is full, just wait
                if (!bABuffValid || !bVBuffValid)
                {
                    if (PlayTreadMng->ucDownFlag <=0)
                        Mos_Sleep(10);
                    else
                        Mos_Sleep(10);

                    continue;
                }

                if (uiFileEndFlag == 1)
                {
                    if (Media_SdVideoWriteEmpty(PlayTreadMng->hAudioHander) && Media_SdVideoWriteEmpty(PlayTreadMng->hAudioHander))
                    {
                        //send finish sendding data
                        {
                            ST_MSGP2P_FEEDBACK param;
                            MOS_MEMSET(&param, 0, sizeof(param));
                            for (int i=1; i<3; i++)
                            {
                                P2pProcessCmd::procCmdFeedBackResp((_HP2PCHANNEL)pstTask, i, PlayTreadMng->usChannel,
                                                                   EN_FEED_BACK_FINISH_SENDING, usMediaEndSeq[i], 0);
                                Mos_Sleep(3);
                            }
                        }
                        P2pProcessCmd::procCmdPlayBackResp((_HP2PCHANNEL)pstTask, PlayTreadMng->usChannel,  1000, 0x08);
                        MOS_LOG_INF(P2P_STRLOG, "playback file end!!");
                        break;
                    }
                    else
                    {
                        Mos_Sleep(10);
                        continue;
                    }
                }

                _INT iRet = RdStg_ReadPlayBackFile(pstRdStg_fileFD, ucBuf, &uiBufLen, &ucAVFlag, &uiTimeStamp, &ucFramePos, &uiFrameLen);
                if (uiBufLen > 0)
                {                    
                    _HPBVIDEOREAD hMediaRead = PlayTreadMng->hAudioHander;
                    _UC  ucAvType = EN_HTTP_STREAMER_AUDIO;
                    if (ucAVFlag == 1)
                    {
                        hMediaRead = PlayTreadMng->hVideoHander;
                        ucAvType   = EN_HTTP_STREAMER_VIDEO;
                    }
                    if ((ucAVFlag == 1) || (ucAVFlag == 2) )// Video
                    {
                        ST_DATA_NODE *stNodeData = Media_SdVideoMakeOneNode(hMediaRead, ucBuf,
                                                                            uiBufLen, uiTimeStamp, ucFramePos, uiFrameLen);
                        if (usWinSize[ucAvType] > 0)
                        {
                            P2pProcessCmd::procSendMediaNode(pstTask->m_iceTranSport, PlayTreadMng->usChannel,
                                                             EN_OGCT_METHOD_DATA, EN_OGCT_MEDIA_DATA_RECORDSTREAM,
                                                             stNodeData, ucAvType, 1, 0);
                            usWinSize[ucAvType]--;
                            stNodeData->aucUseFlag[0] = 1;
                        }
                        usMediaEndSeq[ucAVFlag] = stNodeData->usSeqNum;

                        if ((iDebug >0) && (stNodeData != MOS_NULL))
                        {
                            ST_DATA_NODE *pstTmpNode = stNodeData;
                                MOS_PRINTF(" type:%d add Time:%u, seq:%u, off:%u, framePos:%02x framebg:%d fameend:%d nalstart:%d naulend:%d, nalLen:%d,len:%u,usedflag:%d\n",
                                           ucAvType, pstTmpNode->uiTimeStamp, pstTmpNode->usSeqNum, pstTmpNode->usOffset,
                                           pstTmpNode->stFrameNode.ucFramPos,
                                           MD_GETFRAMEPOS(pstTmpNode->stFrameNode.ucFramPos)&MD_FRAME_HEAD,
                                           MD_GETFRAMEPOS(pstTmpNode->stFrameNode.ucFramPos)&MD_FRAME_TAIL,
                                           MD_GETFRAMEPOS(pstTmpNode->stFrameNode.ucFramPos)&MD_NAUL_HEAD,
                                           MD_GETFRAMEPOS(pstTmpNode->stFrameNode.ucFramPos)&MD_NALU_TAIL,
                                           pstTmpNode->stFrameNode.uiNaluLen, pstTmpNode->stFrameNode.usDatalen,  pstTmpNode->aucUseFlag[0]);
                        }
                        Media_SdVideoHisAddOneNode(hMediaRead, stNodeData);
                    }
                }
                else
                {
                    if (iRet == MOS_ERR_FILEFINISH)
                    {
                        uiFileEndFlag = 1;
                    }
                }
            }
            else
            {
                if (PlayTreadMng->ucDownFlag <=0)
                {
                    Mos_Sleep(50);
                }
                else
                {
                    Mos_Sleep(10);
                }
            }
        }
    }

    RdStg_ClosePlayBackFile(pstRdStg_fileFD);
    pstRdStg_fileFD = MOS_NULL;

    if (PlayTreadMng->hAudioHander != MOS_NULL)
    {
        Media_SdVideoDestroyReadHandle(PlayTreadMng->hAudioHander);
        PlayTreadMng->hAudioHander = MOS_NULL;
    }

    if (PlayTreadMng->hVideoHander != MOS_NULL)
    {
        Media_SdVideoDestroyReadHandle(PlayTreadMng->hVideoHander);
        PlayTreadMng->hVideoHander = MOS_NULL;
    }
    //pstTask->m_playBackThreadMng.ucRunFlag = 0;
    //Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, P2pManageMent::instance().getOnVideoClient()?1:0);
    //Mos_ThreadDelete(pstTask->m_playBackThreadMng.hThread);
    //pstTask->m_playBackThreadMng.hThread = MOS_NULL;
    PlayTreadMng->ucOverFlag = EN_P2P_THREAD_MNG_TYPE_END;
    if (iDebug)
        MOS_PRINTF("%s:%d PlayTreadMng->ucOverFlag set to 2\r\n", __FUNCTION__, __LINE__);
    return MOS_OK;
}

_VOID  P2pManageMent::onP2pStatus_Disconnected_Handle(_VPTR pstP2pAddrInfo, kj_code status_coder)
{
    ST_P2PTURN_ADDRINFO *pstP2pInfo = (ST_P2PTURN_ADDRINFO*)pstP2pAddrInfo;
    ST_AVCLIENT_INFO *pstAvClient   = pstP2pInfo->pPrivateData;
    if (pstAvClient == MOS_NULL)
    {
        MOS_LOG_ERR(P2P_STRLOG, "Get AvClient Failed\n");
        return;
    }
    
    if (pstAvClient->m_iceTranSport->uiTransResult == EN_P2P_MSG_STATUS_ICENEG_OK)
    {
        P2pManageMent::instance().setClientTimeOut(pstAvClient->m_uacPeerId);
    }
    
    MOS_LOG_INF(P2P_STRLOG, "status code : %d\n", status_coder);
}

_VOID  P2pManageMent::onP2pStatus_ConnectFailed_Handle(_VPTR pstP2pAddrInfo, kj_code status_coder)
{
    ST_P2PTURN_ADDRINFO *pstP2pInfo = (ST_P2PTURN_ADDRINFO*)pstP2pAddrInfo;
    ST_AVCLIENT_INFO *pstAvClient   = pstP2pInfo->pPrivateData;
    if (pstAvClient == MOS_NULL)
    {
        if ((pstP2pInfo->pcbDestoryClienRome != MOS_NULL) && (pstP2pInfo->pKjClienRome != MOS_NULL))
        {
            pstP2pInfo->pcbDestoryClienRome((_VPTR)pstP2pInfo->pKjClienRome);
        }        
        MOS_LOG_ERR(P2P_STRLOG, "Get AvClient Failed\n");
        return;
    }
    
    pstAvClient->m_iceTranSport->uiTransResult = EN_P2P_MSG_STATUS_ICENEG_FAIL;

    P2pManageMent::instance().setClientTimeOut(pstAvClient->m_uacPeerId);

    MOS_LOG_INF(P2P_STRLOG, "status code : %d\n", status_coder);
}

_VOID  P2pManageMent::onP2pStatus_Connecting_Handle(_VPTR pstP2pAddrInfo, kj_code status_coder)
{
    ST_P2PTURN_ADDRINFO *pstP2pInfo = (ST_P2PTURN_ADDRINFO*)pstP2pAddrInfo;
    ST_AVCLIENT_INFO *pstAvClient   = pstP2pInfo->pPrivateData;
    if (pstAvClient == MOS_NULL)
    {
        MOS_LOG_ERR(P2P_STRLOG, "Get AvClient Failed\n");
        return;
    }

    MOS_LOG_INF(P2P_STRLOG, "status code : %d\n", status_coder);
}

_VOID  P2pManageMent::onP2pStatus_Connected_Handle(_VPTR pstP2pAddrInfo, kj_code status_coder)
{
    ST_P2PTURN_ADDRINFO *pstP2pInfo = (ST_P2PTURN_ADDRINFO*)pstP2pAddrInfo;
    ST_AVCLIENT_INFO *pstAvClient   = pstP2pInfo->pPrivateData;
    if (pstAvClient == MOS_NULL)
    {
        MOS_LOG_ERR(P2P_STRLOG, "Get AvClient Failed\n");
        return;
    }

    pstAvClient->m_iceTranSport->uiTransResult = EN_P2P_MSG_STATUS_ICENEG_OK;
    P2pManageMent::instance().startProcCommand(pstAvClient->m_uacPeerId);

    MOS_LOG_INF(P2P_STRLOG, "status code : %d\n", status_coder);
}

/// 连接状态回调
/// @param rome rome实例
/// @param state 状态
/// @param status 0:成功；其他参看kj_code的枚举值
_VOID  P2pManageMent::onP2pStatusCb(kj_rome *rome, kj_cnt_state state, kj_code status_coder)
{
    
    ST_P2PTURN_ADDRINFO *pstP2pAddrInfo = AvClient_GetTurnAddrByKjClienRome(rome);
    if (pstP2pAddrInfo == MOS_NULL)
    {
        MOS_LOG_ERR(P2P_STRLOG, "AvClient_GetTurnAddrByKjClienRome Failed with kjrome(%p)\n", rome);
        return;
    }

	switch(state) 
    {
        case kj_cnt_state_disconnected:
            P2pManageMent::onP2pStatus_Disconnected_Handle((_VPTR)pstP2pAddrInfo, status_coder);
            break;
        case kj_cnt_state_connect_fail:
            P2pManageMent::onP2pStatus_ConnectFailed_Handle((_VPTR)pstP2pAddrInfo, status_coder);
            break;
        case kj_cnt_state_connecting:
            P2pManageMent::onP2pStatus_Connecting_Handle((_VPTR)pstP2pAddrInfo, status_coder);
            break;
        case kj_cnt_state_connected:
            P2pManageMent::onP2pStatus_Connected_Handle((_VPTR)pstP2pAddrInfo, status_coder);
            break; 
        default:
            break;
    }

}

/// 收到数据回调
/// @param rome rome实例
/// @param data 数据指针
/// @param data_len 数据长度
_VOID  P2pManageMent::onP2pRecvDataCb(kj_rome *rome, const void *data, size_t data_len)
{
    ST_P2PTURN_ADDRINFO *pstP2pAddrInfo = AvClient_GetTurnAddrByKjClienRome(rome);
    if (pstP2pAddrInfo != MOS_NULL)
    {
        ST_AVCLIENT_INFO *pstAvClient =  MOS_NULL;
        pstAvClient = (ST_AVCLIENT_INFO*)pstP2pAddrInfo->pPrivateData;
        P2pProcessCmd::instance().PaseReciveData((_HP2PCHANNEL)pstAvClient, (_UC*)data, data_len);
    }
    else
    {
        MOS_LOG_ERR(P2P_STRLOG, "AvClient_GetTurnAddrByKjClienRome Failed with kjrome(%p)\n", rome);
        return;
    }

}

// 获取到SDP信息需要发送的回调
// @param rome rome实例
// @param sdp 本端发送给对端的SDP信息
// @param ipv6 0:IPv4；1:IPv6
// @return 发送错误码，0:成功；1:信令不可用；3:发送失败
_INT P2pManageMent::onP2pSendSdpToEndPointCb(kj_rome *rome, const char *sdp, int ipv6)
{
    MOS_LOG_ERR(P2P_STRLOG, "onP2pSendSdpToEndPointCb\n");
    if (sdp == MOS_NULL)
    {
        MOS_LOG_ERR(P2P_STRLOG, "sdp is err\n");
        return MOS_ERR;
    }

    ST_P2PTURN_ADDRINFO *pstP2pAddrInfo = AvClient_GetTurnAddrByKjClienRome(rome);
    if (pstP2pAddrInfo != MOS_NULL)
    {
        if (ipv6)
        {
            MOS_MEMCPY(pstP2pAddrInfo->aucDevIpv6SdpInfo, sdp, sizeof(pstP2pAddrInfo->aucDevIpv6SdpInfo));
        }
        else
        {
            MOS_MEMCPY(pstP2pAddrInfo->aucDevIpv4SdpInfo, sdp, sizeof(pstP2pAddrInfo->aucDevIpv4SdpInfo));
        }

        ST_P2P_CMDTASK_MSG *pstCmdMsg = ipv6 == 1 ? (ST_P2P_CMDTASK_MSG *)pstP2pAddrInfo->pIceIpv6ReqInfo : (ST_P2P_CMDTASK_MSG *)pstP2pAddrInfo->pIceIpv4ReqInfo;
        if (pstCmdMsg == MOS_NULL)
        {
            return MOS_ERR;
        }

        ST_CMTASK_P2PDATAINFO *p2pMsgInfo = (ST_CMTASK_P2PDATAINFO*)pstCmdMsg->aucMsgBody;
        if (p2pMsgInfo != MOS_NULL)
        {
            _UC  *pucStrTmp = MOS_NULL;
            pucStrTmp = Cmd_BuildP2pInfoMsgRsp(pstCmdMsg->uiSeqId+1, p2pMsgInfo->uiP2pInfoType, sdp,
                                            &pstCmdMsg->stMsgFromTo, P2pManageMent::instance().getDevTransEnc());
            MsgMng_SendMsg(pstCmdMsg->aucPeerId,pstCmdMsg->uiSeqId+1, pstCmdMsg->ucMsgType, EN_CN21_P2P_DEV_SEND_SDP_REQ,
                        pucStrTmp, MOS_STRLEN(pucStrTmp),P2p_DevSendSdpClientRsp);
            MOS_LOG_INF(P2P_STRLOG, "SEND SDP To client:%s MSGOK", pstCmdMsg->stMsgFromTo.aucUserToken);
            Adpt_Json_DePrint(pucStrTmp);            
        }

        if (ipv6 == 1)
        {
            MOS_FREE(pstP2pAddrInfo->pIceIpv6ReqInfo);
            pstP2pAddrInfo->pIceIpv6ReqInfo = MOS_NULL;
        }
        else
        {
            MOS_FREE(pstP2pAddrInfo->pIceIpv4ReqInfo);
            pstP2pAddrInfo->pIceIpv4ReqInfo = MOS_NULL;
        }

        return MOS_OK;   
    }
    else
    {
        MOS_LOG_ERR(P2P_STRLOG, "AvClient_GetTurnAddrByKjClienRome Failed with kjrome(%p)\n", rome);
        return MOS_ERR;
    }

}

// 客户端正在请求传输的媒体流的通道号回调，只有媒体流发送方才会收到此回调
// @param rome rome实例
// @param stream_channels 通道值数组
// @param channel_count 通道数量
_VOID  P2pManageMent::onP2pInTransmittingCb(kj_rome *rome, uint16_t stream_channels[], int channel_count)
{
    ST_P2PTURN_ADDRINFO *pstP2pAddrInfo = AvClient_GetTurnAddrByKjClienRome(rome);
    if (pstP2pAddrInfo != MOS_NULL)
    {
        ST_AVCLIENT_INFO *pstAvClient =  MOS_NULL;
        pstAvClient = (ST_AVCLIENT_INFO*)pstP2pAddrInfo->pPrivateData;
        if (pstAvClient != MOS_NULL)
        {
            pstAvClient->m_stInTransmittingChannelInfo.usChannelCount = channel_count > P2P_CHANNEL_CHECK_MAX ? P2P_CHANNEL_CHECK_MAX : channel_count;
            _INT iChnNum = 0;
            for (iChnNum = 0; iChnNum < pstAvClient->m_stInTransmittingChannelInfo.usChannelCount; iChnNum++)
            {
                pstAvClient->m_stInTransmittingChannelInfo.usChannelList[iChnNum] = stream_channels[iChnNum];
            }
            pstAvClient->m_stInTransmittingChannelInfo.uiCheckFlag = 1;
        }
    }
    else
    {
        MOS_LOG_ERR(P2P_STRLOG, "AvClient_GetTurnAddrByKjClienRome Failed with kjrome(%p)\n", rome);
        return;
    }
}

/// 所有连接建连完成后的建连信息回调，用于采集连接结果
/// @param rome rome实例
/// @param cnt_info 建连结果信息数组
/// @param info_count 建连结果信息个数
_VOID  P2pManageMent::onP2pConnectionInfoCb(kj_rome *rome, kj_rmcnt_info cnt_infos[], int cnt_count, kj_rmcnt_extra_info extra_info)
{
    _INT iChnNum                  = 0;
    _UC  ucSuccessFlag            = 0;
    ST_AVCLIENT_INFO *pstAvClient =  MOS_NULL;

    ST_P2PTURN_ADDRINFO *pstP2pAddrInfo = AvClient_GetTurnAddrByKjClienRome(rome);
    if (pstP2pAddrInfo != MOS_NULL)
    {
        pstAvClient = (ST_AVCLIENT_INFO*)pstP2pAddrInfo->pPrivateData;
        if ((pstAvClient == MOS_NULL) || (pstAvClient->m_iceTranSport == MOS_NULL))
        {
            MOS_LOG_ERR(P2P_STRLOG, "Get AvClient Failed with kjrome(%p)\n", rome);
            return;
        }
    }
    else
    {
        MOS_LOG_ERR(P2P_STRLOG, "AvClient_GetTurnAddrByKjClienRome Failed with kjrome(%p)\n", rome);
        return;
    }

    _UC aucLocalIPv6Addr[64] = {0};
    _UC ucBuf[512]       = {0};
    _UC ucBufEx[1536]    = {0};
    AvClient_GetLocalIPv6Addr(aucLocalIPv6Addr, sizeof(aucLocalIPv6Addr));
    for (iChnNum = 0; iChnNum < cnt_count; iChnNum++)
    {
        if (iChnNum == 0) //数组第一个信息为当前连接的状态结果
        {
            if (cnt_infos[iChnNum].status == kj_code_success)
            {
                ucSuccessFlag = 1;
                MOS_LOG_INF(P2P_STRLOG,"p2p connect succeed %s mode:%s time: %u", (cnt_infos[iChnNum].ipv6==1)?"ipv6":"ipv4", (cnt_infos[iChnNum].type == kj_cnt_type_turn)?"turn":"p2p", cnt_infos[iChnNum].elapsed_ms);
                MOS_VSNPRINTF(ucBufEx, sizeof(ucBufEx), "endp_nat:%d endp_ver:%d local_nat:%d local_ver:%d", extra_info.endp_nat, extra_info.endp_ver, extra_info.local_nat, extra_info.local_ver);
            }
            else
            {
                ucSuccessFlag = 0;
                MOS_LOG_ERR(P2P_STRLOG,"p2p connect failed %s mode:%s time: %u", (cnt_infos[iChnNum].ipv6==1)?"ipv6":"ipv4", (cnt_infos[iChnNum].type == kj_cnt_type_turn)?"turn":"p2p", cnt_infos[iChnNum].elapsed_ms);

                MOS_VSNPRINTF(ucBufEx, sizeof(ucBufEx), 
                    "{\"IPv4StunUrl\": \"%s:%s\", \"IPv4StunUrl2\": \"%s:%s\", \"IPv4TurnUrl\": \"%s:%s\", \"IPv4DevSdpInfo\": \"%s\", \"IPv6StunUrl\": \"%s:%s\", \"IPv6StunUrl2\": \"%s:%s\", \"IPv6TurnUrl\": \"%s:%s\", \"IPv6DevSdpInfo\": \"%s\"} endp_nat:%d endp_ver:%d local_nat:%d local_ver:%d", 
                            pstP2pAddrInfo->aucStunHost, pstP2pAddrInfo->aucStunPort,
                            pstP2pAddrInfo->aucStun2Host, pstP2pAddrInfo->aucStun2Port,
                            pstP2pAddrInfo->aucTurnHost, pstP2pAddrInfo->aucTurnPort,
                            pstP2pAddrInfo->aucDevIpv4SdpInfo,
                            pstP2pAddrInfo->aucIPv6StunHost, pstP2pAddrInfo->aucIPv6StunPort,
                            pstP2pAddrInfo->aucIPv6Stun2Host, pstP2pAddrInfo->aucIPv6Stun2Port,
                            pstP2pAddrInfo->aucIPv6TurnHost, pstP2pAddrInfo->aucIPv6TurnPort,
                            pstP2pAddrInfo->aucDevIpv6SdpInfo,
                            extra_info.endp_nat, extra_info.endp_ver, extra_info.local_nat, extra_info.local_ver);
            }
            _UC ucStrcatBuf[256] = {0};
            _UC ucStrcatLocalV6Buf[128] = {0};
            if (cnt_infos[iChnNum].ipv6==1)
            {
                if (cnt_infos[iChnNum].type == kj_cnt_type_turn)
                {
                    MOS_VSNPRINTF(ucBuf, sizeof(ucBuf), "mode:ipv6 turn, client:%s, IPv6TurnUrl:%s:%s", pstAvClient->m_uacPeerId,
                        pstP2pAddrInfo->aucIPv6TurnHost, pstP2pAddrInfo->aucIPv6TurnPort);
                }
                else
                {
                    MOS_VSNPRINTF(ucBuf, sizeof(ucBuf), "mode:ipv6 p2p, client:%s, IPv6StunUrl:%s:%s, IPv6StunUrl2:%s:%s", pstAvClient->m_uacPeerId,
                        pstP2pAddrInfo->aucIPv6StunHost, pstP2pAddrInfo->aucIPv6StunPort,
                        pstP2pAddrInfo->aucIPv6Stun2Host, pstP2pAddrInfo->aucIPv6Stun2Port);
                }
            }
            else
            {
                if (cnt_infos[iChnNum].type != kj_cnt_type_turn)
                {
                    MOS_VSNPRINTF(ucBuf, sizeof(ucBuf), "mode:ipv4 turn, client:%s, IPv4TurnUrl:%s:%s", pstAvClient->m_uacPeerId,
                        pstP2pAddrInfo->aucTurnHost, pstP2pAddrInfo->aucTurnPort);
                }
                else
                {
                    MOS_VSNPRINTF(ucBuf, sizeof(ucBuf), "mode:ipv4 p2p, client:%s, IPv4StunUrl:%s:%s, IPv4StunUrl2:%s:%s", pstAvClient->m_uacPeerId,
                        pstP2pAddrInfo->aucStunHost, pstP2pAddrInfo->aucStunPort,
                        pstP2pAddrInfo->aucStun2Host, pstP2pAddrInfo->aucStun2Port);
                }
            }
            if (MOS_STRLEN(aucLocalIPv6Addr) > 0)
            {
                MOS_VSNPRINTF(ucStrcatLocalV6Buf, sizeof(ucStrcatLocalV6Buf), ", LocalV6:%s", aucLocalIPv6Addr);
                MOS_STRCAT(ucBuf, ucStrcatLocalV6Buf);
            }
            MOS_VSNPRINTF(ucStrcatBuf, sizeof(ucStrcatBuf), ", %s", (cnt_infos[iChnNum].status == kj_code_success) ? "ICE negotionation sucessful!" : "ICE negotionation failed!");
            MOS_STRCAT(ucBuf, ucStrcatBuf);
        }
        _UC ucStrcatBuf[128] = {0};
        MOS_VSNPRINTF(ucStrcatBuf, sizeof(ucStrcatBuf), " [type:%d status:%d cnt_id:%d elapsed_ms:%u ipv6:%d index:%d]\n", cnt_infos[iChnNum].type, cnt_infos[iChnNum].status, cnt_infos[iChnNum].cnt_id, cnt_infos[iChnNum].elapsed_ms, cnt_infos[iChnNum].ipv6, cnt_infos[iChnNum].index);
        
        _INT iBufExLen     = MOS_STRLEN(ucBufEx);
        _INT iStrcatBufLen = MOS_STRLEN(ucStrcatBuf);
        if ((iBufExLen + iStrcatBufLen) < sizeof(ucBufEx))
        {
            MOS_STRCAT(ucBufEx, ucStrcatBuf);
        }
    }

    if (cnt_count > 0)
    {
        MOS_LOG_INF(P2P_STRLOG, "%s\n", ucBufEx);
        if (ucSuccessFlag == 1)
        {  
            CloudStg_UploadLogEx(Mos_GetSessionId(), __FUNCTION__, 0, (cnt_infos[0].type == kj_cnt_type_turn)?EN_P2P_ERROR_CODE_P2P_TURN_SUCCESS:EN_P2P_ERROR_CODE_P2P_CONN_SUCCESS, ucBuf, ucBufEx, 1);
        }
        else
        {
            CloudStg_UploadLogEx(Mos_GetSessionId(), __FUNCTION__, 0, EN_P2P_ERROR_CODE_P2P_CONN_FAIL, ucBuf, ucBufEx, 1);
        }
    }

    return;

}

// 使用ICE进行的NAT探测结果回调
// @param rome rome实例
// @param nat_type nat类型值，参看nat_detect.h里定义的枚举pj_stun_nat_type值
_VOID  P2pManageMent::onP2pNatDetectCb(kj_rome *rome, int nat_type)
{
    _UC ucNatStatus = nat_type >= STUN_NAT_TYPE_NUMMAX ? P2P_NAT_TYPE_UNKNOWN : nat_type;
    if (ucStunNatType != ucNatStatus)
    {
        ucStunNatType = ucNatStatus;
        _UC aucBuf[128] = {0};
        MOS_VSNPRINTF(aucBuf, sizeof(aucBuf), "ICE get nat type sucessful, nat_type : %s\n", gstStunNatStatusMsg[ucNatStatus]);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_P2P_ERROR_CODE_NAT_DETECT_SUCCESS, aucBuf, 1);
    }
}

/////// 销毁rome实例
_VOID  P2pManageMent::onP2pDestoryClienRome(_VPTR hP2pClienRome)
{
    kj_rome *rome = (kj_rome *)hP2pClienRome;
    kj_rome_destroy(&rome);
}

// 建连成功后，可发送数据
// @param rome rome实例
// @param data 数据指针
// @param length 数据长度
// @return 发送结果
_INT P2pManageMent::onP2pSendData(_VPTR hP2pChnnel, _VPTR data, _UL data_len)
{
    ST_AVCLIENT_INFO *pavClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    if ((pavClient == MOS_NULL) || (pavClient->m_iceTranSport == MOS_NULL))
    {
        return MOS_ERR;
    }

    if (pavClient->m_iceTranSport->uiTransResult == EN_P2P_MSG_STATUS_ICENEG_OK)
    {
        return kj_rome_send_data(pavClient->m_iceTranSport->pKjClienRome, data, data_len);
    }

    return MOS_ERR;
}

// 建连成功后，可靠传输协议接收数据的回调
// @param tbsl 可靠传输协议指针
// @param data 数据内容
_VOID P2pManageMent::P2pTbslRecvCb(const kj_tbsl *tbsl, const kj_data *data)
{
    if ((data != MOS_NULL) && (data->raw_data != MOS_NULL) && (data->media_meta != MOS_NULL))
    {
        if (data->media_meta->av_type == 2)
        {
            ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)tbsl->os_obj;
            if ((avClient != MOS_NULL) && (avClient->m_bEnableSpeaker) && (avClient->m_hAudioPlay != MOS_NULL))
            {
                Media_AudioPlayWriteFrame(avClient->m_hAudioPlay, data->raw_data, data->length, data->media_meta->time_stamp);
            }
        }
        else
        {
            if (data->media_meta->frame_begin == 1)/*该数据包为一帧数据的开始*/
            {
                stTbslRecvInfo.ucRecVStatus = EN_TBSL_RECV_STATUS_START;
        if ((data->length > data->media_meta->frame_len))/*单包的长度比整帧的长度大，数据错误*/
        {
            stTbslRecvInfo.ucRecVStatus == EN_TBSL_RECV_STATUS_ERR;
        }
        
            if (stTbslRecvInfo.aucFrameBuf != MOS_NULL)
            {
                MOS_FREE(stTbslRecvInfo.aucFrameBuf);
                stTbslRecvInfo.aucFrameBuf = MOS_NULL;
            }

            stTbslRecvInfo.aucFrameBuf = (_UC *)MOS_MALLOCCLR(data->media_meta->frame_len);
            MOS_MEMCPY(stTbslRecvInfo.aucFrameBuf, data->raw_data, data->length);
            stTbslRecvInfo.ucAvType    = data->media_meta->av_type;
            stTbslRecvInfo.ucFrameType = data->media_meta->frame_type;
            stTbslRecvInfo.uiTimeStamp = data->media_meta->time_stamp;
            stTbslRecvInfo.uiFrameLen  = data->media_meta->frame_len;
            stTbslRecvInfo.uiRecvLen   = data->length;
            stTbslRecvInfo.uiLeftLen   = data->media_meta->frame_len - data->length;

            if (data->media_meta->frame_end == 1)/*该数据包也为一帧数据的结束，即此数据包是完整一帧的数据*/
            {
                if (stTbslRecvInfo.uiLeftLen > 0)/*该数据包不完整，应丢弃，重新接收下一个包的数据*/
                {
                    stTbslRecvInfo.ucRecVStatus = EN_TBSL_RECV_STATUS_ERR;
                }
                else/*已接收完一整帧数据*/
                {
                    stTbslRecvInfo.ucRecVStatus = EN_TBSL_RECV_STATUS_END;
                }                        
            }
            else/*该数据包不是一帧数据的结束，应继续接收剩下的数据*/
            {
                if (stTbslRecvInfo.uiLeftLen <= 0)/*该数据包长度标记错误，应丢弃，重新接收下一个包的数据*/
                {
                    stTbslRecvInfo.ucRecVStatus = EN_TBSL_RECV_STATUS_ERR;
                }   
            }
        }
        else
        {
            if (stTbslRecvInfo.aucFrameBuf == MOS_NULL)
            {
                stTbslRecvInfo.ucRecVStatus == EN_TBSL_RECV_STATUS_ERR;
            }
            else
            {
                if ((stTbslRecvInfo.uiLeftLen >= data->length) && ((stTbslRecvInfo.uiRecvLen + data->length) <= stTbslRecvInfo.uiFrameLen))
                {
                    MOS_MEMCPY(stTbslRecvInfo.aucFrameBuf+stTbslRecvInfo.uiRecvLen, data->raw_data, data->length);
                    stTbslRecvInfo.uiRecvLen   += data->length;
                    stTbslRecvInfo.uiLeftLen   -= data->length;

                    if (data->media_meta->frame_end == 1)/*该数据包也为一帧数据的结束，即此数据包是完整一帧的数据*/
                    {
                        if (stTbslRecvInfo.uiLeftLen > 0)/*该数据包不完整，应丢弃，重新接收下一个包的数据*/
                        {
                            stTbslRecvInfo.ucRecVStatus = EN_TBSL_RECV_STATUS_ERR;
                        }
                        else/*已接收完一整帧数据*/
                        {
                            stTbslRecvInfo.ucRecVStatus = EN_TBSL_RECV_STATUS_END;
                        }                        
                    }
                    else/*该数据包不是一帧数据的结束，应继续接收剩下的数据*/
                    {
                        if (stTbslRecvInfo.uiLeftLen <= 0)/*该数据包长度标记错误，应丢弃，重新接收下一个包的数据*/
                        {
                            stTbslRecvInfo.ucRecVStatus = EN_TBSL_RECV_STATUS_ERR;
                        }   
                    }
                }
                else
                {
                    stTbslRecvInfo.ucRecVStatus == EN_TBSL_RECV_STATUS_ERR;
                }
            }
        }

        if ((stTbslRecvInfo.ucRecVStatus == EN_TBSL_RECV_STATUS_END) || (stTbslRecvInfo.ucRecVStatus == EN_TBSL_RECV_STATUS_ERR)) 
        {
            if (stTbslRecvInfo.ucRecVStatus == EN_TBSL_RECV_STATUS_END)
            {
                ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)tbsl->os_obj;
                if ((avClient != MOS_NULL) && (avClient->m_bEnableDisplay) && (avClient->m_hVideoPlay != MOS_NULL) && (stTbslRecvInfo.aucFrameBuf != MOS_NULL) && (stTbslRecvInfo.uiFrameLen > 0))
                {
                    Media_VideoDisPlayWriteFrame(avClient->m_hVideoPlay, stTbslRecvInfo.aucFrameBuf, stTbslRecvInfo.uiFrameLen, stTbslRecvInfo.ucFrameType, stTbslRecvInfo.uiTimeStamp);
                }
            }
            
            if (stTbslRecvInfo.aucFrameBuf != MOS_NULL)
            {
                MOS_FREE(stTbslRecvInfo.aucFrameBuf);
                stTbslRecvInfo.aucFrameBuf = MOS_NULL;
                }

                stTbslRecvInfo.ucRecVStatus = EN_TBSL_RECV_STATUS_START;
            }
        }
    } 
}

// 建连成功后，可靠传输协议发送统计数据的回调
// @param tbsl 可靠传输协议指针
// @param data 数据内容
_VOID P2pManageMent::P2pTbslSendCb(const kj_tbsl *tbsl, const kj_data *data)
{
    ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)tbsl->os_obj;
    if (avClient != MOS_NULL)
    {
        if ((data != MOS_NULL) && (data->raw_data != MOS_NULL))
        {
            P2pProcessCmd::instance().procCmdSendMsg((_HP2PCHANNEL)avClient, data->type, data->method, data->raw_data, data->length);
        }   
    }    
}

// 建连成功后，创建可靠传输接收协议对象
// @param hP2pChnnel P2P通道指针
// @param tbsl_mode 协议模式
// @param av_type   媒体类型
// @return 发送结果
_INT P2pManageMent::P2pCreateTbsl(_VPTR hP2pChnnel, kj_tbsl_mode tbsl_mode, kj_av_type av_type)
{
    ST_AVCLIENT_INFO *pavClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    if ((pavClient == MOS_NULL) || (pavClient->m_iceTranSport == MOS_NULL))
    {
        return MOS_ERR;
    }

    if (pavClient->m_iceTranSport->uiTransResult == EN_P2P_MSG_STATUS_ICENEG_OK)
    {
        if (tbsl_mode != kj_tbsl_disable) 
        {
            if (av_type == kj_av_type_video)
            {
                // 视频可靠传输
                pavClient->m_iceTranSport->m_video_tbsl           = kj_tbsl_create(tbsl_mode, P2pManageMent::P2pTbslRecvCb, P2pManageMent::P2pTbslSendCb);
                pavClient->m_iceTranSport->m_video_tbsl->channel  = pavClient->m_sVideoDisplayChn;
                pavClient->m_iceTranSport->m_video_tbsl->av_type  = kj_av_type_video;
                pavClient->m_iceTranSport->m_video_tbsl->os_obj   = hP2pChnnel;
            }
            else if (av_type == kj_av_type_audio)
            {
                // 音频可靠传输
                pavClient->m_iceTranSport->m_audio_tbsl           = kj_tbsl_create(tbsl_mode, P2pManageMent::P2pTbslRecvCb, P2pManageMent::P2pTbslSendCb);
                pavClient->m_iceTranSport->m_audio_tbsl->channel  = pavClient->m_sAudioSpeakChn;
                pavClient->m_iceTranSport->m_audio_tbsl->av_type  = kj_av_type_audio;
                pavClient->m_iceTranSport->m_audio_tbsl->os_obj   = hP2pChnnel;
            }
        }
        return MOS_OK;
    }

    return MOS_ERR;
}

// 建连成功后，销毁可靠传输接收协议对象
// @param hP2pChnnel P2P通道指针
// @param av_type   媒体类型
// @return 发送结果
_INT P2pManageMent::P2pDestroyTbsl(_VPTR hP2pChnnel, kj_av_type av_type)
{
    ST_AVCLIENT_INFO *pavClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    if ((pavClient == MOS_NULL) || (pavClient->m_iceTranSport == MOS_NULL))
    {
        return MOS_ERR;
    }

    if (av_type == kj_av_type_video)
    {
        if (pavClient->m_iceTranSport->m_video_tbsl != MOS_NULL)
        {
            kj_tbsl_destroy(&pavClient->m_iceTranSport->m_video_tbsl);
            pavClient->m_iceTranSport->m_video_tbsl = MOS_NULL;
        }
    }
    else if (av_type == kj_av_type_audio)
    {
        if (pavClient->m_iceTranSport->m_audio_tbsl != MOS_NULL)
        {
            kj_tbsl_destroy(&pavClient->m_iceTranSport->m_audio_tbsl);
            pavClient->m_iceTranSport->m_audio_tbsl = MOS_NULL;
        }
    }

    return MOS_OK;
}


