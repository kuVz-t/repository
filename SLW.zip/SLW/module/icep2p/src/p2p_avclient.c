#include "p2p_avclient.h"

static ST_AVCLIENT_MNG g_stAvClientTrunAddrMng = {0};

ST_AVCLIENT_MNG *AvClient_GetInfoMng()
{
    return &g_stAvClientTrunAddrMng;
}

_UI AvClient_P2pInfoInit()
{
    AvClient_GetInfoMng ()->ucInitFlag = 1;
    AvClient_GetInfoMng()->ucRunFlag   = 0;
    Mos_MutexCreate(&AvClient_GetInfoMng()->hMutex);
    MOS_LIST_INIT(&AvClient_GetInfoMng()->stP2pTurnInfoList);
    return MOS_OK;
}

_UI Avclient_RemoveP2pInfo()
{
    MOS_PARAM_INVALID_RET(AvClient_GetInfoMng ()->ucInitFlag, 0, MOS_FALSE);
    Mos_MutexLock(&AvClient_GetInfoMng()->hMutex);
    AvClient_GetInfoMng ()->ucInitFlag = 0;
    MOS_LIST_RMVALL(&AvClient_GetInfoMng()->stP2pTurnInfoList, MOS_TRUE);
    Mos_MutexUnLock(&AvClient_GetInfoMng()->hMutex);
    Mos_MutexDelete(&AvClient_GetInfoMng()->hMutex);
    return MOS_OK;
}
// 分配节点
ST_CLIENT_TURNNODE *AvClient_AllocClientNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    MOS_PARAM_INVALID_RET(AvClient_GetInfoMng ()->ucInitFlag, 0, MOS_NULL);
    ST_CLIENT_TURNNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&AvClient_GetInfoMng()->stP2pTurnInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 0)
        {
            break;
        }
    }

    if(pstBussNode == MOS_NULL)
    {
        pstBussNode = (ST_CLIENT_TURNNODE*)MOS_MALLOCCLR(sizeof(ST_CLIENT_TURNNODE));
        if(pstBussNode == MOS_NULL)
        {
            return MOS_NULL;
        }
        MOS_LIST_ADDTAIL(&AvClient_GetInfoMng()->stP2pTurnInfoList, pstBussNode);
    }
    pstBussNode->uiClientIndexId = ++AvClient_GetInfoMng()->usIndexId;
    pstBussNode->uiUseFlag       = 1;
    return pstBussNode;
}

ST_P2PTURN_ADDRINFO* AvClient_GetTurnAddr(_UC *aucClientId)
{
    MOS_PARAM_INVALID_RET(AvClient_GetInfoMng ()->ucInitFlag, 0, MOS_NULL);
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLIENT_TURNNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&AvClient_GetInfoMng()->stP2pTurnInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 &&  MOS_STRCMP(aucClientId, pstBussNode->aucClientName) == 0)
        {
            return &(pstBussNode->stP2pTurnInfo);
        }
    }
    return MOS_NULL;
}

ST_P2PTURN_ADDRINFO* AvClient_GetTurnAddrByKjClienRome(kj_rome *rome)
{
    MOS_PARAM_INVALID_RET(AvClient_GetInfoMng ()->ucInitFlag, 0, MOS_NULL);
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLIENT_TURNNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&AvClient_GetInfoMng()->stP2pTurnInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 &&  (pstBussNode->stP2pTurnInfo.pKjClienRome == rome) )
        {
            return &(pstBussNode->stP2pTurnInfo);
        }
    }
    return MOS_NULL;
}

_UI AvClient_SetTurnAddr(_UC *aucClientId, ST_P2PTURN_ADDRINFO *pTurnInfo)
{
    ST_P2PTURN_ADDRINFO* pstTurnAddr = AvClient_GetTurnAddr(aucClientId);
    if (pstTurnAddr == MOS_NULL)
    {
        ST_CLIENT_TURNNODE *pstClientTrunNode = AvClient_AllocClientNode();
        MOS_STRNCPY(pstClientTrunNode->aucClientName, aucClientId, sizeof(pstClientTrunNode->aucClientName));
        pstTurnAddr = &(pstClientTrunNode->stP2pTurnInfo);
    }
    MOS_MEMCPY(pstTurnAddr, pTurnInfo, sizeof(ST_P2PTURN_ADDRINFO));
    pstTurnAddr->uiTransResult     = 0;//refrence P2P_MSG_STATUS
    pstTurnAddr->pKjClienRome      = MOS_NULL;
    pstTurnAddr->pPrivateData      = MOS_NULL;
    pstTurnAddr->pIceIpv4ReqInfo   = MOS_NULL;
    pstTurnAddr->pIceIpv6ReqInfo   = MOS_NULL;
    kj_timer_init(&(pstTurnAddr->tobjTimeout));
    getDiffTimems(&pstTurnAddr->tobjTimeout, 1, 0, 60*10);

    MOS_PRINTF("perrid:%s  ipv4turninfo: %s:%s, %s:%s, %s:%s   ipv6turninfo: %s:%s, %s:%s, %s:%s  TurnUsername: %s  TurnCredential: %s", aucClientId, 
                pstTurnAddr->aucStunHost, pstTurnAddr->aucStunPort, pstTurnAddr->aucStun2Host, pstTurnAddr->aucStun2Port, pstTurnAddr->aucTurnHost, pstTurnAddr->aucTurnPort,
                pstTurnAddr->aucIPv6StunHost, pstTurnAddr->aucIPv6StunPort, pstTurnAddr->aucIPv6Stun2Host, pstTurnAddr->aucIPv6Stun2Port,pstTurnAddr->aucIPv6TurnHost, pstTurnAddr->aucIPv6TurnPort,
                pstTurnAddr->aucTurnUsername, pstTurnAddr->TurnCredential);

    return MOS_OK;
}

_UI AvClient_RemoveNoUsedClienRome()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLIENT_TURNNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&AvClient_GetInfoMng()->stP2pTurnInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 0 && (pstBussNode->stP2pTurnInfo.pKjClienRome != MOS_NULL))
        {
            MOS_LOG_INF(P2P_STRLOG, "Remove KjClienRome = %p\n",pstBussNode->stP2pTurnInfo.pKjClienRome);
            pstBussNode->stP2pTurnInfo.pcbDestoryClienRome(pstBussNode->stP2pTurnInfo.pKjClienRome);
            pstBussNode->stP2pTurnInfo.pKjClienRome    = MOS_NULL;
        }
    }
    return MOS_OK;
}

_UI AvClient_RemoveTurnAddr(_UC *aucClientId)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLIENT_TURNNODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&AvClient_GetInfoMng()->stP2pTurnInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 &&  MOS_STRCMP(aucClientId, pstBussNode->aucClientName) == 0)
        {
            pstBussNode->uiUseFlag = 0;
            pstBussNode->stP2pTurnInfo.uiTransResult   = 0;
            MOS_FREE(pstBussNode->stP2pTurnInfo.pIceIpv4ReqInfo);
            MOS_FREE(pstBussNode->stP2pTurnInfo.pIceIpv6ReqInfo);
            pstBussNode->stP2pTurnInfo.pIceIpv4ReqInfo = MOS_NULL;
            pstBussNode->stP2pTurnInfo.pIceIpv6ReqInfo = MOS_NULL;
            break;
        }
    }
    return MOS_OK;
}

_UI AvClient_CheckTimeoutTurnAddr()
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_CLIENT_TURNNODE *pstBussNode = MOS_NULL;
    MOS_PARAM_INVALID_RET(AvClient_GetInfoMng ()->ucInitFlag, 0, MOS_NULL);
    FOR_EACHDATA_INLIST(&AvClient_GetInfoMng()->stP2pTurnInfoList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 1 &&  pstBussNode->stP2pTurnInfo.pPrivateData == MOS_NULL)
        {
            if (getDiffTimems(&pstBussNode->stP2pTurnInfo.tobjTimeout, 0, 1, 60*10) >= P2P_LINK_TIMEOUT_SEC)
            {
                MOS_PRINTF("check client:%s timeout for sending sdpinfo!\n", pstBussNode->aucClientName);
                pstBussNode->uiUseFlag = 0;
            }
            break;
        }
    }
    return MOS_OK;
}

_UI AvClient_SetLocalIPv6Addr(_UC *pucLocalIPv6Addr)
{
    if ((pucLocalIPv6Addr == MOS_NULL))
    {
        MOS_LOG_ERR(P2P_STRLOG, "pucLocalIPv6Addr is null");
        return MOS_ERR;
    }
    Mos_MutexLock(&AvClient_GetInfoMng()->hMutex);
    if(MOS_STRCMP(AvClient_GetInfoMng()->aucIPv6Addr, pucLocalIPv6Addr) == 0)
    {
        Mos_MutexUnLock(&AvClient_GetInfoMng()->hMutex);
        return MOS_OK;
    }
    MOS_STRNCPY(AvClient_GetInfoMng()->aucIPv6Addr, pucLocalIPv6Addr, sizeof(AvClient_GetInfoMng()->aucIPv6Addr));
    MOS_LOG_INF(P2P_STRLOG,"set IPv6Addr %s", AvClient_GetInfoMng()->aucIPv6Addr);
    Mos_MutexUnLock(&AvClient_GetInfoMng()->hMutex);

    return MOS_OK;
}
_UI AvClient_GetLocalIPv6Addr(_UC *pucLocalIPv6Addr, _UI uiLocalIPv6AddrLen)
{
    if ((pucLocalIPv6Addr == MOS_NULL))
    {
        MOS_LOG_ERR(P2P_STRLOG, "pucLocalIPv6Addr is null");
        return MOS_ERR;
    }
    Mos_MutexLock(&AvClient_GetInfoMng()->hMutex);
    MOS_STRNCPY(pucLocalIPv6Addr, AvClient_GetInfoMng()->aucIPv6Addr, uiLocalIPv6AddrLen);
    Mos_MutexUnLock(&AvClient_GetInfoMng()->hMutex);
    return MOS_OK;
}
