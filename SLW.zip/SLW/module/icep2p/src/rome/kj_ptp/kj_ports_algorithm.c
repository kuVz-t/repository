//
//  kj_ports_algorithm.c
//  P2PLib
//
//  Created by twenty on 2023/7/17.
//

#include "kj_ports_algorithm.h"

#pragma mark - 端口预测算法
void kj_ports_sort_from_left_and_right(uint16_t left, uint16_t right, uint16_t *ports, uint16_t count) {
    // 端口在基准端口先左后右排序，过滤端口为0的情况
    for (uint16_t i = 0; i < count; i++) {
        if (i % 2) {
            ports[i] = right++;
            if (ports[i] == 0) {
                ports[i] = right++;
            }
        } else {
            ports[i] = left--;
            if (ports[i] == 0) {
                ports[i] = left--;
            }
        }
    }
}

#pragma mark - 从给定的端口范围中随机取指定数量的端口
void kj_ports_in_range_random(uint16_t basePort, uint16_t range, uint16_t *ports, uint16_t count) {
    if (range > count) {
        // 获取range范围的端口顺序数组
        uint16_t range_ports[range];
        basePort = basePort - range / 2;
        for (uint16_t i = 0; i < range; i++) {
            range_ports[i] = basePort++;
        }
        // 在range的数组随机获取不重复的端口
        uint16_t target_index, left_range;
        for (uint16_t i = 0; i < count; i++) {
            left_range = range - i;
            target_index = kj_random(left_range) + i;
            ports[i] = range_ports[target_index];
            range_ports[target_index] =  range_ports[i];
        }
    } else {
        kj_ports_alg3_random_from_base(basePort, ports, count);
    }
}

#pragma mark - 在基准端口左右顺序
void kj_ports_around_base(uint16_t basePort, uint16_t *ports, uint16_t count) {
    if (ports && count) {
        *ports = basePort;
        ports++;
        count--;
        // 端口在基准端口先左后右排序，过滤端口为0的情况
        uint16_t left = basePort - 1, right = basePort + 1;
        kj_ports_sort_from_left_and_right(left, right, ports, count);
    }
}

#pragma mark - 随机排序
void kj_ports_swap_random(uint16_t *ports, uint16_t count) {
    // 端口数量需3个起，逐个与后面随机位置进行交换位置的随机顺序
    if (ports && count > 2) {
        uint16_t range, port; int swap_index;
        for (uint16_t i = 0; i < count; i++) {
            range = count - 1 - i;
            if (range > 0) {
                swap_index = kj_random(range) + i + 1;
                port = ports[swap_index];
                ports[swap_index] = ports[i];
                ports[i] = port;
            }
        }
    }
}

#pragma mark - 左右随机排序
void kj_ports_swap_around_random(uint16_t *ports, uint16_t count) {
    // 端口数量需3个起，逐个与后面随机位置且同侧的端口进行交换位置，以达到左右的随机顺序
    if (ports && count > 2) {
        uint16_t range;
        for (uint16_t i = 0; i < count; i++) {
            range = count - 1 - i;
            if (range > 0) {
                int swap_index = kj_random(range) + i + 1;
                // 交换位置相加不为偶数，则位置swap index与i不在base的同一侧，此时前进一位即为同侧，如前进以为已超范围则后退一位
                if ((swap_index + i) % 2 == 1) {
                    if (swap_index + 1 >= count) {
                        swap_index -= 1;
                    } else {
                        swap_index += 1;
                    }
                }
                uint16_t temp = ports[swap_index];
                ports[swap_index] = ports[i];
                ports[i] = temp;
            }
        }
    }
}

#pragma mark - 算法1:在基准端口左右随机排序，但优先指定范围内的
void kj_ports_alg1_random_around_base_priority_in_range(uint16_t basePort, uint16_t range, uint16_t *ports, uint16_t count) {
    if (range >= count) {
        // range已超过数量，则在range的范围内随机取数量内随机排序
        kj_ports_in_range_random(basePort, range, ports, count);
    } else if (range && count) {
        // 基准端口左右顺序排序
        kj_ports_around_base(basePort, ports, range);
        // 计算下一个最左和最右的端口值
        uint16_t left, right;
        if (range % 2) {
            left = ports[range > 2 ? range - 2 : 0] - 1;
            right = ports[range - 1] + 1;
        } else {
            left = ports[range - 1] - 1;
            right = ports[range > 2 ? range - 2 : 0] + 1;
        }
        // 随机左右排序range内的端口
        kj_ports_swap_around_random(ports + 1, range - 1);
        // 随机左右排序range外的端口
        uint16_t left_count = count - range;
        ports = ports + range;
        kj_ports_sort_from_left_and_right(left, right, ports, left_count);
        kj_ports_swap_around_random(ports, left_count);
    }
}

#pragma mark - 算法2:在基准端口左右随机排序
void kj_ports_alg2_random_around_base(uint16_t basePort, uint16_t *ports, uint16_t count) {
    // 先把base port放在数组的第一个，后续端口一右一左顺序铺开
    kj_ports_around_base(basePort, ports, count);
    // 端口数量超过3个，从第二个开始，与后面随机位置且同侧的端口进行交换位置，以达到一右一左的随机端口
    if (ports && count > 3) {
        ports++;
        count--;
        kj_ports_swap_around_random(ports, count);
    }
}

#pragma mark - 算法3:在基准端口两边随机排序
void kj_ports_alg3_random_from_base(uint16_t basePort, uint16_t *ports, uint16_t count) {
    kj_ports_around_base(basePort, ports, count);
    if (ports && count > 3) {
        ports++;
        count--;
        kj_ports_swap_random(ports, count);
    }
}

#pragma mark - 算法4:在基准端口两边随机排序
void kj_ports_alg4_random_from_base_priority_in_range(uint16_t basePort, uint16_t range, uint16_t *ports, uint16_t count) {
    if (range >= count) {
        kj_ports_alg3_random_from_base(basePort, ports, count);
    } else if (range && count) {
        // 基准端口左右顺序排序
        kj_ports_around_base(basePort, ports, range);
        // 计算下一个最左和最右的端口值
        uint16_t left, right;
        if (range % 2) {
            left = ports[range > 2 ? range - 2 : 0] - 1;
            right = ports[range - 1] + 1;
        } else {
            left = ports[range - 1] - 1;
            right = ports[range > 2 ? range - 2 : 0] + 1;
        }
        // 随机排序range内的端口
        kj_ports_swap_random(ports + 1, range - 1);
        // 随机排序range外的端口
        uint16_t left_count = count - range;
        ports = ports + range;
        kj_ports_sort_from_left_and_right(left, right, ports, left_count);
        kj_ports_swap_random(ports, left_count);
    }
}
