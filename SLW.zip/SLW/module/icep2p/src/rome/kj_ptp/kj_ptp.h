//
//  kj_ptp.h
//  ios_demo
//
//  Created by twenty on 2023/5/17.
//

#ifndef kj_ptp_h
#define kj_ptp_h

#include <stdio.h>

#include "kj_rm_types.h"
#include "rm_sock.h"
#include "kj_engine.h"

typedef struct kj_ptp kj_ptp;
typedef enum {
    kj_ptp_state_none,
    kj_ptp_state_reflexiving,
    kj_ptp_state_punching,
    kj_ptp_state_negotiation
} kj_ptp_state;

typedef struct kj_ptp_srflx_info {
    int ipv6;
    char ip[50];
    int port_cnt;
    uint16_t ports[2];
} kj_ptp_srflx_info;

typedef struct kj_ptp_cb {
    void (*recv_data_cb)(kj_ptp *ptp, const void *data, size_t length);
    void (*state_cb)(kj_ptp *ptp, kj_cnt_state state, kj_code status_code);
    kj_code (*sdp_info_cb)(kj_ptp *ptp, const char *sdp);
    void (*nat_port_dynamic_range)(kj_ptp *ptp, int range);
    void (*being_selected_cb)(kj_ptp *ptp);
} kj_ptp_cb;

struct kj_ptp {
    kj_rome_info *info;
    kj_cnt_state state;
    kj_ptp_state ptp_state;
    uint16_t cnt_id;
    void *user_data;
    kj_ptp_cb callback;
    rm_sock *sock;
    kj_timer_task op_timer;
    kj_thread *thread;
    pj_pool_t *pool;
    struct addr {
//        kj_sockaddr local;      // 本机地址
        kj_sockaddr punch;      // 进行穿透的对端地址
        kj_sockaddr endpoint;   // 穿透成功后对端的地址
        kj_sockaddr stun;       // 获取NAT映射地址的stun服务
        kj_sockaddr stun1;      // 获取第一个NAT映射地址的stun服务，用于获取第二个时判断不是由于第一个重发而获取的地址，避免误判
    } addr;
    struct sdp {
        int got;
        int recvd;
        int should_send;
        pthread_mutex_t mutex;
        kj_timer_task waiting_timer;
        kj_ptp_srflx_info local;
        kj_ptp_srflx_info endpoint;
    } sdp;
    struct {
        uint8_t seq;            // 加在心跳包的保留字节中，自增取值，跳过0值，用于返回心跳包对应发送的sequence而计算rtt
        kj_time seq_renew_time; // 更新一次“keepalive_seq”值时，更新该时间值，当收到回复心跳包时以此值为起点计算时间间隔
        uint8_t select_seq;     // 标记是否被选择使用，被标记时发送心跳包的序号收到回复时则确认通道可用
        int rtt;                // 链路数据往返时间，毫秒
        int timeout;            // 心跳超时时间，默认client 5s,server 15s
        int interval;           // 心跳包发送间隔，默认5s
        size_t secs_no_answer;  // 已经多少秒没有收到心跳回复，大于kalive_timeout则判断对方已离线
        size_t secs_alive;      // 建立连接的时间，用于每隔kalive_interval发送心跳包
    } kalive;
};

#pragma mark - 创建与销毁
kj_ptp *kj_ptp_create(kj_rome_info *info, kj_ptp_cb callback, void *user_data);
void kj_ptp_destroy(kj_ptp **ptp);

#pragma mark - 连接管理
/// 根据stun服务获取本端外网地址信息
/// @param server stun服务地址信息
void kj_ptp_get_reflexive_addrs_info(kj_ptp *ptp, const kj_rome_server *server);

/// 允许向对端发送本端SDP信息
void kj_ptp_should_send_sdp_to_endpoint(kj_ptp *ptp);

/// 对对端地址进行穿透建连
/// @param sdp 对端地址SDP信息
void kj_ptp_connect(kj_ptp *ptp, const char *sdp);

/// 关闭连接
void kj_ptp_close(kj_ptp *ptp);

/// 发送数据
kj_send_status kj_ptp_send_data(kj_ptp *ptp, const void *data, size_t length);

/// 心跳包活机制方法，由外部每秒执行
/// @param ptp ptp实例
/// @param data 附在心跳包一起发送的数据，存放传输中的媒体流的通道号
/// @param length 数据长度
/// @param answer_missed 获取是否已发生心跳一秒未回复
void kj_ptp_update_kalive_with_data(kj_ptp *ptp, const void *data, size_t length, int *answer_missed);

void kj_ptp_select_to_using(kj_ptp *ptp);

#pragma mark - 属性配置
void *kj_ptp_get_user_data(kj_ptp *ptp);
int kj_ptp_is_ipv6(kj_ptp *ptp);

#endif /* kj_ptp_h */
