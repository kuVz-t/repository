//
//  kj_ptp.c
//  ios_demo
//
//  Created by twenty on 2023/5/17.
//

#include <pjnath.h>

#include "kj_ptp.h"
#include "kj_sdp.h"
#include "kj_ports_algorithm.h"

#define KJ_PTP_TIMER_SRFLX 1
#define KJ_PTP_TIMER_PUNCH 2
#define KJ_PTP_TIMER_WAITING_SDP 3

struct kj_ptp_state_paras {
    kj_ptp *ptp;
    kj_cnt_state state;
    kj_code status_code;
    int callback;
};

#pragma mark - 函数定义
void kj_ptp_timer_task_excuting_callback(const kj_timer *timer, kj_timer_task *task);
void kj_ptp_start_punch(kj_ptp *ptp);
void kj_ptp_update_cnt_state_and_callback(kj_ptp *ptp, kj_cnt_state cnt_state, kj_code status_code, int callback);
kj_send_status kj_ptp_send_stun_binding_request(kj_ptp *ptp, kj_sockaddr *stun_addr);

#pragma mark - 工具函数
uint8_t kj_ptp_kalive_renew_alive_seq(kj_ptp *ptp) {
    uint8_t seq = 0;
    if (ptp) {
        seq = ++ptp->kalive.seq;
        if (seq == 0) {
            seq = ++ptp->kalive.seq;
        }
        ptp->kalive.seq_renew_time = kj_time_get_current();
    }
    return seq;
}

#pragma mark - 线程执行的函数
void _kj_ptp_update_cnt_state_and_callback(kj_ptp *ptp, kj_cnt_state state, kj_code status_code, int callback) {
    if (state != ptp->state) {
        ptp->state = state;
        if (callback) {
            ptp->callback.state_cb(ptp, ptp->state, status_code);
        }
    }
}
void _kj_ptp_start_punch(kj_ptp *ptp) {
    _kj_rm_cfg.ptp_punch_time = kj_time_get_current();
    // 更新状态
    ptp->state = kj_cnt_state_connecting;
    ptp->ptp_state = kj_ptp_state_punching;
    // 穿透超时定时器
    kj_timer_cancel_task(rm_engine()->timer, ptp->op_timer);
    kj_timer_init_task(&ptp->op_timer, ptp, _kj_rm_cfg.ptp_punch_timeout_ms,
                       0, kj_ptp_timer_task_excuting_callback);
    ptp->op_timer.task_id = KJ_PTP_TIMER_PUNCH;
    kj_timer_schedule_task(rm_engine()->timer, ptp->op_timer);
    // 初始化对端地址
    kj_sockaddr_init(&ptp->addr.punch,
                     ptp->sdp.endpoint.ipv6 ? AF_INET6 : AF_INET,
                     ptp->sdp.endpoint.ip,
                     ptp->sdp.endpoint.ports[0]);
    kj_data_head data = {
        .head = {'#', '$'},
        .type = KJ_RM_DATA_TYPE_PUNCH,
        .method = KJ_RM_DATA_METHOD_PUNCH_ASK,
        .length = 0
    };
    size_t data_len = sizeof(data);
    int send_err_times = 0, max_err_times = 20;
    if (ptp->sdp.endpoint.port_cnt == 1) {
        // 对端只有一个端口，判定为NAT3类型，只向该端口持续发送穿透包
        while (ptp->ptp_state == kj_ptp_state_punching && kj_thread_is_working(ptp->thread)) {
            data.reserved++;
            kj_send_status status = kj_sock_send_to(ptp->sock, &data, data_len, &ptp->addr.punch);
            if (status == kj_send_status_success) {
                send_err_times = 0;
                usleep(_kj_rm_cfg.nat3_punch_interval_us);
            } else if (send_err_times++ < max_err_times) {
                usleep(_kj_rm_cfg.nat3_punch_interval_us);
            } else {
                break;
            }
        }
    } else {
        // 对端有多个端口，判定为NAT4类型，取多个端口的平均值作为穿透的基准端口
        uint16_t punch_alg = ptp->info->local.algorithm.type;
        uint16_t punch_count = ptp->info->local.algorithm.ports_count;
        uint16_t per_count = ptp->info->local.algorithm.per_count;
        useconds_t interval = ptp->info->local.algorithm.per_interval_ms * 1000;
        if (ptp->info->local.role == kj_rm_role_server) {
            punch_alg = ptp->info->remote.algorithm.type;
            punch_count = ptp->info->remote.algorithm.ports_count;
            per_count = ptp->info->remote.algorithm.per_count;
            interval = ptp->info->remote.algorithm.per_interval_ms * 1000;
        }
        uint16_t ports[punch_count];
        uint16_t base_port = 0;
        for (int i = 0; i < ptp->sdp.endpoint.port_cnt; i++) {
            base_port += (ptp->sdp.endpoint.ports[i] / ptp->sdp.endpoint.port_cnt);
        }
        // 选择穿透算法
        if (punch_alg == 1) {
            kj_ports_alg1_random_around_base_priority_in_range(base_port, ptp->info->remote.nat * 2, ports, punch_count);
        } else if (punch_alg == 2) {
            kj_ports_alg2_random_around_base(base_port, ports, punch_count);
        } else if (punch_alg == 3) {
            kj_ports_alg3_random_from_base(base_port, ports, punch_count);
        } else if (punch_alg == 4) {
            kj_ports_alg4_random_from_base_priority_in_range(base_port, ptp->info->remote.nat * 2, ports, punch_count);
        } else {
            kj_ports_alg1_random_around_base_priority_in_range(base_port, ptp->info->remote.nat * 2, ports, punch_count);
        }
        uint16_t sent_count = 0;
        int port_err_times = 0;
        for (int i = 0; i < punch_count && ptp->ptp_state == kj_ptp_state_punching && kj_thread_is_working(ptp->thread); i++) {
            kj_sockaddr_set_port(&ptp->addr.punch, ports[i]);
            data.reserved++;
            kj_send_status status = kj_sock_send_to(ptp->sock, &data, data_len, &ptp->addr.punch);
            // 每100个包均匀发送
            if (status == kj_send_status_success) {
                send_err_times = 0;
                if (++sent_count >= per_count) {
                    sent_count = 0;
                    usleep(interval);
                }
            } else if (send_err_times++ < max_err_times) {
                if (port_err_times < 2) {
                    i--;
                    port_err_times++;
                } else {
                    port_err_times = 0;
                }
                usleep(10000);
            } else {
                break;
            }
        }
    }
    if (ptp->ptp_state == kj_ptp_state_punching) {
        kj_timer_cancel_task(rm_engine()->timer, ptp->op_timer);
        // 打洞时间未超时，则增加4s等待
        size_t elapsed = kj_time_interval_between(_kj_rm_cfg.ptp_punch_time, kj_time_get_current());
        if (elapsed < _kj_rm_cfg.ptp_punch_timeout_ms) {
            if (send_err_times > max_err_times) {
                ptp->ptp_state = kj_ptp_state_none;
                kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_send_punch_data_err, 1);
            } else {
                kj_timer_init_task(&ptp->op_timer, ptp, 4000,
                                   0, kj_ptp_timer_task_excuting_callback);
                ptp->op_timer.task_id = KJ_PTP_TIMER_PUNCH;
                kj_timer_schedule_task(rm_engine()->timer, ptp->op_timer);
            }
        }
    } else {
        send_err_times = 0;
        // 需要确认对端能收发数据
        while (ptp->ptp_state == kj_ptp_state_negotiation && kj_thread_is_working(ptp->thread)) {
            data.reserved++;
            kj_send_status status = kj_sock_send_to(ptp->sock, &data, data_len, &ptp->addr.endpoint);
            if (status == kj_send_status_success) {
                send_err_times = 0;
                usleep(_kj_rm_cfg.nat3_punch_interval_us);
            } else if (send_err_times++ < max_err_times) {
                usleep(_kj_rm_cfg.nat3_punch_interval_us);
            } else {
                break;
            }
        }
    }
}
#pragma mark - 线程任务执行回调
void kj_ptp_thread_task_execute_callback(const kj_thread *thread, const void *func, void *args) {
    if (func == _kj_ptp_update_cnt_state_and_callback) {
        struct kj_ptp_state_paras *paras = args;
        _kj_ptp_update_cnt_state_and_callback(paras->ptp, paras->state, paras->status_code, paras->callback);
    } else if (func == _kj_ptp_start_punch) {
        kj_ptp *ptp = args;
        _kj_ptp_start_punch(ptp);
    }
}
void kj_ptp_thread_will_destroy_callback(const kj_thread *thread, void *user_data) {
    kj_ptp *ptp = user_data;
    pj_thread_desc desc;
    kj_ice_register_thread_to_pjlib(desc);
    pj_pool_release(ptp->pool);
    pthread_mutex_destroy(&ptp->sdp.mutex);
    free(ptp);
}

#pragma mark - 连接状态和获取映射地址状态处理
int kj_ptp_start_punch_if_could_after_last(kj_ptp *ptp) {
    int could = 1;
    // 距离上次打洞时间间隔不够则终止打洞，避免上次打洞在外网NAT开启的端口未被回收而打通后本次socket收不到数据
    if (kj_time_interval_between(_kj_rm_cfg.ptp_punch_time, kj_time_get_current()) < _kj_rm_cfg.ptp_punch_interval_ms) {
        could = 0;
    }
    return could;
}
void kj_ptp_start_waiting_sdp_timer(kj_ptp *ptp) {
    if (kj_ptp_start_punch_if_could_after_last(ptp)) {
        kj_timer_cancel_task(rm_engine()->timer, ptp->sdp.waiting_timer);
        kj_timer_init_task(&ptp->sdp.waiting_timer, ptp,
                           _kj_rm_cfg.waiting_sdp_timeout_ms,
                           0, kj_ptp_timer_task_excuting_callback);
        ptp->sdp.waiting_timer.task_id = KJ_PTP_TIMER_WAITING_SDP;
        kj_timer_schedule_task(rm_engine()->timer, ptp->sdp.waiting_timer);
    } else {
        ptp->ptp_state = kj_ptp_state_none;
        kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_punch_frequent, 1);
    }
}
kj_code kj_ptp_send_sdp_to_endpoint(kj_ptp *ptp) {
    kj_code code = kj_code_ptp_punch_frequent;
    if (kj_ptp_start_punch_if_could_after_last(ptp)) {
        char sdp[KJ_SDP_INFO_MAX_LENGTH] = {};
        kj_sdp_encode_ptp_sdp(ptp, sdp, KJ_SDP_INFO_MAX_LENGTH);
        code = ptp->callback.sdp_info_cb(ptp, sdp);
    }
    if (code != kj_code_success) {
        ptp->ptp_state = kj_ptp_state_none;
        kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, code, 1);
    }
    return code;
}
void kj_ptp_get_srflx_addrs_info_finished_callback(kj_ptp *ptp) {
    // 即刻回调NAT端口信息
    ptp->info->local.nat = kj_util_get_nat_port_range(ptp->sdp.local.ports[0], ptp->sdp.local.ports[1]);
    _kj_rm_cfg.local_nat = ptp->info->local.nat;
    if (ptp->callback.nat_port_dynamic_range) {
        ptp->callback.nat_port_dynamic_range(ptp, ptp->info->local.nat);
    }
    // 根据状态判断是否回调发送SDP信息
    kj_thread_lock(&ptp->sdp.mutex);
    ptp->sdp.got = 1;
    if (ptp->sdp.should_send && ptp->info->local.role == kj_rm_role_client) {
        ptp->sdp.got = 0;
        kj_thread_unlock(&ptp->sdp.mutex);
        if (kj_ptp_send_sdp_to_endpoint(ptp) == kj_code_success) {
            // client角色发送地址给对端后，开启定时器执行超时无对端地址信息
            kj_ptp_start_waiting_sdp_timer(ptp);
        }
    } else if (ptp->info->local.role == kj_rm_role_server && ptp->sdp.recvd) {
        ptp->sdp.got = 0;
        kj_thread_unlock(&ptp->sdp.mutex);
        if (kj_ptp_send_sdp_to_endpoint(ptp) == kj_code_success) {
            kj_ptp_start_punch(ptp);
        }
    } else {
        kj_thread_unlock(&ptp->sdp.mutex);
    }
}

#pragma mark - 定时任务回调
void kj_ptp_timer_task_excuting_callback(const kj_timer *timer, kj_timer_task *task) {
    kj_ptp *ptp = task->user_data;
    if (task->task_id == KJ_PTP_TIMER_SRFLX) {
        // 从stun服务获取两个映射地址超时 40、80、160、320、640、1280
        if (ptp->state == kj_cnt_state_connecting && ptp->ptp_state == kj_ptp_state_reflexiving) {
            kj_cnt_state state = kj_cnt_state_connected;
            kj_code code = kj_code_success;
            if (task->interval < 1280) {
                if (kj_ptp_send_stun_binding_request(ptp, &ptp->addr.stun) == kj_send_status_success) {
                    // 获取映射地址超时定时器，首次超时时间为40ms
                    task->interval *= 2;
                } else {
                    state = kj_cnt_state_connect_fail;
                    code = kj_code_ptp_send_stun_req_fail;
                }
            } else {
                state = kj_cnt_state_connect_fail;
                code = kj_code_ptp_stun_timeout;
            }
            if (state == kj_cnt_state_connect_fail) {
                ptp->ptp_state = kj_ptp_state_none;
                kj_timer_cancel_task(rm_engine()->timer, ptp->op_timer);
                kj_ptp_update_cnt_state_and_callback(ptp, state, code, 1);
            }
        }
    } else if (task->task_id == KJ_PTP_TIMER_PUNCH) {
        // NAT穿透超时
        if (ptp->state != kj_cnt_state_connected && ptp->ptp_state != kj_ptp_state_none) {
            ptp->ptp_state = kj_ptp_state_none;
            kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_punch_failed, 1);
        }
    } else if (task->task_id == KJ_PTP_TIMER_WAITING_SDP) {
        // 等待对端地址信息超时
        if (ptp->state == kj_cnt_state_connecting && ptp->ptp_state == kj_ptp_state_none) {
            kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_missed_endp_addrs, 1);
        }
    }
}

#pragma mark - 连接状态更新
void kj_ptp_update_cnt_state_and_callback(kj_ptp *ptp, kj_cnt_state state, kj_code status_code, int callback) {
    if (ptp) {
        struct kj_ptp_state_paras paras = {
            .ptp = ptp,
            .state = state,
            .status_code = status_code,
            .callback = callback
        };
        kj_thread_task task = kj_thread_task_create(kj_ptp_thread_task_execute_callback, NULL);
        task.args = &paras;
        task.args_length = sizeof(paras);
        task.function = _kj_ptp_update_cnt_state_and_callback;
        kj_thread_add_task(ptp->thread, task);
    }
}

#pragma mark - 通过stun服务获取外网地址
kj_send_status kj_ptp_send_stun_binding_request(kj_ptp *ptp, kj_sockaddr *stun_addr) {
    pj_stun_msg stun_msg;
    pj_stun_msg_init(&stun_msg, PJ_STUN_BINDING_REQUEST, PJ_STUN_MAGIC, NULL);
    pj_str_t name = pj_str("rome ptp");
    pj_stun_msg_add_string_attr(ptp->pool, &stun_msg, PJ_STUN_ATTR_SOFTWARE, &name);
    pj_uint8_t data[200];
    pj_size_t length = sizeof(data);
    pj_stun_msg_encode(&stun_msg, data, length, 0, NULL, &length);
    return kj_sock_send_to(ptp->sock, data, length, stun_addr);
}

#pragma mark - 穿透线程回调
void kj_ptp_start_punch(kj_ptp *ptp) {
    kj_thread_task task = kj_thread_task_create(kj_ptp_thread_task_execute_callback, NULL);
    task.args = ptp;
    task.function = _kj_ptp_start_punch;
    kj_thread_add_task(ptp->thread, task);
}

#pragma mark - sock callback
void kj_ptp_recv_data_callback(kj_ptp *ptp, const void *data, size_t length) {
    kj_data_head data_head = {};
    if (kj_util_is_rm_data(data, length, &data_head)
        && data_head.type == KJ_RM_DATA_TYPE_DISCONNECT
        && data_head.method == KJ_RM_DATA_METHOD_DISCONNECT) {
        data_head.method += 1;
        data_head.length = 0;
        kj_ptp_send_data(ptp, &data_head, kj_data_head_length);
        kj_ptp_close(ptp);
        kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_disconnected, kj_code_ptp_discnt_by_endpoint, 1);
    } else {
        if (kj_util_is_rm_kalive_data(data, length, &data_head)) {
            if (data_head.type == KJ_RM_DATA_TYPE_KALIVE_ANSWER) {
                if (data_head.reserved && data_head.reserved == ptp->kalive.seq) {
                    size_t interval = kj_time_interval_between(ptp->kalive.seq_renew_time, kj_time_get_current());
                    if (ptp->kalive.rtt) {
                        ptp->kalive.rtt = ptp->kalive.rtt * 0.8 + interval * 0.2;
                    } else {
                        ptp->kalive.rtt = (int)interval;
                    }
                }
                if (data_head.reserved) {
                    ptp->kalive.secs_no_answer = 0;
                }
                // 收到选择连接的心跳包回复则回调连接被选择
                if (data_head.reserved && data_head.reserved == ptp->kalive.select_seq) {
                    ptp->kalive.select_seq = 0;
                    ptp->callback.being_selected_cb(ptp);
                }
            } else {
                // 发送回复心跳包
                kj_data_head *answer_data = kj_util_kalive_answer_data_with_seq(data_head.reserved, NULL, 0);
                kj_ptp_send_data(ptp, answer_data, kj_data_head_length);
                free(answer_data);
                // 判断是否为选择连接的心跳包
                if (data_head.length >= 4) {
                    const uint16_t *point = data + kj_data_head_length;
                    uint16_t type = *point;
                    if (ntohs(type) == KJ_RM_KALIVE_DATA_TYPE_SELECT_CNT) {
                        ptp->kalive.select_seq = 0;
                        ptp->callback.being_selected_cb(ptp);
                    }
                }
            }
            // 服务端只要收到对端的心跳则认为链路可用
            if (ptp->info->local.role == kj_rm_role_server) {
                ptp->kalive.secs_no_answer = 0;
            }
        }
        ptp->callback.recv_data_cb(ptp, data, length);
    }
}
void kj_ptp_sock_recv_data_callback(rm_sock *sock, const void *data, size_t length, const kj_sockaddr *src_addr) {
    kj_ptp *ptp = kj_sock_get_user_data(sock);
    if (ptp->state == kj_cnt_state_connected) {
        kj_data_head rm_data;
        if (kj_util_is_rm_punch_data(data, length, &rm_data)) {
            if (rm_data.method == KJ_RM_DATA_METHOD_PUNCH_ASK) {
                rm_data.method = KJ_RM_DATA_METHOD_PUNCH_ANSWER;
                kj_sock_send_to(ptp->sock, &rm_data, sizeof(rm_data), &ptp->addr.endpoint);
            }
        } else {
            kj_ptp_recv_data_callback(ptp, data, length);
        }
    } else if (ptp->ptp_state == kj_ptp_state_reflexiving) {
        // 解析stun消息
        pj_stun_msg *p_msg = NULL, *p_response = NULL;
        pj_stun_msg_decode(ptp->pool, data, length, 0, &p_msg, &length, &p_response);
        if (ptp->sdp.local.port_cnt < 2 && p_msg) {
            // 取消stun超时定时器
            kj_timer_cancel_task(rm_engine()->timer, ptp->op_timer);
            // 解析映射地址
            pj_stun_attr_hdr *attr_hdr = pj_stun_msg_find_attr(p_msg, PJ_STUN_ATTR_XOR_MAPPED_ADDR, 0);
            if (attr_hdr == NULL) {
                attr_hdr = pj_stun_msg_find_attr(p_msg, PJ_STUN_ATTR_MAPPED_ADDR, 0);
            }
            if (attr_hdr) {
                // 确保第二个映射地址不是来自同一个stun服务因重请求而发来的
                if (ptp->sdp.local.port_cnt == 0 || !kj_sockaddr_is_only_addr_equal(src_addr, &ptp->addr.stun1)) {
                    pj_stun_sockaddr_attr *sockadd_attr = (pj_stun_sockaddr_attr *)attr_hdr;
                    pj_status_t result = pj_inet_ntop(sockadd_attr->sockaddr.addr.sa_family,
                                                      pj_sockaddr_get_addr(&sockadd_attr->sockaddr),
                                                      ptp->sdp.local.ip,
                                                      sizeof(ptp->sdp.local.ip));
                    if (result == PJ_SUCCESS) {
                        ptp->sdp.local.ipv6 = sockadd_attr->sockaddr.addr.sa_family == PJ_AF_INET6;
                        ptp->sdp.local.ports[ptp->sdp.local.port_cnt] = pj_sockaddr_get_port(&sockadd_attr->sockaddr);
                        ptp->sdp.local.port_cnt++;
                    }
                }
            }
            if (ptp->sdp.local.port_cnt >= 2) {
                ptp->ptp_state = kj_ptp_state_none;
                // 已向两个stun服务获取到两个地址端口
                if (ptp->sdp.local.ports[0] == ptp->sdp.local.ports[1]) {
                    ptp->sdp.local.port_cnt = 1;
                }
                kj_ptp_get_srflx_addrs_info_finished_callback(ptp);
            } else {
                // 解析第二个stun服务地址
                attr_hdr = pj_stun_msg_find_attr(p_msg, PJ_STUN_ATTR_CHANGED_ADDR, 0);
                if (attr_hdr) {
                    pj_stun_sockaddr_attr *sockadd_attr = (pj_stun_sockaddr_attr *)attr_hdr;
                    if (sockadd_attr->sockaddr.addr.sa_family == PJ_AF_INET) {
                        kj_sockaddr_copy(&ptp->addr.stun, &sockadd_attr->sockaddr.ipv4, AF_INET);
                    } else {
                        kj_sockaddr_copy(&ptp->addr.stun, &sockadd_attr->sockaddr.ipv6, AF_INET6);
                    }
                    if (kj_sockaddr_is_equal(&ptp->addr.stun, &ptp->addr.stun1)) {
                        ptp->ptp_state = kj_ptp_state_none;
                        kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_change_addr_equal, 1);
                    } else {
                        if (kj_ptp_send_stun_binding_request(ptp, &ptp->addr.stun) == kj_send_status_success) {
                            // 获取映射地址超时定时器，首次超时时间为40ms
                            kj_timer_init_task(&ptp->op_timer, ptp, 40, 1, kj_ptp_timer_task_excuting_callback);
                            ptp->op_timer.task_id = KJ_PTP_TIMER_SRFLX;
                            kj_timer_schedule_task(rm_engine()->timer, ptp->op_timer);
                        } else {
                            ptp->ptp_state = kj_ptp_state_none;
                            kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_send_stun_req_fail, 1);
                        }
                    }
                } else {
                    ptp->ptp_state = kj_ptp_state_none;
                    if (ptp->sdp.local.port_cnt == 0) {
                        kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_srflx_err, 1);
                    } else {
                        kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_no_change_addr_attr, 1);
                    }
                }
            }
        }
    } else if (ptp->ptp_state == kj_ptp_state_punching) {
        kj_data_head rm_data = {};
        if (kj_util_is_rm_punch_data(data, length, &rm_data)) {
            ptp->addr.endpoint = ptp->addr.punch;
            if (kj_sockaddr_is_only_addr_equal(&ptp->addr.endpoint, src_addr)) {
                ptp->addr.endpoint = *src_addr;
                if (rm_data.method == KJ_RM_DATA_METHOD_PUNCH_ASK) {
                    ptp->ptp_state = kj_ptp_state_negotiation;
                    rm_data.method = KJ_RM_DATA_METHOD_PUNCH_ANSWER;
                    kj_sock_send_to(ptp->sock, &rm_data, sizeof(rm_data), &ptp->addr.endpoint);
                } else {
                    ptp->ptp_state = kj_ptp_state_none;
                    // 取消穿透超时定时器
                    kj_timer_cancel_task(rm_engine()->timer, ptp->op_timer);
                    // 建连成功
                    kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connected, kj_code_success, 1);
                }
            }
        }
    } else if (ptp->ptp_state == kj_ptp_state_negotiation) {
        kj_data_head rm_data;
        if (kj_util_is_rm_punch_data(data, length, &rm_data) && rm_data.method == KJ_RM_DATA_METHOD_PUNCH_ANSWER) {
            if (kj_sockaddr_is_equal(&ptp->addr.endpoint, src_addr)) {
                ptp->ptp_state = kj_ptp_state_none;
                // 取消穿透超时定时器
                kj_timer_cancel_task(rm_engine()->timer, ptp->op_timer);
                // 建连成功
                kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connected, kj_code_success, 1);
            }
        }
    }
}
void kj_ptp_sock_state_callback(rm_sock *sock, kj_cnt_state state) {
    kj_ptp *ptp = kj_sock_get_user_data(sock);
    if (state == kj_cnt_state_disconnected && ptp->state == kj_cnt_state_connected) {
        kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_disconnected, kj_code_ptp_sock_disconnected, 1);
    }
}

#pragma mark - 创建与销毁
kj_ptp *kj_ptp_create(kj_rome_info *info, kj_ptp_cb callback, void *user_data) {
    kj_ptp *ptp = calloc(1, sizeof(kj_ptp));
    ptp->info = info;
    ptp->callback = callback;
    ptp->user_data = user_data;
    ptp->kalive.interval = 5;
    if (ptp->info->local.role == kj_rm_role_client) {
        // 客户端心跳包超过5秒（发5次）无响应则超时中断
        ptp->kalive.timeout = 5;
    } else {
        // 服务端超过15s无对端心跳包则链路不可用
        ptp->kalive.timeout = 15;
    }
    kj_thread_init_mutex(&ptp->sdp.mutex, 0);
    pj_thread_desc desc;
    kj_ice_register_thread_to_pjlib(desc);
    ptp->pool = pj_pool_create(&rm_engine()->caching_pool.factory, "ptp pool", 512, 512, NULL);
    ptp->thread = kj_thread_create("ptp thread", ptp, kj_ptp_thread_will_destroy_callback);
    return ptp;
}
void kj_ptp_destroy(kj_ptp **ptp) {
    kj_ptp *temp = *ptp;
    *ptp = NULL;
    if (temp) {
        kj_ptp_close(temp);
        kj_sock_destroy(&temp->sock);
        kj_thread_destroy(&temp->thread);
    }
}

#pragma mark - 连接管理
void kj_ptp_get_reflexive_addrs_info(kj_ptp *ptp, const kj_rome_server *server) {
    if (ptp && server) {
        ptp->state = kj_cnt_state_connecting;
        ptp->ptp_state = kj_ptp_state_reflexiving;
        ptp->sdp.local.port_cnt = 0;
        // 取消上一次的定时器
        kj_timer_cancel_task(rm_engine()->timer, ptp->op_timer);
        kj_timer_cancel_task(rm_engine()->timer, ptp->sdp.waiting_timer);
        // 销毁上一次的sock
        kj_sock_destroy(&ptp->sock);
        // 创建新的sock
        kj_sock_cb sock_cb = {
            .recv_data_callback = kj_ptp_sock_recv_data_callback,
            .state_callback = kj_ptp_sock_state_callback
        };
        ptp->sock = kj_sock_create_udp(ptp, AF_INET, sock_cb);
        kj_sock_register_to_ioqueue(ptp->sock, rm_engine()->sock_queue);
        kj_sock_start_recvfrom(ptp->sock);
        
        uint16_t port = server->stun_port ? atoi(server->stun_port) : 0;
        if (kj_sockaddr_init(&ptp->addr.stun, AF_INET, server->stun_host, port)) {
            // 复制一份，用于判断获取两个映射地址不是来自同一个stun服务
            kj_sockaddr_copy(&ptp->addr.stun1, &ptp->addr.stun.addr, AF_INET);
            // 发送stun bind request请求
            if (kj_ptp_send_stun_binding_request(ptp, &ptp->addr.stun) == kj_send_status_success) {
                // 获取映射地址超时定时器，首次超时时间为40ms
                kj_timer_init_task(&ptp->op_timer, ptp, 40, 1, kj_ptp_timer_task_excuting_callback);
                ptp->op_timer.task_id = KJ_PTP_TIMER_SRFLX;
                kj_timer_schedule_task(rm_engine()->timer, ptp->op_timer);
            } else {
                ptp->ptp_state = kj_ptp_state_none;
                kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_send_stun_req_fail, 1);
            }
        } else {
            ptp->ptp_state = kj_ptp_state_none;
            kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_server_err, 1);
        }
    }
}
void kj_ptp_should_send_sdp_to_endpoint(kj_ptp *ptp) {
    if (ptp) {
        uint16_t punch_alg = ptp->info->local.algorithm.type;
        if (ptp->info->local.role == kj_rm_role_server) {
            // server角色如已收到对端支持的类型，意味已收到对端使用的算法，此时使用对端算法进入等待sdp状态
            if (ptp->info->remote.road_support & (kj_road_ice | kj_road_ptp)) {
                punch_alg = ptp->info->remote.algorithm.type;
            }
        }
        if (punch_alg) {
            int should_send = 0;
            int server_waitting_sdp = 0;
            kj_thread_lock(&ptp->sdp.mutex);
            ptp->sdp.should_send = 1;
            if (ptp->info->local.role == kj_rm_role_client && ptp->sdp.got) {
                should_send = 1;
                ptp->sdp.got = 0;
                ptp->sdp.should_send = 0;
            } else if (ptp->info->local.role == kj_rm_role_server && ptp->ptp_state < kj_ptp_state_punching) {
                server_waitting_sdp = 1;
            }
            kj_thread_unlock(&ptp->sdp.mutex);
            if (should_send) {
                if (kj_ptp_send_sdp_to_endpoint(ptp) == kj_code_success) {
                    // client角色发送地址给对端后，开启定时器执行超时无对端地址信息
                    kj_ptp_start_waiting_sdp_timer(ptp);
                }
            } else if (server_waitting_sdp) {
                kj_ptp_start_waiting_sdp_timer(ptp);
            }
        } else {
            ptp->ptp_state = kj_ptp_state_none;
            kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_connect_fail, kj_code_ptp_punch_disable, 1);
        }
    }
}
void kj_ptp_connect(kj_ptp *ptp, const char *sdp) {
    if (ptp && sdp) {
        // 解析sdp信息
        kj_sdp_parse_for_ptp(ptp, sdp);
        kj_thread_lock(&ptp->sdp.mutex);
        ptp->sdp.recvd = 1;
        if (ptp->info->local.role == kj_rm_role_client) {
            ptp->sdp.recvd = 0;
            kj_thread_unlock(&ptp->sdp.mutex);
            kj_ptp_start_punch(ptp);
        } else if (ptp->sdp.got) {
            ptp->sdp.recvd = 0;
            ptp->sdp.got = 0;
            kj_thread_unlock(&ptp->sdp.mutex);
            if (kj_ptp_send_sdp_to_endpoint(ptp) == kj_code_success) {
                kj_ptp_start_punch(ptp);
            }
        } else {
            kj_thread_unlock(&ptp->sdp.mutex);
        }
    }
}
void kj_ptp_close(kj_ptp *ptp) {
    if (ptp) {
        // 取消可能待执行的定时器
        kj_timer_cancel_task(rm_engine()->timer, ptp->op_timer);
        kj_timer_cancel_task(rm_engine()->timer, ptp->sdp.waiting_timer);
        // 初始化相关属性
        ptp->ptp_state = kj_ptp_state_none;
        ptp->sdp.local.port_cnt = 0;
        ptp->kalive.secs_alive = 0;
        ptp->kalive.secs_no_answer = 0;
        // 连接中则发送关闭信令
        if (ptp->state == kj_cnt_state_connected) {
            kj_data_head data = {
                .head = {'#', '$'},
                .type = KJ_RM_DATA_TYPE_DISCONNECT,
                .method = KJ_RM_DATA_METHOD_DISCONNECT
            };
            kj_ptp_send_data(ptp, &data, kj_data_head_length);
        }
        // 关闭sock
        kj_sock_close(ptp->sock, 0);
    }
}
kj_send_status kj_ptp_send_data(kj_ptp *ptp, const void *data, size_t length) {
    kj_send_status status = kj_send_status_invalid;
    if (ptp && ptp->state == kj_cnt_state_connected) {
        status = kj_sock_send_to(ptp->sock, data, length, &ptp->addr.endpoint);
    }
    return status;
}
void kj_ptp_update_kalive_with_data(kj_ptp *ptp, const void *data, size_t length, int *answer_missed) {
    if (ptp) {
        if (ptp->state == kj_cnt_state_connected) {
            size_t secs_alive = ptp->kalive.secs_alive++;
            size_t secs_no_answer = ptp->kalive.secs_no_answer;
            if (ptp->info->local.role == kj_rm_role_server) {
                ptp->kalive.secs_no_answer++;
            }
            if (secs_no_answer >= ptp->kalive.timeout) {
                // 自发送心跳包后超过间隔时间没有收到数据则中断
                // 关闭连接，发送关闭信令
                kj_ptp_close(ptp);
                // 更新连接状态为心跳超时中断
                kj_ptp_update_cnt_state_and_callback(ptp, kj_cnt_state_disconnected, kj_code_ptp_kalive_timeout, 1);
            } else {
                int send_ask = 0;
                if (ptp->info->local.role == kj_rm_role_client) {
                    if (secs_no_answer || secs_alive % ptp->kalive.interval == 0) {
                        ptp->kalive.secs_no_answer++;
                        send_ask = 1;
                    }
                } else {
                    if (secs_no_answer > ptp->kalive.interval) {
                        send_ask = 1;
                    }
                }
                if (send_ask) {
                    if (secs_no_answer && answer_missed) {
                        *answer_missed = 1;
                    }
                    // 发送请求回复心跳包
                    uint8_t rtt_seq = kj_ptp_kalive_renew_alive_seq(ptp);
                    kj_data_head *ask_data = kj_util_kalive_ask_data_with_seq(rtt_seq, data, length);
                    length = ask_data->length + kj_data_head_length;
                    ask_data->length = htons(ask_data->length);
                    kj_ptp_send_data(ptp, ask_data, length);
                    free(ask_data);
                }
            }
        } else {
            ptp->kalive.secs_alive = 0;
            ptp->kalive.secs_no_answer = 0;
        }
    }
}
void kj_ptp_select_to_using(kj_ptp *ptp) {
    if (ptp && ptp->state == kj_cnt_state_connected) {
        uint16_t data[2];
        data[0] = htons(KJ_RM_KALIVE_DATA_TYPE_SELECT_CNT);
        data[1] = ptp->cnt_id;
        data[1] = htons(data[1]);
        size_t length = sizeof(data);
        ptp->kalive.select_seq = kj_ptp_kalive_renew_alive_seq(ptp);
        kj_data_head *ask_data = kj_util_kalive_ask_data_with_seq(ptp->kalive.select_seq, data, length);
        length = ask_data->length + kj_data_head_length;
        ask_data->length = htons(ask_data->length);
        kj_ptp_send_data(ptp, ask_data, length);
        free(ask_data);
    }
}
#pragma mark - 属性配置
void *kj_ptp_get_user_data(kj_ptp *ptp) {
    return ptp ? ptp->user_data : NULL;
}
int kj_ptp_is_ipv6(kj_ptp *ptp) {
    return ptp && ptp->sock ? ptp->sock->af == AF_INET6 : 0;
}
