//
//  kj_ports_algorithm.h
//  P2PLib
//
//  Created by twenty on 2023/7/17.
//

#ifndef kj_ports_algorithm_h
#define kj_ports_algorithm_h

#include <stdio.h>
#include "kj_rm_types.h"

#pragma mark - 在基准端口左右顺序
/*
 取基准端口左右两边的指定数量范围内的端口，左右顺序排序
 假设basePort = 1000，count = 10
 排序后的结果示例：[1000,1001,999,1002,998,1004,997,1005,996,1006]
 */
void kj_ports_around_base(uint16_t basePort, uint16_t *ports, uint16_t count);

#pragma mark - 算法1:在基准端口左右随机排序，但优先指定范围内的
/*
 先在基准端口指定范围内左右交替随机排序，再到范围外的左右交替随机排序
 */
void kj_ports_alg1_random_around_base_priority_in_range(uint16_t basePort, uint16_t range, uint16_t *ports, uint16_t count);

#pragma mark - 算法2:在基准端口左右随机排序
/*
 基准端口左右两边的指定数量范围内的端口，左右交替随机排序
 假设basePort = 1000，count = 10
 随机排序后的结果示例：[1000,1004,996,1001,997,1003,999,1005,998,1002]
 */
void kj_ports_alg2_random_around_base(uint16_t basePort, uint16_t *ports, uint16_t count);

#pragma mark - 算法3:在基准端口两边随机排序
/*
 取基准端口左右两边随机排序
 */
void kj_ports_alg3_random_from_base(uint16_t basePort, uint16_t *ports, uint16_t count);

#pragma mark - 算法4:在基准端口两边随机排序
/*
 取基准端口左右两边的指定数量范围内的端口，随机取指定数量的端口排序
 */
void kj_ports_alg4_random_from_base_priority_in_range(uint16_t basePort, uint16_t range, uint16_t *ports, uint16_t count);

#endif /* kj_ports_algorithm_h */
