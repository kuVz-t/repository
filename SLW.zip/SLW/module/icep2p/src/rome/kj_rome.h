//
//  kj_rome.h
//  ios_demo
//
//  Created by twenty on 2023/4/25.
//

#ifndef kj_rome_h
#define kj_rome_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "kj_rm_types.h"

RM_CPP_BEGIN

typedef struct kj_rome kj_rome;

typedef struct kj_rmcnt_info {
    kj_cnt_type type;   // 连接类型
    kj_code status;     // 连接状态码；0:成功；其他失败
    uint16_t cnt_id;    // 连接ID
    size_t elapsed_ms;  // 连接耗时，单位毫秒
    int ipv6;           // 0:IPv4; 1:IPv6
    int index;          // 在数组中的index
} kj_rmcnt_info;

typedef struct kj_rmcnt_extra_info {
    int local_ver;  // 本端版本
    int endp_ver;   // 对端版本
    int local_nat;  // 本端NAT端口变化范围
    int endp_nat;   // 对端NAT端口变化范围
} kj_rmcnt_extra_info;

typedef struct kj_rome_cb {
    /// 连接状态回调
    /// @param rome rome实例
    /// @param state 状态
    /// @param status_code 0:成功；其他参看kj_code的枚举值
    void (*state_cb)(kj_rome *rome, kj_cnt_state state, kj_code status_code);

    /// 收到数据回调
    /// @param rome rome实例
    /// @param data 数据指针
    /// @param length 数据长度
    void (*recv_data_cb)(kj_rome *rome, const void *data, size_t length);
    
    /// 获取到SDP信息需要发送的回调
    /// @param rome rome实例
    /// @param sdp 本端发送给对端的SDP信息
    /// @param ipv6 0:IPv4；1:IPv6
    /// @return 发送状态码，只需要返回以下三种：
    /// 1、kj_code_success:发送成功；2、kj_code_bypass_err:信令不可用；3、kj_code_bypass_send_sdp_err:发送sdp失败
    kj_code (*send_sdp_to_endpoint_cb)(kj_rome *rome, const char *sdp, int ipv6);
    
    /// 客户端正在请求传输的媒体流的通道号回调，只有媒体流发送方才会收到此回调
    /// @param rome rome实例
    /// @param stream_channels 通道值数组
    /// @param channel_count 通道数量
    void (*streams_in_transmitting_cb)(kj_rome *rome, uint16_t stream_channels[], int channel_count);
    
    /// 所有连接建连完成后的建连信息回调，用于采集连接结果
    /// @param rome rome实例
    /// @param cnt_info 建连结果信息数组
    /// @param info_count 建连结果信息个数
    /// @param extra_info 建连两端的其他信息，包括版本和IPv4的NAT类型
    /// NAT类型等于100为端口不变型，大于100时则表示对称NAT的端口变化在该值范围内，此时取值范围如下：
    /// 100,1000,2000,4000,8000,10000,16000,20000,25000,30000,35000,40000,45000,50000,55000,60000,65000,65535
    void (*connection_info_cb)(kj_rome *rome, kj_rmcnt_info cnt_infos[], int cnt_count, kj_rmcnt_extra_info extra_info);
} kj_rome_cb;

typedef struct kj_rome_inner kj_rome_inner;
struct kj_rome {
    char *client_id;    // 客户端id，服务端可用此标记唯一的客户端
    char *server_id;    // 服务端id，客户端方可用此标记唯一的服务端
    void *user_data;    // 上层数据指针
    size_t bytes_sent;  // 发送数据字节总数，超过类型Max值重回0不影响计算流速
    size_t bytes_recv;  // 接收数据字节总数，超过类型Max值重回0不影响计算流速
    kj_rome_cb callback;// 回调函数结构体
    kj_cnt_state state; // 连接状态
    kj_rmcnt_info cur_cnt_info;// 当前连接信息
    kj_rome_inner *inner;// 私有属性
};

#pragma mark - 实例创建与销毁
/// 创建rome实例
/// @param client_id 客户端id，服务端可用此标记唯一的客户端
/// @param server_id 服务端id，客户端方可用此标记唯一的服务端
/// @param role 角色，被动方作为kj_rm_role_server，主动方作为kj_rm_role_client
/// @param user_data 上层数据指针
kj_rome *kj_rome_create(const char *client_id, const char *server_id, kj_rm_role role, void *user_data);

/// 销毁rome实例
void kj_rome_destroy(kj_rome **rome);

/// 释放rome相关的线程、队列、定时器资源，必须在所有rome实例销毁后才可执行
void kj_rome_release_after_all_rome_destroy(void);

#pragma mark - 连接管理
/// 获取本端用于建连的SDP信息
/// @param rome rome实例
/// @param server stun、turn服务信息
void kj_rome_get_sdp_with_server(kj_rome *rome, const kj_rome_server *server);

/// 使用对端的SDP信息建立连接，由于内部管理多个连接，所以一个建连周期可能会有多个SDP信息
/// @param rome rome实例
/// @param sdp SDP信息
/// @param ipv6 是否为IPv6的SDP信息
void kj_rome_connect_endpoint(kj_rome *rome, const char *sdp, int ipv6);

/// 断开连接，针对当前已有连接的前提下有效
/// @param rome rome实例
/// @param callback 0:不在状态回调函数回调断开状态；1:在状态回调函数回调断开状态
void kj_rome_close(kj_rome *rome, int callback);

/// 建连成功后，可发送数据
/// @param rome rome实例
/// @param data 数据指针
/// @param length 数据长度
/// @return 发送结果
kj_send_status kj_rome_send_data(kj_rome *rome, const void *data, size_t length);

#pragma mark - 属性配置
/// 开启或关闭私有协议心跳保活
/// @param rome rome实例
/// @param enable 0:关闭；1:开启
void kj_rome_enable_internal_keepalive(kj_rome *rome, int enable);

/// 设置回调函数，也可直接设置rome->callback属性设置单个回调函数
/// @param rome rome实例
/// @param callback 回调函数结构体
void kj_rome_set_callback(kj_rome *rome, kj_rome_cb callback);

/// 设置支持建连的类型，默认为kj_road_ice | kj_road_ptp，即同时支持ICE和自研PTP建连
/// @param rome rome实例
/// @param road_support 支持的连接类型，可使用或语法，如kj_road_ice | kj_road_ptp代表支持两种
void kj_rome_set_road_support(kj_rome *rome, kj_road_type road_support);

/// 设置ptp打洞算法参数（client角色设置有效）
/// @param rome rome实例
/// @param algorithm 打洞算法参数，算法type任何值生效，其他参数为0时不生效
void kj_rome_set_ptp_algorithm(kj_rome *rome, kj_ptp_alg algorithm);

/// 获取内部心跳机制是否已发生缺失一次或多次心跳回复
int kj_rome_is_missed_keepalive_answer_for_now(kj_rome *rome);

/// 客户端侧向服务端请求媒体流后，可设置正在请求媒体流的通道号，可设置多个，最多不超过25个
/// 通道号数据会通过心跳包发送给服务端，避免停止请求媒体流信令丢包导致服务端无法收到时，通过心跳包告知服务端是否继续在请求媒体流
/// @param rome rome实例
/// @param stream_channels 通道号数组
/// @param channel_count 通道号个数
void kj_rome_set_stream_channels_in_transmitting(kj_rome *rome, uint16_t stream_channels[], int channel_count);

/// 获取当前使用的连接的rtt时间，如无连接则返回0
int kj_rome_get_current_cnt_rtt(kj_rome *rome);

/// 更新当前使用的连接的rtt时间
void kj_rome_update_current_cnt_rtt(kj_rome *rome, int rtt);

/// 获取IPv4的NAT类型的端口变化范围
int kj_rome_get_ipv4_nat_port_range(kj_rome *rome);

#pragma mark - 属性获取
kj_rome_info *kj_rome_get_info(kj_rome *rome);

RM_CPP_END

#endif /* kj_rome_h */
