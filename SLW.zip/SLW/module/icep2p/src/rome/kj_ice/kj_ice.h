//
//  kj_ice.h
//  P2PLib
//
//  Created by twenty on 2023/5/25.
//

#ifndef kj_ice_h
#define kj_ice_h

#include <stdio.h>

#include <pjlib.h>
#include <pjnath.h>

#include "kj_rm_types.h"
#include "kj_engine.h"

#define KJ_ICE_OPERATIOIN_TIMEOUT       10000 // ICE各个流程的超时时间，毫秒
#define KJ_ICE_OPERATIOIN_GATHER        1 // 收集候选地址
#define KJ_ICE_OPERATIOIN_NEGOTIATION   2 // 协商建连
#define KJ_ICE_OPERATIOIN_WAITTING_SDP  3 // 等待对端SDP

typedef struct kj_ice kj_ice;

typedef struct kj_ice_cb {
    void (*recv_data_cb)(kj_ice *ice, const void *data, size_t length);
    void (*state_cb)(kj_ice *ice, kj_cnt_state state, kj_code status_code);
    kj_code (*sdp_info_cb)(kj_ice *ice, const char *sdp);
    void (*being_selected_cb)(kj_ice *ice);
} kj_ice_cb;

typedef struct kj_ice {
    kj_rome_info *info;
    kj_cnt_state state;
    kj_cnt_type cnt_type;
    kj_ice_cb callback;
    void *user_data;
    uint16_t cnt_id;
    int ipv6;
    struct {
        int got;    // 标记是否取得本端sdp信息
        int recvd;  // 标记是否已收到对端sdp信息
        pthread_mutex_t mutex;       // 标记属性设置和读取的锁
        kj_timer_task waiting_timer; // client角色发送本端sdp信息后即启动超时等待对端sdp，server则在取得本端sdp信息后启动
    } sdp;
    struct {
        uint8_t seq;            // 加在心跳包的保留字节中，自增取值，跳过0值，用于返回心跳包对应发送的sequence而计算rtt
        kj_time seq_renew_time; // 更新一次“keepalive_seq”值时，更新该时间值，当收到回复心跳包时以此值为起点计算时间间隔
        uint8_t select_seq;     // 标记是否被选择使用，被标记时发送心跳包的序号收到回复时则确认通道可用
        int rtt;                // 链路数据往返时间，毫秒
        int timeout;            // 心跳超时时间，默认client 5s,server 15s
        int interval;           // 心跳包发送间隔，默认5s
        size_t secs_no_answer;  // 已经多少秒没有收到心跳回复，大于kalive_timeout则判断对方已离线
        size_t secs_alive;      // 建立连接的时间，用于每隔kalive_interval发送心跳包
    } kalive;
    struct {
        kj_thread *thread;
        kj_timer_task timer;
        pj_ice_strans *strans;
        pj_ice_strans_cfg cfg;
        unsigned comp_cnt;
        int max_host;
    } ice;
    /* Variables to store parsed remote ICE info */
    struct cands_info {
        char ufrag[80];
        char pwd[80];
        char foundation[PJ_ICE_ST_MAX_CAND][32];
        unsigned comp_cnt;
        pj_sockaddr def_addr[PJ_ICE_MAX_COMP];
        unsigned cand_cnt;
        pj_ice_sess_cand cand[PJ_ICE_ST_MAX_CAND];
    } endp_cands;
    pj_thread_desc thread_desc;
} kj_ice;

pj_thread_t *kj_ice_register_thread_to_pjlib(pj_thread_desc desc);

/// 创建kj_ice实例
/// @param info 建连信息
/// @param user_data 上层数据指针
/// @param icecb 回调函数结构体
/// @return kj_ice实例
kj_ice *kj_ice_create(kj_rome_info *info, void *user_data, kj_ice_cb icecb);

void *kj_ice_get_user_data(kj_ice *ice);

/// 销毁kj_ice实例
void kj_ice_destroy(kj_ice **ice);

/// 从stun、turn服务获取sdp信息
/// @param ice kj_ice实例
/// @param ipv6 IPv6地址标志
/// @param server stun、turn服务信息，根据ipv6取对应的值，字符串由上层在整个ice的生命周期持有
void kj_ice_get_sdp(kj_ice *ice, int ipv6, kj_rome_server *server);

/// 关闭ICE连接，如当前已连接则发送关闭信令后销毁ICE
void kj_ice_close(kj_ice *ice);

/// 开始ICE协商
/// @param sdp 对端SDP
void kj_ice_start_negotiation(kj_ice *ice, const char *sdp);

/// 通过ICE通道发送数据（UDP）
/// @param data 数据指针
/// @param length 数据长度
/// @return 发送结果
kj_send_status kj_ice_send_data(kj_ice *ice, const void *data, size_t length);

/// 心跳包活机制方法，由外部每秒执行
/// @param ice ice实例
/// @param data 附在心跳包一起发送的数据，存放传输中的媒体流的通道号
/// @param length 数据长度
/// @param answer_missed 获取是否已发生心跳一秒未回复
void kj_ice_update_kalive_with_data(kj_ice *ice, const void *data, size_t length, int *answer_missed);

void kj_ice_select_to_using(kj_ice *ice);

#endif /* kj_ice_h */
