//
//  kj_ice.c
//  P2PLib
//
//  Created by twenty on 2023/5/25.
//

#include "kj_ice.h"
#include "kj_sdp.h"

struct kj_ice_update_state_paras {
    kj_ice *ice;
    kj_cnt_state state;
    kj_code status_code;
    int callback;
};
struct kj_ice_send_data_paras {
    kj_ice *ice;
    void *data;
    size_t length;
};

#pragma mark - 函数定义
void kj_ice_timer_task_excuting_callback(const kj_timer *timer, kj_timer_task *task);
void kj_ice_update_state_and_callback(kj_ice *ice, kj_cnt_state state, kj_code err_code, int callback);
void kj_ice_strans_recv_data_cb(pj_ice_strans *ice_st, unsigned comp_id,
                                void *pkt, pj_size_t size,
                                const pj_sockaddr_t *src_addr, unsigned src_addr_len);
void kj_ice_strans_op_complete(pj_ice_strans *ice_st, pj_ice_strans_op op, pj_status_t status);

#pragma mark - 工具函数
uint8_t kj_ice_kalive_renew_alive_seq(kj_ice *ice) {
    uint8_t seq = 0;
    if (ice) {
        seq = ++ice->kalive.seq;
        if (seq == 0) {
            seq = ++ice->kalive.seq;
        }
        ice->kalive.seq_renew_time = kj_time_get_current();
    }
    return seq;
}

#pragma mark - ice session初始化
pj_status_t kj_ice_init_strans_session(kj_ice *ice) {
    pj_status_t status = PJ_SUCCESS;
    if (ice->ice.strans && !pj_ice_strans_has_sess(ice->ice.strans)) {
        pj_ice_sess_role role = ice->info->local.role == kj_rm_role_client ?
        PJ_ICE_SESS_ROLE_CONTROLLING : PJ_ICE_SESS_ROLE_CONTROLLED;
        status = pj_ice_strans_init_ice(ice->ice.strans, role, NULL, NULL);
    }
    return status;
}

#pragma mark - ice创建、协商建连和销毁专属执行线程
void _kj_ice_op_create(kj_ice *ice) {
    // 销毁上次的ice strans
    if (ice->ice.strans) {
        pj_ice_strans_destroy(ice->ice.strans);
        ice->ice.strans = NULL;
    }
    pj_ice_strans_cb icecb = {
        .on_rx_data = kj_ice_strans_recv_data_cb,
        .on_ice_complete = kj_ice_strans_op_complete
    };
    // 为避免创建ice阻塞，先启动收集候选地址10s倒计时
    kj_timer_cancel_task(rm_engine()->timer, ice->ice.timer);
    kj_timer_init_task(&ice->ice.timer, ice, KJ_ICE_OPERATIOIN_TIMEOUT,
                       0, kj_ice_timer_task_excuting_callback);
    ice->ice.timer.task_id = KJ_ICE_OPERATIOIN_GATHER;
    kj_timer_schedule_task(rm_engine()->timer, ice->ice.timer);
    // 创建ice strans
    pj_status_t status = pj_ice_strans_create("rm ptp", &ice->ice.cfg, ice->ice.comp_cnt,
                                              ice, &icecb, &ice->ice.strans);
    // 创建失败则取消倒计时，并回调失败
    if (status != PJ_SUCCESS) {
        kj_timer_cancel_task(rm_engine()->timer, ice->ice.timer);
        kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, kj_code_ice_server_err, 1);
    }
}
void _kj_ice_op_destroy(kj_ice *ice) {
    if (ice->ice.strans) {
        pj_ice_strans_destroy(ice->ice.strans);
        ice->ice.strans = NULL;
    }
}
void _kj_ice_op_negotiation(kj_ice *ice) {
    // server角色且已收到client的sdp，则进行协商建连
    pj_str_t rufrag, rpwd;
    if (ice->ice.strans) {
        // 为避免协商接口阻塞，先启动协商建连10s倒计时
        kj_timer_cancel_task(rm_engine()->timer, ice->ice.timer);
        kj_timer_init_task(&ice->ice.timer, ice, KJ_ICE_OPERATIOIN_TIMEOUT,
                           0, kj_ice_timer_task_excuting_callback);
        ice->ice.timer.task_id = KJ_ICE_OPERATIOIN_NEGOTIATION;
        kj_timer_schedule_task(rm_engine()->timer, ice->ice.timer);
        // 开始协商
        pj_status_t status = pj_ice_strans_start_ice(ice->ice.strans,
                                                     pj_cstr(&rufrag, ice->endp_cands.ufrag),
                                                     pj_cstr(&rpwd, ice->endp_cands.pwd),
                                                     ice->endp_cands.cand_cnt,
                                                     ice->endp_cands.cand);
        // 协商失败取消倒计时，并回调失败
        if (status != PJ_SUCCESS) {
            kj_timer_cancel_task(rm_engine()->timer, ice->ice.timer);
            kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, kj_code_ice_start_nego_fail, 1);
        }
    } else {
        kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, kj_code_ice_start_nego_fail, 1);
    }
}
void _kj_ice_update_state_and_callback(kj_ice *ice, kj_cnt_state state, kj_code err_code, int callback) {
    if (ice->state != state) {
        ice->state = state;
        if (ice->state == kj_cnt_state_connected) {
            // 获取本次ice的建连类型，默认已为kj_cnt_type_turn
            const pj_ice_sess_check *check = ice->ice.strans ? pj_ice_strans_get_valid_pair(ice->ice.strans, 1) : NULL;
            if (check) {
                if (check->lcand->type == PJ_ICE_CAND_TYPE_RELAYED || check->rcand->type == PJ_ICE_CAND_TYPE_RELAYED) {
                    ice->cnt_type = kj_cnt_type_turn;
                } else if (check->lcand->type == PJ_ICE_CAND_TYPE_SRFLX || check->rcand->type == PJ_ICE_CAND_TYPE_SRFLX) {
                    ice->cnt_type = kj_cnt_type_ice_ptp;
                } else if (check->lcand->type == PJ_ICE_CAND_TYPE_HOST || check->rcand->type == PJ_ICE_CAND_TYPE_HOST) {
                    ice->cnt_type = kj_cnt_type_lan;
                }
            }
        }
        if (callback) {
            ice->callback.state_cb(ice, ice->state, err_code);
        }
    }
}
void _kj_ice_op_send_data(kj_ice *ice, const void *data, size_t length) {
    if (ice->ice.strans) {
        pj_ice_strans_sendto2(ice->ice.strans, 1, data, length,
                              &ice->endp_cands.def_addr[0],
                              pj_sockaddr_get_len(&ice->endp_cands.def_addr[0]));
    }
}
void kj_ice_op_thread_task_execute_callback(const kj_thread *thread, const void *func, void *args) {
    kj_ice *ice = args;
    if (func == _kj_ice_op_create) {
        _kj_ice_op_create(ice);
    } else if (func == _kj_ice_op_destroy) {
        _kj_ice_op_destroy(ice);
    } else if (func == _kj_ice_op_negotiation) {
        _kj_ice_op_negotiation(ice);
    } else if (func == _kj_ice_update_state_and_callback) {
        struct kj_ice_update_state_paras *paras = args;
        _kj_ice_update_state_and_callback(paras->ice, paras->state, paras->status_code, paras->callback);
    } else if (func == _kj_ice_op_send_data) {
        struct kj_ice_send_data_paras *paras = args;
        _kj_ice_op_send_data(paras->ice, paras->data, paras->length);
        free(paras->data);
    }
}
void kj_ice_op_thread_task_cancel_callback(const kj_thread *thread, const void *func, void *args) {
    if (func == _kj_ice_op_send_data) {
        struct kj_ice_send_data_paras *paras = args;
        free(paras->data);
    }
}
void kj_ice_op_thread_register_to_pjlib_callback(const kj_thread *thread, const void *func, void *args) {
    kj_ice *ice = args;
    kj_ice_register_thread_to_pjlib(ice->thread_desc);
}
void kj_ice_op_thread_will_destroy_callback(const kj_thread *thread, void *user_data) {
    kj_ice *ice = user_data;
    _kj_ice_op_destroy(ice);
    pthread_mutex_destroy(&ice->sdp.mutex);
    free(ice);
}
void kj_ice_op_create(kj_ice *ice) {
    kj_thread_task task = kj_thread_task_create(kj_ice_op_thread_task_execute_callback, NULL);
    task.args = ice;
    task.function = _kj_ice_op_create;
    kj_thread_add_task(ice->ice.thread, task);
}
void kj_ice_op_destroy(kj_ice *ice) {
    kj_thread_task task = kj_thread_task_create(kj_ice_op_thread_task_execute_callback, NULL);
    task.args = ice;
    task.function = _kj_ice_op_destroy;
    kj_thread_add_task(ice->ice.thread, task);
}
void kj_ice_op_negotiation(kj_ice *ice) {
    kj_thread_task task = kj_thread_task_create(kj_ice_op_thread_task_execute_callback, NULL);
    task.args = ice;
    task.function = _kj_ice_op_negotiation;
    kj_thread_add_task(ice->ice.thread, task);
}
void kj_ice_op_send_data(kj_ice *ice, const void *data, size_t length) {
    kj_thread_task task = kj_thread_task_create(kj_ice_op_thread_task_execute_callback, kj_ice_op_thread_task_cancel_callback);
    void *new_data = malloc(length);
    memcpy(new_data, data, length);
    struct kj_ice_send_data_paras paras = {
        .ice = ice,
        .data = new_data,
        .length = length
    };
    task.args = &paras;
    task.args_length = sizeof(paras);
    task.function = _kj_ice_op_send_data;
    if (!kj_thread_add_task(ice->ice.thread, task)) {
        free(new_data);
    }
}
#pragma mark - ice state callback
void kj_ice_update_state_and_callback(kj_ice *ice, kj_cnt_state state, kj_code status_code, int callback) {
    kj_thread_task task = kj_thread_task_create(kj_ice_op_thread_task_execute_callback, NULL);
    struct kj_ice_update_state_paras paras = {
        .ice = ice,
        .state = state,
        .status_code = status_code,
        .callback = callback
    };
    task.args = &paras;
    task.args_length = sizeof(paras);
    task.function = _kj_ice_update_state_and_callback;
    kj_thread_add_task(ice->ice.thread, task);
}

#pragma mark - ice strans callback
void kj_ice_strans_recv_data_cb(pj_ice_strans *ice_st, unsigned comp_id,
                                void *pkt, pj_size_t size,
                                const pj_sockaddr_t *src_addr, unsigned src_addr_len) {
    kj_ice *ice = pj_ice_strans_get_user_data(ice_st);
    if (!ice) {return;}

    kj_data_head data_head = {};
    if (kj_util_is_rm_data(pkt, size, &data_head)
        && data_head.type == KJ_RM_DATA_TYPE_DISCONNECT
        && data_head.method == KJ_RM_DATA_METHOD_DISCONNECT) {
//        char json[50];
//        size_t seqid = 32452;
//        int length = snprintf(json, sizeof(json), "{\"METHOD\":\"%02X%02X\",\"SEQID\":\"%zu\",\"CODE\":\"0\",\"BODY\":{\"CntId\":\"%zu\"}}",KJ_RM_DATA_TYPE_DISCONNECT,KJ_RM_DATA_METHOD_DISCONNECT,seqid,ice->cnt_id);
//        kj_data_head *data = kj_util_create_rm_data(json, length);
//        data->type = KJ_RM_DATA_TYPE_DISCONNECT;
//        data->method = KJ_RM_DATA_METHOD_DISCONNECT;
//        length = data->length + kj_data_head_length;
//        free(data);
        
        // 断开信令改为只发送数据头，旧版本设备固件则等待心跳超时而中断，旧版本客户端不处理该信令
        data_head.method += 1;
        data_head.length = 0;
        kj_ice_send_data(ice, &data_head, kj_data_head_length);
        kj_ice_op_destroy(ice);
        kj_ice_update_state_and_callback(ice, kj_cnt_state_disconnected, kj_code_ice_discnt_by_endpoint, 1);
    } else {
        if (kj_util_is_rm_kalive_data(pkt, size, &data_head)) {
            if (data_head.type == KJ_RM_DATA_TYPE_KALIVE_ANSWER) {
                if (data_head.reserved && data_head.reserved == ice->kalive.seq) {
                    size_t interval = kj_time_interval_between(ice->kalive.seq_renew_time, kj_time_get_current());
                    if (ice->kalive.rtt) {
                        ice->kalive.rtt = ice->kalive.rtt * 0.8 + interval * 0.2;
                    } else {
                        ice->kalive.rtt = (int)interval;
                    }
                }
                if (data_head.reserved) {
                    ice->kalive.secs_no_answer = 0;
                }
                // 收到选择连接的心跳包回复则回调连接被选择
                if (data_head.reserved && data_head.reserved == ice->kalive.select_seq) {
                    ice->kalive.select_seq = 0;
                    ice->callback.being_selected_cb(ice);
                }
            } else {
                // 发送回复心跳包
                kj_data_head *answer_data = kj_util_kalive_answer_data_with_seq(data_head.reserved, NULL, 0);
                kj_ice_send_data(ice, answer_data, kj_data_head_length);
                free(answer_data);
                // 判断是否为选择连接的心跳包
                if (data_head.length >= 4) {
                    uint16_t *point = pkt + kj_data_head_length;
                    uint16_t type = *point;
                    if (ntohs(type) == KJ_RM_KALIVE_DATA_TYPE_SELECT_CNT) {
                        ice->kalive.select_seq = 0;
                        ice->callback.being_selected_cb(ice);
                    }
                }
            }
            // 服务端只要收到对端的心跳则认为链路可用
            if (ice->info->local.role == kj_rm_role_server) {
                ice->kalive.secs_no_answer = 0;
            }
        }
        ice->callback.recv_data_cb(ice, pkt, size);
    }
}

/*
 * This is the callback that is registered to the ICE stream transport to
 * receive notification about ICE state progression.
 */
void kj_ice_strans_op_complete(pj_ice_strans *ice_st, pj_ice_strans_op op, pj_status_t status) {
    kj_ice *ice = pj_ice_strans_get_user_data(ice_st);
    if (!ice) {return;}

    // 取消收集候选地址或协商超时定时器
    kj_timer_cancel_task(rm_engine()->timer, ice->ice.timer);
    // 处理状态
    if (op == PJ_ICE_STRANS_OP_INIT) {
        if (status == PJ_SUCCESS) {
            if (kj_ice_init_strans_session(ice) == PJ_SUCCESS) {
                pthread_mutex_lock(&ice->sdp.mutex);
                ice->sdp.got = 1;
                if (ice->info->local.role == kj_rm_role_client || ice->sdp.recvd) {
                    ice->sdp.got = 0;
                    pthread_mutex_unlock(&ice->sdp.mutex);
                    // client角色或sever角色获取对端SDP信息后可立即发送本端SDP给对端
                    char sdp[KJ_SDP_INFO_MAX_LENGTH];
                    kj_sdp_encode_ice_sdp(ice, sdp, KJ_SDP_INFO_MAX_LENGTH);
                    kj_code code = ice->callback.sdp_info_cb(ice, sdp);
                    if (code == kj_code_success) {
                        if (ice->info->local.role == kj_rm_role_server) {
                            kj_ice_op_negotiation(ice);
                        } else {
                            // client角色先发送SDP信息后，开启等待server端sdp信息超时定时器
                            kj_timer_init_task(&ice->sdp.waiting_timer, ice,
                                               _kj_rm_cfg.waiting_sdp_timeout_ms,
                                               0, kj_ice_timer_task_excuting_callback);
                            ice->sdp.waiting_timer.task_id = KJ_ICE_OPERATIOIN_WAITTING_SDP;
                            kj_timer_schedule_task(rm_engine()->timer, ice->sdp.waiting_timer);
                        }
                    } else {
                        kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, code, 1);
                    }
                } else {
                    pthread_mutex_unlock(&ice->sdp.mutex);
                    // server角色获得SDP信息且未收到client发来的sdp，开启等待client端sdp信息超时定时器
                    kj_timer_init_task(&ice->sdp.waiting_timer, ice,
                                       _kj_rm_cfg.waiting_sdp_timeout_ms,
                                       0, kj_ice_timer_task_excuting_callback);
                    ice->sdp.waiting_timer.task_id = KJ_ICE_OPERATIOIN_WAITTING_SDP;
                    kj_timer_schedule_task(rm_engine()->timer, ice->sdp.waiting_timer);
                }
            } else {
                kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, kj_code_ice_init_ses_err, 1);
            }
        } else if (status == PJNATH_ESTUNTIMEDOUT) {
            kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, kj_code_ice_init_timeout, 1);
        } else {
            kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, kj_code_ice_init_err, 1);
        }
    } else if (op == PJ_ICE_STRANS_OP_NEGOTIATION) {
        if (status == PJ_SUCCESS) {
            kj_ice_update_state_and_callback(ice, kj_cnt_state_connected, kj_code_success, 1);
        } else {
            kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, kj_code_ice_nego_cb_fail, 1);
        }
    }
}

#pragma mark - 定时任务回调
void kj_ice_timer_task_excuting_callback(const kj_timer *timer, kj_timer_task *task) {
    if (task->task_id == KJ_ICE_OPERATIOIN_GATHER) {
        // 收集候选地址超时
        kj_ice_update_state_and_callback(task->user_data, kj_cnt_state_connect_fail, kj_code_ice_init_no_callback, 1);
    } else if (task->task_id == KJ_ICE_OPERATIOIN_NEGOTIATION) {
        // 协商建连超时
        kj_ice_update_state_and_callback(task->user_data, kj_cnt_state_connect_fail, kj_code_ice_nego_timeout, 1);
    } else if (task->task_id == KJ_ICE_OPERATIOIN_WAITTING_SDP) {
        // 对端超时无sdp信息发来
        kj_ice_update_state_and_callback(task->user_data, kj_cnt_state_connect_fail, kj_code_ice_nego_no_endp_sdp, 1);
    }
}

#pragma mark - public api
pj_thread_t *kj_ice_register_thread_to_pjlib(pj_thread_desc desc) {
    pj_thread_t *thread = NULL;
    if (!pj_thread_is_registered()) {
        pj_thread_register(NULL, desc, &thread);
    }
    return thread;
}
kj_ice *kj_ice_create(kj_rome_info *info, void *user_data, kj_ice_cb icecb) {
    kj_ice *ice = calloc(1, sizeof(kj_ice));
    ice->info = info;
    ice->user_data = user_data;
    ice->callback = icecb;
    kj_thread_init_mutex(&ice->sdp.mutex, 0);
    ice->cnt_type = kj_cnt_type_turn;
    // 心跳包发送间隔5s
    ice->kalive.interval = 5;
    if (ice->info->local.role == kj_rm_role_client) {
        // 客户端心跳包超过5秒（发5次）无响应则超时中断
        ice->kalive.timeout = 5;
    } else {
        // 服务端超过15s无对端心跳包则链路不可用
        ice->kalive.timeout = 15;
    }
    // 配置
    ice->ice.comp_cnt = 1;
    ice->ice.max_host = 2;
    // ice 线程
    ice->ice.thread = kj_thread_create("ice thread", ice, kj_ice_op_thread_will_destroy_callback);
    kj_thread_task task = kj_thread_task_create(kj_ice_op_thread_register_to_pjlib_callback, NULL);
    task.args = ice;
    kj_thread_add_task(ice->ice.thread, task);
    return ice;
}
void *kj_ice_get_user_data(kj_ice *ice) {
    return ice ? ice->user_data : NULL;
}
void kj_ice_destroy(kj_ice **ice) {
    kj_ice *temp = *ice;
    *ice = NULL;
    if (temp) {
        kj_ice_close(temp);
        kj_thread_destroy(&temp->ice.thread);
    }
}
void kj_ice_get_sdp(kj_ice *ice, int ipv6, kj_rome_server *server) {
    if (ice) {
        ice->state = kj_cnt_state_connecting;
        ice->ipv6 = ipv6;

        pj_ice_strans_cfg_default(&ice->ice.cfg);
        pj_stun_config_init(&ice->ice.cfg.stun_cfg, &rm_engine()->caching_pool.factory, 0, rm_engine()->ioqueue, rm_engine()->timerhp);
        /* Maximum number of host candidates */
        ice->ice.cfg.stun.max_host_cands = ice->ice.max_host;
        /* Nomination strategy */
        ice->ice.cfg.opt.aggressive = PJ_FALSE;
        
        // 配置stun、turn服务
        ice->ice.cfg.af = ipv6 ? pj_AF_INET6() : pj_AF_INET();
        /* Configure STUN/srflx candidate resolution */
        ice->ice.cfg.stun.af = ice->ice.cfg.af;
        if (ipv6 && server->ipv6_stun_host) {
            ice->ice.cfg.stun.server.ptr = server->ipv6_stun_host;
            ice->ice.cfg.stun.server.slen = strlen(server->ipv6_stun_host);
            ice->ice.cfg.stun.port = server->ipv6_stun_port ? (pj_uint16_t)atoi(server->ipv6_stun_port) : PJ_STUN_PORT;
        } else if (!ipv6 && server->stun_host) {
            ice->ice.cfg.stun.server.ptr = server->stun_host;
            ice->ice.cfg.stun.server.slen = strlen(server->stun_host);
            ice->ice.cfg.stun.port = server->stun_port ? (pj_uint16_t)atoi(server->stun_port) : PJ_STUN_PORT;
        }
        /* For this demo app, configure longer STUN keep-alive time
         * so that it does't clutter the screen output.
         */
        ice->ice.cfg.stun.cfg.ka_interval = 300;
        
        /* Configure TURN candidate */
        ice->ice.cfg.turn.af = ice->ice.cfg.af;
        if (ipv6 && server->ipv6_turn_host) {
            ice->ice.cfg.turn.server.ptr = server->ipv6_turn_host;
            ice->ice.cfg.turn.server.slen = strlen(server->ipv6_turn_host);
            ice->ice.cfg.turn.port = server->ipv6_turn_port ? (pj_uint16_t)atoi(server->ipv6_turn_port) : PJ_STUN_PORT;
        } else if (!ipv6 && server->turn_host) {
            ice->ice.cfg.turn.server.ptr = server->turn_host;
            ice->ice.cfg.turn.server.slen = strlen(server->turn_host);
            ice->ice.cfg.turn.port = server->turn_port ? (pj_uint16_t)atoi(server->turn_port) : PJ_STUN_PORT;
        }

        /* TURN credential */
        ice->ice.cfg.turn.auth_cred.type = PJ_STUN_AUTH_CRED_STATIC;
        if (server->turn_username) {
            ice->ice.cfg.turn.auth_cred.data.static_cred.username.ptr = server->turn_username;
            ice->ice.cfg.turn.auth_cred.data.static_cred.username.slen = strlen(server->turn_username);
        }
        ice->ice.cfg.turn.auth_cred.data.static_cred.data_type = PJ_STUN_PASSWD_PLAIN;
        if (server->turn_userpass) {
            ice->ice.cfg.turn.auth_cred.data.static_cred.data.ptr = server->turn_userpass;
            ice->ice.cfg.turn.auth_cred.data.static_cred.data.slen = strlen(server->turn_userpass);
        }
        /* Connection type to TURN server */
        ice->ice.cfg.turn.conn_type = PJ_TURN_TP_UDP;
        /* For this demo app, configure longer keep-alive time
         * so that it does't clutter the screen output.
         */
        ice->ice.cfg.turn.alloc_param.ka_interval = 300;
        // 转到专属线程创建ice
        kj_ice_op_create(ice);
    }
}
void kj_ice_close(kj_ice *ice) {
    if (ice) {
        ice->kalive.secs_alive = 0;
        ice->kalive.secs_no_answer = 0;
        // 取消可能执行中的定时任务
        kj_timer_cancel_task(rm_engine()->timer, ice->ice.timer);
        kj_timer_cancel_task(rm_engine()->timer, ice->sdp.waiting_timer);
        // 连接中则发送关闭信令
        if (ice->state == kj_cnt_state_connected) {
//            char json[50];
//            size_t seqid = 32452;
//            int length = snprintf(json, sizeof(json), "{\"METHOD\":\"%02X%02X\",\"SEQID\":\"%zu\",\"CODE\":\"0\",\"BODY\":{\"CntId\":\"%zu\"}}",KJ_RM_DATA_TYPE_DISCONNECT,KJ_RM_DATA_METHOD_DISCONNECT,seqid,ice->cnt_id);
//            kj_data_head *data = kj_util_create_rm_data(json, length);
//            data->type = KJ_RM_DATA_TYPE_DISCONNECT;
//            data->method = KJ_RM_DATA_METHOD_DISCONNECT;
//            length = data->length + kj_data_head_length;
//            free(data);
            
            // 断开信令改为只发送数据头，旧版本设备固件则等待心跳超时而中断，旧版本客户端不处理该信令
            kj_data_head data = {
                .head = {'#', '$'},
                .type = KJ_RM_DATA_TYPE_DISCONNECT,
                .method = KJ_RM_DATA_METHOD_DISCONNECT
            };
            kj_ice_send_data(ice, &data, kj_data_head_length);
        }
        // 转到专属线程销毁ice
        kj_ice_op_destroy(ice);
    }
}
void kj_ice_start_negotiation(kj_ice *ice, const char *sdp) {
    if (ice && sdp) {
        // 取消等待对端sdp信息的超时定时器
        kj_timer_cancel_task(rm_engine()->timer, ice->sdp.waiting_timer);
        // 解析sdp
        kj_sdp_parse_for_ice(ice, sdp);
        if (ice->endp_cands.cand_cnt == 0) {
            // 对端无可用候选地址则建连失败
            kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, kj_code_ice_endp_sdp_err, 1);
        } else {
            // client角色或server且已完成候选地址的收集则可立即开始协商建连，但server角色须先发送本端sdp后再协商
            pthread_mutex_lock(&ice->sdp.mutex);
            ice->sdp.recvd = 1;
            if (ice->info->local.role == kj_rm_role_client || ice->sdp.got) {
                ice->sdp.recvd = 0;
                pthread_mutex_unlock(&ice->sdp.mutex);
                
                if (ice->info->local.role == kj_rm_role_server) {
                    char sdp[KJ_SDP_INFO_MAX_LENGTH];
                    kj_sdp_encode_ice_sdp(ice, sdp, KJ_SDP_INFO_MAX_LENGTH);
                    kj_code code = ice->callback.sdp_info_cb(ice, sdp);
                    if (code != kj_code_success) {
                        kj_ice_update_state_and_callback(ice, kj_cnt_state_connect_fail, code, 1);
                        return;
                    }
                }
                kj_ice_op_negotiation(ice);
            } else {
                pthread_mutex_unlock(&ice->sdp.mutex);
            }
        }
    }
}
kj_send_status kj_ice_send_data(kj_ice *ice, const void *data, size_t length) {
    kj_send_status status = kj_send_status_invalid;
    if (ice && data && ice->ice.strans) {
//        pj_thread_desc desc;
//        kj_ice_register_thread_to_pjlib(desc);
//        pj_status_t pj_status = pj_ice_strans_sendto2(ice->ice.strans, 1, data, length,
//                                                      &ice->endp_cands.def_addr[0],
//                                                      pj_sockaddr_get_len(&ice->endp_cands.def_addr[0]));
        pj_status_t pj_status = PJ_SUCCESS;
        kj_ice_op_send_data(ice, data, length);
        if (pj_status == PJ_SUCCESS) {
            status = kj_send_status_success;
        } else if (pj_status == PJ_EPENDING) {
            status = kj_send_status_pending;
        } else {
            status = kj_send_status_failed;
        }
    }
    return status;
}
void kj_ice_update_kalive_with_data(kj_ice *ice, const void *data, size_t length, int *answer_missed) {
    if (ice) {
        if (ice->state == kj_cnt_state_connected) {
            size_t secs_alive = ice->kalive.secs_alive++;
            size_t secs_no_answer = ice->kalive.secs_no_answer;
            if (ice->info->local.role == kj_rm_role_server) {
                ice->kalive.secs_no_answer++;
            }
            if (secs_no_answer >= ice->kalive.timeout) {
                // 自发送心跳包后超过间隔时间没有收到数据则中断
                // 关闭连接，发送关闭信令
                kj_ice_close(ice);
                // 更新连接状态为心跳超时中断
                kj_ice_update_state_and_callback(ice, kj_cnt_state_disconnected, kj_code_ice_kalive_timeout, 1);
            } else {
                int send_ask = 0;
                if (ice->info->local.role == kj_rm_role_client) {
                    if (secs_no_answer || secs_alive % ice->kalive.interval == 0) {
                        ice->kalive.secs_no_answer++;
                        send_ask = 1;
                    }
                } else {
                    if (secs_no_answer > ice->kalive.interval) {
                        send_ask = 1;
                    }
                }
                if (send_ask) {
                    if (secs_no_answer && answer_missed) {
                        *answer_missed = 1;
                    }
                    // 发送请求回复心跳包
                    uint8_t rtt_seq = kj_ice_kalive_renew_alive_seq(ice);
                    kj_data_head *ask_data = kj_util_kalive_ask_data_with_seq(rtt_seq, data, length);
                    length = ask_data->length + kj_data_head_length;
                    ask_data->length = htons(ask_data->length);
                    kj_ice_send_data(ice, ask_data, length);
                    free(ask_data);
                }
            }
        } else {
            ice->kalive.secs_alive = 0;
            ice->kalive.secs_no_answer = 0;
        }
    }
}
void kj_ice_select_to_using(kj_ice *ice) {
    if (ice && ice->state == kj_cnt_state_connected) {
        uint16_t data[2];
        data[0] = htons(KJ_RM_KALIVE_DATA_TYPE_SELECT_CNT);
        data[1] = ice->cnt_id;
        data[1] = htons(data[1]);
        size_t length = sizeof(data);
        ice->kalive.select_seq = kj_ice_kalive_renew_alive_seq(ice);
        kj_data_head *ask_data = kj_util_kalive_ask_data_with_seq(ice->kalive.select_seq, data, length);
        length = ask_data->length + kj_data_head_length;
        ask_data->length = htons(ask_data->length);
        kj_ice_send_data(ice, ask_data, length);
        free(ask_data);
    }
}
