//
//  kj_rome.c
//  ios_demo
//
//  Created by twenty on 2023/4/25.
//

#include "kj_rome.h"
#include "kj_ptp.h"
#include "kj_ice.h"
#include "kj_engine.h"
#include "kj_sdp.h"

typedef struct kj_road {
    kj_road_type type;  // 连接类型
    int priority;       // 该连接的优先等级，连接成功后进行标记，数值越小优先级越高
    kj_time build_time; // 开始建连的时间，用于计算建连耗时
    union cnttion {
        kj_ice *ice;
        kj_ptp *ptp;
    } cnttion;           // 连接对象指针
    KJ_NODE_TYPE(struct kj_road);
} kj_road;

// 媒体流通道号链表，媒体流发送端记录接收端正在请求的媒体流
typedef struct kj_stream_transming {
    uint16_t channel;
    int time;
    KJ_NODE_TYPE(struct kj_stream_transming);
} kj_stream_transming;

struct kj_rome_inner {
    uint16_t cnt_id_src;
    kj_rome_info info;
    struct kalive {
        int enable;
        int missed_answer;
        int chnl_sent_count;
        uint16_t chnl_sent[25];
        kj_stream_transming chnl_recv;
        kj_timer_task timer;
    } kalive;
    struct road {
        pthread_mutex_t mutex;
        kj_road node;
        int ice_building_count;
        int ptp_building_count;
        int select_cnt;
    } road;
    struct cnt_ret {
        int count;
        kj_rmcnt_info infos[4];
    } connection;
    kj_rome_server server;
};

#pragma mark - road管理函数
kj_road *kj_rome_create_road(void *cnttion, kj_road_type road_type) {
    kj_road *road = calloc(1, sizeof(kj_road));
    road->type = road_type;
    if (road_type == kj_road_ice) {
        road->cnttion.ice = cnttion;
    } else {
        road->cnttion.ptp = cnttion;
    }
    return road;
}
kj_road *kj_rome_find_road(kj_rome *rome, void *cnttion, int remove) {
    kj_road *road = NULL;
    kj_road *cursor = rome->inner->road.node.next;
    while (KJ_NODE_NOT_EQUAL(cursor, &rome->inner->road.node)) {
        if (cursor->cnttion.ice == cnttion || cursor->cnttion.ptp == cnttion) {
            road = cursor;
            if (remove) {
                KJ_NODE_REMOVE(road);
            }
            break;
        } else {
            cursor = cursor->next;
        }
    }
    return road;
}
void kj_rome_swap_road_to_current(kj_rome *rome, kj_road *road) {
    kj_road temp = *road;
    *road = rome->inner->road.node;
    road->next = temp.next;
    road->prev = temp.prev;
    rome->inner->road.node.type = temp.type;
    rome->inner->road.node.priority = temp.priority;
    rome->inner->road.node.build_time = temp.build_time;
    rome->inner->road.node.cnttion = temp.cnttion;
}

#pragma mark - 统一处理ice和ptp的state和recv data的callback
//void kj_rome_swap_cmcnt_info_to(kj_rome *rome, int index, int to_index) {
//    if (index < rome->inner->cnt_ret.count && to_index < rome->inner->cnt_ret.count) {
//        kj_rmcnt_info info = rome->inner->cnt_ret.infos[to_index];
//        rome->inner->cnt_ret.infos[to_index] = rome->inner->cnt_ret.infos[index];
//        rome->inner->cnt_ret.infos[index] = info;
//        rome->inner->cnt_ret.infos[to_index].index = to_index;
//        rome->inner->cnt_ret.infos[index].index = index;
//        if (to_index == 0) {
//            rome->cur_cnt_info = rome->inner->cnt_ret.infos[to_index];
//        }
//    }
//}
void kj_rome_swap_cmcnt_info_to_current(kj_rome *rome, int index) {
    // 转移当前连接信息到首位
    if (index < rome->inner->connection.count) {
        rome->cur_cnt_info = rome->inner->connection.infos[index];
        if (index > 0) {
            rome->cur_cnt_info.index = 0;
            rome->inner->connection.infos[0].index = index;
            rome->inner->connection.infos[index] = rome->inner->connection.infos[0];
            rome->inner->connection.infos[0] = rome->cur_cnt_info;
        }
    }
}
void kj_rome_state_callback(kj_rome *rome, void *cnttion, kj_road_type road_type, kj_cnt_state state, kj_code status_code) {
    kj_thread_lock(&rome->inner->road.mutex);
    kj_road *road = kj_rome_find_road(rome, cnttion, 1);
    kj_thread_unlock(&rome->inner->road.mutex);
    if (road == NULL && rome->inner->road.node.cnttion.ice != cnttion) {
        return;
    }
    // 建连成功和失败则可获取建连信息
    int ipv6 = 0, callback = 0;
    kj_cnt_type cnt_type = kj_cnt_type_none;
    kj_rmcnt_info *info = NULL;
    if (state == kj_cnt_state_connected || state == kj_cnt_state_connect_fail) {
        info = &rome->inner->connection.infos[rome->inner->connection.count];
        info->index = rome->inner->connection.count;
        rome->inner->connection.count++;
        info->elapsed_ms = kj_time_interval_between(road->build_time, kj_time_get_current());
        info->status = status_code;
        if (road->type == kj_road_ice) {
            info->ipv6 = road->cnttion.ice->ipv6;
            info->type = road->cnttion.ice->cnt_type;
            info->cnt_id = road->cnttion.ice->cnt_id;
        } else if (road->type == kj_road_ptp) {
            info->ipv6 = kj_ptp_is_ipv6(road->cnttion.ptp);
            info->type = kj_cnt_type_rm_ptp;
            info->cnt_id = road->cnttion.ptp->cnt_id;
        }
        ipv6 = info->ipv6;
        cnt_type = info->type;
    }
    if (state == kj_cnt_state_connected) {
        // 连接成功，标记连接优先级
        int is_ptp = cnt_type & (kj_cnt_type_lan | kj_cnt_type_ice_ptp | kj_cnt_type_rm_ptp);
        if (ipv6 && is_ptp) {
            road->priority = 1;
        } else if (is_ptp){
            road->priority = 2;
        } else if (ipv6) {
            road->priority = 3;
        } else {
            road->priority = 4;
        }
        
        kj_thread_lock(&rome->inner->road.mutex);
        // 切换连接通道
        if (rome->inner->road.node.cnttion.ice == NULL) {
            kj_rome_swap_road_to_current(rome, road);
            // 转移当前连接信息到首位
            kj_rome_swap_cmcnt_info_to_current(rome, info->index);
            free(road);
            rome->state = state;
            callback = 1;
        } else {
            if (road->priority < rome->inner->road.node.priority) {
                kj_rome_swap_road_to_current(rome, road);
                // 转移当前连接信息到首位
                kj_rome_swap_cmcnt_info_to_current(rome, info->index);
            }
            // 优先级高的放到环链前面
            kj_road *tail = rome->inner->road.node.prev;
            kj_road *cursor = rome->inner->road.node.next;
            while (KJ_NODE_NOT_EQUAL(cursor, &rome->inner->road.node)) {
                if (cursor->priority == 0 || road->priority < cursor->priority) {
                    tail = cursor->prev;
                    break;
                }
                cursor = cursor->next;
            }
            KJ_NODE_ADD_BEHIND(tail, road);
        }
        kj_thread_unlock(&rome->inner->road.mutex);
        
    } else if (state != kj_cnt_state_connecting) {
        if (road_type == kj_road_ice) {
            kj_ice *ice = cnttion;
            kj_ice_destroy(&ice);
        } else if (road_type == kj_road_ptp) {
            kj_ptp *ptp = cnttion;
            kj_ptp_destroy(&ptp);
        }
        free(road);
        
        kj_thread_lock(&rome->inner->road.mutex);
        // 连接失败且未有连接成功的，则将连接失败信息设为当前的连接信息，且多个时不把rome ptp设为第一个
        if (info && rome->inner->road.node.cnttion.ice == NULL) {
            if (info->index == 0 || info->type != kj_cnt_type_rm_ptp) {
                kj_rome_swap_cmcnt_info_to_current(rome, info->index);
            }
        }
        // 当前使用的连接失败后，更新当前连接状态码
        if (rome->inner->road.node.cnttion.ice == cnttion) {
            rome->inner->road.node.priority = 0;
            rome->inner->road.node.type = kj_road_none;
            rome->inner->road.node.cnttion.ice = NULL;
            rome->cur_cnt_info.status = status_code;
            rome->inner->connection.infos[0].status = status_code;
        }
        if (rome->inner->road.node.cnttion.ice == NULL && !KJ_NODE_HAS_NODE(rome->inner->road.node)) {
            // 当前无连接，且无待建连结果则本次连接失败为最终结果，回调上层
            rome->state = state;
            callback = 1;
        } else if (rome->inner->road.node.cnttion.ice == NULL) {
            // 当前无可用连接，则从备用连接中选取一个，该情况下针对原本有可用的连接而被中断的条件下进行切换
            kj_road *road = rome->inner->road.node.next;
            while (KJ_NODE_NOT_EQUAL(road, &rome->inner->road.node)) {
                if (road->priority > 0) {
                    kj_rome_swap_road_to_current(rome, road);
                    KJ_NODE_REMOVE_AND_FREE(road);
                    break;
                }
                road = road->next;
            }
        }
        kj_thread_unlock(&rome->inner->road.mutex);
    }
    
    kj_thread_lock(&rome->inner->road.mutex);
    if (rome->inner->road.ice_building_count == 0 && rome->inner->road.ptp_building_count > 0) {
        // 同时支持ice和ptp，ice已完成建连，建连成功且不为ptp，则启动rome ptp
        int abandon_ptp = 0;
        if (rome->state == kj_cnt_state_connected) {
            abandon_ptp = (rome->cur_cnt_info.type & (kj_cnt_type_lan | kj_cnt_type_ice_ptp | kj_cnt_type_rm_ptp));
        } else if (status_code == kj_code_ice_nego_no_endp_sdp) {
            // ice因超时无对端SDP则放弃rome ptp连接，避免造成旧版设备固件因连续收到两次SDP而崩溃
            abandon_ptp = 1;
        }
        kj_road *road = rome->inner->road.node.next;
        while (KJ_NODE_NOT_EQUAL(road, &rome->inner->road.node)) {
            kj_road *next = road->next;
            if (road->type == kj_road_ptp) {
                if (abandon_ptp) {
                    kj_ptp_destroy(&road->cnttion.ptp);
                    KJ_NODE_REMOVE_AND_FREE(road);
                } else {
                    road->build_time = kj_time_get_current();
                    kj_ptp_should_send_sdp_to_endpoint(road->cnttion.ptp);
                }
            }
            road = next;
        }
        if (abandon_ptp) {
            rome->inner->road.ptp_building_count = 0;
            // ICE已经全部完成建连，PTP也被全部销毁，如当前无连接则回调本次的建连结果为最终结果到上层
            if (rome->inner->road.node.cnttion.ice == NULL) {
                rome->state = state;
                callback = 1;
            }
        }
    }
    kj_thread_unlock(&rome->inner->road.mutex);
    
    // 回调所有连接的结果信息
    if (rome->inner->road.ice_building_count == 0 && rome->inner->road.ptp_building_count == 0) {
        rome->inner->road.ice_building_count = -1;
        rome->inner->road.ptp_building_count = -1;
        if (rome->callback.connection_info_cb) {
            kj_rmcnt_extra_info extra_info = {
                .local_ver = rome->inner->info.local.version,
                .endp_ver = rome->inner->info.remote.version,
                .local_nat = rome->inner->info.local.nat,
                .endp_nat = rome->inner->info.remote.nat
            };
            rome->callback.connection_info_cb(rome, rome->inner->connection.infos, rome->inner->connection.count, extra_info);
        }
        // client角色有多个连接标记发送选择连接心跳包
        if (KJ_NODE_HAS_NODE(rome->inner->road.node)) {
            rome->inner->road.select_cnt = rome->inner->info.local.role == kj_rm_role_client;
        }
    }
    if (callback && rome->callback.state_cb) {
        rome->callback.state_cb(rome, state, status_code);
    }
}
void kj_rome_recv_data_callback(kj_rome *rome, const void *data, size_t length) {
    rome->bytes_recv += length;
    // 心跳包数据不输出上层
    kj_data_head data_head = {};
    if (kj_util_is_rm_kalive_data(data, length, &data_head)) {
        if (data_head.length >= 4) {
            uint16_t *channel_data = (uint16_t *)(data + kj_data_head_length);
            *channel_data = ntohs(*channel_data);
            if (*channel_data == KJ_RM_KALIVE_DATA_TYPE_CHANNEL) {
                int output_channel = 0, output_count = 0;
                // 现有的channel先减一，确保三次心跳包都没有该channel时则移除
                kj_stream_transming *channel_cursor = rome->inner->kalive.chnl_recv.next;
                while (KJ_NODE_NOT_EQUAL(channel_cursor, &rome->inner->kalive.chnl_recv)) {
                    channel_cursor->time--;
                    channel_cursor = channel_cursor->next;
                }
                // 查找心跳包包含的channel，有则恢复time为3，没有则新增channel
                uint16_t recv_count = ntohs(*(++channel_data));
                for (uint16_t i = 0; i < recv_count; i++) {
                    channel_data++;
                    uint16_t channel = ntohs(*channel_data);
                    int found_channel = 0;
                    channel_cursor = rome->inner->kalive.chnl_recv.next;
                    while (KJ_NODE_NOT_EQUAL(channel_cursor, &rome->inner->kalive.chnl_recv)) {
                        if (channel_cursor->channel == channel) {
                            found_channel = 1;
                            channel_cursor->time = 3;
                            break;
                        } else {
                            channel_cursor = channel_cursor->next;
                        }
                    }
                    if (!found_channel) {
                        output_channel = 1;
                        kj_stream_transming *new_channel = calloc(1, sizeof(kj_stream_transming));
                        new_channel->time = 3;
                        new_channel->channel = channel;
                        kj_stream_transming *tail = rome->inner->kalive.chnl_recv.prev;
                        KJ_NODE_ADD_BEHIND(tail, new_channel);
                    }
                }
                // 移除三次心跳包均没有的channel
                int capacity = sizeof(rome->inner->kalive.chnl_sent) / 2;
                uint16_t channels[capacity];
                channel_cursor = rome->inner->kalive.chnl_recv.next;
                while (KJ_NODE_NOT_EQUAL(channel_cursor, &rome->inner->kalive.chnl_recv)) {
                    if (channel_cursor->time <= 0) {
                        output_channel = 1;
                        kj_stream_transming *finished = channel_cursor;
                        channel_cursor = channel_cursor->next;
                        KJ_NODE_REMOVE_AND_FREE(finished);
                    } else {
                        channels[output_count] = channel_cursor->channel;
                        output_count++;
                        channel_cursor = channel_cursor->next;
                    }
                }
                if (output_channel && rome->callback.streams_in_transmitting_cb) {
                    rome->callback.streams_in_transmitting_cb(rome, channels, output_count);
                }
            }
        }
    } else if (rome->callback.recv_data_cb) {
        rome->callback.recv_data_cb(rome, data, length);
    }
}

#pragma mark - ice callback
void kj_rome_ice_recv_data_callback(kj_ice *ice, const void *data, size_t length) {
    kj_rome *rome = kj_ice_get_user_data(ice);
    kj_rome_recv_data_callback(rome, data, length);
}
void kj_rome_ice_state_callback(kj_ice *ice, kj_cnt_state state, kj_code status_code) {
    kj_rome *rome = kj_ice_get_user_data(ice);
    if (state == kj_cnt_state_connected || state == kj_cnt_state_connect_fail) {
        rome->inner->road.ice_building_count--;
    }
    kj_rome_state_callback(rome, ice, kj_road_ice, state, status_code);
}
kj_code kj_rome_ice_sdp_info_callback(kj_ice *ice, const char *sdp) {
    kj_rome *rome = kj_ice_get_user_data(ice);
    kj_code code = kj_code_bypass_err;
    if (rome->callback.send_sdp_to_endpoint_cb) {
        code = rome->callback.send_sdp_to_endpoint_cb(rome, sdp, ice->ipv6);
    }
    return code;
}
void kj_rome_ice_being_selected_callback(kj_ice *ice) {
    kj_rome *rome = kj_ice_get_user_data(ice);
    rome->inner->road.select_cnt = 0;
    kj_thread_lock(&rome->inner->road.mutex);
    kj_road *road = rome->inner->road.node.next;
    while (KJ_NODE_NOT_EQUAL(road, &rome->inner->road.node)) {
        kj_road *next = road->next;
        if (road->cnttion.ice == ice) {
            kj_rome_swap_road_to_current(rome, road);
        }
        if (road->type == kj_road_ice) {
            kj_ice_destroy(&road->cnttion.ice);
        } else if (road->type == kj_road_ptp) {
            kj_ptp_destroy(&road->cnttion.ptp);
        }
        KJ_NODE_REMOVE_AND_FREE(road);
        road = next;
    }
    kj_thread_unlock(&rome->inner->road.mutex);
}

#pragma mark - ptp callback
void kj_rome_ptp_recv_data_callback(kj_ptp *ptp, const void *data, size_t length) {
    kj_rome *rome = kj_ptp_get_user_data(ptp);
    kj_rome_recv_data_callback(rome, data, length);
}
void kj_rome_ptp_state_callback(kj_ptp *ptp, kj_cnt_state state, kj_code status_code) {
    kj_rome *rome = kj_ptp_get_user_data(ptp);
    if (state == kj_cnt_state_connected || state == kj_cnt_state_connect_fail) {
        rome->inner->road.ptp_building_count--;
    }
    kj_rome_state_callback(rome, ptp, kj_road_ptp, state, status_code);
}
kj_code kj_rome_ptp_sdp_info_callback(kj_ptp *ptp, const char *sdp) {
    kj_rome *rome = kj_ptp_get_user_data(ptp);
    kj_code code = kj_code_bypass_err;
    if (rome->callback.send_sdp_to_endpoint_cb) {
        code = rome->callback.send_sdp_to_endpoint_cb(rome, sdp, kj_ptp_is_ipv6(ptp));
    }
    return code;
}
void kj_rome_ptp_being_selected_callback(kj_ptp *ptp) {
    kj_rome *rome = kj_ptp_get_user_data(ptp);
    rome->inner->road.select_cnt = 0;
    kj_thread_lock(&rome->inner->road.mutex);
    kj_road *road = rome->inner->road.node.next;
    while (KJ_NODE_NOT_EQUAL(road, &rome->inner->road.node)) {
        kj_road *next = road->next;
        if (road->cnttion.ptp == ptp) {
            kj_rome_swap_road_to_current(rome, road);
        }
        if (road->type == kj_road_ice) {
            kj_ice_destroy(&road->cnttion.ice);
        } else if (road->type == kj_road_ptp) {
            kj_ptp_destroy(&road->cnttion.ptp);
        }
        KJ_NODE_REMOVE_AND_FREE(road);
        road = next;
    }
    kj_thread_unlock(&rome->inner->road.mutex);
}

#pragma mark - 选择通道心跳
void kj_rome_select_cnt_to_using(kj_rome *rome) {
    if (rome->inner->road.select_cnt > 0 && rome->inner->road.select_cnt < 5) {
        rome->inner->road.select_cnt++;
        // 发送选择连接心跳包
        if (rome->inner->road.node.type == kj_road_ice) {
            kj_ice_select_to_using(rome->inner->road.node.cnttion.ice);
        } else if (rome->inner->road.node.type == kj_road_ptp) {
            kj_ptp_select_to_using(rome->inner->road.node.cnttion.ptp);
        }
    } else {
        rome->inner->road.select_cnt = 0;
    }
}
#pragma mark - 定时器心跳保活回调
void kj_rome_heart_beart_timer_task_for_second(const kj_timer *timer, kj_timer_task *task) {
    kj_rome *rome = task->user_data;
    if (rome->state == kj_cnt_state_connected) {
        // 心跳包需要加上当前传输中的媒体的channel，格式:type|channel个数|channel数组，都为2字节，网络字节序传输
        if (kj_thread_try_lock(&rome->inner->road.mutex)) {
            uint16_t channel_data[rome->inner->kalive.chnl_sent_count + 2];
            channel_data[0] = KJ_RM_KALIVE_DATA_TYPE_CHANNEL;
            channel_data[1] = rome->inner->kalive.chnl_sent_count;
            channel_data[0] = htons(channel_data[0]);
            channel_data[1] = htons(channel_data[1]);
            for (int i = 0; i < rome->inner->kalive.chnl_sent_count; i++) {
                channel_data[i + 2] = rome->inner->kalive.chnl_sent[i];
            }
            int answer_missed = 0;
            uint16_t length = sizeof(channel_data);
            if (rome->inner->road.node.type == kj_road_ice) {
                kj_ice_update_kalive_with_data(rome->inner->road.node.cnttion.ice, channel_data, length, &answer_missed);
            } else if (rome->inner->road.node.type == kj_road_ptp) {
                kj_ptp_update_kalive_with_data(rome->inner->road.node.cnttion.ptp, channel_data, length, &answer_missed);
            }
            rome->inner->kalive.missed_answer = answer_missed;
            kj_rome_select_cnt_to_using(rome);
            kj_thread_unlock(&rome->inner->road.mutex);
        }
    }
}

#pragma mark - 对象管理
kj_rome *kj_rome_create(const char *client_id, const char *server_id, kj_rm_role role, void *user_data) {
    kj_rome *rome = calloc(1, sizeof(kj_rome) + sizeof(kj_rome_inner));
    rome->user_data = user_data;
    rome->inner = (kj_rome_inner *)(rome + 1);
    rome->inner->info.local.role = role;
    rome->inner->cnt_id_src = 40000 + kj_random(9000);
    // 设置本端的版本、支持的连接类型、记录的NAT端口特性和支持的IPv版本
    rome->inner->info.local.version = _kj_rm_cfg.version;
    rome->inner->info.local.road_support = _kj_rm_cfg.road_support;
    rome->inner->info.local.nat = _kj_rm_cfg.local_nat;
    rome->inner->info.local.ipv_support = _kj_rm_cfg.ipv_support;
    // 配置默认的打洞算法
    rome->inner->info.local.algorithm.type = 1;
    rome->inner->info.local.algorithm.ports_count = _kj_rm_cfg.ptp_ports_count;
    rome->inner->info.local.algorithm.per_count = _kj_rm_cfg.ptp_per_count;
    rome->inner->info.local.algorithm.per_interval_ms = _kj_rm_cfg.ptp_interval_ms;
    rome->inner->info.remote.algorithm = rome->inner->info.local.algorithm;
    
    kj_thread_init_mutex(&rome->inner->road.mutex, 1);
    KJ_NODE_INIT(rome->inner->kalive.chnl_recv);
    KJ_NODE_INIT(rome->inner->road.node);
    if (client_id) {
        rome->client_id = strdup(client_id);
    }
    if (server_id) {
        rome->server_id = strdup(server_id);
    }
    return rome;
}
void kj_rome_destroy(kj_rome **rome) {
    kj_rome *temp = *rome;
    *rome = NULL;
    if (temp) {
        // 先取消定时任务，避免销毁后执行导致野指针
        kj_timer_cancel_task(rm_engine()->timer, temp->inner->kalive.timer);
        kj_rome_close(temp, 0);
        kj_util_free_rome_server_info(&temp->inner->server);
        pthread_mutex_destroy(&temp->inner->road.mutex);
        free(temp->client_id);
        free(temp->server_id);
        free(temp);
    }
}
void kj_rome_release_after_all_rome_destroy(void) {
    kj_engine_release();
}

#pragma mark - 连接管理
void kj_rome_get_sdp_with_server(kj_rome *rome, const kj_rome_server *server) {
    if (rome && server) {
        // 初始化连接状态、建连个数和建连结果数
        rome->state = kj_cnt_state_connecting;
        rome->inner->road.ice_building_count = 0;
        rome->inner->road.ptp_building_count = 0;
        rome->inner->connection.count = 0;
        rome->inner->road.select_cnt = 0;
        // 服务stun、turn服务信息
        kj_util_free_rome_server_info(&rome->inner->server);
        kj_util_copy_rome_server_info(&rome->inner->server, server);
        // 支持rome ptp则创建ptp待ice建连完成后结果没有ptp而启动rome ptp，如果本次没有ice则立即启动，只针对IPv4
        kj_ptp *ptp = NULL;
        if ((rome->inner->info.local.road_support & kj_road_ptp) && kj_util_rome_server_has_ipv4_stun(&rome->inner->server)) {
            rome->inner->road.ptp_building_count++;
            kj_ptp_cb callback = {
                .recv_data_cb = kj_rome_ptp_recv_data_callback,
                .sdp_info_cb = kj_rome_ptp_sdp_info_callback,
                .state_cb = kj_rome_ptp_state_callback,
                .being_selected_cb = kj_rome_ptp_being_selected_callback
            };
            ptp = kj_ptp_create(&rome->inner->info, callback, rome);
            ptp->cnt_id = ++rome->inner->cnt_id_src;
            kj_road *road = kj_rome_create_road(ptp, kj_road_ptp);
            
            kj_thread_lock(&rome->inner->road.mutex);
            kj_road *tail = rome->inner->road.node.prev;
            KJ_NODE_ADD_BEHIND(tail, road);
            kj_thread_unlock(&rome->inner->road.mutex);
            // 获取外网地址
            road->build_time = kj_time_get_current();
            kj_ptp_get_reflexive_addrs_info(road->cnttion.ptp, &rome->inner->server);
        }
        // 支持ICE则根据stun和turn服务创建IPv4或IPv6的ICE
        if (rome->inner->info.local.road_support & kj_road_ice) {
            kj_ice_cb callback = {
                .state_cb = kj_rome_ice_state_callback,
                .recv_data_cb = kj_rome_ice_recv_data_callback,
                .sdp_info_cb = kj_rome_ice_sdp_info_callback,
                .being_selected_cb = kj_rome_ice_being_selected_callback
            };
            // 创建IPv6的ICE
            if (rome->inner->server.ipv6_support && kj_util_rome_server_has_ipv6_server_and_local_support(&rome->inner->server)) {
                rome->inner->road.ice_building_count++;

                kj_ice *ice = kj_ice_create(&rome->inner->info, rome, callback);
                ice->cnt_id = ++rome->inner->cnt_id_src;
                kj_road *road = kj_rome_create_road(ice, kj_road_ice);

                kj_thread_lock(&rome->inner->road.mutex);
                kj_road *tail = rome->inner->road.node.prev;
                KJ_NODE_ADD_BEHIND(tail, road);
                kj_thread_unlock(&rome->inner->road.mutex);

                road->build_time = kj_time_get_current();
                kj_ice_get_sdp(road->cnttion.ice, 1, &rome->inner->server);
            }
            // 在发送SDP信息前更新本端支持的IPv版本
            rome->inner->info.local.ipv_support = _kj_rm_cfg.ipv_support;
            // 创建IPv4的ICE
            if (kj_util_rome_server_has_ipv4_server(&rome->inner->server)) {
                rome->inner->road.ice_building_count++;
                
                kj_ice *ice = kj_ice_create(&rome->inner->info, rome, callback);
                ice->cnt_id = ++rome->inner->cnt_id_src;
                kj_road *road = kj_rome_create_road(ice, kj_road_ice);
                
                kj_thread_lock(&rome->inner->road.mutex);
                kj_road *tail = rome->inner->road.node.prev;
                KJ_NODE_ADD_BEHIND(tail, road);
                kj_thread_unlock(&rome->inner->road.mutex);
                
                road->build_time = kj_time_get_current();
                kj_ice_get_sdp(road->cnttion.ice, 0, &rome->inner->server);
            }
        }
        // 没有发起连接则报stun、turn服务信息缺失
        if (rome->inner->road.ice_building_count == 0 && rome->inner->road.ptp_building_count == 0) {
            rome->state = kj_cnt_state_connect_fail;
            if (rome->callback.state_cb) {
                rome->callback.state_cb(rome, rome->state, kj_code_no_stun_turn_server);
            }
        } else if (rome->inner->road.ice_building_count == 0 && rome->inner->road.ptp_building_count) {
            // 没有ice则立即启动rome ptp
            kj_ptp_should_send_sdp_to_endpoint(ptp);
        }
    }
}
void kj_rome_connect_endpoint(kj_rome *rome, const char *sdp, int ipv6) {
    if (rome && sdp) {
        // 解析sdp头并更新到对端信息
        kj_sdp_head head = kj_sdp_parse_head(sdp);
        rome->inner->info.remote.version = head.version;
        rome->inner->info.remote.role = head.role;
        rome->inner->info.remote.road_support = head.road_support;
        rome->inner->info.remote.nat = head.nat;
        rome->inner->info.remote.ipv_support = head.ipv_support;
        // server角色同步使用对端打洞算法
        if (rome->inner->info.local.role == kj_rm_role_server) {
            rome->inner->info.remote.algorithm = head.algorithm;
        }
        // 根据sdp head匹配连接，并销毁对端不支持的连接
        int match = 0;
        kj_ice *unsupport_ice1 = NULL, *unsupport_ice2 = NULL;
        kj_ptp *unsupport_ptp = NULL;
        kj_thread_lock(&rome->inner->road.mutex);
        kj_road *road = rome->inner->road.node.next;
        while (KJ_NODE_NOT_EQUAL(road, &rome->inner->road.node)) {
            kj_road *next = road->next;
            if (road->type == kj_road_ice) {
                if (road->type & head.road_support) {
                    if (road->cnttion.ice->ipv6 == head.type) {
                        kj_ice_start_negotiation(road->cnttion.ice, sdp);
                        if (rome->inner->info.local.role == kj_rm_role_server) {
                            road->cnttion.ice->cnt_id = head.cnt_id;
                        }
                        match = 1;
                    } else if (road->cnttion.ice->ipv6 == kj_sdp_ice_ipv6 && head.ipv_support != kj_ipv_unknow && !(head.ipv_support & kj_ipv6_support)) {
                        // 在server端支持IPv6的情况下，client端发来带有不支持IPv6信息的SDP信息时，server端即可得知本次不支持IPv6建连
                        if (unsupport_ice1 == NULL) {
                            unsupport_ice1 = road->cnttion.ice;
                        } else {
                            unsupport_ice2 = road->cnttion.ice;
                        }
                    }
                } else {
                    if (unsupport_ice1 == NULL) {
                        unsupport_ice1 = road->cnttion.ice;
                    } else {
                        unsupport_ice2 = road->cnttion.ice;
                    }
                }
            } else if (road->type == kj_road_ptp) {
                if (road->type & head.road_support) {
                    if (head.type == kj_sdp_ptp_ipv4) {
                        kj_ptp_connect(road->cnttion.ptp, sdp);
                        if (rome->inner->info.local.role == kj_rm_role_server) {
                            road->cnttion.ptp->cnt_id = head.cnt_id;
                        }
                        match = 1;
                        break;
                    }
                } else {
                    unsupport_ptp = road->cnttion.ptp;
                }
            }
            road = next;
        }
        kj_thread_unlock(&rome->inner->road.mutex);
        // 没有找到匹配的连接，进行本端不支持的处理
        if (!match) {
            if (head.type == kj_sdp_unsupport) {
                // 对端反馈不支持的连接，则本端销毁对应的连接
                kj_thread_lock(&rome->inner->road.mutex);
                kj_road *road = rome->inner->road.node.next;
                while (KJ_NODE_NOT_EQUAL(road, &rome->inner->road.node)) {
                    kj_road *next = road->next;
                    if (road->type == kj_road_ice) {
                        if (road->cnttion.ice->cnt_id == head.cnt_id) {
                            if (unsupport_ice1 == NULL) {
                                unsupport_ice1 = road->cnttion.ice;
                            } else {
                                unsupport_ice2 = road->cnttion.ice;
                            }
                            break;
                        }
                    } else if (road->type == kj_road_ptp) {
                        if (road->cnttion.ptp->cnt_id == head.cnt_id) {
                            unsupport_ptp = road->cnttion.ptp;
                            break;
                        }
                    }
                    road = next;
                }
                kj_thread_unlock(&rome->inner->road.mutex);
            } else if (head.version > 0 && rome->callback.send_sdp_to_endpoint_cb) {
                // 本次没有找到匹配的连接，则说明本端不支持对端的连接，向对端反馈本端支持的连接，使对端进行切换，对端版本必须在1及以上
                kj_sdp_head resp_head = {
                    .version = rome->inner->info.local.version,
                    .role = rome->inner->info.local.role,
                    .cnt_id = head.cnt_id,
                    .nat = rome->inner->info.local.nat,
                    .ipv_support = rome->inner->info.local.ipv_support,
                    .road_support = rome->inner->info.local.road_support,
                    .type = kj_sdp_unsupport,
                    .algorithm = rome->inner->info.local.algorithm,
                };
                char unsupport_sdp[KJ_SDP_INFO_MAX_LENGTH] = {};
                kj_sdp_encode_head(unsupport_sdp, KJ_SDP_INFO_MAX_LENGTH, resp_head);
                rome->callback.send_sdp_to_endpoint_cb(rome, unsupport_sdp, 0);
            }
        }
        // 销毁本端不支持的连接
        if (unsupport_ice1) {
            kj_rome_ice_state_callback(unsupport_ice1, kj_cnt_state_connect_fail, kj_code_unsupport_road_type);
        }
        if (unsupport_ice2) {
            kj_rome_ice_state_callback(unsupport_ice2, kj_cnt_state_connect_fail, kj_code_unsupport_road_type);
        }
        if (unsupport_ptp) {
            kj_rome_ptp_state_callback(unsupport_ptp, kj_cnt_state_connect_fail, kj_code_unsupport_road_type);
        }
    }
}
void kj_rome_close(kj_rome *rome, int callback) {
    if (rome) {
        rome->inner->kalive.chnl_sent_count = 0;
        rome->inner->kalive.missed_answer = 0;
        rome->bytes_sent = 0;
        rome->bytes_recv = 0;
        
        kj_thread_lock(&rome->inner->road.mutex);
        // 销毁当前使用中的连接
        if (rome->inner->road.node.type == kj_road_ice) {
            kj_ice_destroy(&rome->inner->road.node.cnttion.ice);
        } else if (rome->inner->road.node.type == kj_road_ptp) {
            kj_ptp_destroy(&rome->inner->road.node.cnttion.ptp);
        }
        rome->inner->road.node.type = kj_road_none;
        rome->inner->road.node.priority = 0;
        // 销毁建连中或备用的连接
        kj_road *road = rome->inner->road.node.next;
        while (KJ_NODE_NOT_EQUAL(road, &rome->inner->road.node)) {
            kj_road *next = road->next;
            if (road->type == kj_road_ice) {
                kj_ice_destroy(&road->cnttion.ice);
            } else if (road->type == kj_road_ptp) {
                kj_ptp_destroy(&road->cnttion.ptp);
            }
            KJ_NODE_REMOVE_AND_FREE(road);
            road = next;
        }
        kj_thread_unlock(&rome->inner->road.mutex);
        
        // 销毁缓存的媒体流channel号
        kj_stream_transming *channel_cursor = rome->inner->kalive.chnl_recv.next;
        while (KJ_NODE_NOT_EQUAL(channel_cursor, &rome->inner->kalive.chnl_recv)) {
            kj_stream_transming *finished = channel_cursor;
            channel_cursor = channel_cursor->next;
            KJ_NODE_REMOVE_AND_FREE(finished);
        }
    }
}
kj_send_status kj_rome_send_data(kj_rome *rome, const void *data, size_t length) {
    kj_send_status status = kj_send_status_invalid;
    if (rome && data) {
        kj_thread_lock(&rome->inner->road.mutex);
        if (rome->inner->road.node.type == kj_road_ice) {
            rome->bytes_sent += length;
            status = kj_ice_send_data(rome->inner->road.node.cnttion.ice, data, length);
        } else if (rome->inner->road.node.type == kj_road_ptp) {
            rome->bytes_sent += length;
            status = kj_ptp_send_data(rome->inner->road.node.cnttion.ptp, data, length);
        }
        kj_thread_unlock(&rome->inner->road.mutex);
    }
    return status;
}

#pragma mark - 属性配置
void kj_rome_enable_internal_keepalive(kj_rome *rome, int enable) {
    if (rome) {
        rome->inner->kalive.enable = enable;
        kj_timer_cancel_task(rm_engine()->timer, rome->inner->kalive.timer);
        if (enable) {
            kj_timer_init_task(&rome->inner->kalive.timer, rome, 1000, 1, kj_rome_heart_beart_timer_task_for_second);
            kj_timer_schedule_task(rm_engine()->timer, rome->inner->kalive.timer);
        }
    }
}
void kj_rome_set_callback(kj_rome *rome, kj_rome_cb callback) {
    if (rome) {
        rome->callback = callback;
    }
}
void kj_rome_set_road_support(kj_rome *rome, kj_road_type road_support) {
    if (rome) {
        rome->inner->info.local.road_support = road_support;
    }
}
void kj_rome_set_ptp_algorithm(kj_rome *rome, kj_ptp_alg algorithm) {
    if (rome) {
        uint16_t type = algorithm.type;
        if (type < 10) {
            // 算法个位数则两端相同算法
            rome->inner->info.local.algorithm.type = type;
        } else if (type < 100) {
            // 两位数十位为client，个位为server
            rome->inner->info.local.algorithm.type = type / 10;
            type = type % 10;
        } else if (type < 10000) {
            // 三位四位数，个十两位为server，以上为client
            rome->inner->info.local.algorithm.type = type / 100;
            type = type % 100;
        } else {
            // 超出为关闭
            rome->inner->info.local.algorithm.type = 0;
            type = 0;
        }
        if (algorithm.ports_count > 0) {
            rome->inner->info.local.algorithm.ports_count = algorithm.ports_count;
        }
        if (algorithm.per_count > 0) {
            rome->inner->info.local.algorithm.per_count = algorithm.per_count;
        }
        if (algorithm.per_interval_ms > 0) {
            rome->inner->info.local.algorithm.per_interval_ms = algorithm.per_interval_ms;
        }
        // client角色配置对端相同的算法参数，和可能不同的算法类型
        if (rome->inner->info.local.role == kj_rm_role_client) {
            rome->inner->info.remote.algorithm = rome->inner->info.local.algorithm;
            rome->inner->info.remote.algorithm.type = type;
        }
    }
}
int kj_rome_is_missed_keepalive_answer_for_now(kj_rome *rome) {
    int missed = 0;
    if (rome && rome->inner->kalive.enable) {
        missed = rome->inner->kalive.missed_answer;
    }
    return missed;
}
void kj_rome_set_stream_channels_in_transmitting(kj_rome *rome, uint16_t stream_channels[], int channel_count) {
    if (rome && stream_channels) {
        int capacity = sizeof(rome->inner->kalive.chnl_sent) / 2;
        if (channel_count > capacity) {
            channel_count = capacity;
        }
        // 转为网络字节序存储
        int count = 0;
        for (; count < channel_count; count++) {
            rome->inner->kalive.chnl_sent[count] = htons(stream_channels[count]);
        }
        rome->inner->kalive.chnl_sent_count = count;
    }
}
int kj_rome_get_current_cnt_rtt(kj_rome *rome) {
    int rtt = 0;
    if (rome && rome->state == kj_cnt_state_connected) {
        kj_thread_lock(&rome->inner->road.mutex);
        if (rome->inner->road.node.type == kj_road_ice) {
            rtt = rome->inner->road.node.cnttion.ice->kalive.rtt;
        } else if (rome->inner->road.node.type == kj_road_ptp) {
            rtt = rome->inner->road.node.cnttion.ptp->kalive.rtt;
        }
        kj_thread_unlock(&rome->inner->road.mutex);
    }
    return rtt;
}
void kj_rome_update_current_cnt_rtt(kj_rome *rome, int rtt) {
    if (rome && rome->state == kj_cnt_state_connected && rtt > 0) {
        kj_thread_lock(&rome->inner->road.mutex);
        if (rome->inner->road.node.type == kj_road_ice) {
            rome->inner->road.node.cnttion.ice->kalive.rtt = rome->inner->road.node.cnttion.ice->kalive.rtt * 0.8 + rtt * 0.2;
        } else if (rome->inner->road.node.type == kj_road_ptp) {
            rome->inner->road.node.cnttion.ptp->kalive.rtt = rome->inner->road.node.cnttion.ptp->kalive.rtt * 0.8 + rtt * 0.2;
        }
        kj_thread_unlock(&rome->inner->road.mutex);
    }
}
int kj_rome_get_ipv4_nat_port_range(kj_rome *rome) {
    int range = 0;
    if (rome) {
        range = rome->inner->info.local.nat;
    }
    return range;
}

#pragma mark - 属性获取
kj_rome_info *kj_rome_get_info(kj_rome *rome) {
    return rome ? &rome->inner->info : NULL;
}
