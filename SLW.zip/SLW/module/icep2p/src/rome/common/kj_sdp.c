//
//  kj_sdp.c
//  P2PLib
//
//  Created by twenty on 2023/6/14.
//

#include "kj_sdp.h"

#pragma mark - 公共信息解析
int kj_sdp_get_a_line_from_sdp(char *linebuf, const char *sdp, size_t *startPos) {
    char *p_src = (char *)(sdp + *startPos);
    int line_len = 0;
    while (*p_src != '\0') {
        *startPos += 1;
        if (*p_src == '\r' || *p_src == '\n' || (line_len == 0 && isspace(*p_src))) {
            if (line_len) {
                break;
            } else {
                p_src++;
            }
        } else {
            *linebuf = *p_src;
            linebuf++;
            p_src++;
            line_len++;
        }
    }
    *linebuf = '\0';
    return line_len;
}

#pragma mark - 解析SDP头部信息
kj_sdp_head kj_sdp_parse_head(const char *sdp) {
    kj_sdp_head head = {};
    if (sdp) {
        char linebuf[200] = {};
        size_t sdp_len = strlen(sdp);
        size_t position = 0;
        int line_len = 0, count = 0;
        while (position < sdp_len && count < 5) {
            line_len = kj_sdp_get_a_line_from_sdp(linebuf, sdp, &position);
            if (line_len > 0) {
                switch (linebuf[0]) {
                    case 'v': { // 版本信息
                        sscanf(linebuf + 2, "%d", &head.version);
                        count++;
                    } break;
                    case 'o': { // 连接ID、角色、NAT端口特性值
                        char cnt_id[40] = {}, nat[10] = {};
                        sscanf(linebuf + 2, "%s %hu %d %s %d ipv %d", cnt_id, &head.cnt_id, &head.role, nat, &head.nat, &head.ipv_support);
                        if (strcmp(cnt_id, "cnt-id")) {
                            head.cnt_id = 0;
                            head.role = 0;
                        }
                        if (strcmp(nat, "nat")) {
                            head.nat = 0;
                        }
                        count++;
                    } break;
                    case 's': { // 支持的连接类型
                        char first[20] = {}, second[20] = {};
                        sscanf(linebuf + 2, "%s %s", first, second);
                        if (strcmp(first, KJ_SDP_S_ICE) == 0 || strcmp(second, KJ_SDP_S_ICE) == 0) {
                            head.road_support |= kj_road_ice;
                        }
                        if (strcmp(first, KJ_SDP_S_PTP) == 0 || strcmp(second, KJ_SDP_S_PTP) == 0) {
                            head.road_support |= kj_road_ptp;
                        }
                        count++;
                    } break;
                    case 't': { // SDP信息类型
                        sscanf(linebuf + 2, "%d", &head.type);
                        count++;
                    } break;
                    case 'p': { // 穿透算法和参数
                        sscanf(linebuf + 2, "method %hu ports %hu per %hu interval %f", &head.algorithm.type, &head.algorithm.ports_count, &head.algorithm.per_count, &head.algorithm.per_interval_ms);
                        count++;
                    } break;
                    default:
                        break;
                }
            }
        }
    }
    return head;
}
int kj_sdp_encode_head(char *sdp, size_t sdp_len, kj_sdp_head head) {
    int length = 0;
    if (sdp && sdp_len) {
        // s字段的内容必须按照ice ptp的顺序填充，日后增加其他的必须在ice ptp的后面增加，以使解析正确
        char road_support[50] = {};
        int printed = 0;
        if (head.road_support & kj_road_ice) {
            printed = snprintf(road_support, 50, "%s", KJ_SDP_S_ICE);
        }
        if (head.road_support & kj_road_ptp) {
            if (printed) {
                length = snprintf(road_support + printed, 50 - printed, " %s", KJ_SDP_S_PTP);
            } else {
                length = snprintf(road_support, 50, "%s", KJ_SDP_S_PTP);
            }
            printed += length;
        }
        length = snprintf(sdp, sdp_len, "v=%d\no=cnt-id %hu %d nat %d ipv %d\ns=%s\nt=%d\n",head.version,head.cnt_id,head.role,head.nat,head.ipv_support,road_support,head.type);
        if (head.road_support & kj_road_ptp) {
            sdp += length;
            sdp_len -= length;
            // 穿透算法和穿透包个数
            printed = snprintf(sdp, sdp_len, "p=method %hu ports %hu per %hu interval %.03f\n", head.algorithm.type, head.algorithm.ports_count, head.algorithm.per_count, head.algorithm.per_interval_ms);
            length += printed;
        }
    }
    return length;
}

#pragma mark - ICE SDP信息解析和编码
kj_code kj_sdp_parse_for_ice(kj_ice *ice, const char *sdp) {
    kj_code status = kj_code_success;
    bzero(&ice->endp_cands, sizeof(ice->endp_cands));
    unsigned media_cnt = 0;
    unsigned comp0_port = 0;
    char linebuf[200] = {};
    char comp0_addr[80] = {};

    size_t sdp_len = strlen(sdp);
    size_t position = 0;
    int line_len = 0;
    while (position < sdp_len) {
        line_len = kj_sdp_get_a_line_from_sdp(linebuf, sdp, &position);
        switch (linebuf[0]) {
            case 'm': {
                // 只需要一个
                if (++media_cnt < 2) {
                    char media[32], portstr[32];
                    int cnt = sscanf(linebuf + 2, "%s %s RTP/", media, portstr);
                    if (cnt != 2) {
                        goto on_error;
                    }
                    comp0_port = atoi(portstr);
                }
            } break;
            case 'c': {
                char c[32], net[32], ip[80];
                int cnt = sscanf(linebuf + 2, "%s %s %s", c, net, ip);
                if (cnt != 3) {
//                    PJ_LOG(1, (THIS_FILE, "Error parsing connection line"));
                    goto on_error;
                }
                strcpy(comp0_addr, ip);
            } break;
            case 'a': {
                char *attr = strtok(linebuf + 2, ": \t\r\n");
                if (strcmp(attr, "ice-ufrag") == 0) {
                    strcpy(ice->endp_cands.ufrag, attr + strlen(attr) + 1);
                } else if (strcmp(attr, "ice-pwd") == 0) {
                    strcpy(ice->endp_cands.pwd, attr + strlen(attr) + 1);
                } else if (strcmp(attr, "candidate") == 0) {
                    char *sdpcand = attr + strlen(attr) + 1;
                    char transport[12], ipaddr[80], type[32];
                    int comp_id, prio, port;
                    pj_ice_sess_cand *cand;
                    int cnt = sscanf(sdpcand, "%s %d %s %d %s %d typ %s",
                                     ice->endp_cands.foundation[ice->endp_cands.cand_cnt],
                                     &comp_id,
                                     transport,
                                     &prio,
                                     ipaddr,
                                     &port,
                                     type);
                    if (cnt != 7) {
//                        PJ_LOG(1, (THIS_FILE, "error: Invalid ICE candidate line"));
                        goto on_error;
                    }

                    cand = &ice->endp_cands.cand[ice->endp_cands.cand_cnt];
                    if (strcmp(type, "host") == 0)
                        cand->type = PJ_ICE_CAND_TYPE_HOST;
                    else if (strcmp(type, "srflx") == 0)
                        cand->type = PJ_ICE_CAND_TYPE_SRFLX;
                    else if (strcmp(type, "relay") == 0)
                        cand->type = PJ_ICE_CAND_TYPE_RELAYED;
                    else {
//                        PJ_LOG(1, (THIS_FILE, "Error: invalid candidate type '%s'", type));
                        goto on_error;
                    }
                    cand->comp_id = (pj_uint8_t)comp_id;
                    cand->prio = prio;
                    cand->foundation = pj_str(ice->endp_cands.foundation[ice->endp_cands.cand_cnt]);
                    
                    int af = strchr(ipaddr, ':') ? pj_AF_INET6() : pj_AF_INET();
                    pj_str_t tmpaddr = pj_str(ipaddr);
                    pj_status_t status = pj_sockaddr_init(af, &cand->addr, &tmpaddr, (pj_uint16_t)port);
                    if (status != PJ_SUCCESS) {
//                        PJ_LOG(1, (THIS_FILE, "Error: invalid IP address '%s'", ipaddr));
                        goto on_error;
                    }

                    ice->endp_cands.cand_cnt++;

                    if (cand->comp_id > ice->endp_cands.comp_cnt) {
                        ice->endp_cands.comp_cnt = cand->comp_id;
                    }
                }
            } break;
        }
    }

    if (ice->endp_cands.cand_cnt == 0 ||
        ice->endp_cands.ufrag[0] == 0 ||
        ice->endp_cands.pwd[0] == 0 ||
        ice->endp_cands.comp_cnt == 0) {
//        PJ_LOG(1, (THIS_FILE, "Error: not enough info"));
        goto on_error;
    }

    if (comp0_port == 0 || comp0_addr[0] == '\0') {
//        PJ_LOG(1, (THIS_FILE, "Error: default address for component 0 not found"));
        goto on_error;
    } else {
        int af = strchr(comp0_addr, ':') ? pj_AF_INET6() : pj_AF_INET();
        pj_str_t tmp_addr = pj_str(comp0_addr);
        pj_status_t status = pj_sockaddr_init(af, &ice->endp_cands.def_addr[0], &tmp_addr, (pj_uint16_t)comp0_port);
        if (status != PJ_SUCCESS) {
//            PJ_LOG(1, (THIS_FILE, "Invalid IP address in c= line"));
            goto on_error;
        }
    }
//    PJ_LOG(3, (THIS_FILE, "Done, %d remote candidate(s) added", ice->remote_sdp.cand_cnt));
    return status;

    on_error:
    status = kj_code_ice_endp_sdp_err;
    bzero(&ice->endp_cands, sizeof(ice->endp_cands));
    return status;
}
int kj_sdp_encode_ice_candidate(char buffer[], unsigned maxlen, const pj_ice_sess_cand *cand) {
    char ipaddr[PJ_INET6_ADDRSTRLEN];
    char *cursor = buffer;

    int printed = snprintf(cursor, maxlen, "a=candidate:%.*s %u UDP %u %s %u typ %s\n",
                           (int)cand->foundation.slen, cand->foundation.ptr,
                           (unsigned)cand->comp_id, cand->prio,
                           pj_sockaddr_print(&cand->addr, ipaddr, sizeof(ipaddr), 0),
                           (unsigned)pj_sockaddr_get_port(&cand->addr), pj_ice_get_cand_type_name(cand->type));
    cursor += printed;
    *cursor = '\0';
    return printed;
}
int kj_sdp_encode_ice_sdp(kj_ice *ice, char *sdp, size_t sdp_len) {
    char *cursor = sdp;
    size_t left_len = sdp_len;

    /* Write "dummy" SDP v=, o=, s=, and t= lines */
    kj_sdp_head head = {
        .version = ice->info->local.version,
        .role = ice->info->local.role,
        .cnt_id = ice->cnt_id,
        .nat = ice->info->local.nat,
        .ipv_support = ice->info->local.ipv_support,
        .road_support = ice->info->local.road_support,
        .type = ice->ipv6,
        .algorithm = ice->info->local.algorithm
    };
    // 角色为client则指定对端的打洞算法
    if (ice->info->local.role == kj_rm_role_client) {
        head.algorithm = ice->info->remote.algorithm;
    }
    int printed = kj_sdp_encode_head(cursor, left_len, head);
    cursor += printed;
    left_len -= printed;

    /* Get ufrag and pwd from current session */
    pj_str_t local_ufrag, local_pwd;
    pj_status_t status;
    pj_ice_strans_get_ufrag_pwd(ice->ice.strans, &local_ufrag, &local_pwd, NULL, NULL);

    /* Write the a=ice-ufrag and a=ice-pwd attributes */
    printed = snprintf(cursor, left_len, "a=ice-ufrag:%.*s\na=ice-pwd:%.*s\n",
                       (int)local_ufrag.slen, local_ufrag.ptr,
                       (int)local_pwd.slen, local_pwd.ptr);
    cursor += printed;
    left_len -= printed;

    /* Write each component */
    for (int comp = 0; comp < ice->ice.comp_cnt; ++comp) {
        pj_ice_sess_cand cand[PJ_ICE_ST_MAX_CAND];
        char ipaddr[PJ_INET6_ADDRSTRLEN];
        
        /* Get default candidate for the component */
        status = pj_ice_strans_get_def_cand(ice->ice.strans, comp + 1, &cand[0]);
        if (status != PJ_SUCCESS)
            return -status;
        
        /* Write the default address */
        if (comp == 0) {
            /* For component 1, default address is in m= and c= lines */
            printed = snprintf(cursor, left_len, "m=audio %d RTP/AVP 0\n" "c=IN IP4 %s\n",
                               (int)pj_sockaddr_get_port(&cand[0].addr),
                               pj_sockaddr_print(&cand[0].addr, ipaddr, sizeof(ipaddr), 0));
        } else if (comp == 1) {
            /* For component 2, default address is in a=rtcp line */
            printed = snprintf(cursor, left_len, "a=rtcp:%d IN IP4 %s\n",
                               (int)pj_sockaddr_get_port(&cand[0].addr),
                               pj_sockaddr_print(&cand[0].addr, ipaddr, sizeof(ipaddr), 0));
        } else {
            /* For other components, we'll just invent this.. */
            printed = snprintf(cursor, left_len, "a=Xice-defcand:%d IN IP4 %s\n",
                               (int)pj_sockaddr_get_port(&cand[0].addr),
                               pj_sockaddr_print(&cand[0].addr, ipaddr, sizeof(ipaddr), 0));
        }
        cursor += printed;
        left_len -= printed;
        
        /* Enumerate all candidates for this component */
        unsigned cand_cnt = PJ_ARRAY_SIZE(cand);
        status = pj_ice_strans_enum_cands(ice->ice.strans, comp + 1, &cand_cnt, cand);
        if (status != PJ_SUCCESS)
            return -status;
        
        /* And encode the candidates as SDP */
        for (int j = 0; j < cand_cnt; ++j) {
            printed = kj_sdp_encode_ice_candidate(cursor, (unsigned)left_len, &cand[j]);
            if (printed < 0)
                return -PJ_ETOOSMALL;
            cursor += printed;
            left_len -= printed;
        }
    }
    *cursor = '\0';
    return (int)(cursor - sdp);
}

#pragma mark - ROME PTP SDP信息解析和编码
kj_code kj_sdp_parse_for_ptp(kj_ptp *ptp, const char *sdp) {
    kj_code code = kj_code_success;
    char linebuf[200] = {};
    size_t sdp_len = strlen(sdp);
    size_t position = 0;
    int line_len = 0;
    while (position < sdp_len) {
        line_len = kj_sdp_get_a_line_from_sdp(linebuf, sdp, &position);
        if (line_len > 0) {
            switch (linebuf[0]) {
                case 'a': { // 解析对端外网IP和映射的端口
                    char *attr = strtok(linebuf + 2, " ");
                    if (strcmp(attr, "ip-srflx") == 0) {
                        strcpy(ptp->sdp.endpoint.ip, attr + strlen(attr) + 1);
                    } else if (strcmp(attr, "ports-srflx") == 0) {
                        sscanf(attr + strlen(attr) + 1, "%d %hu %hu", &ptp->sdp.endpoint.port_cnt, &ptp->sdp.endpoint.ports[0], &ptp->sdp.endpoint.ports[1]);
                        ptp->info->remote.nat = kj_util_get_nat_port_range(ptp->sdp.endpoint.ports[0], ptp->sdp.endpoint.ports[1]);
                    }
                } break;
                default:
                    break;
            }
        }
    }
    return code;
}
int kj_sdp_encode_ptp_sdp(kj_ptp *ptp, char *sdp, size_t sdp_len) {
    /* Write "dummy" SDP v=, o=, s=, and t= lines */
    kj_sdp_head head = {
        .version = ptp->info->local.version,
        .role = ptp->info->local.role,
        .cnt_id = ptp->cnt_id,
        .nat = ptp->info->local.nat,
        .ipv_support = ptp->info->local.ipv_support,
        .road_support = ptp->info->local.road_support,
        .type = ptp->sdp.local.ipv6 ? kj_sdp_ptp_ipv6 : kj_sdp_ptp_ipv4,
        .algorithm = ptp->info->local.algorithm
    };
    // 角色为client则指定对端的打洞算法
    if (ptp->info->local.role == kj_rm_role_client) {
        head.algorithm = ptp->info->remote.algorithm;
    }
    // sdp 头
    int printed = kj_sdp_encode_head(sdp, sdp_len, head);
    sdp += printed;
    sdp_len -= printed;
    int length = printed;
    // IPv4的外网IP
    printed = snprintf(sdp, sdp_len, "a=ip-srflx %s\n", ptp->sdp.local.ip);
    sdp += printed;
    sdp_len -= printed;
    length += printed;
    // IPv4的外网端口
    printed = snprintf(sdp, sdp_len, "a=ports-srflx %d %hu %hu", ptp->sdp.local.port_cnt, ptp->sdp.local.ports[0], ptp->sdp.local.ports[1]);
    length += printed;
    return length;
}
