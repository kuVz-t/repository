//
//  kj_engine.c
//  P2PLib
//
//  Created by twenty on 2023/5/17.
//

#include "kj_engine.h"
#include "kj_ice.h"

#define THIS_FILE __FILE__

static kj_engine *_rm_engine = NULL;

void kj_engine_ioqueue_thread(void *arg, pthread_t *pthread) {
    // 因kj_sock_ioqueue_poll函数涉及使用pjsip解析stun协议包，因此需要注册该线程到pjsip
    pj_thread_desc desc;
    kj_ice_register_thread_to_pjlib(desc);
    
    pthread_setname_np(*pthread, "rm engine thread");
    kj_engine *engine = arg;
    int events = 0;
    pj_time_val timeout = {};
    pj_time_val ioqueue_timeout = {};
    while (engine->working) {
        // ice里的定时器
        pj_timer_heap_poll(engine->timerhp, &timeout);
        // rome的数据读取
        events = kj_sock_ioqueue_poll(engine->sock_queue);
        // ice的数据读取
        events += pj_ioqueue_poll(engine->ioqueue, &ioqueue_timeout);
        if (events) {
            continue;
        } else {
            usleep(10000);
        }
    }
    kj_timer_destroy(&engine->timer);
    pj_timer_heap_destroy(engine->timerhp);
    pj_ioqueue_destroy(engine->ioqueue);
    kj_sock_ioqueue_destroy(&engine->sock_queue);
    pj_caching_pool_destroy(&engine->caching_pool);
    pj_shutdown();
    free(engine);
    _rm_engine = NULL;
}

kj_engine *rm_engine(void) {
    if (_rm_engine == NULL) {
        _rm_engine = calloc(1, sizeof(kj_engine));
        _rm_engine->working = 1;
        // ice
        if (!pj_thread_is_registered()) {
            pj_thread_desc desc;
            pj_thread_t *thread = NULL;
            pj_thread_register(NULL, desc, &thread);
        }
        // 初始化pjlib
        pj_init();
        pjlib_util_init();
        pjnath_init();
        // 设置pjlib日志输出
        pj_log_set_level(1);
        // 创建ICE所需的内存池、定时器和网络IO队列
        pj_caching_pool_init(&_rm_engine->caching_pool, &pj_pool_factory_default_policy, 0);
        _rm_engine->pool = pj_pool_create(&_rm_engine->caching_pool.factory, "engine pool", 1024, 1024, NULL);
        if (_rm_engine->pool == NULL) {
            PJ_LOG(3, (THIS_FILE, "pj_pool_create failed!"));
            goto error;
        }
        pj_status_t status = pj_timer_heap_create(_rm_engine->pool, 20, &_rm_engine->timerhp);
        if (status != PJ_SUCCESS) {
            PJ_LOG(3, (THIS_FILE, "pj_timer_heap_create failed![%d]",status));
            goto error;
        }
        // 设置timer heap的锁，避免不同ice strans对象在不同的线程中销毁导致Android端崩溃
        pj_lock_t *lock = NULL;
        pj_lock_create_recursive_mutex(_rm_engine->pool, NULL, &lock);
        pj_timer_heap_set_lock(_rm_engine->timerhp, lock, PJ_TRUE);
        
        status = pj_ioqueue_create(_rm_engine->pool, PJ_IOQUEUE_MAX_HANDLES, &_rm_engine->ioqueue);
        if (status != PJ_SUCCESS) {
            PJ_LOG(3, (THIS_FILE, "pj_ioqueue_create failed![%d]",status));
            goto error;
        }
//        pj_lock_create_recursive_mutex(_rm_engine->pool, NULL, &lock);
//        pj_ioqueue_set_lock(_rm_engine->ioqueue, lock, PJ_TRUE);
        
        // rome ptp网络队列
        _rm_engine->sock_queue = kj_sock_ioqueue_create();
        kj_thread_new_thread(_rm_engine, kj_engine_ioqueue_thread);
        // rome 定时器
        _rm_engine->timer = kj_timer_create();
    }
    return _rm_engine;
error:
    free(_rm_engine);
    _rm_engine = NULL;
    return NULL;
}
void kj_engine_release(void) {
    if (_rm_engine) {
        _rm_engine->working = 0;
    }
}
