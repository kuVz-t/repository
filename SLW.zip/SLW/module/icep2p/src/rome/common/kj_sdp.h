//
//  kj_sdp.h
//  P2PLib
//
//  Created by twenty on 2023/6/14.
//

#ifndef kj_sdp_h
#define kj_sdp_h

#include <stdio.h>

#include "kj_ice.h"
#include "kj_ptp.h"

/* SDP信息格式示例
 // ROME v0 SDP信息示例
 v=0
 o=- 3414953978 3414953978 IN IP4 localhost
 s=ice
 t=0 0
 a=ice-ufrag:6f6dc7a7
 a=ice-pwd:659716985a9a3df379749096
 m=audio 54983 RTP/AVP 0
 c=IN IP4 192.168.99.216
 a=candidate:Sc0a801f4 1 UDP 1694498815 113.65.204.125 29567 typ srflx
 a=candidate:Hc0a801f4 1 UDP 2130706431 192.168.1.244 40424 typ host
 a=candidate:Rc0a863d8 1 UDP 16777215 192.168.99.216 54983 typ relay
 
 // ROME v1 SDP头部信息
 v=1（版本，取整型值）
 o=cnt-id 47539 0 IN IP4 localhost（连接ID和角色，格式为o=cnt-id 连接ID 角色 IN IP4 localhost）
 s=ice（支持的连接类型，取值ice、ptp，支持多个，格式为：ice ptp）
 t=0（SDP信息类型，0:IPv4的ice；1:IPv6的ice；2:IPv4的ptp；3:IPv6的ptp；4:不支持的连接协商）
 p=method 1 ports 10000 per 1 interval 1.f（穿透信息，格式：method 穿透算法 ports 穿透包总数 per 每轮发送个数 interval 每轮休眠时长，毫秒）

 // ROME v1 SDP头部信息（2024-1-05修改）
 v=0（版本，取整型值）
 o=cnt-id 47539 0 nat 100 ipv 1（连接ID和角色，格式为o=cnt-id 连接ID 角色 nat NAT端口特性值 ipv 支持的IPv版本(0:未知；0x01:IPv4；0x02:IPv6)）
 s=ice（支持的连接类型，取值ice、ptp，支持多个，格式为：ice ptp）
 t=0（SDP信息类型，0:IPv4的ice；1:IPv6的ice；2:IPv4的ptp；3:IPv6的ptp；4:不支持的连接协商）
 p=method 1 ports 10000 per 1 interval 1.f（穿透信息，格式：method 穿透算法 ports 穿透包总数 per 每轮发送个数 interval 每轮休眠时长，毫秒）
 
 // ROME v1 ICE的SDP信息
 a=ice-ufrag:437266f5
 a=ice-pwd:0bc5816b53b39dd6353f7788
 m=audio 33365 RTP/AVP 0
 c=IN IP4 192.168.41.94
 a=candidate:Sa1538bf 1 UDP 1694498815 183.63.90.59 2361 typ srflx
 a=candidate:Ha1538bf 1 UDP 2130706431 10.21.56.191 49320 typ host
 a=candidate:Rc0a8295e 1 UDP 16777215 192.168.41.94 33365 typ relay
 
 // ROME v1 rome ptp的SDP信息
 a=ip-rflx 183.63.90.59
 a=ports-rflx 2 2345 8436
 a=ip-rflx6 fe80::d833:9687:435c:28a3
 a=ports-rflx6 1 9767
 a=ip-host 192.168.0.112 port 9467
 a=ip-host6 fe80::d833:9687:435c:28a3 port 9467
 */

#define KJ_SDP_INFO_MAX_LENGTH 512

typedef enum {
    kj_sdp_ice_ipv4 = 0,    // IPv4的ICE SDP
    kj_sdp_ice_ipv6 = 1,    // IPv6的ICE SDP
    kj_sdp_ptp_ipv4 = 2,    // IPv4的ROME PTP SDP
    kj_sdp_ptp_ipv6 = 3,    // IPv6的ROME PTP SDP
    kj_sdp_unsupport = 4    // 不支持的连接协商 SDP
} kj_sdp_type;

typedef struct kj_sdp_head {
    int version;                // 版本
    kj_rm_role role;            // 角色
    uint16_t cnt_id;            // 连接ID
    int nat;                    // NAT端口特性值
    kj_ipv ipv_support;         // 支持的IPv版本
    kj_road_type road_support;  // 支持的连接类型
    kj_sdp_type type;           // SDP信息的连接类型
    kj_ptp_alg algorithm;       // ptp打洞算法参数
} kj_sdp_head;

// s字段的内容必须按照ice ptp的顺序填充，日后增加其他的必须在ice ptp的后面增加，以使解析正确
#define KJ_SDP_S_ICE "ice"
#define KJ_SDP_S_PTP "ptp"

#pragma mark - 解析和编码SDP头部信息
kj_sdp_head kj_sdp_parse_head(const char *sdp);
int kj_sdp_encode_head(char *sdp, size_t sdp_len, kj_sdp_head head);

#pragma mark - ICE SDP信息解析和编码
kj_code kj_sdp_parse_for_ice(kj_ice *ice, const char *sdp);
int kj_sdp_encode_ice_sdp(kj_ice *ice, char *sdp, size_t sdp_len);

#pragma mark - ROME PTP SDP信息解析和编码
kj_code kj_sdp_parse_for_ptp(kj_ptp *ptp, const char *sdp);
int kj_sdp_encode_ptp_sdp(kj_ptp *ptp, char *sdp, size_t sdp_len);

#endif /* kj_sdp_h */
