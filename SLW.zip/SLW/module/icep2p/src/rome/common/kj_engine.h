//
//  kj_engine.h
//  P2PLib
//
//  Created by twenty on 2023/5/17.
//

#ifndef kj_engine_h
#define kj_engine_h

#include <stdio.h>

#include <pjlib.h>
#include <pjnath.h>

#include "rm_sock.h"
#include "rm_timer.h"

typedef struct kj_engine {
    kj_timer *timer;
    // rome
    kj_sock_ioqueue *sock_queue;
    // ice
    pj_caching_pool caching_pool;
    pj_pool_t *pool;
    pj_ioqueue_t *ioqueue;
    pj_timer_heap_t *timerhp;
    pj_thread_t *thread;
    int working;
} kj_engine;

/// 全局引擎
kj_engine *rm_engine(void);
/// 释放全局引擎相关资源
void kj_engine_release(void);

#endif /* kj_engine_h */
