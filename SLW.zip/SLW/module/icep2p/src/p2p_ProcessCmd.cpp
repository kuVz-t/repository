#include "p2p_ProcessCmd.h"
#include "P2pManageMent.h"
#include "record_api.h"
#include "mos.h"
#include "p2p_connect.h"
#include "media_playback.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#ifdef BUILD_IMSSDK_FALG
#include "ims_render.h"
#endif

#ifdef BUILD_ONBROADCAST_FALG
#include "broadcast_api.h"
#include "AudioDeviceAPI.h"
#endif
static ST_P2P_RECIVE_MNG* P2pProcessCmd::stP2pReciveMng=MOS_NULL;
P2pProcessCmd::P2pProcessCmd()
{

}

void P2pProcessCmd::InitReciveBuf()
{
    if (stP2pReciveMng == MOS_NULL)
    {
        stP2pReciveMng = (ST_P2P_RECIVE_MNG*)MOS_MALLOCCLR(sizeof(ST_P2P_RECIVE_MNG));
        stP2pReciveMng->uiInitFlag    = 1;
        stP2pReciveMng->uiMaxBufLen   = MAX_P2P_RECIVE_BUF_LEN;
        stP2pReciveMng->hSockBuffPool = Mos_MallocSockBuf(stP2pReciveMng->uiMaxBufLen);
        stP2pReciveMng->uiPayloadLen  = stP2pReciveMng->uiMaxBufLen  - sizeof(ST_MOS_SOCKBUF);
        stP2pReciveMng->pstRecvBuf    = Mos_PopSockBuf(stP2pReciveMng->hSockBuffPool);
        //Mos_MutexCreate(&(stP2pReciveMng->hMutexRecive));
        Mos_InitSockBuf(stP2pReciveMng->pstRecvBuf);
    }
}

void P2pProcessCmd::DeniReciveBuf()
{
    if (stP2pReciveMng != MOS_NULL && stP2pReciveMng->uiInitFlag== 1)
    {
        MOS_FUNCTION_LINE();
        stP2pReciveMng->uiInitFlag  = 0;
        Mos_PushSockBuf(stP2pReciveMng->hSockBuffPool, stP2pReciveMng->pstRecvBuf);
        stP2pReciveMng->pstRecvBuf = MOS_NULL;
        Mos_DeleteSockBuf(stP2pReciveMng->hSockBuffPool);
        //Mos_MutexDelete(&(stP2pReciveMng->hMutexRecive));
        MOS_FREE(stP2pReciveMng);
    }
}

_INT P2pProcessCmd::procDispathCmdMsg(_HP2PCHANNEL hP2pChnnel, _UC ucMsgType, _UC ucMsgId, _UC ucRerv,
                                      _INT iSeqID, _UC *pucMsgBuff,_INT iMsgBuffLen)
{
    ST_AVCLIENT_INFO *avClint = (ST_AVCLIENT_INFO*)hP2pChnnel;

    ST_P2P_CMD_MSG *pstCmdMsg =(ST_P2P_CMD_MSG*)MOS_MALLOCCLR(sizeof(ST_P2P_CMD_MSG) + iMsgBuffLen);
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdMsg->stMsgHead.usMsgType = EN_P2P_MSG_TYPE_NET;
    pstCmdMsg->stMsgHead.usMsgLen  = iMsgBuffLen;
    pstCmdMsg->ucMsgType = ucMsgType;
    pstCmdMsg->ucMsgId   = ucMsgId;
    pstCmdMsg->iSeqNum   = iSeqID;
    pstCmdMsg->ucRsv[0]  = ucRerv;
    if (iMsgBuffLen >=0 )
    {
        MOS_MEMCPY(pstCmdMsg->aucMsgBody, pucMsgBuff, iMsgBuffLen);
    }

    _INT iRet = Mos_MsgQueuePush(avClint->m_liveCmdThreadMng.hMsgQueque, pstCmdMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdMsg);
        return MOS_ERR;
    }
    return sizeof(ST_OGCT_PROTOCAL_HEAD);
}

_INT P2pProcessCmd::P2pCmd_DecodeMultiMediaData(_HP2PCHANNEL hP2pChnnel, _UC *pucMsgBuff,_INT iMsgBuffLen)
{
    MOS_PARAM_NULL_RETERR(pucMsgBuff);

    _INT iRet      = 0;
    _INT iParseLen = 0;

    do
    {
        // 处理接收到的信令data数据
        iRet = procCmdServerMsg(hP2pChnnel, pucMsgBuff, iMsgBuffLen - iParseLen);
        if(iRet <= 0)
        {
            break;
        }
        iParseLen   += iRet;
        pucMsgBuff  += iRet;
    }while(iParseLen < iMsgBuffLen);

    if(iRet < 0)
    {
        while(iMsgBuffLen - iParseLen > 0)
        {
            if(pucMsgBuff[0] == '#' && pucMsgBuff[1] == '$')
            {
                break;
            }
            iParseLen++;
            pucMsgBuff++;
        }
    }
    return iParseLen;
}


_INT P2pProcessCmd::PaseReciveData(_HP2PCHANNEL hP2pChnnel, _UC *pData, _UI uiDataLen)
{
    MOS_PARAM_NULL_RETERR(hP2pChnnel);
    _INT iRetLen  = uiDataLen;
    //_UI uiByteLen = stP2pReciveMng->uiPayloadLen - MOS_BOFF(stP2pReciveMng->pstRecvBuf) - MOS_BLEN(stP2pReciveMng->pstRecvBuf);

    //MOS_PRINTF("uiDataLen:%d uiBytelen:%d, off:%d blen:%d\n", uiDataLen, uiByteLen, MOS_BOFF(stP2pReciveMng->pstRecvBuf), MOS_BLEN(stP2pReciveMng->pstRecvBuf));
    MOS_MEMCPY(((_VPTR)(MOS_BEND(stP2pReciveMng->pstRecvBuf))), pData, uiDataLen);
    MOS_BLEN(stP2pReciveMng->pstRecvBuf) += iRetLen;

    if(MOS_BLEN( stP2pReciveMng->pstRecvBuf) < sizeof(ST_OGCT_PROTOCAL_HEAD))
    {
        //MOS_PRINTF("RETURN OK: %d < %d\n", MOS_BLEN( stP2pReciveMng->pstRecvBuf) , sizeof(ST_OGCT_PROTOCAL_HEAD));
        return MOS_OK;
    }
    iRetLen = P2pCmd_DecodeMultiMediaData(hP2pChnnel, MOS_BPTR( stP2pReciveMng->pstRecvBuf),
                                          MOS_BLEN( stP2pReciveMng->pstRecvBuf));
    if(iRetLen > 0)
    {
        MOS_BOFF( stP2pReciveMng->pstRecvBuf) += iRetLen;
        MOS_BLEN( stP2pReciveMng->pstRecvBuf) -= iRetLen;
    }

    if(MOS_BLEN( stP2pReciveMng->pstRecvBuf) > 0)
    {
        MOS_MEMMOVE( stP2pReciveMng->pstRecvBuf->aucPayload, MOS_BPTR( stP2pReciveMng->pstRecvBuf),
                     MOS_BLEN( stP2pReciveMng->pstRecvBuf));
        MOS_BOFF( stP2pReciveMng->pstRecvBuf) = 0;
    }
    else
    {
        Mos_InitSockBuf( stP2pReciveMng->pstRecvBuf);
    }
    return MOS_OK;
}


/**
* @brief         // 处理务P2P下发的信令
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pProcessCmd::procCmdServerMsg(_HP2PCHANNEL hP2pChnnel,_UC *pucMsgBuff,_INT iMsgBuffLen)
{
    ST_AVCLIENT_INFO *avClint = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_FUNRET_NULL_RETERR(P2PCMD_STRLOG, avClint, __FUNCTION__);

    _INT iSeqID         = 0;
    _UC  aucMethod[8]   = {0};
    _UC *pucMethod      = MOS_NULL;

    JSON_HANDLE hRoot   = MOS_NULL;
    ST_OGCT_PROTOCAL_HEAD stOgctHead;
    ST_HTTP_ENCRYPTO_INF *pstEncrypInf = P2pManageMent::instance().getDevTransEnc();

    if(iMsgBuffLen < sizeof(stOgctHead))
    {
        return 0;
    }
    MOS_MEMCPY(&stOgctHead, pucMsgBuff, sizeof(ST_OGCT_PROTOCAL_HEAD));
    if(stOgctHead.aucheck[0] != '#' || stOgctHead.aucheck[1] != '$')
    {
        MOS_LOG_ERR(P2PCMD_STRLOG,"parse msg head err %02x %02x", stOgctHead.aucheck[0], stOgctHead.aucheck[1]);
        return -1;
    }

    stOgctHead.usBodyLen = MOS_INET_NTOHS(stOgctHead.usBodyLen);
    if(stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD) > (_US)iMsgBuffLen)
    {
        //MOS_LOG_ERR(P2PCMD_STRLOG,"parse msg len err");
        return 0;
    }

    if (0)//stOgctHead.ucMsgType ==  EN_OGCT_METHOD_CN21_CMD)
    {
        MOS_BUFPRINTF("p2previce cmd:", pucMsgBuff, iMsgBuffLen>50?10:iMsgBuffLen);
    }

    pucMsgBuff  += sizeof(ST_OGCT_PROTOCAL_HEAD);
    iMsgBuffLen -= sizeof(ST_OGCT_PROTOCAL_HEAD);
    if ((stOgctHead.ucMsgType ==  EN_OGCT_METHOD_KEEPALIVE )|| (stOgctHead.ucMsgType ==  EN_OGCT_METHOD_FEEDBACK)
            || (stOgctHead.ucMsgType == EN_OGCT_METHOD_FORCEKEEPALIVE))
    {
        //MOS_PRINTF("recive keepalive command!!type:%02x, %02x\n", stOgctHead.ucMsgType,stOgctHead.ucMsgId);
        procDispathCmdMsg(hP2pChnnel, stOgctHead.ucMsgType, stOgctHead.ucMsgId, stOgctHead.ucRsv,
                          iSeqID, pucMsgBuff, iMsgBuffLen);
        return sizeof(ST_OGCT_PROTOCAL_HEAD)+stOgctHead.usBodyLen;
    }

    if(stOgctHead.usBodyLen == 0)
    {
        return sizeof(ST_OGCT_PROTOCAL_HEAD);
    }

    if (stOgctHead.ucMsgType != EN_OGCT_METHOD_DATA)//==  EN_OGCT_METHOD_CN21_CMD) //this is cmd data
    {
        Http_DecMsgBody(stOgctHead.ucEncFlag,pucMsgBuff, stOgctHead.usBodyLen,pstEncrypInf);
        MOS_LOG_INF(P2P_STRLOG,"type:%02x methodid:%02x len:%d, stOgctHead.ucEncFlag:%d\r\n", stOgctHead.ucMsgType, stOgctHead.ucMsgId, stOgctHead.usBodyLen, stOgctHead.ucEncFlag);

        hRoot = Adpt_Json_Parse(pucMsgBuff);
        do
        {
            if(hRoot == MOS_NULL)
            {
                MOS_LOG_ERR(P2PCMD_STRLOG, "parse net msg body err");
                break;
            }
            MOS_SPRINTF(aucMethod, "%02X%02X",stOgctHead.ucMsgType, stOgctHead.ucMsgId);
            // 解析 方法METHOD 字段
            Adpt_Json_GetString(Adpt_Json_GetObjectItem(hRoot,(_UC*)"METHOD"), &pucMethod);

            if(MOS_STRCMP(aucMethod, pucMethod) != 0)
            {
                MOS_LOG_ERR(P2PCMD_STRLOG, "msg check method err%s %s", aucMethod, pucMethod);
                break;
            }

            Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hRoot,(_UC*)"SEQID"), &iSeqID);
            procDispathCmdMsg(hP2pChnnel, stOgctHead.ucMsgType, stOgctHead.ucMsgId, stOgctHead.ucRsv, iSeqID, pucMsgBuff, iMsgBuffLen);
        }while(0);

        Adpt_Json_Delete(hRoot);
    }
    else if ((stOgctHead.ucMsgType == EN_OGCT_METHOD_DATA) && (stOgctHead.ucMsgId == EN_OGCT_MEDIA_DATA_PUSHSTREAM)) //audio data
    {
        _UC ucAudioBufer[1024] = {0};
        _UI uiEncLen = stOgctHead.usBodyLen;
        if (uiEncLen >= sizeof(ucAudioBufer))
        {
            return stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD);
        }

        //MOS_PRINTF("stOgctHead.usBodyLen;:%d\N", stOgctHead.usBodyLen);
        if (uiEncLen >= 32)
        {
            uiEncLen = 32;
            Http_DecMsgBodyMedia(stOgctHead.ucEncFlag, pucMsgBuff, uiEncLen, pstEncrypInf);
        }
        else if (uiEncLen >= 16)
        {
            uiEncLen = 16;
            Http_DecMsgBodyMedia(stOgctHead.ucEncFlag, pucMsgBuff, uiEncLen, pstEncrypInf);
        }
        MOS_MEMCPY(ucAudioBufer, pucMsgBuff,  stOgctHead.usBodyLen);//iMsgBuffLen);

        ST_MEDIA_PROTOCAL_HEAD *mediaHeader = (ST_MEDIA_PROTOCAL_HEAD *)ucAudioBufer;
        static _INT oldSeqId = -1;
        mediaHeader->usChannel  = MOS_INET_NTOHS(mediaHeader->usChannel);
        mediaHeader->usSeqId    = MOS_INET_NTOHS(mediaHeader->usSeqId);
        mediaHeader->iTimeStamp = MOS_INET_NTOHL(mediaHeader->iTimeStamp);
        mediaHeader->iFrameLen  = MOS_INET_NTOHL(mediaHeader->iFrameLen);
        if (oldSeqId == -1)
        {
          oldSeqId = mediaHeader->usSeqId;
        }
        if (stOgctHead.usBodyLen  != (mediaHeader->iFrameLen+sizeof(ST_MEDIA_PROTOCAL_HEAD)) )
        {
            MOS_PRINTF("recive audio data error, incrroct length:%d\n", stOgctHead.usBodyLen);
        }
        else
        {
            if (avClint->m_bEnableSpeaker && (avClint->m_hAudioPlay != MOS_NULL) && mediaHeader->iFrameLen>0)
            {
                if (oldSeqId != (mediaHeader->usSeqId-1))
                {
                    MOS_PRINTF("recive wrong speaker data!!old:%d new:%d!\n", oldSeqId, mediaHeader->usSeqId);
                }
                oldSeqId = mediaHeader->usSeqId;
                getDiffTimems(&avClint->m_tReiveAudioDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
//                MOS_PRINTF("Recive audio data.channel:%d usSeqId:%d frameType:%02x..avType:%d, frmlen:%d timest:%d\n",
//                                mediaHeader->usChannel, mediaHeader->usSeqId, mediaHeader->ucFrameType,
//                                mediaHeader->ucAVType,  mediaHeader->iFrameLen, mediaHeader->iTimeStamp);
                Media_AudioPlayWriteFrame(avClint->m_hAudioPlay, ucAudioBufer+sizeof(ST_MEDIA_PROTOCAL_HEAD),
                                       mediaHeader->iFrameLen, mediaHeader->iTimeStamp);
            }
        }
    }
    else if((stOgctHead.ucMsgType == EN_OGCT_METHOD_DATA) && (stOgctHead.ucMsgId == EN_OGCT_MEDIA_DATA_LIVESTREAM)) //video data
    {
        if ((avClint != MOS_NULL) && (avClint->m_iceTranSport != MOS_NULL))
        {
            _UC ucVideoBufer[1400] = {0};
            _UI uiEncLen = stOgctHead.usBodyLen;
            if (uiEncLen >= 32)
            {
                uiEncLen = 32;
                Http_DecMsgBodyMedia(stOgctHead.ucEncFlag, pucMsgBuff, uiEncLen, pstEncrypInf);
            }
            else if (uiEncLen >= 16)
            {
                uiEncLen = 16;
                Http_DecMsgBodyMedia(stOgctHead.ucEncFlag, pucMsgBuff, uiEncLen, pstEncrypInf);
            }
            MOS_MEMCPY(ucVideoBufer, pucMsgBuff,  stOgctHead.usBodyLen);//iMsgBuffLen);

            ST_MEDIA_PROTOCAL_HEAD2 *mediaHeader2 = (ST_MEDIA_PROTOCAL_HEAD2 *)ucVideoBufer;
            mediaHeader2->usChannel  = MOS_INET_NTOHS(mediaHeader2->usChannel);
            mediaHeader2->usSeqId    = MOS_INET_NTOHS(mediaHeader2->usSeqId);
            
            kj_data Kjdata    = {0};
            Kjdata.type       = stOgctHead.ucMsgType;
            Kjdata.method     = stOgctHead.ucMsgId;
            Kjdata.encryption = 0;
    
            kj_media_meta kjMediaMeta = {0}; 
            Kjdata.media_meta                  = &kjMediaMeta;
            Kjdata.media_meta->channel         = mediaHeader2->usChannel;
            Kjdata.media_meta->sequence        = mediaHeader2->usSeqId;
            Kjdata.media_meta->frame_type      = mediaHeader2->ucFrameType >> 4;
            Kjdata.media_meta->frame_begin     = ((mediaHeader2->ucFrameType & 0x08) >> 3);
            Kjdata.media_meta->frame_end       = ((mediaHeader2->ucFrameType & 0x04) >> 2);
            Kjdata.media_meta->frame_nal_begin = ((mediaHeader2->ucFrameType & 0x02) >> 1);
            Kjdata.media_meta->frame_nal_end   = (mediaHeader2->ucFrameType & 0x01);
            Kjdata.media_meta->av_type         = mediaHeader2->ucAVType;

            _INT iMediaDataLength = 0;
            _INT iMediaHeadLength = 0;
            if (Kjdata.media_meta->frame_begin == 1)
            {
                iMediaHeadLength  = sizeof(ST_MEDIA_PROTOCAL_HEAD);
                iMediaDataLength  = stOgctHead.usBodyLen - iMediaHeadLength;
                Kjdata.length     = iMediaDataLength;

                ST_MEDIA_PROTOCAL_HEAD  *mediaHeader  = (ST_MEDIA_PROTOCAL_HEAD *)ucVideoBufer;
                mediaHeader->iTimeStamp = MOS_INET_NTOHL(mediaHeader->iTimeStamp);
                mediaHeader->iFrameLen  = MOS_INET_NTOHL(mediaHeader->iFrameLen);
                Kjdata.media_meta->frame_len       = mediaHeader->iFrameLen;
                Kjdata.media_meta->time_stamp      = mediaHeader->iTimeStamp;
            }
            else
            {
                iMediaHeadLength  = sizeof(ST_MEDIA_PROTOCAL_HEAD2);
                iMediaDataLength  = stOgctHead.usBodyLen - iMediaHeadLength;
                Kjdata.length     = iMediaDataLength;
            }

            // Kjdata.raw_data =(void *)MOS_MALLOCCLR(iMediaDataLength);
            // MOS_MEMCPY(Kjdata.raw_data, ucVideoBufer+iMediaHeadLength, iMediaDataLength);
            Kjdata.raw_data = ucVideoBufer+iMediaHeadLength;
            if ((avClint->m_iceTranSport->m_video_tbsl != MOS_NULL) && (Kjdata.media_meta->av_type == 1))
            {
                getDiffTimems(&avClint->m_tReiveVideoDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);

                kj_tbsl_recv(avClint->m_iceTranSport->m_video_tbsl, &Kjdata);
            }
            else if((avClint->m_iceTranSport->m_audio_tbsl != MOS_NULL) && (Kjdata.media_meta->av_type == 2))
            {
                getDiffTimems(&avClint->m_tReiveAudioDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
                kj_tbsl_recv(avClint->m_iceTranSport->m_audio_tbsl, &Kjdata);
            }
            
            // MOS_FREE(Kjdata.raw_data);
        }
    }
    

    return stOgctHead.usBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD);
}

_INT P2pProcessCmd::procCmdSendMsg(_HP2PCHANNEL hP2pChnnel, _UC msgType, _UC msgId, _UC *pucMsgBuff, _INT iMsgBuffLen, _UC msgRev)
{
    ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    ST_OGCT_PROTOCAL_HEAD msgHeader;
    ST_HTTP_ENCRYPTO_INF  transEnc;
    MOS_MEMSET(&transEnc, 0, sizeof(transEnc));
    MOS_PARAM_NULL_RETERR(hP2pChnnel);

    _INT  pucOutLen   = 0;
    if ((msgType ==  EN_OGCT_METHOD_KEEPALIVE )|| (msgType ==  EN_OGCT_METHOD_FEEDBACK) || (msgType == EN_OGCT_METHOD_FORCEKEEPALIVE))
    {
        transEnc.iEncType = 0;
    }
    else
    {
        MOS_MEMCPY(&transEnc, P2pManageMent::instance().getDevTransEnc(), sizeof(ST_HTTP_ENCRYPTO_INF));
    }
    Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, transEnc.iEncType);
    msgHeader.ucRsv = msgRev;
    if (iMsgBuffLen > 0)
    {
        _UI uiDataLenEx  =  MOS_HEX_NUM(iMsgBuffLen)+1;
        if (transEnc.iEncType == 0)
        {
            uiDataLenEx = iMsgBuffLen;
        }
        ST_OGCT_PROTOCAL_HEAD *pstCmdMsg = (ST_OGCT_PROTOCAL_HEAD*)MOS_MALLOCCLR(sizeof(ST_OGCT_PROTOCAL_HEAD) + uiDataLenEx);
        Http_EncMsgBody2(&msgHeader, pucMsgBuff, iMsgBuffLen, &transEnc,
                        (_UC*)(pstCmdMsg), &pucOutLen);
        MOS_PARAM_NULL_RETERR(avClient->m_iceTranSport);
        avClient->m_iceTranSport->pcbSendP2pData(hP2pChnnel, pstCmdMsg, pucOutLen);
        MOS_FREE(pstCmdMsg);
    }
    else
    {
        MOS_PARAM_NULL_RETERR(avClient->m_iceTranSport);
        avClient->m_iceTranSport->pcbSendP2pData(hP2pChnnel,  &msgHeader, sizeof(msgHeader));
    }
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdSendKeepAlive(_HP2PCHANNEL hP2pChnnel, _UC msgType, _UC msgId, _UC msgRev)
{
    _UC *pucMsgBuff  = NULL;
    _INT iMsgBuffLen = 0;
    procCmdSendMsg(hP2pChnnel, msgType, msgId, pucMsgBuff, iMsgBuffLen, msgRev);
    //MOS_PRINTF("###send keep alive method:%02X%02X , msgRev:%d \n",msgType, msgId, msgRev);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdReciveKeepAlive(_HP2PCHANNEL hP2pChnnel, _UC msgType, _VPTR msgParam)
{
    ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    _UC msgId  = 0xff;
    _UC msgRev = 0;
    _UC msgLen = 0;

    if (msgParam != MOS_NULL)
    {
        ST_MSGP2P_OPTION *param = (ST_MSGP2P_OPTION*)msgParam;
        msgId  = param->ucMsgId;
        msgRev = param->ucRsv[0];
        msgLen = param->ucRsv[1];
#if 0
        MOS_PRINTF("msgRev: %02x, msgLen: %02x \r\nmsgBuf: ", msgRev, msgLen);
        for (int i = 0; i < msgLen; i++)
        {
            MOS_PRINTF("%02x ", param->aucMsgBody[i]);
        }
        MOS_PRINTF("\r\n");
#endif
        Mos_MutexLock(&avClient->hMutex);
        if (msgLen > 0)
        {
            if ((avClient->m_stKeepAliveChannelInfo.uiMsgLen  == msgLen) && (MOS_MEMCMP(avClient->m_stKeepAliveChannelInfo.stMsgBody, param->aucMsgBody, msgLen) == 0))
            {
                avClient->m_stKeepAliveChannelInfo.uiCheckTimes++;
            }
            else
            {
                avClient->m_stKeepAliveChannelInfo.uiCheckTimes = 1;
            }
            avClient->m_stKeepAliveChannelInfo.uiMsgLen     = msgLen;
            MOS_MEMCPY(avClient->m_stKeepAliveChannelInfo.stMsgBody, param->aucMsgBody, msgLen);
        }
        else
        {
            MOS_MEMSET(&avClient->m_stKeepAliveChannelInfo, 0, sizeof(avClient->m_stKeepAliveChannelInfo));
        }
        Mos_MutexUnLock(&avClient->hMutex);
        //MOS_PRINTF("avClient->m_stKeepAliveChannelInfo.uiCheckTimes :%d, msgLen:%d\n", avClient->m_stKeepAliveChannelInfo.uiCheckTimes , msgLen);
    }
    if (msgType == EN_OGCT_METHOD_FORCEKEEPALIVE)//force keep alive
    {
        msgType = EN_OGCT_METHOD_KEEPALIVE;
        //MOS_PRINTF("#######recive force keep alive method:%02X%02X \n",msgType, msgId);
        procCmdSendKeepAlive(hP2pChnnel, msgType, EN_CN21_P2P_KEEPALIVE_REQ, msgRev);
    }
    else
    {
        //MOS_PRINTF("#######recive keep alive method:%02X%02X \n",msgType, msgId);
    }

    //TODO check avclient lock
    avClient->m_bChannelTimeOut = MOS_FALSE;
    return MOS_OK;
}

/**
* @brief         recive Reliable transmission feedback msg
* @author        Hejh
* @date          2021-05-12
*/
_INT P2pProcessCmd::procCmdReciveFeedBack(_HP2PCHANNEL hP2pChnnel,_UI msgLen, _VPTR msgParam)
{
    ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;

    if (msgParam != MOS_NULL)
    {
        ST_MSGP2P_FEEDBACK *param = (ST_MSGP2P_FEEDBACK*)msgParam;
        ProCmdResendMediaReq(hP2pChnnel, 1, 1, param->ucAvType, msgParam, msgLen);
    }
    return MOS_OK;
}

/**
* @brief         deal with resend feedback message
* @author        Hejh
* @date          2021-05-12
*/
_INT P2pProcessCmd::ProCmdResendMediaReq(_HP2PCHANNEL hP2pChnnel, _UC ucMsgType, _UC ucMsgId, _INT iAvType,
                                      _UC *pucMsgBuff,_INT iMsgBuffLen)
{
    ST_AVCLIENT_INFO *avClint = (ST_AVCLIENT_INFO*)hP2pChnnel;

    ST_P2P_FEEDBACK_MSG *pstCmdMsg =(ST_P2P_FEEDBACK_MSG*)MOS_MALLOCCLR(sizeof(ST_P2P_FEEDBACK_MSG) + iMsgBuffLen);
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdMsg->stMsgHead.usMsgType = EN_P2P_MSG_TYPE_NET;
    pstCmdMsg->stMsgHead.usMsgLen  = iMsgBuffLen;
    pstCmdMsg->ucMsgType = ucMsgType;
    pstCmdMsg->ucMsgId   = ucMsgId;
    pstCmdMsg->iSeqNum   = 0;
    pstCmdMsg->ucAvType  = iAvType;
    ST_MSGP2P_FEEDBACK* msgParam = (ST_MSGP2P_FEEDBACK*)pucMsgBuff;
    _US usChannel = MOS_INET_NTOHS(msgParam->usChannel);
    MOS_MEMCPY(pstCmdMsg->aucPeerId, avClint->m_uacPeerId, sizeof(pstCmdMsg->aucPeerId));
    if (iMsgBuffLen >=0 )
    {
        MOS_MEMCPY(pstCmdMsg->aucMsgBody, pucMsgBuff, iMsgBuffLen);
    }
#if 0
    ST_MSGP2P_FEEDBACK *param = (ST_MSGP2P_FEEDBACK*)pucMsgBuff;
    param->usChannel   = MOS_INET_NTOHS(param->usChannel);
    param->usPsrtMode  = MOS_INET_NTOHS(param->usPsrtMode);
    param->usWinSize   = MOS_INET_NTOHS(param->usWinSize);
    param->usWinBeginSeq  = MOS_INET_NTOHS(param->usWinBeginSeq);
    param->usNackCount = MOS_INET_NTOHS(param->usNackCount);
    MOS_PRINTF("#######video feedback iMsgBuffLen:%u form:%s chan:%u ackSeq:%d account:%u nackcount:%u av:%d psrtmode:%d winsize:%d,  \n",
               iMsgBuffLen, avClint->m_uacPeerId, param->usChannel, param->ucPackSeq, param->usWinBeginSeq, param->usNackCount,
               param->ucAvType, MOS_INET_NTOHS(param->usPsrtMode), MOS_INET_NTOHS(param->usWinSize));
#endif
    ST_AVCLIENT_INFO *pAvClientInfo = P2pManageMent::instance().findAvclientById(pstCmdMsg->aucPeerId);
    if (pAvClientInfo != MOS_NULL)
    {
        _INT iRet = MOS_ERR;
        if ((pAvClientInfo->m_bEnableVideo) && (usChannel == pAvClientInfo->m_sLiveVideoChn))
        {
            iRet = P2pManageMent::instance().addResendMediaReq(iAvType, pstCmdMsg);
        }
        else if (usChannel == pAvClientInfo->m_playBackThreadMng.usChannel)
        {
            iRet = P2pManageMent::instance().addResendPlaybackMediaReq(pAvClientInfo, pstCmdMsg);
        }

        if (iRet != MOS_OK)
        {
            MOS_FREE(pstCmdMsg);
            MOS_LOG_ERR(P2P_STRLOG, "error #%s #recive unrecognizable channel:%d \n", __FUNCTION__, usChannel);
        }
        return iRet;
    }
    else
    {
        MOS_FREE(pstCmdMsg);
        MOS_LOG_ERR(P2P_STRLOG,"error #%s######client unknow  \n", __FUNCTION__ );
    }
    return MOS_OK;
}

/**
* @brief         send retrans media data, one node is limit whit 1440 bytes
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pProcessCmd::procSendMediaNode(_VPTR hIceTrans, _US usChannel, _UC msgType, _UC msgId,
                                       ST_DATA_NODE *pstNode, _INT trasTye, _INT iIsOneNode, _UC ucResSeq)
{
    ST_OGCT_PROTOCAL_HEAD   msgHeader;
    ST_MEDIA_PROTOCAL_HEAD  msgMediaHeader;
    ST_MEDIA_PROTOCAL_HEAD2 msgMediaHeader2;
    ST_MEDIA_PROTOCAL_HEAD  *mediaHeader = &msgMediaHeader;
    _INT iMsgBuffLen = 0;

    ST_HTTP_ENCRYPTO_INF  transEnc;
    MOS_MEMSET(&transEnc, 0, sizeof(transEnc));
    transEnc.iEncType = 0;
    _INT  pucOutLen   = 0;
    MOS_MEMCPY(&transEnc, P2pManageMent::instance().getDevTransEnc(), sizeof(ST_HTTP_ENCRYPTO_INF));

    _UC pucSendBuf[MAX_MEDIA_PACKEG_LEN] = {0};
    _UC pucSendDataBuf[MAX_MEDIA_PACKEG_LEN] = {0};
    _UI uiListCnt = 0;

    if(pstNode != MOS_NULL)
    {
        ST_DATA_NODE *pstFrameNode = pstNode;
        while(pstFrameNode != MOS_NULL)
        {
            uiListCnt++;
            _INT   iHeaderSize = sizeof(ST_MEDIA_PROTOCAL_HEAD2);
            MOS_MEMSET(&msgHeader, 0, sizeof(ST_OGCT_PROTOCAL_HEAD));
            _UC   ucFrameType = MD_GETFRAMEPOS(pstFrameNode->stFrameNode.ucFramPos)&MD_FRAME_HEAD;
            transEnc.iEncType = MD_GETFRAMETYPE(pstFrameNode->stFrameNode.ucFramPos)==EN_FRAMETYPE_I?transEnc.iEncType:0;

            if ( ucFrameType > 0)
            {
                iHeaderSize = sizeof(ST_MEDIA_PROTOCAL_HEAD);
                mediaHeader = &msgMediaHeader;
                mediaHeader->iFrameLen = MOS_INET_HTONL(pstFrameNode->stFrameNode.usDatalen);
                mediaHeader->iTimeStamp= MOS_INET_HTONL(pstFrameNode->uiTimeStamp);
            }
            else
            {
                mediaHeader = (ST_MEDIA_PROTOCAL_HEAD*)&msgMediaHeader2;
            }
            mediaHeader->ucFrameType= pstFrameNode->stFrameNode.ucFramPos;
            mediaHeader->usSeqId    = MOS_INET_HTONS(pstFrameNode->usSeqNum);
            mediaHeader->usChannel  = MOS_INET_HTONS(usChannel);
            mediaHeader->ucAVType   = trasTye;

            //if (trasTye == EN_HTTP_STREAMER_VIDEO)
            //MOS_PRINTF("---->av:%02d  chan:%d02  seqid:%04d  frameType:%02d,  size:%02d\n", mediaHeader->ucAVType, usChannel, pstFrameNode->usSeqNum, mediaHeader->ucFrameType, pstFrameNode->stFrameNode.uiNaluLen);
            iMsgBuffLen = pstFrameNode->stFrameNode.uiNaluLen + iHeaderSize;
            Http_EncMsgHead(&msgHeader, msgType, msgId, iMsgBuffLen, transEnc.iEncType);
            msgHeader.ucRsv = ucResSeq;

            MOS_MEMCPY(pucSendBuf, &msgHeader, sizeof(ST_OGCT_PROTOCAL_HEAD));
            MOS_MEMCPY(pucSendBuf+(sizeof(ST_OGCT_PROTOCAL_HEAD)), mediaHeader, iHeaderSize);
            MOS_MEMCPY(pucSendBuf+sizeof(ST_OGCT_PROTOCAL_HEAD)+iHeaderSize,
                       pstFrameNode->ptbuff, pstFrameNode->stFrameNode.uiNaluLen);
            _UI uiTotalSize = iHeaderSize+pstFrameNode->stFrameNode.uiNaluLen;

            Http_EncMsgBody2(&msgHeader, (_UC*)(pucSendBuf+(sizeof(ST_OGCT_PROTOCAL_HEAD))),
                             uiTotalSize, &transEnc, (_UC*)pucSendDataBuf, &pucOutLen);
            ((ST_P2PTURN_ADDRINFO*)hIceTrans)->pcbSendP2pData(((ST_P2PTURN_ADDRINFO*)hIceTrans)->pPrivateData, pucSendDataBuf, pucOutLen);
            //((ST_P2PTURN_ADDRINFO*)hIceTrans)->sendData(1, pucSendBuf, pucOutLen);
            if (iIsOneNode >= 1)
            {
                break;
            }
            pstFrameNode = pstFrameNode->pstnext;
        }
    }
    return MOS_OK;
}

/**
* @brief         get device info, not used now
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pProcessCmd:: procCmdGetDevInfo(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{
    _UC *pucMsgBuff  = NULL;
    _INT iMsgBuffLen = 0;
    _UC  uacSdkVersion[32] = {0};

    _UC aucMethod[8] = {0};
    {
        _UC *pucPhoneType = MOS_NULL;
        JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg, (_UC*)"BODY");
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"PhoneType"), &pucPhoneType);
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETDEVINFO_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId+1));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"DevName",Adpt_Json_CreateString("21CNSDK4.0"));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Version",Adpt_Json_CreateString(Config_GetSdkVersion(uacSdkVersion)));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"SdStatus",Adpt_Json_CreateString("1"));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Capacity",Adpt_Json_CreateString("10240"));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"FreeSpace",Adpt_Json_CreateString("512"));
    pucMsgBuff = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pucMsgBuff);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETDEVINFO_RESP,
                   pucMsgBuff, iMsgBuffLen);
    MOS_LOG_ERR(P2P_STRLOG,"send dev info method:%02X%02X pucMsgBuff:%s\n",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETDEVINFO_RESP, pucMsgBuff);
    MOS_FREE(pucMsgBuff);
    return MOS_OK;
}

/**
* @brief         process playback control response
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pProcessCmd::procCmdPlayBackResp(_HP2PCHANNEL hP2pChnnel, _US usChannel, _UI iSeqId, _UI iVodType)
{
    _UC *pucMsgBuff  = NULL;
    _INT iMsgBuffLen = 0;

    _UC aucMethod[8] = {0};
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_CONTROL_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId+1));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(usChannel));
    // Adpt_Json_AddItemToObject(hBody,(_UC*)"Vod",Adpt_Json_CreateStrWithNum(iVodType));
    // Adpt_Json_AddItemToObject(hBody,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
    pucMsgBuff = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pucMsgBuff);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_CONTROL_RESP,
                   pucMsgBuff, iMsgBuffLen);
    MOS_LOG_ERR(P2P_STRLOG,"send palyack info method:%02X%02X pucMsgBuff:%s\n",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_CONTROL_RESP, pucMsgBuff);
    MOS_FREE(pucMsgBuff);
    return MOS_OK;
}

/**
* @brief         process playback retrans feedback cmd
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pProcessCmd::procCmdPlayBackFeedBackResp(_HP2PCHANNEL hP2pChnnel, ST_MSGP2P_FEEDBACK  *param, _UC ucCmdType)
{
    _INT iMsgBuffLen = 0;
    ST_MSGP2P_FEEDBACK paramTemp;
    MOS_MEMCPY(&paramTemp, param, sizeof(ST_MSGP2P_FEEDBACK));

    if (ucCmdType == EN_FEED_BACK_NORMAL)
    {
        paramTemp.usChannel    = MOS_INET_HTONS(paramTemp.usChannel);
        paramTemp.usWinSize    = MOS_INET_HTONS(paramTemp.usWinSize);
        paramTemp.usWinBeginSeq= MOS_INET_HTONS(paramTemp.usWinBeginSeq);
        paramTemp.usNackCount  = MOS_INET_HTONS(0);
    }
    else  if (ucCmdType == EN_FEED_BACK_PAUSE_SENDDING)
    {
        paramTemp.ucPsrtMode   = EN_PST_MODE_TRS_NOLOSE_FSPEED;
        paramTemp.ucAckType    = EN_FEED_BACK_PAUSE_SENDDING;
        paramTemp.usChannel    = MOS_INET_HTONS(paramTemp.usChannel);
        paramTemp.usWinSize    = MOS_INET_HTONS(paramTemp.usWinSize);
        paramTemp.usWinBeginSeq= MOS_INET_HTONS(paramTemp.usWinBeginSeq);
        paramTemp.usNackCount  = MOS_INET_HTONS(0);
    }
    else  if (ucCmdType == EN_FEED_BACK_FINISH_SENDING)
    {
        paramTemp.ucPsrtMode   = EN_PST_MODE_TRS_NOLOSE_FSPEED;
        paramTemp.ucAckType    = EN_FEED_BACK_FINISH_SENDING;
        paramTemp.usChannel    = MOS_INET_HTONS(paramTemp.usChannel);
        paramTemp.usWinSize    = MOS_INET_HTONS(paramTemp.usWinSize);
        paramTemp.usWinBeginSeq= MOS_INET_HTONS(paramTemp.usWinBeginSeq);
        paramTemp.usNackCount  = MOS_INET_HTONS(0);
    }
    else  if (ucCmdType == EN_FEED_BACK_NOTIFY_ITERVEL)
    {
        paramTemp.ucPsrtMode   = EN_PST_MODE_TRS_LOSE_PACK;
        paramTemp.ucAckType    = EN_FEED_BACK_NOTIFY_ITERVEL;
        paramTemp.usChannel    = MOS_INET_HTONS(paramTemp.usChannel);
        paramTemp.usWinSize    = MOS_INET_HTONS(paramTemp.usWinSize);
        paramTemp.usWinBeginSeq= MOS_INET_HTONS(paramTemp.usWinBeginSeq);
        paramTemp.usNackCount  = MOS_INET_HTONS(0);
    }

    MOS_LOG_INF(P2P_STRLOG,"SEND feedback ucPackSeq:%d ackType:%d channel:%d winsize:%d, type:%d", paramTemp.ucPackSeq,
               paramTemp.ucAckType, MOS_INET_NTOHS(paramTemp.usChannel), MOS_INET_NTOHS(paramTemp.usWinBeginSeq), paramTemp.ucAvType);
    iMsgBuffLen = sizeof(ST_MSGP2P_FEEDBACK);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_FEEDBACK, EN_CN21_P2P_FEEDBACK_REQ,
                   (_UC*)&paramTemp, iMsgBuffLen);
    return MOS_OK;
}

/**
* @brief         call playback feedback entrance
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pProcessCmd::procCmdFeedBackResp(_HP2PCHANNEL hP2pChnnel, _UC ucAvType, _US usChannel, _UC ucCmdType, _US usWinSize, _UC ucPackSeq)
{
    ST_MSGP2P_FEEDBACK param;
    MOS_MEMSET(&param, 0, sizeof(param));
    param.ucAvType     = ucAvType;
    param.usChannel    = usChannel;
    param.usWinBeginSeq= usWinSize;
    param.ucPackSeq    = ucPackSeq;
    P2pProcessCmd::procCmdPlayBackFeedBackResp(hP2pChnnel, &param, ucCmdType);
    return MOS_OK;
}

/**
* @brief         process start live cmd
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pProcessCmd::procCmdStartLiveVideo(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{

    _UC *pStrTmp        = MOS_NULL;
    _INT iCamId         = 0;
    _INT iAudioId       = 0;
    _INT iStreamId      = 0;
    _INT iChannelId     = 0;
    _INT iCacheMediaTime= 0;
    _INT iMsgBuffLen    = 0;
    _UC aucMethod[8]    = {0};
    {
        JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg, (_UC*)"BODY");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"ChannelID"), &iChannelId);
        //Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"CamID"), &iCamId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"StreamID"), &iStreamId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"AudioID"), &iAudioId);
        MOS_LOG_INF(P2P_STRLOG,"##start live video iChannelId:%d _INT iCamId:%d, iStreamId:%d, iAudioId:%d", iChannelId, iCamId, iStreamId, iAudioId);
    }

    if (iStreamId > Config_GetCamaraMng()->uiStreamCnt)
    {
        iStreamId = 0;
    }

    _INT iMaxUser       = P2pManageMent::instance().getOnVideoClient();
    _INT iSessionDisable= (iMaxUser<Config_GetDeviceMng()->uiMaxSessionCnt) ? 0 : 1;
    JSON_HANDLE hRoot   = Adpt_Json_CreateObject();

    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTMEDIA_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iSessionDisable));

    if (iSessionDisable >= 1)
    {
        pStrTmp = Adpt_Json_Print(hRoot);
        Adpt_Json_Delete(hRoot);

        iMsgBuffLen = MOS_STRLEN(pStrTmp);
        procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTMEDIA_RESP,
                       pStrTmp, iMsgBuffLen);
        MOS_LOG_INF(P2P_STRLOG,"send start live failed,limmit maxuser:%d method:%02X%02X pucMsgBuff:%s",
                   iMaxUser, EN_OGCT_METHOD_CN21_CMD,
                   EN_CN21_P2P_CMD_STARTMEDIA_RESP, pStrTmp);
        MOS_FREE(pStrTmp);
        return MOS_OK;
    }

    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(iChannelId));

    ST_CFG_VIDEODES *pstVideoDes    = MOS_NULL;
    pstVideoDes  = Config_GetVideoDes(0, iStreamId);
    MOS_PARAM_NULL_RETERR(pstVideoDes);

    ST_ZJ_AUDIO_PARAM *pstAudioParam = Config_GetCamAudioParm(0);
    iCacheMediaTime = 1000*MAX_HISTORY_VIDEO_FRAME/pstVideoDes->stVideoPara.uiFramerate;
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CacheMaxTimeRange",Adpt_Json_CreateStrWithNum(iCacheMediaTime));

    JSON_HANDLE hVBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiEncodeType));
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiFramerate));
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"Width",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiWidth));
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"Height",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiHeight));
    Adpt_Json_AddItemToObject(hVBody,(_UC*)"LensType",Adpt_Json_CreateStrWithNum(0));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"VideoParam",hVBody);

    JSON_HANDLE hABody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hABody,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(pstAudioParam->uiEncodeType));
    Adpt_Json_AddItemToObject(hABody,(_UC*)"SampleRate",Adpt_Json_CreateStrWithNum(pstAudioParam->uiSampleRate));
    Adpt_Json_AddItemToObject(hABody,(_UC*)"Channel",Adpt_Json_CreateStrWithNum(pstAudioParam->uiChannel));
    Adpt_Json_AddItemToObject(hABody,(_UC*)"Depth",Adpt_Json_CreateStrWithNum(pstAudioParam->uiDepth));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"AudioParam",hABody);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pStrTmp);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTMEDIA_RESP,
                   pStrTmp, iMsgBuffLen);
    MOS_LOG_INF(P2P_STRLOG,"current onlne:%d maxuser:%d info method:%02X%02X pucMsgBuff:%s",
                iMaxUser, Config_GetDeviceMng()->uiMaxSessionCnt,
                EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTMEDIA_RESP, pStrTmp);
    MOS_FREE(pStrTmp);
    // 请求I帧
    if (ZJ_GetFuncTable()->pfunVideoNeedIFrame)
    {
        ZJ_GetFuncTable()->pfunVideoNeedIFrame(iStreamId, EN_ZJ_KEYFRAME_QUALITY_NORMAL);
    }
    procCmdFeedBackResp(hP2pChnnel, EN_ZJ_MEDIA_VIDEO, iChannelId, EN_FEED_BACK_NOTIFY_ITERVEL, iCacheMediaTime, 0);
    _INT iACacheMediaTime = 1000*MAX_HISTORY_AUDIO_FRAME*2/25;
    procCmdFeedBackResp(hP2pChnnel, EN_ZJ_MEDIA_AUDIO, iChannelId, EN_FEED_BACK_NOTIFY_ITERVEL, iACacheMediaTime, 0);
    P2pManageMent::instance().setClientStartLiveVideo(hP2pChnnel, iStreamId, iChannelId);
    Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, 1);
    MOS_LOG_INF(P2P_STRLOG,"live video cache msecond:%d , live audio cache:%d", iCacheMediaTime, iACacheMediaTime);
    return MOS_OK;
}

/**
* @brief         close live media
* @author        Hejh
* @date          2021-05-13
*/
_INT P2pProcessCmd::procCmdCloseLiveVideo(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{
    _INT iMsgBuffLen = 0;
    _UC *pStrTmp     = MOS_NULL;
    _INT iChannelId  = 0;
    _INT iCamId      = 0;
    _INT iStreamId   = 0;
    _INT iAudioId    = 0;
    _UC aucMethod[8] = {0};
    {
        JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg,(_UC*)"BODY");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"ChannelID"), &iChannelId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"CamID"), &iCamId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"StreamID"), &iStreamId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"AudioID"), &iAudioId);
        MOS_LOG_INF(P2P_STRLOG,"recive close live video iChannelId:%d iCamId:%d, iStreamId:%d, iAudioId:%d", iChannelId, iCamId, iStreamId, iAudioId);
    }

    P2pManageMent::instance().setClientCloseLiveVideo(hP2pChnnel, iStreamId);
    //Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, P2pManageMent::instance().getOnVideoClient(1)?1:0);
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPMEDIA_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(iChannelId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CamID", Adpt_Json_CreateStrWithNum(iCamId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"StreamID", Adpt_Json_CreateStrWithNum(iStreamId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"AudioID", Adpt_Json_CreateStrWithNum(iAudioId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pStrTmp);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPMEDIA_RESP,
                   pStrTmp, iMsgBuffLen);
    MOS_LOG_INF(P2P_STRLOG,"send close live video method:%02X%02X msg:%s",
               EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPMEDIA_RESP, pStrTmp);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdStartSpeaker(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{
    _UC *pStrTmp        = MOS_NULL;
    _INT iChannelId     = 0;
    _INT iMsgBuffLen    = 0;
    ST_ZJ_AUDIO_PARAM   audioParams = {0};
    _UC aucMethod[8]    = {0};
    {
        JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg, (_UC*)"BODY");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"ChannelID"), &iChannelId);

        JSON_HANDLE hAudioObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"AudioParam");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioObj,(_UC*)"EncType"), &audioParams.uiEncodeType);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioObj,(_UC*)"SampleRate"), &audioParams.uiSampleRate);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioObj,(_UC*)"Channel"), &audioParams.uiChannel);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioObj,(_UC*)"Depth"), &audioParams.uiDepth);
        MOS_LOG_INF(P2P_STRLOG,"##start speaker iChannelId:%d EncType:%u audiochannel:%u, depth:%u",
                   iChannelId, audioParams.uiEncodeType, audioParams.uiChannel, audioParams.uiDepth);
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();

    _INT bSpeakInValid = (P2pManageMent::instance().checkSpeakerClient());
    if (Config_GetCamaraMng()->uiSpkOpenFlag == MOS_TRUE)
    {
        bSpeakInValid = MOS_TRUE;
    }

    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTSPEAK_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(bSpeakInValid?1001:0));

    if (!bSpeakInValid)
    {
        JSON_HANDLE hBody = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(iChannelId));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"VideoFlag",Adpt_Json_CreateString("1"));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"AudioFlag",Adpt_Json_CreateStrWithNum(1));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    }

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pStrTmp);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTSPEAK_RESP,
                   pStrTmp, iMsgBuffLen);
    MOS_LOG_INF(P2P_STRLOG,"send speak response method:%02X%02X pucMsgBuff:%s",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTSPEAK_RESP, pStrTmp);
    MOS_FREE(pStrTmp);

#ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Pause_OpenTalk();
#endif    

    if ((!bSpeakInValid )&& (Config_GetCamaraMng()->uiSpkOpenFlag == MOS_FALSE))
    {
#ifdef BUILD_IMSSDK_FALG
        if (ImsMedia_GetTaskMng()->bEnableSpeaker)
        {
            MOS_LOG_INF(P2P_STRLOG, "ImsMedia Is Working");
            return MOS_OK;
        }
#endif
        MOS_LOG_ERR(P2P_STRLOG,"speaker channel is invalid:%d, uiSpkOpenFlag:%u !!!\n", bSpeakInValid, Config_GetCamaraMng()->uiSpkOpenFlag);
        #ifdef BUILD_ONBROADCAST_FALG
        Broadcast_Task_SetBroadcastState(BROADCAST_STATE_TALK);
        #endif   
        Config_SetCamerSpkOpenFlag(0, MOS_TRUE);            
        Media_AudioPlayCancelFrameBuff(MOS_NULL);
        ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
        Mos_MutexLock(&avClient->hMutex);
        getDiffTimems(&avClient->m_tReiveAudioDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
        avClient->m_bEnableSpeaker  = MOS_TRUE;
        avClient->m_sAudioSpeakChn  = iChannelId;
        avClient->m_hAudioPlay = Media_AudioPlayCreatWriteHandle(avClient->m_uacPeerId, iChannelId, &audioParams);
        Media_Notify_AudioPlay(avClient->m_uacPeerId, 1, avClient->m_bEnableSpeaker, iChannelId);
#ifdef BUILD_IMSSDK_FALG
        ImsMedia_SetP2pMedia((_VOID*)avClient);
#endif
        Mos_MutexUnLock(&avClient->hMutex);
        Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, 1);
        return MOS_OK;
    }

    MOS_LOG_ERR(P2P_STRLOG,"speaker channel is invalid:%d\n", bSpeakInValid);
    return MOS_ERR;
}

_INT P2pProcessCmd::procCmdCloseSpeaker(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{
    _INT iCamId         = 0;
    _INT iAudioId       = 0;
    _INT iStreamId      = 0;
    _INT iChannelId     = 0;
    _INT iMsgBuffLen    = 0;
    _UC *pStrTmp        = MOS_NULL;
    _UC aucMethod[8]    = {0};
    {
        JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg, (_UC*)"BODY");
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"ChannelID"), &iChannelId);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"“Code”"), &iCamId);
        MOS_LOG_INF(P2P_STRLOG,"recive close speaker iChannelId:%d iCamId:%d, iStreamId:%d, iAudioId:%d", iChannelId, iCamId, iStreamId, iAudioId);
    }

    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPTSPEAK_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(iChannelId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pStrTmp);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTSPEAK_RESP,
                   pStrTmp, iMsgBuffLen);
    MOS_LOG_INF(P2P_STRLOG,"send close speak resp method:%02X%02X msg:%s",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTSPEAK_RESP, pStrTmp);
    MOS_FREE(pStrTmp);

    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    Mos_MutexLock(&avClient->hMutex);
    if (avClient->m_bEnableSpeaker)
    {
        avClient->m_bEnableSpeaker  = MOS_FALSE;
        avClient->m_sAudioSpeakChn  =  0;
        Media_Notify_AudioPlay(avClient->m_uacPeerId, 1, avClient->m_bEnableSpeaker, iChannelId);
        Media_AudioPlayDestroyWriteHandle(avClient->m_hAudioPlay);
        avClient->m_hAudioPlay = MOS_NULL;
        Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
        //Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, P2pManageMent::instance().getOnVideoClient(1)?1:0);
    }
    
    Media_AudioPlayCancelFrameBuff(MOS_NULL);

#ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Resume_CloseTalk();
#endif    
    Mos_MutexUnLock(&avClient->hMutex);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdStartDisplay(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{
    _INT iChannelId      = 0; // 通话通道号
    _INT iCameraId       = 0; // 默认为0，NVR产品传摄像机序号
    _INT iSessionId      = 0; // 会话ID，用于同一个用户因网络变动使用新的连接恢复通话不被判断为占线中
    _INT iStreamId       = 0; // 点播的实时媒体通道ID,-1:不带视频，0：主码流，1：次码流
    _INT iAudioId        = 0; // 音频ID,默认为1，-1为不带音频
    _INT iVideoEncPrior  = 0; // 客户端优先使用的视频编码类型
    _INT iVideoEncSpt    = 0; // 客户端支持的视频编码类型,由多个编码类型值使⽤或运算得到的整型值
    _INT iVideoDncSpt    = 0; // 客户端支持的视频解码类型,由多个编码类型值使⽤或运算得到的整型值
    _INT iAudioEncSpt    = 0; // 客户端支持的音频编码类型,由多个编码类型值使⽤或运算得到的整型值
    _INT iAudioDncSpt    = 0; // 客户端支持的音频解码类型,由多个编码类型值使⽤或运算得到的整型值
    _INT iVideoOutStatus = 0; // 客户端是否输出视频数据 "0:关闭输出；1:开启输出"
    _INT iAudioOutStatus = 0; // 客户端是否输出音频数据 "0:关闭输出；1:开启输出"
    _INT iOnHoldStatus   = 0; // 是否等待接听  0:不需接听端接听⽽直接开始通话；1:需要等待接听端接听后开始通话
    _INT iOnHoldTime     = 0; // 等待接听超时时间，单位秒
    _UC aucMethod[8]     = {0};       // 回复方法字
    _INT bSpeakInValid   = MOS_FALSE; // 是否正在接收音频进行播放(是否占用中)
    _INT bDisplayInValid = MOS_FALSE; // 是否正在接收视频进行显示(是否占用中)
    _INT iVideoCode      = 0;         // 视频错误码
    _INT iAudioCode      = 0;         // 音频错误码
    ST_ZJ_VIDEO_PARAM stVideoPlayInf = {0};      // 双向视频通话对端出流信息
    ST_CFG_VIDEODES *pstVideoDes     = MOS_NULL; // 双向视频通话本端出流信息

    JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg, (_UC*)"BODY");
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"ChannelID"),     &iChannelId);     // 通话通道号
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"CamID"),         &iCameraId);      // 默认为0，NVR产品传摄像机序号
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"SessionID"),     &iSessionId);      // 会话ID，用于同一个用户因网络变动使用新的连接恢复通话不被判断为占线中
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"StreamID"),      &iStreamId);      // 点播的实时媒体通道ID,-1:不带视频，0：主码流，1：次码流
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"AudioID"),       &iAudioId);       // 音频ID,默认为1，-1为不带音频
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"VideoEncSpt"),   &iVideoEncSpt);   // 客户端支持的视频编码类型,由多个编码类型值使⽤或运算得到的整型值
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"VideoDecSpt"),   &iVideoDncSpt);   // 客户端支持的视频解码类型,由多个编码类型值使⽤或运算得到的整型值
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"AudioEncSpt"),   &iAudioEncSpt);   // 客户端支持的音频编码类型,由多个编码类型值使⽤或运算得到的整型值
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"AudioDecSpt"),   &iAudioDncSpt);   // 客户端支持的音频解码类型,由多个编码类型值使⽤或运算得到的整型值
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"OnHold"),        &iOnHoldStatus);  // 是否等待接听  0:不需接听端接听⽽直接开始通话；1:需要等待接听端接听后开始通话
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"OnHoldTime"),    &iOnHoldTime);    // 等待接听超时时间，单位秒

    JSON_HANDLE hVideoOutObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"VideoOut");
    JSON_HANDLE hAudioOutObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"AudioOut");
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoOutObj,(_UC*)"Status"),    &iVideoOutStatus); // 客户端是否输出视频数据 "0:关闭输出；1:开启输出"
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoOutObj,(_UC*)"EncType"),   &iVideoEncPrior);  // 客户端优先使用的视频编码类型
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioOutObj,(_UC*)"Status"),    &iAudioOutStatus); // 客户端是否输出音频数据 "0:关闭输出；1:开启输出"
    
    MOS_LOG_INF(P2P_STRLOG,"##start Display iChannelId:%d CamID:%u SessionId:%u StreamID:%u AudioID:%u VideoEncSpt:%d VideoDncSpt:%d AudioEncSpt:%d AudioDncSpt:%d OnHoldStatus:%d OnHoldTime:%d",
                    iChannelId, iCameraId, iSessionId, iStreamId, iAudioId,iVideoEncSpt,iVideoDncSpt,iAudioEncSpt,iAudioDncSpt,iOnHoldStatus,iOnHoldTime);
    MOS_LOG_INF(P2P_STRLOG,"##start Display VideoOutStatus:%d VideoEncPrior:%d AudioOutStatus:%u",iVideoOutStatus, iVideoEncPrior, iAudioOutStatus);

    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    hRoot  = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTDISPLAY_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(iChannelId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CacheMaxTimeRange",Adpt_Json_CreateStrWithNum(5000)); // 最大缓存的实时视频时间范围值，单位毫秒
    Adpt_Json_AddItemToObject(hBody,(_UC*)"OnHold",Adpt_Json_CreateStrWithNum(0));

    if ((Config_GetCamaraMng()->uiWithScreenAbility) && ((Config_GetCamaraMng()->uiVideoPlayAbility & EN_ZJ_VIDEOPLAY_ABILITY_P2P) == EN_ZJ_VIDEOPLAY_ABILITY_P2P))
    {
        MOS_MEMCPY(&stVideoPlayInf, &Config_GetCamaraMng()->stVideoPlayInf, sizeof(ST_ZJ_VIDEO_PARAM));

        _UI uiCommonEncAbility = Config_GetCamaraMng()->stVideoPlaySupport.uiVideoEncAbility & iVideoEncSpt;
        if (uiCommonEncAbility == EN_ZJ_VIDEOENC_TYPE_H264)
        {
            stVideoPlayInf.uiEncodeType  = EN_ZJ_VIDEOENC_TYPE_H264;
        }
        else if (uiCommonEncAbility == EN_ZJ_VIDEOENC_TYPE_H265)
        {
            stVideoPlayInf.uiEncodeType  = EN_ZJ_VIDEOENC_TYPE_H265;
        }
        else if (uiCommonEncAbility == EN_ZJ_VIDEOENC_TYPE_JPEG)
        {
            stVideoPlayInf.uiEncodeType  = EN_ZJ_VIDEOENC_TYPE_JPEG;
        }
        else
        {
            if ((uiCommonEncAbility & iVideoEncPrior) > 0)
            {
                stVideoPlayInf.uiEncodeType  = iVideoEncPrior;
            }
            else
            {
                if ((uiCommonEncAbility & EN_ZJ_VIDEOENC_TYPE_H265) == EN_ZJ_VIDEOENC_TYPE_H265)
                {
                    stVideoPlayInf.uiEncodeType  = EN_ZJ_VIDEOENC_TYPE_H265;
                }
                else if ((uiCommonEncAbility & EN_ZJ_VIDEOENC_TYPE_H264) == EN_ZJ_VIDEOENC_TYPE_H264)
                {
                    stVideoPlayInf.uiEncodeType  = EN_ZJ_VIDEOENC_TYPE_H264;
                }
                else if ((uiCommonEncAbility & EN_ZJ_VIDEOENC_TYPE_JPEG) == EN_ZJ_VIDEOENC_TYPE_JPEG)
                {
                    stVideoPlayInf.uiEncodeType  = EN_ZJ_VIDEOENC_TYPE_JPEG;
                }
                else
                {
                    iVideoCode = EN_P2P_ERROR_CODE_P2P_ENC_NOT_SUPPORTED;
                }                    
            }
        }

        P2pManageMent::instance().CloseClientSpeakerAndDisplay(0, 1, iSessionId);
        
        //需要接收客户端的视频
        if (iVideoOutStatus == 1) 
        {
            if ((P2pManageMent::instance().checkDisplayClient() == MOS_TRUE) || (Config_GetCamaraMng()->uiDisPlayOpenFlag == MOS_TRUE))
            {
                bDisplayInValid = MOS_TRUE;
                iVideoCode      = EN_P2P_ERROR_CODE_P2P_DISPLAY_OCCUOIED;
                MOS_LOG_ERR(P2P_STRLOG,"display channel is invalid:%d, uiDisPlayOpenFlag:%u !!!\n", bDisplayInValid, Config_GetCamaraMng()->uiDisPlayOpenFlag);
            }
            else if ((Config_GetCamaraMng()->stVideoPlaySupport.uiVideoEncAbility & iVideoEncSpt) <= 0)
            {
                iVideoCode = EN_P2P_ERROR_CODE_P2P_ENC_NOT_SUPPORTED;
                MOS_LOG_ERR(P2P_STRLOG,"dev is not support app enc, dev(%d) app(%d)!!!\n", Config_GetCamaraMng()->stVideoPlaySupport.uiVideoEncAbility, iVideoEncSpt);
            }
        }

        //需要接收客户端的音频
        if (iAudioOutStatus == 1) 
        {
            if ((P2pManageMent::instance().checkSpeakerClient() == MOS_TRUE) || (Config_GetCamaraMng()->uiSpkOpenFlag == MOS_TRUE))
            {
                bSpeakInValid = MOS_TRUE;
                iAudioCode    = EN_P2P_ERROR_CODE_P2P_DISPLAY_OCCUOIED;
                MOS_LOG_ERR(P2P_STRLOG,"speaker channel is invalid:%d, uiSpkOpenFlag:%u !!!\n", bSpeakInValid, Config_GetCamaraMng()->uiSpkOpenFlag);
            }
        }
    }
    else
    {
        MOS_LOG_ERR(P2P_STRLOG,"display WithScreenAbility:%d  VideoPlayAbility:%d\n", Config_GetCamaraMng()->uiWithScreenAbility, Config_GetCamaraMng()->uiVideoPlayAbility);
        iVideoCode = EN_P2P_ERROR_CODE_P2P_ABILITY_NOSET;
    }

    /*应答错误码计算*/
    _INT iP2pRspCode = 0;
    if (iVideoCode == EN_P2P_ERROR_CODE_P2P_ENC_NOT_SUPPORTED)
    {
        iP2pRspCode = EN_P2P_ERROR_CODE_P2P_ENC_NOT_SUPPORTED;
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("dev is not support app enc type"));
    }
    else if(iVideoCode == EN_P2P_ERROR_CODE_P2P_DEC_NOT_SUPPORTED)
    {
        iP2pRspCode = EN_P2P_ERROR_CODE_P2P_DEC_NOT_SUPPORTED;
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("app is not support dev enc type"));
    }
    else if(iVideoCode == EN_P2P_ERROR_CODE_P2P_ABILITY_NOSET)
    {
        iP2pRspCode = EN_P2P_ERROR_CODE_P2P_ABILITY_NOSET;
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("dev is not support display"));
    }
    else if((iAudioCode == EN_P2P_ERROR_CODE_P2P_DISPLAY_OCCUOIED) || (iVideoCode == EN_P2P_ERROR_CODE_P2P_DISPLAY_OCCUOIED))
    {
        iP2pRspCode = EN_P2P_ERROR_CODE_P2P_DISPLAY_OCCUOIED;
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("dev is occuoied"));
    }
    else
    {
        iP2pRspCode = 0;
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"MSG",Adpt_Json_CreateString("ok"));
    }

    if (iP2pRspCode == 0)
    {
        ST_ZJ_AUDIO_PARAM audioParams = {0};
        audioParams.uiEncodeType = EN_ZJ_AUDIOENC_TYPE_G711A;
        audioParams.uiSampleRate = 8000;
        audioParams.uiChannel    = 1;
        audioParams.uiDepth      = 16;

        ST_AVCLIENT_INFO *avClientTmp = (ST_AVCLIENT_INFO*)hP2pChnnel;
        Mos_MutexLock(&avClientTmp->hMutex);
        avClientTmp->m_iSessionId = iSessionId;
        Mos_MutexUnLock(&avClientTmp->hMutex);

        // 本机输出视频流的参数
        JSON_HANDLE hVideoOut = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hBody,(_UC*)"VideoOut",hVideoOut);

        //客户端需要设备传输本端视频
        if ((iStreamId != -1) && ((iStreamId == 0) || (iStreamId == 1))) 
        {
            Adpt_Json_AddItemToObject(hVideoOut,(_UC*)"Status",   Adpt_Json_CreateStrWithNum(1));
            pstVideoDes  = Config_GetVideoDes(0, iStreamId);
            if (pstVideoDes != MOS_NULL)
            {
                if ((pstVideoDes->stVideoPara.uiEncodeType & iVideoDncSpt) > 0) // 开始推流给客户端
                {
                    // 请求I帧
                    if (ZJ_GetFuncTable()->pfunVideoNeedIFrame)
                    {
                        ZJ_GetFuncTable()->pfunVideoNeedIFrame(iStreamId, EN_ZJ_KEYFRAME_QUALITY_NORMAL);
                    }
                    P2pManageMent::instance().setClientStartLiveForVideo(hP2pChnnel, iStreamId, iChannelId);
                    Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, 1);

                    Adpt_Json_AddItemToObject(hVideoOut,(_UC*)"EncType",  Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiEncodeType));
                    Adpt_Json_AddItemToObject(hVideoOut,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiFramerate));
                    Adpt_Json_AddItemToObject(hVideoOut,(_UC*)"Width",    Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiWidth));
                    Adpt_Json_AddItemToObject(hVideoOut,(_UC*)"Height",   Adpt_Json_CreateStrWithNum(pstVideoDes->stVideoPara.uiHeight));
                    Adpt_Json_AddItemToObject(hVideoOut,(_UC*)"LensType", Adpt_Json_CreateStrWithNum(0));                
                }
                else
                {
                    MOS_LOG_ERR(P2P_STRLOG,"App no support dev enc type, the dev EncodeType is :%d, app EncodeType :%d !!!\n", pstVideoDes->stVideoPara.uiEncodeType, iVideoDncSpt);
                }
            }
            else
            {
                MOS_LOG_ERR(P2P_STRLOG,"App no support dev enc type, the dev EncodeType is not Set\n");
            }
        }
        else
        {
            Adpt_Json_AddItemToObject(hVideoOut,(_UC*)"Status",   Adpt_Json_CreateStrWithNum(0));
        }

        // 本机输出音频流的参数
        JSON_HANDLE hAudioOut = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hBody,(_UC*)"AudioOut",hAudioOut);
        Adpt_Json_AddItemToObject(hAudioOut,(_UC*)"EncType",   Adpt_Json_CreateStrWithNum(audioParams.uiEncodeType));
        Adpt_Json_AddItemToObject(hAudioOut,(_UC*)"SampleRate",Adpt_Json_CreateStrWithNum(audioParams.uiSampleRate));
        Adpt_Json_AddItemToObject(hAudioOut,(_UC*)"Channel",   Adpt_Json_CreateStrWithNum(audioParams.uiChannel));
        Adpt_Json_AddItemToObject(hAudioOut,(_UC*)"Depth",     Adpt_Json_CreateStrWithNum(audioParams.uiDepth)); 
        //客户端需要设备传输本端音频
        if (iAudioId != -1)
        {
            Adpt_Json_AddItemToObject(hAudioOut,(_UC*)"Status",   Adpt_Json_CreateStrWithNum(1));
            P2pManageMent::instance().setClientStartLiveForAudio(hP2pChnnel, iChannelId);
        }
        else
        {
            Adpt_Json_AddItemToObject(hAudioOut,(_UC*)"Status",   Adpt_Json_CreateStrWithNum(0));
        }

        // 要求对端输出视频流的参数
        JSON_HANDLE hVideoIn = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hBody,(_UC*)"VideoIn",hVideoIn);
        Adpt_Json_AddItemToObject(hVideoIn,(_UC*)"Status",   Adpt_Json_CreateStrWithNum(iVideoOutStatus));
        Adpt_Json_AddItemToObject(hVideoIn,(_UC*)"EncType",  Adpt_Json_CreateStrWithNum(stVideoPlayInf.uiEncodeType));
        Adpt_Json_AddItemToObject(hVideoIn,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(stVideoPlayInf.uiFramerate));
        Adpt_Json_AddItemToObject(hVideoIn,(_UC*)"Width",    Adpt_Json_CreateStrWithNum(stVideoPlayInf.uiWidth));
        Adpt_Json_AddItemToObject(hVideoIn,(_UC*)"Height",   Adpt_Json_CreateStrWithNum(stVideoPlayInf.uiHeight));
        //需要接收客户端的视频
        if (iVideoOutStatus == 1) 
        {
            if (bDisplayInValid != MOS_TRUE)
            {
                MOS_LOG_INF(P2P_STRLOG,"display channel is invalid:%d, uiDisPlayOpenFlag:%u !!!\n", bDisplayInValid, Config_GetCamaraMng()->uiDisPlayOpenFlag);
                Config_SetCamerDisplayOpenFlag(0, MOS_TRUE);            
                Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
                ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
                Mos_MutexLock(&avClient->hMutex);
                getDiffTimems(&avClient->m_tReiveVideoDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
                avClient->m_bEnableDisplay    = MOS_TRUE;
                avClient->m_sVideoDisplayChn  = iChannelId;
                avClient->m_hVideoPlay        = Media_VideoDisPlayCreatHandle(avClient->m_uacPeerId, &stVideoPlayInf);
                Media_Notify_VideoPlay(avClient->m_uacPeerId, avClient->m_bEnableDisplay);

                P2pManageMent::instance().P2pCreateTbsl((_VPTR)hP2pChnnel, kj_tbsl_loss_selectively, kj_av_type_video);

                Mos_MutexUnLock(&avClient->hMutex);
            }            
        }        

        // 要求对端输出音频流的参数
        JSON_HANDLE hAudioIn = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hBody,(_UC*)"AudioIn",hAudioIn);
        Adpt_Json_AddItemToObject(hAudioIn,(_UC*)"Status",   Adpt_Json_CreateStrWithNum(iAudioOutStatus));
        Adpt_Json_AddItemToObject(hAudioIn,(_UC*)"EncType",   Adpt_Json_CreateStrWithNum(audioParams.uiEncodeType));
        Adpt_Json_AddItemToObject(hAudioIn,(_UC*)"SampleRate",Adpt_Json_CreateStrWithNum(audioParams.uiSampleRate));
        Adpt_Json_AddItemToObject(hAudioIn,(_UC*)"Channel",   Adpt_Json_CreateStrWithNum(audioParams.uiChannel));
        Adpt_Json_AddItemToObject(hAudioIn,(_UC*)"Depth",     Adpt_Json_CreateStrWithNum(audioParams.uiDepth));
        //需要接收客户端的音频
        if (iAudioOutStatus == 1) 
        {
            if (bSpeakInValid != MOS_TRUE)
            {
                #ifdef BUILD_ONBROADCAST_FALG
                Broadcast_Task_Pause_OpenTalk();
                Broadcast_Task_SetBroadcastState(BROADCAST_STATE_TALK);
                #endif   
                MOS_LOG_INF(P2P_STRLOG,"speaker channel is invalid:%d, uiSpkOpenFlag:%u !!!\n", bSpeakInValid, Config_GetCamaraMng()->uiSpkOpenFlag);
                Config_SetCamerSpkOpenFlag(0, MOS_TRUE);            
                Media_AudioPlayCancelFrameBuff(MOS_NULL);
                ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
                Mos_MutexLock(&avClient->hMutex);
                getDiffTimems(&avClient->m_tReiveAudioDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
                avClient->m_bEnableSpeaker    = MOS_TRUE;
                avClient->m_sAudioSpeakChn    = iChannelId;       
                avClient->m_hAudioPlay   = Media_AudioPlayCreatWriteHandle(avClient->m_uacPeerId, iChannelId, &audioParams);
                Media_Notify_AudioPlay(avClient->m_uacPeerId, 1, avClient->m_bEnableSpeaker, iChannelId);
                P2pManageMent::instance().P2pCreateTbsl((_VPTR)hP2pChnnel, kj_tbsl_loss_selectively, kj_av_type_audio);
                Mos_MutexUnLock(&avClient->hMutex);
                Config_AppSLeepMonotorUpdateStatus(P2p_GetTaskMng()->uiSleepMonitorId, 1);
            }
        }

        if ((iVideoOutStatus == 1) || (iAudioOutStatus == 1))
        {
            #ifdef BUILD_IMSSDK_FALG
            ImsMedia_SetP2pMedia((_VOID*)hP2pChnnel);
            #endif
        }   
    }

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iP2pRspCode));

    _UC *pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    _INT iMsgBuffLen = MOS_STRLEN(pStrTmp);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTDISPLAY_RESP, pStrTmp, iMsgBuffLen);
    MOS_LOG_INF(P2P_STRLOG,"send display response method:%02X%02X pucMsgBuff:%s",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STARTDISPLAY_RESP, pStrTmp);
    MOS_FREE(pStrTmp);

    return MOS_OK;
}

_INT P2pProcessCmd::procCmdCloseDisplay(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{
    _INT iChannelId     = 0;
    _INT iCameraId      = 0;
    _INT iMsgBuffLen    = 0;
    _UC *pStrTmp        = MOS_NULL;
    _UC aucMethod[8]    = {0};
    
    JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg, (_UC*)"BODY");
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"CamID"),     &iCameraId); // 通话通道号
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"ChannelID"), &iChannelId);// 默认为0，NVR产品传摄像机序号
    MOS_LOG_INF(P2P_STRLOG,"recive close display iChannelId:%d", iChannelId);
 
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPTDISPLAY_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CamID",Adpt_Json_CreateStrWithNum(iCameraId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(iChannelId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pStrTmp);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPTDISPLAY_RESP, pStrTmp, iMsgBuffLen);
    MOS_LOG_INF(P2P_STRLOG,"send close display resp method:%02X%02X msg:%s",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_STOPTDISPLAY_RESP, pStrTmp);
    MOS_FREE(pStrTmp);

    // 停止推视频流与音频流
    P2pManageMent::instance().setClientCloseLiveAll(hP2pChnnel);

    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    Mos_MutexLock(&avClient->hMutex);
    // 关闭本机视频显示
    {
        if (avClient->m_bEnableDisplay == MOS_TRUE)
        {        
            P2pManageMent::instance().P2pDestroyTbsl((_VPTR)hP2pChnnel, kj_av_type_video);

            avClient->m_bEnableDisplay  = MOS_FALSE;
            avClient->m_sVideoDisplayChn  =  0;
            Media_Notify_VideoPlay(avClient->m_uacPeerId, avClient->m_bEnableDisplay);
            Media_VideoDisPlayDestroyHandle(avClient->m_hVideoPlay);  
            avClient->m_hVideoPlay = MOS_NULL;
            Config_SetCamerDisplayOpenFlag(0, MOS_FALSE);
        }
        Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
    }

    // 关闭本机对讲
    {
        if (avClient->m_bEnableSpeaker)
        {
            P2pManageMent::instance().P2pDestroyTbsl((_VPTR)hP2pChnnel, kj_av_type_audio);

            avClient->m_bEnableSpeaker  = MOS_FALSE;
            avClient->m_sAudioSpeakChn  =  0;
            Media_Notify_AudioPlay(avClient->m_uacPeerId, 1, avClient->m_bEnableSpeaker, iChannelId);
            Media_AudioPlayDestroyWriteHandle(avClient->m_hAudioPlay);
            avClient->m_hAudioPlay = MOS_NULL;
            Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
        } 
        Media_AudioPlayCancelFrameBuff(MOS_NULL);

        #ifdef BUILD_ONBROADCAST_FALG
        Broadcast_Task_Resume_CloseTalk();
        #endif
    }

    Mos_MutexUnLock(&avClient->hMutex);
    return MOS_OK;
}

/*
控制信令类型字：0x23 ⽅法字：0x2C
通话控制信令包括接听通话、⾳视频输出和⾳视频接收控制三⼤信令。其中接听通话信令只能由接听⽅发起，其余双⽅在通话中均可主动发起。
当Type的值为0x01时，VideoOut、AudioOut、VideoIn、AudioIn均可为空，此时使⽤开始通话时协商好的
编码和状态进⾏⾳视频推流和接收处理。
当Type值与运算0x02为真时，VideoOut、AudioOut不可为空，通过Status字段控制⾳视频输出状态，其他保
持与通话时协商好的值保持⼀致。
当Type值与运算0x04为真时，VideoIn、AudioIn不可为空，通过Status字段控制⾳视频的接收状态，其他保
持与通话时协商好的值保持⼀致。*/
_INT P2pProcessCmd::procCmdContorlDisplay(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{
    _INT iChannelId      = 0;  // 通话通道号
    _INT iCameraId       = 0;  // 默认为0，NVR产品传摄像机序号
    _INT iType           = 0;  // 控制信令的类型
    _INT iVideoOutStatus = 0;  // 客户端是否输出视频数据 "0:关闭输出；1:开启输出"
    _INT iAudioOutStatus = 0;  // 客户端是否输出音频数据 "0:关闭输出；1:开启输出"
    _INT iVideoInStatus  = 0;  // 客户端是否接收视频数据 "0:关闭接收；1:开启接收"
    _INT iAudioInStatus  = 0;  // 客户端是否接收音频数据 "0:关闭接收；1:开启接收"
    _INT iMsgBuffLen     = 0;
    _UC *pStrTmp         = MOS_NULL;
    _UC aucMethod[8]     = {0};

    ST_ZJ_VIDEO_PARAM stVideoPlayInf = {0};      // 双向视频通话对端出流信息
    
    JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg, (_UC*)"BODY");
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"CamID"),     &iCameraId); 
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"ChannelID"), &iChannelId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"Type"),      &iType);
    MOS_LOG_INF(P2P_STRLOG,"recive contorl display iCameraId:%d, iChannelId:%d, iType:%d", iCameraId, iChannelId, iType);
 
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_CONTORLDISPLAY_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));

    ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    Mos_MutexLock(&avClient->hMutex);
    if ((avClient->m_bEnableVideo == 0) && (avClient->m_bEnableAudio == 0) && (avClient->m_bEnableDisplay == 0) && (avClient->m_bEnableSpeaker == 0))
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(-1));
    }
    else
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

        // 当Type值与运算0x02为真时，VideoOut、AudioOut不可为空，通过Status字段控制⾳视频输出状态，其他保
        // 持与通话时协商好的值保持⼀致。
        if ((iType & 0x02) > 0)
        {
            JSON_HANDLE hVideoOutObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"VideoOut");
            JSON_HANDLE hAudioOutObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"AudioOut");

            if ((hVideoOutObj != MOS_NULL) && (hAudioOutObj != MOS_NULL))
            {
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoOutObj,(_UC*)"Status"), &iVideoOutStatus);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioOutObj,(_UC*)"Status"), &iAudioOutStatus);

                if (iVideoOutStatus != avClient->m_bEnableDisplay)
                {
                    MOS_LOG_INF(P2P_STRLOG,"contorl VideoOutStatus:%d  !!!\n", iVideoOutStatus);

                    if (iVideoOutStatus == 0)
                    {
                        P2pManageMent::instance().P2pDestroyTbsl((_VPTR)hP2pChnnel, kj_av_type_video);

                        avClient->m_bEnableDisplay  = MOS_FALSE;
                        avClient->m_sVideoDisplayChn  =  0;
                        Media_Notify_VideoPlay(avClient->m_uacPeerId, avClient->m_bEnableDisplay);
                        Media_VideoDisPlayDestroyHandle(avClient->m_hVideoPlay);  
                        avClient->m_hVideoPlay = MOS_NULL;
                        Config_SetCamerDisplayOpenFlag(0, MOS_FALSE);

                        Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
                    }
                    else
                    {
                        MOS_MEMCPY(&stVideoPlayInf, &Config_GetCamaraMng()->stVideoPlayInf, sizeof(ST_ZJ_VIDEO_PARAM));

                        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoOutObj,(_UC*)"EncType"),   &stVideoPlayInf.uiEncodeType);
                        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoOutObj,(_UC*)"FrameRate"), &stVideoPlayInf.uiFramerate);
                        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoOutObj,(_UC*)"Width"),     &stVideoPlayInf.uiWidth);
                        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoOutObj,(_UC*)"Height"),    &stVideoPlayInf.uiHeight);

                        Config_SetCamerDisplayOpenFlag(0, MOS_TRUE);            
                        Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
                        getDiffTimems(&avClient->m_tReiveVideoDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
                        avClient->m_bEnableDisplay    = MOS_TRUE;
                        avClient->m_sVideoDisplayChn  = iChannelId;
                        avClient->m_hVideoPlay        = Media_VideoDisPlayCreatHandle(avClient->m_uacPeerId, &stVideoPlayInf);
                        Media_Notify_VideoPlay(avClient->m_uacPeerId, avClient->m_bEnableDisplay);

                        P2pManageMent::instance().P2pCreateTbsl((_VPTR)hP2pChnnel, kj_tbsl_loss_selectively, kj_av_type_video);
                    }
                }

                if (iAudioOutStatus != avClient->m_bEnableSpeaker)
                {
                    MOS_LOG_INF(P2P_STRLOG,"contorl AudioOutStatus:%d  !!!\n", iAudioOutStatus);

                    if (iAudioOutStatus == 0)
                    {
                        P2pManageMent::instance().P2pDestroyTbsl((_VPTR)hP2pChnnel, kj_av_type_audio);

                        avClient->m_bEnableSpeaker  = MOS_FALSE;
                        avClient->m_sAudioSpeakChn  =  0;
                        Media_Notify_AudioPlay(avClient->m_uacPeerId, 1, avClient->m_bEnableSpeaker, iChannelId);
                        Media_AudioPlayDestroyWriteHandle(avClient->m_hAudioPlay);
                        avClient->m_hAudioPlay = MOS_NULL;
                        Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                        Media_AudioPlayCancelFrameBuff(MOS_NULL);

                        #ifdef BUILD_ONBROADCAST_FALG
                        Broadcast_Task_Resume_CloseTalk();
                        #endif
                    }
                    else
                    {
                        #ifdef BUILD_ONBROADCAST_FALG
                        Broadcast_Task_Pause_OpenTalk();
                        Broadcast_Task_SetBroadcastState(BROADCAST_STATE_TALK);
                        #endif

                        ST_ZJ_AUDIO_PARAM audioParams = {0};   
                        audioParams.uiEncodeType = EN_ZJ_AUDIOENC_TYPE_G711A;
                        audioParams.uiSampleRate = 8000;
                        audioParams.uiChannel    = 1;
                        audioParams.uiDepth      = 16;  

                        Config_SetCamerSpkOpenFlag(0, MOS_TRUE);            
                        Media_AudioPlayCancelFrameBuff(MOS_NULL);
                        ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
                        getDiffTimems(&avClient->m_tReiveAudioDataTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
                        avClient->m_bEnableSpeaker    = MOS_TRUE;
                        avClient->m_sAudioSpeakChn    = iChannelId;       
                        avClient->m_hAudioPlay   = Media_AudioPlayCreatWriteHandle(avClient->m_uacPeerId, iChannelId, &audioParams);
                        Media_Notify_AudioPlay(avClient->m_uacPeerId, 1, avClient->m_bEnableSpeaker, iChannelId);

                        P2pManageMent::instance().P2pCreateTbsl((_VPTR)hP2pChnnel, kj_tbsl_loss_selectively, kj_av_type_audio);
                    }
                }

                if ((iVideoOutStatus == 1) || (iAudioOutStatus == 1))
                {
                    #ifdef BUILD_IMSSDK_FALG
                    ImsMedia_SetP2pMedia((_VOID*)hP2pChnnel);
                    #endif
                }
            }
            else
            {
                MOS_LOG_ERR(P2P_STRLOG,"App Output Param Is Error, iType(%d) VideoOut(%p), VideoOut(%p)\n",iType, hVideoOutObj, hAudioOutObj);
            }
        }

        // 当Type值与运算0x04为真时，VideoIn、AudioIn不可为空，通过Status字段控制⾳视频的接收状态，其他保
        // 持与通话时协商好的值保持⼀致。
        if ((iType & 0x04) > 0)
        {
            JSON_HANDLE hVideoInObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"VideoIn");
            JSON_HANDLE hAudioInObj = Adpt_Json_GetObjectItem(hDataObj, (_UC*)"AudioIn");

            if ((hVideoInObj != MOS_NULL) && (hAudioInObj != MOS_NULL))
            {
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hVideoInObj,(_UC*)"Status"), &iVideoInStatus);
                Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hAudioInObj,(_UC*)"Status"), &iAudioInStatus);

                if (iVideoInStatus != avClient->m_bEnableVideo)
                {
                    MOS_LOG_INF(P2P_STRLOG,"contorl VideoInStatus:%d  !!!\n", iVideoInStatus);

                    if (iVideoInStatus == 0)
                    {
                        avClient->m_bEnableVideo    = MOS_FALSE;
                    }
                    else
                    {
                        // 请求I帧
                        if (ZJ_GetFuncTable()->pfunVideoNeedIFrame)
                        {
                            ZJ_GetFuncTable()->pfunVideoNeedIFrame(avClient->m_ucStreamId, EN_ZJ_KEYFRAME_QUALITY_NORMAL);
                        }

                        avClient->m_bEnableVideo    = MOS_TRUE;
                        avClient->m_ucStreamId      = avClient->m_ucStreamId;
                        avClient->m_ucNeedIframe    = MOS_TRUE;
                        avClient->m_sLiveVideoChn   = iChannelId;
                    }
                }

                if (iAudioInStatus != avClient->m_bEnableAudio)
                {
                    MOS_LOG_INF(P2P_STRLOG,"contorl AudioInStatus:%d  !!!\n", iAudioInStatus);

                    if (iAudioInStatus == 0)
                    {
                        avClient->m_bEnableAudio    = MOS_FALSE;
                    }
                    else
                    {
                        avClient->m_bEnableAudio    = MOS_TRUE;
                        avClient->m_sLiveAudioChn   = iChannelId;
                    }
                }
            }
            else
            {
                MOS_LOG_ERR(P2P_STRLOG,"App Input Param Is Error, iType(%d) VideoOut(%p), VideoOut(%p)\n",iType, hVideoInObj, hAudioInObj);
            }            
        }
    }
    Mos_MutexUnLock(&avClient->hMutex);

    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CamID",Adpt_Json_CreateStrWithNum(iCameraId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(iChannelId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pStrTmp);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_CONTORLDISPLAY_RESP, pStrTmp, iMsgBuffLen);
    MOS_LOG_INF(P2P_STRLOG,"send contorl display resp method:%02X%02X msg:%s",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_CONTORLDISPLAY_RESP, pStrTmp);
    MOS_FREE(pStrTmp);

    return MOS_OK;
}

_INT P2pProcessCmd::procCmdGetRecordCalender(_HP2PCHANNEL hP2pChnnel, _UI uiSeqId, _VPTR hJsonRoot)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC aucMethod[8]    = {0};
    _UC *pucDay         = MOS_NULL;
    _UC *pStrTmp        = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    JSON_HANDLE hArray  = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_MOS_LIST    *pstDateList    = MOS_NULL;
    ST_RDSTG_DATENODE *pstDataNode = MOS_NULL;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    pstDateList = RdStg_GetDateList(0);
    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Date"),&pucDay);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETRECORDCALENDER_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Dates",hArray);
    FOR_EACHDATA_INLIST(pstDateList, pstDataNode, stIterator)
    {
        if(MOS_STRCMP(pstDataNode->stDate.aucDate,pucDay) >= 0)
        {
            Adpt_Json_AddItemToArray(hArray,Adpt_Json_CreateString(pstDataNode->stDate.aucDate));
        }
        MOS_LIST_RMVNODE(pstDateList, pstDataNode);
        MOS_FREE(pstDataNode);
    }
    MOS_FREE(pstDateList);

    pStrTmp = Adpt_Json_Print(hRoot);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETRECORDCALENDER_RSP,
                   pStrTmp, MOS_STRLEN(pStrTmp));

    MOS_LOG_INF(P2P_STRLOG,"reqid %u  send Record Calender %s", uiSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdGetRecordList(_HP2PCHANNEL hP2pChnnel, _UI uiSeqId, _VPTR hJsonRoot)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UI uiDuration              = 0;
    _INT iPageSize              = 0;
    _UC aucBuff[32]             = {0};
    _UC *pStrTmp                = MOS_NULL;
    _UC *pucFromTime            = MOS_NULL;
    JSON_HANDLE hRoot           = MOS_NULL;
    JSON_HANDLE hArray          = MOS_NULL;
    JSON_HANDLE hArrayItem      = MOS_NULL;
    ST_MOS_LIST *pstAxisList    = MOS_NULL;
    ST_MOS_SYS_TIME stSysTime;
    ST_MOS_LIST_ITERATOR stIterator;
    ST_RDSTG_FILEDESNODE *pstFileDesNode = MOS_NULL;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Date"),&pucFromTime);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PageSize"),&iPageSize);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucBuff, "%02X%02X",EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETRECORDLIST_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucBuff));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    // 通过page查询卡录像文件列表 通过信令调用 (卡录像查询入口)
    pstAxisList = RdStg_GetFileListByPage(0,pucFromTime,iPageSize);
    if (pstAxisList == MOS_NULL)
    {
        MOS_LOG_ERR(P2P_STRLOG,"pstAxisList == MOS_NULL");
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Size",Adpt_Json_CreateStrWithNum(0));
    }
    else
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"Size",Adpt_Json_CreateStrWithNum(MOS_LIST_GETCOUNT(pstAxisList)));
    }

    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Files",hArray);

    if (pstAxisList)
    {
        FOR_EACHDATA_INLIST_CONVERSE(pstAxisList, pstFileDesNode, stIterator)
        {
            hArrayItem = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToArray(hArray, hArrayItem);

            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"FileID",Adpt_Json_CreateStrWithNum(pstFileDesNode->stFileDes.uiFileSeq));

            Mos_TimetoSysTime(&pstFileDesNode->stFileDes.cStartTime,&stSysTime);
            MOS_SPRINTF(aucBuff, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
            Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"SrcTime",Adpt_Json_CreateString(aucBuff));

            if(pstFileDesNode->stFileDes.cStopTime > pstFileDesNode->stFileDes.cStartTime)
            {
                uiDuration = (_UI)(pstFileDesNode->stFileDes.cStopTime- pstFileDesNode->stFileDes.cStartTime);
                if(uiDuration == 0)
                {
                    uiDuration = 1;
                }
                Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDuration));
            }
            else
            {
                uiDuration = (pstFileDesNode->stFileDes.uiEndTimeStamp - pstFileDesNode->stFileDes.uiStartTimeStamp)/1000;
                if(uiDuration == 0)
                {
                    uiDuration = 1;
                }
                Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Duration",Adpt_Json_CreateStrWithNum(uiDuration));
            }
            MOS_LIST_RMVNODE(pstAxisList, pstFileDesNode);
            MOS_FREE(pstFileDesNode);
        }
    }

    pStrTmp = Adpt_Json_Print(hRoot);

    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_GETRECORDLIST_RSP,
                   pStrTmp, MOS_STRLEN(pStrTmp));
    MOS_LOG_INF(P2P_STRLOG,"reqid %u get MediaAxis rsp %s",uiSeqId,pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    MOS_FREE(pstAxisList);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdGetJpegCalender(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot)
{
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdGetJpegList(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot)
{
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdStartPlayBack(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC aucBuf[128]             = {0};
    _UC aucMethod[8]            = {0};
    _UI uiCamId                 = 0;
    _UI uiDownFlag              = 0;
    _UI uiPlayBackMode          = 0;
    _UI uiVideoWin              = 100;
    _UI uiAudioWin              = 100;
    _UI uiChannelId             = 0;
    _UC *pStrTmp                = MOS_NULL;
    JSON_HANDLE hBody           = MOS_NULL;
    JSON_HANDLE hRoot           = MOS_NULL;
    _UC *pucPlayBackStartTime   = MOS_NULL;
    ST_CFG_VIDEODES   stVideoDes;
    ST_ZJ_AUDIO_PARAM stAudioParm;
    _INT              iAdjustTime = 0;
    _RDFILEFD *pstRdStg_fileFD = MOS_NULL;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 解析JSON
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Time"),&pucPlayBackStartTime);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID"),&uiChannelId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CamID"),&uiCamId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"DownFlag"),&uiDownFlag);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PlayFlag"),&uiPlayBackMode);    // 0:d单文件回放 1：时间轴连续回放
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"VideoWinSize"),&uiVideoWin);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"AudioWinSize"),&uiAudioWin);

    uiVideoWin = (uiVideoWin<=0) ? 100 : uiVideoWin;
    uiAudioWin = (uiAudioWin<=0) ? 100 : uiAudioWin;
    MOS_LOG_INF(P2P_STRLOG,">>>>recive startPlaybsck time:%s chan:%u camId:%u DownFlag:%u PlayBackMode:%u",
               pucPlayBackStartTime, uiChannelId, uiCamId, uiDownFlag, uiPlayBackMode);

    _INT iMaxUser       = P2pManageMent::instance().getOnVideoClient();
    _INT iSessionResult = iMaxUser < Config_GetDeviceMng()->uiMaxSessionCnt ? 0 : 1;
    // 回复JSON
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_START_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(iSeqId));

    if (iSessionResult == 0)
    {
        ST_MOS_SYS_TIME  stSysTime   = {0};
        Mos_GetSysTime(&stSysTime);
        MOS_SSCANF(pucPlayBackStartTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
            &stSysTime.usYear,&stSysTime.usMonth,&stSysTime.usDay,
            &stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);
        pstRdStg_fileFD = RdStg_OpenPlayBackFile(pucPlayBackStartTime, &iAdjustTime, 0);
        if (MOS_NULL == pstRdStg_fileFD)
        {
            MOS_LOG_INF(P2P_STRLOG,"MOS_NULL == pstRdStg_fileFD,pucPlayBackStartTime:%s file not exitst!", pucPlayBackStartTime);
            iSessionResult = 2;
        }
    }

    // allready maxSessionCount
    if (iSessionResult == 1)
    {
        MOS_LOG_WARN(P2P_STRLOG,"p2p livevideo conn max, playback can't conn anymore!");
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",  Adpt_Json_CreateStrWithNum(EN_P2P_ERROR_CODE_PLAYBACK_ALREADY_MAX_CONN));
        pStrTmp = Adpt_Json_Print(hRoot);
        procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_START_RESP,
                    pStrTmp, MOS_STRLEN(pStrTmp));

        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_P2P_ERROR_CODE_PLAYBACK_ALREADY_MAX_CONN, "p2p livevideo conn max, playback can't conn anymore!", 1);
        Adpt_Json_Delete(hRoot);
        MOS_FREE(pStrTmp);
        return MOS_ERR;
    }
    // file is not exist
    else if (iSessionResult == 2)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",  Adpt_Json_CreateStrWithNum(EN_P2P_ERROR_CODE_PLAYBACK_OPEN_VIDEO_FAIL));
        pStrTmp = Adpt_Json_Print(hRoot);
        procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_START_RESP,
                       pStrTmp, MOS_STRLEN(pStrTmp));

        MOS_LOG_INF(P2P_STRLOG,">>>online:%d maxuser:%d errcode:%d start playback ignored resp: %s", iMaxUser, Config_GetDeviceMng()->uiMaxSessionCnt, iSessionResult,pStrTmp);

        MOS_MEMSET(aucBuf, 0x00, sizeof(aucBuf));
        MOS_VSNPRINTF(aucBuf, sizeof(aucBuf), "start playback error online:%d maxuser:%d errcode:%d", iMaxUser, Config_GetDeviceMng()->uiMaxSessionCnt, iMaxUser);
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_P2P_ERROR_CODE_PLAYBACK_OPEN_VIDEO_FAIL, aucBuf, 1);
        Adpt_Json_Delete(hRoot);
        MOS_FREE(pStrTmp);
        return MOS_ERR;
    }

    ST_PLAYBACK_MNG *m_playbackThreadMng = &avClient->m_playBackThreadMng;
    if(m_playbackThreadMng->ucInitFlag == 0)
    {
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",  Adpt_Json_CreateStrWithNum(iSessionResult));
        RdStg_ReadFileDes((_RDFILEFD)pstRdStg_fileFD, &stVideoDes, &stAudioParm);
        RdStg_ClosePlayBackFile(pstRdStg_fileFD);

        JSON_HANDLE hVBody = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hVBody,(_UC*)"ChannelID",   Adpt_Json_CreateStrWithNum(uiChannelId));
        Adpt_Json_AddItemToObject(hVBody,(_UC*)"VideoWinSize",Adpt_Json_CreateStrWithNum(uiVideoWin));
        Adpt_Json_AddItemToObject(hVBody,(_UC*)"AudioWinSize",Adpt_Json_CreateStrWithNum(uiAudioWin));

        JSON_HANDLE hVParam = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(stVideoDes.stVideoPara.uiEncodeType));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"FrameRate",Adpt_Json_CreateStrWithNum(stVideoDes.stVideoPara.uiFramerate));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"Width",Adpt_Json_CreateStrWithNum(stVideoDes.stVideoPara.uiWidth));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"Height",Adpt_Json_CreateStrWithNum(stVideoDes.stVideoPara.uiHeight));
        Adpt_Json_AddItemToObject(hVParam,(_UC*)"LensType",Adpt_Json_CreateStrWithNum(0));
        Adpt_Json_AddItemToObject(hVBody ,(_UC*)"VideoParam",hVParam);

        JSON_HANDLE hAParam = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hAParam,(_UC*)"EncType",Adpt_Json_CreateStrWithNum(stAudioParm.uiEncodeType));
        Adpt_Json_AddItemToObject(hAParam,(_UC*)"SampleRate",Adpt_Json_CreateStrWithNum(8000));
        Adpt_Json_AddItemToObject(hAParam,(_UC*)"Channel",Adpt_Json_CreateStrWithNum(1));
        Adpt_Json_AddItemToObject(hAParam,(_UC*)"Depth",Adpt_Json_CreateStrWithNum(16));
        Adpt_Json_AddItemToObject(hVBody ,(_UC*)"AudioParam",hAParam);

        Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hVBody);

        pStrTmp = Adpt_Json_Print(hRoot);
        procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_START_RESP,
                       pStrTmp, MOS_STRLEN(pStrTmp));

        MOS_LOG_INF(P2P_STRLOG,"<<<startPlayback resp: %s", pStrTmp);
        Adpt_Json_Delete(hRoot);
        MOS_FREE(pStrTmp);

        MOS_MEMSET(m_playbackThreadMng, 0, sizeof(ST_PLAYBACK_MNG));
        m_playbackThreadMng->ucInitFlag    = 1;
        m_playbackThreadMng->ucRunFlag     = 0;
        m_playbackThreadMng->hMsgQueque    = Mos_MsgQueueCreate(MOS_FALSE, 30, "playBack");
        m_playbackThreadMng->usChannel     = uiChannelId;
        m_playbackThreadMng->hVideoHander  = MOS_NULL;
        m_playbackThreadMng->hAudioHander  = MOS_NULL;

        m_playbackThreadMng->ucDownFlag    = uiDownFlag;
        m_playbackThreadMng->ucPlayFlag    = uiPlayBackMode;
        m_playbackThreadMng->usAvWinSize[0]= uiVideoWin;
        m_playbackThreadMng->usAvWinSize[1]= uiAudioWin;
        P2pManageMent::instance().startPlayback( hP2pChnnel, pucPlayBackStartTime);
    }
    else
    {
        MOS_LOG_WARN(P2P_STRLOG,"Playback conn max, can't conn anymore!");
        RdStg_ClosePlayBackFile(pstRdStg_fileFD);
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",  Adpt_Json_CreateStrWithNum(EN_P2P_ERROR_CODE_PLAYBACK_ALREADY_MAX_CONN));
        pStrTmp = Adpt_Json_Print(hRoot);
        procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_START_RESP,
                    pStrTmp, MOS_STRLEN(pStrTmp));

        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, 0, EN_P2P_ERROR_CODE_PLAYBACK_ALREADY_MAX_CONN, "Playback conn is max, can't conn anymore!", 1);
        Adpt_Json_Delete(hRoot);
        MOS_FREE(pStrTmp);
        return MOS_ERR;
    }
    return MOS_OK;
}

_INT P2pProcessCmd::procPlayBackCmdMsg(_HP2PCHANNEL hP2pChnnel, _UC ucMsgType, _UC ucMsgId, _INT iSeqID,
                                      _UC *pucMsgBuff,_INT iMsgBuffLen)
{
    ST_AVCLIENT_INFO *avClint = (ST_AVCLIENT_INFO*)hP2pChnnel;

    ST_P2P_CMD_MSG *pstCmdMsg =(ST_P2P_CMD_MSG*)MOS_MALLOCCLR(sizeof(ST_P2P_CMD_MSG) + iMsgBuffLen);
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdMsg->stMsgHead.usMsgType = EN_P2P_MSG_TYPE_NET;
    pstCmdMsg->stMsgHead.usMsgLen  = iMsgBuffLen;
    pstCmdMsg->ucMsgType = ucMsgType;
    pstCmdMsg->ucMsgId   = ucMsgId;
    pstCmdMsg->iSeqNum   = iSeqID;
    if (iMsgBuffLen > 0 )
    {
        MOS_MEMCPY(pstCmdMsg->aucMsgBody, pucMsgBuff, iMsgBuffLen);
    }

    _INT iRet = Mos_MsgQueuePush(avClint->m_playBackThreadMng.hMsgQueque, pstCmdMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdMsg);
        return MOS_ERR;
    }

    return sizeof(ST_OGCT_PROTOCAL_HEAD);
}

_INT P2pProcessCmd::procCmdControlPlayBack(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot)
{
    ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UI uiVod            = 0;
    _UI uiParamFlag      = 0;
    _UI uiChannelId      = 0;
    _UC aucMethod[8]     = {0};
    _UC *pStrTmp         = MOS_NULL;
    JSON_HANDLE hRoot    = MOS_NULL;
    JSON_HANDLE hBody    = MOS_NULL;
    JSON_HANDLE hRspBody = MOS_NULL;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID"),&uiChannelId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Vod"),&uiVod);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"Param"),&uiParamFlag);
    MOS_LOG_INF(P2P_STRLOG,">>>>recive control playback chan:%u uiVod:%u flag:%u",  uiChannelId, uiVod, uiParamFlag);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_CONTROL_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    hRspBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRspBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(uiChannelId));

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hRspBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_CONTROL_RESP,
                   pStrTmp, MOS_STRLEN(pStrTmp));

    _UC* pStrTmp2 = Adpt_Json_Print(hBody);
    procPlayBackCmdMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_CONTROL_REQ,
                       iSeqId, pStrTmp2, MOS_STRLEN(pStrTmp2) + 1);
    MOS_FREE(pStrTmp2);
    MOS_LOG_INF(P2P_STRLOG,">>>reqid %d rsp get Record Calender %s", iSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT P2pProcessCmd::P2pPlaybackStop(_HP2PCHANNEL hP2pChnnel, _UI uiChannel, _UI uiForceClose)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    _VPTR pstMsg = MOS_NULL;
    _INT iRetryCount = 0;
    MOS_PARAM_NULL_RETERR(avClient);
    if((avClient->m_playBackThreadMng.ucRunFlag != 1) || (avClient->m_playBackThreadMng.usChannel != uiChannel))
    {
        if(uiForceClose != MOS_TRUE)
            return MOS_OK;
    }

    avClient->m_playBackThreadMng.ucRunFlag  = 0;
    avClient->m_playBackThreadMng.ucInitFlag = 0;
    // Mos_MsgQueueWake(avClient->m_playBackThreadMng.hMsgQueque,MOS_TRUE);
    for(;;)
    {
        if (++iRetryCount >= 3000 || avClient->m_playBackThreadMng.ucOverFlag == EN_P2P_THREAD_MNG_TYPE_END)
        {
            MOS_PRINTF("%s:%d Delete playBackThread.....\r\n", __FUNCTION__, __LINE__);
            iRetryCount = 0;
            avClient->m_playBackThreadMng.ucOverFlag = EN_P2P_THREAD_MNG_TYPE_INIT;
            Mos_ThreadDelete(avClient->m_playBackThreadMng.hThread);
            break;
        }
        Mos_Sleep(1);
    }
    while((pstMsg = Mos_MsgQueuePop(avClient->m_playBackThreadMng.hMsgQueque)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    Mos_MsgQueueDelete(avClient->m_playBackThreadMng.hMsgQueque);
    avClient->m_playBackThreadMng.hMsgQueque = MOS_NULL;
    MOS_LOG_INF(P2P_STRLOG,"%s playback task uiForceClose:%u stop ok", avClient->m_uacPeerId, uiForceClose);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdStopPlayBack(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC aucMethod[8]    = {0};
    _UI  uiChannelId    = 0;
    _UI  uiParamCode    = 0;
    _UC *pStrTmp        = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;

    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    hBody = Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"ChannelID"),&uiChannelId);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"CODE"), &uiParamCode);
    MOS_LOG_INF(P2P_STRLOG,">>>>recive control playback chan:%u Code:%u", uiChannelId,  uiParamCode);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_STOP_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ChannelID",Adpt_Json_CreateStrWithNum(uiChannelId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_PLAYBACK_STOP_RESP,
                   pStrTmp, MOS_STRLEN(pStrTmp));

    P2pPlaybackStop(hP2pChnnel, uiChannelId);
    MOS_LOG_INF(P2P_STRLOG,"<<<reqid %u stop playback %s", iSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}


_INT P2pProcessCmd::procCmdSendCloseSession(_HP2PCHANNEL hP2pChnnel)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);

    _UC aucMethod[8]    = {0};
    _UC *pStrTmp        = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_P2PSESSION_CLOSE_REQ);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(1));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
    pStrTmp = Adpt_Json_Print(hRoot);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_P2PSESSION_CLOSE_REQ,
                   pStrTmp, MOS_STRLEN(pStrTmp));
    MOS_PRINTF("timout send close session:%s \n", pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdCloseSession(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC aucMethod[8]    = {0};
    _UC *pStrTmp        = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    _UC* pucParamCode;
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hJsonRoot,(_UC*)"CODE"), &pucParamCode);
    MOS_LOG_INF(P2P_STRLOG,">>>>recive close p2p session, code:%s",   pucParamCode);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_P2PSESSION_CLOSE_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"ClientId",Adpt_Json_CreateString(avClient->m_uacPeerId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_P2PSESSION_CLOSE_RESP,
                   pStrTmp, MOS_STRLEN(pStrTmp));
    P2pManageMent::instance().setClientTimeOut(hP2pChnnel);
    P2p_GetTaskMng()->ucCheckFlag =1;
    MOS_LOG_INF(P2P_STRLOG,">>>reqid %u stop p2pconnecttion %s", iSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdStartNatHole(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC aucMethod[8]    = {0};
    _UC *pStrTmp        = MOS_NULL;
    _UC *pucAppSdkVer   = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    _UC aucSdkVersion[32]   = {0};
    Config_GetSdkVersion(aucSdkVersion);
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"devSdkVer"), &pucAppSdkVer);
    MOS_LOG_INF(P2P_STRLOG,">>>>recive start nat4 app version:%s \n",   pucAppSdkVer);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_START_NAT4HOLE_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"devSdkVer",Adpt_Json_CreateString(aucSdkVersion));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    pStrTmp = Adpt_Json_Print(hRoot);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_START_NAT4HOLE_RESP,
                   pStrTmp, MOS_STRLEN(pStrTmp));
    MOS_LOG_INF(P2P_STRLOG,">>>send start p2p nat4 response %s", pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdSelectCntidReq(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot)
{
    ST_AVCLIENT_INFO *avClient  = (ST_AVCLIENT_INFO*)hP2pChnnel;
    MOS_PARAM_NULL_RETERR(avClient);
    MOS_PARAM_NULL_RETERR(hJsonRoot);

    _UC aucMethod[8]    = {0};
    _UC *pP2pcntId      = MOS_NULL;
    _UC *pStrTmp        = MOS_NULL;
    JSON_HANDLE hBody   = MOS_NULL;
    JSON_HANDLE hRoot   = MOS_NULL;
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    hBody = Adpt_Json_GetObjectItem(hJsonRoot, (_UC*)"BODY");
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"cntId"), &pP2pcntId);

    MOS_PRINTF("%s pP2pcntId:%s\n", __FUNCTION__, pP2pcntId);

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_SELECT_CNTID_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    pStrTmp = Adpt_Json_Print(hRoot);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_SELECT_CNTID_RESP,
                   pStrTmp, MOS_STRLEN(pStrTmp));
  
    MOS_LOG_INF(P2P_STRLOG,">>>reqid %u stop p2p nat4 connecttion %s", iSeqId,pStrTmp);
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT P2pProcessCmd::procCmdClientNatInfoNotify(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg)
{
        #if 0
    _UC *pStrTmp        = MOS_NULL;
    _INT iSrfixPort     = 0;
    _INT iNatType       = 0;
    _UC  *pucSrfixIp    = MOS_NULL;
    _INT iMsgBuffLen    = 0;
    _UC aucMethod[8]    = {0};

    MOS_FUNCTION_PRINTF(__FUNCTION__, __LINE__);
    ST_AVCLIENT_INFO *avClient = (ST_AVCLIENT_INFO*)hP2pChnnel;
    {
        JSON_HANDLE hDataObj = Adpt_Json_GetObjectItem(hRootOrg, (_UC*)"BODY");
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"srfIxIp"), &pucSrfixIp);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"srfIxPort"), &iSrfixPort);
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hDataObj,(_UC*)"natType"), &iNatType);
        MOS_LOG_INF(P2P_STRLOG,"##recive start nat4-nat3:pucSrfixIp:%s, iSrfixPort:%d, iNatType:%d\n", pucSrfixIp, iSrfixPort, iNatType);

        JSON_HANDLE hRoot   = Adpt_Json_CreateObject();
        _UC aucMethod[8]    = {0};
        MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_CLIENT_NAT4_INF_RESP);
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

        pStrTmp = Adpt_Json_Print(hRoot);
        Adpt_Json_Delete(hRoot);
        iMsgBuffLen = MOS_STRLEN(pStrTmp);
        procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_CLIENT_NAT4_INF_RESP,
                       pStrTmp, iMsgBuffLen);
            MOS_LOG_INF(P2P_STRLOG,"send recive nat4info method:%02X%02X pucMsgBuff:%s\n",
                        EN_OGCT_METHOD_CN21_CMD,
                       EN_CN21_P2P_CMD_CLIENT_NAT4_INF_RESP, pStrTmp);
        MOS_FREE(pStrTmp);
    }

    JSON_HANDLE hRoot   = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X", EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_DEVICE_NAT4_INF_REQ);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(iSeqId));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));

    //avClient->m_iceTranSport->createP2PInstance(//avClient->m_iceTranSport, 1, 0 );
    //avClient->m_iceTranSport->startCustomNat4Detect(//avClient->m_iceTranSport);
    kj_timer_t checkTime;
    kj_timer_init(&checkTime);
    _INT delayTime = getDiffTimems(&checkTime, 1, 0, 60*10);
    _BOOL  bInValid = MOS_TRUE;
    do
    {
        _INT iStatus = 0;//avClient->m_iceTranSport->getNatDetectInfo()->iStatus;
        if ( (iStatus == STATUS_SUCCESS) || (iStatus == STATUS_FAILED))
        {
            bInValid = MOS_FALSE;
            MOS_LOG_INF(P2P_STRLOG,">>>get natsrfip res:%d, cost:%d ms!!\n",iStatus, delayTime);
            if (iStatus == STATUS_FAILED)
            {
                bInValid = MOS_TRUE;
            }
            break;
        }
        delayTime = getDiffTimems(&checkTime, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
        if (delayTime >= 8*1000)
        {
            MOS_LOG_INF(P2P_STRLOG,">>>nattype detect time out!! clentId:%s\n", avClient->m_uacPeerId);
            break;
        }
    }while(bInValid);

    ST_NATDETECT_INFO *stNatInfo = //avClient->m_iceTranSport->getNatDetectInfo();
    JSON_HANDLE hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(bInValid==MOS_TRUE ? 1 : 0));
    if (bInValid == MOS_FALSE)
    {
        Adpt_Json_AddItemToObject(hBody,(_UC*)"srfIxIp",Adpt_Json_CreateString(stNatInfo->ucSrfIp));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"srfIxPort",Adpt_Json_CreateStrWithNum(stNatInfo->uiPort));
        Adpt_Json_AddItemToObject(hBody,(_UC*)"natType",Adpt_Json_CreateStrWithNum(stNatInfo->uiNatType));

        if (stNatInfo->uiNatType == NAT_TYPE_SYMMETRIC)
        {
            bInValid = MOS_TRUE;
        }
    }
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    pStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    iMsgBuffLen = MOS_STRLEN(pStrTmp);
    procCmdSendMsg(hP2pChnnel, EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_DEVICE_NAT4_INF_REQ,
                   pStrTmp, iMsgBuffLen);
    MOS_LOG_INF(P2P_STRLOG,"current   info method:%02X%02X pucMsgBuff:%s\n",
                EN_OGCT_METHOD_CN21_CMD, EN_CN21_P2P_CMD_DEVICE_NAT4_INF_REQ, pStrTmp);
    MOS_FREE(pStrTmp);

    if (!bInValid)
    {
        //avClient->m_iceTranSport->startHolePunching(0, pucSrfixIp, iSrfixPort, iNatType);
    }
    else
    {
        //avClient->m_iceTranSport->destroyP2PInstance(0);
    }
        #endif
    return MOS_OK;
}
