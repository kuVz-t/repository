#include "zj_interface.h"
#include "p2p_connect.h"
#include "msgmng_api.h"
#include "adpt_json_adapt.h"
#include "P2pManageMent.h"
#include "record_api.h"
#include "watchdog_api.h"
#include "p2p_avclient.h"
#include "kj_rome.h"
/***************************************************************************************
说明 :命令的格式 
  int       int              string
 cmdtype   cmdlen            json格式("id")
 如果是 自定义命令 则为命令的长度
****************************************************************************************/
static ST_CONNETP2P_MNG g_stP2pConnectMng = {0};
/***************************************************************************************
****************************************************************************************/
static _INT P2p_ServerTask_Loop(_VPTR pstArg);

/*************************************************************************************
***************************************************************************************/
ST_CONNETP2P_MNG *P2p_GetTaskMng()
{
    return &g_stP2pConnectMng;
}

/**
* @brief         p2p task thread init
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_Task_Init()
{
    if (P2p_GetTaskMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(P2P_STRLOG, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stP2pConnectMng, 0, sizeof(g_stP2pConnectMng));
    P2p_GetTaskMng()->hMsgQueque = Mos_MsgQueueCreate(MOS_FALSE,30, "p2pTaskInit");
    P2p_GetTaskMng()->ucCheckFlag= 0;
    P2p_GetTaskMng()->ucRunFlag  = 0;
    MOS_PRINTF("%s p2pModule init ok ", __FUNCTION__);

    P2pManageMent &p2pMngCtrl = P2pManageMent::instance();
    p2pMngCtrl.InitP2p(MOS_NULL);
    P2p_GetTaskMng()->ucInitFlag = 1;
    return MOS_OK;
}

/**
* @brief         p2p task thread start
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_Task_Start()
{
    _UI uiStackSize = MOS_THREAD_STACK_HIGH_SIZE;//MOS_THREAD_STACK_NORMAL_SIZE;
    if (P2p_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }

    if (P2p_GetTaskMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(P2P_STRLOG, "Already Start");
        return MOS_OK;
    }
    
#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif
    P2p_GetTaskMng()->ucRunFlag  = 1;
    P2pManageMent::instance().StartP2p();
    if (Mos_ThreadCreate((_UC*)"P2p_task",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        P2p_ServerTask_Loop,MOS_NULL,MOS_NULL,&P2p_GetTaskMng()->hThread) == MOS_ERR)
    {
        P2p_GetTaskMng()->ucRunFlag = 0;
        return MOS_ERR;
    }
    MOS_LOG_INF(P2P_STRLOG, "thread start ok!");
    return MOS_OK;
}

/**
* @brief         p2p task thread stop
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_Task_Stop()
{
#if 0 //当P2p_ServerTask_Loop内部进行P2P建连流程时调用了pj_thread_register,退出P2p_ServerTask_Loop线程回收资源时会出现奔溃情况。
    if (P2p_GetTaskMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(P2P_STRLOG, "Already Stop");
        return MOS_OK;
    }
    P2p_GetTaskMng()->ucRunFlag  = 0;
#endif
    P2pManageMent::instance().StopP2p();
    // Mos_MsgQueueWake(P2p_GetTaskMng()->hMsgQueque,MOS_TRUE);
#if 0    
    Mos_ThreadDelete(P2p_GetTaskMng()->hThread);
#endif    

    MOS_PRINTF("p2p task thread stop ok \r\n");
    return MOS_OK;
}

/**
* @brief         p2p task thread destroy
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_Task_Destroy()
{
#if 0 //当P2p_ServerTask_Loop内部进行P2P建连流程时调用了pj_thread_register,退出P2p_ServerTask_Loop线程回收资源时会出现奔溃情况。    
    if (P2p_GetTaskMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(P2P_STRLOG, "Already Destroy");
        return MOS_OK;
    }
    P2p_GetTaskMng()->ucInitFlag = 0;
#endif    
    P2pManageMent::instance().UninitP2p();
#if 0    
    _VPTR pstMsg = MOS_NULL;
    while((pstMsg = Mos_MsgQueuePop(P2p_GetTaskMng()->hMsgQueque)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    Mos_MsgQueueDelete(P2p_GetTaskMng()->hMsgQueque);
    MOS_MEMSET(&g_stP2pConnectMng, 0, sizeof(g_stP2pConnectMng));
#endif
    MOS_PRINTF("p2p task  thread Destroy ok \r\n");
    return MOS_OK;
}

/**
* @brief         p2p connect cmd call functions
* @author        Hejh
* @date          2021-05-13
*/
static ST_P2P_DEVMSG_HANDLER s_p2pDevMsgHandler[] =
{
//    { EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_SETSDP_REQ, (PFUN_P2P_DEVMSG_PROC)P2p_Task_ProcNewConnect},
//    { EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_CONNECTPRE_REQ, (PFUN_P2P_DEVMSG_PROC)P2p_Task_ProcNewLink},
    { EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_GET_ONLINE_NUMBER_REQ, (PFUN_P2P_DEVMSG_PROC)P2p_Task_ProcClinetNumber},
    { EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_APP_SEND_SDP_REQ, (PFUN_P2P_DEVMSG_PROC)P2p_Task_ProcClientP2pConnctReq}
};

static ST_P2P_DEVMSG_HANDLER *P2p_FindDevMsgHandle(_UC ucMsgType,_UC ucMsgId)
{
    _UI i = 0;
    _UI uiHandleCnt = sizeof(s_p2pDevMsgHandler)/sizeof(ST_P2P_DEVMSG_HANDLER);
    for(i = 0; i < uiHandleCnt;i++)
    {
        if (s_p2pDevMsgHandler[i].ucMsgType == ucMsgType && s_p2pDevMsgHandler[i].ucMsgId == ucMsgId)
        {
            return &s_p2pDevMsgHandler[i];
        }
    }
    return MOS_NULL;
}

/**
* @brief         process client Ready to connect command from cmd server
*                pharse prepare conncet device request form client
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_SetPrepareConnectMsg(_UC *pucPeerId,_UI uiSeqId, ST_FROM_TO_MSG *pstMsgFromTo,
                      _VPTR *pucRole)
{
    if (P2p_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }

    ST_P2P_CMDTASK_MSG *pstCmdTaskMsg =(ST_P2P_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_P2P_CMDTASK_MSG) + (CFG_STRING_LEN));
    if (pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->stMsgHead.usMsgType = EN_P2P_MSG_TYPE_NET;
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_21CN_P2P_CMD;
    pstCmdTaskMsg->ucMsgId   = EN_CN21_P2P_CONNECTPRE_REQ;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    MOS_MEMCPY(pstCmdTaskMsg->aucMsgBody, pucRole, (CFG_STRING_LEN));

    _INT iRet = Mos_MsgQueuePush(P2p_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

/**
* @brief         recive client start link cmd, using get DevSdp info first
* @author        Hejh
* @date          2021-05-13
*/
//pharse get sdp request form client
_INT P2p_SetGetDevSdpMsg(_UC *pucPeerId,_UI uiSeqId, ST_FROM_TO_MSG *pstMsgFromTo,
                      ST_CMTASK_GETSDPINFO *pstSdpInfo)
{
    if (P2p_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }

    ST_P2P_CMDTASK_MSG *pstCmdTaskMsg =(ST_P2P_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_P2P_CMDTASK_MSG) + sizeof(ST_CMTASK_GETSDPINFO));
    if (pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->stMsgHead.usMsgType = EN_P2P_MSG_TYPE_NET;
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_21CN_P2P_CMD;
    pstCmdTaskMsg->ucMsgId   = EN_CN21_P2P_SETSDP_REQ;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    MOS_MEMCPY(pstCmdTaskMsg->aucMsgBody, pstSdpInfo,sizeof(ST_CMTASK_GETSDPINFO));

    _INT iRet = Mos_MsgQueuePush(P2p_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

//pharse get sdp request form client
_INT P2p_ReciveClientP2pDataMsg(_UC *pucPeerId,_UI uiSeqId, ST_FROM_TO_MSG *pstMsgFromTo,
                      ST_CMTASK_P2PDATAINFO *pstSdpInfo)
{
    if (P2p_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }

    ST_P2P_CMDTASK_MSG *pstCmdTaskMsg =(ST_P2P_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_P2P_CMDTASK_MSG) + sizeof(ST_CMTASK_P2PDATAINFO));
    if (pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->stMsgHead.usMsgType = EN_P2P_MSG_TYPE_NET;
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_21CN_P2P_CMD;
    pstCmdTaskMsg->ucMsgId   = EN_CN21_P2P_APP_SEND_SDP_REQ;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    MOS_MEMCPY(pstCmdTaskMsg->aucMsgBody, pstSdpInfo,sizeof(ST_CMTASK_P2PDATAINFO));

    _INT iRet = Mos_MsgQueuePush(P2p_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}
/**
* @brief         Process get p2p Online  Number request
*                pharse get get client number request form client
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_SetGetClientNumberMsg(_UC *pucPeerId,_UI uiSeqId, ST_FROM_TO_MSG *pstMsgFromTo, _VPTR pMsgParam)
{
    if (P2p_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }

    ST_P2P_CMDTASK_MSG *pstCmdTaskMsg =(ST_P2P_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_P2P_CMDTASK_MSG)+ sizeof(ST_P2PTURN_ADDRINFO));

    if (pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->stMsgHead.usMsgType = EN_P2P_MSG_TYPE_NET;
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_21CN_P2P_CMD;
    pstCmdTaskMsg->ucMsgId   = EN_CN21_P2P_GET_ONLINE_NUMBER_REQ;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    MOS_MEMCPY(pstCmdTaskMsg->aucMsgBody, pMsgParam,sizeof(ST_P2PTURN_ADDRINFO));
    _INT iRet = Mos_MsgQueuePush(P2p_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

/**
* @brief         Just fullfill msgFromTo  infos
* @author        Hejh
* @date          2021-05-13
*/
static _VOID P2p_AddMsgSrcInfObject(_VPTR hRoot,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo)
{
    JSON_HANDLE hFromObject = MOS_NULL;
    JSON_HANDLE hToObject   = MOS_NULL;

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));
    if (MOS_STRLEN(pstMsgFromTo->aucDID) > 0)
    {
        hFromObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"FROM",hFromObject);
        Adpt_Json_AddItemToObject(hFromObject,(_UC*)"DID",Adpt_Json_CreateString(pstMsgFromTo->aucDID));
    }

    if (MOS_STRLEN(pstMsgFromTo->aucUserToken) > 0 || MOS_STRLEN(pstMsgFromTo->aucSvrID) > 0)
    {
        hToObject = Adpt_Json_CreateObject();
        if (MOS_STRLEN(pstMsgFromTo->aucUserToken) > 0)
        {
#ifdef SUPPORT_DEBUG_P2P
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"UserToken",Adpt_Json_CreateString(pstMsgFromTo->aucUserToken));
#else
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"ClientID",Adpt_Json_CreateString(pstMsgFromTo->aucUserToken));
#endif
        }
        if (MOS_STRLEN(pstMsgFromTo->aucSvrID) > 0)
        {
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"SvrID",Adpt_Json_CreateString(pstMsgFromTo->aucSvrID));
        }
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"TO",hToObject);
    }
    return;
}


/**
* @brief         Just fullfill p2p online numbers of client
* @author        Hejh
* @date          2021-05-13
*/
static _UC *Cmd_ProcGetOnlineNumberRsp(_UI uiSeqId, _UI onlieNumber, ST_FROM_TO_MSG *pstMsgFromTo)
{
    _UC aucMethod[64]       = {0};
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBody       = MOS_NULL;
    _UC aucSdkVersion[32]   = {0};
    Config_GetSdkVersion(aucSdkVersion);

    hRoot = Adpt_Json_CreateObject();
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X", EN_OGCT_METHOD_21CN_P2P_CMD, EN_CN21_P2P_GET_ONLINE_NUMBER_RESP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));

    P2p_AddMsgSrcInfObject(hRoot, uiSeqId, pstMsgFromTo);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(0));

    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBody,(_UC*)"P2PConnectCount", Adpt_Json_CreateStrWithNum(onlieNumber));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"AllConnectCount", Adpt_Json_CreateStrWithNum(onlieNumber));
    Adpt_Json_AddItemToObject(hBody,(_UC*)"SDKVersion",Adpt_Json_CreateString(aucSdkVersion));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pucStrTmp;
}

/**
* @brief         Process get Online client number
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_Task_ProcClinetNumber(ST_P2P_CMDTASK_MSG *pstCmdMsg)
{
    _INT iMaxUser = P2pManageMent::instance().getOnVideoClient();
    
    _UC  *pucStrTmp = Cmd_ProcGetOnlineNumberRsp(pstCmdMsg->uiSeqId, iMaxUser, &pstCmdMsg->stMsgFromTo);
    MsgMng_SendMsg(pstCmdMsg->aucPeerId, pstCmdMsg->uiSeqId, pstCmdMsg->ucMsgType, pstCmdMsg->ucMsgId + 1,
        pucStrTmp, MOS_STRLEN(pucStrTmp),MOS_NULL);

    MOS_PRINTF("reqid %u send rsp %s",pstCmdMsg->uiSeqId,pucStrTmp);
    Adpt_Json_DePrint(pucStrTmp);

    if (iMaxUser >= 4)
    {
        MOS_PRINTF("reqid %u iMaxUser = %d ",pstCmdMsg->uiSeqId,iMaxUser);
        return MOS_OK;
    }
    
    ST_P2PTURN_ADDRINFO * pstP2pAddrInfo = (ST_P2PTURN_ADDRINFO*)pstCmdMsg->aucMsgBody;

    if (AvClient_GetTurnAddr(pstCmdMsg->stMsgFromTo.aucUserToken) != MOS_NULL)
    {
        MOS_PRINTF("client is alivenow, force quit,peerid:%s\n", pstCmdMsg->stMsgFromTo.aucUserToken);
        P2pManageMent::instance().setClientTimeOut(pstCmdMsg->stMsgFromTo.aucUserToken);
        P2pManageMent::instance().checkClientTimeOut(MOS_TRUE);
    }

    AvClient_SetTurnAddr(pstCmdMsg->stMsgFromTo.aucUserToken, pstP2pAddrInfo);
    {
        ST_P2PTURN_ADDRINFO *pstP2pAddInfo = AvClient_GetTurnAddr(pstCmdMsg->stMsgFromTo.aucUserToken);
        pstP2pAddInfo->pKjClienRome = kj_rome_create(pstCmdMsg->stMsgFromTo.aucUserToken, NULL, kj_rm_role_server, NULL);
        if (pstP2pAddInfo->pKjClienRome != MOS_NULL)
        {
            MOS_LOG_INF(P2P_STRLOG, "ClientId(%s) Create KjClienRome = %p\n",pstCmdMsg->stMsgFromTo.aucUserToken,pstP2pAddInfo->pKjClienRome);
            pstP2pAddInfo->pcbSendP2pData      = P2pManageMent::onP2pSendData;
            pstP2pAddInfo->pcbDestoryClienRome = P2pManageMent::onP2pDestoryClienRome;

            pstP2pAddInfo->pKjClienRome->callback.state_cb                   = P2pManageMent::onP2pStatusCb;
            pstP2pAddInfo->pKjClienRome->callback.recv_data_cb               = P2pManageMent::onP2pRecvDataCb;
            pstP2pAddInfo->pKjClienRome->callback.send_sdp_to_endpoint_cb    = P2pManageMent::onP2pSendSdpToEndPointCb;
            pstP2pAddInfo->pKjClienRome->callback.streams_in_transmitting_cb = P2pManageMent::onP2pInTransmittingCb;
            pstP2pAddInfo->pKjClienRome->callback.connection_info_cb         = P2pManageMent::onP2pConnectionInfoCb;
            // pstP2pAddInfo->pKjClienRome->callback.ice_nat_detect_cb          = P2pManageMent::onP2pNatDetectCb;

            kj_rome_server Kjserver = { .stun_host      = (_C*)pstP2pAddInfo->aucStunHost,
                                        .stun_port      = (_C*)pstP2pAddInfo->aucStunPort,
                                        .turn_host      = (_C*)pstP2pAddInfo->aucTurnHost,
                                        .turn_port      = (_C*)pstP2pAddInfo->aucTurnPort,
                                        .turn_username  = (_C*)pstP2pAddInfo->aucTurnUsername,
                                        .turn_userpass  = (_C*)pstP2pAddInfo->TurnCredential,
                                        .ipv6_support   = (_C*)pstP2pAddInfo->iIpv6Support,
                                        .ipv6_stun_host = (_C*)pstP2pAddInfo->aucIPv6StunHost,
                                        .ipv6_stun_port = (_C*)pstP2pAddInfo->aucIPv6StunPort,
                                        .ipv6_turn_host = (_C*)pstP2pAddInfo->aucIPv6TurnHost,
                                        .ipv6_turn_port = (_C*)pstP2pAddInfo->aucIPv6TurnPort};
            kj_rome_get_sdp_with_server(pstP2pAddInfo->pKjClienRome, &Kjserver);

            kj_rome_enable_internal_keepalive(pstP2pAddInfo->pKjClienRome, 1);

            kj_rome_set_road_support(pstP2pAddInfo->pKjClienRome, kj_road_ice|kj_road_ptp);

            pstP2pAddInfo->ullTimeReq = Mos_GetLLTickCount();
        }
        else
        {
            _UC aucBuf[128] = {0};
            MOS_VSNPRINTF(aucBuf, sizeof(aucBuf), "client:%s, ICE CreateIce Failed\n", pstCmdMsg->stMsgFromTo.aucUserToken);
            CloudStg_UploadLogEx(Mos_GetSessionId(), __FUNCTION__, 0, EN_P2P_ERROR_CODE_P2P_CONN_FAIL, aucBuf, MOS_NULL, 1);
        } 
    }
    return MOS_OK;
}

/**
* @brief         package p2p data response
* @author        Hejh
* @date          2021-11-19
*/
static _UC *Cmd_ProcP2pDataTypeRsp(_UI uiSeqId, _UI resultCode, ST_FROM_TO_MSG *pstMsgFromTo,_UI uiMethodType)
{
    _UC aucMethod[64]  = {0};
    _UC aucResCode[4]  = {0};
    _UC *pucStrTmp     = MOS_NULL;
    JSON_HANDLE hRoot  = MOS_NULL;
    hRoot = Adpt_Json_CreateObject();
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X", EN_OGCT_METHOD_21CN_P2P_CMD, uiMethodType);
    MOS_VSNPRINTF(aucResCode, 4, "%u", resultCode);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));

    P2p_AddMsgSrcInfObject(hRoot, uiSeqId, pstMsgFromTo);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateString(aucResCode));
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pucStrTmp;
}

/**
* @brief         process client send p2p connect info[sdp or turn map info]
* @author        Hejh
* @date          2021-11-19
*/
_INT P2p_Task_ProcClientP2pConnctReq(ST_P2P_CMDTASK_MSG *pstCmdMsg)
{
    _INT iRet               = MOS_OK;
    ST_CMTASK_P2PDATAINFO *p2pMsgInfo = (ST_CMTASK_P2PDATAINFO*)pstCmdMsg->aucMsgBody;
    {
        _UI  uiResult   = 0;
        ST_P2PTURN_ADDRINFO *pstP2pAddInfo = AvClient_GetTurnAddr(pstCmdMsg->stMsgFromTo.aucUserToken);
        if (pstP2pAddInfo == MOS_NULL)
        {
            uiResult = 1;
        }
        _UC  *pucStrTmp = Cmd_ProcP2pDataTypeRsp(pstCmdMsg->uiSeqId, uiResult, &pstCmdMsg->stMsgFromTo, EN_CN21_P2P_APP_SEND_SDP_RESP);
        MsgMng_SendMsg(pstCmdMsg->aucPeerId,pstCmdMsg->uiSeqId, pstCmdMsg->ucMsgType, pstCmdMsg->ucMsgId + 1,
            pucStrTmp, MOS_STRLEN(pucStrTmp),MOS_NULL);

        MOS_PRINTF("peerid:%s reqid %u send rsp %s, len:%d\n",pstCmdMsg->aucPeerId , pstCmdMsg->uiSeqId,pucStrTmp, MOS_STRLEN(pucStrTmp));
        Adpt_Json_DePrint(pucStrTmp);
        MOS_PARAM_NULL_RETERR(pstP2pAddInfo);
    }

    if (p2pMsgInfo->uiP2pInfoType == EN_P2PMSG_IP_TYPE_V4_TYPE || p2pMsgInfo->uiP2pInfoType == EN_P2PMSG_IP_TYPE_V6_TYPE)//p2p
    {
        P2pManageMent::instance().onGenerateEnc();
        P2pManageMent::instance().onNewClientIceConnectTion(pstCmdMsg->stMsgFromTo.aucUserToken, pstCmdMsg);
        iRet = MOS_DELAY_FREE;
    }
    return iRet;
}


/**
* @brief         Deal whith register commands
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_ProcDevInfoMsg(_VPTR pstMsg)
{
    _INT iRet =  MOS_OK;
    if (Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    ST_P2P_CMDTASK_MSG *pstDevMsg         = (ST_P2P_CMDTASK_MSG*)pstMsg;
    ST_P2P_DEVMSG_HANDLER *pstMsgProcNode = P2p_FindDevMsgHandle(pstDevMsg->ucMsgType,pstDevMsg->ucMsgId);

    if (pstMsgProcNode == MOS_NULL)
    {
        MOS_LOG_ERR(P2P_STRLOG,"can't find msgtype %u or msgid %u ",pstDevMsg->ucMsgType,pstDevMsg->ucMsgId);
        return MOS_ERR;
    }

    if (pstMsgProcNode->pfunMsgProc)
    {
        iRet = pstMsgProcNode->pfunMsgProc(pstDevMsg);
    }
    return iRet;
}

/**
* @brief         sending data to client by clientId
* @author        Hejh
* @date          2021-05-13
*/
_INT P2p_SendDataToPeer(_UC aucPeerId[CFG_STRING_LEN],_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen)
{
    if (P2p_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }

    ST_AVCLIENT_INFO *avClient = P2pManageMent::instance().findAvclientById(aucPeerId);
    if (avClient != MOS_NULL)
    {  
        MOS_LOG_ERR(P2P_STRLOG,"%s###### send peer uiDatalen:%u pucData:%s", __FUNCTION__, uiDatalen, pucData);
        P2pProcessCmd::instance().procCmdSendMsg((_HP2PCHANNEL)avClient, ucMsgType, ucMsgId, pucData, uiDatalen); 
    }
    else
    {
        MOS_LOG_ERR(P2P_STRLOG,"%s %d @@@@@@ P2P RSP avClient == MOS_NULL", __FUNCTION__, __LINE__);
    }
    return MOS_OK;
}

/**
* @brief         Manager p2p connections, and process connect request cmd
* @author        Hejh
* @date          2021-05-13
*/
 _INT P2p_ServerTask_Loop(_VPTR pstArg)
{
    ST_MOS_MSGHEAD *pstMsgHead;
    MOS_LIST_INIT(&P2p_GetTaskMng()->stClientList);

    kj_timer_t  tCheckAliveTimeout;
    kj_timer_init(&tCheckAliveTimeout);
    getDiffTimems(&tCheckAliveTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    _UC ucOldCameOpenFlag = Config_GetCamaraMng()->uiCamOpenFlag;
    
    kj_timer_t   tFeedDogTimeOut;
    kj_timer_init(&tFeedDogTimeOut);
    getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    _HSWDWRITE hSwdFeedDog = Swd_AppThreadRegist(P2P_CONNECT_MNG, FEED_DOG_SUPER_MAX_TIMESEC);

    P2p_GetTaskMng()->uiSleepMonitorId = Config_AppSLeepMonotorRegist("P2P");
    while(P2p_GetTaskMng()->ucRunFlag)
    {
        pstMsgHead = Mos_MsgQueuePop(P2p_GetTaskMng()->hMsgQueque);
        if (pstMsgHead)
        {
            _INT  iNeedFree = MOS_TRUE;
            switch(pstMsgHead->usMsgType)
            {
                case EN_P2P_MSG_TYPE_NET:
                {
                    iNeedFree = P2p_ProcDevInfoMsg(pstMsgHead);
                    break;
                }
                default:
                {
                    break;
                }
            }
            if (iNeedFree != MOS_DELAY_FREE)
            {
                MOS_FREE(pstMsgHead);
            }
        }
        else
        {
            _INT keepAliveMseconds = getDiffTimems(&tCheckAliveTimeout, 0, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
            if (keepAliveMseconds >= P2P_KEEP_ALIVE_TIMEOUT || P2p_GetTaskMng()->ucCheckFlag>=1)
            {
                getDiffTimems(&tCheckAliveTimeout, 1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
                P2pManageMent::instance().checkClientTimeOut(0, P2p_GetTaskMng()->ucCheckFlag);
                if (P2p_GetTaskMng()->ucCheckFlag >=1)
                {
                    P2p_GetTaskMng()->ucCheckFlag = 0;
                }
                AvClient_CheckTimeoutTurnAddr();
            }

            if (Config_GetCamaraMng()->uiCamOpenFlag != ucOldCameOpenFlag)
            {
                ucOldCameOpenFlag = Config_GetCamaraMng()->uiCamOpenFlag;
                P2pManageMent::instance().checkClientTimeOut(!ucOldCameOpenFlag);
            }

            if (getDiffTimems(&tFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
            {
                Swd_AppThreadFeedDog(hSwdFeedDog);
                getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
            }
            Mos_Sleep(5);
        }
    }

    Swd_AppThreadUnRegist(hSwdFeedDog);
    /*在P2p_Task_Stop已释放*/
    // _VPTR pstMsg = MOS_NULL;
    // while((pstMsg = Mos_MsgQueuePop(P2p_GetTaskMng()->hMsgQueque)) != MOS_NULL)
    // {
    //     MOS_FREE(pstMsg);
    // }
    // Config_AppSLeepMonotorUnRegist(P2p_GetTaskMng()->uiSleepMonitorId);
    // Mos_ThreadDelete(P2p_GetTaskMng()->hThread);
    // P2p_GetTaskMng()->ucRunFlag = 0;
    return MOS_OK;
}


////stun.miwifi.com:3478
////turn:106.55.39.76:8478?transport=udp //113.125.71.247:8340;182.43.197.59:8341
 _INT P2p_Config_Addr(_UC *pucSturnUrl, _UC *pucTrunUrl, _UC *pucTurnUername, _UC *pucTrunUserPasswd)
 {
    return MOS_OK;
 }

_INT P2p_CloseClientSpeakerAndDisplay(_INT iNeedCloseLive, _INT iNeedCheckSessionId, _INT iSessionId)
{
    P2pManageMent::instance().CloseClientSpeakerAndDisplay(iNeedCloseLive, iNeedCheckSessionId, iSessionId);
    return MOS_OK;
}
