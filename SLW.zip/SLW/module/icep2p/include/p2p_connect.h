#ifndef _P2P_CONNECT_API_H
#define _P2P_CONNECT_API_H

#include "p2p_type.h"

#ifdef __cplusplus
extern "C" {
#endif
ST_CONNETP2P_MNG *P2p_GetTaskMng();

_INT P2p_Task_Init();

_INT P2p_Task_Start();

_INT P2p_Task_Stop();

_INT P2p_Task_Destroy();

_INT P2p_Config_Addr(_UC *pucSturnUrl, _UC *pucTrunUrl, _UC *pucTurnUername, _UC *pucTrunUserPasswd);

_INT P2p_SetGetDevSdpMsg(_UC *pucPeerId,_UI uiSeqId, ST_FROM_TO_MSG *pstMsgFromTo,
                      ST_CMTASK_GETSDPINFO* pstClientSdp );
_INT P2p_ReciveClientP2pDataMsg(_UC *pucPeerId,_UI uiSeqId, ST_FROM_TO_MSG *pstMsgFromTo,
                                  ST_CMTASK_P2PDATAINFO *pstSdpInfo);

_INT P2p_SetGetClientNumberMsg(_UC *pucPeerId,_UI uiSeqId, ST_FROM_TO_MSG *pstMsgFromTo,
                               _VPTR pMsgParam);

_INT P2p_SetPrepareConnectMsg(_UC *pucPeerId,_UI uiSeqId, ST_FROM_TO_MSG *pstMsgFromTo,
                      _VPTR *pucRole);

_INT P2p_SendDataToPeer(_UC aucPeerId[CFG_STRING_LEN],_UC ucMsgType,_UC ucMsgId,_UC* pucData,_UI uiDatalen);

_INT P2p_Task_ProcClinetNumber(ST_P2P_CMDTASK_MSG *pstCmdMsg);
_INT P2p_Task_ProcClientP2pConnctReq(ST_P2P_CMDTASK_MSG *pstCmdMsg);

_INT P2p_ProcDevInfoMsg(_VPTR pstMsg);

/*
关闭喇叭输出和视频显示输出
iNeedCloseLive: 是否一并关闭推流
iNeedCheckSessionId:是否开启SessionId检测（开启时，判断上一次是否同一个iSessionId，若相同，则不关闭喇叭输出和视频显示输出）
iSessionId: 客户端连接ID
*/
_INT P2p_CloseClientSpeakerAndDisplay(_INT iNeedCloseLive, _INT iNeedCheckSessionId, _INT iSessionId);

#ifdef __cplusplus
}
#endif
#endif
