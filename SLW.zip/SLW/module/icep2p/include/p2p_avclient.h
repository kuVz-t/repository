#ifndef P2P_AVCLIENT_H
#define P2P_AVCLIENT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"
#include "p2p_type.h"

typedef struct stru_AVCLIENT_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _US             usIndexId;
    _HMUTEX         hMutex;
    _UC             aucIPv6Addr[CFG_STRING_LEN];   // 设备本地IPv6地址
    ST_MOS_LIST     stP2pTurnInfoList;
}ST_AVCLIENT_MNG;

typedef struct stuct_ClientTurnInfoNode
{
    _UI    uiUseFlag;              // 0：未分配内存 1：分配内存
    _UI    uiClientIndexId;
    _UC    aucClientName[64];
    ST_P2PTURN_ADDRINFO stP2pTurnInfo;
    ST_MOS_LIST_NODE    stNode;
}ST_CLIENT_TURNNODE;

ST_AVCLIENT_MNG *AvClient_GetInfoMng();
_UI AvClient_P2pInfoInit();
_UI Avclient_RemoveP2pInfo();
ST_P2PTURN_ADDRINFO* AvClient_GetTurnAddr(_UC *aucClientId);
_UI AvClient_SetTurnAddr(_UC *aucClientId, ST_P2PTURN_ADDRINFO *pTurnInfo);
_UI AvClient_RemoveTurnAddr(_UC *aucClientId);
_UI AvClient_CheckTimeoutTurnAddr();
_UI AvClient_SetLocalIPv6Addr(_UC *pucLocalIPv6Addr);
_UI AvClient_GetLocalIPv6Addr(_UC *pucLocalIPv6Addr, _UI uiLocalIPv6AddrLen);
ST_P2PTURN_ADDRINFO* AvClient_GetTurnAddrByKjClienRome(kj_rome *rome);
_UI AvClient_RemoveNoUsedClienRome();

#ifdef __cplusplus
}
#endif

#endif // P2P_AVCLIENT_H
