/*
 * @Author: your name
 * @Date: 2020-10-26 23:10:51
 * @LastEditTime: 2020-10-27 01:54:37
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /yjDeviceSdk/demos/p2pdemo/P2pManageMent.hpp
 */

#ifndef __P2P_MANAGE_MENT__
#define __P2P_MANAGE_MENT__
#include "pthread.h"
#include "pjlib.h"
#include "mos.h"
#include "p2p_type.h"
#include "p2p_ProcessCmd.h"
#include "kj_timer.h"
#include "media_audioplay.h"
#include "kj_mutex.h"
#include "media_video.h"
#include "media_video_display.h"

typedef enum ICE_TRANS_MODE{
    MODE_NONE ,
    ICE_RELAY , //中继模式
    ICE_P2P  //直连模式
} ice_trans_mode;
typedef enum P2P_NAT_TYPE
{
    P2P_NAT_TYPE_UNKNOWN,
    P2P_NAT_TYPE_ERR_UNKNOWN,
    P2P_NAT_TYPE_OPEN,
    P2P_NAT_TYPE_BLOCKED,
    P2P_NAT_TYPE_SYMMETRIC_UDP,
    P2P_NAT_TYPE_FULL_CONE,
    P2P_NAT_TYPE_SYMMETRIC,
    P2P_NAT_TYPE_RESTRICTED,
    P2P_NAT_TYPE_PORT_RESTRICTED
} P2P_NAT_TYPE;

typedef enum P2P_LINK_STATUS
{
    EN_P2P_MSG_STATUS_UNKNOW         = 0,
    EN_P2P_MSG_STATUS_ICECREAT       = 1,
    EN_P2P_MSG_STATUS_ICECREAT_FAIL   ,
    EN_P2P_MSG_STATUS_ICENEG_OK       ,
    EN_P2P_MSG_STATUS_ICENEG_FAIL     ,
    EN_P2P_MSG_STATUS_TURN_ALLOC      ,
    EN_P2P_MSG_STATUS_TURN_HOLE_OK    ,
    EN_P2P_MSG_STATUS_TURN_HOLE_FAIL
}P2P_MSG_STATUS;

#define RECORD_VIDEO_NALU_BUFLEN   (1400)


typedef enum ST_TBSL_RECV_STATUS
{
    EN_TBSL_RECV_STATUS_START  = 0, // 开始接收
    EN_TBSL_RECV_STATUS_RECVING,    // 接收中
    EN_TBSL_RECV_STATUS_END,        // 接收结束
    EN_TBSL_RECV_STATUS_ERR         // 接收出错
}ST_TBSL_RECV_STATUS;
typedef struct stru_TBSL_INFO
{
    _UC ucRecVStatus;  // 接收状态, refer to ST_TBSL_RECV_STATUS
    _UC ucAvType;      // 媒体数据类型：1：视频；2：音频
    _UC ucFrameType;   // 视频帧标记, 1：I帧；0：P帧
    _UC ucRes;         // 保留
    _UI uiFrameLen;    // 帧长
    _UI uiRecvLen;     // 已接收长度
    _UI uiLeftLen;     // 剩余未接收的长度
    _UI uiTimeStamp;   // 帧的时间戳，当天的毫秒数
    _UC *aucFrameBuf;  // 帧Buf
}ST_TBSL_INFO;

typedef struct avClientInfo
{
    _UC               m_uacPeerId[STRING_ICE_NAME_LENGHT];//client userToken
    ST_P2PTURN_ADDRINFO *m_iceTranSport;//one client one transport
    ST_THREAD_MNG     m_liveCmdThreadMng;//one client one command thread
    ST_PLAYBACK_MNG   m_playBackThreadMng;//playback command thread
    _UC               m_bEnableVideo;
    _UC               m_ucStreamId;       //0-main stream, 1-sub stream
    _UC               m_ucNeedIframe;     //1-need iframe 0-not need
    _US               m_sLiveVideoChn;
    _US               m_sLiveAudioChn;
    _US               m_sAudioSpeakChn;
    _US               m_sVideoDisplayChn;
    _BOOL             m_bEnableAudio;
    _BOOL             m_bEnableSpeaker;
    _BOOL             m_bEnableDisplay;
    _INT              m_iSessionId;
    _HAUDIOPLAY       m_hAudioPlay;
    _HVPLAYHANDLE     m_hVideoPlay;    
    _BOOL             m_bChannelTimeOut;
    kj_timer_t        m_tReiveAudioDataTimeout; //对端对讲数据接收时间
    kj_timer_t        m_tReiveVideoDataTimeout; //对端视频数据接收时间
    ST_MSGP2P_KEEPALIVE_CHANNEL_INFO    m_stKeepAliveChannelInfo;//ST_MSGP2P_KEEPALIVE_BODY
    ST_MSGP2P_INTRANSMITTING_CHANNEL_INFO   m_stInTransmittingChannelInfo;
    _HMUTEX           hMutex;
    ST_MOS_LIST_NODE  stNode;
}ST_AVCLIENT_INFO;

class P2pManageMent  
{
public:
    P2pManageMent();
    ~P2pManageMent();

    static P2pManageMent &instance()
    {
        static P2pManageMent instance_;
        return instance_;
    }

    _VOID  InitP2p(_UC *deviceId);
    _VOID  UninitP2p();

    _VOID  StartP2p();
    _VOID  StopP2p();
    _VOID  DestoryP2p();

    _UC*   onNewClientIceConnectTion(_UC *uacPeerId, _VPTR pstP2pMsgInfo);

    _UI    onGenerateEnc();
    ST_HTTP_ENCRYPTO_INF*   getDevTransEnc();
    ST_HTTP_ENCRYPTO_INF*   setDevTransEnc(_INT iEncType,_UC *paucEncKey, _UC *paucEncLv);

    //发送视频线程
    static _VPTR createliveVideo(_VPTR obj);
    _VOID  initLiveVideo();
    _UI    startLiveVideo();
    _INT   destoryLiveVideo();
    _INT   stopLiveVideo();
    _INT   *liveVideoThread(_VPTR arg);

    //发送音频线程
    static _VPTR createliveAudio(_VPTR obj);
    _VOID  initLiveAudio();
    _UI    startLiveAudio();
    _INT   destoryLiveAudio();
    _INT   stopLiveAudio();
    _INT  *liveAudioThread(_VPTR arg);
    _INT  addResendMediaReq(_INT iMediaType, _VPTR pFeedBackPara);
    _INT  addResendPlaybackMediaReq(ST_AVCLIENT_INFO *pAvClientInfo,
                                    _VPTR pFeedBackPara);

    //接收所有命令部分线程
    _VOID initCommandFunctions();
    _VOID initProcCommand(ST_AVCLIENT_INFO *pstTask);
    _UI   startProcCommand(_VPTR clientToken);
    static _VPTR p2pCommandThread(_VPTR arg);
    _INT  stopAllLiveCmd();

    static _VOID  onP2pStatus_Disconnected_Handle(_VPTR pstP2pAddrInfo, kj_code status_coder);
    static _VOID  onP2pStatus_ConnectFailed_Handle(_VPTR pstP2pAddrInfo, kj_code status_coder);
    static _VOID  onP2pStatus_Connecting_Handle(_VPTR pstP2pAddrInfo, kj_code status_coder);
    static _VOID  onP2pStatus_Connected_Handle(_VPTR pstP2pAddrInfo, kj_code status_coder);

    static _VOID  onP2pStatusCb(kj_rome *rome, kj_cnt_state state, kj_code status_coder);
    static _VOID  onP2pRecvDataCb(kj_rome *rome, const void *data, size_t data_len);
    static _INT   onP2pSendSdpToEndPointCb(kj_rome *rome, const char *sdp, int ipv6);
    static _VOID  onP2pInTransmittingCb(kj_rome *rome, uint16_t stream_channels[], int channel_count);
    static _VOID  onP2pConnectionInfoCb(kj_rome *rome, kj_rmcnt_info cnt_infos[], int cnt_count, kj_rmcnt_extra_info extra_info);
    static _VOID  onP2pNatDetectCb(kj_rome *rome, int nat_type);

    static _VOID  onP2pDestoryClienRome(_VPTR hP2pClienRome);
    static _INT   onP2pSendData(_VPTR hP2pChnnel, _VPTR data, _UL data_len);

    ST_MSGP2P_MNG *MsgP2p_GetMng();
    ST_MSGP2P_ACTIVE_NODE *MsgP2p_FindActiveNode(_UC usMsgType, _UC ucMsgId);
    _VOID p2pCmdregistActiveFunc(_UC usMsgType, _UC ucMsgId, PFUN_MSGMNG_ACTIVEPROC pFunActiveMsgProc);

    _INT checkSpeakerClient();
    _INT checkDisplayClient();
    _INT getOnVideoClient(_INT inLive=1);
    _INT checkClientTimeOut(_INT iForceQuit=0,_INT iNeedNotifyClose=1);
    _INT CloseClientSpeakerAndDisplay(_INT iNeedCloseLive, _INT iNeedCheckSessionId, _INT iSessionId);
    _INT setClientTimeOut(_HP2PCHANNEL hP2pChnnel);
    _INT setClientTimeOut(_UC *aucPeerId);
    ST_AVCLIENT_INFO *findAvclientById(_UC *uacPeerId);
    ST_AVCLIENT_INFO *GetAvClient(_UC *aucPeerId);

    _INT setClientStartLiveVideo(_HP2PCHANNEL hP2pChnnel, _INT iStreamId, _UI uiChnId);
    _INT setClientCloseLiveVideo(_HP2PCHANNEL hP2pChnnel, _INT iStreamId);

    _INT setClientStartLiveForVideo(_HP2PCHANNEL hP2pChnnel, _INT iStreamId, _UI uiChnId);
    _INT setClientStartLiveForAudio(_HP2PCHANNEL hP2pChnnel, _UI uiChnId);
    _INT setClientCloseLiveAll(_HP2PCHANNEL hP2pChnnel);
    _UI  startPlayback(_HP2PCHANNEL hP2pChannel, _UC *pucFileName);
    static _VPTR PlayBackThread(_VPTR arg);////每次通过接收回放命令启动此线程

    static _VOID P2pTbslRecvCb(const kj_tbsl *tbsl, const kj_data *data);
    static _VOID P2pTbslSendCb(const kj_tbsl *tbsl, const kj_data *data);
    _INT P2pCreateTbsl(_VPTR hP2pChnnel, kj_tbsl_mode tbsl_mode, kj_av_type av_type);
    _INT P2pDestroyTbsl(_VPTR hP2pChnnel, kj_av_type av_type);
private:
    ST_MOS_LIST      m_hIceClientList;
    P2pProcessCmd    &m_hProcessCmd;
    ST_THREAD_MNG    m_liveVideoThread;
    ST_THREAD_MNG    m_liveAudioThread;
    ST_THREAD_MNG    m_liveSpeakThread;
    ST_MSGP2P_MNG    m_p2pCmdFuncMnger;
    KjRwMutexLock    m_mutexAvclientList;
    ST_HTTP_ENCRYPTO_INF  m_aucP2pTrasEnc;
};

#endif
