#ifndef P2P_TYPE_H
#define P2P_TYPE_H
#include "msgmng_api.h"
#include "config_api.h"
#include "cmdhdl_type.h"
#include "media_cache_type.h"
#include "kj_timer.h"

#include "kj_tbsl.h"
#include "kj_rome.h"
#include "kj_rm_types.h"

#define P2P_STRLOG                    (_UC*)"P2P"
#define P2PCMD_STRLOG                 (_UC*)"P2P"
#define AV_CLIENT_TIMEOUT_SECOND      (15*1000)
#define STRING_ICE_NAME_LENGHT        128
#define MAX_P2P_RECIVE_BUF_LEN        (10*1024)
#define P2P_LINK_TIMEOUT_SEC          (25)
#define P2P_AUDIODATA_TIMEOUT_SEC     (15)
#define P2P_KEEP_ALIVE_TIMEOUT        (5*1000)
#define P2P_CHANNEL_CHECK_TIMEOUT_TIMES 4
#define P2P_CHANNEL_CHECK_MAX         (64)

typedef  MOS_MASK_HANDLE_TYPE(_HP2PCHANNEL)           _HP2PCHANNEL;

typedef enum enum_P2P_MES_HEADER_TYPE
{
    EN_P2P_MSG_TYPE_NET        = 0,
    EN_P2P_MSG_TYPE_TRANS_INFO = 1
}EN_P2P_MSG_TYPE;

typedef enum enum_P2P_THREAD_MNG_TYPE
{
    EN_P2P_THREAD_MNG_TYPE_INIT  = 0,
    EN_P2P_THREAD_MNG_TYPE_START = 1,
    EN_P2P_THREAD_MNG_TYPE_END   = 2
}EN_P2P_THREAD_MNG_TYPE;

// 内部消息
typedef struct stru_P2P_CMDTASK_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UC  ucMsgType;
    _UC  ucMsgId;
    _UC  ucRsv[2];
    _UI  uiSeqId;
    _UC  aucPeerId[CFG_STRING_LEN];
    ST_FROM_TO_MSG stMsgFromTo;
    _UC aucMsgBody[0];
}ST_P2P_CMDTASK_MSG;

typedef struct stru_P2P_TRANS_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UC  ucMsgType;
    _UC  ucMsgStatus;
    _UC  ucRsv[2];
    _UC  aucPeerId[CFG_STRING_LEN];
    _UC aucMsgBody[0];
}ST_P2P_TRANS_MSG;

typedef struct stru_P2P_CMD_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UC  ucMsgType;
    _UC  ucMsgId;
    _UC  ucRsv[2];
    _INT iSeqNum;
    _UC aucMsgBody[0];
}ST_P2P_CMD_MSG;

typedef struct stru_P2P_FEEDBACK_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UC  ucMsgType;
    _UC  ucMsgId;
    _UC  ucAvType;
    _UC  ucRsv;
    _INT iSeqNum;
    _UC  aucPeerId[CFG_STRING_LEN];
    _UC aucMsgBody[0];
}ST_P2P_FEEDBACK_MSG;

typedef _INT (*PFUN_P2P_DEVMSG_PROC)(ST_P2P_CMDTASK_MSG *pstCmdMsg);

//handle signalServer cmd refrence p2p
typedef struct stru_P2P_DEVMSG_HANDLER
{
    _UC ucMsgType;
    _UC ucMsgId;
    PFUN_P2P_DEVMSG_PROC pfunMsgProc; // 回调函数
}ST_P2P_DEVMSG_HANDLER;

//client link sdp info
typedef struct stru_CMSTASK_GETSDPINFO
{
    _UC aucSdpType[CFG_STRING_LEN];
    _UC aucSdpInfo[CFG_STRING_SDP_LENGTH];
    _UC aucP2PToken[CFG_STRING_LEN];
}ST_CMTASK_GETSDPINFO;

typedef enum P2PMSG_IP_TYPE
{
    EN_P2PMSG_IP_TYPE_UNKNOW   = 0,
    EN_P2PMSG_IP_TYPE_V4_TYPE  = 1,
    EN_P2PMSG_IP_TYPE_V6_TYPE  = 2
}EN_P2PMSG_IP_TYPE;

//client link sdp info
typedef struct stru_CMSTASK_P2PDATAINFO
{
    _UI uiP2pInfoType; //refrence EN_P2PMSG_INFO_TYPE
    _UC aucRemoteSdpInfo[CFG_STRING_SDP_LENGTH];
    _UC aucChnId[CFG_STRING_LEN];
    _UC aucRelayAddr[CFG_STRING_LEN];
    _UC aucMappedAddr[CFG_STRING_LEN];
}ST_CMTASK_P2PDATAINFO;

typedef _INT (*fP2pSendData)(_VPTR , _VPTR, _UL );
typedef _VOID (*fDestoryClienRome)(_VPTR);

typedef struct stru_P2PTURN_ADDRINFO
{
    _UC aucStunHost[CFG_STRING_LEN];
    _UC aucStunPort[CFG_STRING_COMMONLEN];
    _UC aucStun2Host[CFG_STRING_LEN];
    _UC aucStun2Port[CFG_STRING_COMMONLEN];    
    _UC aucTurnHost[CFG_STRING_LEN];
    _UC aucTurnPort[CFG_STRING_COMMONLEN];

    _UC aucIPv6StunHost[CFG_STRING_LEN];
    _UC aucIPv6StunPort[CFG_STRING_COMMONLEN];
    _UC aucIPv6Stun2Host[CFG_STRING_LEN];
    _UC aucIPv6Stun2Port[CFG_STRING_COMMONLEN];    
    _UC aucIPv6TurnHost[CFG_STRING_LEN];
    _UC aucIPv6TurnPort[CFG_STRING_COMMONLEN];

    _INT iIpv6Support;
    _UC aucTurnUsername[CFG_MAX_TURN_NAME_LENGTH];
    _UC TurnCredential[CFG_STRING_LEN];

    kj_rome *pKjClienRome;
    kj_tbsl *m_video_tbsl;  // 视频流数据可靠传输对象
    kj_tbsl *m_audio_tbsl;  // 音频流数据可靠传输对象
    _VPTR pIceIpv4ReqInfo;
    _VPTR pIceIpv6ReqInfo;
    _UC aucDevIpv4SdpInfo[CFG_STRING_SDP_LENGTH];
    _UC aucDevIpv6SdpInfo[CFG_STRING_SDP_LENGTH];
    _UI uiTransResult;  //refrence P2P_MSG_STATUS
     kj_timer_t  tobjTimeout;
    _VPTR pPrivateData;    //point to avclient
    _ULLID ullTimeReq;

    fP2pSendData      pcbSendP2pData;
    fDestoryClienRome pcbDestoryClienRome;
}ST_P2PTURN_ADDRINFO;

//p2p link status
typedef enum enum_P2P_STATUS
{
    P2P_STATUS_UNKNOW      = 0,
    P2P_STATUS_INIT        = 1,
    P2P_STATUS_WAIT_SDP    = 2,
    P2P_STATUS_START_NEGO  = 3,
    P2P_STATUS_CONNECT_OK  = 4,
    P2P_STATUS_CONNECT_FAILD=5
}EN_P2P_STATUS;

//link client info
typedef struct stru_CLIENT_CONNECT_INFO
{
    EN_P2P_STATUS en_connectStatus;//connect p2p status
    _UC ucUserToken[CFG_STRING_LEN];//user id
    _UC ucClientSdp[CFG_STRING_SDP_LENGTH]; //client sdp
    _UC ucDeviceSdp[CFG_STRING_SDP_LENGTH]; //device sdp
}ST_CLIENT_CONNECT_INFO;

//p2p listen thread
typedef struct stru_CONNETP2P_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _UC             ucCheckFlag;
    _UC             ucRsv;
    _HTHREAD        hThread;
    _HQUEUE         hMsgQueque;
    _UI             uiFormatFlag;
    _UI             uiSleepMonitorId;
    ST_MOS_LIST     stClientList;
}ST_CONNETP2P_MNG;

//p2p ICE cmd info queue ,just for test
typedef struct stru_ICEINFO_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _UC             ucRsv[2];
    _HQUEUE         hMsgQueque;
    _UI             uiFormatFlag;
}ST_ICEINFO_MNG;

//p2p audio,video,speak thread
typedef struct stru_THREAD_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _UC             ucOverFlag; //refer to EN_P2P_THREAD_MNG_TYPE
    _UC             ucRsv[2];
    _HTHREAD        hThread;
    _HQUEUE         hMsgQueque;
}ST_THREAD_MNG;

typedef enum VOD_CMD_TYPE
{
    VOD_CMD_PAUSE    = 0X01,
    VOD_CMD_REPLAY   = 0X02,
    VOD_CMD_KEYFRAME = 0X04,
    VOD_CMD_TEADOWN  = 0X08,
    VOD_CMD_SEEK     = 0X10
}EN_VOD_CMD_TYPE;

typedef enum PLAYBACK_STATUS
{
    EN_PLAYBACK_STATUS_UNKNOW= 0,
    EN_PLAYBACK_STATUS_INIT  = 1,
    EN_PLAYBACK_STATUS_START = 2,
    EN_PLAYBACK_STATUS_PAUSE = 3,
    EN_PLAYBACK_STATUS_SEEK  = 4,
}EN_PLAYBACK_STATUS;

//p2p audio,video,speak thread
typedef struct stru_PLAYBACK_MNG
{
    _UC             ucInitFlag;
    _UC             ucRunFlag;
    _UC             ucPlayStatus;
    _UC             ucPlayFlag;    //0-single file, 1-continous
    _US             usAvWinSize[2];//media package win size
    _UC             ucDownFlag;    //0-playback 1-download
    _UC             ucOverFlag;    //refer to EN_P2P_THREAD_MNG_TYPE
    _UC             ucReserv;
    _US             usChannel;
    _HTHREAD        hThread;
    _HQUEUE         hMsgQueque;
    _HPBVIDEOREAD   hVideoHander;
    _HPBVIDEOREAD   hAudioHander;
    _UC             ucFilePath[128];
}ST_PLAYBACK_MNG;

typedef _INT (*PFUN_MSGP2P_ACTIVEPROC)(_VPTR pP2pChanel,_UI uiSeqId,_VPTR hJsonRoot);
//p2p cmd function list
typedef struct stru_msgP2p_Active_Node
{
    _UC usMsgType;
    _UC ucMsgId;
    _UC ucRsv[2];
    PFUN_MSGP2P_ACTIVEPROC pFunActiveProc;
    ST_MOS_LIST_NODE stNode;
}ST_MSGP2P_ACTIVE_NODE;

typedef struct str_Msgp2p_mng
{
    _UC ucInitFlag;
    _HMUTEX hMutex;
    ST_MOS_LIST stActiveFunList;   // ST_MSGP2P_ACTIVE_NODE
}ST_MSGP2P_MNG;

typedef struct struct_msg_keepalive
{
    _UC usMsgType;
    _UC ucMsgId;
    _UC ucRsv[2];    
    _UC aucMsgBody[128];
}ST_MSGP2P_OPTION;

typedef enum FEED_BACK_CMD_TYPE
{
    EN_FEED_BACK_NORMAL         = 0,
    EN_FEED_BACK_PAUSE_SENDDING = 1,
    EN_FEED_BACK_FINISH_SENDING = 2,
    EN_FEED_BACK_FINISH_RECIVE  = 3,
    EN_FEED_BACK_NOTIFY_ITERVEL = 4
}EN_FEED_BACK_CMD_TYPE;

typedef enum PST_MODE
{
    EN_PST_MODE_TRS_CLOSE        = 0,
    EN_PST_MODE_TRS_HDL_ORDER    = 1,
    EN_PST_MODE_TRS_LOSE_PACK    = 2,
    EN_PST_MODE_TRS_NOLOSE_PACK  = 3,
    EN_PST_MODE_TRS_NOLOSE_FSPEED  = 4
}EN_PST_MODE_TRS;

typedef enum ENUM_SDP_TYPE
{
    EN_SDP_TYPE_ANSWER      = 0,
    EN_SDP_TYPE_OFFER       = 1,
    EN_SDP_TYPE_CONNECTTION = 2,
    EN_SDP_TYPE_CONNECTFAIL = 3,
}ENUM_SDP_TYPE;

typedef enum ENUM_P2P_ERROR_CODE
{
    EN_P2P_ERROR_CODE_REGISTER_FAIL                = 230001, // p2p服务注册失败(deprecated)  
    EN_P2P_ERROR_CODE_AUTH_FAIL                    = 230002, // p2p服务auth失败(deprecated)
    EN_P2P_ERROR_CODE_NAT_DETECT_FAIL              = 230003, // nat检测失败(deprecated)
    EN_P2P_ERROR_CODE_P2P_CONN_FAIL                = 230004, // p2p打洞失败
    EN_P2P_ERROR_CODE_P2P_CONN_SUCCESS             = 230005, // p2p直连打洞成功
    EN_P2P_ERROR_CODE_PLAYBACK_ALREADY_MAX_CONN    = 230006, // p2p卡回看连接已达到最大连接数
    EN_P2P_ERROR_CODE_PLAYBACK_OPEN_VIDEO_FAIL     = 230007, // p2p卡回看无法打开对应的视频
    EN_P2P_ERROR_CODE_P2P_TURN_SUCCESS             = 230008, // p2p洞Turn转发成功
    EN_P2P_ERROR_CODE_SDP_SENDRSP_SUCCESS          = 230009, // p2p发送设备sdp信息，成功收到回复
    EN_P2P_ERROR_CODE_NAT_DETECT_SUCCESS           = 230010, // p2p设备nat探测结果
    EN_P2P_ERROR_CODE_P2P_V6_CONN_FAIL             = 230011, // p2p IPV6打洞失败
    EN_P2P_ERROR_CODE_P2P_V6_CONN_SUCCESS          = 230012, // p2p IPV6直连打洞成功
    EN_P2P_ERROR_CODE_P2P_V6_TURN_SUCCESS          = 230013, // p2p IPV6 Turn转发成功
    EN_P2P_ERROR_CODE_P2P_DEC_NOT_SUPPORTED        = 230014, // 客户端不支持设备的编码类型
    EN_P2P_ERROR_CODE_P2P_ENC_NOT_SUPPORTED        = 230015, // 设备不支持对端的编码类型
    EN_P2P_ERROR_CODE_P2P_ABILITY_NOSET            = 230016, // 本机双向视频通话能力值为0
    EN_P2P_ERROR_CODE_P2P_DISPLAY_OCCUOIED         = 230017  // 本机音频、视频输出被占用中
    // TODO:
}ENUM_P2P_ERROR_CODE;

#pragma pack (1)
typedef struct struct_msg_feedback
{
    _US    usChannel;   // 数据通道号
    _UC    ucAvType;    // 媒体类型：1 视频，2 音频
    _UC    ucPsrtMode;  // 传输协议，0 关闭协议；1 只处理乱序；2 丢包模式；3 无丢包模式
    _UC    ucPackSeq;   // 发送方需把此值设置到重发数据报文头的保留字节中，用于接收方计算RTT
    _UC    ucAckType;   // 控制类型。无丢包模式时:(收->发：0接收反馈；3结束接收)、(发->收：1暂停发送；2结束发送，接收方收到需回复3；4发送方告知其存储数据时间范围)
    _US    usWinBeginSeq; //无丢包模式时：窗口起始值；丢包模式时：ucAckType==4发送方所能存储数据的最大时间范围，毫秒值,
    _US    usWinSize;   // 可靠传输窗口大小，用于发送方可发送的包个数，丢包模式忽略该值
    _US    usNackCount; // 序号数量,tbsl_mode为2的时候即为丢包序号的数量，ucPsrtMode为3的时候即为收到的序号数量
    _US    usSeqList[1];// 前面数据为收到的序号，后面的为缺失的数据序号
}ST_MSGP2P_FEEDBACK;

typedef struct struct_p2p_recive_mng
{
    _UI                 uiInitFlag;
    _HMUTEX             hMutexRecive;        // 发送数据的互斥锁
    _UI                 uiMaxBufLen;
    _UI                 uiPayloadLen;       // 有效数据长度
    _HSOCKBUFF          hSockBuffPool;      //
    ST_MOS_SOCKBUF*     pstRecvBuf;           // 接收到信令服务器的json数据
}ST_P2P_RECIVE_MNG;

typedef struct struct_msg_keepalive_channel
{
    _US    usChannelType;
    _US    usChannelCount; // 序号数量
    _US    usChannelList[1];// 前面数据为收到的序号，后面的为缺失的数据序号
}ST_MSGP2P_KEEPALIVE_BODY;

typedef struct struct_msg_intransmitting_info
{
    _UC  uiCheckFlag;
    _US  usChannelCount;
    _US  usChannelList[P2P_CHANNEL_CHECK_MAX];
}ST_MSGP2P_INTRANSMITTING_CHANNEL_INFO;

typedef struct struct_msg_keepalive_info
{
    _UI uiCheckTimes;
    _UI uiMsgLen;
    _UC stMsgBody[64];//ST_MSGP2P_KEEPALIVE_BODY
}ST_MSGP2P_KEEPALIVE_CHANNEL_INFO;

#pragma pack ()
#endif // P2P_TYPE_H
