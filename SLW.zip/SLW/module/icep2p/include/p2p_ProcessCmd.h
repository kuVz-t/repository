#ifndef P2P_PROCESSCMD_H
#define P2P_PROCESSCMD_H
#include "mos.h"
#include "p2p_type.h"
#include "http_api.h"
#include "adpt_json_adapt.h"
#include "media_cache_type.h"

class P2pProcessCmd
{
public:
    static P2pProcessCmd &instance()
    {
        static P2pProcessCmd instance_;
        return instance_;
    }
    P2pProcessCmd();
    static _INT procCmdServerMsg(_HP2PCHANNEL hP2pChnnel, _UC *pucMsgBuff, _INT iMsgBuffLen);
    static _INT procCmdSendMsg(_HP2PCHANNEL hP2pChnnel, _UC msgType, _UC msgId, _UC *pucMsgBuff,
                        _INT iMsgBuffLen, _UC msgRev=0);
    static _INT procCmdGetDevInfo(_HP2PCHANNEL hP2pChnnel, _UI iSeqNumber, _VPTR hroot);
    static _INT procCmdSendKeepAlive(_HP2PCHANNEL hP2pChnnel, _UC msgType, _UC msgId, _UC msgRev=0);
    static _INT procCmdReciveKeepAlive(_HP2PCHANNEL hP2pChnnel, _UC msgType, _VPTR msgParam);
    static _INT procCmdReciveFeedBack(_HP2PCHANNEL hP2pChnnel, _UI msgLen, _VPTR msgParam);
    static _INT ProCmdResendMediaReq(_HP2PCHANNEL hP2pChnnel, _UC ucMsgType, _UC ucMsgId,
                                     _INT iAvType, _UC *pucMsgBuff, _INT iMsgBuffLen);

    static _INT procCmdStartLiveVideo(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdCloseLiveVideo(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);

    static _INT procCmdStartSpeaker(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdCloseSpeaker(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);

    static _INT procCmdStartDisplay(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdCloseDisplay(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdContorlDisplay(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    
    //playback commands
    static _INT procCmdGetRecordCalender(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdGetRecordList(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdGetJpegCalender(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdGetJpegList(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdStartPlayBack(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdControlPlayBack(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdStopPlayBack(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT P2pPlaybackStop(_HP2PCHANNEL hP2pChnnel, _UI uiChannel, _UI uiForceClose=MOS_FALSE);
    static _INT procPlayBackCmdMsg(_HP2PCHANNEL hP2pChnnel, _UC ucMsgType, _UC ucMsgId, _INT iSeqID,
                            _UC *pucMsgBuff, _INT iMsgBuffLen);
    static _INT procCmdPlayBackResp(_HP2PCHANNEL hP2pChnnel, _US usChannel, _UI iSeqId, _UI iVodType);
    static _INT procCmdPlayBackFeedBackResp(_HP2PCHANNEL hP2pChnnel, ST_MSGP2P_FEEDBACK *param, _UC ucCmdType);
    static _INT procCmdFeedBackResp(_HP2PCHANNEL hP2pChnnel, _UC ucAvType, _US usChannel, _UC ucCmdType, _US usWinSize, _UC ucPackSeq);

    static _INT procCmdCloseSession(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hJsonRoot);
    static _INT procCmdSendCloseSession(_HP2PCHANNEL hP2pChnnel);
    static _INT procSendMediaNode(_VPTR hIceTrans, _US usChannel, _UC msgType, _UC msgId,
                                  ST_DATA_NODE *pstNode, _INT trasTye, _INT iIsOneNode=0, _UC ucResSeq=0);
    static _INT procDispathCmdMsg(_HP2PCHANNEL hP2pChnnel, _UC ucMsgType, _UC ucMsgId, _UC ucRerv,
                                  _INT iSeqId, _UC *pucMsgBuff, _INT iMsgBuffLen);

    //NAT3-NAT4
    static _INT procCmdStartNatHole(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdClientNatInfoNotify(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);
    static _INT procCmdSelectCntidReq(_HP2PCHANNEL hP2pChnnel, _UI iSeqId, _VPTR hRootOrg);

    static void InitReciveBuf();
    static void DeniReciveBuf();
    static _INT P2pCmd_DecodeMultiMediaData(_HP2PCHANNEL hP2pChnnel, _UC *pucMsgBuff, _INT iMsgBuffLen);
    static _INT PaseReciveData(_HP2PCHANNEL hP2pChnnel, _UC *pData, _UI uiDataLen);

public:
    static ST_P2P_RECIVE_MNG *stP2pReciveMng;
};

#endif // P2P_PROCESSCMD_H
