#include "mos.h"
#include "zj_interface.h"
#include "ims_api.h"
#include "ims_type.h"
#include "ims_render.h"
#include "media_video.h"
#include "media_audio.h"
#include "watchdog_api.h"
#include "adpt_crypto_adapt.h"
#include "http_api.h"
#include "msgmng_cmdserver.h"
#include "adpt_json_adapt.h"
#include "media_type_prv.h"
#include "p2p_type.h"
#include "tras_httpclient.h"

#ifdef BUILD_ONBROADCAST_FALG
#include "AudioDeviceAPI.h"
#include "broadcast_api.h"
#endif

typedef struct avClientImsInfo
{
    _UC               m_uacPeerId[STRING_ICE_NAME_LENGHT];//client userToken
    ST_P2PTURN_ADDRINFO *m_iceTranSport;//one client one transport
    ST_THREAD_MNG     m_liveCmdThreadMng;//one client one command thread
    ST_PLAYBACK_MNG   m_playBackThreadMng;//playback command thread
    _UC               m_bEnableVideo;
    _UC               m_ucStreamId;       //0-main stream, 1-sub stream
    _UC               m_ucNeedIframe;     //1-need iframe 0-not need
    _US               m_sLiveVideoChn;
    _US               m_sLiveAudioChn;
    _US               m_sAudioSpeakChn;
    _US               m_sVideoDisplayChn;
    _BOOL             m_bEnableAudio;
    _BOOL             m_bEnableSpeaker;
    _BOOL             m_bEnableDisplay;
    _HAUDIOPLAY       m_hAudioPlay;
    _HVPLAYHANDLE     m_hVideoPlay;    
    _BOOL             m_bChannelTimeOut;
    kj_timer_t        m_tReiveAudioDataTimeout; //对端对讲数据接收时间
    kj_timer_t        m_tReiveVideoDataTimeout; //对端视频数据接收时间
    ST_MSGP2P_KEEPALIVE_CHANNEL_INFO    m_stKeepAliveChannelInfo;//ST_MSGP2P_KEEPALIVE_BODY
    ST_MSGP2P_INTRANSMITTING_CHANNEL_INFO   m_stInTransmittingChannelInfo;
    _HMUTEX           hMutex;
    ST_MOS_LIST_NODE  stNode;
}ST_IMS_AVCLIENT_INFO;

#define IMS_SIP_FILE (_UC*)"ims_sip.conf"

#define HTTPS_TIMEOUT       5
    
#define HTTPS_DEFAULT_PORT  443
    
#define HTTPS_BUFFER_SIZE   1024

FILE *imsfp = MOS_NULL;
#define DEBUGVIDEO 0

#define IMS_HTTPS_POST "POST %s HTTP/1.1\r\nHOST: %s:%d\r\nAccept: */*\r\n"

#define IMS_MODULE_NAME "ImsMedia"

static _CTIME_T g_cOldPollQueryTime     =  0;   // 上次轮询IMS业务参数的时间点
static _CTIME_T g_cOldOnlineQueryTime   =  0;   // 上次设备上线查询IMS业务参数失败的时间点

static ST_IMS_TASKMNG   g_stImsTaskMng  = {0};
static ST_IMS_HTTP_TASK g_stImsHttpTask = {0};

static ST_MSGMNG_MULTI_MEDIA *pstMultiMediaBak = MOS_NULL;
static ST_IMS_AVCLIENT_INFO *pstP2pMediaBak = MOS_NULL;

static EN_ZJ_NETWORK_TYPE g_enImsNetType = EN_ZJ_NETWORK_TYPE_NONET;

_INT ImsMedia_SetMultiMedia(_VOID* pstMultiMedia)
{
    pstMultiMediaBak = (ST_MSGMNG_MULTI_MEDIA*)pstMultiMedia;
    return MOS_OK;
}

_INT ImsMedia_SetP2pMedia(_VOID* pstP2pMedia)
{
    pstP2pMediaBak = (ST_IMS_AVCLIENT_INFO*)pstP2pMedia;
    return MOS_OK;
}

static _UI ImsMedia_StopTalkTask()
{
    if ((Config_GetCamaraMng()->uiSpkOpenFlag == MOS_TRUE) || (Config_GetCamaraMng()->uiDisPlayOpenFlag == MOS_TRUE))
    {
        if (pstMultiMediaBak)
        {
            if (Config_GetCamaraMng()->uiSpkOpenFlag == MOS_TRUE)
            {
                Mos_MutexLock(&pstMultiMediaBak->hMutexStatus);
                if (pstMultiMediaBak->m_bEnableSpeaker)
                {
                    pstMultiMediaBak->m_sAudioSpeakChn  =  0;
                    Media_Notify_AudioPlay(pstMultiMediaBak->pucResourceID, 1, MOS_FALSE, 0);
                    Media_AudioPlayDestroyWriteHandle(pstMultiMediaBak->m_hAudioPlay);
                    pstMultiMediaBak->m_hAudioPlay = MOS_NULL;
                    Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                    pstMultiMediaBak->m_bEnableSpeaker  = MOS_FALSE;
                    //MsgMng_MultiMediaUpdateLiveBusyStatus(pstMultiMediaBak);
                    MOS_LOG_INF(IMSMEDIA_LOGSTR, "Closing MultiMediaBak audio reverse");
                }
                Mos_MutexUnLock(&pstMultiMediaBak->hMutexStatus);
            }

            pstMultiMediaBak = MOS_NULL;
        }

        if (pstP2pMediaBak)
        {          
            if (Config_GetCamaraMng()->uiSpkOpenFlag == MOS_TRUE)
            { 
                Mos_MutexLock(&pstP2pMediaBak->hMutex);
                if (pstP2pMediaBak->m_bEnableSpeaker)
                {
                    pstP2pMediaBak->m_sAudioSpeakChn  =  0;
                    Media_Notify_AudioPlay(pstP2pMediaBak->m_uacPeerId, 1, MOS_FALSE, 0);
                    Media_AudioPlayDestroyWriteHandle(pstP2pMediaBak->m_hAudioPlay);
                    pstP2pMediaBak->m_hAudioPlay = MOS_NULL;
                    Config_SetCamerSpkOpenFlag(0, MOS_FALSE);
                    pstP2pMediaBak->m_bEnableSpeaker  = MOS_FALSE;
                    Media_AudioPlayCancelFrameBuff(MOS_NULL);
                    MOS_LOG_INF(IMSMEDIA_LOGSTR, "Closing P2pMediaBak audio reverse");
                }
                Mos_MutexUnLock(&pstP2pMediaBak->hMutex);
            }

            if (Config_GetCamaraMng()->uiDisPlayOpenFlag == MOS_TRUE)
            {
                Mos_MutexLock(&pstP2pMediaBak->hMutex);
                if (pstP2pMediaBak->m_bEnableDisplay)
                {           
                    Config_SetCamerDisplayOpenFlag(0, MOS_FALSE);
                    pstP2pMediaBak->m_bEnableDisplay  = MOS_FALSE;
                    Media_Notify_VideoPlay(pstP2pMediaBak->m_uacPeerId, pstP2pMediaBak->m_bEnableDisplay);
                    Media_VideoDisPlayDestroyHandle(pstP2pMediaBak->m_hVideoPlay);  
                    pstP2pMediaBak->m_sVideoDisplayChn  =  0;
                    pstP2pMediaBak->m_hVideoPlay = MOS_NULL;
                    Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
                    MOS_LOG_INF(IMSMEDIA_LOGSTR, "Closing P2pMediaBak video reverse");
                }
                Mos_MutexUnLock(&pstP2pMediaBak->hMutex);
            }

            pstP2pMediaBak = MOS_NULL;
        }
    }

    return MOS_OK;
}

ST_IMS_TASKMNG *ImsMedia_GetTaskMng()
{
    return &g_stImsTaskMng;
}

ST_IMS_HTTP_TASK *ImsMedia_GetHttpTask()
{
    return &g_stImsHttpTask;
}

// IMS是否开通 0.关闭 1.开通
_UI ImsMedia_GetHaveIMS()
{
    _UI uiHaveIMS = 0;
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    uiHaveIMS = Config_GetImsMng()->uiHaveIMS;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return uiHaveIMS;
}
// 轮询查询IMS业务配置开关
_UI ImsMedia_GetPollingStatus()
{
    _UI uiPollingStatus = 0;
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    uiPollingStatus = Config_GetImsMng()->uiPollingStatus;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return uiPollingStatus;
}

// 轮询查询IMS业务配置间隔
_UI ImsMedia_GetPollingInterval()
{
    _UI uiPollingInterval = 0;
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    uiPollingInterval = Config_GetImsMng()->uiPollingInterval;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return uiPollingInterval;
}

// 设备在线状态
_INT ImsMedia_SetOnlineStatus(_UI uiOnlineStatus)
{
    MOS_LOG_INF(IMSMEDIA_LOGSTR, "Ims OnlineStatus change to %d", uiOnlineStatus);
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    ImsMedia_GetTaskMng()->uiOnlineStatus = uiOnlineStatus;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return 0;
}
_UI ImsMedia_GetOnlineStatus()
{
    _UI uiOnlineStatus = 0;
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    uiOnlineStatus = ImsMedia_GetTaskMng()->uiOnlineStatus;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return uiOnlineStatus;
}

// 信令上线查询配置状态
_INT ImsMedia_SetOnlineQueryCfgStatus(_UI uiOnlineQueryCfgStatus)
{
    MOS_LOG_INF(IMSMEDIA_LOGSTR, "Ims OnlineQueryCfgStatus change to %d", uiOnlineQueryCfgStatus);
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    ImsMedia_GetTaskMng()->uiOnlineQueryCfgStatus = uiOnlineQueryCfgStatus;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return 0;
}
_UI ImsMedia_GetOnlineQueryCfgStatus()
{
    _UI uiOnlineQueryCfgStatus = 0;
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    uiOnlineQueryCfgStatus = ImsMedia_GetTaskMng()->uiOnlineQueryCfgStatus;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return uiOnlineQueryCfgStatus;
}

// 查询IMS业务配置失败次数
_INT ImsMedia_SetQueryBusiCfgFailTimes(_UI uiQueryBusiCfgFailTimes)
{
    // MOS_LOG_INF(IMSMEDIA_LOGSTR, "Ims QueryBusiCfgFailTimes change to %d", uiQueryBusiCfgFailTimes);
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    ImsMedia_GetTaskMng()->uiQueryBusiCfgFailTimes = uiQueryBusiCfgFailTimes;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return 0;
}
_UI ImsMedia_GetQueryBusiCfgFailTimes()
{
    _UI uiQueryBusiCfgFailTimes = 0;
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    uiQueryBusiCfgFailTimes = ImsMedia_GetTaskMng()->uiQueryBusiCfgFailTimes;
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
    return uiQueryBusiCfgFailTimes;
}

//parse url
_INT ImsMedia_ParseUrl(_UC *pucInUrl, _UC *pucOutHost, short *pusOutPort,  _UC *pucOutSubUri,_UI *uiHttpType)
{
    _INT iLen = 0;
    _INT iTmp = 0;
    _UC *pucSeparator = MOS_NULL;
    _UC *pucColon = MOS_NULL;
    _UC *pucURL = pucInUrl;
    if (0 == MOS_STRNCMPNOCASE(pucURL, (_UC *)"https://", MOS_STRLEN("https://")))
    {
        *uiHttpType = 1;
        pucURL += MOS_STRLEN("https://");
    }
    else if (0 == MOS_STRNCMPNOCASE(pucURL,(_UC *)"http://", MOS_STRLEN("http://")))
    {
        *uiHttpType = 0;
        pucURL += MOS_STRLEN("http://");
    }

    pucColon = MOS_STRSTR(pucURL, ":");
    if (MOS_NULL == pucColon)
    {
        if(*uiHttpType == 1){
            *pusOutPort = 443;
        }
        else if(*uiHttpType == 0){
            *pusOutPort = 80;
        }
    }
    else
    {
        *pusOutPort = (short)MOS_ATOI(pucColon + 1);
    }

    pucSeparator = MOS_STRSTR(pucURL, "/");
    if (pucSeparator)
    {
        iLen = SAFE_INT(pucSeparator - pucURL);
    }

    if (pucColon)
    {
        iLen = SAFE_INT(pucColon - pucURL);
    }

    if (iLen <= 0 || iLen >= 512)
    {
        return MOS_ERR;
    }
    MOS_MEMCPY(pucOutHost,pucURL,iLen);
    pucOutHost[iLen] = 0;
    if (pucSeparator && pucOutSubUri)
    {
        iLen = MOS_STRLEN(pucSeparator);
        MOS_MEMCPY(pucOutSubUri,pucSeparator,iLen);
        pucOutSubUri[iLen] = 0;
        iTmp = iLen - 1;
        if (iTmp >= 0  && '/' == pucOutSubUri[iTmp])
        {
            pucOutSubUri[iTmp] = 0;
        }
    }
    return MOS_OK;
}

_SOCKET ImsMedia_ConnectServer(_UC *pucHost, _INT iPort)
{
    _INT i                              = 0;
    _INT iRet                           = MOS_ERR;
    _BOOL bWait                         = MOS_FALSE;
    _BOOL bConnected                    = MOS_TRUE;
    _SOCKET hSocket                     = MOS_SOCKET_INVALID;
    ST_MOS_INET_IP *pstIpInfo           = MOS_NULL;
    ST_MOS_INET_IPARRAY stIpArrayInfo   = {0};

    iRet = Mos_InetGetHostByName(pucHost, &stIpArrayInfo, &bWait);
    if (MOS_OK != iRet)
    {
        iRet = Mos_InetGetHostByName(pucHost, &stIpArrayInfo, &bWait);
        if (MOS_OK != iRet)
        {
            MOS_PRINTF("%s Get host by name failed2,host: %s\n", __FUNCTION__, pucHost);
            return MOS_SOCKET_INVALID;
        }
    }
#ifdef SDK_ADPT_IPV6
    pstIpInfo = &pstIpArray->astIps[0];
#else
    for (i = 0; i < stIpArrayInfo.uiCount; i++)
    {
        if (stIpArrayInfo.astIps[i].usType != EN_CINET_TYPE_IPV4)
        {
            continue;
        }
        pstIpInfo = &stIpArrayInfo.astIps[i];
        pstIpInfo->usPort = iPort;
        break;
    }
#endif
    if (pstIpInfo == MOS_NULL)
    {
        return MOS_SOCKET_INVALID;
    }

    hSocket = Mos_SocketOpen(pstIpInfo->usType, EN_CINET_PRTL_TCP, MOS_TRUE, MOS_TRUE);
    if (hSocket == MOS_SOCKET_INVALID)
    {
        return MOS_SOCKET_INVALID;
    }
    //设置发送/接收超时
    if (Mos_SocketSetSendTimeOut(hSocket, HTTPS_TIMEOUT) != MOS_OK)
    {
        Mos_SocketClose(hSocket);
        return MOS_SOCKET_INVALID;
    }
    if (Mos_SocketSetRecvTimeOut(hSocket, HTTPS_TIMEOUT) != MOS_OK)
    {
        Mos_SocketClose(hSocket);
        return MOS_SOCKET_INVALID;
    }
    
    if (Mos_SocketConnect(hSocket, pstIpInfo, &bConnected) != MOS_OK)
    {
        Mos_SocketClose(hSocket);
        return MOS_SOCKET_INVALID;
    }

    return hSocket;
}

_INT ImsMedia_HttpsParseHeader(_SSL_HANDLE hSSL, _INT *piResultCode, _INT *piContentLength, _UC *pucRedirectUrl)
{
    _UC aucBuffer[1]    = {0};
    _UC aucTemp[BUFSIZ] = {0};
    _UC *pucPtr         = MOS_NULL;
    _UC *pucPtrTmp      = MOS_NULL;
    _INT iLen           = 0;
    _INT n              = 0;
    _CTIME_T tBeginTime = 0;

    if (!hSSL || !piResultCode || !piContentLength)
    {
        return MOS_ERR;
    }

    *piResultCode    = 0;
    *piContentLength = 0;

    tBeginTime = Mos_Time();

    while (Adpt_SSL_Read(hSSL, (_UC *)aucBuffer, 1, &iLen) == ITRD_OK)
    {
        aucTemp[n] = *aucBuffer;
        if (*aucBuffer == '\n')
        {
            pucPtr = MOS_STRSTR(aucTemp,"HTTP/1.1");
            if (pucPtr != NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,' ');
                pucPtr++;
                *piResultCode = MOS_ATOI(pucPtr);
            }
            pucPtr = MOS_STRSTR(aucTemp,"Content-Length:");
            if (pucPtr != NULL)
            {
                // 如果是keep alive，则content-length和chunk必然是二选一
                // 若是非keep alive，则和http1.0一样。content-length可有可无
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                *piContentLength = MOS_STRTOL(pucPtr, 10);
            }
            pucPtr = MOS_STRSTR(aucTemp,"Location:");
            if (pucPtr != NULL)
            {
                pucPtr = MOS_STRCHR(pucPtr,':');
                pucPtr++;
                pucPtrTmp = MOS_STRCHR(pucPtr,'\r');
                iLen = pucPtrTmp - pucPtr;
                if (pucRedirectUrl)
                {
                    MOS_STRNCPY(pucRedirectUrl, pucPtr+1, iLen-1);
                    // MOS_PRINTF("pucRedirectUrl:%s \r\n",pucRedirectUrl);
                }
            }

            MOS_PRINTF("%s",aucTemp);
            //"\r\n"后接着"\r\n"
            if (aucTemp[0] == '\r' && aucTemp[1] == '\n')
            {
                return MOS_OK;
            }
            MOS_MEMSET(aucTemp, 0, sizeof(aucTemp));
            n = -1;
        }
        n++;

        if ((tBeginTime+HTTPS_TIMEOUT) < Mos_Time())
        {
            MOS_PRINTF("%s timeout error\n", __FUNCTION__);
            return MOS_ERR;
        }
    }
    MOS_PRINTF("%s recv error\n", __FUNCTION__);
    return MOS_ERR;//接收数据失败
}

static _INT ImsMedia_SendReqMsgHttps(_SSL_HANDLE *phSSL,_SOCKET hSocket,_UC *aucHostAddr, _UC *pucSendBuf,_UI uiBuffLen,_UC *pucHeaderBuf,_UI uiHeaderLen)
{
    _UI  uiTotalSend     = 0;
    _UI  uiSendLen       = 0;
    
    if (Adpt_SSL_Create(hSocket, phSSL) == ITRD_ERR)
    {        
        MOS_LOG_ERR(IMSMEDIA_LOGSTR,"Adpt_SSL_Create error");
        return MOS_ERR;
    }
    
    if (Adpt_SSL_SetClientMode(*phSSL, ITRD_TRUE) == ITRD_ERR)
    {
        MOS_LOG_ERR(IMSMEDIA_LOGSTR,"Adpt_SSL_SetClientMode error");
        return MOS_ERR;
    }

    if (Adpt_SSL_Connect(*phSSL, (_UC*)aucHostAddr) == ITRD_ERR)
    {        
        MOS_LOG_ERR(IMSMEDIA_LOGSTR,"Adpt_SSL_Connect error");
        return MOS_ERR;
    }
    while (uiTotalSend < uiHeaderLen) 
    {
        if(Adpt_SSL_Write(*phSSL,(pucHeaderBuf + uiTotalSend), uiHeaderLen - uiTotalSend, (_INT*)&uiSendLen) != ITRD_OK) 
        {
            MOS_LOG_ERR(IMSMEDIA_LOGSTR, "send ssl %s error",pucHeaderBuf);        
            return MOS_ERR;
        }
        uiTotalSend += uiSendLen;
    }

    uiTotalSend = 0;
    while (uiTotalSend < uiBuffLen && pucSendBuf != MOS_NULL) 
    {
        if(Adpt_SSL_Write(*phSSL,(pucSendBuf + uiTotalSend), uiBuffLen - uiTotalSend, (_INT*)&uiSendLen) != ITRD_OK) 
        {
            MOS_LOG_ERR(IMSMEDIA_LOGSTR, "send ssl %s error",pucSendBuf);        
            return MOS_ERR;
        }
        uiTotalSend += uiSendLen;
    }
    
    return MOS_OK;
}

static _VOID ImsMedia_GetLoginDataRecvFunc(_UC* pucData, _UI uiLen, _VPTR vpUserPtr, _UI uiReqId)
{
    MOS_PARAM_NULL_NORET(pucData);

    if(ImsMedia_GetHttpTask()->usSipBuffLen + uiLen < ImsMedia_GetHttpTask()->usSipBuffMaxLen)
    {
        MOS_MEMCPY(ImsMedia_GetHttpTask()->pucSipBuff + ImsMedia_GetHttpTask()->usSipBuffLen, pucData, uiLen);
        ImsMedia_GetHttpTask()->usSipBuffLen += uiLen;
    }
}

static _VOID ImsMedia_GetLoginDataFinished(_VPTR vpUserPtr, _UI uiReqId)
{

}

static _VOID ImsMedia_GetLoginDataFailed(_VPTR vpUserPtr, _UI uiErrCode, _UI uiReqId)
{
    MOS_LOG_ERR(IMSMEDIA_LOGSTR, "IMS media get login data fail!");
    CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, -1, -1, "IMS media get login data fail!", 1);
}

/* 
https post sync 回调接口
执行https post 阻塞获取所需的数据
参数：
[in]  iConnTimeout:     建连超时时间，单位：秒
[in]  pucInBufData:     需要发送的body数据（数据类型:application/json）
[in]  uiInBufLen:       发送数据的长度
[in]  uiMaxBufSize:     最大接收缓冲区长度
[in]  pucurl:           请求url（格式：https://www.xxx.com）
[out] pucOutBufData:    接收缓冲区（数据类型:application/json）
[out] puiOutBufLen:     实际接收数据长度
[in]  pucAddBuff：      扩展字段，可扩展请求头。
返回值：-1：失败；0：成功
*/
_INT ImsMedia_HttpsPostGetLoginDataCb(_INT iConnTimeout, _UC *pucInBufData, _UI uiInBufLen, _UI uiMaxBufSize,
                                                _UC *pucurl, _UC *pucOutBufData, _UI *puiOutBufLen, _UC *pucAddBuff)
{
    _INT iRet                 = MOS_ERR;
    _US usPort                = 0;
    _UI uiHttpType            = 0;
    _UC aucSubUrl[128]        = {0};
    _UC aucHostAddr[128]      = {0};
    _UC aucAdmonAddrPort[128] = {0};

    // IMS_LOGINDATA_URL https://videocallctit.189smarthome.com:20600/SmartHomeSDKApi/api/login/queryData

    iRet = ImsMedia_ParseUrl(pucurl, aucHostAddr, &usPort, aucSubUrl, &uiHttpType);
    if (iRet != MOS_OK)
    {                             
        MOS_LOG_ERR(IMSMEDIA_LOGSTR, "failed to parse url : %s",pucurl);        
        CloudStg_UploadLog(Mos_GetSessionId(), __FUNCTION__, -1, -1, "ImsMedia Parse Url Failed", 1);
        return MOS_ERR;
    }

    MOS_SPRINTF(aucAdmonAddrPort, "%s:%d", aucHostAddr, usPort);

    ImsMedia_GetHttpTask()->usSipBuffLen    = 0;
    ImsMedia_GetHttpTask()->usSipBuffMaxLen = uiMaxBufSize;
    ImsMedia_GetHttpTask()->pucSipBuff      = pucOutBufData;

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag        = uiHttpType;
    stHttpInfoNode.iTimeOut         = iConnTimeout;
    stHttpInfoNode.pfuncRecv        = ImsMedia_GetLoginDataRecvFunc;
    stHttpInfoNode.pfuncFinished    = ImsMedia_GetLoginDataFinished;
    stHttpInfoNode.pfuncFailed      = ImsMedia_GetLoginDataFailed;
    stHttpInfoNode.pucExpandHeader  = pucAddBuff;
    stHttpInfoNode.pucContent       = pucInBufData;
    stHttpInfoNode.uiContentLen     = uiInBufLen;
    iRet = Http_SendSyncRequest(&stHttpInfoNode, aucAdmonAddrPort, aucSubUrl, EN_HTTP_METHOD_POST, Mos_GetSessionId());

    *puiOutBufLen = ImsMedia_GetHttpTask()->usSipBuffLen;
    ImsMedia_GetHttpTask()->pucSipBuff = MOS_NULL;

    return iRet;
}

/*
回铃音回调
终端发出呼叫后，接收到Ring 触发
参数：
[in] iSession:          会话ID
[in] pucFromNum:        主叫号码
[in] pucDisplayName     主叫名称
[in] pucToNum:          被叫号码
[in] iEarlyMedia:       早期媒体
返回值：无
*/
_VOID ImsMedia_RecvRingCb(_INT iSession, const _UC *pucFromNum, const _UC *pucDisplayName, const _UC *pucToNum, _INT iEarlyMedia)
{
    // TODO 通知设备接听铃响
    MOS_LOG_INF(IMSMEDIA_LOGSTR, "ImsMedia_RecvRingCb iEarlyMedia=%d", iEarlyMedia);
    ImsMedia_GetTaskMng()->stImsCallInf.iEarlyMedia = iEarlyMedia;

    if (ImsMedia_GetTaskMng()->stImsCallInf.iEarlyMedia == 1)
    {
        #ifdef BUILD_ONBROADCAST_FALG
        Broadcast_Task_Pause_OpenTalk();
        #endif  

        ImsMedia_StopTalkTask();

        ImsMedia_GetTaskMng()->stImsCallInf.iSession = iSession;
        if (ImsMedia_GetTaskMng()->bEnableSpeaker == MOS_FALSE)
        {    
            Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
            
            #ifdef BUILD_ONBROADCAST_FALG
            Broadcast_Task_SetBroadcastState(BROADCAST_STATE_TALK);
            #endif

            ST_ZJ_AUDIO_PARAM audioParams = {0};
            audioParams.uiEncodeType = EN_ZJ_AUDIOENC_TYPE_G711A;
            audioParams.uiSampleRate = 8000;
            audioParams.uiChannel = 1;
            audioParams.uiDepth = 16;            
            
            ImsMedia_GetTaskMng()->hAudioPlay = Media_AudioPlayCreatWriteHandle(IMS_MODULE_NAME, 0, &audioParams);

            // 接收回铃音, 更新IMS为繁忙状态
            Config_AppSLeepMonotorUpdateStatus(ImsMedia_GetTaskMng()->uiSleepMonitorId, EN_SDK_STATE_BUSY);
            Media_Notify_AudioPlay(IMS_MODULE_NAME, 1, 1, 0);
            
            ImsMedia_GetTaskMng()->bEnableSpeaker  = MOS_TRUE;
            
            Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
            
            MOS_LOG_INF(IMSMEDIA_LOGSTR, "Opening audio reverse");
            
    #if DEBUGVIDEO
            _UC aucFile[256] = {0};
            MOS_MEMSET(aucFile, 0, sizeof(aucFile));
            MOS_VSNPRINTF(aucFile,256,"./%s","imstest.h264");
            if(imsfp == MOS_NULL)
            {
                imsfp = fopen(aucFile, "wb");
            }
    #endif

            return;
        }

        #ifdef BUILD_ONBROADCAST_FALG
        Broadcast_Task_Resume_CloseTalk();
        #endif    
    }
    return;
}

/* 
接收到来电回调 
终端接收到来电触发
参数：
[in] iSession:           会话ID
[in] pucFromNum:         主叫号码
[in] pucDisplayName      主叫名称
[in] pucToNum:           被叫号码
[in] iCallType:          来电类型
[in] pucJsonCallControl: 来电说明
返回值：无
*/
_VOID ImsMedia_RecvCallCb(_INT iSession, const _UC *pucFromNum, const _UC *pucDisplayName, const _UC *pucToNum, EN_IMS_CALL_TYPE iCallType, const _UC *pucJsonCallControl)
{
    MOS_LOG_INF(IMSMEDIA_LOGSTR, "ImsMedia_RecvCallCb");

    MOS_PARAM_NULL_RETERR(pucToNum);
    MOS_PARAM_NULL_RETERR(pucFromNum);
    MOS_PARAM_NULL_RETERR(pucDisplayName);

    // 终端接听呼叫
    IMS_NoticePickUp(iSession);

    // 记录通话参数 并 通知线程发送媒体流
    ImsMedia_GetTaskMng()->stImsCallInf.iSession          = iSession;
    ImsMedia_GetTaskMng()->stImsCallInf.iCallType         = iCallType;
    ImsMedia_GetTaskMng()->stImsCallInf.uiCallFlag        = 1;
    ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame = 1;
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucToNum,       pucToNum,       sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucToNum));
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucFromNum,     pucFromNum,     sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucFromNum));
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucDisplayName, pucDisplayName, sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucDisplayName));

    #ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Pause_OpenTalk();
    #endif   
    ImsMedia_StopTalkTask();

    if ((ImsMedia_GetTaskMng()->bEnableDisplay == MOS_FALSE ) && (iCallType == 1))
    {    
        /*设置双向视频通话对端出流信息*/ 
        ST_ZJ_VIDEO_PARAM stVideoPlayInf    = {0};
        stVideoPlayInf.uiResolution       = EN_ZJ_CARERA_RESOLUTION_ABILITY_480P;
        stVideoPlayInf.uiWidth            = 480; 
        stVideoPlayInf.uiHeight           = 640 ;
        stVideoPlayInf.uiEncodeType       = EN_ZJ_VIDEOENC_TYPE_H264;
        stVideoPlayInf.uiBitrate          = EN_ZJ_CAMERA_BITRATE_TYPE_384K; 
        stVideoPlayInf.uiFramerate        = 15;
        stVideoPlayInf.uiFrameInterval    = 30;
        stVideoPlayInf.uiQuality          = EN_ZJ_KEYFRAME_QUALITY_NORMAL;
        stVideoPlayInf.uiRateType         = 0;
        stVideoPlayInf.uiSmartEncFlag     = 0;

        Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
        Config_SetCamerDisplayOpenFlag(0, MOS_TRUE);            
        Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
        ImsMedia_GetTaskMng()->bEnableDisplay  = MOS_TRUE;
        ImsMedia_GetTaskMng()->hVideoPlay      = Media_VideoDisPlayCreatHandle(IMS_MODULE_NAME, &stVideoPlayInf);
        Media_Notify_VideoPlay(IMS_MODULE_NAME, ImsMedia_GetTaskMng()->bEnableDisplay);
        Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
        
        MOS_LOG_INF(IMSMEDIA_LOGSTR, "Opening video reverse");
    }

    if (ImsMedia_GetTaskMng()->bEnableSpeaker == MOS_FALSE)
    {    
        Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
        
        #ifdef BUILD_ONBROADCAST_FALG
        Broadcast_Task_SetBroadcastState(BROADCAST_STATE_TALK);
        #endif
        ST_ZJ_AUDIO_PARAM audioParams = {0};
        audioParams.uiEncodeType = EN_ZJ_AUDIOENC_TYPE_G711A;
        audioParams.uiSampleRate = 8000;
        audioParams.uiChannel = 1;
        audioParams.uiDepth = 16;            
        
        ImsMedia_GetTaskMng()->hAudioPlay = Media_AudioPlayCreatWriteHandle(IMS_MODULE_NAME, 0, &audioParams);

        // 收到来电触发, 更新IMS为繁忙状态
        Config_AppSLeepMonotorUpdateStatus(ImsMedia_GetTaskMng()->uiSleepMonitorId, EN_SDK_STATE_BUSY);
        Media_Notify_AudioPlay(IMS_MODULE_NAME, 1, 1, 0);
        
        ImsMedia_GetTaskMng()->bEnableSpeaker  = MOS_TRUE;
        
        Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
        
        MOS_LOG_INF(IMSMEDIA_LOGSTR, "Opening audio reverse");
        
#if DEBUGVIDEO
        _UC aucFile[256] = {0};
        MOS_MEMSET(aucFile, 0, sizeof(aucFile));
        MOS_VSNPRINTF(aucFile,256,"./%s","imstest.h264");
        if(imsfp == MOS_NULL)
        {
            imsfp = fopen(aucFile, "wb");
        }
#endif

        return;
    }

    #ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Resume_CloseTalk();
    #endif 

    return;
}

/* 
会话接通回调 
终端发出呼叫后,被叫接听来电触发
参数：
[in] iSession:          会话ID
[in] pucFromNum:        主叫号码
[in] pucDisplayName     主叫名称
[in] pucToNum:          被叫号码
[in] iCallType:         呼叫类型
返回值：无
*/
_VOID ImsMedia_RecvAnswerCb(_INT iSession, const _UC *pucFromNum, const _UC *pucDisplayName, const _UC *pucToNum, EN_IMS_CALL_TYPE iCallType)
{
    MOS_LOG_INF(IMSMEDIA_LOGSTR, "ImsMedia_RecvAnswerCb");
    MOS_PARAM_NULL_RETERR(pucToNum);
    MOS_PARAM_NULL_RETERR(pucFromNum);
    MOS_PARAM_NULL_RETERR(pucDisplayName);

    // 终端发出的呼叫被接听 通知线程发送媒体流 并 记录通话参数
    ImsMedia_GetTaskMng()->stImsCallInf.iSession          = iSession;
    ImsMedia_GetTaskMng()->stImsCallInf.iCallType         = iCallType;
    ImsMedia_GetTaskMng()->stImsCallInf.uiCallFlag        = 1;
    ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame = 1;
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucToNum,       pucToNum,       sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucToNum));
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucFromNum,     pucFromNum,     sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucFromNum));
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucDisplayName, pucDisplayName, sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucDisplayName));

    #ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Pause_OpenTalk();
    #endif   
    
    ImsMedia_StopTalkTask();
    
    if ((ImsMedia_GetTaskMng()->bEnableDisplay == MOS_FALSE) && (iCallType == 1))
    {    
        /*设置双向视频通话对端出流信息*/ 
        ST_ZJ_VIDEO_PARAM stVideoPlayInf    = {0};
        stVideoPlayInf.uiResolution       = EN_ZJ_CARERA_RESOLUTION_ABILITY_480P;
        stVideoPlayInf.uiWidth            = 480; 
        stVideoPlayInf.uiHeight           = 640 ;
        stVideoPlayInf.uiEncodeType       = EN_ZJ_VIDEOENC_TYPE_H264;
        stVideoPlayInf.uiBitrate          = EN_ZJ_CAMERA_BITRATE_TYPE_384K; 
        stVideoPlayInf.uiFramerate        = 15;
        stVideoPlayInf.uiFrameInterval    = 30;
        stVideoPlayInf.uiQuality          = EN_ZJ_KEYFRAME_QUALITY_NORMAL;
        stVideoPlayInf.uiRateType         = 0;
        stVideoPlayInf.uiSmartEncFlag     = 0;

        Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
        Config_SetCamerDisplayOpenFlag(0, MOS_TRUE);            
        Media_VideoDisPlayCancelFrameBuff(MOS_NULL);
        ImsMedia_GetTaskMng()->bEnableDisplay  = MOS_TRUE;
        ImsMedia_GetTaskMng()->hVideoPlay      = Media_VideoDisPlayCreatHandle(IMS_MODULE_NAME, &stVideoPlayInf);
        Media_Notify_VideoPlay(IMS_MODULE_NAME, ImsMedia_GetTaskMng()->bEnableDisplay);
        Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
        
        MOS_LOG_INF(IMSMEDIA_LOGSTR, "Opening video reverse");
    }

    if (ImsMedia_GetTaskMng()->bEnableSpeaker == MOS_FALSE)
    {    
        Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
        
        #ifdef BUILD_ONBROADCAST_FALG
        Broadcast_Task_SetBroadcastState(BROADCAST_STATE_TALK);
        #endif
        ST_ZJ_AUDIO_PARAM audioParams = {0};
        audioParams.uiEncodeType = EN_ZJ_AUDIOENC_TYPE_G711A;
        audioParams.uiSampleRate = 8000;
        audioParams.uiChannel = 1;
        audioParams.uiDepth = 16;            
        
        ImsMedia_GetTaskMng()->hAudioPlay = Media_AudioPlayCreatWriteHandle(IMS_MODULE_NAME, 0, &audioParams);

        // 通话接听, 更新IMS为繁忙状态
        Config_AppSLeepMonotorUpdateStatus(ImsMedia_GetTaskMng()->uiSleepMonitorId, EN_SDK_STATE_BUSY);
        Media_Notify_AudioPlay(IMS_MODULE_NAME, 1, 1, 0);
        
        ImsMedia_GetTaskMng()->bEnableSpeaker  = MOS_TRUE;
        
        Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);
        
        MOS_LOG_INF(IMSMEDIA_LOGSTR, "Opening audio reverse");

#if DEBUGVIDEO
        _UC aucFile[256] = {0};
        MOS_MEMSET(aucFile, 0, sizeof(aucFile));
        MOS_VSNPRINTF(aucFile,256,"./%s","imstest.h264");
        if(imsfp == MOS_NULL)
        {
            imsfp = fopen(aucFile, "wb");
        }
#endif
        return;
    }

    #ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Resume_CloseTalk();
    #endif 

    return;
}

/* 
会话被挂断回调 
会话被挂断触发
参数：
[in] iSession:          会话ID
[in] iErrCode:          挂机错误码
[in] pucSeason:         挂机具体原因
[in] iCallType:         呼叫类型
返回值：无
*/
_VOID ImsMedia_RecvHangUpCb(_INT iSession, _INT iErrCode, const _UC *pucSeason, EN_IMS_CALL_TYPE iCallType)
{
    MOS_LOG_INF(IMSMEDIA_LOGSTR, "ImsMedia_RecvHangUpCb");

    // MOS_PARAM_NULL_RETERR(pucSeason);

#if DEBUGVIDEO
    if (imsfp)
    {
        fclose(imsfp);
        imsfp = MOS_NULL;
    }
#endif    

    // 通话被远端挂断， 停止发送媒体流
    if (iSession == ImsMedia_GetTaskMng()->stImsCallInf.iSession/* && iCallType == ImsMedia_GetTaskMng()->stImsCallInf.iCallType*/)
    {
        ImsMedia_GetTaskMng()->stImsCallInf.iSession                   = 0;
        ImsMedia_GetTaskMng()->stImsCallInf.iCallType                  = 0;
        ImsMedia_GetTaskMng()->stImsCallInf.uiCallFlag                 = 0;
        ImsMedia_GetTaskMng()->stImsCallInf.iEarlyMedia                = 0;
        ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame          = 0;
        MOS_MEMSET(ImsMedia_GetTaskMng()->stImsCallInf.ucToNum,       0x0, sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucToNum));
        MOS_MEMSET(ImsMedia_GetTaskMng()->stImsCallInf.ucFromNum,     0x0, sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucFromNum));
        MOS_MEMSET(ImsMedia_GetTaskMng()->stImsCallInf.ucDisplayName, 0x0, sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucDisplayName));
    }

    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex); 
    if (ImsMedia_GetTaskMng()->bEnableSpeaker)
    {                             
        ImsMedia_GetTaskMng()->bEnableSpeaker  = MOS_FALSE; 
        Media_Notify_AudioPlay(IMS_MODULE_NAME, 1, 0, 0);
        Media_AudioPlayDestroyWriteHandle(ImsMedia_GetTaskMng()->hAudioPlay);
        ImsMedia_GetTaskMng()->hAudioPlay = MOS_NULL;

        // 通话被挂断, 更新IMS为空闲状态
        Config_AppSLeepMonotorUpdateStatus(ImsMedia_GetTaskMng()->uiSleepMonitorId, EN_SDK_STATE_NONE);

        MOS_LOG_INF(IMSMEDIA_LOGSTR, "Closing audio reverse");
    }

    if (ImsMedia_GetTaskMng()->bEnableDisplay)
    {                             
        ImsMedia_GetTaskMng()->bEnableDisplay  = MOS_FALSE;
        Media_Notify_VideoPlay(IMS_MODULE_NAME, ImsMedia_GetTaskMng()->bEnableDisplay);
        Media_VideoDisPlayDestroyHandle(ImsMedia_GetTaskMng()->hVideoPlay);  
        ImsMedia_GetTaskMng()->hVideoPlay = MOS_NULL;
        Config_SetCamerDisplayOpenFlag(0, MOS_FALSE); 

        MOS_LOG_INF(IMSMEDIA_LOGSTR, "Closing video reverse");
    } 

    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);

    #ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Resume_CloseTalk();
    #endif 

    return;
}

/* 
事件通知回调 
收到一个notify通知，触发
参数：
[in] iNotifyType:       通知类型
[in] pucContent:        通知的具体内容
返回值：无
*/
_VOID ImsMedia_RecvNotifyCb(EN_IMS_NOTIFY_TYPE iNotifyType, const _UC *pucContent)
{
    // TODO 接收到一个notify通知

    return;
}

/* 
强制关键帧回调 
通知终端需要发送一个关键帧，触发
参数：  无
返回值：无
*/
_VOID ImsMedia_RecvKeyFrameRequestCb(_INT iCamId, _INT iStreamId)
{
    // TODO 请求一个I帧

    // 请求I帧
    if (ZJ_GetFuncTable()->pfunVideoNeedIFrame)
    {
        ZJ_GetFuncTable()->pfunVideoNeedIFrame(iStreamId, EN_ZJ_KEYFRAME_QUALITY_NORMAL);
    }

    return;
}

/* 
DTMF通知回调 
通话过程中，收到一个dtmf按键时，触发
参数：
[in] iDtmfValue: DTMF的值
返回值：无
*/
_VOID ImsMedia_RecvDtmfCb(_INT iDtmfValue)
{
    // TODO 接收到一个dtmf按键

    return;
}

/* 
对端音频流推送回调 
通话过程中，对端音频数据的推送
参数：
[in] iSession:         会话ID
[in] pucAudioPacket:   对端音频数据内容
[in] iAudioPacketSize: 对端音频数据长度
[in] uiTimeStamp:      音频时间戳
[in] pstImsAudioParam: 音频编码参数
返回值：无
*/
_VOID ImsMedia_RecvAudioPacketCb(_INT iSession, _UC *pucAudioPacket, _INT iAudioPacketSize, _UI uiTimeStamp, ST_IMS_AUDIO_PARAM *pstImsAudioParam)
{
    // TODO 远端音频数据，终端解码播放
    if (pucAudioPacket == MOS_NULL || iAudioPacketSize == 0)
    {        
        MOS_LOG_INF(IMSMEDIA_LOGSTR, "invalid param");
        return;
    }
    
    // MOS_PRINTF("%s:%d iSession=%d, iAudioPacketSize=%d uiTimeStamp=%d\r\n", __FUNCTION__, __LINE__, iSession, iAudioPacketSize,uiTimeStamp);

    _UI i = 0;
    _INT iRet        = MOS_ERR;
    
    if (ImsMedia_GetTaskMng()->bEnableSpeaker && (ImsMedia_GetTaskMng()->hAudioPlay != MOS_NULL) && iAudioPacketSize >0)
    {
        while (i < 200 && ImsMedia_GetTaskMng()->ucRunFlag == 1)
        {                
            iRet = Media_AudioPlayWriteFrame2(ImsMedia_GetTaskMng()->hAudioPlay, pucAudioPacket,iAudioPacketSize, 0);
            if (iRet == MOS_OK)
            {
                break;
            }
            i++;
            Mos_Sleep(10);
        }

        if (i >= 200)
        {
            MOS_LOG_INF(IMSMEDIA_LOGSTR, " Media_AudioPlayWriteFrame2 Failed");
        }
    }

    return;
}

/* 
对端视频流推送回调 
通话过程中，对端视频数据的推送
参数：
[in] iSession:         会话ID
[in] pucVideoPacket:   对端视频数据内容
[in] iVideoPacketSize: 对端视频数据长度
[in] uiTimeStamp:      视频时间戳
返回值：无
*/
_VOID ImsMedia_RecvVideoPacketCb(_INT iSession, _UC *pucVideoPacket, _INT iVideoPacketSize, _UI uiTimeStamp)
{
    // TODO 远端视频数据，终端解码播放
    if (pucVideoPacket == MOS_NULL || iVideoPacketSize == 0)
    {        
        MOS_LOG_INF(IMSMEDIA_LOGSTR, "invalid param");
        return;
    }

    // MOS_PRINTF("%s:%d iSession=%d, iAudioPacketSize=%d uiTimeStamp=%d\r\n", __FUNCTION__, __LINE__, iSession, iAudioPacketSize,uiTimeStamp);
    
    if ((ImsMedia_GetTaskMng()->ucRunFlag == 1) && (ImsMedia_GetTaskMng()->bEnableDisplay) && (ImsMedia_GetTaskMng()->hVideoPlay != MOS_NULL))
    {
        Media_VideoDisPlayWriteFrame(ImsMedia_GetTaskMng()->bEnableDisplay, pucVideoPacket, iVideoPacketSize, 1, uiTimeStamp);
    }

#if DEBUGVIDEO
    if (imsfp)
    {
        fwrite(pucVideoPacket, iVideoPacketSize, 1, imsfp);
    }
#endif

    return;
}

/* 
设置设备音频参数回调 
SDP协商中需要向设备获取音频参数时回调
参数：
[in]  iCamId:            摄像头ID
[in]  pstImsAudioParam:  音频编码参数
返回值：-1：失败；0：成功
*/
_INT ImsMedia_SetAudioParamCb(_INT iCamId, ST_IMS_AUDIO_PARAM *pstImsAudioParam)
{
    ST_ZJ_AUDIO_PARAM *pstAudio = Config_GetCamAudioParm(iCamId);
    if (pstAudio)
    {
        pstImsAudioParam->uiChannel    = pstAudio->uiChannel;
        pstImsAudioParam->uiDepth      = pstAudio->uiDepth;
        pstImsAudioParam->uiEncodeType = pstAudio->uiEncodeType;
        pstImsAudioParam->uiSampleRate = pstAudio->uiSampleRate;
        return MOS_OK;
    }
    else
    {
        return MOS_ERR;
    }
}

/* 
设置设备视频参数回调 
SDP协商中需要向设备获取视频参数时回调
参数：
[in]  iCamId:            摄像头ID
[in]  iStreamId:         码流ID
[in]  pstImsVideoParam:  视频编码参数
返回值：-1：失败；0：成功
*/
_INT ImsMedia_SetVideoParamCb(_INT iCamId, _INT iStreamId, ST_IMS_VIDEO_PARAM *pstImsVideoParam)
{
    ST_CFG_VIDEODES *pstVideo = Config_GetVideoDes(iCamId, iStreamId);
    if (pstVideo)
    {
        pstImsVideoParam->uiResolution      = pstVideo->stVideoPara.uiResolution;
        pstImsVideoParam->uiWidth           = pstVideo->stVideoPara.uiWidth;
        pstImsVideoParam->uiHeight          = pstVideo->stVideoPara.uiHeight;
        pstImsVideoParam->uiEncodeType      = pstVideo->stVideoPara.uiEncodeType;
        pstImsVideoParam->uiSmartEncFlag    = pstVideo->stVideoPara.uiSmartEncFlag;
        pstImsVideoParam->uiQuality         = pstVideo->stVideoPara.uiQuality;
        pstImsVideoParam->uiBitrate         = pstVideo->stVideoPara.uiBitrate;
        pstImsVideoParam->uiFramerate       = pstVideo->stVideoPara.uiFramerate;
        pstImsVideoParam->uiFrameInterval   = pstVideo->stVideoPara.uiFrameInterval;
        pstImsVideoParam->uiRateType        = pstVideo->stVideoPara.uiRateType;
        return MOS_OK;
    }
    else
    {
        return MOS_ERR;
    }
}

_VOID ImsMedia_SetVideoStreamIdCb(_INT iCamId, _INT iStreamId)
{
    ImsMedia_GetTaskMng()->stImsCallInf.iStreamId = 1;

    return;
}

_VOID ImsMedia_RecvImsKeepAliveCb(_INT callStatus)
{
    if (ImsMedia_GetTaskMng()->uiImsFeedFlag != 1)
    {
        ImsMedia_GetTaskMng()->uiImsFeedFlag = 1;
    }
    return;
}

/* 
日志上报回调
输出日志，保存日志文件 
通过统一SDK接口实现日志统一管理及上报至天翼看家平台
参数：
[in] pucFunName:函数名称
[in] uiLine:    行数
[in] pucPid:    Pid
[in] uiLevel:   等级
[out] pucFormat:输出内容
返回值：-1：失败；0：成功
*/
_INT ImsMedia_LogOutPutCb(const _C *pucFunName, _UI uiLine, _C *pucPid, _UI uiLevel, _C *pucFormat, ...)
{
    if (pucFunName == MOS_NULL || pucFormat == MOS_NULL)
    {        
        MOS_LOG_ERR(IMSMEDIA_LOGSTR, "invalid param");
        return MOS_ERR;
    }

    char printStr[2048] = {0};

    va_list ap;    
    va_start(ap,pucFormat);
    vsnprintf(printStr,sizeof(printStr)-1,(const char*)pucFormat,ap);        
    va_end(ap);

    
    if (uiLevel == EN_IMS_LOG_LVL_ERR)
    {        
        MOS_LOG_ERR(IMSMEDIA_LOGSTR, "%s %d %s",pucFunName,uiLine,printStr);
    }
    else
    {
        MOS_LOG_INF(IMSMEDIA_LOGSTR, "%s %d %s",pucFunName,uiLine,printStr);
    }
    
    return MOS_OK;
    
}

// IMS通话呼叫(AI强告警) 或者 终端按键触发
_INT ImsMedia_HangUp()
{
    IMS_NoticeHangUp(ImsMedia_GetTaskMng()->stImsCallInf.iSession);

    // 通话被远端挂断， 停止发送媒体流
    ImsMedia_GetTaskMng()->stImsCallInf.iSession                   = 0;
    ImsMedia_GetTaskMng()->stImsCallInf.iCallType                  = 0;
    ImsMedia_GetTaskMng()->stImsCallInf.uiCallFlag                 = 0;
    ImsMedia_GetTaskMng()->stImsCallInf.iEarlyMedia                = 0;
    ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame          = 0;
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucToNum,       0x0, sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucToNum));
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucFromNum,     0x0, sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucFromNum));
    MOS_STRNCPY(ImsMedia_GetTaskMng()->stImsCallInf.ucDisplayName, 0x0, sizeof(ImsMedia_GetTaskMng()->stImsCallInf.ucDisplayName));

#if DEBUGVIDEO
    if (imsfp)
    {
        fclose(imsfp);
        imsfp = MOS_NULL;
    }
#endif
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex); 
    if (ImsMedia_GetTaskMng()->bEnableSpeaker)
    {                             
        ImsMedia_GetTaskMng()->bEnableSpeaker  = MOS_FALSE;
        Media_Notify_AudioPlay(IMS_MODULE_NAME, 1, 0, 0);
        Media_AudioPlayDestroyWriteHandle(ImsMedia_GetTaskMng()->hAudioPlay);
        ImsMedia_GetTaskMng()->hAudioPlay = MOS_NULL;

        // 通话挂断, 更新IMS为空闲状态
        Config_AppSLeepMonotorUpdateStatus(ImsMedia_GetTaskMng()->uiSleepMonitorId, EN_SDK_STATE_NONE);

        MOS_LOG_INF(IMSMEDIA_LOGSTR, "Closing audio reverse");
    }

    if (ImsMedia_GetTaskMng()->bEnableDisplay)
    {                             
        ImsMedia_GetTaskMng()->bEnableDisplay  = MOS_FALSE;
        Media_Notify_VideoPlay(IMS_MODULE_NAME, ImsMedia_GetTaskMng()->bEnableDisplay);
        Media_VideoDisPlayDestroyHandle(ImsMedia_GetTaskMng()->hVideoPlay);  
        ImsMedia_GetTaskMng()->hVideoPlay = MOS_NULL;
        Config_SetCamerDisplayOpenFlag(0, MOS_FALSE); 

        MOS_LOG_INF(IMSMEDIA_LOGSTR, "Closing video reverse");
    } 

    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);

    #ifdef BUILD_ONBROADCAST_FALG
    Broadcast_Task_Resume_CloseTalk();
    #endif 

    return MOS_OK;
}

// IMS通话呼叫(AI强告警) 或者 终端按键触发
_INT ImsMedia_CallOut(_UC* pucCallNum, EN_IMS_CALL_TYPE iCallType)
{
    _INT ret = MOS_ERR;

    // 因为发起通话可能要很久才能收到回铃声，所以在此设置为繁忙状态
    Config_AppSLeepMonotorUpdateStatus(ImsMedia_GetTaskMng()->uiSleepMonitorId, EN_SDK_STATE_BUSY);

    ret = IMS_NoticeCallOut(pucCallNum, iCallType);
    if (MOS_OK == ret)
    {
        MOS_LOG_INF(IMSMEDIA_LOGSTR,"IMS Successfully making call!");
    }
    else
    {
        // 发起通话失败,更新IMS为空闲状态
        Config_AppSLeepMonotorUpdateStatus(ImsMedia_GetTaskMng()->uiSleepMonitorId, EN_SDK_STATE_NONE);
    }

    return ret;
}

// IMS 发送流线程
_INT ImsMedia_SendMediaLoopProc(_VPTR vpParam)
{
    _UI uiFrameLen  = 0;
    _UI uiTimeStamp = 0;
    _LLID llTimePts = 0;
    _HVIDEOREAD    hVideoRead         = MOS_NULL;
    _HVIDEOREAD    hAudioRead         = MOS_NULL;
    ST_FRAME_NODE *pucVideoFramHeader = MOS_NULL;
    ST_FRAME_NODE *pucAudioFramHeader = MOS_NULL;

    kj_timer_t   tFeedDogTimeOut;
    kj_timer_init(&tFeedDogTimeOut);
    getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    _HSWDWRITE hSwdFeedDog = Swd_AppThreadRegist(IMS_MEDIA_MNG, FEED_DOG_MAX_TIMESEC);

    while(ImsMedia_GetTaskMng()->ucRunFlag)
    {
        if (getDiffTimems(&tFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
        {
            if (ImsMedia_GetTaskMng()->uiImsFeedFlag >= 1)
            {
                ImsMedia_GetTaskMng()->uiImsFeedFlag = 0;
                Swd_AppThreadFeedDog(hSwdFeedDog);
                getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
            }
        }

        if (ImsMedia_GetTaskMng()->stImsCallInf.uiCallFlag == 1)
        {
            if (ImsMedia_GetTaskMng()->stImsCallInf.iCallType == EN_IMS_CALL_TYPE_IMS_1V1_VIDEO)
            {
                if (MOS_NULL == hVideoRead)
                {
                    hVideoRead = Media_VideoCreatReadHandle2(0, ImsMedia_GetTaskMng()->stImsCallInf.iStreamId, EN_READ_NEWKEY, 0, __FUNCTION__);
                }
                // 向IMS发送视频流
                pucVideoFramHeader = MOS_NULL;
                if (ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame)
                {
                    uiFrameLen = Media_VideoGetFrame2(hVideoRead,&pucVideoFramHeader,&uiTimeStamp,&llTimePts);
                    if ((uiFrameLen > 0) && pucVideoFramHeader && MD_GETFRAMETYPE(pucVideoFramHeader->ucFramPos) == EN_FRAMETYPE_I)
                    {
                        MOS_LOG_INF(IMSMEDIA_LOGSTR,"IMS Find First IIIIIIII Frame Successful StreamId:%d", ImsMedia_GetTaskMng()->stImsCallInf.iStreamId);
                        if(pucVideoFramHeader != MOS_NULL && pucVideoFramHeader->ptDatabuff != MOS_NULL)
                        {
                            ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame = 0;
                            IMS_SendVideo(ImsMedia_GetTaskMng()->stImsCallInf.iSession, pucVideoFramHeader->ptDatabuff, uiFrameLen, uiTimeStamp);
                        }
                    }
                    else
                    {
                        //MOS_LOG_WARN(IMSMEDIA_LOGSTR,"IMS Find First IIIIIIII Frame Error StreamId:%d", ImsMedia_GetTaskMng()->stImsCallInf.iStreamId);
                    }
                }
                else
                {
                    uiFrameLen = Media_VideoGetFrame2(hVideoRead, &pucVideoFramHeader, &uiTimeStamp,&llTimePts);
                    if((uiFrameLen > 0) && pucVideoFramHeader != MOS_NULL && pucVideoFramHeader->ptDatabuff != MOS_NULL)
                    {
                        IMS_SendVideo(ImsMedia_GetTaskMng()->stImsCallInf.iSession, pucVideoFramHeader->ptDatabuff, uiFrameLen, uiTimeStamp);
                    }
                }

                /*while (ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame == 1 || pucVideoFramHeader == MOS_NULL || 
                        MD_GETFRAMETYPE(pucVideoFramHeader->ucFramPos) != EN_FRAMETYPE_I)
                {
                    // MOS_LOG_INF(IMSMEDIA_LOGSTR,"IMS GOTO Find First IIIIIIII Frame");
                    // 第一帧确保I帧
                    Media_VideoSetFrameUsed2(hVideoRead);
                    pucVideoFramHeader = MOS_NULL;
                    Media_VideoGetFrame2(hVideoRead,&pucVideoFramHeader,&uiTimeStamp,&llTimePts);
                }

                if (ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame == 1)
                {
                    MOS_LOG_INF(IMSMEDIA_LOGSTR,"IMS Find First IIIIIIII Frame");
                }
                ImsMedia_GetTaskMng()->stImsCallInf.uiFindFirstIFrame = 0;*/
                Media_VideoSetFrameUsed2(hVideoRead);
            }

            // 向IMS发送音频流
            if (MOS_NULL == hAudioRead)
            {
                hAudioRead = Media_AudioCreatReadHandle2(0, EN_READ_NEWKEY, __FUNCTION__);
            }
            pucAudioFramHeader = MOS_NULL;
            uiFrameLen = Media_AudioGetFrame2(hAudioRead, &pucAudioFramHeader, &uiTimeStamp);
            if((uiFrameLen > 0) && pucAudioFramHeader != MOS_NULL && pucAudioFramHeader->ptDatabuff != MOS_NULL)
            {
                IMS_SendAudio(ImsMedia_GetTaskMng()->stImsCallInf.iSession, pucAudioFramHeader->ptDatabuff, uiFrameLen, uiTimeStamp);
            }
            Media_AudioSetFrameUsed2(hAudioRead);
        }
        else if (ImsMedia_GetTaskMng()->stImsCallInf.iEarlyMedia == 1)
        {
            // 向IMS发送音频流 - 接收回铃音需要先发送音频数据到语音网关
            if (MOS_NULL == hAudioRead)
            {
                hAudioRead = Media_AudioCreatReadHandle2(0, EN_READ_NEWKEY, __FUNCTION__);
            }
            pucAudioFramHeader = MOS_NULL;
            Media_AudioGetFrame2(hAudioRead, &pucAudioFramHeader, &uiTimeStamp);
            if(pucAudioFramHeader != MOS_NULL && pucAudioFramHeader->ptDatabuff != MOS_NULL)
            {
                IMS_SendAudio(ImsMedia_GetTaskMng()->stImsCallInf.iSession, pucAudioFramHeader->ptDatabuff, pucAudioFramHeader->usDatalen, uiTimeStamp);
            }
            Media_AudioSetFrameUsed2(hAudioRead);
        }
        else if (ImsMedia_GetTaskMng()->stImsCallInf.uiCallFlag == 0)
        {
            if (hAudioRead)
            {
                Media_AudioDestroyReadHandle2(hAudioRead);
                hAudioRead = MOS_NULL;
            }  
            if (hVideoRead)
            {
                Media_VideoDestroyReadHandle2(hVideoRead);
                hVideoRead = MOS_NULL;
            }    
        }

        Mos_Sleep(10);

        /*if (Mos_FileIsExist("/tmp/call_ims") == MOS_TRUE)
        {
            MOS_PRINTF("start call out test !!\n");
            ZJ_ImsCallOut(MOS_NULL, ZJ_IMS_CALL_TYPE_1V1_VIDEO);
            Mos_FileRmv("/tmp/call_ims");
        }*/
    }

    Swd_AppThreadUnRegist(hSwdFeedDog);
    // 删除线程
    if(MOS_OK != Mos_ThreadDelete(ImsMedia_GetTaskMng()->hImsMediaThread))
    {
        MOS_LOG_ERR(IMSMEDIA_LOGSTR,"Mos_ThreadDelete hImsMediaThread failed !!");
        return MOS_ERR;
    }

    MOS_LOG_INF(IMSMEDIA_LOGSTR,"hImsMediaThread Exit");

    return MOS_OK;
}

// IMS模块 解析能力平台回复的IMS业务配置的json数据
_INT ImsMedia_ParseQueryBusiCfgRsp(_UC *pucJson)
{
    MOS_PARAM_NULL_RETERR(pucJson);

    _INT iRet              = 0;
    _UC  *pStrTmp          = MOS_NULL;
    _UC  ucSign[16]        = {0};
    _UC  ucBindKey[128]    = {0};
    _UC  ucString[128]     = {0};
    _UI  uiPollingStatus   = 0;
    _UI  uiPollingInterval = 0;
    _UI  uiHaveIMS         = 0;

    JSON_HANDLE hRoot = Adpt_Json_Parse(pucJson);
    if(hRoot == MOS_NULL)
    {
        MOS_LOG_ERR(IMSMEDIA_LOGSTR, "hRoot == MOS_NULL");
        return MOS_ERR;
    }

    JSON_HANDLE hBody = Adpt_Json_GetObjectItem(hRoot,(_UC*)"BODY");
    if(hBody == MOS_NULL)
    {
        return MOS_ERR;
    }

    // 版本号，可依据该字段判断IMS业务参数是否是否有变化
    Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Sign"),&pStrTmp);
    MOS_STRNCPY(ucSign, pStrTmp, sizeof(ucSign));

    if (MOS_STRNCMP(Config_GetImsMng()->ucSign, ucSign, sizeof(Config_GetImsMng()->ucSign)) != 0)
    {
        MOS_SPRINTF(ucString, "Device IMS Busi Cfg Sign:%s Change to %s", Config_GetImsMng()->ucSign, ucSign);
        MOS_LOG_INF(IMSMEDIA_LOGSTR, ucString);

        Config_SetImsSign(ucSign);

        Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
        // 轮询间隔
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PollingInterval"),(_INT*)&uiPollingInterval);
        Config_SetImsPollingInterval(uiPollingInterval);

        // 轮询开关 0.关闭，1.开启，默认关，轮询依赖套餐开通
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"PollingStatus"),(_INT*)&uiPollingStatus);
        Config_SetImsPollingStatus(uiPollingStatus);

        // 是否开通 0.关闭 1.开通
        Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBody,(_UC*)"HaveIMS"),(_INT*)&uiHaveIMS);
        Config_SetImsHaveIMSValue(uiHaveIMS);        

        // 备份绑定码
        Adpt_Json_GetString(Adpt_Json_GetObjectItem(hBody,(_UC*)"Bindkey"),&pStrTmp);
        MOS_STRNCPY(ucBindKey, pStrTmp, sizeof(ucBindKey));
        Config_SetImsBindKey(ucBindKey); 

        Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);

        // IMS业务参数
        _UC *pucImsBusiParamJson = Adpt_Json_Print(hBody);
        Config_SetImsBusiParamJson(pucImsBusiParamJson);
        IMS_SetBusiParamsInf(Config_GetSystemMng()->aucDevCTEI, pucImsBusiParamJson);
        Adpt_Json_DePrint(pucImsBusiParamJson);

        CloudStg_UploadLog(Mos_GetSessionId(), IMSMEDIA_QUERYIMSCONFIG_URL, -1, iRet, ucString, 1);
    }
    else
    {
        MOS_LOG_ERR(IMSMEDIA_LOGSTR, "Device IMS Busi Cfg Sign No Change");
    }
    
    Adpt_Json_Delete(hRoot);
    return iRet;
}

// 建立查询IMS业务配置的json数据  POST方式
_UC *ImsMedia_BuildQueryBusiCfgJson(_UI uiSeqId)
{
    _UI uiTime              = 0;
    _UC *pStrTmp            = MOS_NULL;
    _UC *pucOutBuff         = MOS_NULL;
    _UC aucMethod[8]        = {0};
    _UC aucInBuf[256]       = {0};

    uiTime = Mos_GetTickCount();

    JSON_HANDLE hBody = MOS_NULL;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    MOS_VSNPRINTF(aucMethod, 8,(_UC*)"%02X%02X",EN_OGCT_METHOD_CFGBUSS,EN_OGCT_CFGBUSS_QUERY_IMS_CONFIG);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID", Adpt_Json_CreateStrWithNum(uiSeqId));
    hBody = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);

    Adpt_Json_AddItemToObject(hBody, (_UC*)"CTEI",      Adpt_Json_CreateString((_UC*)(Config_GetSystemMng()->aucDevCTEI)));
    Adpt_Json_AddItemToObject(hBody, (_UC*)"DID",       Adpt_Json_CreateString((_UC*)(Config_GetSystemMng()->aucDevUID)));
    Adpt_Json_AddItemToObject(hBody, (_UC*)"TimeStamp", Adpt_Json_CreateStrWithNum((_DOUBLE)uiTime));
    Adpt_Json_AddItemToObject(hBody, (_UC*)"Version",   Adpt_Json_CreateString((_UC*)(Config_GetDeviceMng()->aucDevVerSion)));
    
    pucOutBuff = (_UC*)MOS_MALLOCCLR(128);
    MOS_VSNPRINTF(aucInBuf, 256,"CTEI=%s&DID=%s&TimeStamp=%u&Version=%s",
            Config_GetSystemMng()->aucDevCTEI, Config_GetSystemMng()->aucDevUID, uiTime, Config_GetDeviceMng()->aucDevVerSion);
    // 对数据进行sha256加密
    Adpt_HmacSha256_Encrypt(aucInBuf,pucOutBuff,128,Config_GetSystemMng()->aucDevkey);
    Adpt_Json_AddItemToObject(hBody,(_UC*)"Signature", Adpt_Json_CreateString(pucOutBuff));

    pStrTmp = Adpt_Json_Print(hRoot);

    MOS_LOG_INF(IMSMEDIA_LOGSTR, "IMS BUSI CFG INPUT pStrTmp:%s", pStrTmp);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pucOutBuff);
    return pStrTmp;
}

// IMS模块 接收能力平台回复IMS业务信息的数据
_VOID ImsMedia_QueryBusiCfgRsp(_UC* pucData, _UI uiLen, _VPTR vpUserPtr)
{
    MOS_PARAM_NULL_NORET(pucData);

    if(ImsMedia_GetHttpTask()->usBuffLen == 0)
    {
        ImsMedia_GetHttpTask()->usBuffLen   = 1024;
        ImsMedia_GetHttpTask()->pucHttpBuff = (_UC*)MOS_MALLOC(ImsMedia_GetHttpTask()->usBuffLen);
    }
    if(ImsMedia_GetHttpTask()->usRecvLen + uiLen < ImsMedia_GetHttpTask()->usBuffLen)
    {
        MOS_MEMCPY(ImsMedia_GetHttpTask()->pucHttpBuff + ImsMedia_GetHttpTask()->usRecvLen, pucData, uiLen);
        ImsMedia_GetHttpTask()->usRecvLen += uiLen;
    }
    return;
}

// IMS模块 接收能力平台回复IMS业务信息的数据结束
_VOID ImsMedia_QueryBusiCfgFinish(_VPTR vpUserPtr)
{   
    if(ImsMedia_GetHttpTask()->pucHttpBuff)
    {
        ImsMedia_GetHttpTask()->pucHttpBuff[ImsMedia_GetHttpTask()->usRecvLen] = 0;
        MOS_LOG_INF(IMSMEDIA_LOGSTR, "QUERY IMS BUSI CFG Finish Recv %s", ImsMedia_GetHttpTask()->pucHttpBuff);
    }
    else
    {
        MOS_LOG_ERR(IMSMEDIA_LOGSTR, "QUERY IMS BUSI CFG Finish Recv Null");
    }

    // IMS模块 解析能力平台回复的IMS业务配置的json数据
    if (ImsMedia_ParseQueryBusiCfgRsp(ImsMedia_GetHttpTask()->pucHttpBuff) == MOS_OK)
    {
        // 若设备上线为获取到IMS配置，通知结束获取，但轮询获取继续
        ImsMedia_SetOnlineQueryCfgStatus(EN_IMS_QUERY_CFG_STATUS_SUCCESS);
        ImsMedia_SetQueryBusiCfgFailTimes(0);
        
    }
    else
    {
        ImsMedia_SetOnlineQueryCfgStatus(EN_IMS_QUERY_CFG_STATUS_NEED);
        Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
        ImsMedia_GetTaskMng()->uiQueryBusiCfgFailTimes++;
        if (ImsMedia_GetTaskMng()->uiQueryBusiCfgFailTimes >= IMSMEDIA_MAX_QUERYBUSI_FAILTIMES)
        {
            ImsMedia_GetTaskMng()->uiQueryBusiCfgFailTimes = IMSMEDIA_MAX_QUERYBUSI_FAILTIMES;
        }
        Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);        
    }
    
    MOS_FREE(ImsMedia_GetHttpTask()->pucHttpBuff);
    ImsMedia_GetHttpTask()->pucHttpBuff   = MOS_NULL;
    ImsMedia_GetHttpTask()->usBuffLen     = 0;
    ImsMedia_GetHttpTask()->usRecvLen     = 0;
    ImsMedia_GetHttpTask()->uiHttpHandle  = 0;
    return ;
}

// IMS模块 接收能力平台回复IMS业务信息的数据失败
_VOID ImsMedia_QueryBusiCfgFail(_VPTR vpUserPtr,_UI uiErrCode, _UI uiReqId)
{
    _UC  ucString[128] = {0};

    if(ImsMedia_GetHttpTask()->pucHttpBuff)
    {
        MOS_LOG_ERR(IMSMEDIA_LOGSTR,"QUERY IMS BUSI CFG Fail Recv %s",ImsMedia_GetHttpTask()->pucHttpBuff);
    }
    MOS_FREE(ImsMedia_GetHttpTask()->pucHttpBuff);
    ImsMedia_GetHttpTask()->pucHttpBuff   = MOS_NULL;
    ImsMedia_GetHttpTask()->usBuffLen     = 0;
    ImsMedia_GetHttpTask()->usRecvLen     = 0;
    ImsMedia_GetHttpTask()->uiHttpHandle  = 0;

    ImsMedia_SetOnlineQueryCfgStatus(EN_IMS_QUERY_CFG_STATUS_NEED);
    
    Mos_MutexLock(&ImsMedia_GetTaskMng()->hImsMutex);
    ImsMedia_GetTaskMng()->uiQueryBusiCfgFailTimes++;
    if (ImsMedia_GetTaskMng()->uiQueryBusiCfgFailTimes >= IMSMEDIA_MAX_QUERYBUSI_FAILTIMES)
    {
        ImsMedia_GetTaskMng()->uiQueryBusiCfgFailTimes = IMSMEDIA_MAX_QUERYBUSI_FAILTIMES;
    }
    Mos_MutexUnLock(&ImsMedia_GetTaskMng()->hImsMutex);

    MOS_SPRINTF(ucString, "IMS Query IMS Busi Cfg Fail");
    CloudStg_UploadLog(Mos_GetSessionId(), IMSMEDIA_QUERYIMSCONFIG_URL, uiErrCode, -1, ucString, 1);
    return;
}

// 向能力平台查询IMS业务配置
_INT ImsMedia_QueryBusiCfgFromServer()
{
    _INT iRet              =  0;
    _UI  uiSeqId           = Mos_GetSessionId();
    _UI  uiHttpsFlag       =  0;
    _UC *pStrTmp           = MOS_NULL;
    _UC *pStrStart         = MOS_NULL;
    _US  usPort            = 80;
    _UC  auAdmonAddr[128]  = {0};
    ST_MOS_INET_IP stNetIp = {0};   

    pStrTmp = MOS_STRSTR(Config_GetSystemMng()->aucImsAddr,"https");
    if(pStrTmp != MOS_NULL)
    {
        uiHttpsFlag = 1;
        usPort      = 443;
    } 

    pStrStart = MOS_STRSTR(Config_GetSystemMng()->aucImsAddr,"//");
    if(pStrStart == MOS_NULL)
    {
        pStrStart = Config_GetSystemMng()->aucImsAddr;
    }
    else
    {
        pStrStart += 2;
    }
    pStrTmp = MOS_STRSTR(pStrStart,":");
    if(pStrTmp != MOS_NULL)
    {
        MOS_MEMCPY(auAdmonAddr,pStrStart,pStrTmp - pStrStart);
        pStrTmp++;
        usPort = MOS_ATOI(pStrTmp);
    }
    else
    {
        MOS_STRLCPY(auAdmonAddr, pStrStart, sizeof(auAdmonAddr));
    }

    // 建立查询IMS业务配置的json数据  POST方式
    pStrTmp = ImsMedia_BuildQueryBusiCfgJson(uiSeqId);

    ST_HTTP_INFO_NODE stHttpInfoNode = {0};
    Http_GetDefaultConfig(&stHttpInfoNode);
    stHttpInfoNode.uiSSLFlag       = uiHttpsFlag;
    stHttpInfoNode.pfuncRecv       = ImsMedia_QueryBusiCfgRsp;
    stHttpInfoNode.pfuncFinished   = ImsMedia_QueryBusiCfgFinish;
    stHttpInfoNode.pfuncFailed     = ImsMedia_QueryBusiCfgFail;
    stHttpInfoNode.iTimeOut        = 15;
    stHttpInfoNode.pucContent      = pStrTmp;
    stHttpInfoNode.uiContentLen    = MOS_STRLEN(pStrTmp);
    iRet = Http_SendAsyncRequest(&stHttpInfoNode, auAdmonAddr, IMSMEDIA_QUERYIMSCONFIG_URL, EN_HTTP_METHOD_POST, uiSeqId);

    MOS_FREE(pStrTmp);

    return iRet;
}

// IMS 查询业务配置
_INT ImsMedia_PollBusiCfg()
{
    _INT iRet = 0;
    _CTIME_T cNowPollQueryTime    = 0;
    _CTIME_T cSubPollQueryTime    = 0;
    _CTIME_T cNowOnlineQueryTime  = 0;
    _CTIME_T cSubOnlineQueryTime  = 0;
    _UI uiPollingStatus           = 0;
    _UI uiPollingInterval         = 0;
    _UI uiOnlineStatus            = 0;
    _UI uiOnlineQueryCfgStatus    = 0;
    _UI uiQueryBusiCfgFailTimes   = 0;
    _UI uiOnlineQueryInterval     = 0;

    if (ImsMedia_GetTaskMng()->ucRunFlag == 0)
    {
        return MOS_ERR;
    }

    if (Mos_MsgQueueGetCount(ImsMedia_GetTaskMng()->hImsMsgQueue) > 0)
    {  
        ST_IMS_ONLINESTATUS_MSG *pstImsMsg = (ST_IMS_ONLINESTATUS_MSG *)Mos_MsgQueuePop(ImsMedia_GetTaskMng()->hImsMsgQueue);
        if (pstImsMsg != NULL)
        {
            if (pstImsMsg->uiOnlineStatus == EN_ZJ_DEVICE_STATUS_ONLINE)
            {
                IMS_SetDevOnlineStatus(EN_ZJ_DEVICE_STATUS_ONLINE);
                ImsMedia_SetOnlineStatus(EN_ZJ_DEVICE_STATUS_ONLINE);
                ImsMedia_SetOnlineQueryCfgStatus(EN_IMS_QUERY_CFG_STATUS_NEED);
                MOS_LOG_INF(IMSMEDIA_LOGSTR, "Device Online ! Get IMS Info");
            }
            else
            {
                // 掉线后下次上线继续获取IMS业务参数
                MOS_LOG_INF(IMSMEDIA_LOGSTR, "Device Offline !");
                ImsMedia_SetOnlineStatus(EN_ZJ_DEVICE_STATUS_OFFLINE);
                ImsMedia_SetOnlineQueryCfgStatus(EN_IMS_QUERY_CFG_STATUS_NONEED);
            }
            MOS_FREE(pstImsMsg);
        }
    }

    // 信令上线查询IMS业务配置  第一种方式
    uiOnlineStatus         = ImsMedia_GetOnlineStatus();
    uiOnlineQueryCfgStatus = ImsMedia_GetOnlineQueryCfgStatus();

    #ifdef DX_DOORBELL // 门铃需要快速获得IMS业务信息
    if (0 == ImsMedia_GetTaskMng()->uiFirstPollBusiFlag)
    #else
    if (uiOnlineStatus == EN_ZJ_DEVICE_STATUS_ONLINE && uiOnlineQueryCfgStatus == EN_IMS_QUERY_CFG_STATUS_NEED)
    #endif
    {
        cNowOnlineQueryTime     = Mos_Time();
        uiQueryBusiCfgFailTimes = ImsMedia_GetQueryBusiCfgFailTimes();
        cSubOnlineQueryTime     = MOS_ABS_NUM(cNowOnlineQueryTime - g_cOldOnlineQueryTime);
        if (uiQueryBusiCfgFailTimes <= IMSMEDIA_MAX_QUERYBUSI_FAILTIMES)
        {
            // （3*（1+2*n））+（1-5）
            uiOnlineQueryInterval = (3 * (1 + (2 * uiQueryBusiCfgFailTimes))) + 2;
        }
        else
        {
            uiOnlineQueryInterval = IMSMEDIA_MAX_QUERYBUSI_INTERVAL;
            IMS_SetBusiParamsInf(Config_GetSystemMng()->aucDevCTEI, Config_GetImsMng()->ucImsBusiParamJson);
        }
        if (cSubOnlineQueryTime >= uiOnlineQueryInterval)
        {
            MOS_LOG_INF(IMSMEDIA_LOGSTR, "IMS ONLINE Get IMS Info SubOnlineQueryTime:%u OnlineIntrtval:%u", cSubOnlineQueryTime, uiOnlineQueryInterval);
            iRet = ImsMedia_QueryBusiCfgFromServer();
            // 成功解析DNS并插入HTTPS链表中
            if (MOS_OK == iRet)
            {
                MOS_LOG_INF(IMSMEDIA_LOGSTR, "query busi success!\n");
                ImsMedia_GetTaskMng()->uiFirstPollBusiFlag = 1;
                g_cOldOnlineQueryTime = cNowOnlineQueryTime;
                ImsMedia_SetOnlineQueryCfgStatus(EN_IMS_QUERY_CFG_STATUS_NOW);
                MOS_PRINTF("%s g_cOldOnlineQueryTime=%u\n", __FUNCTION__, g_cOldOnlineQueryTime);
            }
        }
    }

    // 轮询查询IMS业务配置  第二种方式
    uiPollingStatus = ImsMedia_GetPollingStatus();
    if (uiPollingStatus == EN_IMS_POLL_STATUS_OPEN)
    {
        cNowPollQueryTime   = Mos_Time();
        uiPollingInterval   = ImsMedia_GetPollingInterval();
        cSubPollQueryTime = MOS_ABS_NUM(cNowPollQueryTime - g_cOldPollQueryTime);
        if (cSubPollQueryTime >= uiPollingInterval)
        {
            MOS_LOG_INF(IMSMEDIA_LOGSTR, "IMS Loop Get IMS Info SubPollQueryTime:%u PollIntrtval:%u", cSubPollQueryTime, uiPollingInterval);
            iRet = ImsMedia_QueryBusiCfgFromServer();
            // 成功解析DNS并插入HTTPS链表中
            if (MOS_OK == iRet)
            {
                g_cOldPollQueryTime = cNowPollQueryTime;
                MOS_PRINTF("%s g_cOldPollQueryTime=%u\n", __FUNCTION__, g_cOldPollQueryTime);
            }
        }
    }

    return MOS_OK;
}

#if 0
// IMS 轮询查询业务配置线程
_INT ImsMedia_PollBusiCfgLoopProc(_VPTR vpParam)
{
    kj_timer_t   tFeedDogTimeOut;
    kj_timer_init(&tFeedDogTimeOut);
    getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_MSECONDS, 60*10);
    _HSWDWRITE hSwdFeedDog = Swd_AppThreadRegist(IMS_CFG_MNG, FEED_DOG_MAX_TIMESEC);

    while(ImsMedia_GetTaskMng()->ucRunFlag)
    {
        if (getDiffTimems(&tFeedDogTimeOut,  0, ENUM_SECONDS_TYPE_SECONDS, 60*10) >= FEED_DOG_TIMEOUT_SEC)
        {
            Swd_AppThreadFeedDog(hSwdFeedDog);
            getDiffTimems(&tFeedDogTimeOut,  1, ENUM_SECONDS_TYPE_SECONDS, 60*10);
        }

        ImsMedia_PollBusiCfg();
        Mos_Sleep(200);
    }

    Swd_AppThreadUnRegist(hSwdFeedDog);
    // 删除线程
    if(MOS_OK != Mos_ThreadDelete(ImsMedia_GetTaskMng()->hImsPollBusiThread))
    {
        MOS_LOG_ERR(IMSMEDIA_LOGSTR,"Mos_ThreadDelete hImsPollBusiThread failed !!");
        return MOS_ERR;
    }

    MOS_LOG_INF(IMSMEDIA_LOGSTR,"hImsPollBusiThread Exit");
    return MOS_OK;
}
#endif

// IMS模块睡眠监控注册
_INT ImsMedia_AppSLeepMonotorRegist(void)
{
    ImsMedia_GetTaskMng()->uiSleepMonitorId  = Config_AppSLeepMonotorRegist(IMS_MEDIA_MNG);

    return MOS_OK;
}

// IMS模块睡眠监控解注册
_INT ImsMedia_AppSLeepMonotorUnRegist(void)
{
    Config_AppSLeepMonotorUnRegist(ImsMedia_GetTaskMng()->uiSleepMonitorId);

    return MOS_OK;
}

// IMS模块初始化
_INT ImsMedia_Task_Init()
{
    if (ImsMedia_GetTaskMng()->ucRunFlag == 1)
    {
        return MOS_OK;
    }

    _INT iRet = 0;
    ST_IMS_FUNC_HANDLE_CB stImsFuncsHandleCb         = {0};
    stImsFuncsHandleCb.pFuncImsRecvRingCb            = ImsMedia_RecvRingCb;                 // 回铃音回调
    stImsFuncsHandleCb.pFuncImsRecvCallCb            = ImsMedia_RecvCallCb;                 // 接收到来电回调
    stImsFuncsHandleCb.pFuncImsRecvAnswerCb          = ImsMedia_RecvAnswerCb;               // 会话接通回调
    stImsFuncsHandleCb.pFuncImsRecvHangUpCb          = ImsMedia_RecvHangUpCb;               // 会话被挂断回调
    stImsFuncsHandleCb.pFuncImsRecvNotifyCb          = ImsMedia_RecvNotifyCb;               // 事件通知回调
    stImsFuncsHandleCb.pFuncImsRecvKeyFrameRequestCb = ImsMedia_RecvKeyFrameRequestCb;      // 强制关键帧回调
    stImsFuncsHandleCb.pFuncImsRecvDtmfCb            = ImsMedia_RecvDtmfCb;                 // DTMF通知回调 
    stImsFuncsHandleCb.pFuncImsRecvAudioPacketCb     = ImsMedia_RecvAudioPacketCb;          // 推送音频流到对端回调 
    stImsFuncsHandleCb.pFuncImsRecvVideoPacketCb     = ImsMedia_RecvVideoPacketCb;          // 推送视频流到对端回调 
    stImsFuncsHandleCb.pFuncImsLogOutPutCb           = ImsMedia_LogOutPutCb;                // 日志上报回调
    stImsFuncsHandleCb.pFuncImsSyncSendPostRequestCb = ImsMedia_HttpsPostGetLoginDataCb;    // 获取登录参数回调
    stImsFuncsHandleCb.pFuncImsSetAudioParamCb       = ImsMedia_SetAudioParamCb;            // 设置设备音频参数回调
    stImsFuncsHandleCb.pFuncImsSetVideoParamCb       = ImsMedia_SetVideoParamCb;            // 设置设备视频参数回调
    stImsFuncsHandleCb.pFuncImsSetVideoStreamIdCb    = ImsMedia_SetVideoStreamIdCb;         // 设置发送IMS视频流的码流通道的回调
    stImsFuncsHandleCb.pFuncImsRecvImsHeartBeatCb    = ImsMedia_RecvImsKeepAliveCb;         //设置IMS功能心跳状态回调
    
    _UC aucCfgPath[256] = {0};
    MOS_VSNPRINTF(aucCfgPath, 256, "%s/config/%s",Mos_GetWorkPath(),IMS_SIP_FILE);
    IMS_SdkInit(&stImsFuncsHandleCb, aucCfgPath);

    // IMS_SetBusiParamsInf(Config_GetSystemMng()->aucDevCTEI, Config_GetImsMng()->ucImsBusiParamJson);

    Mos_MutexCreate(&ImsMedia_GetTaskMng()->hImsMutex);
    ImsMedia_GetTaskMng()->hImsMsgQueue = Mos_MsgQueueCreate(MOS_FALSE, 3, __FUNCTION__);

    ImsMedia_GetTaskMng()->ucRunFlag = 1;
    if(-1 == (iRet = Mos_ThreadCreate((_UC *)"IMS_SENDMEDIA", EN_THREAD_PRIORITY_NORMAL, MOS_THREAD_STACK_NORMAL_SIZE,
        ImsMedia_SendMediaLoopProc, MOS_NULL, MOS_NULL, &ImsMedia_GetTaskMng()->hImsMediaThread)))
    {
        ImsMedia_GetTaskMng()->ucRunFlag = 0;
        MOS_LOG_INF(IMSMEDIA_LOGSTR,"IMS Media init task IMS_SENDMEDIA failed");
        return MOS_ERR;
    }
#if 0
    if(-1 == (iRet = Mos_ThreadCreate((_UC *)"IMS_POLLBUSI", EN_THREAD_PRIORITY_NORMAL, MOS_THREAD_STACK_NORMAL_SIZE,
        ImsMedia_PollBusiCfgLoopProc, MOS_NULL, MOS_NULL, &ImsMedia_GetTaskMng()->hImsPollBusiThread)))
    {
        ImsMedia_GetTaskMng()->ucRunFlag = 0;
        MOS_LOG_INF(IMSMEDIA_LOGSTR,"IMS Media init task IMS_POLLBUSI failed");
        return MOS_ERR;
    }
#endif
    MOS_LOG_INF(IMSMEDIA_LOGSTR,"IMS Media init task ok");
    return MOS_OK;
}

// IMS模块销毁
_INT ImsMedia_Task_Destroy()
{
    ST_IMS_ONLINESTATUS_MSG *pstImsMsg = NULL;
    ImsMedia_GetTaskMng()->ucRunFlag = 0;
    Mos_ThreadDelete(ImsMedia_GetTaskMng()->hImsMediaThread);
    // Mos_ThreadDelete(ImsMedia_GetTaskMng()->hImsPollBusiThread);
    Mos_MutexDelete(&ImsMedia_GetTaskMng()->hImsMutex);
    //Mos_MsgQueueWake(ImsMedia_GetTaskMng()->hImsMsgQueue, MOS_TRUE);
    while((pstImsMsg = Mos_MsgQueuePop(ImsMedia_GetTaskMng()->hImsMsgQueue)) != MOS_NULL)
    {
        MOS_FREE(pstImsMsg);
    }
    Mos_MsgQueueDelete(ImsMedia_GetTaskMng()->hImsMsgQueue);
    IMS_SdkDestroy();
    return MOS_OK;
}

//设置网络类型，无网、AP网络、有线、WIFI、4G等 
_INT ImsMedia_Task_SetNetworkType(_UC ucNetworkType)
{
    if(g_enImsNetType != ucNetworkType)
    {
        g_enImsNetType = ucNetworkType;

        // 无网络
        if (g_enImsNetType == EN_ZJ_NETWORK_TYPE_NONET || g_enImsNetType == EN_ZJ_NETWORK_TYPE_AP || g_enImsNetType == EN_ZJ_NETWORK_TYPE_NONSENSE)
        {
            ImsMedia_Task_Logout();
        }
        else
        {
            ImsMedia_Task_Login();
        }
    }

    return MOS_OK;
}

int ImsMedia_Task_Logout()
{
    return IMS_ServerLogout();
}

int ImsMedia_Task_Login()
{
    ST_IMS_LOGIN_PARAMS_INF pstLoginParam = {0};
    MOS_STRNCPY(pstLoginParam.ucCtei,   Config_GetSystemMng()->aucDevCTEI,   sizeof(pstLoginParam.ucCtei));
    MOS_STRNCPY(pstLoginParam.ucBindKey,Config_GetImsMng()->ucBindKey,       sizeof(pstLoginParam.ucBindKey));
    MOS_STRNCPY(pstLoginParam.ucSign,   Config_GetImsMng()->ucSign,          sizeof(pstLoginParam.ucSign));

    return IMS_ServerLogin(&pstLoginParam);
}

