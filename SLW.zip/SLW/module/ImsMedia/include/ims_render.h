#ifndef _IMS_APIRENDER_H
#define _IMS_APIRENDER_H

#ifdef __cplusplus
extern "C" {
#endif
#include "media_audioplay.h"
#include "ims_type.h"
#include "media_video_display.h"

#define IMSMEDIA_LOGSTR "IMS"

#define IMSMEDIA_QUERYIMSCONFIG_URL (_UC*)"/app2/device/QueryIMSConfig"  // 查询IMS业务配置URL

#define IMSMEDIA_MAX_QUERYBUSI_FAILTIMES  (10)
#define IMSMEDIA_MAX_QUERYBUSI_INTERVAL   (24 * 60 *60)

typedef enum enum_IMS_QUERY_CFG_STATUS
{
    EN_IMS_QUERY_CFG_STATUS_NONEED  = 0,    // 不需要查询IMS业务配置
    EN_IMS_QUERY_CFG_STATUS_NEED    = 1,    // 需要查询IMS业务配置
    EN_IMS_QUERY_CFG_STATUS_NOW     = 2,    // IMS业务配置查询中
    EN_IMS_QUERY_CFG_STATUS_SUCCESS = 3,    // IMS业务查询配置成功
    EN_IMS_QUERY_CFG_STATUS_FAILED  = 4,    // IMS业务查询配置失败
}EN_IMS_QUERY_CFG_STATUS;

typedef enum enum_IMS_POLL_STATUS
{
    EN_IMS_POLL_STATUS_CLOSE        = 0,    // 轮询IMS业务配置关闭
    EN_IMS_POLL_STATUS_OPEN         = 1     // 轮询IMS业务配置开启
}EN_IMS_POLL_STATUS;

typedef struct stru_IMS_HTTP_TASK
{
    _UI  uiHttpHandle;              // HTTP请求句柄
    _US  usBuffLen;                 // 单次接收数据长度
    _US  usRecvLen;                 // 总共接收数据长度
    _UC *pucHttpBuff;               // HTTP Buf

    _US  usSipBuffLen;              // 接收到的SIP数据长度
    _US  usSipBuffMaxLen;           // SIP数据buffer大小
    _UC *pucSipBuff;                // 专门保存接收到的SIP数据
}ST_IMS_HTTP_TASK;

// 通话参数
typedef struct stru_IMS_CALL_INFO
{
    _INT iSession;                  // 会话ID  
    _INT iStreamId;                 // 视频码流ID
    _UI  uiCallFlag;                // 通话状态
    _UC  ucToNum[16];               // 被叫号码
    _UC  ucFromNum[16];             // 主叫号码
    _UC  ucDisplayName[64];         // 主叫名称
    _UI  uiFindFirstIFrame;         // 查找第一个I帧标志
    _INT iEarlyMedia;               // 早期媒体标志-回铃音标志
    EN_IMS_CALL_TYPE iCallType;     // 来电类型
} ST_IMS_CALL_INFO;
typedef struct stru_IMS_TASKMNG
{
    _UC  ucRunFlag;                 // 模块运行标志
    _UI  uiOnlineStatus;            // 设备在线状态
    _UI  uiOnlineQueryCfgStatus;    // 信令上线查询配置状态
    _UI  uiQueryBusiCfgFailTimes;   // 查询IMS业务配置失败次数
    ST_IMS_CALL_INFO stImsCallInf;  // 通话参数
    _HMUTEX  hImsMutex;             // IMS互斥锁
    _HQUEUE  hImsMsgQueue;          // IMS消息队列
    _HTHREAD hImsMediaThread;       // 发送流媒体线程
    _HTHREAD hImsPollBusiThread;    // 轮询请求IMS业务参数线程
    _BOOL       bEnableSpeaker;     // 对端音频播放使能值
    _HAUDIOPLAY hAudioPlay;         // 对端音频节点
    _BOOL       bEnableDisplay;     // 对端音视频显示播放使能值
    _HVPLAYHANDLE hVideoPlay;       // 对端视频节点
    _UI  uiImsFeedFlag;             // IMS功能模块心跳包状态
    _UI  uiSleepMonitorId;          // 睡眠监控ID
    _UI  uiFirstPollBusiFlag;       // 首次查下IMS业务标志
}ST_IMS_TASKMNG;

typedef struct stru_IMS_ONLINESTATUS_MSG
{
    ST_MOS_MSGHEAD stMsgHead;
    _UI uiOnlineStatus;
}ST_IMS_ONLINESTATUS_MSG;

ST_IMS_TASKMNG   *ImsMedia_GetTaskMng();
ST_IMS_HTTP_TASK *ImsMedia_GetHttpTask();

// IMS模块睡眠监控注册
_INT ImsMedia_AppSLeepMonotorRegist(void);

// IMS模块睡眠监控解注册
_INT ImsMedia_AppSLeepMonotorUnRegist(void);

// IMS模块初始化
_INT ImsMedia_Task_Init();
// IMS模块销毁
_INT ImsMedia_Task_Destroy();

// IMS通话呼叫(AI强告警) 或者 终端按键触发
_INT ImsMedia_CallOut(_UC* pucCallNum, EN_IMS_CALL_TYPE iCallType);

// IMS主动挂断
_INT ImsMedia_HangUp();

// IMS是否开通 0.关闭 1.开通
_UI  ImsMedia_GetHaveIMS();
// 轮询查询IMS业务配置开关
_UI  ImsMedia_GetPollingStatus();
// 轮询查询IMS业务配置间隔
_UI  ImsMedia_GetPollingInterval();
// 设备在线状态
_UI  ImsMedia_GetOnlineStatus();
_INT ImsMedia_SetOnlineStatus(_UI uiOnlineStatus);
// 信令上线查询配置状态
_UI  ImsMedia_GetOnlineQueryCfgStatus();
_INT ImsMedia_SetOnlineQueryCfgStatus(_UI uiOnlineQueryCfgStatus);
// 查询IMS业务配置失败次数
_UI  ImsMedia_GetQueryBusiCfgFailTimes();
_INT ImsMedia_SetQueryBusiCfgFailTimes(_UI uiQueryBusiCfgFailTimes);

// IMS 查询业务配置
_INT ImsMedia_PollBusiCfg();

_INT ImsMedia_SetMultiMedia(_VOID* pstMultiMedia);

_INT ImsMedia_SetP2pMedia(_VOID* pstP2pMedia);

// IMS 登录与登出
int ImsMedia_Task_Logout();

int ImsMedia_Task_Login();

//设置网络类型 
_INT ImsMedia_Task_SetNetworkType(_UC ucNetworkType);

#ifdef __cplusplus
}
#endif
#endif
