#ifndef _CMDHDL_TYPE_H
#define _CMDHDL_TYPE_H

#ifdef __cplusplus
extern "C" {
#endif


typedef struct stru_FROMTO_MSG
{
    _UC aucUserToken[CFG_STRING_LEN];
    _UC aucSvrID[CFG_STRING_LEN];
    _UC aucDID[CFG_STRING_LEN];
}ST_FROM_TO_MSG;

typedef struct ST_CMD_MSG_INF
{
    _UI uiSeqId;
    _UC ucMsgType;
    _UC ucMsgId;
    _UC aucPeerId[64];
    ST_FROM_TO_MSG stMsgFromTo;
}ST_CMD_MSG_INF;

typedef struct stru_CMSTASK_SETTIMEZONE
{
    _INT iSyncFlag;
    _INT iUseDstFlag;
    _INT iZone;
    _UC aucArea[CFG_STRING_LEN];
    _UC aucTimeStr[CFG_STRING_COMMONLEN];
}ST_CMSTASK_SETTIMEZONE;


typedef struct stru_CMSTASK_PTZOPT
{
    _INT iPtzCtrlType;
    union
    {
        struct 
        {
            _INT iPTZControl;
            _INT iSpeed;
            _INT iStep;
            _INT iZoom;
            _INT iFocus;
        } stOnPtzInf; 
        _UI uiPreSetId;
        _UI uiCruiseId;
    }u;
}ST_CMSTASK_PTZOPT;


// 图片信息
typedef struct stru_CMSTASK_DOWNLOAD_PICTURE_INF
{
    _UI uiWBList;                   // 所属名单 0.都不属于；1.黑名单；2.白名单
    _UC ucDispositionID[64];        // 布控id    底库图片ID
    _UC ucDesc[64];                 // 布控时平台下发的图片描述信息
    _UC ucPicUrl[512];              // 图片下载地址

}ST_CMSTASK_DOWNLOAD_PICTURE_INF;

typedef struct stru_CMSTASK_FACEORLICENSELIB_INF
{
    _UC  ucTaskID[16];       // 任务ID
    _UC  ucUserID[16];       // 用户标识
    _INT iPicType;           // 图片类型 1、人脸；2、车牌
    ST_CMSTASK_DOWNLOAD_PICTURE_INF stPictureInf[10];

}ST_CMSTASK_FACEORLICENSELIB_INF;


#ifdef __cplusplus
}
#endif

#endif
