#ifndef _CMDHDL_API_H
#define _CMDHDL_API_H

#include "cmdhdl_type.h"

#ifdef __cplusplus
extern "C" {
#endif

_INT Cmdhdl_Task_Init();

_INT Cmdhdl_Task_Start();

_INT Cmdhdl_Task_Stop();

_INT Cmdhdl_Task_Destroy();

_INT Cmdhdl_SetCommonMsg(_UC *pucPeerId,_UI uiSeqId,_UC ucMsgType,_UC ucMsgId,ST_FROM_TO_MSG *pstMsgFromTo);

_INT Cmdhdl_SetDevTimeAndZoneMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,ST_CMSTASK_SETTIMEZONE *pstSetTimeAndZone);

_INT Cmdhdl_SetDevPtzCtrlMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,ST_CMSTASK_PTZOPT *pstPtzOpt);

_INT Cmdhdl_SetCamOsdInfMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iPosition,_UC *pucOsdName);

_INT Cmdhdl_SetCamOsdInfExMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC * pucOsdTopLeftName,_UC *pucOsdLowerLeftName,
                                                                                        _UC *pucOsdTopRightName,_UC *pucOsdLowerRightName);

_INT Cmdhdl_SetCamOsdDisplayInfMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iDisplayFlag,_INT iOSDType);

_INT Cmdhdl_SetCamCommonOsdInfMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOSDCommonPosition,_INT iOSDCommonFormat);

_INT Cmdhdl_SetImageRotateMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iRotateType);

_INT Cmdhdl_SetVideoEncParamMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iStreamId,ST_ZJ_VIDEO_PARAM *pstVparam);

_INT Cmdhdl_SetPreSetPointMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iSetCmd,_INT iPrePointId,_UC *pucName);

_INT Cmdhdl_SetAudioParamMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,ST_ZJ_AUDIO_PARAM *pstAudioParm);

_INT Cmdhdl_RSetIrWorkModeMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UI uiIrMode);

_INT Cmdhdl_SwitchDismantableAlarmMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOpenFlag);

_INT Cmdhdl_SetWaitAlarmMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOpenFlag);

_INT Cmdhdl_SetCamWdrMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOpenFlag);

_INT Cmdhdl_AddDevByAPMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucBindCode,_UC *pucGid,_UC *pucSSID,_UC *pucPassWd);

_INT Cmdhdl_SwitchCamLensMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iLenId);

_INT Cmdhdl_SetUpLoadLogFileMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucErrDes,_INT iErrType);

_INT Cmdhdl_GetSoundListMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iSoundType);

_INT Cmdhdl_DeleteSoundFileMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucFileName);

_INT Cmdhdl_PlaySoundFileMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucFileName);

_INT Cmdhdl_DownSoundFileMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucFileName, _UC *pucSoundUrl);

_INT Cmdhdl_SetAwakeRelayDevMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iValue);

_INT Cmdhdl_SetMicVolumeMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iValue);

_INT Cmdhdl_PlayAlarmAudioMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iLoopCnt, _UC *pucSoundName);

_INT Cmdhdl_SetFaceLableMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iMaxFaceCnt,
    _UC *pucFacelableId,_UC *pucLableName,_UC *puclableDes);

_INT Cmdhdl_CreatFaceLableMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iMaxCnt,_UC *pucLableName,_UC *pucFaceDec);

_VOID Cmdhdl_AddMsgSrcInfObject(_VPTR hRoot,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo);

_INT Cmdhdl_Task_SendCommonDevMsgRsp(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_INT iSeqId,_INT iStatus,ST_FROM_TO_MSG *pstMsgFromTo);

_INT Cmdhdl_SetCamSuperCodesMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOpenFlag);

_INT Cmdhdl_SetPtzEndMsg();

_INT Cmdhdl_CmdNotSupporMsg(_UC *pucPeerId, _UI uiSeqId, _UC ucMsgType, _UC ucMsgId, ST_FROM_TO_MSG *pstMsgFromTo);

_INT Cmdhdl_CloseSomethingBeforeReboot(_BOOL bCloseCmdServerFlag);

#ifdef __cplusplus
}
#endif

#endif
