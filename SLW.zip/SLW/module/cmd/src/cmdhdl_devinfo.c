#include "mos.h"
#include "zj_interface.h"
#include "config_type.h"
#include "config_api.h"
#include "cmdhdl_type.h"
#include "cmdhdl_api.h"
#include "http_api.h"
#include "adpt_json_adapt.h"
#include "cmdhdl_devinfo.h"
#include "record_api.h"
#include "rf_radio_api.h"
#include "snap_api.h"
#include "event_api.h"
#include "cloudstg_api.h"
#include "IoManage_api.h"
#include "kjiot_device_api.h"
#include "msgmng_api.h"
#include "cloudstg_api.h"
#include "cloudstg_logcode.h"
#include "msgmng_cmdserver.h"
#include "msgmng_multimedia.h"

// 信令处理的结构体数组
static ST_DEVMSG_HANDLER s_astDevMsgHandler[] =
{
      { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GET_TIMEANDZONE, (PFUN_DEVMSG_PROC)Cmdhdl_Task_GetTimeZone }
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SET_TIMEANDZONE, (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetTimeZone }
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETTFCRADINF,    (PFUN_DEVMSG_PROC)Cmdhdl_Task_GetSdcardInf }
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_FORMATTFCRAD,    (PFUN_DEVMSG_PROC)Cmdhdl_Task_FormatSdcard}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ,       (PFUN_DEVMSG_PROC)Cmdhdl_Task_PtzCtrl}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSD,          (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetOsdInfo}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSDDISPLAY,   (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetOsdDisplay}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSDCOMMONINF, (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetCommonOsdInf}

    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_FACTORYSETTING,  (PFUN_DEVMSG_PROC)Cmdhdl_Task_ClearDevCfg}
    
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_INVERSION,       (PFUN_DEVMSG_PROC)Cmdhdl_Task_CameRotate} 

    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_VENCODE_PARAM,   (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetCamEncParam}
    
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETPRESET,       (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetDevPresetPoint}

    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETAUDIOPARAM,   (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetCamAudioParam}

    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_PTZCHECK,        (PFUN_DEVMSG_PROC)Cmdhdl_Task_PtzSelfCheck}

    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_IRMODE,          (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetIRRedModeSwitch}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETWIFILIST,     (PFUN_DEVMSG_PROC)Cmdhdl_Task_GetWifiParm}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETCURNATINF,    (PFUN_DEVMSG_PROC)Cmdhdl_Task_GetCurNetInf}

    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_PLAYALARM,       (PFUN_DEVMSG_PROC)Cmdhdl_Task_PlayAlarmAudio}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETBELLFLAG,     (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetDismantableAlarmSwitch}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWAITALARM,    (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetStayAlarmSwitch}
    , { EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWDR,          (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetWideDynamicCamSwitch}
    
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_ADDDEVICEBYAP,    (PFUN_DEVMSG_PROC)Cmdhdl_Task_AddDeviceByAp}

    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SWITCHLEN,        (PFUN_DEVMSG_PROC)Cmdhdl_Task_SwitchLen}
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETBELLQUICKREPLY,(PFUN_DEVMSG_PROC)Cmdhdl_Task_Set_BellQuickReply}
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_CHANGEBELLSOUND,  (PFUN_DEVMSG_PROC)Cmdhdl_Task_Change_BellSound}
    
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_UPLOAD_LOGFILE,   (PFUN_DEVMSG_PROC)Cmdhdl_Task_UploadLogFile}

    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETSOUNDLIST,     (PFUN_DEVMSG_PROC)Cmdhdl_Task_GetSoundFiles}

    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_DELSOUNDFILE,     (PFUN_DEVMSG_PROC)Cmdhdl_Task_DelSoundFile}
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_PLAYSOUNDFILE,    (PFUN_DEVMSG_PROC)Cmdhdl_Task_PlaySoundFile}
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_DOWNSOUNDFILE,    (PFUN_DEVMSG_PROC)Cmdhdl_Task_DownSoundFile}
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_RELAYDEV_AWAKE,   (PFUN_DEVMSG_PROC)Cmdhdl_Task_AwakeRelayDev}
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETVOLUME,        (PFUN_DEVMSG_PROC)Cmdhdl_Task_SetVolume}
    , { EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SUPERCODES,       (PFUN_DEVMSG_PROC)Cmdhdl_Task_SuperCodesSwitch}
};

// 查找消息处理结构体数组的回调函数
static ST_DEVMSG_HANDLER *Cmdhdl_FindDevMsgHandle(_UC ucMsgType,_UC ucMsgId)
{
    _UI i = 0;
    _UI uiHandleCnt = sizeof(s_astDevMsgHandler)/sizeof(ST_DEVMSG_HANDLER);
    for(i = 0; i < uiHandleCnt;i++)
    {
        if(s_astDevMsgHandler[i].ucMsgType == ucMsgType && s_astDevMsgHandler[i].ucMsgId == ucMsgId)
        {
            return &s_astDevMsgHandler[i];
        }
    }
    return MOS_NULL;
}

// changed

/*
TODO: 
    1 add cmd id and type to table
    2 Cmd  rsp  need change
*/
// 处理消息队列内容
_INT Cmdhdl_ProcDevInfoMsg(_VPTR pstMsg)
{
    MOS_PARAM_NULL_RETERR(pstMsg);

    ST_CMDTASK_MSG *pstDevMsg = (ST_CMDTASK_MSG*)pstMsg;
    // 查找消息处理结构体数组的回调函数
    ST_DEVMSG_HANDLER *pstMsgProcNode = Cmdhdl_FindDevMsgHandle(pstDevMsg->ucMsgType,pstDevMsg->ucMsgId);

    if(pstMsgProcNode == MOS_NULL)
    {
        MOS_LOG_ERR(CMD_STRLOG,"can't find msgtype %u or msgid %u ",pstDevMsg->ucMsgType,pstDevMsg->ucMsgId);
        return MOS_ERR;
    }
    if(Config_GetCamaraMng()->uiCamOpenFlag == 0)
    {
        return MOS_OK;
    }

    // 回调消息队列对应任务的回调接口
    if(pstMsgProcNode->pfunMsgProc)
    {
        pstMsgProcNode->pfunMsgProc(pstDevMsg);
    }
    return MOS_OK;
}

_VOID Cmdhdl_AddMsgSrcInfObject(_VPTR hRoot,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_NORET(hRoot);
    MOS_PARAM_NULL_NORET(pstMsgFromTo);

    JSON_HANDLE hFromObject = MOS_NULL;
    JSON_HANDLE hToObject   = MOS_NULL;
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));
    if(MOS_STRLEN(pstMsgFromTo->aucDID) > 0)
    {
        hFromObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"FROM",hFromObject);
        Adpt_Json_AddItemToObject(hFromObject,(_UC*)"DID",Adpt_Json_CreateString(pstMsgFromTo->aucDID));
    }
    
    if(MOS_STRLEN(pstMsgFromTo->aucUserToken) > 0 || MOS_STRLEN(pstMsgFromTo->aucSvrID) > 0)
    {
        hToObject = Adpt_Json_CreateObject();
        if(MOS_STRLEN(pstMsgFromTo->aucUserToken) > 0)
        {
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"UserToken",Adpt_Json_CreateString(pstMsgFromTo->aucUserToken));
        }
        if(MOS_STRLEN(pstMsgFromTo->aucSvrID) > 0)
        {
            Adpt_Json_AddItemToObject(hToObject,(_UC*)"SvrID",Adpt_Json_CreateString(pstMsgFromTo->aucSvrID));
        }
        Adpt_Json_AddItemToObject(hRoot,(_UC*)"TO",hToObject);
    }
    return;
}

/*********************************************************************************
通用文件 回应消息 
 changed
**********************************************************************************/
_INT Cmdhdl_Task_SendCommonDevMsgRsp(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_INT iSeqId,_INT iStatus,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    _UC aucMethod[16];
    _UC *pucStrTmp = MOS_NULL;
    
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",ucMsgType,ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Cmdhdl_AddMsgSrcInfObject(hRoot,iSeqId,pstMsgFromTo); 
    pucStrTmp = Adpt_Json_Print(hRoot);
    MsgMng_SendMsg(pucPeerId,iSeqId,ucMsgType,ucMsgId,pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);

    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;
}

/*********************************************************************************
通用文件 回应消息 带Body
 changed
**********************************************************************************/
_INT Cmdhdl_Task_SendCommonDevMsgRspEx(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_INT iSeqId,_INT iStatus,ST_FROM_TO_MSG *pstMsgFromTo, JSON_HANDLE hBody)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    _UC aucMethod[16];
    _UC *pucStrTmp = MOS_NULL;
    
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",ucMsgType,ucMsgId);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Cmdhdl_AddMsgSrcInfObject(hRoot,iSeqId,pstMsgFromTo); 
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBody);
    pucStrTmp = Adpt_Json_Print(hRoot);
    
    MsgMng_SendMsg(pucPeerId,iSeqId,ucMsgType,ucMsgId,pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);

    Adpt_Json_Delete(hRoot);
    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;
}

/***********************************************************************************************
************************************************************************************************/
static _UC *Cmdhdl_BuildGetTimeZoneRsp(_UI uiSeqId,_INT iStatus,_INT iZone,_UC *pucTime,_UI uiSyncFlag,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETNULL(pucTime);
    MOS_PARAM_NULL_RETNULL(pstMsgFromTo);

    _UC aucMethod[64];
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBodyObject = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,pstMsgFromTo);

    hBodyObject = Adpt_Json_CreateObject();
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GET_TIMEANDZONE_RSP);
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"Zone",Adpt_Json_CreateStrWithNum(iZone));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"SyncFlag",Adpt_Json_CreateStrWithNum(uiSyncFlag));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"Time",Adpt_Json_CreateString(pucTime));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"DstArea",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDstArea));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBodyObject);

    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pucStrTmp;
}
// changed
_INT Cmdhdl_Task_GetTimeZone(ST_CMDTASK_MSG *pstCmdMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdMsg);

    _INT iStatus   = MOS_ERR;
    _INT iTimeZone = 0;
    _INT iSyncFlag = 0;
    _UC  *pucStrTmp = MOS_NULL;
    _UC  aucTimeStr[32] = {0};

    if(ZJ_GetFuncTable()->pfunGetTimeZone)
    {
        iStatus = ZJ_GetFuncTable()->pfunGetTimeZone(&iTimeZone,aucTimeStr,&iSyncFlag);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GET_TIMEANDZONE);
            MOS_SPRINTF(pucErrorString, "Device pfunGetTimeZone err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunGetTimeZone is NULL!");
        }
    }
    pucStrTmp = Cmdhdl_BuildGetTimeZoneRsp(pstCmdMsg->uiSeqId,iStatus,iTimeZone,aucTimeStr,iSyncFlag,&pstCmdMsg->stMsgFromTo);

    MsgMng_SendMsg(pstCmdMsg->aucPeerId,pstCmdMsg->uiSeqId,pstCmdMsg->ucMsgType,pstCmdMsg->ucMsgId + 1,
        pucStrTmp, MOS_STRLEN(pucStrTmp),MOS_NULL);
    
    MOS_LOG_INF(CMD_STRLOG,"reqid %u send rsp %s",pstCmdMsg->uiSeqId,pucStrTmp);
    
    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;
}

/*************************************************************************************
{"time":%s;"timezone":%d} isyncflag == 1 表示同步时区 
 changed
****************************************************************************************/
_INT Cmdhdl_Task_SetTimeZone(ST_CMDTASK_MSG *pstCmdMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdMsg);

    _INT iStatus             = MOS_ERR;
    _UC  pucUrl[64]          = {0};
    _UC  pucErrorString[128] = {0};
    ST_CMSTASK_SETTIMEZONE *pstSetTimeMsg = (ST_CMSTASK_SETTIMEZONE*)pstCmdMsg->aucMsgBody;

    if(pstSetTimeMsg->iUseDstFlag == 0)
    {
        if(ZJ_GetFuncTable()->pfunSetTimeZone)
        {
            iStatus = ZJ_GetFuncTable()->pfunSetTimeZone(pstSetTimeMsg->iSyncFlag,pstSetTimeMsg->iZone,pstSetTimeMsg->aucTimeStr,MOS_NULL);
            if (MOS_OK != iStatus)
            {
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SET_TIMEANDZONE);
                MOS_SPRINTF(pucErrorString, "Device pfunSetTimeZone(aucTimeStr:%s) err 11", pstSetTimeMsg->aucTimeStr);
                CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunSetTimeZone is NULL!");
        }
    }
    else if(pstSetTimeMsg->iUseDstFlag == 1 && 
        (MOS_STRLEN(Config_GetDeviceMng()->aucDst) == 0 || MOS_STRCMP(Config_GetDeviceMng()->aucDstArea,pstSetTimeMsg->aucArea) != 0))
    {
        //本地夏令时为空或者城市发生变化，需要去服务器查询夏令时
        Config_SetLocalAreaDst((_UC*)"");
    }
    else
    {
        if(ZJ_GetFuncTable()->pfunSetTimeZone)
        {
            iStatus = ZJ_GetFuncTable()->pfunSetTimeZone(pstSetTimeMsg->iSyncFlag,pstSetTimeMsg->iZone,pstSetTimeMsg->aucTimeStr,Config_GetDeviceMng()->aucDst);
            if (MOS_OK != iStatus)
            {
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SET_TIMEANDZONE);
                MOS_SPRINTF(pucErrorString, "Device pfunSetTimeZone(aucTimeStr:%s) err", pstSetTimeMsg->aucTimeStr);
                CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunSetTimeZone is NULL!");
        }
    }

    if (MOS_OK == iStatus)
    {
        Config_SetLocalTimeZone(pstSetTimeMsg->iZone);
        Config_SetAreaInfo(pstSetTimeMsg->iUseDstFlag, pstSetTimeMsg->aucArea);
    }
    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdMsg->aucPeerId,pstCmdMsg->ucMsgType,pstCmdMsg->ucMsgId + 1,pstCmdMsg->uiSeqId,iStatus,&pstCmdMsg->stMsgFromTo);
}

/*********************************************************************************************
获取SD卡 信息
 changed
**********************************************************************************************/
static _UC *Cmdhdl_BuildGetTfCardInfoRsp(_UI uiSeqId,_INT iStatus,_UI uiTotalsize, _UI uiFreeSize,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETNULL(pstMsgFromTo);

    _UC aucMethod[64];
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBodyObject = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETTFCRADINF_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,pstMsgFromTo);
    
    hBodyObject = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"StorageAbility",Adpt_Json_CreateStrWithNum(Config_GetCamaraMng()->uiStorageAbility));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"TotalSize",Adpt_Json_CreateStrWithNum(uiTotalsize));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"FreeSize",Adpt_Json_CreateStrWithNum(uiFreeSize));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"CardStatus",Adpt_Json_CreateStrWithNum(iStatus));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBodyObject);
    
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pucStrTmp;
}


//0 正常 、1 卡不可用、 2 无卡、 3格式化中  EN_ZJ_SDCARD_STATUS
_INT Cmdhdl_Task_GetSdcardInf(ST_CMDTASK_MSG *pstCmdMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdMsg);

    _INT iStatus     = MOS_ERR;
    _UI  uiTotalsize = 0;
    _UI  uiFreeSize  = 0;
    _UC  *pstrTmp    = MOS_NULL;
    
    if(Cmdhdl_GetTaskMng()->uiFormatFlag == 0)
    {
        if(ZJ_GetFuncTable()->pfunGetSDCardInfo)
        {
            iStatus = ZJ_GetFuncTable()->pfunGetSDCardInfo(&uiTotalsize,&uiFreeSize);
            if (MOS_OK != iStatus)
            {
                _UC  pucUrl[64]          = {0};
                _UC  pucErrorString[128] = {0};
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETTFCRADINF);
                MOS_SPRINTF(pucErrorString, "Device pfunGetSDCardInfo err");
                CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunGetSDCardInfo is NULL!");
        }
    }
    else if(Config_GetCamaraMng()->uiStorageStatus == 0)
    {
        iStatus = EN_ZJ_SDCARD_NOCARD;
    }
    else
    {
        iStatus = EN_ZJ_SDCARD_FORMATING;
    }
    pstrTmp = Cmdhdl_BuildGetTfCardInfoRsp(pstCmdMsg->uiSeqId,iStatus,uiTotalsize,uiFreeSize,&pstCmdMsg->stMsgFromTo);

    MsgMng_SendMsg(pstCmdMsg->aucPeerId,pstCmdMsg->uiSeqId,pstCmdMsg->ucMsgType,pstCmdMsg->ucMsgId + 1,
        pstrTmp,MOS_STRLEN(pstrTmp),MOS_NULL);

    MOS_LOG_INF(CMD_STRLOG,"reqid %u send get TF inf rsp %s",pstCmdMsg->uiSeqId,pstrTmp);
    
    Adpt_Json_DePrint(pstrTmp);
    
    return MOS_OK;
}

/*****************************************************************************************
格式化SD卡
******************************************************************************************/
_INT Cmdhdl_Task_FormatSdcard(ST_CMDTASK_MSG *pstCmdMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdMsg);

    _INT iRet = 0;
    _UI uiLogSize = 0,uiLogNum = 0;
    _INT iStatus = MOS_OK;
    if(Cmdhdl_GetTaskMng()->uiFormatFlag == 1)
    {
        return MOS_OK;
    }

    Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdMsg->aucPeerId,pstCmdMsg->ucMsgType,pstCmdMsg->ucMsgId + 1,
            pstCmdMsg->uiSeqId,iStatus,&pstCmdMsg->stMsgFromTo);

    // 关闭MP4录像
    ZJ_SetStoragePath(NULL);

    MOS_LOG_INF(CMD_STRLOG,"SDCard Format Start");
    Cmdhdl_GetTaskMng()->uiFormatFlag = 1;
    CloudStg_FormatSDCard();
    IoMng_SetPath(MOS_NULL);
    
    iRet = Mos_SetGetLogSize(&uiLogSize, &uiLogNum, 0);
    if (iRet == MOS_OK && uiLogSize > 0 && uiLogNum > 0)
    {
        Mos_SetLogPath(Mos_GetWorkPath(),uiLogSize,uiLogNum);
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG, "set log size fail");
        uiLogSize = MOS_LOG_MAX_FILE_SIZE;
        uiLogNum = MOS_LOG_MAX_FILE_NUM;
        Mos_SetGetLogSize(&uiLogSize, &uiLogNum, 1);
        // return MOS_ERR;
    }
    
    Mos_Sleep(100);
    if(ZJ_GetFuncTable()->pfunFormatSDCard)
    {
        iStatus = ZJ_GetFuncTable()->pfunFormatSDCard();
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_FORMATTFCRAD);
            MOS_SPRINTF(pucErrorString, "Device pfunFormatSDCard err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunFormatSDCard is NULL!");
    }

    if(MOS_STRLEN(Config_GetCoreMng()->aucCachePath) > 0)
    {
        Mos_SetLogPath(Config_GetCoreMng()->aucCachePath,MOS_LOG_SDCARD_MAX_FILE_SIZE,MOS_LOG_SDCARD_MAX_FILE_NUM);
    }
    IoMng_SetPath(Config_GetCoreMng()->aucCachePath);

    Cmdhdl_GetTaskMng()->uiFormatFlag = 0;
    MOS_LOG_INF(CMD_STRLOG,"SDCard Format Stop");
    
    return MOS_OK;
}

/******************************************************************************************************
PTZ执行指令
 changed
******************************************************************************************************/
_INT Cmdhdl_Task_PtzCtrl(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus             = MOS_ERR;
    _UC  pucUrl[64]          = {0};
    _UC  pucErrorString[128] = {0};
    ST_CFG_PRESET_POINT stPreSetPoint = {0};
    ST_CFG_CRUISE_NODE *pstCruiseNode = MOS_NULL;
    ST_CMSTASK_PTZOPT *pstCmdPtzOpt = (ST_CMSTASK_PTZOPT*)pstCmdTaskMsg->aucMsgBody;
    
    if(pstCmdPtzOpt->iPtzCtrlType == EN_PTZ_CONTROL_MOVE)
    {
        // 兼容处理，PTZ操作和变焦变倍 pfunOnPTZEx
        if(ZJ_GetFuncTable()->pfunOnPTZEx)
        {
            if (pstCmdPtzOpt->u.stOnPtzInf.iPTZControl == EN_ZJ_CAMERA_PTZ_CONTROL_STOP)
            {
                if(ZJ_GetFuncTable()->pfunPtzStop)
                {
                    iStatus = ZJ_GetFuncTable()->pfunPtzStop();
                    if (MOS_OK != iStatus)
                    {
                        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ);
                        MOS_SPRINTF(pucErrorString, "Device pfunPtzStop err");
                        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
                    }
                }
                else
                {
                    MOS_LOG_ERR(CMD_STRLOG,"pfunPtzStop is NULL!");
                }
            }
            else
            {
                iStatus = ZJ_GetFuncTable()->pfunOnPTZEx(pstCmdPtzOpt->u.stOnPtzInf.iPTZControl,pstCmdPtzOpt->u.stOnPtzInf.iSpeed,pstCmdPtzOpt->u.stOnPtzInf.iStep,
                pstCmdPtzOpt->u.stOnPtzInf.iZoom,pstCmdPtzOpt->u.stOnPtzInf.iFocus);
                if (MOS_OK != iStatus)
                {
                    MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ);
                    MOS_SPRINTF(pucErrorString, "Device pfunOnPTZEx(iPTZControl:%d, iSpeed:%d, iStep:%d, iZoom:%d, iFocus:%d) err",
                                pstCmdPtzOpt->u.stOnPtzInf.iPTZControl,pstCmdPtzOpt->u.stOnPtzInf.iSpeed,pstCmdPtzOpt->u.stOnPtzInf.iStep,
                                pstCmdPtzOpt->u.stOnPtzInf.iZoom,pstCmdPtzOpt->u.stOnPtzInf.iFocus);
                    CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
                }
            }
        }
        else if(ZJ_GetFuncTable()->pfunOnPTZ)
        {
            if (pstCmdPtzOpt->u.stOnPtzInf.iPTZControl == EN_ZJ_CAMERA_PTZ_CONTROL_STOP)
            {
                if(ZJ_GetFuncTable()->pfunPtzStop)
                {
                    iStatus = ZJ_GetFuncTable()->pfunPtzStop();
                    if (MOS_OK != iStatus)
                    {
                        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ);
                        MOS_SPRINTF(pucErrorString, "Device pfunPtzStop err");
                        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
                    }
                }
                else
                {
                    MOS_LOG_ERR(CMD_STRLOG,"pfunPtzStop is NULL!");
                }
            }
            else
            {
                iStatus = ZJ_GetFuncTable()->pfunOnPTZ(pstCmdPtzOpt->u.stOnPtzInf.iPTZControl,pstCmdPtzOpt->u.stOnPtzInf.iSpeed,pstCmdPtzOpt->u.stOnPtzInf.iStep);
                if (MOS_OK != iStatus)
                {
                    MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ);
                    MOS_SPRINTF(pucErrorString, "Device pfunOnPTZ(iPTZControl:%d, iSpeed:%d, iStep:%d) err",
                                pstCmdPtzOpt->u.stOnPtzInf.iPTZControl,pstCmdPtzOpt->u.stOnPtzInf.iSpeed,pstCmdPtzOpt->u.stOnPtzInf.iStep);
                    CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
                }
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunOnPTZ and pfunOnPTZEx is NULL!");
        }
    }
    else if(pstCmdPtzOpt->iPtzCtrlType == EN_PTZ_CONTROL_GOTO_PRESET_POINT)
    {
        if(Config_FindPresetPointById(0,pstCmdPtzOpt->u.uiPreSetId,&stPreSetPoint) == MOS_ERR)
        {
            iStatus = MOS_ERR;
            MOS_LOG_ERR(CMD_STRLOG,"reqid %u Can't Find PreSetPoint!",pstCmdTaskMsg->uiSeqId);
        }
        else if(ZJ_GetFuncTable()->pfunPTZGotoPoint)
        {
            iStatus = ZJ_GetFuncTable()->pfunPTZGotoPoint(stPreSetPoint.iX,stPreSetPoint.iY);
            if (MOS_OK != iStatus)
            {
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ);
                MOS_SPRINTF(pucErrorString, "Device pfunPTZGotoPoint(X:%d, Y:%d) err", stPreSetPoint.iX, stPreSetPoint.iY);
                CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
            }
        }
        else if(ZJ_GetFuncTable()->pfunPTZGotoPoint == MOS_NULL)
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunPTZGotoPoint is NULL!");
        }
    }
    else if(pstCmdPtzOpt->iPtzCtrlType == EN_PTZ_CONTROL_POSITION_CRUISE)
    {
        pstCruiseNode = Config_FindCuriseNode(0,pstCmdPtzOpt->u.uiCruiseId);
        if(pstCruiseNode == MOS_NULL)
        {
            iStatus = MOS_ERR;
            MOS_LOG_ERR(CMD_STRLOG,"reqid %u Can't Find CuriseNode!",pstCmdTaskMsg->uiSeqId);
        }
        else
        {
            _INT iUseCnt = 0;
            _INT iCruiseCnt = MOS_LIST_GETCOUNT(&pstCruiseNode->stPointList);
            ST_MOS_LIST_ITERATOR stIterator;
            ST_CFG_CRUISE_POINT_NODE *pstPointNode = 0;
            ST_ZJ_CAMERA_CRUISE_PRESET *pstCruisePoint = (ST_ZJ_CAMERA_CRUISE_PRESET*)MOS_MALLOCCLR((iCruiseCnt + 1) * sizeof(ST_ZJ_CAMERA_CRUISE_PRESET));

            FOR_EACHDATA_INLIST(&pstCruiseNode->stPointList, pstPointNode, stIterator)
            {
                if(pstPointNode->uiUseFlag == 0)
                {
                    continue;
                }
                if(Config_FindPresetPointById(0,pstPointNode->uiPresetId,&stPreSetPoint) == MOS_ERR)
                {
                    continue;
                }
                pstCruisePoint[iUseCnt].iDwellTime = pstPointNode->uiDwellTime;
                pstCruisePoint[iUseCnt].iSpeed     = pstPointNode->uiSpeed;
                pstCruisePoint[iUseCnt].Idx        = pstPointNode->uiIndex;
                pstCruisePoint[iUseCnt].iX         = stPreSetPoint.iX;
                pstCruisePoint[iUseCnt].iY         = stPreSetPoint.iY;
                iUseCnt++;
            }
            if(ZJ_GetFuncTable()->pfunCruiseStart && iUseCnt > 0)
            {
                iStatus = ZJ_GetFuncTable()->pfunCruiseStart(iUseCnt,pstCruisePoint);
                if (MOS_OK != iStatus)
                {
                    MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ);
                    MOS_SPRINTF(pucErrorString, "Device pfunCruiseStart(iUseCnt:%d) err", iUseCnt);
                    CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
                }
            }
            else
            {
                MOS_LOG_ERR(CMD_STRLOG,"pfunCruiseStart is NULL!");
            }
            MOS_FREE(pstCruisePoint);
        }
    }
    else if(pstCmdPtzOpt->iPtzCtrlType == EN_PTZ_CONTROL_STOP)
    {
        if(ZJ_GetFuncTable()->pfunPtzStop)
        {
            iStatus = ZJ_GetFuncTable()->pfunPtzStop();
            if (MOS_OK != iStatus)
            {
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ);
                MOS_SPRINTF(pucErrorString, "Device pfunPtzStop err");
                CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunPtzStop is NULL!");
        }
    }
    else if(pstCmdPtzOpt->iPtzCtrlType == EN_PTZ_CONTROL_PRESET_POINT_ALARM)
    {
        /**
         * 移动至预置位，并上报1022事件到平台
        */
        if(Config_FindPresetPointById(0,pstCmdPtzOpt->u.uiPreSetId,&stPreSetPoint) == MOS_ERR)
        {
            iStatus = MOS_ERR;
            MOS_LOG_ERR(CMD_STRLOG,"reqid %u Can't Find PreSetPoint!",pstCmdTaskMsg->uiSeqId);
        }
        else 
        {
            if(ZJ_GetFuncTable()->pfunPTZGotoPoint)
            {
                iStatus = ZJ_GetFuncTable()->pfunPTZGotoPoint(stPreSetPoint.iX,stPreSetPoint.iY);
                if (MOS_OK != iStatus)
                {
                    MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_CONTRLPTZ);
                    MOS_SPRINTF(pucErrorString, "Device pfunPTZGotoPoint(X:%d, Y:%d) err", stPreSetPoint.iX, stPreSetPoint.iY);
                    CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
                }
                KjIOT_AddPtzEventNode(); /*触发设备联动消息*/
            }
            else
            {
                iStatus = MOS_ERR;
                MOS_LOG_ERR(CMD_STRLOG,"pfunPTZGotoPoint is NULL!");
            }
        }
    }
    else if(pstCmdPtzOpt->iPtzCtrlType == EN_PTZ_CONTROL_PANORAMIC_CRUISE)
    {

    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,pstCmdTaskMsg->ucMsgId + 1,
            pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

/*******************************************************************************************
自定义(文本)水印(位置，文本)设置
********************************************************************************************/
_INT Cmdhdl_Task_SetOsdInfo(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus            = MOS_ERR;
    _INT uiDisplayFlag      = 0;
    _UC aucUrl[64]          = {0};
    _UC aucErrorString[128] = {0};    
    _UC aucOsdTemp[CFG_STRING_BIGMAXLEN] = {0};
    ST_CMDTASK_CAMOSD *pstOsdMsg = (ST_CMDTASK_CAMOSD *)pstCmdTaskMsg->aucMsgBody;

    MOS_SPRINTF(aucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSD);

    if (pstOsdMsg->iOSDMode == 0)
    {
        ST_OSD_CONTENT *pstOSDContent = &(pstOsdMsg->uniOSDContent.stContent);

        MOS_STRNCPY(aucOsdTemp, pstOSDContent->aucName, sizeof(aucOsdTemp)-1);
        aucOsdTemp[sizeof(aucOsdTemp)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
        
        if (ZJ_GetFuncTable()->pfunCustomOSDModeSetting)
        {
            ZJ_GetFuncTable()->pfunCustomOSDModeSetting(0);
        }

        if(ZJ_GetFuncTable()->pfunOSDSetting)
        {
            iStatus = ZJ_GetFuncTable()->pfunOSDSetting(pstOSDContent->iPostion,(char*)aucOsdTemp);
            if (MOS_OK != iStatus)
            {
                MOS_SPRINTF(aucErrorString, "Device pfunOSDSetting(iPostion:%d, aucName:%s) return err", 
                                                    pstOSDContent->iPostion,(char*)pstOSDContent->aucName);
                CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, iStatus, aucErrorString, 1);
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunOSDSetting is NULL!");
        }

        if (MOS_OK == iStatus)
        {
            // FIXME
            if (MOS_STRLEN((char*)pstOSDContent->aucName) == 0)
            {
                uiDisplayFlag = 0;
            }
            else
            {
                uiDisplayFlag = 1;
            }
            Config_SetCamerCurOSDInfo(0, uiDisplayFlag, pstOSDContent->iPostion, (char*)pstOSDContent->aucName);
            if(ZJ_GetFuncTable()->pFunCtrlCustomOsd)
            {
                ZJ_GetFuncTable()->pFunCtrlCustomOsd(uiDisplayFlag);
            }
        }
    }
    else
    {
        _INT uiPostion = 0;
        _UC  ucSetTopLeftFlag    = 0;
        _UC  ucSetLowerLeftFlag  = 0;
        _UC  ucSetTopRightFlag   = 0;
        _UC  ucSetLowerRightFlag = 0;
        _INT uiOSDSettingErrorFlag = 0; //记录osd错误标识
        ST_OSD_CONTENT_EX *pstOSDContentEx = &(pstOsdMsg->uniOSDContent.stContentEx);

        if (pstOSDContentEx->ucHasTopLeft || pstOSDContentEx->ucHasLowerLeft || 
            pstOSDContentEx->ucHasTopRight || pstOSDContentEx->ucHasLowerRight)
        {
            if (ZJ_GetFuncTable()->pfunCustomOSDModeSetting)
            {
                ZJ_GetFuncTable()->pfunCustomOSDModeSetting(1);
            }
            else
            {
                MOS_LOG_ERR(CMD_STRLOG,"pfunCustomOSDModeSetting is NULL!");
            }

            if(ZJ_GetFuncTable()->pfunOSDSetting)
            {
                if (pstOSDContentEx->ucHasTopLeft)
                {
                    uiPostion        = EN_ZJ_OSD_POSITION_LT;
                    ucSetTopLeftFlag = 1;
                    MOS_STRNCPY(aucOsdTemp, pstOSDContentEx->aucTopLeftName, sizeof(aucOsdTemp)-1);
                    aucOsdTemp[sizeof(aucOsdTemp)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
                    iStatus = ZJ_GetFuncTable()->pfunOSDSetting(uiPostion,(char*)aucOsdTemp);
                    if (MOS_OK != iStatus)
                    {
                        uiOSDSettingErrorFlag |= (1>>uiPostion);
                        MOS_SPRINTF(aucErrorString, "Device OSDExpand pfunOSDSetting(iPostion:%d, aucName:%s) return err", 
                                                            uiPostion,(char*)aucOsdTemp);
                        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, iStatus, aucErrorString, 1);
                    }
                    else if (MOS_STRLEN((char*)aucOsdTemp) != 0)
                    {
                        uiDisplayFlag = 1;
                    }
                }
                if (pstOSDContentEx->ucHasLowerLeft)
                {
                    uiPostion          = EN_ZJ_OSD_POSITION_LD;
                    ucSetLowerLeftFlag = 1;
                    MOS_STRNCPY(aucOsdTemp, pstOSDContentEx->aucLowerLeftName, sizeof(aucOsdTemp)-1);
                    aucOsdTemp[sizeof(aucOsdTemp)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
                    iStatus = ZJ_GetFuncTable()->pfunOSDSetting(uiPostion,(char*)aucOsdTemp);
                    if (MOS_OK != iStatus)
                    {
                        uiOSDSettingErrorFlag |= (1>>uiPostion);
                        MOS_SPRINTF(aucErrorString, "Device OSDExpand pfunOSDSetting(iPostion:%d, aucName:%s) return err", 
                                                            uiPostion,(char*)aucOsdTemp);
                        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, iStatus, aucErrorString, 1);
                    } 
                    else if (MOS_STRLEN((char*)aucOsdTemp) != 0)
                    {
                        uiDisplayFlag = 1;
                    }                             
                }                
                if (pstOSDContentEx->ucHasTopRight)
                {
                    uiPostion         = EN_ZJ_OSD_POSITION_RT;
                    ucSetTopRightFlag = 1;
                    MOS_STRNCPY(aucOsdTemp, pstOSDContentEx->aucTopRightName, sizeof(aucOsdTemp)-1);
                    aucOsdTemp[sizeof(aucOsdTemp)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
                    iStatus = ZJ_GetFuncTable()->pfunOSDSetting(uiPostion,(char*)aucOsdTemp);
                    if (MOS_OK != iStatus)
                    {
                        uiOSDSettingErrorFlag |= (1>>uiPostion);
                        MOS_SPRINTF(aucErrorString, "Device OSDExpand pfunOSDSetting(iPostion:%d, aucName:%s) return err", 
                                                            uiPostion,(char*)aucOsdTemp);
                        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, iStatus, aucErrorString, 1);
                    }  
                    else if (MOS_STRLEN((char*)aucOsdTemp) != 0)
                    {
                        uiDisplayFlag = 1;
                    }                            
                }
                if (pstOSDContentEx->ucHasLowerRight)
                {
                    uiPostion           = EN_ZJ_OSD_POSITION_RD;
                    ucSetLowerRightFlag = 1;
                    MOS_STRNCPY(aucOsdTemp, pstOSDContentEx->aucLowerRightName, sizeof(aucOsdTemp)-1);
                    aucOsdTemp[sizeof(aucOsdTemp)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
                    iStatus = ZJ_GetFuncTable()->pfunOSDSetting(uiPostion,(char*)aucOsdTemp);
                    if (MOS_OK != iStatus)
                    {
                        uiOSDSettingErrorFlag |= (1>>uiPostion);
                        MOS_SPRINTF(aucErrorString, "Device OSDExpand pfunOSDSetting(iPostion:%d, aucName:%s) return err", 
                                                            uiPostion,(char*)aucOsdTemp);
                        CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, iStatus, aucErrorString, 1);
                    }
                    else if (MOS_STRLEN((char*)aucOsdTemp) != 0)
                    {
                        uiDisplayFlag = 1;
                    }
                }
            }
            else
            {
                MOS_LOG_ERR(CMD_STRLOG,"pfunOSDSetting is NULL!");
            }

            MOS_LOG_INF(CMD_STRLOG,"TLFlag %d LLFlag %d TRFlag %d LRFlag %d ErrFlag 0x%X", 
                        ucSetTopLeftFlag, ucSetLowerLeftFlag, ucSetTopRightFlag, ucSetLowerRightFlag, uiOSDSettingErrorFlag);

            // 其中之一有效就认为成功
            if (ucSetTopLeftFlag || ucSetLowerLeftFlag || ucSetTopRightFlag || ucSetLowerRightFlag)
            {
                Config_SetCamerCurOSDInfoEx(0, uiDisplayFlag, ucSetTopLeftFlag?pstOSDContentEx->aucTopLeftName:MOS_NULL,
                                                            ucSetLowerLeftFlag?pstOSDContentEx->aucLowerLeftName:MOS_NULL,
                                                            ucSetTopRightFlag?pstOSDContentEx->aucTopRightName:MOS_NULL,
                                                            ucSetLowerRightFlag?pstOSDContentEx->aucLowerRightName:MOS_NULL);
                if(ZJ_GetFuncTable()->pFunCtrlCustomOsd)
                {
                    ZJ_GetFuncTable()->pFunCtrlCustomOsd(uiDisplayFlag);
                }
            }
        }
        else
        {
            iStatus = MOS_ERR;
            MOS_SPRINTF(aucErrorString, "Device OSDExpand ContentEx All NULL return err");
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, iStatus, aucErrorString, 1);
        }
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

/*******************************************************************************************
自定义(文本)/默认(时间)水印显示开关设置
********************************************************************************************/
_INT Cmdhdl_Task_SetOsdDisplay(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus             = MOS_ERR;
    _UC  pucUrl[64]          = {0};
    _UC  pucErrorString[128] = {0};
    ST_CMDTASK_CAMOSD *pstOsdMsg = (ST_CMDTASK_CAMOSD *)pstCmdTaskMsg->aucMsgBody;

    // 默认(时间)水印
    if (pstOsdMsg->iOSDType == 0) 
    {
        if(ZJ_GetFuncTable()->pFunCtrlTimeOsd)
        {
            iStatus = ZJ_GetFuncTable()->pFunCtrlTimeOsd(pstOsdMsg->iDisplayFlag);
            if (MOS_OK != iStatus)
            {
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSDDISPLAY);
                MOS_SPRINTF(pucErrorString, "Device pFunCtrlTimeOsd(iDisplayFlag:%d) return err", pstOsdMsg->iDisplayFlag);
                CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
            }
            if (MOS_OK == iStatus)
            {
                // FIXME
                Config_SetCamerCurTimeOSDDisplay(0, pstOsdMsg->iDisplayFlag);
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pFunCtrlTimeOsd is NULL!");
        }
    } 
    // 自定义(文本)水印
    else if (pstOsdMsg->iOSDType == 1)
    {
        if(ZJ_GetFuncTable()->pFunCtrlCustomOsd)
        {
            iStatus = ZJ_GetFuncTable()->pFunCtrlCustomOsd(pstOsdMsg->iDisplayFlag);
            if (MOS_OK != iStatus)
            {
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSDDISPLAY);
                MOS_SPRINTF(pucErrorString, "Device pFunCtrlCustomOsd(iDisplayFlag:%d) return err", pstOsdMsg->iDisplayFlag);
                CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
            }
            if (MOS_OK == iStatus)
            {
                // FIXME
                Config_SetCamerCurCustomOSDDisplay(0, pstOsdMsg->iDisplayFlag);
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pFunCtrlCustomOsd is NULL!");
        }
    } 
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"iOSDType %d err", pstOsdMsg->iOSDType);
        iStatus = -1;
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}


/*******************************************************************************************
默认(时间)水印(位置，格式)设置
********************************************************************************************/
_INT Cmdhdl_Task_SetCommonOsdInf(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus  = MOS_ERR;
    _UC  pucUrl[64]          = {0};
    _UC  pucErrorString[128] = {0};
    ST_CMDTASK_CAMOSD *pstOsdMsg = (ST_CMDTASK_CAMOSD *)pstCmdTaskMsg->aucMsgBody;

    // 默认(时间)水印(位置，格式)设置
    if(ZJ_GetFuncTable()->pFunOSDCommonSetting)
    {
        iStatus = ZJ_GetFuncTable()->pFunOSDCommonSetting(pstOsdMsg->iOSDCommonPosition, pstOsdMsg->iOSDCommonFormat);
        if (MOS_OK != iStatus)
        {
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETOSDCOMMONINF);
            MOS_SPRINTF(pucErrorString, "Device pFunOSDCommonSetting(iOSDCommonPosition:%d, iOSDCommonFormat:%d) return err",
                                            pstOsdMsg->iOSDCommonPosition, pstOsdMsg->iOSDCommonFormat);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
        if (MOS_OK == iStatus)
        {
            // FIXME
            Config_SetCamerCurOSDCommonInfo(0, pstOsdMsg->iOSDCommonPosition, pstOsdMsg->iOSDCommonFormat);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pFunOSDCommonSetting is NULL!");
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

/*******************************************************************************************
恢复出厂设置
 doing
********************************************************************************************/
_INT Cmdhdl_Task_ClearDevCfg(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus  = MOS_ERR;

    // 关闭MP4、Commit云存任务、即将关闭信令服务器，流媒体连接
    MsgMng_GetCmdServer()->uiForceCloseCmdFlag = 1;
    Cmdhdl_CloseSomethingBeforeReboot(MOS_FALSE);
    MsgMng_MultiMediaCloseAllConnect();
    if(ZJ_GetFuncTable()->pfunRestoreFactorySetting)
    {
        iStatus = ZJ_GetFuncTable()->pfunRestoreFactorySetting();
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_FACTORYSETTING);
            MOS_SPRINTF(pucErrorString, "Device pfunRestoreFactorySetting return err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunRestoreFactorySetting is NULL!");
    }

    CloudStg_InitChargeInfo();
    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

#if 0
/*******************************************************************************************
关闭设备
old code
********************************************************************************************/
_INT Cmdhdl_Task_CloseDevice_old(_UC *pucPeerId, _UC ucNeedEncFlag,_INT iSeqId,_VPTR hBodyObject)
{
    _INT iDevOptType = 0;
    _INT iActionType  = 0;
    _INT iStatus      = 0;
    JSON_HANDLE hPolicy = MOS_NULL;
    ST_CFG_SCHEDULE stSchedule;
    if(hBodyObject == MOS_NULL)
    {
        MOS_LOG_ERR(CMD_STRLOG,"json handler is null");
        return MOS_ERR;
    }
    
    MOS_MEMSET(&stSchedule,0,sizeof(stSchedule));
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBodyObject,(_UC*)"Status"),&iDevOptType);

    hPolicy = Adpt_Json_GetObjectItem(hBodyObject,(_UC*)"ActionPolicy");
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPolicy,"Week"),&stSchedule.uiWeekFlag);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPolicy,"StartTime"),&stSchedule.uiStartTime);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPolicy,"EndTime"),&stSchedule.uiStopTime);
    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hPolicy,"PolicyID"),&stSchedule.uiPolicyId);
    stSchedule.uiEnalbe = 1;
    Config_SetDevTimerTask(iDevOptType,&stSchedule);
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,ucNeedEncFlag,EN_OGCT_DEVINFO_DEVCLOSE_RSP,iSeqId,iStatus);
}
#endif

/************************************************************************************
摄像头翻转(图像倒置设置)
 changed
*************************************************************************************/
_INT Cmdhdl_Task_CameRotate(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus     = MOS_ERR;
    ST_CMDTASK_COMVALUE *pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    if(ZJ_GetFuncTable()->pfunImageInversion)
    {
        iStatus = ZJ_GetFuncTable()->pfunImageInversion(pstComValue->iValue);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_INVERSION);
            MOS_SPRINTF(pucErrorString, "Device pfunImageInversion(iValue:%d) return err", pstComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunImageInversion is NULL!");
    }

    if (MOS_OK == iStatus)
    {
        Config_SetCamerCurInversionType(0,pstComValue->iValue);
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

/************************************************************************************
设置摄像头编码参数
 changed
*************************************************************************************/
_INT Cmdhdl_Task_SetCamEncParam(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    ST_CMDTASK_VIDEOPROP *pstVideoProp = (ST_CMDTASK_VIDEOPROP*)pstCmdTaskMsg->aucMsgBody;

    if(ZJ_GetFuncTable()->pfunSetVideoParm)
    {
        iStatus = ZJ_GetFuncTable()->pfunSetVideoParm(pstVideoProp->iStreamId,&pstVideoProp->stVideoParam);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_VENCODE_PARAM);
            MOS_SPRINTF(pucErrorString, "Device pfunSetVideoParm(iStreamId:%d, Resolution:%d) return err", pstVideoProp->iStreamId), pstVideoProp->stVideoParam.uiResolution;
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunSetVideoParm is NULL!");
    }

    if (MOS_OK == iStatus)
    {
        // FIXME
        Config_SetCameraStreamParam(0, pstVideoProp->iStreamId, &pstVideoProp->stVideoParam);
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

/****************************************************************************************
设置预置位用到的RSP函数
 changed
****************************************************************************************/
static _UC *Cmdhdl_BuildSetPresetRsp(_INT iPointx,_INT iPointy,_UC *pucPicId,_UI uiSeqId,_INT iStatus,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETNULL(pstMsgFromTo);

    _UC aucMethod[64];
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBodyObject = MOS_NULL;
    JSON_HANDLE hPoint      = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_SETPRESET_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,pstMsgFromTo);

    hBodyObject = Adpt_Json_CreateObject();

    hPoint = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hPoint,(_UC*)"X",Adpt_Json_CreateStrWithNum(iPointx));
    Adpt_Json_AddItemToObject(hPoint,(_UC*)"Y",Adpt_Json_CreateStrWithNum(iPointy));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"Point",hPoint);

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBodyObject);
    
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    
    return pucStrTmp;
}


/****************************************************************************************
编辑预置位
 changed
****************************************************************************************/
_INT Cmdhdl_Task_SetDevPresetPoint(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus    = MOS_ERR;
    _UC *pStrTmp    = MOS_NULL;
    ST_CFG_PRESET_POINT stPtzPoint = {0};
    ST_CMDTASK_PRESETPOINT *pstPresetMsg = (ST_CMDTASK_PRESETPOINT*)pstCmdTaskMsg->aucMsgBody;

    //通过回调获取当前cam所在位置；
    if(pstPresetMsg->iSetCmd == 1)
    {
        if(ZJ_GetFuncTable()->pfunPTZGetPoint)
        {
            iStatus = ZJ_GetFuncTable()->pfunPTZGetPoint(&stPtzPoint.iX,&stPtzPoint.iY);
            if (MOS_OK != iStatus)
            {
                _UC  pucUrl[64]          = {0};
                _UC  pucErrorString[128] = {0};
                MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETPRESET);
                MOS_SPRINTF(pucErrorString, "Device pfunPTZGetPoint err");
                CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
            }
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfunPTZGetPoint is NULL!");
        }

        if (MOS_OK == iStatus)
        {
            Config_AddPresetPoint(0,pstPresetMsg->iPreSetId,pstPresetMsg->aucName,&stPtzPoint);
        }
    }
    else if(pstPresetMsg->iSetCmd == 2)
    {
        iStatus = Config_DelPresetPointById(0,pstPresetMsg->iPreSetId);
    }
    else if(pstPresetMsg->iSetCmd == 3)
    {
        iStatus = Config_DelAllPresetPoints();
    }

    pStrTmp = Cmdhdl_BuildSetPresetRsp(stPtzPoint.iX,stPtzPoint.iY,MOS_NULL,
        pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);

    MOS_LOG_INF(CMD_STRLOG,"reqid %u send setPresetPoint rsp %s",pstCmdTaskMsg->uiSeqId,pStrTmp);

	MsgMng_SendMsg(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->uiSeqId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pStrTmp, MOS_STRLEN(pStrTmp),MOS_NULL);

    MOS_FREE(pStrTmp);
    
    return MOS_OK;   
}

#if 0
/*******************************************************
 获取预置位的rsp函数
********************************************************/
_UC *Cmdhdl_BuildDevPresetPointRsp(_UI uiSeqId,_INT iStatus,ST_MOS_LIST *pstPresetList,ST_FROM_TO_MSG *fromToMsg)
{
    _UI uiMethod = 0;
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBodyObject = MOS_NULL;
    JSON_HANDLE hPresetArry = MOS_NULL;
    JSON_HANDLE hPresetItem = MOS_NULL;
    JSON_HANDLE hPoint      = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator,stIterator1;

    ST_CFG_PREPOSISION_NODE *pstPositionNode    = MOS_NULL;
    ST_CFG_PRESET_NODE      *pstPtzInfo         = MOS_NULL;
    
    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,"SEQID",Adpt_Json_CreateStrWithNum(uiSeqId));
    Adpt_Json_AddItemToObject(hRoot,"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    uiMethod = EN_OGCT_METHOD_CMDMSG*256 + EN_OGCT_DEVINFO_GETPRESETLIST_RSP;
    Adpt_Json_AddItemToObject(hRoot,"METHOD",Adpt_Json_CreateStrWithNum(uiMethod));

    hBodyObject = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hBodyObject,"CTEI",Adpt_Json_CreateString(Config_GetCompanyInf()->aucDevCTEI));

    hPresetArry = Adpt_Json_CreateArray();
    
    FOR_EACHDATA_INLIST(pstPresetList, pstPtzInfo, stIterator)
    {
        FOR_EACHDATA_INLIST(&pstPtzInfo->stPrePositionList,pstPositionNode,stIterator1);
        {
            hPresetItem = Adpt_Json_CreateObject();
            //Adpt_Json_AddItemToObject(hPresetItem,"ChannelNo",Adpt_Json_CreateStrWithNum(pstPtzInfo->iCamId));
            Adpt_Json_AddItemToObject(hPresetItem,"PresetID",Adpt_Json_CreateStrWithNum(pstPositionNode->uiPresetId));
            Adpt_Json_AddItemToObject(hPresetItem,"Name",Adpt_Json_CreateString(pstPositionNode->aucName));
            Adpt_Json_AddItemToObject(hPresetItem,"PicID",Adpt_Json_CreateString(pstPositionNode->aucName));
            hPoint = Adpt_Json_CreateObject();
            Adpt_Json_AddItemToObject(hPoint,"X",Adpt_Json_CreateStrWithNum(pstPositionNode->stPtzPreset.uiX));
            Adpt_Json_AddItemToObject(hPoint,"Y",Adpt_Json_CreateStrWithNum(pstPositionNode->stPtzPreset.uiY));
            Adpt_Json_AddItemToObject(hPresetItem,hPoint);
            Adpt_Json_AddItemToArray(hPresetArry,hPresetItem);
        }
    }
    Adpt_Json_AddItemToObject(hBodyObject,"PreSets",hPresetArry);
    Adpt_Json_AddItemToObject(hRoot,"BODY",hBodyObject);
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    return pucStrTmp;
}

//获取预置点，只需要告诉上层已经获取到了预置点；
_INT Cmdhdl_Task_GetDevPresetPoint(_INT iSeqId,_VPTR hBodyObject,ST_FROM_TO_MSG *fromToMsg)
{
    _INT iBodyLen   = 0;
    _UC *pStrTmp    = MOS_NULL;
    _UC *pucMsgBuff = MOS_NULL;
    ST_OGCT_PROTOCAL_HEAD *pstOgctHead;
    ST_MOS_LIST *pstPresetList = Config_GetCamaraMng()->stPresetList;
    //加一层指针判空
    if (pstPresetList)
        pStrTmp = Cmdhdl_BuildDevPresetPointRsp(iSeqId,0,pstPresetList,fromToMsg);
    else 
        return MOS_ERR;
    iBodyLen = MOS_HEXALGEN_STR(pStrTmp);

    pucMsgBuff = MOS_MALLOCCLR(iBodyLen + sizeof(ST_OGCT_PROTOCAL_HEAD) + 4)
    
    MOS_STRNCPY(pucMsgBuff + sizeof(ST_OGCT_PROTOCAL_HEAD),pStrTmp,iBodyLen);
    
    Ogct_Proto_EncMsgHead(pstOgctHead,EN_OGCT_METHOD_CMDMSG,EN_OGCT_DEVINFO_SETPRESET_RSP,
        ucNeedEncFlag,iBodyLen);
    Ogct_Proto_EncMsgBody(pstOgctHead,pstOgctHead + sizeof(ST_OGCT_PROTOCAL_HEAD),iBodyLen);
    iBodyLen += sizeof(ST_OGCT_PROTOCAL_HEAD);
    
    Adpt_Json_DePrint(pStrTmp);
    
    return MOS_OK;
}
#endif

#if 0
/******************************************************************************
关闭设备指示灯
******************************************************************************/
_INT Cmdhdl_Task_SwitchDevIndicatorLamp(_UC *pucPeerId, _UC ucNeedEncFlag,_INT iSeqId,_VPTR hBodyObject)
{
    _INT iStatus    = 0;
    _INT iCtrlType  = 0;

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBodyObject,"status"),&iCtrlType);

    if(iCtrlType == 0)
    {
        iCtrlType = 2;
    }
    else
    {
        iCtrlType = 1;
    }

    if(ZJ_GetFuncTable()->pFunLampCtrlCb)
    {
        ZJ_GetFuncTable()->pFunLampCtrlCb(EN_ZJ_AIIOT_INNER_INDICATORLAMP,iCtrlType,0);
    }
    return Cmdhdl_Task_SendCommonDevMsgRsp(pucPeerId,ucNeedEncFlag,EN_OGCT_DEVINFO_SETINDICATORLAMP_RSP,iSeqId,iStatus);

}


/*********************************************************
开关设备音频 输入(old code)
**********************************************************/
_INT Cmdhdl_Task_SwitchAudioInput(_UC ucNeedEncFlag,_INT iSeqId,_VPTR hBodyObject)
{
    _INT iStatus   = 0;
    _INT iMicId    = 0;
    _INT iOpenFlag = 0;
    _UI  iCamId    = 0;

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBodyObject,"ChannelNo"),&iMicId);

    Adpt_Json_GetIntegerEx(Adpt_Json_GetObjectItem(hBodyObject,"Status"),&iOpenFlag);

    Config_SetCamAudioParam(iCamId,iOpenFlag);

    return Cmdhdl_Task_SendCommonDevMsgRsp(ucNeedEncFlag,EN_OGCT_DEVINFO_CLOSEMIC_RSP,iSeqId,iStatus);
}
#endif

/*********************************************************
音频采集参数设置
**********************************************************/
_INT Cmdhdl_Task_SetCamAudioParam(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus      = MOS_ERR;
    ST_ZJ_AUDIO_PARAM *pstAudioParm = (ST_ZJ_AUDIO_PARAM*)pstCmdTaskMsg->aucMsgBody;
    
    if(ZJ_GetFuncTable()->pfunSetAudioParm)
    {
        iStatus = ZJ_GetFuncTable()->pfunSetAudioParm(pstAudioParm);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETAUDIOPARAM);
            MOS_SPRINTF(pucErrorString, "Device pfunSetAudioParm(enctype:%d) err", pstAudioParm->uiEncodeType);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunSetAudioParm is NULL!");
    }

    if (MOS_OK == iStatus)
    {
        // FIXME
        Config_SetCamAudioParam(0,pstAudioParm);
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

/**************************************************************
红外夜视开关设置  0 自动模式 1 红外模式 2 全彩模式
**************************************************************/
_INT Cmdhdl_Task_SetIRRedModeSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    ST_KJIOT_CONTRLDEV_NODE *pstDevCtrlNode = MOS_NULL;
    ST_CMDTASK_COMVALUE *pstComValue = (ST_CMDTASK_COMVALUE *)pstCmdTaskMsg->aucMsgBody;
    
    if(pstComValue->iValue == EN_ZJ_IRMODE_AUTO)
    {
        //红外灯自动模式 
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_DNSET);
        if(pstDevCtrlNode && pstDevCtrlNode->pFunContrlDev)
        {
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_DNSET,0,(_UC*)"{\"CtrlType\":\"0\"}",MOS_NULL);
        }

        /* 白光灯回调在红外灯后 */
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_LAMP);
        if(pstDevCtrlNode != MOS_NULL && pstDevCtrlNode->pFunContrlDev/*&& ( pstDevCtrlNode->uiInTimerCtrl&0x02) > 0*/) // uiInTimerCtrl 无意义
        {
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_LAMP,0,(_UC*)"{\"CtrlType\":\"0\"}",MOS_NULL);
            // pstDevCtrlNode->uiInTimerCtrl ^= 0x02;
            MOS_LOG_INF(CMD_STRLOG,"close lamp OK");
        }
        // Config_SetCamerCurIRWorkMode(0, EN_ZJ_IRMODE_AUTO);
    }
    else if(pstComValue->iValue == EN_ZJ_IRMODE_IR)
    {
        //1关闭白光灯、2打开红外灯
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_DNSET);
        if(pstDevCtrlNode && pstDevCtrlNode->pFunContrlDev)
        {
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_DNSET,0,(_UC*)"{\"CtrlType\":\"1\"}",MOS_NULL);
        }

        /* 白光灯回调在红外灯后 */
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_LAMP);
        if(pstDevCtrlNode && pstDevCtrlNode->pFunContrlDev) 
        {
            // if((pstDevCtrlNode->uiInTimerCtrl & 0x02) > 0) // uiInTimerCtrl 无意义
            // {
            //     pstDevCtrlNode->uiInTimerCtrl ^= 0x02;
            // }
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_LAMP,0,(_UC*)"{\"CtrlType\":\"0\"}",MOS_NULL);
            MOS_LOG_INF(CMD_STRLOG,"close lamp OK");
        }

        // Config_SetCamerCurIRWorkMode(0, EN_ZJ_IRMODE_IR);
    }
    else if(pstComValue->iValue == EN_ZJ_IRMODE_FULLCOLOR)
    {
        //1关闭红外灯 2开启白光灯
        pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_DNSET);
        if(pstDevCtrlNode && pstDevCtrlNode->pFunContrlDev) {
            pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_DNSET,0,(_UC*)"{\"CtrlType\":\"2\"}",MOS_NULL);
        }
        /* 全彩模式切换时，厂家已经通过红外灯（DN）知道是什么全彩模式，没必要再调用白光灯，去掉 */
        // pstDevCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_INNER_LAMP);
        // if(pstDevCtrlNode && pstDevCtrlNode->pFunContrlDev) {
        //     pstDevCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_INNER_LAMP,0,(_UC*)"{\"CtrlType\":\"1\",\"Duration\":\"86400\"}",MOS_NULL);
        //     pstDevCtrlNode->uiInTimerCtrl |= 0x02;
        //     MOS_LOG_INF(CMD_STRLOG,"open lamp ok");
        // }
        // Config_SetCamerCurIRWorkMode(0, EN_ZJ_IRMODE_FULLCOLOR);
    }
#if 0
    if(ZJ_GetFuncTable()->pFunIRLedSwitchCb)
    {
        _INT iStatus = MOS_ERR;
        iStatus = ZJ_GetFuncTable()->pFunIRLedSwitchCb(pstComValue->iValue);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_IRMODE);
            MOS_SPRINTF(pucErrorString, "Device pFunIRLedSwitchCb(iValue:%d) err", pstComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pFunIRLedSwitchCb is NULL!");
    }
#endif

    Config_SetCamerCurIRWorkMode(0, pstComValue->iValue);

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId ,0,&pstCmdTaskMsg->stMsgFromTo);
}

//预置位自检
_INT Cmdhdl_Task_PtzSelfCheck(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    if(ZJ_GetFuncTable()->pfunPTZAutoCheck)
    {
        iStatus = ZJ_GetFuncTable()->pfunPTZAutoCheck();
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_PTZCHECK);
            MOS_SPRINTF(pucErrorString, "Device pfunPTZAutoCheck err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }  
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunPTZAutoCheck is NULL!");
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

//摄像头切换
_INT Cmdhdl_Task_SwitchLen(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus  = MOS_ERR;
    ST_CMDTASK_COMVALUE *pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;
    
    if(ZJ_GetFuncTable()->pfunSwitchLen)
    {
        iStatus = ZJ_GetFuncTable()->pfunSwitchLen(pstComValue->iValue);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SWITCHLEN);
            MOS_SPRINTF(pucErrorString, "Device pfunSwitchLen(iValue:%d) err", pstComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }  
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunSwitchLen is NULL!");
    }

    Config_SetEnableLenId(pstComValue->iValue);
    
    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

//wifi查询的rsp函数
static _UC *Cmdhdl_GetWifiParmRsp(_UI uiSeqId,ST_ZJ_WIFI_INFO stWifiInfo[16],_UI uiWifiCount,_INT iStatus,ST_FROM_TO_MSG *pstMsgFromTo) 
{
    MOS_PARAM_NULL_RETNULL(pstMsgFromTo);

    _UC aucMethod[64];
    _UI uiTmp               = 0;
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBodyObject = MOS_NULL;
    JSON_HANDLE hArray      = MOS_NULL;
    JSON_HANDLE hArrayItem  = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(iStatus));
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETWIFILIST_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,pstMsgFromTo);
    
    hBodyObject = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBodyObject);
    
    hArray = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"WifiList",hArray);
    
    for(uiTmp = 0; uiTmp < uiWifiCount; uiTmp++)
    {
        hArrayItem = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Signal",Adpt_Json_CreateStrWithNum(stWifiInfo[uiTmp].iSigStrength));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"Security",Adpt_Json_CreateStrWithNum(stWifiInfo[uiTmp].iSecurity));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"InUse",Adpt_Json_CreateStrWithNum(stWifiInfo[uiTmp].iConnectFlag));
        Adpt_Json_AddItemToObject(hArrayItem,(_UC*)"SSID",Adpt_Json_CreateString((_UC*)stWifiInfo[uiTmp].acWifiSSID));
        Adpt_Json_AddItemToArray(hArray,hArrayItem);
    }
    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);

    return pucStrTmp; 
}

//wifi查询
_INT Cmdhdl_Task_GetWifiParm(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    ST_ZJ_WIFI_INFO stWifiInfo[16] = {0};
    _UI uiWifiCount = 16;
    _UC *pucStrTmp  = MOS_NULL;
    _INT iStatus    = MOS_ERR;

    if(ZJ_GetFuncTable()->pfuncGetWifi)
    {
        iStatus = ZJ_GetFuncTable()->pfuncGetWifi(stWifiInfo,&uiWifiCount);
        if(iStatus != MOS_OK)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETWIFILIST);
            MOS_SPRINTF(pucErrorString, "Device pfuncGetWifi err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfuncGetWifi is NULL!");
    }

    pucStrTmp = Cmdhdl_GetWifiParmRsp(pstCmdTaskMsg->uiSeqId,stWifiInfo,uiWifiCount,iStatus,&pstCmdTaskMsg->stMsgFromTo); 
    
	MsgMng_SendMsg(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->uiSeqId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);

    MOS_LOG_INF(CMD_STRLOG,"reqid %u send Get WifiList rsp %s",pstCmdTaskMsg->uiSeqId,pucStrTmp);

    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;

}

//网络信息查询的rsp函数
static _UC *Cmdhdl_GetNetInfoRsp(_UI uiSeqId,ST_ZJ_NETWORK_INFO *pstNetInfo,_INT iStatus,ST_FROM_TO_MSG *pstMsgFromTo) 
{
    MOS_PARAM_NULL_RETNULL(pstNetInfo);
    MOS_PARAM_NULL_RETNULL(pstMsgFromTo);

    _UC aucMethod[64];
    //_INT iTmp               = 0;
    _UC *pucStrTmp          = MOS_NULL;
    JSON_HANDLE hRoot       = MOS_NULL;
    JSON_HANDLE hBodyObject = MOS_NULL;

    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(0));
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",EN_OGCT_METHOD_CMDMSG,EN_OGCT_PLATCMD_GETCURNATINF_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));

    Cmdhdl_AddMsgSrcInfObject(hRoot,uiSeqId,pstMsgFromTo);
    hBodyObject = Adpt_Json_CreateObject();
    if(MOS_STRLEN(Config_GetDeviceMng()->aucDev4GCardNum) > 0)
    {
        Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"SIMCard",Adpt_Json_CreateString(Config_GetDeviceMng()->aucDev4GCardNum));
        Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"SignalType",Adpt_Json_CreateStrWithNum(pstNetInfo->iSignalType));
    }
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"NetType",Adpt_Json_CreateStrWithNum(pstNetInfo->iNetType));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"Signal",Adpt_Json_CreateStrWithNum(pstNetInfo->iSigStrength));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"IPAddr",Adpt_Json_CreateString(pstNetInfo->aucIPAddr));
    // Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"IPv6Addr",Adpt_Json_CreateString(pstNetInfo->aucIPv6Addr));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"MacAddr",Adpt_Json_CreateString(pstNetInfo->aucMacAddr));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"SSID",Adpt_Json_CreateString(pstNetInfo->aucWIFISSID));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBodyObject);

    pucStrTmp = Adpt_Json_Print(hRoot);
    Adpt_Json_Delete(hRoot);
    MOS_LOG_INF(CMD_STRLOG,"reqid %u send natinf rspMsg %s",uiSeqId,pucStrTmp);
    return pucStrTmp;
}

//网络信息查询
_INT Cmdhdl_Task_GetCurNetInf(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _UC *pucStrTmp     = MOS_NULL;
    _INT iStatus       = MOS_ERR;
    ST_ZJ_NETWORK_INFO  stNetInfo;

    MOS_MEMSET(&stNetInfo, 0, sizeof(stNetInfo));
    
    if(ZJ_GetFuncTable()->pfunGetCurNetInfo)
    {
        iStatus = ZJ_GetFuncTable()->pfunGetCurNetInfo(&stNetInfo);
        if(iStatus != MOS_OK)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETCURNATINF);
            MOS_SPRINTF(pucErrorString, "Device pfunGetCurNetInfo err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        } 
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunGetCurNetInfo is NULL!");
    }

    pucStrTmp = Cmdhdl_GetNetInfoRsp(pstCmdTaskMsg->uiSeqId,&stNetInfo,iStatus,&pstCmdTaskMsg->stMsgFromTo);
    
	MsgMng_SendMsg(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->uiSeqId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);
    
    Adpt_Json_DePrint(pucStrTmp);
    return MOS_OK;
}

//发送播放警报指令
_INT Cmdhdl_Task_PlayAlarmAudio(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);
    
    _INT iStatus = 0;
    _INT iLoopCnt = 0;
    _UC aucBuzzerOutput[CFG_STRING_MAXLEN] = {0};
    ST_CMDTASK_PLAYALARMAUDIO *pstPlayAlarmAudio = (ST_CMDTASK_PLAYALARMAUDIO*)pstCmdTaskMsg->aucMsgBody;
    ST_KJIOT_CONTRLDEV_NODE *pstIotCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_BUZZER);
    if(pstIotCtrlNode && pstIotCtrlNode->pFunContrlDev)
    {
        if (pstPlayAlarmAudio->iLoopCnt == 0)
        {
            iLoopCnt = 1;
        }
        else
        {
            iLoopCnt = pstPlayAlarmAudio->iLoopCnt;
        }
        if (0 == MOS_STRLEN(pstPlayAlarmAudio->aucSoundName))
        {
            // 兼容门铃设备,SoundType为4
            MOS_VSNPRINTF(aucBuzzerOutput, sizeof(aucBuzzerOutput), (_UC*)"{\"CtrlType\":\"1\",\"SoundType\":\"%d\",\"LoopCnt\":\"%d\"}", EN_ZJ_RING_ALARM, iLoopCnt);
        }
        else
        {
            // 非门铃设备,播放自定义告警声音,SoundType为2
            MOS_VSNPRINTF(aucBuzzerOutput, sizeof(aucBuzzerOutput), (_UC*)"{\"CtrlType\":\"1\",\"SoundType\":\"%d\",\"LoopCnt\":\"%d\",\"SoundName\":\"%s\"}", EN_ZJ_RING_DOORBELL, iLoopCnt, pstPlayAlarmAudio->aucSoundName);
        }
        pstIotCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_BUZZER,0,aucBuzzerOutput,MOS_NULL);
    }
    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

//强拆触发报警开关
_INT Cmdhdl_Task_SetDismantableAlarmSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    ST_CMDTASK_COMVALUE *pstCmdComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    if(ZJ_GetFuncTable()->pfunSetDismantableAlarm)
    {
        iStatus = ZJ_GetFuncTable()->pfunSetDismantableAlarm((_UI)pstCmdComValue->iValue);
        if(iStatus != MOS_OK)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETBELLFLAG);
            MOS_SPRINTF(pucErrorString, "Device pfunSetDismantableAlarm(iValue:%d) err", (_UI)pstCmdComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunSetDismantableAlarm is NULL!");
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

//逗留报警开关
_INT Cmdhdl_Task_SetStayAlarmSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    ST_CMDTASK_COMVALUE *pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    if(ZJ_GetFuncTable()->pfunSetStayAlarm)
    {
        iStatus = ZJ_GetFuncTable()->pfunSetStayAlarm((_UI)pstComValue->iValue);
        if(iStatus != MOS_OK)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWAITALARM);
            MOS_SPRINTF(pucErrorString, "Device pfunSetStayAlarm(iValue:%d) err", (_UI)pstComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunSetStayAlarm is NULL!");
    }
    
    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

//WDR开关
_INT Cmdhdl_Task_SetWideDynamicCamSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = 0;
    ST_CMDTASK_COMVALUE *pstComValue  = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    // 判断wdr接口是否初始化
    if(ZJ_GetFuncTable()->pfunSetWideDynamicCam)
    {
        // 回调设置wdr的接口 在厂商端实现
        iStatus = ZJ_GetFuncTable()->pfunSetWideDynamicCam((_UI)pstComValue->iValue);
        if(iStatus != MOS_OK)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWDR);
            MOS_SPRINTF(pucErrorString, "Device pfunSetWideDynamicCam(iValue:%d) err", (_UI)pstComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunSetWideDynamicCam is NULL!");
    }

    if(iStatus == MOS_OK)
    {
        // 同步wdr配置到配置文件
        Config_SetCamerWDR(0, pstComValue->iValue);
    }
    else
    {
        _UC  pucUrl[64]          = {0};
        _UC  pucErrorString[128] = {0};
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETWDR);
        MOS_SPRINTF(pucErrorString, "Device pfunSetWideDynamicCam(iValue:%d) err", pstComValue->iValue);
        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
    }
    

    // 回复信令服务器
    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
}

_INT Cmdhdl_Task_AddDeviceByAp(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    _UC *pStrTmp = MOS_NULL;
    _UC aucMethod[32];
    JSON_HANDLE hRoot = MOS_NULL;
    ST_CMDTASK_BINDDEV *pstBindDev = (ST_CMDTASK_BINDDEV*)pstCmdTaskMsg->aucMsgBody;

    Config_SetDevNeedBindFlag(pstBindDev->aucBindCode,pstBindDev->aucGroupId);
    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X",pstCmdTaskMsg->ucMsgType,pstCmdTaskMsg->ucMsgId + 1);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK));
    Cmdhdl_AddMsgSrcInfObject(hRoot,pstCmdTaskMsg->uiSeqId,&pstCmdTaskMsg->stMsgFromTo);

    pStrTmp = Adpt_Json_Print(hRoot);
    
    MsgMng_SendMsg(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->uiSeqId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL);

    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    Mos_Sleep(100);
    if(ZJ_GetFuncTable()->pfuncSetWifi)
    {
        iStatus = ZJ_GetFuncTable()->pfuncSetWifi(EN_ZJ_NETWORK_TYPE_WIFI,(char*)pstBindDev->aucSSID,(char*)pstBindDev->aucPasswd,0);
        if(iStatus != MOS_OK)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_ADDDEVICEBYAP);
            MOS_SPRINTF(pucErrorString, "Device AP pfuncSetWifi(aucSSID:%s, aucPasswd:%s) err", 
                                        (char*)pstBindDev->aucSSID,(char*)pstBindDev->aucPasswd);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
        else
        {
            MOS_LOG_ERR(CMD_STRLOG,"pfuncSetWifi is NULL!");
        }
    }
    return MOS_OK;
}

_INT Cmdhdl_Task_Set_BellQuickReply(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    return MOS_OK;
}

_INT Cmdhdl_Task_Change_BellSound(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    return MOS_OK;
}

_INT Cmdhdl_Task_UploadLogFile(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    _UC  pucUrl[64]          = {0};
    _UC  pucErrorString[128] = {0};
    ST_CMDTASK_COLLECTLOG_INF *pstCollectLogInf = (ST_CMDTASK_COLLECTLOG_INF*)pstCmdTaskMsg->aucMsgBody;
    
    if(ZJ_GetFuncTable()->pFunCollectLogFiles)
    {
        iStatus = ZJ_GetFuncTable()->pFunCollectLogFiles(pstCmdTaskMsg->aucPeerId,0,pstCollectLogInf->aucErrDes);
        if(iStatus != MOS_OK)
        {
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOAD_LOGFILE);
            MOS_SPRINTF(pucErrorString, "Device pFunCollectLogFiles err");
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_UPLOAD_LOGFILE);
        MOS_SPRINTF(pucErrorString, "pFunCollectLogFiles is NULL");
        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
    }
    Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,iStatus,&pstCmdTaskMsg->stMsgFromTo);
    return MOS_OK;
}

static _VPTR Cmdhdl_BuildSoudFileList(_UI uiSoundType)
{
    _INT iStatus     = 0;
    _UI  uiFreeSize  = 0;
    _UI  uiTotalSize = 0;
    JSON_HANDLE hArry                  = MOS_NULL;
    JSON_HANDLE hArryObject            = MOS_NULL;
    JSON_HANDLE hRoot                  = MOS_NULL;
    ST_ZJ_SOUNDFILE_INFO *pstHeadNode  = MOS_NULL;
    ST_ZJ_SOUNDFILE_INFO *pstTmpNode   = MOS_NULL;
    
    if(MOS_NULL == ZJ_GetFuncTable()->pFunGetSoudFiles)
    {
        MOS_LOG_ERR(CMD_STRLOG,"pFunGetSoudFiles is NULL!");
        return MOS_NULL;
    }

    iStatus = ZJ_GetFuncTable()->pFunGetSoudFiles(&uiTotalSize,&uiFreeSize,&pstHeadNode,uiSoundType);
    if(iStatus != MOS_OK)
    {
        _UC  pucUrl[64]          = {0};
        _UC  pucErrorString[128] = {0};
        MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_GETSOUNDLIST);
        MOS_SPRINTF(pucErrorString, "Device AP pFunGetSoudFiles(uiSoundType:%d) err", uiSoundType);
        CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
    }

    //MOS_PARAM_NULL_RETNULL(pstHeadNode);//声音文件列表可以为空
    hRoot = Adpt_Json_CreateObject(); 
    hArry = Adpt_Json_CreateArray();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"TotalSize",Adpt_Json_CreateNumber(uiTotalSize));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"FreeSize",Adpt_Json_CreateNumber(uiFreeSize));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SoundList",hArry);
    while (MOS_NULL != pstHeadNode)
    {
        hArryObject = Adpt_Json_CreateObject();
        Adpt_Json_AddItemToArray(hArry,hArryObject);
        Adpt_Json_AddItemToObject(hArryObject,(_UC*)"FileName",Adpt_Json_CreateString(pstHeadNode->aucFileName));
        Adpt_Json_AddItemToObject(hArryObject,(_UC*)"FileSize",Adpt_Json_CreateStrWithNum(pstHeadNode->uiFileSize));   
        Adpt_Json_AddItemToObject(hArryObject,(_UC*)"FileFormat",Adpt_Json_CreateStrWithNum(pstHeadNode->uiFileFormat));   
        Adpt_Json_AddItemToObject(hArryObject,(_UC*)"FileContent",Adpt_Json_CreateString(pstHeadNode->aucFileContent));
        Adpt_Json_AddItemToObject(hArryObject,(_UC*)"FileCategory",Adpt_Json_CreateStrWithNum(pstHeadNode->uiFileCategory)); 
        pstTmpNode = pstHeadNode;
        pstHeadNode = pstHeadNode->pstNextNode;
        MOS_FREE(pstTmpNode);
    }
    return hRoot;
}

_INT Cmdhdl_Task_GetSoundFiles(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _UC aucMethod[8];
    _UC *pStrTmp       = MOS_NULL;
    JSON_HANDLE hRoot  = MOS_NULL;
    JSON_HANDLE hLocalBody = MOS_NULL;
    
    ST_CMDTASK_COMVALUE *pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    hRoot = Adpt_Json_CreateObject();
    MOS_SPRINTF(aucMethod, "%02X%02X",pstCmdTaskMsg->ucMsgType,pstCmdTaskMsg->ucMsgId + 1);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE", Adpt_Json_CreateStrWithNum(MOS_OK)); 
    Cmdhdl_AddMsgSrcInfObject(hRoot,pstCmdTaskMsg->uiSeqId,&pstCmdTaskMsg->stMsgFromTo);

    hLocalBody  = Cmdhdl_BuildSoudFileList(pstComValue->iValue);
    
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hLocalBody);
    
    pStrTmp = Adpt_Json_Print(hRoot);
    
    MsgMng_SendMsg(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->uiSeqId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pStrTmp,MOS_STRLEN(pStrTmp),MOS_NULL); 
    
    Adpt_Json_Delete(hRoot);
    MOS_FREE(pStrTmp);
    return MOS_OK;
}

_INT Cmdhdl_Task_DelSoundFile(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    ST_CMDTASK_SOUNDFILE *pstSoundFile = (ST_CMDTASK_SOUNDFILE*)pstCmdTaskMsg->aucMsgBody;

    if(ZJ_GetFuncTable()->pFunDelSoundFile)
    {
        iStatus = ZJ_GetFuncTable()->pFunDelSoundFile(pstSoundFile->aucFileName);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_DELSOUNDFILE);
            MOS_SPRINTF(pucErrorString, "Device pFunDelSoundFile(aucFileName:%s) err", pstSoundFile->aucFileName);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
        else
        {
            MOS_LOG_INF(CMD_STRLOG,"DelSoundFile %s", pstSoundFile->aucFileName);    
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pFunDelSoundFile is NULL!");
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,0,&pstCmdTaskMsg->stMsgFromTo);
}

_INT Cmdhdl_Task_PlaySoundFile(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _UC *pStrTmp = MOS_NULL;
    JSON_HANDLE hRoot  = MOS_NULL;
    ST_KJIOT_CONTRLDEV_NODE *pstIotCtrlNode = KjIoT_FindDevContrlNode(EN_ZJ_AIIOT_TYPE_BUZZER);
    ST_CMDTASK_SOUNDFILE *pstSoundFile = (ST_CMDTASK_SOUNDFILE*)pstCmdTaskMsg->aucMsgBody;

    hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CtrlType", Adpt_Json_CreateStrWithNum(1)); 
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SoundType", Adpt_Json_CreateStrWithNum(1)); 
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"SoundName", Adpt_Json_CreateString(pstSoundFile->aucFileName)); 
    pStrTmp = Adpt_Json_Print(hRoot);
    
    if(pstIotCtrlNode && pstIotCtrlNode->pFunContrlDev)
    {
        pstIotCtrlNode->pFunContrlDev(EN_ZJ_AIIOT_TYPE_BUZZER,0,pStrTmp,MOS_NULL);
    }
    
    Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,0,&pstCmdTaskMsg->stMsgFromTo);
    
    Adpt_Json_Delete( hRoot);
    Adpt_Json_DePrint(pStrTmp);
    return MOS_OK;
}

_INT Cmdhdl_Task_DownSoundFile(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    ST_CMDTASK_SOUNDFILE *pstSoundFile = (ST_CMDTASK_SOUNDFILE*)pstCmdTaskMsg->aucMsgBody;

    if (DownFile_StartDownload(EN_ZJ_FILE_FORMAT_WAV, pstSoundFile->aucFileName, pstSoundFile->aucSoundUrl) != MOS_OK)
    {
        MOS_LOG_ERR(CMD_STRLOG,"DownFile_StartDownload ERR!");
    }
    
    Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,0,&pstCmdTaskMsg->stMsgFromTo);
    
    return MOS_OK;
}

_INT Cmdhdl_Task_AwakeRelayDev(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    ST_CMDTASK_COMVALUE *pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;
    
    if(ZJ_GetFuncTable()->pfunSetRelayDevAwakeStatus)
    {
        iStatus = ZJ_GetFuncTable()->pfunSetRelayDevAwakeStatus(pstComValue->iValue);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_RELAYDEV_AWAKE);
            MOS_SPRINTF(pucErrorString, "Device pfunSetRelayDevAwakeStatus(iValue:%d) err", pstComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunSetRelayDevAwakeStatus is NULL!");
    }

    Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,0,&pstCmdTaskMsg->stMsgFromTo);
    return MOS_OK;
}

_INT Cmdhdl_Task_SetVolume(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    ST_CMDTASK_COMVALUE *pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    if(ZJ_GetFuncTable()->pfunAudioVolumnAdjust)
    {
        iStatus = ZJ_GetFuncTable()->pfunAudioVolumnAdjust(0,pstComValue->iValue);
        if (MOS_OK != iStatus)
        {
            _UC  pucUrl[64]          = {0};
            _UC  pucErrorString[128] = {0};
            MOS_SPRINTF(pucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SETVOLUME);
            MOS_SPRINTF(pucErrorString, "Device pfunAudioVolumnAdjust(iValue:%d) err", pstComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), pucUrl, 0, iStatus, pucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunAudioVolumnAdjust is NULL!");
    }
    
    if (MOS_OK == iStatus)
    {
        Config_SetCamVolume(0, pstComValue->iValue);
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,0,&pstCmdTaskMsg->stMsgFromTo);
}

_INT Cmdhdl_Task_SuperCodesSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg)
{
    MOS_PARAM_NULL_RETERR(pstCmdTaskMsg);

    _INT iStatus = MOS_ERR;
    ST_CMDTASK_COMVALUE *pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    if(ZJ_GetFuncTable()->pfunSetSuperCodes)
    {
        iStatus = ZJ_GetFuncTable()->pfunSetSuperCodes(pstComValue->iValue);
        if (MOS_OK != iStatus)
        {
            _UC  aucUrl[64]          = {0};
            _UC  aucErrorString[128] = {0};
            MOS_SPRINTF(aucUrl, "%s%02x%02x", MSGMNG_CMD_SERVER_ADDR, EN_OGCT_METHOD_CMDMSG, EN_OGCT_PLATCMD_SUPERCODES);
            MOS_SPRINTF(aucErrorString, "Device pfunSetSuperCodes(iValue:%d) err", pstComValue->iValue);
            CloudStg_UploadLog(Mos_GetSessionId(), aucUrl, 0, iStatus, aucErrorString, 1);
        }
    }
    else
    {
        MOS_LOG_ERR(CMD_STRLOG,"pfunSetSuperCodes is NULL!");
    }
    
    if (MOS_OK == iStatus)
    {
        Config_SetCameraSuperCodesStatus(0, pstComValue->iValue);
    }

    return Cmdhdl_Task_SendCommonDevMsgRsp(pstCmdTaskMsg->aucPeerId,pstCmdTaskMsg->ucMsgType,
        pstCmdTaskMsg->ucMsgId + 1,pstCmdTaskMsg->uiSeqId,0,&pstCmdTaskMsg->stMsgFromTo);
}

_INT Cmdhdl_CloseSomethingBeforeReboot(_BOOL bCloseCmdServerFlag)
{
    _INT iCount = 0;

    // 关闭MP4录像
    ZJ_SetStoragePath(NULL);

    // 关闭信令服务器
    if (bCloseCmdServerFlag == MOS_TRUE)
    {
        MsgMng_CloseCmdServer();
    }

    // commmit所有云存任务
    CloudStg_CommitAllTaskBeforeReboot();

    // 监听云存状态
    for(;;)
    {
        Mos_Sleep(500);
        if (iCount++ >= 10 || CloudStg_CheckAllTaskBeforeReboot() == MOS_OK)
        {
            break;
        }
    }
    return MOS_OK;
}
