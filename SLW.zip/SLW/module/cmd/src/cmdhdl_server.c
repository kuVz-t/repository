#include "mos.h"
#include "zj_interface.h"
#include "config_type.h"
#include "config_api.h"
#include "cmdhdl_type.h"
#include "cmdhdl_api.h"
#include "adpt_json_adapt.h"
#include "http_api.h"
#include "http_type.h"
#include "http_api.h"
#include "IoManage_api.h"
#include "kjiot_device_api.h"
#include "rf_radio_api.h"
#include "cmdhdl_devinfo.h"
#include "record_api.h"
#include "snap_api.h"
#include "event_api.h"
#include "cloudstg_api.h"
#include "msgmng_api.h"
/***************************************************************************************
说明 :命令的格式 
  int       int              string
 cmdtype   cmdlen            json格式("id")
 如果是 自定义命令 则为命令的长度
****************************************************************************************/
static ST_CMDSERVER_MNG g_stCmdServerMng = {0};

static ST_CMDTASK_MSG g_stPtzCmdTaskMsg = {0};

static _HMUTEX g_hPtzMutex;
/***************************************************************************************
****************************************************************************************/
static _INT Cmdhdl_ServerTask_Loop(_VPTR pstArg);

/*************************************************************************************
***************************************************************************************/
ST_CMDSERVER_MNG *Cmdhdl_GetTaskMng()
{
    return &g_stCmdServerMng;
}

ST_CMDTASK_MSG *Cmdhdl_GetPtzTaskMsg()
{
    return &g_stPtzCmdTaskMsg;
}

_INT Cmdhdl_Task_Init()
{
    if(Cmdhdl_GetTaskMng()->ucInitFlag == 1)
    {
        MOS_LOG_WARN(CMD_STRLOG, "Already Init");
        return MOS_OK;
    }
    MOS_MEMSET(&g_stCmdServerMng, 0, sizeof(g_stCmdServerMng));
    Cmdhdl_GetTaskMng()->hMsgQueque = Mos_MsgQueueCreate(MOS_FALSE, 100, __FUNCTION__);
    Mos_MutexCreate(&(g_hPtzMutex));
    Cmdhdl_GetTaskMng()->ucInitFlag = 1;
    MOS_LOG_INF(CMD_STRLOG,"msg queue %p ",Cmdhdl_GetTaskMng()->hMsgQueque);
    return MOS_OK;
}

_INT Cmdhdl_Task_Start()
{
#ifdef HIK_ADAPT_FLAG
    _UI uiStackSize = 0x200000;         /*兼容hik设备*/
#else
    _UI uiStackSize = MOS_THREAD_STACK_NORMAL_SIZE;
#endif
    if(Cmdhdl_GetTaskMng()->ucInitFlag == 0)
    {
        return MOS_ERR;
    }
    if(Cmdhdl_GetTaskMng()->ucRunFlag == 1)
    {
        MOS_LOG_WARN(CMD_STRLOG, "Already Start");
        return MOS_OK;
    }
#ifdef MOS_LINUX_RTOS
    uiStackSize = MOS_THREAD_STACK_MIN_SIZE;
#endif

    Cmdhdl_GetTaskMng()->ucRunFlag  = 1;
    if(Mos_ThreadCreate((_UC*)"cmdhdl_task",EN_THREAD_PRIORITY_NORMAL,uiStackSize,
                        Cmdhdl_ServerTask_Loop,MOS_NULL,MOS_NULL,&Cmdhdl_GetTaskMng()->hThread) == MOS_ERR)
    {
        Cmdhdl_GetTaskMng()->ucRunFlag = 0;
        return MOS_ERR;
    }
    return MOS_OK;
}

_INT Cmdhdl_Task_Stop()
{
    if(Cmdhdl_GetTaskMng()->ucRunFlag == 0)
    {
        MOS_LOG_WARN(CMD_STRLOG, "Already Stop");
        return MOS_OK;
    }   
    Cmdhdl_GetTaskMng()->ucRunFlag  = 0;
    Mos_ThreadDelete(Cmdhdl_GetTaskMng()->hThread);
    
    MOS_LOG_INF(CMD_STRLOG,"cmd task stop ok");
    return MOS_OK;
}

_INT Cmdhdl_Task_Destroy()
{
    if(Cmdhdl_GetTaskMng()->ucInitFlag == 0)
    {
        MOS_LOG_WARN(CMD_STRLOG, "Already Destroy");
        return MOS_OK;
    }
    _VPTR pstMsg = MOS_NULL;
    // Mos_MsgQueueWake(Cmdhdl_GetTaskMng()->hMsgQueque,MOS_TRUE);
    while((pstMsg = Mos_MsgQueuePop(Cmdhdl_GetTaskMng()->hMsgQueque)) != MOS_NULL)
    {
        MOS_FREE(pstMsg);
    }
    Mos_MsgQueueDelete(Cmdhdl_GetTaskMng()->hMsgQueque);
    MOS_MEMSET(&g_stCmdServerMng, 0, sizeof(g_stCmdServerMng));
    Mos_MutexDelete(&(g_hPtzMutex));
    Cmdhdl_GetTaskMng()->ucInitFlag = 0;
    MOS_LOG_INF(CMD_STRLOG,"cmd task Destroy ok");
    return MOS_OK;
}

_INT Cmdhdl_SetCommonMsg(_UC *pucPeerId,_UI uiSeqId,_UC ucMsgType,_UC ucMsgId,ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = ucMsgType;
    pstCmdTaskMsg->ucMsgId   = ucMsgId;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

static _UC *Cmdhdl_BuildCmdNotSupportJsonRsp(_UC *pucPeerId, _UC ucMsgType, _UC ucMsgId, _INT iSeqId, _INT iStatus, ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETNULL(pucPeerId);
    MOS_PARAM_NULL_RETNULL(pstMsgFromTo);

    _UC aucMethod[16] = {0};
    _UC *pucStrTmp    = MOS_NULL;
    
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"CODE", Adpt_Json_CreateStrWithNum(iStatus));
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X", ucMsgType, ucMsgId);
    Adpt_Json_AddItemToObject(hRoot, (_UC*)"METHOD", Adpt_Json_CreateString(aucMethod));
    Cmdhdl_AddMsgSrcInfObject(hRoot, iSeqId, pstMsgFromTo); 
    pucStrTmp = Adpt_Json_Print(hRoot);

    return pucStrTmp;
}

_INT Cmdhdl_CmdNotSupporMsg(_UC *pucPeerId, _UI uiSeqId, _UC ucMsgType, _UC ucMsgId, ST_FROM_TO_MSG *pstMsgFromTo)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    _INT iStatus    = CMD_NOT_SUPPORT_ERR;
    _UC  *pucStrTmp = MOS_NULL;

    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = ucMsgType;
    pstCmdTaskMsg->ucMsgId   = ucMsgId;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pucStrTmp = Cmdhdl_BuildCmdNotSupportJsonRsp(pucPeerId, ucMsgType, ucMsgId + 1, uiSeqId, iStatus, &pstCmdTaskMsg->stMsgFromTo);

    _INT iRet = MsgMng_SendMsg(pstCmdTaskMsg->aucPeerId, pstCmdTaskMsg->uiSeqId, pstCmdTaskMsg->ucMsgType, pstCmdTaskMsg->ucMsgId + 1,         
        pucStrTmp, MOS_STRLEN(pucStrTmp), MOS_NULL);
    
    MOS_LOG_INF(CMD_STRLOG,"cmd %u not support, send rsp %s",pstCmdTaskMsg->uiSeqId, pucStrTmp);
    
    Adpt_Json_DePrint(pucStrTmp);
    MOS_FREE(pstCmdTaskMsg);
    
    // _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    // if (iRet != MOS_OK)
    // {
    //     MOS_FREE(pstCmdTaskMsg);
    //     return MOS_ERR;
    // }
    return iRet;
}

_INT Cmdhdl_SetDevTimeAndZoneMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,ST_CMSTASK_SETTIMEZONE *pstSetTimeAndZone)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pstSetTimeAndZone);

    ST_CMDTASK_MSG *pstCmdTaskMsg =(ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMSTASK_SETTIMEZONE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SET_TIMEANDZONE;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    MOS_MEMCPY(pstCmdTaskMsg->aucMsgBody,pstSetTimeAndZone,sizeof(ST_CMSTASK_SETTIMEZONE));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetDevPtzCtrlMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,ST_CMSTASK_PTZOPT *pstPtzOpt)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pstPtzOpt);

    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMSTASK_PTZOPT));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_CONTRLPTZ;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));  
    MOS_MEMCPY(pstCmdTaskMsg->aucMsgBody,pstPtzOpt,sizeof(ST_CMSTASK_PTZOPT));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    // 执行PTZ的信令才保存通信地址
    if(pstPtzOpt->iPtzCtrlType == 0)
    {
        ST_CMDTASK_MSG *pstPtzTaskMsg = MOS_NULL;
        Mos_MutexLock(&g_hPtzMutex);
        pstPtzTaskMsg = Cmdhdl_GetPtzTaskMsg();
        MOS_MEMCPY(pstPtzTaskMsg, pstCmdTaskMsg, sizeof(ST_CMDTASK_MSG));
        // iPtzCtrlType不超过128，直接赋值不影响
        pstPtzTaskMsg->ucRsv[0] = pstPtzOpt->iPtzCtrlType;
        pstPtzTaskMsg->ucRsv[1] = pstPtzOpt->u.stOnPtzInf.iPTZControl;
        Mos_MutexUnLock(&g_hPtzMutex);
    }
    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetCamOsdInfMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iPosition,_UC *pucOsdName)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pucOsdName);

    ST_CMDTASK_CAMOSD *pstCmdOsd  = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_CAMOSD));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETOSD;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));  
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    
    pstCmdOsd = (ST_CMDTASK_CAMOSD*)pstCmdTaskMsg->aucMsgBody;
    pstCmdOsd->iOSDMode = 0;    //只能显示一个位置水印
    MOS_STRNCPY(pstCmdOsd->uniOSDContent.stContent.aucName, pucOsdName, sizeof(pstCmdOsd->uniOSDContent.stContent.aucName));
    pstCmdOsd->uniOSDContent.stContent.aucName[sizeof(pstCmdOsd->uniOSDContent.stContent.aucName)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
    pstCmdOsd->uniOSDContent.stContent.iPostion = iPosition;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}
// OSD字符串内容可以为空（内容指针不为NULL，STRLEN结果为0），则对应osd内容为空
// OSD指针为NULL，OSD表面这个设置没有设置对应的OSD内容
_INT Cmdhdl_SetCamOsdInfExMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucOsdTopLeftName,_UC *pucOsdLowerLeftName
                                                                                    ,_UC *pucOsdTopRightName,_UC *pucOsdLowerRightName)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_CAMOSD *pstCmdOsd    = MOS_NULL;
    ST_OSD_CONTENT_EX *pstContentEx = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_CAMOSD));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETOSD;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));  
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    
    pstCmdOsd = (ST_CMDTASK_CAMOSD*)pstCmdTaskMsg->aucMsgBody;
    pstCmdOsd->iOSDMode = 1;    //支持同时显示四个位置水印
    pstContentEx = &(pstCmdOsd->uniOSDContent.stContentEx);

    if (pucOsdTopLeftName != MOS_NULL)
    {
        pstContentEx->ucHasTopLeft = 1;
        MOS_STRNCPY(pstContentEx->aucTopLeftName, pucOsdTopLeftName, sizeof(pstContentEx->aucTopLeftName));
        pstContentEx->aucTopLeftName[sizeof(pstContentEx->aucTopLeftName)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
    }
    else
    {
        pstContentEx->ucHasTopLeft = 0;
    }
    
    if (pucOsdLowerLeftName != MOS_NULL)
    {
        pstContentEx->ucHasLowerLeft = 1;
        MOS_STRNCPY(pstContentEx->aucLowerLeftName, pucOsdLowerLeftName, sizeof(pstContentEx->aucLowerLeftName));
        pstContentEx->aucLowerLeftName[sizeof(pstContentEx->aucLowerLeftName)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
    }
    else
    {
        pstContentEx->ucHasLowerLeft = 0;
    }
    
    if (pucOsdTopRightName != MOS_NULL)
    {
        pstContentEx->ucHasTopRight = 1;
        MOS_STRNCPY(pstContentEx->aucTopRightName, pucOsdTopRightName, sizeof(pstContentEx->aucTopRightName));
        pstContentEx->aucTopRightName[sizeof(pstContentEx->aucTopRightName)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
    }
    else
    {
        pstContentEx->ucHasTopRight = 0;
    }

    if (pucOsdLowerRightName != MOS_NULL)
    {
        pstContentEx->ucHasLowerRight = 1;
        MOS_STRNCPY(pstContentEx->aucLowerRightName, pucOsdLowerRightName, sizeof(pstContentEx->aucLowerRightName));
        pstContentEx->aucLowerRightName[sizeof(pstContentEx->aucLowerRightName)-1] = 0;//添加截止符,strncpy超过长度后不会自动添加截止符
    }
    else
    {
        pstContentEx->ucHasLowerRight = 0;
    }

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetCamOsdDisplayInfMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iDisplayFlag,_INT iOSDType)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_CAMOSD *pstCmdOsd  = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_CAMOSD));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETOSDDISPLAY;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));  
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    
    pstCmdOsd = (ST_CMDTASK_CAMOSD*)pstCmdTaskMsg->aucMsgBody;
    pstCmdOsd->iOSDType     = iOSDType;
    pstCmdOsd->iDisplayFlag = iDisplayFlag;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetCamCommonOsdInfMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOSDCommonPosition,_INT iOSDCommonFormat)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_CAMOSD *pstCmdOsd  = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_CAMOSD));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETOSDCOMMONINF;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));  
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    
    pstCmdOsd = (ST_CMDTASK_CAMOSD*)pstCmdTaskMsg->aucMsgBody;
    pstCmdOsd->iOSDCommonFormat   = iOSDCommonFormat;
    pstCmdOsd->iOSDCommonPosition = iOSDCommonPosition;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetImageRotateMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iRotateType)
{ 
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue  = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_INVERSION;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG)); 
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody; 
    pstComValue->iValue = iRotateType;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetVideoEncParamMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iStreamId,ST_ZJ_VIDEO_PARAM *pstVparam)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pstVparam);

    ST_CMDTASK_VIDEOPROP *pstVideoProp = MOS_NULL;

    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_VIDEOPROP));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_VENCODE_PARAM;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG)); 
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstVideoProp = (ST_CMDTASK_VIDEOPROP*)pstCmdTaskMsg->aucMsgBody;

    pstVideoProp->iStreamId = iStreamId;
    
    MOS_MEMCPY(&pstVideoProp->stVideoParam, pstVparam, sizeof(ST_ZJ_VIDEO_PARAM));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetPreSetPointMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iSetCmd,_INT iPrePointId,_UC *pucName)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pucName);

    ST_CMDTASK_PRESETPOINT *pstPresetPoint = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_PRESETPOINT));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETPRESET;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstPresetPoint = (ST_CMDTASK_PRESETPOINT*)pstCmdTaskMsg->aucMsgBody;
    pstPresetPoint->iSetCmd   = iSetCmd;
    pstPresetPoint->iPreSetId = iPrePointId;
    MOS_STRNCPY(pstPresetPoint->aucName, pucName, sizeof(pstPresetPoint->aucName));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetAudioParamMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,ST_ZJ_AUDIO_PARAM *pstAudioParm)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pstAudioParm);

    ST_CMDTASK_MSG *pstCmdTaskMsg   = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_ZJ_AUDIO_PARAM));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETAUDIOPARAM;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    MOS_MEMCPY(pstCmdTaskMsg->aucMsgBody, pstAudioParm, sizeof(ST_ZJ_AUDIO_PARAM));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_RSetIrWorkModeMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UI uiIrMode)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue  = MOS_NULL;
    ST_CMDTASK_MSG      *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_IRMODE;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody; 
    pstComValue->iValue = uiIrMode;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

// 强拆
_INT Cmdhdl_SwitchDismantableAlarmMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOpenFlag)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstCmdComValue = MOS_NULL;
    ST_CMDTASK_MSG      *pstCmdTaskMsg  = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }    
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETBELLFLAG;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstCmdComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;
    pstCmdComValue->iValue = iOpenFlag;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

// 逗留报警
_INT Cmdhdl_SetWaitAlarmMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOpenFlag)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETWAITALARM;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    pstComValue->iValue = iOpenFlag;
    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

// 设置wdr
_INT Cmdhdl_SetCamWdrMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOpenFlag)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    // 设置wdr消息队列的的初始化
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETWDR;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;

    pstComValue->iValue = iOpenFlag;

    // 发送消息队列
    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_AddDevByAPMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,
    _UC *pucBindCode,_UC *pucGid,_UC *pucSSID,_UC *pucPassWd)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pucBindCode);
    MOS_PARAM_NULL_RETERR(pucGid);
    MOS_PARAM_NULL_RETERR(pucSSID);
    MOS_PARAM_NULL_RETERR(pucPassWd);

    ST_CMDTASK_BINDDEV *pstBindDev    = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_BINDDEV));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_ADDDEVICEBYAP;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    
    pstBindDev = (ST_CMDTASK_BINDDEV*)pstCmdTaskMsg->aucMsgBody;
    MOS_STRNCPY(pstBindDev->aucBindCode,pucBindCode, sizeof(pstBindDev->aucBindCode));
    MOS_STRNCPY(pstBindDev->aucGroupId, pucGid, sizeof(pstBindDev->aucGroupId));
    MOS_STRNCPY(pstBindDev->aucSSID,    pucSSID, sizeof(pstBindDev->aucSSID));
    MOS_STRNCPY(pstBindDev->aucPasswd,  pucPassWd, sizeof(pstBindDev->aucPasswd));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SwitchCamLensMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iLenId)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue   = MOS_NULL;
    ST_CMDTASK_MSG      *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SWITCHLEN;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
   
    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;
    pstComValue->iValue = iLenId;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetUpLoadLogFileMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucErrDes,_INT iErrType)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pucErrDes);

    ST_CMDTASK_COLLECTLOG_INF *pstCollectLogInf = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COLLECTLOG_INF));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_UPLOAD_LOGFILE;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    
    pstCollectLogInf = (ST_CMDTASK_COLLECTLOG_INF*)pstCmdTaskMsg->aucMsgBody;
    MOS_STRNCPY(pstCollectLogInf->aucErrDes,pucErrDes,sizeof(pstCollectLogInf->aucErrDes));
    pstCollectLogInf->iErrType = iErrType;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_GetSoundListMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iSoundType)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_GETSOUNDLIST;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;
    pstComValue->iValue = iSoundType;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_DeleteSoundFileMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucFileName)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pucFileName);

    ST_CMDTASK_SOUNDFILE *pstSoundFile = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_SOUNDFILE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_DELSOUNDFILE;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstSoundFile = (ST_CMDTASK_SOUNDFILE*)pstCmdTaskMsg->aucMsgBody;
    
    MOS_STRNCPY(pstSoundFile->aucFileName, pucFileName, sizeof(pstSoundFile->aucFileName));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_PlaySoundFileMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucFileName)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pucFileName);

    ST_CMDTASK_SOUNDFILE *pstSoundFile = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_SOUNDFILE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_PLAYSOUNDFILE;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstSoundFile = (ST_CMDTASK_SOUNDFILE*)pstCmdTaskMsg->aucMsgBody;

    MOS_STRNCPY(pstSoundFile->aucFileName, pucFileName, sizeof(pstSoundFile->aucFileName));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}
_INT Cmdhdl_DownSoundFileMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_UC *pucFileName, _UC *pucSoundUrl)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    MOS_PARAM_NULL_RETERR(pucFileName);
    MOS_PARAM_NULL_RETERR(pucSoundUrl);

    ST_CMDTASK_SOUNDFILE *pstSoundFile = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_SOUNDFILE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_DOWNSOUNDFILE;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstSoundFile = (ST_CMDTASK_SOUNDFILE*)pstCmdTaskMsg->aucMsgBody;

    MOS_STRNCPY(pstSoundFile->aucFileName, pucFileName, sizeof(pstSoundFile->aucFileName));
    MOS_STRNCPY(pstSoundFile->aucSoundUrl, pucSoundUrl, sizeof(pstSoundFile->aucSoundUrl));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetAwakeRelayDevMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iValue)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg    = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_RELAYDEV_AWAKE;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId,   pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;
    pstComValue->iValue = iValue;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetMicVolumeMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iValue)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue  = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_SOUNDFILE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SETVOLUME;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;
    
    pstComValue->iValue = iValue;
    
    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetPtzEndMsg()
{
    ST_CMDTASK_MSG *pstCmdMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG));
    if(pstCmdMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
    Mos_MutexLock(&g_hPtzMutex);
    ST_CMDTASK_MSG *pstCmdTskMsg = Cmdhdl_GetPtzTaskMsg();
    MOS_MEMCPY(pstCmdMsg, pstCmdTskMsg, sizeof(ST_CMDTASK_MSG));
    MOS_MEMSET(pstCmdTskMsg, 0, sizeof(ST_CMDTASK_MSG));
    Mos_MutexUnLock(&g_hPtzMutex);
    // 防止重复发同一条信令
    if (pstCmdMsg->uiSeqId == 0)
    {
        MOS_FREE(pstCmdMsg);
        return MOS_ERR;
    }
    // 只发P2P
    if (MOS_STRCMP(pstCmdMsg->aucPeerId, MSGMNG_CMD_SERVER_ID) == 0)
    {
        MOS_FREE(pstCmdMsg);
        MOS_LOG_INF(CMD_STRLOG,"By CMD Server ,Do Not Send PTZ End Flag\n");
        return MOS_OK;
    }
    
    _UC aucMethod[16] = {0};
    _UC *pucStrTmp = MOS_NULL;
    const _INT PTZ_TOENDCODE = 1;
    JSON_HANDLE hRoot = Adpt_Json_CreateObject();
    JSON_HANDLE hBodyObject = Adpt_Json_CreateObject();

    Adpt_Json_AddItemToObject(hRoot,(_UC*)"CODE",Adpt_Json_CreateStrWithNum(PTZ_TOENDCODE));
    MOS_VSNPRINTF(aucMethod, 8, "%02X%02X",pstCmdMsg->ucMsgType,EN_OGCT_PLATCMD_CONTRLPTZ_RSP);
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"METHOD",Adpt_Json_CreateString(aucMethod));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"PTZType",Adpt_Json_CreateStrWithNum((_INT)pstCmdMsg->ucRsv[0]));
    Adpt_Json_AddItemToObject(hBodyObject,(_UC*)"PTZControl",Adpt_Json_CreateStrWithNum((_INT)pstCmdMsg->ucRsv[1]));
    Adpt_Json_AddItemToObject(hRoot,(_UC*)"BODY",hBodyObject);
    Cmdhdl_AddMsgSrcInfObject(hRoot,pstCmdMsg->uiSeqId,&pstCmdMsg->stMsgFromTo);
    pucStrTmp = Adpt_Json_Print(hRoot);
    MOS_LOG_INF(CMD_STRLOG, "SEND PTZ END FLAG %s", pucStrTmp);

    MsgMng_SendMsg(pstCmdMsg->aucPeerId,pstCmdMsg->uiSeqId,pstCmdMsg->ucMsgType,EN_OGCT_PLATCMD_CONTRLPTZ_RSP,pucStrTmp,MOS_STRLEN(pucStrTmp),MOS_NULL);

    MOS_FREE(pstCmdMsg);
    Adpt_Json_Delete(hRoot);
    return MOS_OK;
}

_INT Cmdhdl_PlayAlarmAudioMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iLoopCnt, _UC *pucSoundName)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);
    // MOS_PARAM_NULL_RETERR(pucSoundName);// 该入参可为空

    ST_CMDTASK_PLAYALARMAUDIO *pstPlayAlarmAudio = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_PLAYALARMAUDIO));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }

    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_PLAYALARM;
    pstCmdTaskMsg->uiSeqId   = uiSeqId; 
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));

    pstPlayAlarmAudio = (ST_CMDTASK_PLAYALARMAUDIO*)pstCmdTaskMsg->aucMsgBody;
    pstPlayAlarmAudio->iLoopCnt = iLoopCnt;
    MOS_STRNCPY(pstPlayAlarmAudio->aucSoundName, pucSoundName, sizeof(pstPlayAlarmAudio->aucSoundName));

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

_INT Cmdhdl_SetCamSuperCodesMsg(_UC *pucPeerId,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo,_INT iOpenFlag)
{
    MOS_PARAM_NULL_RETERR(pucPeerId);
    MOS_PARAM_NULL_RETERR(pstMsgFromTo);

    ST_CMDTASK_COMVALUE *pstComValue  = MOS_NULL;
    ST_CMDTASK_MSG *pstCmdTaskMsg = (ST_CMDTASK_MSG*)MOS_MALLOCCLR(sizeof(ST_CMDTASK_MSG) + sizeof(ST_CMDTASK_COMVALUE));
    if(pstCmdTaskMsg == MOS_NULL)
    {
        return MOS_ERR;
    }
	
    pstCmdTaskMsg->ucMsgType = EN_OGCT_METHOD_CMDMSG;
    pstCmdTaskMsg->ucMsgId   = EN_OGCT_PLATCMD_SUPERCODES;
    pstCmdTaskMsg->uiSeqId   = uiSeqId;
    
    MOS_MEMCPY(&pstCmdTaskMsg->stMsgFromTo, pstMsgFromTo, sizeof(ST_FROM_TO_MSG));  
    MOS_STRNCPY(pstCmdTaskMsg->aucPeerId, pucPeerId, sizeof(pstCmdTaskMsg->aucPeerId));
    
    pstComValue = (ST_CMDTASK_COMVALUE*)pstCmdTaskMsg->aucMsgBody;
    pstComValue->iValue = iOpenFlag;

    _INT iRet = Mos_MsgQueuePush(Cmdhdl_GetTaskMng()->hMsgQueque, pstCmdTaskMsg);
    if (iRet != MOS_OK)
    {
        MOS_FREE(pstCmdTaskMsg);
        return MOS_ERR;
    }
    return iRet;
}

/******************************************************************
局部函数  信令处理线程
******************************************************************/
 _INT Cmdhdl_ServerTask_Loop(_VPTR pstArg)
{
    ST_MOS_MSGHEAD *pstMsgHead;
    while(Cmdhdl_GetTaskMng()->ucRunFlag)
    {
        // 接收信令接收模块发送过来的信令消息队列
        pstMsgHead = Mos_MsgQueuePop(Cmdhdl_GetTaskMng()->hMsgQueque);
        if(pstMsgHead)
        {
            // 判断消息类型
            switch(pstMsgHead->usMsgType)
            {
                //网络层面的消息队列
                case EN_CMD_MSG_TYPE_NET:
                {
                    // 处理消息队列内容
                    Cmdhdl_ProcDevInfoMsg(pstMsgHead);
                    break;
                }
                default:
                {
                    break;
                }
            }
            MOS_FREE(pstMsgHead);
        }
        else
        {
            Mos_Sleep(20);
        }
    }

    MOS_LOG_INF(CMD_STRLOG, "CmdHdl task out");
	return MOS_OK;
}
