#ifndef _CMDHDL_DEVINFO_H
#define _CMDHDL_DEVINFO_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#define CMD_STRLOG                    (_UC*)"CMD"


// 内部消息
typedef struct stru_CMDTASK_MSG
{   
    ST_MOS_MSGHEAD stMsgHead;
    _UC  ucMsgType;                 // 消息队列类型
    _UC  ucMsgId;                   // 信令命令(methon)
    _UC  ucRsv[2];
    _UI  uiSeqId;
    _UC aucPeerId[CFG_STRING_LEN];
    ST_FROM_TO_MSG stMsgFromTo;     // 信令的from to信息
    _UC aucMsgBody[0];
}ST_CMDTASK_MSG;

typedef _INT (*PFUN_DEVMSG_PROC)(ST_CMDTASK_MSG *pstCmdMsg);

typedef struct stru_DEVMSG_HANDLER
{
    _UC ucMsgType;                  // 消息队列类型
    _UC ucMsgId;                    // 信令命令(methon)
    PFUN_DEVMSG_PROC pfunMsgProc;   // 相关信令在sdk处理的回调函数
}ST_DEVMSG_HANDLER;

typedef enum enum_cmdhdl_msg_type
{
    EN_CMD_MSG_TYPE_NET = 0,
    
}EN_CMD_MSG_TYPE;

typedef struct stru_OSD_CONTENT
{
    _INT iPostion;                      // OSD自定义(文本)水印位置  参考: EN_ZJ_OSD_POSITION_TYPE 0.默认；1.左上；2.左下；3.右上；4.右下
    _UC  aucName[CFG_STRING_BIGMAXLEN]; // OSD自定义(文本)水印内容  格式:UTF-8，最大支持512字节
}ST_OSD_CONTENT;

typedef struct struOSD_CONTENT_EX
{
    // 对应的has标志为1的情况，对应的内容才会回调通知设备
    _UC  ucHasTopLeft;
    _UC  ucHasLowerLeft;
    _UC  ucHasTopRight;
    _UC  ucHasLowerRight;
    _UC  aucTopLeftName[CFG_STRING_BIGMAXLEN];      // OSD左上自定义(文本),四角水印
    _UC  aucLowerLeftName[CFG_STRING_BIGMAXLEN];    // OSD左下自定义(文本),四角水印
    _UC  aucTopRightName[CFG_STRING_BIGMAXLEN];     // OSD右上自定义(文本),四角水印
    _UC  aucLowerRightName[CFG_STRING_BIGMAXLEN];   // OSD右下自定义(文本),四角水印
}ST_OSD_CONTENT_EX;

typedef struct stru_CMDTASK_CAMOSD
{
    _INT iOSDType;              // OSD默认(时间)水印显示开关    0.不显示 1.显示
    _INT iOSDCommonPosition;    // OSD默认(时间)水印位置        参考: EN_ZJ_OSD_POSITION_TYPE 0.默认；1.左上；2.左下；3.右上；4.右下
    _INT iOSDCommonFormat;      // OSD默认(时间)水印格式        参考: EN_ZJ_OSD_TIMEFORMAT_TYPE

    _INT iDisplayFlag;          // OSD自定义(文本)水印显示开关  0.不显示 1.显示
    _INT iOSDMode;              // OSD自定义(文本)水印模式      0.默认，只能显示一个位置水印；1.支持同时显示四个位置水印
    union
    {
        ST_OSD_CONTENT stContent;       // 普通自定义(文本)信息结构体
        ST_OSD_CONTENT_EX stContentEx;  // 四角水印信息结构体
    }uniOSDContent;
}ST_CMDTASK_CAMOSD;

typedef struct stru_CMDTASK_COMVALUE
{
    _INT iValue;
    
}ST_CMDTASK_COMVALUE;

typedef struct stru_CMDTASK_COMPTR
{
    _VPTR pstHandle;
    
}ST_CMDTASK_COMPTR;

typedef struct stru_CMDTASK_VIDEOPROP
{
    _INT iStreamId;
    ST_ZJ_VIDEO_PARAM stVideoParam;
}ST_CMDTASK_VIDEOPROP;

typedef struct stru_CMDTASK_PRESETPOINT
{
    _INT iSetCmd;
    _INT iPreSetId;
    _UC aucName[CFG_STRING_LEN];
}ST_CMDTASK_PRESETPOINT;

typedef struct stru_CMDTASK_BINDDEV
{
    _UC aucBindCode[CFG_STRING_LEN];
    _UC aucGroupId[CFG_STRING_LEN];
    _UC aucSSID[CFG_STRING_LEN];
    _UC aucPasswd[CFG_STRING_LEN];
}ST_CMDTASK_BINDDEV;

typedef struct stru_CMDTASK_COLLECTLOG_INF
{
    _INT iErrType;
    _UC  aucErrDes[CFG_STRING_MAXLEN];
}ST_CMDTASK_COLLECTLOG_INF;


typedef struct stru_CMDTASK_SOUNDFILE
{
    _UC  aucFileName[CFG_STRING_MIDLEN];
    _UC  aucSoundUrl[CFG_STRING_BIGMAXLEN];
}ST_CMDTASK_SOUNDFILE;

typedef struct stru_CMDTASK_FACEINF
{
    _INT iMaxFaceCnt;
    _UC  aucFaceDes[CFG_STRING_MAXLEN];    //人脸标签备注信息
    _UC  aucFaceLabeName[CFG_STRING_LEN];  //人脸名称
    _UC  aucFaceLabelId[CFG_STRING_LEN];   //人脸标签id
}ST_CMDTASK_FACEINF;

typedef struct stru_CMDSERVER_MNG
{
    _UC ucInitFlag;
    _UC ucRunFlag;
    _UC ucRsv[2];
    _HTHREAD hThread;
    _HQUEUE  hMsgQueque;
    _UI uiFormatFlag;
}ST_CMDSERVER_MNG;

typedef struct stru_CMDTASK_PLAYALARMAUDIO
{
    _INT iLoopCnt;                          // 播放次数
    _UC  aucSoundName[CFG_STRING_MAXLEN];   // 声音文件名称
}ST_CMDTASK_PLAYALARMAUDIO;

ST_CMDSERVER_MNG *Cmdhdl_GetTaskMng();

ST_CMDTASK_MSG *Cmdhdl_GetPtzTaskMsg();

_INT Cmdhdl_ProcDevInfoMsg(_VPTR pstMsg);

_VOID Cmdhdl_AddMsgSrcInfObject(JSON_HANDLE hRoot,_UI uiSeqId,ST_FROM_TO_MSG *pstMsgFromTo);

_INT Cmdhdl_Task_SendCommonDevMsgRsp(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_INT iSeqId,_INT iStatus,ST_FROM_TO_MSG *stMsgFromTo);

_INT Cmdhdl_Task_SendCommonDevMsgRspEx(_UC *pucPeerId,_UC ucMsgType,_UC ucMsgId,_INT iSeqId,_INT iStatus,ST_FROM_TO_MSG *pstMsgFromTo, JSON_HANDLE hBody);

_INT Cmdhdl_Task_GetTimeZone(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_SetTimeZone(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_GetSdcardInf(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_FormatSdcard(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_PtzCtrl(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_SetOsdInfo(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_SetOsdDisplay(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_SetCommonOsdInf(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_ClearDevCfg(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_CameRotate(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_SetCamEncParam(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_SetDevPresetPoint(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_SetCamAudioParam(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_SetIRRedModeSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_PtzSelfCheck(ST_CMDTASK_MSG *pstCmdTaskMsg);//预置位自检（lack msgid）

_INT Cmdhdl_Task_SwitchLen(ST_CMDTASK_MSG *pstCmdTaskMsg);//摄像头切换

//wifi查询 
_INT Cmdhdl_Task_GetWifiParm(ST_CMDTASK_MSG *pstCmdTaskMsg);

//网络信息查询 
_INT Cmdhdl_Task_GetCurNetInf(ST_CMDTASK_MSG *pstCmdTaskMsg);

//发送播放警报指令
_INT Cmdhdl_Task_PlayAlarmAudio(ST_CMDTASK_MSG *pstCmdTaskMsg);

//强拆触发报警开关
_INT Cmdhdl_Task_SetDismantableAlarmSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg);

//逗留报警开关
_INT Cmdhdl_Task_SetStayAlarmSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg);

//WDR开关
_INT Cmdhdl_Task_SetWideDynamicCamSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_AddDeviceByAp(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_Set_BellQuickReply(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_Change_BellSound(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_UploadLogFile(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_GetSoundFiles(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_DelSoundFile(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_PlaySoundFile(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_DownSoundFile(ST_CMDTASK_MSG *pstCmdTaskMsg);

_INT Cmdhdl_Task_AwakeRelayDev(ST_CMDTASK_MSG *pstCmdTaskMsg);

//设置中继门铃音量
_INT Cmdhdl_Task_SetVolume(ST_CMDTASK_MSG *pstCmdTaskMsg);

//超级编码
_INT Cmdhdl_Task_SuperCodesSwitch(ST_CMDTASK_MSG *pstCmdTaskMsg);


// 错误信令回复
_INT Cmdhdl_Task_CmdNotSupportRsp(ST_CMDTASK_MSG *pstCmdMsg);

#ifdef __cplusplus
}
#endif

#endif



