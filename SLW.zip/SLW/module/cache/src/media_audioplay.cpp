#include "media_audioplay.h"
#include "kj_audio_buffer_multy.h"
#include "kj_audio_buffer.h"
#include "zj_func.h"
AudioBuffer g_hAudioWriteBuf;
ST_AUDIO_TASKMNG g_stSpeakerMng;

ST_AUDIO_TASKMNG* Media_GetSpeakerMng()
{
    return  &g_stSpeakerMng;
}


_INT Media_AudioPlayInit()
{
    if (Media_GetSpeakerMng()->uiInitFlag == 1)
    {
        MOS_PRINTF("Already Init !! \r\n");
        return MOS_OK;
    }
    g_hAudioWriteBuf.bufferInit(AUDIO_ONEBUF_SIZE, 40, 0);
    g_hAudioWriteBuf.bufferClean();

    MOS_MEMSET(&g_stSpeakerMng,0,sizeof(ST_AUDIO_TASKMNG));
    Mos_MutexCreate(&Media_GetSpeakerMng()->hMutex);
    Media_GetSpeakerMng()->uiInitFlag = 1;
    MOS_PRINTF("Media_AudioPlayInit task init ok \r\n");
    return MOS_OK;
}

_INT Media_AudioPlayDestroy()
{
    if (Media_GetSpeakerMng()->uiInitFlag == 0)
    {
        MOS_PRINTF("Already Destroy !! \r\n");
        return MOS_OK;
    }
    
    Mos_MutexDelete(&Media_GetSpeakerMng()->hMutex);
    MOS_LIST_INIT(&Media_GetSpeakerMng()->stBussList);
    g_hAudioWriteBuf.bufferClose();
    Media_GetSpeakerMng()->uiInitFlag = 0;
    return MOS_OK;
}

_HAUDIOPLAY Media_AudioPlayCreatWriteHandle(_UC *pucPeerId,_UI uiUsrId, ST_ZJ_AUDIO_PARAM *pstAudioParm)
{
     WRITE_PLAY_AUDIO_DATA_NODE *pstNode = MOS_NULL;
     pstNode = (WRITE_PLAY_AUDIO_DATA_NODE *)MOS_MALLOC(sizeof(WRITE_PLAY_AUDIO_DATA_NODE));

     pstNode->uiSessionID   = uiUsrId;
     pstNode->uiChannel     = pstAudioParm->uiChannel;
     pstNode->uiSampleRate  = pstAudioParm->uiSampleRate;
     pstNode->uiBitrate     = pstAudioParm->uiDepth;
     pstNode->uiEncodeType  = pstAudioParm->uiEncodeType;
     MOS_STRNCPY(pstNode->ucsPeerId, pucPeerId, sizeof(pstNode->ucsPeerId));
     MOS_PRINTF("Media_AudioPlayCreatWriteHandle iChannel: %u\r\n", pstNode->uiSessionID);
     Media_GetSpeakerMng()->hAudioWrite = pstNode;
     return (_HAUDIOPLAY)pstNode;
}

// 分配Buss节点
WRITE_PLAY_AUDIO_DATA_NODE *Media_AllocPlayAudioNode()
{
    ST_MOS_LIST_ITERATOR stIterator;
    WRITE_PLAY_AUDIO_DATA_NODE *pstBussNode = MOS_NULL;
    FOR_EACHDATA_INLIST(&Media_GetSpeakerMng()->stBussList, pstBussNode, stIterator)
    {
        if(pstBussNode->uiUseFlag == 0)
        {
            break;
        }
    }
    if(pstBussNode == MOS_NULL)
    {
        pstBussNode = (WRITE_PLAY_AUDIO_DATA_NODE*)MOS_MALLOCCLR(sizeof(WRITE_PLAY_AUDIO_DATA_NODE));
        if(pstBussNode == MOS_NULL)
        {
            return MOS_NULL;
        }
        MOS_LIST_ADDTAIL(&Media_GetSpeakerMng()->stBussList, pstBussNode);
    }
    pstBussNode->uiPlayId   = ++Media_GetSpeakerMng()->uiPlayId;
    pstBussNode->uiUseFlag  = 1;
    return pstBussNode;
}

void Media_Notify_AudioPlay(_UC *pucPeerId, _UI uiStreamType, _UI uiOption, _UI uiUsrId )
{
    if(ZJ_GetFuncTable()->pfunMediaToPlay)
    {
        MOS_PRINTF("%s %d sessinid:%u \n", __FUNCTION__, __LINE__, uiUsrId);
        MOS_LOG_INF("debugspeaker","SessionID %u recv option %u", uiUsrId, uiOption);
        if(uiStreamType == 1)
        {
            if(1 == uiOption)
            {
               _HAPLAYREAD hReadSpeakAudio = Media_AudioPlayCreatReadHandle(pucPeerId, uiUsrId);
                ZJ_GetFuncTable()->pfunMediaToPlay(pucPeerId,(_VPTR)hReadSpeakAudio, EN_ZJ_MEDIA_AUDIO,1);
            }
            else
            {
                if (MOS_STRSTR(pucPeerId, "Broadcast") != MOS_NULL)
                {
                    _INT iRet  = 0;
                    _INT iTime = 0;
                    while (iTime < 200)
                    {                
                        iRet = Media_AudioPlayReadFrameIsEnd();
                        if (iRet == MOS_OK)
                        {
                            break;
                        }
                        iTime++;
                        Mos_Sleep(10);
                    }
                }
                ZJ_GetFuncTable()->pfunMediaToPlay(pucPeerId, (_VPTR)Media_GetSpeakerMng()->hAudioRead, EN_ZJ_MEDIA_AUDIO,0);
                Media_AudioPlayDestroyReadHandle((_HAPLAYREAD)Media_GetSpeakerMng()->hAudioRead);
            }
        }
    }
}

_UC* Media_AudioPlayGetFrameBuff(_HAUDIOPLAY hPlay,_UI uiBuffLen)
{
    return MOS_OK;
}

_INT Media_AudioPlaySetFrameInfo(_HAUDIOPLAY hPlay,_UI uiFrameLen,_UI uiTimeStamp)
{
    return MOS_OK;
}

_INT Media_AudioPlayCancelFrameBuff(_HAUDIOPLAY hPlay)
{
    g_hAudioWriteBuf.bufferClean();

    return MOS_OK;
}

_INT Media_AudioPlayWriteFrame(_HAUDIOPLAY hPlay,_UC* ptData,_UI uiDataLen,_UI uiTimeStamp)
{
    _INT iRet = g_hAudioWriteBuf.writeData(ptData, uiDataLen, false, MOS_NULL, uiTimeStamp);
    if(iRet == -1)
    {
        g_hAudioWriteBuf.readOneGopOk();
        g_hAudioWriteBuf.writeData(ptData, uiDataLen, false, MOS_NULL, uiTimeStamp);
    }
    //MOS_PRINTF("%s len:%u, ret:%d\n", __FUNCTION__, uiDataLen, iRet);
    return iRet;
}

_INT Media_AudioPlayWriteFrame2(_HAUDIOPLAY hPlay,_UC* ptData,_UI uiDataLen,_UI uiTimeStamp)
{
    _INT iRet = g_hAudioWriteBuf.writeData(ptData, uiDataLen, false, MOS_NULL, uiTimeStamp);
    if(iRet == -1)
     {
        iRet = g_hAudioWriteBuf.writeData(ptData, uiDataLen, false, MOS_NULL, uiTimeStamp);
    }
    //MOS_PRINTF("%s len:%u, ret:%d\n", __FUNCTION__, uiDataLen, iRet);
    return iRet;
}


_INT Media_AudioPlayDestroyWriteHandle(_HAUDIOPLAY hPlay)
{
    WRITE_PLAY_AUDIO_DATA_NODE *pstNode = (WRITE_PLAY_AUDIO_DATA_NODE*)hPlay;
    if (pstNode != MOS_NULL)
    {
        if (Media_GetSpeakerMng()->hAudioWrite == pstNode)
        {
            Media_GetSpeakerMng()->hAudioWrite = MOS_NULL;
        }
        MOS_FREE(pstNode);
    }
    return MOS_OK;
}

// 读相关的接口
_HAPLAYREAD Media_AudioPlayCreatReadHandle(_UC *pucPeerId,_UI uiUsrId)
{
    MOS_PRINTF("%s %d sessinid:%u \n", __FUNCTION__, __LINE__, uiUsrId);
    READ_PLAY_AUDIO_DATA_NODE *pstNode = MOS_NULL;
    pstNode = (READ_PLAY_AUDIO_DATA_NODE *)MOS_MALLOC(sizeof(READ_PLAY_AUDIO_DATA_NODE));

    pstNode->uiSessionID   = uiUsrId;
    pstNode->uiReadBufID   = g_hAudioWriteBuf.setCurrentUsrId();
    if (Media_GetSpeakerMng()->hAudioWrite != MOS_NULL)
    {
        WRITE_PLAY_AUDIO_DATA_NODE *pstAudioParm = Media_GetSpeakerMng()->hAudioWrite;
        pstNode->uiChannel     = pstAudioParm->uiChannel;
        pstNode->uiSampleRate  = pstAudioParm->uiSampleRate;
        pstNode->uiBitrate     = pstAudioParm->uiBitrate;
        pstNode->uiEncodeType  = pstAudioParm->uiEncodeType;
    }
    MOS_STRNCPY(pstNode->ucsPeerId, pucPeerId, sizeof(pstNode->ucsPeerId));
    Media_GetSpeakerMng()->hAudioRead = pstNode;
    MOS_PRINTF("Media_AudioPlayCreatReadHandle iChannel: %u, readid:%u\n", pstNode->uiSessionID,  pstNode->uiReadBufID);
    return (_HAPLAYREAD)pstNode;
}

_INT Media_AudioPlayReadFrameIsEnd()
{
    return g_hAudioWriteBuf.readDataIsEnd();
}

_INT Media_AudioPlayReadFrame(_HAPLAYREAD hAPlayRead,_UC **pucBuff,_UI *puiTimeStamp,_UI *puiRemFrameCnt)
{
    //MOS_PRINTF("%s %d   \n", __FUNCTION__, __LINE__);
    READ_PLAY_AUDIO_DATA_NODE *pstNode = (READ_PLAY_AUDIO_DATA_NODE*)hAPlayRead;
    if (pstNode == NULL)
    {
        return 0;
    }
    char *DataBuf    = NULL;
    _INT DataBufLen = 0;
    long long time_pts = 0;
    _INT ret = 0;

    ret = g_hAudioWriteBuf.readData(&(DataBuf), &(DataBufLen), (_INT)(pstNode->uiReadBufID), MOS_NULL, &time_pts);
    if (ret != 0)
    {
        ///MOS_PRINTF("%s %d   \n", __FUNCTION__, __LINE__);
        return 0;
    }

    //MOS_PRINTF("%s %d  id:%u len:%d \n", __FUNCTION__, __LINE__, pstNode->uiReadBufID, DataBufLen);
    MOS_MEMSET(pstNode->ucsReadBuf, 0, sizeof(pstNode->ucsReadBuf));
    MOS_MEMCPY(pstNode->ucsReadBuf, DataBuf, DataBufLen);

    *puiTimeStamp = time_pts;
    *puiRemFrameCnt = 1;
    g_hAudioWriteBuf.readOk((_INT)(pstNode->uiReadBufID));
    *pucBuff = pstNode->ucsReadBuf;
    return DataBufLen;
}

_UI Media_AudioPlayGetLateFrameTimeStamp(_HAPLAYREAD hAPlayRead)
{
    return MOS_OK;
}

_INT Media_AudioPlayGetStreamInfo(_HAPLAYREAD hAudioPlayRead,ST_ZJ_AUDIO_PARAM *pstAudioDes)
{
    if (Media_GetSpeakerMng()->hAudioRead != MOS_NULL && (_HAPLAYREAD)Media_GetSpeakerMng()->hAudioRead  == hAudioPlayRead)
    {
        pstAudioDes->uiChannel     = Media_GetSpeakerMng()->hAudioRead->uiChannel;
        pstAudioDes->uiSampleRate  = Media_GetSpeakerMng()->hAudioRead->uiSampleRate;
        pstAudioDes->uiDepth       = Media_GetSpeakerMng()->hAudioRead->uiBitrate;
        pstAudioDes->uiEncodeType  = Media_GetSpeakerMng()->hAudioRead->uiEncodeType;
        return MOS_OK;
    }
    return MOS_FALSE;
}

_INT Media_AudioPlayDestroyReadHandle(_HAPLAYREAD hAPlayRead)
{
    READ_PLAY_AUDIO_DATA_NODE *pstNode = (READ_PLAY_AUDIO_DATA_NODE*)hAPlayRead;
    if (pstNode != MOS_NULL)
    {
        g_hAudioWriteBuf.closeCurrentUsrid(pstNode->uiReadBufID);
        if (Media_GetSpeakerMng()->hAudioRead == pstNode)
        {
            Media_GetSpeakerMng()->hAudioRead = MOS_NULL;
        }
        MOS_FREE(pstNode);
    }
    return MOS_OK;
}



