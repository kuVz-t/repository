#include "kj_audio_buffer.h"
#include <sys/time.h>


AudioBuffer::AudioBuffer()
    :audio_alarm_warning_used_(false)
{
    buffer_id_ = 0;
}

int AudioBuffer::bufferInit(int oneBufsize, int frame_num, int buffer_id)
{
    int   i;
    int   j;
    PCM_BUFFER_NUM = frame_num;
    audio_buffer_.bIsStop = false;
    buffer_id_ = buffer_id;
    audio_buffer_.is_using = 0;
    memset(&audio_buffer_, 0, sizeof(audio_buffer_));
    audio_buffer_.pcmData = (T_PCM_DATA *)malloc(sizeof(T_PCM_DATA)*PCM_BUFFER_NUM);
    for (i=0; i<PCM_BUFFER_NUM; i++)
    {
#ifdef USE_SHARED_PTR
        audio_buffer_.pcmData[i].pData.reset(new char[oneBufsize]);
        if (NULL == audio_buffer_.pcmData[i].pData.get())
        {
            for (j=0; j<PCM_BUFFER_NUM; j++)
            {
                if (audio_buffer_.pcmData[j].pData.get() != NULL)
                {
                    audio_buffer_.pcmData[j].pData.reset(0);
                }
            }
            return -1;
        }
#else
        audio_buffer_.pcmData[i].pData = (char*)malloc(oneBufsize);
        if (NULL == audio_buffer_.pcmData[i].pData)
        {
            for (j=0; j<PCM_BUFFER_NUM; j++)
            {
                if (audio_buffer_.pcmData[j].pData != NULL)
                {
                    free(audio_buffer_.pcmData[j].pData);
                }
            }
            return -1;
        }
#endif
    }
    audio_buffer_.wpos    = 0;
    audio_buffer_.rpos    = 0;
    audio_buffer_.encType = ENC_TYPE_PCM;
    return 0;
}


int AudioBuffer::bufferClean()
{
    KjMutexLockGuard  mutex_guard(mutex_audio_buffer_);
    audio_buffer_.wpos    = 0;
    audio_buffer_.rpos    = 0;
    audio_buffer_.encType = ENC_TYPE_PCM;
    audio_alarm_warning_used_ = false;
    audio_buffer_.is_using = 0;
    return 0;
}

int AudioBuffer::bufferClose()
{
    KjMutexLockGuard  mutex_guard(mutex_audio_buffer_);
    int i;
    audio_buffer_.bIsStop  = true;
    audio_buffer_.is_using = 0;

    //wait capture thread return
#ifdef USE_SHARED_PTR
    for (i=0; i<PCM_BUFFER_NUM; i++)
    {
        if (audio_buffer_.pcmData[i].pData.get() != NULL)
        {
            audio_buffer_.pcmData[i].pData.reset(0);
        }
    }
#else
    for (i=0; i<PCM_BUFFER_NUM; i++)
    {
        if (audio_buffer_.pcmData[i].pData != NULL)
        {
            free(audio_buffer_.pcmData[i].pData);
            audio_buffer_.pcmData[i].pData= NULL;
        }
    }
#endif
    if(audio_buffer_.pcmData != NULL)
    {
        free(audio_buffer_.pcmData);
        audio_buffer_.pcmData = NULL;
    }

    return 0;
}

int AudioBuffer::setBufferStatus(int isStop)
{
    audio_buffer_.bIsStop = isStop;
    audio_buffer_.wpos    = 0;
    audio_buffer_.rpos    = 0;
    return MOS_OK;
}

int AudioBuffer::readOneGopOk()
{
    KjMutexLockGuard  mutex_guard(mutex_audio_buffer_);
    if (audio_buffer_.bIsStop)
    {
        //printf("videoProc_wrData isStop\n");
        return -2;
    }

    if (audio_buffer_.wpos == audio_buffer_.rpos)
    {
        return -1;
    }
    if(audio_buffer_.is_using >= 1)
    {
        //printf(" audio buffer need to lost frame, but is in usesing !!!\n");
        return 0;
    }

    int count = 0;
    if(buffer_id_ == 99)
    printf("readgpo audio wps:%u, rpos:%u\n", audio_buffer_.wpos , audio_buffer_.rpos);
    while(count <= PCM_BUFFER_NUM/2)
    {
        count++;
        audio_buffer_.rpos++;
        if (audio_buffer_.rpos >= PCM_BUFFER_NUM)
        {
            audio_buffer_.rpos = 0;
        }
    }
    if(buffer_id_ == 99)
    printf("end audio wps:%u, rpos:%u\n", audio_buffer_.wpos , audio_buffer_.rpos);
    return 0;
}

int AudioBuffer::writeData(void* pdata, int size, bool is_alarm_audio,
                           struct timeval *tv_capture,long long time_pts)
{
    KjMutexLockGuard  mutex_guard(mutex_audio_buffer_);
    if (audio_buffer_.bIsStop)
    {
        //printf("AudioProc_wrData isStop\n");
        return -2;
    }

    if (((audio_buffer_.wpos+1)%PCM_BUFFER_NUM) == audio_buffer_.rpos)
    {
        //printf("AudioProc_wrData full\n");
        return -1;
    }

    if(audio_alarm_warning_used_ && (!is_alarm_audio))
    {
        return -3;
    }
#ifdef USE_SHARED_PTR
    memcpy(audio_buffer_.pcmData[audio_buffer_.wpos].pData.get(), pdata, size);
#else
    memcpy(audio_buffer_.pcmData[audio_buffer_.wpos].pData, pdata, size);
#endif
    audio_buffer_.pcmData[audio_buffer_.wpos].size = size;

    if(tv_capture != NULL)
    {
        audio_buffer_.pcmData[audio_buffer_.wpos].tv = *tv_capture;
    }
    audio_buffer_.pcmData[audio_buffer_.wpos].time_pts = time_pts;
    if(buffer_id_ == 99)
    {
        if(audio_buffer_.wpos==0)
            printf(" wpos:%u, rpos:%u........pts:%llu....diff:%llu\n", audio_buffer_.wpos,  audio_buffer_.rpos, time_pts,( time_pts-audio_buffer_.pcmData[PCM_BUFFER_NUM-1].time_pts)/1000 );
        else
          printf(" wpos:%u, rpos:%u........pts:%llu....diff:%llu\n", audio_buffer_.wpos,  audio_buffer_.rpos, time_pts,( time_pts-audio_buffer_.pcmData[(((audio_buffer_.wpos-1)<0)?(PCM_BUFFER_NUM-1):(audio_buffer_.wpos-1))].time_pts)/1000 );
    }
    audio_buffer_.wpos++;
    if (audio_buffer_.wpos >= PCM_BUFFER_NUM)
    {
        audio_buffer_.wpos = 0;
    }
    return 0;
}

int AudioBuffer::printfCahepts()
{
    if (audio_buffer_.bIsStop)
    {
        //printf("AudioProc_wrData isStop\n");
        return -2;
    }
    if (audio_buffer_.wpos == audio_buffer_.rpos)
    {
        return -1;
    }
    int curent_r_pos = audio_buffer_.rpos;

    while(curent_r_pos != audio_buffer_.wpos)
    {
        //printf(" wpos:%u, rpos:%u........pts:%llu. \n", audio_buffer_.wpos,  curent_r_pos, audio_buffer_.pcmData[curent_r_pos].time_pts);
        curent_r_pos++;
        if (curent_r_pos >= PCM_BUFFER_NUM)
        {
            curent_r_pos = 0;
        }
    }
    return MOS_OK;
}

//是否已经读取ringbuf数据完毕
int AudioBuffer::readDataIsEnd()
{
    KjMutexLockGuard  mutex_guard(mutex_audio_buffer_);
    
    if (audio_buffer_.bIsStop)
    {
        return 0;
    }
    if (audio_buffer_.wpos == audio_buffer_.rpos)
    {
        return 0;
    }

    return -1;
}

int AudioBuffer::readData(char **pdata, int *size, int usrId, struct timeval *tv_capture, long long *time_pts)
{
    KjMutexLockGuard  mutex_guard(mutex_audio_buffer_);
    if (audio_buffer_.bIsStop)
    {
        //printf("AudioProc_wrData isStop\n");
        return -1;
    }
    if (audio_buffer_.wpos == audio_buffer_.rpos)
    {
        return -1;
    }
#ifdef USE_SHARED_PTR
    *pdata = audio_buffer_.pcmData[audio_buffer_.rpos].pData.get();
#else
    *pdata = audio_buffer_.pcmData[audio_buffer_.rpos].pData;
#endif
    *size = audio_buffer_.pcmData[audio_buffer_.rpos].size;
    if(tv_capture != NULL)
    {
        *tv_capture = audio_buffer_.pcmData[audio_buffer_.rpos].tv;
    }
    if(time_pts != NULL)
    {
        *time_pts = audio_buffer_.pcmData[audio_buffer_.rpos].time_pts;
    }
    return 0;
}


int AudioBuffer::readOk(int usrId)
{
    KjMutexLockGuard  mutex_guard(mutex_audio_buffer_);
    audio_buffer_.rpos++;
    if (audio_buffer_.rpos >= PCM_BUFFER_NUM)
    {
        audio_buffer_.rpos = 0;
    }
    return 0;
}

_INT AudioBuffer::setCurrentUsrId()
{
    _INT ret = 0;
    return ret;
}

_INT AudioBuffer::closeCurrentUsrid(_INT usr_id)
{
    return 0;
}
