#include "media_video.h"
#include "kj_video_buffer_multy.h"
#include "mos.h"
#include "config_api.h"

#define USSHORT_MAX (65535)

// 摄像机当前分辨率
typedef enum enum_ZJ_CAMERA_RESOLUTION_CURRET{
    EN_ZJ_CARERA_RESOLUTION_CURRET_360P        = 0,   // 640*360分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_480P        = 1,   // 640*480分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_720P        = 2,   // 1280*720分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_960P        = 3,   // 1280*960分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_1080P       = 4,   // 1920*1080分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_1200P       = 5,   // 1600*1200分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_300W        = 6,   // 2048*1536分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_400W        = 7,   // 2500*1600分辨率
    EN_ZJ_CAMERA_RESOLUTION_CURRET_1440P       = 8,   // 2560*1440分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_500W        = 9,   // 2560*1920分辨率
    EN_ZJ_CAMERA_RESOLUTION_CURRET_600W        = 10,  // 3072*2048分辨率
    EN_ZJ_CARERA_RESOLUTION_CURRET_4K          = 11,  // 3840*2160分辨率 
    EN_ZJ_CARERA_RESOLUTION_CURRET_8K          = 12,  // 7680*4320分辨率
}EN_ZJ_CARERA_RESOLUTION_CURRET;

//厂家设置内存等级        EN_MOS_DEVICE_ABILITY_RICH     EN_MOS_DEVICE_ABILITY_MID       EN_MOS_DEVICE_ABILITY_POOR              
_UI VIDEOBUFLEN[][3] ={ {(800*1024),                    (600*1024),                     (500*1024)},                // EN_ZJ_CARERA_RESOLUTION_CURRET_360P     
                        {(800*1024),                    (600*1024),                     (500*1024)},                // EN_ZJ_CARERA_RESOLUTION_CURRET_480P   
                        {((15*1024*1024)/10),           (1024*1024),                    (800*1024)},                // EN_ZJ_CARERA_RESOLUTION_CURRET_720P    
                        {((15*1024*1024)/10),           (1024*1024),                    (800*1024)},                // EN_ZJ_CARERA_RESOLUTION_CURRET_960P   
                        {((15*1024*1024)/10),           (1024*1024),                    (800*1024)},                // EN_ZJ_CARERA_RESOLUTION_CURRET_1080P   
                        {((15*1024*1024)/10),           (1024*1024),                    (800*1024)},                // EN_ZJ_CARERA_RESOLUTION_CURRET_1200P   
                        {((18*1024*1024)/10),           ((14*1024*1024)/10),            ((11*1024*1024)/10)},       // EN_ZJ_CARERA_RESOLUTION_CURRET_300W   
                        {(2*1024*1024),                 ((16*1024*1024)/10),            ((13*1024*1024)/10)},       // EN_ZJ_CARERA_RESOLUTION_CURRET_400W   
                        {(2*1024*1024),                 ((16*1024*1024)/10),            ((13*1024*1024)/10)},       // EN_ZJ_CAMERA_RESOLUTION_CURRET_1440   
                        {(4*1024*1024),                 (3*1024*1024),                  (2*1024*1024)},             // EN_ZJ_CARERA_RESOLUTION_CURRET_500W   
                        {(4*1024*1024),                 ((35*1024*1024)/10),            (3*1024*1024)},             // EN_ZJ_CAMERA_RESOLUTION_CURRET_600W  
                        {(6*1024*1024),                 (5*1024*1024),                  (4*1024*1024)},             // PEN_ZJ_CARERA_RESOLUTION_CURRET_4K   
                        {(10*1024*1024),                (8*1024*1024),                  (7*1024*1024)}};            // EN_ZJ_CARERA_RESOLUTION_CURRET_8K    
                   
_UI VIDEOPOLLSIZE[]  = {MOS_MEM_MAXVIDEO_POOL_SIZE, MOS_MEM_MAXVIDEO_POOL_SIZE, MOS_MEM_MAXVIDEO_POOL_SIZE};

#define FRAME_START (1 << 3)
#define FRAME_END   (1 << 2)
#define NAL_START   (1 << 1)
#define NAL_END     (1)
typedef struct stuct_CACHE_MEDIA
{
    _HMEMOWNER      hMem;
    _INT            iMemUnitSize;
    _INT            iVideoInit;
    VideoBuffeMulty hVideoBuf[MAX_CAMERA_ID];
}ST_VIDEO_MNG;

/* h264 */
enum {
    NAL_SLICE           = 1,
    NAL_DPA             = 2,
    NAL_DPB             = 3,
    NAL_DPC             = 4,
    NAL_IDR_SLICE       = 5,
    NAL_SEI             = 6,
    NAL_SPS             = 7,
    NAL_PPS             = 8,
    NAL_AUD             = 9,
    NAL_END_SEQUENCE    = 10,
    NAL_END_STREAM      = 11,
    NAL_FILLER_DATA     = 12,
    NAL_SPS_EXT         = 13,
    NAL_AUXILIARY_SLICE = 19,
    NAL_FF_IGNORE       = 0xff0f001,
};

 /* h265 */
 enum NALUnitType {
     NAL_TRAIL_N    = 0,
     NAL_TRAIL_R    = 1,
     NAL_TSA_N      = 2,
     NAL_TSA_R      = 3,
     NAL_STSA_N     = 4,
     NAL_STSA_R     = 5,
     NAL_RADL_N     = 6,
     NAL_RADL_R     = 7,
     NAL_RASL_N     = 8,
     NAL_RASL_R     = 9,
     NAL_BLA_W_LP   = 16,
     NAL_BLA_W_RADL = 17,
     NAL_BLA_N_LP   = 18,
     NAL_IDR_W_RADL = 19,
     NAL_IDR_N_LP   = 20,
     NAL_CRA_NUT    = 21,
     NAL_HEVC_VPS   = 32,
     NAL_HEVC_SPS   = 33,
     NAL_HEVC_PPS   = 34,
     NAL_HEVC_AUD   = 35,
     NAL_EOS_NUT    = 36,
     NAL_EOB_NUT    = 37,
     NAL_FD_NUT     = 38,
     NAL_SEI_PREFIX = 39,
     NAL_SEI_SUFFIX = 40,
 };


typedef struct
{
    _UC  naluType;              // Nalu类型
    char *naluBuf;              // Nalu起始地址
    _INT naluLength;            // Nalu长度
    _INT timestamp;             // 时间戳
} MEDIA_VIDEO_NALU;

static _INT find_nal_unit(_UC* buf, _INT size, _INT* nal_start, _INT* nal_end)
{
    _INT i;
    // find start
    *nal_start = 0;
    *nal_end = 0;

    i = 0;
    while (   //( next_bits( 24 ) != 0x000001 && next_bits( 32 ) != 0x00000001 )
        (buf[i] != 0 || buf[i+1] != 0 || buf[i+2] != 0x01) &&
        (buf[i] != 0 || buf[i+1] != 0 || buf[i+2] != 0 || buf[i+3] != 0x01)
        )
    {
        i++; // skip leading zero
        if (i+4 >= size) { return 0; } // did not find nal start
    }

    if  (buf[i] != 0 || buf[i+1] != 0 || buf[i+2] != 0x01) // ( next_bits( 24 ) != 0x000001 )
    {
        i++;
    }

    if  (buf[i] != 0 || buf[i+1] != 0 || buf[i+2] != 0x01) { /* error, should never happen */ return 0; }
    i+= 3;
    *nal_start = i;

    while (   //( next_bits( 24 ) != 0x000000 && next_bits( 24 ) != 0x000001 )
        (buf[i] != 0 || buf[i+1] != 0 || buf[i+2] != 0) &&
        (buf[i] != 0 || buf[i+1] != 0 || buf[i+2] != 0x01)
        )
    {
        i++;
        // FIXME the next line fails when reading a nal that ends exactly at the end of the data
        if (i+3 >= size) { *nal_end = size; return -1; } // did not find nal end, stream ended first
    }

    *nal_end = i;
    return (*nal_end - *nal_start);
}

ST_VIDEO_MNG g_videoCacheMng;
ST_VIDEO_MNG *Media_GetModuleMng()
{
    return &g_videoCacheMng;
}

_VOID Media_FreeDataNode(_VPTR hMem, ST_DATA_NODE *pstTmpNode, _INT iMemUnitSize)
{
    if (hMem != MOS_NULL && ((pstTmpNode->stFrameNode.uiNaluLen+sizeof(ST_DATA_NODE)) == iMemUnitSize))
    {
        Mos_MemFree(pstTmpNode);
    }
    else
    {
        MOS_FREE(pstTmpNode);
    }
}

ST_FRAME_NODE *MediaVideoFrameInit()
{
    /* 初始化 */
    ST_FRAME_NODE *st_frame_node = MOS_NULL;
    st_frame_node = (ST_FRAME_NODE *)MOS_MALLOC(sizeof(ST_FRAME_NODE));
    if(st_frame_node == MOS_NULL)
    {
        MOS_PRINTF("%s %d MOS_MALLOC faild!\n", __func__, __LINE__);
        return MOS_NULL;
    }
    st_frame_node->ptnest                       = MOS_NULL;
    st_frame_node->ptDatabuff                   = MOS_NULL;
    st_frame_node->usDatalen                    = 0;
    st_frame_node->uiNaluLen                    = 0;
    st_frame_node->ucFramPos                    = 0;
    st_frame_node->uiRemFrameLen                = 0;
    st_frame_node->ucVideoResolutionChangeFlag  = EN_VIDEOPARAM_CHANGED_NONE;
    return st_frame_node;
}

ST_DATA_NODE *MediaVideoDataNodeInit(_VPTR hMem, _INT buf_size, _INT iMemUnitSize)
{
    /* 初始化 */
    ST_DATA_NODE  *st_data_node = MOS_NULL;
    if (hMem != MOS_NULL && (iMemUnitSize == (sizeof(ST_DATA_NODE)+buf_size)))
    {
        st_data_node = (ST_DATA_NODE *)Mos_MemAlloc((_HMEMOWNER)hMem, sizeof(ST_DATA_NODE)+buf_size);
    }
    else
    {
        st_data_node = (ST_DATA_NODE *)MOS_MALLOC(sizeof(ST_DATA_NODE)+buf_size);
    }

    if (st_data_node != MOS_NULL)
    {
        MOS_MEMSET(st_data_node, 0, sizeof(ST_DATA_NODE));
        st_data_node->pstnext           = MOS_NULL;
        st_data_node->pstFrameHead      = MOS_NULL;

        ST_FRAME_NODE *st_frame_node    = &st_data_node->stFrameNode;
        MOS_MEMSET(st_frame_node, 0, sizeof(ST_FRAME_NODE));
        st_frame_node->ptnest           = MOS_NULL;
        st_frame_node->ptDatabuff       = MOS_NULL;
    }
    return st_data_node;
}

// 视频初始化
_INT Media_VideoInit()
{
    // 创建缓存器
    Media_GetModuleMng()->iVideoInit  = 0;
    Media_GetModuleMng()->hMem        = MOS_NULL;
    Media_GetModuleMng()->iMemUnitSize= VIDEOCACHE_BUF_UNIT_SIZE;
    _UI uiDevAbilit =  Mos_SysGetDeviceAbility();
    switch (uiDevAbilit)
    {
    case EN_MOS_DEVICE_ABILITY_RICH:
        break;
    case EN_MOS_DEVICE_ABILITY_MID:
        break;
    case EN_MOS_DEVICE_ABILITY_POOR:
        break;
    default:
        uiDevAbilit = EN_MOS_DEVICE_ABILITY_MID;
        break;
    }

	ST_CFG_VIDEODES *pstVideoDes[MAX_CAMERA_ID] ={MOS_NULL};

    for (int i=0; i<MAX_CAMERA_ID; i++)
    {
        _UI uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_ABILITY_1080P;
        _INT iRichMem   = MOS_FALSE;
        pstVideoDes[i]  = Config_GetVideoDes(0,i);
        switch (pstVideoDes[i]->stVideoPara.uiResolution)
        {
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_360P:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_360P;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_480P:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_480P;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_720P:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_720P;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_960P:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_960P;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_1080P:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_1080P;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_1200P:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_1200P;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_300W:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_300W;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_400W:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_400W;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_500W:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_500W;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_4K:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_4K;
                break;
            case EN_ZJ_CARERA_RESOLUTION_ABILITY_8K:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_8K;
                break;
            case EN_ZJ_CAMERA_RESOLUTION_ABILITY_1440P:
                uiCurretResolution = EN_ZJ_CAMERA_RESOLUTION_CURRET_1440P;
                break;
            case EN_ZJ_CAMERA_RESOLUTION_ABILITY_600W:
                uiCurretResolution = EN_ZJ_CAMERA_RESOLUTION_CURRET_600W;
                break;                                   
            default:
                uiCurretResolution = EN_ZJ_CARERA_RESOLUTION_CURRET_1080P;
                break;
        }

        Media_GetModuleMng()->hVideoBuf[i].bufferInit(VIDEOBUFLEN[uiCurretResolution][uiDevAbilit], 1, i, 1,
        pstVideoDes[i]->stVideoPara.uiResolution, pstVideoDes[i]->stVideoPara.uiEncodeType, Config_GetCamaraMng()->uiCamDataInputMode);
        Media_GetModuleMng()->hVideoBuf[i].bufferClean();

        if (ZJ_GetFuncTable()->pfunVideoSwitch)
        {
            ZJ_GetFuncTable()->pfunVideoSwitch(i, 1);
        }
        MOS_PRINTF("Media_VideoInit task init ok camestr:%d size:%d uiCamDataInputMode:%d\r\n",i,  VIDEOBUFLEN[uiCurretResolution][uiDevAbilit], Config_GetCamaraMng()->uiCamDataInputMode);
    }
#ifdef MEDIA_BUFFER_USER_MEMSEA
    if(Media_GetModuleMng()->hMem == MOS_NULL)
    {
        Media_GetModuleMng()->hMem = Mos_MemOwnerCreate(MOS_NULL,(_UC*)"videoCache", VIDEOCACHE_BUF_MID_SIZE);
        Mos_MemOwnerSetPriorSea(Media_GetModuleMng()->hMem, VIDEOCACHE_BUF_UNIT_SIZE, VIDEOPOLLSIZE[uiDevAbilit]);
    }
#endif

    Media_GetModuleMng()->iVideoInit = 1;
    return MOS_OK;
}

// 销毁视频
_INT Media_VideoDestroy()
{
    Media_GetModuleMng()->iVideoInit = 0;
    for (int i=0; i<MAX_CAMERA_ID; i++)
    {
        if (ZJ_GetFuncTable()->pfunVideoSwitch)
        {
            ZJ_GetFuncTable()->pfunVideoSwitch(i, 0);
        }
         Media_GetModuleMng()->hVideoBuf[i].bufferClose();
    }

    if(Media_GetModuleMng()->hMem != MOS_NULL)
    {
        Mos_MemOwnerDel(Media_GetModuleMng()->hMem);
        Media_GetModuleMng()->hMem = MOS_NULL;
    }

    MOS_PRINTF("Media_VideoDestroy ok \r\n");
    return MOS_OK;
}

// 视频清理缓存
_INT Media_VideoCleanBuffer()
{
    for (int i=0; i<MAX_CAMERA_ID; i++)
    {
        if (ZJ_GetFuncTable()->pfunVideoSwitch)
        {
            ZJ_GetFuncTable()->pfunVideoSwitch(i, 0);
        }
        Media_GetModuleMng()->hVideoBuf[i].bufferClean();
        if (ZJ_GetFuncTable()->pfunVideoSwitch)
        {
            ZJ_GetFuncTable()->pfunVideoSwitch(i, 1);
        }
    }
    MOS_PRINTF("Media_VideoCleanBuffer ok \r\n");
    return MOS_OK;
}

// 写入视频帧
_INT Media_WriteVideoFrame(_INT iCamid,_INT iStreamId,_UC *ptFrame,_INT iLen,_UI uiTimeStamp,_UI uiFrameType)
{
    static _INT iFrameCount[][4] = {{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
    if (Media_GetModuleMng()->iVideoInit <= 0)
    {
        return 0;
    }

    MOS_PARAM_VALID_RET(iStreamId, 0, 1, MOS_ERR);

    if ((++iFrameCount[iCamid][iStreamId]) >= 4000)
    {
       MOS_LOG_INF(LOG_MEDIA_CACHE,"camId %d stream %d write frameItype:%u, count:%d",iCamid,iStreamId, uiFrameType, iFrameCount[iCamid][iStreamId] );
       iFrameCount[iCamid][iStreamId] = 0;
    }
#ifdef SUPPORT_CHECK_VENC_TYPE
    if( (uiFrameType==0)
        && *((char*)ptFrame) == 0x00
        && *((char*)(ptFrame + 1)) == 0x00
        && *((char*)(ptFrame + 2)) == 0x00
        && *((char*)(ptFrame + 3)) == 0x01
        && (*((char*)(ptFrame + 4)) == 0x67 ||
            *((char*)(ptFrame + 4)) == 0x40))

    {
        uiFrameType= 1;
    }
#endif
    _INT iRet =  Media_GetModuleMng()->hVideoBuf[iStreamId].writeData(ptFrame, iLen, (uiFrameType==EN_FRAMETYPE_I)?1:0, MOS_NULL, uiTimeStamp);
    if (iRet == -1)//buffer is full
    {
#ifdef SUPPPORT_SAME_LEN_VIDEOBUF
        _INT  iRetryTimes = 0;
        do
        {
            iRetryTimes++;
            iRet =  Media_GetModuleMng()->g_hVideoBuf[iStreamId].readOneVideoGopOk();

            //MOS_PRINTF("%s write buffer full, readgop:%d\n",__FUNCTION__, iRet);
            if (iRetryTimes >= 50)
            {
                iRet =  Media_GetModuleMng()->g_hVideoBuf[iStreamId].readOneVideoGopOk(1);
                MOS_PRINTF("%s write buffer full, readgop: timeout \r\n", __FUNCTION__, iRet);
                break;
            }
            Mos_Sleep(2);
        }while(iRet == -4);
        if (iRet != -4)
        {
           iRet =  Media_GetModuleMng()->g_hVideoBuf[iStreamId].writeData(ptFrame, iLen, false, MOS_NULL, uiTimeStamp);
        }
#endif
    }
    return iRet;
}

// 写入视频Nalu帧
_INT Media_WriteVideoNaluFrame(_INT iCamid,_INT iStreamId,_UC *ptNalu[],_INT iNaluLen[],_INT iNaluNum,_UI uiTimeStamp,_UI uiFrameType)
{
    return MOS_OK;
}

// 设置视频参数
_INT Media_ReSetVideoParameter(_INT iCamid,_INT iStreamId, _UI uiResolution, _UI uiEncType)
{
    if ((iStreamId>=0) && (iStreamId<=1) )
    {
        Media_GetModuleMng()->hVideoBuf[iStreamId].resetMediaParam(uiResolution, uiEncType);
    }
    return MOS_OK;
}

// 获取视频总共读的大小
_INT Media_VideoGetTotalReadNum()
{
    return MOS_OK;
}

_US Media_VideoGetHisReadMsec(_HVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_RETERR(hVideoRead);

    READ_MEDIA_DATA_NODE *hRvideo = (READ_MEDIA_DATA_NODE *)hVideoRead;
    return hRvideo->usHisTimeMsec;
}

_HVIDEOREAD Media_VideoCreatReadHandle2(_INT iCamid,_INT iStreamId,_UI uiReadMod,_UI uiKeyQuality, _UC *pUserName)
{
    READ_MEDIA_DATA_NODE *pstNode = MOS_NULL;
    ST_CFG_VIDEODES *pstVideoDes  = MOS_NULL;
    pstNode = (READ_MEDIA_DATA_NODE *)MOS_MALLOC(sizeof(READ_MEDIA_DATA_NODE));
    pstNode->stFrame = MOS_NULL;
    pstNode->id      = 0;

    pstNode->stDataNode   = MOS_NULL;
    pstNode->iCamid       = iCamid;
    pstNode->iStreamId    = iStreamId;
    pstNode->uiReadMod    = uiReadMod;
    pstNode->uiKeyQuality = uiKeyQuality;
    pstNode->uiMaxHisCount= MAX_HISTORY_VIDEO_FRAME;
    pstNode->usSeqNumIndex= 0;
    pstVideoDes           = Config_GetVideoDes(pstNode->iCamid,pstNode->iStreamId);
    pstNode->uiEncodeType = pstVideoDes->stVideoPara.uiEncodeType;
    pstNode->uiResolution = pstVideoDes->stVideoPara.uiResolution;
    pstNode->id           =  Media_GetModuleMng()->hVideoBuf[iStreamId].setCurrentUsrId(uiReadMod, pUserName, pstVideoDes->stVideoPara.uiFramerate);
    if (pstVideoDes->stVideoPara.uiFramerate == 0)
    {
        MOS_LOG_ERR(LOG_MEDIA_CACHE, "frameRate can't be zero");
    }
    pstNode->usHisTimeMsec= 1000*MAX_HISTORY_VIDEO_FRAME/pstVideoDes->stVideoPara.uiFramerate;

    MOS_LIST_INIT(&pstNode->stNodeList);
    MOS_LOG_INF(LOG_MEDIA_CACHE,">>%s camid:%d streamId:%d mode:%u entype:%u \r\n", __FUNCTION__, iCamid, iStreamId, uiReadMod, pstNode->uiEncodeType);
    return (_HVIDEOREAD)pstNode;
}

static ST_DATA_NODE *Media_GetDataNodeFromeFrame(_HVIDEOREAD hVideoRead, ST_FRAME_NODE *pstNode, _INT iFrmeLen, _INT iTimeStamp)
{
    MOS_PARAM_NULL_RETNULL(hVideoRead);
    MOS_PARAM_NULL_RETNULL(pstNode);

    READ_MEDIA_DATA_NODE *hRvideo  = (READ_MEDIA_DATA_NODE *)hVideoRead;
    ST_DATA_NODE *pcurDataNode     = MOS_NULL;
    ST_DATA_NODE *stDataHeadNode   = MOS_NULL;
    _INT  pucOutLen   = 0;
    _UI   uiListCnt   = 0;
    _UI   uiPackNum   = 0;

    if(pstNode != MOS_NULL)
    {
        ST_FRAME_NODE *pstFrameNode = pstNode;
        while(pstFrameNode != MOS_NULL)
        {
            uiListCnt++;
            uiPackNum   += pstFrameNode->uiNaluLen/MAX_P2PMEDIA_BODY_LEN;
            if (pstFrameNode->uiNaluLen%MAX_P2PMEDIA_BODY_LEN != 0)
            {
                uiPackNum += 1;
            }
            pstFrameNode = pstFrameNode->ptnest;
        }
    }
    ST_FRAME_NODE *pstFrameNode = pstNode;
    for (_INT i=0; i<uiListCnt; i++)
    {
        _INT firstFramSize = pstFrameNode->uiNaluLen;
        if (firstFramSize > MAX_P2PMEDIA_BODY_LEN)
        {
            firstFramSize = MAX_P2PMEDIA_BODY_LEN;
        }

        ST_DATA_NODE *stDataNode = MediaVideoDataNodeInit(Media_GetModuleMng()->hMem, firstFramSize, Media_GetModuleMng()->iMemUnitSize);
        pucOutLen = 0;
        _BOOL bStart = MOS_FALSE;

        if (stDataHeadNode == MOS_NULL)
        {
            bStart = MOS_TRUE;
            stDataHeadNode          = stDataNode;
            stDataNode->uiTimeStamp = iTimeStamp;
            stDataNode->usSeqNum    = (++hRvideo->usSeqNumIndex);
            stDataNode->stFrameNode = *pstFrameNode;
            stDataNode->pstFrameHead= stDataHeadNode;
            pcurDataNode            = stDataNode;
        }
        else
        {
            stDataNode->uiTimeStamp = iTimeStamp;
            stDataNode->usSeqNum    = (++hRvideo->usSeqNumIndex);
            stDataNode->stFrameNode = *pstFrameNode;
            stDataNode->pstFrameHead= stDataHeadNode;
            pcurDataNode->pstnext   = stDataNode;
            pcurDataNode = pcurDataNode->pstnext;
        }


        if (pstFrameNode->uiNaluLen <= MAX_P2PMEDIA_BODY_LEN)//one frame video send
        {
            stDataNode->usFramRemPackect = --uiPackNum;
            stDataNode->stFrameNode.ucFramPos = MD_GETFRAMEHIGH(pstFrameNode->ucFramPos);
            stDataNode->stFrameNode.uiNaluLen = pstFrameNode->uiNaluLen;
            stDataNode->stFrameNode.uiRemFrameLen = pstFrameNode->uiNaluLen;
            stDataNode->stFrameNode.ptDatabuff    = pstFrameNode->ptDatabuff;
            stDataNode->stFrameNode.usDatalen     = iFrmeLen;
            MOS_MEMCPY(stDataNode->ptbuff, pstFrameNode->ptDatabuff, pstFrameNode->uiNaluLen);
            if (bStart)//start frame
            {
                stDataNode->stFrameNode.ucFramPos |=  MD_FRAME_HEAD + MD_NAUL_HEAD;
            }
            else
            {
                stDataNode->stFrameNode.ucFramPos |=  MD_NAUL_HEAD;
            }

            if (i == (uiListCnt-1))//last frame
            {
                stDataNode->stFrameNode.ucFramPos |= MD_FRAME_TAIL + MD_NALU_TAIL;
            }
            else
            {
                stDataNode->stFrameNode.ucFramPos  |=  MD_NALU_TAIL;
            }
        }
        else // large frame, multiy frames
        {

            int packeg_count = pstFrameNode->uiNaluLen/MAX_P2PMEDIA_BODY_LEN ;
            if ((pstFrameNode->uiNaluLen%MAX_P2PMEDIA_BODY_LEN) !=0)
            {
                packeg_count += 1;
            }

            for (int j=0; j<packeg_count; j++)
            {
                ST_DATA_NODE *NextDataNode = MOS_NULL;
                stDataNode->uiTimeStamp = iTimeStamp;
                stDataNode->stFrameNode.ucFramPos  = MD_GETFRAMEHIGH(pstFrameNode->ucFramPos);
                if (j==0 && i == 0)
                {
                    stDataNode->stFrameNode.ucFramPos  |= MD_FRAME_HEAD; //first frame
                    stDataNode->stFrameNode.ucFramPos  |= MD_NAUL_HEAD;
                }

                _INT offset = j*MAX_P2PMEDIA_BODY_LEN;
                _INT dataLen = (j==(packeg_count-1)) ?  (pstFrameNode->uiNaluLen-offset) : MAX_P2PMEDIA_BODY_LEN ;

                stDataNode->usFramRemPackect          = --uiPackNum;
                hRvideo->usSeqNumIndex                += j>0?1:0;
                stDataNode->stFrameNode.usDatalen     = iFrmeLen;
                stDataNode->stFrameNode.uiNaluLen     = dataLen;
                stDataNode->stFrameNode.uiRemFrameLen = dataLen;
                stDataNode->stFrameNode.ptDatabuff    = pstFrameNode->ptDatabuff+offset;
                stDataNode->usSeqNum    = (hRvideo->usSeqNumIndex);//%0xffff;
                stDataNode->pstFrameHead= stDataHeadNode;
                MOS_MEMCPY(stDataNode->ptbuff, pstFrameNode->ptDatabuff+offset, dataLen);

                if (i == (uiListCnt-1) && j==(packeg_count-1))
                {
                    stDataNode->stFrameNode.ucFramPos  |= MD_FRAME_TAIL + MD_NALU_TAIL;
                }
                else
                {
                    stDataNode->stFrameNode.ucFramPos  |= (j == 0)?MD_NAUL_HEAD:0;
                }

                //MOS_PRINTF("111Time:%u, seq:%u, off:%u, framePos:%02x, nalLen:%d \r\n", stDataNode->uiTimeStamp, stDataNode->usSeqNum, stDataNode->usOffset,
                //          stDataNode->stFrameNode.ucFramPos, stDataNode->stFrameNode.uiNaluLen);

               if (j != (packeg_count-1))
               {
                   if (j == (packeg_count-2))
                   {
                       dataLen = (pstFrameNode->uiNaluLen - ((packeg_count-1)*MAX_P2PMEDIA_BODY_LEN));
                   }
                   NextDataNode = MediaVideoDataNodeInit(Media_GetModuleMng()->hMem, dataLen,Media_GetModuleMng()->iMemUnitSize);
                   pcurDataNode->pstnext = NextDataNode;
                   pcurDataNode = pcurDataNode->pstnext;
                   stDataNode   = NextDataNode;
               }
            }
        }

        pstFrameNode = pstFrameNode->ptnest;
    }
    return stDataHeadNode;
}

ST_FRAME_NODE *Media_VideoCreatFrame(_UC *DataBuf, _INT DataBufLen, _UI uiLastResolution, _UI uiCurResolution, _UI uiLastEncType, _UC ucCurEncType)
{
    MEDIA_VIDEO_NALU hMediaNalu[5] = {0};
    ST_FRAME_NODE * stFrame = MOS_NULL;
    _INT nal_start = 0;
    _INT nal_end  = 0;
    _UC  *p = DataBuf;
    _INT sz = DataBufLen;
    _INT naul_count = 0;
    //fullfill naul infomation
    while (find_nal_unit(p, sz, &nal_start, &nal_end) > 0)
    {
        if (naul_count++ >= (sizeof(hMediaNalu)/sizeof(hMediaNalu[0]) - 1))
        {
            MOS_BUFPRINTF("Nalu_count over array", DataBuf, (DataBufLen>100)?100:DataBufLen);
            return MOS_NULL;
        }
        _INT naulLen = (nal_end - nal_start);
        hMediaNalu[naul_count-1].naluType = p[nal_start];//&0x1f;
        hMediaNalu[naul_count-1].naluBuf  = p;
        hMediaNalu[naul_count-1].naluLength = naulLen+nal_start;

        p += nal_start;
        // MOS_PRINTF("111find nalcount:%d start:%d end:%d, len:%d %02x \r\n", naul_count, nal_start, nal_end,hMediaNalu[naul_count-1].naluLength, p[0]& 0x1f);
        p += (nal_end - nal_start);
        sz -= nal_end;
    }

    naul_count ++;
    _INT naulLen = (nal_end - nal_start);
    hMediaNalu[naul_count-1].naluType = p[nal_start];//&0x1f;
    hMediaNalu[naul_count-1].naluBuf = p;
    hMediaNalu[naul_count-1].naluLength = naulLen+nal_start;

    for (_INT i=0; i<naul_count; i++)
    {
        ST_FRAME_NODE *st_frame_node = MediaVideoFrameInit();
        if (ucCurEncType == EN_ZJ_VIDEOENC_TYPE_H265)
        {
            char nNalType = ((hMediaNalu[i].naluType >> 1) & 0x3F);
            switch (nNalType)
            {
                case NAL_HEVC_VPS: // VPS
                    st_frame_node->ucFramPos = EN_FRAMETYPE_I << 4;
                    st_frame_node->ucFramPos |=  (FRAME_START + NAL_START + NAL_END);
                    break;
                case NAL_HEVC_PPS: // PPS
                case NAL_SEI_PREFIX:
                case NAL_SEI_SUFFIX: // SEI
                case NAL_HEVC_SPS: // SPS
                   st_frame_node->ucFramPos = EN_FRAMETYPE_I << 4;
                   st_frame_node->ucFramPos |= (FRAME_START + NAL_START + NAL_END);
                   break;

                case NAL_IDR_W_RADL: //IDR
                   st_frame_node->ucFramPos = EN_FRAMETYPE_I << 4;
                   st_frame_node->ucFramPos |= (FRAME_START + NAL_START + NAL_END);
                   break;

                default :
                    st_frame_node->ucFramPos = EN_FRAMETYPE_P << 4;
                    st_frame_node->ucFramPos |= (FRAME_START + NAL_START + NAL_END);
                    break;
            }
        }
        else
        {
            char frame_type = (hMediaNalu[i].naluType & 0x1f);
            st_frame_node->ucFramPos = EN_FRAMETYPE_P << 4;
            switch(frame_type)
            {
            case NAL_SPS:
            case NAL_PPS:
            case NAL_SEI:
            case NAL_IDR_SLICE:
                st_frame_node->ucFramPos = EN_FRAMETYPE_I << 4;
                st_frame_node->ucFramPos |= (FRAME_START + NAL_START + NAL_END);
                break;

            default:
                st_frame_node->ucFramPos = EN_FRAMETYPE_P << 4;
                st_frame_node->ucFramPos |= (FRAME_START + NAL_START + NAL_END);
                break;
            }
        }

		if (uiLastResolution != uiCurResolution)
		{
			MOS_PRINTF("uiLastResolution = %u  uiCurResolution = %u\n",uiLastResolution,uiCurResolution);
            st_frame_node->ucVideoResolutionChangeFlag = EN_VIDEOPARAM_CHANGED_RES;
		}
		if (uiLastEncType != ucCurEncType)
		{
		
			MOS_PRINTF("uiLastEncType = %u  ucCurEncType = %d\n",uiLastEncType,ucCurEncType);
            st_frame_node->ucVideoResolutionChangeFlag = EN_VIDEOPARAM_CHANGED_ENC;
		}

        st_frame_node->ptDatabuff    = hMediaNalu[i].naluBuf;
        st_frame_node->uiRemFrameLen = hMediaNalu[i].naluLength;
        st_frame_node->usDatalen = hMediaNalu[i].naluLength;
        st_frame_node->uiNaluLen = hMediaNalu[i].naluLength;
        st_frame_node->ptnest    = MOS_NULL;

        if (stFrame != MOS_NULL)
        {
            ST_FRAME_NODE *nextNode = stFrame;
            while (true)
            {
                if (nextNode->ptnest == MOS_NULL)
                    break;
                nextNode = nextNode->ptnest;
            }
            nextNode->ptnest = st_frame_node;
        }
        else
        {
            stFrame = st_frame_node;
            stFrame->ptnest = MOS_NULL;
        }
    }
    return stFrame;
}

// 获取视频一个节点
ST_DATA_NODE *Media_VideoGetOneNode(_HVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_RETNULL(hVideoRead);

    READ_MEDIA_DATA_NODE *pstNode = (READ_MEDIA_DATA_NODE *)hVideoRead;

    _INT    ret         = -1;
    _UC    *DataBuf     = NULL;
    _INT    DataBufLen  = 0;
    _INT    Id          = pstNode->id;
    _INT    IsKeyFrame  = 0;
	_UI 	uiResolution= 0;
	_UI 	uiEncType	= 0;
    pstNode->stFrame    = MOS_NULL;
    pstNode->stDataNode = MOS_NULL;
    _INT iTimeStamp1    = 0;

    // 读一Frame数据，需要分成多个NALU
    ret =  Media_GetModuleMng()->hVideoBuf[pstNode->iStreamId].readData(&(DataBuf), &(DataBufLen), (_INT)(Id), &IsKeyFrame, MOS_NULL, &iTimeStamp1, MOS_NULL, &uiResolution, &uiEncType);
    if (ret == 0)
    {
        pstNode->stFrame    = Media_VideoCreatFrame(DataBuf, DataBufLen, pstNode->uiResolution, uiResolution, pstNode->uiEncodeType, uiEncType);
		pstNode->uiResolution = uiResolution;
		pstNode->uiEncodeType = uiEncType;
        pstNode->stDataNode = Media_GetDataNodeFromeFrame(hVideoRead, pstNode->stFrame, DataBufLen, iTimeStamp1);

        if(pstNode->stFrame != MOS_NULL)
        {
            ST_FRAME_NODE *pstFrameNode = pstNode->stFrame;
            while(pstFrameNode != MOS_NULL)
            {
                ST_FRAME_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->ptnest;
                MOS_FREE(pstTmpNode);
            }
        }
        return pstNode->stDataNode;
    }
    else
    {
        return MOS_NULL;
    }
}


// 释放当前节点
_VOID Media_VideoSetNodeUsed(_HVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_NORET(hVideoRead);

    READ_MEDIA_DATA_NODE *pstNode = (READ_MEDIA_DATA_NODE *)hVideoRead;
    _UI uiListCnt = 0;
    if(pstNode->stDataNode != MOS_NULL)
    {
        //This nodes need free where used in outside
//        ST_DATA_NODE *pstFrameNode = pstNode->stDataNode;
//        while(pstFrameNode != MOS_NULL)
//        {
//            uiListCnt++;
//            ST_DATA_NODE *pstTmpNode = pstFrameNode;
//            pstFrameNode = pstFrameNode->pstnext;
//            MOS_FREE(pstTmpNode);
//        }
        pstNode->stDataNode = MOS_NULL;
        Media_GetModuleMng()->hVideoBuf[pstNode->iStreamId].readOk(pstNode->id);
    }

    return;
}

// 偏移到下个节点
_VOID Media_VideoShiftNextNode(_HVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_NORET(hVideoRead);

    return;
}

ST_DATA_NODE * Media_VideoHisGetPackNode(_HVIDEOREAD hVideoRead, _UI packgSeqNum)
{
    MOS_PARAM_NULL_RETNULL(hVideoRead);
    
    READ_MEDIA_DATA_NODE *pstMedia   = (READ_MEDIA_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    ST_MOS_LIST_ITERATOR stIterator;
    ST_DATA_NODE  *pstDataNode       = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
    {      
        _UI minSeq  = stOneNodeInfo->stHdataNode->pstFrameHead->usSeqNum;         // 重传数据的起始包的序号
        _UI FramRem = stOneNodeInfo->stHdataNode->pstFrameHead->usFramRemPackect; // 重传数据的剩余包数，如起始包的序号为100，剩余包数为100，则改重传数据的序号范围是[100,200],共201个包

        if ((USSHORT_MAX - minSeq) >= FramRem)/*重传数据的包序号的范围在0-65535区间，如[65500,65535],即判断需要重传的包是否在此范围即可*/
        {
            _UI maxSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usFramRemPackect+minSeq;
            if (packgSeqNum >= minSeq && packgSeqNum <= maxSeq)
            {
                //MOS_PRINTF("found noddep packet!!");
                ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
                while(pstFrameNode != MOS_NULL)
                {
                    if (pstFrameNode->usSeqNum == packgSeqNum)
                    {
                        //MOS_PRINTF("found seq:%u firtseq:%u cuseq:%d \r\n", pstFrameNode->usSeqNum, pstFrameNode->pstFrameHead->usSeqNum, packgSeqNum);
                        pstDataNode = pstFrameNode;
                        break;
                    }
                    pstFrameNode = pstFrameNode->pstnext;
                }
                break;
            }
        }
        else/*重传数据的包序号溢出情况，即包序号大于65535时，会重新从0开始*/
        {
            _UI uiOverPackNum = stOneNodeInfo->stHdataNode->pstFrameHead->usFramRemPackect - (USSHORT_MAX - minSeq);/*溢出后的计算范围*/
            if (((packgSeqNum >= minSeq) && (packgSeqNum <= USSHORT_MAX))
                || ((packgSeqNum >= 0) && (packgSeqNum < uiOverPackNum)))
            {
                ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
                while(pstFrameNode != MOS_NULL)
                {
                    if (pstFrameNode->usSeqNum == packgSeqNum)
                    {
                        pstDataNode = pstFrameNode;
                        break;
                    }
                    pstFrameNode = pstFrameNode->pstnext;
                }
                break;
            }
        }       
    }
    return pstDataNode;
}

_VOID Media_VideoHisAddOneNode(_HVIDEOREAD hVideoRead, ST_DATA_NODE *pstDataNode)
{
    MOS_PARAM_NULL_NORET(hVideoRead);

    READ_MEDIA_DATA_NODE *pstMedia   = (READ_MEDIA_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

     stOneNodeInfo = (ST_DATA_NODE_INFO*)MOS_MALLOCCLR(sizeof(ST_DATA_NODE_INFO));
     stOneNodeInfo->stHdataNode = pstDataNode;

     if (pstMedia->stNodeList.uiTotalCount >= pstMedia->uiMaxHisCount)
     {
         Media_VideoHisDelHeadNode(hVideoRead);
     }

     MOS_LIST_ADDTAIL(&pstMedia->stNodeList, stOneNodeInfo);
     // MOS_PRINTF("%s node size:%d \r\n",__FUNCTION__, pstMedia->stNodeList.uiTotalCount);

     return;
}


_VOID Media_VideoHisDelHeadNode(_HVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_NORET(hVideoRead);

    READ_MEDIA_DATA_NODE *pstMedia   = (READ_MEDIA_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    stOneNodeInfo = MOS_LIST_RMVHEAD(&pstMedia->stNodeList);
    if (stOneNodeInfo != MOS_NULL)
    {
        if(stOneNodeInfo->stHdataNode != MOS_NULL)
        {
            ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
            while(pstFrameNode != MOS_NULL)
            {
                ST_DATA_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->pstnext;
                Media_FreeDataNode(Media_GetModuleMng()->hMem, pstTmpNode, Media_GetModuleMng()->iMemUnitSize);
            }
        }
        MOS_FREE(stOneNodeInfo);
    }

    return;
}

_VOID Media_VideoHisDelAllNode(_HVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_NORET(hVideoRead);

    READ_MEDIA_DATA_NODE *pstMedia = (READ_MEDIA_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    while (MOS_LIST_GETCOUNT(&pstMedia->stNodeList)>0)
    {
        stOneNodeInfo = MOS_LIST_RMVHEAD(&pstMedia->stNodeList);
        if (stOneNodeInfo != MOS_NULL)
        {
            ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
            while(pstFrameNode != MOS_NULL)
            {
                ST_DATA_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->pstnext;
                Media_FreeDataNode(Media_GetModuleMng()->hMem, pstTmpNode, Media_GetModuleMng()->iMemUnitSize);
            }
            MOS_FREE(stOneNodeInfo);
        }
        else
        {
            break;
        }
    }

    return;
}

// 释放指定的节点
_VOID Media_VideoSetNodeUsedEx(_HVIDEOREAD hVideoRead,ST_DATA_NODE* pstDataNode)
{
    MOS_PARAM_NULL_NORET(hVideoRead);

    return;
}

/*读句柄 的销毁*/
_INT Media_VideoDestroyReadHandle2(_HVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_RETERR(hVideoRead);
    
    READ_MEDIA_DATA_NODE *pstMedia = (READ_MEDIA_DATA_NODE *)hVideoRead;
     Media_GetModuleMng()->hVideoBuf[pstMedia->iStreamId].closeCurrentUsrid(pstMedia->id);

    pstMedia->id = -1;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
    {
        ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
        while(pstFrameNode != MOS_NULL)
        {
            ST_DATA_NODE *pstTmpNode = pstFrameNode;
            pstFrameNode = pstFrameNode->pstnext;
            Media_FreeDataNode(Media_GetModuleMng()->hMem, pstTmpNode, Media_GetModuleMng()->iMemUnitSize);
        }
    }
    MOS_LIST_RMVALL(&pstMedia->stNodeList, MOS_TRUE);
    MOS_FREE(pstMedia);

    return MOS_OK;
}

/**** 读取 一个视频帧  返回 值 小于 0  表示 出错  ， 0 表示  没有数据 ,大于 0  表示 读取正确****/
_INT Media_VideoGetFrame2(_HVIDEOREAD hVideoRead,_OUT ST_FRAME_NODE **pucFrameHead,_OUT _INT *puiTimestamp,_OUT _LLID  *llTimePts)
{
    MOS_PARAM_NULL_RETERR(hVideoRead);

    _INT              ret         = 0;
    READ_MEDIA_DATA_NODE *pstNode = (READ_MEDIA_DATA_NODE *)hVideoRead;

    _UC    *DataBuf    = NULL;
    _INT    DataBufLen = 0;
    _INT    Id         = pstNode->id;
    _INT    IsKeyFrame = 0;
	_UI 	uiResolution = 0;
	_UI 	uiEncType	 = 0;

    if (pstNode!=MOS_NULL && pstNode->uiReadMod == EN_READ_COMMON)
    {
        if ( pstNode->stFrame != MOS_NULL)
        {
            *puiTimestamp = pstNode->uiTimeStamp;
            *pucFrameHead = pstNode->stFrame;
            return DataBufLen;
        }
    }
    pstNode->stFrame = MOS_NULL;
    // 读一Frame数据，需要分成多个NALU
    ret =  Media_GetModuleMng()->hVideoBuf[pstNode->iStreamId].readData(&(DataBuf), &(DataBufLen), (_INT)(Id), &IsKeyFrame, MOS_NULL, puiTimestamp, llTimePts, &uiResolution, &uiEncType);
    if (ret == 0)
    {
        pstNode->stFrame     = Media_VideoCreatFrame(DataBuf, DataBufLen, pstNode->uiResolution, uiResolution, pstNode->uiEncodeType,uiEncType);
        if(pstNode->stFrame == MOS_NULL)
        {
            MOS_PRINTF("%s %d Media_VideoCreatFrame error!\n", __func__, __LINE__);
            *pucFrameHead = MOS_NULL;
            return MOS_ERR;
        }
		pstNode->uiResolution = uiResolution;
		pstNode->uiEncodeType = uiEncType;
        pstNode->uiTimeStamp  = *puiTimestamp;
        pstNode->llTimePts    = *llTimePts;
        *pucFrameHead = pstNode->stFrame;
        return DataBufLen;
    }
    else
    {
        *puiTimestamp = 0;
        pstNode->stFrame = MOS_NULL;
        *pucFrameHead = MOS_NULL;
        return MOS_ERR;
    }
}

/**** 读取 一个视频帧  返回 值 小于 0  表示 出错  ， 0 表示  没有数据 ,大于 0  表示 读取正确****/
_INT Media_GetVideoBufferFrameNode(_OUT ST_FRAME_NODE **stFrameOut,  _UC *DataBuf, _INT DataBufLen, _UI uiLastResolution, _UI uiCurResolution, _UI uiLastEncType, _UC ucCurEncType)
{
    ST_FRAME_NODE *stFrame = MOS_NULL;
    // 读一Frame数据，需要分成多个NALU
    if ((DataBuf != MOS_NULL) && (DataBufLen>0))
    {
        stFrame     =  Media_VideoCreatFrame(DataBuf, DataBufLen, uiLastResolution, uiCurResolution, uiLastEncType,ucCurEncType);
        if(stFrame == MOS_NULL)
        {
            MOS_PRINTF("%s %d Media_VideoCreatFrame error!\n", __func__, __LINE__);
            *stFrameOut = MOS_NULL; 
            return MOS_ERR;
        }
        *stFrameOut = stFrame;        
        return DataBufLen;
    }
    else
    {
        stFrame     = MOS_NULL;
        *stFrameOut = MOS_NULL;
        return MOS_ERR;
    }
}

_VOID Media_FreeVideoBufferFrameNode(ST_FRAME_NODE *stFrameIn)
{
    if(stFrameIn != MOS_NULL)
    {
        ST_FRAME_NODE *pstFrameNode = stFrameIn;
        while(pstFrameNode != MOS_NULL)
        {
            ST_FRAME_NODE *pstTmpNode = pstFrameNode;
            pstFrameNode = pstFrameNode->ptnest;
            MOS_FREE(pstTmpNode);
        } 
    }
}


// 设置视频帧为使用，释放资源
_VOID Media_VideoSetFrameUsed2(_HVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_NORET(hVideoRead);

    READ_MEDIA_DATA_NODE *pstNode = (READ_MEDIA_DATA_NODE *)hVideoRead;

    if (pstNode->uiReadMod == EN_READ_COMMON)
    {
        if(pstNode->stFrame != MOS_NULL)
        {
            ST_FRAME_NODE *pstFrameNode = pstNode->stFrame;
            if (pstFrameNode != MOS_NULL)
            {
                ST_FRAME_NODE *pstTmpNodeOri = pstFrameNode;
                pstFrameNode = pstFrameNode->ptnest;
                pstNode->stFrame = pstFrameNode;
                MOS_FREE(pstTmpNodeOri);
            }

            if (pstFrameNode == MOS_NULL)
            {
                pstNode->stFrame = MOS_NULL;
                 Media_GetModuleMng()->hVideoBuf[pstNode->iStreamId].readOk(pstNode->id);
            }
        }
    }
    else
    {
        _UI uiListCnt = 0;
        if(pstNode->stFrame != MOS_NULL)
        {
            ST_FRAME_NODE *pstFrameNode = pstNode->stFrame;
            while(pstFrameNode != MOS_NULL)
            {
                uiListCnt++;
                ST_FRAME_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->ptnest;
                MOS_FREE(pstTmpNode);
            }

            if (pstFrameNode == MOS_NULL)
            {
                pstNode->stFrame = MOS_NULL;
                 Media_GetModuleMng()->hVideoBuf[pstNode->iStreamId].readOk(pstNode->id);
            }
        }
    }
    return;
}
