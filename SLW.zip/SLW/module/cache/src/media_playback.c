#include "media_playback.h"
//#include "media_video.h"

_HPBVIDEOREAD Media_SdVideoCreatReadHandle(_UI uiReadMod)
{
    READ_PLAYBACK_DATA_NODE *pstNode = MOS_NULL;
    pstNode = (READ_PLAYBACK_DATA_NODE *)MOS_MALLOC(sizeof(READ_PLAYBACK_DATA_NODE));
    pstNode->stFrame      = MOS_NULL;
    pstNode->id           = 0;
    pstNode->stDataNode   = MOS_NULL;
    pstNode->uiReadMod    = uiReadMod;
    pstNode->uiMaxHisCount= uiReadMod==1?MAX_PLAYBACK_VIDEO_FRAME:MAX_PLAYBACK_AUDIO_FRAME;
    pstNode->usSeqNumIndex= 0;
    pstNode->uiIsFirst    = 1;
    pstNode->stDataNode   = MOS_NULL;
    pstNode->stNode       = MOS_NULL;
    MOS_LIST_INIT(&pstNode->stNodeList);
    MOS_LOG_INF(LOG_MEDIA_CACHE, ">>%s mode:%u [1-video,2-audio] \n", __FUNCTION__, uiReadMod);
    return (_HPBVIDEOREAD)pstNode;
}

_INT Media_SdVideoDestroyReadHandle(_HPBVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_RETERR(hVideoRead);
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;

    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
    {
        ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
        while(pstFrameNode != MOS_NULL)
        {
            ST_DATA_NODE *pstTmpNode = pstFrameNode;
            pstFrameNode = pstFrameNode->pstnext;
            MOS_FREE(pstTmpNode);
        }
    }
    MOS_LIST_RMVALL(&pstMedia->stNodeList, MOS_TRUE);
    MOS_FREE(pstMedia);
    return MOS_OK;
}

_INT Media_SdVideoWriteAvailable(_HPBVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_RETERR(hVideoRead);
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    if (pstMedia->stNodeList.uiTotalCount < pstMedia->uiMaxHisCount)
    {
        return MOS_TRUE;
    }
    return MOS_FALSE;
}

_INT Media_SdVideoWriteEmpty(_HPBVIDEOREAD hVideoRead)
{
    MOS_PARAM_NULL_RETERR(hVideoRead);
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    if (pstMedia->stNodeList.uiTotalCount == 0)
    {
        return MOS_TRUE;
    }
    return MOS_FALSE;
}

//make one node
ST_DATA_NODE * Media_SdVideoMakeOneNode(_HPBVIDEOREAD hVideoRead, _UC *ucBuf, _UI uiBufLen,
                                        _UI uiTimeStamp, _UC ucFramePos, _UI uiFrmameLen)
{
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE *pstDataNode = MediaVideoDataNodeInit( MOS_NULL, uiBufLen, 0);
    pstDataNode->stFrameNode.ucVideoResolutionChangeFlag = EN_VIDEOPARAM_CHANGED_NONE;
    pstDataNode->stFrameNode.ucFramPos = ucFramePos;
    pstDataNode->stFrameNode.usDatalen = uiFrmameLen;
    pstDataNode->stFrameNode.uiNaluLen = uiBufLen;
    pstDataNode->stFrameNode.uiRemFrameLen = uiBufLen;

    pstDataNode->uiTimeStamp= uiTimeStamp;
    pstDataNode->usOffset   = 0;
    pstDataNode->usSeqNum   = (pstMedia->uiIsFirst==1)?pstMedia->usSeqNumIndex:++pstMedia->usSeqNumIndex;
    pstMedia->uiIsFirst     = 0;
    pstDataNode->usFramRemPackect = 0;
    pstDataNode->usSkpLen     = 0;
    pstDataNode->pstFrameHead = pstDataNode;
    pstDataNode->pstnext      = MOS_NULL;
    pstDataNode->aucUseFlag[0]=0;
    MOS_MEMCPY(pstDataNode->ptbuff, ucBuf, uiBufLen);
    return pstDataNode;
}

//add one node in to history data node
_VOID Media_SdVideoHisAddOneNode(_HPBVIDEOREAD hVideoRead, ST_DATA_NODE *pstDataNode)
{
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

     stOneNodeInfo = (ST_DATA_NODE_INFO*)MOS_MALLOCCLR(sizeof(ST_DATA_NODE_INFO));
     stOneNodeInfo->stHdataNode = pstDataNode;

     if (pstMedia->stNodeList.uiTotalCount >= pstMedia->uiMaxHisCount)
     {
         Media_SdVideoHisDelHeadNode(hVideoRead);
     }

     MOS_LIST_ADDTAIL(&pstMedia->stNodeList, stOneNodeInfo);
}

_VOID Media_SdVideoHisDelHeadNode(_HPBVIDEOREAD hVideoRead)
{
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    stOneNodeInfo = MOS_LIST_RMVHEAD(&pstMedia->stNodeList);

    ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
    while(pstFrameNode != MOS_NULL)
    {
        ST_DATA_NODE *pstTmpNode = pstFrameNode;
        pstFrameNode = pstFrameNode->pstnext;
        MOS_FREE(pstTmpNode);
    }
    MOS_FREE(stOneNodeInfo);
}

//find packNum in each list
ST_DATA_NODE * Media_SdVideoHisGetPackNode(_HPBVIDEOREAD hVideoRead, _UI packgSeqNum)
{
    READ_PLAYBACK_DATA_NODE *pstMedia= (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;
    ST_DATA_NODE  *pstDataNode       = MOS_NULL;

    ST_MOS_LIST_ITERATOR stIterator;
    FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
    {
        _INT minSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usSeqNum;
        _INT maxSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usFramRemPackect+minSeq;
        if (packgSeqNum >= minSeq && packgSeqNum <= maxSeq)
        {
            ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
            while(pstFrameNode != MOS_NULL)
            {
                if (pstFrameNode->usSeqNum == packgSeqNum)
                {
                    MOS_PRINTF("found seq:%u firtseq:%u cuseq:%u\n", pstFrameNode->usSeqNum, pstFrameNode->pstFrameHead->usSeqNum, packgSeqNum);
                    pstDataNode = pstFrameNode;
                    break;
                }
                pstFrameNode = pstFrameNode->pstnext;
            }
            break;
        }
        else
        {
            //MOS_PRINTF("notund noddep packet min:%u max:%u tofound:%u\n", minSeq, maxSeq, packgSeqNum);

        }
    }
    return pstDataNode;
}

ST_DATA_NODE_INFO * Media_SdVideoHisGetPackNode2(_HPBVIDEOREAD hVideoRead, _UI packgSeqNum)
{
    READ_PLAYBACK_DATA_NODE *pstMedia   = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;
    ST_DATA_NODE_INFO  *pstDataNode       = MOS_NULL;
    ST_MOS_LIST_ITERATOR stIterator;
    FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
    {
        if (stOneNodeInfo->stHdataNode->aucUseFlag[0] == 0) //add by hejh 0329
        {
            break;
        }
        _INT minSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usSeqNum;
        _INT maxSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usFramRemPackect+minSeq;
        if (packgSeqNum >= minSeq && packgSeqNum <= maxSeq)
        {
            ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
            while(pstFrameNode != MOS_NULL)
            {
                if (pstFrameNode->usSeqNum == packgSeqNum)
                {
                    //MOS_PRINTF("found seq:%u firtseq:%u cuseq:%u\n", pstFrameNode->usSeqNum, pstFrameNode->pstFrameHead->usSeqNum, packgSeqNum);
                    pstDataNode = stOneNodeInfo;
                    break;
                }
                pstFrameNode = pstFrameNode->pstnext;
            }
            break;
        }
        else
        {
            //MOS_PRINTF("notund noddep packet min:%u max:%u tofound:%u\n", minSeq, maxSeq, packgSeqNum);

        }
    }

    return pstDataNode;
}

//find packNum in each list
_VOID  Media_SdVideoDelHisPackNode(_HPBVIDEOREAD hVideoRead, _UI packgSeqNum)
{
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    stOneNodeInfo = Media_SdVideoHisGetPackNode2(hVideoRead, packgSeqNum);
    if (stOneNodeInfo != MOS_NULL)
    {
        MOS_LIST_RMVNODE(&pstMedia->stNodeList, stOneNodeInfo);
        ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
        while(pstFrameNode != MOS_NULL)
        {
            ST_DATA_NODE *pstTmpNode = pstFrameNode;
            pstFrameNode = pstFrameNode->pstnext;
            MOS_FREE(pstTmpNode);
        }
        MOS_FREE(stOneNodeInfo);
    }
}

_UI Media_SdDelSeqList(ST_MOS_LIST *pstDelSeqList, _US usSeqNum)
{
    ST_MOS_LIST_ITERATOR stIterator;
    ST_DATA_PACKAGE_INFO *pstPackInfo = MOS_NULL;
    _UI uiRet = MOS_FALSE;
    FOR_EACHDATA_INLIST(pstDelSeqList, pstPackInfo, stIterator)
    {
        if (pstPackInfo->uiPackNum == usSeqNum)
        {
            MOS_LIST_RMVNODE(pstDelSeqList, pstPackInfo);
            //TODO pstPackInfo delete outside
            uiRet = MOS_TRUE;
            break;
        }
    }
    return uiRet;
}

_VOID  Media_SdVideoDelListNodes(_HPBVIDEOREAD hVideoRead, ST_MOS_LIST *pstDelSeqList)
{
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    if ((pstDelSeqList != MOS_NULL) && (pstDelSeqList->uiTotalCount>0))
    {
        ST_MOS_LIST_ITERATOR stIterator;
        FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
        {
            _INT minSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usSeqNum;
            _UC  ucInUsed = stOneNodeInfo->stHdataNode->aucUseFlag[0];
            if ((ucInUsed==1) && (Media_SdDelSeqList(pstDelSeqList, minSeq)==MOS_TRUE))
            {
                //MOS_PRINTF("%s delete :%d\n", __FUNCTION__, minSeq);
                MOS_LIST_RMVNODE(&pstMedia->stNodeList, stOneNodeInfo);
                ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
                while(pstFrameNode != MOS_NULL)
                {
                    ST_DATA_NODE *pstTmpNode = pstFrameNode;
                    pstFrameNode = pstFrameNode->pstnext;
                    MOS_FREE(pstTmpNode);
                }
                MOS_FREE(stOneNodeInfo);
                if (pstDelSeqList->uiTotalCount <= 0)
                {
                    break;
                }
            }
            else if (ucInUsed == 0)//add by hejh 0329
            {
                break;
            }
        }
        return;
    }
    else
    {
        return;
    }
}


ST_DATA_NODE * Media_SdVideoHisGetHead(_HPBVIDEOREAD hVideoRead)
{
    READ_PLAYBACK_DATA_NODE *pstMedia   = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO  *pstDataNode = MOS_LIST_GETHEAD(&pstMedia->stNodeList);
    if (pstDataNode != MOS_NULL)
    {
        pstMedia->stNode = &pstDataNode->stNode;
        return pstDataNode->stHdataNode;
    }
    else
    {
        return MOS_NULL;
    }
}

ST_DATA_NODE * Media_SdVideoHisShiftNextNode(_HPBVIDEOREAD hVideoRead)
{
    READ_PLAYBACK_DATA_NODE *pstMedia   = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO  *pstDataNode = ( ST_DATA_NODE_INFO *)MOS_LIST_GETNEXT(&pstMedia->stNodeList, pstMedia->stNode);
    if (pstDataNode != MOS_NULL)
    {
        pstMedia->stNode = &pstDataNode->stNode;
        return pstDataNode->stHdataNode;
    }
    return MOS_NULL;
}

_INT Media_SdVideoDelMultiyNodeOld(_HPBVIDEOREAD hVideoRead, _US startPackgSeqNum)
{
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;
    stOneNodeInfo = Media_SdVideoHisGetPackNode2(hVideoRead, startPackgSeqNum);
    if (stOneNodeInfo != MOS_NULL)
    {
        ST_MOS_LIST_ITERATOR stIterator;
        FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
        {
            _INT minSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usSeqNum;
            _UC  ucInUsed = stOneNodeInfo->stHdataNode->aucUseFlag[0];
            if (/*(startPackgSeqNum != minSeq) &&*/ (ucInUsed==1))
            {
                MOS_LIST_RMVNODE(&pstMedia->stNodeList, stOneNodeInfo);
                ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
                while(pstFrameNode != MOS_NULL)
                {
                    ST_DATA_NODE *pstTmpNode = pstFrameNode;
                    pstFrameNode = pstFrameNode->pstnext;
                    MOS_FREE(pstTmpNode);
                }
                MOS_FREE(stOneNodeInfo);
                if (startPackgSeqNum == minSeq)
                {
                    MOS_PRINTF("need remove seq:%u start:%u\n", minSeq, startPackgSeqNum);
                    break;
                }
            }
            else if (startPackgSeqNum == minSeq)
            {
                break;
            }
            else if (ucInUsed == 0)
            {
                break;
            }
        }
        return MOS_TRUE;
    }
    else
    {
        //MOS_PRINTF("##############NOT FOUNT PACKEG %d\n", startPackgSeqNum);
        return MOS_FALSE;
    }
}
_INT Media_SdVideoDelMultiyNode(_HPBVIDEOREAD hVideoRead, _US startPackgSeqNum)
{
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;
    stOneNodeInfo = Media_SdVideoHisGetPackNode2(hVideoRead, startPackgSeqNum);
    if (stOneNodeInfo == MOS_NULL)
    {
        //MOS_PRINTF("##############NOT FOUNT PACKEG %d\n", startPackgSeqNum);
    }

    {
        ST_MOS_LIST_ITERATOR stIterator;
        //ST_DATA_NODE_INFO  *pstDataNode = MOS_LIST_GETHEAD(&pstMedia->stNodeList);
        FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
        {
            _US minSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usSeqNum;
            _UC  ucInUsed = stOneNodeInfo->stHdataNode->aucUseFlag[0];
            _US  usNum = startPackgSeqNum - minSeq ;//小于32767
            if (/*(startPackgSeqNum != minSeq) &&*/ (ucInUsed==1) && (usNum<32767))
            {
                MOS_LIST_RMVNODE(&pstMedia->stNodeList, stOneNodeInfo);
                ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
                while(pstFrameNode != MOS_NULL)
                {
                    ST_DATA_NODE *pstTmpNode = pstFrameNode;
                    pstFrameNode = pstFrameNode->pstnext;
                    MOS_FREE(pstTmpNode);
                }
                MOS_FREE(stOneNodeInfo);
                if (startPackgSeqNum == minSeq)
                {
                    //MOS_PRINTF("11need remove seq:%u start:%u, usNum:%d, ucInUsed:%d\n", minSeq, startPackgSeqNum, usNum, ucInUsed);
                    break;
                }
//                else
//                    MOS_PRINTF("222need remove seq:%u start:%u, usNum:%d, ucInUsed:%d\n", minSeq, startPackgSeqNum, usNum, ucInUsed);
            }
            else if ((startPackgSeqNum == minSeq) || (ucInUsed == 0))
            {
                //MOS_PRINTF("break; startcheck seq:%u start:%u, usNum:%d, ucInUsed:%d\n", minSeq, startPackgSeqNum, usNum, ucInUsed);
                break;
            }
//            else
//            {
//                MOS_PRINTF("not delete need remove seq:%u start:%u, usNum:%d, ucInUsed:%d\n", minSeq, startPackgSeqNum, usNum, ucInUsed);
//            }
        }
        return MOS_TRUE;
    }
}

_INT Media_SdVideoDelAllNode(_HPBVIDEOREAD hVideoRead)
{
    READ_PLAYBACK_DATA_NODE *pstMedia = (READ_PLAYBACK_DATA_NODE *)hVideoRead;
    ST_DATA_NODE_INFO *stOneNodeInfo  = MOS_NULL;
    {
        ST_MOS_LIST_ITERATOR stIterator;
        FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
        {
            MOS_LIST_RMVNODE(&pstMedia->stNodeList, stOneNodeInfo);
            ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
            while(pstFrameNode != MOS_NULL)
            {
                ST_DATA_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->pstnext;
                MOS_FREE(pstTmpNode);
            }
            MOS_FREE(stOneNodeInfo);
        }
        pstMedia->usSeqNumIndex= 0;
        pstMedia->uiIsFirst    = 1;
        return MOS_TRUE;
    }
}
