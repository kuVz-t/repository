#include "kj_video_buffer_display.h"
#include "mos.h"

VideoBuffeDisplay::VideoBuffeDisplay()
    :iMaxBufNum(6)
{
     iMaxBufNum             =(1);
     debug                  = 0;
     iNoNeedMutexFlag       = 0;
     video_display_buffer_.pRingBuf = NULL;
     MOS_MEMSET((&video_display_buffer_), 0, sizeof(video_display_buffer_));
     video_display_buffer_.iIsStop  = MOS_TRUE;
     MOS_MEMSET(&usr_index_, 0, sizeof(usr_index_));

    //  if (KjMutexLock::getFileEixst("/tmp/test_displaymedia") == 0)
    //  {
    //      debug  = 1;
    //  }
}

_INT VideoBuffeDisplay::bufferInit(_INT oneBufsize, _INT buffer_num)
{
    _INT i = 0;
    MOS_MEMSET(&video_display_buffer_, 0, sizeof(video_display_buffer_));
    iMaxBufNum                           = buffer_num;
    iNoNeedMutexFlag                     = 0;
    video_display_buffer_.iIsStop        = MOS_FALSE;
    video_display_buffer_.uiMaxConsumer  = 0;
    video_display_buffer_.uiConReadIndex = 0;
    oneBufsize_                          = oneBufsize;

    video_display_buffer_.uiMaxLen       = oneBufsize*iMaxBufNum;
    video_display_buffer_.pRingBuf       = (char *)MOS_MALLOCCLR(video_display_buffer_.uiMaxLen);
    video_display_buffer_.uiLeftLen      = video_display_buffer_.uiMaxLen;
    video_display_buffer_.nIsFull        = MOS_FALSE;
    video_display_buffer_.iNeedIflag     = 1;

    for (i=0; i<(sizeof(video_display_buffer_.index)/sizeof(ST_VIDEO_DISPLAY_BUF)); i++)
    {
       MOS_MEMSET(&video_display_buffer_.index[i], 0, sizeof(ST_VIDEO_DISPLAY_BUF));
    }

    MOS_MEMSET(&usr_index_, 0, sizeof(usr_index_));
    MOS_PRINTF("MAXSIZE:%d  video_display_buffer_.uiMaxLen:%u\n", (sizeof(video_display_buffer_.index)/sizeof(ST_VIDEO_DISPLAY_BUF)), video_display_buffer_.uiMaxLen);
    return 0;
}



_INT VideoBuffeDisplay::bufferClose()
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    video_display_buffer_.iNeedIflag   = 0;
    MOS_MEMSET(&usr_index_, 0, sizeof(usr_index_));
    if(video_display_buffer_.iIsStop)
    {
        return RD_ERROR_DISPLAY_CODE_STOPED;
    }

    video_display_buffer_.iIsStop = MOS_TRUE;
    MOS_FREE(video_display_buffer_.pRingBuf);
    MOS_PRINTF("VideoBuffeDisplay::bufferClose iMaxBufNum:%d \r\n", iMaxBufNum);
    return 0;
}

_INT VideoBuffeDisplay::bufferClean()
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);

    if (video_display_buffer_.pRingBuf)
    {
        MOS_MEMSET(video_display_buffer_.pRingBuf, 0x00, video_display_buffer_.uiMaxLen);
    }
    video_display_buffer_.uiCurPos         = 0;
    video_display_buffer_.uiHeadIndex      = 0;
    video_display_buffer_.uiCurIndex       = 0;
    video_display_buffer_.uiLeftLen        = video_display_buffer_.uiMaxLen;
    video_display_buffer_.uiOldestIndex    = 0;
    video_display_buffer_.uinewIFrameIndex = 0;
    video_display_buffer_.uiConReadIndex   = 0;
    video_display_buffer_.iNeedIflag       = 1;

    _INT i = 0;
    for (i=0; i<(sizeof(video_display_buffer_.index)/sizeof(ST_VIDEO_DISPLAY_BUF)); i++)
    {
        MOS_MEMSET(&video_display_buffer_.index[i], 0, sizeof(ST_VIDEO_DISPLAY_BUF));
    }

        usr_index_.buffer_rpos = video_display_buffer_.uinewIFrameIndex;
    return 0;
}

_INT VideoBuffeDisplay::writeData(_VPTR pData, _UI uiDataLen, _INT is_keyframe,
                           struct timeval *tv_capture, _INT time_stamp, _LLID time_pts)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    _UI uiLeftLen = 0;

    if (video_display_buffer_.iIsStop)
    {
        return RD_ERROR_DISPLAY_CODE_STOPED;
    }

    if (((video_display_buffer_.iNeedIflag == MOS_TRUE))  && (is_keyframe != MOS_TRUE) )
    {
        return RD_ERROR_DISPLAY_CODE_INVALID;
    }

    if (video_display_buffer_.uiMaxLen <= uiDataLen)
    {
        MOS_PRINTF("Error!!! The Video Frame Size Is Too Large");
        return WR_FLAG_DISPLAY_FULL;
    }

    video_display_buffer_.iNeedIflag  = 0;
    while(1)
    {
        uiLeftLen = video_display_buffer_.uiMaxLen - video_display_buffer_.uiCurPos;
        if( video_display_buffer_.nIsFull == MOS_TRUE)
        {
            /*覆盖数据*/
            if(uiLeftLen < uiDataLen)
            {
                static _UI uiCoverIFrameCnt = 0;
                static _UI uiTrashNonIFrameCnt = 0;

                /*剩下的空间不足保存数据，从头开始存数据*/
                video_display_buffer_.uiOldestIndex = video_display_buffer_.uiHeadIndex;

                video_display_buffer_.uiCurPos = 0;
                uiLeftLen = 0;
                while( uiLeftLen < uiDataLen)
                {
                    uiLeftLen += video_display_buffer_.index[video_display_buffer_.uiOldestIndex].uiDataLen;
                    video_display_buffer_.uiOldestIndex = CHK_PARAM_MAXVALUE_RET(video_display_buffer_.uiOldestIndex, MAX_DISPLAY_MEDIA_INDE, 0);
                }
                video_display_buffer_.uiHeadIndex = video_display_buffer_.uiCurIndex;
            }
            else
            {
                uiLeftLen = video_display_buffer_.uiLeftLen;
                while( uiLeftLen < uiDataLen)
                {
                    if (debug >= 1)
                    MOS_PRINTF("%s %d uiLeftLen:%u , uiDataLen:%u, curpos:%u, diffmax:%d \n",
                               __FUNCTION__, __LINE__,  uiLeftLen, uiDataLen, video_display_buffer_.uiCurPos,
                               (video_display_buffer_.uiMaxLen - video_display_buffer_.uiCurPos));
                    if( video_display_buffer_.index[video_display_buffer_.uiOldestIndex].uiOffset == 0)
                    {/*最旧的buffer是在缓冲头部*/
                        if (debug >= 1)
                        MOS_PRINTF("2222%s %d uiLeftLen:%u , uiDataLen:%u, curpos:%u, diffmax:%d \n",
                                                    __FUNCTION__, __LINE__,  uiLeftLen, uiDataLen,
                                   video_display_buffer_.uiCurPos,(video_display_buffer_.uiMaxLen - video_display_buffer_.uiCurPos));

                        uiLeftLen = video_display_buffer_.uiMaxLen - video_display_buffer_.uiCurPos;
                        break;
                    }
                    else
                    {
                        uiLeftLen += video_display_buffer_.index[video_display_buffer_.uiOldestIndex].uiDataLen;
                        video_display_buffer_.uiOldestIndex = CHK_PARAM_MAXVALUE_RET(video_display_buffer_.uiOldestIndex, MAX_DISPLAY_MEDIA_INDE, 0);
                    }
                }
            }
        }
        else
        {
            /*BUF是空的情况，直接插入数据*/
            if( uiLeftLen < uiDataLen)
            {
                video_display_buffer_.nIsFull = MOS_TRUE;
                continue;
            }
            video_display_buffer_.uiHeadIndex   = 0;
            video_display_buffer_.uiOldestIndex = 0;
        }
        break;
    }
    memcpy( video_display_buffer_.pRingBuf + video_display_buffer_.uiCurPos, pData, uiDataLen);
    video_display_buffer_.index[video_display_buffer_.uiCurIndex].uiDataLen   = uiDataLen;
    video_display_buffer_.index[video_display_buffer_.uiCurIndex].uiOffset    = video_display_buffer_.uiCurPos;
    video_display_buffer_.index[video_display_buffer_.uiCurIndex].uiFrameType = is_keyframe;
    video_display_buffer_.index[video_display_buffer_.uiCurIndex].iTimeStamp  = time_stamp;
    video_display_buffer_.index[video_display_buffer_.uiCurIndex].llTimePts   = time_pts;

    video_display_buffer_.uiCurPos += uiDataLen;
    if(is_keyframe )
    {
        video_display_buffer_.uinewIFrameIndex = video_display_buffer_.uiCurIndex;
    }

    video_display_buffer_.uiCurIndex = CHK_PARAM_MAXVALUE_RET(video_display_buffer_.uiCurIndex, MAX_DISPLAY_MEDIA_INDE, 0);
    video_display_buffer_.uiLeftLen  = uiLeftLen - uiDataLen;

    if (debug >=1)
    MOS_PRINTF("%s uimaxLen:%u uiCurIndex:%u, headindex:%u, oldindex:%u, iFrameIndex:%d time:%u er_.uiLeftLen:%u?=max-pos:%u, uiCurPos:%u  uiDataLen:%u offset:%u frameType:%u, \n",
               __FUNCTION__, video_display_buffer_.uiMaxLen, video_display_buffer_.uiCurIndex,
               video_display_buffer_.uiHeadIndex, video_display_buffer_.uiOldestIndex, video_display_buffer_.uinewIFrameIndex, time_stamp, video_display_buffer_.uiLeftLen, video_display_buffer_.uiMaxLen - video_display_buffer_.uiCurPos,
               video_display_buffer_.uiCurPos,
               uiDataLen, video_display_buffer_.uiCurPos, is_keyframe);
    return 0;
}

_INT VideoBuffeDisplay::readData(char **pDataBuf, _INT *size, _INT *is_keyframe, _INT *time_stamp, _LLID *time_pts)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE, iNoNeedMutexFlag);
    if (video_display_buffer_.iIsStop)
    {
        return RD_ERROR_DISPLAY_CODE_STOPED;
    }

    _INT  iDataLen     = -1;
    //MOS_PRINTF("usrid invalid:%d name:%s, usr_index_.buffer_rpos:%d\n", usr_id, usr_index_.buffer_name, usr_index_.buffer_rpos);
    _INT uiReadIndex  = usr_index_.buffer_rpos;

     if( uiReadIndex >= MAX_DISPLAY_MEDIA_INDE || uiReadIndex < 0)
     {
         uiReadIndex= video_display_buffer_.uinewIFrameIndex;
     }

     if( video_display_buffer_.uiCurIndex != uiReadIndex)
     {
         if(*(video_display_buffer_.pRingBuf + video_display_buffer_.index[uiReadIndex].uiOffset) != 0x00
             || *(video_display_buffer_.pRingBuf + video_display_buffer_.index[uiReadIndex].uiOffset + 1) != 0x00
             || *(video_display_buffer_.pRingBuf + video_display_buffer_.index[uiReadIndex].uiOffset + 2) != 0x00
             || *(video_display_buffer_.pRingBuf + video_display_buffer_.index[uiReadIndex].uiOffset + 3) != 0x01)
         {
             uiReadIndex = video_display_buffer_.uinewIFrameIndex;
         }
     }

     if( video_display_buffer_.uiCurIndex != uiReadIndex)
     {
         *size = video_display_buffer_.index[uiReadIndex].uiDataLen;
         *pDataBuf = video_display_buffer_.pRingBuf + video_display_buffer_.index[uiReadIndex].uiOffset;
         *is_keyframe = video_display_buffer_.index[uiReadIndex].uiFrameType;
         if (time_stamp != MOS_NULL)
         {
            *time_stamp = video_display_buffer_.index[uiReadIndex].iTimeStamp;
         }
         if (time_pts != MOS_NULL)
         {
            *time_pts = video_display_buffer_.index[uiReadIndex].llTimePts;
         }
		 
         iDataLen = *size;
         if (debug >= 2)
         {
            MOS_PRINTF("%s %s, size:%d uiReadIndex:%d\n",__FUNCTION__, usr_index_.buffer_name, *size, uiReadIndex);
         }
         
         return 0;
     }
     return -1;
}

_INT VideoBuffeDisplay::readOk()
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE, iNoNeedMutexFlag);

    usr_index_.buffer_rpos = CHK_PARAM_MAXVALUE_RET(usr_index_.buffer_rpos, MAX_DISPLAY_MEDIA_INDE, 0);
    if (debug >= 2)
    {
        MOS_PRINTF(":%s name:%s buf_rpos:%d\n", __FUNCTION__, usr_index_.buffer_name, usr_index_.buffer_rpos);
    }

    return 0;
}

_INT VideoBuffeDisplay::setCurrentUsrId(_UC *pUserName)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    usr_index_.buffer_rpos      = video_display_buffer_.uinewIFrameIndex;

    MOS_MEMSET(usr_index_.buffer_name, 0, sizeof(usr_index_.buffer_name));
    MOS_PRINTF("video %s consume app:%s, readINdex:%d\n", __FUNCTION__,  (pUserName!=MOS_NULL)?pUserName:"none", usr_index_.buffer_rpos);
    if (pUserName != MOS_NULL)
    {
        MOS_STRNCPY(usr_index_.buffer_name, pUserName, sizeof((usr_index_.buffer_name)));
    }

    return 0;
}

_INT VideoBuffeDisplay::closeCurrentUsrid()
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    return MOS_OK;
}
