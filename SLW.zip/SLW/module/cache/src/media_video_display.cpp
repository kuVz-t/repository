#include "kj_video_buffer_display.h"
#include "media_video_display.h"
#include "zj_func.h"

_UI VIDEOPLAYBUFLEN[] ={(3*1024*1024/2), (1*1024*1024), (800*1024)};

VideoBuffeDisplay g_hVideoDisplayBuf;
ST_VIDEO_TASKMNG  g_stDisPlayMng;

ST_VIDEO_TASKMNG* Media_GetDisplayMng()
{
    return  &g_stDisPlayMng;
}

_INT Media_VideoDisPlayInit()
{
    if (Media_GetDisplayMng()->uiInitFlag == 1)
    {
        MOS_PRINTF("Already Init !! \r\n");
        return MOS_OK;
    }

    // 创建缓存器
    _UI uiDevAbilit =  Mos_SysGetDeviceAbility();
    switch (uiDevAbilit)
    {
    case EN_MOS_DEVICE_ABILITY_RICH:
        break;
    case EN_MOS_DEVICE_ABILITY_MID:
        break;
    case EN_MOS_DEVICE_ABILITY_POOR:
        break;
    default:
        uiDevAbilit = EN_MOS_DEVICE_ABILITY_MID;
        break;
    }

    g_hVideoDisplayBuf.bufferInit(VIDEOPLAYBUFLEN[uiDevAbilit], 1);
    g_hVideoDisplayBuf.bufferClean();

    MOS_PRINTF("Media_VideoInit task init o size:%d \r\n",  VIDEOPLAYBUFLEN[uiDevAbilit]);

    MOS_MEMSET(&g_stDisPlayMng,0,sizeof(ST_VIDEO_TASKMNG));
    Mos_MutexCreate(&Media_GetDisplayMng()->hMutex);
    Media_GetDisplayMng()->uiInitFlag = 1;
    MOS_PRINTF("Media_VideoDisPlayInit task init ok \r\n");

    return MOS_OK;
}

_INT Media_VideoDisPlayDestroy()
{
    if (Media_GetDisplayMng()->uiInitFlag == 0)
    {
        MOS_PRINTF("Already Destroy !! \r\n");
        return MOS_OK;
    }
    
    Mos_MutexDelete(&Media_GetDisplayMng()->hMutex);
    g_hVideoDisplayBuf.bufferClose();
    Media_GetDisplayMng()->uiInitFlag = 0;
    return MOS_OK;
}

_HVPLAYHANDLE Media_VideoDisPlayCreatHandle(_UC *pucPeerId, ST_ZJ_VIDEO_PARAM *pstVideoParm)
{
    if ((pucPeerId == MOS_NULL) || (pstVideoParm == MOS_NULL))
    {
        return MOS_NULL;
    }
    g_hVideoDisplayBuf.setCurrentUsrId(pucPeerId);
    PLAY_VIDEO_DATA_NODE *pstNode = (PLAY_VIDEO_DATA_NODE *)MOS_MALLOC(sizeof(PLAY_VIDEO_DATA_NODE));
    MOS_MEMCPY(&pstNode->pstVideoParm, pstVideoParm, sizeof(ST_ZJ_VIDEO_PARAM));
    MOS_STRNCPY(pstNode->ucsPeerId, pucPeerId, sizeof(pstNode->ucsPeerId));
    MOS_PRINTF("Media_VideoDisPlayCreatHandle pucPeerId: %s\r\n", pucPeerId);
    Media_GetDisplayMng()->hVideoPlay = pstNode;
    return (_HVPLAYHANDLE)pstNode;
}

void Media_Notify_VideoPlay(_UC *pucPeerId, _UI uiOption)
{
    if(ZJ_GetFuncTable()->pfunVideoToPlay)
    {
        if (pucPeerId != MOS_NULL)
        {
            MOS_PRINTF("%s %d PeerId:%s recv option:%u\n", __FUNCTION__, __LINE__, pucPeerId, uiOption);
            MOS_LOG_INF("debugVideoplay","PeerId %s recv option %u",pucPeerId, uiOption);
        }

        if(1 == uiOption)
        {
            ZJ_GetFuncTable()->pfunVideoToPlay(pucPeerId, 1);
        }
        else
        {
            ZJ_GetFuncTable()->pfunVideoToPlay(pucPeerId, 0);
        }
    }
}

_INT Media_VideoDisPlayCancelFrameBuff(_HVPLAYHANDLE hPlay)
{
    g_hVideoDisplayBuf.bufferClean();

    return MOS_OK;
}

_INT Media_VideoDisPlayWriteFrame(_HVPLAYHANDLE hPlay,_UC* ptData,_UI uiDataLen,_INT is_keyframe,_UI uiTimeStamp)
{
    _INT iRet = g_hVideoDisplayBuf.writeData(ptData, uiDataLen, is_keyframe, MOS_NULL, uiTimeStamp,0);
    if(iRet == -1)
     {
        iRet = g_hVideoDisplayBuf.writeData(ptData, uiDataLen, is_keyframe, MOS_NULL, uiTimeStamp,0);
    }
    return iRet;
}


_INT Media_VideoDisPlayDestroyHandle(_HVPLAYHANDLE hPlay)
{
    if (Media_GetDisplayMng()->hVideoPlay != MOS_NULL)
    {
        MOS_FREE(Media_GetDisplayMng()->hVideoPlay);
    }
    return MOS_OK;
}

_INT Media_VideoDisPlayReadFrameIsEnd()
{
    return MOS_OK;
}

_INT Media_VideoDisPlayReadFrame(_UC **pucBuff,_INT *is_keyframe,_UI *puiTimeStamp)
{
    _INT iRet        = 0;
    _INT DataBufLen  = 0;
    _UC  *DataBuf    = NULL;
    // 读一Frame数据
    iRet = g_hVideoDisplayBuf.readData(&(DataBuf), &(DataBufLen), is_keyframe, puiTimeStamp, NULL); 
    if (iRet == 0)
    {
        g_hVideoDisplayBuf.readOk();
        *pucBuff = DataBuf;
        return DataBufLen;
    }
    else
    {
        *puiTimeStamp = 0;
        return MOS_ERR;
    }

    return DataBufLen;
}

_INT Media_VideoDisPlayGetStreamInfo(ST_ZJ_VIDEO_PARAM *pstVideoDes)
{
    if ((Media_GetDisplayMng()->hVideoPlay != MOS_NULL) && (pstVideoDes != MOS_NULL))
    {
        MOS_MEMCPY(pstVideoDes, &Media_GetDisplayMng()->hVideoPlay->pstVideoParm, sizeof(ST_ZJ_VIDEO_PARAM));
        return MOS_OK;
    }
    return MOS_ERR;
}


