#include "media_retras_reader.h"
#include "record_api.h"
#include "config_api.h"

// #define USE_STATIC_BUF
#ifdef USE_STATIC_BUF
static _UC g_pucBuf[MAX_TRANS_DATA_LEN] = {0};
#endif
/**
* @brief         check input start time & end time is  real exitst
* @author        Hejh
* @date          2021-04-25
*/
_INT Media_RetrasCheckTimeValid(_UC* aucDay, _CTIME_T *cTime, _CTIME_T *cTimeEnd,
                                READ_SDMEDIA_DATA_NODE *pstNode, ST_RDSTG_FILEDES* pstMediaParm)
{
    if (*cTimeEnd <= pstMediaParm->cStartTime) //
    {
        return MOS_ERR;
    }
    else if ((*cTime <= pstMediaParm->cStartTime) && (*cTimeEnd>= pstMediaParm->cStartTime))
    {
        *cTime = pstMediaParm->cStartTime;
        if (*cTimeEnd>= pstMediaParm->cStopTime)
        {
            ST_RDSTG_FILEDES     pstMediaParm2;
            if(RdStg_GetFileDes(pstNode->iCamid, aucDay, pstMediaParm->cStopTime+1, &pstMediaParm2) != MOS_ERR)
            {
                if ((pstMediaParm2.cStartTime-*cTimeEnd) <= 5)
                {
                    MOS_PRINTF("ok get netx record file is continus\n");
                    if (pstMediaParm2.cStopTime <= *cTimeEnd)
                    {
                        *cTimeEnd = pstMediaParm2.cStopTime;
                    }
                }
                else
                {
                    *cTimeEnd = pstMediaParm->cStopTime;
                }
            }
            else
            {
                *cTimeEnd = pstMediaParm->cStopTime;
            }
        }
    }
    else if ((*cTime >= pstMediaParm->cStartTime) && (*cTimeEnd<= pstMediaParm->cStopTime))
    {

    }
    else if ((*cTime >= pstMediaParm->cStartTime) && (*cTimeEnd>= pstMediaParm->cStopTime))
    {
      //  cTimeEnd = pstMediaParm->cStopTime;
        if (*cTimeEnd>= pstMediaParm->cStopTime)
        {
            ST_RDSTG_FILEDES     pstMediaParm2;
            if(RdStg_GetFileDes(pstNode->iCamid, aucDay, pstMediaParm->cStopTime+1, &pstMediaParm2) != MOS_ERR)
            {
                if ((pstMediaParm2.cStartTime-*cTimeEnd) <= 5)
                {
                    MOS_PRINTF("222ok get netx record file is continus\n");
                    if (pstMediaParm2.cStopTime <= *cTimeEnd)
                    {
                        *cTimeEnd = pstMediaParm2.cStopTime;
                    }
                    pstNode->usFileNum++;
                    pstNode->cTimeNext = pstMediaParm->cStopTime+1;
                }
                else
                {
                    *cTimeEnd = pstMediaParm->cStopTime;
                }
            }
            else
            {
                *cTimeEnd = pstMediaParm->cStopTime;
            }
        }
    }
   return MOS_TRUE;
}

/**
* @brief         creator cloud retrans video read handler
* @author        Hejh
* @date          2021-04-25
*/
_HRTSMEDIAREAD Media_RetrasCreatReadHandle(_UC iCamid, _UI iStreamId, _UC *aucStarTime,   _UC *aucEndTime,
                                           ST_ZJ_AUDIO_PARAM **pstAudioParm,  ST_CFG_VIDEODES   **pstVideo)
{
    _INT iAdjustTime = 0;
    READ_SDMEDIA_DATA_NODE *pstNode = MOS_NULL;
    pstNode = (READ_SDMEDIA_DATA_NODE *)MOS_MALLOC(sizeof(READ_SDMEDIA_DATA_NODE));
    pstNode->stFrame = MOS_NULL;
    pstNode->stDataNode   = MOS_NULL;
    pstNode->iCamid       = iCamid;
    pstNode->iStreamId    = iStreamId;
    pstNode->uiReadMod    = EN_READ_COMMON;
    pstNode->usFileNum    = 0;
    pstNode->usSeqNumIndex= 0;
    pstNode->pstFile      = MOS_NULL;
    ST_RDSTG_FILEDES     pstMediaParm;
    _UI puiStreamId       =0;

    if (MOS_STRCMP(aucStarTime, aucEndTime) >= 0)
    {
        MOS_PRINTF("input params error aucStarTime:%s >= aucEndTime:%s\n", aucStarTime, aucEndTime);
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    _CTIME_T cTime    = 0;
    _CTIME_T cTimeEnd = 0;
    _UC aucDay[16]    = {0};
    ST_MOS_SYS_TIME stSysTime    = {0};
    ST_MOS_SYS_TIME stSysEndTime = {0};
    Mos_GetSysTime(&stSysTime);
    Mos_GetSysTime(&stSysEndTime);
    Config_GetLocalRecordProp(MOS_NULL, MOS_NULL, &puiStreamId,MOS_NULL,MOS_NULL);
    _INT iRet = MOS_SSCANF(aucStarTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        &stSysTime.usYear,&stSysTime.usMonth,&stSysTime.usDay,
        &stSysTime.usHour,&stSysTime.usMinute,&stSysTime.usSecond);

    if(iRet != 6)
    {
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    iRet = MOS_SSCANF(aucEndTime, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        &stSysEndTime.usYear,&stSysEndTime.usMonth,&stSysEndTime.usDay,
        &stSysEndTime.usHour,&stSysEndTime.usMinute,&stSysEndTime.usSecond);

    if(iRet != 6)
    {
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    MOS_VSNPRINTF(aucDay, 16, "%04u-%02u-%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    cTime = Mos_SysTimetoTime(&stSysTime);
    cTimeEnd = Mos_SysTimetoTime(&stSysEndTime);
    //get record file info & real startTime  and real endTime
    if(RdStg_GetFileDes(iCamid, aucDay, cTime, &pstMediaParm) == MOS_ERR)
    {
        MOS_PRINTF("can't find file by play aucStarTime %s ",aucStarTime);
        if(RdStg_GetFileDes(iCamid, aucDay, cTimeEnd, &pstMediaParm) == MOS_ERR)
        {
            MOS_PRINTF("can't find file by play aucEndTime %s ",aucEndTime);
            MOS_FREE(pstNode);
            return MOS_NULL;
        }
        else
        {
            MOS_PRINTF("open new file endtime:%s sucessful!!\n", aucEndTime);
            cTime = pstMediaParm.cStartTime;
            Mos_TimetoSysTime(&cTime, &stSysTime);
            MOS_MEMSET(aucStarTime, 0, sizeof(pstNode->aucStartTime));
            MOS_VSNPRINTF(aucStarTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
                stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
        }
    }
    //just for print
    {
    Mos_TimetoSysTime(&pstMediaParm.cStartTime, &stSysTime);
    MOS_MEMSET(pstNode->aucStartTime, 0, sizeof(pstNode->aucStartTime));
    MOS_VSNPRINTF(pstNode->aucStartTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
        stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    Mos_TimetoSysTime(&pstMediaParm.cStopTime, &stSysTime);
    MOS_MEMSET(pstNode->aucEndTime, 0, sizeof(pstNode->aucEndTime));
    MOS_VSNPRINTF(pstNode->aucEndTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
        stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    MOS_PRINTF("in>>> file real time:%s endtime:%s\n ", pstNode->aucStartTime, pstNode->aucEndTime);
    }

    if (Media_RetrasCheckTimeValid(aucDay, &cTime, &cTimeEnd, pstNode, &pstMediaParm) != MOS_TRUE)
    {
        MOS_PRINTF("can't find file by play aucStarTime %s ",aucStarTime);
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    if ((cTime >= cTimeEnd )|| (cTimeEnd<=0))
    {
        MOS_PRINTF("check start time:%d or endtime:%d invalid!!!\n ", cTime, cTimeEnd);
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    Mos_TimetoSysTime(&cTime, &stSysTime);
    MOS_MEMSET(pstNode->aucStartTime, 0, sizeof(pstNode->aucStartTime));
    MOS_VSNPRINTF(pstNode->aucStartTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
        stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    //find record end time
    MOS_MEMSET(pstNode->aucEndTime,   0, sizeof(pstNode->aucEndTime));
    Mos_TimetoSysTime(&cTimeEnd, &stSysTime);
    MOS_VSNPRINTF(pstNode->aucEndTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
        stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

#ifdef USE_STATIC_BUF
    pstNode->pMediaBuf    = g_pucBuf;
    MOS_MEMSET(pstNode->pMediaBuf, 0x00, MAX_TRANS_DATA_LEN);
#else
    pstNode->pMediaBuf    = (_VPTR)Mos_MallocClr(MAX_TRANS_DATA_LEN);
    if (pstNode->pMediaBuf == MOS_NULL )
    {
        MOS_FREE(pstNode);
        return MOS_NULL;
    }
#endif

    pstNode->uiMaxMediaLen= MAX_TRANS_DATA_LEN;
    _RDFILEFD *pstRdStg_fileFD = RdStg_OpenPlayBackFile(aucStarTime, &iAdjustTime, 0);
    if (pstRdStg_fileFD == MOS_NULL )
    {
        MOS_FREE(pstNode);
        return MOS_NULL;
    }
    RdStg_ReadFileDes((_RDFILEFD)pstRdStg_fileFD, &pstNode->stVideoDes, &pstNode->stAudioParm);
    pstNode->pstFile      = (_VPTR)pstRdStg_fileFD;
    pstNode->uiEncodeType = pstNode->stVideoDes.stVideoPara.uiEncodeType;
    *pstAudioParm         = &pstNode->stAudioParm;
    *pstVideo             = &pstNode->stVideoDes;
#ifdef USER_RD_EXTERN_FILEDES
    *pstAudioParm          = Config_GetCamAudioParm(0);
    *pstVideo              = Config_GetVideoDes(iCamid, puiStreamId);
    pstNode->uiEncodeType = pstMediaParm.uiVideoEncType;
    (*pstVideo)->stVideoPara.uiHeight     = pstMediaParm.uiVideoHeight;
    (*pstVideo)->stVideoPara.uiWidth      = pstMediaParm.uiVideoWidth;
    (*pstVideo)->stVideoPara.uiEncodeType = pstMediaParm.uiVideoEncType;
#endif

    MOS_PRINTF(">>%s camid:%d streamId:%d starttime:%s endtime:%s entype:%u\n", __FUNCTION__, iCamid, iStreamId, aucStarTime, aucEndTime, pstNode->uiEncodeType);
    MOS_STRNCPY( aucStarTime, pstNode->aucStartTime, sizeof(pstNode->aucStartTime));
    MOS_STRNCPY(  aucEndTime, pstNode->aucEndTime,   sizeof(pstNode->aucEndTime));
    MOS_PRINTF("out file real time:%s endtime:%s\n ", pstNode->aucStartTime, pstNode->aucEndTime);

    return (_HRTSMEDIAREAD)pstNode;
}

/**
* @brief         creator cloud retrans video read handler
* @author        Hejh
* @date          2021-04-25
*/
_HRTSMEDIAREAD Media_RetrasCreatReadHandle2(_UC iCamid, _UI iStreamId, _CTIME_T *cTimeStart, _CTIME_T *cTimeEnd, _UC *aucStarTime,   _UC *aucEndTime,
                                           ST_ZJ_AUDIO_PARAM **pstAudioParm,  ST_CFG_VIDEODES   **pstVideo)
{
    _INT iAdjustTime = 0;
    READ_SDMEDIA_DATA_NODE *pstNode = MOS_NULL;
#if 0
    pstNode = (READ_SDMEDIA_DATA_NODE *)MOS_MALLOC(sizeof(READ_SDMEDIA_DATA_NODE));
    pstNode->stFrame = MOS_NULL;
    pstNode->stDataNode   = MOS_NULL;
    pstNode->iCamid       = iCamid;
    pstNode->iStreamId    = iStreamId;
    pstNode->uiReadMod    = EN_READ_COMMON;
    pstNode->usFileNum    = 0;
    pstNode->usSeqNumIndex= 0;
    pstNode->pstFile      = MOS_NULL;
    ST_RDSTG_FILEDES     pstMediaParm;
    _UI puiStreamId       =0;

    if ((*cTimeStart > *cTimeEnd))
    {
        MOS_PRINTF("input params error aucStarTime:%d >= aucEndTime:%d\n", *cTimeStart , *cTimeEnd);
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    _UC aucDay[16]    = {0};
    ST_MOS_SYS_TIME stSysTime    = {0};
    ST_MOS_SYS_TIME stSysEndTime = {0};
    Mos_GetSysTime(&stSysTime);
    Config_GetLocalRecordProp(MOS_NULL, MOS_NULL, &puiStreamId,MOS_NULL,MOS_NULL);


    Mos_TimetoSysTime(&cTimeStart, &stSysTime);
    MOS_VSNPRINTF(aucDay, 16, "%04u-%02u-%02u",stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay);
    //get record file info & real startTime  and real endTime
    if(RdStg_GetFileDes(iCamid, aucDay, *cTimeStart, &pstMediaParm) == MOS_ERR)
    {
        MOS_PRINTF("can't find file by play aucStarTime %d ", *cTimeStart);
        MOS_FREE(pstNode);
        return MOS_NULL;
    }
    //just for print
    {
    Mos_TimetoSysTime(&pstMediaParm.cStartTime, &stSysTime);
    MOS_MEMSET(pstNode->aucStartTime, 0, sizeof(pstNode->aucStartTime));
    MOS_VSNPRINTF(pstNode->aucStartTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
        stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    Mos_TimetoSysTime(&pstMediaParm.cStopTime, &stSysTime);
    MOS_MEMSET(pstNode->aucEndTime, 0, sizeof(pstNode->aucEndTime));
    MOS_VSNPRINTF(pstNode->aucEndTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
        stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    MOS_PRINTF("in>>> file real time:%s endtime:%s\n ", pstNode->aucStartTime, pstNode->aucEndTime);
    }

    //cTimeEnd = Mos_SysTimetoTime(&stSysEndTime);
    if (Media_RetrasCheckTimeValid(aucDay, cTimeStart, cTimeEnd, pstNode, &pstMediaParm) != MOS_TRUE)
    {
        MOS_PRINTF("can't find file by play aucStarTime %s ",aucStarTime);
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    Mos_TimetoSysTime(cTimeStart, &stSysTime);
    MOS_MEMSET(pstNode->aucStartTime, 0, sizeof(pstNode->aucStartTime));
    MOS_VSNPRINTF(pstNode->aucStartTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
        stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    //find record end time
    MOS_MEMSET(pstNode->aucEndTime,   0, sizeof(pstNode->aucEndTime));
    Mos_TimetoSysTime(cTimeEnd, &stSysTime);
    MOS_VSNPRINTF(pstNode->aucEndTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
        stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
        stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);

    pstNode->pMediaBuf    = (_VPTR)Mos_MallocClr(MAX_TRANS_DATA_LEN);
    if (pstNode->pMediaBuf == MOS_NULL )
    {
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    pstNode->uiMaxMediaLen= MAX_TRANS_DATA_LEN;
    _RDFILEFD *pstRdStg_fileFD = RdStg_OpenPlayBackFile(aucStarTime, &iAdjustTime, 0);
    if (pstRdStg_fileFD == MOS_NULL )
    {
        MOS_FREE(pstNode);
        return MOS_NULL;
    }

    pstNode->uiEncodeType = pstMediaParm.uiVideoEncType;
    pstNode->pstFile      = (_VPTR)pstRdStg_fileFD;
    *pstAudioParm          = Config_GetCamAudioParm(0);
    *pstVideo              = Config_GetVideoDes(iCamid, puiStreamId);
    (*pstVideo)->stVideoPara.uiHeight     = pstMediaParm.uiVideoHeight;
    (*pstVideo)->stVideoPara.uiWidth      = pstMediaParm.uiVideoWidth;
    (*pstVideo)->stVideoPara.uiEncodeType = pstMediaParm.uiVideoEncType;

    MOS_PRINTF(">>%s camid:%d streamId:%d starttime:%s endtime:%s entype:%d\n", __FUNCTION__, iCamid, iStreamId, aucStarTime, aucEndTime, pstNode->uiEncodeType);
    //MOS_STRNCPY( aucStarTime, pstNode->aucStartTime, sizeof(pstNode->aucStartTime));
    //MOS_STRNCPY(  aucEndTime, pstNode->aucEndTime,   sizeof(pstNode->aucEndTime));
    MOS_PRINTF("out file real time:%s endtime:%s\n ", pstNode->aucStartTime, pstNode->aucEndTime);
#endif
    return (_HRTSMEDIAREAD)pstNode;
}

/**
* @brief         Destroy retrans media handler
* @author        Hejh
* @date          2021-04-25
*/
_INT Media_RetrasDestroyReadHandle(_HRTSMEDIAREAD hVideoRead)
{
    MOS_PARAM_NULL_RETERR(hVideoRead);
    READ_SDMEDIA_DATA_NODE *pstMedia = (READ_SDMEDIA_DATA_NODE *)hVideoRead;

    if (pstMedia->pstFile != MOS_NULL)
    {
        RdStg_ClosePlayBackFile((_RDFILEFD*)(pstMedia->pstFile));
        pstMedia->pstFile =  MOS_NULL;
    }

#ifndef USE_STATIC_BUF
    if (pstMedia->pMediaBuf != MOS_NULL)
    {
        MOS_FREE(pstMedia->pMediaBuf);
    }
#endif
    MOS_FREE(pstMedia);

    return MOS_OK;
}

/**
* @brief         Get media data from sdcard file
* @author        Hejh
* @date          2021-04-25
*/
_INT Media_RetrasGetFrame(_HRTSMEDIAREAD hVideoRead,_OUT ST_FRAME_NODE **pucFrameHead,
                          _OUT _UC *ucAvType,  _OUT _INT *puiTimestamp, _IN _UI uiIsIframe)
{
    MOS_PARAM_NULL_RETERR(hVideoRead);
    READ_SDMEDIA_DATA_NODE *pstNode = (READ_SDMEDIA_DATA_NODE *)hVideoRead;

    _UC  DataBuf[1450]  = {0};
    _UI  uiBufLen       = 0;
    _UC  ucAVFlag       = 0;
    _UI  uiTimeStamp    = 0;
    _UC  ucFramePos     = 0;
    _UI  uiFrameLen     = 0;

    if (pstNode!=MOS_NULL && pstNode->uiReadMod == EN_READ_COMMON)
    {
        if ( pstNode->stFrame != MOS_NULL)
        {
            *puiTimestamp = pstNode->uiTimeStamp;
            *pucFrameHead = pstNode->stFrame;
            *ucAvType     = pstNode->iAvType;
            return pstNode->stFrame->uiNaluLen;
        }
    }

    pstNode->stFrame = MOS_NULL;
    // 读一Frame数据，需要分成多个NALU
    _UI uiTotalLen = 0;

    if (pstNode->pstFile != MOS_NULL)
    {
        _INT iRet = RdStg_ReadPlayBackFile((_RDFILEFD*)(pstNode->pstFile), DataBuf, &uiBufLen, &ucAVFlag, &uiTimeStamp, &ucFramePos, &uiFrameLen);
#ifndef USE_STATIC_BUF
        if (uiFrameLen > pstNode->uiMaxMediaLen)
        {
            MOS_FREE(pstNode->pMediaBuf);
            pstNode->pMediaBuf = (_VPTR)Mos_MallocClr(uiFrameLen);
            if (pstNode->pMediaBuf == MOS_NULL)
            {
                pstNode->pMediaBuf = (_VPTR)Mos_MallocClr(pstNode->uiMaxMediaLen);
                if (pstNode->pMediaBuf != MOS_NULL)
                {
                    uiTotalLen     += uiBufLen;
                    *puiTimestamp = 0;
                    pstNode->stFrame = MOS_NULL;
                    *pucFrameHead = MOS_NULL;
                    //MOS_PRINTF("uiBufLen:%u, uiTimeStamp:%u, ucFramePos:%u, uiFrameLen::%u\n", uiBufLen, uiTimeStamp, ucFramePos, uiFrameLen);
                    while (uiTotalLen < uiFrameLen)
                    {
                        iRet = RdStg_ReadPlayBackFile((_RDFILEFD*)(pstNode->pstFile), DataBuf, &uiBufLen, &ucAVFlag, &uiTimeStamp, &ucFramePos, &uiFrameLen);
                        if (uiBufLen > 0)
                        {
                            uiTotalLen  += uiBufLen;
                        }
                        else
                        {
                            break;
                        }
                    }
                    if (uiTotalLen == uiFrameLen )
                    {
                        return EN_RETRANS_READ_RETRY;
                    }
                }
                RdStg_ClosePlayBackFile((_RDFILEFD*)(pstNode->pstFile));
                pstNode->pstFile = MOS_NULL;
                *puiTimestamp = 0;
                pstNode->stFrame = MOS_NULL;
                *pucFrameHead = MOS_NULL;
                return EN_RETRANS_READ_UNKONWERR;
            }
            pstNode->uiMaxMediaLen = uiFrameLen;
        }
#endif
        if (uiBufLen > 0)
        {
            MOS_MEMCPY(pstNode->pMediaBuf+uiTotalLen, DataBuf, uiBufLen);
            uiTotalLen     += uiBufLen;
            *ucAvType      = ucAVFlag;
            *puiTimestamp  = uiTimeStamp;
            pstNode->uiTimeStamp = *puiTimestamp;
            pstNode->iAvType     = *ucAvType;
            //MOS_PRINTF("uiBufLen:%u, uiTimeStamp:%u, ucFramePos:%u, uiFrameLen::%u\n", uiBufLen, uiTimeStamp, ucFramePos, uiFrameLen);
            while (uiTotalLen < uiFrameLen)
            {
                iRet = RdStg_ReadPlayBackFile((_RDFILEFD*)(pstNode->pstFile), DataBuf, &uiBufLen, &ucAVFlag, &uiTimeStamp, &ucFramePos, &uiFrameLen);
                if (uiBufLen > 0)
                {
                    MOS_MEMCPY(pstNode->pMediaBuf+uiTotalLen, DataBuf, uiBufLen);
                    uiTotalLen  += uiBufLen;
                    //MOS_PRINTF("1111uiTotalLen:%u, uiTimeStamp:%u, ucFramePos:%u, uiFrameLen::%u\n", uiTotalLen, uiTimeStamp, ucFramePos, uiFrameLen);
                }
                else
                {
                    break;
                }
            }
            //read total frame
            if (uiTotalLen == uiFrameLen )
            {
                if ((pstNode->usSeqNumIndex == 0) && (*ucAvType==EN_ZJ_MEDIA_VIDEO) && ((_UC)(MD_GETFRAMETYPE(ucFramePos))==EN_FRAMETYPE_I))
                {
                   pstNode->usSeqNumIndex = 1;
                   //MOS_PRINTF("FOUND FIRST IFRAME!!\n");
                }

                if (pstNode->usSeqNumIndex == 0)
                {
                    *puiTimestamp = 0;
                    pstNode->stFrame = MOS_NULL;
                    *pucFrameHead = MOS_NULL;
                    return MOS_ERR;
                }

                if (*ucAvType == EN_ZJ_MEDIA_VIDEO)
                {
                    pstNode->stFrame = Media_VideoCreatFrame(pstNode->pMediaBuf, uiTotalLen, pstNode->uiEncodeType, pstNode->uiEncodeType,pstNode->uiEncodeType, pstNode->uiEncodeType);
                }
                else
                {
                    pstNode->stFrame = Media_AudioCreatFrame(pstNode->pMediaBuf, uiTotalLen);
                    pstNode->stFrame->ptnest = MOS_NULL;
                }
                *pucFrameHead = pstNode->stFrame;
                //MOS_PRINTF("sd data ucAvType:%d uiTotalLen:%u, uiTimeStamp:%u, ucFramePos:%u, uiFrameLen::%u, encodetype:%d\n", *ucAvType, pstNode->stFrame->uiNaluLen, pstNode->uiTimeStamp, ucFramePos, uiFrameLen, pstNode->uiEncodeType);
                return uiTotalLen;
            }
            else //read data error
            {
                pstNode->stFrame = MOS_NULL;
                *pucFrameHead = MOS_NULL;
                RdStg_ClosePlayBackFile((_RDFILEFD*)(pstNode->pstFile));
                pstNode->pstFile = MOS_NULL;
                *puiTimestamp = 0;
                pstNode->stFrame = MOS_NULL;
                return EN_RETRANS_READ_ERRORDATA;
            }
        }
        else
        {
            *puiTimestamp = 0;
            pstNode->stFrame = MOS_NULL;
            *pucFrameHead = MOS_NULL;
            if (iRet == MOS_ERR_FILEFINISH)
            {
                RdStg_ClosePlayBackFile((_RDFILEFD*)(pstNode->pstFile));
                pstNode->pstFile = MOS_NULL;

                if (pstNode->usFileNum >0)
                {
                    pstNode->usFileNum--;
                    _INT iAdjustTime = 0;
                    ST_MOS_SYS_TIME stSysTime;
                    Mos_TimetoSysTime(&pstNode->cTimeNext, &stSysTime);
                    MOS_MEMSET(pstNode->aucStartTime, 0, sizeof(pstNode->aucStartTime));
                    MOS_VSNPRINTF(pstNode->aucStartTime, 40, "%04hu-%02hu-%02hu %02hu:%02hu:%02hu",
                                  stSysTime.usYear,stSysTime.usMonth,stSysTime.usDay,
                                  stSysTime.usHour,stSysTime.usMinute,stSysTime.usSecond);
                    _RDFILEFD *pstRdStg_fileFD = RdStg_OpenPlayBackFile(pstNode->aucStartTime, &iAdjustTime, 0);
                    if (pstRdStg_fileFD != MOS_NULL )
                    {
                        pstNode->pstFile = (_VPTR)pstRdStg_fileFD;
                        MOS_PRINTF("open next file sucessful!!\n");
                        return EN_RETRANS_READ_RETRY;
                    }
                }
            }
            return EN_RETRANS_READ_DATAEND;
        }
    }
    else
    {
        *puiTimestamp = 0;
        pstNode->stFrame = MOS_NULL;
        *pucFrameHead = MOS_NULL;
        return EN_RETRANS_READ_DATAEND;
    }
}

_VOID Media_RetrasSetFrameUsed(_HRTSMEDIAREAD hVideoRead)
{
    MOS_PARAM_NULL_NORET(hVideoRead);
    READ_SDMEDIA_DATA_NODE *pstNode = (READ_SDMEDIA_DATA_NODE *)hVideoRead;

    if (pstNode->uiReadMod == EN_READ_COMMON)
    {
        if(pstNode->stFrame != MOS_NULL)
        {
            ST_FRAME_NODE *pstFrameNode = pstNode->stFrame;
            if (pstFrameNode != MOS_NULL)
            {
                ST_FRAME_NODE *pstTmpNodeOri = pstFrameNode;
                pstFrameNode = pstFrameNode->ptnest;
                pstNode->stFrame = pstFrameNode;
                MOS_FREE(pstTmpNodeOri);
            }

            if (pstFrameNode == MOS_NULL)
            {
                //MOS_MEMSET(pstNode->pMediaBuf, 0, pstNode->stFrame->usDatalen);
                pstNode->stFrame = MOS_NULL;
            }
        }
    }
    else
    {
        _UI uiListCnt = 0;
        if(pstNode->stFrame != MOS_NULL)
        {
            MOS_MEMSET(pstNode->pMediaBuf, 0, pstNode->stFrame->usDatalen);
            ST_FRAME_NODE *pstFrameNode = pstNode->stFrame;
            while(pstFrameNode != MOS_NULL)
            {
                uiListCnt++;
                ST_FRAME_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->ptnest;
                MOS_FREE(pstTmpNode);
            }
        }
    }
    return;
}
