#include "media_audio.h"
#include "kj_video_buffer_multy.h"
#include "kj_audio_buffer_multy.h"
#include "mos_mem.h"
#include "zj_func.h"
#include "config_api.h"

extern ST_FRAME_NODE *MediaVideoFrameInit();
typedef struct stuct_CACHE_AUDIO_MEDIA
{
    _HMEMOWNER       hMem;
    _INT             iMemUnitSize;
    _INT             iAudioInit;
    AudioBufferMulty hAudioBuf;
}ST_AUDIO_MNG;

_UI AUDIOBUFLEN[][2] ={{AUDIO_ENC_SIZE, (25*8)}, {AUDIO_ENC_SIZE, (25*8)},
                       {AUDIO_ENC_SIZE, (25*8)}, {AUDIO_ENC_SIZE, (25*8)}};
_UI AUDIOPOLLSIZE[]  = {MOS_MEM_MAXAUDIO_POOL_SIZE, MOS_MEM_MAXAUDIO_POOL_SIZE, MOS_MEM_MAXAUDIO_POOL_SIZE};
ST_AUDIO_MNG g_audioCacheMng;

ST_AUDIO_MNG *Media_GetCacheAudioMng()
{
    return &g_audioCacheMng;
}

// 音频初始化
_INT Media_AuidoInit()
{
    Media_GetCacheAudioMng()->iAudioInit = 0;
    Media_GetCacheAudioMng()->hMem       = MOS_NULL;
    Media_GetCacheAudioMng()->iMemUnitSize= AUDIOCACHE_BUF_UNIT_SIZE;
    _UI uiDevAbilit =  Mos_SysGetDeviceAbility();
    switch (uiDevAbilit)
    {
    case EN_MOS_DEVICE_ABILITY_RICH:
        break;
    case EN_MOS_DEVICE_ABILITY_MID:
        break;
    case EN_MOS_DEVICE_ABILITY_POOR:
        break;
    default:
        uiDevAbilit = EN_MOS_DEVICE_ABILITY_MID;
        break;
    }
    Media_GetCacheAudioMng()->hAudioBuf.bufferInit(AUDIOBUFLEN[uiDevAbilit][0], AUDIOBUFLEN[uiDevAbilit][1], 0, Config_GetCamaraMng()->uiCamDataInputMode);//five seconds
    Media_GetCacheAudioMng()->hAudioBuf.bufferClean();
    MOS_PRINTF("Media_AuidoInit task init ok uiCamDataInputMode:%d\r\n",Config_GetCamaraMng()->uiCamDataInputMode);
#ifdef MEDIA_BUFFER_USER_MEMSEA
    if(Media_GetCacheAudioMng()->hMem == MOS_NULL)
    {
        Media_GetCacheAudioMng()->hMem = Mos_MemOwnerCreate(MOS_NULL,(_UC*)"AudioCache",AUDIOCACHE_BUF_MID_SIZE);
        Mos_MemOwnerSetPriorSea(Media_GetCacheAudioMng()->hMem, AUDIOCACHE_BUF_UNIT_SIZE, AUDIOPOLLSIZE[uiDevAbilit]);
    }
#endif
    if (ZJ_GetFuncTable()->pfunAudioSwitch)
    {
        ZJ_GetFuncTable()->pfunAudioSwitch(1);
    }

    Media_GetCacheAudioMng()->iAudioInit = 1;
    MOS_PRINTF("Media_AuidoInit task init ok \r\n");
    return MOS_OK;
}

// 音频销毁
_INT Media_AuidoDestroy()
{
    if (ZJ_GetFuncTable()->pfunAudioSwitch)
    {
        ZJ_GetFuncTable()->pfunAudioSwitch(0);
    }
    Media_GetCacheAudioMng()->hAudioBuf.bufferClose();
    if(Media_GetCacheAudioMng()->hMem != MOS_NULL)
    {
        Mos_MemOwnerDel(Media_GetCacheAudioMng()->hMem);
        Media_GetCacheAudioMng()->hMem = MOS_NULL;
    }
    MOS_PRINTF("Media_AuidoDestroy ok \r\n");
    return MOS_OK;
}

// 音频清理缓存
_INT Media_AuidoCleanBuffer()
{
    if (ZJ_GetFuncTable()->pfunAudioSwitch)
    {
        ZJ_GetFuncTable()->pfunAudioSwitch(0);
    }
    Media_GetCacheAudioMng()->hAudioBuf.bufferClean();
    if (ZJ_GetFuncTable()->pfunAudioSwitch)
    {
        ZJ_GetFuncTable()->pfunAudioSwitch(1);
    }
    MOS_PRINTF("Media_AuidoCleanBuffer ok \r\n");
    return MOS_OK;
}

ST_FRAME_NODE *Media_AudioCreatFrame(_UC *DataBuf, _INT DataBufLen)
{
    ST_FRAME_NODE *st_frame_node = MediaVideoFrameInit();
    if(st_frame_node == MOS_NULL)
    {
        MOS_PRINTF("%s %d MediaVideoFrameInit error!\n", __func__, __LINE__);
        return MOS_NULL;
    }
    st_frame_node->ucFramPos     = EN_FRAMETYPE_I << 4;
    st_frame_node->ucFramPos     |= MD_FRAME_HEAD + MD_FRAME_TAIL + MD_NAUL_HEAD + MD_NALU_TAIL;
    st_frame_node->ptDatabuff    = DataBuf;
    st_frame_node->uiRemFrameLen =DataBufLen;
    st_frame_node->usDatalen     = DataBufLen;
    st_frame_node->uiNaluLen     = DataBufLen;
    st_frame_node->ptnest        = MOS_NULL;
    return st_frame_node;
}

// 写音频帧入链表
_INT Media_WriteAudioFrame(_INT iCamId,_UC *ptFrame,_INT iLen,_UI uiTimeStamp)
{
    if (Media_GetCacheAudioMng()->iAudioInit <= 0)
    {
        return 0;
    }

    _INT iRet = Media_GetCacheAudioMng()->hAudioBuf.writeData(ptFrame, iLen, false, MOS_NULL, uiTimeStamp);
    if (iRet == -1)
    {
        iRet = Media_GetCacheAudioMng()->hAudioBuf.readOneGopOk(); 
        if (iRet != 0)
        {
            MOS_PRINTF("%s write buffer full, readgop: timeout \r\n", __FUNCTION__, iRet);
            iRet = Media_GetCacheAudioMng()->hAudioBuf.readOneGopOk(1);   
        }
        
        if (iRet != -4)
        {
           iRet = Media_GetCacheAudioMng()->hAudioBuf.writeData(ptFrame, iLen, false, MOS_NULL, uiTimeStamp);
        }
    }
    return iRet;
}

// 改变Audio参数
_INT Media_ReSetAudioParameter(_INT iCamId,_UI uiSample, _UI uiChannel, _UI uiDepth,_UI uiAudioType)
{
    _INT iRet = Media_GetCacheAudioMng()->hAudioBuf.changeAudioParams(uiChannel, uiSample, uiDepth, uiAudioType);
    return iRet;
}

// 创建Audio读handle
_HAUDIOREAD Media_AudioCreatReadHandle2(_INT iCamId, _UI uiReadMod, _UC *pUserName)
{
    READ_AUDIO_DATA_NODE *pstNode = MOS_NULL;
    pstNode = (READ_AUDIO_DATA_NODE *)MOS_MALLOC(sizeof(READ_AUDIO_DATA_NODE));
    pstNode->stFrame = MOS_NULL;

    pstNode->id           = 0;
    pstNode->iCamid       = 0;
    pstNode->iStreamId    = 0;
    pstNode->uiReadMod    = uiReadMod;
    pstNode->uiKeyQuality = 0;
    pstNode->uiMaxHisCount= MAX_HISTORY_AUDIO_FRAME;
    pstNode->usSeqNumIndex= 0;
    pstNode->id           = Media_GetCacheAudioMng()->hAudioBuf.setCurrentUsrId(pUserName,uiReadMod);
    pstNode->usHisTimeMsec= 1000*MAX_HISTORY_AUDIO_FRAME*2/25;
    MOS_LIST_INIT(&pstNode->stNodeList);
    MOS_LOG_INF(LOG_MEDIA_CACHE, "%s app:%s iChannel: %u \r\n",__FUNCTION__, pUserName, pstNode->id);
    return (_HAUDIOREAD)pstNode;
}

_US  Media_AudioGetHisReadMsec(_HAUDIOREAD hAudioRead)
{
    MOS_PARAM_NULL_RETERR(hAudioRead);

    READ_AUDIO_DATA_NODE *hAudio = (READ_AUDIO_DATA_NODE *)hAudioRead;
    return hAudio->usHisTimeMsec;
}

static ST_DATA_NODE *Media_GetAudioNodeFromeFrame(_HAUDIOREAD hAudioRead, ST_FRAME_NODE *pstNode,
                                                  _INT iFrmeLen,  _INT iTimeStamp)
{
    MOS_PARAM_NULL_RETNULL(hAudioRead);
    MOS_PARAM_NULL_RETNULL(pstNode);
    READ_AUDIO_DATA_NODE *hAudio = (READ_AUDIO_DATA_NODE *)hAudioRead;
    ST_DATA_NODE *stDataHeadNode  = MOS_NULL;
    _INT  pucOutLen   = 0;
    _UI   uiListCnt   = 1;
    _UI   uiPackNum   = 1;

    ST_FRAME_NODE *pstFrameNode = pstNode;
    for (_INT i=0; i<uiListCnt; i++)
    {
        _INT firstFramSize = pstFrameNode->uiNaluLen;
        if (firstFramSize > MAX_MEDIA_BODY_LEN)
        {
            firstFramSize = MAX_MEDIA_BODY_LEN;
        }
        ST_DATA_NODE *stDataNode = MediaVideoDataNodeInit(Media_GetCacheAudioMng()->hMem, firstFramSize, Media_GetCacheAudioMng()->iMemUnitSize);
        pucOutLen = 0;
        _BOOL bStart = MOS_FALSE;

        if (stDataHeadNode == MOS_NULL)
        {
            bStart = MOS_TRUE;
            stDataHeadNode          = stDataNode;
            stDataNode->uiTimeStamp = iTimeStamp;
            stDataNode->usSeqNum    = (++hAudio->usSeqNumIndex);//%0xffff;
            stDataNode->stFrameNode = *pstFrameNode;
            stDataNode->pstFrameHead= stDataHeadNode;
            stDataNode->pstnext     = MOS_NULL;
            stDataNode->usFramRemPackect      = --uiPackNum;
            stDataNode->stFrameNode.ucFramPos = MD_GETFRAMEHIGH(pstFrameNode->ucFramPos);
            stDataNode->stFrameNode.uiNaluLen = pstFrameNode->uiNaluLen;
            stDataNode->stFrameNode.uiRemFrameLen = pstFrameNode->uiNaluLen;
            stDataNode->stFrameNode.ptDatabuff    = pstFrameNode->ptDatabuff;
            stDataNode->stFrameNode.usDatalen     = iFrmeLen;
            MOS_MEMCPY(stDataNode->ptbuff, pstFrameNode->ptDatabuff, pstFrameNode->uiNaluLen);
            stDataNode->stFrameNode.ucFramPos |= MD_FRAME_HEAD + MD_NAUL_HEAD;
            stDataNode->stFrameNode.ucFramPos |= MD_FRAME_TAIL + MD_NALU_TAIL;
        }
    }
    return stDataHeadNode;
}

// 获取一个Audio节点
ST_DATA_NODE *Media_AudioGetOneNode(_HAUDIOREAD hAudioRead)
{
    MOS_PARAM_NULL_RETNULL(hAudioRead);

    _INT              ret         = 0;
    READ_AUDIO_DATA_NODE *pstNode = (READ_AUDIO_DATA_NODE *)hAudioRead;
    pstNode->stFrame = MOS_NULL;

    _UC    *DataBuf    = NULL;
    _INT    DataBufLen = 0;
    _INT    Id         = pstNode->id;
    _INT    IsKeyFrame = 1;
    _INT    iTimeStamp= 0;
    _UI     ullAudioTime = 0;

    // 读一Frame数据，需要分成多个NALU
    ret = Media_GetCacheAudioMng()->hAudioBuf.readData((_C**)&(DataBuf), &(DataBufLen), (_INT)(Id), MOS_NULL, &ullAudioTime);
    if (ret == 0)
    {
        iTimeStamp               = (_INT)ullAudioTime;
        pstNode->stFrame         = Media_AudioCreatFrame(DataBuf, DataBufLen);
        pstNode->stFrame->ptnest = MOS_NULL;

        pstNode->stDataNode = Media_GetAudioNodeFromeFrame(hAudioRead, pstNode->stFrame, DataBufLen, iTimeStamp);
        if(pstNode->stFrame != MOS_NULL)
        {
            ST_FRAME_NODE *pstFrameNode = pstNode->stFrame;
            while(pstFrameNode != MOS_NULL)
            {
                ST_FRAME_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->ptnest;
                MOS_FREE(pstTmpNode);
            }
        }
        return pstNode->stDataNode;
    }
    else
    {
        return MOS_NULL;
    }
}

// 设置Audio节点为使用，释放内存
_VOID Media_AudioSetNodeUsed(_HAUDIOREAD hAudioRead)
{
    MOS_PARAM_NULL_NORET(hAudioRead);

    READ_AUDIO_DATA_NODE *pstNode = (READ_AUDIO_DATA_NODE *)hAudioRead;

    if(pstNode->stDataNode != MOS_NULL)
    {
        pstNode->stDataNode = MOS_NULL;
        Media_GetCacheAudioMng()->hAudioBuf.readOk(pstNode->id);
    }

    return;
}

// 音频扩展接口
//ST_DATA_NODE *Media_AudioGetOneNodeEx(_HAUDIOREAD hAudioRead)
_VOID Media_AudioShiftNextNode(_HAUDIOREAD hAudioRead)
{
    MOS_PARAM_NULL_NORET(hAudioRead);

    return ;
}


ST_DATA_NODE * Media_AudioHisGetPackNode(_HAUDIOREAD hAudioRead, _UI packgSeqNum)
{
    MOS_PARAM_NULL_RETNULL(hAudioRead);

    READ_AUDIO_DATA_NODE *pstMedia = (READ_AUDIO_DATA_NODE *)hAudioRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    ST_MOS_LIST_ITERATOR stIterator;
    ST_DATA_NODE  *pstDataNode    = MOS_NULL;

    FOR_EACHDATA_INLIST(&pstMedia->stNodeList, stOneNodeInfo, stIterator)
    {
        _INT minSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usSeqNum;
        _INT maxSeq = stOneNodeInfo->stHdataNode->pstFrameHead->usFramRemPackect+minSeq;
        if (packgSeqNum >= minSeq && packgSeqNum <= maxSeq)
        {
            ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
            while(pstFrameNode != MOS_NULL)
            {
                if (pstFrameNode->usSeqNum == packgSeqNum)
                {
                    //MOS_PRINTF("found seq:%u firtseq:%u cuseq:%u \r\n\n", pstFrameNode->usSeqNum, pstFrameNode->pstFrameHead->usSeqNum, packgSeqNum);
                    pstDataNode = pstFrameNode;
                    break;
                }
                pstFrameNode = pstFrameNode->pstnext;
            }
            break;
        }
        else
        {
            // MOS_PRINTF("notund noddep packet min:%u max:%u tofound:%u \r\n", minSeq, maxSeq, packgSeqNum);

        }
    }
    return pstDataNode;
}

_VOID Media_AudioHisAddOneNode(_HAUDIOREAD hAudioRead, ST_DATA_NODE *pstDataNode)
{
    MOS_PARAM_NULL_NORET(hAudioRead);

    READ_AUDIO_DATA_NODE *pstMedia = (READ_AUDIO_DATA_NODE *)hAudioRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

     stOneNodeInfo = (ST_DATA_NODE_INFO*)MOS_MALLOCCLR(sizeof(ST_DATA_NODE_INFO));
     stOneNodeInfo->stHdataNode = pstDataNode;

     if (pstMedia->stNodeList.uiTotalCount >= pstMedia->uiMaxHisCount)
     {
         Media_AudioHisDelHeadNode(hAudioRead);
     }

     MOS_LIST_ADDTAIL(&pstMedia->stNodeList, stOneNodeInfo);
     //MOS_PRINTF("%s node size:%u \r\n", __FUNCTION__, pstMedia->stNodeList.uiTotalCount);

     return;
}

_VOID Media_AudioFreeDataNode(_VPTR hMem, ST_DATA_NODE *pstTmpNode, _INT iMemUnitSize)
{
    if (hMem != MOS_NULL && ((pstTmpNode->stFrameNode.uiNaluLen+sizeof(ST_DATA_NODE)) == iMemUnitSize))
    {
        Mos_MemFree(pstTmpNode);
    }
    else
    {
        MOS_FREE(pstTmpNode);
    }
}

_VOID Media_AudioHisDelHeadNode(_HAUDIOREAD hAudioRead)
{
    MOS_PARAM_NULL_NORET(hAudioRead);

    READ_AUDIO_DATA_NODE *pstMedia = (READ_AUDIO_DATA_NODE *)hAudioRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    stOneNodeInfo = MOS_LIST_RMVHEAD(&pstMedia->stNodeList);

    if (stOneNodeInfo != MOS_NULL)
    {
        if(stOneNodeInfo->stHdataNode != MOS_NULL)
        {
            ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
            while(pstFrameNode != MOS_NULL)
            {
                ST_DATA_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->pstnext;
                Media_AudioFreeDataNode(Media_GetCacheAudioMng()->hMem, pstTmpNode, Media_GetCacheAudioMng()->iMemUnitSize);
            }
        }
        //MOS_FREE(stOneNodeInfo->stHdataNode);
        MOS_FREE(stOneNodeInfo);
    }

    return;
}

_VOID Media_AudioHisDelAllNode(_HAUDIOREAD hAudioRead)
{
    MOS_PARAM_NULL_NORET(hAudioRead);

    READ_AUDIO_DATA_NODE *pstMedia = (READ_AUDIO_DATA_NODE *)hAudioRead;
    ST_DATA_NODE_INFO *stOneNodeInfo = MOS_NULL;

    while (MOS_LIST_GETCOUNT(&pstMedia->stNodeList)>0)
    {
        stOneNodeInfo = MOS_LIST_RMVHEAD(&pstMedia->stNodeList);
        if (stOneNodeInfo != MOS_NULL)
        {
            ST_DATA_NODE *pstFrameNode = stOneNodeInfo->stHdataNode->pstFrameHead;
            while(pstFrameNode != MOS_NULL)
            {
                ST_DATA_NODE *pstTmpNode = pstFrameNode;
                pstFrameNode = pstFrameNode->pstnext;
                Media_AudioFreeDataNode(Media_GetCacheAudioMng()->hMem, pstTmpNode, Media_GetCacheAudioMng()->iMemUnitSize);
            }
            //MOS_FREE(stOneNodeInfo->stHdataNode);
            MOS_FREE(stOneNodeInfo);
        }
        else
        {
            break;
        }
    }

    return;
}

_VOID Media_AudioSetNodeUsedEx(_HAUDIOREAD hAudioRead,ST_DATA_NODE *pstADataNode)
{
    MOS_PARAM_NULL_NORET(hAudioRead);

    return ;
}

// 音频句柄销毁
_INT Media_AudioDestroyReadHandle2(_HAUDIOREAD hAudioRead)
{
    MOS_PARAM_NULL_RETERR(hAudioRead);
    
    READ_AUDIO_DATA_NODE *pstMedia = (READ_AUDIO_DATA_NODE *)hAudioRead;
    Media_GetCacheAudioMng()->hAudioBuf.closeCurrentUsrid(pstMedia->id);
    pstMedia->id = -1;
    if (pstMedia->stFrame != MOS_NULL)
    {
        MOS_FREE(pstMedia->stFrame);
    }
    MOS_LIST_RMVALL(&pstMedia->stNodeList, MOS_TRUE);
    if (pstMedia)
    {
        MOS_FREE(pstMedia);
    }

    return MOS_OK;
}

// 获取 音频数据帧
_INT Media_AudioGetFrame2(_HAUDIOREAD hAudioRead,_OUT ST_FRAME_NODE **pucFrameHead,_OUT _UI *puiTimestamp)
{
    MOS_PARAM_NULL_RETERR(hAudioRead);

    _INT              ret         = 0;
    READ_AUDIO_DATA_NODE *pstNode = (READ_AUDIO_DATA_NODE *)hAudioRead;
    pstNode->stFrame = MOS_NULL;

    _UC    *DataBuf    = NULL;
    _INT    DataBufLen = 0;
    _INT    Id         = pstNode->id;
    _INT    IsKeyFrame = 0;
    _UI     ullAudioTime = 0;
        // 读一Frame数据，需要分成多个NALU

    ret = Media_GetCacheAudioMng()->hAudioBuf.readData((_C**)&(DataBuf), &(DataBufLen), Id, MOS_NULL, &ullAudioTime);
    if (ret == 0)
    {
        *puiTimestamp    = (_UI)ullAudioTime; 
        pstNode->stFrame = Media_AudioCreatFrame(DataBuf, DataBufLen);
        if(pstNode->stFrame == MOS_NULL)
        {
            MOS_PRINTF("%s %d Media_AudioCreatFrame error!\n", __func__, __LINE__);
            *pucFrameHead = MOS_NULL;
            return MOS_ERR;
        }
        pstNode->stFrame->ptnest = MOS_NULL;
        *pucFrameHead = pstNode->stFrame;
        return DataBufLen;
    }
    else
    {
        pstNode->stFrame = MOS_NULL;
        *puiTimestamp    = 0;
        *pucFrameHead    = MOS_NULL;
        return MOS_ERR;
    }
}

// 获取 音频数据帧
_INT Media_GetAudioBufferFrameNode(_OUT ST_FRAME_NODE **stFrameOut,  _UC *DataBuf, _INT DataBufLen)
{
    ST_FRAME_NODE *stFrame = MOS_NULL;

    if ( (DataBuf!=MOS_NULL) && (DataBufLen>0) )
    {
        stFrame = Media_AudioCreatFrame(DataBuf, DataBufLen);
        if(stFrame == MOS_NULL)
        {
            MOS_PRINTF("%s %d Media_AudioCreatFrame error!\n", __func__, __LINE__);
            *stFrameOut = MOS_NULL;
            return MOS_ERR;
        }
        stFrame->ptnest = MOS_NULL;

        *stFrameOut = stFrame;
        return DataBufLen;
    }
    else
    {
        stFrame     = MOS_NULL;
        *stFrameOut = MOS_NULL;
        return MOS_ERR;
    }
}

_VOID Media_FreeAudioBufferFrameNode(ST_FRAME_NODE *stFrameIn)
{
    _UI uiListCnt = 0;
    if(stFrameIn != MOS_NULL)
    {
        ST_FRAME_NODE *pstFrameNode = stFrameIn;
        while(pstFrameNode != MOS_NULL)
        {
            uiListCnt++;
            ST_FRAME_NODE *pstTmpNode = pstFrameNode;
            pstFrameNode = pstFrameNode->ptnest;
            MOS_FREE(pstTmpNode);
        } 
    }
}

// 设置音频帧为使用，释放内存
_VOID Media_AudioSetFrameUsed2(_HAUDIOREAD hAudioRead)
{
    MOS_PARAM_NULL_NORET(hAudioRead);
    
    READ_AUDIO_DATA_NODE *pstNode = (READ_AUDIO_DATA_NODE *)hAudioRead;

    _UI uiListCnt = 0;
    if(pstNode->stFrame != MOS_NULL)
    {
        ST_FRAME_NODE *pstFrameNode = pstNode->stFrame;
        while(pstFrameNode != MOS_NULL)
        {
            uiListCnt++;
            ST_FRAME_NODE *pstTmpNode = pstFrameNode;
            pstFrameNode = pstFrameNode->ptnest;
            MOS_FREE(pstTmpNode);
        }
        pstNode->stFrame = MOS_NULL;
        Media_GetCacheAudioMng()->hAudioBuf.readOk(pstNode->id);
    }
    return;
}

