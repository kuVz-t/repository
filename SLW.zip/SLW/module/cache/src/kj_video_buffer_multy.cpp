#include "kj_video_buffer_multy.h"
#include "mos.h"

VideoBuffeMulty::VideoBuffeMulty()
    :iMaxBufNum(6)
{
     iMaxBufNum             =(6);
     debug                  = 0;
     iNoNeedMutexFlag       = 0;
     video_buffer_.pRingBuf = NULL;
     MOS_MEMSET((&video_buffer_), 0, sizeof(video_buffer_));
     video_buffer_.iIsStop  = MOS_TRUE;
     MOS_MEMSET(usr_index_, 0, sizeof(usr_index_));

     if (KjMutexLock::getFileEixst("/tmp/test_media") == 0)
     {
         debug  = 1;
     }
}

_INT VideoBuffeMulty::bufferInit(_INT oneBufsize, _INT buffer_num, _INT buffer_id, _UI uiMediaType, _UI uiResolution, _UI uiEncType, _INT inNoNeedMutex)
{
    _INT   i;
    MOS_MEMSET(&video_buffer_, 0, sizeof(video_buffer_));
    iMaxBufNum                   = buffer_num;
    iNoNeedMutexFlag             = inNoNeedMutex;
    video_buffer_.iIsStop        = MOS_FALSE;
    buffer_id_                   = buffer_id;
    video_buffer_.uiMediaType    = uiMediaType;
    video_buffer_ .uiMaxConsumer = 0;
    video_buffer_.uiConReadIndex = 0;
    oneBufsize_                  = oneBufsize;

    video_buffer_.uiMaxLen       = oneBufsize*iMaxBufNum;
    video_buffer_.pRingBuf       = (char *)MOS_MALLOCCLR(video_buffer_.uiMaxLen);
    video_buffer_.uiLeftLen      = video_buffer_.uiMaxLen;
    video_buffer_.nIsFull        = MOS_FALSE;
    video_buffer_.iNeedIflag     = 1;

    video_buffer_.uiEncType      = uiEncType;
    video_buffer_.uiResolution   = uiResolution;

    for (i=0; i<(sizeof(video_buffer_.index)/sizeof(ST_VIDEO_BUF)); i++)
    {
       MOS_MEMSET(&video_buffer_.index[i], 0, sizeof(ST_VIDEO_BUF));
       MOS_MEMSET(video_buffer_.index[i].lock_index_ , 0,
                sizeof(video_buffer_.index[i].lock_index_ ));
    }

    MOS_MEMSET(usr_index_, 0, sizeof(usr_index_));
    MOS_PRINTF("MAXSIZE:%d  video_buffer_.uiMaxLen:%u\n", (sizeof(video_buffer_.index)/sizeof(ST_VIDEO_BUF)), video_buffer_.uiMaxLen);
    return 0;
}

_INT VideoBuffeMulty::bufferClose()
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    video_buffer_.iNeedIflag   = 0;
    MOS_MEMSET(usr_index_, 0, sizeof(usr_index_));
    if(video_buffer_.iIsStop)
    {
        return RD_ERROR_CODE_STOPED;
    }

    video_buffer_.iIsStop = MOS_TRUE;
    MOS_FREE(video_buffer_.pRingBuf);
    MOS_PRINTF("VideoBuffeMulty::bufferClose iMaxBufNum:%d \r\n", iMaxBufNum);
    return 0;
}

_INT VideoBuffeMulty::bufferClean()
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);

    if (video_buffer_.pRingBuf)
    {
        MOS_MEMSET(video_buffer_.pRingBuf, 0x00, video_buffer_.uiMaxLen);
    }
    video_buffer_.uiCurPos         = 0;
    video_buffer_.uiHeadIndex      = 0;
    video_buffer_.uiCurIndex       = 0;
    video_buffer_.uiLeftLen        = video_buffer_.uiMaxLen;
    video_buffer_.uiOldestIndex    = 0;
    video_buffer_.uinewIFrameIndex = 0;
    video_buffer_.uiConReadIndex   = 0;
    video_buffer_.iNeedIflag       = 1;

    for (_INT i=0; i<(sizeof(video_buffer_.index)/sizeof(ST_VIDEO_BUF)); i++)
    {
        MOS_MEMSET(&video_buffer_.index[i], 0, sizeof(ST_VIDEO_BUF));
        MOS_MEMSET(video_buffer_.index[i].lock_index_ , 0,
                    sizeof(video_buffer_.index[i].lock_index_ ));
    }

    for(_INT i=0; i<MAX_USR_ID; i++)
    {
        if(usr_index_[i].buffer_usr_valid > 0)
        {
            usr_index_[i].buffer_rpos = video_buffer_.uinewIFrameIndex;
        }
    }
    return 0;
}

_INT VideoBuffeMulty::writeData(_VPTR pData, _UI uiDataLen, _INT is_keyframe,
                           struct timeval *tv_capture, _INT time_stamp, _LLID time_pts)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    _UI uiLeftLen = 0;

    if (video_buffer_.iIsStop)
    {
        return RD_ERROR_CODE_STOPED;
    }

    if (((video_buffer_.iNeedIflag == MOS_TRUE))  && (is_keyframe != MOS_TRUE) )
    {
        return RD_ERROR_CODE_INVALID;
    }

    if (video_buffer_.uiMaxLen < uiDataLen)
    {
        MOS_PRINTF("Error!!! The Video Frame Size Is Too Large");
        return WR_FLAG_FULL;
    }

    video_buffer_.iNeedIflag  = 0;
    while(1)
    {
        uiLeftLen = video_buffer_.uiMaxLen - video_buffer_.uiCurPos;
        if( video_buffer_.nIsFull == MOS_TRUE)
        {
            /*覆盖数据*/
            if(uiLeftLen < uiDataLen)
            {
                static _UI uiCoverIFrameCnt = 0;
                static _UI uiTrashNonIFrameCnt = 0;

                /*剩下的空间不足保存数据，从头开始存数据*/
                video_buffer_.uiOldestIndex = video_buffer_.uiHeadIndex;
                /*确保有一个I帧在缓冲区*/
                /*无法避免p帧被覆盖*/
                if (video_buffer_.uiOldestIndex == video_buffer_.uinewIFrameIndex)
                {
                    if (is_keyframe != MOS_TRUE) 
                    {
                        uiTrashNonIFrameCnt++;
                        if ((uiTrashNonIFrameCnt%20) == 0)
                        {
                            MOS_LOG_WARN(LOG_MEDIA_CACHE, "TrashNonIFrameCnt:%d CoverIFrameCnt:%d", uiTrashNonIFrameCnt, uiCoverIFrameCnt);
                        }
                        MOS_PRINTF("cache warn: trash non-IFrame\n");
                        video_buffer_.iNeedIflag = MOS_TRUE;// 丢弃后续的非I帧，等待I帧到来
                        return WR_FLAG_NEED_KEYFRAME;
                    }
                    else
                    {
                        uiCoverIFrameCnt++;
                        if ((uiCoverIFrameCnt%20) == 0)
                        {
                            MOS_LOG_WARN(LOG_MEDIA_CACHE, "CoverIFrameCnt:%d TrashNonIFrameCnt:%d ", uiCoverIFrameCnt, uiTrashNonIFrameCnt);
                        }
                        MOS_PRINTF("cache warn: cover IFrame\n");
                    }
                }

                video_buffer_.uiCurPos = 0;
                uiLeftLen = 0;
                while( uiLeftLen < uiDataLen)
                {
                    uiLeftLen += video_buffer_.index[video_buffer_.uiOldestIndex].uiDataLen;
                    video_buffer_.uiOldestIndex = CHK_PARAM_MAXVALUE_RET(video_buffer_.uiOldestIndex, MAX_MEDIA_INDE, 0);
                }
                video_buffer_.uiHeadIndex = video_buffer_.uiCurIndex;
            }
            else
            {
                uiLeftLen = video_buffer_.uiLeftLen;
                while( uiLeftLen < uiDataLen)
                {
                    if (debug >= 1)
                    MOS_PRINTF("%s %d error stream:%d uiLeftLen:%u , uiDataLen:%u, curpos:%u, diffmax:%d \n",
                               __FUNCTION__, __LINE__, buffer_id_,  uiLeftLen, uiDataLen, video_buffer_.uiCurPos,
                               (video_buffer_.uiMaxLen - video_buffer_.uiCurPos));
                    if( video_buffer_.index[video_buffer_.uiOldestIndex].uiOffset == 0)
                    {/*最旧的buffer是在缓冲头部*/
                        if (debug >= 1)
                        MOS_PRINTF("2222%s %d error stream:%d uiLeftLen:%u , uiDataLen:%u, curpos:%u, diffmax:%d \n",
                                                    __FUNCTION__, __LINE__, buffer_id_,  uiLeftLen, uiDataLen,
                                   video_buffer_.uiCurPos,(video_buffer_.uiMaxLen - video_buffer_.uiCurPos));

                        uiLeftLen = video_buffer_.uiMaxLen - video_buffer_.uiCurPos;
                        break;
                    }
                    else
                    {
                        uiLeftLen += video_buffer_.index[video_buffer_.uiOldestIndex].uiDataLen;
                        video_buffer_.uiOldestIndex = CHK_PARAM_MAXVALUE_RET(video_buffer_.uiOldestIndex, MAX_MEDIA_INDE, 0);
                    }
                }
            }
        }
        else
        {
            /*BUF是空的情况，直接插入数据*/
            if( uiLeftLen < uiDataLen)
            {
                video_buffer_.nIsFull = MOS_TRUE;
                continue;
            }
            video_buffer_.uiHeadIndex   = 0;
            video_buffer_.uiOldestIndex = 0;
        }
        break;
    }
    memcpy( video_buffer_.pRingBuf + video_buffer_.uiCurPos, pData, uiDataLen);
    video_buffer_.index[video_buffer_.uiCurIndex].uiDataLen   = uiDataLen;
    video_buffer_.index[video_buffer_.uiCurIndex].uiOffset    = video_buffer_.uiCurPos;
    video_buffer_.index[video_buffer_.uiCurIndex].uiFrameType = is_keyframe;
    video_buffer_.index[video_buffer_.uiCurIndex].iTimeStamp  = time_stamp;
    video_buffer_.index[video_buffer_.uiCurIndex].llTimePts   = time_pts;

    video_buffer_.uiCurPos += uiDataLen;
    if(is_keyframe )
    {
        time_t tNowTime = 0;
        tNowTime = time(0);
        video_buffer_.index[video_buffer_.uiCurIndex].llTimePts = (_LLID)((_LLID)tNowTime * 1000);
        video_buffer_.uinewIFrameIndex = video_buffer_.uiCurIndex;
    }

    video_buffer_.uiCurIndex = CHK_PARAM_MAXVALUE_RET(video_buffer_.uiCurIndex, MAX_MEDIA_INDE, 0);
    video_buffer_.uiLeftLen  = uiLeftLen - uiDataLen;

    if (debug >=1)
    // if (buffer_id_ == 0)
    MOS_PRINTF("%s stream:%d uimaxLen:%u uiCurIndex:%u, headindex:%u, oldindex:%u, iFrameIndex:%d time:%u er_.uiLeftLen:%u?=max-pos:%u, uiCurPos:%u  uiDataLen:%u offset:%u frameType:%u, \n",
               __FUNCTION__,buffer_id_, video_buffer_.uiMaxLen, video_buffer_.uiCurIndex,
               video_buffer_.uiHeadIndex, video_buffer_.uiOldestIndex, video_buffer_.uinewIFrameIndex, time_stamp, video_buffer_.uiLeftLen, video_buffer_.uiMaxLen - video_buffer_.uiCurPos,
               video_buffer_.uiCurPos,
               uiDataLen, video_buffer_.uiCurPos, is_keyframe);
    return 0;
}

_INT VideoBuffeMulty::readData(char **pDataBuf, _INT *size, _INT usr_id, _INT *is_keyframe,
                          struct timeval *tv_capture, _INT *time_stamp,_LLID *time_pts,_UI *uiResolution,_UI *uiEncType)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE, iNoNeedMutexFlag);
    if (video_buffer_.iIsStop)
    {
        return RD_ERROR_CODE_STOPED;
    }

    if(0)//video_buffer_.iNeedIflag == -1)//WR_FLAG_NEED_WAITFULL)
    {
        return RD_ERROR_CODE_WAITE;//wait write data recover
    }

    if(usr_index_[usr_id].buffer_usr_valid <= 0)
    {
        MOS_PRINTF("usrid invalid:%d name:%s\n", usr_id, usr_index_[usr_id].buffer_name);
        return RD_ERROR_CODE_INVALID;
    }
    _INT  iDataLen     = -1;
    //MOS_PRINTF("usrid invalid:%d name:%s, usr_index_[usr_id].buffer_rpos:%d\n", usr_id, usr_index_[usr_id].buffer_name, usr_index_[usr_id].buffer_rpos);
    _INT &uiReadIndex  = usr_index_[usr_id].buffer_rpos;

     if( uiReadIndex >= MAX_MEDIA_INDE || uiReadIndex < 0)
     {
         uiReadIndex= video_buffer_.uinewIFrameIndex;
     }

     while(1)
     {
        if( video_buffer_.uiCurIndex != uiReadIndex)
        {
            if(*(video_buffer_.pRingBuf + video_buffer_.index[uiReadIndex].uiOffset) != 0x00
                || *(video_buffer_.pRingBuf + video_buffer_.index[uiReadIndex].uiOffset + 1) != 0x00
                || *(video_buffer_.pRingBuf + video_buffer_.index[uiReadIndex].uiOffset + 2) != 0x00
                || *(video_buffer_.pRingBuf + video_buffer_.index[uiReadIndex].uiOffset + 3) != 0x01)
            {
                if ((usr_index_[usr_id].uiPreFlag == 1) && (usr_index_[usr_id].uiFindPreFlag == 0))
                {
                    usr_index_[usr_id].buffer_rpos   = CHK_PARAM_MAXVALUE_RET(usr_index_[usr_id].buffer_rpos, MAX_MEDIA_INDE, 0);
                    uiReadIndex = usr_index_[usr_id].buffer_rpos;
                }
                else
                {
                    uiReadIndex = video_buffer_.uinewIFrameIndex;
                    break;
                }
            }
            else
            {
                usr_index_[usr_id].uiFindPreFlag = 1;
                break;
            }
        }
        else
        {
            break;
        }
     }

     if( video_buffer_.uiCurIndex != uiReadIndex)
     {
         *size = video_buffer_.index[uiReadIndex].uiDataLen;
         *pDataBuf = video_buffer_.pRingBuf + video_buffer_.index[uiReadIndex].uiOffset;
         *is_keyframe = video_buffer_.index[uiReadIndex].uiFrameType;
         if (time_stamp != MOS_NULL)
         {
            *time_stamp = video_buffer_.index[uiReadIndex].iTimeStamp;
         }
         if (time_pts != MOS_NULL)
         {
            *time_pts = video_buffer_.index[uiReadIndex].llTimePts;
         }
		 
		 *uiEncType = video_buffer_.uiEncType;
		 *uiResolution = video_buffer_.uiResolution;
		 
         iDataLen = *size;
         video_buffer_.index[uiReadIndex].lock_index_[usr_id] = 1;
         video_buffer_.index[uiReadIndex].uiUserCount++;
         //uiReadIndex = CHK_PARAM_MAXVALUE_RET(uiReadIndex, MAX_MEDIA_INDE, 0);
         if (debug >= 2)//usr_id == 0)
         MOS_PRINTF("%s %s, size:%d uiReadIndex:%d\n",__FUNCTION__, usr_index_[usr_id].buffer_name, *size, uiReadIndex);
         return 0;
     }
     return -1;
}

_INT VideoBuffeMulty::readOk(_INT usr_id)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE, iNoNeedMutexFlag);
     if(usr_id < 0 || usr_id>= MAX_USR_ID)
    {
        return -1;
    }
    else
    {
        _INT current_read_pos = usr_index_[usr_id].buffer_rpos;
        if (video_buffer_.index[current_read_pos].lock_index_[usr_id] != 1)
        {
            MOS_PRINTF ("video rpos:%d usrid:%d  not preset:%d!!, ignor read ok!! usrName:%s\n",
                        current_read_pos, usr_id, video_buffer_.index[current_read_pos].lock_index_[usr_id], usr_index_[usr_id].buffer_name);
            return -1;
        }

        video_buffer_.index[current_read_pos].lock_index_[usr_id] = 0;
        usr_index_[usr_id].buffer_rpos = CHK_PARAM_MAXVALUE_RET(usr_index_[usr_id].buffer_rpos, MAX_MEDIA_INDE, 0);
        if (debug >= 2)
        {
            MOS_PRINTF(":%s name:%s buf_rpos:%d\n", __FUNCTION__, usr_index_[usr_id].buffer_name, usr_index_[usr_id].buffer_rpos);
        }

        //check if all consumer is readok, then release rpos buf
        if (video_buffer_.index[current_read_pos].uiUserCount < video_buffer_.uiMaxConsumer)
        {
            //MOS_PRINTF("%s %d %d %d\n", __FUNCTION__, __LINE__, video_buffer_.index[current_read_pos].nUserCount, audio_buffer_.nMaxConsumer);
            return 0;
        }
        else
        {
            for(_INT i=0; i<MAX_USR_AUDIO_ID; i++)
            {
                if(usr_index_[i].buffer_usr_valid > 0)
                {
                   if (video_buffer_.index[current_read_pos].lock_index_[i] != 0)
                   {
                       return 0;
                   }
                }
            }
        }

        //video_buffer_.index[current_read_pos].lock_index_ = 0; //add by hejh
        MOS_MEMSET(video_buffer_.index[current_read_pos].lock_index_ , 0,
                sizeof(video_buffer_.index[current_read_pos].lock_index_ ));
        video_buffer_.index[current_read_pos].uiUserCount  = 0;
        video_buffer_.uiConReadIndex = CHK_PARAM_MAXVALUE_RET(video_buffer_.uiConReadIndex, MAX_MEDIA_INDE, 0);
        if (debug >= 2)
        {
            MOS_PRINTF(":%s all read ok video_buffer_.uiConReadIndex:%u\n", __FUNCTION__,  video_buffer_.uiConReadIndex);
        }
        return 0;
    }
}

_UI VideoBuffeMulty::GetNextIFrame(_UI PreFlag)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE, iNoNeedMutexFlag);
    _INT iFoundIframe = MOS_FALSE;
    _UI  ReadIndex    = 0;

    if(PreFlag == 1)//预录标志
    {
        ReadIndex = video_buffer_.uiOldestIndex;
    }
    else if (PreFlag == 0)
    {
        if(video_buffer_.uiCurIndex > READSTART_INDEX)
        {
            ReadIndex = video_buffer_.uiCurIndex  - READSTART_INDEX;
        }
        else
        {
            ReadIndex = video_buffer_.uiCurIndex + MAX_MEDIA_INDE - READSTART_INDEX;
        }
    }
    else
    {
        ReadIndex = video_buffer_.uiConReadIndex;
    }

    while(video_buffer_.uiCurIndex != ReadIndex)
    {
        if( video_buffer_.index[ReadIndex].uiFrameType == 1
            && *(video_buffer_.pRingBuf + video_buffer_.index[ReadIndex].uiOffset) == 0x00
            && *(video_buffer_.pRingBuf + video_buffer_.index[ReadIndex].uiOffset  + 1) == 0x00
            && *(video_buffer_.pRingBuf + video_buffer_.index[ReadIndex].uiOffset  + 2) == 0x00
            && *(video_buffer_.pRingBuf + video_buffer_.index[ReadIndex].uiOffset  + 3) == 0x01
            && (*(video_buffer_.pRingBuf + video_buffer_.index[ReadIndex].uiOffset + 4) == 0x67 ||
                *(video_buffer_.pRingBuf + video_buffer_.index[ReadIndex].uiOffset + 4) == 0x40))

        {
            iFoundIframe = MOS_TRUE;
            iFoundIframe = 1;
            break;
        }
        ReadIndex = CHK_PARAM_MAXVALUE_RET(ReadIndex, MAX_MEDIA_INDE, 0);
    }

    if (iFoundIframe != MOS_TRUE)
    {
        ReadIndex  = video_buffer_.uiConReadIndex;
    }
    return ReadIndex;
}

_INT VideoBuffeMulty::GetPreIFrameIndex(_UI uiFramerate)
{
    _UI  uiReadIndex      = 0;
    _UI  uiStartFindFps   = 0;
    _UI  uiCountIndex     = 0;
    _UI  uiStartFindIndex = 0;
    _UI  uiFps            = uiFramerate;

    uiFps           = ((uiFps > 50) || (uiFps < 5)) ? 15 : uiFps;
    uiStartFindFps  = uiFps * VIDEO_FIND_SEC;

    if (video_buffer_.uiCurIndex >= video_buffer_.uiOldestIndex)
    {
        uiCountIndex = video_buffer_.uiCurIndex - video_buffer_.uiOldestIndex;
    }
    else
    {
        uiCountIndex = video_buffer_.uiCurIndex + (MAX_MEDIA_INDE - video_buffer_.uiOldestIndex);
    }

    MOS_PRINTF("video_buffer_.uiCurIndex  = %d   video_buffer_.uiOldestIndex = %d   uiCountIndex = %d  uiStartFindFps = %d\n", video_buffer_.uiCurIndex, video_buffer_.uiOldestIndex, uiCountIndex, uiStartFindFps);

    uiStartFindFps = uiStartFindFps > uiCountIndex ?  uiCountIndex : uiStartFindFps;

    if (video_buffer_.uiCurIndex >= uiStartFindFps)
    {
        uiStartFindIndex = video_buffer_.uiCurIndex - uiStartFindFps;
    }
    else
    {
        uiStartFindIndex = MAX_MEDIA_INDE - (uiStartFindFps - video_buffer_.uiCurIndex);
    }

    uiReadIndex = uiStartFindIndex;
    MOS_PRINTF("uiReadIndex = %d  uinewIFrameIndex = %d\n",uiReadIndex, video_buffer_.uinewIFrameIndex);

     while(video_buffer_.uiCurIndex != uiReadIndex)
     {  
        if (video_buffer_.index[uiReadIndex].uiFrameType == 1)
        {
            return uiReadIndex;
        }
        else
        {
            uiReadIndex  = CHK_PARAM_MAXVALUE_RET(uiReadIndex, MAX_MEDIA_INDE, 0);
        }
     }

    return video_buffer_.uinewIFrameIndex;
}

_UI VideoBuffeMulty::resetMediaParam(_UI uiResolution, _UI uiEncType)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    video_buffer_.uiEncType = uiEncType;
	video_buffer_.uiResolution = uiResolution;
    return MOS_OK;
}

//read one gop video for nothing
_INT VideoBuffeMulty::readOneVideoGopOk(_INT isFource)
{
    return 0;
}

_INT VideoBuffeMulty::setCurrentUsrId(_INT readMode, _UC *pUserName, _UI uiFramerate)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    _INT ret = -1;
    for(_INT i=0; i<MAX_USR_ID; i++)
    {
        if(usr_index_[i].buffer_usr_valid <= 0)
        {
            usr_index_[i].buffer_usr_valid = 1;
            usr_index_[i].buffer_usr_id    = i;
            switch (readMode)
            {
            case EN_READ_PRE:
                usr_index_[i].buffer_rpos = GetPreIFrameIndex(uiFramerate);
                usr_index_[i].uiPreFlag      = 1;
                usr_index_[i].uiFindPreFlag  = 0;
                break;
            case EN_READ_COMMON:
                usr_index_[i].buffer_rpos = video_buffer_.uinewIFrameIndex;//uiConReadIndex;
                break;
            case EN_READ_NEWKEY:
                usr_index_[i].buffer_rpos = video_buffer_.uinewIFrameIndex;
                break;
            default:
                usr_index_[i].buffer_rpos = video_buffer_.uinewIFrameIndex;
                break;
            }
            //usr_index_[i].buffer_rpos = GetNextIFrame(2);
            MOS_MEMSET(usr_index_[i].buffer_name, 0, sizeof(usr_index_[i].buffer_name));
            MOS_PRINTF("video %s find index:%d for consume app:%s, readINdex:%d\n", __FUNCTION__,  i,  (pUserName!=MOS_NULL)?pUserName:"none", usr_index_[i].buffer_rpos);
            if (pUserName != MOS_NULL)
            {
                MOS_STRNCPY(usr_index_[i].buffer_name, pUserName, sizeof((usr_index_[i].buffer_name)));
            }
            ret = i;
            video_buffer_.uiMaxConsumer++;
            break;
        }
    }
    return ret;
}

_INT VideoBuffeMulty::refreshCurrentUsrIdReadtime(_INT usr_id)
{
    _INT ret = -1;
   _INT  i   = usr_id;
   if(usr_index_[i].buffer_usr_valid > 0)
   {
       struct timeval tv;
       gettimeofday(&tv, NULL);
       usr_index_[i].buffer_read_time=tv.tv_sec*1000+tv.tv_usec/1000;
       ret = 0;
   }
   return ret;
}

_INT VideoBuffeMulty::closeCurrentUsrid(_INT usr_id)
{
    KjRwMutexLockGuard  mutex_guard(mutex_video_buffer_, MOS_TRUE);
    if (usr_id < 0 || usr_id >= MAX_USR_ID)
    {
        return MOS_ERR;
    }

    if (usr_index_[usr_id].buffer_usr_valid >= 1)
    {
        _INT i = usr_id;
        usr_index_[i].buffer_usr_valid = 0;
        video_buffer_.uiMaxConsumer--;
        if (video_buffer_.uiMaxConsumer <= 0)
            video_buffer_.uiMaxConsumer = 0;
        MOS_PRINTF("video %s id:%d app:%s,left_maxuser:%u \n", __FUNCTION__, usr_id, usr_index_[i].buffer_name, video_buffer_.uiMaxConsumer);
    }
    else
    {
        MOS_PRINTF("WARING INVALID video %s id:%d app:%s,left_maxuser:%u \n", __FUNCTION__, usr_id, usr_index_[usr_id].buffer_name, video_buffer_.uiMaxConsumer);
    }
    return MOS_OK;
}
