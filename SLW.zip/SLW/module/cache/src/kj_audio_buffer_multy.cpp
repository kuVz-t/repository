#include "kj_audio_buffer_multy.h"

#define AUDIO_FRAME_SIZE 320

AudioBufferMulty::AudioBufferMulty()
    :audio_alarm_warning_used_(false)
{
    buffer_id_ = 0;
    audio_buffer_.bIsStop = true;
    debug = 0;
    if (KjMutexLock::getFileEixst("/mnt/config/test_audio") == 0)
    {
        debug  = 1;
    }
}

_INT AudioBufferMulty::bufferInit(_INT oneBufsize, _INT frame_num, _INT buffer_id, _INT inNoNeedMutex)
{
    _INT   i;
    _INT   j;
    PCM_BUFFER_NUM = frame_num;
    audio_buffer_.bIsStop = false;
    buffer_id_ = buffer_id;
    iNoNeedMutexFlag = inNoNeedMutex;
    audio_buffer_.is_using = 0;
    audio_buffer_.nMaxConsumer = 0;
    memset(&audio_buffer_, 0, sizeof(audio_buffer_));
    audio_buffer_.pcmData = (T_PCM_DATA_MULTY *)malloc(sizeof(T_PCM_DATA_MULTY)*PCM_BUFFER_NUM);
    for (i=0; i<PCM_BUFFER_NUM; i++)
    {
        audio_buffer_.pcmData[i].pData = (char*)malloc(oneBufsize);
        if (MOS_NULL   == audio_buffer_.pcmData[i].pData)
        {
            for (j=0; j<PCM_BUFFER_NUM; j++)
            {
                if (audio_buffer_.pcmData[j].pData != MOS_NULL  )
                {
                    free(audio_buffer_.pcmData[j].pData);
                }
            }
            return -1;
        }
        MOS_MEMSET(audio_buffer_.pcmData[i].lock_index_ , 0,
                sizeof(audio_buffer_.pcmData[i].lock_index_ ));
    }
    audio_buffer_.wpos    = 0;
    audio_buffer_.rpos    = 0;
    audio_buffer_.encType = ENC_TYPE_PCM;
    audio_buffer_.nflag = 0;
    audio_buffer_.iFullFlag = 0;

    audio_params.bitrate = 16;
    audio_params.channel = 1;
    audio_params.sampleRate = 8000;
    return 0;
}

_INT AudioBufferMulty::changeAudioParams(_UI channel, _UI samprate, _UI bitrate, unsigned char type)
{
    audio_params.bitrate = bitrate;
    audio_params.channel = channel;
    audio_params.sampleRate = samprate;
    audio_params.audio_type = type;
    return MOS_OK;
}

_INT AudioBufferMulty::bufferClean()
{
    KjRwMutexLockGuard  mutex_guard(mutex_audio_buffer_, 1);
    audio_buffer_.wpos    = 0;
    audio_buffer_.rpos    = 0;
    audio_buffer_.encType = ENC_TYPE_PCM;
    audio_alarm_warning_used_ = false;
    audio_buffer_.is_using = 0;
    audio_buffer_.nflag = 0;
    audio_buffer_.iFullFlag = 0;
    audio_buffer_.nMaxConsumer =0;
    for(_INT i=0; i<MAX_USR_AUDIO_ID; i++)
    {
        if(usr_index_[i].buffer_usr_valid > 0)
        {
            usr_index_[i].buffer_rpos = audio_buffer_.rpos;
        }
    }
    return 0;
}

_INT AudioBufferMulty::bufferClose()
{
    KjRwMutexLockGuard  mutex_guard(mutex_audio_buffer_, 1);
    _INT i;
    audio_buffer_.bIsStop  = true;
    audio_buffer_.is_using = 0;

    //wait capture thread return
    for (i=0; i<PCM_BUFFER_NUM; i++)
    {
        if (audio_buffer_.pcmData[i].pData != MOS_NULL  )
        {
            MOS_FREE(audio_buffer_.pcmData[i].pData);
            audio_buffer_.pcmData[i].pData= MOS_NULL  ;
        }
    }
    if(audio_buffer_.pcmData != MOS_NULL  )
    {
        MOS_FREE(audio_buffer_.pcmData);
        audio_buffer_.pcmData = MOS_NULL  ;
    }

    MOS_PRINTF("AudioBufferMulty::bufferClose PCM_BUFFER_NUM:%d \r\n", PCM_BUFFER_NUM);
    return 0;
}

_INT AudioBufferMulty::setBufferStatus(_INT isStop)
{
    audio_buffer_.bIsStop = isStop;
    audio_buffer_.wpos    = 0;
    audio_buffer_.rpos    = 0;
    return MOS_OK;
}

_INT AudioBufferMulty::readOneGopOk(_INT isFource)
{
    KjRwMutexLockGuard  mutex_guard(mutex_audio_buffer_, 1, iNoNeedMutexFlag);
    if (audio_buffer_.bIsStop)
    {
        //MOS_PRINTF ("videoProc_wrData isStop\n");
        return RD_ERROR_CODE_STOPED;
    }

    if (audio_buffer_.wpos == audio_buffer_.rpos)
    {
        return RD_ERROR_CODE_NODATA;
    }

    if (audio_buffer_.is_using >= 1)
    {
        //MOS_PRINTF (" audio buffer need to lost frame, but is in usesing !!!\n");
        return 0;
    }

    _INT count = 0;
    if(debug > 0)
    MOS_PRINTF ("readgpo audio wps:%u, rpos:%u\n", audio_buffer_.wpos , audio_buffer_.rpos);
    _INT  maxDeletCount = (PCM_BUFFER_NUM/2>30)?30:PCM_BUFFER_NUM/2;
    int startIndex = audio_buffer_.rpos;
    while(count <= maxDeletCount)
    {
        count++;
        if (audio_buffer_.pcmData[startIndex].nUserCount != 0)
        {
            for(_INT i=0; i<MAX_USR_AUDIO_ID; i++)
            {
                if(usr_index_[i].buffer_usr_valid > 0)
                {
                    if (audio_buffer_.pcmData[startIndex].lock_index_[i] == 1 && !isFource)
                    {
                        MOS_PRINTF("%s %d id:%d in app:%s using delete buf %d!!\n", __FUNCTION__, __LINE__,  i, usr_index_[i].buffer_name,  startIndex);
                        return WR_FLAG_BUFFER_INUSER;
                    }
                }
            }
        }
        startIndex = (startIndex+1)%PCM_BUFFER_NUM;
    }

    count = 0;
    _INT  bResetValid = 0;
    while(count <= maxDeletCount)
    {
        count++;
        //if (audio_buffer_.pcmData[audio_buffer_.rpos].nUserCount != 0)
        {
            for(_INT i=0; i<MAX_USR_AUDIO_ID; i++)
            {
                if(usr_index_[i].buffer_usr_valid > 0)
                {
                    if (usr_index_[i].buffer_rpos == audio_buffer_.rpos)
                    {
                        MOS_PRINTF("%s %d id:%d -name:%s usr usrrps:%d allrps:%u reset -1!!\n", __FUNCTION__, __LINE__,i, usr_index_[i].buffer_name, usr_index_[i].buffer_rpos, audio_buffer_.rpos);
                        usr_index_[i].buffer_rpos = -1;
                        bResetValid = 1;
                    }
                }
            }
        }
        MOS_MEMSET(audio_buffer_.pcmData[audio_buffer_.rpos].lock_index_ , 0,
                sizeof(audio_buffer_.pcmData[audio_buffer_.rpos].lock_index_ ));
        audio_buffer_.pcmData[audio_buffer_.rpos].nUserCount  = 0;
        audio_buffer_.rpos = (audio_buffer_.rpos+1)%PCM_BUFFER_NUM;
    }

    if (bResetValid)
    {
        for(_INT i=0; i<MAX_USR_AUDIO_ID; i++)
        {
            if(usr_index_[i].buffer_usr_valid > 0)
            {
                if (usr_index_[i].buffer_rpos == -1)
                {
                    MOS_PRINTF("%s %d id:%d usr reset!!\n", __FUNCTION__, __LINE__, audio_buffer_.rpos);
                    usr_index_[i].buffer_rpos = audio_buffer_.rpos;
                }
            }
        }
    }
    if(debug > 0)
    MOS_PRINTF ("end __%s wps:%u, rpos:%u\n",__FUNCTION__, audio_buffer_.wpos , audio_buffer_.rpos);
    return 0;
}

_INT AudioBufferMulty::writeData(_VPTR pdata, _INT size, bool is_alarm_audio,
                           struct timeval *tv_capture,_UI time_pts)
{
    KjRwMutexLockGuard  mutex_guard(mutex_audio_buffer_, 1);
    if (audio_buffer_.bIsStop)
    {
        return RD_ERROR_CODE_STOPED;
    }
    if(audio_alarm_warning_used_ && (!is_alarm_audio))
    {
        return RD_ERROR_CODE_BUSY;
    }
    if (size != AUDIO_FRAME_SIZE)
    {
        MOS_PRINTF("Error!!! The Audio Frame Size Must be 320");
    }

    //if(audio_buffer_.nflag == WR_FLAG_NEED_KEYFRAME)
    {
        if (((audio_buffer_.wpos+1)%PCM_BUFFER_NUM) == audio_buffer_.rpos)
        {
            audio_buffer_.nflag = WR_FLAG_NEED_WAITFULL;//需要判断是否满了
            //MOS_PRINTF("%s %d buffer is full:\n", __FUNCTION__, __LINE__);
            return WR_FLAG_FULL;
        }
        audio_buffer_.nflag = WR_FLAG_NORMAL;
    }
    if(debug > 0)
    MOS_PRINTF ("%s audio size:%d wpos:%d\n", __FUNCTION__, size, audio_buffer_.wpos);
    memcpy(audio_buffer_.pcmData[audio_buffer_.wpos].pData, pdata, size);
    audio_buffer_.pcmData[audio_buffer_.wpos].size = size;
    MOS_MEMSET(audio_buffer_.pcmData[audio_buffer_.wpos].lock_index_ , 0,
            sizeof(audio_buffer_.pcmData[audio_buffer_.wpos].lock_index_ ));

    if(tv_capture != MOS_NULL  )
    {
        audio_buffer_.pcmData[audio_buffer_.wpos].tv = *tv_capture;
    }
    audio_buffer_.pcmData[audio_buffer_.wpos].time_pts = time_pts;
    //如果下一帧要写入即将要满了，先标记起来
    if (0)//((audio_buffer_.wpos+1)%PCM_BUFFER_NUM) == audio_buffer_.rpos)
    {
        audio_buffer_.nflag = WR_FLAG_NEED_WAITFULL;//需要判断是否满了
    }
//    else  if(debug > 0)
//    {
//        MOS_PRINTF("write audio,size:%05d is_keyframe:%d wpos:%02d, ts:%u\n", size, 1, audio_buffer_.wpos, (unsigned int)time_pts);
//    }

    audio_buffer_.wpos++;
    if (audio_buffer_.wpos >= PCM_BUFFER_NUM)
    {
        audio_buffer_.iFullFlag = 1; // 预录模式使用，表示音频缓存器已写满
        audio_buffer_.wpos = 0;
    }
    return 0;
}

_INT AudioBufferMulty::printfCahepts()
{
    if (audio_buffer_.bIsStop)
    {
        //MOS_PRINTF ("AudioProc_wrData isStop\n");
        return RD_ERROR_CODE_STOPED;
    }
    if (audio_buffer_.wpos == audio_buffer_.rpos)
    {
        return RD_ERROR_CODE_NODATA;
    }
    _INT curent_r_pos = audio_buffer_.rpos;

    while(curent_r_pos != audio_buffer_.wpos)
    {
        curent_r_pos++;
        if (curent_r_pos >= PCM_BUFFER_NUM)
        {
            curent_r_pos = 0;
        }
    }
    return MOS_OK;
}

_INT AudioBufferMulty::readData(char **pdata, _INT *size, _INT usr_id, struct timeval *tv_capture, _UI *time_pts)
{
    KjRwMutexLockGuard  mutex_guard(mutex_audio_buffer_, 0, iNoNeedMutexFlag);
    if (audio_buffer_.bIsStop)
    {
        //MOS_PRINTF ("AudioProc_wrData isStop\n");
        return RD_ERROR_CODE_STOPED;
    }

    if(audio_buffer_.nflag == WR_FLAG_NEED_WAITFULL)
    {
        return RD_ERROR_CODE_WAITE;//wait write data recover
    }


    if(usr_index_[usr_id].buffer_usr_valid <= 0)
    {
        return RD_ERROR_CODE_INVALID;
    }

    _INT rpos = usr_index_[usr_id].buffer_rpos;
    if (audio_buffer_.wpos == rpos)
    {
        //MOS_PRINTF ("wpos:%d\n", audio_buffer_.wpos, rpos);
        return RD_ERROR_CODE_NODATA;
    }

    *pdata = audio_buffer_.pcmData[rpos].pData;
    *size = audio_buffer_.pcmData[rpos].size;
    if(tv_capture != MOS_NULL  )
    {
        *tv_capture = audio_buffer_.pcmData[rpos].tv;
    }
    if(time_pts != MOS_NULL  )
    {
        *time_pts = audio_buffer_.pcmData[rpos].time_pts;
    }
    audio_buffer_.pcmData[rpos].nUserCount++;
    audio_buffer_.pcmData[rpos].lock_index_[usr_id] = 1;

    if(debug > 0)
    MOS_PRINTF ("%s wpos:%u, usrid:%d rpos:%d, usredF:%d \n", __FUNCTION__, audio_buffer_.wpos, usr_id, rpos, audio_buffer_.pcmData[rpos].lock_index_[usr_id]);
    //audio_buffer_.pcmData[rpos].lock_index_ |= (1<<usr_id)&0xffffffff;
//    if(debug>0)
//    MOS_PRINTF (" audio_buffer_.pcmData[rpos].lock_index_:%04x\n",  audio_buffer_.pcmData[rpos].lock_index_[usr_id]);

    return 0;
}

_INT AudioBufferMulty::readOk(_INT usr_id)
{
    KjRwMutexLockGuard  mutex_guard(mutex_audio_buffer_, 0, iNoNeedMutexFlag);
    if(usr_id < 0 || usr_id>=MAX_USR_AUDIO_ID)
    {
//        audio_buffer_.rpos++;
//        if (audio_buffer_.rpos >= PCM_BUFFER_NUM)
//        {
//            audio_buffer_.rpos = 0;
//        }
        MOS_PRINTF("%s %d error\n", __FUNCTION__, __LINE__);
        return 0;
    }
    else
    {
        _INT current_read_pos = usr_index_[usr_id].buffer_rpos;
        if (audio_buffer_.pcmData[current_read_pos].lock_index_[usr_id] != 1)
        {

            MOS_PRINTF ("audio rpos:%d usrid:%d  not preset:%d!!, ignor read ok!! usrName:%s\n",
                        current_read_pos, usr_id, audio_buffer_.pcmData[current_read_pos].lock_index_[usr_id], usr_index_[usr_id].buffer_name);

            return 0;
        }
        //audio_buffer_.pcmData[current_read_pos].nUserCount++;
        audio_buffer_.pcmData[current_read_pos].lock_index_[usr_id] = 0;

        usr_index_[usr_id].buffer_rpos++;
        if (usr_index_[usr_id].buffer_rpos >= PCM_BUFFER_NUM)
        {
            usr_index_[usr_id].buffer_rpos = 0;
        }

        //check if all consumer is readok, then release rpos buf
        if (audio_buffer_.pcmData[current_read_pos].nUserCount < audio_buffer_.nMaxConsumer)
        {
            //MOS_PRINTF("%s %d %d %d\n", __FUNCTION__, __LINE__, audio_buffer_.pcmData[current_read_pos].nUserCount, audio_buffer_.nMaxConsumer);
            return 0;
        }
        else
        {
            for(_INT i=0; i<MAX_USR_AUDIO_ID; i++)
            {
                if(usr_index_[i].buffer_usr_valid > 0)
                {
                   if (audio_buffer_.pcmData[current_read_pos].lock_index_[i] != 0)
                   {
                       return 0;
                   }
                }
            }
        }
        //MOS_PRINTF("%s %d %d %d %d\n", __FUNCTION__, __LINE__, current_read_pos, audio_buffer_.pcmData[current_read_pos].nUserCount, audio_buffer_.nMaxConsumer);

        //audio_buffer_.pcmData[current_read_pos].lock_index_ = 0; //add by hejh
        MOS_MEMSET(audio_buffer_.pcmData[current_read_pos].lock_index_ , 0,
                sizeof(audio_buffer_.pcmData[current_read_pos].lock_index_ ));
        audio_buffer_.pcmData[current_read_pos].nUserCount  = 0;
        audio_buffer_.rpos++;
        if (audio_buffer_.rpos >= PCM_BUFFER_NUM)
        {
            audio_buffer_.rpos = 0;
        }
        return 0;
    }
    return 0;
}


_INT AudioBufferMulty::setCurrentUsrId(_UC *pUserName,_UI readMode)
{
    KjRwMutexLockGuard  mutex_guard(mutex_audio_buffer_, 1);
    _INT ret = -1;
    for(_INT i=0; i<MAX_USR_AUDIO_ID; i++)
    {
        if(usr_index_[i].buffer_usr_valid <= 0)
        {
            usr_index_[i].buffer_usr_valid = 1;
            usr_index_[i].buffer_usr_id    = i;
            if (readMode == EN_READ_PRE)
            {
                // 当缓存器未写满，从最开始读取音频
                if (audio_buffer_.iFullFlag)
                {
                    if (audio_buffer_.wpos >= (25*AUDIO_FIND_SEC))
                    {
                        usr_index_[i].buffer_rpos =  audio_buffer_.wpos - (25*AUDIO_FIND_SEC);
                    }
                    else
                    {
                        usr_index_[i].buffer_rpos =  PCM_BUFFER_NUM - ((25*AUDIO_FIND_SEC) - audio_buffer_.wpos);
                    }
                }
                else
                {
                    usr_index_[i].buffer_rpos = audio_buffer_.rpos;
                }
                // MOS_PRINTF("setCurrentUsrId[%d] audio_buffer_.iFullFlag: %d audio_buffer_.wpos:%u usr_index_[i].buffer_rpos: %d\r\n", i, audio_buffer_.iFullFlag, audio_buffer_.wpos, usr_index_[i].buffer_rpos);
            }
            else
            {
                usr_index_[i].buffer_rpos = audio_buffer_.rpos;
            }
            MOS_MEMSET(usr_index_[i].buffer_name, 0, sizeof(usr_index_[i].buffer_name));
            MOS_PRINTF("audio %s find index:%d free!!, app:%s\n", __FUNCTION__,  i,  (pUserName!=MOS_NULL)?pUserName:"none");
            if (pUserName != MOS_NULL)
            {
                MOS_STRNCPY(usr_index_[i].buffer_name, pUserName, sizeof((usr_index_[i].buffer_name)));
            }
            ret = i;
            audio_buffer_.nMaxConsumer++;
            break;
        }
    }
    return ret;
}

_INT AudioBufferMulty::refreshCurrentUsrIdReadtime(_INT usr_id)
{
    _INT ret = -1;
   _INT i = usr_id;
   if(usr_index_[i].buffer_usr_valid > 0)
   {
       //MOS_PRINTF ("%s %d find index:%d free!!\n", __FUNCTION__,  __LINE__, i);
//       struct timeval tv;
//       gettimeofday(&tv, MOS_NULL  );
//       usr_index_[i].buffer_read_time=tv.tv_sec*1000+tv.tv_usec/1000;
       ret = 0;
   }
   return ret;
}

_INT AudioBufferMulty::closeCurrentUsrid(_INT usr_id)
{
    KjRwMutexLockGuard  mutex_guard(mutex_audio_buffer_, 1);
    if (usr_id < 0 || usr_id >= MAX_USR_AUDIO_ID)
    {
        return MOS_ERR;
    }

    if (usr_index_[usr_id].buffer_usr_valid >= 1)
    {
        //clean old datas
        {
            _INT curTmpPos = audio_buffer_ .rpos;
            while (audio_buffer_.pcmData[curTmpPos].nUserCount > 0)
            {
                if (audio_buffer_.pcmData[curTmpPos].lock_index_[usr_id] == 0)
                {
                    break;
                }
                MOS_PRINTF("waring video %s id:%d app:%s, clean curTmpPos:%d\n", __FUNCTION__, usr_id, usr_index_[usr_id].buffer_name, curTmpPos);
                audio_buffer_.pcmData[curTmpPos].nUserCount--;
                audio_buffer_.pcmData[curTmpPos].lock_index_[usr_id] = 0;
                curTmpPos = (audio_buffer_.rpos+1)%PCM_BUFFER_NUM;
                if (curTmpPos == audio_buffer_.wpos)
                {
                    break;
                }
            }
        }
        _INT i = usr_id;
        usr_index_[i].buffer_usr_valid = 0;
        audio_buffer_.nMaxConsumer--;
        if (audio_buffer_.nMaxConsumer <= 0)
            audio_buffer_.nMaxConsumer = 0;
        MOS_PRINTF("audio %s id:%d app:%s,left_maxuser:%u \n", __FUNCTION__, usr_id, usr_index_[i].buffer_name, audio_buffer_.nMaxConsumer);
    }
    else
    {
        MOS_PRINTF("WARING INVALID audio %s id:%d app:%s,left_maxuser:%u \n", __FUNCTION__, usr_id, usr_index_[usr_id].buffer_name, audio_buffer_.nMaxConsumer);
    }
    return MOS_OK;
}

