#ifndef _MEDIA_AUDIO_H
#define _MEDIA_AUDIO_H

#ifdef __cplusplus
extern "C" {
#endif

#include "mos.h"
#include "media_cache_type.h"

typedef  MOS_MASK_HANDLE_TYPE(_HAUDIOREAD)  _HAUDIOREAD;
typedef  MOS_MASK_HANDLE_TYPE(_KJAUDIOREAD) _KJAUDIOREAD;
typedef  MOS_MASK_HANDLE_TYPE(_KJVIDEOREAD) _KJVIDEOREAD;

extern ST_DATA_NODE *MediaVideoDataNodeInit(_VPTR hMem,_INT buf_size, _INT iMemUnitSize);
ST_FRAME_NODE *Media_AudioCreatFrame(_UC *DataBuf, _INT DataBufLen);
_INT Media_AuidoInit();

_INT Media_AuidoDestroy();

_INT Media_WriteAudioFrame(_INT iCamId,_UC *ptFrame,_INT iLen,_UI uiTimeStamp);

_INT Media_ReSetAudioParameter(_INT iCamId,_UI uiSample, _UI uiChannel, _UI uiDepth,_UI uiAudioType);

_HAUDIOREAD Media_AudioCreatReadHandle2(_INT iCamId,_UI uiReadMod, _UC *pUserName); //add by hejh

ST_DATA_NODE *Media_AudioGetOneNode(_HAUDIOREAD hAudioRead);

_VOID Media_AudioSetNodeUsed(_HAUDIOREAD hAudioRead);
_US   Media_AudioGetHisReadMsec(_HAUDIOREAD hAudioRead);

//add one node in to history data node
_VOID Media_AudioHisAddOneNode(_HAUDIOREAD hAudioRead, ST_DATA_NODE *pstDataNode);
_VOID Media_AudioHisDelHeadNode(_HAUDIOREAD hAudioRead);
_VOID Media_AudioHisDelAllNode(_HAUDIOREAD hAudioRead);

//find packNum in each list
ST_DATA_NODE * Media_AudioHisGetPackNode(_HAUDIOREAD hAudioRead, _UI packgSeqNum);

// 音频扩展接口
//ST_DATA_NODE *Media_AudioGetOneNodeEx(_HAUDIOREAD hAudioRead);

_VOID Media_AudioShiftNextNode(_HAUDIOREAD hAudioRead);

_VOID Media_AudioSetNodeUsedEx(_HAUDIOREAD hAudioRead,ST_DATA_NODE *pstADataNode);

_INT Media_AudioDestroyReadHandle2(_HAUDIOREAD hAudioRead); //add by hejh

// 获取 音频数据帧
_INT Media_AudioGetFrame2(_HAUDIOREAD hAudioRead,_OUT ST_FRAME_NODE **pucFrameHead,_OUT _UI *puiTimestamp); //add by hejh
_INT Media_GetAudioBufferFrameNode(_OUT ST_FRAME_NODE **stFrameOut,  _UC *DataBuf, _INT DataBufLen);

_VOID Media_AudioSetFrameUsed2(_HAUDIOREAD hAudioRead); //add by hejh
_VOID Media_FreeAudioBufferFrameNode(ST_FRAME_NODE *stFrameIn);
_INT Media_AuidoCleanBuffer();


#ifdef __cplusplus
}
#endif


#endif
