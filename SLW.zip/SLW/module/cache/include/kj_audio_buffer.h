#ifndef JK_AUDIO_BUFFER_H
#define JK_AUDIO_BUFFER_H

#define AUDIO_ONEBUF_SIZE 340
#include <string.h>
#include "stdio.h"
#include "stdlib.h"
#include "kj_mutex.h"
#include "media_cache_type.h"


typedef struct {
#ifdef USE_SHARED_PTR
    shared_ptr<char>  pData;
#else
    char *            pData;
#endif
    unsigned int      size;
    struct timeval    tv;
    long long    time_pts;
}T_PCM_DATA;

typedef struct {
    bool          bIsStop;
    int           encType;
    T_PCM_DATA    *pcmData;
    unsigned int  wpos;
    unsigned int  rpos;
    unsigned int  oneBufsize;

    char *        pEncBuffer;
    unsigned int  nEncBufferSize;
    int           is_using;

}T_AUDIO_PROC;

class AudioBuffer
{
public:
    AudioBuffer();
    int bufferInit(int oneBufsize, int frame_num=8, int buffer_id=0);
    int bufferClose();
    int writeData(void* pdata, int size, bool is_alarm_audio=false,
                  struct timeval *tv_capture=NULL,  long long time_pts=0);
    
    int readDataIsEnd();
    int readData(char **pdata, int *size, int usrId=0, struct timeval *tv_capture=NULL, long long *time_pts=NULL);
    int readOk(int usrId=0);

    int setAlarmWaringUsed(bool used)
    {
        audio_alarm_warning_used_ = used;
        return 0;
    }

    int getAlarmWaringUsed()
    {
        return audio_alarm_warning_used_;
    }

    int getIsBufferUsing()
    {
        return audio_buffer_.is_using;
    }

    int setIsbufferUsing(int is_used)
    {
        audio_buffer_.is_using = is_used;
        return 0;
    }

    int bufferClean();
    int readOneGopOk();
    int printfCahepts();
    int setBufferStatus(int isStop=1);
    _INT setCurrentUsrId();
    _INT closeCurrentUsrid(_INT usr_id);
private:
   T_AUDIO_PROC audio_buffer_;
   bool         audio_alarm_warning_used_;
   KjMutexLock  mutex_audio_buffer_;
   int          PCM_BUFFER_NUM;
   int          buffer_id_;
};

#endif // JK_AUDIO_BUFFER_H
