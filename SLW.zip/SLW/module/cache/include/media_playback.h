#ifndef MEDIA_PLAYBACK_H
#define MEDIA_PLAYBACK_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "media_cache_type.h"

extern ST_DATA_NODE *MediaVideoDataNodeInit(_VPTR hMem,_INT buf_size, _INT iMemUnitSize);
//playback video & audio handle
_HPBVIDEOREAD Media_SdVideoCreatReadHandle(_UI uiReadMod);
_INT Media_SdVideoDestroyReadHandle(_HPBVIDEOREAD hVideoRead);

_INT Media_SdVideoWriteEmpty(_HPBVIDEOREAD hVideoRead);
_INT Media_SdVideoWriteAvailable(_HPBVIDEOREAD hVideoRead);
ST_DATA_NODE * Media_SdVideoMakeOneNode(_HPBVIDEOREAD hVideoRead, _UC *ucBuf, _UI uiBufLen,
                                        _UI uiTimeStamp, _UC ucFramePos, _UI uiFrmameLen);
//add one node in to history data node
_VOID Media_SdVideoHisAddOneNode(_HPBVIDEOREAD hVideoRead, ST_DATA_NODE *pstDataNode);
_VOID Media_SdVideoHisDelHeadNode(_HPBVIDEOREAD hVideoRead);

//find packNum in playback media list
ST_DATA_NODE * Media_SdVideoHisGetPackNode(_HPBVIDEOREAD hVideoRead, _UI packgSeqNum);

//delete packNum in each list
_VOID Media_SdVideoDelHisPackNode(_HPBVIDEOREAD hVideoRead, _UI packgSeqNum);
_INT  Media_SdVideoDelMultiyNode(_HPBVIDEOREAD hVideoRead, _US startPackgSeqNum);
_INT Media_SdVideoDelAllNode(_HPBVIDEOREAD hVideoRead);

//delete packages in the list
_VOID Media_SdVideoDelListNodes(_HPBVIDEOREAD hVideoRead, ST_MOS_LIST *pstDelSeqList);

ST_DATA_NODE * Media_SdVideoHisGetHead(_HPBVIDEOREAD hVideoRead);
ST_DATA_NODE * Media_SdVideoHisShiftNextNode(_HPBVIDEOREAD hVideoRead);

#ifdef __cplusplus
}
#endif
#endif // MEDIA_PLAYBACK_H
