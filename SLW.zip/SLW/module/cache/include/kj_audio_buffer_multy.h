#ifndef KJ_AUDIO_BUFFER_MULTY_H
#define KJ_AUDIO_BUFFER_MULTY_H
#include "mos.h"
#include "kj_mutex.h"
#include "media_cache_type.h"
#define MAX_USR_AUDIO_ID    20
#define AUDIO_FIND_SEC      6

//设缓冲区大小为N，队头out，队尾in，out、in均是下标表示:

//初始时，in=out=0
//队头队尾的更新用取模操作，out=(out+1)%N，in=(in+1)%N
//out==in表示缓冲区空，(in+1)%N==out表示缓冲区满
//入队que[in]=value;in=(in+1)%N;
//出队ret =que[out];out=(out+1)%N;
//数据长度 len =( in - out + N) % N
#define USER_SAFE_BUFFER 1

#pragma pack (1)
typedef struct
{
    char *            pData;
    _UI               size;
    struct timeval    tv;
    _UI               time_pts;
    _INT              nUserCount;
    _UC               lock_index_[MAX_USR_AUDIO_ID];
}T_PCM_DATA_MULTY;

typedef struct
{
    bool           bIsStop;
    _INT           encType;
    T_PCM_DATA_MULTY    *pcmData;
    _UI            wpos;
    _UI            rpos;
    _UI            oneBufsize;

    char *         pEncBuffer;
    _UI            nEncBufferSize;
    _INT           is_using;
    _INT           nflag;
    _INT           iFullFlag; // 预录模式使用，0：音频缓存器未写满 1：音频缓存器已写满
    _UI            nMaxConsumer;
}T_AUDIO_PROC_MULTY;


typedef struct
{
    _UI  buffer_usr_valid;//0-invald, 1-valid
    _UI  buffer_usr_id; //
    _INT buffer_rpos;
    _UI  buffer_read_time;
    _UC  buffer_name[32];
}struct_audio_buffer_index;

typedef struct
{
    _UI channel; //audio of channel
    _UI sampleRate;
    _UI bitrate;
    unsigned char audio_type;
}T_AUDIO_PARAMES;
#pragma pack ()

typedef enum READ_ERROR_CODE
{
    RD_ERROR_CODE_WAITE   = -5,
    RD_ERROR_CODE_BUSY    = -4,
    RD_ERROR_CODE_INVALID = -3,
    RD_ERROR_CODE_STOPED  = -2,
    RD_ERROR_CODE_NODATA  = -1,
    RD_ERROR_CODE_NOERROR = 0
}ENUM_AUDIO_ERROR_CODE;

typedef enum WRITE_VIDEO_FLAG
{
    WR_FLAG_BUFFER_INUSER = -4,
    WR_FLAG_NEED_INVALID  = -3,
    WR_FLAG_BUFFER_STOP   = -2,
    WR_FLAG_FULL          = -1,
    WR_FLAG_NORMAL        = 0,
    WR_FLAG_NEED_KEYFRAME = 1,
    WR_FLAG_NEED_WAITFULL = 2,
}ENUM_WRITE_VIDEO_FLAG;

class AudioBufferMulty
{
public:
    AudioBufferMulty();
    _INT bufferInit(_INT oneBufsize, _INT frame_num=8, _INT buffer_id=0, _INT inNoNeedMutex=0);
    _INT bufferClose();
    _INT writeData(_VPTR pdata, _INT size, bool is_alarm_audio=false,
                  struct timeval *tv_capture=NULL,  _UI time_pts=0);

    _INT readData(char **pdata, _INT *size, _INT usr_id=0, struct timeval *tv_capture=NULL,
                  _UI *time_pts=NULL);
    _INT readOk(_INT id=-1);

    _INT setAlarmWaringUsed(bool used)
    {
        audio_alarm_warning_used_ = used;
        return 0;
    }

    _INT getAlarmWaringUsed()
    {
        return audio_alarm_warning_used_;
    }

    _INT getIsBufferUsing()
    {
        return audio_buffer_.is_using;
    }

    _INT setIsbufferUsing(_INT is_used)
    {
        audio_buffer_.is_using = is_used;
        return 0;
    }

    _INT bufferClean();
    _INT readOneGopOk(_INT isFource=0);
    _INT printfCahepts();
    _INT setBufferStatus(_INT isStop=1);

    _INT setCurrentUsrId(_UC *pUserName=NULL,_UI readMode=EN_READ_NEWKEY);
    _INT refreshCurrentUsrIdReadtime(_INT usr_id);
    _INT closeCurrentUsrid(_INT usr_id);

    _INT changeAudioParams(_UI channel, _UI samprate, _UI bitrate, unsigned char audioType);

private:
   T_AUDIO_PROC_MULTY audio_buffer_;
   T_AUDIO_PARAMES    audio_params;
   bool           audio_alarm_warning_used_;
   KjRwMutexLock  mutex_audio_buffer_;
   _INT           PCM_BUFFER_NUM;
   _INT           buffer_id_;
   _INT           debug;
   struct_audio_buffer_index usr_index_[MAX_USR_AUDIO_ID];
   _INT           iNoNeedMutexFlag;
};

#endif // JK_AUDIO_BUFFER_H
