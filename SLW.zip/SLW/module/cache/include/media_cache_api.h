#ifndef MEDIA_CACHE_API_H
#define MEDIA_CACHE_API_H

#include "media_cache_type.h"
#include "media_video.h"
#include "media_audio.h"
#include "media_audioplay.h"
#include "media_video_display.h"

#endif
