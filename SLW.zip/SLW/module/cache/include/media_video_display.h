#ifndef _MEDIA_VIDEO_DISPLAY_H
#define _MEDIA_VIDEO_DISPLAY_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "zj_type.h"
#include "media_cache_type.h"

typedef  MOS_MASK_HANDLE_TYPE(_HVPLAYHANDLE)          _HVPLAYHANDLE;

//video play reader
typedef struct
{
    _UI    uiUseFlag;
    _UC    ucsPeerId[64];
    ST_ZJ_VIDEO_PARAM pstVideoParm;
} PLAY_VIDEO_DATA_NODE;

//video play manager
typedef struct stru_VIDEO_TASKMNG
{
    _UI    uiInitFlag;
    _UI    uiStartFlag;
    _UI    uiMaxCnt;
    _UI    uiPlayId;                            // 流媒体管理ID
    _UC    pucResourceID[33];
    _HMUTEX hMutex;                             // 互斥体
    PLAY_VIDEO_DATA_NODE *hVideoPlay;
}ST_VIDEO_TASKMNG;


_INT Media_VideoDisPlayInit();
_INT Media_VideoDisPlayDestroy();

_HVPLAYHANDLE Media_VideoDisPlayCreatHandle(_UC *pucPeerId,ST_ZJ_VIDEO_PARAM *pstVideoParm);

_INT Media_VideoDisPlayCancelFrameBuff(_HVPLAYHANDLE hPlay);

_INT Media_VideoDisPlayWriteFrame(_HVPLAYHANDLE hPlay,_UC* ptData,_UI uiDataLen,_INT is_keyframe,_UI uiTimeStamp);

_INT Media_VideoDisPlayDestroyHandle(_HVPLAYHANDLE hPlay);


_INT Media_VideoDisPlayReadFrameIsEnd();

_INT Media_VideoDisPlayReadFrame(_UC **pucBuff,_INT *is_keyframe,_UI *puiTimeStamp);

_INT Media_VideoDisPlayGetStreamInfo(ST_ZJ_VIDEO_PARAM *pstVideoDes);

void Media_Notify_VideoPlay(_UC *pucPeerId, _UI uiOption);

#ifdef __cplusplus
}
#endif
#endif


