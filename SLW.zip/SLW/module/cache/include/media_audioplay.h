#ifndef _MEDIA_AUDIOPLAY_H
#define _MEDIA_AUDIOPLAY_H
#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "media_cache_type.h"
#include  "zj_type.h"

typedef  MOS_MASK_HANDLE_TYPE(_HAUDIOPLAY)           _HAUDIOPLAY;
typedef  MOS_MASK_HANDLE_TYPE(_HAPLAYREAD)           _HAPLAYREAD;

_INT Media_AudioPlayInit();
_INT Media_AudioPlayDestroy();

_HAUDIOPLAY Media_AudioPlayCreatWriteHandle(_UC *pucPeerId,_UI uiUsrId,ST_ZJ_AUDIO_PARAM *pstAudioParm);

_UC* Media_AudioPlayGetFrameBuff(_HAUDIOPLAY hPlay,_UI uiBuffLen);

_INT Media_AudioPlaySetFrameInfo(_HAUDIOPLAY hPlay,_UI uiFrameLen,_UI uiTimeStamp);

_INT Media_AudioPlayCancelFrameBuff(_HAUDIOPLAY hPlay);

_INT Media_AudioPlayWriteFrame(_HAUDIOPLAY hPlay,_UC* ptData,_UI uiDataLen,_UI uiTimeStamp);

_INT Media_AudioPlayWriteFrame2(_HAUDIOPLAY hPlay,_UC* ptData,_UI uiDataLen,_UI uiTimeStamp);

_INT Media_AudioPlayDestroyWriteHandle(_HAUDIOPLAY hPlay);

// 读相关的接口
_HAPLAYREAD Media_AudioPlayCreatReadHandle(_UC *pucPeerId,_UI uiUsrId);

_INT Media_AudioPlayReadFrameIsEnd();

_INT Media_AudioPlayReadFrame(_HAPLAYREAD hAPlayRead,_UC **pucBuff,_UI *puiTimeStamp,_UI *puiRemFrameCnt);

_UI Media_AudioPlayGetLateFrameTimeStamp(_HAPLAYREAD hAPlayRead);

_INT Media_AudioPlayGetStreamInfo(_HAPLAYREAD hAPlayRead,ST_ZJ_AUDIO_PARAM *pstAudioDes);

_INT Media_AudioPlayDestroyReadHandle(_HAPLAYREAD hAPlayRead);

void Media_Notify_AudioPlay(_UC *pucPeerId, _UI uiStreamType, _UI uiOption, _UI uiUsrId );

#ifdef __cplusplus
}
#endif
#endif


