#ifndef MEDIA_RETRAS_READER_H
#define MEDIA_RETRAS_READER_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "media_cache_type.h"
#include "zj_type.h"
#include "record_api.h"
typedef enum RETRANS_READ_TYPE
{
    EN_RETRANS_READ_RETRY       = 0, //file switch, need get again
    EN_RETRANS_READ_DATAEND     = -1, //file end or no data anymore
    EN_RETRANS_READ_ERRORDATA   = -2, //read error data,file maybe broken
    EN_RETRANS_READ_UNKONWERR   = -3, //internel error, need destory
}EN_RETRANS_READ_TYPE;

//retrans media handler data struct
typedef struct
{
    _UI    iAvType;
    _INT   iCamid;
    _INT   iStreamId;
    _UI    uiReadMod;
    _US    usFileNum;              //file numbers
    _US    usSeqNumIndex;
    _CTIME_T cTimeNext;
    _UI    uiTimeStamp;            //时间戳
    _UI    uiMaxMediaLen;
    _UI    uiEncodeType;
    _UC    aucStartTime[40];
    _UC    aucEndTime[40];
    ST_CFG_VIDEODES   stVideoDes;
    ST_ZJ_AUDIO_PARAM stAudioParm;
    _VPTR  pMediaBuf;
    _VPTR  pstFile;
    ST_FRAME_NODE *stFrame;
    ST_DATA_NODE  *stDataNode;
    ST_MOS_LIST   stNodeList;
} READ_SDMEDIA_DATA_NODE;

extern ST_FRAME_NODE *Media_VideoCreatFrame(_UC *DataBuf, _INT DataBufLen, _UI uiLastResolution, _UI uiCurResolution, _UI uiLastEncType, _UC ucCurEncType);
extern ST_FRAME_NODE *Media_AudioCreatFrame(_UC *DataBuf, _INT DataBufLen);

//creat
_HRTSMEDIAREAD Media_RetrasCreatReadHandle(_UC iCamid, _UI iStreamId, _UC *aucStarTime,   _UC *aucEndTime,
                                           ST_ZJ_AUDIO_PARAM **pstAudioParm, ST_CFG_VIDEODES   **pstVideo);

_INT Media_RetrasDestroyReadHandle(_HRTSMEDIAREAD hVideoRead);

_INT Media_RetrasGetFrame(_HRTSMEDIAREAD hVideoRead,_OUT ST_FRAME_NODE **pucFrameHead,
                          _OUT _UC *ucAvType,  _OUT _INT *puiTimestamp, _IN _UI uiIsIframe);
_VOID Media_RetrasSetFrameUsed(_HRTSMEDIAREAD hVideoRead);

#ifdef __cplusplus
}
#endif
#endif // MEDIA_RETRAS_READER_H
