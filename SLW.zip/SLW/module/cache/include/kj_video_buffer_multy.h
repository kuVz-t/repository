#ifndef KJ_VIDEO_BUFFER_MULTY_H
#define KJ_VIDEO_BUFFER_MULTY_H

#include "mos.h"
#include "kj_mutex.h"
#include "kj_audio_buffer_multy.h"
#define MAX_USR_ID     20
#define MAX_MEDIA_INDE 1000
#define READSTART_INDEX 20
#define VIDEO_FIND_SEC  6

#pragma pack (1)
typedef struct
{
    _UI               uiDataLen;
    _UI               uiOffset;
    _UI               uiFrameType; //当前包的类型
    struct timeval    tv;
    _INT              iTimeStamp;//ms
    _LLID             llTimePts;
    _UI               uiUserCount;
    _UC               lock_index_[MAX_USR_ID];
}ST_VIDEO_BUF;

typedef struct RingBuf_s
{
    _INT    iIsStop;
    _UI     uiMediaType;        //1-video, 2-audio
    _UI 	nIsFull;			/*BUF是否满*/
    _UI 	uiMaxLen;			/*BUF的最大容量*/
    _UI	    uiCurPos;			/*当前位置*/
    _UI	    uiHeadIndex;		/*指向BUF头的索引*/
    _UI 	uiCurIndex;			/*当前的Index*/
    _UI	    uiLeftLen;			/*剩下的BUF长度*/
    _UI	    uiOldestIndex;		/*最旧的Index*/
    _UI     uinewIFrameIndex;	/*最新的I帧Index*/
    _UI     uiConReadIndex;
    _INT    iNeedIflag;
    _UI     uiMaxConsumer;
    _UI     uiEncType;
	_UI     uiResolution;
    ST_VIDEO_BUF index[MAX_MEDIA_INDE];	/*保存每一帧的数据大小和开始点*/
    char 	*pRingBuf;			/*数据存储BUF*/
    //KjMutexLock	lock;		    /*锁*/
}ST_VIDEO_RING_BUF;

typedef struct
{
    _UI  buffer_usr_valid;//0-invald, 1-valid
    _UI  buffer_usr_id; //
    _INT buffer_rpos;
    _UI  buffer_read_time;
    _UC  buffer_name[32];
    _UI  uiPreFlag;
    _UI  uiFindPreFlag;  
}struct_buffer_index;
#pragma pack ()

class VideoBuffeMulty
{
public:
    VideoBuffeMulty();
    _INT bufferInit(_INT oneBufsize, _INT buffer_num=6, _INT buffer_id=0, _UI uiMediaType=1, _UI uiResolution=0, _UI uiEncType=4, _INT inNoNeedMutex=0);
    _INT bufferClose();
    _INT bufferClean();
    _INT writeData(_VPTR pdata, _UI size, _INT is_keyframe,
                  struct timeval *tv_capture=NULL, _INT time_stamp=0, _LLID time_pts=0);

    _INT readData(char* *pdata, _INT *size, _INT usr_id=0, _INT *is_keyfram=NULL,
                 struct timeval *tv_capture=NULL, _INT *time_stamp=NULL, _LLID *time_pts=NULL, _UI *uiResolution=NULL,_UI *uiEncType=NULL);
    _INT readOk(_INT usr_id=-1);

    _INT isBufferInitialed()
    {
        return !video_buffer_.iIsStop;
    }

    _INT readOneVideoGopOk(_INT isFource=0);
    _INT setCurrentUsrId(_INT readMode=EN_READ_NEWKEY, _UC *pUserName=NULL, _UI uiFramerate=0);
    _INT refreshCurrentUsrIdReadtime(_INT usr_id);
    _INT closeCurrentUsrid(_INT usr_id);
    _UI  GetNextIFrame(_UI PreFlag);
    _INT GetPreIFrameIndex(_UI uiFramerate);
    _UI  resetMediaParam(_UI uiResolution, _UI uiEncType);

private:
   ST_VIDEO_RING_BUF  video_buffer_;
   _INT               iMaxBufNum;
   _INT               oneBufsize_;
   _INT               buffer_id_;
   _INT               debug;
   struct_buffer_index usr_index_[MAX_USR_ID];
   KjRwMutexLock      mutex_video_buffer_;
   _INT               iNoNeedMutexFlag;
};
#endif // JK_VIDEO_BUFFER_H
