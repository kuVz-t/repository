#ifndef KJ_VIDEO_BUFFER_DISPLAY_H
#define KJ_VIDEO_BUFFER_DISPLAY_H
#include "mos.h"
#include "kj_mutex.h"
#include "media_cache_type.h"
#define MAX_DISPLAY_MEDIA_INDE 1000

#pragma pack (1)

typedef enum READ_ERROR_DISPLAY_CODE
{
    RD_ERROR_DISPLAY_CODE_WAITE   = -5,
    RD_ERROR_DISPLAY_CODE_BUSY    = -4,
    RD_ERROR_DISPLAY_CODE_INVALID = -3,
    RD_ERROR_DISPLAY_CODE_STOPED  = -2,
    RD_ERROR_DISPLAY_CODE_NODATA  = -1,
    RD_ERROR_DISPLAY_CODE_NOERROR = 0
}ENUM_DISPLAY_ERROR_CODE;

typedef enum WRITE_VIDEO_DISPLAY_FLAG
{
    WR_FLAG_DISPLAY_BUFFER_INUSER = -4,
    WR_FLAG_DISPLAY_NEED_INVALID  = -3,
    WR_FLAG_DISPLAY_BUFFER_STOP   = -2,
    WR_FLAG_DISPLAY_FULL          = -1,
    WR_FLAG_DISPLAY_NORMAL        = 0,
    WR_FLAG_DISPLAY_NEED_KEYFRAME = 1,
    WR_FLAG_DISPLAY_NEED_WAITFULL = 2,
}ENUM_WRITE_VIDEO_DISPLAY_FLAG;

typedef struct
{
    _UI               uiDataLen;
    _UI               uiOffset;
    _UI               uiFrameType; //当前包的类型
    struct timeval    tv;
    _INT              iTimeStamp;//ms
    _LLID             llTimePts;
    _UI               uiUserCount;
}ST_VIDEO_DISPLAY_BUF;

typedef struct RingBuf_s
{
    _INT    iIsStop;
    _UI     uiMediaType;        //1-video, 2-audio
    _UI 	nIsFull;			/*BUF是否满*/
    _UI 	uiMaxLen;			/*BUF的最大容量*/
    _UI	    uiCurPos;			/*当前位置*/
    _UI	    uiHeadIndex;		/*指向BUF头的索引*/
    _UI 	uiCurIndex;			/*当前的Index*/
    _UI	    uiLeftLen;			/*剩下的BUF长度*/
    _UI	    uiOldestIndex;		/*最旧的Index*/
    _UI     uinewIFrameIndex;	/*最新的I帧Index*/
    _UI     uiConReadIndex;
    _INT    iNeedIflag;
    _UI     uiMaxConsumer;
    _UI     uiEncType;
	_UI     uiResolution;
    ST_VIDEO_DISPLAY_BUF index[MAX_DISPLAY_MEDIA_INDE];	/*保存每一帧的数据大小和开始点*/
    char 	*pRingBuf;			/*数据存储BUF*/
    //KjMutexLock	lock;		    /*锁*/
}ST_VIDEO_DISPLAY_RING_BUF;

typedef struct
{
    _UI  buffer_usr_valid;//0-invald, 1-valid
    _INT buffer_rpos;
    _UI  buffer_read_time;
    _UC  buffer_name[32];
}ST_VIDEO_DISPLAY_BUFFER_INDEX;
#pragma pack ()

class VideoBuffeDisplay
{
public:
    VideoBuffeDisplay();
    _INT bufferInit(_INT oneBufsize, _INT buffer_num=1);
    _INT bufferClose();
    _INT bufferClean();
    _INT writeData(_VPTR pdata, _UI size, _INT is_keyframe,
                  struct timeval *tv_capture=NULL, _INT time_stamp=0, _LLID time_pts=0);

    _INT readData(char* *pdata, _INT *size, _INT *is_keyfram=NULL, _INT *time_stamp=NULL, _LLID *time_pts=NULL);
    _INT readOk();

    _INT setCurrentUsrId(_UC *pUserName=NULL);
    _INT closeCurrentUsrid();

private:
   ST_VIDEO_DISPLAY_RING_BUF  video_display_buffer_;
   _INT               iMaxBufNum;
   _INT               oneBufsize_;
   _INT               buffer_id_;
   _INT               debug;
   ST_VIDEO_DISPLAY_BUFFER_INDEX usr_index_;
   KjRwMutexLock      mutex_video_buffer_;
   _INT               iNoNeedMutexFlag;
};
#endif // JK_VIDEO_BUFFER_H
