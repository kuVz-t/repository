#ifndef _MEDIA_VIDEO_H
#define _MEDIA_VIDEO_H

#ifdef __cplusplus
extern "C" {
#endif
#include "mos.h"
#include "media_cache_type.h"

typedef  MOS_MASK_HANDLE_TYPE(_HVIDEOREAD)     _HVIDEOREAD;

_INT Media_VideoInit();
_INT Media_VideoDestroy();
ST_DATA_NODE *MediaVideoDataNodeInit(_VPTR hMem, _INT buf_size, _INT iMemUnitSize);
ST_FRAME_NODE *Media_VideoCreatFrame(_UC *DataBuf, _INT DataBufLen, _UI uiLastResolution, _UI uiCurResolution, _UI uiLastEncType, _UC ucCurEncType);

_INT Media_WriteVideoFrame(_INT iCamid,_INT iStreamId,_UC *ptFrame,_INT iLen,_UI uiTimeStamp,_UI uiFrameType);
_INT Media_WriteVideoNaluFrame(_INT iCamid,_INT iStreamId,_UC *ptNalu[],_INT iNaluLen[],_INT iNaluNum,_UI uiTimeStamp,_UI uiFrameType);
_INT Media_ReSetVideoParameter(_INT iCamid,_INT iStreamId, _UI uiResolution, _UI uiEncType);

_INT Media_VideoGetTotalReadNum();
_US  Media_VideoGetHisReadMsec(_HVIDEOREAD hVideoRead);

/* 读句柄的创建 */
_HVIDEOREAD Media_VideoCreatReadHandle2(_INT iCamid,_INT iStreamId,_UI uiReadMod,_UI uiKeyQuality, _UC *pUserName); //add by hejh

ST_DATA_NODE *Media_VideoGetOneNode(_HVIDEOREAD hVideoRead);
// 释放当前节点
_VOID Media_VideoSetNodeUsed(_HVIDEOREAD hVideoRead);
// 释放指定的节点
_VOID Media_VideoSetNodeUsedEx(_HVIDEOREAD hVideoRead,ST_DATA_NODE* pstDataNode);
// 偏移到下个节点
_VOID Media_VideoShiftNextNode(_HVIDEOREAD hVideoRead);

//add one node in to history data node
_VOID Media_VideoHisAddOneNode(_HVIDEOREAD hVideoRead, ST_DATA_NODE *pstDataNode);
_VOID Media_VideoHisDelHeadNode(_HVIDEOREAD hVideoRead);
_VOID Media_VideoHisDelAllNode(_HVIDEOREAD hVideoRead);

//find packNum in each list
ST_DATA_NODE * Media_VideoHisGetPackNode(_HVIDEOREAD hVideoRead, _UI packgSeqNum);


/*读句柄 的销毁*/
_INT Media_VideoDestroyReadHandle2(_HVIDEOREAD hVideoRead);//add by hejh 12-17

/**** 读取 一个视频帧  返回 值 小于 0  表示 出错  ， 0 表示  没有数据 ,大于 0  表示 读取正确****/
_INT Media_VideoGetFrame2(_HVIDEOREAD hVideoRead,_OUT ST_FRAME_NODE **pucFrameHead,_OUT _INT *puiTimestamp,_OUT _LLID  *llTimePts);//add by hejh 12-17
_INT Media_GetVideoBufferFrameNode(_OUT ST_FRAME_NODE **stFrameOut,  _UC *DataBuf, _INT DataBufLen, _UI uiLastResolution, _UI uiCurResolution, _UI uiLastEncType, _UC ucCurEncType);

_VOID Media_VideoSetFrameUsed2(_HVIDEOREAD hVideoRead);//add by hejh 12-17
_VOID Media_FreeVideoBufferFrameNode(ST_FRAME_NODE *stFrameIn);
_INT Media_VideoCleanBuffer();

#ifdef __cplusplus
}
#endif

#endif
