#ifndef _MEDIA_CACHE_TYPE_H
#define _MEDIA_CACHE_TYPE_H
#ifdef __cplusplus
extern "C" {
#endif
#define  MD_FRAME_HEAD                                  0X8
#define  MD_FRAME_TAIL                                  0X4
#define  MD_NAUL_HEAD                                   0X2
#define  MD_NALU_TAIL                                   0X1
#define  MD_GETFRAMEHIGH(ucframeType)                  ((ucframeType & 0xF0))
#define  MD_GETFRAMETYPE(ucframeType)                  ((ucframeType & 0xF0) >> 4)
#define  MD_GETFRAMEPOS(ucframeType)                   (ucframeType & 0x0F)
#define  SDK_MAX_READ_NUM                               8
#define  MAX_CAMERA_ID                                  2
#define  MAX_MEDIA_BODY_LEN                             1400
#define  MAX_P2PMEDIA_BODY_LEN                          1200
#define  MAX_MEDIA_PACKEG_LEN                           1500
#define  MAX_HISTORY_VIDEO_FRAME                        10       //20
#define  MAX_HISTORY_AUDIO_FRAME                        (25*3/4) //(25*3/2)
#define  MAX_PLAYBACK_VIDEO_FRAME                       400
#define  MAX_PLAYBACK_AUDIO_FRAME                       200
#define  MAX_TRANS_DATA_LEN                             (100*1024)
typedef  MOS_MASK_HANDLE_TYPE(_HPBVIDEOREAD)           _HPBVIDEOREAD;  //playback media
typedef  MOS_MASK_HANDLE_TYPE(_HRTSMEDIAREAD)          _HRTSMEDIAREAD; //retras media
#define  LOG_MEDIA_CACHE                                "CH"
#define  AUDIO_ENC_SIZE                                 324
#define  VIDEOCACHE_BUF_UNIT_SIZE                       1272// 1472
#define  MOS_MEM_MAXVIDEO_POOL_SIZE                     24  //20
#define  MOS_MEM_MAXAUDIO_POOL_SIZE                     10
#define  VIDEOCACHE_BUF_MID_SIZE                        (300 * VIDEOCACHE_BUF_UNIT_SIZE)
#define  AUDIOCACHE_BUF_UNIT_SIZE                       392
#define  AUDIOCACHE_BUF_MID_SIZE                        (100 * AUDIOCACHE_BUF_UNIT_SIZE)
#define  MEDIA_BUFFER_USER_MEMSEA                        1

typedef enum
{
    ENC_TYPE_PCM = 0,
    ENC_TYPE_ADPCM_IMA,
    ENC_TYPE_AAC,
    ENC_TYPE_COUNT
}AUDIO_ENCODE_TYPE_CC;

typedef enum  EN_READ_MODE
{
    EN_READ_PRE = 0,    // 预录的 读取方式
    EN_READ_COMMON,     // 正常的读取方式
    EN_READ_ATONCE,
    EN_READ_NEWKEY      // 读取最新的关键帧 stream 指的是 shv
}EN_READ_MODE;

typedef enum 
{
    EN_NODATA_UNKOMN     = 0,
    EN_NODATA_NOTWRITE   = 1,
    EN_NODATA_NOKEYFRAME = 2
}EN_NODATA_TYPE;

typedef enum
{
    EN_FRAMETYPE_P,
    EN_FRAMETYPE_I,         // 仅代表SPS
    EN_FRAMETYPE_UNKOMN
}EN_FRAME_TYPE;

typedef enum
{
    EN_VIDEOPARAM_CHANGED_NONE = 0,
    EN_VIDEOPARAM_CHANGED_RES  = 1,
    EN_VIDEOPARAM_CHANGED_ENC  = 2
}EN_VIDEOPARAM_CHANGED;

typedef struct ST_FRAME_NODE
{
    _UC  ucVideoResolutionChangeFlag;   // 改变视频flag,0无操作 1,分辨率改变 2,编码类型改变, refrence EN_VIDEOPARAM_CHANGED
    _UC  ucFramPos;         // 高四位是帧类型 ， 然后从高到低依次为 帧开始 帧结束 nual 开始 nalu 结束
    _INT usDatalen;         // Data 长度
    _UI  uiRemFrameLen;     // 剩余帧的长度
    _UI  uiNaluLen;         // 当前Nalu的长度
    char *ptDatabuff;       // Data
    struct ST_FRAME_NODE *ptnest;
}ST_FRAME_NODE;

typedef struct ST_DATA_NODE
{
    _UC ucCheckFlag;             // check 位
    _UC ucDesInd;
    _UC ucWaitCnt;
    _UC ucRsv;
    _UI uiTimeStamp;            //时间戳
    _US usSeqNum;               //包序列号 
    _US usOffset;               //偏移量
    _US usFramRemPackect;       //该frame剩余包的数目
    _US usSkpLen;               //加头后的偏移量
    _UC aucUseFlag[SDK_MAX_READ_NUM];     //是否在发送的标识
    struct ST_DATA_NODE *pstnext;
    struct ST_DATA_NODE *pstFrameHead; //每一帧的头包
    ST_FRAME_NODE        stFrameNode;
    _UC ptbuff[0];
}ST_DATA_NODE;

//media data node info
typedef struct ST_DATA_NODE_INFO
{
    ST_DATA_NODE    *stHdataNode;
    ST_MOS_LIST_NODE stNode;
}ST_DATA_NODE_INFO;

typedef struct ST_DATA_PACKAGE_INFO
{
    _UI     uiPackNum;
    ST_MOS_LIST_NODE stNode;
}ST_DATA_PACKAGE_INFO;

//live video handler data struct
typedef struct
{
    _UI    id;                     // 同缓存器
    _INT   iCamid;
    _INT   iStreamId;
    _UI    uiReadMod;
    _UI    uiKeyQuality;
    _UI    uiMaxHisCount;
    _US    usSeqNumIndex;          //包序列号
    _US    usHisTimeMsec;           //history package time
    _UI    uiTimeStamp;            //时间戳
    _LLID  llTimePts;               //内部毫秒时间戳
    _UI    uiEncodeType;
	_UI    uiResolution;
    ST_FRAME_NODE *stFrame;
    ST_DATA_NODE  *stDataNode;
    ST_MOS_LIST   stNodeList;
} READ_MEDIA_DATA_NODE;

typedef struct
{
    _UI    id;                     // 同缓存器
    _INT   iCamid;
    _INT   iStreamId;
    _UI    uiReadMod;
    _UI    uiIsFirst;
    _UI    uiMaxHisCount;
    _US    usSeqNumIndex;          //包序列号
    _UI    uiTimeStamp;            //时间戳
    _UI    uiEncodeType;
    ST_FRAME_NODE *stFrame;
    ST_DATA_NODE  *stDataNode;
    ST_MOS_LIST_NODE *stNode;
    ST_MOS_LIST   stNodeList;
} READ_PLAYBACK_DATA_NODE;


//live audio handler data struct
typedef struct
{
    _UI    id;                     // 同缓存器
    _INT   iCamid;
    _INT   iStreamId;
    _UI    uiReadMod;
    _UI    uiKeyQuality;
    _UI    uiMaxHisCount;
    _US    usSeqNumIndex;          //包序列号
    _US    usHisTimeMsec;
    _UI    uiTimeStamp;            //时间戳
    ST_FRAME_NODE *stFrame;
    ST_DATA_NODE  *stDataNode;
    ST_MOS_LIST   stNodeList;
} READ_AUDIO_DATA_NODE;


//audio speaker reader
typedef struct
{
    _UI    uiUseFlag;
    _UI    uiSessionID;                     //
    _UI    uiReadBufID;                     // 同缓存器;
    _UI    uiSampleRate;
    _UI    uiChannel;
    _UI    uiBitrate;
    _UI    uiEncodeType;
    _UC    ucsPeerId[64];
    _UC    ucsReadBuf[640];
} READ_PLAY_AUDIO_DATA_NODE;

//audio speaker writer
typedef struct
{
    _UI    uiUseFlag;
    _UI    uiSessionID;                        //  流媒体通道ID
    _UI    uiSampleRate;
    _UI    uiChannel;
    _UI    uiBitrate;
    _UI    uiPlayId;                            // 流媒体管理ID
    _UI    uiBussType;                          // 流媒体类型
    _UI    uiEncodeType;
    _UC    ucsWriteBuf[640];
    _UC    ucsPeerId[64];
    ST_MOS_LIST_NODE stNode;
} WRITE_PLAY_AUDIO_DATA_NODE;

//audio speaker manager
typedef struct stru_AUDIO_TASKMNG
{
    _UI    uiInitFlag;
    _UI    uiStartFlag;
    _UI    uiMaxCnt;
    _UI    uiPlayId;                            // 流媒体管理ID
    _UC    pucResourceID[33];
    _HMUTEX hMutex;                             // 互斥体
    READ_PLAY_AUDIO_DATA_NODE  *hAudioRead;
    WRITE_PLAY_AUDIO_DATA_NODE *hAudioWrite;
    ST_MOS_LIST stBussList;
}ST_AUDIO_TASKMNG;


#ifdef __cplusplus
}
#endif
#endif
