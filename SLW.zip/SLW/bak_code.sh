#!/bin/sh
name=`date +%Y%m%d`
git archive dev --prefix='cn21sdk400/' --format=zip > /mnt/hgfs/share/cn21sdk400-${name}-dev.zip
